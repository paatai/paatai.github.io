# Lean 4 formalization of Theorem 1.1: the optimal reverse Khinchin constant for biased bits

This is a Lean 4 formalization of Theorem 1.1 (the Main Theorem) of P. Ivanisvili, *A sharp
reverse Khinchin-type inequality for biased bits: the optimal constant R(q) for every
q ∈ (0,1)*, https://paatai.github.io/ai-proofs/#12.

For `q ∈ (0,1)` let `χ₁, χ₂, …` be independent, each equal to `√((1−q)/q)` with probability `q`
and to `−√(q/(1−q))` with probability `1 − q`, and let `R(q)` be the best constant in
`E|∑ αᵢχᵢ| ≤ R(q) ‖α‖₂`. Theorem 1.1 states that, for every `q ∈ (0,1)`,

    R(q) = 2 √(q(1−q)) max_{k ≥ 1} √k q̂^(k−1),    q̂ = max(q, 1−q),

that the maximum is attained at `k = ⌊1/(p(2−p))⌋`, `p = min(q, 1−q)` (and also at `k − 1`
exactly when `p = 1 − √((k−1)/k)`), and that the supremum is attained at `α = (1,…,1)/√k`. It
also gives the bands of `q` on which each `k` is optimal, `R(1 − q) = R(q)`, and
`R(q) → √(2/e)` as `q → 0` and as `q → 1`.

* **Main theorem:** `ReverseKhinchin.mainTheorem`, in `ReverseKhinchin/MainTheorem.lean`. It
  states every sentence of Theorem 1.1, for every `q ∈ (0,1)`, with no hypotheses.
* **Lean:** `leanprover/lean4:v4.35.0`, pinned in `lean-toolchain`.
* **Mathlib:** `v4.35.0`, commit `56a005855ea17e0b0958f73ec801ae140b0a1679`, pinned in
  `lakefile.toml` and `lake-manifest.json`.

## Building

Install [elan](https://github.com/leanprover/elan), the Lean version manager, and run in this
directory

```bash
lake exe cache get && lake build
```

`lake exe cache get` downloads the prebuilt Mathlib, and `lake build` builds the project: the
Lean kernel checks every proof and every certificate. Afterwards

```bash
lake env lean scripts/Axioms.lean
```

prints the axioms of `mainTheorem` and of 49 further theorems: only `propext`,
`Classical.choice` and `Quot.sound`. The sources contain no `sorry`, `axiom` or `native_decide`.

The build takes roughly 35–45 CPU-hours, almost all of it the kernel checking certificates, and
about 23 GB of disk. `lake build` runs one job per core and needs about 6 GB of memory plus up to
4 GB per job; "Building" in `OVERVIEW.md` shows how to check the largest modules a few at a time.
Do not run `lake update`, which would move the pinned versions.

## Contents

The 823 Lean files have about 534,000 lines: about 508,000 lines in 720 files are
machine-generated certificate data, checked by the kernel with `decide +kernel`, and about
26,000 lines in 103 files are definitions and proofs.

* `ReverseKhinchin/`: the Lean sources.
* `OVERVIEW.md`: how the formal proof follows the paper, the main theorems proved, the cost of
  the build, the layout of the files, and how to regenerate the certificate data.
* `STATEMENT.md`: the Lean statement compared with the paper line by line, the differences
  between the formal proof and the paper's proof, what is not formalized, and the trust base.
* `STATUS.md`: details of the formalization of Sections 13–15.
* `scripts/`: the Python scripts that generated the certificate data (not trusted: the kernel
  re-checks their output), and `scripts/Axioms.lean`.

Not formalized: Theorem 10.1 and the characterizations of the equality cases. Theorems 13.11
and 14.1 are replaced by one statement with new certificates, and Theorem 15.1 is proved with
the constant 8551/10000 in place of 171/200 (`STATEMENT.md`, Sections 5e and 6). The
formalization should therefore be cited for Theorem 1.1 only.
