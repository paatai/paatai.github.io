# Reverse Khinchin inequality for biased bits: a Lean 4 formalisation

This repository is a Lean 4 + Mathlib formalisation of the Main Theorem (Theorem 1.1) of Paata
Ivanisvili, *A sharp reverse Khinchin-type inequality for biased bits: the optimal constant R(q)
for every q ∈ (0,1)*, for every `q ∈ (0,1)`. Every proof, including every computer-assisted
certificate, is checked by the Lean kernel.

For `q ∈ (0,1)`, let `χ₁, χ₂, …` be i.i.d. with `P(χ = √((1−q)/q)) = q` and
`P(χ = −√(q/(1−q))) = 1 − q`. Let `R(q)` be the best constant in `E|∑ αᵢχᵢ| ≤ R(q) ‖α‖₂`. The
paper's Main Theorem states

  `R(q) = M(q) := 2 √(q(1−q)) max_{k ≥ 1} √k q̂^{k−1}`,  `q̂ = max(q, 1−q)`.

The maximum is attained at `k = ⌊1/(p(2−p))⌋`, `p = min(q, 1−q)` (and also at `k − 1` exactly when
`p = 1 − √((k−1)/k)`), and the supremum is attained at `α = (1,…,1)/√k`. With
`q_k = 1 − √((k−1)/k)` and `τ = √(q(1−q))`, `R(q) = 2√k (1−q)^{k−1} τ` on the band
`[q_{k+1}, q_k]`: `2τ` on `[q₂, 1/2]`, `2√2 (1−q) τ` on `[q₃, q₂]`, `2√3 (1−q)² τ` on `[q₄, q₃]`,
`4 (1−q)³ τ` on `[q₅, q₄]`, and so on. Moreover `R(1 − q) = R(q)`, and `R(q) → √(2/e)` as
`q → 0` and as `q → 1`.

## The main theorem

`mainTheorem` (`ReverseKhinchin/MainTheorem.lean`) states every sentence of Theorem 1.1, for
every `q ∈ (0,1)`, with no hypotheses. It is a conjunction of twelve parts:

1. for every `q ∈ (0,1)`, `MainStatement q` ((S), the maximiser `k`, the tie rule and the
   extremiser; `ReverseKhinchin/Statement.lean`) and `R q = Mconst q`, where
   `R q = sSup (ratioSet q)` is the supremum of `E|∑ αᵢχᵢ| / ‖α‖₂` over `n ≥ 1` and
   `α ∈ ℝⁿ \ {0}`;
2. on the band `[q_{k+1}, q_k]` the maximiser is `k`, and `M = T_k = 2√k (1−q)^{k−1} τ`;
3. the neighbours `k ± 1` tie with `k` at the two ends of the band;
4. to 8. the table of `R(q)` on `[q₂, 1/2]`, `[q₃, q₂]`, `[q₄, q₃]`, `[q₅, q₄]` and
   `[q_{k+1}, q_k]` for `k ≥ 5`, with `q₂ = 1 − 1/√2`, `q₃ = 1 − √(2/3)`, `q₄ = 1 − √3/2` and
   `q₅ = 1 − 2/√5`;
9. `R(1 − q) = R(q)`;
10. and 11. `R(q) → √(2/e)` as `q → 0⁺` and as `q → 1⁻`;
12. the decimal values in the theorem (`q₂ = 0.2928…`, `q₃ = 0.1835…`, `q₄ = 0.1339…`,
    `q₅ = 0.1055…`, `√(2/e) = 0.85776…`), as strict bounds by rationals.

[`STATEMENT.md`](STATEMENT.md) compares the Lean statement with the paper line by line
(Section 3), and lists the parts of the paper that are not formalised (Section 6). None of them is
part of Theorem 1.1.

Soundness:

* There is no `sorry`, `admit`, `axiom`, `native_decide`, `implemented_by` or `extern`.
* `mainTheorem`, and every other theorem printed by `scripts/Axioms.lean` (50 in all), depends
  only on `propext`, `Classical.choice` and `Quot.sound`.
* The certificates are checked with `decide +kernel`, in exact arithmetic (rationals, signed
  dyadics and natural numbers).

## How the proof is organised

The formal proof follows the paper's proof of Theorem 1.1:

* **`q ∈ [q₅, 1 − q₅]`.** Theorems 5.1, 6.1, 7.1, 8.1 and 9.1 (the regimes k = 1, 2, 3, 4) give
  the upper bound `E|∑ αᵢχᵢ| ≤ M(q) ‖α‖₂`. Their computer-assisted parts (Propositions 5.7, 6.4,
  7.4, 8.10 and 9.8) use the paper's certificates, re-checked by kernel checkers that are proved
  sound in Lean.
* **`q ∈ (0, q₅)`.** Sections 11–12 (Poissonisation and localisation) reduce the upper bound to
  ID*(C₅), an inequality for compound Poisson sums with jumps in `[−77/50, 77/50]` that does not
  involve `q` (`IDstar`, `Small/Reduction.lean`). Sections 13–15 prove it (`RC.idstar`,
  `RC/IDstar.lean`). One exact checker, `checkCell` (the chain of the paper's Lemma 15.7), checks
  all the moment certificates:
  * the light far region (Theorem 15.1) uses the paper's 10,966 certificates of
    Proposition 15.10;
  * the band lemma and the heavy far region (Theorems 13.11 and 14.1) are proved together, as the
    single case `V₊ ≥ 1/2`, with 1,264 new certificates.

  Two constants inside this part of the proof differ from the paper. The proof uses `θ = 9/10`
  instead of `17/20` (ID*(C₅) allows any `θ > 0`). The certificates are checked against
  `8551/10000` instead of `171/200`; both are below `C₅ = 0.85510045…`. Neither constant appears
  in Theorem 1.1 (see `STATEMENT.md`, Section 5e).
* **`q ∈ (1 − q₅, 1)`.** This follows from the symmetry `R(1 − q) = R(q)` (Lemma 4.1).
* Theorem 4.2 gives the lower bound, the maximiser, the tie rule and the extremiser. The bands,
  the table, the limits and the decimals follow from (S).

[`STATUS.md`](STATUS.md) describes the formalisation of Sections 13–15 in more detail, with notes
for continuing the work.

## What is proved

| Lean theorem | Statement |
|---|---|
| `mainTheorem` (`MainTheorem.lean`) | Theorem 1.1, every sentence, for every `q ∈ (0,1)` |
| `mainStatement_all` (`MainTheorem.lean`) | `MainStatement q` for every `q ∈ (0,1)`: (S), the maximiser, the tie rule and the extremiser |
| `R_eq_Mconst` (`MainTheorem.lean`) | `R(q) = M(q)` for every `q ∈ (0,1)`, where `R q = sSup (ratioSet q)` |
| `band_max`, `band_ties`, `R_band` (`MainTheorem.lean`) | the bands `[q_{k+1}, q_k]`: `k` maximises, `M = R = T_k`, and `k ± 1` tie at the ends |
| `decimals` (`MainTheorem.lean`) | the decimal values of `q₂`, `q₃`, `q₄`, `q₅` and `√(2/e)` |
| `tendsto_Mconst_zero`, `tendsto_Mconst_one` (`Limit.lean`) | `M(q) → √(2/e)` as `q → 0⁺` and as `q → 1⁻` |
| `RC.idstar` (`RC/IDstar.lean`) | ID*(C₅) on `[−77/50, 77/50]` (Sections 13–15), with `θ = 9/10` |
| `RC.heavy_region` (`RC/HeavyRegion.lean`) | `V₊ ≥ 1/2` implies `E|Z_K| ≤ max(g(λ₊), 8551/10000)` (the cases of Theorems 13.11 and 14.1 together) |
| `RC.light_region` (`RC/LightRegion.lean`) | Theorem 15.1: `V₊, V₋ < 1/2` implies `E|Z_K| ≤ 8551/10000` |
| `mainStatement_of_IDstar` (`Small/Main.lean`) | Theorem 1.1, every clause, for every `q ∈ (0,1)`, from `IDstar` |
| `upperBound_of_IDstar` (`Small/Reduction.lean`) | Sections 11–12: `IDstar` implies `E|∑ αᵢχᵢ| ≤ M(q) ‖α‖₂` for every `q ∈ (0, q₅)` |
| `mainTheorem_q5` (`K4/Upper.lean`) | Theorem 1.1, every clause, for every `q ∈ [q₅, 1 − q₅]`, `q₅ = 1 − √(4/5)` |
| `upperBound_band4` (`K4/Upper.lean`) | Theorem 9.1(a): `E|∑ αᵢχᵢ| ≤ 4 (1−q)³ √(q(1−q)) ‖α‖₂` for `q ∈ [q₅, q₄]` |
| `mainTheorem_q4` (`K3L/Upper.lean`) | Theorem 1.1, every clause, for every `q ∈ [q₄, 1 − q₄]`, `q₄ = 1 − √3/2` |
| `upperBound_band3b` (`K3L/Upper.lean`) | Theorem 8.1(a): `E|∑ αᵢχᵢ| ≤ 2√3 (1−q)² √(q(1−q)) ‖α‖₂` for `q ∈ [q₄, q_L]` |
| `mainTheorem_qL` (`K3/Upper.lean`) | Theorem 1.1, every clause, for every `q ∈ [q_L, 1 − q_L]`, `q_L = 25/169` |
| `upperBound_band3a` (`K3/Upper.lean`) | Theorem 7.1(a): `E|∑ αᵢχᵢ| ≤ 2√3 (1−q)² √(q(1−q)) ‖α‖₂` for `q ∈ [q_L, q₃]` |
| `mainTheorem_q₃` (`K2/Upper.lean`) | Theorem 1.1, every clause, for every `q ∈ [q₃, 1 − q₃]`, `q₃ = 1 − √(2/3)` |
| `upperBound_band2` (`K2/Upper.lean`) | Theorem 6.1(a): `E|∑ αᵢχᵢ| ≤ 2√2 (1−q) √(q(1−q)) ‖α‖₂` for `q ∈ [q₃, q₂]` |
| `mainTheorem_central` | Theorem 1.1, every clause, for every `q ∈ [q₂, 1 − q₂]`, `q₂ = 1 − 1/√2` |
| `theorem_5_1` | Theorem 5.1(a)+(b): `R(q) = 2√(q(1−q))` if and only if `q ∈ [q₂, 1 − q₂]` |
| `theorem_5_1_b` | Theorem 5.1(b): `R(q) ≥ 2√2 max(q,1−q) √(q(1−q)) > 2√(q(1−q))` outside `[q₂, 1 − q₂]` |
| `mainStatement_parts` | for every `q ∈ (0,1)`: all of Theorem 1.1 except the upper bound (Theorem 4.2) |
| `Mconst_band`, `Mconst_band_le_half`, `hk_tie_ends` | for every `q ∈ (0,1)`: `k` maximises on the band `[q_{k+1}, q_k]`, where `M = T_k`, with ties at the ends |
| `ratioSet_one_sub` | Lemma 4.1: `R(1 − q) = R(q)` |

Theorems without a file name are in `ReverseKhinchin/Main.lean`; all files are under
`ReverseKhinchin/`. The intermediate conditional theorems `mainStatement_of_upperBound_lt_q₂`,
`…_lt_q₃`, `…_lt_qL`, `…_lt_q4` and `…_lt_q5` (Theorem 1.1 on `(0,1)` from the upper bound below
`q₂`, …, `q₅`) remain in the files; `mainStatement_of_IDstar` uses the last one.

## Building

Requirements: [elan](https://github.com/leanprover/elan). The toolchain `leanprover/lean4:v4.35.0`
is pinned in `lean-toolchain`, and Mathlib `v4.35.0` is pinned in `lakefile.toml` and
`lake-manifest.json`.

```bash
lake exe cache get                 # download prebuilt Mathlib
lake build                         # build and kernel-check everything
lake env lean scripts/Axioms.lean  # print the axioms of the main theorems
```

A full build of this project, excluding Mathlib, takes about 34 CPU-hours. Almost all of it is the
kernel checking certificates:

* about 12 CPU-hours for the 10,966 light-region certificates of Proposition 15.10 in
  `ReverseKhinchin/RC/Data/L00.lean` to `L51.lean`;
* about 735 CPU-minutes for the 7,261 vertex-certificate boxes of Theorem 9.1 in
  `ReverseKhinchin/Cert/DataK4/Box/`;
* about 260 CPU-minutes for the 81,975 two-coordinate boxes of Theorem 7.1 in
  `ReverseKhinchin/Cert/DataK3/Box/`;
* about 125 CPU-minutes each for the 55,515 boxes of Theorem 6.1 in
  `ReverseKhinchin/Cert/DataK2/Box/` and for the 1,421 vertex-certificate boxes of Theorem 8.1 in
  `ReverseKhinchin/Cert/DataK3L/Box/`;
* about 45 CPU-minutes for the 1,264 heavy-region leaves in `ReverseKhinchin/RC/Data/H00.lean` to
  `H04.lean`;
* some minutes each for the cells of Propositions 5.7(i), 6.4(i), 7.4(i), 8.10(i) and 9.8(i).

Each data module of Sections 13–15 (`ReverseKhinchin/RC/Data/`) needs 7–10 GB of memory while it
is checked. On the machine used for development (8 cores, 47 GB of memory), the 52 light-region
modules were built five at a time, which took about 2.5 hours. If memory is short, build them
first with bounded parallelism:

```bash
lake build ReverseKhinchin.RC.Light ReverseKhinchin.RC.Heavy ReverseKhinchin.RC.DataElab
ls ReverseKhinchin/RC/Data/*.lean | sed 's|\.lean$||; s|/|.|g' | xargs -P 5 -I{} lake build {}
lake build
```

The only remaining warnings are Lean's suggestion to adopt the module system for files importing
`Mathlib`.

## Layout

| File | Content |
|---|---|
| `ReverseKhinchin/Defs.lean` | bits, `χ`, expectations as finite sums, `meanAbs`, `l2norm`, `ratioSet`, `M(q)`, `UpperBound` |
| `ReverseKhinchin/Statement.lean` | `MainStatement q`: Theorem 1.1 at a fixed `q`; `q₂` |
| `ReverseKhinchin/Expect.lean` | linearity, independence and symmetry of `expect`; `τ` |
| `ReverseKhinchin/LowerBound.lean` | Theorem 4.2: equal coefficients, the maximiser `k(q)`, the tie rule, attainment |
| `ReverseKhinchin/Assembly.lean` | `MainStatement q` from `UpperBound q` |
| `ReverseKhinchin/Param.lean` | the parametrisation `q = 1/(1+u²)` |
| `ReverseKhinchin/Moments.lean`, `PowerSums.lean` | moments up to order six (Lemmas 4.4, 4.6), power sums (Lemma 4.7) |
| `ReverseKhinchin/OneCoord.lean` | the one-coordinate identity (Lemma 4.3) and the reduction of Section 4.6 |
| `ReverseKhinchin/SixMoment.lean` | six-moment cells (Lemmas 4.10, 4.14) |
| `ReverseKhinchin/Cert/QQ.lean`, `Poly.lean`, `Poly2.lean` | exact rational arithmetic and Bernstein positivity checkers, with soundness proofs |
| `ReverseKhinchin/Cert/Cell.lean` | the kernel-checkable cell checker `checkTree` and `checkTree_sound` (Lemma 4.15) |
| `ReverseKhinchin/Cert/Data/*.lean` | the 379 cells of Proposition 5.7(i), checked by `decide +kernel` |
| `ReverseKhinchin/Quartic.lean`, `QuarticBox.lean` | the quartic two-extremiser certificate (Lemmas 5.3–5.4, Proposition 5.7(ii)) |
| `ReverseKhinchin/NearDictator.lean` | the near-dictator bound (Lemma 5.6) |
| `ReverseKhinchin/Central.lean` | Theorem 5.1(a) and `MainStatement q` on `[q₂, 1 − q₂]` |
| `ReverseKhinchin/Bits.lean` | the three-bit bound (Lemma 6.3, upper bound), 256 kernel-checked sign patterns |
| `ReverseKhinchin/Cert/DataK2/OneA.lean`, `OneB.lean`, `K2/Cells.lean` | k=2: the 784 cells of Proposition 6.4(i) and the one-coordinate case of Theorem 6.1 |
| `ReverseKhinchin/TwoCoord.lean` | the two-coordinate route (Lemmas 4.16, 4.19, 4.21, 4.34, 6.2) and the reduction of Section 4.7 |
| `ReverseKhinchin/Cert/Env.lean`, `Cert/BoxDefs.lean` | the envelope domination checker (W1) and the box checker (lp, near-circle, m-split, small, guillotine trees) |
| `ReverseKhinchin/Cert/DataK2/Box/*.lean`, `Cert/DataK2/Boxes.lean` | k=2: the 55,515 boxes of Proposition 6.4(ii), checked by `decide +kernel` |
| `ReverseKhinchin/K2/Boxes.lean` | soundness of the box checker (Lemmas 4.23, 4.35, 4.36–4.39), `checkBTree_sound` |
| `ReverseKhinchin/K2/Upper.lean` | Theorem 6.1, Theorem 1.1 on `[q₃, 1 − q₃]` |
| `ReverseKhinchin/Target.lean` | the targets `T_k`, unimodality of `T̃_k`, the rational target (4.3) |
| `ReverseKhinchin/K3/Basic.lean` | k=3: Lemma 7.2, Lemma 7.3 (256 kernel-checked sign patterns), target and cell-weight bounds |
| `ReverseKhinchin/Cert/DataK3/One*.lean`, `K3/Cells.lean` | k=3: the 2,704 cells of Proposition 7.4(i) and the one-coordinate case of Theorem 7.1 |
| `ReverseKhinchin/Cert/BoxDefsG.lean`, `BoxRoute.lean` | the box checker and the two-coordinate route for a general target |
| `ReverseKhinchin/Cert/DataK3/Box/*.lean`, `Cert/DataK3/Boxes.lean` | k=3: the 81,975 boxes of Proposition 7.4(ii), checked by `decide +kernel` |
| `ReverseKhinchin/K3/Upper.lean` | Theorem 7.1, Theorem 1.1 on `[q_L, 1 − q_L]` |
| `ReverseKhinchin/Moments10.lean`, `Cert/Obj10.lean`, `TenMoment.lean` | moments to order ten (Lemma 4.6) and the ten-moment objective bound (Definition 4.11, Lemma 4.12), for Theorems 8.1–10.1 |
| `ReverseKhinchin/Cert/Cell10.lean`, `TenCell.lean` | the ten-moment cell checker `checkLeaf10` on guillotine trees and its soundness |
| `ReverseKhinchin/Cert/DataK3L/Ten*.lean`, `K3L/Cells.lean` | Theorem 8.1: the 288 ten-moment cells of Proposition 8.10(i) and the one-coordinate case `k3l_one_coord` |
| `ReverseKhinchin/Cert/Vertex.lean`, `Vertex.lean` | the vertex-certificate checker `checkVC` (Section 4.9) and its soundness `checkVC_sound` (Lemma 4.32), for Theorems 8.1–10.1 |
| `ReverseKhinchin/Cert/Bits4.lean`, `K3L/Bits.lean` | Lemma 8.3: the three-bit lemma on `[q_U, q_L]` and the four-bit lemma on `[q₄, q_L]` (all 65,536 functions of four bits, kernel-checked) |
| `ReverseKhinchin/Cert/K3LDefs.lean` | the box checker of Theorem 8.1: lpv, nc and ms5 boxes (pieces (A3)/(B3), TC, SG, TCS with test (A4)), guillotine trees `VTree` |
| `ReverseKhinchin/K3L/Peel.lean`, `K3L/Boxes.lean` | the peeling identity (Lemma 4.25) and the soundness of the checker (Lemmas 4.33, 8.5, 8.7, 8.9), `checkVTree_sound` |
| `ReverseKhinchin/Cert/DataK3L/Box/*.lean`, `Cert/DataK3L/Boxes.lean` | Theorem 8.1: the 1,421 boxes of Proposition 8.10(ii), checked by `decide +kernel` |
| `ReverseKhinchin/K3L/Upper.lean` | Theorem 8.1, Theorem 1.1 on `[q₄, 1 − q₄]` |
| `ReverseKhinchin/Cert/BitsK4.lean`, `K4/Bits.lean` | Lemma 9.2 (three- and four-bit lemmas on `[q₅, q₄]`) and the five-bit OR bound of Lemma 4.18 |
| `ReverseKhinchin/Cert/EnvD.lean`, `Cert/VertexX.lean`, `VertexX.lean` | vertex certificates with polynomials of any degree and their soundness |
| `ReverseKhinchin/Cert/K4Defs.lean`, `Cert/K4Split.lean` | the box checker of Theorem 9.1 (TCN pieces with inner pieces (A4), TC4, TC4S, SG3) and split kernel checks of vertex certificates |
| `ReverseKhinchin/K4/Peel.lean`, `K4/Boxes.lean` | the second peeling and the soundness of the checker (Lemmas 9.5, 9.7), `checkWTree_sound` |
| `ReverseKhinchin/Cert/K4W.lean`, `Cert/DataK4/Ten*.lean` | Theorem 9.1: the weight `wK4` and the 1,268 ten-moment cells of Proposition 9.8(i) |
| `ReverseKhinchin/Cert/DataK4/Box/*.lean`, `Cert/DataK4/Boxes.lean` | Theorem 9.1: the 7,261 boxes of Proposition 9.8(ii), checked by `decide +kernel` |
| `ReverseKhinchin/K4/Upper.lean` | Theorem 9.1, Theorem 1.1 on `[q₅, 1 − q₅]` |
| `ReverseKhinchin/Small/Poisson.lean` | Poissonisation (Section 11): the transfer identity and `E|α·χ|` against `E|Z_K|` |
| `ReverseKhinchin/Small/Localise.lean` | localisation of maximisers (Theorem 12.1(a)–(e)) |
| `ReverseKhinchin/Small/Reduction.lean` | `IDstar` (ID*(C₅)), `C₅`, and the reduction `upperBound_of_IDstar` for `q ∈ (0, q₅)` |
| `ReverseKhinchin/Small/Main.lean` | `mainStatement_of_IDstar`: Theorem 1.1 on `(0,1)` from `IDstar` |
| `ReverseKhinchin/Small/Compound.lean` | finite compound Poisson sums `pe L f = E f(Z_L)` for lists of jumps with rates: linearity, independence, growth bounds |
| `ReverseKhinchin/Small/CompoundOrder.lean` | exchange and merging of atoms, the convex order `CxLe` for the functions `|c + ·|`, the two-point spread (Lemma 15.2) and the top-up |
| `ReverseKhinchin/Small/CompoundMoments.lean` | cumulants, the Stein and Chen identities, the moment recursion (Lemma 14.5) |
| `ReverseKhinchin/Small/CompoundLink.lean` | `poisAbs_eq_pe`: the Poisson expectation of Section 11 as a compound Poisson sum |
| `ReverseKhinchin/RC/Basic.lean` | kernel arithmetic: signed dyadics and the Kronecker positivity test `kron` |
| `ReverseKhinchin/RC/Cell.lean`, `RC/Check.lean` | the cells of the rest-class certificates (near split, chord, light) and the cell checker `checkCell` (Lemma 15.7) |
| `ReverseKhinchin/RC/Moments.lean`, `RC/Tables.lean`, `RC/TablesOK.lean` | moment polynomials, the generated moment and product tables (degrees 14, 16, 18) and their kernel checks |
| `ReverseKhinchin/RC/Cover.lean`, `RC/Light.lean` | the required roots and subdivision trees of the light region (Lemma 15.9), `coverAll`, and the light leaf check |
| `ReverseKhinchin/RC/Heavy.lean` | the heavy-region checker: rate boxes, omitted, vacuous, slope and rest-class leaves, the coverage walk `coverHeavy` |
| `ReverseKhinchin/RC/DataElab.lean` | `data%`: elaboration of large certificate literals without info trees |
| `ReverseKhinchin/RC/Data/L*.lean`, `RC/LightData.lean` | the 10,966 light-region certificates of Proposition 15.10, checked by `decide +kernel`, and their coverage check |
| `ReverseKhinchin/RC/Data/H*.lean`, `RC/HeavyData.lean` | the 1,264 heavy-region leaves, checked by `decide +kernel`, and their coverage check |
| `ReverseKhinchin/RC/Sound/Dy.lean`, `Kron.lean`, `Rest.lean`, `Mass.lean`, `Root.lean`, `Spread.lean` | soundness, part 1: the dyadics, `kron`, rest classes, masses and the rest rectangle (Lemma 15.9), window spreads (Lemmas 15.2–15.4, 15.6) |
| `ReverseKhinchin/RC/Sound/Dual.lean`, `Outer.lean`, `Moments.lean`, `Rows.lean`, `Cell.lean` | soundness, part 2: linear duals, the outer majorant, the moment tables, the Lagrangian rows, and `checkCell_sound` (Lemma 15.7) |
| `ReverseKhinchin/RC/Sound/Cover.lean`, `Light.lean`, `LightFar.lean` | soundness, part 3: the coverage check and the light far region (Lemmas 15.8–15.9, Theorem 15.1) |
| `ReverseKhinchin/RC/Sound/HeavyBox.lean`, `HeavyCover.lean`, `Slope.lean`, `HeavyFar.lean` | soundness, part 4: heavy boxes, the heavy coverage walk, slope cells and the heavy far region |
| `ReverseKhinchin/RC/LightRegion.lean`, `RC/HeavyRegion.lean` | `light_region` and `heavy_region` from the certified data |
| `ReverseKhinchin/RC/IDstar.lean` | ID*(C₅): `idstar : IDstar` and `C5_ge` |
| `ReverseKhinchin/Limit.lean` | `√(2 e^{−(1+2q)/(1−q)}) ≤ M(q) ≤ √(2 e^{q−1})` on `(0, 1/2]`, and `M(q) → √(2/e)` at the ends of `(0, 1)` |
| `ReverseKhinchin/Main.lean` | Theorem 5.1 and the central range, Theorem 4.2's parts of `MainStatement`, the bands, the symmetry, the conditional statements |
| `ReverseKhinchin/MainTheorem.lean` | `R q = sSup (ratioSet q)`, the bands and the table, the decimals, and `mainTheorem` |
| `scripts/gen_cells.py`, `gen_cells_k2.py`, `gen_cells_k3.py`, `gen_cells_k3l.py`, `gen_cells_k4.py`, `gen_boxes_k2.py`, `gen_boxes_k3.py`, `gen_boxes_k3l.py`, `gen_boxes_k4.py`, `gen_bits4.py`, `gen_bits_k4.py`, `gen_quartic.py` | untrusted generators of the certificate data of Theorems 5.1–9.1 |
| `scripts/k2box_mirror.py`, `scripts/vc_mirror.py`, `scripts/k3lbox_mirror.py`, `scripts/k4box_mirror.py` | exact Python mirrors of the box checkers and of the vertex-certificate checker, used to pre-verify generated data |
| `scripts/rc/*.py` | Sections 13–15, untrusted: the cell geometry (`rcgeom.py`); exact mirrors of `RC/Cell.lean`, `RC/Check.lean` and `RC/Cover.lean` (`rccell.py`, `rccheck.py`, `rccover.py`); the conversion of the paper's light certificates (`rcmirror.py`, `rcser.py`, `rcconv.py`, `rcconv2.py`, `rcbatch.py`); the heavy-region generator (`rcheavy.py`, `rcslope.py`, `hlp.py`); the path to the paper's numerics (`rqb.py`); the Lean writer (`gen_lean.py`) |
| `scripts/Axioms.lean` | `#print axioms` for the final theorems |

## Regenerating the certificate data

The generated Lean data are committed, and you don't need to regenerate them to check the proof.
To regenerate the data of Theorems 5.1–9.1:

```bash
python3 scripts/gen_cells.py <cover-dir>        # <cover-dir>: RQ-A/outputs/cover/ of the paper's certificate archive
python3 scripts/gen_cells_k2.py <cover_k2-dir>  # RQ-A/outputs/cover_k2/
python3 scripts/gen_boxes_k2.py <outputs-dir>   # RQ-A/outputs/ (reads k2_manifest.json and cover2c/)
python3 scripts/gen_cells_k3.py <k3-one-dir>    # RQ-A/outputs/k3/one/
python3 scripts/gen_boxes_k3.py <outputs-dir>   # RQ-A/outputs/ (reads k3_manifest.json and k3/cover2c/)
python3 scripts/gen_cells_k3l.py <k3b-dir>      # RQ-A/outputs/k3b/ (the ten-moment cells one_*.json)
python3 scripts/gen_boxes_k3l.py <outputs-dir>  # RQ-A/outputs/ (reads k3b_manifest.json and k3b/)
python3 scripts/gen_bits4.py                    # Lemma 8.3(b), four-bit Bernstein data
python3 scripts/gen_bits_k4.py                  # Lemma 9.2, bit-lemma Bernstein data on [q5, q4]
python3 scripts/gen_cells_k4.py <k4-dir>        # RQ-A/outputs/k4/ (the ten-moment cells one_*.json)
python3 scripts/gen_boxes_k4.py <outputs-dir>   # RQ-A/outputs/ (reads k4_manifest.json and k4/)
python3 scripts/gen_quartic.py                  # prints the quartic-box polynomials (needs sympy)
```

The public certificate archive lacks 28 of the 76 k = 4 region files (`k4/p_0..p_7`,
`k4/p_18..p_37`). They were regenerated with the paper's own generator
(`RQ-A/scripts/run_k4.sh --only p_0,…`); since the kernel re-checks every box, their provenance
does not matter for correctness.

The data of Sections 13–15 are written by the scripts in `scripts/rc/`. They need Python 3 with
numpy, scipy and python-flint, and the paper's numerics: set `RQB_NUMERICS` to the directory
`Rq_proof_source/RQ-B/numerics` of the paper's code archive. The light-region input is the
paper's certificates `RQ-B/numerics/cover_final/nsplit_D14.jsonl.xz`, `chord_D14.jsonl.xz` and
`light_vl025_D18.jsonl.xz` of the certificate archive, decompressed into `$CERTS`. From
`scripts/rc/`:

```bash
python3 gen_lean.py tables ../../ReverseKhinchin/RC/Tables.lean      # moment and product tables
# light far region (Proposition 15.10): convert, re-encode for checkCell, sort into coverage order
for f in nsplit_D14 chord_D14 light_vl025_D18; do
  python3 rcbatch.py $CERTS/$f.jsonl 0 8 --all --out $OUT/$f.rc.jsonl
  python3 rcconv2.py $OUT/$f.rc.jsonl $OUT/$f.jsonl 8
done
python3 rccover.py --sort $OUT/all_sorted.jsonl $OUT/nsplit_D14.jsonl $OUT/chord_D14.jsonl $OUT/light_vl025_D18.jsonl
python3 gen_lean.py light $OUT/all_sorted.jsonl ../..                # RC/Data/L*.lean, RC/LightData.lean
# heavy far region (V+ >= 1/2): rate boxes of P1 to level 3, of P2 to level 6
python3 rcheavy.py tree p1 5 3 $OUT/tree.jsonl 8
python3 rcheavy.py tree p2 5 6 $OUT/tree.jsonl 8
python3 gen_lean.py heavy $OUT/tree.jsonl ../..                      # RC/Data/H*.lean, RC/HeavyData.lean
```

With the committed scripts, these commands reproduce `RC/Tables.lean`, `RC/Data/H*.lean` and
`RC/HeavyData.lean` byte for byte. The committed light data are the output of the same commands
with `scripts/rc/` as of commit `04872af`, which added them. Later changes to the scripts, made
for the heavy region, show up in a rerun with the current scripts in two ways. The margins of the
converted duals are now raised by twice their sampled float deficit, which changes the numbers in
24 of the 10,966 light certificates. A new field in the cell records changes the line lengths that
decide where one data module ends, so some leaves move to a neighbouring module. The leaves
themselves are the same, and all of them pass the exact mirror with the same largest bound,
`0.8549979`.

The output of these scripts is not trusted. The kernel re-checks all of it during `lake build`.
