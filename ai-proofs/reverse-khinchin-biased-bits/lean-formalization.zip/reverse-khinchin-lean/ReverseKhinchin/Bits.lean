import ReverseKhinchin.Cert.Poly2
import ReverseKhinchin.Param

/-!
# The three-bit lemma (Lemmas 4.17 and 6.3 of the paper)

For `f : {0,1}³ → {±1}` let `Δᵢ(f) = E[f | xᵢ = 1] - E[f | xᵢ = 0]`. The level-one identity
`E[f χᵢ] = τ Δᵢ(f)` (4.7) and Cauchy–Schwarz give, with `f = sgn(∑ cᵢχᵢ)`,

  `E|∑ cᵢ χᵢ| = τ ∑ cᵢ Δᵢ(f) ≤ τ |c| (∑ Δᵢ(f)²)^{1/2}` (Lemma 4.17).

We write `Δᵢ(f)` as an integer polynomial in `q` whose coefficients depend on the eight values of
`f` (`dP3`, `P3`), and the kernel checks, for all 256 sign patterns, that `8(1-q)² - ∑ Δᵢ(f)²`
is nonnegative on `[9/50, 3/10] ⊃ [q₃, q₂]`, possibly after subtracting `4 g₂(q)` (dictators)
and/or `-4(1-q)² g₃(q)` (the OR of three bits); both are `≥ 0` on `[q₃, q₂]`
(`g₂ = 2(1-q)² - 1`, `g₃ = 3(1-q)² - 2`). This gives `G3_le`:
`E|c₀χ₀ + c₁χ₁ + c₂χ₂| ≤ T₂ |c|` for `q ∈ [q₃, q₂]`, with `T₂ = 2√2 (1-q) τ` (Lemma 6.3).

Expectations over three bits are written out as sums over `Bool³`.
-/

namespace ReverseKhinchin

open ReverseKhinchin.Poly

/-- `T₂ = 2√2 (1-q) τ`. -/
noncomputable def T2 (q : ℝ) : ℝ := 2 * √2 * (1 - q) * tau q

variable {q : ℝ}

/-! ### Signs and the polynomials `Δᵢ` -/

/-- `±1` as a real number. -/
def sR (b : Bool) : ℝ := if b then 1 else -1

/-- `±1` as an integer. -/
def sI (b : Bool) : ℤ := if b then 1 else -1

@[simp] theorem cast_sI (b : Bool) : ((sI b : ℤ) : ℝ) = sR b := by cases b <;> simp [sI, sR]

/-- The weight `P(xᵢ = b)` as a polynomial in `q`. -/
def wP (b : Bool) : List ℤ := if b then [0, 1] else [1, -1]

@[simp] theorem evalM_wP (b : Bool) (x : ℝ) : evalM (wP b) x = bitProb x b := by
  cases b
  · simp [wP, bitProb]; ring
  · simp [wP, bitProb]

/-- `∑_{b ∈ {0,1}} g b` for polynomials. -/
def sumB (g : Bool → List ℤ) : List ℤ := padd (g true) (g false)

@[simp] theorem evalM_sumB (g : Bool → List ℤ) (x : ℝ) :
    evalM (sumB g) x = evalM (g true) x + evalM (g false) x := by
  simp [sumB, evalM_padd]

/-- `Δᵢ(f)` for `f : {0,1}³ → {±1}`. -/
noncomputable def D3 (q : ℝ) (f : Bool → Bool → Bool → Bool) : Fin 3 → ℝ
  | 0 => ∑ b : Bool, ∑ c : Bool, bitProb q b * bitProb q c * (sR (f true b c) - sR (f false b c))
  | 1 => ∑ b : Bool, ∑ c : Bool, bitProb q b * bitProb q c * (sR (f b true c) - sR (f b false c))
  | 2 => ∑ b : Bool, ∑ c : Bool, bitProb q b * bitProb q c * (sR (f b c true) - sR (f b c false))

def dP3 (f : Bool → Bool → Bool → Bool) : Fin 3 → List ℤ
  | 0 => sumB fun b => sumB fun c => pscale (sI (f true b c) - sI (f false b c)) (pmul (wP b) (wP c))
  | 1 => sumB fun b => sumB fun c => pscale (sI (f b true c) - sI (f b false c)) (pmul (wP b) (wP c))
  | 2 => sumB fun b => sumB fun c => pscale (sI (f b c true) - sI (f b c false)) (pmul (wP b) (wP c))

theorem evalM_dP3 (f : Bool → Bool → Bool → Bool) (i : Fin 3) (x : ℝ) :
    evalM (dP3 f i) x = D3 x f i := by
  match i with
  | 0 => simp only [dP3, D3, evalM_sumB, evalM_pscale, evalM_pmul, evalM_wP, Int.cast_sub,
      cast_sI, Fintype.sum_bool]; ring
  | 1 => simp only [dP3, D3, evalM_sumB, evalM_pscale, evalM_pmul, evalM_wP, Int.cast_sub,
      cast_sI, Fintype.sum_bool]; ring
  | 2 => simp only [dP3, D3, evalM_sumB, evalM_pscale, evalM_pmul, evalM_wP, Int.cast_sub,
      cast_sI, Fintype.sum_bool]; ring

/-- `8(1-q)² - ∑ Δᵢ(f)²`. -/
def P3 (f : Bool → Bool → Bool → Bool) : List ℤ :=
  padd [8, -16, 8] (pneg (padd (pmul (dP3 f 0) (dP3 f 0))
    (padd (pmul (dP3 f 1) (dP3 f 1)) (pmul (dP3 f 2) (dP3 f 2)))))

theorem evalM_P3 (f : Bool → Bool → Bool → Bool) (x : ℝ) :
    evalM (P3 f) x = 8 * (1 - x) ^ 2 - (D3 x f 0 ^ 2 + D3 x f 1 ^ 2 + D3 x f 2 ^ 2) := by
  simp only [P3, evalM_padd, evalM_pneg, evalM_pmul, evalM_dP3, evalM_cons, evalM_nil]
  push_cast; ring

/-! ### Positivity on an interval -/

/-- `p ≥ 0` on `[α/γ, (α+β)/γ]` (`β, γ > 0`), via the affine map onto `[0,1]`. -/
def checkOn (α β γ : ℤ) (p : List ℤ) : Bool := checkNN 30 (aff α β γ p)

theorem checkOn_sound {α β γ : ℤ} (hβ : 0 < β) (hγ : 0 < γ) {p : List ℤ}
    (h : checkOn α β γ p = true) {x : ℝ} (h1 : (α : ℝ) / γ ≤ x) (h2 : x ≤ ((α : ℝ) + β) / γ) :
    0 ≤ evalM p x := by
  have hγ' : (0 : ℝ) < γ := by exact_mod_cast hγ
  have hβ' : (0 : ℝ) < β := by exact_mod_cast hβ
  set X := ((γ : ℝ) * x - α) / β
  have hX0 : 0 ≤ X := by
    apply div_nonneg _ hβ'.le
    rw [div_le_iff₀ hγ'] at h1; linarith
  have hX1 : X ≤ 1 := by
    rw [div_le_one hβ']
    rw [le_div_iff₀ hγ'] at h2; linarith
  have hx : ((α : ℝ) + β * X) / γ = x := by
    simp only [X]; field_simp; ring
  have := checkNN_sound 30 _ h X hX0 hX1
  rw [evalM_aff α β γ hγ'.ne', hx] at this
  exact (mul_nonneg_iff_of_pos_left (by positivity)).1 this

/-- `4 g₂(q) = 8q² - 16q + 4`. -/
def g2P : List ℤ := [4, -16, 8]
/-- `-4 (1-q)² g₃(q)`. -/
def g3P : List ℤ := [-4, 32, -64, 48, -12]

theorem evalM_g2P (x : ℝ) : evalM g2P x = 4 * (2 * (1 - x) ^ 2 - 1) := by
  simp [g2P]; ring

theorem evalM_g3P (x : ℝ) : evalM g3P x = 4 * (1 - x) ^ 2 * (2 - 3 * (1 - x) ^ 2) := by
  simp [g3P]; ring

/-- `P₃(f) ≥ 0` on `[9/50, 3/10]`, possibly after subtracting `4 g₂` and/or `-4(1-q)² g₃`. -/
def chk3 (f : Bool → Bool → Bool → Bool) : Bool :=
  checkOn 18 12 100 (P3 f) || checkOn 18 12 100 (padd (P3 f) (pneg g2P)) ||
    checkOn 18 12 100 (padd (P3 f) (pneg g3P)) ||
    checkOn 18 12 100 (padd (padd (P3 f) (pneg g2P)) (pneg g3P))

/-- The function `{0,1}³ → {0,1}` with the given truth table. -/
def tab3 (b0 b1 b2 b3 b4 b5 b6 b7 : Bool) : Bool → Bool → Bool → Bool
  | false, false, false => b0 | false, false, true => b1 | false, true, false => b2
  | false, true, true => b3 | true, false, false => b4 | true, false, true => b5
  | true, true, false => b6 | true, true, true => b7

theorem chk3_all : ∀ b0 b1 b2 b3 b4 b5 b6 b7 : Bool,
    chk3 (tab3 b0 b1 b2 b3 b4 b5 b6 b7) = true := by
  decide +kernel

theorem tab3_eq (f : Bool → Bool → Bool → Bool) :
    f = tab3 (f false false false) (f false false true) (f false true false) (f false true true)
      (f true false false) (f true false true) (f true true false) (f true true true) := by
  funext x y z; cases x <;> cases y <;> cases z <;> rfl

/-- The claim of Lemma 6.3: `∑ Δᵢ(f)² ≤ 8(1-q)²` on `[q₃, q₂]`. -/
theorem sumD3_le (hq2 : 1 ≤ 2 * (1 - q) ^ 2) (hq3 : 3 * (1 - q) ^ 2 ≤ 2) (hq1 : q ≤ 1 / 2)
    (f : Bool → Bool → Bool → Bool) :
    D3 q f 0 ^ 2 + D3 q f 1 ^ 2 + D3 q f 2 ^ 2 ≤ 8 * (1 - q) ^ 2 := by
  have hql : 9 / 50 ≤ q := by nlinarith
  have hqh : q ≤ 3 / 10 := by nlinarith
  have h1 : ((18 : ℤ) : ℝ) / ((100 : ℤ) : ℝ) ≤ q := by push_cast; linarith
  have h2 : q ≤ ((18 : ℤ) + (12 : ℤ) : ℝ) / ((100 : ℤ) : ℝ) := by push_cast; linarith
  have hg2 : 0 ≤ evalM g2P q := by rw [evalM_g2P]; linarith
  have hg3 : 0 ≤ evalM g3P q := by
    rw [evalM_g3P]; exact mul_nonneg (by positivity) (by linarith)
  have h := chk3_all (f false false false) (f false false true) (f false true false)
    (f false true true) (f true false false) (f true false true) (f true true false)
    (f true true true)
  rw [← tab3_eq] at h
  simp only [chk3, Bool.or_eq_true] at h
  rcases h with ((h | h) | h) | h
  · have := checkOn_sound (by norm_num) (by norm_num) h h1 h2
    clear h; rw [evalM_P3] at this; linarith
  · have := checkOn_sound (by norm_num) (by norm_num) h h1 h2
    clear h; rw [evalM_padd, evalM_pneg, evalM_P3] at this; linarith
  · have := checkOn_sound (by norm_num) (by norm_num) h h1 h2
    clear h; rw [evalM_padd, evalM_pneg, evalM_P3] at this; linarith
  · have := checkOn_sound (by norm_num) (by norm_num) h h1 h2
    clear h; rw [evalM_padd, evalM_padd, evalM_pneg, evalM_pneg, evalM_P3] at this; linarith

/-! ### Level-one identity and bit reduction -/

/-- `E g(x₀, x₁, x₂)` for three independent `q`-biased bits. -/
noncomputable def E3 (q : ℝ) (g : Bool → Bool → Bool → ℝ) : ℝ :=
  ∑ b0 : Bool, ∑ b1 : Bool, ∑ b2 : Bool, bitProb q b0 * bitProb q b1 * bitProb q b2 * g b0 b1 b2

/-- (4.7) for three bits: `E[f χᵢ] = τ Δᵢ(f)`. -/
theorem level_one (hu : 0 < u) (f : Bool → Bool → Bool → Bool) :
    E3 (qOf u) (fun b0 b1 b2 => sR (f b0 b1 b2) * chi (qOf u) b0) = tau (qOf u) * D3 (qOf u) f 0 ∧
    E3 (qOf u) (fun b0 b1 b2 => sR (f b0 b1 b2) * chi (qOf u) b1) = tau (qOf u) * D3 (qOf u) f 1 ∧
    E3 (qOf u) (fun b0 b1 b2 => sR (f b0 b1 b2) * chi (qOf u) b2) = tau (qOf u) * D3 (qOf u) f 2 := by
  have hu' : (1 + u ^ 2) ≠ 0 := by positivity
  simp only [E3, D3, Fintype.sum_bool, bitProb_true, bitProb_false, chi_qOf_true hu,
    chi_qOf_false hu, tau_qOf hu, one_sub_qOf]
  simp only [qOf]
  refine ⟨?_, ?_, ?_⟩ <;> field_simp <;> ring

/-- Cauchy–Schwarz in `ℝ³`. -/
theorem cs3 (a0 a1 a2 b0 b1 b2 : ℝ) :
    a0 * b0 + a1 * b1 + a2 * b2 ≤ √(a0 ^ 2 + a1 ^ 2 + a2 ^ 2) * √(b0 ^ 2 + b1 ^ 2 + b2 ^ 2) := by
  rw [← Real.sqrt_mul (by positivity)]
  apply Real.le_sqrt_of_sq_le
  nlinarith [sq_nonneg (a0 * b1 - a1 * b0), sq_nonneg (a0 * b2 - a2 * b0),
    sq_nonneg (a1 * b2 - a2 * b1)]

/-- Lemma 6.3 (three-bit lemma, upper bound): for `q ∈ [q₃, q₂]`,
`E|c₀χ₀ + c₁χ₁ + c₂χ₂| ≤ T₂ |c|`. -/
theorem G3_le (hu : 0 < u) (hq2 : 1 ≤ 2 * (1 - qOf u) ^ 2) (hq3 : 3 * (1 - qOf u) ^ 2 ≤ 2)
    (hq1 : qOf u ≤ 1 / 2) (c0 c1 c2 : ℝ) :
    E3 (qOf u) (fun b0 b1 b2 =>
      |c0 * chi (qOf u) b0 + c1 * chi (qOf u) b1 + c2 * chi (qOf u) b2|) ≤
      T2 (qOf u) * √(c0 ^ 2 + c1 ^ 2 + c2 ^ 2) := by
  set q := qOf u
  set X : Bool → Bool → Bool → ℝ := fun b0 b1 b2 => c0 * chi q b0 + c1 * chi q b1 + c2 * chi q b2
  set f : Bool → Bool → Bool → Bool := fun b0 b1 b2 => decide (0 ≤ X b0 b1 b2)
  have habs : ∀ b0 b1 b2, |X b0 b1 b2| = sR (f b0 b1 b2) * X b0 b1 b2 := by
    intro b0 b1 b2
    by_cases h : 0 ≤ X b0 b1 b2
    · simp [f, h, sR, abs_of_nonneg h]
    · simp [f, h, sR, abs_of_neg (lt_of_not_ge h)]
  obtain ⟨l0, l1, l2⟩ := level_one hu f
  have hE : E3 q (fun b0 b1 b2 => |X b0 b1 b2|) =
      c0 * E3 q (fun b0 b1 b2 => sR (f b0 b1 b2) * chi q b0) +
      c1 * E3 q (fun b0 b1 b2 => sR (f b0 b1 b2) * chi q b1) +
      c2 * E3 q (fun b0 b1 b2 => sR (f b0 b1 b2) * chi q b2) := by
    simp only [habs, E3, X, Fintype.sum_bool]; ring
  have hτ : 0 ≤ tau q := Real.sqrt_nonneg _
  have hD := sumD3_le hq2 hq3 hq1 f
  have hsq : √(D3 q f 0 ^ 2 + D3 q f 1 ^ 2 + D3 q f 2 ^ 2) ≤ 2 * √2 * (1 - q) := by
    rw [Real.sqrt_le_left (by have : (0:ℝ) ≤ √2 := Real.sqrt_nonneg _; nlinarith)]
    rw [mul_pow, mul_pow, Real.sq_sqrt (by norm_num)]; linarith
  show E3 q (fun b0 b1 b2 => |X b0 b1 b2|) ≤ _
  rw [hE, l0, l1, l2]
  calc c0 * (tau q * D3 q f 0) + c1 * (tau q * D3 q f 1) + c2 * (tau q * D3 q f 2)
      = tau q * (c0 * D3 q f 0 + c1 * D3 q f 1 + c2 * D3 q f 2) := by ring
    _ ≤ tau q * (√(c0 ^ 2 + c1 ^ 2 + c2 ^ 2) * (2 * √2 * (1 - q))) := by
        apply mul_le_mul_of_nonneg_left _ hτ
        exact (cs3 _ _ _ _ _ _).trans (mul_le_mul_of_nonneg_left hsq (Real.sqrt_nonneg _))
    _ = T2 q * √(c0 ^ 2 + c1 ^ 2 + c2 ^ 2) := by unfold T2; ring

end ReverseKhinchin
