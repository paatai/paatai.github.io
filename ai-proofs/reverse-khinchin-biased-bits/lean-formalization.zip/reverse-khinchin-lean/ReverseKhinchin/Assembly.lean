import ReverseKhinchin.Statement
import ReverseKhinchin.LowerBound

/-!
# From the upper bound to the full Main Theorem

`mainStatement_of_upperBound` shows that, at every `q ∈ (0,1)`, the full statement of
Theorem 1.1 follows from its upper-bound half `UpperBound q`
(`E|∑ αᵢχᵢ| ≤ M(q) ‖α‖₂` for all `α`). Everything else (the maximum over `k`, the tie rule,
attainment, and the lower bound `R(q) ≥ M(q)`) is proved here.
-/

open Finset

namespace ReverseKhinchin

variable {q : ℝ}

theorem l2norm_pos {n : ℕ} {α : Fin n → ℝ} (h : α ≠ 0) : 0 < l2norm α := by
  obtain ⟨i, hi⟩ : ∃ i, α i ≠ 0 := by
    by_contra hcon
    push Not at hcon
    exact h (funext hcon)
  unfold l2norm
  apply Real.sqrt_pos.2
  calc (0:ℝ) < α i ^ 2 := by positivity
    _ ≤ ∑ j, α j ^ 2 := Finset.single_le_sum (f := fun j => α j ^ 2) (fun j _ => sq_nonneg _)
        (Finset.mem_univ i)

theorem l2norm_nonneg {n : ℕ} (α : Fin n → ℝ) : 0 ≤ l2norm α := Real.sqrt_nonneg _

theorem mainStatement_iff : MainStatement q ↔
    (IsGreatest {r | ∃ j : ℕ, 1 ≤ j ∧ r = hk q j} (hk q (kopt q)) ∧
    (∀ j : ℕ, 1 ≤ j → (hk q j = hk q (kopt q) ↔
      j = kopt q ∨ (j = kopt q - 1 ∧ pmin q = 1 - √(((kopt q : ℝ) - 1) / kopt q)))) ∧
    IsGreatest (ratioSet q) (Mconst q) ∧
    UpperBound q ∧
    (1 ≤ kopt q ∧ l2norm (fun _ : Fin (kopt q) => 1 / √(kopt q : ℝ)) = 1 ∧
      meanAbs q (fun _ : Fin (kopt q) => 1 / √(kopt q : ℝ)) = Mconst q)) := Iff.rfl

/-- The full Main Theorem at `q` follows from its upper-bound half. -/
theorem mainStatement_of_upperBound (hq0 : 0 < q) (hq1 : q < 1) (h : UpperBound q) :
    MainStatement q := by
  rw [mainStatement_iff]
  have hk1 := one_le_kopt hq0 hq1
  have hnorm := l2norm_const (kopt q) hk1
  have hatt := meanAbs_attain hq0 hq1
  refine ⟨⟨⟨kopt q, hk1, rfl⟩, ?_⟩, ?_, ⟨?_, ?_⟩, h, hk1, hnorm, hatt⟩
  · rintro r ⟨j, hj, rfl⟩
    exact (hk_max hq0 hq1 j hj).1
  · intro j hj
    rw [(hk_max hq0 hq1 j hj).2, tie_iff hq0 hq1]
  · refine ⟨kopt q, fun _ => 1 / √(kopt q : ℝ), ?_, ?_⟩
    · intro h0
      have := congrFun h0 ⟨0, hk1⟩
      have hkpos : (0:ℝ) < kopt q := by exact_mod_cast hk1
      simp only [Pi.zero_apply, one_div, inv_eq_zero] at this
      exact (Real.sqrt_pos.2 hkpos).ne' this
    · rw [hnorm, hatt, div_one]
  · rintro r ⟨n, α, hα, rfl⟩
    rw [div_le_iff₀ (l2norm_pos hα)]
    exact h n α

end ReverseKhinchin
