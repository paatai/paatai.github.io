import ReverseKhinchin.QuarticBox
import ReverseKhinchin.NearDictator
import ReverseKhinchin.Assembly
import ReverseKhinchin.Cert.Data.R1A
import ReverseKhinchin.Cert.Data.R1B
import ReverseKhinchin.Cert.Data.R1C
import ReverseKhinchin.Cert.Data.R1D
import ReverseKhinchin.Cert.Data.R2A
import ReverseKhinchin.Cert.Data.R2B
import ReverseKhinchin.Cert.Data.R3A
import ReverseKhinchin.Cert.Data.R3B

/-!
# Theorem 5.1: the central range `q ∈ [q₂, 1 - q₂]`

For `q ∈ [q₂, 1/2]`, i.e. `u ∈ [1, u₂]` with `u₂² = 1 + √2` (equivalently `(u² - 1)² ≤ 2`), and a
reduced unit vector `α = (a, bβ)` (Section 4.6), the bound `E|L| ≤ 2τ` is proved by cases on
`(u, a) ∈ [1, ū₀] × (0, 1)` (Proposition 5.7(iii)):

1. `a ≥ 9/10`: the near-dictator bound (`near_dictator`);
2. `(u, a) ∈ [611/400, ū₀] × [16/25, 77/100]`: the quartic certificate (`quartic_region`);
3. otherwise `(u, a)` lies in one of the eight rectangles of Table 3, each tiled by kernel-checked
   six-moment cells (`checkTree_sound` with `Data.r1a_check`, …, `Data.r3b_check`).

The range `[1/2, 1 - q₂]` follows by the symmetry `q ↦ 1 - q` (Lemma 4.1).
-/

namespace ReverseKhinchin

open Quartic QuarticBox

/-- `ū₀ = 776887/500000 > u₂`. -/
theorem le_ubar {u : ℝ} (hu : 1 ≤ u) (hu2 : (u ^ 2 - 1) ^ 2 ≤ 2) : u ≤ 776887 / 500000 := by
  by_contra h
  push Not at h
  have h1 : (776887 / 500000 : ℝ) ^ 2 < u ^ 2 := by nlinarith
  nlinarith

/-- The quartic region (case (2) of the proof of Theorem 5.1, via Corollary 5.5). -/
theorem quartic_region {u a : ℝ} (hu1 : 611 / 400 ≤ u) (hu2 : (u ^ 2 - 1) ^ 2 ≤ 2)
    (ha1 : 16 / 25 ≤ a) (ha2 : a ≤ 77 / 100) {n : ℕ} (β : Fin n → ℝ) (h2 : psum β 2 = 1) :
    2 * tau (qOf u) * a + 2 * expect (qOf u) (fun x => Ra u a (√(1 - a ^ 2) * lin (qOf u) β x)) ≤
      2 * tau (qOf u) := by
  have hu0 : 0 < u := by linarith
  have hu' := le_ubar (by linarith) hu2
  have ha0 : 0 < a := by linarith
  set b := √(1 - a ^ 2) with hb
  have hb2 : b ^ 2 = 1 - a ^ 2 := Real.sq_sqrt (by nlinarith)
  have hb0 : 0 < b := Real.sqrt_pos.2 (by nlinarith)
  have h1b : 0 < 1 + b := by linarith
  -- the parameter `t = a / (1 + b)` with `a = 2t/(1+t²)`, `b = (1-t²)/(1+t²)`
  set t := a / (1 + b) with ht
  have ht1 : 9 / 25 ≤ t := by
    rw [ht, le_div_iff₀ h1b]
    nlinarith
  have ht2 : t ≤ 471 / 1000 := by
    rw [ht, div_le_iff₀ h1b]
    nlinarith
  have hsum : (1 + b) ^ 2 + a ^ 2 = 2 * (1 + b) := by linear_combination hb2
  have hk : 1 + t ^ 2 = 2 / (1 + b) := by
    rw [ht, div_pow, eq_div_iff h1b.ne']
    field_simp
    linear_combination hsum
  have hat : a = 2 * t / (1 + t ^ 2) := by
    rw [hk, ht]; field_simp
  have hbt : b = (1 - t ^ 2) / (1 + t ^ 2) := by
    have : 1 - t ^ 2 = 2 * b / (1 + b) := by
      rw [show 1 - t ^ 2 = 2 - (1 + t ^ 2) by ring, hk]; field_simp; ring
    rw [this, hk]; field_simp
  obtain ⟨p1, p2, p3, p4, p5, p6⟩ := hyps hu1 hu' ht1 ht2 hat hbt
  have hu3 : u ^ 2 ≤ 3 := by nlinarith
  have hcore := quartic_core (by linarith) hu3 ha0 hb0 p1 p2 p3 p4.le p5.le p6.le β h2
  -- `2τa + 2q(1-q)(bu - av) = 2τ(1-q)(a+b) ≤ 2τ`
  have e : tau (qOf u) * a + qOf u * (1 - qOf u) * (b * u - a * u⁻¹) =
      tau (qOf u) * ((1 - qOf u) * (a + b)) := by
    rw [tau_qOf hu0, one_sub_qOf]; unfold qOf; field_simp; ring
  have hle : (1 - qOf u) * (a + b) ≤ 1 := by
    rw [one_sub_qOf]
    have hab : (a + b) ^ 2 ≤ 2 := by nlinarith [sq_nonneg (a - b)]
    have hsq : (u ^ 2 / (1 + u ^ 2) * (a + b)) ^ 2 ≤ 1 := by
      rw [mul_pow, div_pow, div_mul_eq_mul_div, div_le_one (by positivity)]
      have : (u ^ 2) ^ 2 * (a + b) ^ 2 ≤ (u ^ 2) ^ 2 * 2 :=
        mul_le_mul_of_nonneg_left hab (by positivity)
      nlinarith
    have hnn : 0 ≤ u ^ 2 / (1 + u ^ 2) * (a + b) := by positivity
    nlinarith
  have htau : 0 < tau (qOf u) := tau_pos (qOf_pos u) (qOf_lt_one hu0)
  have : tau (qOf u) * ((1 - qOf u) * (a + b)) ≤ tau (qOf u) :=
    mul_le_of_le_one_right htau.le hle
  linarith

theorem cell_case {B : QQ × QQ × QQ × QQ} {t : CTree}
    (h : checkTree wK1 B.1 B.2.1 B.2.2.1 B.2.2.2 t = true)
    {u a : ℝ} (hu1 : B.1.toReal ≤ u) (hu2 : u ≤ B.2.1.toReal) (ha1 : B.2.2.1.toReal ≤ a)
    (ha2 : a ≤ B.2.2.2.toReal) (ha0 : 0 < a) {n : ℕ} (β : Fin n → ℝ) (h2 : psum β 2 = 1)
    (hβ1 : ∀ i, |β i| ≤ 1) (hβa : ∀ i, |β i| ≤ a / √(1 - a ^ 2)) :
    expect (qOf u) (fun x => Ra u a (√(1 - a ^ 2) * lin (qOf u) β x)) ≤ tau (qOf u) * (1 - a) :=
  checkTree_sound wK1 t h (fun v _ _ => wK1_le v) hu1 hu2 ha1 ha2 ha0 β h2 hβ1 hβa

macro "box_bound" : tactic => `(tactic| (norm_num [Data.r1aBox, Data.r1bBox, Data.r1cBox,
  Data.r1dBox, Data.r2aBox, Data.r2bBox, Data.r3aBox, Data.r3bBox, QQ.toReal_mk'] <;> linarith))

/-- Theorem 5.1(a) in reduced form: for `u ∈ [1, u₂]` and a reduced unit vector,
`E|a χ₁ + b M| = 2τa + 2 E R_a(b M) ≤ 2τ`. -/
theorem central_reduced {u : ℝ} (hu : 1 ≤ u) (hu2 : (u ^ 2 - 1) ^ 2 ≤ 2) (a : ℝ) (ha0 : 0 < a)
    (ha1 : a < 1) {n : ℕ} (β : Fin n → ℝ) (h2 : psum β 2 = 1) (hβ1 : ∀ i, |β i| ≤ 1)
    (hβa : ∀ i, |β i| ≤ a / √(1 - a ^ 2)) :
    2 * tau (qOf u) * a + 2 * expect (qOf u) (fun x => Ra u a (√(1 - a ^ 2) * lin (qOf u) β x)) ≤
      2 * tau (qOf u) := by
  have hu' := le_ubar hu hu2
  suffices H : (611 / 400 ≤ u ∧ 16 / 25 ≤ a ∧ a ≤ 77 / 100) ∨
      expect (qOf u) (fun x => Ra u a (√(1 - a ^ 2) * lin (qOf u) β x)) ≤ tau (qOf u) * (1 - a) by
    rcases H with ⟨h1, h2', h3⟩ | H
    · exact quartic_region h1 hu2 h2' h3 β h2
    · linarith
  rcases le_or_gt (9 / 10) a with h9 | h9
  · exact Or.inr (near_dictator hu hu2 h9 ha1 β h2)
  rcases le_or_gt a (4 / 25) with h | h
  · exact Or.inr (cell_case Data.r1a_check (by box_bound) (by box_bound) (by box_bound)
      (by box_bound) ha0 β h2 hβ1 hβa)
  rcases le_or_gt a (8 / 25) with h' | h'
  · exact Or.inr (cell_case Data.r1b_check (by box_bound) (by box_bound) (by box_bound)
      (by box_bound) ha0 β h2 hβ1 hβa)
  rcases le_or_gt a (12 / 25) with h'' | h''
  · exact Or.inr (cell_case Data.r1c_check (by box_bound) (by box_bound) (by box_bound)
      (by box_bound) ha0 β h2 hβ1 hβa)
  rcases le_or_gt a (16 / 25) with h3 | h3
  · exact Or.inr (cell_case Data.r1d_check (by box_bound) (by box_bound) (by box_bound)
      (by box_bound) ha0 β h2 hβ1 hβa)
  rcases le_or_gt (77 / 100) a with h4 | h4
  · rcases le_total u (13 / 10) with hu13 | hu13
    · exact Or.inr (cell_case Data.r2a_check (by box_bound) (by box_bound) (by box_bound)
        (by box_bound) ha0 β h2 hβ1 hβa)
    · exact Or.inr (cell_case Data.r2b_check (by box_bound) (by box_bound) (by box_bound)
        (by box_bound) ha0 β h2 hβ1 hβa)
  rcases le_total u (13 / 10) with hu13 | hu13
  · exact Or.inr (cell_case Data.r3a_check (by box_bound) (by box_bound) (by box_bound)
      (by box_bound) ha0 β h2 hβ1 hβa)
  rcases le_total u (611 / 400) with hu6 | hu6
  · exact Or.inr (cell_case Data.r3b_check (by box_bound) (by box_bound) (by box_bound)
      (by box_bound) ha0 β h2 hβ1 hβa)
  · exact Or.inl ⟨hu6, h3.le, h4.le⟩

/-! ### Back to `q` -/

theorem two_tau_le_Mconst {q : ℝ} (hq0 : 0 < q) (hq1 : q < 1) : 2 * tau q ≤ Mconst q := by
  have h := (hk_max hq0 hq1 1 le_rfl).1
  have h1 : hk q 1 = 1 := by simp [hk]
  have ht : 0 ≤ tau q := Real.sqrt_nonneg _
  unfold Mconst
  change 2 * tau q ≤ 2 * tau q * hk q (kopt q)
  nlinarith

theorem Mconst_one_sub (q : ℝ) : Mconst (1 - q) = Mconst q := by
  unfold Mconst hk
  rw [kopt_one_sub, qhat_one_sub, sub_sub_cancel, mul_comm (1 - q) q]

/-- Lemma 4.1 for the upper bound: `UpperBound (1 - q) → UpperBound q`. -/
theorem upperBound_of_one_sub {q : ℝ} (h : UpperBound (1 - q)) : UpperBound q := by
  intro n α
  have := h n α
  rwa [Mconst_one_sub, meanAbs_one_sub] at this

theorem q₂_pos : 0 < q₂ := by
  have hs : (1:ℝ) < √2 := by
    rw [show (1:ℝ) = √1 by simp]; exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
  have : 1 / √2 < 1 := by rw [div_lt_one (by linarith)]; exact hs
  unfold q₂; linarith

theorem q₂_lt_half : q₂ < 1 / 2 := by
  have hs : √2 < 2 := by
    rw [show (2:ℝ) = √4 by rw [show (4:ℝ) = 2 ^ 2 by norm_num, Real.sqrt_sq (by norm_num)]]
    exact Real.sqrt_lt_sqrt (by norm_num) (by norm_num)
  have hs0 : 0 < √2 := by positivity
  have : 1 / 2 < 1 / √2 := by rw [div_lt_div_iff₀ (by norm_num) hs0]; linarith
  unfold q₂; linarith

theorem tau_one_sub (q : ℝ) : tau (1 - q) = tau q := by
  unfold tau; rw [sub_sub_cancel, mul_comm]

/-- Theorem 5.1(a) on `[q₂, 1/2]`: `E|∑ αᵢχᵢ| ≤ 2τ ‖α‖₂`. -/
theorem twoTau_bound_half {q : ℝ} (hq2 : q₂ ≤ q) (hq : q ≤ 1 / 2) (n : ℕ) (α : Fin n → ℝ) :
    meanAbs q α ≤ 2 * tau q * l2norm α := by
  have hq0 : 0 < q := lt_of_lt_of_le q₂_pos hq2
  have hq1 : q < 1 := by linarith
  have hu := one_le_uOf hq0 hq
  have hu0 : 0 < uOf q := by linarith
  have hqu : qOf (uOf q) = q := qOf_uOf hq0 hq1
  have hu2 : (uOf q ^ 2 - 1) ^ 2 ≤ 2 := by
    have hsq : uOf q ^ 2 = (1 - q) / q := Real.sq_sqrt (div_nonneg (by linarith) hq0.le)
    have h1q : 2 * (1 - q) ^ 2 ≤ 1 := by
      have hs0 : 0 < √2 := by positivity
      have h : 1 - q ≤ 1 / √2 := by unfold q₂ at hq2; linarith
      have := pow_le_pow_left₀ (by linarith) h 2
      rw [div_pow, Real.sq_sqrt (by norm_num)] at this
      linarith
    rw [hsq, div_sub_one hq0.ne', div_pow, div_le_iff₀ (by positivity)]
    nlinarith
  have H := upperBound_of_reduced hu0 (2 * tau (qOf (uOf q))) le_rfl
    (fun a ha0 ha1 m β h2 hβ1 hβa => central_reduced hu hu2 a ha0 ha1 β h2 hβ1 hβa) n α
  rwa [hqu] at H

/-- **Theorem 5.1(a)**: `E|∑ αᵢχᵢ| ≤ 2 √(q(1-q)) ‖α‖₂` for `q ∈ [q₂, 1 - q₂]`. -/
theorem twoTau_bound {q : ℝ} (h1 : q₂ ≤ q) (h2 : q ≤ 1 - q₂) (n : ℕ) (α : Fin n → ℝ) :
    meanAbs q α ≤ 2 * tau q * l2norm α := by
  rcases le_total q (1 / 2) with h | h
  · exact twoTau_bound_half h1 h n α
  · have := twoTau_bound_half (q := 1 - q) (by linarith) (by linarith) n α
    rwa [meanAbs_one_sub, tau_one_sub] at this

/-- The upper-bound half of the Main Theorem on the central range `q ∈ [q₂, 1 - q₂]`. -/
theorem upperBound_central {q : ℝ} (h1 : q₂ ≤ q) (h2 : q ≤ 1 - q₂) : UpperBound q := by
  have hq0 : 0 < q := lt_of_lt_of_le q₂_pos h1
  have hq1 : q < 1 := by linarith [q₂_pos]
  intro n α
  exact le_trans (twoTau_bound h1 h2 n α)
    (mul_le_mul_of_nonneg_right (two_tau_le_Mconst hq0 hq1) (l2norm_nonneg α))

/-- The Main Theorem on the central range `q ∈ [q₂, 1 - q₂]`. -/
theorem mainStatement_central {q : ℝ} (h1 : q₂ ≤ q) (h2 : q ≤ 1 - q₂) : MainStatement q := by
  have hq0 : 0 < q := lt_of_lt_of_le q₂_pos h1
  have hq1 : q < 1 := by linarith [q₂_pos]
  exact mainStatement_of_upperBound hq0 hq1 (upperBound_central h1 h2)

end ReverseKhinchin
