import ReverseKhinchin.Cert.DataK2.Box.BoxS00p
import ReverseKhinchin.Cert.DataK2.Box.BoxS01p
import ReverseKhinchin.Cert.DataK2.Box.BoxS02p
import ReverseKhinchin.Cert.DataK2.Box.BoxS03p
import ReverseKhinchin.Cert.DataK2.Box.BoxS04p
import ReverseKhinchin.Cert.DataK2.Box.BoxS05p
import ReverseKhinchin.Cert.DataK2.Box.BoxS06p
import ReverseKhinchin.Cert.DataK2.Box.BoxS07p
import ReverseKhinchin.Cert.DataK2.Box.BoxS08p
import ReverseKhinchin.Cert.DataK2.Box.BoxS09p
import ReverseKhinchin.Cert.DataK2.Box.BoxS10p
import ReverseKhinchin.Cert.DataK2.Box.BoxS11p
import ReverseKhinchin.Cert.DataK2.Box.BoxS12p
import ReverseKhinchin.Cert.DataK2.Box.BoxS13p
import ReverseKhinchin.Cert.DataK2.Box.BoxS14p
import ReverseKhinchin.Cert.DataK2.Box.BoxS15p
import ReverseKhinchin.Cert.DataK2.Box.BoxS16p
import ReverseKhinchin.Cert.DataK2.Box.BoxS17p
import ReverseKhinchin.Cert.DataK2.Box.BoxS18p
import ReverseKhinchin.Cert.DataK2.Box.BoxS19p
import ReverseKhinchin.Cert.DataK2.Box.BoxS20p
import ReverseKhinchin.Cert.DataK2.Box.BoxS21p
import ReverseKhinchin.Cert.DataK2.Box.BoxS22p
import ReverseKhinchin.Cert.DataK2.Box.BoxS23p
import ReverseKhinchin.Cert.DataK2.Box.BoxS24p
import ReverseKhinchin.Cert.DataK2.Box.BoxS25p
import ReverseKhinchin.Cert.DataK2.Box.BoxS26p
import ReverseKhinchin.Cert.DataK2.Box.BoxS27p
import ReverseKhinchin.Cert.DataK2.Box.BoxS28p
import ReverseKhinchin.Cert.DataK2.Box.BoxS29p
import ReverseKhinchin.Cert.DataK2.Box.BoxS30p
import ReverseKhinchin.Cert.DataK2.Box.BoxS31p
import ReverseKhinchin.Cert.DataK2.Box.BoxS32p
import ReverseKhinchin.Cert.DataK2.Box.BoxS33p
import ReverseKhinchin.Cert.DataK2.Box.BoxS34p
import ReverseKhinchin.Cert.DataK2.Box.BoxS35p
import ReverseKhinchin.Cert.DataK2.Box.BoxS36p
import ReverseKhinchin.Cert.DataK2.Box.BoxS37p
import ReverseKhinchin.Cert.DataK2.Box.BoxS38p
import ReverseKhinchin.Cert.DataK2.Box.BoxS39p
import ReverseKhinchin.Cert.DataK2.Box.BoxS40p
import ReverseKhinchin.Cert.DataK2.Box.BoxS41p
import ReverseKhinchin.Cert.DataK2.Box.BoxS42p
import ReverseKhinchin.Cert.DataK2.Box.BoxS43p
import ReverseKhinchin.Cert.DataK2.Box.BoxS44p
import ReverseKhinchin.Cert.DataK2.Box.BoxB00p
import ReverseKhinchin.Cert.DataK2.Box.BoxB01p
import ReverseKhinchin.Cert.DataK2.Box.BoxB02p
import ReverseKhinchin.Cert.DataK2.Box.BoxB03p
import ReverseKhinchin.Cert.DataK2.Box.BoxB04p
import ReverseKhinchin.Cert.DataK2.Box.BoxB05p
import ReverseKhinchin.Cert.DataK2.Box.BoxB06p
import ReverseKhinchin.Cert.DataK2.Box.BoxB07p
import ReverseKhinchin.Cert.DataK2.Box.BoxB08p
import ReverseKhinchin.Cert.DataK2.Box.BoxB09ap
import ReverseKhinchin.Cert.DataK2.Box.BoxB09bp
import ReverseKhinchin.Cert.DataK2.Box.BoxB10ap
import ReverseKhinchin.Cert.DataK2.Box.BoxB10bp
import ReverseKhinchin.Cert.DataK2.Box.BoxS00m
import ReverseKhinchin.Cert.DataK2.Box.BoxS01m
import ReverseKhinchin.Cert.DataK2.Box.BoxS02m
import ReverseKhinchin.Cert.DataK2.Box.BoxS03m
import ReverseKhinchin.Cert.DataK2.Box.BoxS04m
import ReverseKhinchin.Cert.DataK2.Box.BoxS05m
import ReverseKhinchin.Cert.DataK2.Box.BoxS06m
import ReverseKhinchin.Cert.DataK2.Box.BoxS07m
import ReverseKhinchin.Cert.DataK2.Box.BoxS08m
import ReverseKhinchin.Cert.DataK2.Box.BoxS09m
import ReverseKhinchin.Cert.DataK2.Box.BoxS10m
import ReverseKhinchin.Cert.DataK2.Box.BoxS11m
import ReverseKhinchin.Cert.DataK2.Box.BoxS12m
import ReverseKhinchin.Cert.DataK2.Box.BoxS13m
import ReverseKhinchin.Cert.DataK2.Box.BoxS14m
import ReverseKhinchin.Cert.DataK2.Box.BoxS15m
import ReverseKhinchin.Cert.DataK2.Box.BoxS16m
import ReverseKhinchin.Cert.DataK2.Box.BoxS17m
import ReverseKhinchin.Cert.DataK2.Box.BoxS18m
import ReverseKhinchin.Cert.DataK2.Box.BoxS19m
import ReverseKhinchin.Cert.DataK2.Box.BoxS20m
import ReverseKhinchin.Cert.DataK2.Box.BoxS21m
import ReverseKhinchin.Cert.DataK2.Box.BoxS22m
import ReverseKhinchin.Cert.DataK2.Box.BoxS23m
import ReverseKhinchin.Cert.DataK2.Box.BoxS24m
import ReverseKhinchin.Cert.DataK2.Box.BoxS25m
import ReverseKhinchin.Cert.DataK2.Box.BoxS26m
import ReverseKhinchin.Cert.DataK2.Box.BoxS27m
import ReverseKhinchin.Cert.DataK2.Box.BoxS28m
import ReverseKhinchin.Cert.DataK2.Box.BoxS29m
import ReverseKhinchin.Cert.DataK2.Box.BoxS30m
import ReverseKhinchin.Cert.DataK2.Box.BoxS31m
import ReverseKhinchin.Cert.DataK2.Box.BoxS32m
import ReverseKhinchin.Cert.DataK2.Box.BoxS33m
import ReverseKhinchin.Cert.DataK2.Box.BoxS34m
import ReverseKhinchin.Cert.DataK2.Box.BoxS35m
import ReverseKhinchin.Cert.DataK2.Box.BoxS36m
import ReverseKhinchin.Cert.DataK2.Box.BoxS37m
import ReverseKhinchin.Cert.DataK2.Box.BoxS38m
import ReverseKhinchin.Cert.DataK2.Box.BoxS39m
import ReverseKhinchin.Cert.DataK2.Box.BoxS40m
import ReverseKhinchin.Cert.DataK2.Box.BoxS41m
import ReverseKhinchin.Cert.DataK2.Box.BoxS42m
import ReverseKhinchin.Cert.DataK2.Box.BoxS43m
import ReverseKhinchin.Cert.DataK2.Box.BoxS44m
import ReverseKhinchin.Cert.DataK2.Box.BoxB00m
import ReverseKhinchin.Cert.DataK2.Box.BoxB01m
import ReverseKhinchin.Cert.DataK2.Box.BoxB02m
import ReverseKhinchin.Cert.DataK2.Box.BoxB03m
import ReverseKhinchin.Cert.DataK2.Box.BoxB04m
import ReverseKhinchin.Cert.DataK2.Box.BoxB05m
import ReverseKhinchin.Cert.DataK2.Box.BoxB06m
import ReverseKhinchin.Cert.DataK2.Box.BoxB07m
import ReverseKhinchin.Cert.DataK2.Box.BoxB08m
import ReverseKhinchin.Cert.DataK2.Box.BoxB09m
import ReverseKhinchin.Cert.DataK2.Box.BoxB10m

/-! The box trees of Theorem 6.1 over `[U₋, U₊] × [0, T₈] × [9/20, 1]` for both signs of the
second coefficient, assembled from the region modules generated by `scripts/gen_boxes_k2.py`. -/

namespace ReverseKhinchin.DataK2

open ReverseKhinchin

/-- The two-coordinate boxes with `s = true` (58 regions). -/
def k2BoxP : BTree :=
  (.cutU (QQ.mk' (39) 25) boxS00p (.cutU (QQ.mk' (157) 100) boxS01p (.cutU (QQ.mk' (79) 50) boxS02p (.cutU (QQ.mk' (159) 100) boxS03p (.cutU (QQ.mk' (8) 5) boxS04p (.cutU (QQ.mk' (161) 100) boxS05p (.cutU (QQ.mk' (81) 50) boxS06p (.cutU (QQ.mk' (163) 100) boxS07p (.cutU (QQ.mk' (41) 25) boxS08p (.cutU (QQ.mk' (33) 20) boxS09p (.cutU (QQ.mk' (83) 50) boxS10p (.cutU (QQ.mk' (167) 100) boxS11p (.cutU (QQ.mk' (42) 25) boxS12p (.cutU (QQ.mk' (169) 100) boxS13p (.cutU (QQ.mk' (17) 10) boxS14p (.cutU (QQ.mk' (171) 100) boxS15p (.cutU (QQ.mk' (43) 25) boxS16p (.cutU (QQ.mk' (173) 100) boxS17p (.cutU (QQ.mk' (87) 50) boxS18p (.cutU (QQ.mk' (7) 4) boxS19p (.cutU (QQ.mk' (44) 25) boxS20p (.cutU (QQ.mk' (177) 100) boxS21p (.cutU (QQ.mk' (89) 50) boxS22p (.cutU (QQ.mk' (179) 100) boxS23p (.cutU (QQ.mk' (9) 5) boxS24p (.cutU (QQ.mk' (181) 100) boxS25p (.cutU (QQ.mk' (91) 50) boxS26p (.cutU (QQ.mk' (183) 100) boxS27p (.cutU (QQ.mk' (46) 25) boxS28p (.cutU (QQ.mk' (37) 20) boxS29p (.cutU (QQ.mk' (93) 50) boxS30p (.cutU (QQ.mk' (187) 100) boxS31p (.cutU (QQ.mk' (47) 25) boxS32p (.cutU (QQ.mk' (189) 100) boxS33p (.cutU (QQ.mk' (19) 10) boxS34p (.cutU (QQ.mk' (191) 100) boxS35p (.cutU (QQ.mk' (48) 25) boxS36p (.cutU (QQ.mk' (193) 100) boxS37p (.cutU (QQ.mk' (97) 50) boxS38p (.cutU (QQ.mk' (39) 20) boxS39p (.cutU (QQ.mk' (49) 25) boxS40p (.cutU (QQ.mk' (197) 100) boxS41p (.cutU (QQ.mk' (99) 50) boxS42p (.cutU (QQ.mk' (199) 100) boxS43p (.cutU (QQ.mk' (2) 1) boxS44p (.cutU (QQ.mk' (201) 100) boxB00p (.cutU (QQ.mk' (101) 50) boxB01p (.cutU (QQ.mk' (203) 100) boxB02p (.cutU (QQ.mk' (51) 25) boxB03p (.cutU (QQ.mk' (41) 20) boxB04p (.cutU (QQ.mk' (103) 50) boxB05p (.cutU (QQ.mk' (207) 100) boxB06p (.cutU (QQ.mk' (52) 25) boxB07p (.cutU (QQ.mk' (209) 100) boxB08p (.cutU (QQ.mk' (419) 200) boxB09ap (.cutU (QQ.mk' (21) 10) boxB09bp (.cutU (QQ.mk' (421) 200) boxB10ap boxB10bp)))))))))))))))))))))))))))))))))))))))))))))))))))))))))

theorem k2BoxP_check : checkBTree true (QQ.mk' (1553773) 1000000) (QQ.mk' (1054691) 500000) (QQ.mk' (0) 1) (QQ.mk' (20711) 50000) (QQ.mk' (9) 20) (QQ.mk' (1) 1) k2BoxP = true :=
  (checkBTree_cutU_of boxS00p_check (checkBTree_cutU_of boxS01p_check (checkBTree_cutU_of boxS02p_check (checkBTree_cutU_of boxS03p_check (checkBTree_cutU_of boxS04p_check (checkBTree_cutU_of boxS05p_check (checkBTree_cutU_of boxS06p_check (checkBTree_cutU_of boxS07p_check (checkBTree_cutU_of boxS08p_check (checkBTree_cutU_of boxS09p_check (checkBTree_cutU_of boxS10p_check (checkBTree_cutU_of boxS11p_check (checkBTree_cutU_of boxS12p_check (checkBTree_cutU_of boxS13p_check (checkBTree_cutU_of boxS14p_check (checkBTree_cutU_of boxS15p_check (checkBTree_cutU_of boxS16p_check (checkBTree_cutU_of boxS17p_check (checkBTree_cutU_of boxS18p_check (checkBTree_cutU_of boxS19p_check (checkBTree_cutU_of boxS20p_check (checkBTree_cutU_of boxS21p_check (checkBTree_cutU_of boxS22p_check (checkBTree_cutU_of boxS23p_check (checkBTree_cutU_of boxS24p_check (checkBTree_cutU_of boxS25p_check (checkBTree_cutU_of boxS26p_check (checkBTree_cutU_of boxS27p_check (checkBTree_cutU_of boxS28p_check (checkBTree_cutU_of boxS29p_check (checkBTree_cutU_of boxS30p_check (checkBTree_cutU_of boxS31p_check (checkBTree_cutU_of boxS32p_check (checkBTree_cutU_of boxS33p_check (checkBTree_cutU_of boxS34p_check (checkBTree_cutU_of boxS35p_check (checkBTree_cutU_of boxS36p_check (checkBTree_cutU_of boxS37p_check (checkBTree_cutU_of boxS38p_check (checkBTree_cutU_of boxS39p_check (checkBTree_cutU_of boxS40p_check (checkBTree_cutU_of boxS41p_check (checkBTree_cutU_of boxS42p_check (checkBTree_cutU_of boxS43p_check (checkBTree_cutU_of boxS44p_check (checkBTree_cutU_of boxB00p_check (checkBTree_cutU_of boxB01p_check (checkBTree_cutU_of boxB02p_check (checkBTree_cutU_of boxB03p_check (checkBTree_cutU_of boxB04p_check (checkBTree_cutU_of boxB05p_check (checkBTree_cutU_of boxB06p_check (checkBTree_cutU_of boxB07p_check (checkBTree_cutU_of boxB08p_check (checkBTree_cutU_of boxB09ap_check (checkBTree_cutU_of boxB09bp_check (checkBTree_cutU_of boxB10ap_check boxB10bp_check)))))))))))))))))))))))))))))))))))))))))))))))))))))))))

/-- The two-coordinate boxes with `s = false` (56 regions). -/
def k2BoxM : BTree :=
  (.cutU (QQ.mk' (39) 25) boxS00m (.cutU (QQ.mk' (157) 100) boxS01m (.cutU (QQ.mk' (79) 50) boxS02m (.cutU (QQ.mk' (159) 100) boxS03m (.cutU (QQ.mk' (8) 5) boxS04m (.cutU (QQ.mk' (161) 100) boxS05m (.cutU (QQ.mk' (81) 50) boxS06m (.cutU (QQ.mk' (163) 100) boxS07m (.cutU (QQ.mk' (41) 25) boxS08m (.cutU (QQ.mk' (33) 20) boxS09m (.cutU (QQ.mk' (83) 50) boxS10m (.cutU (QQ.mk' (167) 100) boxS11m (.cutU (QQ.mk' (42) 25) boxS12m (.cutU (QQ.mk' (169) 100) boxS13m (.cutU (QQ.mk' (17) 10) boxS14m (.cutU (QQ.mk' (171) 100) boxS15m (.cutU (QQ.mk' (43) 25) boxS16m (.cutU (QQ.mk' (173) 100) boxS17m (.cutU (QQ.mk' (87) 50) boxS18m (.cutU (QQ.mk' (7) 4) boxS19m (.cutU (QQ.mk' (44) 25) boxS20m (.cutU (QQ.mk' (177) 100) boxS21m (.cutU (QQ.mk' (89) 50) boxS22m (.cutU (QQ.mk' (179) 100) boxS23m (.cutU (QQ.mk' (9) 5) boxS24m (.cutU (QQ.mk' (181) 100) boxS25m (.cutU (QQ.mk' (91) 50) boxS26m (.cutU (QQ.mk' (183) 100) boxS27m (.cutU (QQ.mk' (46) 25) boxS28m (.cutU (QQ.mk' (37) 20) boxS29m (.cutU (QQ.mk' (93) 50) boxS30m (.cutU (QQ.mk' (187) 100) boxS31m (.cutU (QQ.mk' (47) 25) boxS32m (.cutU (QQ.mk' (189) 100) boxS33m (.cutU (QQ.mk' (19) 10) boxS34m (.cutU (QQ.mk' (191) 100) boxS35m (.cutU (QQ.mk' (48) 25) boxS36m (.cutU (QQ.mk' (193) 100) boxS37m (.cutU (QQ.mk' (97) 50) boxS38m (.cutU (QQ.mk' (39) 20) boxS39m (.cutU (QQ.mk' (49) 25) boxS40m (.cutU (QQ.mk' (197) 100) boxS41m (.cutU (QQ.mk' (99) 50) boxS42m (.cutU (QQ.mk' (199) 100) boxS43m (.cutU (QQ.mk' (2) 1) boxS44m (.cutU (QQ.mk' (201) 100) boxB00m (.cutU (QQ.mk' (101) 50) boxB01m (.cutU (QQ.mk' (203) 100) boxB02m (.cutU (QQ.mk' (51) 25) boxB03m (.cutU (QQ.mk' (41) 20) boxB04m (.cutU (QQ.mk' (103) 50) boxB05m (.cutU (QQ.mk' (207) 100) boxB06m (.cutU (QQ.mk' (52) 25) boxB07m (.cutU (QQ.mk' (209) 100) boxB08m (.cutU (QQ.mk' (21) 10) boxB09m boxB10m)))))))))))))))))))))))))))))))))))))))))))))))))))))))

theorem k2BoxM_check : checkBTree false (QQ.mk' (1553773) 1000000) (QQ.mk' (1054691) 500000) (QQ.mk' (0) 1) (QQ.mk' (20711) 50000) (QQ.mk' (9) 20) (QQ.mk' (1) 1) k2BoxM = true :=
  (checkBTree_cutU_of boxS00m_check (checkBTree_cutU_of boxS01m_check (checkBTree_cutU_of boxS02m_check (checkBTree_cutU_of boxS03m_check (checkBTree_cutU_of boxS04m_check (checkBTree_cutU_of boxS05m_check (checkBTree_cutU_of boxS06m_check (checkBTree_cutU_of boxS07m_check (checkBTree_cutU_of boxS08m_check (checkBTree_cutU_of boxS09m_check (checkBTree_cutU_of boxS10m_check (checkBTree_cutU_of boxS11m_check (checkBTree_cutU_of boxS12m_check (checkBTree_cutU_of boxS13m_check (checkBTree_cutU_of boxS14m_check (checkBTree_cutU_of boxS15m_check (checkBTree_cutU_of boxS16m_check (checkBTree_cutU_of boxS17m_check (checkBTree_cutU_of boxS18m_check (checkBTree_cutU_of boxS19m_check (checkBTree_cutU_of boxS20m_check (checkBTree_cutU_of boxS21m_check (checkBTree_cutU_of boxS22m_check (checkBTree_cutU_of boxS23m_check (checkBTree_cutU_of boxS24m_check (checkBTree_cutU_of boxS25m_check (checkBTree_cutU_of boxS26m_check (checkBTree_cutU_of boxS27m_check (checkBTree_cutU_of boxS28m_check (checkBTree_cutU_of boxS29m_check (checkBTree_cutU_of boxS30m_check (checkBTree_cutU_of boxS31m_check (checkBTree_cutU_of boxS32m_check (checkBTree_cutU_of boxS33m_check (checkBTree_cutU_of boxS34m_check (checkBTree_cutU_of boxS35m_check (checkBTree_cutU_of boxS36m_check (checkBTree_cutU_of boxS37m_check (checkBTree_cutU_of boxS38m_check (checkBTree_cutU_of boxS39m_check (checkBTree_cutU_of boxS40m_check (checkBTree_cutU_of boxS41m_check (checkBTree_cutU_of boxS42m_check (checkBTree_cutU_of boxS43m_check (checkBTree_cutU_of boxS44m_check (checkBTree_cutU_of boxB00m_check (checkBTree_cutU_of boxB01m_check (checkBTree_cutU_of boxB02m_check (checkBTree_cutU_of boxB03m_check (checkBTree_cutU_of boxB04m_check (checkBTree_cutU_of boxB05m_check (checkBTree_cutU_of boxB06m_check (checkBTree_cutU_of boxB07m_check (checkBTree_cutU_of boxB08m_check (checkBTree_cutU_of boxB09m_check boxB10m_check)))))))))))))))))))))))))))))))))))))))))))))))))))))))

end ReverseKhinchin.DataK2
