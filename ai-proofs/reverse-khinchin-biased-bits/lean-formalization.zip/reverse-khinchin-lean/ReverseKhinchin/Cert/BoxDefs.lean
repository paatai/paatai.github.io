import ReverseKhinchin.Cert.Env
import ReverseKhinchin.Cert.Cell

/-!
# The two-coordinate box checker of Theorem 6.1 (definitions)

A box is `[u₁,u₂] × [t₁,t₂] × [r₁,r₂]` in the coordinates `a₁ = r c(t)`, `a₂ = r d(t)` of
Section 6 (`c(t) = (1-t²)/(1+t²)`, `d(t) = 2t/(1+t²)`), together with the sign `s` of the second
coefficient. This file contains only the computable checker; the soundness proofs are in
`ReverseKhinchin/K2/Boxes.lean`, so that the kernel-checked data does not depend on them.

* `checkLP` (Lemmas 4.21 and 4.23, test (W1)+(W2)): a degree-six polynomial `c` dominates the
  envelope of the four atoms on both half-lines (`domOK`, by `checkHalf7`, after rounding the
  envelope outward to `2⁻⁶⁴`), and the six-moment objective bound for `E c(M)` is below the target
  `S₂ min(T̃(u₁), T̃(u₂))`, `T̃(u) = 2u³/(1+u²)²` (`objOK`).
* `checkNC` (Lemma 4.35): the near-circle tests (A) and (B), using the tail bound of Lemma 4.34.
* `checkMS` (Lemma 4.39): the m-split boxes, with a second polynomial for residuals whose largest
  coefficient is negative (Lemma 4.8) and the three-coordinate pieces for a positive one.
* `small`: the box lies in `a₁ ≤ 9/20`.

All interval arithmetic is exact (`QQ`).
-/

namespace ReverseKhinchin

open ReverseKhinchin.Poly

/-! ### Rational intervals -/

/-- The closed interval `[lo, hi]`. -/
structure IQ where
  lo : QQ
  hi : QQ

namespace IQ

def add (I J : IQ) : IQ := ⟨I.lo + J.lo, I.hi + J.hi⟩

def neg (I : IQ) : IQ := ⟨-I.hi, -I.lo⟩

def mul (I J : IQ) : IQ :=
  let a := I.lo * J.lo
  let b := I.lo * J.hi
  let c := I.hi * J.lo
  let d := I.hi * J.hi
  ⟨QQ.min (QQ.min a b) (QQ.min c d), QQ.max (QQ.max a b) (QQ.max c d)⟩

/-- An upper bound for `|x|` on the interval. -/
def absHi (I : IQ) : QQ := QQ.max (QQ.abs I.lo) (QQ.abs I.hi)

/-- A lower bound for `|x|` on the interval. -/
def absLo (I : IQ) : QQ :=
  if QQ.blt (QQ.ofInt 0) I.lo then I.lo
  else if QQ.blt I.hi (QQ.ofInt 0) then -I.hi else QQ.ofInt 0

end IQ

/-! ### Enclosures on a box -/

def qIv (u1 u2 : QQ) : IQ := ⟨QQ.inv (QQ.ofInt 1 + u2 * u2), QQ.inv (QQ.ofInt 1 + u1 * u1)⟩

def qbIv (u1 u2 : QQ) : IQ :=
  ⟨QQ.ofInt 1 - QQ.inv (QQ.ofInt 1 + u1 * u1), QQ.ofInt 1 - QQ.inv (QQ.ofInt 1 + u2 * u2)⟩

def tauIv (u1 u2 : QQ) : IQ := ⟨u2 / (QQ.ofInt 1 + u2 * u2), u1 / (QQ.ofInt 1 + u1 * u1)⟩

def vIv (u1 u2 : QQ) : IQ := ⟨QQ.inv u2, QQ.inv u1⟩

def cQ (t : QQ) : QQ := (QQ.ofInt 1 - t * t) / (QQ.ofInt 1 + t * t)

def dQ (t : QQ) : QQ := QQ.ofInt 2 * t / (QQ.ofInt 1 + t * t)

def cIv (t1 t2 : QQ) : IQ := ⟨cQ t2, cQ t1⟩

/-- The enclosure of `s d(t)`. -/
def sdIv (s : Bool) (t1 t2 : QQ) : IQ := if s then ⟨dQ t1, dQ t2⟩ else ⟨-dQ t2, -dQ t1⟩

/-- The atoms `gⱼ` of the unit vector `(c, s d)`: `pⱼ xⱼ = τ gⱼ` (Lemma 4.16). -/
def gIv (s : Bool) (u1 u2 t1 t2 : QQ) : List IQ :=
  let q := qIv u1 u2
  let qb := qbIv u1 u2
  let c := cIv t1 t2
  let sd := sdIv s t1 t2
  [q.mul (c.add sd), (qb.mul c).add (q.mul sd).neg, (q.mul c).neg.add (qb.mul sd),
    (qb.mul (c.add sd)).neg]

/-- The atom probabilities `pⱼ`. -/
def pIv (u1 u2 : QQ) : List IQ :=
  let q := qIv u1 u2
  let qb := qbIv u1 u2
  [q.mul q, q.mul qb, qb.mul q, qb.mul qb]

/-- The atom values `yⱼ = c χ(b₀) + s d χ(b₁)` of the unit vector. -/
def yIv (s : Bool) (u1 u2 t1 t2 : QQ) : List IQ :=
  let U : IQ := ⟨u1, u2⟩
  let V := vIv u1 u2
  let c := cIv t1 t2
  let sd := sdIv s t1 t2
  [(c.add sd).mul U, (c.mul U).add (sd.mul V).neg, (c.mul V).neg.add (sd.mul U),
    ((c.add sd).mul V).neg]

/-- The envelope terms `(πⱼ, βⱼ)` of Lemma 4.21: `πⱼ = r τ gⱼ`, `βⱼ = pⱼ b`. -/
def envTerms (s : Bool) (u1 u2 t1 t2 r1 r2 bl bh : QQ) : List (IQ × IQ) :=
  let rt := (IQ.mk r1 r2).mul (tauIv u1 u2)
  let b : IQ := ⟨bl, bh⟩
  List.zipWith (fun g p => (rt.mul g, p.mul b)) (gIv s u1 u2 t1 t2) (pIv u1 u2)

/-! ### Outward rounding of the envelope to `2⁻⁶⁴` -/

def DE : ℤ := 18446744073709551616

def flD (x : QQ) : ℤ := x.num * DE / (x.den : ℤ)

def ceD (x : QQ) : ℤ := -((-x.num) * DE / (x.den : ℤ))

/-- `(⌈D π⁺⌉, ⌊D π⁻⌋, ⌈D β⁺⌉, ⌊D β⁻⌋)` -/
def roundT (T : IQ × IQ) : ℤ × ℤ × ℤ × ℤ := (ceD T.1.hi, flD T.1.lo, ceD T.2.hi, flD T.2.lo)

/-- The lines on `y = Y x ≥ 0`: `max(P + Bp y, -Mn - Bm y)`. -/
def linesPos (Y : ℤ) : List (ℤ × ℤ × ℤ × ℤ) → List Line2
  | [] => []
  | (P, Mn, Bp, Bm) :: R => (P, Bp * Y, -Mn, -(Bm * Y)) :: linesPos Y R

/-- The lines on `y = -Y x ≤ 0`: `max(-Mn + Bp z, P - Bm z)` with `z = -y`. -/
def linesNeg (Y : ℤ) : List (ℤ × ℤ × ℤ × ℤ) → List Line2
  | [] => []
  | (P, Mn, Bp, Bm) :: R => (-Mn, Bp * Y, P, -(Bm * Y)) :: linesNeg Y R

/-! ### Polynomials -/

/-- `c(y) = (n₀ + n₁ y + ⋯ + n₆ y⁶)/N`, with the scales `Y` of the two half-lines. -/
structure Poly7 where
  N : ℕ
  n0 : ℤ
  n1 : ℤ
  n2 : ℤ
  n3 : ℤ
  n4 : ℤ
  n5 : ℤ
  n6 : ℤ
  yP : ℤ
  yN : ℤ

/-- The coefficients of `c` as a six-moment cell (for the objective bound). -/
def Poly7.cell (c : Poly7) (mb : QQ) : CellCert :=
  ⟨QQ.ofInt 0, mb, QQ.mk' c.n0 c.N, QQ.mk' c.n1 c.N, QQ.mk' c.n2 c.N, QQ.mk' c.n3 c.N,
    QQ.mk' c.n4 c.N, QQ.mk' c.n5 c.N, QQ.mk' c.n6 c.N⟩

def envFuel : ℕ := 30

/-- `N H(x) ≤ D N c(Y x)` for `x ≥ 0`. -/
def halfOK (L : List Line2) (c : Poly7) (Y : ℤ) : Bool :=
  let Y2 := Y * Y
  let Y3 := Y2 * Y
  let Y4 := Y3 * Y
  let Y5 := Y4 * Y
  let Y6 := Y5 * Y
  checkHalf7 L c.N (DE * c.n0) (DE * c.n1 * Y) (DE * c.n2 * Y2) (DE * c.n3 * Y3)
    (DE * c.n4 * Y4) (DE * c.n5 * Y5) (DE * c.n6 * Y6) envFuel

/-- (W1): `c` dominates the rounded envelope on both half-lines. -/
def domOK (R : List (ℤ × ℤ × ℤ × ℤ)) (c : Poly7) : Bool :=
  decide (0 < c.N) && decide (0 < c.yP) && decide (0 < c.yN) &&
    halfOK (linesPos c.yP R) c c.yP && halfOK (linesNeg c.yN R) c (-c.yN)

/-! ### The objective bound -/

/-- `T̃(u) = 2u³/(1+u²)²`, so that `T₂ = √2 T̃(u)`. -/
def ttQ (u : QQ) : QQ :=
  QQ.ofInt 2 * (u * u * u) / ((QQ.ofInt 1 + u * u) * (QQ.ofInt 1 + u * u))

/-- The target `S₂ min(T̃(u₁), T̃(u₂)) ≤ T₂` on `[u₁, u₂]`. -/
def tgtQ (u1 u2 : QQ) : QQ := S2Q * QQ.min (ttQ u1) (ttQ u2)

/-- (W2): the six-moment objective bound for `E c(M)` is at most `tgt`, for `|βᵢ| ≤ m̄`. -/
def objOK (u1 u2 tgt : QQ) (cc : CellCert) : Bool :=
  QQ.blt (wwQ u2) (QQ.ofInt 13) && QQ.blt (QQ.ofInt 0) cc.mb &&
    checkNN cellFuel (clearDen (objPoly (tgt - cellA cc) (cellBb u2 cc) (cellGam u1 u2 cc)
      (cellEps u1 u2 cc) cc.mb)).1

/-- The objective bound when `∑ βᵢ³ ≤ p₃* < 0` is known: the cubic term is
`κ₃(u₁)(c₃ + 10c₅) p₃*` (requires `c₃ + 10c₅ ≥ 0`). -/
def objOK3 (u1 u2 tgt p3max : QQ) (cc : CellCert) : Bool :=
  QQ.blt (wwQ u2) (QQ.ofInt 13) && QQ.blt (QQ.ofInt 0) cc.mb &&
    QQ.ble (QQ.ofInt 0) (cc.c3 + QQ.ofInt 10 * cc.c5) && QQ.ble p3max (QQ.ofInt 0) &&
    checkNN cellFuel (clearDen (objPoly
      (tgt - (cellA cc + k3Q u1 * (cc.c3 + QQ.ofInt 10 * cc.c5) * p3max)) (QQ.ofInt 0)
      (cellGam u1 u2 cc) (cellEps u1 u2 cc) cc.mb)).1

/-! ### Common conditions -/

def boxOK (u1 t1 t2 r1 r2 : QQ) : Bool :=
  QQ.ble (QQ.ofInt 1) u1 && QQ.ble (QQ.ofInt 0) t1 && QQ.ble t2 (QQ.ofInt 1) &&
    QQ.ble (QQ.ofInt 0) r1 && QQ.ble r2 (QQ.ofInt 1)

/-- `b⁻ ≤ √(1-r²) ≤ b⁺` on the box. -/
def bOK (r1 r2 bl bh : QQ) : Bool :=
  QQ.ble (QQ.ofInt 0) bl && QQ.ble (bl * bl) (QQ.ofInt 1 - r2 * r2) &&
    QQ.ble (QQ.ofInt 0) bh && QQ.ble (QQ.ofInt 1 - r1 * r1) (bh * bh)

/-- `m̄ ≥ min(1, a₂/b)` on the box. -/
def mbOK (t2 r2 bl mb : QQ) : Bool :=
  QQ.blt (QQ.ofInt 0) mb && (QQ.ble (QQ.ofInt 1) mb || QQ.ble (r2 * dQ t2) (mb * bl))

/-! ### Linear-programming boxes -/

structure LPCert where
  c : Poly7
  mb : QQ
  bl : QQ
  bh : QQ

def checkLP (s : Bool) (u1 u2 t1 t2 r1 r2 : QQ) (d : LPCert) : Bool :=
  boxOK u1 t1 t2 r1 r2 && bOK r1 r2 d.bl d.bh && mbOK t2 r2 d.bl d.mb &&
    domOK ((envTerms s u1 u2 t1 t2 r1 r2 d.bl d.bh).map roundT) d.c &&
    objOK u1 u2 (tgtQ u1 u2) (d.c.cell d.mb)

/-! ### Near-circle boxes (Lemma 4.35) -/

structure NCCert where
  testA : Bool
  mb : QQ
  bl : QQ
  bh : QQ

def C27 : QQ := QQ.mk' 27 128

def cube (x : QQ) : QQ := x * x * x

/-- `E M⁴ ≤ 3 + max(κ₄(u₂), 0) m̄²`. -/
def E4Q (u2 mb : QQ) : QQ :=
  QQ.ofInt 3 + QQ.max (wwQ u2 - QQ.ofInt 4) (QQ.ofInt 0) * (mb * mb)

def allPosLo : List IQ → Bool
  | [] => true
  | y :: ys => QQ.blt (QQ.ofInt 0) y.absLo && allPosLo ys

/-- `∑ⱼ p⁺ⱼ / (|yⱼ|⁻)³` -/
def sumInvCube : List IQ → List IQ → QQ
  | p :: ps, y :: ys => p.hi / cube y.absLo + sumInvCube ps ys
  | _, _ => QQ.ofInt 0

/-- An upper bound for `E|xⱼ + bM| - |xⱼ|` (`|xⱼ| = r|yⱼ|`): `min(b⁺, (27/128) b⁴ E₄/|xⱼ|³)`. -/
def tailE (bh b2 E4 r1 : QQ) (y : IQ) : QQ :=
  if QQ.blt (QQ.ofInt 0) y.absLo then
    QQ.min bh (C27 * (b2 * b2) * E4 / (cube r1 * cube y.absLo))
  else bh

def sumTail (bh b2 E4 r1 : QQ) : List IQ → List IQ → QQ
  | p :: ps, y :: ys => p.hi * tailE bh b2 E4 r1 y + sumTail bh b2 E4 r1 ps ys
  | _, _ => QQ.ofInt 0

def sumAbsHi : List IQ → QQ
  | [] => QQ.ofInt 0
  | g :: gs => g.absHi + sumAbsHi gs

/-- Test (A): `(27/128) E₄ b² (1 + r) r⁻³ ∑ⱼ pⱼ/|yⱼ|³ < T` (uses Lemma 6.2). -/
def ncTestA (s : Bool) (u1 u2 t1 t2 r1 r2 mb : QQ) : Bool :=
  let ys := yIv s u1 u2 t1 t2
  allPosLo ys &&
    QQ.blt (C27 * E4Q u2 mb * (QQ.ofInt 1 - r1 * r1) * (QQ.ofInt 1 + r2) / cube r1 *
      sumInvCube (pIv u1 u2) ys) (tgtQ u1 u2)

/-- Test (B): `∑ⱼ pⱼ eⱼ < T(1 - r) + r(T - G)` with `G ≥ E|cχ₁ + s dχ₂|`. -/
def ncTestB (s : Bool) (u1 u2 t1 t2 r1 r2 mb bh : QQ) : Bool :=
  let T := tgtQ u1 u2
  let margin := T - (tauIv u1 u2).hi * sumAbsHi (gIv s u1 u2 t1 t2)
  QQ.blt (QQ.ofInt 0) margin &&
    QQ.blt (sumTail bh (QQ.ofInt 1 - r1 * r1) (E4Q u2 mb) r1 (pIv u1 u2) (yIv s u1 u2 t1 t2))
      (T * (QQ.ofInt 1 - r2) + r1 * margin)

def checkNC (s : Bool) (u1 u2 t1 t2 r1 r2 : QQ) (d : NCCert) : Bool :=
  boxOK u1 t1 t2 r1 r2 && bOK r1 r2 d.bl d.bh && mbOK t2 r2 d.bl d.mb &&
    QQ.blt (QQ.ofInt 0) r1 &&
    (if d.testA then ncTestA s u1 u2 t1 t2 r1 r2 d.mb else ncTestB s u1 u2 t1 t2 r1 r2 d.mb d.bh)

/-! ### m-split boxes (Lemmas 4.8 and 4.39) -/

/-- A piece `m ∈ [m₁, m₂]` of the largest residual coefficient `+m`, with `r' ≤ rp` and
`b' ≤ bp`, where `a₃ = b m`, `b' = b √(1 - m²)` and `r'² = r² + a₃² = 1 - b'²`. -/
structure MSPiece where
  m1 : QQ
  m2 : QQ
  testA : Bool
  rp : QQ
  bp : QQ

structure MSCert where
  c : Poly7
  c2 : Poly7
  mcut : QQ
  p3max : QQ
  mb : QQ
  bl : QQ
  bh : QQ
  pieces : List MSPiece

/-- `φ(m) = -m³ + (1-m²)^{3/2} ≤ p₃* < 0` at `m = m_cut`. -/
def phiOK (mcut p3max : QQ) : Bool :=
  QQ.blt (QQ.ofInt 0) mcut && QQ.ble mcut (QQ.ofInt 1) &&
    QQ.blt (QQ.ofInt 1) (QQ.ofInt 2 * mcut * mcut) && QQ.blt p3max (QQ.ofInt 0) &&
    QQ.ble (QQ.ofInt 0) (p3max + cube mcut) &&
    QQ.ble (cube (QQ.ofInt 1 - mcut * mcut)) ((p3max + cube mcut) * (p3max + cube mcut))

/-- The pieces cover `[cur, mtop]`. -/
def coverOK (mtop : QQ) : QQ → List MSPiece → Bool
  | cur, [] => QQ.ble mtop cur
  | cur, p :: ps => QQ.ble p.m1 cur && coverOK mtop (QQ.max cur p.m2) ps

/-- The atom `(p, x, p x)` of three coefficients `a₁, a₂, a₃` at the bits `e₁, e₂, e₃`
(`p x` through `q u = (1-q)/u = τ`). -/
def atom3 (q qb U V τ a1 a2 a3 : IQ) (e1 e2 e3 : Bool) : IQ × IQ × IQ :=
  let p1 := if e1 then q else qb
  let p2 := if e2 then q else qb
  let p3 := if e3 then q else qb
  ((p1.mul p2).mul p3,
    ((a1.mul (if e1 then U else V.neg)).add (a2.mul (if e2 then U else V.neg))).add
      (a3.mul (if e3 then U else V.neg)),
    (((a1.mul (p2.mul p3)).mul (if e1 then τ else τ.neg)).add
      ((a2.mul (p1.mul p3)).mul (if e2 then τ else τ.neg))).add
      ((a3.mul (p1.mul p2)).mul (if e3 then τ else τ.neg)))

def atoms3 (q qb U V τ a1 a2 a3 : IQ) : List (IQ × IQ × IQ) :=
  [atom3 q qb U V τ a1 a2 a3 true true true, atom3 q qb U V τ a1 a2 a3 true true false,
    atom3 q qb U V τ a1 a2 a3 true false true, atom3 q qb U V τ a1 a2 a3 true false false,
    atom3 q qb U V τ a1 a2 a3 false true true, atom3 q qb U V τ a1 a2 a3 false true false,
    atom3 q qb U V τ a1 a2 a3 false false true, atom3 q qb U V τ a1 a2 a3 false false false]

def allPosLo3 : List (IQ × IQ × IQ) → Bool
  | [] => true
  | a :: as => QQ.blt (QQ.ofInt 0) a.2.1.absLo && allPosLo3 as

def sumInvCube3 : List (IQ × IQ × IQ) → QQ
  | [] => QQ.ofInt 0
  | a :: as => a.1.hi / cube a.2.1.absLo + sumInvCube3 as

/-- `∑ⱼ (|pⱼxⱼ| + pⱼ min(b', (27/128) b'⁴ E₄/|xⱼ|³))` -/
def sumB3 (bp bp2 E4 : QQ) : List (IQ × IQ × IQ) → QQ
  | [] => QQ.ofInt 0
  | a :: as =>
    a.2.2.absHi + a.1.hi * (if QQ.blt (QQ.ofInt 0) a.2.1.absLo then
      QQ.min bp (C27 * (bp2 * bp2) * E4 / cube a.2.1.absLo) else bp) + sumB3 bp bp2 E4 as

/-- Tests (A3) (with the three-bit lemma) and (B3) on a piece. -/
def pieceOK (s : Bool) (u1 u2 t1 t2 r1 r2 bl bh E4 T : QQ) (pc : MSPiece) : Bool :=
  let r : IQ := ⟨r1, r2⟩
  let ats := atoms3 (qIv u1 u2) (qbIv u1 u2) ⟨u1, u2⟩ (vIv u1 u2) (tauIv u1 u2)
    (r.mul (cIv t1 t2)) (r.mul (sdIv s t1 t2)) ⟨bl * pc.m1, bh * pc.m2⟩
  let bp2 := bh * bh * (QQ.ofInt 1 - pc.m1 * pc.m1)
  QQ.ble (QQ.ofInt 0) pc.m1 && QQ.ble pc.m1 pc.m2 && QQ.ble pc.m2 (QQ.ofInt 1) &&
    (if pc.testA then
      QQ.ble (QQ.ofInt 0) pc.rp &&
        QQ.ble (QQ.ofInt 1 - bl * bl * (QQ.ofInt 1 - pc.m2 * pc.m2)) (pc.rp * pc.rp) &&
        allPosLo3 ats && QQ.blt (C27 * E4 * bp2 * (QQ.ofInt 1 + pc.rp) * sumInvCube3 ats) T
    else
      QQ.ble (QQ.ofInt 0) pc.bp && QQ.ble bp2 (pc.bp * pc.bp) && QQ.blt (sumB3 pc.bp bp2 E4 ats) T)

def checkMS (s : Bool) (u1 u2 t1 t2 r1 r2 : QQ) (d : MSCert) : Bool :=
  let R := (envTerms s u1 u2 t1 t2 r1 r2 d.bl d.bh).map roundT
  let T := tgtQ u1 u2
  boxOK u1 t1 t2 r1 r2 && bOK r1 r2 d.bl d.bh && mbOK t2 r2 d.bl d.mb &&
    QQ.blt (QQ.ofInt 0) d.bl &&
    domOK R d.c && objOK u1 u2 T (d.c.cell (QQ.min d.mb d.mcut)) &&
    phiOK d.mcut d.p3max && domOK R d.c2 && objOK3 u1 u2 T d.p3max (d.c2.cell d.mb) &&
    coverOK (QQ.min (QQ.ofInt 1) d.mb) d.mcut d.pieces &&
    d.pieces.all (pieceOK s u1 u2 t1 t2 r1 r2 d.bl d.bh (E4Q u2 (QQ.ofInt 1)) T)

/-! ### Box trees -/

/-- `A_S = 9/20`: the two-coordinate route treats `a₁ > 9/20`. -/
def ASQ : QQ := QQ.mk' 9 20

/-- A guillotine subdivision of a box. -/
inductive BTree
  | lp (d : LPCert)
  | nc (d : NCCert)
  | ms (d : MSCert)
  | small
  | cutU (x : QQ) (l r : BTree)
  | cutT (x : QQ) (l r : BTree)
  | cutR (x : QQ) (l r : BTree)

def checkBTree (s : Bool) : QQ → QQ → QQ → QQ → QQ → QQ → BTree → Bool
  | u1, u2, t1, t2, r1, r2, .lp d => checkLP s u1 u2 t1 t2 r1 r2 d
  | u1, u2, t1, t2, r1, r2, .nc d => checkNC s u1 u2 t1 t2 r1 r2 d
  | u1, u2, t1, t2, r1, r2, .ms d => checkMS s u1 u2 t1 t2 r1 r2 d
  | _, _, t1, t2, r1, r2, .small =>
    QQ.ble (QQ.ofInt 0) t1 && QQ.ble t2 (QQ.ofInt 1) && QQ.ble (QQ.ofInt 0) r1 &&
      QQ.ble (r2 * cQ t1) ASQ
  | u1, u2, t1, t2, r1, r2, .cutU x l r =>
    checkBTree s u1 x t1 t2 r1 r2 l && checkBTree s x u2 t1 t2 r1 r2 r
  | u1, u2, t1, t2, r1, r2, .cutT x l r =>
    checkBTree s u1 u2 t1 x r1 r2 l && checkBTree s u1 u2 x t2 r1 r2 r
  | u1, u2, t1, t2, r1, r2, .cutR x l r =>
    checkBTree s u1 u2 t1 t2 r1 x l && checkBTree s u1 u2 t1 t2 x r2 r

theorem checkBTree_cutU_of {s : Bool} {u1 u2 t1 t2 r1 r2 x : QQ} {l r : BTree}
    (hl : checkBTree s u1 x t1 t2 r1 r2 l = true) (hr : checkBTree s x u2 t1 t2 r1 r2 r = true) :
    checkBTree s u1 u2 t1 t2 r1 r2 (.cutU x l r) = true := by
  simp only [checkBTree, hl, hr, Bool.and_self]

theorem checkBTree_cutT_of {s : Bool} {u1 u2 t1 t2 r1 r2 x : QQ} {l r : BTree}
    (hl : checkBTree s u1 u2 t1 x r1 r2 l = true) (hr : checkBTree s u1 u2 x t2 r1 r2 r = true) :
    checkBTree s u1 u2 t1 t2 r1 r2 (.cutT x l r) = true := by
  simp only [checkBTree, hl, hr, Bool.and_self]

theorem checkBTree_cutR_of {s : Bool} {u1 u2 t1 t2 r1 r2 x : QQ} {l r : BTree}
    (hl : checkBTree s u1 u2 t1 t2 r1 x l = true) (hr : checkBTree s u1 u2 t1 t2 x r2 r = true) :
    checkBTree s u1 u2 t1 t2 r1 r2 (.cutR x l r) = true := by
  simp only [checkBTree, hl, hr, Bool.and_self]

end ReverseKhinchin
