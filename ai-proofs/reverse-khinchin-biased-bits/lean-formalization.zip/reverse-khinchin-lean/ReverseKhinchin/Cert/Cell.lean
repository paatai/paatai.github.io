import ReverseKhinchin.Cert.Poly
import ReverseKhinchin.SixMoment

/-!
# The kernel-checked six-moment cell certificates

A `CellCert` stores the data of Definition 4.13 (`k = 1`, `D = 6`): the bound `b̄ ≥ √(1-a₁²)`,
the coefficient bound `m̄`, and the seven coefficients of `P`. `checkLeaf` recomputes everything
else from the cell corners in exact rational arithmetic and certifies (V1)–(V4) with the
integer Bernstein checker. A `CTree` is a binary subdivision of a rectangle into cells
(each split is at the midpoint), so that the cells cover the rectangle by construction.

`checkTree_sound`: if `checkTree u₁ u₂ a₁ a₂ t = true`, then `E R_a(b M) ≤ τ(u)(1-a)` for all
`u ∈ [u₁,u₂]`, `a ∈ [a₁,a₂] ∩ (0,1)` and all admissible `M`.
-/

namespace ReverseKhinchin

open ReverseKhinchin.Poly

/-! ### Rational polynomials -/

/-- Horner evaluation of a list of rationals. -/
noncomputable def evalQ : List QQ → ℝ → ℝ
  | [], _ => 0
  | c :: p, x => c.toReal + x * evalQ p x

def clearDenStep (c : QQ) (r : List ℤ × ℕ) : List ℤ × ℕ :=
  (c.num * r.2 :: pscale c.den r.1, c.den * r.2)

/-- Clearing denominators: `(clearDen p).1 = (clearDen p).2 • p` as polynomials. -/
def clearDen : List QQ → List ℤ × ℕ
  | [] => ([], 1)
  | c :: p => clearDenStep c (clearDen p)

theorem clearDen_spec (p : List QQ) :
    0 < (clearDen p).2 ∧ ∀ x, evalM (clearDen p).1 x = (clearDen p).2 * evalQ p x := by
  induction p with
  | nil => exact ⟨Nat.one_pos, fun x => by simp [clearDen, evalQ]⟩
  | cons c p ih =>
    obtain ⟨hd, he⟩ := ih
    refine ⟨Nat.mul_pos c.den_pos hd, fun x => ?_⟩
    simp only [clearDen, clearDenStep, evalM_cons, evalM_pscale, he, evalQ, QQ.toReal]
    have := c.den_ne_zero
    push_cast
    field_simp

theorem evalQ_nonneg_of_checkNNR {n : ℕ} {p : List QQ} (h : checkNNR n (clearDen p).1 = true)
    (y : ℝ) : 0 ≤ evalQ p y := by
  obtain ⟨hd, he⟩ := clearDen_spec p
  have := checkNNR_sound h y
  rw [he] at this
  exact (mul_nonneg_iff_of_pos_left (by exact_mod_cast hd)).1 this

theorem evalQ_nonneg_of_checkNN {n : ℕ} {p : List QQ} (h : checkNN n (clearDen p).1 = true)
    {x : ℝ} (hx0 : 0 ≤ x) (hx1 : x ≤ 1) : 0 ≤ evalQ p x := by
  obtain ⟨hd, he⟩ := clearDen_spec p
  have := checkNN_sound n _ h x hx0 hx1
  rw [he] at this
  exact (mul_nonneg_iff_of_pos_left (by exact_mod_cast hd)).1 this

/-! ### Cell data and the checker -/

/-- The stored data of one six-moment cell. -/
structure CellCert where
  bb : QQ
  mb : QQ
  c0 : QQ
  c1 : QQ
  c2 : QQ
  c3 : QQ
  c4 : QQ
  c5 : QQ
  c6 : QQ

/-- Maximal bisection depth for the polynomial checks. -/
def cellFuel : ℕ := 40

def k3Q (u : QQ) : QQ := u - QQ.inv u
def wwQ (u : QQ) : QQ := u * u + QQ.inv (u * u)
def f6Q (w : QQ) : QQ := w * w - QQ.ofInt 26 * w + QQ.ofInt 64

theorem toReal_k3Q (u : QQ) : (k3Q u).toReal = k3 u.toReal := by
  simp [k3Q, k3]

theorem toReal_wwQ (u : QQ) : (wwQ u).toReal = ww u.toReal := by
  simp only [wwQ, ww, QQ.toReal_add, QQ.toReal_mul, QQ.toReal_inv]
  rw [mul_inv]; ring

theorem toReal_f6Q (w : QQ) : (f6Q w).toReal = w.toReal ^ 2 - 26 * w.toReal + 64 := by
  simp [f6Q]; ring

/-- The objective polynomial `h(m̄ x)` of (V4), its value being
`target - B̄ ρ - Γ ρ² - ε ρ⁴` at `ρ = m̄ x`. -/
def objPoly (target Bb gam eps mb : QQ) : List QQ :=
  [target, -(Bb * mb), -(gam * (mb * mb)), QQ.ofInt 0, -(eps * ((mb * mb) * (mb * mb)))]

/-! The quantities of Definitions 4.9 and 4.13, computed from the cell corners. -/

/-- `ℓ̄₁(y) = l1c0 + l1c1 y` -/
def l1c0 (u2 a1 : QQ) : QQ := -(u2 * u2 / (QQ.ofInt 1 + u2 * u2) * (a1 / u2))
def l1c1 (u2 bb : QQ) : QQ := u2 * u2 / (QQ.ofInt 1 + u2 * u2) * bb
/-- `ℓ̄₂(y) = l2c0 + l2c1 y` -/
def l2c0 (u1 a1 : QQ) : QQ := -(QQ.inv (QQ.ofInt 1 + u1 * u1) * (a1 * u1))
def l2c1 (u1 bb : QQ) : QQ := -(QQ.inv (QQ.ofInt 1 + u1 * u1) * bb)

def cellA (cc : CellCert) : QQ := cc.c0 + cc.c2 + QQ.ofInt 3 * cc.c4 + QQ.ofInt 15 * cc.c6
def cellBb (u2 : QQ) (cc : CellCert) : QQ := k3Q u2 * QQ.abs (cc.c3 + QQ.ofInt 10 * cc.c5)
def cellCh (u1 u2 : QQ) (cc : CellCert) : QQ :=
  QQ.max ((wwQ u1 - QQ.ofInt 4) * (cc.c4 + QQ.ofInt 15 * cc.c6))
    ((wwQ u2 - QQ.ofInt 4) * (cc.c4 + QQ.ofInt 15 * cc.c6))
def cellDb (u1 u2 : QQ) (cc : CellCert) : QQ :=
  k3Q u2 * QQ.max (QQ.abs (wwQ u1 - QQ.ofInt 10)) (QQ.abs (wwQ u2 - QQ.ofInt 10)) * QQ.abs cc.c5
def cellEh (u1 u2 : QQ) (cc : CellCert) : QQ := QQ.max (f6Q (wwQ u1) * cc.c6) (f6Q (wwQ u2) * cc.c6)
def cellFh (u1 u2 : QQ) (cc : CellCert) : QQ :=
  QQ.max (QQ.ofInt 0) (QQ.max (QQ.ofInt 10 * (k3Q u1 * k3Q u1) * cc.c6)
    (QQ.ofInt 10 * (k3Q u2 * k3Q u2) * cc.c6))
def cellGam (u1 u2 : QQ) (cc : CellCert) : QQ :=
  cellCh u1 u2 cc + cellDb u1 u2 cc * cc.mb + cellFh u1 u2 cc +
    QQ.max (cellEh u1 u2 cc) (QQ.ofInt 0) * (cc.mb * cc.mb)
def cellEps (u1 u2 : QQ) (cc : CellCert) : QQ := QQ.min (cellEh u1 u2 cc) (QQ.ofInt 0)
/-- `Θ₁ - A` with `Θ₁ = τ(u₂)(w - a̅)` (Definition 4.13; `w = S_k (u₁²/(1+u₁²))^(k-1)`). -/
def cellTarget (w u2 a2 : QQ) (cc : CellCert) : QQ :=
  u2 / (QQ.ofInt 1 + u2 * u2) * (w - a2) - cellA cc

/-- The checker for one cell `[u₁,u₂] × [a₁,a₂]` with target weight `w`. -/
def checkLeaf (w u1 u2 a1 a2 : QQ) (cc : CellCert) : Bool :=
  QQ.ble (QQ.ofInt 1) u1 && QQ.ble u1 u2 && QQ.ble (QQ.ofInt 0) a1 && QQ.ble a1 a2 &&
  QQ.blt a2 (QQ.ofInt 1) && QQ.ble a2 w &&
  QQ.ble (QQ.ofInt 0) cc.bb && QQ.ble (QQ.ofInt 1 - a1 * a1) (cc.bb * cc.bb) &&
  QQ.blt (QQ.ofInt 0) cc.mb &&
  (QQ.ble (QQ.ofInt 1) cc.mb || QQ.ble (a2 * a2) (cc.mb * cc.mb * (QQ.ofInt 1 - a2 * a2))) &&
  QQ.blt (wwQ u2) (QQ.ofInt 13) &&
  checkNNR cellFuel (clearDen [cc.c0, cc.c1, cc.c2, cc.c3, cc.c4, cc.c5, cc.c6]).1 &&
  checkNNR cellFuel (clearDen [cc.c0 - l1c0 u2 a1, cc.c1 - l1c1 u2 cc.bb, cc.c2, cc.c3, cc.c4,
    cc.c5, cc.c6]).1 &&
  checkNNR cellFuel (clearDen [cc.c0 - l2c0 u1 a1, cc.c1 - l2c1 u1 cc.bb, cc.c2, cc.c3, cc.c4,
    cc.c5, cc.c6]).1 &&
  checkNN cellFuel (clearDen (objPoly (cellTarget w u2 a2 cc) (cellBb u2 cc) (cellGam u1 u2 cc)
    (cellEps u1 u2 cc) cc.mb)).1

theorem evalQ_P6 (c0 c1 c2 c3 c4 c5 c6 : QQ) (y : ℝ) :
    evalQ [c0, c1, c2, c3, c4, c5, c6] y =
      P6 c0.toReal c1.toReal c2.toReal c3.toReal c4.toReal c5.toReal c6.toReal y := by
  simp [evalQ, P6]

theorem evalQ_P6_sub (c0 c1 c2 c3 c4 c5 c6 l0 l1 : QQ) (y : ℝ) :
    evalQ [c0 - l0, c1 - l1, c2, c3, c4, c5, c6] y =
      P6 c0.toReal c1.toReal c2.toReal c3.toReal c4.toReal c5.toReal c6.toReal y -
        (l0.toReal + l1.toReal * y) := by
  simp [evalQ, P6]; ring

theorem checkLeaf_sound {w u1 u2 a1 a2 : QQ} {cc : CellCert}
    (h : checkLeaf w u1 u2 a1 a2 cc = true) {W : ℝ} (hW : 1 ≤ u1.toReal → w.toReal ≤ W)
    {u a : ℝ} (hu1 : u1.toReal ≤ u) (hu2 : u ≤ u2.toReal) (ha1 : a1.toReal ≤ a)
    (ha2 : a ≤ a2.toReal) (ha0 : 0 < a) {n : ℕ} (β : Fin n → ℝ) (h2 : psum β 2 = 1)
    (hβ1 : ∀ i, |β i| ≤ 1) (hβa : ∀ i, |β i| ≤ a / √(1 - a ^ 2)) :
    expect (qOf u) (fun x => Ra u a (√(1 - a ^ 2) * lin (qOf u) β x)) ≤ tau (qOf u) * (W - a) := by
  simp only [checkLeaf, Bool.and_eq_true, Bool.or_eq_true] at h
  obtain ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨hU1, -⟩, hA1⟩, -⟩, hA2⟩, hAW⟩, hbb0⟩, hbb⟩, hm0⟩, hm⟩, hw⟩, hV1⟩,
    hV2⟩, hV3⟩, hV4⟩ := h
  simp only [QQ.ble_iff, QQ.blt_iff, QQ.toReal_ofInt, QQ.toReal_sub, QQ.toReal_mul,
    Int.cast_one, Int.cast_zero, Int.cast_ofNat, toReal_wwQ] at hU1 hA1 hA2 hAW hbb0 hbb hm0 hm hw
  have hwW := hW hU1
  suffices H : expect (qOf u) (fun x => Ra u a (√(1 - a ^ 2) * lin (qOf u) β x)) ≤
      tau (qOf u) * (w.toReal - a) from
    H.trans (mul_le_mul_of_nonneg_left (by linarith) (Real.sqrt_nonneg _))
  clear hW hwW
  set U1 := u1.toReal
  set U2 := u2.toReal
  set A1 := a1.toReal
  set A2 := a2.toReal
  set Wq := w.toReal
  set bb := cc.bb.toReal
  set m := cc.mb.toReal
  -- (V1)–(V4)
  have hP0 : ∀ y, 0 ≤ P6 cc.c0.toReal cc.c1.toReal cc.c2.toReal cc.c3.toReal cc.c4.toReal
      cc.c5.toReal cc.c6.toReal y := fun y => by
    have := evalQ_nonneg_of_checkNNR hV1 y
    rwa [evalQ_P6] at this
  have hP1 : ∀ y, U2 ^ 2 / (1 + U2 ^ 2) * (bb * y - A1 / U2) ≤ P6 cc.c0.toReal cc.c1.toReal
      cc.c2.toReal cc.c3.toReal cc.c4.toReal cc.c5.toReal cc.c6.toReal y := fun y => by
    have := evalQ_nonneg_of_checkNNR hV2 y
    rw [evalQ_P6_sub] at this
    simp only [l1c0, l1c1, QQ.toReal_neg, QQ.toReal_mul, QQ.toReal_div, QQ.toReal_add,
      QQ.toReal_ofInt, Int.cast_one] at this
    have e : -(U2 * U2 / (1 + U2 * U2) * (A1 / U2)) + U2 * U2 / (1 + U2 * U2) * bb * y =
        U2 ^ 2 / (1 + U2 ^ 2) * (bb * y - A1 / U2) := by ring
    linarith
  have hP2 : ∀ y, 1 / (1 + U1 ^ 2) * (-(bb * y) - A1 * U1) ≤ P6 cc.c0.toReal cc.c1.toReal
      cc.c2.toReal cc.c3.toReal cc.c4.toReal cc.c5.toReal cc.c6.toReal y := fun y => by
    have := evalQ_nonneg_of_checkNNR hV3 y
    rw [evalQ_P6_sub] at this
    simp only [l2c0, l2c1, QQ.toReal_neg, QQ.toReal_mul, QQ.toReal_inv, QQ.toReal_add,
      QQ.toReal_ofInt, Int.cast_one] at this
    have e : -((1 + U1 * U1)⁻¹ * (A1 * U1)) + -((1 + U1 * U1)⁻¹ * bb) * y =
        1 / (1 + U1 ^ 2) * (-(bb * y) - A1 * U1) := by ring
    linarith
  have hV : ∀ ρ, 0 ≤ ρ → ρ ≤ m →
      (cellBb u2 cc).toReal * ρ + ((cellCh u1 u2 cc).toReal + (cellDb u1 u2 cc).toReal * m +
        (cellFh u1 u2 cc).toReal + max (cellEh u1 u2 cc).toReal 0 * m ^ 2) * ρ ^ 2 +
        min (cellEh u1 u2 cc).toReal 0 * ρ ^ 4 ≤
      U2 / (1 + U2 ^ 2) * (Wq - A2) -
        (cc.c0.toReal + cc.c2.toReal + 3 * cc.c4.toReal + 15 * cc.c6.toReal) := by
    intro ρ hρ0 hρm
    have hx0 : 0 ≤ ρ / m := div_nonneg hρ0 hm0.le
    have hx1 : ρ / m ≤ 1 := (div_le_one hm0).2 hρm
    have hV := evalQ_nonneg_of_checkNN hV4 hx0 hx1
    simp only [objPoly, evalQ, QQ.toReal_neg, QQ.toReal_mul, QQ.toReal_ofInt,
      Int.cast_zero] at hV
    have hρ : m * (ρ / m) = ρ := by field_simp
    have e1 : (cellGam u1 u2 cc).toReal = (cellCh u1 u2 cc).toReal +
        (cellDb u1 u2 cc).toReal * m + (cellFh u1 u2 cc).toReal +
        max (cellEh u1 u2 cc).toReal 0 * m ^ 2 := by
      simp only [cellGam, QQ.toReal_add, QQ.toReal_mul, QQ.toReal_max, QQ.toReal_ofInt,
        Int.cast_zero]; ring
    have e2 : (cellEps u1 u2 cc).toReal = min (cellEh u1 u2 cc).toReal 0 := by
      simp only [cellEps, QQ.toReal_min, QQ.toReal_ofInt, Int.cast_zero]
    have e3 : (cellTarget w u2 a2 cc).toReal = U2 / (1 + U2 ^ 2) * (Wq - A2) -
        (cc.c0.toReal + cc.c2.toReal + 3 * cc.c4.toReal + 15 * cc.c6.toReal) := by
      simp only [cellTarget, cellA, QQ.toReal_add, QQ.toReal_sub, QQ.toReal_mul,
        QQ.toReal_div, QQ.toReal_ofInt, Int.cast_one, Int.cast_ofNat]; ring
    rw [e1, e2, e3] at hV
    rw [← hρ]
    linear_combination hV
  clear hV1 hV2 hV3 hV4
  refine cell_bound (U1 := U1) (U2 := U2) (A1 := A1) (A2 := A2) (bb := bb) (m := m) (W := Wq)
    cc.c0.toReal cc.c1.toReal cc.c2.toReal cc.c3.toReal cc.c4.toReal cc.c5.toReal cc.c6.toReal
    (cellBb u2 cc).toReal (cellCh u1 u2 cc).toReal (cellDb u1 u2 cc).toReal
    (cellEh u1 u2 cc).toReal (cellFh u1 u2 cc).toReal
    hU1 hu1 hu2 hw hA1 ha1 ha2 hA2 hAW hbb0 (by rw [sq, sq]; exact hbb) hm0
    (by rcases hm with hm | hm
        · exact Or.inl hm
        · exact Or.inr (by rw [sq, sq]; exact hm))
    hP0 hP1 hP2 ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ ?_ hV ha0 β h2 hβ1 hβa
  · simp only [cellBb, QQ.toReal_mul, QQ.toReal_abs, QQ.toReal_add, QQ.toReal_ofInt,
      toReal_k3Q, Int.cast_ofNat]
    exact le_rfl
  · simp only [cellCh, QQ.toReal_max, QQ.toReal_mul, QQ.toReal_sub, QQ.toReal_add,
      QQ.toReal_ofInt, toReal_wwQ, Int.cast_ofNat]
    exact le_max_left _ _
  · simp only [cellCh, QQ.toReal_max, QQ.toReal_mul, QQ.toReal_sub, QQ.toReal_add,
      QQ.toReal_ofInt, toReal_wwQ, Int.cast_ofNat]
    exact le_max_right _ _
  · simp only [cellDb, QQ.toReal_max, QQ.toReal_mul, QQ.toReal_sub, QQ.toReal_abs,
      QQ.toReal_ofInt, toReal_wwQ, toReal_k3Q, Int.cast_ofNat]
    exact le_rfl
  · simp only [cellEh, QQ.toReal_max, QQ.toReal_mul, toReal_f6Q, toReal_wwQ]
    exact le_max_left _ _
  · simp only [cellEh, QQ.toReal_max, QQ.toReal_mul, toReal_f6Q, toReal_wwQ]
    exact le_max_right _ _
  · simp only [cellFh, QQ.toReal_max, QQ.toReal_ofInt, Int.cast_zero]
    exact le_max_left _ _
  · simp only [cellFh, QQ.toReal_max, QQ.toReal_ofInt, QQ.toReal_mul, toReal_k3Q,
      Int.cast_ofNat]
    exact le_trans (le_of_eq (by ring)) (le_trans (le_max_left _ _) (le_max_right _ _))
  · simp only [cellFh, QQ.toReal_max, QQ.toReal_ofInt, QQ.toReal_mul, toReal_k3Q,
      Int.cast_ofNat]
    exact le_trans (le_of_eq (by ring)) (le_trans (le_max_right _ _) (le_max_right _ _))

/-! ### Trees of cells -/

/-- A binary subdivision of a rectangle: `splitU`/`splitA` split at the midpoint, `cutU x`/`cutA x`
at the given point `x`. -/
inductive CTree
  | leaf (c : CellCert)
  | splitU (l r : CTree)
  | splitA (l r : CTree)
  | cutU (x : QQ) (l r : CTree)
  | cutA (x : QQ) (l r : CTree)

def midQ (x y : QQ) : QQ := (x + y) * QQ.mk' 1 2

theorem toReal_midQ (x y : QQ) : (midQ x y).toReal = (x.toReal + y.toReal) / 2 := by
  simp [midQ, QQ.toReal_mk']; ring

/-- Checks every leaf of the tree; the target weight of a cell is `wf u₁`. -/
def checkTree (wf : QQ → QQ) : QQ → QQ → QQ → QQ → CTree → Bool
  | u1, u2, a1, a2, .leaf c => checkLeaf (wf u1) u1 u2 a1 a2 c
  | u1, u2, a1, a2, .splitU l r =>
    checkTree wf u1 (midQ u1 u2) a1 a2 l && checkTree wf (midQ u1 u2) u2 a1 a2 r
  | u1, u2, a1, a2, .splitA l r =>
    checkTree wf u1 u2 a1 (midQ a1 a2) l && checkTree wf u1 u2 (midQ a1 a2) a2 r
  | u1, u2, a1, a2, .cutU x l r => checkTree wf u1 x a1 a2 l && checkTree wf x u2 a1 a2 r
  | u1, u2, a1, a2, .cutA x l r => checkTree wf u1 u2 a1 x l && checkTree wf u1 u2 x a2 r

theorem checkTree_cutU_of {wf : QQ → QQ} {u1 u2 a1 a2 x : QQ} {l r : CTree}
    (hl : checkTree wf u1 x a1 a2 l = true) (hr : checkTree wf x u2 a1 a2 r = true) :
    checkTree wf u1 u2 a1 a2 (.cutU x l r) = true := by
  simp only [checkTree, hl, hr, Bool.and_self]

theorem checkTree_cutA_of {wf : QQ → QQ} {u1 u2 a1 a2 x : QQ} {l r : CTree}
    (hl : checkTree wf u1 u2 a1 x l = true) (hr : checkTree wf u1 u2 x a2 r = true) :
    checkTree wf u1 u2 a1 a2 (.cutA x l r) = true := by
  simp only [checkTree, hl, hr, Bool.and_self]

theorem checkTree_splitU_of {wf : QQ → QQ} {u1 u2 a1 a2 : QQ} {l r : CTree}
    (hl : checkTree wf u1 (midQ u1 u2) a1 a2 l = true)
    (hr : checkTree wf (midQ u1 u2) u2 a1 a2 r = true) :
    checkTree wf u1 u2 a1 a2 (.splitU l r) = true := by
  simp only [checkTree, hl, hr, Bool.and_self]

theorem checkTree_splitA_of {wf : QQ → QQ} {u1 u2 a1 a2 : QQ} {l r : CTree}
    (hl : checkTree wf u1 u2 a1 (midQ a1 a2) l = true)
    (hr : checkTree wf u1 u2 (midQ a1 a2) a2 r = true) :
    checkTree wf u1 u2 a1 a2 (.splitA l r) = true := by
  simp only [checkTree, hl, hr, Bool.and_self]

/-- `checkTree_sound`: on the rectangle, `E R_a(b M) ≤ τ(u)(W - a)` for every `W` that bounds the
weights `wf v` of the cells with `1 ≤ v ≤ u`. -/
theorem checkTree_sound (wf : QQ → QQ) {W : ℝ} (t : CTree) :
    ∀ {u1 u2 a1 a2 : QQ}, checkTree wf u1 u2 a1 a2 t = true →
    ∀ {u a : ℝ}, (∀ v : QQ, 1 ≤ v.toReal → v.toReal ≤ u → (wf v).toReal ≤ W) →
    u1.toReal ≤ u → u ≤ u2.toReal → a1.toReal ≤ a → a ≤ a2.toReal → 0 < a →
    ∀ {n : ℕ} (β : Fin n → ℝ), psum β 2 = 1 → (∀ i, |β i| ≤ 1) →
    (∀ i, |β i| ≤ a / √(1 - a ^ 2)) →
    expect (qOf u) (fun x => Ra u a (√(1 - a ^ 2) * lin (qOf u) β x)) ≤
      tau (qOf u) * (W - a) := by
  induction t with
  | leaf c =>
    intro u1 u2 a1 a2 h u a hW hu1 hu2 ha1 ha2 ha0 n β h2 hβ1 hβa
    exact checkLeaf_sound h (fun h1 => hW u1 h1 hu1) hu1 hu2 ha1 ha2 ha0 β h2 hβ1 hβa
  | splitU l r ihl ihr =>
    intro u1 u2 a1 a2 h u a hW hu1 hu2 ha1 ha2 ha0 n β h2 hβ1 hβa
    simp only [checkTree, Bool.and_eq_true] at h
    rcases le_total u (midQ u1 u2).toReal with hu | hu
    · exact ihl h.1 hW hu1 hu ha1 ha2 ha0 β h2 hβ1 hβa
    · exact ihr h.2 hW hu hu2 ha1 ha2 ha0 β h2 hβ1 hβa
  | splitA l r ihl ihr =>
    intro u1 u2 a1 a2 h u a hW hu1 hu2 ha1 ha2 ha0 n β h2 hβ1 hβa
    simp only [checkTree, Bool.and_eq_true] at h
    rcases le_total a (midQ a1 a2).toReal with ha | ha
    · exact ihl h.1 hW hu1 hu2 ha1 ha ha0 β h2 hβ1 hβa
    · exact ihr h.2 hW hu1 hu2 ha ha2 ha0 β h2 hβ1 hβa
  | cutU x l r ihl ihr =>
    intro u1 u2 a1 a2 h u a hW hu1 hu2 ha1 ha2 ha0 n β h2 hβ1 hβa
    simp only [checkTree, Bool.and_eq_true] at h
    rcases le_total u x.toReal with hu | hu
    · exact ihl h.1 hW hu1 hu ha1 ha2 ha0 β h2 hβ1 hβa
    · exact ihr h.2 hW hu hu2 ha1 ha2 ha0 β h2 hβ1 hβa
  | cutA x l r ihl ihr =>
    intro u1 u2 a1 a2 h u a hW hu1 hu2 ha1 ha2 ha0 n β h2 hβ1 hβa
    simp only [checkTree, Bool.and_eq_true] at h
    rcases le_total a x.toReal with ha | ha
    · exact ihl h.1 hW hu1 hu2 ha1 ha ha0 β h2 hβ1 hβa
    · exact ihr h.2 hW hu1 hu2 ha ha2 ha0 β h2 hβ1 hβa

/-! ### Target weights -/

/-- `k = 1`: the weight is `1`. -/
def wK1 (_ : QQ) : QQ := QQ.ofInt 1

/-- `S₂ = ⌊√2⌋₁₅`. -/
def S2Q : QQ := QQ.mk' 1414213562373095 1000000000000000

/-- `k = 2`: the weight is `S₂ u₁²/(1+u₁²)`. -/
def wK2 (u1 : QQ) : QQ := S2Q * (u1 * u1 / (QQ.ofInt 1 + u1 * u1))

theorem wK1_le (v : QQ) : (wK1 v).toReal ≤ 1 := by simp [wK1]

theorem S2Q_le : S2Q.toReal ≤ √2 := by
  rw [S2Q, QQ.toReal_mk' _ _ (by norm_num)]
  rw [Real.le_sqrt (by norm_num) (by norm_num)]
  norm_num

/-- For `1 ≤ v ≤ u`: `S₂ v²/(1+v²) ≤ √2 (1 - q(u))`. -/
theorem wK2_le {v : QQ} {u : ℝ} (hv : 1 ≤ v.toReal) (hvu : v.toReal ≤ u) :
    (wK2 v).toReal ≤ √2 * (1 - qOf u) := by
  rw [one_sub_qOf]
  simp only [wK2, QQ.toReal_mul, QQ.toReal_div, QQ.toReal_add, QQ.toReal_ofInt, Int.cast_one]
  have h1 := sqfrac_mono (by linarith) hvu
  have h2 : 0 ≤ v.toReal * v.toReal / (1 + v.toReal * v.toReal) := by positivity
  rw [← sq] at h2 ⊢
  exact mul_le_mul S2Q_le h1 h2 (Real.sqrt_nonneg _)

end ReverseKhinchin
