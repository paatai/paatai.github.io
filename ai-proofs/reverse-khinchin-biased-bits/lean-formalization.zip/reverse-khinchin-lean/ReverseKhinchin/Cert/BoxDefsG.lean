import ReverseKhinchin.Cert.BoxDefs

/-!
# The two-coordinate box checker with a general target

`checkBTreeG tg AS` is the checker `checkBTree` of `Cert/BoxDefs.lean` (Theorem 6.1) with the
target `S₂ min(T̃(u₁), T̃(u₂))` replaced by `tg u₁ u₂` and the threshold `A_S = 9/20` of the
one-coordinate route replaced by `AS`. It is used for the regimes `k ≥ 3`.
`checkBTree_eq : checkBTree s = checkBTreeG tgtQ ASQ s`, so the data of Theorem 6.1 (checked with
`checkBTree`) need not be checked again.
-/

namespace ReverseKhinchin

/-- Test (A) with target `T`. -/
def ncTestAG (T : QQ) (s : Bool) (u1 u2 t1 t2 r1 r2 mb : QQ) : Bool :=
  let ys := yIv s u1 u2 t1 t2
  allPosLo ys &&
    QQ.blt (C27 * E4Q u2 mb * (QQ.ofInt 1 - r1 * r1) * (QQ.ofInt 1 + r2) / cube r1 *
      sumInvCube (pIv u1 u2) ys) T

/-- Test (B) with target `T`. -/
def ncTestBG (T : QQ) (s : Bool) (u1 u2 t1 t2 r1 r2 mb bh : QQ) : Bool :=
  let margin := T - (tauIv u1 u2).hi * sumAbsHi (gIv s u1 u2 t1 t2)
  QQ.blt (QQ.ofInt 0) margin &&
    QQ.blt (sumTail bh (QQ.ofInt 1 - r1 * r1) (E4Q u2 mb) r1 (pIv u1 u2) (yIv s u1 u2 t1 t2))
      (T * (QQ.ofInt 1 - r2) + r1 * margin)

def checkLPG (T : QQ) (s : Bool) (u1 u2 t1 t2 r1 r2 : QQ) (d : LPCert) : Bool :=
  boxOK u1 t1 t2 r1 r2 && bOK r1 r2 d.bl d.bh && mbOK t2 r2 d.bl d.mb &&
    domOK ((envTerms s u1 u2 t1 t2 r1 r2 d.bl d.bh).map roundT) d.c &&
    objOK u1 u2 T (d.c.cell d.mb)

def checkNCG (T : QQ) (s : Bool) (u1 u2 t1 t2 r1 r2 : QQ) (d : NCCert) : Bool :=
  boxOK u1 t1 t2 r1 r2 && bOK r1 r2 d.bl d.bh && mbOK t2 r2 d.bl d.mb &&
    QQ.blt (QQ.ofInt 0) r1 &&
    (if d.testA then ncTestAG T s u1 u2 t1 t2 r1 r2 d.mb
      else ncTestBG T s u1 u2 t1 t2 r1 r2 d.mb d.bh)

def checkMSG (T : QQ) (s : Bool) (u1 u2 t1 t2 r1 r2 : QQ) (d : MSCert) : Bool :=
  let R := (envTerms s u1 u2 t1 t2 r1 r2 d.bl d.bh).map roundT
  boxOK u1 t1 t2 r1 r2 && bOK r1 r2 d.bl d.bh && mbOK t2 r2 d.bl d.mb &&
    QQ.blt (QQ.ofInt 0) d.bl &&
    domOK R d.c && objOK u1 u2 T (d.c.cell (QQ.min d.mb d.mcut)) &&
    phiOK d.mcut d.p3max && domOK R d.c2 && objOK3 u1 u2 T d.p3max (d.c2.cell d.mb) &&
    coverOK (QQ.min (QQ.ofInt 1) d.mb) d.mcut d.pieces &&
    d.pieces.all (pieceOK s u1 u2 t1 t2 r1 r2 d.bl d.bh (E4Q u2 (QQ.ofInt 1)) T)

/-- `checkBTree` with the target `tg u₁ u₂` on each box and the threshold `AS`. -/
def checkBTreeG (tg : QQ → QQ → QQ) (AS : QQ) (s : Bool) :
    QQ → QQ → QQ → QQ → QQ → QQ → BTree → Bool
  | u1, u2, t1, t2, r1, r2, .lp d => checkLPG (tg u1 u2) s u1 u2 t1 t2 r1 r2 d
  | u1, u2, t1, t2, r1, r2, .nc d => checkNCG (tg u1 u2) s u1 u2 t1 t2 r1 r2 d
  | u1, u2, t1, t2, r1, r2, .ms d => checkMSG (tg u1 u2) s u1 u2 t1 t2 r1 r2 d
  | _, _, t1, t2, r1, r2, .small =>
    QQ.ble (QQ.ofInt 0) t1 && QQ.ble t2 (QQ.ofInt 1) && QQ.ble (QQ.ofInt 0) r1 &&
      QQ.ble (r2 * cQ t1) AS
  | u1, u2, t1, t2, r1, r2, .cutU x l r =>
    checkBTreeG tg AS s u1 x t1 t2 r1 r2 l && checkBTreeG tg AS s x u2 t1 t2 r1 r2 r
  | u1, u2, t1, t2, r1, r2, .cutT x l r =>
    checkBTreeG tg AS s u1 u2 t1 x r1 r2 l && checkBTreeG tg AS s u1 u2 x t2 r1 r2 r
  | u1, u2, t1, t2, r1, r2, .cutR x l r =>
    checkBTreeG tg AS s u1 u2 t1 t2 r1 x l && checkBTreeG tg AS s u1 u2 t1 t2 x r2 r

section
variable {tg : QQ → QQ → QQ} {AS : QQ} {s : Bool} {u1 u2 t1 t2 r1 r2 x : QQ} {l r : BTree}

theorem checkBTreeG_cutU_of (hl : checkBTreeG tg AS s u1 x t1 t2 r1 r2 l = true)
    (hr : checkBTreeG tg AS s x u2 t1 t2 r1 r2 r = true) :
    checkBTreeG tg AS s u1 u2 t1 t2 r1 r2 (.cutU x l r) = true := by
  simp only [checkBTreeG, hl, hr, Bool.and_self]

theorem checkBTreeG_cutT_of (hl : checkBTreeG tg AS s u1 u2 t1 x r1 r2 l = true)
    (hr : checkBTreeG tg AS s u1 u2 x t2 r1 r2 r = true) :
    checkBTreeG tg AS s u1 u2 t1 t2 r1 r2 (.cutT x l r) = true := by
  simp only [checkBTreeG, hl, hr, Bool.and_self]

theorem checkBTreeG_cutR_of (hl : checkBTreeG tg AS s u1 u2 t1 t2 r1 x l = true)
    (hr : checkBTreeG tg AS s u1 u2 t1 t2 x r2 r = true) :
    checkBTreeG tg AS s u1 u2 t1 t2 r1 r2 (.cutR x l r) = true := by
  simp only [checkBTreeG, hl, hr, Bool.and_self]

end

/-- The checker of Theorem 6.1 is the general checker with the target `tgtQ` and `A_S = 9/20`. -/
theorem checkBTree_eq (s : Bool) : ∀ (T : BTree) (u1 u2 t1 t2 r1 r2 : QQ),
    checkBTree s u1 u2 t1 t2 r1 r2 T = checkBTreeG tgtQ ASQ s u1 u2 t1 t2 r1 r2 T
  | .lp _, _, _, _, _, _, _ => rfl
  | .nc _, _, _, _, _, _, _ => rfl
  | .ms _, _, _, _, _, _, _ => rfl
  | .small, _, _, _, _, _, _ => rfl
  | .cutU _ l r, _, _, _, _, _, _ => by
    simp only [checkBTree, checkBTreeG, checkBTree_eq s l, checkBTree_eq s r]
  | .cutT _ l r, _, _, _, _, _, _ => by
    simp only [checkBTree, checkBTreeG, checkBTree_eq s l, checkBTree_eq s r]
  | .cutR _ l r, _, _, _, _, _, _ => by
    simp only [checkBTree, checkBTreeG, checkBTree_eq s l, checkBTree_eq s r]

end ReverseKhinchin
