import ReverseKhinchin.Cert.Obj10
import ReverseKhinchin.Cert.K3W

/-!
# Ten-moment cells (Definition 4.13 with `D = 10`), computable part

A `Cell10` stores the bound `b̄ ≥ √(1-a₁²)`, the coefficient bound `m̄` and the (at most eleven)
coefficients of `P`. `checkLeaf10` certifies (V1)–(V3) with the Bernstein checker on `ℝ` and
(V4) with the ten-moment objective bound `obj10OK` (Definition 4.11) and the target
`Θ₁ = τ(u₂)(w - a₂)`. A `GTree` is a guillotine tree of cells (midpoint splits and cuts), so the
cells cover the rectangle by construction. The soundness proofs are in
`ReverseKhinchin/TenCell.lean`.
-/

namespace ReverseKhinchin

open ReverseKhinchin.Poly

/-- The stored data of one ten-moment cell. -/
structure Cell10 where
  bb : QQ
  mb : QQ
  c : List QQ

/-- `P - (l₀ + l₁ y)`. -/
def subLin (c : List QQ) (l0 l1 : QQ) : List QQ := paddQ c [-l0, -l1]

/-- The checker for one cell `[u₁,u₂] × [a₁,a₂]` with target weight `w`. -/
def checkLeaf10 (w u1 u2 a1 a2 : QQ) (cc : Cell10) : Bool :=
  QQ.ble (QQ.ofInt 1) u1 && QQ.ble u1 u2 && QQ.ble (QQ.ofInt 0) a1 && QQ.ble a1 a2 &&
  QQ.blt a2 (QQ.ofInt 1) && QQ.ble a2 w &&
  QQ.ble (QQ.ofInt 0) cc.bb && QQ.ble (QQ.ofInt 1 - a1 * a1) (cc.bb * cc.bb) &&
  QQ.blt (QQ.ofInt 0) cc.mb &&
  (QQ.ble (QQ.ofInt 1) cc.mb || QQ.ble (a2 * a2) (cc.mb * cc.mb * (QQ.ofInt 1 - a2 * a2))) &&
  checkNNR cellFuel (clearDen cc.c).1 &&
  checkNNR cellFuel (clearDen (subLin cc.c (l1c0 u2 a1) (l1c1 u2 cc.bb))).1 &&
  checkNNR cellFuel (clearDen (subLin cc.c (l2c0 u1 a1) (l2c1 u1 cc.bb))).1 &&
  obj10OK (kapAll u1 u2) cc.mb none (u2 / (QQ.ofInt 1 + u2 * u2) * (w - a2)) cc.c

/-- A guillotine tree of cells: `splitU`/`splitA` split at the midpoint, `cutU x`/`cutA x` at the
given point `x`. -/
inductive GTree (α : Type)
  | leaf (c : α)
  | splitU (l r : GTree α)
  | splitA (l r : GTree α)
  | cutU (x : QQ) (l r : GTree α)
  | cutA (x : QQ) (l r : GTree α)

/-- Checks every leaf of the tree with `ok u₁ u₂ a₁ a₂`. -/
def checkGTree {α : Type} (ok : QQ → QQ → QQ → QQ → α → Bool) :
    QQ → QQ → QQ → QQ → GTree α → Bool
  | u1, u2, a1, a2, .leaf c => ok u1 u2 a1 a2 c
  | u1, u2, a1, a2, .splitU l r =>
    checkGTree ok u1 (midQ u1 u2) a1 a2 l && checkGTree ok (midQ u1 u2) u2 a1 a2 r
  | u1, u2, a1, a2, .splitA l r =>
    checkGTree ok u1 u2 a1 (midQ a1 a2) l && checkGTree ok u1 u2 (midQ a1 a2) a2 r
  | u1, u2, a1, a2, .cutU x l r => checkGTree ok u1 x a1 a2 l && checkGTree ok x u2 a1 a2 r
  | u1, u2, a1, a2, .cutA x l r => checkGTree ok u1 u2 a1 x l && checkGTree ok u1 u2 x a2 r

theorem checkGTree_cutU_of {α : Type} {ok : QQ → QQ → QQ → QQ → α → Bool} {u1 u2 a1 a2 x : QQ}
    {l r : GTree α} (hl : checkGTree ok u1 x a1 a2 l = true)
    (hr : checkGTree ok x u2 a1 a2 r = true) : checkGTree ok u1 u2 a1 a2 (.cutU x l r) = true := by
  simp only [checkGTree, hl, hr, Bool.and_self]

theorem checkGTree_cutA_of {α : Type} {ok : QQ → QQ → QQ → QQ → α → Bool} {u1 u2 a1 a2 x : QQ}
    {l r : GTree α} (hl : checkGTree ok u1 u2 a1 x l = true)
    (hr : checkGTree ok u1 u2 x a2 r = true) : checkGTree ok u1 u2 a1 a2 (.cutA x l r) = true := by
  simp only [checkGTree, hl, hr, Bool.and_self]

theorem checkGTree_splitU_of {α : Type} {ok : QQ → QQ → QQ → QQ → α → Bool} {u1 u2 a1 a2 : QQ}
    {l r : GTree α} (hl : checkGTree ok u1 (midQ u1 u2) a1 a2 l = true)
    (hr : checkGTree ok (midQ u1 u2) u2 a1 a2 r = true) :
    checkGTree ok u1 u2 a1 a2 (.splitU l r) = true := by
  simp only [checkGTree, hl, hr, Bool.and_self]

theorem checkGTree_splitA_of {α : Type} {ok : QQ → QQ → QQ → QQ → α → Bool} {u1 u2 a1 a2 : QQ}
    {l r : GTree α} (hl : checkGTree ok u1 u2 a1 (midQ a1 a2) l = true)
    (hr : checkGTree ok u1 u2 (midQ a1 a2) a2 r = true) :
    checkGTree ok u1 u2 a1 a2 (.splitA l r) = true := by
  simp only [checkGTree, hl, hr, Bool.and_self]

/-- The ten-moment cells of Theorem 8.1 (`k = 3`, lower part) use the weight `wK3` of
Theorem 7.1. -/
def ok10K3 (u1 u2 a1 a2 : QQ) (c : Cell10) : Bool := checkLeaf10 (wK3 u1) u1 u2 a1 a2 c

end ReverseKhinchin
