import ReverseKhinchin.K2.Upper

/-!
# The two-coordinate route for a general target

The reduction used in Theorems 6.1 and 7.1: a reduced vector `(a₁, s a₂, γ)` with `a₁ > A` is
mapped to the point `(u, t, r)` with `r = √(a₁² + a₂²)` and the half-angle `t = a₂/(r + a₁)`, so
that `(a₁, a₂) = r (c(t), d(t))` and `t ≤ 20711/50000`. For `r = 1` the residual vanishes and the
two-coordinate bound `F₂(c, s d, 0) ≤ T √(c² + d²)` applies; for `r < 1` a point claim
`PointClaimT T s u t r` (from a kernel-checked box tree) gives the bound.
-/

namespace ReverseKhinchin

theorem two_coord_route {T A : ℝ} {s' : Bool} {u : ℝ}
    (hF2 : ∀ c d : ℝ, 0 ≤ c → 0 ≤ d → F2 (qOf u) c (sR s' * d) 0 ≤ T * √(c ^ 2 + d ^ 2))
    (hclaim : ∀ t r : ℝ, 0 ≤ t → t ≤ 20711 / 50000 → A ≤ r → r < 1 → A < r * cR t →
      PointClaimT T s' u t r)
    {a1 a2 : ℝ} (ha1 : A < a1) (hA : 0 ≤ A) (ha2 : 0 ≤ a2) (ha21 : a2 ≤ a1) {n : ℕ}
    (γ : Fin n → ℝ) (h2 : a1 ^ 2 + a2 ^ 2 + psum γ 2 = 1) (hγ : ∀ i, |γ i| ≤ a2) :
    expect (qOf u) (fun x => F2 (qOf u) a1 (sR s' * a2) (lin (qOf u) γ x)) ≤ T := by
  have ha1' : 0 < a1 := by linarith
  have hpsum0 := psum_two_nonneg γ
  obtain ⟨r, hr⟩ : ∃ r, r = √(a1 ^ 2 + a2 ^ 2) := ⟨_, rfl⟩
  have hr2 : r ^ 2 = a1 ^ 2 + a2 ^ 2 := by rw [hr]; exact Real.sq_sqrt (by positivity)
  have hr0 : 0 ≤ r := by rw [hr]; exact Real.sqrt_nonneg _
  have hra1 : a1 ≤ r := by
    rw [hr]; exact (le_abs_self a1).trans (Real.abs_le_sqrt (by nlinarith))
  have hr1 : r ≤ 1 := by nlinarith
  rcases eq_or_lt_of_le hr1 with hr1 | hr1
  · -- `r = 1`: the residual vanishes
    have hγ0 : psum γ 2 = 0 := by nlinarith
    have hγi : ∀ i, γ i = 0 := fun i => by
      have : γ i ^ 2 ≤ psum γ 2 := Finset.single_le_sum (f := fun j => γ j ^ 2)
        (fun j _ => sq_nonneg _) (Finset.mem_univ i)
      exact pow_eq_zero_iff (n := 2) (by norm_num) |>.1 (le_antisymm (this.trans hγ0.le)
        (sq_nonneg _))
    have hlin : ∀ x, lin (qOf u) γ x = 0 := fun x => by unfold lin; simp [hγi]
    simp only [hlin]
    rw [expect_const]
    have := hF2 a1 a2 ha1'.le ha2
    rwa [← hr, hr1, mul_one] at this
  · -- `r < 1`: the point `(u, t, r)`
    have hra : 0 < r + a1 := by linarith
    have hra' : r + a1 ≠ 0 := hra.ne'
    obtain ⟨t, ht⟩ : ∃ t, t = a2 / (r + a1) := ⟨_, rfl⟩
    have e : t * (r + a1) = a2 := by rw [ht]; field_simp
    have h1t : (1 + t ^ 2) ≠ 0 := by positivity
    have key : r * (1 - t ^ 2) - a1 * (1 + t ^ 2) = 0 := by
      have : (r + a1) * (r * (1 - t ^ 2) - a1 * (1 + t ^ 2)) = 0 := by
        linear_combination hr2 - (a2 + t * (r + a1)) * e
      exact (mul_eq_zero.1 this).resolve_left hra'
    have hcR : r * cR t = a1 := by
      unfold cR; rw [mul_div_assoc', div_eq_iff h1t]; linarith
    have hdR : r * dR t = a2 := by
      unfold dR; rw [mul_div_assoc', div_eq_iff h1t]
      linear_combination t * key + (1 + t ^ 2) * e
    have ht0 : 0 ≤ t := by rw [ht]; exact div_nonneg ha2 hra.le
    have ht1 : t ≤ 20711 / 50000 := by rw [ht]; exact halfAngle_le ha2 ha21 hr0 hr2
    have hclaim' : PointClaimT T s' u t r :=
      hclaim t r ht0 ht1 (by linarith) hr1 (by rw [hcR]; exact ha1)
    -- the normalised residual `β = γ / √(1 - r²)`
    have hb2 : 1 - r ^ 2 = psum γ 2 := by linarith
    have hbpos : 0 < √(1 - r ^ 2) := Real.sqrt_pos.2 (by nlinarith)
    have hbne : √(1 - r ^ 2) ≠ 0 := hbpos.ne'
    have hbsq : √(1 - r ^ 2) ^ 2 = psum γ 2 := by rw [Real.sq_sqrt (by nlinarith), hb2]
    have hβ2 : psum (fun i => γ i / √(1 - r ^ 2)) 2 = 1 := by
      unfold psum at hbsq ⊢
      simp only [div_pow]
      rw [← Finset.sum_div, ← hbsq]
      exact div_self (pow_pos hbpos 2).ne'
    have hlin : ∀ x, lin (qOf u) γ x =
        √(1 - r ^ 2) * lin (qOf u) (fun i => γ i / √(1 - r ^ 2)) x := fun x => by
      unfold lin
      rw [Finset.mul_sum]
      refine Finset.sum_congr rfl fun i _ => ?_
      field_simp
    have hβb : ∀ i, √(1 - r ^ 2) * |γ i / √(1 - r ^ 2)| ≤ r * dR t := fun i => by
      rw [hdR, abs_div, abs_of_pos hbpos, mul_div_assoc', mul_div_cancel_left₀ _ hbne]
      exact hγ i
    have := hclaim' (fun i => γ i / √(1 - r ^ 2)) hβ2 hβb
    rw [hcR, hdR] at this
    simp only [hlin]
    exact this

end ReverseKhinchin
