"""Exact checks of every numerical constant used by the chain (RQ-REF3).

All decisions are exact comparisons of rationals; irrational quantities are enclosed
by ref/rig.py.  Run: python3 ref/constants.py
"""

import sys
from gmpy2 import mpq
import rig
from rig import q, sqrt_b, log_b, exp_b, iadd, isub, imul, iscale, idiv

P = 200
ok_all = True


def check(name, cond, detail=""):
    global ok_all
    ok_all &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name + (("  [" + detail + "]") if detail else ""))


def f(iv):
    return "[%.15f, %.15f]" % (float(iv[0]), float(iv[1]))


theta = mpq(17, 20)
A = mpq(77, 50)
tau = theta

# ---------------------------------------------------------------- C_5 and the target 171/200
ln54 = log_b(mpq(5, 4), P)
two_ln54 = iscale(2, ln54)
sq = (sqrt_b(two_ln54[0], P)[0], sqrt_b(two_ln54[1], P)[1])
C5 = iscale(mpq(32, 25), sq)  # g(2 ln 5/4) = 2 sqrt(2 ln 5/4) (4/5)^2
print("C5 =", f(C5))
check("C5 matches 0.8551004554...", C5[0] > mpq(8551004554, 10 ** 10) and C5[1] < mpq(8551004555, 10 ** 10), f(C5))
check("171/200 < C5", mpq(171, 200) < C5[0], "margin %.3e" % float(C5[0] - mpq(171, 200)))
# equivalent form: ln(5/4) > (171/256)^2/2
check("ln(5/4) > (171/256)^2/2 (same fact)", ln54[0] > (mpq(171, 256) ** 2) / 2, "%.10f > %.10f" % (float(ln54[0]), float(mpq(171, 256) ** 2 / 2)))


# ---------------------------------------------------------------- C_K = min of C(q) on [q_{K+1}, q_K]
def g_iv(x):
    """g(x) = 2 sqrt(x) e^{-x} for an enclosure x of a positive number."""
    s = (sqrt_b(x[0], P)[0], sqrt_b(x[1], P)[1])
    e = (exp_b(-x[1], P)[0], exp_b(-x[0], P)[1])
    return iscale(2, imul(s, e))


def CK(K):
    # s_K = (1/2) ln(K/(K-1)) is the tie point g((K-1)s) = g(Ks); C_K = g((K-1) s_K)
    sK = iscale(mpq(1, 2), log_b(mpq(K, K - 1), P))
    return g_iv(iscale(K - 1, sK)), g_iv(iscale(K, sK)), sK


vals = {}
for K in range(2, 41):
    a, b, sK = CK(K)
    vals[K] = a
    # both expressions are the same number; their enclosures must overlap
    check("C_%d: g((K-1)s_K) and g(K s_K) agree" % K, a[0] <= b[1] and b[0] <= a[1], f(a)) if K in (4, 5, 6) else None
print("C_4 =", f(vals[4]), " C_5 =", f(vals[5]), " C_6 =", f(vals[6]))
check("C_5 from the tie formula equals 1.28 sqrt(2 ln 1.25)", vals[5][0] <= C5[1] and C5[0] <= vals[5][1])
check("C_K strictly increasing for 4 <= K <= 40 (enclosures disjoint)",
      all(vals[K][1] < vals[K + 1][0] for K in range(4, 40)))
# Analytic part (REFEREE.md): x_K = ((K-1)/2) ln(K/(K-1)) = (n/2) ln(1+1/n), n = K-1, increases to 1/2,
# and g increases on (0, 1/2]; so C_K increases for every K, and inf_{K>=5} C_K = C_5.
# Check x_K < 1/2 numerically for the listed K as a sanity test of that argument.
check("x_K = ((K-1)/2) ln(K/(K-1)) < 1/2 for K <= 40",
      all(iscale(mpq(K - 1, 2), log_b(mpq(K, K - 1), P))[1] < mpq(1, 2) for K in range(2, 41)))
check("sqrt(2/e) > C_5 (limit q -> 0)", g_iv((mpq(1, 2), mpq(1, 2)))[0] > C5[1])

# ---------------------------------------------------------------- q_5, q_6 and the localisation constant
s5 = sqrt_b(5, P)
q5 = (1 - 2 / s5[0], 1 - 2 / s5[1])  # 1 - 2/sqrt5
q5 = (min(q5), max(q5))
print("q5 =", f(q5))
check("q5 = 1 - 2/sqrt5 = 0.105572809...", q5[0] > mpq(105572809, 10 ** 9) and q5[1] < mpq(105572810, 10 ** 9))
s30 = sqrt_b(30, P)
q6 = (1 - s30[1] / 6, 1 - s30[0] / 6)  # 1 - sqrt(5/6)
check("q6 = 1 - sqrt(5/6) < q5", q6[1] < q5[0], f(q6))
# tie points: e^{-s_K} = sqrt((K-1)/K), so q_K = 1 - sqrt((K-1)/K): K = 5 gives q5
check("q_5 = 1 - e^{-s_5} with s_5 = (1/2) ln(5/4)", True, "e^{-s_5} = sqrt(4/5) = 2/sqrt5 exactly")
# A'(q) = sqrt(2q/s)/(1-q), s = ln(1/(1-q)); at q5: A'^2 = 2 q5 / (s (1 - q5)^2) = 5 q5 / ln(5/4)
Ap2 = (5 * q5[0] / ln54[1], 5 * q5[1] / ln54[0])
Ap = (sqrt_b(Ap2[0], P)[0], sqrt_b(Ap2[1], P)[1])
print("A'(q5) =", f(Ap))
check("A'(q5) < 1.54 = 77/50", Ap[1] < A, f(Ap))
check("A'(q5) = 1.53804...", Ap[0] > mpq(153804, 10 ** 5) and Ap[1] < mpq(153806, 10 ** 5))
check("sqrt(2) (limit of A' as q -> 0) < 77/50", sqrt_b(2, P)[1] < A)
# A' increasing: d/dq log A'^2 = (s(1+q) - q)/(q s (1-q)) > 0 since s = ln(1/(1-q)) >= q > q/(1+q).  Spot check:
qs = [mpq(k, 1000) for k in range(1, 106)]


def Aprime2(qq):
    s = log_b(1 / (1 - qq), P)
    return (2 * qq / (s[1] * (1 - qq) ** 2), 2 * qq / (s[0] * (1 - qq) ** 2))


ap = [Aprime2(x) for x in qs]
check("A'(q) increasing on the grid q = k/1000, k <= 105 (spot check of the analytic proof)",
      all(ap[i][1] < ap[i + 1][0] for i in range(len(ap) - 1)))

# ---------------------------------------------------------------- RQ-D heavy constants (Lemmas 19-20)
check("2 tau = 1.7 > A = 1.54 (Lemma 19, dQ/da >= 0)", 2 * tau > A)
check("0.8/tau^2 < 28/25 (Lemma 20(i))", mpq(4, 5) / tau ** 2 < mpq(28, 25), "%.6f" % float(mpq(4, 5) / tau ** 2))
check("0.8/A^2 < 17/50 (Lemma 20(i))", mpq(4, 5) / A ** 2 < mpq(17, 50), "%.6f" % float(mpq(4, 5) / A ** 2))

# ---------------------------------------------------------------- RQ-B light constants (Lemmas D, E)
r = mpq(6, 5)
v = (1 + r) ** 2 / (4 * r)  # (a+b)^2/(4ab) with b = 6a/5
check("case 1: (a+b)^2/(4ab) = 121/120 and floor(20 * 121/120) = 20", v == mpq(121, 120) and (20 * v).__floor__() == 20)
v2 = (theta + A) ** 2 / (4 * theta * A) / 2
check("case 2: (theta+A)^2/(4 theta A) * (1/2) < 11/20, so i+j <= 10", v2 < mpq(11, 20), "%.6f" % float(v2))
check("case 3: m1 < A/4 + 3 theta/4 = 1.0225", A / 4 + 3 * theta / 4 == mpq(409, 400))
check("case 3: m2 < (A^2 + theta^2)/2 = 1.54705 < 31/20", (A * A + theta * theta) / 2 < mpq(31, 20), "%.6f" % float((A * A + theta * theta) / 2))
# localisation reaches q5: the theorem constants
check("theta = 17/20 = 0.85, A = 77/50 = 1.54", theta == mpq(85, 100) and A == mpq(154, 100))

print("ALL CONSTANT CHECKS PASSED" if ok_all else "SOME CONSTANT CHECK FAILED")
sys.exit(0 if ok_all else 1)
