"""Evidence only (not part of any proof): random tests of the ingredients verified by heavy_verify.py (RQ-REF3).

For random cells of random certified boxes, draw finitely supported W in W_B(C) and check, in exact arithmetic,
L_j <= kappa_j(W) <= U_j and E phi(Z_W) <= beta (E phi(Z_W) from the exact cumulants); and check
h_B(r) <= phi(r) + eps on a grid of r in [-3L, 3L] (h_B by Poisson enumeration in floats).
"""

import random
import sys

import numpy as np
from gmpy2 import mpq

import heavy_verify as H
from moments import moment_poly
from rig import q


def EZk(kap, k):
    tot = mpq(0)
    for mono, v in moment_poly(k).items():
        t = mpq(v)
        for b in mono:
            t *= kap[b]
        tot += t
    return tot


def hB_float(a1, b1, r):
    from math import exp, lgamma, log
    tot = np.zeros_like(r)
    for n in range(60):
        pn = exp(-a1 + (n * log(a1) if a1 > 0 else (0 if n == 0 else -1e300)) - lgamma(n + 1)) if (a1 > 0 or n == 0) else 0
        if pn < 1e-30:
            continue
        for m in range(60):
            pm = exp(-b1 + (m * log(b1) if b1 > 0 else (0 if m == 0 else -1e300)) - lgamma(m + 1)) if (b1 > 0 or m == 0) else 0
            if pm < 1e-30:
                continue
            c = 0.85 * (n - a1) + 1.54 * (m - b1)
            tot += pn * pm * np.abs(c + r)
    return tot


def main(seed=1, nbox=12, nw=300):
    rng = random.Random(seed)
    recs, _ = H.load_records()
    okb = [r for r in recs if r["status"] == "ok"]
    worst_gap = None
    nchecked = 0
    for rec in rng.sample(okb, nbox):
        a1, a2, b1, b2 = H.box_coords(rec["box"])
        mu = 1 - max(H.Qf(a2, b2), mpq(1, 2)) + H.Mf(a2, b2) - H.Mf(a1, b1)
        cap = (b2 - b1) * H.A ** 2
        R3 = (-H.A * mu, H.TAU * mu + (H.A - H.TAU) * cap)
        R4 = (mpq(0), H.A ** 2 * mu)
        for c in rec["certs"]:
            if c["status"] != "ok":
                continue
            l, i, j = c["cell"]
            w3 = (R3[1] - R3[0]) / 2 ** l
            w4 = (R4[1] - R4[0]) / 2 ** l
            cell = (R3[0] + i * w3, R3[0] + (i + 1) * w3, R4[0] + j * w4, R4[0] + (j + 1) * w4)
            coef = [q(x) for x in c["coef"]]
            Lr, Ur = H.ranges(cell, mu, cap, c["rmult"])
            beta = H.lagrangian(coef, mu, cap, cell, Lr, Ur, c["mult"])
            ok, eps, _ = H.majorant(coef, a1, b1, c["Lt"])
            hits = 0
            for _ in range(nw * 20):
                if hits >= nw:
                    break
                k = rng.randint(1, 4)
                wA = cap * mpq(rng.randint(0, 1000), 1000) if rng.random() < 0.5 else mpq(0)
                wA = min(wA, mu)
                xs = [mpq(rng.randint(-1540, 850), 1000) for _ in range(k)]
                ws = [mpq(rng.randint(1, 1000), 1) for _ in range(k)]
                s = sum(ws)
                ws = [(mu - wA) * w / s for w in ws]
                if wA > 0:
                    xs.append(H.A)
                    ws.append(wA)
                kap = {jj: sum(w * x ** (jj - 2) for w, x in zip(ws, xs)) for jj in range(2, 17)}
                if not (cell[0] <= kap[3] <= cell[1] and cell[2] <= kap[4] <= cell[3]):
                    continue
                hits += 1
                for jj in range(3, 17):
                    assert Lr[jj] <= kap[jj] <= Ur[jj], ("range", rec["box"], c["cell"], jj)
                Ephi = sum(coef[kk] * EZk(kap, kk) for kk in range(17))
                assert Ephi <= beta, ("beta", rec["box"], c["cell"])
                gap = beta - Ephi
                if worst_gap is None or gap < worst_gap:
                    worst_gap = gap
                nchecked += 1
            L = float(c["Lt"])
            r = np.linspace(-3 * L, 3 * L, 4001)
            hb = hB_float(float(a1), float(b1), r)
            ph = np.polyval([float(x) for x in coef][::-1], r)
            viol = float(np.max(hb - ph - float(eps)))
            assert viol <= 1e-9, ("majorant", rec["box"], c["cell"], viol)
    print("heavy sanity OK: %d random W checked, smallest beta - E phi = %.3e" % (nchecked, float(worst_gap)))


if __name__ == "__main__":
    main(*(int(x) for x in sys.argv[1:]))
