"""Semantic end-to-end test of the light far region (evidence only; RQ-REF3).

Random finitely supported probability measures K on [-A, A] with V+ < 1/2 and V- < 1/2 (rational atoms) are pushed
through the proof: Lemma D chooses the case and the reflection, Lemmas S1-S3 give the box, the rest measure
K' = K_R + t_a delta_a + t_b delta_b + g delta_0 (cases 1-2; K' = K in case 3), and Lemma E the root; the leaf is
found by descending the subdivision with the point (int x dK', int x^2 dK').  Checked exactly for every sample:
the root is one of the regenerated roots, g >= 0 and 0 <= t_p <= cap_p, every cap of the cell holds for K_R, a
containing child exists at every level, the leaf is not certified empty, L_j <= kappa_j(K') <= U_j for all j, and
E phi(Z_K') <= U (moments from the cumulants by the set-partition formula).  Uses light_verify for the cells and the
certificate check, so it tests the reading of Lemmas D, E and S1-S5, not the verifier's own algebra.

Usage: python3 light_semantic.py [--n 1500] [--seed 1] [--out FILE]
"""

import argparse
import random
import time
from fractions import Fraction

from gmpy2 import mpq

import light_verify as lv
from moments import moment_poly

A, TH, DELTA = lv.A, lv.TH, lv.DELTA


def _mq(x):
    if isinstance(x, str):
        f = Fraction(x)
        return mpq(f.numerator, f.denominator)
    return mpq(x)


def rq(rng, lo, hi, den=4000):
    lo, hi = _mq(lo), _mq(hi)
    return lo + (hi - lo) * mpq(rng.randint(1, den - 1), den)


def masses(rng, total, n):
    cuts = sorted(rng.randint(1, 999) for _ in range(n - 1))
    parts = [b - a for a, b in zip([0] + cuts, cuts + [1000])]
    return [total * mpq(p, 1000) for p in parts]


def add(K, x, m):
    if m > 0:
        K[x] = K.get(x, mpq(0)) + m


def mass_on(K, lo, hi):
    return sum((m for x, m in K.items() if lo <= x <= hi), mpq(0))


def gen(rng, scen):
    """A random K (dict atom -> mass) with V+ < 1/2, V- < 1/2, or None."""
    K = {}
    if scen == "near":
        k = rng.choice([k for k, (a, b) in enumerate(lv.WFP) if a < TH])
        a, b = lv.WFP[k]
        m = rq(rng, "0.251", "0.98")
        npts = rng.randint(1, 3)
        for x, w in zip([rq(rng, a, b) for _ in range(npts)], masses(rng, m, npts)):
            add(K, x, w)
        rest = 1 - m
    elif scen == "chord":
        vp = rq(rng, "0.25", "0.4999")
        for w in masses(rng, vp, rng.randint(1, 3)):
            add(K, rq(rng, TH, A) if rng.random() < 0.8 else rng.choice([TH, A]), w)
        rest = 1 - vp
    else:
        rest = mpq(1)
    nr = {"near": rng.randint(1, 6), "chord": rng.randint(3, 10), "light": rng.randint(6, 16)}[scen]
    for w in masses(rng, rest, nr):
        u = rng.random()
        if scen == "chord":
            x = rq(rng, -A, TH) if u < 0.9 else mpq(0)
            if x >= TH:
                x = mpq(0)
        elif u < 0.1:
            x = mpq(0)
        else:
            x = rq(rng, -A, A)
        add(K, x, w)
    K = {x: m for x, m in K.items() if m > 0}
    assert sum(K.values(), mpq(0)) == 1 and all(-A <= x <= A for x in K)
    if mass_on(K, TH, A) >= mpq(1, 2) or mass_on(K, -A, -TH) >= mpq(1, 2):
        return None
    return K


def reflect(K):
    return {-x: m for x, m in K.items()}


def kappas(K, D):
    return {j: sum((m * x ** (j - 2) for x, m in K.items()), mpq(0)) for j in range(2, D + 1)}


def e_phi(phi, kap):
    tot = mpq(0)
    for n, c in enumerate(phi):
        if c == 0:
            continue
        for mono, v in moment_poly(n).items():
            t = mpq(v)
            for blk in mono:
                t *= kap[blk]
            tot += c * t
    return tot


def floor_q(x):
    return x.numerator // x.denominator


class Ctx:
    def __init__(self):
        self.data = {}
        self.cache = {}

    def case(self, c):
        if c not in self.data:
            certs, _ = lv.load(c)
            roots, use, kids, mism = lv.tree(c, certs)
            below = set()
            for p in use:
                parts = p.split("/")
                for n in range(1, len(parts)):
                    below.add("/".join(parts[:n]))
            self.data[c] = (roots, use, below)
        return self.data[c]

    def leafcheck(self, c, path, d, rec):
        if path not in self.cache:
            info = {}
            ok, U, msg = lv.verify_cert(lv.make_cell(d), rec["spec"]["D"], rec["cert"], info)
            self.cache[path] = (ok, U, msg, info, rec["spec"]["D"])
        return self.cache[path]


def run_one(ctx, K):
    near = [(lo, hi) for lo, hi in lv.WF if lv.is_near(lo, hi)]
    nm = [mass_on(K, lo, hi) for lo, hi in near]
    big = max(nm)
    if big > mpq(1, 4):
        lo, hi = near[nm.index(big)]
        if hi < 0:
            K = reflect(K)
            lo, hi = -hi, -lo
        case, (a, b) = "nsplit", (lo, hi)
        k = lv.WFP.index((a, b))
    else:
        vp, vm = mass_on(K, TH, A), mass_on(K, -A, -TH)
        if max(vp, vm) >= mpq(1, 4):
            if vm > vp:
                K = reflect(K)
            case, (a, b), k = "chord", (TH, A), None
        else:
            if sum((m * x for x, m in K.items()), mpq(0)) < 0:
                K = reflect(K)
            case = "light"
    roots, use, below = ctx.case(case)
    if case != "light":
        KW = {x: m for x, m in K.items() if a <= x <= b}
        KR = {x: m for x, m in K.items() if not a <= x <= b}
        pa = sum((m / x ** 2 * (b - x) / (b - a) for x, m in KW.items()), mpq(0))
        pb = sum((m / x ** 2 * (x - a) / (b - a) for x, m in KW.items()), mpq(0))
        i, j = floor_q(a * a * pa / DELTA), floor_q(b * b * pb / DELTA)
        path = "C/i%dj%d" % (i, j) if case == "chord" else "N/k%d/i%dj%d" % (k, i, j)
        if path not in roots:
            return case, "NOT A ROOT %s" % path
        d = roots[path]
        cell = lv.make_cell(d)
        ta, tb = a * a * (pa - d["Pa"]), b * b * (pb - d["Pb"])
        g = cell.mu - sum(KR.values(), mpq(0)) - ta - tb
        if g < 0 or not (0 <= ta <= a * a * d["da"]) or not (0 <= tb <= b * b * d["db"]):
            return case, "rest measure outside the class at %s" % path
        Kp = dict(KR)
        add(Kp, a, ta)
        add(Kp, b, tb)
        add(Kp, mpq(0), g)
        capped = KR
    else:
        m1 = sum((m * x for x, m in K.items()), mpq(0))
        m2 = sum((m * x * x for x, m in K.items()), mpq(0))
        s, t = floor_q(m1 / lv.W_LIGHT), floor_q(m2 / lv.W_LIGHT)
        path = "L/s%dt%d" % (s, t)
        if path not in roots:
            return case, "NOT A ROOT %s" % path
        d = roots[path]
        cell = lv.make_cell(d)
        Kp, capped = K, K
    for lo, hi, c in cell.caps:
        if mass_on(capped, lo, hi) > c:
            return case, "cap [%.4f, %.4f] <= %.4f violated at %s" % (lo, hi, c, path)
    m1 = sum((m * x for x, m in Kp.items()), mpq(0))
    m2 = sum((m * x * x for x, m in Kp.items()), mpq(0))
    while path not in use:
        ch = lv.children(path, d)
        nxt = [(p, dd) for p, dd in sorted(ch.items())
               if dd["cellq"][0] <= m1 <= dd["cellq"][1] and dd["cellq"][2] <= m2 <= dd["cellq"][3]]
        if not nxt:
            return case, "no child of %s contains (m1, m2)" % path
        nxt = [(p, dd) for p, dd in nxt if p in use or p in below] or nxt
        path, d = nxt[0]
    ok, U, msg, info, D = ctx.leafcheck(case, path, d, use[path][1])
    if not ok:
        return case, "leaf %s rejected: %s" % (path, msg)
    if U is None:
        return case, "EMPTY leaf %s contains a member" % path
    kap = kappas(Kp, D)
    if kap[2] != cell.mu:
        return case, "mass of K' is not mu"
    for jj, (L, Uj) in info["rng"].items():
        if not L <= kap[jj] <= Uj:
            return case, "kappa_%d outside the certified range at %s" % (jj, path)
    ep = e_phi(info["phi"], kap)
    if ep > U:
        return case, "E phi = %.6f > U = %.6f at %s" % (ep, U, path)
    return case, ("ok", float(U - ep), path)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=1500)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    rng = random.Random(args.seed)
    ctx = Ctx()
    stats, fails, slack, leaves = {}, [], {}, {}
    t0 = time.time()
    for scen in ("near", "chord", "light"):
        done = 0
        while done < args.n:
            K = gen(rng, scen)
            if K is None:
                continue
            case, res = run_one(ctx, K)
            done += 1
            if isinstance(res, tuple):
                stats[case] = stats.get(case, 0) + 1
                slack[case] = min(slack.get(case, 9.0), res[1])
                leaves.setdefault(case, set()).add(res[2])
            else:
                fails.append((case, res))
    lines = ["RQ-REF3 light_semantic.py (evidence); %d samples per scenario, seed %d, %.0f s" %
             (args.n, args.seed, time.time() - t0)]
    for c in ("nsplit", "chord", "light"):
        lines.append("  case %-6s: %5d samples passed, %4d distinct leaves, smallest U - E phi(Z_K') = %.3e" %
                     (c, stats.get(c, 0), len(leaves.get(c, ())), slack.get(c, float("nan"))))
    lines.append("  failures: %d" % len(fails))
    lines += ["    %s: %s" % f for f in fails[:20]]
    lines.append("RESULT: %s" % ("no violation" if not fails else "VIOLATIONS"))
    print("\n".join(lines))
    if args.out:
        with open(args.out, "w") as fh:
            fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
