"""Independent re-verification of RQ-D Theorem 16 (heavy far region), RQ-REF3.

Reads the certificate data outputs/plus_cert/certs_v1_r{0..4}.jsonl of RQ-D (numbers only; none of RQ-D's code is
used or imported) and re-checks, in exact rational arithmetic, every inequality that the proof of Theorem 16 needs:

  * the leaf boxes cover [0, 28/25] x [0, 17/50]           (recursive quadtree descent, not an area count);
  * empty leaves: Q(a1, b1) >= 4/5 or M(a2, b2) < 1/2;
  * for every other leaf B: mu_B, cap_B, R_B, and the cells cover R_B (same descent);
  * per cell, the ranges (a), the Farkas test (b), the Lagrangian bound beta of (c), the majorant test of Lemma 23
    (my own n_a, n_b, Poisson enclosures and tail bound), and beta + eps < C5.

Polynomial suprema are bounded by exact Bernstein subdivision (ref/bern.py), the moment expansion uses the
set-partition formula (ref/moments.py), and exp/sqrt/log are enclosed by ref/rig.py.  Floating point is used only to
choose a floor for the piecewise supremum (any floor is sound: it can only increase the bound).

Usage: python3 heavy_verify.py [--procs 8] [--shift S] [--limit N] [--controls]
"""

import os as _os
_ROOT = _os.path.abspath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", ".."))  # archive root
import argparse
import glob
import hashlib
import json
import os
import sys
import time
from multiprocessing import Pool

import numpy as np
from gmpy2 import mpq, mpz

from bern import peval, sup_upper, taylor_shift
from moments import expansion
from rig import exp_b, log_b, q, rdown, rup, sqrt_b

TAU = mpq(17, 20)
A = mpq(77, 50)
AROOT = mpq(28, 25)
BROOT = mpq(17, 50)
LEVEL0 = 4
MAXLEVEL = 30
TOL = mpq(1, 10 ** 15)
WEIGHT_BITS = 110
SMALL = mpq(1, 2 ** 60)

CERTDIR = _os.path.join(_ROOT, "RQ-D/outputs/plus_cert")


def c5_lower():
    ln = log_b(mpq(5, 4), 220)
    s = sqrt_b(2 * ln[0], 220)[0]
    return mpq(32, 25) * s


C5_LO = c5_lower()


def Mf(a, b):
    return a * TAU ** 2 + b * A ** 2


def Qf(a, b):
    if a + b == 0:
        return mpq(0)
    return (a * TAU + b * A) ** 2 / (a + b)


# ---------------------------------------------------------------- coverage by recursive descent
def covers(leafset, level, i, j, maxlevel=MAXLEVEL):
    """True iff the dyadic square (level, i, j) is a union of squares in leafset (recursively)."""
    stack = [(level, i, j)]
    used = set()
    while stack:
        l, x, y = stack.pop()
        if (l, x, y) in leafset:
            used.add((l, x, y))
            continue
        if l >= maxlevel:
            return False, used
        for dx in (0, 1):
            for dy in (0, 1):
                stack.append((l + 1, 2 * x + dx, 2 * y + dy))
    return True, used


def box_tiling(records):
    leaves = {}
    for r in records:
        la, ia, lb, ib = r["box"]
        if la != lb:
            return False, "non-square box %r" % (r["box"],)
        key = (la, ia, ib)
        if key in leaves:
            return False, "duplicate box %r" % (r["box"],)
        leaves[key] = r
    leafset = set(leaves)
    used = set()
    for i in range(2 ** LEVEL0):
        for j in range(2 ** LEVEL0):
            ok, u = covers(leafset, LEVEL0, i, j)
            if not ok:
                return False, "initial box (%d, %d) not covered" % (i, j)
            used |= u
    unused = leafset - used
    return True, "%d leaves, %d unused (nested or outside the rectangle)" % (len(leafset), len(unused))


def box_coords(rec):
    la, ia, lb, ib = rec
    ha = AROOT / (mpz(1) << la)
    hb = BROOT / (mpz(1) << lb)
    return ia * ha, (ia + 1) * ha, ib * hb, (ib + 1) * hb


# ---------------------------------------------------------------- Poisson weights
def poisson_upper(lam):
    """Upper bounds p_n^hi of P(N_lam = n) for n <= n_max and an upper bound for P(N_lam > n_max) <= 2^-80."""
    if lam == 0:
        return [mpq(1)], mpq(0)
    el = exp_b(-lam, WEIGHT_BITS + 20)[1]
    ps = []
    t = el
    n = 0
    while True:
        ps.append(rup(t, WEIGHT_BITS))
        nxt = t * lam / (n + 1)
        if n + 2 > 2 * lam and n >= 2:
            # sum_{k > n} p_k <= p_{n+1} / (1 - lam/(n+2))
            tail = nxt / (1 - lam / (n + 2))
            if tail < mpq(1, 2 ** 80):
                return ps, rup(tail, WEIGHT_BITS)
        t = nxt
        n += 1


def poisson_lower_sum(lam, n):
    if lam == 0:
        return mpq(1)
    el = exp_b(-lam, WEIGHT_BITS + 20)[0]
    s = mpq(0)
    t = el
    for k in range(n + 1):
        s += t
        t = t * lam / (k + 1)
    return s


# ---------------------------------------------------------------- the checks of one cell
def poly_upper_on(p, u, v):
    return sup_upper(p, u, v, TOL)


def ranges(cell, mu, cap, rmult):
    k3m, k3p, k4m, k4p = cell
    Lr, Ur = {}, {}
    for j in range(3, 17):
        sL3, sL4, sU3, sU4 = (q(x) for x in rmult[str(j)])
        deg = max(j - 2, 2)
        g = [mpq(0)] * (deg + 1)
        g[j - 2] += 1
        g[1] -= sU3
        g[2] -= sU4
        S = poly_upper_on(g, -A, TAU)
        Ur[j] = mu * S + cap * max(peval(g, A) - S, 0) + max(sU3 * k3m, sU3 * k3p) + max(sU4 * k4m, sU4 * k4p)
        h = [mpq(0)] * (deg + 1)
        h[j - 2] -= 1
        h[1] += sL3
        h[2] += sL4
        S = poly_upper_on(h, -A, TAU)
        Lr[j] = -(mu * S + cap * max(peval(h, A) - S, 0)) + min(sL3 * k3m, sL3 * k3p) + min(sL4 * k4m, sL4 * k4p)
    Lr[3] = max(Lr[3], k3m)
    Ur[3] = min(Ur[3], k3p)
    Lr[4] = max(Lr[4], k4m)
    Ur[4] = min(Ur[4], k4p)
    return Lr, Ur


def iprod(ivs):
    lo, hi = mpq(1), mpq(1)
    for a, b in ivs:
        c = (lo * a, lo * b, hi * a, hi * b)
        lo, hi = min(c), max(c)
    return lo, hi


def parse_tuple(key):
    al = tuple(int(x) for x in key.split(","))
    if len(al) < 2 or list(al) != sorted(al) or not all(3 <= x <= 16 for x in al):
        raise ValueError("bad tuple key %r" % (key,))
    return al


def lagrangian(coef, mu, cap, cell, Lr, Ur, mult):
    k3m, k3p, k4m, k4p = cell
    const, lin, prod = expansion(coef, mu)
    lin = {j: lin.get(j, mpq(0)) for j in range(3, 17)}
    lam = [max(q(x), mpq(0)) for x in mult["cell"]]
    if len(lam) != 4:
        raise ValueError("cell multipliers")
    const += lam[0] * k3p - lam[1] * k3m + lam[2] * k4p - lam[3] * k4m
    lin[3] += -lam[0] + lam[1]
    lin[4] += -lam[2] + lam[3]
    for key, ms in mult["mcc"].items():
        al = parse_tuple(key)
        l1, l2, l3, l4 = (max(q(x), mpq(0)) for x in ms)
        j = al[-1]
        Ym, Yp = Lr[j], Ur[j]
        if len(al) == 2:
            Xm, Xp = Lr[al[0]], Ur[al[0]]
        else:
            Xm, Xp = iprod([(Lr[x], Ur[x]) for x in al[:-1]])
        prod[al] = prod.get(al, mpq(0)) + (l1 + l2 - l3 - l4)
        lin[j] += -l1 * Xm - l2 * Xp + l3 * Xp + l4 * Xm
        cx = -l1 * Ym - l2 * Yp + l3 * Ym + l4 * Yp
        if len(al) == 2:
            lin[al[0]] += cx
        else:
            prod[al[:-1]] = prod.get(al[:-1], mpq(0)) + cx
        const += l1 * Xm * Ym + l2 * Xp * Yp - l3 * Xp * Ym - l4 * Xm * Yp
    gamma = {}
    for key, ms in mult["cheb"].items():
        al = parse_tuple(key)
        n1, n2 = (max(q(x), mpq(0)) for x in ms)
        s = sum(x - 2 for x in al)
        gamma[s] = gamma.get(s, mpq(0)) + (n1 + n2) * mu ** (len(al) - 1)
        prod[al] = prod.get(al, mpq(0)) - n1 + n2
    deg = max([j - 2 for j in range(3, 17)] + list(gamma) + [2])
    Rp = [mpq(0)] * (deg + 1)
    Rn = [mpq(0)] * (deg + 1)
    for j in range(3, 17):
        Rp[j - 2] += lin[j]
        Rn[j - 2] += lin[j]
    for s, gm in gamma.items():
        Rp[s] += gm
        Rn[s] += gm if s % 2 == 0 else -gm
    SR = max(poly_upper_on(Rn, -A, mpq(0)), poly_upper_on(Rp, mpq(0), TAU))
    RA = peval(Rp, A)
    beta = const + mu * SR + cap * max(RA - SR, 0)
    for al, e in prod.items():
        if e == 0:
            continue
        lo, hi = iprod([(Lr[x], Ur[x]) for x in al])
        beta += max(e * lo, e * hi)
    return beta


def majorant(coef, a1, b1, Lt):
    """Returns (ok, eps, info).  ok False if a tail test or L >= tau a1 + A b1 fails."""
    L = q(Lt)
    if L < TAU * a1 + A * b1:
        return False, None, "L < tau a1 + A b1"
    pa, Ta = poisson_upper(a1)
    pb, Tb = poisson_upper(b1)
    T = Ta + Tb
    var = TAU ** 2 * a1 + A ** 2 * b1
    e = sqrt_b(T * var, WEIGHT_BITS)[1] if T * var > 0 else mpq(0)
    terms = []
    for n, pn in enumerate(pa):
        cn = TAU * (n - a1)
        for m, pm in enumerate(pb):
            terms.append((pn * pm, cn + A * (m - b1)))
    delta = 2 * sum((p * (c - L) for p, c in terms if c > L), mpq(0)) + 2 * e
    # tail tests of Lemma 23(iii)
    d = taylor_shift([q(x) for x in coef], L)
    d[0] -= L
    d[1] -= 1
    if any(x < 0 for x in d):
        return False, None, "right tail test fails"
    psi = [q(x) if k % 2 == 0 else -q(x) for k, x in enumerate(coef)]
    d = taylor_shift(psi, L)
    d[0] -= L + delta
    d[1] -= 1
    if any(x < 0 for x in d):
        return False, None, "left tail test fails"
    # H~(r) = sum_big p |c + r| + (T + sum_small p) |r| + e + sum_small p |c|  >=  H(r) on R
    big = [(p, c) for p, c in terms if p >= SMALL]
    small = [(p, c) for p, c in terms if p < SMALL]
    slope_abs = T + sum((p for p, _ in small), mpq(0))
    cst = e + sum((p * abs(c) for p, c in small), mpq(0))
    kinks = {}
    for p, c in big:
        x = -c
        if -L < x < L:
            kinks[x] = kinks.get(x, mpq(0)) + p
    kinks[mpq(0)] = kinks.get(mpq(0), mpq(0)) + slope_abs
    # value on (-L, first kink): every term with -c >= L or -c in (-L, L) has c + r < 0 there; -c <= -L: c + r > 0
    slope = mpq(0)
    icpt = cst
    for p, c in big:
        if -c <= -L:
            slope += p
            icpt += p * c
        else:
            slope -= p
            icpt -= p * c
    slope -= slope_abs
    pts = sorted(kinks)
    # float floor for the piecewise supremum
    cf = np.array([float(x) for x in coef])[::-1]
    grid = np.concatenate([np.linspace(float(-L), float(L), 20001), np.array([float(x) for x in pts])])
    pf = np.array([float(p) for p, _ in big])
    cfv = np.array([float(c) for _, c in big])
    Hf = (pf[None, :] * np.abs(cfv[None, :] + grid[:, None])).sum(axis=1) + float(slope_abs) * np.abs(grid) + float(cst)
    fl = float(np.max(Hf - np.polyval(cf, grid)))
    floor = max(mpq(0), q(fl) - mpq(1, 10 ** 9))
    eps = floor
    bounds = [-L] + [x for x in pts if -L < x < L] + [L]
    cq = [q(x) for x in coef]
    for k in range(len(bounds) - 1):
        u, v = bounds[k], bounds[k + 1]
        if k > 0:
            w = kinks[u]
            slope += 2 * w
            icpt += 2 * w * (-u) if u != 0 else 0
        if v <= u:
            continue
        poly = [-x for x in cq]
        poly[0] += icpt
        poly[1] += slope
        eps = max(eps, sup_upper(poly, u, v, mpq(1, 10 ** 13), floor=floor))
    return True, eps, "n_a=%d n_b=%d pieces=%d" % (len(pa) - 1, len(pb) - 1, len(bounds) - 1)


def farkas_phi(f, mu, cap, cell):
    k3m, k3p, k4m, k4p = cell
    s3, s4 = q(f[0]), q(f[1])
    g = [mpq(0), -s3, -s4]
    S = poly_upper_on(g, -A, TAU)
    return mu * S + cap * max(peval(g, A) - S, 0) + max(s3 * k3m, s3 * k3p) + max(s4 * k4m, s4 * k4p)


def verify_box(args):
    rec, target, mods = args
    t0 = time.time()
    a1, a2, b1, b2 = box_coords(rec["box"])
    out = {"box": rec["box"], "status": rec["status"], "ok": False, "msg": "", "worst": None, "ncell": 0}
    if rec["status"] == "empty":
        if Qf(a1, b1) >= mpq(4, 5) or Mf(a2, b2) < mpq(1, 2):
            out["ok"] = True
            out["msg"] = "empty"
        else:
            out["msg"] = "recorded empty but Q(a1,b1) < 4/5 and M(a2,b2) >= 1/2"
        out["t"] = time.time() - t0
        return out
    if rec["status"] != "ok":
        out["msg"] = "unknown status"
        return out
    mu = 1 - max(Qf(a2, b2), mpq(1, 2)) + Mf(a2, b2) - Mf(a1, b1)
    cap = (b2 - b1) * A ** 2
    if mu < 0:
        out["ok"] = True
        out["msg"] = "mu_B < 0: no admissible rest measure"
        return out
    R3 = (-A * mu, TAU * mu + (A - TAU) * cap)
    R4 = (mpq(0), A ** 2 * mu)
    certs = rec["certs"]
    cells = {}
    for c in certs:
        l, i, j = c["cell"]
        key = (l, i, j)
        if key in cells:
            out["msg"] = "duplicate cell %r" % (key,)
            return out
        if not (0 <= i < 2 ** l and 0 <= j < 2 ** l):
            out["msg"] = "cell index out of grid %r" % (key,)
            return out
        cells[key] = c
    ok, _ = covers(set(cells), 0, 0, 0, maxlevel=12)
    if not ok:
        out["msg"] = "cells do not cover R_B"
        return out
    worst = None
    details = []
    for key, c in cells.items():
        l, i, j = key
        w3 = (R3[1] - R3[0]) / (mpz(1) << l)
        w4 = (R4[1] - R4[0]) / (mpz(1) << l)
        cell = (R3[0] + i * w3, R3[0] + (i + 1) * w3, R4[0] + j * w4, R4[0] + (j + 1) * w4)
        if c["status"] == "empty_farkas":
            phi = farkas_phi(c["farkas"], mu, cap, cell)
            if phi < 0:
                details.append((key, "farkas", float(phi)))
                continue
            out["msg"] = "Farkas test fails in cell %r (Phi = %.3e)" % (key, float(phi))
            return out
        if c["status"] != "ok":
            out["msg"] = "unknown cell status"
            return out
        coef = c["coef"]
        if len(coef) != 17:
            out["msg"] = "phi does not have 17 coefficients"
            return out
        coef = [q(x) for x in coef]
        if "c16neg" in mods:
            coef[16] = -abs(coef[16]) - mpq(1, 10 ** 12)
        Lr, Ur = ranges(cell, mu, cap, c["rmult"])
        if any(Lr[j] > Ur[j] for j in range(3, 17)):
            details.append((key, "empty_by_ranges", None))
            continue
        Lt = c["Lt"]
        if "lowL" in mods:
            Lt = float(TAU * a1 + A * b1) * 0.999 if a1 + b1 > 0 else -1.0
        okm, eps, info = majorant(coef, a1, b1, Lt)
        if not okm:
            out["msg"] = "majorant test fails in cell %r: %s" % (key, info)
            return out
        beta = lagrangian(coef, mu, cap, cell, Lr, Ur, c["mult"])
        bnd = beta + eps
        details.append((key, "ok", float(bnd), float(c.get("bound", float("nan"))), info, float(eps)))
        if not bnd < target:
            out["msg"] = "beta + eps = %.7f >= target in cell %r" % (float(bnd), key)
            out["worst"] = float(bnd)
            return out
        if worst is None or bnd > worst[0]:
            worst = (bnd, key)
    out["ok"] = True
    out["ncell"] = len(cells)
    out["worst"] = None if worst is None else (float(worst[0]), list(worst[1]))
    out["details"] = details
    out["t"] = time.time() - t0
    return out


def load_records():
    files = sorted(glob.glob(os.path.join(CERTDIR, "certs_v1_r*.jsonl")))
    recs = []
    md5 = {}
    for fn in files:
        with open(fn, "rb") as fh:
            data = fh.read()
        md5[os.path.basename(fn)] = hashlib.md5(data).hexdigest()
        for line in data.decode().splitlines():
            if line.strip():
                recs.append(json.loads(line))
    return recs, md5


def run(recs, target, procs, mods=(), log=print):
    ok, msg = box_tiling(recs)
    log("box tiling: %s (%s)" % ("OK" if ok else "FAIL", msg))
    if not ok:
        return False, None
    t0 = time.time()
    fails = []
    worst = None
    nbox = {"ok": 0, "empty": 0}
    ncell = 0
    allres = []
    with Pool(procs) as pool:
        for r in pool.imap_unordered(verify_box, [(rec, target, mods) for rec in recs], chunksize=1):
            allres.append(r)
            if not r["ok"]:
                fails.append((r["box"], r["msg"]))
                continue
            nbox[r["status"]] += 1
            ncell += r["ncell"]
            if r["worst"] is not None and (worst is None or r["worst"][0] > worst[0]):
                worst = (r["worst"][0], r["box"], r["worst"][1])
    log("verified boxes: %d ok, %d empty, %d failures; %d cells; %.0f s" % (nbox["ok"], nbox["empty"], len(fails),
                                                                          ncell, time.time() - t0))
    for b, m in fails[:10]:
        log("  FAIL box %r: %s" % (b, m))
    if worst is not None:
        log("worst certified bound beta + eps = %.7f in box %r cell %r" % worst)
    return len(fails) == 0, (allres, worst, fails)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--procs", type=int, default=8)
    ap.add_argument("--shift", type=str, default="0")
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--controls", action="store_true")
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    lines = []

    def log(s):
        print(s, flush=True)
        lines.append(s)

    recs, md5 = load_records()
    log("RQ-REF3 heavy_verify.py; start %s UTC" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()))
    with open(__file__, "rb") as fh:
        log("md5 %s  heavy_verify.py" % hashlib.md5(fh.read()).hexdigest())
    for k, v in md5.items():
        log("md5 %s  %s" % (v, k))
    log("C5 lower bound used: %s = %.15f" % ("(32/25) sqrt(2 ln 5/4) rounded down", float(C5_LO)))
    log("%d box records" % len(recs))
    if args.limit:
        recs = recs[: args.limit]
    target = C5_LO - q(args.shift)
    ok, res = run(recs, target, args.procs, log=log)
    if res is not None:
        allres, worst, fails = res
        # level statistics and comparison with the stored (float) bounds
        lev = {}
        diffs = []
        statuses = {}
        for r in allres:
            if not r["ok"]:
                continue
            d = r["box"][0] - LEVEL0
            k = lev.setdefault(d, [0, 0])
            k[0 if r["status"] == "ok" else 1] += 1
            for det in r.get("details", []):
                statuses[det[1]] = statuses.get(det[1], 0) + 1
                if det[1] == "ok" and det[3] == det[3]:
                    diffs.append(det[2] - det[3])
        for d in sorted(lev):
            log("  box level d = %d: %d certified, %d empty" % (d, lev[d][0], lev[d][1]))
        log("cell outcomes: %r" % statuses)
        if diffs:
            log("my bound - stored float bound: min %.3e, max %.3e" % (min(diffs), max(diffs)))
        top = []
        for r in allres:
            for det in r.get("details", []):
                if det[1] == "ok":
                    top.append((det[2], r["box"], det[0]))
        top.sort(reverse=True)
        for t in top[:8]:
            log("  bound %.7f  box %r cell %r" % t)
    log("RESULT: %s" % ("ALL CHECKS PASSED" if ok else "FAILED"))
    if args.controls:
        controls(recs, args.procs, log)
    log("end %s UTC" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()))
    if args.out:
        with open(args.out, "w") as fh:
            fh.write("\n".join(lines) + "\n")
    sys.exit(0 if ok else 1)


def controls(recs, procs, log):
    """Negative controls: each must make the verification fail."""
    import copy
    log("---- negative controls (each must FAIL) ----")
    res = []
    r2 = [r for r in recs if r["box"] != [4, 0, 4, 0]]
    ok, msg = box_tiling(r2)
    res.append(("drop box [4,0,4,0]", ok))
    r2 = copy.deepcopy(recs)
    for r in r2:
        if r["box"] == [4, 15, 4, 11]:
            r["box"] = [4, 31, 4, 11]
    ok, msg = box_tiling(r2)
    res.append(("move box [4,15,4,11] out of grid", ok))
    okb = [r for r in recs if r["status"] == "ok"]
    rec = copy.deepcopy(next(r for r in okb if len(r["certs"]) > 1))
    rec["certs"] = rec["certs"][1:]
    res.append(("drop one cell of box %r" % (rec["box"],), verify_box((rec, C5_LO, ()))["ok"]))
    rec = copy.deepcopy(okb[0])
    rec["status"] = "empty"
    res.append(("relabel ok box %r as empty" % (rec["box"],), verify_box((rec, C5_LO, ()))["ok"]))
    rec = copy.deepcopy(next(r for r in okb if any(c["status"] == "empty_farkas" for c in r["certs"])))
    for c in rec["certs"]:
        if c["status"] == "empty_farkas":
            c["farkas"] = [0.0, 0.0]
    res.append(("Farkas multipliers (0, 0) in box %r" % (rec["box"],), verify_box((rec, C5_LO, ()))["ok"]))
    rec = copy.deepcopy(okb[5])
    res.append(("c16 made negative in box %r" % (rec["box"],), verify_box((rec, C5_LO, ("c16neg",)))["ok"]))
    rec = copy.deepcopy(next(r for r in okb if box_coords(r["box"])[0] > 0))
    res.append(("L below tau a1 + A b1 in box %r" % (rec["box"],), verify_box((rec, C5_LO, ("lowL",)))["ok"]))
    rec = copy.deepcopy(okb[3])
    for c in rec["certs"]:
        if c["status"] == "ok":
            c["coef"][2] = c["coef"][2] * 0.97
    res.append(("phi coefficient c2 scaled by 0.97 in box %r" % (rec["box"],), verify_box((rec, C5_LO, ()))["ok"]))
    for name, passed in res:
        log("  %-60s -> %s" % (name, "passed (CONTROL FAILED TO DETECT)" if passed else "rejected (good)"))
    for s in ("1e-4", "3e-4", "1e-3"):
        t = C5_LO - q(s)
        nf = 0
        with Pool(procs) as pool:
            for r in pool.imap_unordered(verify_box, [(rec, t, ()) for rec in okb], chunksize=1):
                if not r["ok"]:
                    nf += 1
        log("  target C5 - %s: %d of %d non-empty boxes fail" % (s, nf, len(okb)))


if __name__ == "__main__":
    main()
