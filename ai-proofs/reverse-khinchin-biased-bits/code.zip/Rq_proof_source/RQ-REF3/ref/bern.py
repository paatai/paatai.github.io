"""Exact polynomial bounds on intervals by Bernstein subdivision (RQ-REF3).

A polynomial p (ascending rational coefficients) on [u, v] is written in the Bernstein basis of degree n,
p(u + (v-u) t) = sum_i b_i C(n,i) t^i (1-t)^(n-i).  The convex-hull property gives
min_i b_i <= p <= max_i b_i on [u, v], with equality of b_0, b_n and the end values.  Subdivision at the midpoint
(de Casteljau) is done on integer vectors with an exact common scale, so every bound is an exact rational.
"""

import heapq
from gmpy2 import mpq, mpz

from rig import q

_BINOM = {}


def binom(n, k):
    key = (n, k)
    v = _BINOM.get(key)
    if v is None:
        from math import comb
        v = mpz(comb(n, k))
        _BINOM[key] = v
    return v


def trim(p):
    p = [q(c) for c in p]
    while len(p) > 1 and p[-1] == 0:
        p.pop()
    return p


def peval(p, x):
    r = mpq(0)
    for c in reversed(p):
        r = r * x + c
    return r


def taylor_shift(p, u):
    """Coefficients of p(u + s) in s."""
    a = list(p)
    n = len(a) - 1
    if u == 0:
        return a
    for i in range(n):
        for j in range(n - 1, i - 1, -1):
            a[j] += u * a[j + 1]
    return a


def bern_coeffs(p, u, v):
    """Integer Bernstein coefficients B and a positive integer scale S with b_i = B_i / S on [u, v]."""
    p = trim(p)
    n = len(p) - 1
    if n == 0:
        c = p[0]
        return [c.numerator], c.denominator
    a = taylor_shift(p, u)
    w = v - u
    wk = mpq(1)
    for k in range(n + 1):
        a[k] = a[k] * wk
        wk *= w
    b = []
    for i in range(n + 1):
        s = mpq(0)
        for k in range(i + 1):
            if a[k]:
                s += a[k] * binom(i, k) / binom(n, k)
        b.append(s)
    D = mpz(1)
    for x in b:
        d = x.denominator
        if D % d:
            from math import lcm
            D = mpz(lcm(int(D), int(d)))
    B = [x.numerator * (D // x.denominator) for x in b]
    return B, D


def split(B):
    """de Casteljau at t = 1/2; both halves are returned scaled by 2^n relative to B."""
    n = len(B) - 1
    left = [B[0] << n]
    right = [B[n] << n]
    work = list(B)
    for r in range(1, n + 1):
        work = [work[i] + work[i + 1] for i in range(n - r + 1)]
        left.append(work[0] << (n - r))
        right.append(work[-1] << (n - r))
    right.reverse()
    return left, right


def is_le(p, u, v, c, maxdepth=40):
    """Decide p <= c on [u, v] (u < v rational).  True = proved, False = disproved (an end value of a
    subinterval exceeds c), None = undecided at maxdepth."""
    c = q(c)
    B, S = bern_coeffs(p, u, v)
    n = len(B) - 1
    cn, cd = c.numerator, c.denominator
    stack = [(B, S, 0)]
    while stack:
        B, S, d = stack.pop()
        thr = cn * S
        if max(B) * cd <= thr:
            continue
        if B[0] * cd > thr or B[-1] * cd > thr:
            return False
        if d >= maxdepth or n == 0:
            return None
        L, R = split(B)
        S2 = S << n
        stack.append((R, S2, d + 1))
        stack.append((L, S2, d + 1))
    return True


def sup_upper(p, u, v, tol=mpq(1, 10 ** 14), maxdepth=60, floor=None):
    """A rigorous upper bound for max_{[u,v]} p, at most tol above the best end value found.

    With floor given, returns an upper bound for max(floor, max_{[u,v]} p); subintervals whose Bernstein bound is
    <= floor are discarded without refinement."""
    tol = q(tol)
    B, S = bern_coeffs(p, u, v)
    n = len(B) - 1
    if n == 0:
        r = mpq(B[0], S)
        return r if floor is None else max(r, q(floor))
    best_lo = max(mpq(B[0], S), mpq(B[-1], S))
    if floor is not None:
        floor = q(floor)
        best_lo = max(best_lo, floor)
    leaf_ub = best_lo
    tick = 0
    heap = [(-mpq(max(B), S), 0, 0, B, S)]
    while heap:
        nub, d, _, B, S = heapq.heappop(heap)
        ub = -nub
        lo = mpq(max(B[0], B[-1]), S)
        if lo > best_lo:
            best_lo = lo
        if ub <= best_lo + tol:
            # every node still in the heap has a bound <= ub, so all of them would be leaves as well
            return max(leaf_ub, ub)
        if d >= maxdepth:
            leaf_ub = max(leaf_ub, ub)
            continue
        L, R = split(B)
        S2 = S << n
        for C in (L, R):
            tick += 1
            heapq.heappush(heap, (-mpq(max(C), S2), d + 1, tick, C, S2))
    return leaf_ub


def nonneg_halfline(qc, maxdepth=30):
    """Decide q(t) >= 0 for all t >= 0.  (1-s)^n q(s/(1-s)) = sum q_k s^k (1-s)^(n-k) has Bernstein
    coefficients q_k / C(n,k) on [0, 1]; s in [0, 1) covers t in [0, oo).  Returns True/False/None."""
    qc = trim(qc)
    n = len(qc) - 1
    if n == 0:
        return qc[0] >= 0
    b = [qc[k] / binom(n, k) for k in range(n + 1)]
    D = mpz(1)
    from math import lcm
    for x in b:
        D = mpz(lcm(int(D), int(x.denominator)))
    B = [x.numerator * (D // x.denominator) for x in b]
    stack = [(B, 0)]
    while stack:
        B, d = stack.pop()
        if min(B) >= 0:
            continue
        if B[0] < 0 or B[-1] < 0:
            return False
        if d >= maxdepth:
            return None
        L, R = split(B)
        stack.append((R, d + 1))
        stack.append((L, d + 1))
    return True


def _selftest():
    import random
    rng = random.Random(5)
    for trial in range(300):
        n = rng.randint(1, 16)
        p = [mpq(rng.randint(-1000, 1000), rng.randint(1, 50)) for _ in range(n + 1)]
        u = mpq(rng.randint(-200, 100), 100)
        v = u + mpq(rng.randint(1, 300), 100)
        ub = sup_upper(p, u, v, mpq(1, 10 ** 12))
        N = 400
        vals = [peval(p, u + (v - u) * mpq(i, N)) for i in range(N + 1)]
        m = max(vals)
        assert ub >= m, (trial, float(ub), float(m))
        scale = 1 + abs(m)
        assert ub - m <= scale * mpq(1, 10) * 1, (trial, float(ub), float(m))
        assert is_le(p, u, v, ub) is not False, trial
        assert is_le(p, u, v, m - mpq(1, 10 ** 9)) is False, trial
        assert is_le(p, u, v, ub + scale * mpq(1, 10 ** 6)) is True, trial
        fl = m + scale * mpq(rng.randint(-100, 100), 1000)
        ubf = sup_upper(p, u, v, mpq(1, 10 ** 12), floor=fl)
        assert ubf >= max(fl, m) and ubf <= max(fl, ub) + scale * mpq(1, 10 ** 9), trial
    # exact touching at a dyadic point is decided
    p = [mpq(0), mpq(0), mpq(-1)]  # -x^2 on [-1, 1]
    assert is_le(p, mpq(-1), mpq(1), mpq(0)) is True
    # half line
    assert nonneg_halfline([mpq(1), mpq(-1), mpq(1)]) is True  # t^2 - t + 1
    assert nonneg_halfline([mpq(1), mpq(-3), mpq(1)]) is False  # has positive roots
    print("bern selftest OK")


if __name__ == "__main__":
    _selftest()
