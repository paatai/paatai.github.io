"""Exact upper bounds for the stop-loss costs chi^B_h, chi^C_h of RQ-D Lemma 6 (RQ-REF3).

W_B = theta (N_{a/theta^2} - a/theta^2) + sqrt(b) G,   W_C = A (N_{b/A^2} - b/A^2) + sqrt(a) G,
chi^B_h(t) = E (W_B - t + h)_+^2 / (2h),              chi^C_h(t) = E (W_C - t + h)_+^2 / (2h).

With J = theta (resp. A), lam = a/theta^2 (resp. b/A^2), s^2 = b (resp. a), c = t - h:
chi_h(t) = (1/2h) sum_n p_n(lam) Q(J (n - lam) - c, s),  Q(d, s) = E (d + s G)_+^2 = s^2 qq(d/s),
qq(x) = E (x + G)_+^2 = (x^2 + 1) Phi(x) + x phi(x).

Upper bounds, all exact rationals:
  * qq is increasing and convex (qq' = 2 E(x + G)_+, qq'' = 2 Phi(x)), so on [x_k, x_k+1] it lies below the chord
    through upper bounds at the grid points; the grid is x_k = -16 + k 2^-12, the values are upper bounds from
    ref/rig.py (Phi and phi enclosures, 100 bits).  Below -16: qq(x) <= qq_hi(-16); above 16: qq(x) <= x^2 + 1.
  * Q(d, s) is nondecreasing in s, so s is replaced by a rational s_hi >= s.
  * p_n(lam) <= e^-lam lam^n / n! with an upper enclosure of e^-lam; the tail n > N is bounded by
    sum_{n > N} lam^n/n! ((J n + C)^2 + s^2), C = J lam + |c| (Q(d, s) <= d^2 + s^2, |d_n| <= J n + C), whose
    consecutive terms have ratio <= lam (n + 1)/n^2 <= lam (N + 2)/(N + 1)^2 for n >= N + 1.
Linear bounds of the slope check (RQ-D Section 6.1; re-derived by hand): for a, b >= 0, a + b <= r, c = t - h > 0,
  chi^B_h(t) <= a alphaB + b betaB if r/theta <= 2 (theta - c), and chi^C_h(t) <= a alphaC + b betaC if
  r/A <= 2 (A - c), with alphaB = (1/(2h theta^2)) sum_{n >= 1} (r/theta^2)^(n-1)/n! ((theta n - c)^2 + r),
  betaB = tau(c/sqrt r)/(2h), alphaC = tau(c/sqrt r)/(2h), betaC = (1/(2h A^2)) sum (r/A^2)^(n-1)/n! ((A n - c)^2 + r),
  tau(x) = E(G - x)_+^2 = qq(-x).  Series tail: terms <= (r/J^2)^(n-1)/n! ((J n)^2 + r), ratio <= (r/J^2)(N+2)/(N+1)^2.
"""

import math
import os
import pickle

from gmpy2 import mpq, mpz

from rig import exp_b, ncdf_b, npdf_b, rdown, rup, sqrt_b

TH = mpq(17, 20)
A = mpq(77, 50)
QLO, QHI, QBITS, QPREC = -16, 16, 12, 100
QPATH = "/tmp/rqref3_qtable_v1.pkl"
RB = 64          # outward rounding of intermediate upper bounds
XB = 24          # arguments of qq are rounded up to multiples of 2^-XB
MPQ = type(mpq(1))

_QT = None


def _qq_hi_exact(x):
    ph = ncdf_b(x, QPREC)
    pd = npdf_b(x, QPREC)
    v = (x * x + 1) * ph[1] + (x * pd[1] if x >= 0 else x * pd[0])
    return v


def build_qtable():
    n = (QHI - QLO) << QBITS
    vals = []
    S = mpz(1) << QPREC
    for k in range(n + 1):
        x = mpq(QLO) + mpq(k, 1 << QBITS)
        v = _qq_hi_exact(x)
        vals.append(int(-((-v.numerator * S) // v.denominator)))  # ceil(v 2^QPREC)
    return vals


def qtable():
    global _QT
    if _QT is None:
        if os.path.exists(QPATH):
            with open(QPATH, "rb") as fh:
                d = pickle.load(fh)
            if d.get("key") == (QLO, QHI, QBITS, QPREC):
                _QT = [mpz(v) for v in d["vals"]]
        if _QT is None:
            vals = build_qtable()
            with open(QPATH + ".tmp%d" % os.getpid(), "wb") as fh:
                pickle.dump({"key": (QLO, QHI, QBITS, QPREC), "vals": vals}, fh)
            os.replace(QPATH + ".tmp%d" % os.getpid(), QPATH)
            _QT = [mpz(v) for v in vals]
    return _QT


def qq_hi(x):
    """Upper bound of qq(x) = E(x + G)_+^2 for rational x."""
    assert isinstance(x, MPQ)
    if x >= QHI:
        return x * x + 1
    T = qtable()
    if x <= QLO:
        return mpq(T[0], mpz(1) << QPREC)
    xu = rup(x, XB)
    if xu >= QHI:
        return x * x + 1
    u = (xu - QLO) * (1 << QBITS)
    k = int(u.numerator // u.denominator)
    fr = u - k
    v = T[k] + fr * (T[k + 1] - T[k])
    return v / (mpz(1) << QPREC)


def qq_f(x):
    """Float value of qq (guidance only)."""
    if x > 30:
        return x * x + 1
    if x < -30:
        return 0.0
    Phi = 0.5 * math.erfc(-x / math.sqrt(2))
    phi = math.exp(-x * x / 2) / math.sqrt(2 * math.pi)
    if x < -5:
        # asymptotic form avoids cancellation: tau(y) ~ 2 phi(y)/y^3 (1 - 6/y^2)
        y = -x
        return max(0.0, 2 * phi / y ** 3 * (1 - 6 / y ** 2 + 60 / y ** 4))
    return (x * x + 1) * Phi + x * phi


class Chi:
    """chi^B (kind 'B') or chi^C (kind 'C') at the corner (abar, bbar): exact upper bounds and float values."""

    def __init__(self, kind, abar, bbar):
        self.kind = kind
        if kind == "B":
            self.J, self.lam, s2 = TH, abar / (TH * TH), bbar
        else:
            self.J, self.lam, s2 = A, bbar / (A * A), abar
        self.s_hi = sqrt_b(s2, RB)[1]
        self.s2_hi = self.s_hi * self.s_hi
        lam = self.lam
        # p_n upper bounds and the truncation N: smallest N >= 2 with lam^(N+1)/(N+1)! (J (N+1) + 3)^2 < 2^-80
        eh = exp_b(-lam, RB + 8)[1] if lam > 0 else mpq(1)
        ps, t, n = [], eh, 0
        while True:
            ps.append(rup(t, RB))
            t = t * lam / (n + 1)
            n += 1
            if n >= 3 and (lam == 0 or lam ** n / math.factorial(n) * (self.J * n + 3) ** 2 < mpq(1, 2 ** 80)):
                break
        self.ps, self.N = ps, len(ps) - 1
        self.ratio = lam * (self.N + 2) / mpq((self.N + 1) ** 2)
        assert self.ratio < mpq(1, 2)
        self.cache = {}
        self.fcache = {}
        self.lam_f, self.s_f, self.J_f = float(lam), float(self.s_hi), float(self.J)
        self.ps_f = [float(p) for p in ps]

    def hi(self, t, h):
        key = (t, h)
        v = self.cache.get(key)
        if v is not None:
            return v
        c = t - h
        J, lam = self.J, self.lam
        tot = mpq(0)
        for n, p in enumerate(self.ps):
            d = J * (n - lam) - c
            tot += p * self.s2_hi * qq_hi(d / self.s_hi)
        n1 = self.N + 1
        C = J * lam + abs(c)
        tail = lam ** n1 / mpq(math.factorial(n1)) * ((J * n1 + C) ** 2 + self.s2_hi) / (1 - self.ratio)
        v = (tot + tail) / (2 * h)
        assert isinstance(v, MPQ)
        v = rup(v, RB)
        self.cache[key] = v
        return v

    def f(self, t, h):
        key = (t, h)
        v = self.fcache.get(key)
        if v is not None:
            return v
        c = float(t) - h
        tot = 0.0
        for n, p in enumerate(self.ps_f):
            d = self.J_f * (n - self.lam_f) - c
            tot += p * self.s_f * self.s_f * qq_f(d / self.s_f)
        v = tot / (2 * h)
        self.fcache[key] = v
        return v


def lin_coef(J, t, h, r, exact=True):
    """(jump coefficient, Gaussian coefficient) of the linear bound of chi_h(t) for the law with jump J, valid for
    a + b <= r; None if c = t - h <= 0 or r/J > 2 (J - c).  For chi^B the jump coefficient multiplies a and the
    Gaussian one b; for chi^C the jump coefficient multiplies b and the Gaussian one a."""
    c = t - h
    if not exact:
        J, t, r, c = float(J), float(t), float(r), float(t) - h
    if c <= 0 or r / J > 2 * (J - c):
        return None
    one = mpq(1) if exact else 1.0
    if r == 0:
        return 0 * one, 0 * one  # a = b = 0, and chi_h(t) = (h - t)_+^2 / (2h) = 0 for c > 0
    x = r / (J * J)
    S = 0 * one
    term_pow = one
    N = 12
    for n in range(1, N + 1):
        S += term_pow / (one * math.factorial(n)) * ((J * n - c) ** 2 + r)
        term_pow = term_pow * x
    n1 = N + 1
    rat = x * (N + 2) / ((N + 1) ** 2 * one)
    tail = term_pow / (one * math.factorial(n1)) * ((J * n1) ** 2 + r) / (1 - rat)
    jump = (S + tail) / (2 * h * J * J)
    if exact:
        xs = c / sqrt_b(r, RB)[1]
        gauss = qq_hi(-xs) / (2 * h)
        assert isinstance(jump, MPQ) and isinstance(gauss, MPQ)
        return rup(jump, RB), rup(gauss, RB)
    return jump, qq_f(-c / math.sqrt(r)) / (2 * h)


# ---------------------------------------------------------------- self-test
def _selftest():
    import random
    import mpmath
    mpmath.mp.prec = 200
    T = qtable()
    rng = random.Random(5)
    for _ in range(300):
        x = mpq(rng.randint(-20000, 20000), rng.randint(1, 997))
        xm = mpmath.mpf(int(x.numerator)) / int(x.denominator)
        y = -abs(xm)
        tau = (y * y + 1) * mpmath.ncdf(y) + y * mpmath.npdf(y)  # qq(-|x|), no cancellation problem at 200 bits
        true = tau if xm <= 0 else xm * xm + 1 - tau            # qq(x) + qq(-x) = x^2 + 1
        ub = qq_hi(x)
        if x >= QHI:
            assert ub == x * x + 1  # qq(x) = x^2 + 1 - qq(-x) < x^2 + 1 exactly
            continue
        ubm = mpmath.mpf(int(ub.numerator)) / int(ub.denominator)
        assert ubm >= true * (1 - mpmath.mpf(2) ** -150), (x, ubm, true)
        assert ubm - true <= mpmath.mpf(2) ** -20 * (1 + true) or (x < -8 and ubm < 1e-14), (x, ubm, true)
    # chi against a direct high-precision evaluation
    for _ in range(40):
        abar = mpq(rng.randint(1, 200), 1000)
        bbar = mpq(rng.randint(1, 200), 1000)
        for kind in ("B", "C"):
            ch = Chi(kind, abar, bbar)
            t = mpq(rng.randint(-1500, 1500), 1000)
            h = mpq(rng.randint(1, 1000), 1000)
            J = mpmath.mpf(17) / 20 if kind == "B" else mpmath.mpf(77) / 50
            a_m, b_m = mpmath.mpf(int(abar.numerator)) / int(abar.denominator), mpmath.mpf(int(bbar.numerator)) / int(bbar.denominator)
            lam = a_m / J ** 2 if kind == "B" else b_m / J ** 2
            s = mpmath.sqrt(b_m if kind == "B" else a_m)
            c = mpmath.mpf(int((t - h).numerator)) / int((t - h).denominator)
            tot = 0
            for n in range(60):
                d = J * (n - lam) - c
                x = d / s
                tot += mpmath.exp(-lam) * lam ** n / mpmath.factorial(n) * s * s * ((x * x + 1) * mpmath.ncdf(x) + x * mpmath.npdf(x))
            hm = mpmath.mpf(int(h.numerator)) / int(h.denominator)
            true = tot / (2 * hm)
            ub = ch.hi(t, h)
            ubm = mpmath.mpf(int(ub.numerator)) / int(ub.denominator)
            assert ubm >= true and ubm - true <= 1e-6 * (1 + true), (kind, abar, bbar, t, h, ubm, true)
            fl = ch.f(t, float(h))
            assert abs(fl - float(true)) <= 1e-9 * (1 + float(true)), (fl, true)
    # linear bounds dominate chi at random (a, b) with a + b <= r
    nlin = 0
    for _ in range(400):
        r = mpq(rng.randint(1, 200), 10000)
        a = r * mpq(rng.randint(0, 100), 100)
        b = (r - a) * mpq(rng.randint(0, 100), 100)
        if a == 0 or b == 0:
            continue
        for kind, J in (("B", TH), ("C", A)):
            t = mpq(rng.randint(300, 1500), 1000)
            h = mpq(rng.randint(1, 900), 1000)
            co = lin_coef(J, t, h, r)
            if co is None:
                continue
            jump, gauss = co
            ch = Chi(kind, a, b)
            lin = a * jump + b * gauss if kind == "B" else b * jump + a * gauss
            assert ch.hi(t, h) <= lin * (1 + mpq(1, 10 ** 6)) + mpq(1, 10 ** 15), (kind, a, b, t, h)
            nlin += 1
    print("chi selftest OK (qq table %d points; 300 qq points, 80 chi values vs mpmath, %d linear bounds)"
          % (len(T), nlin))


if __name__ == "__main__":
    _selftest()
