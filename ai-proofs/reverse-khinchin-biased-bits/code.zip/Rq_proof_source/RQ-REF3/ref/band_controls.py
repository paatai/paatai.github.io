"""Controls for ref/band_verify.py (not part of the proof), RQ-REF3.

Each control reruns single (a, b) squares without refinement (band_verify.py --squares) and records which are certified:
  C1  origin squares [0, 1/128]^2 and [0, 1/256]^2 at shift 0 (expected: certified);
  C2  the same with the target lowered by 0.0005 (expected: not certified; the Dirac curve has margin 0);
  C3  the same at shift 0 with the slope check disabled (expected: not certified);
  C4  the two neighbours of the origin square at side 1/128, shift 0 (expected: not certified without refinement);
  C5  the squares of the finest level of the certified run, at shift 0 (expected: certified) and at shift 0.001
      (expected: a positive fraction not certified, i.e. the margin along the hypotenuse is below 1e-3).
With a shift the target is T - shift and test (T1), which only gives F <= g(L), is disabled.
Usage: python3 band_controls.py [--jsonl ../logs/band_verify_squares.jsonl] [--out ../logs/band_controls.txt]
"""

import argparse
import json
import re
import subprocess
import sys
import time
from fractions import Fraction


def run(squares, shift="0", noslope=False, procs=8):
    cmd = [sys.executable, "band_verify.py", "--procs", str(procs), "--shift", shift, "--squares"]
    cmd += ["%d,%d,%d,%d" % s for s in squares]
    if noslope:
        cmd.append("--noslope")
    out = subprocess.run(cmd, capture_output=True, text=True).stdout
    bad = {}
    for line in out.splitlines():
        mm = re.match(r"\s*not certified: square \((\d+), (\d+), (\d+), (\d+)\), first failing box (.*)$", line)
        if mm:
            bad[tuple(int(mm.group(k)) for k in range(1, 5))] = mm.group(5)
    head = [l for l in out.splitlines() if l.startswith("RQ-REF3")]
    return bad, head[0] if head else "?"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--jsonl", default="../logs/band_verify_squares.jsonl")
    ap.add_argument("--out", default="")
    args = ap.parse_args()
    lines = []

    def log(s):
        print(s, flush=True)
        lines.append(s)

    t0 = time.time()
    ok = True
    recs = [json.loads(l) for l in open(args.jsonl)]
    cert = {(r["a1"], r["b1"], r["side"], r["den"]) for r in recs if r["ok"]}
    assert all(s[2] == 1 for s in cert)
    dmax = max(s[3] for s in cert)

    def meets(a1, b1, den):  # the closed square [a1, a1+1] x [b1, b1+1] / den meets {a, b >= 0, a + b <= 1/5}
        return Fraction(a1 + b1, den) <= Fraction(1, 5)

    def covered(a1, b1, den):
        if (a1, b1, 1, den) in cert:
            return True
        if den >= dmax:
            return False
        return all(covered(2 * a1 + i, 2 * b1 + j, 2 * den) for i in (0, 1) for j in (0, 1)
                   if meets(2 * a1 + i, 2 * b1 + j, 2 * den))

    roots = [(i, j) for i in range(128) for j in range(128) if meets(i, j, 128)]
    cov = all(covered(i, j, 128) for i, j in roots)
    log("C0 coverage re-check from %s: %d level-0 squares meet the triangle, all covered by the %d certified "
        "squares: %s" % (args.jsonl.split("/")[-1], len(roots), len(cert), cov))
    ok &= cov and len(roots) == 351
    origin = [(0, 0, 1, 128), (0, 0, 1, 256)]
    bad, head = run(origin)
    log(head)
    log("C1 origin squares, shift 0: %d / 2 certified (expected 2)" % (2 - len(bad)))
    ok &= not bad
    bad, _ = run(origin, shift="0.0005")
    log("C2 origin squares, shift 0.0005: %d / 2 certified (expected 0)" % (2 - len(bad)))
    for s, b in sorted(bad.items()):
        log("   %s first failing (L1, L2, m1, m2) = %s" % (s, b))
    ok &= len(bad) == 2
    bad, _ = run(origin, noslope=True)
    log("C3 origin squares, shift 0, slope check off: %d / 2 certified (expected 0)" % (2 - len(bad)))
    for s, b in sorted(bad.items()):
        log("   %s first failing (L1, L2, m1, m2) = %s" % (s, b))
    ok &= len(bad) == 2
    nb = [(1, 0, 1, 128), (0, 1, 1, 128)]
    bad, _ = run(nb)
    log("C4 neighbours (1,0) and (0,1) of side 1/128, shift 0, no refinement: %d / 2 certified (expected 0)"
        % (2 - len(bad)))
    ok &= len(bad) == 2
    fin = sorted((r["a1"], r["b1"], r["side"], r["den"]) for r in recs if r["ok"] and r["den"] == dmax)
    bad0, _ = run(fin)
    bad1, _ = run(fin, shift="0.001")
    log("C5 the %d squares of the finest level (side 1/%d): shift 0: %d certified (expected all); shift 0.001: %d "
        "not certified" % (len(fin), dmax, len(fin) - len(bad0), len(bad1)))
    sums = [(s[0] + s[1]) / s[3] for s in fin]
    log("   these squares have a1 + b1 in [%.4f, %.4f]" % (min(sums), max(sums)))
    ok &= not bad0 and len(bad1) > 0
    log("RESULT: %s (%.0f s)" % ("ALL CONTROLS BEHAVE AS EXPECTED" if ok else "UNEXPECTED CONTROL OUTCOME",
                                 time.time() - t0))
    if args.out:
        with open(args.out, "w") as fh:
            fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
