"""Semantic test of ref/band_verify.py (evidence only, not part of the proof), RQ-REF3.

Random finitely supported probability K on [-A, A] with K([theta, A]) >= 4/5 (rational atoms) are pushed through the
verifier's own cover: a certified square containing (a, b) (from logs/band_verify_squares.jsonl, or the level-0
square), then the path of (L, m) boxes containing (Lambda, m), with the verifier's own decisions at every box.  The
verifier's methods are wrapped (not modified) to record which bound certified the leaf.  At the leaf, against values
computed from the exact law of Z_K (Poisson enumeration, float64), the test checks:
  * the leaf is not 'infeasible' (K is a point of D*);
  * every bound the leaf's method uses dominates what it bounds: e^-L, L e^-L, P2(L), the M term, c_B, c_C, O'
    (direct check), or the linear bounds alpha a + beta b, Lemma 12 and M0 (slope check);
  * E|Z_K| <= F_true <= F_used, and F_used < T <= max(g(Lambda), C5) (direct), resp. the test (T1)-(T3) passed.
Usage: python3 band_semantic.py [--n 300] [--seed S] [--jsonl ../logs/band_verify_squares.jsonl]
"""

import argparse
import json
import math
import random
import sys
from fractions import Fraction

import numpy as np
from gmpy2 import mpq
from scipy.special import ndtr

import band_verify as bv
from chi import qtable

TH, A = bv.TH, bv.A
THf, Af = float(TH), float(A)
C5f = 1.28 * math.sqrt(2 * math.log(1.25))
REC = {}


def _wrap():
    od, os_ = bv.Square.direct_exact, bv.Square.slope_exact

    def de(self, *args):
        ok = od(self, *args)
        if ok:
            REC["leaf"] = ("direct", args)
        return ok

    def se(self, *args):
        ok = os_(self, *args)
        if ok:
            REC.setdefault("pieces", []).append(args)
        return ok

    bv.Square.direct_exact, bv.Square.slope_exact = de, se


# ---------------------------------------------------------------- exact laws (float64)
def poisson_law(lam, tol=1e-19):
    ps, p, n = [], math.exp(-lam), 0
    while True:
        ps.append(p)
        n += 1
        p = p * lam / n
        if n > lam and p < tol:
            break
    return np.array(ps)


def compound(atoms):
    """Law of sum_j x_j (N_j - lam_j), lam_j = w_j / x_j^2, as (values, probs) (merged on a float grid)."""
    vals, probs = np.array([0.0]), np.array([1.0])
    for x, w in atoms:
        lam = w / (x * x)
        pl = poisson_law(lam)
        jv = x * (np.arange(len(pl)) - lam)
        V = (vals[:, None] + jv[None, :]).ravel()
        P = (probs[:, None] * pl[None, :]).ravel()
        keep = P > 1e-22
        vals, probs = V[keep], P[keep]
    return vals, probs


def epos(vals, probs, sig, shift):
    """E (D + shift + sig G)_+."""
    d = vals + shift
    if sig == 0:
        return float(np.dot(probs, np.maximum(d, 0.0)))
    z = d / sig
    Phi = ndtr(z)
    phi = np.exp(-z * z / 2) / math.sqrt(2 * math.pi)
    return float(np.dot(probs, d * Phi + sig * phi))


def g(L):
    return 2 * math.sqrt(L) * math.exp(-L)


# ---------------------------------------------------------------- random K
def rnd_K(rng, scen):
    """Atoms (x, w) with rational x, w; total mass 1; K([theta, A]) >= 4/5."""
    def rx(lo, hi, den=400):
        return Fraction(rng.randint(math.ceil(lo * den), math.floor(hi * den)), den)

    if scen == "dirac":
        rho2 = Fraction(rng.randint(0, 200), 10000)             # rho^2 <= 1/50
        L = rng.uniform(0.40, 0.62)
        x0 = Fraction(round(math.sqrt(float(1 - rho2) / L) * 2000), 2000)
        x0 = min(max(x0, Fraction(17, 20)), Fraction(77, 50))
        S = [(x0, 1 - rho2)]
        if rng.random() < 0.6:
            eps = Fraction(rng.randint(1, 60), 1000) * (1 - rho2)
            S = [(x0, 1 - rho2 - eps), (rx(0.85, 1.54), eps)]
    else:
        V = Fraction(rng.randint(800, 1000), 1000) if scen == "general" else Fraction(rng.randint(800, 806), 1000)
        rho2 = 1 - V
        k = rng.randint(1, 2)
        cuts = sorted(Fraction(rng.randint(1, 999), 1000) for _ in range(k - 1))
        parts = [b - a for a, b in zip([Fraction(0)] + cuts, cuts + [Fraction(1)])]
        S = [(rx(0.85, 1.54), V * p) for p in parts if p > 0]
    R = []
    if rho2 > 0:
        k = rng.randint(1, 3)
        cuts = sorted(Fraction(rng.randint(1, 999), 1000) for _ in range(k - 1))
        parts = [b - a for a, b in zip([Fraction(0)] + cuts, cuts + [Fraction(1)])]
        for p in parts:
            if p == 0:
                continue
            u = rng.random()
            if u < 0.25 and all(x != 0 for x, _ in R):
                x = Fraction(0)
            elif u < 0.6:
                x = rx(0.3, 0.84)
            else:
                x = -rx(0.3, 1.54)
            R.append((x, rho2 * p))
    tot = sum(w for _, w in S) + sum(w for _, w in R)
    assert tot == 1, tot
    return S, R


# ---------------------------------------------------------------- one sample
def find_square(a, b, squares):
    best = None
    for (a1, b1, side, den) in squares:
        if Fraction(a1, den) <= a <= Fraction(a1 + side, den) and Fraction(b1, den) <= b <= Fraction(b1 + side, den):
            if best is None or den < best[3]:
                best = (a1, b1, side, den)
    return best


def descend(sq, L, m):
    """Follow the verifier's (L, m) box tree to the leaf containing (L, m); returns (method, box)."""
    LS, MS = 1 << bv.LBITS, 1 << bv.MBITS
    i1 = math.floor(L * LS) // bv.L0W * bv.L0W
    j1 = math.floor(m * MS) // bv.M0W * bv.M0W
    i2, j2, dep = i1 + bv.L0W, j1 + bv.M0W, 0
    while True:
        L1, L2, m1, m2 = mpq(i1, LS), mpq(i2, LS), mpq(j1, MS), mpq(j2, MS)
        REC.clear()
        res = sq.infeasible(L1, L2, m1, m2)
        if res is None:
            res = sq.direct(L1, L2, m1, m2)
        if res is None:
            res = sq.slope(L1, L2, m1, m2)
        if res is not None:
            return res, (L1, L2, m1, m2), dict(REC)
        split_m = (dep % 2 == 0 and j2 - j1 > bv.MMIN) or i2 - i1 <= bv.LMIN
        if split_m and j2 - j1 > bv.MMIN:
            jm = (j1 + j2) // 2
            j1, j2 = (j1, jm) if m * MS <= jm else (jm, j2)
        elif i2 - i1 > bv.LMIN:
            im = (i1 + i2) // 2
            i1, i2 = (i1, im) if L * LS <= im else (im, i2)
        else:
            return "FAIL", (L1, L2, m1, m2), {}
        dep += 1


def check_one(S, R, squares, stats):
    V = sum(w for _, w in S)
    Lam = sum(w / (x * x) for x, w in S)
    m = sum(w / x for x, w in S)
    a = sum(w for x, w in R if 0 < x < TH)
    b = sum(w for x, w in R if x <= 0)
    rho2 = a + b
    assert V + rho2 == 1
    sqk = find_square(a, b, squares)
    if sqk is None:
        stats["no_square"] += 1
        return None
    sq = bv.Square(mpq(sqk[0], sqk[3]), mpq(sqk[1], sqk[3]), mpq(sqk[2], sqk[3]))
    Lq, mq = mpq(Lam.numerator, Lam.denominator), mpq(m.numerator, m.denominator)
    res, box, rec = descend(sq, Lq, mq)
    L1, L2, m1, m2 = box
    # exact laws
    Rnz = [(float(x), float(w)) for x, w in R if x != 0]
    sig = math.sqrt(float(sum(w for x, w in R if x == 0)))
    Wv, Wp = compound(Rnz)
    Lf, mf, Vf = float(Lam), float(m), float(V)
    cB_t = 2 * epos(Wv, Wp, sig, -mf)
    cC_t = 2 * epos(-Wv, Wp, sig, -(2 * THf - mf))
    O_t = 0.0
    for x, w in S:
        O_t += float(w / (x * x)) / Lf * 2 * epos(-Wv, Wp, sig, -(float(x) - mf))
    Zv, Zp = compound([(float(x), float(w)) for x, w in S] + Rnz)
    EZ = 2 * epos(Zv, Zp, sig, 0.0) - float(np.dot(Zp, Zv))
    P2t = 1 - math.exp(-Lf) * (1 + Lf)
    F_t = 2 * mf * math.exp(-Lf) + math.exp(-Lf) * cB_t + Lf * math.exp(-Lf) * O_t + P2t * cC_t
    tgt = max(g(Lf), C5f)
    tol = 1e-12
    bad = []
    if EZ > F_t + tol:
        bad.append(("prop9", EZ, F_t))
    if res == "FAIL":
        bad.append(("uncertified_leaf",))
    elif res.startswith("F"):
        bad.append(("infeasible_leaf", res))
    elif res in ("O1", "O2", "O3", "O4", "O5"):
        args = rec["leaf"][1]
        _, _, _, _, chB, chC, name, choice = args
        E1, LE, P2, T, _, _ = bv.lam_quant(L1, L2)
        cB = sq.chiB.hi(m1, bv.H_GRID[chB[1]]) if chB[0] == "chi" else sq.cs_hi(m1)
        yC = 2 * TH - m2
        cC = sq.chiC.hi(yC, bv.H_GRID[chC[1]]) if chC[0] == "chi" else sq.cs_hi(yC)
        O = sq.oprime_exact(L1, L2, m1, m2, name, choice)
        Vh = sq.V_hi
        Ls = m2 * m2 / Vh
        M = 2 * m2 * bv.exp_hi(-L1)
        if Ls >= L1:
            M = min(M, bv.sqrt_hi(Vh) * bv.ghat_hi(L1, min(L2, Ls)))
        Fu = M + E1 * cB + LE * O + P2 * cC
        for nm, ub, tv in (("e^-L", E1, math.exp(-Lf)), ("Le^-L", LE, Lf * math.exp(-Lf)), ("P2", P2, P2t),
                           ("M", M, 2 * mf * math.exp(-Lf)), ("c_B", cB, cB_t), ("c_C", cC, cC_t), (name, O, O_t)):
            gap = float(ub) - tv
            stats["mingap"][nm] = min(stats["mingap"].get(nm, 9.0), gap)
            if gap < -tol:
                bad.append((nm, float(ub), tv))
        if not Fu < T:
            bad.append(("F_used>=T", float(Fu), float(T)))
        if float(T) > tgt + tol:
            bad.append(("T>target", float(T), tgt))
        stats["mingap"]["target-F_true"] = min(stats["mingap"].get("target-F_true", 9.0), tgt - F_t)
    elif res == "slope":
        pieces = rec.get("pieces", [])
        hit = [p for p in pieces if p[4] <= rho2 <= p[5]]
        if not hit:
            bad.append(("no_slope_piece", float(rho2)))
        else:
            (_, _, _, _, r1, r2, r, Vh1, ctx, kB, kC, kO) = hit[0]
            vB = sq.lin_one("B", kB, ctx, r, Vh1, L1, True)
            vC = sq.lin_one("C", kC, ctx, r, Vh1, L1, True)
            vO = sq.lin_one("O", kO, ctx, r, Vh1, L1, True)
            af, bf = float(a), float(b)
            lB = float(vB[0]) * af + float(vB[1]) * bf
            lC = float(vC[0]) * af + float(vC[1]) * bf
            lO = float(vO[0]) * af + float(vO[1]) * bf
            sJ2 = (Lf * Vf - mf * mf) / (Lf * Lf)
            d = mf / Lf - THf
            if kO[0] == "O5":
                w = d * d / (d * d + sJ2) if d > 0 else 1.0
                kap = float(vO[2])
                lO += (1 - w) * kap
                absl = 2 * mf * math.exp(-Lf) + Lf * math.exp(-Lf) * kap * (1 - w)
                if absl > math.sqrt(Vf) * g(Lf) + tol:
                    bad.append(("lemma12", absl, math.sqrt(Vf) * g(Lf)))
                stats["mingap"]["lemma12"] = min(stats["mingap"].get("lemma12", 9.0),
                                                 math.sqrt(Vf) * g(Lf) - absl)
            for nm, ub, tv in (("lin c_B", lB, cB_t), ("lin c_C", lC, cC_t), ("lin " + kO[0], lO, O_t)):
                stats["mingap"][nm] = min(stats["mingap"].get(nm, 9.0), ub - tv)
                if ub < tv - tol:
                    bad.append((nm, ub, tv))
            stats["mingap"]["target-F_true"] = min(stats["mingap"].get("target-F_true", 9.0), tgt - F_t)
    elif res == "empty_F4":
        bad.append(("empty_F4_leaf",))
    key = "infeasible" if (res.startswith("F") and res != "FAIL") else res
    stats["by"][key] = stats["by"].get(key, 0) + 1
    if F_t > tgt + tol:
        bad.append(("F_true>target", F_t, tgt))
    stats["mingap"]["F_true-EZ"] = min(stats["mingap"].get("F_true-EZ", 9.0), F_t - EZ)
    return bad


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=300)
    ap.add_argument("--seed", type=int, default=20261023)
    ap.add_argument("--jsonl", type=str, default="../logs/band_verify_squares.jsonl")
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    qtable()
    _wrap()
    squares = []
    with open(args.jsonl) as fh:
        for line in fh:
            r = json.loads(line)
            if r["ok"]:
                squares.append((r["a1"], r["b1"], r["side"], r["den"]))
    rng = random.Random(args.seed)
    lines = []

    def log(s):
        print(s, flush=True)
        lines.append(s)

    log("RQ-REF3 band_semantic.py (evidence only): %d certified squares read; seed %d" % (len(squares), args.seed))
    allbad = 0
    for scen in ("dirac", "general", "hypot"):
        stats = {"by": {}, "mingap": {}, "no_square": 0}
        nb = 0
        for _ in range(args.n):
            S, R = rnd_K(rng, scen)
            bad = check_one(S, R, squares, stats)
            if bad:
                nb += 1
                if nb <= 5:
                    log("  VIOLATION %s: %s  K_S=%s K_R=%s" % (scen, bad, S, R))
        allbad += nb
        log("scenario %-8s: %d samples, %d with a violation, %d without a certified square; leaves by method %s"
            % (scen, args.n, nb, stats["no_square"], json.dumps(dict(sorted(stats["by"].items())))))
        log("  smallest gaps (bound - true value): " +
            ", ".join("%s %.2e" % (k, v) for k, v in sorted(stats["mingap"].items())))
    log("RESULT: %s" % ("no violation" if allbad == 0 else "%d VIOLATIONS" % allbad))
    if args.out:
        with open(args.out, "w") as fh:
            fh.write("\n".join(lines) + "\n")
    sys.exit(0 if allbad == 0 else 1)


if __name__ == "__main__":
    main()
