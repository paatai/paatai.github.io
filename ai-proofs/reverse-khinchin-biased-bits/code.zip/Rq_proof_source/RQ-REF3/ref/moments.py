"""Moments of a centred random variable from its cumulants (RQ-REF3).

E Y^n for a centred Y with cumulants kappa_2, kappa_3, ... is the sum, over the set partitions of {1, ..., n} into
blocks of size >= 2, of the product of kappa_{|block|}.  The number of set partitions with block sizes
b_1, ..., b_r (multiplicities m_j) is n! / (prod_i b_i! prod_j m_j!).  A monomial is a sorted tuple of block sizes.

This is a different route from the recursion P_n = sum_{i=2}^n C(n-1, i-1) kappa_i P_{n-i} used by RQ-D; the
self-test checks that the two agree for n <= 16, and checks both against exact moments of centred Poisson and
Gaussian laws computed from Stirling numbers.
"""

from collections import Counter
from functools import lru_cache
from math import comb, factorial

from gmpy2 import mpq, mpz

NMAX = 16


def _parts(n, mn):
    """Nondecreasing tuples of integers >= mn with sum n."""
    if n == 0:
        yield ()
        return
    for first in range(mn, n + 1):
        for rest in _parts(n - first, first):
            yield (first,) + rest


@lru_cache(maxsize=None)
def moment_poly(n):
    """dict: sorted tuple of block sizes (all >= 2) -> integer coefficient of prod kappa in E Y^n."""
    out = {}
    for blocks in _parts(n, 2):
        den = 1
        for b in blocks:
            den *= factorial(b)
        for _, m in Counter(blocks).items():
            den *= factorial(m)
        c, r = divmod(factorial(n), den)
        assert r == 0
        out[blocks] = c
    return out


def moment_poly_recursion(N):
    """P_0..P_N by the recursion of RQ-D Lemma 21, as dicts like moment_poly."""
    P = [{(): 1}, {}]
    for n in range(2, N + 1):
        acc = {}
        for i in range(2, n + 1):
            c = comb(n - 1, i - 1)
            for mono, v in P[n - i].items():
                key = tuple(sorted(mono + (i,)))
                acc[key] = acc.get(key, 0) + c * v
        P.append({k: v for k, v in acc.items() if v})
    return P


def split_mono(mono):
    """(number of kappa_2 factors, tuple of the factors of order >= 3)."""
    a = sum(1 for b in mono if b == 2)
    return a, tuple(b for b in mono if b >= 3)


def product_tuples(N=NMAX):
    """Sorted tuples (t >= 2, entries >= 3) occurring in some P_k, k <= N, together with their prefixes."""
    S = set()
    for k in range(N + 1):
        for mono in moment_poly(k):
            _, al = split_mono(mono)
            if len(al) >= 2:
                S.add(al)
    for al in list(S):
        for t in range(2, len(al)):
            S.add(al[:t])
    return sorted(S, key=lambda al: (len(al), al))


def expansion(c, mu):
    """E phi(Y) for phi = sum_k c_k r^k (any degree len(c) - 1), kappa_2 = mu.

    Returns (const, lin, prod) with E phi(Y) = const + sum_j lin[j] kappa_j + sum_alpha prod[alpha] kappa^alpha,
    j >= 3 and alpha sorted tuples of length >= 2 with entries >= 3.  All exact rationals."""
    const = mpq(0)
    lin = {}
    prod = {}
    mupow = [mpq(1)]
    for _ in range(len(c)):
        mupow.append(mupow[-1] * mu)
    for k, ck in enumerate(c):
        if ck == 0:
            continue
        for mono, v in moment_poly(k).items():
            a, al = split_mono(mono)
            term = ck * v * mupow[a]
            if not al:
                const += term
            elif len(al) == 1:
                lin[al[0]] = lin.get(al[0], mpq(0)) + term
            else:
                prod[al] = prod.get(al, mpq(0)) + term
    return const, lin, prod


# ---------------------------------------------------------------- self-test
def _stirling2(n, k):
    S = [[0] * (n + 1) for _ in range(n + 1)]
    S[0][0] = 1
    for i in range(1, n + 1):
        for j in range(1, i + 1):
            S[i][j] = j * S[i - 1][j] + S[i - 1][j - 1]
    return S[n][k]


def _poisson_central(lam, n):
    """E (N - lam)^n for N ~ Poisson(lam), exactly: E N^i = sum_k S(i, k) lam^k."""
    tot = mpq(0)
    for i in range(n + 1):
        ENi = sum(_stirling2(i, k) * lam ** k for k in range(i + 1))
        tot += comb(n, i) * ENi * (-lam) ** (n - i)
    return tot


def _gauss(s2, n):
    if n % 2:
        return mpq(0)
    df = 1
    for i in range(n - 1, 0, -2):
        df *= i
    return df * s2 ** (n // 2)


def _eval(Pn, kap):
    tot = mpq(0)
    for mono, v in Pn.items():
        t = mpq(v)
        for b in mono:
            t *= kap[b]
        tot += t
    return tot


def _selftest():
    rec = moment_poly_recursion(NMAX)
    for n in range(NMAX + 1):
        assert moment_poly(n) == rec[n], n
    lam = mpq(3, 7)
    for n in range(NMAX + 1):
        kap = {j: lam for j in range(2, NMAX + 1)}
        assert _eval(moment_poly(n), kap) == _poisson_central(lam, n), n
        kap = {j: (mpq(5, 3) if j == 2 else mpq(0)) for j in range(2, NMAX + 1)}
        assert _eval(moment_poly(n), kap) == _gauss(mpq(5, 3), n), n
    # Y = x (N_a - a) + y (N_b - b) + sigma G, independent; kappa_j = a x^j + b y^j (+ sigma^2 at j = 2)
    a, b, x, y, s2 = mpq(2, 5), mpq(1, 9), mpq(17, 20), mpq(-77, 50), mpq(1, 8)
    ma = [x ** i * _poisson_central(a, i) for i in range(NMAX + 1)]
    mb = [y ** i * _poisson_central(b, i) for i in range(NMAX + 1)]
    mg = [_gauss(s2, i) for i in range(NMAX + 1)]
    for n in range(NMAX + 1):
        direct = mpq(0)
        for i in range(n + 1):
            for k in range(n - i + 1):
                l = n - i - k
                direct += factorial(n) // (factorial(i) * factorial(k) * factorial(l)) * ma[i] * mb[k] * mg[l]
        kap = {j: a * x ** j + b * y ** j + (s2 if j == 2 else 0) for j in range(2, NMAX + 1)}
        assert _eval(moment_poly(n), kap) == direct, n
    # expansion() reproduces E phi for a random phi
    import random
    rng = random.Random(3)
    c = [mpq(rng.randint(-99, 99), rng.randint(1, 30)) for _ in range(NMAX + 1)]
    kap = {j: a * x ** j + b * y ** j + (s2 if j == 2 else 0) for j in range(2, NMAX + 1)}
    const, lin, prod = expansion(c, kap[2])
    val = const + sum(v * kap[j] for j, v in lin.items())
    for al, v in prod.items():
        t = v
        for j in al:
            t *= kap[j]
        val += t
    ref = sum(c[n] * _eval(moment_poly(n), kap) for n in range(NMAX + 1))
    assert val == ref
    T = product_tuples()
    print("moments selftest OK; %d product tuples (t >= 2), max length %d" % (len(T), max(len(t) for t in T)))
    return T


if __name__ == "__main__":
    _selftest()
