"""Rigorous enclosures in exact rational arithmetic (RQ-REF3).

Every function returns a pair (lo, hi) of gmpy2.mpq with lo <= true value <= hi.
Intermediate results are rounded outward to dyadic rationals with P fractional bits,
so all arithmetic is exact rational arithmetic and every rounding is directed.

Nothing here uses floating point for a decision.  Floats are only converted exactly
(every IEEE double is a dyadic rational) via `q()`.
"""

import math
import gmpy2
from gmpy2 import mpq, mpz

ZERO = mpq(0)
ONE = mpq(1)
HALF = mpq(1, 2)


def q(x):
    """Exact conversion to mpq.  Floats are converted exactly; NaN/inf raise."""
    if isinstance(x, type(ZERO)):
        return x
    if isinstance(x, float):
        if not math.isfinite(x):
            raise ValueError("non-finite number in certificate: %r" % (x,))
        return mpq(x)
    if isinstance(x, str):
        s = x.strip()
        if s.startswith(("0x", "-0x", "+0x")):
            f = float.fromhex(s)
            if not math.isfinite(f):
                raise ValueError("non-finite hex double: %r" % (x,))
            return mpq(f)
        if "/" in s:
            n, d = s.split("/")
            return mpq(int(n), int(d))
        if any(c in s for c in ".eE") or s.lower() in ("nan", "inf", "-inf", "+inf"):
            f = float(s)
            if not math.isfinite(f):
                raise ValueError("non-finite number: %r" % (x,))
            return mpq(f)
        return mpq(int(s))
    if isinstance(x, (int, type(mpz(0)))):
        return mpq(x)
    raise TypeError("cannot convert %r" % (x,))


def rdown(x, P):
    """Largest multiple of 2^-P that is <= x."""
    s = mpz(1) << P
    n = x.numerator * s
    return mpq(n // x.denominator, s)


def rup(x, P):
    s = mpz(1) << P
    n = x.numerator * s
    return mpq(-((-n) // x.denominator), s)


def rnd(iv, P):
    return (rdown(iv[0], P), rup(iv[1], P))


# ---------------------------------------------------------------- interval helpers
def iv(x):
    x = q(x)
    return (x, x)


def iadd(a, b):
    return (a[0] + b[0], a[1] + b[1])


def isub(a, b):
    return (a[0] - b[1], a[1] - b[0])


def ineg(a):
    return (-a[1], -a[0])


def imul(a, b):
    p = (a[0] * b[0], a[0] * b[1], a[1] * b[0], a[1] * b[1])
    return (min(p), max(p))


def iscale(c, a):
    c = q(c)
    if c >= 0:
        return (c * a[0], c * a[1])
    return (c * a[1], c * a[0])


def idiv(a, b):
    if b[0] <= 0 <= b[1]:
        raise ZeroDivisionError("interval division by an interval containing 0")
    return imul(a, (ONE / b[1], ONE / b[0]))


def isqr(a):
    if a[0] >= 0:
        return (a[0] * a[0], a[1] * a[1])
    if a[1] <= 0:
        return (a[1] * a[1], a[0] * a[0])
    return (ZERO, max(a[0] * a[0], a[1] * a[1]))


def imax0(a):
    return (max(a[0], ZERO), max(a[1], ZERO))


# ---------------------------------------------------------------- sqrt
def sqrt_b(x, P=200):
    """Enclosure of sqrt(x) for rational x >= 0 (exact integer square roots)."""
    x = q(x)
    if x < 0:
        raise ValueError("sqrt of negative")
    if x == 0:
        return (ZERO, ZERO)
    s2 = mpz(1) << (2 * P)
    n = (x.numerator * s2) // x.denominator  # floor(x * 4^P)
    r = gmpy2.isqrt(n)  # r^2 <= n <= x*4^P
    lo = mpq(r, mpz(1) << P)
    hi = mpq(r + 1, mpz(1) << P)
    assert lo * lo <= x <= hi * hi
    return (lo, hi)


def isqrt_iv(a, P=200):
    lo = sqrt_b(max(a[0], ZERO), P)[0]
    hi = sqrt_b(a[1], P)[1]
    return (lo, hi)


# ---------------------------------------------------------------- exp
def _exp_small(y, P):
    """Enclosure of e^y for rational |y| <= 1/16 by Taylor series with remainder."""
    ay = abs(y)
    S = ONE
    t = ONE
    n = 0
    eps = mpq(1, mpz(1) << (P + 8))
    while True:
        n += 1
        t = rnd_mul(t, y, n, P + 16)
        S += t
        # remainder after term n: |R| <= |y|^(n+1)/(n+1)! * e^|y| <= 2*|t|*|y|/(n+1);
        # each rounding of t errs by <= 2^-(P+16) and is damped by |y|/n <= 1/16 later,
        # so the accumulated rounding error of S is <= (16/15) n 2^-(P+16).
        R = 2 * abs(t) * ay / (n + 1) + mpq(2 * (n + 1), mpz(1) << (P + 16))
        if R < eps:
            break
    return (rdown(S - R, P + 8), rup(S + R, P + 8))


def rnd_mul(t, y, n, P):
    # t*y/n rounded to nearest-ish; the rounding error (<= 2^-P per term) is
    # accounted for in the remainder term of _exp_small.
    v = t * y / n
    return rdown(v, P)


def exp_b(x, P=200):
    """Enclosure of e^x for rational x."""
    x = q(x)
    if x == 0:
        return (ONE, ONE)
    if x < 0:
        lo, hi = exp_b(-x, P + 8)
        return (ONE / hi, ONE / lo)
    k = 0
    ax = abs(x)
    while ax > mpq(1, 16):
        ax /= 2
        k += 1
    y = x / (mpz(1) << k)
    lo, hi = _exp_small(y, P + 2 * k + 16)
    for _ in range(k):
        lo = rdown(lo * lo, P + 2 * k + 16)
        hi = rup(hi * hi, P + 2 * k + 16)
    assert 0 < lo <= hi
    return (rdown(lo, P), rup(hi, P))


def exp_iv(a, P=200):
    return (exp_b(a[0], P)[0], exp_b(a[1], P)[1])


# ---------------------------------------------------------------- log
def _atanh_series(u, P):
    """Enclosure of atanh(u) for rational 0 <= u <= 1/2 (positive series)."""
    if u == 0:
        return (ZERO, ZERO)
    S = ZERO
    u2 = u * u
    t = u
    k = 0
    eps = mpq(1, mpz(1) << (P + 8))
    while True:
        S += t / (2 * k + 1)
        t = t * u2
        k += 1
        tail = t / ((2 * k + 1) * (1 - u2))
        if tail < eps:
            break
        t = rup(t, P + 40) if k > 4 else t
    # S is a sum of exact rationals except the (upward) roundings of t, which only
    # increase later terms; so S <= true sum + rounding; bound that by 2^-(P+30)
    return (rdown(S - mpq(k + 1, mpz(1) << (P + 38)), P + 4), rup(S + tail, P + 4))


def log_b(x, P=200):
    """Enclosure of ln(x) for rational x > 0."""
    x = q(x)
    if x <= 0:
        raise ValueError("log of nonpositive")
    if x == 1:
        return (ZERO, ZERO)
    e = 0
    m = x
    while m > mpq(4, 3):
        m /= 2
        e += 1
    while m < mpq(2, 3):
        m *= 2
        e -= 1
    u = (m - 1) / (m + 1)  # |u| <= 1/7
    if u >= 0:
        a = _atanh_series(u, P)
    else:
        b = _atanh_series(-u, P)
        a = (-b[1], -b[0])
    lnm = (2 * a[0], 2 * a[1])
    l2 = _atanh_series(mpq(1, 3), P)
    ln2 = (2 * l2[0], 2 * l2[1])
    res = iadd(lnm, iscale(e, ln2))
    return (rdown(res[0], P), rup(res[1], P))


# ---------------------------------------------------------------- pi
def _atan_inv(n, P):
    """Enclosure of atan(1/n), integer n >= 2 (alternating series)."""
    x = mpq(1, n)
    x2 = x * x
    S = ZERO
    t = x
    k = 0
    eps = mpq(1, mpz(1) << (P + 8))
    while True:
        term = t / (2 * k + 1)
        if term < eps:
            break
        S += term if k % 2 == 0 else -term
        t = t * x2
        k += 1
    # alternating, decreasing terms: |error| <= next term
    return (S - term, S + term)


_PI_CACHE = {}


def pi_b(P=200):
    if P in _PI_CACHE:
        return _PI_CACHE[P]
    a = _atan_inv(5, P + 10)
    b = _atan_inv(239, P + 10)
    lo = 16 * a[0] - 4 * b[1]
    hi = 16 * a[1] - 4 * b[0]
    r = (rdown(lo, P), rup(hi, P))
    _PI_CACHE[P] = r
    return r


_PHI0 = {}


def phi0_b(P=200):
    """Enclosure of 1/sqrt(2*pi)."""
    if P in _PHI0:
        return _PHI0[P]
    p = pi_b(P + 20)
    s_lo = sqrt_b(2 * p[0], P + 20)[0]
    s_hi = sqrt_b(2 * p[1], P + 20)[1]
    r = (rdown(ONE / s_hi, P), rup(ONE / s_lo, P))
    _PHI0[P] = r
    return r


# ---------------------------------------------------------------- normal law
def npdf_b(x, P=200):
    """Enclosure of the standard normal density at rational x."""
    x = q(x)
    e = exp_b(-x * x / 2, P + 10)
    return rnd(imul(e, phi0_b(P + 10)), P)


def ncdf_b(x, P=200):
    """Enclosure of Phi(x) for rational x."""
    x = q(x)
    if x == 0:
        return (HALF, HALF)
    if x > 8:
        d = npdf_b(x, P + 10)
        return (rdown(1 - d[1] / x, P), ONE)
    if x < -8:
        d = npdf_b(-x, P + 10)
        return (ZERO, rup(d[1] / (-x), P))
    # series Phi(x) = 1/2 + phi0 * sum_n (-1)^n x^(2n+1) / (2^n n! (2n+1))
    x2 = x * x
    # the magnitude of the terms is at most e^(x^2/2) < 2^47; work with P+80 bits
    W = P + 80
    S = ZERO
    t = x  # x^(2n+1)/(2^n n!)
    n = 0
    nmin = int(x2 / 2) + 2
    eps = mpq(1, mpz(1) << (P + 20))
    err = ZERO
    while True:
        term = t / (2 * n + 1)
        if n >= nmin and abs(term) < eps:
            break
        S += term if n % 2 == 0 else -term
        t = t * x2 / (2 * (n + 1))
        tr = rdown(t, W) if t >= 0 else -rdown(-t, W)
        err += abs(t - tr) * 2
        t = tr
        n += 1
    # terms from n on are decreasing in absolute value (n > x^2/2), alternating:
    # |remainder| <= |term|.  Each rounding of t errs by <= 2^-W and is amplified by at
    # most prod x^2/(2l) <= e^(x^2/2) < 2^47 (|x| <= 8) in every later term; with n terms
    # the accumulated error of S is below n^2 2^(47-W).
    R = abs(term) + mpq((n + 1) * (n + 1), mpz(1) << (W - 48))
    Sl, Sh = S - R, S + R
    p0 = phi0_b(P + 20)
    prod = imul((Sl, Sh), p0)
    return (rdown(HALF + prod[0], P), rup(HALF + prod[1], P))


def _selftest():
    import mpmath
    mpmath.mp.prec = 300
    import random
    rng = random.Random(1)
    for _ in range(200):
        x = mpq(rng.randint(-4000, 4000), rng.randint(1, 500))
        lo, hi = exp_b(x, 120)
        v = mpmath.exp(mpmath.mpf(int(x.numerator)) / int(x.denominator))
        assert mpmath.mpf(int(lo.numerator)) / int(lo.denominator) <= v <= mpmath.mpf(int(hi.numerator)) / int(hi.denominator)
        assert hi - lo < mpq(1, 2 ** 100) * (1 + hi)
    for _ in range(200):
        x = mpq(rng.randint(1, 4000), rng.randint(1, 500))
        lo, hi = log_b(x, 120)
        v = mpmath.log(mpmath.mpf(int(x.numerator)) / int(x.denominator))
        assert mpmath.mpf(int(lo.numerator)) / int(lo.denominator) <= v <= mpmath.mpf(int(hi.numerator)) / int(hi.denominator)
        assert hi - lo < mpq(1, 2 ** 100)
    for _ in range(300):
        x = mpq(rng.randint(-1200, 1200), rng.randint(1, 100))
        lo, hi = ncdf_b(x, 120)
        v = mpmath.ncdf(mpmath.mpf(int(x.numerator)) / int(x.denominator))
        assert mpmath.mpf(int(lo.numerator)) / int(lo.denominator) <= v <= mpmath.mpf(int(hi.numerator)) / int(hi.denominator), (x, lo, hi)
        if abs(x) <= 8:
            assert hi - lo < mpq(1, 2 ** 100)
    lo, hi = pi_b(200)
    v = mpmath.pi
    assert lo <= mpq(int(mpmath.floor(v * 2 ** 290)), 2 ** 290) + mpq(1, 2 ** 289)
    for _ in range(100):
        x = mpq(rng.randint(0, 10 ** 6), rng.randint(1, 1000))
        lo, hi = sqrt_b(x, 100)
        assert lo * lo <= x <= hi * hi
    print("rig selftest OK")


if __name__ == "__main__":
    _selftest()
