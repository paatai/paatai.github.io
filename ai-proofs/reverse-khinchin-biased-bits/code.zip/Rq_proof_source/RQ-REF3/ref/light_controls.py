"""Negative controls for ref/light_verify.py (RQ-REF3).

For a seeded sample of certificates of each case every mutation below must be rejected by verify_cert:
  phi0     phi_0 lowered by 1e-6                      (tests the check phi >= h^)
  phiD     phi_D set to 0                             (half-lines)
  y0       x-dual y_0 lowered by 1e-6                 (x-dual of f)
  rangeU3  y_0 of the U_3 range certificate lowered by 1e-6
  zneg     one nonzero multiplier made negative
  cell     the certificate checked against a neighbouring cell (next box / shifted rectangle)
  target   171/200 replaced by U - 1e-12
A mutation that leaves the certificate unchanged (phi_D already 0) is reported as an identity.
zdrop (the largest multiplier set to 0) is not a negative control: every z >= 0 is admissible, so the mutant is still
a valid certificate with a different bound; it is reported as rejected or as accepted with the bound U' >= U.
Coverage: with every certificate accepted all roots are covered, and deleting any one sampled leaf uncovers a root.

Usage: python3 light_controls.py [--n 40] [--out FILE]
"""

import argparse
import random
import sys
import time

from gmpy2 import mpq

import light_verify as lv
from rig import q

EPS = mpq(1, 10 ** 6)


def hexf(x):
    return float(x).hex()


def mutate(kind, certj):
    c = dict(certj)
    if kind == "phi0":
        c["phi"] = list(c["phi"])
        c["phi"][0] = hexf(q(c["phi"][0]) - EPS)
    elif kind == "phiD":
        if q(c["phi"][-1]) == 0:
            return None
        c["phi"] = list(c["phi"])
        c["phi"][-1] = hexf(0.0)
    elif kind == "y0":
        c["xdual"] = dict(c["xdual"])
        c["xdual"]["y0"] = hexf(q(c["xdual"]["y0"]) - EPS)
    elif kind == "rangeU3":
        c["ranges"] = dict(c["ranges"])
        r3 = dict(c["ranges"]["3"])
        r3["U"] = dict(r3["U"])
        r3["U"]["y0"] = hexf(q(r3["U"]["y0"]) - EPS)
        c["ranges"]["3"] = r3
    elif kind in ("zneg", "zdrop"):
        z = dict(c["z"])
        nzk = [k for k, h in z.items() if q(h) != 0]
        if not nzk:
            return None
        if kind == "zneg":
            z[nzk[0]] = hexf(-float(q(z[nzk[0]])))
        else:
            kmax = max(nzk, key=lambda k: q(z[k]))
            z[kmax] = hexf(0.0)
        c["z"] = z
    return c


def neighbour(d):
    d = dict(d)
    if d["cellq"] is not None:
        L3, U3, L4, U4 = d["cellq"]
        d["cellq"] = (U3, 2 * U3 - L3, L4, U4)
    else:
        d["Pb"] = d["Pb"] + d["db"]
    return d


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, default=40)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    lines = []

    def log(s):
        print(s, flush=True)
        lines.append(s)

    log("RQ-REF3 light_controls.py; start %s UTC" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()))
    allok = True
    for case in ("chord", "light", "nsplit"):
        certs, md5 = lv.load(case)
        roots, use, kids, mism = lv.tree(case, certs)
        rng = random.Random(20261023)
        withphi = sorted(p for p, (d, rec) in use.items() if "phi" in rec["cert"])
        sample = rng.sample(withphi, min(args.n, len(withphi)))
        stats = {}
        for p in sample:
            d, rec = use[p]
            D = rec["spec"]["D"]
            cell = lv.make_cell(d)
            ok, U, msg = lv.verify_cert(cell, D, rec["cert"])
            assert ok and U is not None, (p, msg)
            for kind in ("phi0", "phiD", "y0", "rangeU3", "zneg", "zdrop", "cell", "target"):
                if kind == "cell":
                    try:
                        r = lv.verify_cert(lv.make_cell(neighbour(d)), D, rec["cert"])
                    except (AssertionError, ValueError, ZeroDivisionError) as e:
                        r = (False, None, "exception %r" % (e,))
                    res = "rejected" if not r[0] or r[1] is None else "ACCEPTED"
                elif kind == "target":
                    saved = lv.TARGET
                    lv.TARGET = U - mpq(1, 10 ** 12)
                    r = lv.verify_cert(cell, D, rec["cert"])
                    lv.TARGET = saved
                    res = "rejected" if not r[0] else "ACCEPTED"
                else:
                    m = mutate(kind, rec["cert"])
                    if m is None:
                        res = "identity"
                    else:
                        r = lv.verify_cert(cell, D, m)
                        if not r[0]:
                            res = "rejected"
                        elif kind == "zdrop":
                            res = "valid, U' >= U" if r[1] >= U else "valid, U' < U"
                        else:
                            res = "ACCEPTED"
                stats.setdefault(kind, {}).setdefault(res, []).append(p)
        log("case %s: %d sampled certificates" % (case, len(sample)))
        for kind, v in stats.items():
            log("  %-8s %s" % (kind, ", ".join("%s %d" % (k, len(x)) for k, x in sorted(v.items()))))
            if "ACCEPTED" in v:
                allok = False
                log("    accepted mutants: %s" % v["ACCEPTED"][:5])
        # coverage logic
        leaves = set(use)

        def covered(p, drop):
            if p in leaves:
                return p != drop
            ch = kids.get(p) or []
            return bool(ch) and all(covered(c, drop) for c in ch)

        sys.setrecursionlimit(100000)
        full = sum(1 for r in roots if covered(r, None))
        drops = rng.sample(sorted(leaves), min(args.n, len(leaves)))
        unc = [sum(1 for r in roots if not covered(r, dp)) for dp in drops]
        cov_ok = full == len(roots) and all(u >= 1 for u in unc)
        allok &= cov_ok
        log("  coverage: all leaves accepted -> %d / %d roots covered; deleting one of %d sampled leaves uncovers "
            ">= 1 root in %d cases" % (full, len(roots), len(drops), sum(1 for u in unc if u >= 1)))
    log("RESULT: %s" % ("ALL CONTROLS BEHAVE AS EXPECTED" if allok else "A MUTANT WAS ACCEPTED"))
    if args.out:
        with open(args.out, "w") as fh:
            fh.write("\n".join(lines) + "\n")


if __name__ == "__main__":
    main()
