"""Independent re-verification of RQ-B Theorem 13.1 (light far region, E|Z_K| <= 171/200), RQ-REF3.

Reads only the numbers in RQ-B's numerics/cover_final/{nsplit_D14,chord_D14,light_vl025_D18}.jsonl.xz (paths and
hex doubles; the stored specs are only compared, never used).  None of RQ-B's code is imported or run.

For each case of Lemma D it regenerates, from Lemmas S1-S5 and E, the required root cells, the caps, atoms and
masses of every cell, and the subdivision rule, and checks that every root is covered by certificates that pass
Lemma C, re-checked here in exact rational arithmetic:
  (C2) the range x-duals for f = +-x^(j-2), 3 <= j <= D;
  (C1) phi >= h^ >= h_P on R, with MY majorant h^ (own Poisson enclosures and tail bounds) checked by adaptive
       chords of the convex function h^ plus exact Bernstein subdivision, and the two half-lines;
  (C3) the inequality list rebuilt from the certified ranges (row order is RQ-B's file convention: McCormick rows
       for the product tuples in (length, lex) order, then per j six tangents and one Cauchy-Schwarz row),
       z >= 0, and E_w, d, e_0, f in exact arithmetic (moment expansion by the set-partition formula);
  (C4) the x-dual of f (closed pieces between breakpoints outside W, atoms, the mass at 0);
  and U <= 171/200.
Polynomial checks are exact: a monomial-wise interval lower bound, else Bernstein subdivision (ref/bern.py).

Usage: python3 light_verify.py CASE [--procs 8] [--limit N] [--controls] [--out FILE]
  CASE in nsplit, chord, light
"""

import os as _os
_ROOT = _os.path.abspath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", ".."))  # archive root
import argparse
import bisect
import hashlib
import json
import lzma
import os
import sys
import time
from multiprocessing import Pool

from gmpy2 import mpq, mpz

from bern import is_le, nonneg_halfline, peval, taylor_shift
from moments import expansion, product_tuples
from rig import exp_b, q, rup

A = mpq(77, 50)
TH = mpq(17, 20)
TARGET = mpq(171, 200)
DELTA = mpq(1, 20)
VL = mpq(1, 4)
VV = mpq(1, 2)
V1 = mpq(1, 4)
W_LIGHT = mpq(1, 20)
CERTDIR = _os.path.join(_ROOT, "RQ-B/numerics/cover_final")
FILES = {"nsplit": "nsplit_D14.jsonl.xz", "chord": "chord_D14.jsonl.xz", "light": "light_vl025_D18.jsonl.xz"}
PB = 250  # bits for Poisson weights


# ---------------------------------------------------------------- the window family (exact)
def _round_nearest(x):
    """Nearest integer to the rational x (no ties occur for the windows, asserted)."""
    n = x.numerator // x.denominator
    fr = x - n
    assert fr != mpq(1, 2), "tie in window rounding"
    return n + (1 if fr > mpq(1, 2) else 0)


def window_family_pos():
    out = []
    k = 0
    while True:
        ak = mpq(_round_nearest(mpq(3, 10) * mpq(103, 100) ** k * 10000), 10000)
        bk = mpq(6, 5) * ak
        if bk >= A:
            break
        out.append((ak, bk))
        k += 1
    out.append((A * mpq(5, 6), A))
    return out


WFP = window_family_pos()
WF = WFP + [(-b, -a) for a, b in WFP]


def is_near(lo, hi):
    return (0 < lo < TH) or (hi < 0 and -hi < TH)


# ---------------------------------------------------------------- Lemmas S2, S3, S5 and the caps of Lemma E
def box_params(a, b, Pa, Pb, da, db):
    qa, qb = Pa + da, Pb + db
    exc = qa * qb * (b - a) ** 2 / (qa + qb)
    mu = 1 - a * a * Pa - b * b * Pb + exc
    return mu, a * a * Pa + b * b * Pb - exc, a * a * qa + b * b * qb


def s_lo(a, b, Pb, qa, V_hi):
    if not (a < TH < b):
        return mpq(0)
    assert b < 2 * a
    beta = b * b * (TH - a) / ((b - a) * TH ** 2)
    assert beta < 1
    rho = qa * (b - a) * TH ** 2 / (b - TH)
    return max(mpq(0), (b * b * Pb - beta * V_hi) / (1 - beta), b * b * Pb - beta * rho)


class Cell:
    def __init__(self, kind, k=None, Pa=None, Pb=None, da=None, db=None, cellq=None):
        self.kind, self.k, self.cellq = kind, k, cellq
        if kind == "light":
            self.mu = mpq(1)
            self.caps = [(TH, A, VV), (-A, -TH, VV)] + [(lo, hi, VL) for lo, hi in WF]
            self.excl = None
            self.atoms = []
        else:
            a, b = (TH, A) if kind == "chord" else WFP[k]
            if kind == "nsplit":
                assert a < TH
            self.a, self.b, self.Pa, self.Pb, self.da, self.db = a, b, Pa, Pb, da, db
            self.mu, self.V_lo, self.V_hi = box_params(a, b, Pa, Pb, da, db)
            if kind == "nsplit":
                sl = s_lo(a, b, Pb, Pa + da, self.V_hi)
                self.caps = [(TH, A, max(VV - sl, mpq(0))), (-A, -TH, VV)]
                self.caps += [(lo, hi, self.V_hi) for lo, hi in WF if (lo, hi) != (a, b) and is_near(lo, hi)]
            else:
                self.caps = [(-A, -TH, min(VV, self.V_hi))] + [(lo, hi, VL) for lo, hi in WF if is_near(lo, hi)]
            self.excl = (a, b)
            self.atoms = [(a, a * a * da), (b, b * b * db)]
        pts = {-A, A, mpq(0), TH, -TH}
        for lo, hi, _ in self.caps:
            pts.add(lo)
            pts.add(hi)
        if self.excl:
            pts.update(self.excl)
        pts.update(p for p, _ in self.atoms)
        bps = sorted(p for p in pts if -A <= p <= A)
        self.pieces = []
        for lo, hi in zip(bps, bps[1:]):
            if self.excl and lo >= self.excl[0] and hi <= self.excl[1]:
                continue
            inside = [i for i, (cl, ch, _) in enumerate(self.caps) if cl <= lo and hi <= ch]
            self.pieces.append((lo, hi, inside))
        self._pw = {}

    def powers(self, D):
        if D not in self._pw:
            pw = []
            for lo, hi, _ in self.pieces:
                pl, ph = [mpq(1)], [mpq(1)]
                for _ in range(D + 2):
                    pl.append(pl[-1] * lo)
                    ph.append(ph[-1] * hi)
                pw.append((pl, ph))
            self._pw[D] = pw
        return self._pw[D]

    def rest_rect(self):
        c_pos = sum((c for lo, hi, c in self.caps if (lo, hi) == (TH, A)), mpq(0))
        c_neg = sum((c for lo, hi, c in self.caps if (lo, hi) == (-A, -TH)), mpq(0))
        c_pos += sum((cap for p, cap in self.atoms if p >= TH), mpq(0))
        mu = self.mu
        m1, m2, m3 = min(mu, c_pos), min(mu, c_neg), min(mu, c_pos + c_neg)
        return (-A * m2 - TH * (mu - m2), A * m1 + TH * (mu - m1), mpq(0), A * A * m3 + TH ** 2 * (mu - m3))


# ---------------------------------------------------------------- roots and subdivision (Lemma E)
def required_roots(case, light_smax=24):
    out = {}
    if case in ("nsplit", "chord"):
        wins = [(None, TH, A)] if case == "chord" else [(k, a, b) for k, (a, b) in enumerate(WFP) if a < TH]
        for k, a, b in wins:
            infl = (a + b) ** 2 / (4 * a * b)
            if case == "chord":
                x = VV * infl / DELTA
                nmax = -((-x.numerator) // x.denominator) - 1  # ceil(x) - 1: i + j <= x' < x strictly
            else:
                x = infl / DELTA
                nmax = x.numerator // x.denominator
            da, db = DELTA / a ** 2, DELTA / b ** 2
            for i in range(nmax + 1):
                for j in range(nmax + 1 - i):
                    Pa, Pb = i * da, j * db
                    mu, V_lo, V_hi = box_params(a, b, Pa, Pb, da, db)
                    if case == "nsplit" and (V_hi <= VL or V_lo > 1):
                        continue
                    if case == "chord" and (V_hi < V1 or V_lo >= VV):
                        continue
                    path = "C/i%dj%d" % (i, j) if case == "chord" else "N/k%d/i%dj%d" % (k, i, j)
                    out[path] = dict(kind=case, k=k, Pa=Pa, Pb=Pb, da=da, db=db, cellq=None)
    else:
        w = W_LIGHT
        for s in range(light_smax):
            for t in range(31):
                L3, U3, L4, U4 = s * w, (s + 1) * w, t * w, (t + 1) * w
                if U4 < L3 * L3:
                    continue
                out["L/s%dt%d" % (s, t)] = dict(kind="light", cellq=(L3, U3, L4, U4))
    return out


def make_cell(d):
    if d["kind"] == "light":
        return Cell("light", cellq=d["cellq"])
    return Cell(d["kind"], k=d["k"], Pa=d["Pa"], Pb=d["Pb"], da=d["da"], db=d["db"], cellq=d["cellq"])


def children(path, d):
    if d["cellq"] is None:
        rect, n = make_cell(d).rest_rect(), 4
    else:
        rect, n = d["cellq"], 2
    L3, U3, L4, U4 = rect
    out = {}
    for s in range(n):
        for t in range(n):
            qq = (L3 + (U3 - L3) * s / n, L3 + (U3 - L3) * (s + 1) / n, L4 + (U4 - L4) * t / n,
                  L4 + (U4 - L4) * (t + 1) / n)
            if d["kind"] == "light" and qq[3] < max(qq[0], mpq(0)) ** 2:
                continue
            ch = dict(d)
            ch["cellq"] = qq
            out["%s/q%d%d" % (path, s, t)] = ch
    return out


# ---------------------------------------------------------------- exact polynomial nonnegativity on an interval
def mono_lower(g, pl, ph, lo, hi):
    """Lower bound of sum_k g_k x^k on [lo, hi] as the sum of the exact minima of the monomials."""
    zero_in = lo <= 0 <= hi
    tot = mpq(0)
    for k, c in enumerate(g):
        if c == 0:
            continue
        if k == 0:
            tot += c
            continue
        u, v = pl[k], ph[k]
        if c > 0:
            m = mpq(0) if (zero_in and k % 2 == 0) else min(u, v)
            tot += c * m
        else:
            tot += c * max(u, v)
    return tot


def nonneg_on(g, lo, hi, pl, ph):
    if mono_lower(g, pl, ph, lo, hi) >= 0:
        return True
    r = is_le([-x for x in g], lo, hi, 0, maxdepth=40)
    return r is True


# ---------------------------------------------------------------- (C4) x-duals
def parse_dual(t, ncaps, natoms, has_rect):
    if t["nc"] != ncaps:
        raise ValueError("nc = %d but the cell has %d caps" % (t["nc"], ncaps))
    yc = [mpq(0)] * ncaps
    for i, h in t["yc"].items():
        i = int(i)
        if not 0 <= i < ncaps:
            raise ValueError("cap index out of range")
        yc[i] = q(h)
    ya = [q(h) for h in t["ya"]]
    ycl = [q(h) for h in t["ycell"]]
    if len(ya) != natoms:
        raise ValueError("atom multipliers: %d for %d atoms" % (len(ya), natoms))
    if has_rect:
        if len(ycl) != 4:
            raise ValueError("rectangle multipliers")
    elif any(x != 0 for x in ycl):
        raise ValueError("rectangle multipliers without a rectangle")
    return q(t["y0"]), yc, ya, (ycl if has_rect else [])


def xdual_bound(cell, f, dual, D):
    """Checks f <= y0 + step + y3 x + y4 x^2 on every piece, at the atoms, f(0) <= y0; returns the bound or None."""
    y0, yc, ya, ycl = dual
    if any(x < 0 for x in yc) or any(x < 0 for x in ya) or any(x < 0 for x in ycl):
        return None
    f = list(f) + [mpq(0)] * max(0, 3 - len(f))
    if y0 < f[0]:
        return None
    y3 = ycl[0] - ycl[1] if ycl else mpq(0)
    y4 = ycl[2] - ycl[3] if ycl else mpq(0)
    pw = cell.powers(D)
    for (lo, hi, inside), (pl, ph) in zip(cell.pieces, pw):
        sv = sum((yc[i] for i in inside), mpq(0))
        g = [-c for c in f]
        g[0] += y0 + sv
        g[1] += y3
        g[2] += y4
        if not nonneg_on(g, lo, hi, pl, ph):
            return None
    for (p, _), yp in zip(cell.atoms, ya):
        if y0 + yp + y3 * p + y4 * p * p - peval(f, p) < 0:
            return None
    bound = y0 * cell.mu + sum((y * c for y, (_, _, c) in zip(yc, cell.caps)), mpq(0))
    bound += sum((yp * cap for yp, (_, cap) in zip(ya, cell.atoms)), mpq(0))
    if ycl:
        L3, U3, L4, U4 = cell.cellq
        bound += ycl[0] * U3 - ycl[1] * L3 + ycl[2] * U4 - ycl[3] * L4
    return bound


# ---------------------------------------------------------------- (C1) the majorant h^ and phi >= h^
def pois_upper(lam):
    """(p_i^hi for i <= I, T >= P(N > I), E >= E[N; N > I]) with P(N > I) <= 2^-220."""
    if lam == 0:
        return [mpq(1)], mpq(0), mpq(0)
    eh = exp_b(-lam, PB + 20)[1]
    ps = []
    t = eh
    i = 0
    while True:
        ps.append(rup(t, PB))
        nxt = t * lam / (i + 1)
        if i + 2 > 2 * lam:
            tail = rup(nxt / (1 - lam / (i + 2)), PB)
            if tail < mpq(1, 2 ** 220):
                return ps, tail, rup(lam * (ps[-1] + tail), PB)
        t = nxt
        i += 1


def hhat(cell):
    """Sorted kinks and the (slope, intercept) of h^ on each of the len(kinks) + 1 segments."""
    if cell.kind == "light":
        return [mpq(0)], [(mpq(-1), mpq(0)), (mpq(1), mpq(0))]
    a, b, Pa, Pb = cell.a, cell.b, cell.Pa, cell.Pb
    pa, Ta, Ea = pois_upper(Pa)
    pb, Tb, Eb = pois_upper(Pb)
    m = a * Pa + b * Pb
    terms = {}
    for i, wi in enumerate(pa):
        ci = a * i - m
        for j, wj in enumerate(pb):
            c = ci + b * j
            terms[c] = terms.get(c, mpq(0)) + rup(wi * wj, PB)
    T = Ta + Tb
    E = a * Ea + (b * Pb + m) * Ta + b * Eb + (a * Pa + m) * Tb
    terms[mpq(0)] = terms.get(mpq(0), mpq(0)) + T
    kinks = sorted(-c for c in terms)
    slope = -sum(terms.values(), mpq(0))
    icpt = -sum((w * c for c, w in terms.items()), mpq(0)) + E
    segs = [(slope, icpt)]
    for x in kinks:
        w = terms[-x]
        slope += 2 * w
        icpt -= 2 * w * x
        segs.append((slope, icpt))
    return kinks, segs


def phi_ge_hhat(phi, kinks, segs):
    n = len(phi) - 1
    # half-lines
    s0, i0 = segs[0]
    x1 = kinks[0]
    psi = [c if k % 2 == 0 else -c for k, c in enumerate(phi)]  # phi(-t)
    qL = taylor_shift(psi, -x1)  # phi(x1 - t) in t
    qL[0] -= s0 * x1 + i0
    qL[1] += s0
    if nonneg_halfline(qL) is not True:
        return False, "left half-line"
    sK, iK = segs[-1]
    xK = kinks[-1]
    qR = taylor_shift(list(phi), xK)
    qR[0] -= sK * xK + iK
    qR[1] -= sK
    if nonneg_halfline(qR) is not True:
        return False, "right half-line"

    def hval(x):
        s, t = segs[bisect.bisect_right(kinks, x)]
        return s * x + t

    stack = [(0, len(kinks) - 1)]
    nchk = 0
    while stack:
        i0, i1 = stack.pop()
        if i1 <= i0:
            continue
        u, v = kinks[i0], kinks[i1]
        hu, hv = hval(u), hval(v)
        sl = (hv - hu) / (v - u)
        p = [-c for c in phi]
        p[0] += hu - sl * u
        p[1] += sl
        nchk += 1
        if i1 == i0 + 1:
            if is_le(p, u, v, 0, maxdepth=48) is not True:
                return False, "piece [%.6f, %.6f]" % (float(u), float(v))
            continue
        if is_le(p, u, v, 0, maxdepth=5) is True:
            continue
        mid = (i0 + i1) // 2
        stack.append((i0, mid))
        stack.append((mid, i1))
    return True, "%d chord checks over %d kinks" % (nchk, len(kinks))


# ---------------------------------------------------------------- (C3) the inequality list
def interval_pow(L, U, m):
    if m % 2 == 1 or L >= 0:
        return L ** m, U ** m
    if U <= 0:
        return U ** m, L ** m
    return mpq(0), max(-L, U) ** m


def exact_range(al, rng):
    lo, hi = mpq(1), mpq(1)
    for j in sorted(set(al)):
        pl, ph = interval_pow(rng[j][0], rng[j][1], al.count(j))
        c = (lo * pl, lo * ph, hi * pl, hi * ph)
        lo, hi = min(c), max(c)
    return lo, hi


_PT = {}


def ptuples(D):
    if D not in _PT:
        _PT[D] = product_tuples(D)
    return _PT[D]


def build_rows(D, rng, mu):
    """Rows (wcoef, kcoef, rhs) meaning sum wcoef[alpha] w_alpha + sum kcoef[j] kappa_j <= rhs."""
    rows = []
    prods = ptuples(D)
    for al in prods:
        pre, j = al[:-1], al[-1]
        if len(pre) == 1:
            XL, XU = rng[pre[0]]
            xk = ("k", pre[0])
        else:
            XL, XU = exact_range(pre, rng)
            xk = ("w", pre)
        YL, YU = rng[j]
        # (X-XL)(Y-YL) >= 0, (XU-X)(YU-Y) >= 0, (XU-X)(Y-YL) >= 0, (X-XL)(YU-Y) >= 0
        for sw, cx, cy, rhs in ((-1, YL, XL, XL * YL), (-1, YU, XU, XU * YU), (1, -YL, -XU, -XU * YL),
                                (1, -YU, -XL, -XL * YU)):
            wc = {al: mpq(sw)}
            kc = {}
            if xk[0] == "k":
                kc[xk[1]] = kc.get(xk[1], mpq(0)) + cx
            else:
                wc[xk[1]] = wc.get(xk[1], mpq(0)) + cx
            kc[j] = kc.get(j, mpq(0)) + cy
            rows.append((wc, kc, rhs))
    pset = set(prods)
    for j in range(3, D + 1):
        if (j, j) not in pset:
            continue
        L, U = rng[j]
        for s in range(1, 7):
            t = L + (U - L) * s / 7
            rows.append(({(j, j): mpq(-1)}, {j: 2 * t}, t * t))
        if 2 * j - 2 <= D:
            rows.append(({(j, j): mpq(1)}, {2 * j - 2: -mu}, mpq(0)))
    return rows


# ---------------------------------------------------------------- one certificate
def verify_cert(cell, spec_D, certj, info=None):
    """Returns (status, U or None, message); status True = certified (U <= 171/200) or empty.
    If info is a dict it receives the certified ranges and phi."""
    D = spec_D
    nca, nat, rect = len(cell.caps), len(cell.atoms), cell.cellq is not None
    rj = certj["ranges"]
    if sorted(int(j) for j in rj) != list(range(3, D + 1)):
        return False, None, "range keys"
    rng = {}
    for j in range(3, D + 1):
        n = j - 2
        fU = [mpq(0)] * n + [mpq(1)]
        fL = [mpq(0)] * n + [mpq(-1)]
        U = xdual_bound(cell, fU, parse_dual(rj[str(j)]["U"], nca, nat, rect), D)
        Ln = xdual_bound(cell, fL, parse_dual(rj[str(j)]["L"], nca, nat, rect), D)
        if U is None or Ln is None:
            return False, None, "range certificate fails at j = %d" % j
        rng[j] = (-Ln, U)
    if info is not None:
        info["rng"] = rng
    if any(rng[j][0] > rng[j][1] for j in rng):
        return True, None, "empty"
    if "phi" not in certj:
        return False, None, "no phi"
    phi = [q(h) for h in certj["phi"]]
    if len(phi) != D + 1:
        return False, None, "phi degree"
    if info is not None:
        info["phi"] = phi
    kinks, segs = hhat(cell)
    ok, msg = phi_ge_hhat(phi, kinks, segs)
    if not ok:
        return False, None, "phi >= h^ fails: " + msg
    rows = build_rows(D, rng, cell.mu)
    if certj["nz"] != len(rows):
        return False, None, "nz = %d but %d rows" % (certj["nz"], len(rows))
    z = [mpq(0)] * len(rows)
    for i, h in certj["z"].items():
        z[int(i)] = q(h)
    if any(t < 0 for t in z):
        return False, None, "negative multiplier"
    const, lin, prod = expansion(phi, cell.mu)
    comb = {}
    dj = {j: mpq(0) for j in range(3, D + 1)}
    d0 = mpq(0)
    for zt, (wc, kc, rhs) in zip(z, rows):
        if zt == 0:
            continue
        for al, cf in wc.items():
            comb[al] = comb.get(al, mpq(0)) + zt * cf
        for j, cf in kc.items():
            dj[j] -= zt * cf
        d0 += zt * rhs
    Ew = mpq(0)
    for al in set(prod) | set(comb):
        eps = prod.get(al, mpq(0)) - comb.get(al, mpq(0))
        if eps != 0:
            lo, hi = exact_range(al, rng)
            Ew += abs(eps) * max(abs(lo), abs(hi))
    f = [mpq(0)] * (D - 1)
    for j in range(3, D + 1):
        f[j - 2] = lin.get(j, mpq(0)) + dj[j]
    e0 = const + d0
    bx = xdual_bound(cell, f, parse_dual(certj["xdual"], nca, nat, rect), D)
    if bx is None:
        return False, None, "x-dual of f fails"
    U = e0 + bx + Ew
    return (U <= TARGET), U, ("ok" if U <= TARGET else "U above 171/200")


def spec_mismatch(spec, d):
    def fr(s):
        a, b = s.split("/")
        return mpq(int(a), int(b))
    if spec["kind"] != d["kind"]:
        return "kind"
    sq = tuple(fr(t) for t in spec["cellq"]) if spec.get("cellq") else None
    if sq != d["cellq"]:
        return "cellq"
    if d["kind"] == "light":
        return None if (fr(spec["vl"]) == VL and fr(spec["v"]) == VV) else "vl/v"
    if d["kind"] == "nsplit" and spec.get("k") != d["k"]:
        return "k"
    for key in ("Pa", "Pb", "da", "db"):
        if fr(spec[key]) != d[key]:
            return key
    return None


def job(item):
    path, d, D, certj, mods = item
    t0 = time.time()
    try:
        cell = make_cell(d)
        if "lowphi0" in mods and "phi" in certj:
            certj = dict(certj)
            certj["phi"] = list(certj["phi"])
            certj["phi"][0] = (q(certj["phi"][0]) - mpq(1, 1000)).__float__().hex()
        ok, U, msg = verify_cert(cell, D, certj)
    except Exception as e:  # noqa: BLE001
        return path, False, None, "exception %r" % (e,), time.time() - t0
    return path, ok, (float(U) if U is not None else None), msg, time.time() - t0


# ---------------------------------------------------------------- the coverage tree
def load(case):
    fn = os.path.join(CERTDIR, FILES[case])
    with open(fn, "rb") as fh:
        md5 = hashlib.md5(fh.read()).hexdigest()
    certs = {}
    with lzma.open(fn, "rt") as fh:
        for line in fh:
            d = json.loads(line)
            certs.setdefault(d["path"], []).append(d)
    return certs, md5


def tree(case, certs, light_smax=24):
    roots = required_roots(case, light_smax)
    below = set()
    for p in certs:
        parts = p.split("/")
        for n in range(1, len(parts)):
            below.add("/".join(parts[:n]))
    use, kids, mism = {}, {}, []
    stack = list(roots.items())
    while stack:
        path, d = stack.pop()
        if path in certs:
            m = spec_mismatch(certs[path][-1]["spec"], d)
            if m:
                mism.append((path, m))
            use[path] = (d, certs[path][-1])
            kids[path] = []
        elif path in below:
            ch = children(path, d)
            kids[path] = list(ch)
            stack.extend(ch.items())
        else:
            kids[path] = []
    return roots, use, kids, mism


def run_case(case, procs, log, limit=0, mods=(), light_smax=24):
    certs, md5 = load(case)
    log("case %s: file %s md5 %s, %d records" % (case, FILES[case], md5, sum(len(v) for v in certs.values())))
    roots, use, kids, mism = tree(case, certs, light_smax)
    log("  required roots (regenerated from Lemma E): %d; certificates used: %d; spec mismatches: %d" %
        (len(roots), len(use), len(mism)))
    for p, m in mism[:5]:
        log("    mismatch %s: %s" % (p, m))
    items = [(p, d, rec["spec"]["D"], rec["cert"], mods) for p, (d, rec) in sorted(use.items())]
    if limit:
        items = items[:limit]
    verdict = {}
    t0 = time.time()
    with Pool(procs) as pool:
        for n, (p, ok, U, msg, dt) in enumerate(pool.imap_unordered(job, items, chunksize=2)):
            verdict[p] = (ok, U, msg)
            if (n + 1) % 1000 == 0:
                print("  [%5.0f s] %d / %d" % (time.time() - t0, n + 1, len(items)), flush=True)
    sys.setrecursionlimit(100000)

    def covered(p):
        if p in verdict:
            return verdict[p][0]
        ch = kids.get(p) or []
        return bool(ch) and all(covered(c) for c in ch)

    unc = [p for p in roots if not covered(p)]
    Us = [(v[1], p) for p, v in verdict.items() if v[0] and v[1] is not None]
    nempty = sum(1 for v in verdict.values() if v[0] and v[2] == "empty")
    bad = [(p, v[2]) for p, v in verdict.items() if not v[0]]
    log("  verified %d certificates in %.0f s: %d certified (U <= 171/200), %d empty, %d rejected" %
        (len(verdict), time.time() - t0, len(Us), nempty, len(bad)))
    for p, m in sorted(bad)[:10]:
        log("    REJECTED %s: %s" % (p, m))
    log("  roots covered: %d / %d" % (len(roots) - len(unc), len(roots)))
    for p in sorted(unc)[:10]:
        log("    UNCOVERED %s" % p)
    if Us:
        Us.sort(reverse=True)
        log("  largest U = %.8f at %s (171/200 - U = %.3e)" % (Us[0][0], Us[0][1], 0.855 - Us[0][0]))
    return len(unc) == 0 and not mism, dict(verdict=verdict, unc=unc, roots=roots, use=use, Us=Us, bad=bad)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=["nsplit", "chord", "light", "all"])
    ap.add_argument("--procs", type=int, default=8)
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--out", type=str, default="")
    args = ap.parse_args()
    lines = []

    def log(s):
        print(s, flush=True)
        lines.append(s)

    log("RQ-REF3 light_verify.py; start %s UTC" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()))
    with open(__file__, "rb") as fh:
        log("md5 %s  light_verify.py" % hashlib.md5(fh.read()).hexdigest())
    near = [k for k, (a, b) in enumerate(WFP) if a < TH]
    log("window family: %d positive windows (last [A/R, A]); near: k = %d..%d; b/a = 6/5 for all: %s; "
        "(a+b)^2/(4ab) = 121/120 for all: %s" % (len(WFP), near[0], near[-1],
                                                  all(b == mpq(6, 5) * a for a, b in WFP),
                                                  all((a + b) ** 2 / (4 * a * b) == mpq(121, 120) for a, b in WFP)))
    cases = ["chord", "light", "nsplit"] if args.case == "all" else [args.case]
    allok = True
    for c in cases:
        ok, res = run_case(c, args.procs, log, args.limit)
        allok &= ok
        log("  case %s: %s" % (c, "ALL ROOTS COVERED" if ok else "FAILED"))
    log("RESULT: %s" % ("ALL CHECKS PASSED" if allok else "FAILED"))
    log("end %s UTC" % time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()))
    if args.out:
        with open(args.out, "w") as fh:
            fh.write("\n".join(lines) + "\n")
    sys.exit(0 if allok else 1)


if __name__ == "__main__":
    main()
