"""Independent re-verification of RQ-D Theorem 13 (ID* band lemma, theta = 17/20, A = 77/50), RQ-REF3.

Claim: every finitely supported probability K on [-A, A] with K([theta, A]) >= 4/5 has
E|Z_K| <= max(g(lambda+_theta(K)), C5), g(L) = 2 sqrt(L) e^-L.  By Proposition 9 (second form)
E|Z_K| <= F = 2 m e^-L + e^-L c_B + L e^-L O' + P2(L) c_C for every admissible choice of c_B, c_C, O', where
(a, b, L, m) lies in D* = {a, b >= 0, a + b <= 1/5, (L, m) satisfy (F1)-(F5) with V = 1 - a - b}.

RQ-D recorded no box-level certificate, so this program rebuilds a cover of D* from scratch: squares in (a, b) of
side 1/128 (children of uncertified squares down to 1/2048) and, in each square, boxes in (L, m) (strips of 1/64,
bisected alternately down to the minimum widths).  Every box is disposed of by an exact rational test:
  infeasible  one of (F1)-(F5) fails at every point of the box for every V in [V_lo, V_hi];
  direct      M + e^-L1 c_B + max(t e^-t) O' + P2(L2) c_C < T = max(min g(L1), g(L2), C5_lo), with O' one of
              (O1) chord, (O2) Taylor with chi^B, (O3) two-point with chi^C, (O4) two-point with the CS function,
              (O5) two-point with chi^C and the constant kappa kept (not absorbed);
  slope       (a2 + b2 <= 1/50 and m2 < theta) linear bounds in (a, b) and one of (T1)-(T3) on pieces of rho^2,
              with O' from (O1), (O3), (O4) or (O5) (Lemma 12 absorbs kappa).
Only lemmas checked by hand are used (RQ-D Lemmas 6, 7, 8, 12, Proposition 9 and the options after it).  The numerics
are my own (ref/chi.py, ref/rig.py): chi from a table of exact upper bounds of qq(x) = E(x + G)_+^2 with convex
chord interpolation, own Poisson tails, own variance bound sigma_J^2 <= V_hi/L1 - m1^2/L2^2, own choice of h and of
the subdivision (floats only choose; every acceptance is an exact comparison of rationals).

Usage: python3 band_verify.py [--procs 8] [--levels 5] [--shift S] [--noslope] [--squares a1,b1,side ...] [--out F]
"""

import argparse
import hashlib
import json
import math
import sys
import time
from functools import lru_cache
from multiprocessing import Pool

from gmpy2 import mpq

from chi import MPQ, Chi, lin_coef, qtable
from rig import exp_b, log_b, rdown, rup, sqrt_b

TH, A = mpq(17, 20), mpq(77, 50)
THf, Af = 17 / 20, 77 / 50
R5, R50, HALF, ONE = mpq(1, 5), mpq(1, 50), mpq(1, 2), mpq(1)
LBITS, MBITS = 16, 14                   # L = i / 2^16, m = j / 2^14
L0W, M0W = 1 << (LBITS - 6), 1 << (MBITS - 6)   # initial widths 1/64
LMIN, MMIN = 2, 2                       # minimum widths 2^-15, 2^-13
GB = 14                                 # far points / arguments rounded down to multiples of 2^-14
H_GRID = sorted({max(1, round(2 ** (k / 4) / 64 * 4096)) for k in range(0, 31)})
H_GRID = [mpq(k, 4096) for k in H_GRID]  # h from 1/64 to about 2.8
H_GRID_F = [float(h) for h in H_GRID]
SHIFT = mpq(0)
USE_SLOPE = True


def _c5_lo():
    l = log_b(mpq(5, 4), 120)[0]
    return rdown(mpq(32, 25) * sqrt_b(2 * l, 120)[0], 64)


C5_LO = _c5_lo()
C5_F = float(C5_LO)


# ---------------------------------------------------------------- exact elementary bounds (cached)
@lru_cache(maxsize=None)
def exp_hi(x):
    return rup(exp_b(x, 80)[1], 64)


@lru_cache(maxsize=None)
def exp_lo(x):
    return rdown(exp_b(x, 80)[0], 64)


@lru_cache(maxsize=None)
def sqrt_hi(x):
    return sqrt_b(x, 64)[1]


@lru_cache(maxsize=None)
def sqrt_lo(x):
    return sqrt_b(x, 64)[0]


def g_lo(L):
    return 2 * sqrt_lo(L) * exp_lo(-L)


def g_hi(L):
    return 2 * sqrt_hi(L) * exp_hi(-L)


def ghat_hi(L1, L2):
    """Upper bound of max g on [L1, L2] (g increases on [0, 1/2] and decreases after)."""
    if L1 <= HALF <= L2:
        return g_hi(HALF)
    return g_hi(L2) if L2 < HALF else g_hi(L1)


def gf(L):
    return 2 * math.sqrt(L) * math.exp(-L)


def ghat_f(L1, L2):
    if L1 <= 0.5 <= L2:
        return gf(0.5)
    return gf(L2) if L2 < 0.5 else gf(L1)


@lru_cache(maxsize=None)
def lam_quant(L1, L2):
    """Exact (E1, LE, P2, T, glo_min, ghat) for the strip [L1, L2]."""
    E1 = exp_hi(-L1)
    if L2 <= 1:
        LE = L2 * exp_hi(-L2)
    elif L1 >= 1:
        LE = L1 * exp_hi(-L1)
    else:
        LE = exp_hi(-ONE)
    P2 = 1 - exp_lo(-L2) * (1 + L2)
    gmin = min(g_lo(L1), g_lo(L2))
    T = max(gmin, C5_LO) - SHIFT
    return E1, LE, P2, T, gmin, ghat_hi(L1, L2)


@lru_cache(maxsize=None)
def lam_quant_f(L1, L2):
    E1 = math.exp(-L1)
    LE = L2 * math.exp(-L2) if L2 <= 1 else (L1 * math.exp(-L1) if L1 >= 1 else math.exp(-1))
    P2 = 1 - math.exp(-L2) * (1 + L2)
    gmin = min(gf(L1), gf(L2))
    return E1, LE, P2, max(gmin, C5_F) - float(SHIFT), gmin, ghat_f(L1, L2)


def rdg(x):
    """Round down to a multiple of 2^-GB (exact)."""
    return rdown(x, GB)


def rdg_f(x):
    return math.floor(x * (1 << GB)) / (1 << GB)


# ---------------------------------------------------------------- one (a, b) square
class Square:
    def __init__(self, a1, b1, side):
        self.a1, self.b1 = a1, b1
        self.a2, self.b2 = a1 + side, b1 + side
        if self.a2 + self.b2 <= R5:
            self.abar, self.bbar = self.a2, self.b2
        else:
            self.abar, self.bbar = min(self.a2, R5 - b1), min(self.b2, R5 - a1)
        self.r2 = min(self.abar + self.bbar, R5)          # r^2 >= rho^2 = a + b
        self.V_lo, self.V_hi = 1 - min(self.a2 + self.b2, R5), 1 - a1 - b1
        self.chiB, self.chiC = Chi("B", self.abar, self.bbar), Chi("C", self.abar, self.bbar)
        self.slope_ok = USE_SLOPE and self.a2 + self.b2 <= R50
        self.r2f, self.Vlf, self.Vhf = float(self.r2), float(self.V_lo), float(self.V_hi)
        self.bestf = {}

    # -- float helpers (guidance only)
    def best_chi_f(self, kind, t):
        key = (kind, t)
        v = self.bestf.get(key)
        if v is None:
            ch = self.chiB if kind == "B" else self.chiC
            v = min((ch.f(t, h), i) for i, h in enumerate(H_GRID_F))
            self.bestf[key] = v
        return v

    def cs_f(self, y):
        return math.sqrt(y * y + self.r2f) - y

    def cs_hi(self, y):
        return sqrt_hi(y * y + self.r2) - y

    # -- feasibility (F1)-(F5): True if one of them fails on the whole box for every V
    def infeasible(self, L1, L2, m1, m2):
        Vl, Vh = self.V_lo, self.V_hi
        if L1 * TH * TH > Vh or L2 * A * A < Vl:
            return "F1"
        if m1 * TH > Vh or m2 * A < Vl:
            return "F2"
        if TH * L1 > m2 or m1 > A * L2:
            return "F3"
        if m1 * m1 > L2 * Vh:
            return "F4"
        if L1 > (1 / A + 1 / TH) * m2 - Vl / (A * TH):
            return "F5"
        return None

    # -- the direct check
    def direct(self, L1, L2, m1, m2):
        """Float search for the best options, then the exact bound.  Returns the option name or None."""
        Lf1, Lf2, mf1, mf2 = float(L1), float(L2), float(m1), float(m2)
        E1, LE, P2, T, _, gh = lam_quant_f(Lf1, Lf2)
        Ls = mf2 * mf2 / self.Vhf
        if Ls < Lf1:
            M = 2 * mf2 * math.exp(-Lf1)
        else:
            M = min(2 * mf2 * math.exp(-Lf1), math.sqrt(self.Vhf) * ghat_f(Lf1, min(Lf2, Ls)))
        vB, iB = self.best_chi_f("B", m1)
        cB = min(vB, self.cs_f(mf1))
        chB = ("chi", iB) if vB <= self.cs_f(mf1) else ("cs",)
        y = 2 * TH - m2
        yf = float(y)
        vC, iC = self.best_chi_f("C", y)
        cC = min(vC, self.cs_f(yf))
        chC = ("chi", iC) if vC <= self.cs_f(yf) else ("cs",)
        rest = M + E1 * cB + P2 * cC
        budget = T - rest
        if budget <= 0 or LE <= 0:
            return None
        need = budget / LE
        opts = self.oprime_f(Lf1, Lf2, mf1, mf2, m1, m2, L1, L2)
        opts.sort()
        for val, name, choice in opts:
            if val >= need * (1 - 1e-12):
                break
            if self.direct_exact(L1, L2, m1, m2, chB, chC, name, choice):
                return name
        return None

    def oprime_f(self, Lf1, Lf2, mf1, mf2, m1, m2, L1, L2):
        """Float values of the O' options with their parameter choices."""
        out = []
        mu_lo = max(THf, mf1 / Lf2)
        mu_hi = min(Af, mf2 / Lf1)
        if mu_lo > mu_hi:
            return out
        d_lo, d_hi = mu_lo - THf, mu_hi - THf
        s2 = max(0.0, min(self.Vhf / Lf1 - mf1 * mf1 / (Lf2 * Lf2), d_hi * (Af - THf - d_lo)))
        y1, y2 = TH - m2, A - m2
        y1f, y2f = float(y1), float(y2)
        # O1
        c1 = [(self.best_chi_f("C", y1)[0], ("C", self.best_chi_f("C", y1)[1])), (self.cs_f(y1f), ("cs",))]
        vb = self.best_chi_f("B", -y1)
        c1.append((-2 * y1f + vb[0], ("B", vb[1])))
        p1, ch1 = min(c1)
        c2 = [(self.best_chi_f("C", y2)[0], ("C", self.best_chi_f("C", y2)[1])), (self.cs_f(y2f), ("cs",))]
        p2, ch2 = min(c2)
        p1m = max(p1, p2)
        out.append((p1m - d_lo * (p1m - p2) / (Af - THf), "O1", (ch1, ch2)))
        # O2
        t2 = rdg(-(mu_hi_exact(m2, L1) - m1))
        best = None
        for i, h in enumerate(H_GRID_F):
            v = -2 * (mu_lo - mf2) + self.chiB.f(t2, h) + s2 / (2 * h)
            if best is None or v < best[0]:
                best = (v, i)
        out.append((best[0], "O2", best[1]))
        # two-point options
        if d_lo > 0:
            w = d_lo * d_lo / (d_lo * d_lo + s2)
            if s2 <= d_lo * d_lo:
                u = d_lo + s2 / d_lo
            elif s2 >= d_hi * d_hi:
                u = d_hi + s2 / d_hi
            else:
                u = 2 * math.sqrt(s2)
        else:
            w, u = 0.0, 0.0
        xf = rdg(y1 + mpq(u) * (1 - mpq(1, 2 ** 30))) if w > 0 else y1
        best = None
        for i, h in enumerate(H_GRID_F):
            v = (1 - w) * self.chiC.f(y1, h) + w * self.chiC.f(xf, h)
            if best is None or v < best[0]:
                best = (v, i)
        out.append((best[0], "O3", best[1]))
        if y1f >= 0:
            out.append(((1 - w) * self.cs_f(y1f) + w * self.cs_f(float(xf)), "O4", None))
        if d_lo > 0:
            y5 = rdg(y1 + mpq(d_lo) * (1 - mpq(1, 2 ** 30)))
            best = None
            for i, h in enumerate(H_GRID_F):
                kap = max(h - y1f, 0.0) ** 2 / (2 * h)
                v = (1 - w) * kap + (1 - w) * self.r2f / (2 * h) + self.chiC.f(y5, h)
                if best is None or v < best[0]:
                    best = (v, i)
            out.append((best[0], "O5", best[1]))
        return out

    def direct_exact(self, L1, L2, m1, m2, chB, chC, name, choice):
        E1, LE, P2, T, _, _ = lam_quant(L1, L2)
        Vh = self.V_hi
        Ls = m2 * m2 / Vh
        M = 2 * m2 * exp_hi(-L1)
        if Ls >= L1:
            M = min(M, sqrt_hi(Vh) * ghat_hi(L1, min(L2, Ls)))
        cB = self.chiB.hi(m1, H_GRID[chB[1]]) if chB[0] == "chi" else self.cs_hi(m1)
        y = 2 * TH - m2
        cC = self.chiC.hi(y, H_GRID[chC[1]]) if chC[0] == "chi" else self.cs_hi(y)
        O = self.oprime_exact(L1, L2, m1, m2, name, choice)
        if O is None:
            return False
        F = M + E1 * cB + LE * O + P2 * cC
        assert isinstance(F, MPQ)
        return F < T

    def twopoint_params(self, L1, L2, m1, m2, Vh):
        """Exact (mu_lo, d_lo, d_hi, s2, w', u') for the box; None if F3 fails."""
        mu_lo = max(TH, m1 / L2)
        mu_hi = mu_hi_exact(m2, L1)
        if mu_lo > mu_hi:
            return None
        d_lo, d_hi = mu_lo - TH, mu_hi - TH
        s2 = max(mpq(0), min(Vh / L1 - m1 * m1 / (L2 * L2), d_hi * (A - TH - d_lo)))
        if d_lo > 0:
            w = d_lo * d_lo / (d_lo * d_lo + s2)
            if s2 <= d_lo * d_lo:
                u = d_lo + s2 / d_lo
            elif s2 >= d_hi * d_hi:
                u = d_hi + s2 / d_hi
            else:
                u = 2 * sqrt_lo(s2)
        else:
            w, u = mpq(0), mpq(0)
        return mu_lo, mu_hi, d_lo, d_hi, s2, w, u

    def oprime_exact(self, L1, L2, m1, m2, name, choice):
        par = self.twopoint_params(L1, L2, m1, m2, self.V_hi)
        if par is None:
            return None
        mu_lo, mu_hi, d_lo, d_hi, s2, w, u = par
        y1, y2 = TH - m2, A - m2
        if name == "O1":
            ch1, ch2 = choice

            def phib(yy, ch):
                if ch[0] == "C":
                    return self.chiC.hi(yy, H_GRID[ch[1]])
                if ch[0] == "B":
                    return -2 * yy + self.chiB.hi(-yy, H_GRID[ch[1]])
                return self.cs_hi(yy)
            p1, p2 = phib(y1, ch1), phib(y2, ch2)
            p1 = max(p1, p2)
            return p1 - d_lo * (p1 - p2) / (A - TH)
        if name == "O2":
            h = H_GRID[choice]
            t2 = rdg(-(mu_hi - m1))
            return -2 * (mu_lo - m2) + self.chiB.hi(t2, h) + s2 / (2 * h)
        xf = rdg(y1 + u) if w > 0 else y1
        if name == "O3":
            h = H_GRID[choice]
            return (1 - w) * self.chiC.hi(y1, h) + w * self.chiC.hi(xf, h)
        if name == "O4":
            if y1 < 0:
                return None
            return (1 - w) * self.cs_hi(y1) + w * self.cs_hi(xf)
        if name == "O5":
            if d_lo <= 0:
                return None
            h = H_GRID[choice]
            kap = max(h - y1, mpq(0)) ** 2 / (2 * h)
            y5 = rdg(y1 + d_lo)
            return (1 - w) * kap + (1 - w) * self.r2 / (2 * h) + self.chiC.hi(y5, h)
        raise ValueError(name)

    # -- the slope check
    def slope(self, L1, L2, m1, m2):
        if not (self.slope_ok and m2 < TH):
            return None
        r0 = self.a1 + self.b1
        rB = min(self.a2 + self.b2, 1 - m1 * m1 / L2)
        if rB < r0:
            return "empty_F4"
        pieces = [(r0, rB)]
        for _ in range(7):
            nxt = []
            for r1, r2 in pieces:
                if not self.slope_piece(L1, L2, m1, m2, r1, r2):
                    mid = (r1 + r2) / 2
                    nxt += [(r1, mid), (mid, r2)]
            if not nxt:
                return "slope"
            pieces = nxt
        return None

    def lin_ctx(self, L1, L2, m1, m2, Vh1):
        """Exact points at which the slope-check costs are bounded; None if (F3) fails on the box."""
        par = self.twopoint_params(L1, L2, m1, m2, Vh1)
        if par is None:
            return None
        mu_lo, mu_hi, d_lo, d_hi, s2, w, u = par
        y1 = TH - m2
        return dict(m1=m1, y1=y1, y2=A - m2, yC=2 * TH - m2, xf=rdg(y1 + u) if w > 0 else y1,
                    y5=rdg(y1 + d_lo) if d_lo > 0 else None, d_lo=d_lo, w=w)

    def lin_one(self, fam, key, ctx, r, Vh1, L1, exact, memo=None):
        """Linear bound (alpha, beta) of one cost, valid for a, b >= 0 with a + b <= r: family 'B' is c_B at m1,
        'C' is c_C at 2 theta - m2, 'O' is O' (for (O5) a third entry kappa).  Floats or exact; None if the bound
        does not apply."""
        hs = H_GRID if exact else H_GRID_F
        cv = (lambda x: x) if exact else float
        zero = mpq(0) if exact else 0.0

        def cs(yy):
            if yy <= 0:
                return None
            v = 1 / (2 * cv(yy))
            return (v, v)

        def lc(J, yy, i, swap):
            mk = (J, yy, i)
            if memo is not None and mk in memo:
                co = memo[mk]
            else:
                co = lin_coef(J, yy, hs[i], r, exact)
                if memo is not None:
                    memo[mk] = co
            if co is None:
                return None
            return (co[1], co[0]) if swap else co

        def ptC(k, yy):
            return cs(yy) if k[0] == "cs" else lc(A, yy, k[1], True)

        if fam == "B":
            return cs(ctx["m1"]) if key[0] == "cs" else lc(TH, ctx["m1"], key[1], False)
        if fam == "C":
            return ptC(key, ctx["yC"])
        if fam in ("E1", "E2"):
            return ptC(key, ctx["y1" if fam == "E1" else "y2"])
        w = cv(ctx["w"])
        if key[0] == "O1":
            v1, v2 = ptC(key[1], ctx["y1"]), ptC(key[2], ctx["y2"])
            if v1 is None or v2 is None:
                return None
            fac = cv(ctx["d_lo"]) / (cv(A) - cv(TH))
            a1c, b1c = max(v1[0], v2[0]), max(v1[1], v2[1])
            return (a1c - fac * (a1c - v2[0]), b1c - fac * (b1c - v2[1]))
        if key[0] == "O3":
            v1, v2 = lc(A, ctx["y1"], key[1], True), lc(A, ctx["xf"], key[1], True)
            if v1 is None or v2 is None:
                return None
            return ((1 - w) * v1[0] + w * v2[0], (1 - w) * v1[1] + w * v2[1])
        if key[0] == "O4":
            v1, v2 = cs(ctx["y1"]), cs(ctx["xf"])
            if v1 is None or v2 is None:
                return None
            c = (1 - w) * v1[0] + w * v2[0]
            return (c, c)
        if key[0] == "O5":
            d_lo = ctx["d_lo"]
            if d_lo <= 0:
                return None
            h = hs[key[1]]
            kap = max(h - cv(ctx["y1"]), zero) ** 2 / (2 * h)
            if exact:
                if kap * kap * Vh1 > d_lo ** 4 * L1:          # Lemma 12: kappa <= D^2 sqrt(L/V), D = d_lo
                    return None
            elif kap * kap * float(Vh1) > float(d_lo) ** 4 * float(L1) * (1 - 1e-12):
                return None
            v = lc(A, ctx["y5"], key[1], True)
            if v is None:
                return None
            extra = (1 - w) / (2 * h)
            return (v[0] + extra, v[1] + extra, kap)
        raise ValueError(key)

    def slope_piece(self, L1, L2, m1, m2, r1, r2):
        r = rup(r2, 20)
        Vh1 = 1 - r1
        ctx = self.lin_ctx(L1, L2, m1, m2, Vh1)
        if ctx is None:
            return True
        memo = {}
        nh = len(H_GRID)

        def front(fam, keys):
            vals = []
            for k in keys:
                v = self.lin_one(fam, k, ctx, r, Vh1, L1, False, memo)
                if v is not None:
                    vals.append((v[0], v[1], k))
            vals.sort(key=lambda t: (t[0], t[1]))
            out, bmin = [], math.inf
            for a, b, k in vals:
                if b < bmin:
                    out.append((k, (a, b)))
                    bmin = b
            return out

        chi_keys = [("cs",)] + [("chi", i) for i in range(nh)]
        fB = front("B", chi_keys)
        fC = front("C", chi_keys)
        end_keys = [("cs",)] + [("C", i) for i in range(nh)]
        o1 = [("O1", k1, k2) for k1, _ in front("E1", end_keys) for k2, _ in front("E2", end_keys)]
        fO = front("O", o1 + [("O3", i) for i in range(nh)] + [("O4",)])
        fO5 = front("O", [("O5", i) for i in range(nh)])
        E1, LE, P2, T, gmin, gh = lam_quant_f(float(L1), float(L2))
        cands = []
        for kB, vB in fB:
            for kC, vC in fC:
                for kO, vO in fO + fO5:
                    Aa = E1 * vB[0] + LE * vO[0] + P2 * vC[0]
                    Bb = E1 * vB[1] + LE * vO[1] + P2 * vC[1]
                    cands.append((max(Aa, Bb), kB, kC, kO))
        if not cands:
            return False
        cands.sort(key=lambda c: c[0])
        tried = cands[:3] + [c for c in cands if c[3][0] != "O5"][:1]
        for Mx, kB, kC, kO in tried:
            if self.slope_exact(L1, L2, m1, m2, r1, r2, r, Vh1, ctx, kB, kC, kO):
                return True
        return False

    def slope_exact(self, L1, L2, m1, m2, r1, r2, r, Vh1, ctx, kB, kC, kO):
        vB = self.lin_one("B", kB, ctx, r, Vh1, L1, True)
        vC = self.lin_one("C", kC, ctx, r, Vh1, L1, True)
        vO = self.lin_one("O", kO, ctx, r, Vh1, L1, True)
        if vB is None or vC is None or vO is None:
            return False
        E1, LE, P2, T, gmin, gh = lam_quant(L1, L2)
        Aa = E1 * vB[0] + LE * vO[0] + P2 * vC[0]
        Bb = E1 * vB[1] + LE * vO[1] + P2 * vC[1]
        Mx = max(Aa, Bb)
        assert isinstance(Mx, MPQ) and Mx >= 0
        if SHIFT == 0 and Mx <= gmin / 2:                                     # (T1)
            return True
        if gh + max(r1 * (Mx - gh / 2), r2 * (Mx - gh / 2)) < T:             # (T2)
            return True
        # (T3): M0 bounds 2 m e^-L (plus the kappa term of (O5)) on the piece
        Ls = m2 * m2 / Vh1
        M = 2 * m2 * exp_hi(-L1)
        if Ls >= L1:
            M = min(M, sqrt_hi(Vh1) * ghat_hi(L1, min(L2, Ls)))
        if kO[0] == "O5":
            kap, d_lo = vO[2], ctx["d_lo"]
            Lc = m2 * m2 / (1 - r2)
            Mrest = sqrt_hi(Vh1) * ghat_hi(L1, min(L2, Lc)) if Lc >= L1 else mpq(0)
            M0 = max(exp_hi(-L1) * (2 * m2 + kap * max(mpq(0), Vh1 - m2 * m2 / L2) / (d_lo * d_lo)), Mrest)
        else:
            M0 = M
        return M0 + r2 * Mx < T


def mu_hi_exact(m2, L1):
    return min(A, m2 / L1)


# ---------------------------------------------------------------- the (L, m) cover of one square
def run_square(arg):
    a1n, b1n, side_n, den = arg
    t0 = time.time()
    qtable()
    sq = Square(mpq(a1n, den), mpq(b1n, den), mpq(side_n, den))
    Lmin = int(rdown(sq.V_lo / (A * A), LBITS) * (1 << LBITS))
    Lmax = int(rup(sq.V_hi / (TH * TH), LBITS) * (1 << LBITS))
    mmin = int(rdown(sq.V_lo / A, MBITS) * (1 << MBITS))
    mmax = int(rup(sq.V_hi / TH, MBITS) * (1 << MBITS))
    stack = []
    i = Lmin - Lmin % L0W
    while i < Lmax:
        j = mmin - mmin % M0W
        while j < mmax:
            stack.append((i, i + L0W, j, j + M0W, 0))
            j += M0W
        i += L0W
    counts = {}
    nbox = 0
    fail = None
    LS, MS = 1 << LBITS, 1 << MBITS
    while stack:
        i1, i2, j1, j2, dep = stack.pop()
        L1, L2, m1, m2 = mpq(i1, LS), mpq(i2, LS), mpq(j1, MS), mpq(j2, MS)
        res = sq.infeasible(L1, L2, m1, m2)
        if res is None:
            res = sq.direct(L1, L2, m1, m2)
        if res is None:
            res = sq.slope(L1, L2, m1, m2)
        if res is not None:
            key = "infeasible" if res.startswith("F") else res
            counts[key] = counts.get(key, 0) + 1
            nbox += 1
            continue
        split_m = (dep % 2 == 0 and j2 - j1 > MMIN) or i2 - i1 <= LMIN
        if split_m and j2 - j1 > MMIN:
            jm = (j1 + j2) // 2
            stack += [(i1, i2, j1, jm, dep + 1), (i1, i2, jm, j2, dep + 1)]
        elif i2 - i1 > LMIN:
            im = (i1 + i2) // 2
            stack += [(i1, im, j1, j2, dep + 1), (im, i2, j1, j2, dep + 1)]
        else:
            fail = (float(L1), float(L2), float(m1), float(m2))
            break
    return dict(a1=a1n, b1=b1n, side=side_n, den=den, ok=fail is None, nbox=nbox, counts=counts, fail=fail,
                sec=round(time.time() - t0, 2), nchi=len(sq.chiB.cache) + len(sq.chiC.cache))


def level0(den=128):
    out = []
    for i in range(den):
        for j in range(den):
            if mpq(i + j, den) < R5:
                out.append((i, j, 1, den))
    return out


def children(sqr):
    a1, b1, side, den = sqr
    out = []
    for di in (0, 1):
        for dj in (0, 1):
            a, b = 2 * a1 + di, 2 * b1 + dj
            if mpq(a + b, 2 * den) < R5:
                out.append((a, b, 1, 2 * den))
    return out


def main():
    global SHIFT, USE_SLOPE
    ap = argparse.ArgumentParser()
    ap.add_argument("--procs", type=int, default=8)
    ap.add_argument("--levels", type=int, default=5)
    ap.add_argument("--shift", type=str, default="0")
    ap.add_argument("--noslope", action="store_true")
    ap.add_argument("--squares", type=str, nargs="*", default=None, help="a1,b1,side,den (integers)")
    ap.add_argument("--out", type=str, default="")
    ap.add_argument("--jsonl", type=str, default="")
    args = ap.parse_args()
    SHIFT = mpq(args.shift) if "/" in args.shift else mpq(float(args.shift))
    USE_SLOPE = not args.noslope
    lines = []

    def log(s):
        print(s, flush=True)
        lines.append(s)

    with open(__file__, "rb") as fh:
        md5 = hashlib.md5(fh.read()).hexdigest()
    import chi as chimod
    with open(chimod.__file__, "rb") as fh:
        md5c = hashlib.md5(fh.read()).hexdigest()
    log("RQ-REF3 band_verify.py md5 %s, chi.py md5 %s; start %s UTC" %
        (md5, md5c, time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime())))
    log("theta = 17/20, A = 77/50, C5_lo = %.15f, shift = %s, slope check %s" %
        (float(C5_LO), args.shift, "on" if USE_SLOPE else "OFF"))
    qtable()
    if args.squares:
        todo = [tuple(int(x) for x in s.split(",")) for s in args.squares]
    else:
        todo = level0()
    jl = open(args.jsonl, "w") if args.jsonl else None
    tot = {}
    allok = True
    t0 = time.time()
    with Pool(args.procs) as pool:
        for lev in range(args.levels):
            if not todo:
                break
            res = []
            for n, r in enumerate(pool.imap_unordered(run_square, todo, chunksize=1)):
                res.append(r)
                if jl:
                    jl.write(json.dumps(r) + "\n")
                    jl.flush()
                if (n + 1) % 50 == 0:
                    print("  level %d: %d / %d squares, %.0f s" % (lev, n + 1, len(todo), time.time() - t0), flush=True)
            bad = [r for r in res if not r["ok"]]
            nb = sum(r["nbox"] for r in res)
            for r in res:
                if r["ok"]:
                    for k, v in r["counts"].items():
                        tot[k] = tot.get(k, 0) + v
            log("level %d (side 1/%d): %d squares, %d not certified, %d (L, m) boxes in the certified ones, %.0f s" %
                (lev, todo[0][3], len(todo), len(bad), sum(r["nbox"] for r in res if r["ok"]), time.time() - t0))
            todo = [c for r in bad for c in children((r["a1"], r["b1"], r["side"], r["den"]))]
            if args.squares:
                for r in bad:
                    log("  not certified: square %s, first failing box %s" % ((r["a1"], r["b1"], r["side"], r["den"]), r["fail"]))
                todo = []
    if todo:
        allok = False
        log("UNCERTIFIED squares remain after %d levels: %d" % (args.levels, len(todo)))
    log("leaf boxes of the certified squares by method: %s" % json.dumps(dict(sorted(tot.items()))))
    log("RESULT: %s" % ("EVERY SQUARE CERTIFIED: the squares cover the triangle and every box is disposed of"
                        if allok and not args.squares else ("FAILED" if not allok else "done (selected squares)")))
    log("end %s UTC (%.0f s)" % (time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime()), time.time() - t0))
    if args.out:
        with open(args.out, "w") as fh:
            fh.write("\n".join(lines) + "\n")
    sys.exit(0 if allok else 1)


if __name__ == "__main__":
    main()
