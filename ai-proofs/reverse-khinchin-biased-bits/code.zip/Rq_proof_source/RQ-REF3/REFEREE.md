# RQ-REF3 referee report: the chain "R(q) = M(q) on (0, q5]", hence Conjecture S for all q

Referee: RQ-REF3 (independent, hostile). I did not write any of the refereed material and did not run or trust the
authors' or the auditor's code. Every computer step below is re-done with my own code in `ref/`, and every decision
is an exact comparison of rationals.

**Status: FINAL** (all four links refereed; 2026-10-23 UTC).

**Overall verdict: VALID.** Conjecture S holds for all q in (0, 1). This takes RQ-A MAIN-1..6 on
[1 - sqrt(5/6), sqrt(5/6)] as given, as instructed. Every link of the chain is correct as stated. Every
computer-assisted step was re-done with my own code (exact rational decisions); for the band lemma, whose run recorded
no box-level certificate, I re-did the computation from scratch with an independent cover. I found no gap affecting
validity, and two robustness remarks (see the end).

## Verdicts

| link | what | verdict |
|---|---|---|
| 1 | Reduction: RQ-B level-one form (Lemma 2.1), Poissonisation (Theorem 3), Theorem 3.4 (a)-(d) = RQ-A U.1-U.3 (md numbering; tex labels lem:level1, thm:poisson, thm:uniform): ID*(C5) on finitely supported K implies R = M on (0, q5] | **VALID** (by hand; constants re-checked exactly) |
| 2 | RQ-C C15 localisation: only K on [-A, A] with A > A'(q) are needed; A'(q5) = 1.538044 < 1.54 | **VALID** (by hand; constants re-checked exactly) |
| 3 | RQ-D MAIN_RESULT Sections 2-7: band Theorem 13 / Cor 14-15 and heavy far region Theorem 16 / Cor 17 | **VALID** (by hand; Theorem 16 certificates re-verified with my own code; the computation of Theorem 13 re-done from scratch with my own exact cover of D*, every square certified) |
| 4 | RQ-B MAIN_RESULT Section 13: light far region Theorem 13.1 (E\|Z_K\| <= 171/200), Lemmas S1-S5, C, D, E | **VALID** (by hand; all 10966 certificates re-verified with my own code; one non-blocking robustness remark) |
| all | Conjecture S holds for all q in (0, 1) | **VALID** (links 1-4 VALID; with RQ-A MAIN-1..6 on [q6, 1 - q6] taken as given) |

## Documents refereed

| document | md5 |
|---|---|
| RQ-B `rq/MAIN_RESULT.tex` (Sections 3, 4, 13) | e41938426653fabb413484e593485ccf |
| RQ-D `MAIN_RESULT.tex` (Sections 1-7) | 212c6f230b7bd8b8ef0c377b21f7c937 |
| RQ-C `CLAIMS.md` (C15) | 4b1e22a4fb96d0a383a1d8f5395edc06 |
| RQ-AUD `AUDIT.md` (A.7a, A.10a, A.26, A.28, A.30, A.32, A.34, A.38, A.39, A.40; read for orientation only) | ee9a1bb18740b7dacd12d2624dd360d9 (copy of 01:22 UTC); A.40 read in e5c425c8… |
| RQ-D certificates `outputs/plus_cert/certs_v1_r{0..4}.jsonl` | e23d52dd…, ee9307ee…, f5fe9a23…, 6d495261…, 3033710b… |
| RQ-B certificates `numerics/cover_final/{nsplit_D14,chord_D14,light_vl025_D18}.jsonl.xz` | 0883b5d9…, 3d7366f9…, 2bbb7484… |

Taken as given (auditor and referee VALID, outside my scope): RQ-A MAIN-1..6, i.e. Conjecture S on
[1 - sqrt(5/6), sqrt(5/6)] = [q6, 1 - q6].

## Link 1: the reduction (RQ-B Lemma 2.1, Theorem 3, Theorem 3.4 (a)-(d)) — VALID

Checked by hand, line by line:

- **Level-one form.** E[f chi_i] = tau Delta_i(f) with tau = sqrt(q(1-q)). For a unit alpha, f = 1{L > 0} gives
  E|L| = 2 E[fL] <= 2 tau sqrt(D(f)); conversely alpha = Delta(f) gives tau D(f) = E[fL] <= E L_+ = E|L|/2. So
  R(q) = 2 tau sup_f sqrt(D(f)).
- **Poissonisation (Theorem 3 and Theorem 3.4(a)).** With N_i i.i.d. Poisson(s), s = ln(1/(1-q)), x_i = 1{N_i >= 1} is Bernoulli(q).
  Stein's identity E[(N - s) g(N)] = s E[g(N+1) - g(N)] and F(N + e_i) - F(N) = 1{N_i = 0}(f(x^{i<-1}) - f(x^{i<-0}))
  give E[F I] = s(1-q) D(f) for I = sum Delta_i (N_i - s); E[FI] <= E I_+ = E|I|/2 as 0 <= F <= 1. The law of
  I/sqrt(sD) is Z_{K_f} with K_f = sum beta_i^2 delta_{beta_i/sqrt s} (each c(N_s - s) has Kolmogorov measure
  s c^2 delta_c), a probability measure. Hence 2 tau sqrt(D(f)) <= sqrt(q/((1-q)s)) E|Z_{K_f}|.
- **Quantisation (b).** lambda_+(K_f) = s #{i : beta_i >= theta sqrt s} (each atom contributes exactly s), and
  sqrt(q/((1-q)s)) g(ks) = 2 sqrt(kq)(1-q)^{k-1/2} = T_k(q). So the g-terms of ID* are at most M(q), and
  sqrt(q/((1-q)s)) C(q) = max_k T_k(q) = M(q) for q <= 1/2.
- **(c)-(d).** If ID*(C) holds for every finitely supported probability K and C <= C(q), then 2 tau sqrt(D(f)) <= M(q)
  for every f, so R(q) <= M(q). The lower bound R >= M: for kq < 1, E|chi_1 + ... + chi_k|/sqrt(k) =
  2kq(1-q)^k/(tau sqrt k) = T_k(q), and on the band [q_{k+1}, q_k] where T_k = M one has kq <= k q_k < 1, since
  q_k = 1 - sqrt(1 - 1/k) < 1/k.
- **min of C(q) on (0, q5] is C5.** With s_K = (1/2) ln(K/(K-1)) the tie point g((K-1)s) = g(Ks), on
  [q_{K+1}, q_K] one has C(q) = g(Ks) with Ks running from (K/2) ln((K+1)/K) < 1/2 to (K/2) ln(K/(K-1)) > 1/2, so
  the minimum over that band is min(C_K, C_{K+1}) with C_K = g(x_K), x_K = ((K-1)/2) ln(K/(K-1)). Writing
  n = K - 1, x_K = (n/2) ln(1 + 1/n) increases to 1/2, and g increases on (0, 1/2], so C_K increases in K and
  inf over (0, q5] = union of the bands K >= 5 is C_5 = g(2 ln(5/4)) = 1.28 sqrt(2 ln 1.25).
- **The mirror.** chi -> -chi maps q to 1 - q and M(q) = M(1 - q). With RQ-A MAIN-1..6 on [q6, 1 - q6] and q6 < q5,
  (0, q5] together with its mirror covers (0, 1).
- The hypothesis needed downstream is exactly: *E|Z_K| <= max(g(lambda+_theta(K)), g(lambda-_theta(K)), C5) for every
  finitely supported probability K on [-1.54, 1.54], with the closed thresholds lambda+-_theta = int_{+-x >= theta}
  x^{-2} dK* (theta may depend on K; the chain uses theta = 0.85 throughout). RQ-D's Theorem 13 uses the same closed
  threshold (Lambda = int x^{-2} dK_S with K_S = K restricted to [theta, A]).

Exact checks (`ref/constants.py`, output `logs/constants.txt`, all PASS): C5 = 0.855100455470819…;
171/200 < C5 (margin 1.005e-4); C_4 < C_5 < C_6 and C_K strictly increasing for 4 <= K <= 40; x_K < 1/2; q6 < q5.

## Link 2: localisation (RQ-C C15 (a)-(g)) — VALID

Checked by hand, line by line: the first-order condition (a) (P(L = 0) = 0 and E[chi_i sgn L] = R_n alpha_i); the
identity (b) R_n u alpha_i = 2(1-q) P(-alpha_i u < L' < alpha_i v) <= 2 p_- (and the mirror); the one-extra-bit
inequality (c), including the identity |x + a| - |x| = a(1 - 2 1{x<0}) + 2(x + a)_+ 1{x<0} and the cancellation
q a (1 - 2p_-) + (1-q) b (1 - 2p_+) = 0; the optimisation in (d) at a = 2(1-q)p_-/R; (e)
u|alpha_i| <= Lambda_n -> sqrt(2/(1-q)); (f) the contradiction argument (if R > M choose n with R_n > M and
supp K~ in [-A, A]; then Theorem 3.4(a)-(b) and ID* at the single measure K~ = K_{f*} give R_n <= M); and (g)
d/dq ln A'(q)^2 = (s(1+q) - q)/(q s (1-q)) > 0 because s = ln(1/(1-q)) >= q > q/(1+q).

So for q <= q5, ID* is needed only for finitely supported probability K on [-A'(q5), A'(q5)], strictly inside
[-1.54, 1.54]. Exact checks (`ref/constants.py`): A'(q5) = sqrt(5 q5 / ln(5/4)) = 1.538044391650755… < 77/50;
sqrt 2 < 77/50; A' increasing on a grid (spot check of the analytic proof).

## Coverage and hypothesis matching (links 3-4 together)

For a probability K on [-1.54, 1.54] put V+ = K([0.85, 1.54]) and V- = K([-1.54, -0.85]); V+ + V- <= 1.

| region | statement used | source |
|---|---|---|
| V+ >= 4/5 (or V- >= 4/5) | E\|Z_K\| <= max(g(lambda+-_0.85), C5), finitely supported K | RQ-D Theorem 13 |
| 1/2 <= V+ < 4/5 or 1/2 <= V- < 4/5 | E\|Z_K\| < C5, every K | RQ-D Theorem 16 |
| V+ < 1/2 and V- < 1/2 | E\|Z_K\| <= 171/200 < C5, finitely supported K | RQ-B Theorem 13.1 |

The thresholds are closed/open consistently (V >= 4/5 | 1/2 <= V < 4/5 | V < 1/2), the same theta = 17/20 and
A = 77/50 are used everywhere, and the three statements cover every finitely supported probability K on
[-1.54, 1.54]. This is exactly ID*(C5) with theta = 0.85 on [-1.54, 1.54], which is what links 1-2 need. Nothing in
the chain uses C5 (R_ID = sqrt(2/e)), Theorem 10 or Corollary 11 of RQ-D.

## Link 3: RQ-D Sections 2-7 — VALID

Hand checks (all correct as stated): Lemma 1 (flip formula), Lemma 2 (conditional form), Lemma 3
(OR-region identity), Lemma 4 (comparison lemma, both steps), Remark 5, Lemma 6 (stop-loss bounds (i)-(iv)),
Lemma 7 (a)-(c) including the box form, Lemma 8 (F1)-(F5), Proposition 9 (both forms), the options (O1)-(O5),
Lemma 12 (absorption), the reduction of Theorem 13 to D*, Corollaries 14-15; Section 7: Lemma 18 (chord reduction),
Lemma 19 (dQ/da >= 0 needs 2 tau >= A), Lemma 20 (box reduction; the corner bookkeeping V+ - M+ >=
max(Q2, 1/2) - M2 in both cases), Lemma 21 (moment recursion, R_B), Lemma 22, the inequalities (a)-(c) (McCormick,
Hoelder/Lyapunov, cell rows), Lemma 23 (majorant test (i)-(iii)), Lemma 24 and the proof of Theorem 16.

### Theorem 16 (heavy far region): certificates re-verified — VALID

`ref/heavy_verify.py` (my code; reads only the numbers in RQ-D's `certs_v1_r{0..4}.jsonl`, md5s as above) re-checks
every inequality the proof of Theorem 16 uses, in exact rational arithmetic, with algorithms different from RQ-D's:

| step | RQ-D's method | my method |
|---|---|---|
| leaf boxes cover [0, 28/25] x [0, 17/50]; cells cover R_B | area sum of non-nested dyadic squares | recursive quadtree descent from the 256 initial boxes (resp. from R_B) |
| polynomial suprema (S in (a), (b); S_R in (c); pieces of H - phi) | Taylor/ball branch and bound (arb, 128 bits) | exact Bernstein subdivision (`ref/bern.py`, integer de Casteljau) |
| E phi(Z_W) as a polynomial in the cumulants | recursion P_n = sum C(n-1,i-1) kappa_i P_{n-i} | set-partition formula n!/(prod b! prod m!) (`ref/moments.py`; checked equal to the recursion and to exact centred Poisson/Gaussian moments) |
| Poisson weights, T, e in Lemma 23 | arb balls, T = 1 - sum, n_a ~ a1 + 12 sqrt(a1) + 20 | own enclosures (`ref/rig.py`), direct tail bound p_{n+1}/(1 - lam/(n+2)) <= 2^-80, own n_a, n_b; weights < 2^-60 moved into the |r| and constant terms (a larger majorant, fewer kinks) |
| C5 | arb ball | exact lower bound (32/25) sqrt(2 ln 5/4) from `ref/rig.py` |

Checks per cell: the 14 ranges [L_j, U_j] of (a) with the certificate's (s3, s4) (cell-intersected for j = 3, 4;
L_j > U_j means empty); the Farkas value Phi < 0 of (b); beta of (c) with the four cell rows, the four McCormick
rows and the two Hoelder rows per tuple (negative multipliers set to 0; any tuple key is accepted as long as it is a
sorted tuple of orders 3..16, since every row is valid for every such product); L >= tau a1 + A b1; the two Taylor
tail tests of Lemma 23(iii) with delta rounded up; eps = max(0, sup_{[-L, L]} (H~ - phi)) piece by piece between the
kinks; and beta + eps < C5.

Result (`logs/heavy_verify.txt`, 19 s on 8 processes): **box tiling OK (436 leaves, none unused); 280 certified
boxes and 156 empty boxes, 0 failures; 1237 cells (1236 'ok', 1 'empty_farkas'); worst bound beta + eps =
0.8548832 < C5 = 0.8551004** (box [0.0525, 0.0700] x [0.2072, 0.2125], cell (2, 3, 1)), the same box, cell and
value (to 1e-9) as RQ-D reports. Per level: d = 0..4 certified 96/71/66/44/3, empty 134/12/6/3/1, as in RQ-D's
table. My bounds are below RQ-D's stored float bounds by 2e-13 .. 1.2e-9 in every cell.

Negative controls (all rejected, as they must be): dropping a box record; moving a box index out of its grid;
dropping a cell; relabelling a certified box as empty; Farkas multipliers (0, 0); c16 < 0; L < tau a1 + A b1;
scaling one coefficient of phi by 0.97. Lowering the target to C5 - s makes 0 / 9 / 50 of the 280 boxes fail for
s = 1e-4 / 3e-4 / 1e-3 (RQ-D reports the same counts). Evidence only: `ref/heavy_sanity.py` draws 8272 random
finitely supported W in W_B(C) over 12 random boxes; every kappa_j lies in its range and E phi(Z_W) <= beta (smallest
gap 5.2e-5); h_B <= phi + eps on a grid of [-3L, 3L].

### Theorem 13 (band lemma, theta = 17/20, A = 77/50): computation re-done independently — VALID

RQ-D's run of `verify_bandstar.py` recorded no box-level certificate. Its `verify_bandstar_squares.jsonl` gives
only box, ok, nbox and seconds per (a, b) square, so the published run cannot be replayed box by box. I therefore
re-proved the computational step of Theorem 13 from scratch. `ref/band_verify.py`, with `ref/chi.py` and
`ref/rig.py`, is my own design and code. It uses only the hand-checked Lemmas 6, 7, 8 and 12, Proposition 9 (second
form) and the options (O1)-(O5). It covers D* = {a, b >= 0, a + b <= 1/5, (L, m) satisfying (F1)-(F5) with
V = 1 - a - b} by boxes and disposes of every box by an exact inequality between rationals. Floats only choose the
option, h and the subdivision.

The setup on an (a, b) square [a1, a2] x [b1, b2]:

- V lies in [V_lo, V_hi] = [1 - min(a2 + b2, 1/5), 1 - a1 - b1].
- The chi costs are evaluated at the corner (a^, b^), which is (a2, b2) or, past the hypotenuse,
  (min(a2, 1/5 - b1), min(b2, 1/5 - a1)). This is valid by Lemma 6(iv).
- r^2 = min(a^ + b^, 1/5) >= rho^2.

Box tests (each bound re-derived by hand):

- **infeasible.** One of (F1)-(F5) fails at every point of the box for every V in [V_lo, V_hi].
- **direct.** The box passes if
  M + e^-L1 c_B + max_[L1,L2](t e^-t) O' + P2(L2) c_C < T = max(min(g(L1), g(L2)), C5),
  with every factor rounded outward. The pieces:
  - M bounds 2 m e^-L = 2 e^-L min(m, sqrt(L V)) through the unimodality of g, splitting at L = m2^2 / V_hi.
  - c_B = min(chi^B_h(m1), sqrt(m1^2 + r^2) - m1), and c_C is the same at 2 theta - m2.
  - O' is one of (O1)-(O5):
    - (O1): the chord, with endpoint bounds of phi at theta - m2 and A - m2, the max replacement, evaluated at mu_lo.
    - (O2): Gamma(y) = -2y + chi^B_h(-y), kappa = 1/h, with the chi argument rounded down to 2^-14.
    - (O3), (O4): the box form of Lemma 7(c), with j0' = theta - m2, w' = d_lo^2/(d_lo^2 + s^2), u' the minimum of
      d + s^2/d over [d_lo, d_hi], and the far point rounded down to 2^-14.
    - (O5): with its constant kappa kept.
  - The variance bound is s^2 = min(V_hi/L1 - m1^2/L2^2, d_hi (A - theta - d_lo)) >= sigma_J^2. The first term is
    my own bound; the second is Bhatia-Davis.
- **slope.** Used only when a2 + b2 <= 1/50 and m2 < theta.
  - rho^2 lies in [a1 + b1, min(a2 + b2, 1 - m1^2/L2)], the upper end coming from (F4). This range is bisected up
    to 6 times.
  - On a piece [r1, r2], c_B, c_C and O' are replaced by bounds alpha a + beta b, valid for a + b <= r = r2
    rounded up to 2^-20. I re-derived these:
    - The n = 0 term is at most b tau(c/sqrt r).
    - For n >= 1, p_n <= (a/theta^2)(r/theta^2)^(n-1)/n!, and (theta n - a/theta - c)^2 <= (theta n - c)^2 when
      r/theta <= 2(theta - c). The case of chi^C is symmetric.
    - sqrt(t^2 + rho^2) - t <= rho^2/(2t) for t > 0.
    - For r = 0 every cost vanishes.
  - Then F <= sqrt(V) g(L) + rho^2 M_x, by (F4) or, for (O5), by Lemma 12 with D = d_lo; the condition
    kappa <= d_lo^2 sqrt(L1/(1 - r1)) is checked exactly. One of (T1)-(T3) then decides. For (T3) with (O5) I use my
    own bound M0 = max(e^-L1 (2 m2 + kappa max(0, 1 - r1 - m2^2/L2)/d_lo^2), sqrt(1 - r1) max g on
    [L1, min(L2, m2^2/(1 - r2))]), which follows from the proof of Lemma 12. RQ-D's M0 is also valid.

| step | RQ-D (`verify_bandstar.py`) | mine (`band_verify.py`, `chi.py`) |
|---|---|---|
| decisions | arb balls, 80 bits | exact rationals (gmpy2), outward rounding to 64 bits |
| chi^B_h, chi^C_h | lattice sum n <= 14 with arb Phi, phi; geometric tail | lattice sum to an adaptive N; exact table of upper bounds of qq(x) = E(x + G)_+^2 on [-16, 16], step 2^-12, interpolated by chords (qq is convex and increasing), built from my own Phi, phi enclosures; s rounded up (E(d + sG)_+^2 is nondecreasing in s); own tail bound with ratio lam (N+2)/(N+1)^2 |
| sigma_J^2 | (L2 V_hi - m1^2)/L1^2 and Bhatia-Davis | V_hi/L1 - m1^2/L2^2 and Bhatia-Davis |
| h | 2-3 float-chosen values per option | the best of a 31-point dyadic grid in [1/64, 2.83] (float choice) |
| linear bounds | series to n = 11, tail as twice the n = 12 term | series to n = 12, geometric tail with ratio (r/J^2)(N+2)/(N+1)^2 |
| (L, m) boxes | strips 1/64, blocks 1/64, minimum 1/16384 x 1/4096 | same initial sizes, minimum 2^-15 x 2^-13; bisection alternately in m and L |
| (a, b) squares | side 1/128, children of uncertified squares down to 1/8192 | side 1/128, children of uncertified squares (allowed down to 1/4096, needed only to 1/1024) |

Result (`logs/band_verify.txt`, `logs/band_verify_squares.jsonl`; `band_verify.py` md5 18a0f70d…, `chi.py` md5
4de87131…; 510 s on 8 processes):

| side of the squares | squares | not certified | leaf boxes in the certified squares |
|---|---|---|---|
| 1/128 | 351 | 205 | 859,282 |
| 1/256 | 796 | 84 | 4,033,527 |
| 1/512 | 336 | 6 | 3,896,332 |
| 1/1024 | 24 | 0 | 288,202 |

**Every square is certified.** The 1212 certified squares carry 9,077,343 leaf boxes:

| method | leaf boxes |
|---|---|
| infeasible | 2,051,477 |
| (O1) | 447,902 |
| (O2) | 2,137,115 |
| (O3) | 4,105,282 |
| (O4) | 334,983 |
| slope check | 584 |

(O5) was never needed in the direct check. For comparison, RQ-D reports 1339 certified squares (351/215, 837/102,
408/20 and 80/0 per level), 7,874,211 leaf boxes and 426 slope leaves. The two covers differ in h, the variance
bound, M0, the chi enclosure and the subdivision, and both succeed.

Coverage re-check (`ref/band_controls.py`, C0). This recomputation reads only the per-square log, not the
verifier's level loop. All 351 squares of side 1/128 that meet the triangle are covered, recursively, by the 1212
certified squares. A child square with a1 + b1 > 1/5 misses the closed triangle, and a1 + b1 = 1/5 cannot occur
for denominators 128 * 2^k.

Controls (`logs/band_controls.txt`, all as expected; reruns of single squares without refinement):

- **C1.** The origin squares [0, 1/128]^2 and [0, 1/256]^2 are certified at shift 0.
- **C2.** With the target lowered by 0.0005 neither origin square is certified. The first failing box,
  L in [0.563263, 0.563293] and m in [0.750488, 0.750610], lies on the Dirac curve m^2 = L, where
  C5 - g(L) is about 0.0005. RQ-D reports the same place.
- **C3.** With the slope check off, neither origin square is certified; the failure is again on the Dirac curve.
- **C4.** The two neighbours of the origin square at side 1/128 need refinement.
- **C5.** The 24 squares of the last level, along the hypotenuse with a1 + b1 in [0.1973, 0.1992], are certified at
  shift 0, and 15 of them are not certified at shift 0.001.

So the margin is 0 on the Dirac curve, where the slope check and Lemma 12 are essential, and below 1e-3 along the
hypotenuse. The checks are not vacuous.

Self-tests (`logs/selftests.txt`):

- `chi.py` compares 300 random qq_hi values with mpmath at 200 bits, using qq(x) + qq(-x) = x^2 + 1 to avoid
  cancellation.
- It checks 80 chi^B, chi^C upper bounds against a direct 60-term mpmath sum.
- It checks 568 random linear bounds alpha a + beta b against chi computed at (a, b).
- The qq table, rebuilt from scratch, is identical to the cached table the run used.

Semantic test (evidence only; `ref/band_semantic.py`, `logs/band_semantic.txt`, seed 20261023). I drew 1500 random
finitely supported K with K([theta, A]) >= 4/5 and rational atoms: 500 near-Dirac with rho^2 <= 1/50, 500 general,
and 500 near the hypotenuse. Each K went through the verifier's own cover: a certified square containing (a, b),
then the verifier's own (L, m) box path to the leaf containing (Lambda(K), m(K)), with the verifier's methods
wrapped rather than modified. Against values from the exact law of Z_K (Poisson enumeration),
the test checks:

- no leaf containing a real K is "infeasible";
- every bound the leaf used dominates its true value: e^-L, L e^-L, P2, M, c_B, c_C and O' in the direct check, and
  the linear bounds, Lemma 12 and M0 in the slope check;
- E|Z_K| <= F_true (Proposition 9) and F_true <= max(g(L), C5).

There was no violation in 1500 of 1500 samples. 423 of them ended in slope-check leaves. The smallest gaps are
-5.6e-16, which is rounding at the equality cases of Proposition 9 and Lemma 12 (rho^2 = 0, or a one-atom K_S).
The smallest gap max(g, C5) - F_true is 7.1e-5, near the Dirac curve.

So Theorem 13 holds, and with it Corollaries 14-15 (hand-checked). Together with Theorem 16 (above) and RQ-B
Theorem 13.1 (link 4), this gives ID*(C5) on all of [-1.54, 1.54].

## Link 4: RQ-B Section 13 — VALID

Hand checks (all correct as stated): Lemma S1 (thinning; E[M | Z_{K_W}] = 0), Lemma S2 (identity,
Jensen and Cauchy-Schwarz bounds, monotonicity of p_a p_b/(p_a + p_b)), Lemma S3 (splitting at the lower corner,
mass count, Gaussian top-up), Corollary S4, Lemma S5 ((x - a)/x^2 increasing on [a, b] for b < 2a; both lower
bounds for s; beta < 1 via (b - a) theta^2 - b^2(theta - a) = (b - theta)(a(b + theta) - b theta)), Lemma C (the
x-dual integration step; closed pieces suffice because y_I >= 0), Lemma D (three cases, reflections), Lemma E
(i + j <= 20 in case 1 from (a+b)^2/(4ab) = 121/120; i + j <= 10 in case 2; root counts 221 x 36 = 7956 and 60
recounted by hand; case 3: 537 cells for s < 24, t < 31 after the Jensen exclusion, of which s >= 21 are
superfluous but harmless; the rest rectangle R(B)).

Further hand checks of the cell data the certificates rely on: in case 1 the caps hold for K_R = K off W
(K_R(W') <= K(W') <= K(W) <= V_hi for near W' != W, K_R([theta, A]) = V+ - K_W([theta, b]) < 1/2 - s_lo,
K_R([-A, -theta]) = V- < 1/2), and the exclusions are strict where they must be (V_hi <= 1/4 contradicts
K(W) > 1/4; V_lo > 1 contradicts K(W) <= 1); in case 2 K_R lives on [-A, theta), V- <= V+ <= V_hi, and
i + j < (1/2)(a+b)^2/(4ab delta) = 10.909 gives i + j <= 10; in case 3 m1 < A/4 + 3 theta/4 = 1.0225 and
m2 < (A^2 + theta^2)/2 = 1.54705 need only s <= 20, t <= 30. In (C4) the atom inequalities carry no cap terms
(the atom masses t_p are not part of K_R), f(0) = 0 so f(0) <= y_0 means y_0 >= 0 (needed for the top-up g at 0),
and y_0 may otherwise have either sign because K'(R) = mu exactly. The majorant: for (i, j) outside the truncation
|r + c_ij| <= |r| + a i + b j + m, and summing over {i > I_a} and {j > I_b} separately (double counting allowed)
gives exactly T|r| + E with T = P(N_a > I_a) + P(N_b > I_b) and
E = a E[N_a; N_a > I_a] + (b P_b + m) P(N_a > I_a) + (same with a <-> b).

### Certificates re-verified — VALID

`ref/light_verify.py` (my code; reads only the numbers of RQ-B's three `cover_final` files, md5s as above; RQ-B's
stored specs are compared with my regenerated cells but never used) regenerates from Lemmas S2, S5 and E the
required roots, the caps, atoms, masses mu, breakpoints and the subdivision rule, and re-checks Lemma C for every
certificate in exact rational arithmetic:

| step | RQ-B's method (`far_verify.py`) | my method |
|---|---|---|
| (C1) phi >= h^ | Taylor test per piece between consecutive kinks, bisection, Sturm count of the squarefree part; arb Poisson balls, I = P + 14 sqrt P + 25, tail pi_I q/(1-q) | my own majorant h^ (own Poisson enclosures from `ref/rig.py`, truncation where the tail is < 2^-220, tail pi_{I+1}/(1 - lam/(I+2))); phi >= chord of the convex h^ over runs of kinks (adaptive, exact Bernstein subdivision), down to single kink intervals where needed; both half-lines by Bernstein on [0, inf) |
| (C2), (C4) x-duals | per piece: endpoint test for monomials, else Taylor/Sturm | per piece: exact sum of monomial minima, else exact Bernstein subdivision; exact list lengths enforced |
| (C3) moments | recursion m_n = sum C(n-1, i-1) kappa_i m_{n-i} | set-partition formula (`ref/moments.py`), any degree |
| (C3) rows | rebuilt from certified ranges | rebuilt independently from my ranges, same documented order; every row re-derived by hand |
| coverage | `cover_check.py` | own tree: regenerated roots, children by the rule of Lemma E, every root must be certified or have all children covered |

Result (`logs/light_verify_{chord,light,nsplit}.txt`; 7 s, 19 s and 37 s on 8 processes):

| case | roots (regenerated) | certificates used | certified / empty / rejected | roots covered | largest U | 171/200 - U |
|---|---|---|---|---|---|---|
| 1 (near splits, D = 14) | 7956 | 8481 | 8476 / 5 / 0 | 7956 / 7956 | 0.8549969805515450 at N/k35/i0j6 | 3.02e-6 |
| 2 (chord boxes, D = 14) | 60 | 1212 | 1046 / 166 / 0 | 60 / 60 | 0.8549552502410571 at C/i1j3/q32 | 4.47e-5 |
| 3 (light cells, D = 18) | 537 | 1273 | 1213 / 60 / 0 | 537 / 537 | 0.8549743150463496 at L/s15t15 | 2.57e-5 |

No spec mismatches; no certificate file contains a path whose ancestor is also certified. The three largest bounds
agree with RQ-B's reported values to all 16 printed digits (exact rational U computed independently), which also
confirms that my rows, moment expansion, E_w and x-dual bound reproduce theirs. Since every root of every case is
covered and every U <= 171/200 < C5, Theorem 13.1 holds.

Negative controls (`ref/light_controls.py`, `logs/light_controls.txt`; 40 seeded certificates per case): each of
phi_0 - 1e-6, phi_D := 0, x-dual y_0 - 1e-6, U_3-range y_0 - 1e-6, one multiplier made negative, the certificate
checked against the neighbouring cell, and target := U - 1e-12 is rejected in every case (2 phi_D mutations in case 2
are the identity, as RQ-B also reports); with all leaves accepted all roots are covered, and deleting any one of 40
sampled leaves uncovers a root. (Zeroing the largest multiplier is not a negative control, since any z >= 0 is
admissible; such mutants are rejected or accepted with a larger U, as expected.)

Semantic test (evidence only; `ref/light_semantic.py`, `logs/light_semantic.txt`): 4500 random finitely supported
K with V+-, V- < 1/2 (rational atoms; scenarios with a heavy near window, with V+ in [1/4, 1/2), and spread out) are
pushed through Lemma D (case and reflection), Lemmas S1-S3 (box, t_a, t_b, top-up g) and Lemma E (root, then the
leaf containing (int x dK', int x^2 dK')). For all 4500 (2789 in case 1, 1353 in case 2, 358 in case 3): the root is
a regenerated root, g >= 0 and 0 <= t_p <= cap_p, every cap holds for K_R, the leaf is not certified empty, every
kappa_j(K') lies in the certified range, and E phi(Z_K') <= U exactly (smallest gap 1.9e-6).

Remark (robustness, not a gap): RQ-B's `far_verify.check_linear_dual` pairs atoms with their multipliers and caps
with theirs by `zip`, and adds the rectangle terms only when the cell has a rectangle. A certificate with fewer atom
multipliers than atoms would have its atom inequalities silently skipped, and nonzero rectangle multipliers on a
cell without a rectangle would enter the piece checks but not the bound; both would be unsound. My verifier rejects
any length mismatch (exactly 2 atom multipliers for split cells, 0 for light cells, 4 rectangle multipliers iff the
cell has a rectangle, nc = number of caps), and every certificate passed it, so the hazard is not triggered by the
data. Recommend RQ-B add the same assertions.

## Overall verdict on "Conjecture S holds for all q": VALID

The links combine as follows.

1. Fix q in (0, q5]. By link 1, R(q) = M(q) follows from ID*(C5) for finitely supported probability K. By link 2,
   only K on [-A'(q), A'(q)] with A'(q) <= A'(q5) = 1.538 < 1.54 are needed.
2. ID*(C5) with theta = 0.85 on [-1.54, 1.54] holds on three regions, with closed and open thresholds that fit
   together:
   - V+ >= 4/5 or V- >= 4/5: RQ-D Theorem 13 (band).
   - 1/2 <= V+- < 4/5: RQ-D Theorem 16 (heavy).
   - V+, V- < 1/2: RQ-B Theorem 13.1 (light), with 171/200 < C5.
3. Hence R(q) = M(q) on (0, q5]. The mirror q -> 1 - q gives [1 - q5, 1). RQ-A MAIN-1..6 (taken as given) covers
   [q6, 1 - q6], which contains [q5, 1 - q5] since q6 < q5.

Nothing in the chain is circular. No link uses Conjecture S, RQ-D's C5 statement (R_ID = sqrt(2/e)), Theorem 10 or
Corollary 11, or RQ-C's chain check, which I did not use.

## What I re-ran

- `python3 ref/rig.py` (self-test of my enclosures of exp, log, sqrt, pi, Phi against mpmath at 300 bits): OK.
- `python3 ref/constants.py` -> `logs/constants.txt`: 27 PASS, 0 FAIL.
- `python3 ref/bern.py`, `python3 ref/moments.py` (self-tests) -> `logs/selftests.txt`: OK; 81 product tuples of
  length <= 5, as RQ-D states.
- `python3 ref/heavy_verify.py --procs 8 --controls` -> `logs/heavy_verify.txt`: ALL CHECKS PASSED, controls
  rejected (details in link 3).
- `python3 ref/heavy_sanity.py 1 12 200` -> `logs/heavy_sanity.txt` (evidence only): OK.
- `python3 ref/light_verify.py {chord,light,nsplit} --procs 8` -> `logs/light_verify_{chord,light,nsplit}.txt`:
  ALL CHECKS PASSED in each case (details in link 4). The logs are from the final file (md5 4f0d5c17…), re-run
  after adding the read-only hook used by the controls; the results are unchanged.
- `python3 ref/light_controls.py --n 40` -> `logs/light_controls.txt`: ALL CONTROLS BEHAVE AS EXPECTED.
- `python3 ref/light_semantic.py --n 1500 --seed 20261023` -> `logs/light_semantic.txt` (evidence only): no
  violation.
- `python3 ref/chi.py` (self-test: qq_hi, chi^B and chi^C, and linear bounds against mpmath) and a from-scratch
  rebuild of the qq table -> `logs/selftests.txt`: OK; the rebuilt table is identical to the cached one the run used.
- `python3 ref/band_verify.py --procs 8 --levels 6 --out ../logs/band_verify.txt --jsonl ../logs/band_verify_squares.jsonl`:
  RESULT: EVERY SQUARE CERTIFIED (details in link 3).
- `python3 ref/band_controls.py --out ../logs/band_controls.txt`: coverage re-check OK; ALL CONTROLS BEHAVE AS
  EXPECTED.
- `python3 ref/band_semantic.py --n 500 --seed 20261023 --out ../logs/band_semantic.txt` (evidence only): no
  violation in 1500 samples.

Environment: Python 3.12, gmpy2 (exact rationals), mpmath (self-tests only), numpy and scipy (semantic tests only).

## Gaps and remarks

There is no gap affecting validity. There are two robustness remarks, neither of which affects the result:

1. RQ-B's verifier (`far_verify.check_linear_dual`) does not enforce the lengths of the atom and rectangle
   multiplier lists (link 4). The hazard is not triggered by the data, and my verifier enforces the lengths.
2. RQ-D's band run (Theorem 13) stores no box-level certificate, only per-square summaries. The published run
   therefore cannot be audited box by box, and the theorem rests here on my independent cover. I recommend that
   RQ-D store, per leaf box, the method, option and h, so that a checker can replay it.

Minor points that need no fix: the margins are genuinely tight. They are 0 on the Dirac curve, handled at first
order in rho^2 by the slope check and Lemma 12, and below 1e-3 along the hypotenuse of the band, and about 3e-6 in
the light region (171/200 - U). All of these are decided exactly, so the tightness is no defect.
