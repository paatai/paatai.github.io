# RQ-REF3: independent referee of the all-q chain for Conjecture S

This repository is an independent referee's re-check of the chain that claims Conjecture S,

    R(q) = sup E|sum a_i chi_i| / ||a||_2 = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1),   qh = max(q, 1-q),

for every q in (0, 1) (chi_i i.i.d. normalised q-biased bits), on the range (0, q5] not covered by RQ-A's MAIN-1..6.

The report is `REFEREE.md` (one verdict per link plus an overall verdict). Every computer step of the refereed proofs
is re-done here by code written from the mathematical statements alone; the authors' and the auditor's programs are
not used. All decisions are exact comparisons of rational numbers (gmpy2 `mpq`); irrational quantities (exp, log,
sqrt, pi, the normal law) are enclosed by `ref/rig.py`, which implements its own series with explicit remainders.

## Layout

- `REFEREE.md`: the report.
- `ref/rig.py`: rigorous enclosures in exact rational arithmetic (self-test: `python3 ref/rig.py`).
- `ref/constants.py`: exact checks of every constant of the chain (C5, 171/200 < C5, C_K, q5, q6, A'(q5) < 1.54, ...).
- `ref/bern.py`, `ref/moments.py`: exact Bernstein subdivision and cumulant-to-moment expansion (self-tests).
- `ref/heavy_verify.py`: independent verifier of RQ-D's heavy far-region certificates (Theorem 16);
  `ref/heavy_sanity.py`: random-instance evidence test.
- `ref/light_verify.py`: independent verifier of RQ-B's light far-region certificates (Theorem 13.1);
  `ref/light_controls.py` (negative controls), `ref/light_semantic.py` (random-instance evidence test).
- `ref/chi.py`: exact upper bounds of the stop-loss costs chi^B_h, chi^C_h and their linear bounds (self-test).
- `ref/band_verify.py`: independent re-proof of RQ-D's band Theorem 13 (own cover of D*, own bounds);
  `ref/band_controls.py` (coverage re-check and controls), `ref/band_semantic.py` (random-instance evidence test).
- `logs/`: outputs of the runs quoted in the report.

## Running

Python 3.12 with the packages in `requirements.txt` (`pip install -r requirements.txt`). The certificate files are
read from this archive (`RQ-D/outputs/plus_cert/`, `RQ-B/numerics/cover_final/`, paths relative to the archive root).
Run from `ref/`:

    python3 rig.py; python3 bern.py; python3 moments.py; python3 chi.py    # self-tests
    python3 constants.py                                                   # exact constants
    python3 heavy_verify.py --procs 8 --controls                           # heavy far region (Theorem 16)
    python3 light_verify.py all --procs 8                                  # light far region (Theorem 13.1)
    python3 light_controls.py --n 40; python3 light_semantic.py --n 1500
    python3 band_verify.py --procs 8 --levels 6 --out ../logs/band_verify.txt --jsonl ../logs/band_verify_squares.jsonl
    python3 band_controls.py --out ../logs/band_controls.txt                # needs the jsonl of the run above
    python3 band_semantic.py --n 500 --out ../logs/band_semantic.txt

Each verifier prints a summary and exits with status 0 only if every check passes. The band run takes about 9 minutes
on 8 processes; `chi.py` caches its qq table in `/tmp` (rebuilt in about 20 s if absent).
