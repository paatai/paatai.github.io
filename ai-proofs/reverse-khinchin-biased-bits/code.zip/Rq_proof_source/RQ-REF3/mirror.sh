#!/bin/bash
# Mirror the referee report, code and logs to the referee's store directories.
set -e
cd "$(dirname "$0")"
commit=$(git rev-parse --short HEAD)
for dest in /cursor/stores/bot/rq/RQ-REF3 /cursor/stores/self/RQ-REF3; do
  mkdir -p "$dest/ref" "$dest/logs"
  cp REFEREE.md README.md requirements.txt mirror.sh "$dest/"
  cp ref/*.py "$dest/ref/"
  cp -r logs/. "$dest/logs/" 2>/dev/null || true
  {
    echo "Mirrored $(date -u '+%Y-%m-%d %H:%M:%S') UTC from commit $commit (branch main)."
    grep -m1 '^\*\*Status' REFEREE.md || true
    echo
    (md5sum REFEREE.md README.md requirements.txt ref/*.py)
  } > "$dest/LAST_MIRROR.txt"
done
echo "mirrored commit $commit"
