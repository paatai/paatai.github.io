# R(q) attack: common rules (Paata Ivanisvili)
Deadline: Thu Oct 22 2026, 22:30 PT (Fri Oct 23 05:30 UTC). Work nonstop until then, or until the problem is completely solved.

## Problem (exact)
For q in (0,1) let chi_1, chi_2, ... be i.i.d. with
  Pr[chi = sqrt((1-q)/q)] = q,  Pr[chi = -sqrt(q/(1-q))] = 1-q   (so E chi = 0, E chi^2 = 1).
Define
  R(q) = sup over n >= 1 and alpha in R^n \ {0} of  E|sum_i alpha_i chi_i| / (sum_i alpha_i^2)^{1/2}.
GOAL: determine R(q) exactly for EVERY q in (0,1) (closed form or an exact characterisation, e.g. as a max over an explicit finite/one-parameter family, with proof), together with the extremisers (or extremising sequences).

## Known facts (verify before relying on them)
- R(q) = R(1-q) (chi -> -chi). R(q) <= 1 (Cauchy-Schwarz). R(1/2) = 1.
- Lower bounds: n=1 gives 2 sqrt(q(1-q)); CLT gives sqrt(2/pi); alpha=(1,1)/sqrt2 gives sqrt2 (1-q) * 2 sqrt(q(1-q)) for q <= 1/2 (Stone's thesis §4.2).
- BF3 Theorem K (attached BF3_approx_polymorphisms_final.pdf, §9.4, Remark 9.8): R(q) = 2 sqrt(q(1-q)) for q in [3/8, 5/8]. Status: the case q=3/8 (and hand cases 2/5, 5/12) was audited and refereed VALID; the extension to all of [3/8,5/8] via exact rational interval arithmetic is auditor-checked only. BF3 conjectures R(q) = 2 sqrt(q(1-q)) exactly for 1-1/sqrt2 <= q <= 1/sqrt2; numerics with n <= 7 found no other obstruction. For q < 1-1/sqrt2 the two-coefficient example beats n=1.
- Literature: Ivanisvili–Li–van Handel–Volberg arXiv:1811.05584 (R(q)<1 near 3/4, L1-Poincare); Ivanisvili–Stone arXiv:2407.04835 (Sharpening the gap between L1 and L2 norms; bounds on R(q)); Y. Stone PhD thesis UCI 2025 (escholarship.org/uc/item/2wv0w7cz); van Handel bound quoted in Ivanisvili–Stone; L. Yu arXiv:2608.29703 (sharp small-coefficient Khintchine, zero-bias); Oleszkiewicz 2003 (nonsymmetric Khinchine–Kahane). Check for any 2024-2026 follow-ups.
- Note: as q -> 0 the n=1 value -> 0 while CLT gives sqrt(2/pi), and Poisson-type limits (many tiny-q bits) may matter; the small-q regime is genuinely different.

## Protocol (hard-math-attack)
1. SOTA.md first: exact statement, best known bounds with citations, follow-ups up to Oct 2026.
2. CLAIMS.md: every claim tagged PROVED / CONDITIONAL / NUMERICAL / CONJECTURE / FAILED, with proof or pointer.
3. Try several genuinely different mechanisms first; reduce failure to the smallest missing lemma; try to break your own crucial lemma before investing in the rest.
4. A claimed result goes in MAIN_RESULT.md plus a LaTeX-compiled MAIN_RESULT.pdf (full, uncompressed proof). Computer-assisted steps must be rigorous (exact rational or certified interval arithmetic), with scripts and outputs committed.
5. Commit and push at least every 30 minutes, and mirror your working folder to /cursor/stores/bot/rq/<YOUR_ID>/ each time (if that path is not writable, say so in STATUS.md and keep committing).
6. If you run out of ideas, write STATUS.md: what is established, the exact failure point, the extra statement that would remove it, then attack that statement.
7. Never lower the proof standard. Numerics are evidence, not proof.

## UPDATE 2026-10-22 07:15 PT — NEW GOAL (Paata: "prove that conjecture")
Target: Conjecture S for ALL q in (0,1):
  R(q) = 2 sqrt(q(1-q)) * max_{k>=1} sqrt(k) * qh^(k-1),  qh = max(q,1-q).
Proved+audited so far: [1-sqrt3/2, sqrt3/2] (RQ-A MAIN 1-4). k=4,5 covers in progress.
Regime-by-regime computer covers cannot finish infinitely many k. Needed: a mechanism uniform in k
(e.g. for all q <= q_K by an analytic/Poisson-type argument, then finitely many covers for k < K).
Protocol unchanged: auditor + independent referee; never lower the standard. Deadline extended to Sun Oct 25 2026 22:30 PT.
