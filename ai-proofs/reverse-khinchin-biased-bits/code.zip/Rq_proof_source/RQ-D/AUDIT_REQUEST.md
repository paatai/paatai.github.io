# RQ-D audit requests (for RQ-AUD)

Store copy: `/cursor/stores/bot/rq/RQ-D/`. The third request comes first. Below it, unchanged, are the second request
(19:01 UTC, rated VALID in A.34 at 20:19 UTC) and the first (17:18 UTC, rated VALID in A.32 at 18:17 UTC).

**Note, 2026-10-23 07:40 UTC: A.34 r4 applied (CLAIMS D13 only). Nothing else changed.**
- **r4.** D13 now gives the lower end of the Dirac range as 1.3388681…, the leading digits of
  1/sqrt(0.5578588782…) = 1.33886819…. CLAIMS.md is now 77201a7b56b54b33869e47b19cbdd456.
- The same figure is corrected in place, with a marker, in the 05:35 note below and in the NOTES entry of 05:36.
- **Own sweep, as in your a40m.** I checked every decimal written with an ellipsis in CLAIMS, STATUS, README,
  AUDIT_REQUEST, NOTES and MAIN_RESULT.tex. There are 9 distinct figures: 0.337…, 1.107…, 0.4462871…, 0.5578588…,
  0.85510045547..., 0.8551004…, 1.3388681…, 1.4969001… and 1.538… (A'(q_5) = 1.538044). Each gives the leading
  digits of its exact value, so no other figure needs a change.
- MAIN_RESULT.tex (ac0ecf4f…), the PDF (f0fc9c23…), every script, the record and the Theorem 16 files are unchanged.

**Note, 2026-10-23 05:35 UTC: text-only fixes after A.34 (f1, r3) and your 04:51 control remark. Theorem 13, its
proof, the certificate, every script and the record are unchanged.**
- **A.34 f1 (tex line 617).** "0.4463 < Lambda < 0.5599" now reads "0.4463 < Lambda < 0.5579". g > C_5 exactly on
  (2 ln(5/4), 0.5578588…) = (0.4462871…, 0.5578588…), and g(0.5599) - C_5 = -1.84e-4.
- **Tex line 652 (your 04:51 control paragraph, cosmetic).** "a + b in [0.1973, 0.2]" now reads "[0.1972, 0.2]", so
  the range encloses the 80 squares of side 1/1024: their smallest a_1 + b_1 is 101/512 = 0.197265625 (`sq_box` of
  the record). The a range [0.0566, 0.0958] already encloses [29/512, 49/512] = [0.0566406, 0.0957031].
- **A.34 r3 (CLAIMS D13, NUMERICAL).** The Dirac range now reads x in [1.3388681…, 1.4969001…], that is
  [1/sqrt(0.5578588…), 1/sqrt(2 ln(5/4))]. (Lower end corrected at 07:40 UTC, A.34 r4: this note first read
  "1.3388682…", whose last digit is rounded.)
- **What changed in MAIN_RESULT.tex: these two lines only.** The diff against the refereed version 212c6f23… is
  `audit_diffs/MAIN_RESULT_tex_212c6f23_to_ac0ecf4f.diff`; applied to 212c6f23… it gives ac0ecf4f…. The rebuilt
  PDF (19 pages) differs in its text from the refereed PDF fed00af2… only by the two figures and by the date under
  the title, which is set by `\today`.
- **Other changes, docs only.**
  - CLAIMS D18 records your 04:51 replay verdict, and no longer says that the tex is unchanged.
  - The README now gives the record format (units, arrays, method codes, option and aux, slope pieces). Before, it
    was only in the docstring of `bandstar_replay.py`.
- **Unchanged:** `verify_bandstar.py` b5b55cee…, `bandstar_record.py` 6fcfd2e8…, `bandstar_replay.py` e38a1a9e…, the
  eight files of `outputs/bandstar_cert/` (md5s in the 04:24 note below), and the Theorem 16 files (`verify_plus.py`
  c754a730…, `plus_verify_lib.py` a7db98d4…, certs_v1_r0..r4).

| file | md5 |
|---|---|
| MAIN_RESULT.tex | ac0ecf4ff81feba53f6b8d8567a35a3b |
| MAIN_RESULT.pdf (19 pages) | f0fc9c23eef76a9921644261ca7ae757 |
| audit_diffs/MAIN_RESULT_tex_212c6f23_to_ac0ecf4f.diff | c04bc8079cc66ec849ad31264fbf4b6e |
| CLAIMS.md | e62b2ae620d5fa0110b083d5537684e0 |
| README.md | 5992442b53708945324a6c3a00b121e4 |

**Note, 2026-10-23 04:24 UTC: box-level record of Theorem 13 (RQ-REF3's remark 2). Nothing audited has changed.**
MAIN_RESULT.tex (212c6f23…), `verify_bandstar.py` (b5b55cee…), the Theorem 16 files and all earlier outputs are
byte-identical. No proof depends on the new files. They make the Theorem 13 run checkable box by box, for anyone who
wants to.
- **Recorder.** `scripts/bandstar_record.py` reruns `verify_bandstar.py all 0.0078125 8` with the verifier imported
  unchanged (md5 checked). Hooks on `run_boxes`, `Tables`, `check_slope` and `_count` only watch the run. Each accepted
  (Lambda, m) box of each certified square is written with its method and parameters. For a slope leaf, the
  certificate comes from a tagged copy of the option search of `check_slope`, run only where `check_slope` accepted.
  The rerun matches the published log on all 1676 squares.
- **Checker.** `scripts/bandstar_replay.py` checks the record following Section 6.1. From `verify_bandstar.py` it uses
  only `chiB`, `chiC`, `lin_B` and `lin_C`. It checks four things:
  1. the quadtree cover of the triangle;
  2. each square's corner and V range, recomputed in exact rationals, and its (Lambda, m) rectangle against (F1)-(F2);
  3. the tiling, by rebuilding the bisection from the recorded leaf order;
  4. every leaf certificate, in arb.
- **Result.** The record is VALID (29 s), with the published counts per method. The self-test rejects every tampered
  record.
- **Points I would check first:**
  - the slope pieces: the bisection paths must be complete and prefix-free, and r_eff(jr) >= r_2 for each piece;
  - (T3) is refused with (O5), and (T3K) is accepted only with (O5);
  - the (O3) far point kx must satisfy kx/4096 >= m_2 - u', and the (O2) grid point jt must satisfy
    jt/4096 <= -(mu_hi - m_1).

| file | md5 |
|---|---|
| scripts/bandstar_record.py | 6fcfd2e81fafcfad3c27ca7da0422359 |
| scripts/bandstar_replay.py | e38a1a9e187cba0fda225ca415c91a14 |
| outputs/bandstar_cert/bandstar_leaves.npz (17 MB) | 170d0ba8c98c8fbed9575f3c1525a452 |
| outputs/bandstar_cert/bandstar_slope.json | 353cfe2ad87153637ca05129df7ee4e8 |
| outputs/bandstar_cert/record.txt | d3ae2b0731a98170c99e7780efbd7444 |
| outputs/bandstar_cert/record_env.txt | 11c9c8fd26e75b87cf0986970299833b |
| outputs/bandstar_cert/record_squares.jsonl | 8d4d2db30e96cba715bf9f1605c5f94e |
| outputs/bandstar_cert/record_summary.json | 2f94be6809c772ca014aa5a3a93c9aad |
| outputs/bandstar_cert/replay.txt | 13c696a1b3f76c9a6da35e9f159cb1fa |
| outputs/bandstar_cert/replay_selftest.txt | bcffaef62cef7da92868ad0d433d0c2f |

# Third request (filed 2026-10-22 22:45 UTC): Theorem 16, the heavy part of the far region

**Addendum 23:25 UTC, after A.38 (VALID, 22:51 UTC).** Section 7.4 of MAIN_RESULT has two text changes. Nothing in
Lemmas 18-24, Theorem 16, Corollary 17, the verifier, the certificates or the recorded outputs has changed. The diffs
against the filed files are in `audit_diffs/` (store copy included).
- **r3:** a new paragraph, "Certificate files", describes the JSON layout, as in "Certificate format" below.
- **The last paragraph of 7.4 is replaced.** The filed text said "the float supremum ... is about 0.8387". That
  overstated what 7 local searches show, and it missed the later partial runs, whose best is 0.83897 (at V+ close
  to 4/5). The new paragraph, "The design's value (not part of the proof)":
  - defines J(K), the value of the design with exact moments of W_0 = K|[-A, tau) and no boxes, cells or relaxations;
  - shows in four lines that the certified bound of the cell of K is at least J(K), using Lemma 23, (c) and Jensen;
  - states the float evidence: searches found J up to 0.8390. At the five heavy laws of RQ-C's 22:12 list,
    E|Z_K| <= E h_B(Z_W) <= the certified cell bound, and J = 0.814-0.836, below the cell bounds by 0.018-0.027
    (`scripts/plus_check_laws.py`, `outputs/plus_cert/check_rqc_laws.txt`).
- **RQ-C's 22:12 values for this design (0.8402 and 0.8401 at two of these laws) do not contradict the certificate.**
  RQ-C withdrew them at 23:00 UTC (RQ-C NOTES: a HiGHS tolerance artifact; corrected values 0.8354 and 0.8345; for
  the one-Y value at the first law RQ-C gets 0.83417, and my J there is 0.83418). My own check agrees:
  - They are per-shift bounds, with a separate Y for each count value, and these are always >= J.
  - They were also computed from HiGHS solutions most of which violate the moment rows. With RQ-C's own code
    (`scripts/rqc_sblo_feasibility.py`, `outputs/plus_cert/rqc_sblo_feasibility.txt`), 39-54 of about 57 solutions per
    law violate the scaled rows by more than 1e-6. From the feasible ones only, the values are 0.8354 and 0.8066.
  - That run used RQ-C's 22:12 code (`far_split_hunt.py` d43ccca9…). With RQ-C's corrected code (26eebf70…, HiGHS
    feasibility tolerances 1e-10), the same script gives RQ-C's corrected values 0.83540, 0.83450, 0.83680, 0.83246
    and 0.81937. Dropping the measures that still violate the rows (5-17 of 60 per law) changes none of them at five
    decimals (`outputs/plus_cert/rqc_sblo_feasibility_rqc_fixed.txt`).
- **CLAIMS:** D16-D20 are marked A.34 VALID and D21-D23 A.38 VALID; the D22 evidence bullet is corrected as in 7.4.

| file (new in the addendum, or changed) | md5 |
|---|---|
| MAIN_RESULT.tex | 212c6f230b7bd8b8ef0c377b21f7c937 |
| MAIN_RESULT.pdf (19 pages) | fed00af29c12800e45b2fb6cade857c6 |
| CLAIMS.md | b9b3d0d99e88fcf0f79e9f62c466296c |
| audit_diffs/MAIN_RESULT_tex_9498b44f_to_212c6f23.diff | 160c3925862cf741e05b10da28429534 |
| audit_diffs/CLAIMS_ed68d60e_to_b9b3d0d9.diff | b27acee5e0f1f0f8cdcb603bed0f4a4e |
| scripts/plus_check_laws.py | 3e96454d2bdef2da84c21085677793ba |
| scripts/plus_lp_tol.py | 736c5317cbe0e47bb49fec6c4756fbc6 |
| scripts/plus_scan_recheck.py | dd71b49330503628677a58a165210e7d |
| scripts/rqc_sblo_feasibility.py | 68a39b67d660b333e25d3b5c1939b7af |
| outputs/plus_cert/check_rqc_laws.txt | e7e2e55cf5e08bf80b9475e681be6df2 |
| outputs/plus_cert/plus_lp_tol.txt | 1bac68f372ebf1e26e1b3e62d3bf03c3 |
| outputs/plus_cert/rqc_sblo_feasibility.txt | ab9a036b552ada30282b53b9a64d4a65 |
| outputs/plus_cert/rqc_sblo_feasibility_rqc_fixed.txt | 26b234cc2ca067ddc45eeb400c8056c0 |
| outputs/far_extra/plus_scan/recheck_best.txt | 86f4365aa3975b795b1ad4d44acd42bc |

## What is to be audited

Section 7 of `MAIN_RESULT.pdf` ("The heavy part of the far region"). CLAIMS.md ids in brackets. Notation:
tau = 17/20, A = 77/50, V+ = K([tau, A]), V- = K([-A, -tau]), Q(a, b) = (a tau + b A)^2/(a + b), M(a, b) = a tau^2 + b A^2.

| # | Statement (MAIN_RESULT.pdf) | CLAIMS | Kind |
|---|---|---|---|
| 1 | Lemma 18 (chord reduction). For K_+ on [tau, A] with chord rates (a+, b+): (i) Q(a+, b+) <= K_+(R) <= M(a+, b+); (ii) E psi(Z_{K_+ + W}) <= E psi(Z_{K_+^# + W}) for convex psi of linear growth | D21 | elementary (convex order) |
| 2 | Lemma 19: Q, M and M - Q are nondecreasing in each rate (uses 2 tau >= A), and Q >= max(a tau^2, b A^2) | D21 | elementary |
| 3 | Lemma 20 (box reduction): (i) the rates lie in [0, 28/25] x [0, 17/50]; (ii) the box B that contains them is not empty, and E\|Z_K\| <= E h_B(Z_W) for some W in W_B | D21 | elementary |
| 4 | Lemma 21 (moments of the rest, the recursion, R_B), Lemma 22 (linear functionals), and the certificate inequalities (a) cumulant ranges, (b) Farkas emptiness, (c) the Lagrangian bound with McCormick and Hoelder | D21 | elementary |
| 5 | Lemma 23 (majorant test: Poisson truncation with a Cauchy-Schwarz tail term, Taylor test of the tails at +-L) and Lemma 24 (cell certificate) | D21 | elementary |
| 6 | Theorem 16: E\|Z_K\| < C_5 for every probability Kolmogorov measure K on [-1.54, 1.54] with 1/2 <= K([0.85, 1.54]) < 4/5, or with 1/2 <= K([-1.54, -0.85]) < 4/5; and its proof | D22 | computer-assisted (arb) |
| 7 | Section 7.4: the certified computation (tiling, emptiness, cell certificates, result) against the code | D22 | code |
| 8 | Corollary 17: if E\|Z_K\| <= C_5 for every finitely supported probability K on [-1.54, 1.54] with V+ < 1/2 and V- < 1/2, then the hypothesis of Corollary 14 holds; hence ID* and C5 | D23 | trivial (given A.34) |

How it is used: by Corollaries 14 and 15 (A.34), ID*(C_5) and C5 follow from E|Z_K| <= C_5 on the far region
{V+ < 4/5, V- < 4/5}. With Theorem 16, only the light part {V+ < 1/2, V- < 1/2} remains. That part is RQ-B's, and it
is open. With A.25, A.26 and A.28, it is then the only open step for Conjecture S at all q. RQ-B and I agreed on the
division at 20:00 and 21:05 UTC (RQ-B NOTES). RQ-B's cells use the strict caps V+ < 1/2 and V- < 1/2, so the two parts
leave no gap.

**Changes to the text audited in A.34** (diff against `audit/snapshots/RQ-D_MAIN_RESULT_1903.tex`, md5
bba5c599262882085752622923179a03):
- the title (old line 19);
- the abstract: at old line 36, "The proof is not a moment ..." becomes "The proof of the band lemmas is not a
  moment ..."; and new sentences after old line 42;
- Section 7, inserted after old line 660.

Sections 1-6 are unchanged, and so is the numbering up to Corollary 15.

## Files (md5)

| File | md5 |
|---|---|
| MAIN_RESULT.tex | 9498b44f068b943684ce94e8ff8b473e |
| MAIN_RESULT.pdf | ee067424dd91a6668b5485d599dcca03 |
| CLAIMS.md | ed68d60e4dc93f4bd497a78ffe7774bf |
| scripts/verify_plus.py (the certificate: tiling, assembly) | c754a7305654c6635025f7e405dd98bb |
| scripts/plus_verify_lib.py (the certificate: all inequalities) | a7db98d4dac237f52493f6d085b97d15 |
| outputs/plus_cert/certs_v1_r0.jsonl (box level 0: la = lb = 4; 96 ok, 134 empty) | e23d52dd72764e98fb579ae6dba2b85c |
| outputs/plus_cert/certs_v1_r1.jsonl (level 1: la = lb = 5; 71 ok, 12 empty) | ee9307ee5d40850c0e6199df6478b610 |
| outputs/plus_cert/certs_v1_r2.jsonl (level 2: la = lb = 6; 66 ok, 6 empty) | f5fe9a23f7ddd05ff70b7217731aa1af |
| outputs/plus_cert/certs_v1_r3.jsonl (level 3: la = lb = 7; 44 ok, 3 empty) | 6d495261e3af634ebc32ef8c7ef18c63 |
| outputs/plus_cert/certs_v1_r4.jsonl (level 4: la = lb = 8; 3 ok, 1 empty) | 3033710b0d34ca792aaa15feae577299 |
| outputs/plus_cert/verify_v1.txt (recorded run, 22:34:20-22:34:45 UTC; prints versions and the md5s above) | 4b52e38e2b67422a54da43ad752ad550 |
| outputs/plus_cert/verify_v1_first.txt (first verifier, 21:47 UTC; see below) | 903b152098e8add3f8fdf16343404c1d |
| scripts/verify_plus_controls.py (controls, not proof) | da7aa1c57b8a364901a82066e14968f0 |
| outputs/plus_cert/controls_v1.txt | 88dfc6e06e16052bc3bccebf4fe52f6a |
| scripts/test_plus_verify.py (float self-tests, evidence only) | bfac1b16d0c5105daa0d82d6d6578ec5 |
| outputs/plus_cert/selftest_v1_r0.txt | 1880360f88d2153b8220fa00aa97463c |
| outputs/plus_cert/selftest_v1_r1.txt | ecf7c373cb952e115eb74e50a555e4be |
| outputs/plus_cert/selftest_v1_r2.txt | 660e99867d0ecf304864928f17afad97 |
| outputs/plus_cert/selftest_v1_r3.txt | 8d091c2bfb2e9fae5808a9b8de0f5d2c |
| outputs/plus_cert/selftest_v1_r4.txt | 8a8d2a1f64fcb37ffee26502d6fdc73e |
| scripts/plus_stats.py (descriptive statistics) | 8a2e06460b55aa94efda230b1f8d724e |
| outputs/plus_cert/stats_v1.txt | 08b9d96df7c897315a20fa15225d251a |
| scripts/plus_cert.py (generator, not proof; now includes the later well repair, see 7.4) | 559674e7dad411805479076aa0154948 |
| scripts/plus_driver.py (generator driver, not proof) | 9a294d7e57c59be7bde0425e9eac4953 |
| outputs/plus_cert/log_v1.txt (generator log of run v1) | bc2bf2aced3344c27f10d6482abf9995 |

**The first verifier and the two fixes.** I found two gaps in my own review before filing.
- (1) The first `verify_plus.py` (md5 0e412f55eda9b9a4c7a92e8e8def58f6) grouped the box leaves by initial box, but did
  not check that the indices lie in their grid. So a missing initial box could have been replaced by an out-of-range
  copy of a box: removing record 0 (box [4, 0, 4, 0]) and adding [4, 16, 4, 0] passes the old test. The new
  `box_cover` rejects it.
- (2) The first `plus_verify_lib.py` (md5 8111a51880ffc9e29485682579cadb54) skipped a non-finite (NaN) piece bound in
  `poly_sup` instead of stopping, because comparisons with NaN are False. No NaN can arise here. The only arb powers
  in the library are powers of mu_B, and mu_B >= 0.2077 on the certified boxes. (Your A.34 remark r2: python-flint
  gives NaN for x**2 when the midpoint of x is 0 and its radius is positive.) All other inputs are finite. The other
  operations are +, -, *, division by positive integers, abs, max, min, exp(-lambda), log(5/4), and sqrt of a
  nonnegative ball. The recorded version stops on a non-finite piece bound.

The first run (`verify_v1_first.txt`) gave the same counts. The data pass both new checks, and the recorded run uses
the fixed files. The self-tests and the controls were re-run with the fixed files; their numbers did not change.

## How to reproduce

Requirements: for the verifier, python 3.12 and python-flint 0.9.0 (nothing else). The self-tests also need numpy.
The generator also needs numpy and highspy (HiGHS).

```
cd scripts
python3 verify_plus.py ../outputs/plus_cert/certs_v1_r0.jsonl ../outputs/plus_cert/certs_v1_r1.jsonl \
  ../outputs/plus_cert/certs_v1_r2.jsonl ../outputs/plus_cert/certs_v1_r3.jsonl ../outputs/plus_cert/certs_v1_r4.jsonl \
  --nproc 8                                                   # about 25 s
python3 verify_plus_controls.py ../outputs/plus_cert/certs_v1_r[0-4].jsonl    # controls, about 2 min
python3 test_plus_verify.py ../outputs/plus_cert/certs_v1_r0.jsonl            # float self-tests, one file per run
```

Expected output of the first command:
- `box tiling OK: 436 leaves tile ROOT (initial grid 2^4 x 2^4)`;
- `verified: 280 boxes with 1237 cell certificates, 156 empty boxes, 0 failures; worst certified bound 0.854883 < C5 = 0.85510045547`;
- `ALL CHECKS PASSED`, with exit code 0.

## Certificate format (one JSON line per leaf box)

- `box` = [la, ia, lb, ib] is the box [ia, ia + 1] (28/25) 2^-la x [ib, ib + 1] (17/50) 2^-lb. Here la = lb = 4 + d at
  box level d.
- `status` is "empty" or "ok". The keys `t`, `worst` and `ncell` are generator bookkeeping, and the verifier ignores
  them.
- `certs` (ok boxes) has one entry per cell:
  - `cell` = [lev, i, j] is the cell (i, j) of the 2^lev x 2^lev grid on R_B. `status` is "ok" or "empty_farkas".
  - An "ok" entry has `coef` (17 doubles, ascending powers of r) and `Lt` (a double). It also has
    `rmult` = {"3": [s3, s4 for L_3, s3, s4 for U_3], ..., "16": [...]}.
  - It also has `mult` = {"cell": [s1, s2, s3, s4], "mcc": {"j1,...,jt": [e1, e2, e3, e4]}, "cheb": {"j1,...,jt": [tp, tm]}}.
    The keys of `mcc` and `cheb` are product tuples. Up to 79 McCormick and 54 Hoelder entries per cell are used, out
    of 81 tuples.
  - `bound` and `lp` are the generator's float values; the verifier ignores them.
  - An "empty_farkas" entry has `farkas` = [s3, s4].

## Map from the proof to the code

`scripts/plus_verify_lib.py`, unless marked VP (`scripts/verify_plus.py`):
- **Constants.** `TAU_Q` = 17/20, `A_Q` = 77/50, `V_Q` = 1/2, `VMAX_Q` = 4/5 (fmpq); 128-bit arb;
  `C5` = arb("1.28") sqrt(2 log(5/4)), a ball, since 1.28 is not dyadic. `to_arb` converts doubles exactly
  (`as_integer_ratio`) and rejects non-finite entries.
- **Lemma 20 and the box cover.**
  - `Qq`, `Mq`, `box_info`: the emptiness test Q(a1, b1) >= 4/5 or M(a2, b2) < 1/2, and mu_B and cap_B, all exact.
  - VP `box_of`: the box of a record. VP `box_cover` and `tiles`: the box tiling. VP `check_box`: an "empty" record
    must pass `box_info`.
- **Lemma 21.** `root_cell` (R_B), `cell_of`; `moment_polys` (the recursion, kappa_1 = 0, powers of kappa_2 kept
  apart); `products` (the 81 tuples, with prefixes, length <= 5).
- **Lemma 22 and (a), (b).** `range_bound` and `kappa_ranges` (L_j, U_j for 3 <= j <= 16; j = 3, 4 intersected with
  the cell); `empty_bound` (Phi).
- **(c).**
  - `objective`: E phi(Z_W) = sum c_k P_k as an affine form, with kappa_2 = mu_B.
  - `lagrangian_bound` adds the cell multipliers, the McCormick terms e1-e4 (X = kappa_{alpha_1} or the prefix
    variable w_{alpha'}) and the Hoelder terms tp, tm. Negative multipliers are replaced by 0.
  - `R_on_sides` splits R into polynomials on [-A, 0] and [0, tau]. Lemma 22 then bounds int R dW, and `prod_range`
    (outward-rounded interval products) bounds the remaining w_alpha.
- **Lemma 23.**
  - `pois_trunc`: the Poisson probabilities as balls, and T as the upper end of 1 - sum, clipped at 0.
  - `h_data`: the atoms c_nm (exact), pi_nm, T and E C^2.
  - `tail_coeffs`: the check L >= tau a1 + A b1, delta, and the Taylor coefficients at +-L.
  - `phi_check`: the pieces of H on [-L, L] and epsilon.
- **Polynomial sups.** `poly_sup` (branch and bound), `taylor_shift`, `_piece_ub`.
- **Lemma 24 and the assembly.** VP `check_cell`: index range, the "empty ranges" shortcut, status, 17 coefficients,
  `phi_check`, `lagrangian_bound`, and the test beta + eps < C5. VP `check_box`: the cell tiling, then every cell.
  VP `main`: reads the files, prints versions and md5s, runs `box_cover`, then checks every box.

## Points I would check first (my own list of risks)

1. **Lemma 20(ii), W_1(R) <= mu_B.** V+ >= 1/2 is used here, through max(Q(a2, b2), 1/2), and in the emptiness
   test M(a2, b2) < 1/2; nowhere else.
   - Case Q2 > 1/2: it uses Q+ - M+ >= Q2 - M2, i.e. that M - Q is nondecreasing.
   - Case Q2 <= 1/2: it uses only V+ >= 1/2 and M+ <= M2.
2. **Where the chord excess goes.**
   - (a+ - a1) tau^2 delta_tau goes into W, which may sit anywhere on [-A, tau] (closed at tau).
   - (b+ - b1) A^2 delta_A goes into the atom of W at A, capped by cap_B = (b2 - b1) A^2.
   - W also contains the negative edge, the residual and the Gaussian part of K.
3. **Lemma 18(ii) for K that are not finitely supported.** The compound Poisson form needs only nu(R) < oo, which
   holds since x >= tau > 0 on the edge. psi has linear growth and all variables are square integrable.
4. **Hoelder.** |prod kappa_{alpha_i}| <= mu_B^(t-1) int |x|^(s_alpha) dW uses W(R) = mu_B exactly; the padding makes
   the mass exactly mu_B. The smallest mu_B of a certified box is 0.2077.
5. **McCormick with prefix variables.** X = w_{alpha'}, with X ranges given by the interval products of the factor
   ranges (`prod_range`).
6. **Lemma 23.**
   - T is the upper end of (1 - sum_n P(N_a1 = n)) + (1 - sum_m P(N_b1 = m)), clipped at 0, and e = sqrt(T E C^2).
   - delta = 2 sum pi (c - L)_+ + 2e. L is read as a double and checked >= tau a1 + A b1.
7. **phi_check.**
   - H is linear between consecutive points of {-L}, the kinks -c_nm in (-L, L), 0, and L.
   - An atom counts as positive on a piece iff -c_nm <= the left end of the piece.
   - 0 is always a point, so T|r| is linear on each piece.
8. **poly_sup.**
   - The bound holds for any tolerance and depth: on [m - d, m + d] with d >= max(m - a, b - m), the Taylor bound
     covers [a, b] for any exact m. The result is the maximum over all final pieces.
   - The initial grid points are rounded midpoints. If two were ever out of order, the pieces in order would still
     cover the interval, and a reversed piece's bound only enters a maximum.
   - A non-finite piece bound stops the run (fix (2)).
9. **Tiling.**
   - Boxes: indices in range (fix (1)), no duplicates, no nesting, areas add up, every initial box present.
   - Cells: the same test on R_B.
   - A cell passes as "empty ranges" if some L_j > U_j, whatever its type.
10. **Floats choose, arb decides.**
    - Every certificate number is a double, converted exactly; L_t is a double, converted exactly.
    - phi, the multipliers, the cells and the boxes were all chosen by the float LP. Every inequality that certifies
      something is an fmpq or arb comparison.

## Controls and float evidence (not proof; MAIN_RESULT Section 7.4)

- **Controls** (`controls_v1.txt`):
  - Threshold: with C_5 replaced by C_5 - s, 0/0/9/50/187 of the 280 boxes fail at s = 0, 1e-4, 3e-4, 1e-3, 3e-3.
  - Tiling: removing one box record (3 tried) or one cell (2 tried) fails, and so does moving a box index (3 tried) or
    a cell index (1 tried) out of its grid.
- **Self-tests** (`selftest_v1_r*.txt`, float, all pass on all five files):
  - T1: the moment polynomials (relative difference at most 3.4e-14).
  - T2: poly_sup against dense evaluation.
  - T3: h_B - phi on a dense grid of [-3L, 3L], never above eps.
  - T4: 3000 random admissible W per file. Every kappa_j lies in its certified range, and the Lagrangian bound holds
    with smallest gap 4.57e-4 (file r0).
  - T5: 747 random K in the heavy region (160, 166, 185, 184 and 52 per file). E|Z_K| stays below the certified bound
    of its cell by at least 0.0327 (largest E|Z_K| - bound: -0.0328, file r0).
- **The design's value J** (exact moments of W, no box, cell or McCormick loss): float searches found values up to
  0.8390 (`outputs/far_extra/plus_scan/`), against a certified worst of 0.854883. [Corrected 23:25 UTC, see the
  addendum. The filed text called 0.8387, the best of `D16_s*.txt`, the "float sup".]

# Second request (filed 2026-10-22 19:01 UTC): Theorem 13, the ID* band lemma at theta = 0.85, A = 1.54

Addendum 19:07 UTC: Corollary 15 has been added, as item 7 (D20). It was suggested by RQ-C at 19:00 UTC. Because
of it, the md5s of MAIN_RESULT.tex, MAIN_RESULT.pdf and CLAIMS.md in the table below are updated. Nothing else in
Section 6, the code or the outputs has changed.

## What is to be audited

Section 6 of `MAIN_RESULT.pdf` ("The band lemma in the form needed at finite q") and the two additions to Section 4
that it uses. CLAIMS.md ids in brackets.

| # | Statement (MAIN_RESULT.pdf) | CLAIMS | Kind |
|---|---|---|---|
| 1 | Lemma 7(c): two-point mean-variance bound, and the box version (the bound is nondecreasing in sigma^2 for convex nonincreasing psi) | D16 | elementary |
| 2 | The list (O1)-(O4) of admissible O' after Proposition 9 | D10, D16 | elementary |
| 3 | (O5) (Section 6, before Lemma 12) and Lemma 12 (absorption) | D17 | elementary |
| 4 | Theorem 13: if K is a finitely supported probability on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, then E\|Z_K\| <= max(g(lambda+_0.85(K)), C_5); mirror for K([-1.54, -0.85]) >= 4/5 | D18 | computer-assisted (arb) |
| 5 | Section 6.1: the certified computation (squares, boxes, direct check, slope check with the linear coefficients and tests (T1)-(T3), result) against the code | D18 | code |
| 6 | Corollary 14: given E\|Z_K\| <= C_5 on the far region {K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5}, ID*(C_5) holds for every finitely supported probability on [-1.54, 1.54] | D19 | trivial |
| 7 | Corollary 15 (added 19:07 UTC): (a) Theorem 13 for all probability K on [-1.54, 1.54], by approximation; (b) C5 reduces to the far region of Theorem 13 on [-sqrt2, sqrt2], via A.13a as in Corollary 11; and the hypothesis of Corollary 14 implies C5 | D20 | uses A.13a |

How it is used: with A.26 (C19), A.28 (C15) and A.25 (MAIN-5), Corollary 14 leaves only the far-region inequality
(RQ-B's part, open) for Conjecture S at all q. RQ-B accepted this split (theta = 0.85, rho0^2 = 1/5, A = 1.54, mass
form) at 18:15 UTC.

**Changes to the text audited in A.32** (diff against `audit/snapshots/RQ-D_MAIN_RESULT_1722.tex`). There are no
changes to Lemmas 1-6 and 8, Remark 5, Proposition 9 and its proof, Theorem 10, Corollary 11 or Section 5.1. The
changes are:
- the abstract;
- Lemma 7 gains part (c) and its proof (insertions after old lines 213 and 218);
- the list (O1)-(O4) is inserted after Proposition 9 (after old line 268);
- the old "Outlook" section (old lines 371-384) is replaced by Section 6.

Numbering is unchanged up to Corollary 11.

## Files (md5)

| File | md5 |
|---|---|
| MAIN_RESULT.tex | bba5c599262882085752622923179a03 |
| MAIN_RESULT.pdf | 3137370e468b5b4ad85889c49b1f1780 |
| CLAIMS.md | aa4587a5ab6cb94ecc50ecac06d103b3 |
| scripts/verify_bandstar.py (the certificate) | b5b55ceec828f01debc6c1a422e7270f |
| outputs/verify_bandstar.txt (recorded run, 18:39:45-18:52:59 UTC) | c36c17e52bb29948ebd55119097e2732 |
| outputs/verify_bandstar_squares.jsonl (one line per square) | 73a8da42b2c739cc01713566199d7250 |
| outputs/verify_bandstar_env.txt (versions, md5, start/end) | 2d40d19e7d642ef687367b1c8dd9b8fa |
| outputs/verify_bandstar_run2.txt (earlier run, same counts) | e05b2c0c0c2dd3ad7f9ce4e38d782ef5 |
| scripts/verify_bandstar_controls.py (controls, not proof) | 7427d4c4be4ccd5d30e804360336f06f |
| outputs/verify_bandstar_controls.txt | 5b51fc49a9678954a7da23742863aacb |
| scripts/bandstar_soundness2.py (float test, evidence only) | 88c63664e70fa8378cf795f1006f499f |
| scripts/idlib.py (exact laws for the float test) | b388f50f6777523824788911843f53d7 |
| outputs/bandstar_soundness2.txt (400 band K, rho^2 <= 1/5) | e7df91de74c93163241975767732f72e |
| outputs/bandstar_soundness2_dirac.txt (400 near-Dirac K, rho^2 <= 1/50) | 4d4e5cd11695cecc8201c09afa7aad3a |

The earlier run (18:25-18:38 UTC) used a copy of the script with md5 c3fe3289db0d505d20483e1046c3b751. It differs
from the recorded file in these places only:
- the docstring;
- an unused constant `RLINF` and an unused argument `lin` of `Tables`;
- one `flog.flush()`;
- the control shift `TGT_SHIFT`. This is 0 by default; with 0, `target_lo` and test (T1) are unchanged.

## How to reproduce

Requirements: python 3.12, python-flint 0.9.0 (arb), numpy, scipy (versions in `outputs/verify_bandstar_env.txt`).

```
python3 scripts/verify_bandstar.py all 0.0078125 8 outputs/verify_bandstar_squares.jsonl   # 8 processes, about 13 min
python3 scripts/verify_bandstar.py one 0,0.0078125,0,0.0078125 full                         # one square, prints its JSON
PYTHONPATH=scripts python3 scripts/verify_bandstar_controls.py 8                          # controls, about 1 min
cd scripts && python3 bandstar_soundness2.py 0.2 400 && python3 bandstar_soundness2.py 0.02 400 dirac
```

Expected result: the final JSON line of the first command has levels with `not_certified` 215, 102, 20, 0 (sides
1/128 to 1/1024), `"certified": 1339`, `"lam_m_boxes": 14894034` and no key `"uncertified"`.

## Map from the proof to the code (`scripts/verify_bandstar.py`)

- **Target and C_5.** `target_lo` is max(min(g(L1), g(L2)), C_5) minus the control shift (0 by default). `C5` is
  the ball 2 sqrt(2 ln(5/4)) * 16/25, with theta = 85/100 and A = 154/100 exact, at 80 bits.
- **Covering.**
  - `ab_boxes` and `run_all`: the squares and their refinement; children with a1 + b1 >= 1/5 are dropped.
  - `verify_ab_box`: the V range, the clipped corner (a-bar, b-bar) and r^2, and whether the slope check applies.
  - `run_boxes`: the (Lambda, m) boxes and their bisection.
- **Parameter domain.** `feasible` tests (F1)-(F5). `jump_geometry` gives mu_lo, mu_hi, d_lo, s^2 (the exact
  formula and Bhatia-Davis), w' and u'.
- **Corner costs** (class `Tables`):
  - `cB`: c_B at m1;
  - `cC2`: c_C at 2 theta - m2;
  - `phi1`, `phi2`: phi at theta - m2 (with the option -2y + chi^B_h(-y)) and at A - m2;
  - `chiC_y`: chi^C on the grid y = theta - k/4096, for (O3);
  - `chiB_t`: chi^B on the grid t = j/4096, for (O2).
- **Direct check.** `check_direct`, with the options in the order (O1), (O3), (O4), (O2).
- **Linear coefficients.**
  - `lin_B`, `lin_C`: the two displayed bounds of Section 6.1, with the validity tests on c.
  - `r_eff`: r = min(ceil(4096 r2)/4096, 1/50).
  - `lin_options_point`: adds the Cauchy-Schwarz coefficient 1/(2t).
  - `best_pair`: Pareto reduction in floats; the values stay arb.
- **Slope check** (`check_slope`):
  - `options`: (O1) is the chord with the coefficientwise max-fix. Then come (O3), (O4), and (O5) with the condition
    kappa <= d_lo^2 sqrt(L1/(1 - r1)).
  - `combine`: chooses the combination in floats and recomputes Mx in arb.
  - `ok`: tests (T1)-(T3). (T1) is skipped when the control shift is nonzero, and (T3) has an (O5) form.
  - `rec`: bisects rho^2 at most 6 times and skips pieces with m1^2 > L2 (1 - r1).

## Points I would check first (my own list of risks)

1. **(O5) uses two versions of Lemma 7(c).** Lemma 12 needs the exact weight w. The code bounds (1 - w) rho^2/(2h)
   by (1 - w') rho^2/(2h), using w >= w' (s^2 >= sigma_J^2 and d >= d_lo). It bounds the far term by
   chi^C_h(theta - m2 + d_lo) >= chi^C_h(mu1 - m), rounded down to the grid. It does not use u', which belongs to the
   box version with s^2. An earlier draft did use u' there. I found this mix in review and fixed it before the
   recorded run.
2. **The kappa condition of Lemma 12.** kappa <= d_lo^2 sqrt(L1/(1 - r1)) implies kappa <= D^2 sqrt(Lambda/V), with
   D = d_lo <= d, Lambda >= L1 and V <= 1 - r1. (O5) is offered only if d_lo > 0.
3. **(T3) for (O5).** If m2 <= sqrt(Lambda V):
   e^{-Lambda} q(m) <= e^{-L1}(2 m2 + kappa max(0, L2(1 - r1) - m2^2)/(L1 d_lo^2)), since q is nondecreasing up to
   its vertex >= sqrt(Lambda V). Otherwise e^{-Lambda} q(m) <= sqrt(V) g(Lambda) <= M.
4. **The linear bounds.**
   - Validity conditions: c = t - h > 0 and r/theta <= 2(theta - c) on the B side, r/A <= 2(A - c) on the C side.
   - The n = 0 term, and the tail bounded by twice the n = 12 term with c = 0.
   - r_eff >= rho^2 on the piece. This holds because r2 <= a2 + b2 < 1/50 whenever the slope check is used.
5. **Nonnegativity.** All coefficients and O'-bounds are >= 0. This is needed to replace e^{-Lambda},
   Lambda e^{-Lambda} and P_2(Lambda) by their box maxima.
6. **(T2).** F <= g-hat + rho^2 (Mx - g-hat/2) uses 1 - rho^2/2 > 0 and g(Lambda) <= g-hat.
7. **Squares crossing a + b = 1/5.** Here the code uses the clipped corner (a-bar, b-bar), r^2 = min(a-bar + b-bar, 1/5)
   and V >= 4/5.
8. **The direct check's (O2).** It uses Gamma'' <= 1/h (since chi^B_h'' = P/h), the t-grid point rounded down
   (t <= -(mu_hi - m1)) and s^2 >= sigma_J^2.
9. **NaN in python-flint.** `x**2` returns NaN for a ball with midpoint exactly 0. Every comparison with NaN is
   False, which can only make a check fail; in `feasible`, False means "keep the box". `lin_B` and `lin_C` use
   `**2` on theta n - c and A n - c. In `check_slope`, kappa is computed as e*e, and only when e > 0.
10. **Floats choose, arb decides.** h, the option order, `best_pair` and `combine` are float choices. Every
    inequality that certifies something is an arb comparison.

## Controls and float evidence (not proof; MAIN_RESULT Section 6.1)

- **Controls** (target lowered by a shift, no refinement, (T1) disabled):
  - The origin squares [0, 1/256]^2 and [0, 1/128]^2 are certified at shift 0 and fail at shift 0.0005. The first
    failure is on the Dirac curve at Lambda = 0.5632, m = 3074/4096, where C_5 - g(Lambda) is in
    [0.000496, 0.000502] and F = g at rho^2 = 0.
  - The 80 squares of side 1/1024 all lie along a + b = 1/5. At shift 0.001, 63 of them fail.
- **Float soundness of every ingredient.**
  - No bound is below its exact value by more than 1e-15. The two equality cases are at -8.9e-16 and -2.2e-16.
  - min(F - E\|Z_K\|) = 2.1e-4 and min(target - F) = 5.8e-4 on 400 band K.
  - The same two quantities are 1.5e-7 and 7.3e-7 on 400 near-Dirac K.

# First request (filed 2026-10-22 17:18 UTC; rated VALID in A.32, 18:17 UTC)

Erratum 17:35 UTC (A.32 text nit): the md5 printed for `scripts/band_soundness.py` was garbled (it was the md5
of `outputs/verify_band_S.txt` with "OUND" appended). The correct value, now in the table, is
5aad81599fde76b2e01ef699237a50f0. Nothing else in this file changed.

## What is to be audited

Theorem 10 (band lemma for C5) and Corollary 11 of `MAIN_RESULT.pdf`, with the lemmas they use. CLAIMS.md ids in
brackets.

| # | Statement (MAIN_RESULT.pdf) | CLAIMS | Kind |
|---|---|---|---|
| 1 | Lemma 3: OR-region identity with residual, **fix f1 of A.30 applied** (K_S != 0 in the hypothesis; used for P(Y = 0) = 0 and in the equality clause) | D2 | re-check of a fix |
| 2 | Lemma 2: conditional form l(y) = E\|y + W\| (convex, 1-Lipschitz, two exact identities, \|y\| <= l <= sqrt(y^2 + rho^2)) | D6 | elementary |
| 3 | Lemma 4: comparison lemma, E psi(Z_K) <= E psi(Z_{T#K}) for T(x) >= x and psi'' nondecreasing, bounded | D7 | new, analytic |
| 4 | Remark 5: counterexample for psi = (w - t)_+, and minimality of psi_{t,h} (stated "not used") | D7 | optional |
| 5 | Lemma 6: stop-loss bounds (i)-(iv) through the comparison laws W_B, W_C | D8 | analytic |
| 6 | Lemmas 7, 8: one-jump bounds (chord, variance) and feasibility F1-F5 | D9 | elementary |
| 7 | Proposition 9: band bound (F) and its second form | D10 | analytic |
| 8 | Theorem 10: K probability on [-sqrt2, sqrt2], K([1, sqrt2]) >= 9/10 (or mirror) => E\|Z_K\| <= sqrt(2/e); finitely supported equality only at delta_{+-sqrt2} | D11 | computer-assisted (arb) |
| 9 | Corollary 11: C5 <= the far region {K([1, sqrt2]) < 9/10 and K([-sqrt2, -1]) < 9/10} on [-sqrt2, sqrt2] | D12 | uses A.13a |

Not for audit (labelled NUMERICAL / in progress): Section 6 (ID* band at theta = 0.85, D13), D14, D15.

## Files (md5)

| File | md5 |
|---|---|
| MAIN_RESULT.tex | 4df86775aaa4b0e44d1ef733cefaeb16 |
| MAIN_RESULT.pdf | f69703ee53c78ad68fa2195961f4afca |
| CLAIMS.md | 5802cb5d470efa1b2548a5ab5b037a56 |
| scripts/verify_band.py | b8164113fd41949dbb3c3fe9a7b5d119 |
| outputs/verify_band_S.txt | 00d374efd595e521d5a41e2a3d23e6cf |
| outputs/verify_band_B.txt | 4b010e6bcfdad07098eb15938146123b |
| outputs/verify_band_env.txt | c1f8fd2706ac0f1221ead53f253c2235 |
| scripts/band_soundness.py (float test, evidence only) | 5aad81599fde76b2e01ef699237a50f0 |

## How to reproduce the certificate

Requirements: python 3.12, python-flint 0.9.0 (arb), numpy, scipy (versions in `outputs/verify_band_env.txt`).

```
python3 scripts/verify_band.py S     # Part S, 0 < rho^2 <= 1/50: about 3 s, prints one JSON line
python3 scripts/verify_band.py B     # Part B, 1/50 <= rho^2 <= 1/10: 8 processes, about 95 s
```

Expected: Part S `"nfail": 0`; Part B a final JSON line whose last level has `"nbad": 0` and no key
`"uncertified"`. Recorded results: Part S 1098 boxes, 0 failures (2.3 s); Part B side 0.00390625: 341 squares, 85 not certified; side 0.001953125: 333 squares, 3 not certified; side 0.0009765625: 12 squares, 0 not certified; 598 squares certified, 1,339,228 (Lambda, m) boxes, 95 s.

## Map from the proof to the code

- F of Theorem 10: `check_box` (Part B) and `check_S` (Part S); target `T = sqrt(2/e)` in arb.
- chi^B_h, chi^C_h (Lemma 6 (i)): `chiB`, `chiC` via `lattice_sum` (14 Poisson terms, exact Gaussian stop-loss `Q`,
  geometric tail bound with ratio lam (N+2)/(N+1)^2), h chosen in floats (`make_tables`), then evaluated in arb.
- Cauchy-Schwarz costs (Lemma 6 (ii)): `cs`.
- 2 m e^{-Lambda} on a box with m^2 <= Lambda V (Lemma 3, F4): `main_max` (unimodality of g).
- Chord for O' (Lemma 7 (a), Prop. 9 second form): `chord`, which replaces the upper value at y = 1 - m by
  max(g1, g2) so that the bounding chord is nonincreasing in mu1 (change of 17:11 UTC; the certificate was re-run
  after it).
- Infeasible boxes (Lemma 8, F1-F5 with theta = 1, A = sqrt2): first two `if` blocks of `check_box` / `check_S`.
- Monotonicity in (a, b) used to evaluate all costs at the corner (a2, b2) of an (a, b) square: Lemma 6 (iv).
- Part S linear bounds chi <= a alpha + b beta: `lin_coeffs_B`, `lin_coeffs_C` (derivation in Section 5.1, Part S).

## Points I would check first (my own list of risks)

1. Lemma 4, Step 1: the right derivative of s -> E psi(X + Z_{sL}) (no-jump, one-jump and two-jump events) and the
   joint continuity used for Psi'(t). Step 2: the mollification limit.
2. Lemma 6 (i): T(x) = theta on (0, theta), 0 on [-A, 0] (resp. A on [0, A], 0 on (-theta, 0) after reflection);
   the atom at 0 (Gaussian part) is in b and T(0) = 0 (resp. A).
3. Proposition 9: the n >= 2 sum equals m Lambda e^{-Lambda} (uses E Y = 0 and Lambda mu1 = m); no sign condition on
   theta - m or 2 theta - m is needed.
4. Section 5.1, Part S: the n = 0 term bound b tau(c/sqrt r), and (n - a - c)^2 <= (n - c)^2 for 0 <= a <= 2(n - c)
   (c = m - h < 0.95 because h >= 0.05); the C-side analogue needs sqrt2 n - c > 0 (c <= 1.35).
5. Part B: monotonicity directions (e^{-L1}, L2 e^{-L2}, P2(L2) on Lambda <= 1; c_B at m1; c_C and the chord endpoint
   values at m2).
6. Theorem 10, general K: approximation by finitely supported K_n with K_n([1, sqrt2]) >= 9/10 (cells inside
   [1, sqrt2] and inside [-sqrt2, 1)), and E|Z_{K_n}| -> E|Z_K| (A.8 / A.26(e) continuity step).
7. Corollary 11: x <= 2(1-u)/R and 1 - u <= R/sqrt2 (A.13a) give x <= sqrt2; mirrored for x < 0.

## Controls (recorded in MAIN_RESULT Section 5.1)

r = 0.06 in Part S: 426,627 failing boxes; target sqrt(2/e) - 0.002 in Part S: 5,750 failures; Part B at target
sqrt(2/e) - 0.001: 110 of 1281 squares fail at side 1/512. Float soundness of F on 400 random K
(`scripts/band_soundness.py`): F - E|Z_K| >= 1.5e-5 and sqrt(2/e) - F >= 3.2e-5.
