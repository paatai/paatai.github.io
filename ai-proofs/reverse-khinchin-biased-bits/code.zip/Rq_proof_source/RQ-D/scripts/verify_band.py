"""Certified verification of the band lemma (Theorem B of MAIN_RESULT.tex).

Claim. Let K be a probability measure on [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10. Then
E|Z_K| <= sqrt(2/e), with equality only for K = delta_sqrt2.

Reduction (MAIN_RESULT.tex, Section 4). Write a = K((0,1)), b = K([-sqrt2, 0]), rho^2 = a + b <= 1/10,
V = 1 - rho^2 = K([1, sqrt2]), Lam = int x^-2 dK_S, m = int x^-1 dK_S (K_S = K restricted to [1, sqrt2]).
Then E|Z_K| <= F, where

  F = 2 m e^{-Lam} + e^{-Lam} cB(m) + Lam e^{-Lam} C1 + P2(Lam) cC2(m),     P2(L) = 1 - e^{-L}(1 + L),

  cB(m)   = min( chiB(m, h), sqrt(m^2 + rho^2) - m )                       (any h > 0),
  chiB    = (1/(2h)) E (W_B - m + h)_+^2,  W_B = (N_a - a) + sqrt(b) G,
  cC2(m)  = min( chiC(2 - m, h), sqrt((2-m)^2 + rho^2) - (2 - m) ),
  chiC(y) = (1/(2h)) E (W_C - y + h)_+^2,  W_C = sqrt2 (N_{b/2} - b/2) + sqrt(a) G,
  C1      = chord of a convex majorant g of the one-jump cost on J in [1, sqrt2] at mu1 = m/Lam:
            [(sqrt2 - mu1) g(1 - m) + (mu1 - 1) g(sqrt2 - m)] / (sqrt2 - 1),
            g = chiC(., h) (fixed h) or g = sqrt(y^2 + rho^2) - y.

Feasible (Lam, m) for given V: V/2 <= Lam <= V, max(Lam, V/sqrt2, (Lam + V/sqrt2)/(1 + 1/sqrt2)) <= m,
m <= min(sqrt(Lam V), sqrt2 Lam, V) (and m < 1).

Monotonicity used on boxes (all proved in MAIN_RESULT.tex): chiB, chiC, the CS terms are nondecreasing in a
and b; chiB(m) is nonincreasing in m; chiC(y), CS(y) are nonincreasing in y; the chord is nonincreasing in
mu1 (since g(1-m) >= g(sqrt2-m)); e^{-L} decreasing, L e^{-L} and P2 increasing on [0, 1].

Part S (rho^2 <= R_LIN): linear bounds cB <= a alB + b beB etc. (Lemma 4.6) and the slope argument.
Part B (R_LIN <= rho^2 <= 1/10): boxes in (a, b) x (Lam, m) with all quantities at the worst corner.

All final inequalities are checked in arb ball arithmetic (python-flint); floats only choose the
parameters h and the subdivision.
"""
import json
import math
import sys
import time
from multiprocessing import Pool

import numpy as np
from flint import arb, ctx
from scipy.stats import norm

ctx.prec = 80

S2 = arb(2).sqrt()
T = (arb(2) / arb(1).exp()).sqrt()  # sqrt(2/e)
SQ2PI = (2 * arb.pi()).sqrt()
HALF = arb(1) / 2
RHO0 = arb(1) / 10
R_LIN_F = 0.02
R_LIN = arb(1) / 50
NTERMS = 14

MGRID_DEN = 1024
M_LO_IDX = int(0.62 * MGRID_DEN)  # m >= V/sqrt2 >= 0.9/sqrt2 = 0.6364
M_HI_IDX = MGRID_DEN  # m < 1
HGRID = np.geomspace(0.01, 3.0, 90)

# ---------------------------------------------------------------- float kernels (parameter choice only)


def f_lattice(J, lam, s, c):
    """float: sum_n p_n E(J(n - lam) - c + s G)_+^2 for arrays c (vectorised over c)."""
    c = np.atleast_1d(c)
    if lam <= 0:
        n = np.array([0])
        p = np.array([1.0])
    else:
        nmax = int(lam + 12 * math.sqrt(lam) + 15)
        n = np.arange(nmax + 1)
        p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    d = J * (n[:, None] - lam) - c[None, :]
    if s <= 0:
        q = np.where(d > 0, d * d, 0.0)
    else:
        z = d / s
        q = (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)
    return p @ q


def f_best_h(J, lam, s, t, extra=None):
    """float: h minimising (1/(2h)) E(W - t + h)_+^2 over HGRID (optionally restricted)."""
    vals = f_lattice(J, lam, s, t - HGRID) / (2 * HGRID)
    if extra is not None:
        vals = np.where(extra(HGRID), vals, np.inf)
    i = int(np.argmin(vals))
    return float(HGRID[i]), float(vals[i])


# ---------------------------------------------------------------- arb kernels


def Q(d, s):
    """Upper enclosure of E(d + s G)_+^2; s is an arb >= 0 or None (meaning s = 0)."""
    if s is None:
        if d <= 0:
            return arb(0)
        u = d.upper()
        return u * u if u > 0 else arb(0)
    z = d / s
    Phi = (-z / S2).erfc() / 2
    ph = (-(z * z) / 2).exp() / SQ2PI
    return (d * d + s * s) * Phi + d * s * ph


def lattice_sum(J, lam, s, c, N=NTERMS):
    """Upper bound for sum_n p_n(lam) E(J (n - lam) - c + s G)_+^2, N ~ Poisson(lam), lam exact >= 0."""
    if lam == 0:
        return Q(-c, s)
    p = (-lam).exp()
    tot = arb(0)
    for n in range(N + 1):
        tot += p * Q(J * (n - lam) - c, s)
        p = p * lam / (n + 1)
    # tail: sum_{n > N} (lam^n/n!) ((J n + C)^2 + s^2), C = J lam + |c|, ratio <= lam (N+2)/(N+1)^2
    C = J * lam + abs(c)
    s2 = s * s if s is not None else arb(0)
    lamN = lam ** (N + 1) / arb(math.factorial(N + 1))
    t = lamN * ((J * (N + 1) + C) ** 2 + s2)
    q = lam * (N + 2) / arb((N + 1) ** 2)
    assert q < 1
    return tot + t / (1 - q)


def sq(x):
    return x.sqrt() if x != 0 else None


def chiB(m, h, a, b):
    return lattice_sum(arb(1), a, sq(b), m - h) / (2 * h)


def chiC(y, h, a, b):
    return lattice_sum(S2, b / 2, sq(a), y - h) / (2 * h)


def cs(y, r2):
    return (y * y + r2).sqrt() - y


def phi_max(l, u):
    """max of phi(L) = 2 sqrt(L) e^{-L} on [l, u] (phi increases on [0, 1/2], decreases after)."""
    if u <= HALF:
        x = u
    elif l >= HALF:
        x = l
    else:
        return T
    return 2 * x.sqrt() * (-x).exp()


def main_max(L1, L2, m2, Vhi):
    """Upper bound of 2 m e^{-L} over L in [L1, L2], m <= m2, m <= sqrt(L Vhi).

    With Lc = m2^2/Vhi: for L <= Lc the cap sqrt(L V) binds (value sqrt(V) phi(L)); for L >= Lc the value
    2 m2 e^{-L} <= 2 m2 e^{-Lc} = sqrt(Vhi) phi(Lc). Hence the max is sqrt(Vhi) max phi over
    [min(L1, Lc), min(L2, Lc)] in the mixed case."""
    Lc = m2 * m2 / Vhi
    if L2 <= Lc:
        return Vhi.sqrt() * phi_max(L1, L2)
    if L1 >= Lc:
        return 2 * m2 * (-L1).exp()
    lo = _min(L1, Lc.lower())
    hi = _min(L2, Lc.upper())
    return Vhi.sqrt() * phi_max(lo, hi)


def _min(x, y):
    """Returns one of x, y that is a valid upper bound for min(x, y)."""
    return x if x < y else y


def P2(L):
    return 1 - (-L).exp() * (1 + L)


def amax(x, y):
    return (x + y + abs(x - y)) / 2


def chord(mu1, g1, g2):
    """Upper bound, for every mu in [mu1, sqrt2], of the chord through (1, phi1), (sqrt2, phi2) at mu, given
    phi1 <= g1, phi2 <= g2 and phi1 >= phi2 (phi nonincreasing); g1 is replaced by max(g1, g2) so that the
    bounding chord is nonincreasing in mu."""
    g1 = amax(g1, g2)
    return ((S2 - mu1) * g1 + (mu1 - 1) * g2) / (S2 - 1)


# ---------------------------------------------------------------- tables for a given (a_hi, b_hi)


def make_tables(a_f, b_f, kstep=1):
    """Cost tables on the m-grid for corner (a, b) (floats exactly representable, dyadic)."""
    a, b = arb(a_f), arb(b_f)
    r2 = a + b
    sb, sa = math.sqrt(b_f), math.sqrt(a_f)
    ks = np.arange(M_LO_IDX, M_HI_IDX + 1, kstep)
    mf = ks / MGRID_DEN
    H = HGRID[None, :]
    # float choice of h (vectorised over the m-grid)
    vB = f_lattice(1.0, a_f, sb, (mf[:, None] - H).ravel()).reshape(len(ks), -1) / (2 * H)
    hB = HGRID[np.argmin(vB, axis=1)]
    v2 = f_lattice(math.sqrt(2), b_f / 2, sa, ((2 - mf)[:, None] - H).ravel()).reshape(len(ks), -1) / (2 * H)
    h2 = HGRID[np.argmin(v2, axis=1)]
    g1 = f_lattice(math.sqrt(2), b_f / 2, sa, ((1 - mf)[:, None] - H).ravel()).reshape(len(ks), -1) / (2 * H)
    gs = f_lattice(math.sqrt(2), b_f / 2, sa, ((math.sqrt(2) - mf)[:, None] - H).ravel()).reshape(len(ks), -1) / (2 * H)
    hc = [HGRID[np.argmin(w * g1 + (1 - w) * gs, axis=1)] for w in (0.0, 0.3, 0.7, 1.0)]
    cB, ch1, cC2 = {}, {}, {}
    for i, k in enumerate(ks):
        m = arb(int(k)) / MGRID_DEN
        cB[k] = _min(chiB(m, arb(float(hB[i])), a, b).upper(), cs(m, r2).upper())
        cC2[k] = _min(chiC(2 - m, arb(float(h2[i])), a, b).upper(), cs(2 - m, r2).upper())
        pairs = []
        for hh in sorted({float(x[i]) for x in hc}):
            ha = arb(hh)
            pairs.append((chiC(1 - m, ha, a, b).upper(), chiC(S2 - m, ha, a, b).upper()))
        pairs.append((cs(1 - m, r2).upper(), cs(S2 - m, r2).upper()))
        ch1[k] = pairs
    return cB, ch1, cC2


# ---------------------------------------------------------------- Part B: one (a, b) box


def check_box(L1, L2, k1, k2, Vlo, Vhi, tabs):
    """Return True if F < T is certified on the (Lam, m) box [L1, L2] x [k1, k2]/MGRID_DEN."""
    cB, ch1, cC2 = tabs
    m1, m2 = arb(k1) / MGRID_DEN, arb(k2) / MGRID_DEN
    # infeasible boxes: m > sqrt2 L, m < L, m^2 > L V, m below the lower envelope, L outside [V/2, V]
    if m1 > S2 * L2 or m2 < L1 or m1 * m1 > L2 * Vhi or L2 < Vlo / 2 or L1 > Vhi:
        return True
    if (1 + 1 / S2) * m2 < L1 + Vlo / S2 or m2 < Vlo / S2:
        return True
    M = main_max(L1, L2, m2, Vhi)
    mu1 = m1 / L2
    if mu1 < 1:
        mu1 = arb(1)
    if mu1 > S2:
        return True
    c1 = None
    for g1, g2 in ch1[k2]:
        v = chord(mu1, g1, g2)
        c1 = v if c1 is None else _min(c1, v)
    F = M + (-L1).exp() * cB[k1] + L2 * (-L2).exp() * c1 + P2(L2) * cC2[k2]
    return F < T


def verify_ab_box(args):
    """Verify all (Lam, m) for the (a, b) box [a1, a2] x [b1, b2] intersected with R_LIN <= a + b <= 1/10."""
    a1, a2, b1, b2 = args
    lo = max(a1 + b1, R_LIN_F)
    hi = min(a2 + b2, 0.1)
    Vlo, Vhi = arb(1) - arb(hi), arb(1) - arb(lo)
    t0 = time.time()
    tabs = make_tables(a2, b2)
    nbox, fails = 0, []
    # initial Lambda boxes of width 1/64 on [0.44, 1], m-boxes of 16 grid steps
    stack = []
    Lsteps = 64
    for i in range(int(0.44 * Lsteps), Lsteps):
        for k in range(M_LO_IDX, M_HI_IDX, 16):
            stack.append((arb(i) / Lsteps, arb(i + 1) / Lsteps, k, min(k + 16, M_HI_IDX), 0))
    while stack:
        L1, L2, k1, k2, depth = stack.pop()
        nbox += 1
        if check_box(L1, L2, k1, k2, Vlo, Vhi, tabs):
            continue
        if depth > 24:
            fails.append((float(L1.mid()), float(L2.mid()), k1, k2))
            continue
        # bisect m first while possible, alternating with Lambda
        if k2 - k1 > 1 and (depth % 2 == 0 or (L2 - L1) < arb(1) / 4096):
            km = (k1 + k2) // 2
            stack.append((L1, L2, k1, km, depth + 1))
            stack.append((L1, L2, km, k2, depth + 1))
        elif (L2 - L1) > arb(1) / 65536:
            Lm = (L1 + L2) / 2
            stack.append((L1, Lm, k1, k2, depth + 1))
            stack.append((Lm, L2, k1, k2, depth + 1))
        else:
            fails.append((float(L1.mid()), float(L2.mid()), k1, k2))
    return dict(box=args, nbox=nbox, fails=fails[:5], nfail=len(fails), sec=time.time() - t0)


# ---------------------------------------------------------------- Part S: rho^2 <= R_LIN (linear slopes)


def tau(x):
    """E(G - x)_+^2 = (1 + x^2) Phibar(x) - x phi(x) (decreasing in x)."""
    Phibar = (x / S2).erfc() / 2
    ph = (-(x * x) / 2).exp() / SQ2PI
    return (1 + x * x) * Phibar - x * ph


def lin_coeffs_B(m, h, r):
    """alB, beB with chiB(m, h, a, b) <= a alB + b beB for a, b >= 0, a + b <= r (needs c = m - h > 0)."""
    c = m - h
    assert c > 0
    s = arb(0)
    for n in range(1, 12):
        s += r ** (n - 1) / math.factorial(n) * ((n - c) ** 2 + r)
    s += r ** 11 / math.factorial(12) * ((12 + 1) ** 2 + r) * 2  # crude tail (r <= 1/50)
    return s / (2 * h), tau(c / r.sqrt()) / (2 * h)


def lin_coeffs_C(y, h, r):
    """alC, beC with chiC(y, h, a, b) <= a alC + b beC (needs c = y - h > 0)."""
    c = y - h
    assert c > 0
    s = arb(0)
    for n in range(1, 12):
        s += r ** (n - 1) / (2 ** n * math.factorial(n)) * ((S2 * n - c) ** 2 + r)
    s += r ** 11 / (2 ** 12 * math.factorial(12)) * ((S2 * 13) ** 2 + r) * 2
    return tau(c / r.sqrt()) / (2 * h), s / (2 * h)


def part_S():
    r = R_LIN
    rf = R_LIN_F
    t0 = time.time()
    # coefficient tables on the m-grid (m in [V/sqrt2, 1), V >= 1 - r)
    kmin = int((1 - rf) / math.sqrt(2) * MGRID_DEN) - 1
    tabB, tabC1, tabC2 = {}, {}, {}
    for k in range(kmin, M_HI_IDX + 1):
        mf = k / MGRID_DEN
        m = arb(k) / MGRID_DEN
        # B: choose h < m minimising the slope near the optimum: h ~ 1 - m (tangent at 1), clipped
        best = None
        for hf in np.linspace(0.05, min(0.95 * mf, 1.2), 60):
            al, be = lin_coeffs_B_f(mf, hf, rf)
            v = max(al, be)
            if best is None or v < best[0]:
                best = (v, hf)
        al, be = lin_coeffs_B(m, arb(best[1]), r)
        tabB[k] = (al.upper(), be.upper())
        # C2 at y = 2 - m
        y2 = 2 - mf
        best = None
        for hf in np.linspace(0.05, 0.95 * y2, 60):
            al, be = lin_coeffs_C_f(y2, hf, rf)
            v = max(al, be)
            if best is None or v < best[0]:
                best = (v, hf)
        al, be = lin_coeffs_C(2 - m, arb(best[1]), r)
        tabC2[k] = (al.upper(), be.upper())
        # chord pairs with a common h < 1 - m
        y1, ys = 1 - mf, math.sqrt(2) - mf
        pairs = []
        if y1 > 0.004:
            for frac in (0.3, 0.5, 0.7, 0.9):
                hf = frac * y1
                hh = arb(hf)
                a1, b1 = lin_coeffs_C(1 - m, hh, r)
                a2, b2 = lin_coeffs_C(S2 - m, hh, r)
                pairs.append((a1.upper(), b1.upper(), a2.upper(), b2.upper()))
        tabC1[k] = pairs
    # (Lam, m) boxes: V in [1 - r, 1]
    Vlo, Vhi = 1 - r, arb(1)
    nbox, fails = 0, []
    stack = []
    Lsteps = 64
    for i in range(int(0.48 * Lsteps), Lsteps):
        for k in range(kmin, M_HI_IDX, 16):
            stack.append((arb(i) / Lsteps, arb(i + 1) / Lsteps, k, min(k + 16, M_HI_IDX), 0))
    while stack:
        L1, L2, k1, k2, depth = stack.pop()
        nbox += 1
        if check_S(L1, L2, k1, k2, Vlo, Vhi, r, tabB, tabC1, tabC2):
            continue
        if depth > 26:
            fails.append((float(L1.mid()), float(L2.mid()), k1, k2))
            continue
        if k2 - k1 > 1 and (depth % 2 == 0 or (L2 - L1) < arb(1) / 4096):
            km = (k1 + k2) // 2
            stack += [(L1, L2, k1, km, depth + 1), (L1, L2, km, k2, depth + 1)]
        elif (L2 - L1) > arb(1) / 65536:
            Lm = (L1 + L2) / 2
            stack += [(L1, Lm, k1, k2, depth + 1), (Lm, L2, k1, k2, depth + 1)]
        else:
            fails.append((float(L1.mid()), float(L2.mid()), k1, k2))
    return dict(part="S", nbox=nbox, nfail=len(fails), fails=fails[:10], sec=time.time() - t0)


def lin_coeffs_B_f(m, h, r):
    c = m - h
    s = sum(r ** (n - 1) / math.factorial(n) * ((n - c) ** 2 + r) for n in range(1, 12))
    x = c / math.sqrt(r)
    t = (1 + x * x) * norm.sf(x) - x * norm.pdf(x)
    return s / (2 * h), t / (2 * h)


def lin_coeffs_C_f(y, h, r):
    c = y - h
    s = sum(r ** (n - 1) / (2 ** n * math.factorial(n)) * ((math.sqrt(2) * n - c) ** 2 + r) for n in range(1, 12))
    x = c / math.sqrt(r)
    t = (1 + x * x) * norm.sf(x) - x * norm.pdf(x)
    return t / (2 * h), s / (2 * h)


def check_S(L1, L2, k1, k2, Vlo, Vhi, r, tabB, tabC1, tabC2):
    m1, m2 = arb(k1) / MGRID_DEN, arb(k2) / MGRID_DEN
    if m1 > S2 * L2 or m2 < L1 or m1 * m1 > L2 * Vhi or L2 < Vlo / 2 or L1 > Vhi:
        return True
    if (1 + 1 / S2) * m2 < L1 + Vlo / S2 or m2 < Vlo / S2:
        return True
    # rho^2 <= rB := min(r, 1 - m1^2 / L2)
    rB = 1 - m1 * m1 / L2
    if rB > r:
        rB = r
    if rB <= 0:
        return True
    M0 = main_max(L1, L2, m2, Vhi)  # V <= 1
    mu1 = m1 / L2
    if mu1 < 1:
        mu1 = arb(1)
    if mu1 > S2:
        return True
    eL1, LeL2, p2 = (-L1).exp(), L2 * (-L2).exp(), P2(L2)
    # crude Cauchy-Schwarz alternative (cost_B <= rho^2/(2m), one jump <= rho, two jumps <= rho^2/(2(2-m)))
    crude = M0 + eL1 * rB / (2 * m1) + LeL2 * rB.sqrt() + p2 * rB / (2 * (2 - m2))
    if crude < T:
        return True
    # linear slopes
    alB, beB = tabB[k1]
    alC2, beC2 = tabC2[k2]
    best = None
    for a1, b1, a2, b2 in tabC1[k2]:
        ca = chord(mu1, a1, a2)
        cb = chord(mu1, b1, b2)
        A = eL1 * alB + LeL2 * ca + p2 * alC2
        B = eL1 * beB + LeL2 * cb + p2 * beC2
        C = A if A > B else (B if B > A else A + B)  # upper bound of max(A, B)
        if best is None or C < best:
            best = C
    if best is None:
        return False
    if best < T / 2:
        return True
    return M0 + rB * best < T


# ---------------------------------------------------------------- driver


def ab_boxes(step):
    out = []
    n = int(round(0.1 / step))
    for i in range(n):
        for j in range(n - i):
            a1, a2, b1, b2 = i * step, (i + 1) * step, j * step, (j + 1) * step
            if a2 + b2 <= R_LIN_F or a1 + b1 >= 0.1:
                continue
            out.append((a1, a2, b1, b2))
    return out


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "S"
    if mode == "S":
        res = part_S()
        print(json.dumps(res))
    elif mode == "B":
        step = float(sys.argv[2]) if len(sys.argv) > 2 else 1 / 256
        min_step = 1 / 4096
        boxes = ab_boxes(step)
        t0 = time.time()
        log = dict(part="B", levels=[], certified=0)
        with Pool(8) as pool:
            while boxes:
                print(f"level step {step}: {len(boxes)} (a,b) boxes", flush=True)
                bad, nb = [], 0
                for i, r in enumerate(pool.imap_unordered(verify_ab_box, boxes, chunksize=4)):
                    nb += r["nbox"]
                    if r["nfail"]:
                        bad.append(r["box"])
                    if i % 200 == 0:
                        print(f"  {i}/{len(boxes)}  {time.time()-t0:.0f}s  bad so far {len(bad)}", flush=True)
                log["levels"].append(dict(step=step, nboxes=len(boxes), nbad=len(bad), lam_m_boxes=nb))
                log["certified"] += len(boxes) - len(bad)
                if not bad:
                    break
                if step / 2 < min_step:
                    log["uncertified"] = bad
                    break
                step /= 2
                boxes = []
                for (a1, a2, b1, b2) in bad:
                    am, bm = (a1 + a2) / 2, (b1 + b2) / 2
                    for q in ((a1, am, b1, bm), (am, a2, b1, bm), (a1, am, bm, b2), (am, a2, bm, b2)):
                        if q[1] + q[3] > R_LIN_F and q[0] + q[2] < 0.1:
                            boxes.append(q)
        log["sec"] = time.time() - t0
        print(json.dumps(log))
