"""Scan of the band-lemma bound F(Lambda, m, rp, rn) with theta = 1 (float exploration).

Bound (all terms rigorous upper bounds; see MAIN_RESULT.tex):
  F = 2 m e^{-L}                                   (OR part, exact)
    + 2 e^{-L} PhiB(m)                             (residual above the zero atom of Y)
    + 2 L e^{-L} E PhiC(J - m)                     (one big jump; J-law worst case two-point {1, b})
    + 2 (1 - e^{-L}(1 + L)) PhiC(2 - m)            (two or more big jumps)
PhiB(m) = inf_s E psi_{m,s}(theta (N - rp/theta^2) + sqrt(rn) G)
PhiC(y) = inf_{c in [0,y)} [rn + E(sqrt(rp) G - c)_+^2] / (4 (y - c))
"""
import sys
import numpy as np
from math import exp, sqrt
from scipy.stats import norm
from flipbound import e_sq_plus, pois_law
from idlib import SQ2E

THETA = 1.0


def phiB(m, rp, rn, grid=40):
    vals, probs = pois_law(THETA, rp) if rp > 0 else (np.zeros(1), np.ones(1))
    sig = sqrt(rn)
    best = np.inf
    for s in m * (1 + np.geomspace(1e-3, 1.0, grid)):
        best = min(best, e_sq_plus(vals, probs, sig, 2 * m - s) / (4 * (s - m)))
    return best


def gauss_sq_plus(sig, c):
    if sig == 0:
        return 0.0
    z = -c / sig
    return (c * c + sig * sig) * norm.cdf(z) - c * sig * norm.pdf(z)


def phiC(y, rp, rn, grid=40):
    if y <= 0:
        return np.inf
    sig = sqrt(rp)
    best = np.inf
    for c in y * np.linspace(0, 0.95, grid):
        best = min(best, (rn + gauss_sq_plus(sig, c)) / (4 * (y - c)))
    return best


def F(L, m, rp, rn):
    vs = 1 - rp - rn
    mu1, mu2 = m / L, vs / L
    # two-point law {1, b} with mean mu1, second moment mu2 (requires mu1 >= 1, mu2 >= mu1^2)
    if mu1 < 1 or mu2 < mu1 * mu1 - 1e-15 or m >= THETA:
        return None
    if mu1 == 1:
        b, w = 1.0, 1.0
    else:
        b = (mu2 - 1) / (mu1 - 1) - 1  # from w + (1-w) b = mu1, w + (1-w) b^2 = mu2
        w = 1 - (mu1 - 1) / (b - 1) if b > 1 else 1.0
    a_term = 2 * m * exp(-L)
    b_term = 2 * exp(-L) * phiB(m, rp, rn)
    eC = w * phiC(1 - m, rp, rn) + (1 - w) * phiC(b - m, rp, rn)
    c_term = 2 * L * exp(-L) * eC + 2 * (1 - exp(-L) * (1 + L)) * phiC(2 - m, rp, rn)
    return a_term + b_term + c_term


if __name__ == "__main__":
    for r2 in [0.01, 0.03, 0.05, 0.08, 0.1, 0.15, 0.2]:
        worst = (np.inf, None)
        for fr in np.linspace(0, 1, 6):
            rp, rn = fr * r2, (1 - fr) * r2
            vs = 1 - r2
            for L in np.linspace(0.05, vs, 40):
                mlo, mhi = L, min(sqrt(L * vs), THETA * 0.999)
                for m in np.linspace(mlo, mhi, 30):
                    f = F(L, m, rp, rn)
                    if f is None:
                        continue
                    mar = SQ2E - f
                    if mar < worst[0]:
                        worst = (mar, (fr, L, m))
        print(f"rho^2={r2}: worst margin {worst[0]:+.5f} at (frac_pos, Lambda, m) = "
              + ", ".join(f"{v:.4f}" for v in worst[1]))
        sys.stdout.flush()
