"""Exact verification of the F_heavy 'plus' cover from its certificate files. Uses only python-flint (fmpq and
arb) through plus_verify_lib; no LP solver and no floating-point decisions.

Checks:
  1. The finished boxes tile ROOT = [0, 28/25] x [0, 17/50] (dyadic quadtree leaves with in-range indices:
     pairwise not nested and of total area |ROOT|).
  2. Each 'empty' box has Q(a_lo, b_lo) >= 4/5 or M(a_hi, b_hi) < 1/2 (exact).
  3. Each 'ok' box: its cells tile root_cell(mu_B, cap_B) (same quadtree test), and every cell certificate holds:
       'ok':           phi_check(coef, a_lo, b_lo, Lt) = eps exists and lagrangian_bound(...) + eps < C5;
       'empty':        some cumulant range from the certificate's multipliers is empty (L_j > U_j);
       'empty_farkas': empty_bound(...) < 0.
Usage: python3 verify_plus.py FILE.jsonl [FILE2.jsonl ...] [--nproc N]
"""
import hashlib
import json
import multiprocessing as mp
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import flint
from flint import arb, fmpq

import plus_verify_lib as V

D = 16
ROOT = (fmpq(0), fmpq(28, 25), fmpq(0), fmpq(17, 50))


def box_of(la, ia, lb, ib):
    a0, a1, b0, b1 = ROOT
    wa, wb = (a1 - a0) / 2 ** la, (b1 - b0) / 2 ** lb
    return (a0 + ia * wa, a0 + (ia + 1) * wa, b0 + ib * wb, b0 + (ib + 1) * wb)


def dec_mult(m):
    def key(s):
        return tuple(int(t) for t in s.split(","))
    return dict(cell=m["cell"], mcc={key(k): v for k, v in m["mcc"].items()},
                cheb={key(k): v for k, v in m["cheb"].items()})


def in_grid(lev, i, j):
    return all(isinstance(x, int) for x in (lev, i, j)) and lev >= 0 and 0 <= i < 2 ** lev and 0 <= j < 2 ** lev


def tiles(ids, area):
    """ids: list of (level, i, j) leaves of a quadtree; True iff they tile the root."""
    if not all(in_grid(*t) for t in ids):
        return False
    s = set(ids)
    if len(s) != len(ids):
        return False
    for lev, i, j in ids:
        for k in range(1, lev + 1):
            if (lev - k, i >> k, j >> k) in s:
                return False
    return sum((area(lev) for lev, _, _ in ids), fmpq(0)) == 1


def box_cover(recs):
    """None if the box records tile ROOT, else the reason. A box at level (la, lb) with indices (ia, ib) is the
    level-d quadtree leaf, d = la - la0 = lb - lb0, of the initial box (ia >> d, ib >> d) of the 2^la0 x 2^lb0
    grid; the leaves of every initial box must tile it."""
    for r in recs:
        la, ia, lb, ib = r["box"]
        if not (in_grid(la, ia, ia) and in_grid(lb, ib, ib)):
            return f"box index out of range {r['box']}"
    la0 = min(r["box"][0] for r in recs)
    lb0 = min(r["box"][2] for r in recs)
    groups = {}
    for r in recs:
        la, ia, lb, ib = r["box"]
        d = la - la0
        if lb - lb0 != d:
            return f"box levels not synchronised {r['box']}"
        groups.setdefault((ia >> d, ib >> d), []).append((d, ia - ((ia >> d) << d), ib - ((ib >> d) << d)))
    if len(groups) != 2 ** la0 * 2 ** lb0:
        return f"{len(groups)} initial boxes covered, expected {2 ** la0 * 2 ** lb0}"
    for g, leaves in groups.items():
        if not tiles(leaves, lambda lev: fmpq(1, 4 ** lev)):
            return f"boxes do not tile initial box {g}"
    return None


def check_cell(box, mu, cap, root, c):
    lev, i, j = c["cell"]
    if not in_grid(lev, i, j):
        return False, "bad cell index"
    cell = V.cell_of(root, lev, i, j)
    a_lo, a_hi, b_lo, b_hi = box
    st = c["status"]
    if st == "empty_farkas":
        b = V.empty_bound(mu, cap, cell, *c["farkas"])
        return bool(b < 0), f"farkas {float(b.mid()):.3e}"
    rm = {int(k): v for k, v in c["rmult"].items()}
    if sorted(rm) != list(range(3, D + 1)):
        return False, "rmult keys"
    L, U = V.kappa_ranges(D, mu, cap, cell, rm)
    if any(L[jj] > U[jj] for jj in L):
        return True, "empty ranges"
    if st != "ok":
        return False, "status " + st
    if len(c["coef"]) != D + 1:
        return False, "coef length"
    eps = V.phi_check(c["coef"], a_lo, b_lo, c["Lt"])
    if eps is None:
        return False, "phi tail test failed"
    B = V.lagrangian_bound(c["coef"], D, mu, cap, cell, L, U, dec_mult(c["mult"]))
    tot = B + eps
    return bool(tot < V.C5), f"{float(tot.upper()):.6f}"


def check_box(rec):
    t0 = time.time()
    la, ia, lb, ib = rec["box"]
    box = box_of(la, ia, lb, ib)
    info = V.box_info(*box)
    if rec["status"] == "empty":
        return rec["box"], bool(info["empty"]), "empty box", 0.0, time.time() - t0
    if rec["status"] != "ok":
        return rec["box"], False, "status " + rec["status"], 0.0, time.time() - t0
    mu, cap = info["mu"], info["cap"]
    root = V.root_cell(mu, cap)
    ids = [tuple(c["cell"]) for c in rec["certs"]]
    if not tiles(ids, lambda lev: fmpq(1, 4 ** lev)):
        return rec["box"], False, "cells do not tile", 0.0, time.time() - t0
    worst = 0.0
    for c in rec["certs"]:
        ok, msg = check_cell(box, mu, cap, root, c)
        if not ok:
            return rec["box"], False, f"cell {c['cell']}: {msg}", worst, time.time() - t0
        try:
            worst = max(worst, float(msg))
        except ValueError:
            pass
    return rec["box"], True, "ok", worst, time.time() - t0


def main():
    args = sys.argv[1:]
    nproc = 8
    if "--nproc" in args:
        k = args.index("--nproc")
        nproc = int(args[k + 1])
        args = args[:k] + args[k + 2:]
    here = os.path.dirname(os.path.abspath(__file__))
    print(f"start {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC; python {sys.version.split()[0]}, "
          f"python-flint {flint.__version__}, arb precision {V.ctx.prec} bits", flush=True)
    for fn in [os.path.join(here, "verify_plus.py"), os.path.join(here, "plus_verify_lib.py")] + args:
        with open(fn, "rb") as f:
            print(f"md5 {hashlib.md5(f.read()).hexdigest()}  {os.path.basename(fn)}", flush=True)
    recs = []
    for fn in args:
        with open(fn) as f:
            recs += [json.loads(line) for line in f if line.strip()]
    print(f"{len(recs)} box records from {len(args)} files", flush=True)
    why = box_cover(recs)
    if why is not None:
        print("FAIL:", why)
        return 1
    la0 = min(r["box"][0] for r in recs)
    lb0 = min(r["box"][2] for r in recs)
    print(f"box tiling OK: {len(recs)} leaves tile ROOT (initial grid 2^{la0} x 2^{lb0})", flush=True)
    nfail, worst, nok, nemp, ncell = 0, 0.0, 0, 0, 0
    t0 = time.time()
    with mp.Pool(nproc) as pool:
        for bid, ok, msg, w, dt in pool.imap_unordered(check_box, recs):
            if not ok:
                nfail += 1
                print("FAIL box", bid, msg, flush=True)
            elif msg == "empty box":
                nemp += 1
            else:
                nok += 1
                worst = max(worst, w)
    ncell = sum(len(r.get("certs", [])) for r in recs)
    print(f"verified: {nok} boxes with {ncell} cell certificates, {nemp} empty boxes, {nfail} failures; "
          f"worst certified bound {worst:.6f} < C5 = {float(V.C5.mid()):.11f}; {time.time() - t0:.0f}s", flush=True)
    print(f"end {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC", flush=True)
    print("ALL CHECKS PASSED" if nfail == 0 else "VERIFICATION FAILED", flush=True)
    return 0 if nfail == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
