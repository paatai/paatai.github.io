"""Float scan (evidence only, never proof): sup over F_heavy of the proof-shaped bound with EXACT residual moments.

Domain (proof-shaped, after Lemma E and reflection V+ >= V-): chord rates (a+, b+) at (tau, A) and (a-, b-) at
(-tau, -A); Q_s = (a_s tau + b_s A)^2 / (a_s + b_s) is the least edge mass with those rates (one atom),
M_s = a_s tau^2 + b_s A^2 the largest; F_heavy needs some V+ in [max(Q+, v), M+] with V+ < 0.8, so
Q+ < 0.8 and M+ >= v; then V- >= Q- and the residual has mass rho^2 = 1 - max(Q+, v) - Q- >= 0 (worst case;
E|.| is nondecreasing in the residual mass). Residual: two atoms in (-tau, tau) plus a Gaussian part.
Bound: B = sup{E h(Y): Y has the moments of Z_R up to degree D}, h(r) = E|C + r| (one Y for all shifts).
Usage: python3 heavy_scan.py D seed nstarts [v]
"""
import math
import sys

import numpy as np
from scipy.optimize import linprog, minimize

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from heavy_box_lp import A, C5, TAU, shift_law
from edge_split_feas import cumulants, moments_from_cumulants

NR = 4001


def exact_common(c, p, mom, D, extra=None, tol=1e-9):
    sc = math.sqrt(mom[2])
    zm = [mom[k] / sc ** k for k in range(D + 1)]
    Lz = max(10.0, (1e8 * math.sqrt(zm[D - 2] * zm[D])) ** (1.0 / (D - 1)))
    z = np.linspace(-Lz, Lz, NR)
    z = np.unique(np.concatenate([z, -c[np.abs(c) < Lz * sc] / sc] + ([np.asarray(extra) / sc] if extra is not None
                                                                         else [])))
    h = np.abs(c[None, :] + sc * z[:, None]) @ p
    rows, rhs = [], []
    for k in range(D + 1):
        e0, e1 = 2 * (k // 2), 2 * ((k + 1) // 2)
        s = max(1.0, math.sqrt(zm[e0] * zm[e1]))
        rows.append(z ** k / s)
        rhs.append(zm[k] / s)
    Am, b = np.array(rows), np.array(rhs)
    for t in (tol, 1e-7):
        res = linprog(-h, A_ub=np.vstack([Am[1:D], -Am[1:D], Am[D:]]),
                      b_ub=np.concatenate([b[1:D] + t, -b[1:D] + t, b[D:] + t]),
                      A_eq=Am[:1], b_eq=b[:1], bounds=(0, None), method="highs")
        if res.status == 0:
            return -res.fun
    return float("nan")


def Q(a, b):
    return (a * TAU + b * A) ** 2 / (a + b) if a + b > 0 else 0.0


def M(a, b):
    return a * TAU ** 2 + b * A ** 2


def decode(u, v):
    """u in R^8 -> (a+, b+, a-, b-, residual atoms, wG) or None if infeasible."""
    s = 1 / (1 + np.exp(-np.asarray(u)))
    ap, bp = 1.2 * s[0], 0.36 * s[1]
    am, bm = 0.75 * s[2], 0.23 * s[3]
    qp, qm = Q(ap, bp), Q(am, bm)
    if qp >= 0.8 or M(ap, bp) < v:
        return None
    vp = max(qp, v)
    if qm > vp or qm > 1 - vp:
        return None
    rho2 = 1 - vp - qm
    y1, y2 = TAU * (2 * s[4] - 1), TAU * (2 * s[5] - 1)
    f1 = s[6]
    f2 = (1 - f1) * s[7]
    g = 1 - f1 - f2
    return ap, bp, am, bm, rho2, [(y1, f1 * rho2), (y2, f2 * rho2)], g * rho2


def bound(u, D, v):
    dec = decode(u, v)
    if dec is None:
        return 0.0, None
    ap, bp, am, bm, rho2, rest, wG = dec
    cond = [(x, l) for x, l in [(TAU, ap), (A, bp), (-TAU, am), (-A, bm)] if l > 1e-12]
    c, p = shift_law(cond)
    if rho2 < 1e-9:
        return float(np.abs(c) @ p), dec
    mom = moments_from_cumulants(cumulants(rest, wG, D), D)
    val = exact_common(c, p, mom, D)
    if not np.isfinite(val):
        return 0.0, dec
    return val, dec


def fmt(dec):
    ap, bp, am, bm, rho2, rest, wG = dec
    r = " + ".join(f"{w:.4f} d_{x:+.4f}" for x, w in rest if w > 1e-5)
    return (f"a+ {ap:.4f} b+ {bp:.4f} a- {am:.4f} b- {bm:.4f} (Q+ {Q(ap, bp):.4f} M+ {M(ap, bp):.4f} "
            f"Q- {Q(am, bm):.4f})  rho2 {rho2:.4f} = {r} + {wG:.4f} G")


if __name__ == "__main__":
    D, seed, nst = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    v = float(sys.argv[4]) if len(sys.argv) > 4 else 0.5
    rng = np.random.default_rng(seed)
    best = (0.0, None)
    for st in range(nst):
        while True:
            u0 = rng.normal(0, 1.5, 8)
            if decode(u0, v) is not None:
                break
        f = lambda u: -bound(u, D, v)[0]
        res = minimize(f, u0, method="Nelder-Mead", options=dict(maxiter=400, xatol=1e-3, fatol=1e-6))
        val, dec = bound(res.x, D, v)
        print(f"D={D} seed {seed} start {st}: B = {val:.5f}  {fmt(dec)}", flush=True)
        if val > best[0]:
            best = (val, dec)
    print(f"BEST D={D} seed {seed}: B = {best[0]:.5f}  {fmt(best[1])}  (C5 = {C5})", flush=True)
