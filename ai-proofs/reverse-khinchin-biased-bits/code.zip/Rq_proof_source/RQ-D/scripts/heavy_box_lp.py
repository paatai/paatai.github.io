"""Float prototype (evidence only, never proof) of the per-box residual LP for F_heavy.

Bound chain for one box (tau = 0.85, A = 1.54):
  Z_K <=_cx Z_{K#}                          (Lemma E: chord law of each edge on {s tau, s A})
  Z_{K#} = C + Y,  C = sum_i x_i (N_i - l_i) over the conditioned chord atoms (x_i, rate l_i),
                   Y = Z_R, R = the rest (residual on [-tau, tau], plus extra atoms when a box is used),
  E|Z_K| <= E h(Y),  h(r) = E|C + r| = sum_N pi_N |c_N + r|,
  E h(Y) <= sup over laws nu of Y with E Y^k = moment polynomial of the cumulants kappa_j = int x^(j-2) dR,
            k <= D (top one <=), every product of >= 2 cumulants (j >= 3) a free variable w_alpha, bounded by
            Chebyshev's sum inequality |w_alpha| <= mu0^(|alpha|-1) int |x|^(s_alpha) dR (RQ-B's far_cell_lp)
            and, optionally, McCormick envelopes on a cell in (kappa_3, kappa_4).
This is the primal; its dual is a polynomial phi >= h (one polynomial for all shifts at once) plus a dual
polynomial in x, which is what an exact certificate would verify.
moment_polys / alpha_coeffs are copied from RQ-B's numerics/far_cell_lp.py (20:02 UTC mirror).
"""
import math
import sys
from functools import lru_cache

import numpy as np
from scipy.optimize import linprog

TAU, A = 0.85, 1.54
C5 = 0.85510045547


@lru_cache(maxsize=None)
def moment_polys(D):
    m = [dict() for _ in range(D + 1)]
    m[0][(0, ())] = 1
    for n in range(1, D + 1):
        acc = {}
        for i in range(2, n + 1):
            c = math.comb(n - 1, i - 1)
            for (p2, al), v in m[n - i].items():
                key = (p2 + 1, al) if i == 2 else (p2, tuple(sorted(al + (i,))))
                acc[key] = acc.get(key, 0) + c * v
        m[n] = acc
    return m


def alpha_coeffs(D, mu0):
    m = moment_polys(D)
    out = []
    for k in range(D + 1):
        d = {}
        for (p2, al), v in m[k].items():
            d[al] = d.get(al, 0.0) + v * mu0 ** p2
        out.append(d)
    return out


def pois_pmf(lam, tol=1e-16):
    if lam <= 0:
        return np.array([1.0])
    n = int(lam + 12 * math.sqrt(lam) + 15)
    k = np.arange(n + 1)
    lp = -lam + k * math.log(lam) - np.array([math.lgamma(i + 1) for i in k])
    return np.exp(lp)


def shift_law(cond, tol=1e-14):
    """cond = list of (x_i, rate_i). Returns atoms c and probabilities p of C = sum x_i (N_i - rate_i)."""
    c, p = np.array([0.0]), np.array([1.0])
    for x, lam in cond:
        q = pois_pmf(lam)
        cc = (c[:, None] + x * (np.arange(len(q)) - lam)[None, :]).ravel()
        pp = (p[:, None] * q[None, :]).ravel()
        keep = pp > tol
        cc, pp = cc[keep], pp[keep]
        key = np.round(cc, 10)
        u, inv = np.unique(key, return_inverse=True)
        p = np.bincount(inv, weights=pp)
        c = u
    return c, p / p.sum()


def resid_lp(c, p, mu0, D, caps=(), nx=171, L=None, nr=4001, cell=None, verbose=False):
    """sup E h(Y) over the relaxation. caps = list of (x, cap): extra atoms at x (outside [-tau, tau]) with
    R({x}) <= cap. cell = (k3lo, k3hi, k4lo, k4hi) or None."""
    sig = math.sqrt(max(mu0, 1e-6))
    if L is None:
        L = max(6.0, 9.0 * sig + 2.0)
    r = np.linspace(-L, L, nr)
    r = np.unique(np.concatenate([r, -c[np.abs(c) < L]]))
    h = np.abs(c[None, :] + r[:, None]) @ p
    x = np.unique(np.concatenate([np.linspace(-TAU, TAU, nx), [0.0], [cx for cx, _ in caps]]))
    cof = alpha_coeffs(D, mu0)
    alphas = sorted({al for k in range(D + 1) for al in cof[k] if len(al) >= 2}, key=lambda t: (len(t), t))
    nR, nX, nW = len(r), len(x), len(alphas)
    nv = nR + nX + nW
    rows_eq, rhs_eq, rows_ub, rhs_ub = [], [], [], []
    row = np.zeros(nv); row[:nR] = 1.0
    rows_eq.append(row); rhs_eq.append(1.0)
    for k in range(1, D + 1):
        sk = max(1.0, (max(sig, 0.5) * 1.5) ** k * math.prod(range(k - 1, 0, -2)))
        row = np.zeros(nv)
        row[:nR] = r ** k / sk
        lin = np.zeros(nX)
        for al, v in cof[k].items():
            if len(al) == 1:
                lin += v * x ** (al[0] - 2)
        row[nR:nR + nX] = -lin / sk
        for j, al in enumerate(alphas):
            row[nR + nX + j] = -cof[k].get(al, 0.0) / sk
        rhs = cof[k].get((), 0.0) / sk
        if k < D:
            rows_eq.append(row); rhs_eq.append(rhs)
        else:
            rows_ub.append(row); rhs_ub.append(rhs)
    row = np.zeros(nv); row[nR:nR + nX] = 1.0
    rows_eq.append(row); rhs_eq.append(mu0)
    for cx, cap in caps:
        row = np.zeros(nv); row[nR + int(np.argmin(np.abs(x - cx)))] = 1.0
        rows_ub.append(row); rhs_ub.append(cap)
    if cell is not None:
        k3lo, k3hi, k4lo, k4hi = cell
        for f, lo, hi in ((x, k3lo, k3hi), (x ** 2, k4lo, k4hi)):
            row = np.zeros(nv); row[nR:nR + nX] = f
            rows_ub.append(row.copy()); rhs_ub.append(hi)
            rows_ub.append(-row); rhs_ub.append(-lo)
    bounds = [(0, None)] * (nR + nX)
    for j, al in enumerate(alphas):
        s = sum(i - 2 for i in al)
        dens = mu0 ** (len(al) - 1) * np.abs(x) ** s
        sc = max(1.0, float(dens.max()))
        nonneg = all(i % 2 == 0 for i in al) or all(al.count(i) % 2 == 0 for i in set(al))
        row = np.zeros(nv); row[nR + nX + j] = 1.0 / sc; row[nR:nR + nX] = -dens / sc
        rows_ub.append(row); rhs_ub.append(0.0)
        if nonneg:
            bounds.append((0, None))
        else:
            row = np.zeros(nv); row[nR + nX + j] = -1.0 / sc; row[nR:nR + nX] = -dens / sc
            rows_ub.append(row); rhs_ub.append(0.0)
            bounds.append((None, None))
    cobj = np.zeros(nv); cobj[:nR] = -h
    res = linprog(cobj, A_ub=np.array(rows_ub), b_ub=np.array(rhs_ub), A_eq=np.array(rows_eq),
                  b_eq=np.array(rhs_eq), bounds=bounds, method="highs")
    if res.status != 0:
        if verbose:
            print("LP status", res.status, res.message)
        return float("nan"), None
    K = res.x[nR:nR + nX]
    supp = [(round(float(xx), 3), round(float(kk), 4)) for xx, kk in zip(x, K) if kk > 1e-4]
    return -res.fun, supp


def chord_rates(side_atoms):
    """side_atoms = [(|x|, w)] on [tau, A] -> (a, b) rates at tau and A (Lemma E)."""
    lam = sum(w / x ** 2 for x, w in side_atoms)
    m = sum(w / x for x, w in side_atoms)
    if lam == 0:
        return 0.0, 0.0
    p = (m / lam - TAU) / (A - TAU)
    return lam * (1 - p), lam * p


def law_to_box_input(atoms, wG):
    """Exact (degenerate box): conditioned chord atoms and residual mass."""
    plus = [(x, w) for x, w in atoms if x >= TAU]
    minus = [(-x, w) for x, w in atoms if x <= -TAU]
    ap, bp = chord_rates(plus)
    am, bm = chord_rates(minus)
    rest = [(x, w) for x, w in atoms if abs(x) < TAU]
    mu0 = sum(w for _, w in rest) + wG
    cond = [(TAU, ap), (A, bp), (-TAU, am), (-A, bm)]
    return [(x, l) for x, l in cond if l > 0], mu0, rest


TESTS = [
    ("K* (F maximiser)", [(1.2978, 0.8), (-1.1008, 0.095), (0.8499, 0.105)], 0.0),
    ("0.79 d1.30 + 0.11 d-1.54 + 0.10 d0.84", [(1.30, 0.79), (-1.54, 0.11), (0.84, 0.10)], 0.0),
    ("0.79 d1.414 + 0.21 G", [(1.414, 0.79)], 0.21),
    ("0.5 d1.2 + 0.5 G", [(1.2, 0.5)], 0.5),
    ("0.55 d1.1 + 0.45 d0.6", [(1.1, 0.55), (0.6, 0.45)], 0.0),
    ("0.5 d1.0 + 0.3 d-1.0 + 0.2 G", [(1.0, 0.5), (-1.0, 0.3)], 0.2),
    ("0.5 d1.3 + 0.5 d-0.84", [(1.3, 0.5), (-0.84, 0.5)], 0.0),
]

if __name__ == "__main__":
    D = int(sys.argv[1]) if len(sys.argv) > 1 else 16
    idx = [int(s) for s in sys.argv[2].split(",")] if len(sys.argv) > 2 else range(len(TESTS))
    print(f"D = {D}; residual class: all measures on [-tau, tau] of the residual's mass (no cells); "
          f"Chebyshev bounds on cumulant products", flush=True)
    for i in idx:
        name, atoms, wG = TESTS[i]
        cond, mu0, rest = law_to_box_input(atoms, wG)
        c, p = shift_law(cond)
        val, supp = resid_lp(c, p, mu0, D)
        print(f"{name:40s} mu0 = {mu0:.3f}  #shifts = {len(c)}  U = {val:.5f}  worst R {supp}", flush=True)
