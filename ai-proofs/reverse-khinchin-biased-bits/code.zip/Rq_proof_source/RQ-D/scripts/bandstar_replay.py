"""Replay checker for the box-level certificate of Theorem 13 (thm:bandstar of MAIN_RESULT.tex, Section 6.1).

The record (written by scripts/bandstar_record.py, default directory outputs/bandstar_cert):

  bandstar_leaves.npz
    HGRID, HMV, HLIN        the h values (floats, used exactly as stored)
    grid                    [MDEN, LDEN, SDEN, CDEN, RDEN, KLO, KHI] = [4096, 16384, 8192, 2^24, 4096, 2125, 4820]
    sq_box (n, 4)           certified square [a1, a2] x [b1, b2], in units of 1/SDEN
    sq_corner (n, 2)        corner (a_bar, b_bar) of the costs, in units of 1/CDEN
    sq_strips (n, 2)        Lambda strips [i/64, (i+1)/64], istart <= i < iend
    sq_nbox (n)             (Lambda, m) boxes examined in the square (leaves and bisected boxes)
    sq_h (n, 5, KHI-KLO+1)  indices into HGRID of the h used at m = k/MDEN for c_B (at t = m), c_C (at 2 theta - m),
                            phi(theta - m) (chi^C_h and -2y + chi^B_h(-y)) and phi(A - m)
    sq_off (n + 1)          the leaves of square s are sq_off[s] <= j < sq_off[s + 1], in the order of acceptance
    leaf_L1, leaf_L2        Lambda in [L1, L2]/LDEN
    leaf_k1, leaf_k2        m in [k1, k2]/MDEN
    leaf_meth               0 infeasible, 1 (O1) chord, 2 (O3) two-point chi^C_h, 3 (O4) two-point sqrt(y^2 + r^2) - y,
                            4 (O2) Taylor with -2y + chi^B_h(-y), 5 slope check
    leaf_opt                infeasible: which of the 8 inequalities INFEASIBLE fails; (O3), (O2): index of h in HMV
    leaf_aux                (O3): far point theta - kx/MDEN; (O2): t = jt/MDEN; slope: index into bandstar_slope.json
  bandstar_slope.json       per slope leaf {sq, leaf, box, pieces}; a piece {path, test, jr, B, O, C2}: path is the
                            bisection path of [r_0, r_B] ('0' lower half, '1' upper half), test is E (empty by (F4)),
                            T1, T2, T3 or T3K ((T3) with (O5)), jr gives r = min(jr/4096, 1/50), B and C2 are
                            ['lin', i] (h = HLIN[i]) or ['cs'], O is ['chord', P1, P2], ['O3', i], ['O5', i] or ['O4']

What is checked, from the record alone:
  (1) the certified squares form a quadtree cover of {a, b >= 0, a + b <= 1/5}: the squares of side 1/128 with
      a1 + b1 < 1/5, each certified or replaced by its children that meet the triangle, down to side 1/8192;
  (2) per square, (a_bar, b_bar), r^2 and [V_lo, V_hi] are recomputed in exact rationals by the rule of Section 6.1
      and the recorded corner must agree; the strips contain [V_lo/A^2, V_hi/theta^2] and [KLO, KHI]/MDEN contains
      [V_lo/A, V_hi/theta], so (F1)-(F2) put every feasible (Lambda, m) in the rectangle;
  (3) the leaves, in their recorded order, are exactly the leaves of a bisection of strips x m-blocks (alternately in
      m and Lambda), so they tile the rectangle;
  (4) every leaf passes its recorded certificate, decided in arb ball arithmetic (80 bits): the recorded inequality
      of (F1)-(F5) fails on the whole box for every V in [V_lo, V_hi]; or the direct check holds with the recorded
      option and h; or the slope pieces cover [r_0, r_B] and each is empty by (F4) or passes its test.
Only the enclosures chiB, chiC (Section 5.1) and lin_B, lin_C (slope paragraph of Section 6.1) are taken from
verify_bandstar.py (md5 checked). The rest (constants, square rule, subdivision, (F1)-(F5), box geometry, cost
assembly, options and tests) is written here from Section 6.1.

Usage: python3 scripts/bandstar_replay.py [recorddir] [nproc] [full|partial|selftest]
  partial: skip (1) (for a record of some squares only); selftest: tampered records must be rejected.
"""
import hashlib
import json
import math
import os
import sys
import time
from fractions import Fraction
from multiprocessing import Pool

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import numpy as np  # noqa: E402
from flint import arb, ctx  # noqa: E402

from verify_bandstar import chiB, chiC, lin_B, lin_C  # noqa: E402

ctx.prec = 80
VB_MD5 = "b5b55ceec828f01debc6c1a422e7270f"

TH = arb(17) / 20
AA = arb(77) / 50
TH2, AA2 = TH * TH, AA * AA
HALF = arb(1) / 2
ZERO = arb(0)
C5LO = (2 * (2 * (arb(5) / 4).log()).sqrt() * arb(16) / 25).lower()
GMAX = 2 * HALF.sqrt() * (-HALF).exp()
RLIN = arb(1) / 50
MDEN, LDEN, SDEN, CDEN, RDEN = 4096, 16384, 8192, 2 ** 24, 4096
KLO, KHI = 2125, 4820
KYMIN = -1280
FIFTH = Fraction(1, 5)
METHODS = ("infeasible", "chord", "twopoint_C", "twopoint_CS", "taylor_B", "slope")
PAPER = {"infeasible": "infeasible", "chord": "(O1)", "twopoint_C": "(O3)", "twopoint_CS": "(O4)",
         "taylor_B": "(O2)", "slope": "slope"}
PUBLISHED = {"infeasible": 3114781, "chord": 551105, "twopoint_C": 2876016, "twopoint_CS": 128597,
             "taylor_B": 1203286, "slope": 426}
G = {"shift": ZERO}


def md5(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


# ---------------------------------------------------------------- elementary bounds (Section 6.1, "On a box")

def amax(x, y):
    return (x + y + abs(x - y)) / 2


def amin(x, y):
    return (x + y - abs(x - y)) / 2


def smaller(x, y):
    """x or y, whichever is a valid upper bound of min(x, y)."""
    return x if x < y else y


def g(L):
    return 2 * L.sqrt() * (-L).exp()


def gmax_on(l, u):
    """max of g on [l, u] (g increases on [0, 1/2] and decreases after)."""
    if u <= HALF:
        return g(u)
    if l >= HALF:
        return g(l)
    return GMAX


def target(L1, L2):
    """T = max(min(g(L1), g(L2)), C5), a lower bound of max(g, C5) on [L1, L2] (g is unimodal)."""
    g1, g2 = g(L1).lower(), g(L2).lower()
    gl = g1 if g1 < g2 else g2
    return (gl if gl > C5LO else C5LO) - G["shift"]


def main_max(L1, L2, m2, Vhi):
    """Upper bound of 2 e^-L min(m, sqrt(L V)) over L in [L1, L2], m <= m2, V <= Vhi."""
    Lc = m2 * m2 / Vhi
    if L2 <= Lc:
        return Vhi.sqrt() * gmax_on(L1, L2)
    if L1 >= Lc:
        return 2 * m2 * (-L1).exp()
    return Vhi.sqrt() * gmax_on(smaller(L1, Lc.lower()), smaller(L2, Lc.upper()))


def lel_max(L1, L2):
    """max of t e^-t on [L1, L2]."""
    if L2 <= 1:
        return L2 * (-L2).exp()
    if L1 >= 1:
        return L1 * (-L1).exp()
    return (-arb(1)).exp()


def P2(L):
    return 1 - (-L).exp() * (1 + L)


def cs(y, r2):
    return (y * y + r2).sqrt() - y


def grid_ceil(x, den):
    """Smallest j with j/den >= every point of the ball x (exact comparisons)."""
    u = x.upper()
    j = math.ceil(float(u) * den)
    while arb(j) / den < u:
        j += 1
    while arb(j - 1) / den >= u:
        j -= 1
    return j


def jump_geometry(L1, L2, m1, m2, Vhi):
    """mu_1 in [mu_lo, mu_hi]; sigma_J^2 <= s2 (exact formula or Bhatia-Davis); w' <= w; u' <= min (d + s2/d)."""
    mu_lo = amax(TH, m1 / L2)
    mu_hi = amin(AA, m2 / L1)
    dlo = (mu_lo - TH).lower()
    if dlo < 0:
        dlo = ZERO
    dhi = (mu_hi - TH).upper()
    s2a = ((L2 * Vhi - m1 * m1) / (L1 * L1)).upper()
    s2b = (dhi * (AA - TH - dlo)).upper()
    s2 = s2a if s2a < s2b else s2b
    if s2 < 0:
        s2 = ZERO
    if s2 == 0:
        wl = arb(1) if dlo > 0 else ZERO
        ul = dlo
    else:
        wl = (dlo * dlo / (s2 + dlo * dlo)).lower()
        s = s2.sqrt()
        if dlo >= s:
            ul = (dlo + s2 / dlo).lower()
        elif dhi <= s:
            ul = (dhi + s2 / dhi).lower()
        else:
            ul = (2 * s).lower()
    return mu_lo, mu_hi, s2, wl, ul


def r_eff(jr):
    r = arb(jr) / RDEN
    return r if r < RLIN else RLIN


# ---------------------------------------------------------------- one (a, b) square

def ceil_to(x, den):
    return Fraction(math.ceil(x * den), den)


class Square:
    def __init__(self, box, hidx, hgrid, hmv, hlin):
        a1, a2, b1, b2 = (int(v) for v in box)
        self.box = (a1, a2, b1, b2)
        s_hi = Fraction(a2 + b2, SDEN)
        self.Vhi = 1 - arb(a1 + b1) / SDEN
        if s_hi <= FIFTH:
            ac, bc = Fraction(a2, SDEN), Fraction(b2, SDEN)
            self.Vlo = 1 - arb(a2 + b2) / SDEN
            self.r2 = arb(a2 + b2) / SDEN
        else:
            ac = min(Fraction(a2, SDEN), ceil_to(FIFTH - Fraction(b1, SDEN), CDEN))
            bc = min(Fraction(b2, SDEN), ceil_to(FIFTH - Fraction(a1, SDEN), CDEN))
            self.Vlo = 1 - arb(1) / 5
            self.r2 = arb(1) / 5 if ac + bc > FIFTH else arb(int((ac + bc) * CDEN)) / CDEN
        assert (ac * CDEN).denominator == 1 and (bc * CDEN).denominator == 1
        self.corner = (int(ac * CDEN), int(bc * CDEN))
        self.a, self.b = arb(self.corner[0]) / CDEN, arb(self.corner[1]) / CDEN
        self.s_hi = arb(a2 + b2) / SDEN
        self.slope = s_hi <= Fraction(1, 50)
        self.hB, self.hC2, self.hP1, self.hP1b, self.hP2 = ([float(hgrid[i]) for i in row] for row in hidx)
        self.hmv, self.hlin = hmv, hlin
        self.memo = {}

    def _get(self, key, f):
        v = self.memo.get(key)
        if v is None:
            v = self.memo[key] = f()
        return v

    def cB(self, k):
        """>= 2E(W - m)_+ at m = k/MDEN, for every (a, b) of the square."""
        def f():
            m = arb(k) / MDEN
            return smaller(chiB(m, arb(self.hB[k - KLO]), self.a, self.b).upper(), cs(m, self.r2).upper())
        return self._get(("cB", k), f)

    def cC2(self, k):
        """>= phi(2 theta - m)."""
        def f():
            y = 2 * TH - arb(k) / MDEN
            return smaller(chiC(y, arb(self.hC2[k - KLO]), self.a, self.b).upper(), cs(y, self.r2).upper())
        return self._get(("cC2", k), f)

    def phi1(self, k):
        """>= phi(theta - m): min of chi^C_h(y), sqrt(y^2 + r^2) - y, -2y + chi^B_h(-y) at y = theta - m."""
        def f():
            m = arb(k) / MDEN
            y = TH - m
            v = smaller(chiC(y, arb(self.hP1[k - KLO]), self.a, self.b).upper(), cs(y, self.r2).upper())
            return smaller(v, (chiB(m - TH, arb(self.hP1b[k - KLO]), self.a, self.b) - 2 * y).upper())
        return self._get(("phi1", k), f)

    def phi2(self, k):
        """>= phi(A - m)."""
        def f():
            y = AA - arb(k) / MDEN
            return smaller(chiC(y, arb(self.hP2[k - KLO]), self.a, self.b).upper(), cs(y, self.r2).upper())
        return self._get(("phi2", k), f)

    def chiC_y(self, i, k):
        return self._get(("Cy", i, k), lambda: chiC(TH - arb(k) / MDEN, arb(float(self.hmv[i])), self.a,
                                                    self.b).upper())

    def chiB_t(self, i, j):
        return self._get(("Bt", i, j), lambda: chiB(arb(j) / MDEN, arb(float(self.hmv[i])), self.a, self.b).upper())


# ---------------------------------------------------------------- certificates of one leaf

def infeasible_ok(S, L1, L2, m1, m2, which):
    """The recorded inequality of (F1)-(F5) fails at every point of the box for every V in [V_lo, V_hi]."""
    Vlo, Vhi = S.Vlo, S.Vhi
    tests = {1: lambda: L2 < Vlo / AA2,                       # (F1) Lambda >= V/A^2
             2: lambda: L1 > Vhi / TH2,                       # (F1) Lambda <= V/theta^2
             3: lambda: m2 < Vlo / AA,                        # (F2) m >= V/A
             4: lambda: m1 > Vhi / TH,                        # (F2) m <= V/theta
             5: lambda: m2 < TH * L1,                         # (F3) m >= theta Lambda
             6: lambda: m1 > AA * L2,                         # (F3) m <= A Lambda
             7: lambda: m1 * m1 > L2 * Vhi,                   # (F4) m^2 <= Lambda V (m >= m1 > 0)
             8: lambda: L1 > (1 / AA + 1 / TH) * m2 - Vlo / (AA * TH)}   # (F5)
    return which in tests and bool(tests[which]())


def direct_ok(S, L1, L2, m1, m2, k1, k2, meth, opt, aux):
    """M + e^-L1 c_B + P2(L2) c_C + max(t e^-t) O' < T, with O' the recorded option."""
    tgt = target(L1, L2)
    base = main_max(L1, L2, m2, S.Vhi) + (-L1).exp() * S.cB(k1) + P2(L2) * S.cC2(k2)
    if not (base < tgt):
        return False
    room = (tgt - base) / lel_max(L1, L2)
    mu_lo, mu_hi, s2, wl, ul = jump_geometry(L1, L2, m1, m2, S.Vhi)
    if meth == 1:
        # (O1): chord of phi on [theta - m, A - m] at mu_lo, upper end value replaced by max(phi1, phi2)
        p1, p2 = S.phi1(k2), S.phi2(k2)
        return ((AA - mu_lo) * amax(p1, p2) + (mu_lo - TH) * p2) / (AA - TH) < room
    if meth == 2:
        # (O3): (1 - w') chi^C_h(theta - m2) + w' chi^C_h(y), y = theta - kx/MDEN <= theta - m2 + u'
        i, kx = opt, aux
        if not (0 <= i < len(S.hmv) and arb(kx) / MDEN >= m2 - ul):
            return False
        return (1 - wl) * S.chiC_y(i, k2) + wl * S.chiC_y(i, kx) < room
    if meth == 3:
        # (O4): psi(y) = sqrt(y^2 + r^2) - y, needs theta - m2 >= 0
        j0 = TH - m2
        if not (j0 >= 0):
            return False
        return (1 - wl) * cs(j0, S.r2) + wl * cs(j0 + ul, S.r2) < room
    if meth == 4:
        # (O2): -2 (mu_lo - m2) + chi^B_h(t) + s2/(2h), t = jt/MDEN <= -(mu_hi - m1)
        i, jt = opt, aux
        if not (0 <= i < len(S.hmv) and arb(jt) / MDEN <= -(mu_hi - m1)):
            return False
        return -2 * (mu_lo - m2) + S.chiB_t(i, jt) + s2 / (2 * arb(float(S.hmv[i]))) < room
    return False


def complete_code(paths, maxdepth=6):
    """The bisection paths are distinct, prefix-free and cover the root interval."""
    P = set(paths)
    if len(P) != len(paths) or any(len(p) > maxdepth or set(p) - {"0", "1"} for p in paths):
        return False
    if any(p[:j] in P for p in paths for j in range(len(p))):
        return False

    def cov(pre):
        if pre in P:
            return True
        return len(pre) < maxdepth and cov(pre + "0") and cov(pre + "1")

    return cov("")


def lin_value(S, kind, tag, k, jr):
    """Linear bound (alpha, beta), valid for a, b >= 0, a + b <= r_eff(jr), of: 'B' c_B at m, 'C2' c_C at
    2 theta - m, 'P1' phi(theta - m), 'P2' phi(A - m), m = k/MDEN."""
    m = arb(k) / MDEN
    t = m if kind == "B" else {"C2": 2 * TH - m, "P1": TH - m, "P2": AA - m}[kind]
    if tag == ["cs"]:
        if not (t > 0):
            return None
        c = (1 / (2 * t)).upper()                 # sqrt(t^2 + rho^2) - t <= rho^2/(2t)
        return c, c
    if len(tag) != 2 or tag[0] != "lin" or not (0 <= tag[1] < len(S.hlin)):
        return None
    h, r = arb(float(S.hlin[tag[1]])), r_eff(jr)
    return lin_B(t, h, r) if kind == "B" else lin_C(t, h, r)


def slope_ok(S, L1, L2, m1, m2, k1, k2, cert):
    if not S.slope or cert is None:
        return False
    j0 = TH - m2
    if not (j0 > 0):
        return False
    tgt = target(L1, L2)
    g1, g2 = g(L1).lower(), g(L2).lower()
    glo = g1 if g1 < g2 else g2
    ghi = gmax_on(L1, L2)
    eL, LeL, p2 = (-L1).exp(), lel_max(L1, L2), P2(L2)
    mu_lo = amax(TH, m1 / L2)
    dlo = (mu_lo - TH).lower()
    w = (AA - mu_lo) / (AA - TH)
    # rho^2 in [r_0, r_B]: r_0 = a1 + b1, r_B = min(a2 + b2, 1 - m1^2/L2) by (F4)
    rB = smaller(S.s_hi, (1 - m1 * m1 / L2).upper())
    r0 = (1 - S.Vhi).lower()
    if r0 < 0:
        r0 = ZERO
    if rB <= r0:
        rB = r0
    if not complete_code([p["path"] for p in cert]):
        return False
    for p in cert:
        r1, r2 = r0, rB
        for c in p["path"]:
            rm = (r1 + r2) / 2
            r1, r2 = (r1, rm) if c == "0" else (rm, r2)
        Vh = 1 - r1
        if p["test"] == "E":
            if not (m1 * m1 > L2 * Vh):
                return False
            continue
        jr = p["jr"]
        if not (r_eff(jr) >= r2):
            return False
        _, _, s2, wl, ul = jump_geometry(L1, L2, m1, m2, Vh)
        kx = max(grid_ceil(m2 - ul, MDEN), KYMIN)
        oB = lin_value(S, "B", p["B"], k1, jr)
        oC = lin_value(S, "C2", p["C2"], k2, jr)
        O = p["O"]
        kap = ZERO
        oO = None
        if O[0] == "chord" and len(O) == 3:
            q1, q2 = lin_value(S, "P1", O[1], k2, jr), lin_value(S, "P2", O[2], k2, jr)
            if q1 is not None and q2 is not None:
                (a1, b1), (a2, b2) = q1, q2
                oO = ((a2 + w * (amax(a1, a2) - a2)).upper(), (b2 + w * (amax(b1, b2) - b2)).upper())
        elif O[0] == "O3" and len(O) == 2 and 0 <= O[1] < len(S.hlin):
            h, r = arb(float(S.hlin[O[1]])), r_eff(jr)
            q0, q1 = lin_C(TH - m2, h, r), lin_C(TH - arb(kx) / MDEN, h, r)
            if q0 is not None and q1 is not None and arb(kx) / MDEN >= m2 - ul:
                oO = (((1 - wl) * q0[0] + wl * q1[0]).upper(), ((1 - wl) * q0[1] + wl * q1[1]).upper())
        elif O[0] == "O5" and len(O) == 2 and 0 <= O[1] < len(S.hlin) and dlo > 0:
            # far point theta - kxK/MDEN <= theta - m2 + d_lo; kappa <= d_lo^2 sqrt(L1/(1 - r1)) (lem:absorb)
            h = arb(float(S.hlin[O[1]]))
            kxK = max(grid_ceil(m2 - dlo, MDEN), KYMIN)
            qK = lin_C(TH - arb(kxK) / MDEN, h, r_eff(jr))
            e = h - j0
            kap = (e * e / (2 * h)).upper() if e > 0 else ZERO
            if qK is not None and kap <= (dlo * dlo * (L1 / Vh).sqrt()).lower():
                c = (1 - wl) / (2 * h)
                oO = ((c + qK[0]).upper(), (c + qK[1]).upper())
        elif O == ["O4"]:
            xlo = TH - arb(kx) / MDEN
            if xlo > 0:
                c = ((1 - wl) / (2 * j0) + wl / (2 * xlo)).upper()
                oO = (c, c)
        if oB is None or oC is None or oO is None:
            return False
        Mx = amax(eL * oB[0] + LeL * oO[0] + p2 * oC[0], eL * oB[1] + LeL * oO[1] + p2 * oC[1])
        test, o5 = p["test"], O[0] == "O5"
        if test == "T1":
            ok = G["shift"] == 0 and Mx < glo / 2
        elif test == "T2":
            ex = Mx - ghi / 2
            ok = ghi + amax(r1 * ex, r2 * ex) < tgt
        elif test == "T3":
            ok = not o5 and Mx >= 0 and main_max(L1, L2, m2, Vh) + r2 * Mx < tgt
        elif test == "T3K":
            M0 = main_max(L1, L2, m2, Vh)
            Mk = amax(M0, eL * (2 * m2 + kap * amax(L2 * Vh - m2 * m2, ZERO) / (L1 * dlo * dlo)))
            ok = o5 and Mx >= 0 and Mk + r2 * Mx < tgt
        else:
            ok = False
        if not ok:
            return False
    return True


# ---------------------------------------------------------------- one square: rectangle, tiling, leaves

W = {}


def init_worker(hgrid, hmv, hlin):
    W.update(hgrid=hgrid, hmv=hmv, hlin=hlin)


def square_task(args):
    s, box, corner, strips, hidx, L1s, L2s, k1s, k2s, meth, opt, aux, certs, shift = args
    t0 = time.time()
    G["shift"] = arb(shift)
    S = Square(box, hidx, W["hgrid"], W["hmv"], W["hlin"])
    errors = []
    if tuple(int(v) for v in corner) != S.corner:
        errors.append(("corner differs", tuple(int(v) for v in corner), S.corner))
    istart, iend = (int(v) for v in strips)
    if not (arb(istart) / 64 <= S.Vlo / AA2 and arb(iend) / 64 >= S.Vhi / TH2):
        errors.append(("strips do not contain [V_lo/A^2, V_hi/theta^2]", istart, iend))
    if not (arb(KLO) / MDEN <= S.Vlo / AA and arb(KHI) / MDEN >= S.Vhi / TH):
        errors.append(("m range does not contain [V_lo/A, V_hi/theta]",))
    L1s, L2s, k1s, k2s = L1s.tolist(), L2s.tolist(), k1s.tolist(), k2s.tolist()
    meth, opt, aux = meth.tolist(), opt.tolist(), aux.tolist()
    n = len(L1s)
    counts = [0] * len(METHODS)
    stack = [(i * 256, (i + 1) * 256, k, min(k + 64, KHI), 0) for i in range(istart, iend) for k in range(KLO, KHI, 64)]
    pos = 0
    while stack:
        a, b, c, d, depth = stack.pop()
        if pos < n and a == L1s[pos] and b == L2s[pos] and c == k1s[pos] and d == k2s[pos]:
            L1, L2, m1, m2 = arb(a) / LDEN, arb(b) / LDEN, arb(c) / MDEN, arb(d) / MDEN
            mt = meth[pos]
            if mt == 0:
                ok = infeasible_ok(S, L1, L2, m1, m2, opt[pos])
            elif mt == 5:
                ok = slope_ok(S, L1, L2, m1, m2, c, d, certs.get(pos))
            else:
                ok = direct_ok(S, L1, L2, m1, m2, c, d, mt, opt[pos], aux[pos])
            if ok:
                counts[mt] += 1
            else:
                errors.append(("leaf fails", pos, (a, b, c, d), METHODS[mt] if mt < len(METHODS) else mt))
            pos += 1
            continue
        if d - c > 1 and depth % 2 == 0:
            km = (c + d) // 2
            stack += [(a, b, c, km, depth + 1), (a, b, km, d, depth + 1)]
        elif b - a > 1:
            lm = (a + b) // 2
            stack += [(a, lm, c, d, depth + 1), (lm, b, c, d, depth + 1)]
        else:
            errors.append(("box not covered by the leaves", (a, b, c, d)))
            break
    if pos != n:
        errors.append(("leaves left over after the tiling", n - pos))
    return s, counts, len(errors), errors[:3], time.time() - t0


# ---------------------------------------------------------------- driver

def cover_check(sq_box):
    """(1): the certified squares form a quadtree cover of the triangle."""
    cert, bad = {}, []
    for a1, a2, b1, b2 in sq_box.tolist():
        side = a2 - a1
        if not (side > 0 and side == b2 - b1 and side & (side - 1) == 0 and a1 % side == 0 and b1 % side == 0
                and 5 * (a1 + b1) < SDEN):
            bad.append((a1, a2, b1, b2))
        cert[(a1, b1, side)] = True
    used, missing = set(), []

    def cover(a1, b1, side):
        if (a1, b1, side) in cert:
            used.add((a1, b1, side))
            return
        if side == 1:
            missing.append((a1, b1, side))
            return
        hs = side // 2
        for a, b in ((a1, b1), (a1 + hs, b1), (a1, b1 + hs), (a1 + hs, b1 + hs)):
            if 5 * (a + b) < SDEN:
                cover(a, b, hs)

    roots = [(64 * i, 64 * j) for i in range(26) for j in range(26) if 5 * 64 * (i + j) < SDEN]
    for a, b in roots:
        cover(a, b, 64)
    return dict(level0_squares=len(roots), malformed=len(bad), uncovered=len(missing), unused=len(cert) - len(used),
                ok=not bad and not missing and len(used) == len(cert))


def load(d):
    Z = np.load(os.path.join(d, "bandstar_leaves.npz"))
    R = {k: Z[k] for k in Z.files}
    with open(os.path.join(d, "bandstar_slope.json")) as f:
        R["slope"] = json.load(f)
    return R


def tasks_of(R, shift=0.0):
    off, slope = R["sq_off"], R["slope"]
    by_sq = {}
    for e_idx, e in enumerate(slope):
        by_sq.setdefault(e["sq"], {})[e["leaf"] - int(off[e["sq"]])] = (e_idx, e)
    out = []
    for s in range(len(R["sq_box"])):
        lo, hi = int(off[s]), int(off[s + 1])
        certs = {}
        for p, (e_idx, e) in by_sq.get(s, {}).items():
            j = lo + p
            if (lo <= j < hi and R["leaf_meth"][j] == 5 and R["leaf_aux"][j] == e_idx
                    and e["box"] == [int(R["leaf_L1"][j]), int(R["leaf_L2"][j]), int(R["leaf_k1"][j]),
                                     int(R["leaf_k2"][j])]):
                certs[p] = e["pieces"]
        out.append((s, R["sq_box"][s], R["sq_corner"][s], R["sq_strips"][s], R["sq_h"][s],
                    R["leaf_L1"][lo:hi], R["leaf_L2"][lo:hi], R["leaf_k1"][lo:hi], R["leaf_k2"][lo:hi],
                    R["leaf_meth"][lo:hi], R["leaf_opt"][lo:hi], R["leaf_aux"][lo:hi], certs, shift))
    return out


def run_tasks(R, tasks, nproc):
    with Pool(nproc, initializer=init_worker, initargs=(R["HGRID"], R["HMV"], R["HLIN"])) as pool:
        return sorted(pool.imap_unordered(square_task, tasks, chunksize=1))


def header(d):
    lines = [f"bandstar_replay.py, record {os.path.normpath(d)}",
             "start: " + time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime())]
    for p in (os.path.join(d, "bandstar_leaves.npz"), os.path.join(d, "bandstar_slope.json"),
              os.path.join(HERE, "bandstar_replay.py"), os.path.join(HERE, "verify_bandstar.py")):
        lines.append(f"md5 {os.path.relpath(p, os.path.join(HERE, '..'))}: {md5(p)}")
    import flint
    import scipy
    lines.append(f"python {sys.version.split()[0]}, numpy {np.__version__}, scipy {scipy.__version__}, "
                 f"python-flint {flint.__version__}")
    return lines


def full(d, nproc, partial=False):
    for ln in header(d):
        print(ln, flush=True)
    assert md5(os.path.join(HERE, "verify_bandstar.py")) == VB_MD5, "verify_bandstar.py is not the refereed version"
    R = load(d)
    grid = R["grid"].tolist()
    assert grid == [MDEN, LDEN, SDEN, CDEN, RDEN, KLO, KHI], grid
    nsq, nleaf = len(R["sq_box"]), int(R["sq_off"][-1])
    print(f"record: {nsq} squares, {nleaf} leaf boxes, {len(R['slope'])} slope certificates", flush=True)
    cov = None
    if not partial:
        cov = cover_check(R["sq_box"])
        print("(1) cover of the triangle by the certified squares:", json.dumps(cov), flush=True)
    t0 = time.time()
    res = run_tasks(R, tasks_of(R), nproc)
    counts = np.sum([r[1] for r in res], axis=0).tolist()
    nerr = sum(r[2] for r in res)
    bad = [(int(r[0]), r[3]) for r in res if r[2]]
    sides = {}
    for r in res:
        a1, a2 = int(R["sq_box"][r[0]][0]), int(R["sq_box"][r[0]][1])
        key = f"1/{SDEN // (a2 - a1)}"
        e = sides.setdefault(key, dict(squares=0, leaves=0))
        e["squares"] += 1
        e["leaves"] += sum(r[1])
    by_method = {PAPER[m]: c for m, c in zip(METHODS, counts)}
    print("(2)-(4) squares by side:", json.dumps(sides), flush=True)
    print("leaves verified, by certificate:", json.dumps(by_method), flush=True)
    if not partial:
        print("same counts as the published run (MAIN_RESULT Section 6.1):",
              all(c == PUBLISHED[m] for m, c in zip(METHODS, counts)), flush=True)
    print(f"squares with errors: {len(bad)}, errors: {nerr}", flush=True)
    for s, e in bad[:10]:
        print("  square", s, R["sq_box"][s].tolist(), e, flush=True)
    used_slope = counts[5]
    verdict = (nerr == 0 and sum(counts) == nleaf and used_slope == len(R["slope"]) and (partial or cov["ok"]))
    print(f"time {time.time() - t0:.0f}s", flush=True)
    print("VERDICT: " + ("record VALID: every leaf certificate holds and the leaves tile every square"
                         + ("" if partial else "; the squares cover the triangle") if verdict else "record REJECTED"),
          flush=True)
    print("end: " + time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()), flush=True)
    return verdict


def selftest(d, nproc):
    """Tampered copies of the record must be rejected (the checker is not vacuous)."""
    for ln in header(d):
        print(ln, flush=True)
    R = load(d)
    T = tasks_of(R)
    side = (R["sq_box"][:, 1] - R["sq_box"][:, 0]).astype(int)
    meth = R["leaf_meth"]
    off = R["sq_off"]

    def first_square_with(code):
        for s in range(len(T)):
            if np.any(meth[off[s]:off[s + 1]] == code):
                return s
        return None

    def replace(t, **kw):
        names = ("s", "box", "corner", "strips", "hidx", "L1", "L2", "k1", "k2", "meth", "opt", "aux", "certs",
                 "shift")
        t = list(t)
        for k, v in kw.items():
            t[names.index(k)] = v
        return tuple(t)

    cases = []
    s = first_square_with(1)
    t = T[s]
    cases.append(("drop the first leaf of a square", replace(t, **{k: v[1:] for k, v in zip(
        ("L1", "L2", "k1", "k2", "meth", "opt", "aux"), t[5:12])}, certs={p - 1: c for p, c in t[12].items()})))
    k2 = t[8].copy()
    k2[0] += 1
    cases.append(("move the upper m-edge of one leaf by 1/4096", replace(t, k2=k2)))
    j = int(np.nonzero(t[9] == 1)[0][0])
    for which in range(1, 9):
        m2 = t[9].copy()
        m2[j] = 0
        o2 = t[10].copy()
        o2[j] = which
        cases.append((f"declare an (O1) leaf infeasible by inequality {which}", replace(t, meth=m2, opt=o2)))
    s3 = first_square_with(2)
    t3 = T[s3]
    j = int(np.nonzero((t3[9] == 2) & (t3[11] > KYMIN))[0][0])
    a3 = t3[11].copy()
    a3[j] -= 64
    cases.append(("(O3) leaf with its far point moved 64 grid steps to the right", replace(t3, aux=a3)))
    s5 = first_square_with(5)
    t5 = T[s5]
    multi = [(p, c) for p, c in t5[12].items() if len(c) > 1]
    if multi:
        p, c = multi[0]
        certs = dict(t5[12])
        certs[p] = c[1:]
        cases.append(("slope leaf with one rho^2 piece removed", replace(t5, certs=certs)))
    o5 = [(p, c) for p, c in t5[12].items() if any(q.get("O", [""])[0] == "O5" and q["test"] != "T3K" for q in c)]
    if o5:
        p, c = o5[0]
        certs = dict(t5[12])
        certs[p] = [dict(q, test="T3") if q.get("O", [""])[0] == "O5" else q for q in c]
        cases.append(("slope leaf: (O5) piece re-labelled (T3), which ignores kappa", replace(t5, certs=certs)))
    smallest = [T[s] for s in range(len(T)) if side[s] == side.min()]
    cases.append((f"target lowered by 0.001 on the {len(smallest)} smallest squares",
                  [replace(t, shift=0.001) for t in smallest]))
    allrej = True
    for name, tk in cases:
        tk = tk if isinstance(tk, list) else [tk]
        res = run_tasks(R, tk, nproc)
        nerr = sum(r[2] for r in res)
        nsq = sum(1 for r in res if r[2])
        rejected = nerr > 0
        allrej &= rejected
        print(f"{'REJECTED' if rejected else 'ACCEPTED (bad)'}: {name}: {nsq} of {len(res)} squares with errors, "
              f"{nerr} errors; first: {res[[r[2] > 0 for r in res].index(True)][3][0] if rejected else '-'}",
              flush=True)
    print("SELFTEST " + ("passed: every tampered record was rejected" if allrej else "FAILED"), flush=True)
    return allrej


if __name__ == "__main__":
    d = sys.argv[1] if len(sys.argv) > 1 else os.path.join(HERE, "..", "outputs", "bandstar_cert")
    nproc = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    mode = sys.argv[3] if len(sys.argv) > 3 else "full"
    if mode == "selftest":
        ok = selftest(d, nproc)
    else:
        ok = full(d, nproc, partial=(mode == "partial"))
    sys.exit(0 if ok else 1)
