"""Float local search (evidence only): sup E|Z_K| near the far-region maximiser shape
K = v1 d_a + w2 d_-b + w3 d_c + w0 G (a in [0.85, A], b in [0, A], c just below a band threshold),
for the agreed far region F and for F minus the extra bands B(0.80, 0.15), B(0.75, 0.10) (and mirrors).
"""
import sys
import numpy as np
from scipy.optimize import minimize

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from idlib import mean_abs_small

A = 1.54
EPS = 1e-6


def value(p, c, cap3):
    a, b, v1, w2, w3 = p
    a = min(max(a, 0.85), A)
    b = min(max(b, 0.05), A)
    v1 = min(max(v1, 0.0), 0.8)
    w3 = min(max(w3, 0.0), cap3)
    w2 = max(w2, 0.0)
    if b >= 0.85:
        w2 = min(w2, 0.8)
    w0 = 1.0 - v1 - w2 - w3
    if w0 < 0:
        return -1.0, None
    K = [(a, v1), (-b, w2), (c, w3), (0.0, w0)]
    return mean_abs_small(K), K


def run(label, c, cap3, starts):
    best = (-1, None)
    for p0 in starts:
        r = minimize(lambda p: -value(p, c, cap3)[0], p0, method="Nelder-Mead",
                     options={"maxiter": 3000, "xatol": 1e-7, "fatol": 1e-10})
        v, K = value(r.x, c, cap3)
        if v > best[0]:
            best = (v, K)
    v, K = best
    atoms = ", ".join(f"{w:.4f} d_{x:+.4f}" for x, w in K)
    print(f"{label}: c = {c:.6f}, w3 <= {cap3:.3f}: E|Z| = {v:.6f}  K = {atoms}", flush=True)
    return v


if __name__ == "__main__":
    starts = [np.array([1.288, 1.105, 0.8, 0.1, 0.1]), np.array([1.32, 1.4, 0.8, 0.1, 0.1]),
              np.array([1.19, 1.13, 0.8, 0.15, 0.05]), np.array([1.25, 0.9, 0.75, 0.15, 0.1])]
    run("F  (c = 0.85-)", 0.85 - EPS, 0.2, starts)
    run("F' (c = 0.85-)", 0.85 - EPS, 0.05, starts)
    run("F' (c = 0.80-)", 0.80 - EPS, 0.10, starts)
    run("F' (c = 0.75-)", 0.75 - EPS, 0.2, starts)
    run("F' (c = 0.70)", 0.70, 0.2, starts)
