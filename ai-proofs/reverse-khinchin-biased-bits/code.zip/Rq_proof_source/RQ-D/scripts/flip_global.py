"""Global test of the flip bound on random Kolmogorov measures (float).

For K = sum_j w_j delta_{x_j} (+ Gaussian), theta ranges over candidate thresholds; S = atoms >= theta must satisfy
theta > m_S. The residual (atoms < theta) is split into positive mass rp (jumps in (0, theta)) and negative /
Gaussian mass rn, then bounded by the comparison lemma with the worst placements (top jump theta for B, -A for C).
The C term uses the exact law of Y = Z_{K_S} on {N_S >= 1}.
"""
import sys
import numpy as np
from math import exp, sqrt
from idlib import law, mean_abs, SQ2E
from flipbound import stoploss_bound

A = sqrt(2.0)
rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 1)


def flip_bound(K, theta):
    S = [(x, w) for x, w in K if x >= theta]
    R = [(x, w) for x, w in K if x < theta]
    if not S:
        return np.inf
    lam = sum(w / x ** 2 for x, w in S)
    m = sum(w / x for x, w in S)
    if theta <= m:
        return np.inf
    rp = sum(w for x, w in R if x > 0)
    rn = sum(w for x, w in R if x <= 0)
    tot = 2 * m * exp(-lam)
    if rp + rn == 0:
        return tot
    tot += 2 * exp(-lam) * stoploss_bound(m, theta, rp, rn, grid=30)
    vals, probs, _ = law(S)
    pos = vals > 0
    v, p = vals[pos], probs[pos]
    # merge atoms of Y on a coarse grid from below (stop-loss bound is decreasing in y)
    order = np.argsort(v)
    v, p = v[order], p[order]
    grid = np.unique(np.concatenate([np.linspace(0, v.max() + 1e-9, 60)]))
    idx = np.searchsorted(grid, v, side="right") - 1
    for g, pp in zip(grid[idx], p):
        pass
    acc = {}
    for gi, pp in zip(idx, p):
        acc[gi] = acc.get(gi, 0.0) + pp
    for gi, pp in acc.items():
        y = max(grid[gi], 1e-6)
        tot += 2 * pp * stoploss_bound(y, A, rn, rp, grid=30)
    return tot


def random_K():
    k = rng.integers(1, 5)
    xs = rng.uniform(-A, A, size=k)
    ws = rng.dirichlet(np.ones(k + 1))
    K = [(float(x), float(w)) for x, w in zip(xs, ws[:k])]
    if rng.random() < 0.5:
        K.append((0.0, float(ws[k])))
    else:
        K[0] = (K[0][0], K[0][1] + float(ws[k]))
    tot = sum(w for _, w in K)
    return [(x, w / tot) for x, w in K]


ntrial = int(sys.argv[2]) if len(sys.argv) > 2 else 300
stats = []
for t in range(ntrial):
    K = random_K()
    if rng.random() < 0.5:
        K = [(-x, w) for x, w in K]
    # orient so that the larger positive OR part is on the positive side
    true = mean_abs(K)
    best = np.inf
    for sgn in (1, -1):
        KK = [(sgn * x, w) for x, w in K]
        cands = sorted(set(x for x, _ in KK if x > 0))
        for th in cands:
            for eps in (0.0,):
                best = min(best, flip_bound(KK, th - eps))
    stats.append((true, best, K))
cert = sum(1 for tr, b, _ in stats if b <= SQ2E)
print(f"certified by flip bound: {cert}/{ntrial}")
hi = sorted(stats, key=lambda s: -s[0])[:10]
print("largest true values: (true, best bound, K)")
for tr, b, K in hi:
    print(f"  {tr:.4f} {b:.4f} " + " ".join(f"({x:+.3f},{w:.3f})" for x, w in K))
unc = [s for s in stats if s[1] > SQ2E]
unc.sort(key=lambda s: -s[0])
print("uncertified with largest true value:")
for tr, b, K in unc[:15]:
    print(f"  {tr:.4f} {b if b < 9 else float('inf'):.4f} " + " ".join(f"({x:+.3f},{w:.3f})" for x, w in K))
