"""Re-evaluation of the best plus_scan law with a checked LP (float evidence, not proof).

plus_scan.py (heavy_scan.exact_common) does not check the measure HiGHS returns. Its best value over all runs in
outputs/far_extra/plus_scan/ is B = 0.83897 (D16_v03_s1.txt and D16_v04_s1.txt), printed with 4 decimals as
a+ 0.2007, b+ 0.3003, rest 0.0356 d_-0.2831 + 0.1609 d_+0.8500 + 0.0035 d_-1.5400 (mass mu0 = 0.2, no Gaussian
part). This recomputes J at those rounded values with plus_lp_tol.lp_max and reports the row violation of the
returned measure. The rest's atom at 0.8500 is put at 0.8499999 (the rest lives on [-A, tau)).
"""
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import plus_lp_tol as PT
from edge_split_feas import cumulants, moments_from_cumulants
from heavy_box_lp import shift_law
from heavy_scan import M, Q
from plus_check_laws import A, D, TAU, stand_in_support

AP, BP = 0.2007, 0.3003
REST = [(-0.2831, 0.0356), (0.8499999, 0.1609), (-1.54, 0.0035)]
MU0 = 0.2


def main():
    print(f"start {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC")
    g = max(MU0 - sum(w for _, w in REST), 0.0)
    print(f"a+ {AP}, b+ {BP}: Q+ {Q(AP, BP):.6f}, M+ {M(AP, BP):.6f}; rest {REST}, Gaussian part {g:.1e}")
    c, p = shift_law([(TAU, AP), (A, BP)])
    mom = moments_from_cumulants(cumulants(REST, g, D), D)
    sc, z, Am, b = PT.lp_data(c, mom, stand_in_support(REST, g))
    for t in (1e-9, 1e-7):
        J, st, viol = PT.lp_max(np.abs(c[None, :] + sc * z[:, None]) @ p, Am, b, t)
        print(f"t = {t:.0e}: J = {J:.5f} (HiGHS status {st}, row violation of its measure {viol:.1e})")


if __name__ == "__main__":
    main()
