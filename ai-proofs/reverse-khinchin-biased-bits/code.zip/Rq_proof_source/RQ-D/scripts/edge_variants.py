"""Float feasibility (evidence only, never proof): which chord atoms must be conditioned on exactly?

After the chord reduction (Lemma E, tau = 0.85, A = 1.54) the edge of K is four lattice atoms
+-tau (rates a+, a-) and +-A (rates b+, b-). Every atom that is conditioned on adds one dimension to the box
cover; every atom left in the residual is bounded by the degree-D moment LP at each shift instead.
Variants (columns):
    all4  condition on +tau, +A, -tau, -A   (residual support (-tau, tau))
    pA_m  condition on +tau, +A, -A          (-tau atom into the residual; support [-tau, tau))
    AA    condition on +A, -A only           (+-tau atoms into the residual; support [-tau, tau])
    plus  condition on +tau, +A only         (negative chord atoms into the residual; support [-A, tau))
    Aonly condition on +A only
Usage: python3 edge_variants.py D [i]     (i = index into HEAVY; all laws if omitted)
"""
import itertools
import math
import sys

import numpy as np

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from idlib import mean_abs_small
from edge_split_feas import (FALLBACKS, chord_law, cumulants, moments_from_cumulants, pois, resid_support,
                             sup_abs_shift)

TAU, A = 0.85, 1.54


def split_sel(atoms, wG, D, cond, ptol=1e-10):
    edge = [(x, w) for x, w in atoms if cond(x) and w > 0]
    rest = [(x, w) for x, w in atoms if not cond(x) and w > 0]
    no_resid = not rest and wG == 0
    mom = None if no_resid else moments_from_cumulants(cumulants(rest, wG, D), D)
    extra = None if no_resid else resid_support(rest, wG)
    lams = [w / x ** 2 for x, w in edge]
    nmaxs = [int(l + 8 * math.sqrt(l) + 8) for l in lams]
    ps = [pois(l, nm) for l, nm in zip(lams, nmaxs)]
    comp = -sum(x * l for (x, _), l in zip(edge, lams))
    cache, tot = {}, 0.0
    for ns in itertools.product(*[range(nm + 1) for nm in nmaxs]):
        pr = 1.0
        for p, n in zip(ps, ns):
            pr *= p[n]
        if pr < ptol:
            continue
        c = comp + sum(x * n for (x, _), n in zip(edge, ns))
        key = round(c, 12)
        if key not in cache:
            v = abs(c) if no_resid else sup_abs_shift(c, mom, D, extra=extra)
            if not np.isfinite(v):
                v = math.sqrt(c * c + mom[2])
                FALLBACKS.append((c, pr))
            cache[key] = v
        tot += pr * cache[key]
    return tot


VARIANTS = [
    ("all4", lambda x: abs(abs(x) - TAU) < 1e-12 or abs(abs(x) - A) < 1e-12),
    ("pA_m", lambda x: abs(x - TAU) < 1e-12 or abs(abs(x) - A) < 1e-12),
    ("AA", lambda x: abs(abs(x) - A) < 1e-12),
    ("plus", lambda x: abs(x - TAU) < 1e-12 or abs(x - A) < 1e-12),
    ("Aonly", lambda x: abs(x - A) < 1e-12),
]

HEAVY = [
    ("K* (F maximiser)", [(1.2978, 0.8), (-1.1008, 0.095), (0.8499, 0.105)], 0.0),
    ("0.79 d1.30 + 0.11 d-1.54 + 0.10 d0.84", [(1.30, 0.79), (-1.54, 0.11), (0.84, 0.10)], 0.0),
    ("0.79 d1.414 + 0.21 G", [(1.414, 0.79)], 0.21),
    ("0.6 spread [1.2,1.54] + 0.4 G", [(1.2, 0.15), (1.31, 0.15), (1.43, 0.15), (1.54, 0.15)], 0.4),
    ("0.5 d1.2 + 0.5 G", [(1.2, 0.5)], 0.5),
    ("0.5 d1.0 + 0.3 d-1.0 + 0.2 G", [(1.0, 0.5), (-1.0, 0.3)], 0.2),
    ("0.55 d1.1 + 0.45 d0.6", [(1.1, 0.55), (0.6, 0.45)], 0.0),
    ("0.5 d0.85 + 0.5 d0.8499", [(0.85, 0.5), (0.8499, 0.5)], 0.0),
    ("0.5 d1.3 + 0.5 d-0.84", [(1.3, 0.5), (-0.84, 0.5)], 0.0),
    ("0.6 d1.3 + 0.2 d-1.3 + 0.2 d0.5", [(1.3, 0.6), (-1.3, 0.2), (0.5, 0.2)], 0.0),
    ("0.5 d1.25 + 0.3 d-0.84 + 0.2 d0.84", [(1.25, 0.5), (-0.84, 0.3), (0.84, 0.2)], 0.0),
    ("0.7 d1.25 + 0.1 d-1.54 + 0.2 G", [(1.25, 0.7), (-1.54, 0.1)], 0.2),
]

if __name__ == "__main__":
    D = int(sys.argv[1]) if len(sys.argv) > 1 else 16
    laws = HEAVY if len(sys.argv) < 3 else [HEAVY[int(sys.argv[2])]]
    names = [v[0] for v in VARIANTS]
    if len(sys.argv) < 3:
        print(f"D = {D}, tau = {TAU}, A = {A}; chord law, then condition on the listed atoms; NPTS from "
              f"EDGE_NPTS", flush=True)
        print(f"{'law':40s} {'true':>8s} " + " ".join(f"{n:>8s}" for n in names), flush=True)
    for name, atoms, wG in laws:
        t = mean_abs_small(atoms + [(0.0, wG)])
        ch = chord_law(atoms, TAU, A)
        vals, fbs = [], []
        for _, cond in VARIANTS:
            FALLBACKS.clear()
            vals.append(split_sel(ch, wG, D, cond))
            fbs.append(sum(p for _, p in FALLBACKS))
        fb = "" if max(fbs) == 0 else "  fallback prob " + " ".join(f"{p:.0e}" for p in fbs)
        print(f"{name:40s} {t:8.5f} " + " ".join(f"{v:8.5f}" for v in vals) + fb, flush=True)
