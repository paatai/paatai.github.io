"""Exploration (float, evidence only): endpoint property for specific pairs of a positive alpha.

For alpha >= 0 sorted decreasingly, test the pair (two smallest), (two largest), (largest, smallest).
Also test near-optimal alpha (perturbations of equal-coefficient vectors).
"""
import sys
import numpy as np
from core import dist, AbsShift, mean_abs, tau, Mconj, kstar
from explore_pairs import pair_profile

rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 2)
thetas = np.linspace(0, np.pi / 4, 401)


def excess(alpha, i, j, q):
    g = pair_profile(alpha, i, j, q, thetas)
    return g.max() - max(g[0], g[-1])


for q in [0.05, 0.1, 0.15, 0.2, 0.3]:
    k = kstar(q)
    for n in [5, 8, 10]:
        res = {"small": 0.0, "large": 0.0, "extreme": 0.0}
        cnt = {"small": 0, "large": 0, "extreme": 0}
        T = 120
        for t in range(T):
            if t % 2 == 0:
                alpha = rng.random(n) ** rng.uniform(0.3, 3)
            else:
                # near-equal on m coords plus small noise elsewhere
                m = min(n, max(2, k + rng.integers(-2, 3)))
                alpha = np.zeros(n)
                alpha[:m] = 1 + 0.3 * rng.normal(size=m)
                alpha[m:] = 0.3 * rng.random(n - m)
                alpha = np.abs(alpha)
            alpha = np.sort(alpha)[::-1]
            alpha /= np.linalg.norm(alpha)
            for name, (i, j) in {"small": (n - 2, n - 1), "large": (0, 1), "extreme": (0, n - 1)}.items():
                e = excess(alpha, i, j, q)
                if e > 1e-12:
                    cnt[name] += 1
                    res[name] = max(res[name], e)
        print(f"q={q} k*={k} n={n}: violations small {cnt['small']}/{T} (max {res['small']:.2e}), "
              f"large {cnt['large']}/{T} (max {res['large']:.2e}), extreme {cnt['extreme']}/{T} (max {res['extreme']:.2e})")
        sys.stdout.flush()
