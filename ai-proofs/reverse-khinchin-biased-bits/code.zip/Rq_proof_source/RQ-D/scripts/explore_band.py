"""Landscape of E|Z_K| for two-atom K = (1-w) delta_x + w delta_y near the Dirac curve (float)."""
import sys
import numpy as np
from idlib import mean_abs, SQ2E

xs = [1.0, 1.1, 1.2, 1.3, 1.35, 1.4, 1.414213562, 1.45, 1.5, 1.6]
ys = [-1.5, -1.2, -1.0, -0.8, -0.6, -0.4, -0.2, 0.0, 0.2, 0.4, 0.6, 0.8, 0.9, 1.0, 1.2, 1.3, 1.5, 1.8, 2.2]
ws = [0.02, 0.05, 0.1, 0.2, 0.3]

worst = []
for x in xs:
    base = mean_abs([(x, 1.0)])
    print(f"x={x:.4f}: Dirac value {base:.6f} (margin {SQ2E - base:.5f})")
    for w in ws:
        row = []
        for y in ys:
            K = [(x, 1 - w), (y, w)]
            v = mean_abs(K)
            m1 = (1 - w) * x + w * y
            m2 = (1 - w) * x * x + w * y * y
            row.append(SQ2E - v)
            worst.append((SQ2E - v, x, y, w, m1, m2 - m1 * m1))
        print(f"  w={w:.2f}: min margin over y {min(row):+.5f} at y={ys[int(np.argmin(row))]:+.2f}")
worst.sort()
print("smallest margins (margin, x, y, w, m1, Var_K):")
for t in worst[:15]:
    print("  " + " ".join(f"{u:+.5f}" for u in t))
