"""Soundness test of the band-lemma bound: F(K) >= E|Z_K| on random K in the band (float).

For random K on [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10 (several atoms, optional Gaussian part), compute
the exact E|Z_K| (idlib) and the bound F of verify_band.py evaluated at the exact (Lam, m, a, b) of K
(costs with the same majorants, chord in the jump law). The bound must never be below the truth.
"""
import math
import numpy as np
from idlib import mean_abs, SQ2E
from verify_band import f_lattice, HGRID

S2 = math.sqrt(2)
rng = np.random.default_rng(7)


def costs_float(a, b, m):
    sa, sb, r2 = math.sqrt(a), math.sqrt(b), a + b
    cB = min(np.min(f_lattice(1.0, a, sb, m - HGRID) / (2 * HGRID)), math.sqrt(m * m + r2) - m)

    def g(y, hh):
        return f_lattice(S2, b / 2, sa, np.array([y - hh]))[0] / (2 * hh)

    def cC(y):
        return min(np.min(f_lattice(S2, b / 2, sa, y - HGRID) / (2 * HGRID)), math.sqrt(y * y + r2) - y)
    return cB, g, cC


def bound(K):
    S = [(x, w) for x, w in K if x >= 1]
    R = [(x, w) for x, w in K if x < 1]
    V = sum(w for _, w in S)
    a = sum(w for x, w in R if x > 0)
    b = sum(w for x, w in R if x <= 0)
    L = sum(w / x ** 2 for x, w in S)
    m = sum(w / x for x, w in S)
    mu1 = m / L
    cB, g, cC = costs_float(a, b, m)
    # chord: best common h, and CS
    best = np.inf
    for hh in HGRID:
        best = min(best, ((S2 - mu1) * g(1 - m, hh) + (mu1 - 1) * g(S2 - m, hh)) / (S2 - 1))
    r2 = a + b
    csg = lambda y: math.sqrt(y * y + r2) - y
    best = min(best, ((S2 - mu1) * csg(1 - m) + (mu1 - 1) * csg(S2 - m)) / (S2 - 1))
    P2 = 1 - math.exp(-L) * (1 + L)
    return 2 * m * math.exp(-L) + math.exp(-L) * cB + L * math.exp(-L) * best + P2 * cC(2 - m)


worst_gap, worst_margin = np.inf, np.inf
for trial in range(400):
    r2 = rng.uniform(0, 0.1)
    nS, nR = rng.integers(1, 4), rng.integers(1, 4)
    xs = rng.uniform(1, S2, nS)
    if rng.random() < 0.3:
        xs[0] = S2
    ws = rng.dirichlet(np.ones(nS)) * (1 - r2)
    xr = rng.uniform(-S2, 1, nR)
    if rng.random() < 0.3:
        xr[0] = 0.0
    if rng.random() < 0.3:
        xr[-1] = 0.999
    wr = rng.dirichlet(np.ones(nR)) * r2
    K = [(float(x), float(w)) for x, w in zip(xs, ws)] + [(float(x), float(w)) for x, w in zip(xr, wr)]
    true = mean_abs(K)
    F = bound(K)
    worst_gap = min(worst_gap, F - true)
    worst_margin = min(worst_margin, SQ2E - F)
    if F < true - 1e-9:
        print("UNSOUND", K, F, true)
print(f"min (bound - true) = {worst_gap:+.6f} (must be >= 0); min (sqrt(2/e) - bound) = {worst_margin:+.6f}")
