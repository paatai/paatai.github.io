"""Band-lemma bound, version 2 (float exploration; the rigorous version is verify_band.py).

Setting: K probability Kolmogorov measure on [-A, A], A = sqrt2; K_S = K|[theta, A] (mass V_S = 1 - rho^2),
K_R = K|[-A, theta) with mass rp on (0, theta) and rn on [-A, 0]. Y = Z_{K_S}, W = Z_{K_R}.
  E|Z| = E g(Y),  g(y) = E|y + W| <= |y| + cost(y),
  cost(y) = min( 2 Phi(y), sqrt(y^2 + rho^2) - |y| ),
  Phi(-m) <= inf_h E psi_{m,h}(W_B*),  W_B* = theta (N - rp/theta^2) + sqrt(rn) G,
  Phi(y)  <= inf_h E psi_{y,h}(W_C*),  W_C* = A (N' - rn/A^2) + sqrt(rp) G'   (y > 0),
  psi_{t,h}(w) = (w - t + h)_+^2 / (4h)  (>= (w - t)_+, psi'' nondecreasing).
So E|Z| <= 2 m e^{-L} + e^{-L} costB(m) + L e^{-L} E costC(J - m) + P(N_S >= 2) costC(2 theta - m),
with the law of J (jump law of K_S) worst case by an LP with E J = m/L, E J^2 = V_S/L, J in [theta, A].
"""
import sys
import numpy as np
from math import exp, sqrt
from scipy.stats import norm
from scipy.optimize import linprog
from idlib import pois_pmf, SQ2E

A = sqrt(2.0)
HGRID = np.geomspace(1e-3, 3.0, 70)


def lattice(jump, mass):
    if mass <= 0:
        return np.zeros(1), np.ones(1)
    lam = mass / jump ** 2
    nmax = int(lam + 12 * sqrt(lam) + 30)
    p = pois_pmf(lam, nmax)
    n = np.arange(nmax + 1)
    return jump * (n - lam), p


def esq_plus_vec(vals, probs, sig, c):
    """E (V + sig G - c)_+^2 for each c in array c."""
    d = vals[:, None] - c[None, :]
    if sig == 0:
        return probs @ np.where(d > 0, d * d, 0.0)
    z = d / sig
    return probs @ ((d * d + sig * sig) * norm.cdf(z) + d * sig * norm.pdf(z))


def phi_tail(t_arr, vals, probs, sig):
    """inf_h E psi_{t,h}(V + sig G) for each t."""
    out = np.empty_like(t_arr)
    for i, t in enumerate(t_arr):
        c = t - HGRID
        out[i] = np.min(esq_plus_vec(vals, probs, sig, c) / (4 * HGRID))
    return out


def costs(theta, rp, rn, m_arr, y_arr):
    r2 = rp + rn
    vb, pb = lattice(theta, rp)
    vc, pc = lattice(A, rn)
    cb = np.minimum(2 * phi_tail(m_arr, vb, pb, sqrt(rn)), np.sqrt(m_arr ** 2 + r2) - m_arr)
    cc = np.minimum(2 * phi_tail(y_arr, vc, pc, sqrt(rp)), np.sqrt(y_arr ** 2 + r2) - y_arr)
    return cb, cc


def jlaw_lp(jgrid, cvals, mu1, mu2):
    """max sum p c s.t. p >= 0, sum p = 1, sum p j = mu1, sum p j^2 = mu2."""
    Aeq = np.vstack([np.ones_like(jgrid), jgrid, jgrid ** 2])
    res = linprog(-cvals, A_eq=Aeq, b_eq=[1, mu1, mu2], bounds=(0, None), method="highs")
    if res.status != 0:
        return None
    return -res.fun


def scan(theta, r2, fracs, nL=36, nm=24, nj=40):
    vs = 1 - r2
    jgrid = np.linspace(theta, A, nj)
    worst = (np.inf, None)
    ygrid = np.linspace(1e-4, 2 * A, 400)
    for fr in fracs:
        rp, rn = fr * r2, (1 - fr) * r2
        Ls = np.linspace(vs / A ** 2, vs / theta ** 2, nL)
        mgrid = np.linspace(0.05, min(vs / theta, theta) - 1e-9, 300)
        cb_tab, cc_tab = costs(theta, rp, rn, mgrid, ygrid)
        for L in Ls:
            mlo = max(theta * L, vs / A)
            mhi = min(A * L, vs / theta, sqrt(L * vs), theta - 1e-9)
            if mhi < mlo:
                continue
            for m in np.linspace(mlo, mhi, nm):
                cb = np.interp(m, mgrid, cb_tab)
                cvals = np.interp(jgrid - m, ygrid, cc_tab)
                lp = jlaw_lp(jgrid, cvals, m / L, vs / L)
                if lp is None:
                    continue
                c2 = np.interp(2 * theta - m, ygrid, cc_tab)
                f = 2 * m * exp(-L) + exp(-L) * cb + L * exp(-L) * lp + (1 - exp(-L) * (1 + L)) * c2
                mar = SQ2E - f
                if mar < worst[0]:
                    worst = (mar, (fr, L, m, 2 * m * exp(-L), exp(-L) * cb, L * exp(-L) * lp))
    return worst


if __name__ == "__main__":
    theta = float(sys.argv[1]) if len(sys.argv) > 1 else 1.0
    for r2 in [0.005, 0.02, 0.05, 0.08, 0.1, 0.12, 0.15, 0.2]:
        w = scan(theta, r2, np.linspace(0, 1, 6))
        print(f"theta={theta} rho^2={r2}: worst margin {w[0]:+.5f}  margin/rho^2 {w[0]/r2:+.4f}  at "
              f"(frac_pos, Lambda, m, A, B, C1) = " + ", ".join(f"{v:.4f}" for v in w[1]))
        sys.stdout.flush()
