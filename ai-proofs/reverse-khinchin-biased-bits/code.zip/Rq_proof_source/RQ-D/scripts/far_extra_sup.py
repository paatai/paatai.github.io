"""Float search (evidence only, never proof): sup E|Z_K| over the far region of the agreed split,
F = {K([0.85, A]) < 0.8, K([-A, -0.85]) < 0.8}, A = 1.54, with and without the extra bands
B(0.80, 0.15) = {K([0.80, A]) >= 0.85} and B(0.75, 0.10) = {K([0.75, A]) >= 0.90} (and mirrors).

K = up to three atoms in [-A, A] plus a Gaussian part, total mass 1. Random starts + Nelder-Mead on a
penalised objective; reported values are recomputed exactly for feasible laws (lower bounds for the sup).

Usage: python3 far_extra_sup.py REGION NSTARTS SEED   (REGION = F or Fx)
"""
import sys
import numpy as np
from scipy.optimize import minimize

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from idlib import mean_abs_small

A = 1.54
C5 = 0.85510045547
BANDS_F = [(0.85, 0.8)]
BANDS_FX = [(0.85, 0.8), (0.80, 0.85), (0.75, 0.90)]


def unpack(u):
    x = A * np.tanh(u[:3])
    e = np.exp(u[3:7] - np.max(u[3:7]))
    w = e / e.sum()
    return x, w


def violation(x, w, bands):
    v = 0.0
    for th, vmax in bands:
        vp = w[:3][x >= th].sum()
        vn = w[:3][x <= -th].sum()
        v += max(0.0, vp - vmax + 1e-12) + max(0.0, vn - vmax + 1e-12)
    return v


def K_of(x, w):
    K = [(float(xi), float(wi)) for xi, wi in zip(x, w[:3]) if abs(xi) > 1e-9 and wi > 1e-12]
    K.append((0.0, float(w[3])))
    return K


def obj(u, bands):
    x, w = unpack(u)
    if np.any(np.abs(x) < 0.05):
        return 1.0
    val = mean_abs_small(K_of(x, w))
    return -val + 20.0 * violation(x, w, bands)


def main():
    region = sys.argv[1]
    nst = int(sys.argv[2])
    seed = int(sys.argv[3])
    bands = BANDS_F if region == "F" else BANDS_FX
    rng = np.random.default_rng(seed)
    best = (-1, None)
    for s in range(nst):
        u0 = np.concatenate([rng.normal(0, 1.2, 3), rng.normal(0, 1.5, 4)])
        r = minimize(obj, u0, args=(bands,), method="Nelder-Mead",
                     options={"maxiter": 1500, "xatol": 1e-6, "fatol": 1e-9})
        x, w = unpack(r.x)
        if violation(x, w, bands) > 0 or np.any(np.abs(x) < 0.05):
            continue
        val = mean_abs_small(K_of(x, w))
        if val > best[0]:
            best = (val, (x.copy(), w.copy()))
            atoms = ", ".join(f"{wi:.4f} d_{xi:+.4f}" for xi, wi in zip(x, w[:3]))
            print(f"{region} seed {seed} start {s}: E|Z| = {val:.6f}  K = {atoms} + {w[3]:.4f} G", flush=True)
    print(f"{region} seed {seed} BEST {best[0]:.6f}", flush=True)


if __name__ == "__main__":
    main()
