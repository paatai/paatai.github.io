"""Controls for verify_bandstar.py (non-vacuity of the certificate; not part of the proof).

(1) The four (a, b) squares at the origin used by the slope check, at the true target and with the target lowered
    by 0.0005 (BANDSTAR_TGT_SHIFT; test (T1) is then disabled, since it only gives F <= g(Lambda)).
(2) The squares of the finest level of the certificate run (read from outputs/verify_bandstar_squares.jsonl), with
    the target lowered by 0.001, without refinement.
A square "fails" if some (Lambda, m) box cannot be certified down to the minimal box size.
Usage: python3 scripts/verify_bandstar_controls.py [nproc]
"""
import json
import sys
from multiprocessing import Pool

from flint import arb

import verify_bandstar as vb

ORIGIN = [(0, 1 / 256, 0, 1 / 256), (0, 1 / 128, 0, 1 / 128), (1 / 128, 1 / 64, 0, 1 / 128), (0, 1 / 128, 1 / 128, 1 / 64)]


def run_one(args):
    box, shift = args
    vb.TGT_SHIFT = arb(shift)
    r = vb.verify_ab_box(box, stop_on_fail=True)
    return dict(box=box, shift=shift, ok=not r["nfail"], first_fail=r["fails"][:1], nbox=r["nbox"])


def main():
    nproc = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    jobs = [(b, s) for b in ORIGIN for s in ("0", "0.0005")]
    finest, side = [], None
    with open("outputs/verify_bandstar_squares.jsonl") as f:
        rows = [json.loads(line) for line in f]
    side = min(r["box"][1] - r["box"][0] for r in rows)
    finest = [tuple(r["box"]) for r in rows if r["box"][1] - r["box"][0] == side and r["ok"]]
    jobs += [(b, "0.001") for b in finest]
    with Pool(nproc) as pool:
        res = pool.map(run_one, jobs, chunksize=1)
    print("(1) origin squares (slope check), target max(g, C5) - shift:")
    for r in res[: 2 * len(ORIGIN)]:
        print(f"  square {r['box']}  shift {r['shift']}:  {'certified' if r['ok'] else 'NOT certified'}"
              f"  (boxes {r['nbox']}{', first failing box ' + str(r['first_fail'][0]) if r['first_fail'] else ''})")
    rest = res[2 * len(ORIGIN):]
    nf = sum(not r["ok"] for r in rest)
    print(f"(2) finest level of the certificate (side {side}): {len(rest)} squares certified at shift 0;"
          f" with shift 0.001 and no refinement, {nf} of {len(rest)} are NOT certified.")


if __name__ == "__main__":
    main()
