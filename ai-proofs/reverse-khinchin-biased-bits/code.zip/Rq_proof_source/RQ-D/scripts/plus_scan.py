"""Float scan (evidence only, never proof): sup over F_heavy of the 'plus' design with EXACT moments of the rest.

'plus' design (tau = 0.85, A = 1.54; reflection V+ >= V-, F_heavy: V+ >= v):
  Lemma E on the positive edge only: chord rates (a+, b+) at (tau, A); Q+ = (a+ tau + b+ A)^2/(a+ + b+) is the
  least edge mass with those rates, M+ = a+ tau^2 + b+ A^2 the largest; F_heavy needs V+ in [max(Q+, v), M+],
  V+ < 0.8. Everything else (negative edge and residual) is the rest W: a measure on [-A, tau) of mass
  1 - V+ <= 1 - max(Q+, v) (worst case: equality; E|.| is nondecreasing in the rest's mass).
  Bound: B = sup{E h(Y): Y has the moments of Z_W up to degree D}, h(r) = E|tau (N_a - a+) + A (N_b - b+) + r|.
Rest W in the scan: three atoms in [-A, tau) plus a Gaussian part.
Usage: python3 plus_scan.py D seed nstarts [v]
"""
import sys

import numpy as np
from scipy.optimize import minimize

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from edge_split_feas import cumulants, moments_from_cumulants, resid_support
from heavy_box_lp import A, C5, TAU, shift_law
import heavy_scan
from heavy_scan import M, Q, exact_common

heavy_scan.NR = int(__import__('os').environ.get('PLUS_NR', '4001'))


def decode(u, v):
    s = 1 / (1 + np.exp(-np.clip(np.asarray(u), -40, 40)))
    ap, bp = 1.2 * s[0], 0.36 * s[1]
    qp = Q(ap, bp)
    if qp >= 0.8 or M(ap, bp) < v:
        return None
    mu0 = 1 - max(qp, v)
    ys = [-A + (TAU + A) * s[2 + i] for i in range(3)]
    f1 = s[5]
    f2 = (1 - f1) * s[6]
    f3 = (1 - f1 - f2) * s[7]
    g = 1 - f1 - f2 - f3
    rest = [(y, f * mu0) for y, f in zip(ys, (f1, f2, f3))]
    return ap, bp, mu0, rest, g * mu0


def bound(u, D, v, extra_pts=True):
    dec = decode(u, v)
    if dec is None:
        return 0.0, None
    ap, bp, mu0, rest, wG = dec
    cond = [(x, l) for x, l in [(TAU, ap), (A, bp)] if l > 1e-12]
    c, p = shift_law(cond)
    mom = moments_from_cumulants(cumulants(rest, wG, D), D)
    ex = resid_support(rest, wG) if extra_pts else None
    val = exact_common(c, p, mom, D, extra=ex)
    if not np.isfinite(val):
        return 0.0, dec
    return val, dec


def fmt(dec):
    ap, bp, mu0, rest, wG = dec
    r = " + ".join(f"{w:.4f} d_{x:+.4f}" for x, w in rest if w > 1e-5)
    return f"a+ {ap:.4f} b+ {bp:.4f} (Q+ {Q(ap, bp):.4f} M+ {M(ap, bp):.4f})  mu0 {mu0:.4f} = {r} + {wG:.4f} G"


if __name__ == "__main__":
    D, seed, nst = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    v = float(sys.argv[4]) if len(sys.argv) > 4 else 0.5
    rng = np.random.default_rng(seed)
    best = (0.0, None)
    for st in range(nst):
        while True:
            u0 = rng.normal(0, 1.5, 8)
            if decode(u0, v) is not None:
                break
        f = lambda u: -bound(u, D, v, extra_pts=False)[0]
        res = minimize(f, u0, method="Nelder-Mead", options=dict(maxiter=300, xatol=1e-3, fatol=1e-6))
        val, dec = bound(res.x, D, v)
        print(f"D={D} seed {seed} start {st}: B = {val:.5f}  {fmt(dec)}", flush=True)
        if val > best[0]:
            best = (val, dec)
    print(f"BEST D={D} seed {seed}: B = {best[0]:.5f}  {fmt(best[1])}  (C5 = {C5})", flush=True)
