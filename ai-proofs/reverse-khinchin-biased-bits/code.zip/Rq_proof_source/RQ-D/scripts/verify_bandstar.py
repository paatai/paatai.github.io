"""Certified verification of the ID* band lemma (Theorem B* of MAIN_RESULT.tex).

Claim. theta = 0.85, A = 1.54, C5 = g(2 ln(5/4)), g(l) = 2 sqrt(l) e^{-l}. If K is a finitely supported probability
measure on [-A, A] with K([theta, A]) >= 4/5 and Lambda = int_{[theta, A]} x^-2 dK, then
E|Z_K| <= max(g(Lambda), C5).

Reduction (MAIN_RESULT.tex, Proposition 9, second form). K_S = K|[theta, A], V = K_S(R), m = int x^-1 dK_S,
mu1 = m/Lambda, sigma^2 = (Lambda V - m^2)/Lambda^2; a = K((0, theta)), b = K([-A, 0]), rho^2 = a + b = 1 - V <= 1/5;
W = Z_{K - K_S}, phi(y) = 2E(-W - y)_+ (convex, nonincreasing), J ~ jump law of K_S (on [theta, A]). Then
    E|Z_K| <= F = 2 m e^-Lambda + e^-Lambda cB + Lambda e^-Lambda O' + P2(Lambda) cC,     P2(L) = 1 - e^-L (1 + L),
    cB >= 2E(W - m)_+,  cC >= 2E(-W - (2 theta - m))_+,  O' >= E phi(J - m).
Cost bounds (Lemma 6): 2E(W - t)_+ <= chiB_h(t); phi(y) <= chiC_h(y); both <= sqrt(t^2 + rho^2) - t;
phi(y) = -2y + 2E(W + y)_+ <= -2y + chiB_h(-y).  Here
    chiB_h(t) = E(W_B - t + h)_+^2/(2h), W_B = theta (N_{a/theta^2} - a/theta^2) + sqrt(b) G,
    chiC_h(y) = E(W_C - y + h)_+^2/(2h), W_C = A (N_{b/A^2} - b/A^2) + sqrt(a) G.
Options for O' (MAIN_RESULT.tex, Lemma lem:onejump and (O1)-(O5)):
    (O1) chord of phi: ((A - mu1) phi(theta - m) + (mu1 - theta) phi(A - m)) / (A - theta);
    (O3)/(O4) two-point (c), psi = chiC_h (any m) or psi = sqrt(y^2 + rho^2) - y (theta - m >= 0), psi'' nonincreasing:
        E psi(J - m) <= (1 - w) psi(theta - m) + w psi(theta - m + u), d = mu1 - theta, w = d^2/(sigma^2 + d^2),
        u = d + sigma^2/d (box version: sigma^2 replaced by an upper bound s2);
    (O2) Taylor (b), Gamma(y) = -2y + chiB_h(-y) >= phi(y), Gamma'' <= 1/h:
        O' <= Gamma(y0) + sigma^2/(2h) = -2 y0 + chiB_h(-y0) + sigma^2/(2h), y0 = mu1 - m;
    (O5) two-point with h > theta - m and the exact sigma^2: O' = (1 - w) kappa + (1 - w) rho^2/(2h) + chiC_h(mu1 - m),
        kappa = (h - (theta - m))_+^2/(2h); the constant (1 - w) kappa is absorbed by the main term (lem:absorb):
        2 m e^-Lambda + Lambda e^-Lambda kappa (1 - w) <= sqrt(V) g(Lambda) if kappa <= D^2 sqrt(Lambda/V), D <= d.
Target: max(g(Lambda), C5).

Covering. The triangle {a, b >= 0, a + b <= 1/5} is covered by squares [a1, a2] x [b1, b2] (side 1/128, squares not
certified are split into four, down to side 1/8192). On a square, V is in [1 - min(a2 + b2, 1/5), 1 - (a1 + b1)], and
the costs are taken at the corner (a2, b2), clipped to a + b <= 1/5 and rounded up to a dyadic (costs are
nondecreasing in a and in b). For every square the (Lambda, m) range allowed by (F1)-(F5) is covered by boxes
(Lambda strips of 1/64, m on the grid k/4096), bisected until each box is infeasible or certified by
  check_direct: F < max(g, C5) on the box with the corner costs and one of (O1)-(O4); or, if a2 + b2 <= 1/50,
  check_slope: every cost is <= a alpha + b beta on a + b <= r (r >= the piece's largest rho^2), so that
    F <= sqrt(V) g(Lambda) + rho^2 Mx <= (1 - rho^2/2) g(Lambda) + rho^2 Mx, Mx = max of the a- and b-coefficients,
    with tests (T1) Mx <= g/2, (T2) the same with the box range of g, (T3) a bound of the main term plus rho^2 Mx.

All final inequalities are checked in arb ball arithmetic (python-flint); floats only choose h and the subdivision.
Environment variable BANDSTAR_TGT_SHIFT (default 0, controls only) lowers the target by the given amount.
"""
import os
import json
import math
import sys
import time
from multiprocessing import Pool

import numpy as np
from flint import arb, ctx
from scipy.stats import norm

ctx.prec = 80

THF, AF = 0.85, 1.54
TH = arb(85) / 100
AA = arb(154) / 100
TH2, AA2 = TH * TH, AA * AA
RHO0F = 0.2
RHO0 = arb(1) / 5
RLIN = arb(1) / 50
HALF = arb(1) / 2
SQ2 = arb(2).sqrt()
SQ2PI = (2 * arb.pi()).sqrt()
C5 = 2 * (2 * (arb(5) / 4).log()).sqrt() * arb(16) / 25
C5LO = C5.lower()
GMAX = 2 * HALF.sqrt() * (-HALF).exp()
TGT_SHIFT = arb(os.environ.get("BANDSTAR_TGT_SHIFT", "0"))
NTERMS = 14
MDEN = 4096
KLO = int(0.8 / AF * MDEN) - 2
KHI = int(1.0 / THF * MDEN) + 2
KYMIN = -(MDEN * 5) // 16
KTMIN, KTMAX = -(MDEN * 75) // 64, (MDEN * 15) // 32
HGRID = np.geomspace(0.005, 3.0, 80)
HMV = np.array([0.005 * 2 ** (i / 4) for i in range(37)])
HLIN = np.array([0.01 * 1.25 ** i for i in range(26)])

# ---------------------------------------------------------------- float kernels (parameter choice only)


def f_lattice(J, lam, s, c):
    c = np.atleast_1d(np.asarray(c, dtype=float))
    if lam <= 0:
        n = np.array([0])
        p = np.array([1.0])
    else:
        nmax = int(lam + 12 * math.sqrt(lam) + 15)
        n = np.arange(nmax + 1)
        p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    d = J * (n[:, None] - lam) - c[None, :]
    if s <= 0:
        q = np.where(d > 0, d * d, 0.0)
    else:
        z = d / s
        q = (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)
    return p @ q


def f_tau(x):
    return (1 + x * x) * norm.sf(x) - x * norm.pdf(x)


def f_lin_B(t, h, r):
    c = t - h
    if not (c > 0 and r / THF <= 2 * (THF - c)):
        return None
    s = sum((r / THF ** 2) ** (n - 1) / math.factorial(n) * ((THF * n - c) ** 2 + r) for n in range(1, 12))
    return s / THF ** 2 / (2 * h), f_tau(c / math.sqrt(r)) / (2 * h)


def f_lin_C(y, h, r):
    c = y - h
    if not (c > 0 and r / AF <= 2 * (AF - c)):
        return None
    s = sum((r / AF ** 2) ** (n - 1) / math.factorial(n) * ((AF * n - c) ** 2 + r) for n in range(1, 12))
    return f_tau(c / math.sqrt(r)) / (2 * h), s / AF ** 2 / (2 * h)


# ---------------------------------------------------------------- arb kernels


def Q(d, s):
    """Upper enclosure of E(d + s G)_+^2; s is an arb > 0 or None (s = 0)."""
    if s is None:
        if d <= 0:
            return arb(0)
        u = d.upper()
        return u * u if u > 0 else arb(0)
    z = d / s
    Phi = (-z / SQ2).erfc() / 2
    ph = (-(z * z) / 2).exp() / SQ2PI
    return (d * d + s * s) * Phi + d * s * ph


def lattice_sum(J, lam, s, c, N=NTERMS):
    """Upper bound of sum_n p_n(lam) E(J (n - lam) - c + s G)_+^2, lam >= 0."""
    if lam == 0:
        return Q(-c, s)
    p = (-lam).exp()
    tot = arb(0)
    for n in range(N + 1):
        tot += p * Q(J * (n - lam) - c, s)
        p = p * lam / (n + 1)
    C = J * lam + abs(c)
    s2 = s * s if s is not None else arb(0)
    lamN = lam ** (N + 1) / arb(math.factorial(N + 1))
    t = lamN * ((J * (N + 1) + C) ** 2 + s2)
    q = lam * (N + 2) / arb((N + 1) ** 2)
    assert q < 1
    return tot + t / (1 - q)


def sq(x):
    return x.sqrt() if x != 0 else None


def chiB(t, h, a, b):
    return lattice_sum(TH, a / TH2, sq(b), t - h) / (2 * h)


def chiC(y, h, a, b):
    return lattice_sum(AA, b / AA2, sq(a), y - h) / (2 * h)


def cs(y, r2):
    return (y * y + r2).sqrt() - y


def tau(x):
    Phibar = (x / SQ2).erfc() / 2
    ph = (-(x * x) / 2).exp() / SQ2PI
    return (1 + x * x) * Phibar - x * ph


def lin_B(t, h, r):
    """(alpha, beta) with chiB_h(t) <= a alpha + b beta for a, b >= 0, a + b <= r, or None."""
    c = t - h
    if not (c > 0 and r / TH <= 2 * (TH - c)):
        return None
    s = arb(0)
    for n in range(1, 12):
        s += (r / TH2) ** (n - 1) / math.factorial(n) * ((TH * n - c) ** 2 + r)
    s += (r / TH2) ** 11 / math.factorial(12) * ((TH * 12) ** 2 + r) * 2
    return (s / TH2 / (2 * h)).upper(), (tau(c / r.sqrt()) / (2 * h)).upper()


def lin_C(y, h, r):
    """(alpha, beta) with chiC_h(y) <= a alpha + b beta for a, b >= 0, a + b <= r, or None."""
    c = y - h
    if not (c > 0 and r / AA <= 2 * (AA - c)):
        return None
    s = arb(0)
    for n in range(1, 12):
        s += (r / AA2) ** (n - 1) / math.factorial(n) * ((AA * n - c) ** 2 + r)
    s += (r / AA2) ** 11 / math.factorial(12) * ((AA * 12) ** 2 + r) * 2
    return (tau(c / r.sqrt()) / (2 * h)).upper(), (s / AA2 / (2 * h)).upper()


def _min(x, y):
    """One of x, y that is a valid upper bound for min(x, y)."""
    return x if x < y else y


def amax(x, y):
    return (x + y + abs(x - y)) / 2


def amin(x, y):
    return (x + y - abs(x - y)) / 2


def garb(L):
    return 2 * L.sqrt() * (-L).exp()


def phi_max(l, u):
    """max of g on [l, u] (g increases on [0, 1/2], decreases after)."""
    if u <= HALF:
        x = u
    elif l >= HALF:
        x = l
    else:
        return GMAX
    return garb(x)


def main_max(L1, L2, m2, Vhi):
    """Upper bound of 2 m e^{-L} over L in [L1, L2], m <= m2, m^2 <= L Vhi (see verify_band.py)."""
    Lc = m2 * m2 / Vhi
    if L2 <= Lc:
        return Vhi.sqrt() * phi_max(L1, L2)
    if L1 >= Lc:
        return 2 * m2 * (-L1).exp()
    lo = _min(L1, Lc.lower())
    hi = _min(L2, Lc.upper())
    return Vhi.sqrt() * phi_max(lo, hi)


def lel_max(L1, L2):
    """max of L e^{-L} on [L1, L2] (increasing on [0, 1], decreasing after)."""
    if L2 <= 1:
        return L2 * (-L2).exp()
    if L1 >= 1:
        return L1 * (-L1).exp()
    return (-arb(1)).exp()


def P2(L):
    return 1 - (-L).exp() * (1 + L)


def target_lo(L1, L2):
    """Lower bound of max(g(L), C5) on [L1, L2]."""
    g1, g2 = garb(L1).lower(), garb(L2).lower()
    gl = g1 if g1 < g2 else g2
    return (gl if gl > C5LO else C5LO) - TGT_SHIFT


def grid_ceil(x, den):
    """Smallest integer j with j/den >= every point of the ball x (den a power of 2, exact comparisons)."""
    u = x.upper()
    j = math.ceil(float(u) * den)
    while arb(j) / den < u:
        j += 1
    while arb(j - 1) / den >= u:
        j -= 1
    return j


def grid_floor(x, den):
    """Largest integer j with j/den <= every point of the ball x (den a power of 2, exact comparisons)."""
    lo = x.lower()
    j = math.floor(float(lo) * den)
    while arb(j) / den > lo:
        j -= 1
    while arb(j + 1) / den <= lo:
        j += 1
    return j


def dy_up(x, den=2 ** 24):
    """A dyadic upper bound of the arb x (as an exact float)."""
    return grid_ceil(x, den) / den


# ---------------------------------------------------------------- cost tables for a corner (a, b)


class Tables:
    def __init__(self, a_f, b_f, r2):
        self.a_f, self.b_f = a_f, b_f
        self.a, self.b = arb(a_f), arb(b_f)
        self.r2 = r2
        self.r2f = float(r2.upper())
        sa, sb = math.sqrt(a_f), math.sqrt(b_f)
        lamB, lamC = a_f / THF ** 2, b_f / AF ** 2
        ks = np.arange(KLO, KHI + 1)
        mf = ks / MDEN
        H = HGRID[None, :]

        def fB(t):
            t = np.asarray(t, dtype=float)
            return f_lattice(THF, lamB, sb, (t[:, None] - H).ravel()).reshape(len(t), -1) / (2 * H)

        def fC(y):
            y = np.asarray(y, dtype=float)
            return f_lattice(AF, lamC, sa, (y[:, None] - H).ravel()).reshape(len(y), -1) / (2 * H)

        self.hB = HGRID[np.argmin(fB(mf), axis=1)]
        self.hC2 = HGRID[np.argmin(fC(2 * THF - mf), axis=1)]
        self.hP1 = HGRID[np.argmin(fC(THF - mf), axis=1)]
        self.hP1b = HGRID[np.argmin(fB(mf - THF), axis=1)]
        self.hP2 = HGRID[np.argmin(fC(AF - mf), axis=1)]
        self._cB, self._cC2, self._phi1, self._phi2 = {}, {}, {}, {}
        # float tables on the y-grid y_k = theta - k/MDEN (two-point option) and the t-grid t_j = j/MDEN (Taylor B)
        self.ky = np.arange(KYMIN, KHI + 1)
        yf = THF - self.ky / MDEN
        self.FC = np.stack([f_lattice(AF, lamC, sa, yf - h) / (2 * h) for h in HMV])
        tf = np.arange(KTMIN, KTMAX + 1) / MDEN
        self.FB = np.stack([f_lattice(THF, lamB, sb, tf - h) / (2 * h) for h in HMV])
        self.memoC, self.memoB = {}, {}

    # upper bounds of the costs at m = k/MDEN (arb, evaluated on first use)
    def cB(self, k):
        """>= 2E(W - m)_+."""
        v = self._cB.get(k)
        if v is None:
            m = arb(k) / MDEN
            v = _min(chiB(m, arb(float(self.hB[k - KLO])), self.a, self.b).upper(), cs(m, self.r2).upper())
            self._cB[k] = v
        return v

    def cC2(self, k):
        """>= phi(2 theta - m)."""
        v = self._cC2.get(k)
        if v is None:
            y2 = 2 * TH - arb(k) / MDEN
            v = _min(chiC(y2, arb(float(self.hC2[k - KLO])), self.a, self.b).upper(), cs(y2, self.r2).upper())
            self._cC2[k] = v
        return v

    def phi1(self, k):
        """>= phi(theta - m)."""
        v = self._phi1.get(k)
        if v is None:
            m = arb(k) / MDEN
            y1 = TH - m
            v1 = _min(chiC(y1, arb(float(self.hP1[k - KLO])), self.a, self.b).upper(), cs(y1, self.r2).upper())
            v = _min(v1, (chiB(m - TH, arb(float(self.hP1b[k - KLO])), self.a, self.b) - 2 * y1).upper())
            self._phi1[k] = v
        return v

    def phi2(self, k):
        """>= phi(A - m)."""
        v = self._phi2.get(k)
        if v is None:
            yA = AA - arb(k) / MDEN
            v = _min(chiC(yA, arb(float(self.hP2[k - KLO])), self.a, self.b).upper(), cs(yA, self.r2).upper())
            self._phi2[k] = v
        return v

    def chiC_y(self, i, k):
        key = (i, k)
        v = self.memoC.get(key)
        if v is None:
            v = chiC(TH - arb(k) / MDEN, arb(float(HMV[i])), self.a, self.b).upper()
            self.memoC[key] = v
        return v

    def chiB_t(self, i, j):
        key = (i, j)
        v = self.memoB.get(key)
        if v is None:
            v = chiB(arb(j) / MDEN, arb(float(HMV[i])), self.a, self.b).upper()
            self.memoB[key] = v
        return v



# linear coefficients for a + b <= r_eff(jr) = min(jr/RDEN, RLIN) (independent of the square, memoised per process):
# chiC_h at y_k = theta - k/MDEN, at 2 theta - m_k, A - m_k, and chiB_h at t = m_k = k/MDEN, h = HLIN[i]
_LIN_MEMO = {}
RDEN = 4096


def r_eff(jr):
    r = arb(jr) / RDEN
    return r if r < RLIN else RLIN


def linC_y(i, k, jr):
    key = ("Cy", i, k, jr)
    if key not in _LIN_MEMO:
        _LIN_MEMO[key] = lin_C(TH - arb(k) / MDEN, arb(float(HLIN[i])), r_eff(jr))
    return _LIN_MEMO[key]


def linC_at(i, y, key, jr):
    key = key + (jr,)
    if key not in _LIN_MEMO:
        _LIN_MEMO[key] = lin_C(y, arb(float(HLIN[i])), r_eff(jr))
    return _LIN_MEMO[key]


def linB_m(i, k, jr):
    key = ("Bm", i, k, jr)
    if key not in _LIN_MEMO:
        _LIN_MEMO[key] = lin_B(arb(k) / MDEN, arb(float(HLIN[i])), r_eff(jr))
    return _LIN_MEMO[key]


# ---------------------------------------------------------------- one (Lambda, m) box: geometry


def feasible(L1, L2, m1, m2, Vlo, Vhi):
    """False if (F1)-(F5) fail at every point of the box (for every V in [Vlo, Vhi])."""
    if L2 < Vlo / AA2 or L1 > Vhi / TH2:
        return False
    if m2 < Vlo / AA or m1 > Vhi / TH:
        return False
    if m2 < TH * L1 or m1 > AA * L2:
        return False
    if m1 * m1 > L2 * Vhi:
        return False
    if L1 > (1 / AA + 1 / TH) * m2 - Vlo / (AA * TH):
        return False
    return True


def jump_geometry(L1, L2, m1, m2, Vhi):
    """Bounds for the jump law on the box: mu1 in [mu_lo, mu_hi], d = mu1 - theta, sigma^2 <= s2, and the lower
    bounds wl of w = d^2/(sigma^2 + d^2) and ul of u = d + sigma^2/d (as exact arbs)."""
    mu_lo = amax(TH, m1 / L2)
    mu_hi = amin(AA, m2 / L1)
    dlo = (mu_lo - TH).lower()
    if dlo < 0:
        dlo = arb(0)
    dhi = (mu_hi - TH).upper()
    s2a = ((L2 * Vhi - m1 * m1) / (L1 * L1)).upper()
    s2b = (dhi * (AA - TH - dlo)).upper()
    s2 = s2a if s2a < s2b else s2b
    if s2 < 0:
        s2 = arb(0)
    if s2 == 0:
        wl = arb(1) if dlo > 0 else arb(0)
        ul = dlo
    else:
        wl = (dlo * dlo / (s2 + dlo * dlo)).lower()
        s = s2.sqrt()
        if dlo >= s:
            ul = (dlo + s2 / dlo).lower()
        elif dhi <= s:
            ul = (dhi + s2 / dhi).lower()
        else:
            ul = (2 * s).lower()
    return mu_lo, mu_hi, s2, wl, ul


# ---------------------------------------------------------------- direct check of one box


def _count(stats, key):
    if stats is not None:
        stats[key] = stats.get(key, 0) + 1


def check_direct(L1, L2, k1, k2, Vlo, Vhi, T, stats=None):
    m1, m2 = arb(k1) / MDEN, arb(k2) / MDEN
    if not feasible(L1, L2, m1, m2, Vlo, Vhi):
        _count(stats, "infeasible")
        return True
    tgt = target_lo(L1, L2)
    M = main_max(L1, L2, m2, Vhi)
    LeL = lel_max(L1, L2)
    base = M + (-L1).exp() * T.cB(k1) + P2(L2) * T.cC2(k2)
    if not (base < tgt):
        return False
    room = (tgt - base) / LeL
    mu_lo, mu_hi, s2, wl, ul = jump_geometry(L1, L2, m1, m2, Vhi)
    # chord of phi, upper value at theta - m replaced by max(phi1, phi2) (bounding chord nonincreasing in mu1)
    p1, p2v = T.phi1(k2), T.phi2(k2)
    ch = ((AA - mu_lo) * amax(p1, p2v) + (mu_lo - TH) * p2v) / (AA - TH)
    if ch < room:
        _count(stats, "chord")
        return True
    # two-point option with psi = chiC_h (one h for both points)
    kx = max(grid_ceil(m2 - ul, MDEN), KYMIN)
    wlf = float(wl.mid())
    fl = (1 - wlf) * T.FC[:, k2 - KYMIN] + wlf * T.FC[:, kx - KYMIN]
    for i in np.argsort(fl)[:3]:
        i = int(i)
        v = (1 - wl) * T.chiC_y(i, k2) + wl * T.chiC_y(i, kx)
        if v < room:
            _count(stats, "twopoint_C")
            return True
    # two-point option with psi = CS (needs theta - m >= 0 on the box)
    j0 = TH - m2
    if j0 >= 0:
        v = (1 - wl) * cs(j0, T.r2) + wl * cs(j0 + ul, T.r2)
        if v < room:
            _count(stats, "twopoint_CS")
            return True
    # Taylor option with Gamma(y) = -2y + chiB_h(-y)
    y0lo = mu_lo - m2
    y0hi = mu_hi - m1
    jt = grid_floor(-y0hi, MDEN)
    if jt >= KTMIN:
        jt = min(jt, KTMAX)
        s2f = float(s2)
        fl = -2 * float(y0lo.mid()) + T.FB[:, jt - KTMIN] + s2f / (2 * HMV)
        for i in np.argsort(fl)[:2]:
            i = int(i)
            v = -2 * y0lo + T.chiB_t(i, jt) + s2 / (2 * arb(float(HMV[i])))
            if v < room:
                _count(stats, "taylor_B")
                return True
    return False


# ---------------------------------------------------------------- slope check (Part S)


def lin_options_point(kind, k, jr):
    """List of linear (alpha, beta) bounds, valid for a, b >= 0, a + b <= r_eff(jr), at grid point k for: 'B' cB
    at m_k, 'C2' cC at 2 theta - m_k, 'P1' phi at theta - m_k, 'P2' phi at A - m_k."""
    out = []
    m = arb(k) / MDEN
    if kind == "B":
        t = m
        for i in range(len(HLIN)):
            v = linB_m(i, k, jr)
            if v is not None:
                out.append(v)
    else:
        yy = {"C2": 2 * TH - m, "P1": TH - m, "P2": AA - m}[kind]
        for i in range(len(HLIN)):
            v = linC_at(i, yy, (kind, i, k), jr)
            if v is not None:
                out.append(v)
        t = yy
    if t > 0:
        c = (1 / (2 * t)).upper()
        out.append((c, c))
    return out


_OPT_MEMO = {}


def lin_opts(kind, k, jr):
    key = (kind, k, jr)
    if key not in _OPT_MEMO:
        _OPT_MEMO[key] = best_pair(lin_options_point(kind, k, jr))
    return _OPT_MEMO[key]


def best_pair(opts):
    """Pareto-reduce a list of (alpha, beta) or (alpha, beta, kappa) arb tuples (by the floats of alpha, beta)."""
    fl = sorted(((float(p[0]), float(p[1]), p) for p in opts), key=lambda x: (x[0], x[1]))
    res, bmin = [], math.inf
    for fa, fb, p in fl:
        if fb < bmin:
            res.append(p)
            bmin = fb
    return res


def check_slope(L1, L2, k1, k2, Vlo, Vhi, rmax, max_split=6):
    """Slope argument on an OR box (m2 < theta), for V in [Vlo, Vhi] and rho^2 = 1 - V <= rmax <= RLIN.

    The rho^2-range is bisected (at most max_split times). On a piece [r1, r2] every cost is <= a alpha + b beta
    (a, b >= 0, a + b <= r_eff >= r2), and the jump-law variance bound uses V <= 1 - r1. The O'-options with a
    constant kappa > 0 (two-point bound with h > j0 = theta - m2) satisfy kappa <= dlo^2 sqrt(L1 / (1 - r1)), which
    gives 2 m e^-L + L e^-L kappa (1 - w) <= sqrt(V) g(L). So
    F <= sqrt(V) g(L) + rho^2 Mx <= (1 - rho^2/2) g(L) + rho^2 Mx, Mx >= both coefficients of a and b."""
    m1, m2 = arb(k1) / MDEN, arb(k2) / MDEN
    j0 = TH - m2
    if not (j0 > 0):
        return False
    tgt = target_lo(L1, L2)
    g1, g2 = garb(L1).lower(), garb(L2).lower()
    glo = g1 if g1 < g2 else g2
    ghi = phi_max(L1, L2)
    eL, LeL, p2 = (-L1).exp(), lel_max(L1, L2), P2(L2)
    mu_lo = amax(TH, m1 / L2)
    dlo = (mu_lo - TH).lower()
    w = (AA - mu_lo) / (AA - TH)
    feL, fLeL, fp2 = float(eL), float(LeL), float(p2)

    def combine(oB, oO, oC2):
        """Combination minimising max(A, B) (floats); returns (Mx, kappa) in arb, or None."""
        fB = [(float(p[0]), float(p[1])) for p in oB]
        fO = [(float(p[0]), float(p[1])) for p in oO]
        fC2 = [(float(p[0]), float(p[1])) for p in oC2]
        best, bestf = None, math.inf
        for ib, (ab, bb) in enumerate(fB):
            for io, (ao, bo) in enumerate(fO):
                for ic, (ac, bc) in enumerate(fC2):
                    v = max(feL * ab + fLeL * ao + fp2 * ac, feL * bb + fLeL * bo + fp2 * bc)
                    if v < bestf:
                        bestf, best = v, (ib, io, ic)
        if best is None:
            return None
        pB, pO, pC = oB[best[0]], oO[best[1]], oC2[best[2]]
        Mx = amax(eL * pB[0] + LeL * pO[0] + p2 * pC[0], eL * pB[1] + LeL * pO[1] + p2 * pC[1])
        return Mx, (pO[2] if len(pO) > 2 else arb(0))

    def options(Vh, jr):
        oB = lin_opts("B", k1, jr)
        oC2 = lin_opts("C2", k2, jr)
        # chord with per-coefficient max-fix (independent of V)
        oO = []
        for a1, b1 in lin_opts("P1", k2, jr):
            for a2, b2 in lin_opts("P2", k2, jr):
                oO.append(((a2 + w * (amax(a1, a2) - a2)).upper(), (b2 + w * (amax(b1, b2) - b2)).upper()))
        _, _, s2, wl, ul = jump_geometry(L1, L2, m1, m2, Vh)
        kx = max(grid_ceil(m2 - ul, MDEN), KYMIN)
        xlo = TH - arb(kx) / MDEN
        kap_max = (dlo * dlo * (L1 / Vh).sqrt()).lower() if dlo > 0 else None
        # (O5) uses the true sigma_J^2, so its far point is only known to be >= j0 + d >= theta - m2 + dlo
        kxK = max(grid_ceil(m2 - dlo, MDEN), KYMIN) if dlo > 0 else None
        oK = []
        for i in range(len(HLIN)):
            q = linC_y(i, kx, jr)
            p = linC_y(i, k2, jr) if kx != k2 else q
            if p is not None and q is not None:
                # (O3), psi = chiC_h, h < j0: linear at both points
                oO.append((((1 - wl) * p[0] + wl * q[0]).upper(), ((1 - wl) * p[1] + wl * q[1]).upper()))
            if kap_max is not None:
                # (O5): psi(j0) <= kappa + rho^2/(2h), kappa = (h - j0)_+^2/(2h), absorbed by lem:absorb
                qK = linC_y(i, kxK, jr)
                if qK is None:
                    continue
                h = arb(float(HLIN[i]))
                e = h - j0
                kap = (e * e / (2 * h)).upper() if e > 0 else arb(0)
                if kap <= kap_max:
                    c = (1 - wl) / (2 * h)
                    oK.append(((c + qK[0]).upper(), (c + qK[1]).upper(), kap))
        if xlo > 0:
            c = ((1 - wl) / (2 * j0) + wl / (2 * xlo)).upper()
            oO.append((c, c))
        return oB, best_pair(oO), oC2, best_pair(oO + oK)

    def ok(r1, r2, Vh, jr):
        oB, oO, oC2, oOK = options(Vh, jr)
        res0 = combine(oB, oO, oC2)
        resK = combine(oB, oOK, oC2)
        if resK is None:
            return False
        Mx, kap = resK
        if TGT_SHIFT == 0 and Mx < glo / 2:
            return True
        ex = Mx - ghi / 2
        if ghi + amax(r1 * ex, r2 * ex) < tgt:
            return True
        M0 = main_max(L1, L2, m2, Vh)
        if res0 is not None and M0 + r2 * res0[0] < tgt:
            return True
        if kap > 0:
            Mk = amax(M0, eL * (2 * m2 + kap * amax(L2 * Vh - m2 * m2, arb(0)) / (L1 * dlo * dlo)))
            return Mk + r2 * Mx < tgt
        return False

    rB = _min(rmax, (1 - m1 * m1 / L2).upper())
    r0 = (1 - Vhi).lower()
    if r0 < 0:
        r0 = arb(0)
    if rB <= r0:
        rB = r0

    def rec(r1, r2, depth):
        Vh = 1 - r1
        if m1 * m1 > L2 * Vh:
            return True
        if ok(r1, r2, Vh, max(1, grid_ceil(r2, RDEN))):
            return True
        if depth >= max_split:
            return False
        rm = (r1 + r2) / 2
        return rec(r1, rm, depth + 1) and rec(rm, r2, depth + 1)

    return rec(r0, rB, 0)


# ---------------------------------------------------------------- box subdivision driver


LMIN = arb(1) / 16384


def run_boxes(check, Vlo, Vhi, lam_lo, lam_hi, max_depth=40, stop_on_fail=False):
    """Cover Lambda in [lam_lo, lam_hi] (rounded outwards to 1/64) times m in [KLO, KHI]/MDEN by boxes accepted by
    check, bisecting rejected boxes (m down to one grid step 1/MDEN, Lambda down to LMIN)."""
    stack = []
    Lsteps = 64
    mblock = MDEN // 64
    for i in range(int(lam_lo * Lsteps), int(math.ceil(lam_hi * Lsteps))):
        for k in range(KLO, KHI, mblock):
            stack.append((arb(i) / Lsteps, arb(i + 1) / Lsteps, k, min(k + mblock, KHI), 0))
    nbox, fails = 0, []
    while stack:
        L1, L2, k1, k2, depth = stack.pop()
        nbox += 1
        if check(L1, L2, k1, k2):
            continue
        if depth > max_depth:
            fails.append((float(L1.mid()), float(L2.mid()), k1, k2))
        elif k2 - k1 > 1 and (depth % 2 == 0 or (L2 - L1) < LMIN):
            km = (k1 + k2) // 2
            stack += [(L1, L2, k1, km, depth + 1), (L1, L2, km, k2, depth + 1)]
            continue
        elif (L2 - L1) > LMIN:
            Lm = (L1 + L2) / 2
            stack += [(L1, Lm, k1, k2, depth + 1), (Lm, L2, k1, k2, depth + 1)]
            continue
        else:
            fails.append((float(L1.mid()), float(L2.mid()), k1, k2))
        if stop_on_fail:
            break
    return nbox, fails


# ---------------------------------------------------------------- (a, b) squares


def verify_ab_box(args, stop_on_fail=True):
    """Certify F <= max(g(Lambda), C5) for every (a, b) in [a1, a2] x [b1, b2] with a + b <= 1/5 and every feasible
    (Lambda, m). Costs at the corner (clipped to a + b <= 1/5), V in [1 - min(a2 + b2, 1/5), 1 - (a1 + b1)]; if
    a2 + b2 <= 1/50 the slope argument is also available."""
    a1, a2, b1, b2 = args
    s_lo, s_hi = arb(a1 + b1), arb(a2 + b2)
    Vhi = 1 - s_lo
    if s_hi <= RHO0:
        Vlo = 1 - s_hi
        ac, bc = a2, b2
        r2 = s_hi
    else:
        Vlo = 1 - RHO0
        ac = min(a2, dy_up(RHO0 - arb(b1)))
        bc = min(b2, dy_up(RHO0 - arb(a1)))
        r2 = RHO0 if arb(ac + bc) > RHO0 else arb(ac + bc)
    slope = bool(s_hi <= RLIN)
    t0 = time.time()
    T = Tables(ac, bc, r2)
    lam_lo = float((Vlo / AA2).lower()) - 0.01
    lam_hi = float((Vhi / TH2).upper()) + 0.01
    stats = {}

    def check(L1, L2, k1, k2):
        if check_direct(L1, L2, k1, k2, Vlo, Vhi, T, stats):
            return True
        if slope and check_slope(L1, L2, k1, k2, Vlo, Vhi, s_hi):
            _count(stats, "slope")
            return True
        return False

    nbox, fails = run_boxes(check, Vlo, Vhi, lam_lo, lam_hi, stop_on_fail=stop_on_fail)
    return dict(box=args, nbox=nbox, fails=fails[:5], nfail=len(fails), stats=stats, sec=time.time() - t0)


def ab_boxes(step):
    """Squares of side step (a power of 1/2) covering {a, b >= 0, a + b <= 1/5}."""
    out = []
    n = int(math.floor(RHO0F / step)) + 1
    for i in range(n):
        for j in range(n - i):
            a1, a2, b1, b2 = i * step, (i + 1) * step, j * step, (j + 1) * step
            if a1 + b1 >= RHO0F:
                continue
            out.append((a1, a2, b1, b2))
    return out


def run_all(step, nproc=8, min_step=1 / 8192, log_path=None):
    boxes = ab_boxes(step)
    t0 = time.time()
    log = dict(levels=[], certified=0, lam_m_boxes=0)
    stats = {}
    flog = open(log_path, "w") if log_path else None
    with Pool(nproc) as pool:
        while boxes:
            print(f"level step {step}: {len(boxes)} (a,b) squares", flush=True)
            bad, nb = [], 0
            for i, r in enumerate(pool.imap_unordered(verify_ab_box, boxes, chunksize=1)):
                nb += r["nbox"]
                if r["nfail"]:
                    bad.append(r["box"])
                else:
                    for k, v in r["stats"].items():
                        stats[k] = stats.get(k, 0) + v
                if flog:
                    flog.write(json.dumps(dict(box=r["box"], ok=not r["nfail"], nbox=r["nbox"],
                                               sec=round(r["sec"], 2))) + "\n")
                    flog.flush()
                if i % 200 == 0:
                    print(f"  {i}/{len(boxes)}  {time.time()-t0:.0f}s  bad so far {len(bad)}", flush=True)
            log["levels"].append(dict(step=step, squares=len(boxes), not_certified=len(bad), lam_m_boxes=nb))
            log["certified"] += len(boxes) - len(bad)
            log["lam_m_boxes"] += nb
            if not bad:
                break
            if step / 2 < min_step:
                log["uncertified"] = bad
                break
            step /= 2
            boxes = []
            for (a1, a2, b1, b2) in bad:
                am, bm = (a1 + a2) / 2, (b1 + b2) / 2
                for q in ((a1, am, b1, bm), (am, a2, b1, bm), (a1, am, bm, b2), (am, a2, bm, b2)):
                    if q[0] + q[2] < RHO0F:
                        boxes.append(q)
    if flog:
        flog.close()
    log["certified_by"] = stats
    log["sec"] = round(time.time() - t0, 1)
    return log


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode == "all":
        step = float(sys.argv[2]) if len(sys.argv) > 2 else 1 / 128
        nproc = int(sys.argv[3]) if len(sys.argv) > 3 else 8
        log_path = sys.argv[4] if len(sys.argv) > 4 else None
        print(json.dumps(run_all(step, nproc, log_path=log_path)), flush=True)
    elif mode == "one":
        a1, a2, b1, b2 = (float(x) for x in sys.argv[2].split(","))
        full = len(sys.argv) > 3 and sys.argv[3] == "full"
        print(json.dumps(verify_ab_box((a1, a2, b1, b2), stop_on_fail=not full)), flush=True)
