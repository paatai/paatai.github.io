"""Box-level certificate of Theorem 13 (thm:bandstar of MAIN_RESULT.tex): a recording rerun of verify_bandstar.py.

RQ-REF3 (FINAL report, remark 2) asked that the band run store, per leaf box, the method, the option and h, so that a
checker can replay it. This script reruns the published computation (`verify_bandstar.py all 0.0078125 8`) with
verify_bandstar.py imported unchanged (its md5 is checked) and four hooks that only observe: run_boxes, Tables,
check_slope and _count are wrapped so that every (Lambda, m) box accepted in a certified (a, b) square is written out
with the method that accepted it and the parameters it used. The hooks change no decision, so the run reproduces
outputs/verify_bandstar_squares.jsonl square by square (compared at the end). For a slope leaf the certificate (the
rho^2 pieces, and per piece the test and the three linear options) comes from a tagged copy of the option search of
check_slope, run only on boxes that check_slope accepted.

Output, in the directory given (default outputs/bandstar_cert):
  bandstar_leaves.npz   per certified square: box, corner, Lambda strips, h tables; per leaf box: box, method,
                        option, aux (the format is described in scripts/bandstar_replay.py)
  bandstar_slope.json   the certificates of the slope leaves
  record_squares.jsonl  one line per (a, b) square examined, as in outputs/verify_bandstar_squares.jsonl
  record_summary.json   the summary of verify_bandstar.py run_all, and the comparison with the published run
The record is checked by scripts/bandstar_replay.py, which does not use the search code.

Usage: python3 scripts/bandstar_record.py all [nproc] [outdir]
       python3 scripts/bandstar_record.py one a1,a2,b1,b2 outdir      (one square, for tests)
"""
import hashlib
import json
import math
import os
import sys
import time
from multiprocessing import Pool

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import numpy as np  # noqa: E402
from flint import arb  # noqa: E402

import verify_bandstar as vb  # noqa: E402

VB_MD5 = "b5b55ceec828f01debc6c1a422e7270f"
LDEN, SDEN, CDEN = 16384, 8192, 2 ** 24
METHODS = ("infeasible", "chord", "twopoint_C", "twopoint_CS", "taylor_B", "slope")
MCODE = {name: i for i, name in enumerate(METHODS)}
HNAMES = ("hB", "hC2", "hP1", "hP1b", "hP2")
ZERO = arb(0)


def md5(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def exact_int(x, den):
    """The integer n with x = n/den, for a float or an exact arb x (checked exactly)."""
    n = int(round(float(x) * den))
    if isinstance(x, arb):
        assert x == arb(n) / den, (x, den)
    else:
        assert n == x * den, (x, den)
    return n


# ---------------------------------------------------------------- observing hooks

CUR = {}
_run_boxes, _check_slope, _count = vb.run_boxes, vb.check_slope, vb._count


class RecTables(vb.Tables):
    def __init__(self, a_f, b_f, r2):
        super().__init__(a_f, b_f, r2)
        CUR["T"] = self

    def chiC_y(self, i, k):
        CUR["lastC"] = (i, k)
        return super().chiC_y(i, k)

    def chiB_t(self, i, j):
        CUR["lastB"] = (i, j)
        return super().chiB_t(i, j)


def count_rec(stats, key):
    CUR["key"] = key
    _count(stats, key)


def check_slope_rec(L1, L2, k1, k2, Vlo, Vhi, rmax, max_split=6):
    CUR["slope_args"] = (L1, L2, k1, k2, Vlo, Vhi, rmax, max_split)
    return _check_slope(L1, L2, k1, k2, Vlo, Vhi, rmax, max_split)


def run_boxes_rec(check, Vlo, Vhi, lam_lo, lam_hi, max_depth=40, stop_on_fail=False):
    CUR["strips"] = (int(lam_lo * 64), int(math.ceil(lam_hi * 64)))
    leaves, slope = CUR["leaves"], CUR["slope"]

    def check_rec(L1, L2, k1, k2):
        CUR["key"] = CUR["lastC"] = CUR["lastB"] = CUR["slope_args"] = None
        ok = check(L1, L2, k1, k2)
        if ok:
            leaves.append(leaf_record(L1, L2, k1, k2, Vlo, Vhi, slope))
        return ok

    return _run_boxes(check_rec, Vlo, Vhi, lam_lo, lam_hi, max_depth, stop_on_fail)


vb.Tables = RecTables
vb._count = count_rec
vb.check_slope = check_slope_rec
vb.run_boxes = run_boxes_rec


def infeasible_reason(L1, L2, k1, k2, Vlo, Vhi):
    """Number (1-8) of the first test of feasible() that fails on the whole box."""
    TH, AA = vb.TH, vb.AA
    m1, m2 = arb(k1) / vb.MDEN, arb(k2) / vb.MDEN
    tests = (lambda: L2 < Vlo / vb.AA2, lambda: L1 > Vhi / vb.TH2,
             lambda: m2 < Vlo / AA, lambda: m1 > Vhi / TH,
             lambda: m2 < TH * L1, lambda: m1 > AA * L2,
             lambda: m1 * m1 > L2 * Vhi,
             lambda: L1 > (1 / AA + 1 / TH) * m2 - Vlo / (AA * TH))
    for i, t in enumerate(tests):
        if t():
            return i + 1
    raise AssertionError("box rejected by feasible() but no test fails")


def leaf_record(L1, L2, k1, k2, Vlo, Vhi, slope):
    key = CUR["key"]
    opt = aux = 0
    if key == "infeasible":
        opt = infeasible_reason(L1, L2, k1, k2, Vlo, Vhi)
    elif key == "twopoint_C":
        opt, aux = CUR["lastC"]
    elif key == "taylor_B":
        opt, aux = CUR["lastB"]
    elif key == "slope":
        args = CUR["slope_args"]
        assert args[0] is L1 and args[1] is L2 and args[2:4] == (k1, k2)
        pieces = slope_certificate(*args)
        assert pieces is not None, "check_slope accepted a box but the tagged search found no certificate"
        aux = len(slope)
        slope.append(pieces)
    else:
        assert key in ("chord", "twopoint_CS"), key
    return (exact_int(L1, LDEN), exact_int(L2, LDEN), k1, k2, MCODE[key], opt, aux)


# ---------------------------------------------------------------- tagged copy of the option search of check_slope

def _tag_opts(kind, k, jr):
    """vb.lin_options_point with tags: (alpha, beta, kappa = 0, tag), tag ('lin', i) or ('cs',)."""
    out = []
    m = arb(k) / vb.MDEN
    if kind == "B":
        t = m
        for i in range(len(vb.HLIN)):
            v = vb.linB_m(i, k, jr)
            if v is not None:
                out.append((v[0], v[1], ZERO, ("lin", i)))
    else:
        yy = {"C2": 2 * vb.TH - m, "P1": vb.TH - m, "P2": vb.AA - m}[kind]
        for i in range(len(vb.HLIN)):
            v = vb.linC_at(i, yy, (kind, i, k), jr)
            if v is not None:
                out.append((v[0], v[1], ZERO, ("lin", i)))
        t = yy
    if t > 0:
        c = (1 / (2 * t)).upper()
        out.append((c, c, ZERO, ("cs",)))
    return out


_TAG_MEMO = {}


def tag_opts(kind, k, jr):
    key = (kind, k, jr)
    if key not in _TAG_MEMO:
        _TAG_MEMO[key] = vb.best_pair(_tag_opts(kind, k, jr))
    return _TAG_MEMO[key]


def slope_certificate(L1, L2, k1, k2, Vlo, Vhi, rmax, max_split=6):
    """The search of vb.check_slope, step for step, returning the certificate (list of pieces) or None."""
    TH, AA, MDEN = vb.TH, vb.AA, vb.MDEN
    amax = vb.amax
    m1, m2 = arb(k1) / MDEN, arb(k2) / MDEN
    j0 = TH - m2
    if not (j0 > 0):
        return None
    tgt = vb.target_lo(L1, L2)
    g1, g2 = vb.garb(L1).lower(), vb.garb(L2).lower()
    glo = g1 if g1 < g2 else g2
    ghi = vb.phi_max(L1, L2)
    eL, LeL, p2 = (-L1).exp(), vb.lel_max(L1, L2), vb.P2(L2)
    mu_lo = amax(TH, m1 / L2)
    dlo = (mu_lo - TH).lower()
    w = (AA - mu_lo) / (AA - TH)
    feL, fLeL, fp2 = float(eL), float(LeL), float(p2)

    def combine(oB, oO, oC2):
        fB = [(float(p[0]), float(p[1])) for p in oB]
        fO = [(float(p[0]), float(p[1])) for p in oO]
        fC2 = [(float(p[0]), float(p[1])) for p in oC2]
        best, bestf = None, math.inf
        for ib, (ab, bb) in enumerate(fB):
            for io, (ao, bo) in enumerate(fO):
                for ic, (ac, bc) in enumerate(fC2):
                    v = max(feL * ab + fLeL * ao + fp2 * ac, feL * bb + fLeL * bo + fp2 * bc)
                    if v < bestf:
                        bestf, best = v, (ib, io, ic)
        if best is None:
            return None
        pB, pO, pC = oB[best[0]], oO[best[1]], oC2[best[2]]
        Mx = amax(eL * pB[0] + LeL * pO[0] + p2 * pC[0], eL * pB[1] + LeL * pO[1] + p2 * pC[1])
        return Mx, pO[2], (pB[3], pO[3], pC[3])

    def options(Vh, jr):
        oB = tag_opts("B", k1, jr)
        oC2 = tag_opts("C2", k2, jr)
        oO = []
        for a1, b1, _, t1 in tag_opts("P1", k2, jr):
            for a2, b2, _, t2 in tag_opts("P2", k2, jr):
                oO.append(((a2 + w * (amax(a1, a2) - a2)).upper(), (b2 + w * (amax(b1, b2) - b2)).upper(), ZERO,
                           ("chord", t1, t2)))
        _, _, s2, wl, ul = vb.jump_geometry(L1, L2, m1, m2, Vh)
        kx = max(vb.grid_ceil(m2 - ul, MDEN), vb.KYMIN)
        xlo = TH - arb(kx) / MDEN
        kap_max = (dlo * dlo * (L1 / Vh).sqrt()).lower() if dlo > 0 else None
        kxK = max(vb.grid_ceil(m2 - dlo, MDEN), vb.KYMIN) if dlo > 0 else None
        oK = []
        for i in range(len(vb.HLIN)):
            q = vb.linC_y(i, kx, jr)
            p = vb.linC_y(i, k2, jr) if kx != k2 else q
            if p is not None and q is not None:
                oO.append((((1 - wl) * p[0] + wl * q[0]).upper(), ((1 - wl) * p[1] + wl * q[1]).upper(), ZERO,
                           ("O3", i)))
            if kap_max is not None:
                qK = vb.linC_y(i, kxK, jr)
                if qK is None:
                    continue
                h = arb(float(vb.HLIN[i]))
                e = h - j0
                kap = (e * e / (2 * h)).upper() if e > 0 else arb(0)
                if kap <= kap_max:
                    c = (1 - wl) / (2 * h)
                    oK.append(((c + qK[0]).upper(), (c + qK[1]).upper(), kap, ("O5", i)))
        if xlo > 0:
            c = ((1 - wl) / (2 * j0) + wl / (2 * xlo)).upper()
            oO.append((c, c, ZERO, ("O4",)))
        return oB, vb.best_pair(oO), oC2, vb.best_pair(oO + oK)

    def ok(r1, r2, Vh, jr):
        oB, oO, oC2, oOK = options(Vh, jr)
        res0 = combine(oB, oO, oC2)
        resK = combine(oB, oOK, oC2)
        if resK is None:
            return None
        Mx, kap, tags = resK
        if vb.TGT_SHIFT == 0 and Mx < glo / 2:
            return "T1", tags
        ex = Mx - ghi / 2
        if ghi + amax(r1 * ex, r2 * ex) < tgt:
            return "T2", tags
        M0 = vb.main_max(L1, L2, m2, Vh)
        if res0 is not None and M0 + r2 * res0[0] < tgt:
            return "T3", res0[2]
        if kap > 0:
            Mk = amax(M0, eL * (2 * m2 + kap * amax(L2 * Vh - m2 * m2, arb(0)) / (L1 * dlo * dlo)))
            if Mk + r2 * Mx < tgt:
                return "T3K", tags
        return None

    def rec(r1, r2, depth, path):
        Vh = 1 - r1
        if m1 * m1 > L2 * Vh:
            return [dict(path=path, test="E")]
        jr = max(1, vb.grid_ceil(r2, vb.RDEN))
        res = ok(r1, r2, Vh, jr)
        if res is not None:
            test, (tB, tO, tC) = res
            return [dict(path=path, test=test, jr=jr, B=tB, O=tO, C2=tC)]
        if depth >= max_split:
            return None
        rm = (r1 + r2) / 2
        lo = rec(r1, rm, depth + 1, path + "0")
        if lo is None:
            return None
        hi = rec(rm, r2, depth + 1, path + "1")
        if hi is None:
            return None
        return lo + hi

    rB = vb._min(rmax, (1 - m1 * m1 / L2).upper())
    r0 = (1 - Vhi).lower()
    if r0 < 0:
        r0 = arb(0)
    if rB <= r0:
        rB = r0
    return rec(r0, rB, 0, "")


# ---------------------------------------------------------------- driver (run_all of verify_bandstar.py, recorded)

def record_square(box):
    CUR.clear()
    CUR["leaves"], CUR["slope"] = [], []
    r = vb.verify_ab_box(box)
    out = dict(box=box, ok=not r["nfail"], nbox=r["nbox"], stats=r["stats"], sec=r["sec"])
    if out["ok"]:
        T = CUR["T"]
        leaves = np.array(CUR["leaves"], dtype=np.int64).reshape(-1, 7)
        counts = np.bincount(leaves[:, 4], minlength=len(METHODS))
        assert {METHODS[i]: int(c) for i, c in enumerate(counts) if c} == r["stats"], (box, counts, r["stats"])
        h = []
        for name in HNAMES:
            hv = getattr(T, name)
            idx = np.searchsorted(vb.HGRID, hv)
            assert np.array_equal(vb.HGRID[idx], hv)
            h.append(idx)
        out.update(leaves=leaves, slope=CUR["slope"], strips=CUR["strips"],
                   corner=(exact_int(T.a_f, CDEN), exact_int(T.b_f, CDEN)), h=np.array(h, dtype=np.uint8))
    return out


def jsonable(x):
    if isinstance(x, (list, tuple)):
        return [jsonable(y) for y in x]
    if isinstance(x, dict):
        return {k: jsonable(v) for k, v in x.items()}
    return x


def write_record(results, outdir):
    results = sorted(results, key=lambda r: (-(r["box"][1] - r["box"][0]), r["box"][0], r["box"][2]))
    off = np.zeros(len(results) + 1, dtype=np.int64)
    off[1:] = np.cumsum([len(r["leaves"]) for r in results])
    leaves = np.concatenate([r["leaves"] for r in results])
    slope = []
    for s, r in enumerate(results):
        pos = np.nonzero(r["leaves"][:, 4] == MCODE["slope"])[0]
        assert len(pos) == len(r["slope"])
        for loc, p in enumerate(pos):
            j = int(off[s] + p)
            assert leaves[j, 6] == loc
            leaves[j, 6] = len(slope)
            slope.append(dict(sq=s, leaf=j, box=[int(v) for v in leaves[j, :4]], pieces=jsonable(r["slope"][loc])))
    assert leaves[:, 0].max() < 2 ** 31 and abs(leaves[:, 2:4]).max() < 2 ** 15 and leaves[:, 6].max() < 2 ** 15
    np.savez_compressed(
        os.path.join(outdir, "bandstar_leaves.npz"),
        methods=np.array(METHODS), hnames=np.array(HNAMES),
        HGRID=vb.HGRID, HMV=vb.HMV, HLIN=vb.HLIN,
        grid=np.array([vb.MDEN, LDEN, SDEN, CDEN, vb.RDEN, vb.KLO, vb.KHI], dtype=np.int64),
        sq_box=np.array([[exact_int(x, SDEN) for x in r["box"]] for r in results], dtype=np.int32),
        sq_corner=np.array([r["corner"] for r in results], dtype=np.int64),
        sq_strips=np.array([r["strips"] for r in results], dtype=np.int32),
        sq_nbox=np.array([r["nbox"] for r in results], dtype=np.int64),
        sq_off=off,
        sq_h=np.stack([r["h"] for r in results]),
        leaf_L1=leaves[:, 0].astype(np.int32), leaf_L2=leaves[:, 1].astype(np.int32),
        leaf_k1=leaves[:, 2].astype(np.int16), leaf_k2=leaves[:, 3].astype(np.int16),
        leaf_meth=leaves[:, 4].astype(np.uint8), leaf_opt=leaves[:, 5].astype(np.uint8),
        leaf_aux=leaves[:, 6].astype(np.int16))
    with open(os.path.join(outdir, "bandstar_slope.json"), "w") as f:
        json.dump(slope, f, separators=(",", ":"))
        f.write("\n")
    return len(results), len(leaves), len(slope)


def compare_published(lines, path):
    pub = {}
    with open(path) as f:
        for ln in f:
            d = json.loads(ln)
            pub[tuple(d["box"])] = (d["ok"], d["nbox"])
    same = sum(1 for d in lines if pub.get(tuple(d["box"])) == (d["ok"], d["nbox"]))
    return dict(published_squares=len(pub), recorded_squares=len(lines), identical=same,
                differ=len(lines) - same, missing=len(set(pub) - {tuple(d["box"]) for d in lines}))


def run_all(step, nproc, outdir, min_step=1 / 8192):
    boxes = vb.ab_boxes(step)
    t0 = time.time()
    log = dict(levels=[], certified=0, lam_m_boxes=0)
    stats, results, lines = {}, [], []
    with Pool(nproc) as pool:
        while boxes:
            print(f"level step {step}: {len(boxes)} (a,b) squares", flush=True)
            bad, nb = [], 0
            for i, r in enumerate(pool.imap_unordered(record_square, boxes, chunksize=1)):
                nb += r["nbox"]
                if not r["ok"]:
                    bad.append(r["box"])
                else:
                    for k, v in r["stats"].items():
                        stats[k] = stats.get(k, 0) + v
                    results.append(r)
                lines.append(dict(box=r["box"], ok=r["ok"], nbox=r["nbox"], sec=round(r["sec"], 2)))
                if i % 200 == 0:
                    print(f"  {i}/{len(boxes)}  {time.time()-t0:.0f}s  bad so far {len(bad)}", flush=True)
            log["levels"].append(dict(step=step, squares=len(boxes), not_certified=len(bad), lam_m_boxes=nb))
            log["certified"] += len(boxes) - len(bad)
            log["lam_m_boxes"] += nb
            if not bad:
                break
            if step / 2 < min_step:
                log["uncertified"] = bad
                break
            step /= 2
            boxes = []
            for (a1, a2, b1, b2) in bad:
                am, bm = (a1 + a2) / 2, (b1 + b2) / 2
                for q in ((a1, am, b1, bm), (am, a2, b1, bm), (a1, am, bm, b2), (am, a2, bm, b2)):
                    if q[0] + q[2] < vb.RHO0F:
                        boxes.append(q)
    log["certified_by"] = stats
    log["sec"] = round(time.time() - t0, 1)
    with open(os.path.join(outdir, "record_squares.jsonl"), "w") as f:
        for d in lines:
            f.write(json.dumps(d) + "\n")
    return log, results, lines


if __name__ == "__main__":
    assert md5(os.path.join(HERE, "verify_bandstar.py")) == VB_MD5, "verify_bandstar.py is not the refereed version"
    assert "BANDSTAR_TGT_SHIFT" not in os.environ, "the target shift must be unset"
    mode = sys.argv[1] if len(sys.argv) > 1 else "all"
    if mode == "all":
        nproc = int(sys.argv[2]) if len(sys.argv) > 2 else 8
        outdir = sys.argv[3] if len(sys.argv) > 3 else os.path.join(HERE, "..", "outputs", "bandstar_cert")
        os.makedirs(outdir, exist_ok=True)
        print("start", time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()), flush=True)
        log, results, lines = run_all(1 / 128, nproc, outdir)
        print(json.dumps(log), flush=True)
        nsq, nleaf, nslope = write_record(results, outdir)
        cmp = compare_published(lines, os.path.join(HERE, "..", "outputs", "verify_bandstar_squares.jsonl"))
        summary = dict(run_all=log, record=dict(squares=nsq, leaves=nleaf, slope_leaves=nslope),
                       comparison_with_published_run=cmp)
        with open(os.path.join(outdir, "record_summary.json"), "w") as f:
            json.dump(summary, f, indent=1)
            f.write("\n")
        print(json.dumps(summary["record"]), json.dumps(cmp), flush=True)
        print("end", time.strftime("%Y-%m-%d %H:%M:%S UTC", time.gmtime()), flush=True)
    elif mode == "one":
        box = tuple(float(x) for x in sys.argv[2].split(","))
        outdir = sys.argv[3]
        os.makedirs(outdir, exist_ok=True)
        r = record_square(box)
        print(json.dumps(dict(box=r["box"], ok=r["ok"], nbox=r["nbox"], stats=r["stats"], sec=round(r["sec"], 1))))
        if r["ok"]:
            print(write_record([r], outdir))
