"""Float prototype (evidence only, never proof): per-(box, cell) LP for the 'plus' design.

Value = sup E h(Y) over: laws nu of Y on a grid, rests W (measures on a grid of [xlo, xhi], mass mu0, cell
constraints kappa_3 = int x dW in [k3lo, k3hi], kappa_4 = int x^2 dW in [k4lo, k4hi]), and free product variables
w_alpha (products of >= 2 cumulants kappa_j, j >= 3) tied to the cumulants by recursive McCormick envelopes with
per-cell ranges [L_j, U_j] of kappa_j (computed by LP over W in the cell), as in RQ-B's numerics/cell_whole_lp.py,
and optionally by Chebyshev's sum inequality |w_alpha| <= mu0^(|alpha|-1) int |x|^(s_alpha) dW.
Moments of Y: E Y^k = moment polynomial of the cumulants (kappa_2 = mu0), k < D; E Y^D <= it.
h(r) = sum_N pi_N |c_N + r| (shift law of the conditioned chord atoms). The dual of this LP is the certificate
shape (polynomial phi >= h, dual polynomial in x, McCormick multipliers).
"""
import math
import sys

import numpy as np
from scipy.optimize import linprog

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from heavy_box_lp import A, TAU, alpha_coeffs


def prod_range(al, L, U):
    lo, hi = 1.0, 1.0
    for j in al:
        cands = [lo * L[j], lo * U[j], hi * L[j], hi * U[j]]
        lo, hi = min(cands), max(cands)
    return lo, hi


def cell_lp(c, p, mu0, D, cell=None, xlo=-A, xhi=TAU, nx=201, nr=2001, L=None, caps=(), cheb=True,
            mcc=True, verbose=False, return_res=False):
    sig = math.sqrt(max(mu0, 1e-6))
    if L is None:
        L = max(6.0, 9.0 * sig + 2.0)
    r = np.linspace(-L, L, nr)
    r = np.unique(np.concatenate([r, -c[np.abs(c) < L]]))
    h = np.abs(c[None, :] + r[:, None]) @ p
    x = np.unique(np.concatenate([np.linspace(xlo, xhi, nx), [0.0, xlo, xhi], [cx for cx, _ in caps]]))
    nR, nX = len(r), len(x)
    # base constraints on W alone (for the kappa ranges)
    ub, ubr = [], []
    for cx, cap in caps:
        row = np.zeros(nX); row[int(np.argmin(np.abs(x - cx)))] = 1.0
        ub.append(row); ubr.append(cap)
    if cell is not None:
        k3lo, k3hi, k4lo, k4hi = cell
        ub += [x, -x, x ** 2, -x ** 2]
        ubr += [k3hi, -k3lo, k4hi, -k4lo]
    eq, eqr = [np.ones(nX)], [mu0]
    Lr, Ur = {}, {}
    for j in range(3, D + 1):
        f = x ** (j - 2)
        kw = dict(A_ub=np.array(ub) if ub else None, b_ub=np.array(ubr) if ub else None, A_eq=np.array(eq),
                  b_eq=np.array(eqr), bounds=(0, None), method="highs")
        lo = linprog(f, **kw)
        hi = linprog(-f, **kw)
        if lo.status != 0 or hi.status != 0:
            return (float("nan"), None) if not return_res else (float("nan"), None, None)
        Lr[j], Ur[j] = lo.fun, -hi.fun
    cof = alpha_coeffs(D, mu0)
    prods = set()
    for k in range(D + 1):
        for al in cof[k]:
            if len(al) >= 2:
                for t in range(2, len(al) + 1):
                    prods.add(tuple(sorted(al[:t])))
    prods = sorted(prods, key=lambda t: (len(t), t))
    pidx = {al: i for i, al in enumerate(prods)}
    nW = len(prods)
    nv = nR + nX + nW
    oK, oW = nR, nR + nX

    def lin_kappa(j):
        row = np.zeros(nv); row[oK:oK + nX] = x ** (j - 2); return row

    rows_eq, rhs_eq, rows_ub, rhs_ub = [], [], [], []
    row = np.zeros(nv); row[:nR] = 1.0; rows_eq.append(row); rhs_eq.append(1.0)
    row = np.zeros(nv); row[oK:oK + nX] = 1.0; rows_eq.append(row); rhs_eq.append(mu0)
    for g, gr in zip(ub, ubr):
        row = np.zeros(nv); row[oK:oK + nX] = g; rows_ub.append(row); rhs_ub.append(gr)
    for k in range(1, D + 1):
        sk = max(1.0, (max(sig, 0.5) * 1.5) ** k * math.prod(range(k - 1, 0, -2)))
        row = np.zeros(nv); row[:nR] = r ** k / sk
        for al, v in cof[k].items():
            if len(al) == 1:
                row -= v * lin_kappa(al[0]) / sk
            elif len(al) >= 2:
                row[oW + pidx[al]] -= v / sk
        rhs = cof[k].get((), 0.0) / sk
        if k < D:
            rows_eq.append(row); rhs_eq.append(rhs)
        else:
            rows_ub.append(row); rhs_ub.append(rhs)
    bounds = [(0, None)] * (nR + nX)
    for al in prods:
        lo_w, hi_w = prod_range(al, Lr, Ur)
        bounds.append((lo_w, hi_w))
        W = np.zeros(nv); W[oW + pidx[al]] = 1.0
        if mcc:
            pre, j = al[:-1], al[-1]
            if len(pre) == 1:
                Xrow = lin_kappa(pre[0]); XL, XU = Lr[pre[0]], Ur[pre[0]]
            else:
                Xrow = np.zeros(nv); Xrow[oW + pidx[pre]] = 1.0; XL, XU = prod_range(pre, Lr, Ur)
            Yrow = lin_kappa(j); YL, YU = Lr[j], Ur[j]
            sc = max(1.0, abs(XL * YL), abs(XU * YU), abs(XL * YU), abs(XU * YL))
            rows_ub.append((-W + XL * Yrow + YL * Xrow) / sc); rhs_ub.append(XL * YL / sc)
            rows_ub.append((-W + XU * Yrow + YU * Xrow) / sc); rhs_ub.append(XU * YU / sc)
            rows_ub.append((W - XU * Yrow - YL * Xrow) / sc); rhs_ub.append(-XU * YL / sc)
            rows_ub.append((W - XL * Yrow - YU * Xrow) / sc); rhs_ub.append(-XL * YU / sc)
        if cheb:
            s = sum(i - 2 for i in al)
            dens = mu0 ** (len(al) - 1) * np.abs(x) ** s
            sc = max(1.0, float(dens.max()))
            row = W / sc; row = row.copy(); row[oK:oK + nX] = -dens / sc
            rows_ub.append(row); rhs_ub.append(0.0)
            row = -W / sc; row = row.copy(); row[oK:oK + nX] = -dens / sc
            rows_ub.append(row); rhs_ub.append(0.0)
    cobj = np.zeros(nv); cobj[:nR] = -h
    res = linprog(cobj, A_ub=np.array(rows_ub), b_ub=np.array(rhs_ub), A_eq=np.array(rows_eq),
                  b_eq=np.array(rhs_eq), bounds=bounds, method="highs")
    if res.status != 0:
        if verbose:
            print("LP status", res.status, res.message)
        return (float("nan"), None) if not return_res else (float("nan"), None, None)
    Kw = res.x[oK:oK + nX]
    supp = [(round(float(xx), 3), round(float(kk), 4)) for xx, kk in zip(x, Kw) if kk > 1e-4]
    if return_res:
        return -res.fun, supp, res
    return -res.fun, supp
