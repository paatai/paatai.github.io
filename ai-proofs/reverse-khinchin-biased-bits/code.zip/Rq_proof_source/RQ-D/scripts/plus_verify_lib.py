"""Exact (python-flint arb) checks for the F_heavy 'plus' certificates.

Every inequality below is decided with arb balls or exact fmpq arithmetic; floating-point numbers enter only as
certificate data (each double is an exact dyadic rational).

Setting: tau = 17/20, A = 77/50, v = 1/2. A box B = [a_lo, a_hi] x [b_lo, b_hi] of chord rates (a+, b+) at
(tau, A) has
  mu_B  = 1 - max(Q(a_hi, b_hi), v) + (a_hi - a_lo) tau^2 + (b_hi - b_lo) A^2,
  cap_B = (b_hi - b_lo) A^2,
  h_B(r) = E|tau (N_a - a_lo) + A (N_b - b_lo) + r|,  N_a ~ Poi(a_lo), N_b ~ Poi(b_lo) independent,
where Q(a, b) = (a tau + b A)^2 / (a + b) and M(a, b) = a tau^2 + b A^2. The rest W'' ranges over the measures on
[-A, tau] u {A} of mass mu_B with W''({A}) <= cap_B; kappa_2 = mu_B and kappa_j = int x^(j-2) dW'' for j >= 3.
A cell is a rectangle k3 in [k3lo, k3hi], k4 in [k4lo, k4hi] for (kappa_3, kappa_4).

A certificate for (B, cell) consists of phi(r) = sum_{k <= D} c_k r^k and Lagrange multipliers. It proves
  sup over W'' in the cell of E h_B(Z_{W''}) <= bound
through (i) h_B <= phi + eps_phi on R and (ii) a Lagrangian upper bound for sum_k c_k E Z_{W''}^k, in which every
product of >= 2 cumulants kappa_j (j >= 3) is a free variable w_alpha tied to the cumulants by recursive McCormick
inequalities on the cell's cumulant ranges and by Hoelder's inequality
  |prod_i kappa_{alpha_i}| <= mu_B^(t-1) int |x|^(s_alpha) dW'',  t = |alpha|, s_alpha = sum_i (alpha_i - 2).
"""
import math
from functools import lru_cache

from flint import arb, ctx, fmpq

ctx.prec = 128

TAU_Q = fmpq(17, 20)
A_Q = fmpq(77, 50)
V_Q = fmpq(1, 2)
VMAX_Q = fmpq(4, 5)
TAU = arb(TAU_Q)
A = arb(A_Q)
C5 = arb("1.28") * (2 * (arb(5) / 4).log()).sqrt()


def to_arb(x):
    """Exact conversion: fmpq, int, or a Python float (an exact dyadic rational)."""
    if isinstance(x, arb):
        return x
    if isinstance(x, (fmpq, int)):
        return arb(x)
    if isinstance(x, float):
        if not math.isfinite(x):
            raise ValueError("non-finite certificate entry")
        n, d = x.as_integer_ratio()
        return arb(fmpq(n, d))
    if isinstance(x, str):
        return to_arb(float(x))
    raise TypeError(type(x))


def exact_lo(x):
    return arb(x.lower())


def exact_hi(x):
    return arb(x.upper())


def amax(x, y):
    return x.max(y)


def amin(x, y):
    return x.min(y)


# ----------------------------------------------------------------------------------------------- box geometry

def Qq(a, b):
    if a + b == 0:
        return fmpq(0)
    return (a * TAU_Q + b * A_Q) ** 2 / (a + b)


def Mq(a, b):
    return a * TAU_Q ** 2 + b * A_Q ** 2


def box_info(a_lo, a_hi, b_lo, b_hi):
    """Exact. empty = no chord rates in the box are compatible with V+ in [v, 4/5): Q and M are nondecreasing in
    a and b, so the box misses {Q < 4/5, M >= v} iff Q(a_lo, b_lo) >= 4/5 or M(a_hi, b_hi) < v."""
    empty = Qq(a_lo, b_lo) >= VMAX_Q or Mq(a_hi, b_hi) < V_Q
    qh = Qq(a_hi, b_hi)
    mu = 1 - (qh if qh > V_Q else V_Q) + (a_hi - a_lo) * TAU_Q ** 2 + (b_hi - b_lo) * A_Q ** 2
    cap = (b_hi - b_lo) * A_Q ** 2
    return dict(empty=empty, mu=mu, cap=cap)


def root_cell(mu, cap):
    """Exact rectangle containing (kappa_3, kappa_4) of every admissible W''."""
    return (-A_Q * mu, TAU_Q * mu + (A_Q - TAU_Q) * cap, fmpq(0), A_Q ** 2 * mu)


def cell_of(root, level, i, j):
    k3a, k3b, k4a, k4b = root
    n = 2 ** level
    w3, w4 = (k3b - k3a) / n, (k4b - k4a) / n
    return (k3a + i * w3, k3a + (i + 1) * w3, k4a + j * w4, k4a + (j + 1) * w4)


# ------------------------------------------------------------------------------------------ moment structure

@lru_cache(maxsize=None)
def moment_polys(D):
    """m[n] = {(p2, alpha): integer}: E Z^n = sum coef * kappa_2^p2 * prod_i kappa_{alpha_i}, alpha sorted, all
    alpha_i >= 3 (kappa_1 = 0). Recursion E Z^n = sum_{i=2}^n C(n-1, i-1) kappa_i E Z^(n-i)."""
    m = [dict() for _ in range(D + 1)]
    m[0][(0, ())] = 1
    for n in range(1, D + 1):
        acc = {}
        for i in range(2, n + 1):
            c = math.comb(n - 1, i - 1)
            for (p2, al), v in m[n - i].items():
                key = (p2 + 1, al) if i == 2 else (p2, tuple(sorted(al + (i,))))
                acc[key] = acc.get(key, 0) + c * v
        m[n] = acc
    return m


@lru_cache(maxsize=None)
def products(D):
    """Canonical list of the product variables: every alpha with >= 2 entries occurring in some E Z^k, k <= D,
    together with all its prefixes of length >= 2."""
    m = moment_polys(D)
    ps = set()
    for k in range(D + 1):
        for (_, al) in m[k]:
            for t in range(2, len(al) + 1):
                ps.add(al[:t])
    return tuple(sorted(ps, key=lambda t: (len(t), t)))


# ------------------------------------------------------------------------------------- rigorous polynomial sup

def taylor_shift(p, m):
    """Coefficients of p(m + t) (Ruffini-Horner)."""
    q = list(p)
    n = len(q)
    for i in range(n):
        for k in range(n - 2, i - 1, -1):
            q[k] = q[k] + m * q[k + 1]
    return q


def _piece_ub(p, m, d):
    q = taylor_shift(p, m)
    ub = q[0]
    dk = arb(1)
    for k in range(1, len(q)):
        dk = dk * d
        if k % 2:
            ub = ub + abs(q[k]) * dk
        else:
            ub = ub + q[k].max(arb(0)) * dk
    return ub.upper(), q[0]


def _mid_exact(a, b):
    return arb(((a + b) / 2).mid())


def poly_sup(p, lo, hi, tol=1e-9, n0=8, maxdepth=40):
    """Rigorous upper bound (an exact arb) for sup p over [lo, hi] (over the hull of the balls lo, hi);
    p = ascending arb coefficients. Branch and bound on exact-endpoint pieces covering the interval; on a piece
    [a, b] with exact centre m and d >= max(m - a, b - m): p(m + t) = sum q_k t^k <= q_0 + sum_odd |q_k| d^k +
    sum_even max(q_k, 0) d^k. Within about tol of the true sup unless maxdepth is hit."""
    lo, hi = exact_lo(arb(lo)), exact_hi(arb(hi))
    if len(p) == 0:
        return arb(0)
    if len(p) == 1:
        return exact_hi(p[0])
    pts = [lo] + [arb((lo + (hi - lo) * i / n0).mid()) for i in range(1, n0)] + [hi]
    pieces = [(pts[i], pts[i + 1], 0) for i in range(n0)]
    best_lb = None
    final_ub = None
    while pieces:
        ev = []
        for a, b, dep in pieces:
            m = _mid_exact(a, b)
            d = exact_hi((m - a).max(b - m))
            ub, val = _piece_ub(p, m, d)
            if not ub.is_finite():
                raise ValueError("poly_sup: non-finite piece bound")
            if best_lb is None or val.lower() > best_lb:
                best_lb = val.lower()
            ev.append((ub, a, b, dep, m))
        pieces = []
        for ub, a, b, dep, m in ev:
            if ub > best_lb + tol and dep < maxdepth:
                pieces.append((a, m, dep + 1))
                pieces.append((m, b, dep + 1))
            elif final_ub is None or ub > final_ub:
                final_ub = ub
    return arb(final_ub)


def poly_eval(p, x):
    s = arb(0)
    for c in reversed(p):
        s = s * x + c
    return s


def padd(p, q, s=1):
    n = max(len(p), len(q))
    out = [arb(0)] * n
    for i, c in enumerate(p):
        out[i] = out[i] + c
    for i, c in enumerate(q):
        out[i] = out[i] + s * c
    return out


# ------------------------------------------------------------------------------- affine forms in (W'', w)

class Aff:
    """const + int P(x) dW''(x) + int sum_s g_s |x|^s dW''(x) + sum_alpha e_alpha w_alpha."""

    def __init__(self, D):
        self.c = arb(0)
        self.P = [arb(0)] * (D - 1)
        self.g = {}
        self.e = {}

    def add_kappa(self, j, s):
        self.P[j - 2] = self.P[j - 2] + s

    def add_w(self, al, s):
        self.e[al] = self.e.get(al, arb(0)) + s

    def add_abs(self, sx, s):
        self.g[sx] = self.g.get(sx, arb(0)) + s

    def add_var(self, var, s):
        """var = ('k', j) or ('w', alpha)."""
        if var[0] == 'k':
            self.add_kappa(var[1], s)
        else:
            self.add_w(var[1], s)


def R_on_sides(aff):
    """R(x) = P(x) + sum_s g_s |x|^s as two ordinary polynomials: on [-A, 0] and on [0, tau]."""
    n = max([len(aff.P)] + [s + 1 for s in aff.g])
    neg = list(aff.P) + [arb(0)] * (n - len(aff.P))
    pos = list(neg)
    for s, gs in aff.g.items():
        pos[s] = pos[s] + gs
        neg[s] = neg[s] + (gs if s % 2 == 0 else -gs)
    return neg, pos


# --------------------------------------------------------------------------------- cumulant ranges on a cell

def range_bound(j, mu, cap, cell, s3, s4, upper, tol=1e-10):
    """Rigorous bound for kappa_j over the cell, from g(x) = x^(j-2) - s3 x - s4 x^2:
    kappa_j = int g dW'' + s3 kappa_3 + s4 kappa_4, and with W''([-A, tau]) = mu - m_A, m_A in [0, cap]:
    int g dW'' <= mu sup g + cap max(0, g(A) - sup g)  (sup over [-A, tau]); symmetrically for the lower bound."""
    k3lo, k3hi, k4lo, k4hi = (to_arb(x) for x in cell)
    s3, s4 = to_arb(s3), to_arb(s4)
    P = [arb(0)] * (max(j - 2, 2) + 1)
    P[j - 2] = P[j - 2] + 1
    P[1] = P[1] - s3
    P[2] = P[2] - s4
    sgn = 1 if upper else -1
    Ps = [sgn * c for c in P]
    S = poly_sup(Ps, -A, TAU, tol=tol)
    gA = poly_eval(Ps, A)
    val = to_arb(mu) * S + to_arb(cap) * (gA - S).max(arb(0))
    t3 = (s3 * k3lo * sgn).max(s3 * k3hi * sgn)
    t4 = (s4 * k4lo * sgn).max(s4 * k4hi * sgn)
    b = val + t3 + t4
    return exact_lo(-b) if not upper else exact_hi(b)


def empty_bound(mu, cap, cell, s3, s4, tol=1e-10):
    """Exact upper bound for Phi(s3, s4) = sup over W'' of 0 = int (-s3 x - s4 x^2) dW'' + s3 kappa_3 + s4 kappa_4
    (bounded as in range_bound). If it is < 0, no admissible W'' has (kappa_3, kappa_4) in the cell."""
    k3lo, k3hi, k4lo, k4hi = (to_arb(x) for x in cell)
    s3, s4 = to_arb(s3), to_arb(s4)
    P = [arb(0), -s3, -s4]
    S = poly_sup(P, -A, TAU, tol=tol)
    gA = poly_eval(P, A)
    b = to_arb(mu) * S + to_arb(cap) * (gA - S).max(arb(0))
    b = b + (s3 * k3lo).max(s3 * k3hi) + (s4 * k4lo).max(s4 * k4hi)
    return exact_hi(b)


def kappa_ranges(D, mu, cap, cell, rmult):
    """rmult[j] = (s3_lo, s4_lo, s3_hi, s4_hi). Returns dicts L, U of exact arbs (valid bounds for kappa_j)."""
    k3lo, k3hi, k4lo, k4hi = (to_arb(x) for x in cell)
    L, U = {}, {}
    for j in range(3, D + 1):
        s3l, s4l, s3h, s4h = rmult[j]
        L[j] = range_bound(j, mu, cap, cell, s3l, s4l, upper=False)
        U[j] = range_bound(j, mu, cap, cell, s3h, s4h, upper=True)
    L[3], U[3] = L[3].max(exact_lo(k3lo)), U[3].min(exact_hi(k3hi))
    L[4], U[4] = L[4].max(exact_lo(k4lo)), U[4].min(exact_hi(k4hi))
    return L, U


def prod_range(al, L, U):
    lo, hi = arb(1), arb(1)
    for j in al:
        cands = [lo * L[j], lo * U[j], hi * L[j], hi * U[j]]
        lo = arb(min(z.lower() for z in cands))
        hi = arb(max(z.upper() for z in cands))
    return lo, hi


# ---------------------------------------------------------------------------------------- the shift law, h

def pois_trunc(lam, extra=20):
    """[(n, P(N = n))] for n <= nmax, and an upper bound for P(N > nmax); lam an exact arb."""
    if lam == 0:
        return [(0, arb(1))], arb(0)
    lf = float(lam.mid())
    nmax = int(lf + 12 * math.sqrt(lf) + extra)
    out = []
    t = (-lam).exp()
    s = arb(0)
    for n in range(nmax + 1):
        if n > 0:
            t = t * lam / n
        out.append((n, t))
        s = s + t
    tail = exact_hi(arb(1) - s).max(arb(0))
    return out, tail


def h_data(a_lo, b_lo):
    """Atoms c_N (exact fmpq) and probabilities pi_N (arb) of the truncated shift law, the tail mass bound T and
    E C^2 (exact)."""
    pa, ta = pois_trunc(arb(a_lo))
    pb, tb = pois_trunc(arb(b_lo))
    atoms = []
    for n, p in pa:
        for m_, q in pb:
            atoms.append((TAU_Q * (n - a_lo) + A_Q * (m_ - b_lo), p * q))
    atoms.sort(key=lambda z: z[0])
    return atoms, exact_hi(ta + tb), TAU_Q ** 2 * a_lo + A_Q ** 2 * b_lo


def tail_coeffs(c, a_lo, b_lo, Lt):
    """Taylor coefficients in t >= 0 of phi(Lt + t) - (Lt + t) and of phi(-Lt - t) - (Lt + t) - delta, where
    delta >= 2 E(C - Lt)_+. Valid tail majorants: for r >= Lt >= tau a_lo + A b_lo >= -min C, h_B(r) = r exactly;
    for r <= -Lt, h_B(r) = -r + 2 E(C - |r|)_+ <= -r + delta. All coefficients >= 0 implies phi >= h_B on
    |r| >= Lt. Returns None if Lt < tau a_lo + A b_lo."""
    Lt_q = Lt if isinstance(Lt, fmpq) else fmpq(*float(Lt).as_integer_ratio())
    if Lt_q < TAU_Q * a_lo + A_Q * b_lo:
        return None
    LtA = arb(Lt_q)
    atoms, T, EC2 = h_data(a_lo, b_lo)
    dl = arb(0)
    for x, p in atoms:
        if x > Lt_q:
            dl = dl + p * arb(x - Lt_q)
    if T > 0:
        dl = dl + (T * arb(EC2)).sqrt()
    delta = 2 * dl
    cs = [to_arb(x) for x in c]
    out = []
    for sgn in (1, -1):
        q = taylor_shift([ci * (sgn ** k) for k, ci in enumerate(cs)], LtA)
        q[0] = q[0] - LtA - (delta if sgn == -1 else 0)
        q[1] = q[1] - 1
        out.append(q)
    return out


def phi_check(c, a_lo, b_lo, Lt, tol=1e-9):
    """Rigorous eps >= 0 with h_B <= phi + eps on R, or None if the tail test (tail_coeffs) fails at Lt.
    On [-Lt, Lt]: h_B(r) <= h_tr(r) + T |r| + sqrt(T E C^2) (Cauchy-Schwarz on the Poisson tail), checked piece by
    piece between the kinks of h_tr and 0."""
    tq = tail_coeffs(c, a_lo, b_lo, Lt)
    if tq is None or any(not (qq >= 0) for q in tq for qq in q):
        return None
    cs = [to_arb(x) for x in c]
    atoms, T, EC2 = h_data(a_lo, b_lo)
    Lt_q = Lt if isinstance(Lt, fmpq) else fmpq(*float(Lt).as_integer_ratio())
    extra = (T * arb(EC2)).sqrt() if T > 0 else arb(0)
    kinks = sorted(set([-x for x, _ in atoms if -Lt_q < -x < Lt_q] + [fmpq(0)]))
    pts = [-Lt_q] + kinks + [Lt_q]
    # slope/intercept of h_tr on (pts[i], pts[i+1]): sign(c_N + r) = +1 iff -c_N <= pts[i]
    tot_p = arb(0)
    tot_pc = arb(0)
    for x, p in atoms:
        tot_p += p
        tot_pc += p * arb(x)
    # start left of everything inside: all atoms with -c_N <= -Lt are 'positive'
    pos_p, pos_pc = arb(0), arb(0)
    idx = 0
    atoms_by_kink = sorted(atoms, key=lambda z: -z[0])
    worst = arb(0)
    for i in range(len(pts) - 1):
        lo, hi = pts[i], pts[i + 1]
        while idx < len(atoms_by_kink) and -atoms_by_kink[idx][0] <= lo:
            x, p = atoms_by_kink[idx]
            pos_p += p
            pos_pc += p * arb(x)
            idx += 1
        neg_p, neg_pc = tot_p - pos_p, tot_pc - pos_pc
        s = pos_p - neg_p
        t = pos_pc - neg_pc
        s_abs = T if lo >= 0 else -T
        # phi - (s + s_abs) r - t - extra >= -eps on [lo, hi]
        g = [-ci for ci in cs]
        g[0] = g[0] + t + extra
        g[1] = g[1] + s + s_abs
        sup = poly_sup(g, arb(lo), arb(hi), tol=tol)
        if sup > worst:
            worst = sup
    return exact_hi(worst.max(arb(0)))


# ------------------------------------------------------------------------------------- the Lagrangian bound

def objective(c, D, mu):
    """F = sum_k c_k E Z^k as an affine form (products as w variables)."""
    m = moment_polys(D)
    F = Aff(D)
    muA = arb(mu)
    for k in range(D + 1):
        ck = to_arb(c[k])
        for (p2, al), v in m[k].items():
            coef = ck * v * muA ** p2
            if len(al) == 0:
                F.c = F.c + coef
            elif len(al) == 1:
                F.add_kappa(al[0], coef)
            else:
                F.add_w(al, coef)
    return F


def lagrangian_bound(c, D, mu, cap, cell, L, U, mult, tol=1e-9, debug=False):
    """mult = dict(cell=(s1, s2, s3, s4), mcc={alpha: (e1, e2, e3, e4)}, cheb={alpha: (tp, tm)}); negative
    entries are replaced by 0. Returns an exact arb upper bound for sup over W'' in the cell of
    sum_k c_k E Z_{W''}^k."""
    muA, capA = arb(mu), arb(cap)
    k3lo, k3hi, k4lo, k4hi = (to_arb(x) for x in cell)
    Lg = objective(c, D, mu)
    pos = lambda z: to_arb(z).max(arb(0))
    s1, s2, s3, s4 = (pos(z) for z in mult["cell"])
    Lg.c = Lg.c + s1 * k3hi - s2 * k3lo + s3 * k4hi - s4 * k4lo
    Lg.add_kappa(3, s2 - s1)
    Lg.add_kappa(4, s4 - s3)
    prods = products(D)
    rng = {}
    for al in prods:
        rng[al] = prod_range(al, L, U)
    for al in prods:
        t = len(al)
        pre, j = al[:-1], al[-1]
        if al in mult["mcc"]:
            e1, e2, e3, e4 = (pos(z) for z in mult["mcc"][al])
            if len(pre) == 1:
                Xv, (XL, XU) = ('k', pre[0]), (L[pre[0]], U[pre[0]])
            else:
                Xv, (XL, XU) = ('w', pre), rng[pre]
            Yv, YL, YU = ('k', j), L[j], U[j]
            # e1 (w - XL Y - YL X + XL YL) + e2 (w - XU Y - YU X + XU YU)
            # + e3 (-w + XU Y + YL X - XU YL) + e4 (-w + XL Y + YU X - XL YU), each >= 0 at w = XY
            Lg.add_w(al, e1 + e2 - e3 - e4)
            Lg.add_var(Yv, -e1 * XL - e2 * XU + e3 * XU + e4 * XL)
            Lg.add_var(Xv, -e1 * YL - e2 * YU + e3 * YL + e4 * YU)
            Lg.c = Lg.c + e1 * XL * YL + e2 * XU * YU - e3 * XU * YL - e4 * XL * YU
        if al in mult["cheb"]:
            tp, tm = (pos(z) for z in mult["cheb"][al])
            sx = sum(i - 2 for i in al)
            # tp (mu^(t-1) int |x|^s - w) + tm (mu^(t-1) int |x|^s + w) >= 0
            Lg.add_abs(sx, (tp + tm) * muA ** (t - 1))
            Lg.add_w(al, tm - tp)
    neg, posr = R_on_sides(Lg)
    S = poly_sup(neg, -A, arb(0), tol=tol).max(poly_sup(posr, arb(0), TAU, tol=tol))
    RA = poly_eval(posr, A)
    bound = Lg.c + muA * S + capA * (RA - S).max(arb(0))
    resid = arb(0)
    for al, e in Lg.e.items():
        lo, hi = rng[al]
        resid = resid + (e * lo).max(e * hi)
    bound = bound + resid
    if debug:
        return exact_hi(bound), dict(const=Lg.c, S=S, RA=RA, resid=resid, neg=neg, pos=posr, e=Lg.e, rng=rng)
    return exact_hi(bound)
