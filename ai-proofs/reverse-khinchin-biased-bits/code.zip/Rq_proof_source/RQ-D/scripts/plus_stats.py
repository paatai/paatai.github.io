"""Descriptive statistics of an F_heavy certificate run (float, from the certificate files; not part of the proof).
Usage: python3 plus_stats.py FILE.jsonl [FILE2.jsonl ...]
"""
import collections
import json
import sys

from verify_plus import box_of


def main():
    recs = []
    for fn in sys.argv[1:]:
        with open(fn) as f:
            recs += [json.loads(line) for line in f if line.strip()]
    lev0 = min(r["box"][0] for r in recs)
    by_level = collections.defaultdict(collections.Counter)
    cells = collections.Counter()
    cell_levels = collections.Counter()
    worst = []
    gap_max, lt_max = 0.0, 0.0
    for r in recs:
        d = r["box"][0] - lev0
        by_level[d][r["status"]] += 1
        if r["status"] != "ok":
            continue
        for c in r["certs"]:
            cells[c["status"]] += 1
            cell_levels[c["cell"][0]] += 1
            if c["status"] == "ok":
                gap_max = max(gap_max, c["bound"] - c["lp"])
                lt_max = max(lt_max, c["Lt"])
                worst.append((c["bound"], tuple(r["box"]), tuple(c["cell"])))
    print(f"{len(recs)} boxes; initial grid 2^{lev0} x 2^{lev0}")
    print("box level (side = root / 2^(4+d)): ok, empty")
    for d in sorted(by_level):
        print(f"  d = {d}: {by_level[d]['ok']:4d} certified, {by_level[d]['empty']:4d} empty")
    print("cell certificates by status:", dict(cells))
    print("cell certificates by cell level:", dict(sorted(cell_levels.items())))
    print(f"max (stored bound - float LP value) = {gap_max:.2e}; max L_t = {lt_max:.3f}")
    worst.sort(reverse=True)
    print("largest stored cell bounds (float):")
    for b, box, cell in worst[:8]:
        a_lo, a_hi, b_lo, b_hi = (float(z) for z in box_of(*box))
        print(f"  {b:.6f}  box {box} = [{a_lo:.4f}, {a_hi:.4f}] x [{b_lo:.4f}, {b_hi:.4f}], cell {cell}")
    hist = collections.Counter(min(int((0.856 - b) / 0.002), 20) for b, _, _ in worst)
    print("stored cell bounds: count with bound in (0.856 - 0.002 (k + 1), 0.856 - 0.002 k]:",
          dict(sorted(hist.items())))


if __name__ == "__main__":
    main()
