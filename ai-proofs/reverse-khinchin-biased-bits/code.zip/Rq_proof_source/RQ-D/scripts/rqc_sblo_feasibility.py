"""Feasibility of the LP measures behind RQ-C's SB_lo (NOTES 22:12 UTC), float evidence only.

RQ-C's far_split_hunt.split_lower takes, at every shift c, the maximum of E_mu|c + Y| over the HiGHS solutions mu of
the moment LPs at the most probable shifts, and relies on each mu being feasible. This script reruns
split_lower's steps for chord mode 4 (the design of Theorem 16 with exact rates), with RQ-C's own code from the team
store, and reports for each mu its largest constraint violation in RQ-C's scaled rows (tolerance 1e-7 there). It then
recomputes SB_lo from the feasible mu only (violation <= 1e-6).
Usage: python3 rqc_sblo_feasibility.py
"""
import hashlib
import math
import os
import sys
import time

import numpy as np

RQC = "/cursor/stores/bot/rq/RQ-C/numerics"
sys.dont_write_bytecode = True
sys.path.insert(0, RQC)
import far_split_hunt as F

D = 16
LAWS = [
    ("row 1 (V+ 0.5)", [(1.18049, 0.5), (-0.85, 0.00089), (0.84980, 0.43735), (-0.83054, 0.05705)], 0.00471, 0.84024),
    ("row 2 (V+ 0.6)", [(1.17958, 0.6), (0.84985, 0.35216), (-0.81986, 0.04326)], 0.00458, 0.84013),
    ("row 3 (V+ 0.75)", [(1.30, 0.75), (0.8498, 0.204), (-0.75, 0.045)], 0.001, 0.83854),
    ("row 4 (V+ 0.7)", [(1.30, 0.7), (0.8498, 0.2688), (-0.75, 0.03)], 0.0012, 0.83690),
    ("row 6 (V+ 0.5)", [(1.18, 0.5), (0.8498, 0.25), (-0.80, 0.248)], 0.002, 0.82031),
]


def violation(lp, mom, mu):
    """Largest violation of the LP rows by mu, in the scaled units of F.ShiftLP (equality rows k = 0..D-1 two-sided,
    row D one-sided)."""
    zm = [mom[k] / lp.sc ** k for k in range(D + 1)]
    z = lp.y / lp.sc
    worst = 0.0
    for k in range(D + 1):
        e0, e1 = 2 * (k // 2), 2 * ((k + 1) // 2)
        s = max(1.0, math.sqrt(zm[e0] * zm[e1]))
        r = (float(np.dot(mu, z ** k)) - zm[k]) / s
        worst = max(worst, r if k == D else abs(r))
    return worst


def main():
    print(f"start {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC")
    for fn in [os.path.abspath(__file__), os.path.join(RQC, "far_split_hunt.py"), os.path.join(RQC, "far_kkt.py")]:
        with open(fn, "rb") as f:
            print(f"md5 {hashlib.md5(f.read()).hexdigest()}  {fn}")
    for name, atoms, wG, sb_rqc in LAWS:
        sa, ts = F.chord_split(atoms, F.THETA, 4)
        big, small, mR, cs, ps = F.split_parts(sa, wG, ts)
        lp = F.ShiftLP(small, wG, D, npts=2001)
        mom = F.residual_moments(small, wG, D)
        sig = ps > 1e-9
        centers = cs[np.argsort(-ps)[:60]]
        mus = []
        for c in centers:
            r = lp.solve(c)
            if r is not None:
                mus.append(r[1])
        viol = np.array([violation(lp, mom, m) for m in mus])
        base = lp.eabs_W(cs)
        H = np.abs(cs[:, None] + lp.y[None, :])

        def sb(sel):
            lo = base.copy()
            if sel.any():
                lo[sig] = np.maximum(base, (H @ np.array(mus)[sel].T).max(axis=1))[sig]
            return float(np.dot(ps, lo))

        ok = viol <= 1e-6
        print(f"{name}: {len(cs)} shifts, {len(mus)} LP measures ({lp.nfail} failed solves); violations: "
              f"{int(ok.sum())} <= 1e-6, {int((viol > 1e-6).sum())} above (largest {viol.max():.3e})")
        print(f"    SB_lo from all measures {sb(np.ones(len(mus), bool)):.5f} (RQ-C's table {sb_rqc:.5f}); "
              f"from the feasible ones only {sb(ok):.5f}")
    print(f"end {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC")


if __name__ == "__main__":
    main()
