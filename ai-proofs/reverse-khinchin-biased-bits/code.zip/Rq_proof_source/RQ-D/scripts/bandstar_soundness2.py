"""Float soundness test of every ingredient of verify_bandstar.py (evidence only, never proof).

For random finitely supported K on [-A, A] with K([theta, A]) >= 1 - R0, compare in floats:
  cB  >= 2E(W - m)_+,  cC2 >= 2E(-W - (2 theta - m))_+  (exact, from the law of W = Z_{K_R}),
  each option for O' (chord of phi, two-point chi^C_h, two-point CS, Taylor chi^B_h) >= E phi(J - m) (exact),
  F >= E|Z_K| (exact), and reports the true margin max(g(Lambda), C5) - E|Z_K|.
The two-point and Taylor options are evaluated with the true sigma_J^2 and with the larger Bhatia-Davis value
(mu1 - theta)(A - mu1) (suffix _box), which tests the monotonicity in sigma^2 used by the verifier.
Two-point option with h > j0 (tpK): chi^C_h(j0) <= kappa + rho^2/(2h), kappa = (h - j0)_+^2/(2h) (psiK_j0), the
option itself (tpK), and, for h with kappa <= d^2 sqrt(Lambda/V), the absorption
2 m e^-Lambda + Lambda e^-Lambda kappa (1 - w) <= sqrt(V) g(Lambda) (absorb) and the resulting bound FK >= E|Z_K|.
Usage: bandstar_soundness2.py [R0] [N] [dirac]; with 'dirac' the main atom of K_S is in [1.3, 1.5] and
K_S has at most one small extra atom (the regime of the slope argument).
"""
import math
import sys

import numpy as np
from scipy.stats import norm

from idlib import gauss_abs, law, mean_abs_small

THETA, A = 0.85, 1.54
R0 = float(sys.argv[1]) if len(sys.argv) > 1 else 0.2
N = int(sys.argv[2]) if len(sys.argv) > 2 else 400
DIRAC = len(sys.argv) > 3 and sys.argv[3] == "dirac"
C5 = 1.28 * math.sqrt(2 * math.log(1.25))
HG = np.geomspace(0.005, 3.0, 80)
g = lambda l: 2 * math.sqrt(l) * math.exp(-l)


def lattice(J, lam):
    if lam <= 0:
        return np.array([0.0]), np.array([1.0])
    nmax = int(lam + 12 * math.sqrt(lam) + 15)
    n = np.arange(nmax + 1)
    p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    return J * (n - lam), p


def Qf(d, s):
    if s <= 0:
        return np.where(d > 0, d * d, 0.0)
    z = d / s
    return (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)


class Cost:
    def __init__(self, a, b):
        self.r2 = a + b
        self.xB, self.wB, self.sB = *lattice(THETA, a / THETA ** 2), math.sqrt(b)
        self.xC, self.wC, self.sC = *lattice(A, b / A ** 2), math.sqrt(a)

    def chi(self, which, t, h=HG):
        x, w, s = (self.xB, self.wB, self.sB) if which == "B" else (self.xC, self.wC, self.sC)
        h = np.atleast_1d(h)
        d = x[:, None] - (t - h)[None, :]
        return (w[:, None] * Qf(d, s)).sum(0) / (2 * h)

    def cs(self, y):
        return math.sqrt(y * y + self.r2) - y

    def phibar(self, y):
        return min(self.chi("C", y).min(), self.cs(y), -2 * y + self.chi("B", -y).min())


def exact_stoploss(vals, probs, s, t):
    """2E(W - t)_+ = E|W - t| - t."""
    return float(np.dot(gauss_abs(vals - t, s), probs)) - t


def run():
    rng = np.random.default_rng(23)
    worst = dict(cB=np.inf, cC2=np.inf, chord=np.inf, tpC=np.inf, tpC_box=np.inf, tpS=np.inf, tpS_box=np.inf,
                 tayB=np.inf, tayB_box=np.inf, tpK=np.inf, psiK_j0=np.inf, absorb=np.inf, FK=np.inf, F=np.inf,
                 true_margin=np.inf, F_margin=np.inf)
    nabs = 0
    for _ in range(N):
        r2 = rng.uniform(0, R0)
        if DIRAC:
            nS = rng.integers(1, 3)
            xs = np.array([rng.uniform(1.3, 1.5), rng.uniform(THETA, A)])[:nS]
            ws = np.array([1.0, rng.uniform(0, 0.05)])[:nS]
            ws = ws / ws.sum() * (1 - r2)
        else:
            nS = rng.integers(1, 4)
            xs = rng.uniform(THETA, A, nS)
            u = rng.random()
            if u < 0.3:
                xs[0] = THETA + rng.uniform(0, 0.03)
            elif u < 0.5:
                xs[0] = rng.uniform(1.3, 1.5)
            ws = rng.dirichlet(np.ones(nS)) * (1 - r2)
        nR = rng.integers(1, 3)
        xr = np.concatenate([rng.uniform(0.1, THETA - 1e-3, nR), -rng.uniform(0.1, A, nR)])
        if rng.random() < 0.4:
            xr[0] = THETA - 0.005
        if rng.random() < 0.3:
            xr[-1] = -A
        wr = rng.dirichlet(np.ones(len(xr))) * r2
        KR = [(float(x), float(w)) for x, w in zip(xr, wr)]
        if rng.random() < 0.3:
            KR = [(x, 0.6 * w) for x, w in KR] + [(0.0, 0.4 * r2)]
        KS = [(float(x), float(w)) for x, w in zip(xs, ws)]
        K = KS + KR
        V = sum(w for _, w in KS)
        Lam = sum(w / x ** 2 for x, w in KS)
        m = sum(w / x for x, w in KS)
        a = sum(w for x, w in KR if x > 0)
        b = sum(w for x, w in KR if x <= 0)
        mu1 = m / Lam
        s2true = max(Lam * V - m * m, 0.0) / Lam ** 2
        s2box = max((mu1 - THETA) * (A - mu1), s2true)
        vals, probs, s = law(KR)
        c = Cost(a, b)
        # exact quantities
        cB_true = exact_stoploss(vals, probs, s, m)
        cC2_true = exact_stoploss(-vals, probs, s, 2 * THETA - m)
        Jx = np.array([x for x, _ in KS])
        Jp = np.array([w / x ** 2 for x, w in KS]) / Lam
        phi_true = sum(p * exact_stoploss(-vals, probs, s, x - m) for x, p in zip(Jx, Jp))
        # bounds
        cB = min(c.chi("B", m).min(), c.cs(m))
        cC2 = min(c.chi("C", 2 * THETA - m).min(), c.cs(2 * THETA - m))
        p1, p2 = c.phibar(THETA - m), c.phibar(A - m)
        p2 = min(c.chi("C", A - m).min(), c.cs(A - m))
        chord = ((A - mu1) * max(p1, p2) + (mu1 - THETA) * p2) / (A - THETA)
        j0, y0, d = THETA - m, mu1 - m, mu1 - THETA
        opts = {"chord": chord}
        for tag, s2 in (("", s2true), ("_box", s2box)):
            if d > 1e-12:
                w = d * d / (s2 + d * d)
                x = y0 + s2 / d
            else:
                w, x = 0.0, j0
            opts["tpC" + tag] = ((1 - w) * c.chi("C", j0) + w * c.chi("C", x)).min()
            if j0 >= 0:
                opts["tpS" + tag] = (1 - w) * c.cs(j0) + w * c.cs(x)
            opts["tayB" + tag] = (-2 * y0 + c.chi("B", -y0) + s2 / (2 * HG)).min()
        P2 = 1 - math.exp(-Lam) * (1 + Lam)
        true = mean_abs_small(K)
        if d > 1e-12:
            kap = np.maximum(HG - j0, 0) ** 2 / (2 * HG)
            w = d * d / (s2true + d * d)
            x = y0 + s2true / d
            worst["psiK_j0"] = min(worst["psiK_j0"], (kap + c.r2 / (2 * HG) - c.chi("C", j0)).min())
            # as in the verifier: far point x >= j0 + d = mu1 - m, weight w <= 1
            lin = (1 - w) * c.r2 / (2 * HG) + c.chi("C", y0)
            opts["tpK"] = ((1 - w) * kap + lin).min()
            okh = kap <= d * d * math.sqrt(Lam / V)
            if okh.any():
                nabs += 1
                lhs = 2 * m * math.exp(-Lam) + Lam * math.exp(-Lam) * kap[okh] * (1 - w)
                worst["absorb"] = min(worst["absorb"], (math.sqrt(V) * g(Lam) - lhs).min())
                FK = (math.sqrt(V) * g(Lam) + math.exp(-Lam) * cB + Lam * math.exp(-Lam) * lin[okh].min()
                      + P2 * cC2)
                worst["FK"] = min(worst["FK"], FK - true)
        Oprime = min(opts.values())
        F = 2 * m * math.exp(-Lam) + math.exp(-Lam) * cB + Lam * math.exp(-Lam) * Oprime + P2 * cC2
        tgt = max(g(Lam), C5)
        worst["cB"] = min(worst["cB"], cB - cB_true)
        worst["cC2"] = min(worst["cC2"], cC2 - cC2_true)
        for k, v in opts.items():
            worst[k] = min(worst[k], v - phi_true)
        worst["F"] = min(worst["F"], F - true)
        worst["true_margin"] = min(worst["true_margin"], tgt - true)
        worst["F_margin"] = min(worst["F_margin"], tgt - F)
        bad = [k for k in ("cB", "cC2", "F", "psiK_j0", "absorb", "FK") if worst[k] < -1e-9]
        bad += [k for k, v in opts.items() if v < phi_true - 1e-9]
        if bad:
            print("UNSOUND", bad, K, flush=True)
    print(f"theta = {THETA}, A = {A}, rho0^2 = {R0}, {N} random K{' (near-Dirac K_S)' if DIRAC else ''}. "
          f"Minimum over the sample of (bound - exact); all must be >= 0 "
          f"(absorb and FK over the {nabs} samples where some h meets the kappa condition; tpK with the far point at mu1 - m):")
    for k, v in worst.items():
        print(f"  {k:12s} {v:+.3e}")


if __name__ == "__main__":
    run()
