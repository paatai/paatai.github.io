"""Float LPs (scipy/HiGHS) that PRODUCE the F_heavy 'plus' certificates. Nothing here is trusted: every
certificate is re-checked in arb by plus_verify_lib (phi_check, kappa_ranges, lagrangian_bound).

For a box B and a cell (see plus_verify_lib):
  1. range_mults: for each j, the dual multipliers (s3, s4) of the LPs min / max int x^(j-2) dW'' over the cell;
     plus_verify_lib.kappa_ranges turns them into rigorous ranges [L_j, U_j].
  2. joint_lp: sup E h_B(Y) over laws of Y on an r-grid with E Y^k = moment polynomial (k < D, top one <=),
     W'' on an x-grid, product variables w_alpha with McCormick (on the rigorous ranges) and Hoelder rows. Its dual
     gives phi = sum c_k r^k (duals of the moment rows) and the multipliers of the cell / McCormick / Hoelder rows.
"""
import math
import sys

import numpy as np
from scipy.optimize import linprog

sys.path.insert(0, __file__.rsplit("/", 1)[0])
import plus_verify_lib as V
from heavy_box_lp import shift_law

TAU, A = 0.85, 1.54


def fl(x):
    return float(x) if not hasattr(x, "mid") else float(x.mid())


def xgrid(nx):
    x = np.unique(np.concatenate([np.linspace(-A, TAU, nx), [0.0]]))
    return np.concatenate([x, [A]])


def base_rows(x, mu, cap, cell):
    """Rows (A_ub, b_ub) on K for the cap and the cell, and the mass row."""
    nX = len(x)
    k3lo, k3hi, k4lo, k4hi = (fl(z) for z in cell)
    ub, ubr = [], []
    row = np.zeros(nX); row[-1] = 1.0
    ub.append(row); ubr.append(fl(cap))
    ub += [x.copy(), -x, x ** 2, -x ** 2]
    ubr += [k3hi, -k3lo, k4hi, -k4lo]
    return np.array(ub), np.array(ubr), np.ones((1, nX)), np.array([fl(mu)])


def farkas_empty(mu, cap, cell, nx=301):
    """(s3, s4) minimising Phi (see plus_verify_lib.empty_bound) over the box |s| <= 1 on the x-grid."""
    x = xgrid(nx)[:-1]
    k3lo, k3hi, k4lo, k4hi = (fl(z) for z in cell)
    mu_, cap_ = fl(mu), fl(cap)
    # variables: s3, s4, z, zA, u3, u4
    cobj = np.array([0, 0, mu_, cap_, 1, 1.0])
    rows, rhs = [], []
    for xi in x:
        rows.append([-xi, -xi ** 2, -1, 0, 0, 0]); rhs.append(0.0)      # -s3 x - s4 x^2 <= z
    rows.append([-A, -A ** 2, -1, -1, 0, 0]); rhs.append(0.0)           # -s3 A - s4 A^2 - z <= zA
    rows += [[k3lo, 0, 0, 0, -1, 0], [k3hi, 0, 0, 0, -1, 0], [0, k4lo, 0, 0, 0, -1], [0, k4hi, 0, 0, 0, -1]]
    rhs += [0.0] * 4
    bounds = [(-1, 1), (-1, 1), (None, None), (0, None), (None, None), (None, None)]
    r = linprog(cobj, A_ub=np.array(rows), b_ub=np.array(rhs), bounds=bounds, method="highs")
    if r.status != 0 or r.fun >= 0:
        return None
    return float(r.x[0]), float(r.x[1])


def range_mults(D, mu, cap, cell, nx=301):
    x = xgrid(nx)
    Aub, bub, Aeq, beq = base_rows(x, mu, cap, cell)
    out = {}
    for j in range(3, D + 1):
        f = x ** (j - 2)
        res = []
        for sgn in (1, -1):
            r = linprog(sgn * f, A_ub=Aub, b_ub=bub, A_eq=Aeq, b_eq=beq, bounds=(0, None), method="highs")
            if r.status != 0:
                return None
            y = r.ineqlin.marginals
            s3, s4 = y[1] - y[2], y[3] - y[4]
            res.append((s3, s4) if sgn == 1 else (-s3, -s4))
        out[j] = (res[0][0], res[0][1], res[1][0], res[1][1])
    return out


def default_L(mu):
    sig = math.sqrt(max(fl(mu), 1e-6))
    return max(7.0, 10.0 * sig + 2.5)


def joint_lp(c, p, D, mu, cap, cell, L, U, nx=201, nr=2001, Lr=None, cheb=True, rounds=5, outer=1.0,
             taylor=True):
    """Exchange method: re-solve with the points of a fine grid where phi < h added to the r-grid.
    The r-grid covers [-outer Lr, outer Lr] (coarser beyond Lr). taylor: also impose (as dual constraints, via
    extra primal columns) the tail test of plus_verify_lib.tail_coeffs at Lt = outer Lr."""
    if Lr is None:
        Lr = default_L(mu)
    Lo = outer * Lr
    r = np.linspace(-Lr, Lr, nr)
    if outer > 1:
        no = int(nr * (outer - 1) / 4) + 2
        r = np.concatenate([r, np.linspace(Lr, Lo, no), -np.linspace(Lr, Lo, no)])
    r = np.unique(np.concatenate([r, -c[np.abs(c) < Lo]]))
    fine = np.unique(np.concatenate([np.linspace(-Lo, Lo, int(40 * nr * outer)), -c[np.abs(c) < Lo]]))
    hf = np.abs(c[None, :] + fine[:, None]) @ p
    tail = None
    if taylor:
        delta = 2 * float(np.sum(p[c > Lo] * (c[c > Lo] - Lo))) + 1e-12
        tail = (Lo, delta)
    out = None
    for _ in range(rounds):
        nxt = _joint_lp(c, p, D, mu, cap, cell, L, U, r, nx, cheb, tail)
        if nxt is None:
            return out
        out = nxt
        d = np.polyval(out[1][::-1], fine) - hf
        new = np.setdiff1d(fine[d < -1e-9], r)
        if len(new) == 0:
            break
        r = np.unique(np.concatenate([r, new]))
    return out


def _joint_lp(c, p, D, mu, cap, cell, L, U, r, nx, cheb, tail=None):
    """Returns (value, phi coefficients, multipliers) or None. L, U: dicts of floats (rigorous ranges).
    tail = (Lt, delta): extra columns whose dual constraints are the Taylor-coefficient conditions
    phi(Lt + t) - (Lt + t) and phi(-Lt - t) - (Lt + t) - delta have coefficients >= 0 in t."""
    mu, cap = fl(mu), fl(cap)
    sig = math.sqrt(max(mu, 1e-6))
    h = np.abs(c[None, :] + r[:, None]) @ p
    x = xgrid(nx)
    nR, nX = len(r), len(x)
    prods = V.products(D)
    pidx = {al: i for i, al in enumerate(prods)}
    nW = len(prods)
    nZ = 2 * (D + 1) if tail is not None else 0
    nv = nR + nX + nW + nZ
    oK, oW, oZ = nR, nR + nX, nR + nX + nW
    mp = V.moment_polys(D)

    def kap(j):
        row = np.zeros(nv); row[oK:oK + nX] = x ** (j - 2); return row

    def wv(al):
        row = np.zeros(nv); row[oW + pidx[al]] = 1.0; return row

    eq_rows, eq_rhs, ub_rows, ub_rhs, tags = [], [], [], [], []
    # monomial moment rows: E Y^i - (moment polynomial without its constant) = constant
    mono, mono_rhs = [], []
    for i in range(D + 1):
        row = np.zeros(nv)
        const = 0.0
        for (p2, al), v in mp[i].items():
            coef = v * mu ** p2
            if len(al) == 0:
                const += coef
            elif len(al) == 1:
                row -= coef * kap(al[0])
            else:
                row -= coef * wv(al)
        mono.append(row); mono_rhs.append(const)
    # Chebyshev rows E T_k(Y / Lc) = sum_i t_ki Lc^-i E Y^i (k < D equalities, k = D an inequality)
    Lc = float(np.max(np.abs(r)))
    tk = [np.polynomial.chebyshev.cheb2poly([0] * k + [1]) for k in range(D + 1)]
    zcols = None
    if tail is not None:
        Lt, delta = tail
        zcols = np.zeros((D + 1, nZ))
        for si, s in enumerate((1.0, -1.0)):
            r0 = s * Lt
            for k in range(D + 1):
                pk = [t * Lc ** (-i) for i, t in enumerate(tk[k])]
                for j in range(len(pk)):
                    tj = sum(pk[i] * math.comb(i, j) * r0 ** (i - j) for i in range(j, len(pk)))
                    zcols[k, si * (D + 1) + j] = s ** j * tj
        zscale = np.maximum(np.abs(zcols).max(axis=0), 1e-300)
        zcols = zcols / zscale
        zg = np.zeros(nZ)
        zg[0], zg[1] = Lt, 1.0
        zg[D + 1], zg[D + 2] = Lt + delta, 1.0
    mom_row = {}
    for k in range(D + 1):
        row = np.zeros(nv)
        row[:nR] = np.polynomial.chebyshev.chebval(r / Lc, [0] * k + [1])
        if zcols is not None:
            row[oZ:oZ + nZ] = zcols[k]
        rhs = 0.0
        for i, t in enumerate(tk[k]):
            if t != 0:
                row += t * Lc ** (-i) * mono[i]
                rhs += t * Lc ** (-i) * mono_rhs[i]
        if k < D:
            mom_row[k] = ('eq', len(eq_rows)); eq_rows.append(row); eq_rhs.append(rhs)
        else:
            mom_row[k] = ('ub', len(ub_rows)); ub_rows.append(row); ub_rhs.append(rhs); tags.append(('mom', k, 1.0))
    row = np.zeros(nv); row[oK:oK + nX] = 1.0; eq_rows.append(row); eq_rhs.append(mu)
    k3lo, k3hi, k4lo, k4hi = (fl(z) for z in cell)
    row = np.zeros(nv); row[oK + nX - 1] = 1.0; ub_rows.append(row); ub_rhs.append(cap); tags.append(('cap',))
    for i, (g, gr) in enumerate([(kap(3), k3hi), (-kap(3), -k3lo), (kap(4), k4hi), (-kap(4), -k4lo)]):
        ub_rows.append(g); ub_rhs.append(gr); tags.append(('cell', i, 1.0))
    bounds = [(0, None)] * (nR + nX)
    rng = {}
    for al in prods:
        lo_w, hi_w = 1.0, 1.0
        for j in al:
            cands = [lo_w * L[j], lo_w * U[j], hi_w * L[j], hi_w * U[j]]
            lo_w, hi_w = min(cands), max(cands)
        rng[al] = (lo_w, hi_w)
    for al in prods:
        bounds.append(rng[al])
        pre, j = al[:-1], al[-1]
        if len(pre) == 1:
            Xrow, (XL, XU) = kap(pre[0]), (L[pre[0]], U[pre[0]])
        else:
            Xrow, (XL, XU) = wv(pre), rng[pre]
        Yrow, YL, YU = kap(j), L[j], U[j]
        W = wv(al)
        sc = max(1.0, abs(XL * YL), abs(XU * YU), abs(XL * YU), abs(XU * YL))
        # rhs - lhs = e-th McCormick product (>= 0); rows written as lhs <= rhs
        for e, (lhs, rhs) in enumerate([(-W + XL * Yrow + YL * Xrow, XL * YL), (-W + XU * Yrow + YU * Xrow, XU * YU),
                                        (W - XU * Yrow - YL * Xrow, -XU * YL), (W - XL * Yrow - YU * Xrow, -XL * YU)]):
            ub_rows.append(lhs / sc); ub_rhs.append(rhs / sc); tags.append(('mcc', al, e, sc))
        if cheb:
            s = sum(i - 2 for i in al)
            dens = mu ** (len(al) - 1) * np.abs(x) ** s
            sc2 = max(1.0, float(dens.max()))
            row = W.copy(); row[oK:oK + nX] -= dens
            ub_rows.append(row / sc2); ub_rhs.append(0.0); tags.append(('cheb', al, 0, sc2))
            row = -W.copy(); row[oK:oK + nX] -= dens
            ub_rows.append(row / sc2); ub_rhs.append(0.0); tags.append(('cheb', al, 1, sc2))
    cobj = np.zeros(nv); cobj[:nR] = -h
    if zcols is not None:
        cobj[oZ:oZ + nZ] = -zg / zscale
        bounds = bounds + [(0, None)] * nZ
    res = linprog(cobj, A_ub=np.array(ub_rows), b_ub=np.array(ub_rhs), A_eq=np.array(eq_rows),
                  b_eq=np.array(eq_rhs), bounds=bounds, method="highs")
    if res.status != 0:
        return None
    ye, yu = res.eqlin.marginals, res.ineqlin.marginals
    coef = np.zeros(D + 1)
    for k in range(D + 1):
        kind, i = mom_row[k]
        y = ye[i] if kind == 'eq' else yu[i]
        for i2, t in enumerate(tk[k]):
            coef[i2] -= y * t * Lc ** (-i2)
    coef = [float(z) for z in coef]
    mult = dict(cell=[0.0] * 4, mcc={}, cheb={})
    for t, y in zip(tags, yu):
        if t[0] == 'cell':
            mult["cell"][t[1]] = max(0.0, -y)
        elif t[0] == 'mcc':
            mult["mcc"].setdefault(t[1], [0.0] * 4)[t[2]] = max(0.0, -y / t[3])
        elif t[0] == 'cheb':
            mult["cheb"].setdefault(t[1], [0.0] * 2)[t[2]] = max(0.0, -y / t[3])
    return -res.fun, coef, mult


SETTINGS = (dict(outer=1.0), dict(outer=1.0, nr=3001, nx=301), dict(outer=1.25), dict(outer=1.0, taylor=False))


def certify(box, cell, D=16, target=None, settings=SETTINGS):
    """box = (a_lo, a_hi, b_lo, b_hi) fmpq; cell = (k3lo, k3hi, k4lo, k4hi) fmpq. Tries the LP settings in turn
    until the rigorous bound is <= target (all of them if target is None); returns the best."""
    a_lo, a_hi, b_lo, b_hi = box
    info = V.box_info(a_lo, a_hi, b_lo, b_hi)
    mu, cap = info["mu"], info["cap"]
    rm = range_mults(D, mu, cap, cell)
    if rm is None:
        fk = farkas_empty(mu, cap, cell)
        if fk is not None and V.empty_bound(mu, cap, cell, *fk) < 0:
            return dict(status="empty_farkas", farkas=fk)
        return dict(status="range_lp_failed")
    L, U = V.kappa_ranges(D, mu, cap, cell, rm)
    if any(L[j] > U[j] for j in L):
        return dict(status="empty", rmult=rm, bound=None)
    Lf = {j: float(L[j].mid()) for j in L}
    Uf = {j: float(U[j].mid()) for j in U}
    c, p = shift_law([(TAU, float(a_lo)), (A, float(b_lo))])
    best = None
    for st in settings:
        res = _certify_one(c, p, a_lo, b_lo, D, mu, cap, cell, L, U, Lf, Uf, rm, **st)
        if best is None or (res["status"] == "ok" and (best["status"] != "ok" or res["bound"] < best["bound"])):
            best = res
        if target is not None and best["status"] == "ok":
            if best["bound"] <= target or best["lp"] > target + 1e-4:
                break
    return best


def _certify_one(c, p, a_lo, b_lo, D, mu, cap, cell, L, U, Lf, Uf, rm, nx=201, nr=2001, Lr=None, outer=1.0,
                 taylor=True):
    out = joint_lp(c, p, D, mu, cap, cell, Lf, Uf, nx=nx, nr=nr, Lr=Lr, outer=outer, taylor=taylor)
    if out is None:
        return dict(status="lp_failed", rmult=rm)
    val, coef, mult = out
    Lt = outer * (Lr if Lr is not None else default_L(mu))
    coef, eps_bump = fix_wells(coef, c, p, Lt, D)
    coef, eps_tail = fix_tail(coef, a_lo, b_lo, Lt, D)
    eps = V.phi_check(coef, a_lo, b_lo, Lt)
    if eps is None:
        return dict(status="tail_failed", lp=val, rmult=rm, coef=coef, mult=mult)
    B = V.lagrangian_bound(coef, D, mu, cap, cell, L, U, mult)
    tot = B + eps
    return dict(status="ok", lp=val, bound=float(tot.upper()), eps=float(eps.upper()), eps_tail=eps_tail,
                eps_bump=eps_bump, Lt=Lt, rmult=rm, coef=coef, mult=mult)


def fix_wells(coef, c, p, Lt, D, n=200001):
    """Deep narrow wells of phi - h between r-grid points occur near |r| = Lt, where Y carries no mass; fill
    them with eps (r / Lt)^D (cheap: E (Z / Lt)^D is tiny). eps from a fine float grid on 0.5 Lt <= |r| <= Lt;
    the rigorous check is phi_check afterwards."""
    r = np.concatenate([np.linspace(-Lt, -0.5 * Lt, n // 2), np.linspace(0.5 * Lt, Lt, n // 2)])
    h = np.abs(c[None, :] + r[:, None]) @ p
    d = np.polyval(np.array(coef)[::-1], r) - h
    need = np.max(np.maximum(0.0, -d) / (r / Lt) ** D)
    if need <= 1e-9:
        return coef, 0.0
    e = 2.0 * need / Lt ** D
    new = list(coef)
    new[D] = math.nextafter(new[D] + e, math.inf)
    return new, 2.0 * need


def fix_tail(coef, a_lo, b_lo, Lt, D):
    """Raise c_D by the least eps making every tail Taylor coefficient >= 0 (phi + eps r^D >= phi)."""
    tq = V.tail_coeffs(coef, a_lo, b_lo, Lt)
    LtA = V.to_arb(float(Lt))
    need = V.arb(0)
    for q in tq:
        for k, qk in enumerate(q):
            if not (qk >= 0):
                need = need.max(-qk / (math.comb(D, k) * LtA ** (D - k)))
    if need == 0:
        return coef, 0.0
    e = float(need.upper()) * (1 + 1e-6) + 1e-300
    new = list(coef)
    c = new[D] + e
    for _ in range(4):
        c = math.nextafter(c, math.inf)
    new[D] = c
    return new, e


if __name__ == "__main__":
    import time
    from flint import fmpq
    # K*-type box test: a+ ~ 0.25, b+ ~ 0.27
    box = (fmpq(24, 100), fmpq(26, 100), fmpq(26, 100), fmpq(27, 100))
    info = V.box_info(*box)
    print("box info", info, float(info["mu"]))
    root = V.root_cell(info["mu"], info["cap"])
    print("root cell", [float(z) for z in root])
    t0 = time.time()
    res = certify(box, root)
    print({k: v for k, v in res.items() if k not in ("coef", "mult", "rmult")}, f"{time.time() - t0:.1f}s")
