"""Tolerance dependence of the moment-LP values J and S of plus_check_laws.py (float evidence, not proof).

At each law: J(t) = joint LP (one Y for all count values) and S(t) = per-shift LPs (a Y for each count value), with
moments 1..D-1 matched to +-t and E Y^D <= m_D + t on the rows scaled as in heavy_scan.exact_common, on the grid of
exact_common plus the support of a discrete stand-in for Z_W. Every value is reported with its HiGHS status and the
largest violation of the rows by the returned measure beyond +-t (scaled units); no fallback tolerance is used. The
design's value is the limit t -> 0 (the certificate uses exact moments). HiGHS sometimes reports 'optimal' for a
shift LP whose returned measure violates the rows, so S is reported (at t = 1e-9 and 1e-7) as the lower estimate
S_lo: the LP value at shifts whose measure violates no row by more than 1e-6, and |c| at the others.
Usage: python3 plus_lp_tol.py [row numbers, default all]
"""
import math
import os
import sys
import time

import numpy as np
from scipy.optimize import linprog

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from edge_split_feas import cumulants, moments_from_cumulants
from heavy_box_lp import shift_law
from plus_check_laws import A, D, LAWS, TAU, chord_rates, stand_in_support

TOLS = [1e-11, 1e-10, 1e-9, 1e-8, 1e-7, 1e-6]
S_TOLS = [1e-9, 1e-7]
FEAS = 1e-6
NR = 4001


def lp_data(c, mom, extra):
    sc = math.sqrt(mom[2])
    zm = [mom[k] / sc ** k for k in range(D + 1)]
    Lz = max(10.0, (1e8 * math.sqrt(zm[D - 2] * zm[D])) ** (1.0 / (D - 1)))
    z = np.unique(np.concatenate([np.linspace(-Lz, Lz, NR), -c[np.abs(c) < Lz * sc] / sc, np.asarray(extra) / sc]))
    rows, rhs = [], []
    for k in range(D + 1):
        e0, e1 = 2 * (k // 2), 2 * ((k + 1) // 2)
        s = max(1.0, math.sqrt(zm[e0] * zm[e1]))
        rows.append(z ** k / s)
        rhs.append(zm[k] / s)
    return sc, z, np.array(rows), np.array(rhs)


def lp_max(obj, Am, b, t):
    """(value, status, violation): violation = largest excess of the returned x over the rows' bounds (scaled
    units; <= 0 up to rounding when x is feasible), the mass row included."""
    res = linprog(-obj, A_ub=np.vstack([Am[1:D], -Am[1:D], Am[D:]]),
                  b_ub=np.concatenate([b[1:D] + t, -b[1:D] + t, b[D:] + t]),
                  A_eq=Am[:1], b_eq=b[:1], bounds=(0, None), method="highs")
    if res.status != 0:
        return float("nan"), res.status, float("nan")
    x = np.maximum(res.x, 0.0)
    r = Am @ x - b
    viol = max(abs(r[0]), np.max(np.abs(r[1:D])) - t, r[D] - t)
    return float(obj @ x), res.status, float(viol)


def main():
    rows = [int(a) for a in sys.argv[1:]] or None
    print(f"start {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC; D = {D}, grid {NR} points + shifts + "
          f"support of W")
    for name, atoms, gauss, sb_rqc in LAWS:
        if rows and int(name.split()[1]) not in rows:
            continue
        edge = [(x, w) for x, w in atoms if TAU <= x <= A]
        rest = [(x, w) for x, w in atoms if not TAU <= x <= A]
        ap, bp = chord_rates(edge)
        c, p = shift_law([(x, lam) for x, lam in [(TAU, ap), (A, bp)] if lam > 1e-12])
        mom = moments_from_cumulants(cumulants(rest, gauss, D), D)
        sc, z, Am, b = lp_data(c, mom, stand_in_support(rest, gauss))
        H = np.abs(c[None, :] + sc * z[:, None])
        print(f"{name}: {len(c)} count values, {len(z)} grid points; RQ-C's SB_lo {sb_rqc:.5f}")
        for t in TOLS:
            J, sj, vj = lp_max(H @ p, Am, b, t)
            line = f"    t = {t:.0e}: J = {J:.5f} (status {sj}, violation {vj:.1e})"
            if t in S_TOLS:
                vals = [lp_max(H[:, i], Am, b, t) for i in range(len(c))]
                good = np.array([s == 0 and v <= FEAS for _, s, v in vals])
                # a shift without a verified feasible solution counts |c| <= E|c + Y| (Jensen), so S_lo <= S
                S_lo = float(sum(pi * (v if g else abs(ci)) for pi, ci, (v, _, _), g in zip(p, c, vals, good)))
                line += (f";  S_lo = {S_lo:.5f} ({int((~good).sum())} of {len(c)} shift LPs without a feasible "
                         f"solution, total probability {float(p[~good].sum()):.1e})")
            print(line, flush=True)
    print(f"end {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC")


if __name__ == "__main__":
    main()
