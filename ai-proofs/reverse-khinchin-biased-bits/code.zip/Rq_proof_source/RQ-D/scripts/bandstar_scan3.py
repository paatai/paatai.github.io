"""Float scan for the ID* band lemma, adaptive theta, variance-refined one-jump term (evidence only).

As bandstar_scan2.py, but the one-jump term E chi(J - m) (J ~ nu_S / Lam on [theta, A], mean mu1 = m/Lam,
variance s2 = (Lam V - m^2)/Lam^2) is bounded by the minimum of
  - the chord of chi over [theta - m, A - m] at mu1 - m, and
  - chi(mu1 - m) + (1/2) s2 sup_{y >= theta - m} chi''(y)
for chi = chi_h (sup chi'' = P(W_C* > theta - m - h)/h) and chi = Cauchy-Schwarz (sup = r2 / (y^2 + r2)^{3/2}).
"""
import math
import sys

import numpy as np
from scipy.stats import norm

A = float(sys.argv[2]) if len(sys.argv) > 2 else 1.54
DELTA = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
C5 = 1.28 * math.sqrt(2 * math.log(1.25))
HG = np.geomspace(0.004, 3.0, 50)


def g(l):
    return 2 * np.sqrt(np.maximum(l, 0)) * np.exp(-l)


def lattice(J, lam):
    if lam <= 0:
        return np.array([0.0]), np.array([1.0])
    nmax = int(lam + 10 * math.sqrt(lam) + 12)
    n = np.arange(nmax + 1)
    p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    return J * (n - lam), p


def Qf(d, s):
    if s <= 0:
        return np.where(d > 0, d * d, 0.0)
    z = d / s
    return (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)


def tailp(d, s):
    if s <= 0:
        return (d > 0).astype(float)
    return norm.cdf(d / s)


def chi_table(J, lam, s, y):
    """chi_h(y) for all h in HG: array (len(HG), len(y)); and tail probabilities P(W > y - h)."""
    x, w = lattice(J, lam)
    out = np.empty((len(HG), len(y)))
    tp = np.empty((len(HG), len(y)))
    for i, h in enumerate(HG):
        d = x[:, None] - (y - h)[None, :]
        out[i] = (w[:, None] * Qf(d, s)).sum(0) / (2 * h)
        tp[i] = (w[:, None] * tailp(d, s)).sum(0)
    return out, tp


def worst(theta, a, b, nL=150, nm=400):
    r2 = a + b
    V = 1 - r2
    mgrid = np.linspace(max(V / A, theta * V / A ** 2), theta - DELTA, nm)
    cs = lambda y: np.sqrt(y * y + r2) - y
    xB, wB = lattice(theta, a / theta ** 2)
    sB, sC = math.sqrt(b), math.sqrt(a)
    # B cost on the m-grid
    vb = np.full(nm, np.inf)
    for h in HG:
        d = xB[:, None] - (mgrid - h)[None, :]
        vb = np.minimum(vb, (wB[:, None] * Qf(d, sB)).sum(0) / (2 * h))
    cB = np.minimum(vb, cs(mgrid))
    # C tables on a y-grid
    yg = np.linspace(0.0, 2.2, 881)
    chiC, tpC = chi_table(A, b / A ** 2, sC, yg)  # (nh, ny)
    csg = cs(yg)
    curv = tpC / HG[:, None]  # chi_h''(y) = P(W* > y - h) / h
    csc = r2 / (yg ** 2 + r2) ** 1.5
    interp = lambda tab, y: np.array([np.interp(y, yg, row) for row in tab])
    y1, yA, y2 = theta - mgrid, A - mgrid, 2 * theta - mgrid
    g1h, gAh = interp(chiC, y1), interp(chiC, yA)  # (nh, nm)
    c2 = np.minimum(interp(chiC, y2).min(0), cs(y2))
    curv_lo = interp(curv, y1)  # sup chi'' on [theta - m, .)
    cs_curv_lo = np.interp(y1, yg, csc)
    out, arg = -np.inf, None
    for L in np.linspace(V / A ** 2, V / theta ** 2, nL):
        lo = max(theta * L, V / A, (L + V / (A * theta)) / (1 / A + 1 / theta))
        hi = min(math.sqrt(L * V), A * L, V / theta, theta - DELTA)
        ok = (mgrid >= lo - 1e-12) & (mgrid <= hi + 1e-12)
        if not ok.any():
            continue
        m = mgrid[ok]
        mu1 = np.clip(m / L, theta, A)
        s2 = np.maximum(L * V - m * m, 0) / L ** 2
        wlo, whi = (A - mu1) / (A - theta), (mu1 - theta) / (A - theta)
        chord_h = (wlo * g1h[:, ok] + whi * gAh[:, ok]).min(0)
        chord_cs = wlo * cs(y1[ok]) + whi * cs(yA[ok])
        y0 = mu1 - m
        var_h = (interp(chiC, y0) + 0.5 * s2 * curv_lo[:, ok]).min(0)
        var_cs = cs(y0) + 0.5 * s2 * cs_curv_lo[ok]
        ch = np.minimum.reduce([chord_h, chord_cs, var_h, var_cs])
        P2 = 1 - math.exp(-L) * (1 + L)
        F = 2 * m * math.exp(-L) + math.exp(-L) * cB[ok] + L * math.exp(-L) * ch + P2 * c2[ok]
        v = F - max(g(L), C5)
        i = int(np.argmax(v))
        if v[i] > out:
            out, arg = v[i], (L, m[i])
    return out, arg


if __name__ == "__main__":
    thetas = [float(x) for x in sys.argv[1].split(",")] if len(sys.argv) > 1 else [0.8, 0.9, 1.0]
    print(f"A = {A}, C5 = {C5:.7f}, delta = {DELTA}")
    for theta in thetas:
        for r2 in [0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]:
            res = []
            for fa in [0, 0.25, 0.5, 0.75, 1]:
                a = fa * r2
                w, arg = worst(theta, a, r2 - a)
                res.append((w, fa, arg))
            res.sort(key=lambda t: -t[0])
            w, fa, arg = res[0]
            print(f"theta = {theta:.2f} rho^2 = {r2:.3f}: worst = {w:+.5f} at a = {fa:.2f} rho^2, "
                  f"(Lam, m) = ({arg[0]:.4f}, {arg[1]:.4f}) mu1 = {arg[1]/arg[0]:.3f}", flush=True)
