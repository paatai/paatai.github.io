"""Float feasibility scan for the ID* band lemma (evidence only, not proof).

Target (U.1 / C19 form): for K on [-A, A] with K([1, A]) >= 1 - rho^2,
    E|Z_K| <= max( g(lam+_1(K)), g(lam+_thc(K)), C ),   g(l) = 2 sqrt(l) e^{-l}.
Decomposition at theta = 1 (OR identity, m < 1 automatic): K_S = K|[1, A] with (V, Lam, m),
residual: a1 = K((0, thc)), c = K([thc, 1)), b = K([-A, 0]).  lam+_thc >= Lam + c.

Bound F = 2 m e^-Lam + e^-Lam cB(m) + Lam e^-Lam chord + P2(Lam) cC(2 - m), with
  cB: W_B* = (N_c - c) + thc (N_{a1/thc^2} - a1/thc^2) + sqrt(b) G          (two-level comparison)
  cC: W_C* = A (N_{b/A^2} - b/A^2) + sqrt(a1 + c) G
  chord over J in [1, A] at mu1 = m / Lam.
Prints, per (rho^2, thc), the worst value of F - target over a grid.
"""
import math
import sys

import numpy as np
from scipy.stats import norm

A = 1.54
C5 = 1.28 * math.sqrt(2 * math.log(1.25))
HG = np.geomspace(0.005, 3.0, 70)


def g(l):
    return 2 * np.sqrt(np.maximum(l, 0)) * np.exp(-l)


def pois(lam, nmax=None):
    if lam <= 0:
        return np.array([0]), np.array([1.0])
    nmax = nmax or int(lam + 10 * math.sqrt(lam) + 12)
    n = np.arange(nmax + 1)
    p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    return n, p


def Qf(d, s):
    if s <= 0:
        return np.where(d > 0, d * d, 0.0)
    z = d / s
    return (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)


def stoploss2(levels, s, t):
    """min_h (1/(2h)) E(W - t + h)_+^2, W = sum_j J_j (N_j - lam_j) + s G; t array. Returns array."""
    t = np.atleast_1d(t)
    vals = None
    grids = []
    for J, lam in levels:
        n, p = pois(lam)
        grids.append((J * (n - lam), p))
    # combine lattice
    x, w = np.array([0.0]), np.array([1.0])
    for xs, ps in grids:
        x = (x[:, None] + xs[None, :]).ravel()
        w = (w[:, None] * ps[None, :]).ravel()
        keep = w > 1e-15
        x, w = x[keep], w[keep]
    best = np.full(len(t), np.inf)
    for h in HG:
        d = x[:, None] - (t - h)[None, :]
        v = (w[:, None] * Qf(d, s)).sum(0) / (2 * h)
        best = np.minimum(best, v)
    return best


def costs(a1, c, b, thc, mgrid):
    r2 = a1 + c + b
    WB = [(1.0, c), (thc, a1 / thc ** 2)]
    WC = [(A, b / A ** 2)]
    sB, sC = math.sqrt(b), math.sqrt(a1 + c)
    cB = np.minimum(stoploss2(WB, sB, mgrid), np.sqrt(mgrid ** 2 + r2) - mgrid)
    y1, yA, y2 = 1 - mgrid, A - mgrid, 2 - mgrid
    cs = lambda y: np.sqrt(y * y + r2) - y
    g1 = np.minimum(stoploss2(WC, sC, y1), cs(y1))
    gA = np.minimum(stoploss2(WC, sC, yA), cs(yA))
    c2 = np.minimum(stoploss2(WC, sC, y2), cs(y2))
    return cB, g1, gA, c2


def worst(a1, c, b, thc, nL=120):
    r2 = a1 + c + b
    V = 1 - r2
    mgrid = np.linspace(V / A, min(V, 0.99999), 400)
    cB, g1, gA, c2 = costs(a1, c, b, thc, mgrid)
    worst_v, arg = -np.inf, None
    for L in np.linspace(V / A ** 2, V, nL):
        # feasible m for (V, L): L <= m <= A L, m^2 <= L V, chord lower bound (L + V/A) / (1 + 1/A)
        lo = max(L, V / A, (L + V / A) / (1 + 1 / A))
        hi = min(math.sqrt(L * V), A * L, V)
        ok = (mgrid >= lo - 1e-12) & (mgrid <= hi + 1e-12)
        if not ok.any():
            continue
        m = mgrid[ok]
        mu1 = np.clip(m / L, 1, A)
        ch = ((A - mu1) * g1[ok] + (mu1 - 1) * gA[ok]) / (A - 1)
        P2 = 1 - math.exp(-L) * (1 + L)
        F = 2 * m * math.exp(-L) + math.exp(-L) * cB[ok] + L * math.exp(-L) * ch + P2 * c2[ok]
        Lp_lo, Lp_hi = L + c, L + c / thc ** 2
        gp = min(g(Lp_lo), g(Lp_hi)) if c > 0 else 0.0
        tgt = max(g(L), gp, C5)
        v = F - tgt
        i = int(np.argmax(v))
        if v[i] > worst_v:
            worst_v, arg = v[i], (L, m[i])
    return worst_v, arg


if __name__ == "__main__":
    thc = float(sys.argv[1]) if len(sys.argv) > 1 else 0.85
    print(f"A = {A}, C5 = {C5:.7f}, thc = {thc}")
    for r2 in [0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]:
        res = []
        for fa in [0, 0.5, 1]:
            for fc in [0, 0.5, 1]:
                if fa + fc > 1:
                    continue
                a1, c = fa * r2, fc * r2
                b = r2 - a1 - c
                w, arg = worst(a1, c, b, thc)
                res.append((w, fa, fc, arg))
        res.sort(key=lambda t: -t[0])
        w, fa, fc, arg = res[0]
        print(f"rho^2 = {r2:.3f}: worst F - target = {w:+.5f} at a1 = {fa:.1f} rho^2, c = {fc:.1f} rho^2, "
              f"(Lam, m) = ({arg[0]:.4f}, {arg[1]:.4f})", flush=True)
