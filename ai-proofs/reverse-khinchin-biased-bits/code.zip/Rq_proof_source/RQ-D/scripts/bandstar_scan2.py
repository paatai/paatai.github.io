"""Float scan for the ID* band lemma with an adaptive OR threshold theta (evidence only, not proof).

For theta in [theta_lo, 1] and K on [-A, A] with K_S = K|[theta, A] of mass V >= 1 - rho^2 and
m = int_S x^-1 dK < theta (every big jump exceeds the compensator):
    E|Z_K| <= F_theta = 2 m e^-Lam + e^-Lam cB(m) + Lam e^-Lam chord_theta(mu1) + P2(Lam) cC(2 theta - m),
  cB: W_B* = theta (N_{a/theta^2} - a/theta^2) + sqrt(b) G   (positive residual pushed to theta)
  cC: W_C* = A (N_{b/A^2} - b/A^2) + sqrt(a) G               (negative residual pushed to -A)
  chord over J in [theta, A] at mu1 = m / Lam.
Target: max(g(Lam), C5) with Lam = lam+_theta(K) exactly.
Prints the worst F - target over the feasible (Lam, m) for each (theta, rho^2), worst split of (a, b).
"""
import math
import sys

import numpy as np
from scipy.stats import norm

A = float(sys.argv[2]) if len(sys.argv) > 2 else 1.54
C5 = 1.28 * math.sqrt(2 * math.log(1.25))
HG = np.geomspace(0.004, 3.0, 60)


def g(l):
    return 2 * np.sqrt(np.maximum(l, 0)) * np.exp(-l)


def lattice(J, lam):
    if lam <= 0:
        return np.array([0.0]), np.array([1.0])
    nmax = int(lam + 10 * math.sqrt(lam) + 12)
    n = np.arange(nmax + 1)
    p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    return J * (n - lam), p


def Qf(d, s):
    if s <= 0:
        return np.where(d > 0, d * d, 0.0)
    z = d / s
    return (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)


def stoploss(J, lam, s, t):
    x, w = lattice(J, lam)
    best = np.full(len(t), np.inf)
    for h in HG:
        d = x[:, None] - (t - h)[None, :]
        best = np.minimum(best, (w[:, None] * Qf(d, s)).sum(0) / (2 * h))
    return best


def worst(theta, a, b, nL=150, nm=500, delta=0.0):
    r2 = a + b
    V = 1 - r2
    mgrid = np.linspace(max(V / A, theta * V / A ** 2), theta - delta, nm)
    cs = lambda y: np.sqrt(y * y + r2) - y
    cB = np.minimum(stoploss(theta, a / theta ** 2, math.sqrt(b), mgrid), cs(mgrid))
    y1, yA, y2 = theta - mgrid, A - mgrid, 2 * theta - mgrid
    sC = math.sqrt(a)
    g1 = np.minimum(stoploss(A, b / A ** 2, sC, y1), cs(y1))
    gA = np.minimum(stoploss(A, b / A ** 2, sC, yA), cs(yA))
    c2 = np.minimum(stoploss(A, b / A ** 2, sC, y2), cs(y2))
    out, arg = -np.inf, None
    for L in np.linspace(V / A ** 2, V / theta ** 2, nL):
        lo = max(theta * L, V / A, (L + V / (A * theta)) / (1 / A + 1 / theta))
        hi = min(math.sqrt(L * V), A * L, V / theta, theta - delta)
        ok = (mgrid >= lo - 1e-12) & (mgrid <= hi + 1e-12)
        if not ok.any():
            continue
        m = mgrid[ok]
        mu1 = np.clip(m / L, theta, A)
        ch = ((A - mu1) * g1[ok] + (mu1 - theta) * gA[ok]) / (A - theta)
        P2 = 1 - math.exp(-L) * (1 + L)
        F = 2 * m * math.exp(-L) + math.exp(-L) * cB[ok] + L * math.exp(-L) * ch + P2 * c2[ok]
        v = F - max(g(L), C5)
        i = int(np.argmax(v))
        if v[i] > out:
            out, arg = v[i], (L, m[i])
    return out, arg


if __name__ == "__main__":
    thetas = [float(x) for x in sys.argv[1].split(",")] if len(sys.argv) > 1 else [0.8, 0.9, 1.0]
    print(f"A = {A}, C5 = {C5:.7f}")
    for theta in thetas:
        for r2 in [0.02, 0.05, 0.1, 0.15, 0.2, 0.25, 0.3]:
            res = []
            for fa in [0, 0.25, 0.5, 0.75, 1]:
                a = fa * r2
                w, arg = worst(theta, a, r2 - a)
                res.append((w, fa, arg))
            res.sort(key=lambda t: -t[0])
            w, fa, arg = res[0]
            print(f"theta = {theta:.2f} rho^2 = {r2:.3f}: worst = {w:+.5f} at a = {fa:.2f} rho^2, "
                  f"(Lam, m) = ({arg[0]:.4f}, {arg[1]:.4f})", flush=True)
