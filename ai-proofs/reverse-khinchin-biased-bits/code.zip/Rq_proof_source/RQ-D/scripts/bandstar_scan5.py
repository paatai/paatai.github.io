"""Float scan: unified (OR and non-OR) bound for the ID* band lemma with one threshold theta (evidence only).

K on [-A, A], K_S = K|[theta, A] (mass V, Lam = int x^-2 dK_S, m = int x^-1 dK_S), residual a = K((0, theta)),
b = K([-A, 0]). With ell(y) = E|y + W| (convex), W = Z_{K_R}:
  E|Z_K| = e^-Lam ell(-m) + Lam e^-Lam E_J ell(J - m) + sum_{n>=2} P(n) E ell(S_n - m)
        <= e^-Lam (m + cB(m)) + Lam e^-Lam ONE + m Lam e^-Lam + P2 cC(2 theta - m)        (needs 2 theta > m)
ONE: chord of ell over J in [theta, A] at mu1 (endpoint values bounded by |y| + cost bounds), and, when m < theta
(OR), the variance bound (mu1 - m) + chi(mu1 - m) + s2/2 sup chi''.
Target: max(g(Lam), C5).
"""
import math
import sys

import numpy as np
from scipy.stats import norm

A = 1.54
C5 = 1.28 * math.sqrt(2 * math.log(1.25))
HG = np.geomspace(0.004, 3.0, 50)
YG = np.linspace(-1.0, 2.4, 1361)


def g(l):
    return 2 * np.sqrt(np.maximum(l, 0)) * np.exp(-l)


def lattice(J, lam):
    if lam <= 0:
        return np.array([0.0]), np.array([1.0])
    nmax = int(lam + 10 * math.sqrt(lam) + 12)
    n = np.arange(nmax + 1)
    p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    return J * (n - lam), p


def Qf(d, s):
    if s <= 0:
        return np.where(d > 0, d * d, 0.0)
    z = d / s
    return (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)


def tailp(d, s):
    if s <= 0:
        return (d > 0).astype(float)
    return norm.cdf(d / s)


def tables(J, lam, s):
    x, w = lattice(J, lam)
    chi = np.empty((len(HG), len(YG)))
    tp = np.empty((len(HG), len(YG)))
    for i, h in enumerate(HG):
        d = x[:, None] - (YG - h)[None, :]
        chi[i] = (w[:, None] * Qf(d, s)).sum(0) / (2 * h)
        tp[i] = (w[:, None] * tailp(d, s)).sum(0)
    return chi, tp / HG[:, None]  # chi_h''(y) = P(W* > y - h) / h


def worst(theta, a, b, nL=160, nm=500):
    r2 = a + b
    V = 1 - r2
    cs = lambda y: np.sqrt(y * y + r2) - y
    chiB, _ = tables(theta, a / theta ** 2, math.sqrt(b))
    chiC, curvC = tables(A, b / A ** 2, math.sqrt(a))
    cBy = np.minimum(chiB.min(0), cs(YG))  # cost_B(t) on YG
    cCy = np.minimum(chiC.min(0), cs(YG))
    cb = lambda t: np.interp(t, YG, cBy)
    cc = lambda t: np.interp(t, YG, cCy)
    cCall = np.minimum(chiC.min(0), np.sqrt(YG ** 2 + r2) - YG)  # 2E(-W - y)_+ bound, any real y
    ccall = lambda t: np.interp(t, YG, cCall)
    ell = lambda y: np.minimum(y + ccall(y), np.where(y >= 0, y + cc(np.abs(y)), -y + cb(np.abs(y))))
    mgrid = np.linspace(V / A, V / theta, nm)
    e1, eA = ell(theta - mgrid), ell(A - mgrid)
    c2 = cc(2 * theta - mgrid)
    out, arg = -np.inf, None
    for L in np.linspace(V / A ** 2, V / theta ** 2, nL):
        lo = max(theta * L, V / A, (L + V / (A * theta)) / (1 / A + 1 / theta))
        hi = min(math.sqrt(L * V), A * L, V / theta)
        ok = (mgrid >= lo - 1e-12) & (mgrid <= hi + 1e-12)
        if not ok.any():
            continue
        m = mgrid[ok]
        mu1 = np.clip(m / L, theta, A)
        wlo, whi = (A - mu1) / (A - theta), (mu1 - theta) / (A - theta)
        one = wlo * e1[ok] + whi * eA[ok]
        # variance refinement, valid for every m: ell(y) <= y + chi_h(y) on R (smooth, chi_h'' <= tail/(2h))
        s2 = np.maximum(L * V - m * m, 0) / L ** 2
        y0 = mu1 - m
        ylo = theta - m
        vh = np.array([np.interp(y0, YG, chiC[i]) + 0.5 * s2 * np.interp(ylo, YG, curvC[i])
                       for i in range(len(HG))]).min(0)
        # Cauchy-Schwarz form: ell(y) <= sqrt(y^2 + r2); curvature r2/(y^2 + r2)^1.5 <= its value at max(ylo, 0)
        vcs = np.sqrt(y0 ** 2 + r2) + 0.5 * s2 * r2 / (np.maximum(ylo, 0) ** 2 + r2) ** 1.5
        one = np.minimum.reduce([one, y0 + vh, vcs])
        P2 = 1 - math.exp(-L) * (1 + L)
        F = math.exp(-L) * (m + cb(m)) + L * math.exp(-L) * one + m * L * math.exp(-L) + P2 * c2[ok]
        v = F - max(g(L), C5)
        i = int(np.argmax(v))
        if v[i] > out:
            out, arg = v[i], (L, m[i])
    return out, arg


if __name__ == "__main__":
    thetas = [float(x) for x in sys.argv[1].split(",")] if len(sys.argv) > 1 else [0.8, 0.9]
    r2s = [float(x) for x in sys.argv[2].split(",")] if len(sys.argv) > 2 else [0.05, 0.1, 0.15, 0.2, 0.25]
    print(f"A = {A}, C5 = {C5:.7f}")
    for theta in thetas:
        for r2 in r2s:
            res = []
            for fa in [0, 0.25, 0.5, 0.75, 1]:
                a = fa * r2
                w, arg = worst(theta, a, r2 - a)
                res.append((w, fa, arg))
            res.sort(key=lambda t: -t[0])
            w, fa, arg = res[0]
            print(f"theta = {theta:.2f} rho^2 = {r2:.3f}: worst = {w:+.5f} at a = {fa:.2f} rho^2, "
                  f"(Lam, m) = ({arg[0]:.4f}, {arg[1]:.4f}) mu1 = {arg[1]/arg[0]:.3f}", flush=True)
