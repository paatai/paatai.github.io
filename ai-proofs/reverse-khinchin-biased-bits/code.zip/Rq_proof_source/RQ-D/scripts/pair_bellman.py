"""Exploration (float): value of the two-copy ("pair Bellman") relaxation.

B_{m+1}(a,b) = sup_{a0,b0} (a1-a0)(b1-b0) + p^2 B_m(a0,b0) + q^2 B_m(a1,b1) + pq (B_m(a0,b1)+B_m(a1,b0)),
with a = p a0 + q a1, b = p b0 + q b1, all in [0,1].  B_0 = 0.
True W(f) = sum_i (Delta_i f)^2 satisfies W(f) <= B_m(Ef, Ef).  Target: Phi^2 = max_k k p^(2k-2).
"""
import sys
import numpy as np
from scipy.interpolate import RegularGridInterpolator

q = float(sys.argv[1]) if len(sys.argv) > 1 else 0.2
N = int(sys.argv[2]) if len(sys.argv) > 2 else 60
K = int(sys.argv[3]) if len(sys.argv) > 3 else 41
iters = int(sys.argv[4]) if len(sys.argv) > 4 else 60
p = 1 - q
grid = np.linspace(0, 1, N + 1)
B = np.zeros((N + 1, N + 1))
target = max(k * p ** (2 * k - 2) for k in range(1, 400))
triv = 0.25 / (q * p)

A, Bb = np.meshgrid(grid, grid, indexing="ij")
for it in range(iters):
    interp = RegularGridInterpolator((grid, grid), B, bounds_error=False, fill_value=None)
    best = np.zeros_like(B)
    # candidate a0 in [lo, hi] parametrised by s in [0,1]
    lo_a = np.maximum(0, (A - q) / p)
    hi_a = np.minimum(1, A / p)
    lo_b = np.maximum(0, (Bb - q) / p)
    hi_b = np.minimum(1, Bb / p)
    for s in np.linspace(0, 1, K):
        a0 = lo_a + s * (hi_a - lo_a)
        a1 = np.clip((A - p * a0) / q, 0, 1)
        for t in np.linspace(0, 1, K):
            b0 = lo_b + t * (hi_b - lo_b)
            b1 = np.clip((Bb - p * b0) / q, 0, 1)
            val = (a1 - a0) * (b1 - b0)
            pts = np.stack
            val = val + p * p * interp(np.stack([a0, b0], -1)) + q * q * interp(np.stack([a1, b1], -1)) \
                + p * q * (interp(np.stack([a0, b1], -1)) + interp(np.stack([a1, b0], -1)))
            best = np.maximum(best, val)
    B = best
    if it % 5 == 4 or it == iters - 1:
        d = np.diag(B)
        print(f"iter {it+1}: max diag {d.max():.5f} at a={grid[d.argmax()]:.3f}; max all {B.max():.5f}; "
              f"target Phi^2={target:.5f}; trivial={triv:.5f}")
        sys.stdout.flush()
