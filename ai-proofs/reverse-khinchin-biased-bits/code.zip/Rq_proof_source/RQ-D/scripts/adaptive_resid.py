"""Float experiment (evidence only): the adaptive (Bellman) relaxation of the residual.

sup over residual measures R on [-tau, tau] of mass mu0 of E h(Z_R) is at most W(0, mu0), where
    d/dr W(y, r) = max_{x in [-tau, tau]} Delta_x W(., r)(y),   Delta_x W(y) = (W(y + x) - W(y) - x W'(y)) / x^2,
    Delta_0 W = W'' / 2,   W(., 0) = h,   h(y) = E|C + y|  (C = conditioned chord atoms).
(Any super-solution U with U(., 0) >= h gives E h(Z_R) <= U(0, mu0): d/ds E U(Z_{sR}, mu0 (1 - s)) <= 0.)
Explicit scheme on a grid; x restricted to grid multiples.
"""
import math
import sys

import numpy as np

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from heavy_box_lp import TAU, TESTS, law_to_box_input, shift_law


def adaptive_value(c, p, mu0, dy=0.01, L=None, nx=None, cfl=0.2):
    if L is None:
        L = 8.0
    y = np.arange(-L, L + dy / 2, dy)
    W = np.abs(c[None, :] + y[:, None]) @ p
    ks = np.arange(1, int(round(TAU / dy)) + 1)
    if nx is not None:
        ks = np.unique(np.linspace(1, int(round(TAU / dy)), nx).round().astype(int))
    # dt: Delta_0 ~ W''/2 needs dt <= dy^2 (explicit); Delta_x for x >= dy needs dt <= x^2 / 2
    dt = cfl * dy * dy
    nsteps = int(math.ceil(mu0 / dt))
    dt = mu0 / nsteps
    for _ in range(nsteps):
        Wp = np.gradient(W, dy)
        best = np.zeros_like(W)
        d2 = np.zeros_like(W)
        d2[1:-1] = (W[2:] - 2 * W[1:-1] + W[:-2]) / dy ** 2 / 2
        best = d2
        for k in ks:
            x = k * dy
            for s in (1, -1):
                sh = np.empty_like(W)
                if s == 1:
                    sh[:-k] = W[k:]; sh[-k:] = W[-1] + (np.arange(1, k + 1)) * dy * Wp[-1]
                else:
                    sh[k:] = W[:-k]; sh[:k] = W[0] - (np.arange(k, 0, -1)) * dy * Wp[0]
                dx = (sh - W - s * x * Wp) / (x * x)
                best = np.maximum(best, dx)
        W = W + dt * best
    i0 = int(np.argmin(np.abs(y)))
    return W[i0]


if __name__ == "__main__":
    dy = float(sys.argv[1]) if len(sys.argv) > 1 else 0.02
    idx = [int(s) for s in sys.argv[2].split(",")] if len(sys.argv) > 2 else range(len(TESTS))
    for i in idx:
        name, atoms, wG = TESTS[i]
        cond, mu0, rest = law_to_box_input(atoms, wG)
        c, p = shift_law(cond)
        v = adaptive_value(c, p, mu0, dy=dy, nx=30)
        print(f"{name:40s} mu0 = {mu0:.3f}  adaptive W(0, mu0) = {v:.5f}", flush=True)
