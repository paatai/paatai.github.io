"""Margin sqrt(2/e) - E|Z_K| for K = (1-w) delta_x + w delta_y with residual atom y < 1 (float)."""
import numpy as np
from idlib import mean_abs, SQ2E

ys = np.concatenate([np.linspace(-2.0, -0.05, 40), [0.0], np.linspace(0.05, 0.99, 48)])
for x in [1.2, 1.3, 1.38, 2 ** 0.5, 1.45, 1.55]:
    print(f"x = {x:.4f}, Dirac margin {SQ2E - mean_abs([(x, 1.0)]):.6f}")
    for w in [0.01, 0.05, 0.1, 0.2, 0.3]:
        best = None
        for y in ys:
            mar = SQ2E - mean_abs([(x, 1 - w), (y, w)])
            if best is None or mar < best[0]:
                best = (mar, y)
        print(f"   w={w:.2f}: min margin {best[0]:+.6f} (margin/w {best[0]/w:+.4f}) at y={best[1]:+.3f}")
