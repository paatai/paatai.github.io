"""Adaptive cover of F_heavy (V+ in [1/2, 4/5)) by (box, cell) certificates for the 'plus' design.

Boxes: dyadic sub-rectangles of ROOT = [0, 28/25] x [0, 17/50] in the chord rates (a+, b+), indexed by
(la, ia, lb, ib): a in ROOT_a split into 2^la equal parts (part ia), b likewise. ROOT contains every compatible
pair, since Q(a, b) >= max(tau^2 a, A^2 b) and Q < 4/5.
Cells: dyadic sub-rectangles (lev, i, j) of plus_verify_lib.root_cell(mu_B, cap_B).
A box is finished when every cell of a tiling of its root cell has a certificate (bound <= TARGET, or empty);
otherwise it is split into four. Output: one JSON line per finished box in outputs/plus_cert/.
Usage: python3 plus_driver.py TAG LA0 LB0 [MAXCELL] [MAXROUND]
"""
import json
import multiprocessing as mp
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from flint import fmpq

import plus_cert as P
import plus_verify_lib as V

ROOT = (fmpq(0), fmpq(28, 25), fmpq(0), fmpq(17, 50))
C5F = float(V.C5.mid())
TARGET = C5F - 2e-4
HOPELESS = 0.02


def box_of(la, ia, lb, ib):
    a0, a1, b0, b1 = ROOT
    wa, wb = (a1 - a0) / 2 ** la, (b1 - b0) / 2 ** lb
    return (a0 + ia * wa, a0 + (ia + 1) * wa, b0 + ib * wb, b0 + (ib + 1) * wb)


def enc_mult(m):
    out = dict(cell=list(m["cell"]), mcc={}, cheb={})
    for key in ("mcc", "cheb"):
        for al, v in m[key].items():
            if any(z > 0 for z in v):
                out[key][",".join(map(str, al))] = list(v)
    return out


def enc_cert(cell_id, res):
    st = res["status"]
    d = dict(cell=list(cell_id), status=st)
    if st == "ok":
        d.update(coef=res["coef"], Lt=res["Lt"], mult=enc_mult(res["mult"]),
                 rmult={str(j): list(v) for j, v in res["rmult"].items()}, bound=res["bound"], lp=res["lp"])
    elif st == "empty":
        d.update(rmult={str(j): list(v) for j, v in res["rmult"].items()})
    elif st == "empty_farkas":
        d.update(farkas=list(res["farkas"]))
    return d


def work_box(args):
    bid, maxcell = args
    t0 = time.time()
    box = box_of(*bid)
    info = V.box_info(*box)
    if info["empty"]:
        return dict(box=list(bid), status="empty", t=time.time() - t0)
    root = V.root_cell(info["mu"], info["cap"])
    certs, worst, ncell = [], 0.0, 0
    stack = [(0, 0, 0)]
    while stack:
        cid = stack.pop()
        cell = V.cell_of(root, *cid)
        try:
            res = P.certify(box, cell, target=TARGET)
        except Exception as e:  # numerical failure: treat as not certified
            res = dict(status="error:" + repr(e)[:80])
        ncell += 1
        st = res["status"]
        good = st in ("empty", "empty_farkas") or (st == "ok" and res["bound"] <= TARGET)
        if good:
            certs.append(enc_cert(cid, res))
            if st == "ok":
                worst = max(worst, res["bound"])
            continue
        b = res.get("bound") or 9.0
        if cid[0] >= maxcell or (cid[0] == 0 and st == "ok" and b > TARGET + HOPELESS):
            return dict(box=list(bid), status="split", why=f"cell {cid} {st} {b:.5f}", ncell=ncell,
                        t=time.time() - t0)
        lev, i, j = cid
        stack += [(lev + 1, 2 * i + di, 2 * j + dj) for di in (0, 1) for dj in (0, 1)]
    return dict(box=list(bid), status="ok", certs=certs, worst=worst, ncell=ncell, t=time.time() - t0)


def main():
    tag, la0, lb0 = sys.argv[1], int(sys.argv[2]), int(sys.argv[3])
    maxcell = int(sys.argv[4]) if len(sys.argv) > 4 else 2
    maxround = int(sys.argv[5]) if len(sys.argv) > 5 else 4
    outdir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs", "plus_cert")
    os.makedirs(outdir, exist_ok=True)
    pending = [(la0, ia, lb0, ib) for ia in range(2 ** la0) for ib in range(2 ** lb0)]
    log = open(os.path.join(outdir, f"log_{tag}.txt"), "a")
    failed = []
    with mp.Pool(int(os.environ.get("NPROC", "8"))) as pool:
        for rnd in range(maxround + 1):
            if not pending:
                break
            fout = open(os.path.join(outdir, f"certs_{tag}_r{rnd}.jsonl"), "w")
            nxt = []
            done = 0
            for res in pool.imap_unordered(work_box, [(b, maxcell) for b in pending]):
                done += 1
                bid = tuple(res["box"])
                if res["status"] in ("ok", "empty"):
                    fout.write(json.dumps(res) + "\n")
                    fout.flush()
                    if res["status"] == "ok":
                        print(f"r{rnd} {done}/{len(pending)} box {bid} ok worst {res['worst']:.5f} cells "
                              f"{len(res['certs'])} ({res['ncell']} tried) {res['t']:.0f}s", file=log, flush=True)
                else:
                    la, ia, lb, ib = bid
                    if rnd < maxround:
                        nxt += [(la + 1, 2 * ia + di, lb + 1, 2 * ib + dj) for di in (0, 1) for dj in (0, 1)]
                    else:
                        failed.append(bid)
                    print(f"r{rnd} {done}/{len(pending)} box {bid} SPLIT ({res.get('why')}) {res['t']:.0f}s",
                          file=log, flush=True)
            fout.close()
            print(f"round {rnd} finished: {len(pending)} boxes, {len(nxt)} children pending", file=log, flush=True)
            pending = nxt
    pending = pending + failed
    if pending:
        with open(os.path.join(outdir, f"unfinished_{tag}.json"), "w") as f:
            json.dump(pending, f)
        print(f"UNFINISHED: {len(pending)} boxes", file=log, flush=True)
    else:
        print("ALL BOXES FINISHED", file=log, flush=True)


if __name__ == "__main__":
    main()
