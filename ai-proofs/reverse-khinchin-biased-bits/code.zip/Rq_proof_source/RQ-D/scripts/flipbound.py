"""Flip-formula bound for E|Z_K| (float exploration of the band lemma).

K = K_S + K_R, K_S on [theta, A] (exact OR part), K_R = residual on [-A, theta) with positive-part mass rp
(jumps in (0, theta), Gaussian counted in the negative part) and negative-part mass rn.

  E|Z| = 2 m e^{-Lam} + 2 e^{-Lam} E(W - m)_+ + 2 E[(-W - Y)_+; N_S >= 1]          (flip formula, exact)
  E(W - m)_+ <= E psi(W) <= E psi(W*_B),  W*_B = theta (N - rp/theta^2) + sqrt(rn) G   (comparison lemma)
  E(-W - y)_+ <= E psi_y(-W) <= E psi_y(W*_C), W*_C = A (N' - rn/A^2) + sqrt(rp) G'

psi is any function >= (w - t)_+ with psi'' nondecreasing; here psi(w) = (w - 2t + s)_+^2 / (4 (s - t)),
s = tangency point (single-jump value), optimised over s in (t, 2t].
"""
import numpy as np
from math import exp, sqrt
from scipy.stats import norm
from idlib import pois_pmf, SQ2E


def e_sq_plus(vals, probs, sig, c):
    """E (V + sig G - c)_+^2 for discrete V (vals, probs)."""
    d = vals - c
    if sig == 0:
        return float(np.dot(np.where(d > 0, d * d, 0.0), probs))
    z = d / sig
    # E (d + sig G)_+^2 = (d^2 + sig^2) Phi(z) + d sig phi(z)
    return float(np.dot((d * d + sig * sig) * norm.cdf(z) + d * sig * norm.pdf(z), probs))


def pois_law(jump, mass):
    lam = mass / jump ** 2
    nmax = int(lam + 10 * sqrt(lam) + 25)
    p = pois_pmf(lam, nmax)
    n = np.arange(nmax + 1)
    return jump * (n - lam), p


def stoploss_bound(t, top, mtop, sig2, grid=60):
    """Upper bound for E(W - t)_+ over ID W whose Kolmogorov mass mtop sits on jumps <= top (moved to top)
    and the rest sig2 sits below 0 (moved to 0, i.e. Gaussian). Uses psi_s, s in (t, 2t] or s = top if top < 2t."""
    vals, probs = pois_law(top, mtop) if mtop > 0 else (np.zeros(1), np.ones(1))
    sig = sqrt(sig2)
    best = np.inf
    for s in t * (1 + np.geomspace(1e-3, 1.0, grid)):
        val = e_sq_plus(vals, probs, sig, 2 * t - s) / (4 * (s - t))
        best = min(best, val)
    return best


def flip_bound_dirac(x, rp, rn, theta, A=sqrt(2.0)):
    """Bound when K_S = (1 - rp - rn) delta_x, x >= theta."""
    vs = 1 - rp - rn
    lam = vs / x ** 2
    m = vs / x
    assert theta > m and x >= theta
    a_term = 2 * m * exp(-lam)
    b_term = 2 * exp(-lam) * stoploss_bound(m, theta, rp, rn)
    # C term: Y = n x - m on N_S = n
    c_term = 0.0
    pn = pois_pmf(lam, 30)
    for n in range(1, 31):
        y = n * x - m
        if pn[n] < 1e-14:
            break
        c_term += 2 * pn[n] * stoploss_bound(y, A, rn, rp)
    return a_term + b_term + c_term, a_term, b_term, c_term


if __name__ == "__main__":
    for x in [1.2, 1.3, 1.38, sqrt(2), 1.45, 1.55]:
        for theta in [0.8, 0.9, 1.0]:
            line = []
            for r2 in [0.01, 0.02, 0.05, 0.1, 0.15, 0.2]:
                worst = -1
                for fr in np.linspace(0, 1, 11):
                    rp, rn = r2 * fr, r2 * (1 - fr)
                    vs = 1 - r2
                    if theta <= vs / x:
                        continue
                    tot = flip_bound_dirac(x, rp, rn, theta)[0]
                    worst = max(worst, tot)
                line.append(SQ2E - worst)
            print(f"x={x:.3f} theta={theta:.2f}: margin(bound) for rho^2 in .01,.02,.05,.1,.15,.2: "
                  + " ".join(f"{v:+.4f}" for v in line))
