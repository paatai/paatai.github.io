"""Controls for verify_plus.py (not part of the proof): the checks are not vacuous.
  1. Threshold: rerun every box check with C5 replaced by C5 - s; count the boxes that fail.
  2. Tiling (the verifier's own box_cover and check_box): deleting one box record, or one cell certificate of a box,
     makes the corresponding tiling test fail; so does replacing a box record by a copy with an out-of-range index,
     or a cell index by an out-of-range one.
Usage: python3 verify_plus_controls.py FILE.jsonl [FILE2.jsonl ...]
"""
import copy
import json
import multiprocessing as mp
import sys
import time

from flint import arb

import plus_verify_lib as V
import verify_plus as VP

C5_TRUE = V.C5


def run_shift(args):
    rec, shift = args
    V.C5 = C5_TRUE - arb(shift)
    bid, ok, msg, w, dt = VP.check_box(rec)
    return bid, ok, msg


def box_tiling_ok(recs):
    return VP.box_cover(recs) is None


def main():
    recs = []
    for fn in sys.argv[1:]:
        with open(fn) as f:
            recs += [json.loads(line) for line in f if line.strip()]
    ok_recs = [r for r in recs if r["status"] == "ok"]
    print(f"{len(recs)} box records, {len(ok_recs)} with cell certificates", flush=True)
    ctx = mp.get_context("fork")
    for shift in ("0", "1e-4", "3e-4", "1e-3", "3e-3"):
        t0 = time.time()
        with ctx.Pool(8) as pool:
            res = pool.map(run_shift, [(r, shift) for r in ok_recs])
        bad = [bid for bid, ok, _ in res if not ok]
        print(f"threshold C5 - {shift}: {len(bad)} of {len(ok_recs)} boxes fail; {time.time() - t0:.0f}s"
              + (f"; e.g. {bad[:4]}" if bad else ""), flush=True)
    print("box tiling, all records:", box_tiling_ok(recs))
    for k in (0, len(recs) // 2, len(recs) - 1):
        print(f"box tiling without record {k} (box {recs[k]['box']}):", box_tiling_ok(recs[:k] + recs[k + 1:]))
    for k in (0, len(recs) // 2, len(recs) - 1):
        moved = copy.deepcopy(recs[k])
        la, ia, lb, ib = moved["box"]
        moved["box"] = [la, ia + 2 ** la, lb, ib]
        print(f"box tiling with record {k} moved out of range (box {moved['box']}):",
              box_tiling_ok(recs[:k] + [moved] + recs[k + 1:]), f"({VP.box_cover(recs[:k] + [moved] + recs[k + 1:])})")
    r = max(ok_recs, key=lambda z: len(z["certs"]))
    for k in (0, len(r["certs"]) - 1):
        rr = copy.deepcopy(r)
        cell = rr["certs"].pop(k)["cell"]
        _, ok, msg, _, _ = VP.check_box(rr)
        print(f"box {r['box']} without its cell certificate {cell}: verified = {ok} ({msg})")
    rr = copy.deepcopy(r)
    lev, i, j = rr["certs"][0]["cell"]
    rr["certs"][0]["cell"] = [lev, i + 2 ** lev, j]
    _, ok, msg, _, _ = VP.check_box(rr)
    print(f"box {r['box']} with cell {[lev, i, j]} moved out of range: verified = {ok} ({msg})")


if __name__ == "__main__":
    main()
