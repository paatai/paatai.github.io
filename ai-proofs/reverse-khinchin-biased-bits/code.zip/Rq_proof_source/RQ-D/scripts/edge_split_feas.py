"""Float feasibility (evidence only, never proof): moment bounds on far-region laws with ALL edge jumps
conditioned on exactly, for laws whose edge mass is spread over several atoms (the "no window" case).

K = sum_j w_j delta_{x_j} + wG * Gaussian. Edge atoms: |x_j| >= tau_e. With N_j ~ Poisson(w_j / x_j^2):
    split(K) = sum over the edge counts (n_j) of prod_j P(N_j = n_j) * V_D(c + W),
    c = sum_j x_j (n_j - lam_j)  (edge atoms only),   W = Z of the non-edge part,
    V_D(c + W) = sup{E|c + Y| : Y has the moments of W up to degree D}.
This is the best any per-shift polynomial certificate can give at this K. A proof over general K has to replace
the exact shifts by bounds over the edge jump law (two-point bounds in (Lambda, m) boxes), which can only add loss.

The LP (moments_from_cumulants, sup_abs_shift) is copied from RQ-A's numerics/atomsplit_feas.py (18:00 UTC).
Usage: python3 edge_split_feas.py D TAU_E
"""
import itertools
import math
import sys

import numpy as np
from scipy.optimize import linprog

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from idlib import mean_abs_small


def cumulants(atoms, wG, D):
    k = [0.0] * (D + 1)
    k[2] = sum(w for _, w in atoms) + wG
    for j in range(3, D + 1):
        k[j] = sum(w * x ** (j - 2) for x, w in atoms)
    return k


def moments_from_cumulants(k, D):
    m = [1.0] + [0.0] * D
    for n in range(1, D + 1):
        m[n] = sum(math.comb(n - 1, i - 1) * k[i] * m[n - i] for i in range(1, n + 1))
    return m


NPTS = int(__import__("os").environ.get("EDGE_NPTS", "4001"))


def sup_abs_shift(c, mom, D, tol=1e-9, npts=NPTS, extra=None):
    """extra: support points of the residual's own law (in absolute units); adding them to the grid keeps the
    LP feasible when the moment vector is close to the boundary of the moment space (near-lattice residuals).
    On failure the LP is retried once with tolerance 1e-7 (reported values then are slightly relaxed)."""
    sc = abs(mom[2]) ** 0.5
    zm = [mom[k] / sc ** k for k in range(D + 1)]
    Lz = max(10.0, (1e8 * math.sqrt(zm[D - 2] * zm[D])) ** (1.0 / (D - 1)))
    z = np.linspace(-Lz, Lz, npts)
    if extra is not None:
        ez = np.asarray(extra) / sc
        z = np.unique(np.concatenate([z, ez[np.abs(ez) <= Lz]]))
    rows, rhs = [], []
    for k in range(D + 1):
        e0, e1 = 2 * (k // 2), 2 * ((k + 1) // 2)
        s = max(1.0, math.sqrt(zm[e0] * zm[e1]))
        rows.append(z ** k / s)
        rhs.append(zm[k] / s)
    A, b = np.array(rows), np.array(rhs)
    res = linprog(-np.abs(c + sc * z), A_ub=np.vstack([A[1:D], -A[1:D], A[D:]]),
                  b_ub=np.concatenate([b[1:D] + tol, -b[1:D] + tol, b[D:] + tol]),
                  A_eq=A[:1], b_eq=b[:1], bounds=(0, None), method="highs")
    if res.status != 0:
        if tol < 1e-8:
            return sup_abs_shift(c, mom, D, tol=1e-7, npts=npts, extra=extra)
        return float("nan")
    return -res.fun


def resid_support(rest, wG):
    """Support of the residual's discrete part (only when there is no Gaussian part)."""
    if wG > 0 or not rest:
        return None
    from idlib import law_small
    v, p, _ = law_small(rest, tol=1e-22)
    keep = p > 1e-22
    v, p = v[keep], p[keep]
    if len(v) > 3000:
        v = v[np.argsort(p)[-3000:]]
    return v


def pois(lam, nmax):
    p = [math.exp(-lam)]
    for n in range(1, nmax + 1):
        p.append(p[-1] * lam / n)
    return p


FALLBACKS = []


def split_bound(atoms, wG, D, tau_e, ptol=1e-10):
    edge = [(x, w) for x, w in atoms if abs(x) >= tau_e and w > 0]
    rest = [(x, w) for x, w in atoms if abs(x) < tau_e and w > 0]
    no_resid = not rest and wG == 0
    mom = None if no_resid else moments_from_cumulants(cumulants(rest, wG, D), D)
    extra = None if no_resid else resid_support(rest, wG)
    lams = [w / x ** 2 for x, w in edge]
    nmaxs = [int(l + 8 * math.sqrt(l) + 8) for l in lams]
    ps = [pois(l, nm) for l, nm in zip(lams, nmaxs)]
    comp = -sum(x * l for (x, _), l in zip(edge, lams))
    cache = {}
    tot = 0.0
    for ns in itertools.product(*[range(nm + 1) for nm in nmaxs]):
        pr = 1.0
        for p, n in zip(ps, ns):
            pr *= p[n]
        if pr < ptol:
            continue
        c = comp + sum(x * n for (x, _), n in zip(edge, ns))
        key = round(c, 12)
        if key not in cache:
            v = abs(c) if no_resid else sup_abs_shift(c, mom, D, extra=extra)
            if not np.isfinite(v):
                # LP failure: E|c + Y| <= sqrt(c^2 + E Y^2) for every Y with the residual's variance
                v = math.sqrt(c * c + mom[2])
                FALLBACKS.append((c, pr))
            cache[key] = v
        tot += pr * cache[key]
    return tot


def chord_law(atoms, tau_e, A=1.54):
    """Replace each side's edge jump law by the two-point law on {tau_e, A} with the same mean, keeping the
    side's Poisson rate Lambda_s and compensator m_s. Since c -> E|c + W| is convex and the shift is linear in
    every jump, the split bound of the returned law bounds the split for every edge jump law with that mean."""
    out = [(x, w) for x, w in atoms if abs(x) < tau_e]
    for sgn in (1, -1):
        side = [(abs(x), w) for x, w in atoms if sgn * x >= tau_e and w > 0]
        if not side:
            continue
        lam = sum(w / x ** 2 for x, w in side)
        m = sum(w / x for x, w in side)
        mu1 = m / lam
        pA = (mu1 - tau_e) / (A - tau_e)
        if pA > 1e-15:
            out.append((sgn * A, lam * pA * A ** 2))
        if 1 - pA > 1e-15:
            out.append((sgn * tau_e, lam * (1 - pA) * tau_e ** 2))
    return out


CASES = [
    # spread edge mass, both signs (RQ-B's "no window" worst rest, 19:13 far_cell_lp_test_D14.out)
    ("RQ-B no-window rest", [(-1.54, 0.15), (-1.39, 0.039), (1.39, 0.0891), (1.54, 0.15)], 0.572),
    ("edge spread 4 atoms + G", [(1.25, 0.1), (1.4, 0.1), (1.54, 0.1), (-1.3, 0.1)], 0.6),
    ("edge spread + small atoms", [(1.2, 0.15), (1.54, 0.15), (-1.45, 0.1), (0.6, 0.3)], 0.3),
    ("F maximiser (RQ-C C18)", [(1.2977, 0.8), (-1.1008, 0.095), (0.8499, 0.105)], 0.0),
    ("RQ-A 18:53 obstruction", [(0.8499, 0.9448), (-1.54, 0.0552)], 0.0),
    ("RQ-A edge y=1.2, w=0.055", [(0.8499, 0.945), (-1.2, 0.055)], 0.0),
    ("two-sided spread", [(1.25, 0.2), (1.5, 0.2), (-1.25, 0.2), (-1.5, 0.2)], 0.2),
    ("0.3 d1.4 + 0.3 d0.7 + 0.4 G", [(1.4, 0.3), (0.7, 0.3)], 0.4),
    ("spread 0.6 on [1.2,1.54] + 0.4 G", [(1.2, 0.15), (1.31, 0.15), (1.43, 0.15), (1.54, 0.15)], 0.4),
]

ADVERSARIAL = [
    # residual-only laws: the opposite atom just inside the split threshold, and the band-boundary shapes
    ("x=0.8499 y=1.19 w=0.055", [(0.8499, 0.945), (-1.19, 0.055)], 0.0),
    ("x=0.8499 y=0.99 w=0.055", [(0.8499, 0.945), (-0.99, 0.055)], 0.0),
    ("x=0.8499 y=0.84 w=0.055", [(0.8499, 0.945), (-0.84, 0.055)], 0.0),
    ("x=0.8499 y=1.54 w=0.10", [(0.8499, 0.90), (-1.54, 0.10)], 0.0),
    ("x=0.75 y=1.54 w=0.055", [(0.75, 0.945), (-1.54, 0.055)], 0.0),
    ("x=0.70 y=1.19 w=0.055", [(0.70, 0.945), (-1.19, 0.055)], 0.0),
    ("x=0.60 y=0.99 w=0.04", [(0.60, 0.96), (-0.99, 0.04)], 0.0),
    ("x=0.50 y=1.54 w=0.04", [(0.50, 0.96), (-1.54, 0.04)], 0.0),
    ("0.79 d1.414 + 0.21 G", [(1.414, 0.79)], 0.21),
    ("0.79 d1.54 + 0.21 d-0.84", [(1.54, 0.79), (-0.84, 0.21)], 0.0),
    ("0.79 d1.30 + 0.11 d-1.54 + 0.10 d0.84", [(1.30, 0.79), (-1.54, 0.11), (0.84, 0.10)], 0.0),
    ("delta_sqrt(2/3)", [(0.8165, 1.0)], 0.0),
    ("Gaussian", [], 1.0),
]

if __name__ == "__main__":
    D = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    tau_e = float(sys.argv[2]) if len(sys.argv) > 2 else 1.2
    if len(sys.argv) > 3 and sys.argv[3] == "adv":
        CASES = ADVERSARIAL
    print(f"D = {D}, tau_e = {tau_e}; columns: true E|Z_K|, whole-law V_D, split over all edge atoms (exact "
          f"shifts), chord split (edge jump law replaced by its two-point chord law; proof-shaped)", flush=True)
    for name, atoms, wG in CASES:
        t = mean_abs_small(atoms + [(0.0, wG)])
        mom = moments_from_cumulants(cumulants(atoms, wG, D), D)
        vd = sup_abs_shift(0.0, mom, D, extra=resid_support(atoms, wG))
        FALLBACKS.clear()
        sb = split_bound(atoms, wG, D, tau_e)
        cb = split_bound(chord_law(atoms, tau_e), wG, D, tau_e)
        fb = f"  ({len(FALLBACKS)} LP fallbacks, total prob {sum(p for _, p in FALLBACKS):.1e})" if FALLBACKS else ""
        print(f"{name:34s} true {t:.5f}  V_D {vd:.5f}  split {sb:.5f}  chord {cb:.5f}{fb}", flush=True)
