"""Soundness test (float): the unified band bound F must dominate the exact E|Z_K| on random K in the band.

Also reports min over the sample of max(g(lam+_theta), C5) - E|Z_K| (the true margin of the band statement).
"""
import math
import sys

import numpy as np

from bandstar_float import bound, params
from idlib import mean_abs_small as mean_abs

theta = float(sys.argv[1]) if len(sys.argv) > 1 else 0.85
A = 1.54
R0 = float(sys.argv[2]) if len(sys.argv) > 2 else 0.2
N = int(sys.argv[3]) if len(sys.argv) > 3 else 300
C5 = 1.28 * math.sqrt(2 * math.log(1.25))
g = lambda l: 2 * math.sqrt(l) * math.exp(-l)
rng = np.random.default_rng(11)

worst_gap, worst_true, nonor = np.inf, np.inf, 0
for t in range(N):
    r2 = rng.uniform(0, R0)
    nS = rng.integers(1, 4)
    xs = rng.uniform(theta, A, nS)
    u = rng.random()
    if u < 0.25:
        xs[0] = theta + rng.uniform(0, 0.05)
    elif u < 0.5:
        xs[0] = rng.uniform(1.3, 1.5)
    ws = rng.dirichlet(np.ones(nS)) * (1 - r2)
    nR = rng.integers(1, 3)
    xr = np.concatenate([rng.uniform(0.15, theta, nR), -rng.uniform(0.15, A, nR)])
    if rng.random() < 0.3:
        xr[0] = theta - 0.01
    if rng.random() < 0.3:
        xr[-1] = -A
    wr = rng.dirichlet(np.ones(len(xr))) * r2
    K = [(float(x), float(w)) for x, w in zip(xs, ws)] + [(float(x), float(w)) for x, w in zip(xr, wr)]
    if rng.random() < 0.3:
        K.append((0.0, 0.3 * r2))
        K = [(x, w / (1 + 0.3 * r2)) for x, w in K]
    V, Lam, m, a, b = params(K, theta, A)
    true = mean_abs(K)
    F = bound(theta, A, Lam, m, V, a, b)
    if m >= min(x for x, _ in K if x >= theta):
        nonor += 1
    worst_gap = min(worst_gap, F - true)
    worst_true = min(worst_true, max(g(Lam), C5) - true)
    if F < true - 1e-9:
        print("UNSOUND", K, F, true, flush=True)
print(f"theta = {theta}, rho0^2 = {R0}: {N} random K ({nonor} non-OR); min(F - E|Z|) = {worst_gap:+.6f} "
      f"(must be >= 0); min(target - E|Z|) = {worst_true:+.6f}")
