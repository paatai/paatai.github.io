"""Self-tests for plus_verify_lib (independent computations; floating point where noted, as evidence only).

T1 moment_polys: E Z^k for Z = x1 (N1 - l1) + x2 (N2 - l2) + G (Poisson N_i, Gaussian G) by direct expansion
   with Poisson central moments summed from the pmf, against the set-partition polynomials.
T2 poly_sup: random polynomials; the exact value at the argmax of a dense float grid is <= the bound, and the bound
   is within 1e-6 (relative) of the dense maximum.
T3 phi_check: for certificates from a certificate file, max of h_B - phi on a dense grid (h_B summed directly
   from the Poisson pmfs) is <= eps.
T4 kappa_ranges / lagrangian_bound: random admissible W'' (atoms on [-A, tau], an atom at A <= cap_B, a Gaussian
   part; total mass mu_B) whose (kappa_3, kappa_4) lies in a certified cell satisfy L_j <= kappa_j <= U_j and
   sum_k c_k E Z^k <= the Lagrangian bound.
T5 end to end: for random K in F_heavy (V+ in [1/2, 4/5)), E|Z_K| (float, by enumerating the Poisson counts; see
   E_abs_Z) is <= the certified bound of the cell containing its W''.
Usage: python3 test_plus_verify.py CERTFILE.jsonl
"""
import json
import math
import sys

import numpy as np
from flint import arb, fmpq

sys.path.insert(0, __file__.rsplit("/", 1)[0])
import plus_verify_lib as V
import verify_plus as VP

D = 16
TAU, A = 0.85, 1.54
rng = np.random.default_rng(12345)


def pois_central_moments(lam, kmax, nmax=400):
    n = np.arange(max(nmax, int(lam + 30 * math.sqrt(lam) + 60)))
    lp = -lam + n * math.log(lam) - np.array([math.lgamma(i + 1) for i in n]) if lam > 0 else None
    p = np.exp(lp) if lam > 0 else (n == 0).astype(float)
    return [float(np.sum(p * (n - lam) ** k)) for k in range(kmax + 1)]


def t1():
    worst = 0.0
    r1 = np.random.default_rng(1)
    for _ in range(40):
        x1, x2 = r1.choice([-1, 1], 2) * r1.uniform(0.2, 1.54, 2)
        w1, w2, g = r1.uniform(0, 0.4, 3)
        l1, l2 = w1 / x1 ** 2, w2 / x2 ** 2
        m1, m2 = pois_central_moments(l1, D), pois_central_moments(l2, D)
        mg = [0.0 if k % 2 else math.prod(range(k - 1, 0, -2)) * g ** (k / 2) for k in range(D + 1)]
        kap = {2: w1 + w2 + g}
        for j in range(3, D + 1):
            kap[j] = w1 * x1 ** (j - 2) + w2 * x2 ** (j - 2)
        mp = V.moment_polys(D)
        for k in range(D + 1):
            direct = 0.0
            for a in range(k + 1):
                for b in range(k - a + 1):
                    c = k - a - b
                    direct += math.factorial(k) / (math.factorial(a) * math.factorial(b) * math.factorial(c)) * \
                        x1 ** a * m1[a] * x2 ** b * m2[b] * mg[c]
            poly = sum(v * kap[2] ** p2 * math.prod(kap[j] for j in al) for (p2, al), v in mp[k].items())
            worst = max(worst, abs(direct - poly) / max(1.0, abs(direct)))
    print(f"T1 moment polynomials: max relative difference {worst:.2e}", "PASS" if worst < 1e-9 else "FAIL")
    return worst < 1e-9


def t2():
    ok = True
    for _ in range(30):
        deg = rng.integers(2, 15)
        cs = rng.normal(0, 1, deg + 1)
        lo, hi = sorted(rng.uniform(-2, 2, 2))
        ubA = V.poly_sup([arb(float(c)) for c in cs], arb(float(lo)), arb(float(hi)), tol=1e-10)
        ub = float(ubA.mid())
        xs = np.linspace(lo, hi, 200001)
        vals = np.polyval(cs[::-1], xs)
        i = int(vals.argmax())
        exact = V.poly_eval([arb(float(c)) for c in cs], arb(fmpq(*float(xs[i]).as_integer_ratio())))
        if not (exact <= ubA and ub <= vals[i] + 1e-6 * max(1.0, abs(ub))):
            ok = False
            print("  poly_sup mismatch", vals[i], exact.str(20), ub)
    print("T2 poly_sup vs dense evaluation:", "PASS" if ok else "FAIL")
    return ok


def h_direct(a, b, r):
    pa = np.array(pois_central_moments(a, 0, 120)) if False else None
    n = np.arange(120)
    qa = np.exp(-a + n * math.log(a) - np.array([math.lgamma(i + 1) for i in n])) if a > 0 else (n == 0) * 1.0
    qb = np.exp(-b + n * math.log(b) - np.array([math.lgamma(i + 1) for i in n])) if b > 0 else (n == 0) * 1.0
    c = (TAU * (n[:, None] - a) + A * (n[None, :] - b)).ravel()
    p = (qa[:, None] * qb[None, :]).ravel()
    keep = p > 1e-300
    c, p = c[keep], p[keep]
    return np.abs(c[None, :] + r[:, None]) @ p


def load(fn, k=40):
    recs = [json.loads(l) for l in open(fn) if l.strip()]
    recs = [r for r in recs if r["status"] == "ok"]
    rng.shuffle(recs)
    return recs[:k]


def t3(recs):
    ok, worst = True, -1.0
    for rec in recs[:15]:
        box = VP.box_of(*rec["box"])
        a_lo, b_lo = float(box[0]), float(box[2])
        for c in rec["certs"]:
            if c["status"] != "ok":
                continue
            eps = float(V.phi_check(c["coef"], box[0], box[2], c["Lt"]).upper())
            r = np.linspace(-3 * c["Lt"], 3 * c["Lt"], 60001)
            d = (h_direct(a_lo, b_lo, r) - np.polyval(np.array(c["coef"])[::-1], r)).max()
            worst = max(worst, d - eps)
            if d > eps + 1e-9:
                ok = False
                print("  phi_check unsound?", rec["box"], c["cell"], d, eps)
    print(f"T3 phi_check vs dense h - phi: max (dense - eps) = {worst:.2e}", "PASS" if ok else "FAIL")
    return ok


def random_W(mu, cap, natoms=3):
    """Random admissible W'': atoms in [-A, tau], an atom at A (<= cap), Gaussian part; mass mu."""
    xs = list(rng.uniform(-A, TAU, natoms))
    if rng.random() < 0.3:
        xs[0] = TAU
    if rng.random() < 0.3:
        xs[-1] = -A
    wts = rng.dirichlet(np.ones(natoms + 1))
    mA = rng.uniform(0, cap) if rng.random() < 0.7 else 0.0
    rest = mu - mA
    atoms = [(x, w * rest) for x, w in zip(xs, wts[:natoms])] + [(A, mA)]
    g = wts[natoms] * rest
    return atoms, g


def kappas(atoms, g, mu):
    k = {2: mu}
    for j in range(3, D + 1):
        k[j] = sum(w * x ** (j - 2) for x, w in atoms)
    return k


def F_value(coef, kap):
    mp = V.moment_polys(D)
    return sum(coef[kk] * sum(v * kap[2] ** p2 * math.prod(kap[j] for j in al) for (p2, al), v in mp[kk].items())
               for kk in range(D + 1))


def t4(recs, ntrial=3000):
    ok, hits, worst_gap = True, 0, 1e9
    for rec in recs:
        box = VP.box_of(*rec["box"])
        info = V.box_info(*box)
        mu, cap = info["mu"], info["cap"]
        root = V.root_cell(mu, cap)
        cells = {tuple(c["cell"]): c for c in rec["certs"]}
        for _ in range(ntrial // len(recs)):
            atoms, g = random_W(float(mu), float(cap))
            kap = kappas(atoms, g, float(mu))
            # locate the cell
            k3a, k3b, k4a, k4b = (float(z) for z in root)
            found = None
            for (lev, i, j), c in cells.items():
                n = 2 ** lev
                if k3a + i * (k3b - k3a) / n <= kap[3] <= k3a + (i + 1) * (k3b - k3a) / n and \
                        k4a + j * (k4b - k4a) / n <= kap[4] <= k4a + (j + 1) * (k4b - k4a) / n:
                    found = c
                    break
            if found is None:
                ok = False
                print("  W'' in no cell", rec["box"], kap[3], kap[4])
                continue
            if found["status"] != "ok":
                if found["status"] in ("empty", "empty_farkas"):
                    ok = False
                    print("  W'' found in a cell certified empty", rec["box"], found["cell"], kap[3], kap[4])
                continue
            cell = V.cell_of(root, *found["cell"])
            rm = {int(k): v for k, v in found["rmult"].items()}
            L, U = V.kappa_ranges(D, mu, cap, cell, rm)
            for j in range(3, D + 1):
                if not (float(L[j].mid()) - 1e-9 * (1 + abs(kap[j])) <= kap[j] <= float(U[j].mid()) +
                        1e-9 * (1 + abs(kap[j]))):
                    ok = False
                    print("  range violated", rec["box"], found["cell"], j, float(L[j].mid()), kap[j],
                          float(U[j].mid()))
            B = float(V.lagrangian_bound(found["coef"], D, mu, cap, cell, L, U, VP.dec_mult(found["mult"])).mid())
            Fv = F_value(found["coef"], kap)
            hits += 1
            worst_gap = min(worst_gap, B - Fv)
            if Fv > B + 1e-9:
                ok = False
                print("  Lagrangian bound violated", rec["box"], found["cell"], Fv, B)
    print(f"T4 ranges and Lagrangian bound on {hits} random admissible W'': min (bound - E phi(Z)) = "
          f"{worst_gap:.3e}", "PASS" if ok else "FAIL")
    return ok


def E_abs_Z(atoms, g):
    """E|Z| for Z = sum_i x_i (N_i - w_i / x_i^2) + G, G ~ N(0, g): enumerate the Poisson counts (pmf mass
    > 1e-15, truncation error < 1e-9 here) and use E|c + G| = c (1 - 2 Phi(-c / s)) + 2 s phi(c / s)
    (float; evidence only)."""
    c, p = np.array([0.0]), np.array([1.0])
    for x, w in atoms:
        if w <= 0:
            continue
        lam = w / x ** 2
        n = np.arange(int(lam + 15 * math.sqrt(lam) + 30))
        q = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(i + 1) for i in n]))
        cc = (c[:, None] + x * (n - lam)[None, :]).ravel()
        pp = (p[:, None] * q[None, :]).ravel()
        keep = pp > 1e-15
        key = np.round(cc[keep], 9)
        u, inv = np.unique(key, return_inverse=True)
        c, p = u, np.bincount(inv, weights=pp[keep])
    if g <= 0:
        return float(np.sum(p * np.abs(c)))
    s = math.sqrt(g)
    from math import erf
    Phi = np.array([0.5 * (1 + erf(-ci / s / math.sqrt(2))) for ci in c])
    return float(np.sum(p * (c * (1 - 2 * Phi) + 2 * s * np.exp(-c ** 2 / (2 * g)) / math.sqrt(2 * math.pi))))


def t5(recs, ntrial=200):
    ok, worst, hits = True, -1.0, 0
    for _ in range(ntrial):
        rec = recs[rng.integers(len(recs))]
        box = VP.box_of(*rec["box"])
        a = float(box[0]) + rng.random() * float(box[1] - box[0])
        b = float(box[2]) + rng.random() * float(box[3] - box[2])
        # edge law with chord rates (a, b): (1 - theta) x (one atom at the chord mean, V+ = Q) + theta x (the chord
        # atoms themselves, V+ = M); chord rates are linear in K, so V+ = (1 - theta) Q + theta M, any value in [Q, M]
        lam = a + b
        mbar = (a * TAU + b * A) / lam
        Qv, Mv = lam * mbar ** 2, a * TAU ** 2 + b * A ** 2
        lo, hi = max(Qv, 0.5), min(Mv, 0.8)
        if not lo < hi:
            continue
        Vp = lo + rng.random() * (hi - lo)
        theta = (Vp - Qv) / (Mv - Qv) if Mv > Qv else 0.0
        rest_mass = 1 - Vp
        info = V.box_info(*box)
        nat = 2
        xs = rng.uniform(-A, TAU * 0.999, nat)
        xs = np.where(np.abs(xs) < 0.3, np.sign(xs) * 0.3 + (xs == 0) * 0.3, xs)
        wts = rng.dirichlet(np.ones(nat + 1)) * rest_mass
        edge = [(mbar, (1 - theta) * Qv), (TAU, theta * a * TAU ** 2), (A, theta * b * A ** 2)]
        atoms = edge + [(x, w) for x, w in zip(xs, wts[:nat])]
        g = wts[nat]
        val = E_abs_Z(atoms, g)
        # its W'' in the box: rest + (a - a_lo) tau^2 at tau + (b - b_lo) A^2 at A, padded to mu_B with Gaussian
        Wa = [(x, w) for x, w in zip(xs, wts[:nat])] + [(TAU, (a - float(box[0])) * TAU ** 2),
                                                        (A, (b - float(box[2])) * A ** 2)]
        mu = float(info["mu"])
        kap = kappas(Wa, 0.0, mu)
        root = V.root_cell(info["mu"], info["cap"])
        k3a, k3b, k4a, k4b = (float(z) for z in root)
        cert = None
        for c in rec["certs"]:
            lev, i, j = c["cell"]
            n = 2 ** lev
            if k3a + i * (k3b - k3a) / n <= kap[3] <= k3a + (i + 1) * (k3b - k3a) / n and \
                    k4a + j * (k4b - k4a) / n <= kap[4] <= k4a + (j + 1) * (k4b - k4a) / n:
                cert = c
        if cert is None or cert["status"] != "ok":
            ok = False
            print("  K's W'' not in an ok cell", rec["box"], kap[3], kap[4], cert and cert["status"])
            continue
        hits += 1
        worst = max(worst, val - cert["bound"])
        if val > cert["bound"] + 1e-6:
            ok = False
            print("  E|Z_K| exceeds the certified bound", val, cert["bound"])
    print(f"T5 end to end on {hits} random K: max (E|Z_K| - certified bound) = {worst:.4f}",
          "PASS" if ok and hits > 0 else "FAIL")
    return ok and hits > 0


if __name__ == "__main__":
    recs = load(sys.argv[1])
    res = [t1(), t2(), t3(recs), t4(recs), t5(recs)]
    print("ALL SELF-TESTS PASSED" if all(res) else "SOME SELF-TESTS FAILED")
