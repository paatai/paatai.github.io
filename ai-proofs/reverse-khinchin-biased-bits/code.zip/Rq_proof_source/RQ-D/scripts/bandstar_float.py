"""Float evaluation of the unified band bound F at exact parameters (evidence only, never proof).

K on [-A, A]; K_S = K|[theta, A] with V = K_S(R), Lam = int x^-2 dK_S, m = int x^-1 dK_S;
residual a = K((0, theta)), b = K([-A, 0]) (Gaussian part included in b).
    E|Z_K| <= F = e^-Lam (m + cB(m)) + Lam e^-Lam ONE + m Lam e^-Lam + P2(Lam) cC(2 theta - m).
See MAIN_RESULT.tex (band section) for the proof of every ingredient.
"""
import math

import numpy as np
from scipy.stats import norm

HG = np.geomspace(0.004, 3.0, 60)


def lattice(J, lam):
    if lam <= 0:
        return np.array([0.0]), np.array([1.0])
    nmax = int(lam + 10 * math.sqrt(lam) + 12)
    n = np.arange(nmax + 1)
    p = np.exp(-lam + n * math.log(lam) - np.array([math.lgamma(k + 1) for k in n]))
    return J * (n - lam), p


def Qf(d, s):
    if s <= 0:
        return np.where(d > 0, d * d, 0.0)
    z = d / s
    return (d * d + s * s) * norm.cdf(z) + d * s * norm.pdf(z)


def tailp(d, s):
    if s <= 0:
        return (d > 0).astype(float)
    return norm.cdf(d / s)


class Costs:
    """chi^B_h(t) = (1/2h) E(W_B* - t + h)_+^2 and chi^C_h(y) = (1/2h) E(W_C* - y + h)_+^2 for all h in HG."""

    def __init__(self, theta, A, a, b):
        self.theta, self.A, self.a, self.b = theta, A, a, b
        self.r2 = a + b
        self.xB, self.wB = lattice(theta, a / theta ** 2)
        self.sB = math.sqrt(b)
        self.xC, self.wC = lattice(A, b / A ** 2)
        self.sC = math.sqrt(a)

    def chi(self, which, t):
        x, w, s = (self.xB, self.wB, self.sB) if which == "B" else (self.xC, self.wC, self.sC)
        d = x[:, None] - (t - HG)[None, :]
        return (w[:, None] * Qf(d, s)).sum(0) / (2 * HG)  # array over h

    def curv(self, which, t):
        x, w, s = (self.xB, self.wB, self.sB) if which == "B" else (self.xC, self.wC, self.sC)
        d = x[:, None] - (t - HG)[None, :]
        return (w[:, None] * tailp(d, s)).sum(0) / HG  # chi_h''(y) = P(W* > y - h) / h

    def cs(self, y):
        return math.sqrt(y * y + self.r2) - y

    def cB(self, t):
        """upper bound of 2 E(W - t)_+."""
        return min(self.chi("B", t).min(), self.cs(t))

    def cC(self, y):
        """upper bound of 2 E(-W - y)_+."""
        return min(self.chi("C", y).min(), self.cs(y))

    def ell(self, y):
        """upper bound of E|y + W| (valid for every real y)."""
        return min(y + self.cC(y), -y + self.cB(-y), math.sqrt(y * y + self.r2))


def one_jump(c, theta, A, Lam, m, V):
    mu1 = min(max(m / Lam, theta), A)
    s2 = max(Lam * V - m * m, 0.0) / Lam ** 2
    y0 = mu1 - m
    chord = ((A - mu1) * c.ell(theta - m) + (mu1 - theta) * c.ell(A - m)) / (A - theta)
    vC = y0 + (c.chi("C", y0) + 0.5 * s2 * c.curv("C", theta - m)).min()
    vB = -y0 + (c.chi("B", -y0) + 0.5 * s2 * c.curv("B", m - A)).min()
    ylo = max(theta - m, 0.0)
    vS = math.sqrt(y0 * y0 + c.r2) + 0.5 * s2 * c.r2 / (ylo * ylo + c.r2) ** 1.5
    return min(chord, vC, vB, vS)


def bound(theta, A, Lam, m, V, a, b, c=None):
    c = c or Costs(theta, A, a, b)
    P2 = 1 - math.exp(-Lam) * (1 + Lam)
    one = one_jump(c, theta, A, Lam, m, V)
    return (math.exp(-Lam) * (m + c.cB(m)) + Lam * math.exp(-Lam) * one + m * Lam * math.exp(-Lam)
            + P2 * c.cC(2 * theta - m))


def params(K, theta, A):
    S = [(x, w) for x, w in K if x >= theta]
    V = sum(w for _, w in S)
    Lam = sum(w / x ** 2 for x, w in S)
    m = sum(w / x for x, w in S)
    a = sum(w for x, w in K if 0 < x < theta)
    b = sum(w for x, w in K if x <= 0)
    return V, Lam, m, a, b
