"""Float helpers for the infinitely divisible (ID) problem (evidence only, never proof).

K is a discrete Kolmogorov measure given as a list of (x, w): atom at jump size x with Kolmogorov mass w
(x = 0 means Gaussian variance w). Z_K = sum_j x_j (N_j - lam_j) + sigma G with N_j ~ Poisson(lam_j),
lam_j = w_j / x_j^2.
"""
import numpy as np
from math import exp, sqrt, lgamma, log
from scipy.special import erf

SQ2E = sqrt(2 / exp(1))


def pois_pmf(lam, nmax):
    n = np.arange(nmax + 1)
    if lam == 0:
        p = np.zeros(nmax + 1)
        p[0] = 1.0
        return p
    logp = -lam + n * log(lam) - np.array([lgamma(k + 1) for k in n])
    return np.exp(logp)


def law(K, tol=1e-15, nmax_cap=400):
    """Discrete part of Z_K as (values, probs) and the Gaussian sd."""
    vals = np.zeros(1)
    probs = np.ones(1)
    sigma2 = 0.0
    for x, w in K:
        if w <= 0:
            continue
        if x == 0:
            sigma2 += w
            continue
        lam = w / x ** 2
        nmax = int(lam + 12 * sqrt(lam) + 30)
        nmax = min(nmax, nmax_cap)
        p = pois_pmf(lam, nmax)
        keep = p > tol * 1e-3
        n = np.arange(nmax + 1)[keep]
        p = p[keep]
        v = x * (n - lam)
        vals = (vals[:, None] + v[None, :]).ravel()
        probs = (probs[:, None] * p[None, :]).ravel()
        if len(vals) > 2_000_000:
            vals, probs = merge(vals, probs, 1e-12)
    return vals, probs, sqrt(sigma2)


def merge(vals, probs, eps):
    order = np.argsort(vals)
    vals = vals[order]
    probs = probs[order]
    key = np.round(vals / eps).astype(np.int64)
    uniq, idx = np.unique(key, return_index=True)
    sums = np.add.reduceat(probs, idx)
    v = np.add.reduceat(vals * probs, idx) / np.where(sums > 0, sums, 1)
    return v, sums


def gauss_abs(c, s):
    """E|c + s G| elementwise."""
    if s == 0:
        return np.abs(c)
    z = c / s
    return c * erf(z / sqrt(2)) + 2 * s * np.exp(-z * z / 2) / sqrt(2 * np.pi)


def mean_abs(K):
    v, p, s = law(K)
    return float(np.dot(gauss_abs(v, s), p))


def law_small(K, tol=1e-16, cap=200_000, eps=1e-10):
    """As law(), but merges values to an eps-grid after every atom once the support exceeds cap."""
    vals = np.zeros(1)
    probs = np.ones(1)
    sigma2 = 0.0
    for x, w in K:
        if w <= 0:
            continue
        if x == 0:
            sigma2 += w
            continue
        lam = w / x ** 2
        nmax = min(int(lam + 12 * sqrt(lam) + 30), 400)
        p = pois_pmf(lam, nmax)
        keep = p > tol
        n = np.arange(nmax + 1)[keep]
        p = p[keep]
        v = x * (n - lam)
        if len(vals) * len(v) > 8_000_000:
            vals, probs = merge(vals, probs, 1e-7)
        vals = (vals[:, None] + v[None, :]).ravel()
        probs = (probs[:, None] * p[None, :]).ravel()
        if len(vals) > cap:
            vals, probs = merge(vals, probs, eps)
    return vals, probs, sqrt(sigma2)


def mean_abs_small(K):
    v, p, s = law_small(K)
    return float(np.dot(gauss_abs(v, s), p))


def var(K):
    return sum(w for _, w in K)


def ratio(K):
    return mean_abs(K) / sqrt(var(K))


def dirac_value(x):
    """E|Z_{delta_x}| = E|x (N_lam - lam)| with lam = 1/x^2 (variance 1)."""
    return mean_abs([(x, 1.0)])


def stoploss_plus(K, d):
    """E (Z_K - d)_+."""
    v, p, s = law(K)
    return float(np.dot(gauss_abs(v - d, s) + (v - d), p)) / 2
