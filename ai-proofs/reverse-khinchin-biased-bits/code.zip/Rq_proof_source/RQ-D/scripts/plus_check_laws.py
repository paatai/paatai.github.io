"""Cross-check of the Theorem 16 certificate at given laws (float evidence, not part of the proof).

For a law K = sum_i w_i delta_{x_i} + g delta_0 (Kolmogorov measure, mass 1) with 1/2 <= V+ < 4/5:
  chord rates (a+, b+) of K|[tau, A] (Lemma 18), the leaf box B containing them, and the rest
  W'' = K|[-A, tau) + (a+ - a_lo) tau^2 delta_tau + (b+ - b_lo) A^2 delta_A + padding at 0 up to mass mu_B
  (Lemma 20), with its cell (kappa_3, kappa_4).
Reported:
  E|Z_K|;
  E h_B(Z_W'') = E|Z_chord + G_pad| (Z_chord: the chord design with exact rates; float);
  cert = the certified bound beta + eps of that cell (recomputed exactly, as in verify_plus.check_cell);
  J = sup{E h(Y): Y has the moments of Z_W up to degree D}, W = K|[-A, tau) (no excess, no padding),
      h(r) = E|tau (N_a - a+) + A (N_b - b+) + r|: the design's ideal value at K (one Y for all count values,
      as in the certificate's single polynomial phi >= h_B). Float LP (plus_lp_tol.lp_max, t = 1e-9) on the grid
      of heavy_scan.exact_common plus the support of a discrete stand-in for Z_W; the returned measure is checked
      against the rows.
Guaranteed by the proof: E|Z_K| <= E h_B(Z_W'') <= cert and J <= cert (Y + Z_exc + G_pad has the moments of
Z_W''). The per-shift value S = E V_D(W; c(N)) of RQ-C's far_split_hunt.py (a separate Y for each count value,
S >= J) is not related to cert; it is in plus_lp_tol.py.
Usage: python3 plus_check_laws.py CERTFILES...
"""
import hashlib
import json
import math
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import plus_verify_lib as V
import verify_plus as VP
from edge_split_feas import cumulants, moments_from_cumulants
from heavy_box_lp import shift_law
from test_plus_verify import E_abs_Z

TAU, A = 0.85, 1.54
D = 16

# RQ-C NOTES_FOR_TEAM 22:12 UTC, table rows with V+ in [1/2, 4/5): (name, atoms (x, mass), Gaussian mass,
# RQ-C's value of the per-shift bound SB_lo for this design)
LAWS = [
    ("row 1 (V+ 0.5)", [(1.18049, 0.5), (0.8498, 0.43735), (-0.83054, 0.05705), (-0.85, 0.00089)], 0.00471, 0.84024),
    ("row 2 (V+ 0.6)", [(1.17958, 0.6), (0.84985, 0.35216), (-0.81986, 0.04326)], 0.00458, 0.84013),
    ("row 3 (V+ 0.75)", [(1.30, 0.75), (0.8498, 0.204), (-0.75, 0.045)], 0.001, 0.83854),
    ("row 4 (V+ 0.7)", [(1.30, 0.7), (0.8498, 0.2688), (-0.75, 0.03)], 0.0012, 0.83690),
    ("row 6 (V+ 0.5)", [(1.18, 0.5), (0.8498, 0.25), (-0.80, 0.248)], 0.002, 0.82031),
]


def stand_in_support(rest, gauss, nmax=3000):
    """Support of a discrete stand-in for Z_W: the Poisson law of W's atoms convolved with the 8-node Gauss-Hermite
    rule for the Gaussian part (same moments up to degree 15, smaller 16th moment, so feasible for the LPs). Added to
    the LP grids: without it, a lattice-like W (one heavy atom) leaves the grids nearly infeasible and the LP values
    too low."""
    c, p = np.array([0.0]), np.array([1.0])
    for x, w in rest:
        if w <= 0:
            continue
        lam = w / x ** 2
        n = np.arange(int(lam + 15 * np.sqrt(lam) + 30))
        q = np.exp(-lam + n * np.log(lam) - np.array([math.lgamma(i + 1) for i in n]))
        cc = (c[:, None] + x * (n - lam)[None, :]).ravel()
        pp = (p[:, None] * q[None, :]).ravel()
        keep = pp > 1e-15
        u, inv = np.unique(np.round(cc[keep], 12), return_inverse=True)
        c, p = u, np.bincount(inv, weights=pp[keep])
    if gauss > 0:
        t, wt = np.polynomial.hermite.hermgauss(8)
        c = (c[:, None] + math.sqrt(2 * gauss) * t[None, :]).ravel()
        p = (p[:, None] * wt[None, :] / math.sqrt(math.pi)).ravel()
    return c[np.argsort(p)[-nmax:]]


def chord_rates(edge):
    ap = sum(w / x ** 2 * (A - x) / (A - TAU) for x, w in edge)
    bp = sum(w / x ** 2 * (x - TAU) / (A - TAU) for x, w in edge)
    return ap, bp


def find_box(recs, ap, bp):
    for r in recs:
        if r["status"] != "ok":
            continue
        a1, a2, b1, b2 = (float(z) for z in VP.box_of(*r["box"]))
        if a1 <= ap <= a2 and b1 <= bp <= b2:
            return r
    return None


def cell_bound(rec, k3, k4):
    """(cell id, status, exact certified bound as a float upper end) of the cell of rec containing (k3, k4)."""
    box = VP.box_of(*rec["box"])
    info = V.box_info(*box)
    mu, cap = info["mu"], info["cap"]
    root = V.root_cell(mu, cap)
    for c in rec["certs"]:
        cell = V.cell_of(root, *c["cell"])
        lo3, hi3, lo4, hi4 = (float(t) for t in cell)
        if lo3 <= k3 <= hi3 and lo4 <= k4 <= hi4:
            break
    else:
        return None, "no cell", None
    if c["status"] != "ok":
        return c["cell"], c["status"], None
    rm = {int(k): v for k, v in c["rmult"].items()}
    L, U = V.kappa_ranges(D, mu, cap, cell, rm)
    if any(L[j] > U[j] for j in L):
        return c["cell"], "empty ranges", None
    eps = V.phi_check(c["coef"], box[0], box[2], c["Lt"])
    B = V.lagrangian_bound(c["coef"], D, mu, cap, cell, L, U, VP.dec_mult(c["mult"]))
    return c["cell"], "ok", float((B + eps).upper())


def check_law(name, atoms, gauss, sb_rqc, recs):
    edge = [(x, w) for x, w in atoms if TAU <= x <= A]
    rest = [(x, w) for x, w in atoms if not TAU <= x <= A]
    vplus = sum(w for _, w in edge)
    mass = sum(w for _, w in atoms) + gauss
    ap, bp = chord_rates(edge)
    ek = E_abs_Z(atoms, gauss)

    import plus_lp_tol as PT

    c, p = shift_law([(x, lam) for x, lam in [(TAU, ap), (A, bp)] if lam > 1e-12])
    mom = moments_from_cumulants(cumulants(rest, gauss, D), D)
    sc, z, Am, b = PT.lp_data(c, mom, stand_in_support(rest, gauss))
    J, st_j, viol_j = PT.lp_max(np.abs(c[None, :] + sc * z[:, None]) @ p, Am, b, 1e-9)

    print(f"{name}: mass {mass:.5f}, V+ {vplus:.5f}, (a+, b+) = ({ap:.5f}, {bp:.5f}), {len(c)} count values; "
          f"E|Z_K| = {ek:.5f}")
    print(f"    J (one Y) = {J:.5f} (HiGHS status {st_j}, row violation of its measure {viol_j:.1e});  RQ-C's SB_lo "
          f"{sb_rqc:.5f} (per shift; see rqc_sblo_feasibility.py)")
    rec = find_box(recs, ap, bp)
    if rec is None:
        print("    rates in no certified box")
        return False
    a1, a2, b1, b2 = (float(z) for z in VP.box_of(*rec["box"]))
    info = V.box_info(*VP.box_of(*rec["box"]))
    mu = float(info["mu"])
    exc = [(TAU, (ap - a1) * TAU ** 2), (A, (bp - b1) * A ** 2)]
    wat = rest + exc
    pad = mu - (sum(w for _, w in wat) + gauss)
    k3 = sum(w * x for x, w in wat)
    k4 = sum(w * x * x for x, w in wat)
    ehb = E_abs_Z([(TAU, a1 * TAU ** 2), (A, b1 * A ** 2)] + wat, gauss + pad)
    cell, st, cb = cell_bound(rec, k3, k4)
    print(f"    box {rec['box']} = [{a1:.5f}, {a2:.5f}] x [{b1:.5f}, {b2:.5f}], mu_B {mu:.5f}, padding {pad:.5f}; "
          f"(kappa_3, kappa_4) = ({k3:.5f}, {k4:.5f}) in cell {cell} ({st})")
    if cb is None:
        print("    no certified bound for this cell")
        return False
    ok = pad >= -1e-12 and ek <= ehb + 1e-9 and ehb <= cb and st_j == 0 and viol_j <= 1e-6 and J <= cb + 1e-6
    print(f"    E h_B(Z_W'') = {ehb:.5f};  certified cell bound {cb:.6f} (C5 - bound = {0.85510045547 - cb:.5f});  "
          f"E|Z_K| <= E h_B <= cert and J <= cert: {ok};  cert - J = {cb - J:.5f}")
    return ok


def main():
    print(f"start {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC")
    here = os.path.dirname(os.path.abspath(__file__))
    for fn in [os.path.abspath(__file__), os.path.join(here, "plus_lp_tol.py")] + sys.argv[1:]:
        with open(fn, "rb") as f:
            print(f"md5 {hashlib.md5(f.read()).hexdigest()}  {os.path.basename(fn)}")
    recs = []
    for fn in sys.argv[1:]:
        with open(fn) as f:
            recs += [json.loads(line) for line in f if line.strip()]
    print(f"{len(recs)} box records; D = {D}")
    res = [check_law(*law, recs) for law in LAWS]
    print(f"end {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC")
    print("ALL CONSISTENT" if all(res) else "INCONSISTENCY FOUND")
    return 0 if all(res) else 1


if __name__ == "__main__":
    sys.exit(main())
