"""Float helpers for exploration (evidence only, never proof).

Bernoulli form: x_i ~ Bern(q) i.i.d., xi_i = x_i - q, L = sum alpha_i chi_i = sum alpha_i xi_i / tau.
"""
import numpy as np
from math import comb, sqrt


def tau(q):
    return sqrt(q * (1 - q))


def dist(alpha, q):
    """Exact law of sum alpha_i xi_i as (values, probs), 2^n atoms (not merged)."""
    vals = np.zeros(1)
    probs = np.ones(1)
    for a in alpha:
        vals = np.concatenate([vals - q * a, vals + (1 - q) * a])
        probs = np.concatenate([probs * (1 - q), probs * q])
    return vals, probs


def mean_abs(alpha, q):
    v, p = dist(alpha, q)
    return float(np.dot(np.abs(v), p))


def ratio(alpha, q):
    """E|sum alpha_i chi_i| / |alpha|_2."""
    alpha = np.asarray(alpha, dtype=float)
    return mean_abs(alpha, q) / tau(q) / np.linalg.norm(alpha)


def Mconj(q):
    """Conjectured R(q) for q <= 1/2: 2 tau max_k sqrt(k) (1-q)^(k-1)."""
    p = 1 - q
    best = 0.0
    for k in range(1, 10 ** 6):
        v = sqrt(k) * p ** (k - 1)
        if v > best:
            best = v
        elif k * q > 2:
            break
    return 2 * tau(q) * best


def kstar(q):
    p = 1 - q
    vals = [sqrt(k) * p ** (k - 1) for k in range(1, int(3 / q) + 3)]
    return int(np.argmax(vals)) + 1


class AbsShift:
    """Fast evaluation of c -> E|M + c| for a finite law (values, probs)."""

    def __init__(self, vals, probs):
        o = np.argsort(vals)
        self.v = vals[o]
        self.p = probs[o]
        self.cp = np.concatenate([[0.0], np.cumsum(self.p)])
        self.cvp = np.concatenate([[0.0], np.cumsum(self.v * self.p)])
        self.tot_p = self.cp[-1]
        self.tot_vp = self.cvp[-1]

    def __call__(self, c):
        c = np.asarray(c, dtype=float)
        # E|M + c| = sum_{v > -c} (v + c) p - sum_{v <= -c} (v + c) p
        k = np.searchsorted(self.v, -c, side="right")
        lowp = self.cp[k]
        lowvp = self.cvp[k]
        upp = self.tot_p - lowp
        upvp = self.tot_vp - lowvp
        return (upvp + c * upp) - (lowvp + c * lowp)
