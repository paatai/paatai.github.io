"""Float search (evidence only): sup of the whole-law moment relaxation V_D(K) over laws K with all jumps in
(-0.85, 0.85) (up to three atoms plus a Gaussian part). These are the far-region laws on which the edge split at
tau_e = 0.85 gives nothing, so their V_D is what a degree-D residual certificate must beat. RQ-A's U.9 already
covers int |x| dK <= 0.114431; the search reports int |x| dK for every improvement.

Usage: python3 resid_vD_sup.py D NSTARTS SEED
"""
import math
import sys

import numpy as np
from scipy.optimize import minimize

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from edge_split_feas import cumulants, moments_from_cumulants, sup_abs_shift, resid_support

T = 0.85


def unpack(u):
    x = T * np.tanh(u[:3])
    e = np.exp(u[3:7] - np.max(u[3:7]))
    w = e / e.sum()
    return x, w


def vd(u, D, npts=1001):
    x, w = unpack(u)
    if np.any(np.abs(x) < 0.02):
        return 0.0, None
    atoms = [(float(a), float(b)) for a, b in zip(x, w[:3]) if b > 1e-9]
    wG = float(w[3])
    mom = moments_from_cumulants(cumulants(atoms, wG, D), D)
    v = sup_abs_shift(0.0, mom, D, npts=npts, extra=resid_support(atoms, wG) if wG < 1e-9 else None)
    if not np.isfinite(v):
        return 0.0, None
    return v, (atoms, wG)


def main():
    D, nst, seed = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    rng = np.random.default_rng(seed)
    structured = [np.array([3.0, -2.5, 0.5, 2.0, -1.0, -3.0, -4.0]),
                  np.array([3.0, -3.0, 0.5, 2.0, -0.5, -3.0, -4.0]),
                  np.array([1.2, -2.0, 0.3, 1.0, -1.0, -2.0, 0.0])]
    best = -1
    for s in range(nst):
        if seed == 1 and s < len(structured):
            u0 = structured[s]
        else:
            u0 = np.concatenate([rng.normal(0, 1.5, 3), rng.normal(0, 1.5, 4)])
        r = minimize(lambda u: -vd(u, D)[0], u0, method="Nelder-Mead",
                     options={"maxiter": 300, "xatol": 1e-5, "fatol": 1e-7})
        v, law = vd(r.x, D, npts=4001)
        if law is not None and v > best:
            best = v
            atoms, wG = law
            l1 = sum(abs(a) * b for a, b in atoms)
            desc = ", ".join(f"{b:.4f} d_{a:+.4f}" for a, b in atoms)
            print(f"D={D} seed {seed} start {s}: V_D = {v:.5f}  K = {desc} + {wG:.4f} G   int|x|dK = {l1:.4f}",
                  flush=True)
    print(f"D={D} seed {seed} BEST {best:.5f}", flush=True)


if __name__ == "__main__":
    main()
