"""Exploration (float, evidence only).

T1: for alpha >= 0, pair (i, j), M = rest: does theta -> E|M + r(cos t xi_i + sin t xi_j)|
    attain its max over [0, pi/4] at an endpoint?  Also: does every non-constant alpha
    have at least one 'improvable' pair (endpoint value >= current value)?
T2: sign lemma  E|sum alpha_i xi_i| <= E|sum |alpha_i| xi_i| ?
"""
import sys
import numpy as np
from core import dist, AbsShift, mean_abs, tau, Mconj

rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 1)


def pair_profile(alpha, i, j, q, thetas):
    rest = [alpha[k] for k in range(len(alpha)) if k not in (i, j)]
    v, p = dist(rest, q) if rest else (np.zeros(1), np.ones(1))
    F = AbsShift(v, p)
    r = np.hypot(alpha[i], alpha[j])
    a = r * np.cos(thetas)
    b = r * np.sin(thetas)
    P = 1 - q
    g = (P * P * F(-q * (a + b)) + q * P * F(P * a - q * b) + q * P * F(P * b - q * a)
         + q * q * F(P * (a + b)))
    return g


def T1(q, n, trials, positive=True):
    thetas = np.linspace(0, np.pi / 4, 201)
    bad_pairs = 0
    tot_pairs = 0
    no_improvable = 0
    worst = 0.0
    worst_ex = None
    for _ in range(trials):
        kind = rng.integers(3)
        if kind == 0:
            alpha = rng.random(n)
        elif kind == 1:
            alpha = np.abs(rng.normal(size=n))
        else:
            alpha = rng.random(n) ** 3
        if not positive:
            alpha = alpha * rng.choice([-1, 1], size=n)
        alpha /= np.linalg.norm(alpha)
        cur = mean_abs(alpha, q)
        found = False
        for i in range(n):
            for j in range(i + 1, n):
                g = pair_profile(alpha, i, j, q, thetas)
                tot_pairs += 1
                ex = g.max() - max(g[0], g[-1])
                if ex > 1e-12:
                    bad_pairs += 1
                    if ex > worst:
                        worst = ex
                        worst_ex = (alpha.copy(), i, j)
                # improvable: endpoint value >= current value (strictly with tolerance)
                if max(g[0], g[-1]) >= cur - 1e-14 and abs(abs(alpha[i]) - abs(alpha[j])) > 1e-9:
                    found = True
        if not found:
            no_improvable += 1
    return bad_pairs, tot_pairs, no_improvable, worst, worst_ex


def T2(q, n, trials):
    worst = -1.0
    ex = None
    for _ in range(trials):
        alpha = rng.normal(size=n)
        if rng.random() < 0.5:
            alpha = np.abs(alpha) * rng.choice([-1, 1], size=n, p=[0.2, 0.8])
        alpha /= np.linalg.norm(alpha)
        d = mean_abs(alpha, q) - mean_abs(np.abs(alpha), q)
        if d > worst:
            worst = d
            ex = alpha.copy()
    return worst, ex


if __name__ == "__main__":
    for q in [0.05, 0.1, 0.15, 0.2, 0.3]:
        for n in [4, 6, 8]:
            b, t, ni, w, wex = T1(q, n, 150, positive=True)
            print(f"T1 pos q={q} n={n}: bad pairs {b}/{t}, alphas w/o improvable pair {ni}/150,"
                  f" worst interior excess {w:.3e}")
            if wex is not None and w > 1e-6:
                a, i, j = wex
                print("   example:", np.round(a, 4), i, j)
        w, ex = T2(q, 8, 3000)
        print(f"T2 q={q}: max E|L(alpha)| - E|L(|alpha|)| = {w:.3e}", np.round(ex, 3) if w > 0 else "")
        sys.stdout.flush()
