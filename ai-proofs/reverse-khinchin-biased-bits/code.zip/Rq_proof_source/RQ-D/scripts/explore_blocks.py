"""Exploration (float, evidence only): block (level) moves.

alpha has levels a_1 > ... > a_r > 0 with multiplicities k_1..k_r.  For a chosen level j,
t -> ratio(alpha with level j value replaced by t), t in [t_lo, t_hi] where t_lo = 0 (remove)
or the next lower level, and t_hi = next higher level (merge up).  Question: is the max of the
ratio over t attained at an endpoint?
Exact law via binomial convolution (levels with multiplicities), so n can be large.
"""
import sys
import numpy as np
from math import comb, sqrt

rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 3)


def level_law(levels, mults, q):
    """Law of sum_j a_j (B_j - k_j q), B_j ~ Bin(k_j, q) independent; returns (vals, probs)."""
    vals = np.zeros(1)
    probs = np.ones(1)
    for a, k in zip(levels, mults):
        bv = np.array([a * (i - k * q) for i in range(k + 1)])
        bp = np.array([comb(k, i) * q ** i * (1 - q) ** (k - i) for i in range(k + 1)])
        vals = (vals[:, None] + bv[None, :]).ravel()
        probs = (probs[:, None] * bp[None, :]).ravel()
    return vals, probs


def ratio_levels(levels, mults, q):
    v, p = level_law(levels, mults, q)
    nrm = sqrt(sum(k * a * a for a, k in zip(levels, mults)))
    return float(np.dot(np.abs(v), p)) / sqrt(q * (1 - q)) / nrm


def block_profile(levels, mults, j, q, npts=161):
    lo = levels[j + 1] if j + 1 < len(levels) else 0.0
    hi = levels[j - 1] if j > 0 else levels[j] * 3
    ts = np.linspace(lo, hi, npts)
    out = []
    for t in ts:
        lv = list(levels)
        lv[j] = t
        out.append(ratio_levels(lv, mults, q))
    return ts, np.array(out)


def M(q):
    p = 1 - q
    return 2 * sqrt(q * p) * max(sqrt(k) * p ** (k - 1) for k in range(1, int(4 / q) + 2))


tot = 0
viol = 0
worst = 0
for q in [0.04, 0.07, 0.1, 0.13, 0.16, 0.2, 0.25]:
    for trial in range(60):
        r = rng.integers(2, 4)
        mults = list(rng.integers(1, 7, size=r))
        levels = sorted(rng.random(r) + 0.05, reverse=True)
        for j in range(r):
            ts, prof = block_profile(levels, mults, j, q)
            tot += 1
            ex = prof.max() - max(prof[0], prof[-1])
            if ex > 1e-10:
                viol += 1
                if ex > worst:
                    worst = ex
                    print(f"  q={q} levels={np.round(levels,3)} mults={mults} j={j}: interior excess {ex:.3e}"
                          f" at t={ts[prof.argmax()]:.3f}; endpoints {prof[0]:.5f},{prof[-1]:.5f}; M={M(q):.5f}")
                    sys.stdout.flush()
print(f"block moves: {viol}/{tot} with interior maximum; worst excess {worst:.3e}")
