# RQ-D: a non-moment mechanism for Conjecture S

Research repository of solver RQ-D in the R(q) team (see `/cursor/stores/bot/rq/COMMON.md`).

**Problem.** For q in (0,1) let chi_i be i.i.d. with chi = sqrt((1-q)/q) w.p. q and chi = -sqrt(q/(1-q)) w.p. 1-q.
R(q) = sup E|sum alpha_i chi_i| / ||alpha||_2. Conjecture S: R(q) = 2 sqrt(q(1-q)) max_{k>=1} sqrt(k) qh^(k-1),
qh = max(q, 1-q), with equal coefficients on k coordinates (OR_k) as extremisers. Proved and audited by the team on
[1 - sqrt3/2, sqrt3/2].

**RQ-D's mechanism.** The band lemmas (Theorems 10 and 13) use no moment-polynomial certificates. Their tools are

1. the exact *flip formula* E|Y + W| = E|Y| + 2E[(-sgn(Y) W - |Y|)_+] for independent Y, W with E W = 0;
2. the *OR-region identity*: if the large part Y of the sum has every jump above its compensator, then E|Y| is an
   explicit OR-type value, so all the error sits in tail ("stop-loss") terms of the residual W;
3. explicit, non-moment bounds for those stop-loss terms (single-jump expansion plus Poisson/Bernoulli tail
   comparison).

4. a *comparison lemma*: pushing jumps to the right increases E psi(Z_K) whenever psi'' is nondecreasing, which bounds
   the stop-loss terms by two-point laws.

**Results** (details and audit status in `CLAIMS.md`; proofs in `MAIN_RESULT.pdf`):

- **Theorem 10 (band lemma for C5; audit A.32 VALID).** E|Z_K| <= sqrt(2/e) for every probability K on
  [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10 or K([-sqrt2, -1]) >= 9/10. **Corollary 11:** C5 reduces to the far
  region.
- **Theorem 13 (ID* band lemma at theta = 0.85, A = 1.54; audit A.34 VALID, refereed VALID).** E|Z_K| <= max(g(lambda+_0.85(K)), C_5)
  for every finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, and the mirror
  statement. **Corollary 14:** with the team's audited reductions, Conjecture S for all q then needs only
  E|Z_K| <= C_5 on the far region {K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5}.
- **Theorem 16 (heavy part of the far region; audit A.38 VALID, refereed VALID).** E|Z_K| < C_5 for every probability K on
  [-1.54, 1.54] with 1/2 <= K([0.85, 1.54]) < 4/5, and the mirror statement. The jumps in [0.85, 1.54] are replaced by
  their chord law (a convex-order increase) and fixed on boxes of the two chord rates. The rest of K enters through a
  degree-16 polynomial majorant and a Lagrangian bound on cumulant cells. **Corollary 17:** Conjecture S for all q
  then needs only E|Z_K| <= C_5 on the light part {K([0.85, 1.54]) < 1/2 and K([-1.54, -0.85]) < 1/2} (RQ-B's part).
  With RQ-A's MAIN-6 (audit A.37 VALID), C_6 = 0.8559845 suffices there.

All three theorems are computer-assisted. Every inequality the proofs need is checked in exact rational or ball
arithmetic. Theorems 13 and 16, Corollaries 14, 15 and 17 and the lemmas of Sections 2-4 were refereed VALID by the
team's independent referee (RQ-REF3, 2026-10-23). The referee re-verified the Theorem 16 certificates with its own
code and re-did the Theorem 13 computation with its own cover. Theorem 10
was not refereed, because the all-q chain does not use it. With the other links of the chain, Conjecture S holds for
all q in (0, 1).

Following the referee's remark 2, the Theorem 13 run is also stored box by box in `outputs/bandstar_cert/`. For each
of the 7,874,211 leaf boxes, the record holds the method, the option and h. A separate checker replays the record (see
"Box-level record of Theorem 13" below).

## Layout

| Path | Content |
|---|---|
| `CLAIMS.md` | every claim, tagged PROVED / CONDITIONAL / NUMERICAL / FAILED |
| `STATUS.md` | what is established, the exact failure point, the next lemma |
| `MAIN_RESULT.tex` / `.pdf` | write-up of the claimed results (full proofs) |
| `AUDIT_REQUEST.md` | claims submitted to RQ-AUD |
| `NOTES_FOR_TEAM.md` | coordination notes for RQ-A / RQ-B / RQ-C |
| `scripts/` | exploration (float, evidence only) and certified checks (exact / interval) |
| `outputs/` | outputs of the scripts |

## Running

Python 3 with `numpy`, `scipy`, `mpmath` and `python-flint` (arb, for the certified checks). Certified checks
(versions in `outputs/verify_band_env.txt` and `outputs/verify_bandstar_env.txt`):

```bash
python3 scripts/verify_band.py S       # Theorem 10, part S (seconds)
python3 scripts/verify_band.py B       # Theorem 10, part B (8 processes, about 2 min)
python3 scripts/verify_bandstar.py all 0.0078125 8 outputs/verify_bandstar_squares.jsonl   # Theorem 13 (about 13 min)
PYTHONPATH=scripts python3 scripts/verify_bandstar_controls.py 8                         # controls for Theorem 13
python3 -B scripts/bandstar_record.py all 8 outputs/bandstar_cert         # Theorem 13 again, recording every leaf box (about 13 min)
python3 -B scripts/bandstar_replay.py outputs/bandstar_cert 8             # replay of the record (about 30 s)
python3 -B scripts/bandstar_replay.py outputs/bandstar_cert 8 selftest    # tampered records must be rejected
cd scripts
python3 verify_plus.py ../outputs/plus_cert/certs_v1_r[0-4].jsonl --nproc 8       # Theorem 16 (about 25 s)
python3 verify_plus_controls.py ../outputs/plus_cert/certs_v1_r[0-4].jsonl        # controls for Theorem 16
python3 test_plus_verify.py ../outputs/plus_cert/certs_v1_r0.jsonl                # float self-tests, per file
cd ..
```

The Theorem 16 certificates were generated by `scripts/plus_driver.py v1 4 4 2 4` (float LPs in
`scripts/plus_cert.py`, which needs `highspy`); the generator is not part of the proof.

### Box-level record of Theorem 13

The published run of `verify_bandstar.py` keeps only one summary line per (a, b) square.

- **Recording.** `scripts/bandstar_record.py` imports `verify_bandstar.py` unchanged (md5 b5b55cee…, checked) and
  reruns the same computation. Hooks only watch the run. They store each accepted (Lambda, m) box of each certified
  square, with the method that accepted it and the parameters it used:
  - infeasible: which of the inequalities (F1)-(F5) fails;
  - (O1)-(O4): the h values, plus the far point for (O3) and the t-grid point for (O2);
  - slope: the rho^2 pieces, and for each piece the test and the three linear options.
- **Result** (`outputs/bandstar_cert/record.txt`, `record_summary.json`). All 1676 squares, at every level, match the
  published log `outputs/verify_bandstar_squares.jsonl` (same outcome, same box count). The record has 1339 squares
  and 7,874,211 leaf boxes, 426 of them slope leaves.
- **Format** (a shorter version is in the docstring of `scripts/bandstar_replay.py`). `bandstar_leaves.npz` holds
  numpy arrays. Units: a and b in 1/8192, corners in 2^-24, Lambda in 1/16384, m in 1/4096.
  - `HGRID`, `HMV`, `HLIN`: the h values (floats, used exactly as stored). `grid` = [4096, 16384, 8192, 2^24, 4096,
    2125, 4820]: the denominators of m, Lambda, (a, b), corners and r, then the m range [2125, 4820]/4096.
  - Per certified square s: `sq_box[s]` = [a1, a2, b1, b2]; `sq_corner[s]`, the corner (a_bar, b_bar) at which the
    costs are evaluated; `sq_strips[s]` = [i0, i1), the Lambda strips [i/64, (i+1)/64]; `sq_nbox[s]`, the number of
    (Lambda, m) boxes examined. `sq_h[s, c, k - 2125]` is the index in `HGRID` of the h used at m = k/4096 for
    c = 0: c_B (at t = m), 1: c_C (at 2 theta - m), 2: phi(theta - m) through chi^C_h, 3: phi(theta - m) through
    -2y + chi^B_h(-y), 4: phi(A - m). The leaves of s are the j with `sq_off[s]` <= j < `sq_off[s + 1]`, in the
    order of acceptance.
  - Per leaf j: the box Lambda in [`leaf_L1`, `leaf_L2`]/16384, m in [`leaf_k1`, `leaf_k2`]/4096, and the method
    `leaf_meth`: 0 infeasible, 1 (O1), 2 (O3), 3 (O4), 4 (O2), 5 slope (the names are in `methods`, and those of the
    rows of `sq_h` in `hnames`).
    - Infeasible: `leaf_opt` is the inequality that fails on the whole box for every V of the square, numbered 1-8:
      (F1) Lambda >= V/A^2, (F1) Lambda <= V/theta^2, (F2) m >= V/A, (F2) m <= V/theta, (F3) m >= theta Lambda,
      (F3) m <= A Lambda, (F4) m^2 <= Lambda V, (F5).
    - (O3): `leaf_opt` is the index of h in `HMV`, and `leaf_aux` = kx gives the far point theta - kx/4096, which
      is admissible if kx/4096 >= m_2 - u'. (O2): `leaf_opt` likewise, and `leaf_aux` = jt gives t = jt/4096, which
      is admissible if t <= m_1 - mu_hi. (O1) takes its h values from rows 2-4 of `sq_h`, and (O4) uses none; for
      both, `leaf_opt` = `leaf_aux` = 0.
    - Slope: `leaf_aux` is the index into `bandstar_slope.json`.
  - `bandstar_slope.json` has one entry {sq, leaf, box, pieces} per slope leaf. Each piece {path, test, jr, B, O, C2}
    is the part of [r_0, r_B] (the range of rho^2) given by its bisection path ('0' lower half, '1' upper half).
    test is E (empty by (F4)), T1, T2, T3 or T3K ((T3) with (O5)); r_eff = min(jr/4096, 1/50). B and C2 are
    ['lin', i] (h = `HLIN[i]`) or ['cs']; O is ['chord', P1, P2] (P1, P2 tagged like B), ['O3', i] or ['O5', i]
    (again h = `HLIN[i]`), or ['O4'].
- **Replay.** `scripts/bandstar_replay.py` checks the record without the search code. Each step decides its
  inequalities in arb:
  1. the certified squares form a quadtree cover of the triangle {a, b >= 0, a + b <= 1/5};
  2. each square's corner, r^2 and V range are recomputed in exact rationals, and its (Lambda, m) rectangle contains
     every point allowed by (F1)-(F2);
  3. the leaves, in their recorded order, are exactly the leaves of a bisection of that rectangle;
  4. every leaf passes its recorded certificate.
- **What the checker shares with `verify_bandstar.py`:** only the enclosures of chi^B_h and chi^C_h and the linear
  bounds (`chiB`, `chiC`, `lin_B`, `lin_C`). Everything else follows MAIN_RESULT Section 6.1.
- **Outcome.** The replay rated the record VALID in 29 s: every leaf holds, with the same counts per method as the
  published run (`outputs/bandstar_cert/replay.txt`). In the self-test (`replay_selftest.txt`), every tampered record
  is rejected: a dropped or moved leaf, a false infeasibility claim, a moved far point, a removed rho^2 piece, (O5)
  under test (T3), and the target lowered by 0.001.
- **Independent replay.** RQ-AUD read the format off the data and checked every leaf with its own verifier, without
  this code (AUDIT.md, A.34 addendum of 2026-10-23 04:51 UTC). All 7,874,211 leaves are certified, and the record is
  VALID.

Exploration and float tests (evidence only):

```bash
cd scripts && python3 bandstar_soundness2.py 0.2 400   # float soundness test of every ingredient of Theorem 13
cd ..
python3 scripts/explore_pairs2.py      # pair endpoint tests (float)
python3 scripts/explore_blocks.py      # level/block moves (float)
python3 scripts/pair_bellman.py 0.3 80 21 40   # two-copy Bellman relaxation (float)
cd scripts
python3 plus_check_laws.py ../outputs/plus_cert/certs_v1_r[0-4].jsonl   # Theorem 16 certificate vs E|Z_K| and the design's value J at RQ-C's five heavy laws
python3 plus_lp_tol.py           # J and a checked per-shift lower estimate at LP tolerances 1e-11..1e-6
python3 plus_scan_recheck.py     # the best plus_scan law, with an LP measure checked against the rows
python3 rqc_sblo_feasibility.py  # row violations of the LP measures behind RQ-C's 22:12 values (RQ-C's code, from the store)
cd ..
```

`rqc_sblo_feasibility.py` imports RQ-C's current `far_split_hunt.py` from the team store. The run in
`outputs/plus_cert/rqc_sblo_feasibility.txt` used RQ-C's 22:12 version (md5 d43ccca9…), and the run in
`outputs/plus_cert/rqc_sblo_feasibility_rqc_fixed.txt` used the version after RQ-C's 23:00 correction (26eebf70…).

HiGHS can report "optimal" for a moment LP whose returned measure violates the rows; these scripts report the
violation with every value.

Build the PDF with `latexmk -pdf MAIN_RESULT.tex`. Mirror to the team store with `bash mirror.sh`.
