# STATUS (RQ-D)

Last update: 2026-10-23 08:43 UTC. Deadline Sun Oct 25 2026 22:30 PT (Mon Oct 26 05:30 UTC).

## Task
Conjecture S for all q by a non-moment mechanism. Assignment (RQ-A 15:58): **RQ-D owns the band lemma** (ID band,
finite-q band, negative-jump flips). The form needed (A.26 + A.28, with A.25 = MAIN-5): for every finitely supported
probability K on [-1.54, 1.54], some theta = theta(K) with
E|Z_K| <= max(g(lambda+_theta), g(lambda-_theta), C_5), C_5 = g(2 ln 5/4) = 0.85510045547...
Since 20:00 UTC (agreed with RQ-B): **RQ-D also owns the heavy far region F_heavy** = F intersected with
{V+ >= 1/2 or V- >= 1/2}, where V+ = K([0.85, 1.54]) and V- = K([-1.54, -0.85]). RQ-B owns F_light = {V+ < 1/2, V- < 1/2}.

## Established (MAIN_RESULT.pdf; CLAIMS.md)
- D1, D2 (A.30: D1 VALID; D2 VALID WITH FIXES, fix f1 applied, re-rated VALID 17:23 UTC).
- D6-D12 (**A.32 VALID, 18:17 UTC**): comparison lemma, stop-loss bounds, band bound (F); **Theorem 10** (E|Z_K| <=
  sqrt(2/e) on {K([1, sqrt2]) >= 9/10} or the mirror); **Corollary 11** (C5 reduces to a far region).
- D16-D20 (**A.34 VALID, 20:19 UTC**): **Theorem 13** (ID* band lemma at theta = 0.85, A = 1.54, certified in arb),
  **Corollary 14** (ID*(C_5) on [-1.54, 1.54] reduces to F = {V+ < 4/5, V- < 4/5}), **Corollary 15** (C5 reduces to
  the same F).
- D21-D23 (**A.38 VALID, no fix, 22:51 UTC**; Theorem 16 and Corollary 17 rated NEW):
  - **Theorem 16 (D22), certified in arb:** E|Z_K| < C_5 for every probability Kolmogorov measure K on [-1.54, 1.54]
    with 1/2 <= V+ < 4/5, or with 1/2 <= V- < 4/5. Lemmas 18-24 (D21) are the reductions.
  - Certificate: 436 boxes (280 certified with 1237 cell certificates, 156 empty), 0 failures, worst bound
    0.854883 < C_5. `scripts/verify_plus.py`, `outputs/plus_cert/verify_v1.txt`. RQ-C re-ran it from private copies
    at 23:15 UTC (same md5s, "ALL CHECKS PASSED").
  - **Corollary 17 (D23):** ID*(C_5), hence Conjecture S for all q (with A.25, A.26, A.28), and C5 reduce to
    E|Z_K| <= C_5 on F_light (finitely supported K on [-1.54, 1.54]).
- **Refereed VALID by RQ-REF3 (FINAL, 03:09 UTC on 23 Oct; `/cursor/stores/bot/rq/RQ-REF3/REFEREE.md`).** Link 3,
  "RQ-D MAIN_RESULT Sections 2-7", is VALID: D1, D2, D6-D10 and D16-D23.
  - Sections 2-7 were checked by hand.
  - The Theorem 16 certificates were re-verified with RQ-REF3's own exact code. The worst bound is 0.8548832, in the
    same box and cell as mine.
  - The computation of Theorem 13 was re-done from scratch with RQ-REF3's own exact cover: 1212 squares and
    9,077,343 leaf boxes, every square certified.
  - D11 (Theorem 10) and D12 (Corollary 11) were not refereed, because the chain does not use them.
  - **Overall verdict: VALID, Conjecture S holds for all q in (0, 1).** With A.40 this meets the LOCKED_NOTE
    criterion, and the coordinator reported it to Paata at 20:10 PT (03:10 UTC).
- **RQ-REF3's robustness remark 2 (for me; no effect on validity) is done (04:22 UTC).** My run of
  `verify_bandstar.py` stored only per-square summaries, so it could not be replayed box by box. Now:
  - `scripts/bandstar_record.py` reruns it with `verify_bandstar.py` imported unchanged, and stores every leaf box
    with its method, option and h (`outputs/bandstar_cert/`). All 1676 squares match the published log, and the
    record has 1339 squares and 7,874,211 leaf boxes, including 426 slope certificates.
  - `scripts/bandstar_replay.py` replays the record without the search code: cover of the triangle, tiling of every
    square, every leaf certificate in arb. It rated the record VALID in 29 s, with the same counts per method.
  - Its self-test rejects every tampered record.
  - The recording changed no refereed file (MAIN_RESULT.tex 212c6f23…, `verify_bandstar.py` b5b55cee…,
    certs_v1_r0..r4).
- **RQ-AUD replayed the record leaf by leaf with its own verifier (A.34 addendum, 04:51 UTC).** All 7,874,211
  leaves are certified, the record is VALID, and A.34 stays VALID. This is the fourth check of the Theorem 13
  computation, after my run, RQ-AUD's own A.34 run and RQ-REF3's cover.
- **Text-only fixes applied (05:35 UTC; note at the top of AUDIT_REQUEST.md):**
  - A.34 f1: tex line 617, the range where g > C_5 ends at 0.5579, not 0.5599;
  - tex line 652 (RQ-AUD 04:51, cosmetic): the hypotenuse range of the 1/1024 squares starts at 0.1972, not 0.1973;
  - A.34 r3: the Dirac range in CLAIMS D13 (NUMERICAL) is now [1.3388681…, 1.4969001…] (lower end corrected at
    07:40 UTC for A.34 r4).
  - MAIN_RESULT.tex ac0ecf4f… differs from the refereed 212c6f23… only in these two lines (`audit_diffs/`).
    `verify_bandstar.py`, the record and the Theorem 16 files are unchanged.
- **RQ-AUD confirmed these fixes (A.34 addendum, 06:58 UTC; check a34i).** They are text only, and A.34 and A.38 stay
  VALID. f1, r3 and the line-652 remark are settled, and the tex ac0ecf4f… is the version to quote in FULL_PROOF.pdf.
  - The only new item was A.34 r4 (cosmetic): D13 had copied a rounded lower end with an ellipsis. It now reads
    1.3388681… (07:40 UTC). RQ-AUD confirmed it at 07:48 UTC (check a34j), so nothing is open on A.34.
  - My own sweep of every decimal written with an ellipsis in CLAIMS, STATUS, README, AUDIT_REQUEST, NOTES and
    MAIN_RESULT.tex found no other such figure (9 distinct figures).

## Since A.38 (addendum to the third request, 23:25 UTC; text and float evidence only)
- **RQ-AUD's addendum to A.38 (01:05 UTC):** the changes after the verdict are text only; A.38 stays VALID, and r3 is
  settled.
- MAIN_RESULT 7.4 has two text changes: the certificate file layout (A.38 remark r3), and "The design's value (not
  part of the proof)", which replaces the filed sentence "the float supremum ... is about 0.8387". Searches found the
  design's value J up to 0.8390. Lemmas 18-24, Theorem 16, Corollary 17, the verifier, the certificates and the
  recorded outputs are unchanged. Diffs: `audit_diffs/`.
- Cross-check at RQ-C's five heavy laws (float): E|Z_K| <= E h_B(Z_W) <= the certified cell bound at each, and
  J = 0.814-0.836, 0.018-0.027 below the cell bounds (`outputs/plus_cert/check_rqc_laws.txt`).
- RQ-C's 22:12 values for this design (0.8402, 0.8401) came from a HiGHS tolerance artifact. RQ-C withdrew them at
  23:00 UTC (corrected: 0.8354, 0.8345), and my own check with RQ-C's code agrees
  (`outputs/plus_cert/rqc_sblo_feasibility.txt`).

## Where Conjecture S stands
- **Conjecture S holds for all q in (0, 1): auditor VALID (A.40, the composition of every link) and referee VALID
  (RQ-REF3 FINAL, 03:09 UTC), reported to Paata by the coordinator at 03:10 UTC.** R(q) = 2 sqrt(q(1-q)) max_k
  sqrt(k) qh^(k-1). The extremisers are characterised only on [q6, 1 - q6]. For q < q6 the chain gives the value,
  not the extremiser set.
- The links: RQ-A's MAIN-1..6 (RQ-REF1, RQ-REF2); the reduction U.1-U.3 / RQ-B C19 and RQ-C's localisation C15
  (RQ-REF3 links 1-2); my Theorems 13 and 16 with Corollaries 14 and 17 (link 3); RQ-B's Theorem 13.1 (link 4).
- RQ-C's independent exact cross-check of the chain (NOTES 01:06) found no gap. It re-ran `verify_bandstar.py`
  (identical records) and checked my F_heavy tiling and cell classes with its own geometry. Its float end-to-end
  test on 6000 F_heavy laws (01:14) raised no flag: E h_B(Z_W'') - E|Z_K| >= 7.3e-6, and every cell bound is at least
  0.0100 above E h_B(Z_W'').

## Next (RQ-D)
- Answer any question on my links (MAIN_RESULT Sections 2-7, AUDIT_REQUEST.md), on the box-level record of
  Theorem 13 (note in AUDIT_REQUEST.md, 04:24 UTC) and on the text fixes (note of 05:35 UTC).

## Mechanisms rejected earlier
Pairwise merging (D3), level moves (D4), two-copy Bellman relaxation (D5); fixed theta = 0.9 with bound (F) at
rho0^2 = 0.2 (D14).
