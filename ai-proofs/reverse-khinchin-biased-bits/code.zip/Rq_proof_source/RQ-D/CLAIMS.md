# CLAIMS (RQ-D)

Last update: 2026-10-23 07:40 UTC.

Tags: PROVED (full proof in MAIN_RESULT.tex/pdf, computer steps exact or certified), CONDITIONAL (proved from a named
unproved statement), NUMERICAL (float evidence only, not proof), FAILED (a mechanism that does not work).
Audit status is given only as RQ-AUD rated it (AUDIT.md entry number).

**Referee status (RQ-REF3, FINAL, 2026-10-23 03:09 UTC; `/cursor/stores/bot/rq/RQ-REF3/REFEREE.md`).** Link 3,
"RQ-D MAIN_RESULT Sections 2-7", is VALID: D1, D2, D6-D10 and D16-D23 (Lemmas 1-4, 6-8, 12, 18-24, Proposition 9,
Theorems 13 and 16, Corollaries 14, 15 and 17). RQ-REF3 checked these by hand, re-verified the Theorem 16 certificates
with its own code, and re-did the computation of Theorem 13 with its own exact cover. D11 (Theorem 10) and D12
(Corollary 11) were not refereed; the chain does not use them. The overall verdict is VALID: Conjecture S holds for
all q in (0, 1). The coordinator reported it to Paata at 03:10 UTC.

Notation. tau = sqrt(q(1-q)), p = 1-q, q <= 1/2, M(q) = 2 tau max_k sqrt(k) p^(k-1). For a Kolmogorov measure K on
R, Z_K is the centred infinitely divisible law with log E e^{itZ} = int (e^{itx}-1-itx) x^{-2} K(dx) (E Z^2 = K(R)).
g(l) = 2 sqrt(l) e^{-l}; g(1/x^2) = E|Z_{delta_x}| for x >= 1; max g = g(1/2) = sqrt(2/e).
C5: E|Z_K| <= sqrt(2/e) K(R)^{1/2} for every K. C_5 = g(2 ln(5/4)) = 1.28 sqrt(2 ln 1.25) = 0.85510045547...
For K_S = K|[theta, A]: V = K_S(R), Lambda = int x^-2 dK_S (= lambda+_theta(K)), m = int x^-1 dK_S; residual
K_R = K - K_S with a = K_R((0, theta)), b = K_R([-A, 0]) (Gaussian part included in b), rho^2 = a + b.
Theorem numbers below refer to MAIN_RESULT.pdf (md5s of the audited versions: AUDIT_REQUEST.md).

## Exact identities

- **D1 (PROVED; A.30 VALID). Flip formula.** For y != 0 and real w,
  |y + w| = |y| + sgn(y) w + 2 (-sgn(y) w - |y|)_+. Hence for independent Y, W with E|W| < oo, E W = 0 and
  P(Y = 0) = 0: E|Y + W| = E|Y| + 2 E[(-sgn(Y) W - |Y|)_+]. (Lemma 1.)
- **D2 (PROVED; A.30 VALID WITH FIXES, fix f1 applied). OR-region identity with residual.** K = K_S + K_R with
  **K_S != 0** carried by [theta, oo), theta > m. With Y = Z_{K_S}, W = Z_{K_R} independent, N_S the number of jumps
  of Y:  E|Z_K| = 2 m e^{-Lambda} + 2 e^{-Lambda} E(W - m)_+ + 2 E[(-W - Y)_+ ; N_S >= 1], and
  2 m e^{-Lambda} <= sqrt(V) g(Lambda) <= sqrt(2/e) sqrt(V); equality in the first iff K_S is a single atom, in both
  iff K_S = V delta_{sqrt(2V)}. (Lemma 3. f1: the equality clause, and P(Y = 0) = 0, need K_S != 0.)
- **D6 (PROVED; A.32 VALID). Conditional form.** For independent Y, W with E W = 0, E W^2 = rho^2, l(y) = E|y + W| is convex,
  1-Lipschitz, l(y) = y + 2E(-W - y)_+ = -y + 2E(W + y)_+ for all real y, |y| <= l(y) <= sqrt(y^2 + rho^2), and
  E|Y + W| = E l(Y). (Lemma 2.)

## Comparison lemma and stop-loss bounds (non-moment mechanism)

- **D7 (PROVED; A.32 VALID). Comparison lemma.** If psi is C^1, psi' absolutely continuous, psi'' nondecreasing and bounded, K
  finitely supported and T(x) >= x on supp K, then E psi(Z_K) <= E psi(Z_{T#K}) ("pushing jumps to the right
  increases E psi"). Proof: generator interpolation Psi(t) = E psi(Z_{(1-t)K} + Z'_{tK'}), with
  D_x psi(z) = int_0^1 (1-u) psi''(z + ux) du nondecreasing in x; then mollification. (Lemma 4.)
  Remark 5: it fails for psi = (w - t)_+ (t = 0, delta_sqrt2 -> delta_2); psi_{t,h} = (w - t + h)_+^2/(4h) is the
  pointwise smallest admissible majorant of (w - t)_+ touching it at t + h (proof given; not used).
- **D8 (PROVED; A.32 VALID). Stop-loss bounds.** For K_R finitely supported on [-A, theta), W = Z_{K_R},
  W_B = theta (N_{a/theta^2} - a/theta^2) + sqrt(b) G, W_C = A (N_{b/A^2} - b/A^2) + sqrt(a) G,
  chi_h(t) = (2h)^{-1} E(W_* - t + h)_+^2:  2E(W - t)_+ <= min(chi^B_h(t), sqrt(t^2 + rho^2) - t) and
  2E(-W - t)_+ <= min(chi^C_h(t), sqrt(t^2 + rho^2) - t); chi convex, nonincreasing, chi_h'' = P(W_* > t - h)/h;
  chi nondecreasing in a and b, chi^B nondecreasing in theta. (Lemma 6.)
- **D9 (PROVED; A.32 VALID). One-jump and feasibility lemmas.** Chord and variance bounds E phi(J) <= Gamma(mu) + kappa sigma^2/2
  (Lemma 7); jump law of K_S has mean m/Lambda, variance (Lambda V - m^2)/Lambda^2; (Lambda, m, V) satisfy F1-F5
  (Lemma 8).
- **D10 (PROVED; A.32 VALID). Band bound.** For finitely supported probability K on [-A, A] with K_S != 0,
  E|Z_K| <= e^-Lambda (m + c_B) + Lambda e^-Lambda O + m Lambda e^-Lambda + P2(Lambda) c_C,
  P2 = 1 - e^-Lambda (1 + Lambda), with c_B >= 2E(W - m)_+, c_C >= 2E(-W - (2 theta - m))_+, O >= E l(J - m); and
  the equivalent form 2m e^-Lambda + e^-Lambda c_B + Lambda e^-Lambda O' + P2 c_C. No sign condition on theta - m.
  (Proposition 9, with the list of admissible c_B, c_C, O, O' after it.)

## Band lemma for C5 (A.32 VALID, 18:17 UTC; not refereed: RQ-REF3's scope did not need Theorem 10 or Corollary 11)

- **D11 (PROVED, computer-assisted, certified; A.32 VALID). Theorem B (Theorem 10).** If K is a probability Kolmogorov measure on
  [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10 or K([-sqrt2, -1]) >= 9/10, then E|Z_K| <= sqrt(2/e); for finitely
  supported K equality only at delta_{+-sqrt2}. Certificate: `scripts/verify_band.py` (python-flint arb, 80 bits;
  md5 b8164113fd41949dbb3c3fe9a7b5d119; re-run 17:12-17:14 UTC after the chord fix described in AUDIT_REQUEST.md).
  Part S (0 < rho^2 <= 1/50): 1098 (Lambda, m) boxes, 0 failures (`outputs/verify_band_S.txt`). Part B
  (1/50 <= rho^2 <= 1/10): 598 (a, b) squares certified (341 at side 1/256 with 85 refined, 333 at 1/512 with 3
  refined, 12 at 1/1024), 1,339,228 (Lambda, m) boxes, 95 s (`outputs/verify_band_B.txt`). Environment:
  `outputs/verify_band_env.txt`. Controls (run before the chord fix, which can only enlarge F): r = 0.06 in Part S gives
  426,627 failures; target sqrt(2/e) - 0.002 gives 5,750 Part S failures; Part B at target sqrt(2/e) - 0.001 fails
  110 of 1281 squares. Float soundness (`scripts/band_soundness.py`, 400 random K): F - E|Z_K| >= 1.5e-5,
  sqrt(2/e) - F >= 3.2e-5.
- **D12 (PROVED from A.13a; A.32 VALID). Corollary 11: C5 reduces to the far region.** If E|Z_K| <= sqrt(2/e) for every
  probability K on [-sqrt2, sqrt2] with K([1, sqrt2]) < 9/10 and K([-sqrt2, -1]) < 9/10, then C5 holds. Uses
  RQ-B Lemma 8.1 / Prop. 8.3 (A.13a): a maximiser exists, supp K* in [-2u/R, 2(1-u)/R] and max(u, 1-u) <= R/sqrt2,
  so supp K* in [-sqrt2, sqrt2].

## Band lemma in the form the reduction needs (ID*, finite q; A.34 VALID, 20:19 UTC; refereed VALID by RQ-REF3, FINAL 03:09 UTC on 23 Oct)

- **D13 (NUMERICAL; superseded by D18, kept as the float record).** ID* band at theta = 0.85, A = 1.54, rho0^2 = 0.2, C = C_5. The bound of D10 (chord plus the
  three variance bounds for O, chi^B/chi^C/Cauchy-Schwarz costs, 60 values of h) gives
  E|Z_K| <= max(g(lambda+_theta), C_5) on {K([0.85, 1.54]) >= 0.8} (mirror: lambda-_theta) in float scans over
  (a, b, Lambda, m) with F1-F5: worst F - target = -0.00460 (rho^2 = 0.1), -0.00398 (0.15), -0.00164 (0.2);
  the margin tends to 0 as rho^2 -> 0 along the Dirac curve x in [1.3388681…, 1.4969001…] (where g(1/x^2) >= C_5;
  the ends are 1/sqrt(0.5578588…) and 1/sqrt(2 ln(5/4)); A.34 r3, r4).
  `scripts/bandstar_scan6.py`, `scripts/bandstar_float.py`. Soundness (`scripts/bandstar_soundness.py`, 400 random K
  in the band, exact E|Z_K| by Poisson enumeration): min(F - E|Z_K|) = +6.3e-5, min(target - E|Z_K|) = +9.5e-4.
  Not a proof. This bound (with the options of D16-D17 added) is the one certified in D18.
- **D14 (NUMERICAL, FAILED variant).** The same bound with theta = 0.9 fails at rho^2 = 0.2 (worst +0.00099);
  with theta fixed at 1 and the chord alone it fails already at small rho^2. (Consistent with RQ-C C16, A.29.)
- **D15 (FAILED, found and fixed before use).** An earlier float version of the variance bound used the curvature
  P/(2h); the correct value is chi_h'' = P(W_* > y - h)/h. The soundness test caught it (F = 0.7838 < E|Z| =
  0.7883). All scripts and MAIN_RESULT use the corrected value.
- **D16 (PROVED; A.34 VALID). Two-point mean-variance bound (Lemma 7(c)).** If J >= j0 has mean mu > j0 and variance sigma^2,
  phi <= psi on [j0, oo) and psi' is concave there, then E phi(J) <= (1 - w) psi(j0) + w psi(x), d = mu - j0,
  x = mu + sigma^2/d, w = d^2/(d^2 + sigma^2). Proof: the quadratic through (j0, psi(j0)) tangent to psi at x lies
  above psi on [j0, oo) (Rolle, k' = q' - psi' convex), and E q(J) depends only on (mu, sigma^2). For convex
  nonincreasing psi the bound is nondecreasing in sigma^2 (mean-preserving spread), which gives the box version.
  Used with psi = chi^C_h (psi'' = P(W_C > y - h)/h nonincreasing) and psi = sqrt(y^2 + r^2) - y (y >= 0).
- **D17 (PROVED; A.34 VALID). Absorption lemma (Lemma 12) and option (O5).** For K_S != 0 on [theta, A] with mu1 > theta,
  d = mu1 - theta >= D > 0, w = d^2/(d^2 + sigma_J^2) (exact sigma_J^2) and 0 <= kappa <= D^2 sqrt(Lambda/V):
  2 m e^-Lambda + Lambda e^-Lambda kappa (1 - w) <= sqrt(V) g(Lambda). Proof: 1 - w <= (Lambda V - m^2)/(Lambda^2 D^2),
  and t -> 2t + kappa (Lambda V - t^2)/(Lambda D^2) is a concave quadratic with vertex >= sqrt(Lambda V) >= m (F4).
  (O5): E phi(J - m) <= (1 - w) kappa + (1 - w) rho^2/(2h) + chi^C_h(mu1 - m), kappa = (h - (theta - m))_+^2/(2h), from
  D16 with psi = chi^C_h and chi^C_h(theta - m) <= kappa + rho^2/(2h) (W_C has mean 0, variance rho^2). This is what
  removes the near-Dirac obstruction of the certificate (h > theta - m is allowed; the constant is paid by the
  Cauchy-Schwarz slack of the main term).
- **D18 (PROVED, computer-assisted, certified; A.34 VALID). Theorem B*
  (Theorem 13): the ID* band lemma at theta = 0.85, A = 1.54.** If K is a finitely supported probability
  Kolmogorov measure on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, then E|Z_K| <= max(g(lambda+_0.85(K)), C_5); if
  K([-1.54, -0.85]) >= 4/5, then E|Z_K| <= max(g(lambda-_0.85(K)), C_5). Proof: Proposition 9 (second form), with
  c_B, c_C from Lemma 6 and O' from (O1)-(O5) (Lemma 7 with D16, D17), gives E|Z_K| <= F(a, b, Lambda, m); a
  certified covering in arb (80 bits) shows F <= max(g(Lambda), C_5) on the whole domain {a, b >= 0, a + b <= 1/5,
  (Lambda, m) with F1-F5}, with the slope argument (tests T1-T3, Lemma 12) near rho^2 = 0, where the margin vanishes
  on the Dirac curve. Certificate `scripts/verify_bandstar.py` (md5 b5b55ceec828f01debc6c1a422e7270f), recorded run
  2026-10-22 18:39:45-18:52:59 UTC (793 s) on 8 processes: (a, b) squares of side 1/128 (351 squares, 215 not certified), 1/256
  (837, 102), 1/512 (408, 20), 1/1024 (80, 0); 1339 squares certified, 0 uncertified; 14,894,034 (Lambda, m) boxes.
  The leaf boxes of the certified squares: 3,114,781 infeasible (F1-F5), 551,105 chord (O1), 2,876,016 two-point
  chi^C (O3), 128,597 two-point Cauchy-Schwarz (O4), 1,203,286 Taylor (O2), 426 slope check. Outputs
  `outputs/verify_bandstar.txt`, `outputs/verify_bandstar_squares.jsonl`, `outputs/verify_bandstar_env.txt`.
  An earlier run of a copy that differs only in the docstring, unused code, a log flush and the control shift (0 by
  default) gave the same counts (`outputs/verify_bandstar_run2.txt`). Controls (`scripts/verify_bandstar_controls.py`,
  `outputs/verify_bandstar_controls.txt`; target lowered by a shift, no refinement, T1 disabled): the origin squares
  [0, 1/256]^2 and [0, 1/128]^2 are certified at shift 0 and fail at shift 0.0005, first at a box on the Dirac curve
  (Lambda = 0.5632, m = 3074/4096, C_5 - g(Lambda) in [0.000496, 0.000502], and F = g(Lambda) at rho^2 = 0). The 80
  squares of side 1/1024, all along
  a + b = 1/5, fail at shift 0.001 in 63 cases. So the certified margin is below 1e-3 there and 0 on the Dirac curve.
  Float soundness of every ingredient (`scripts/bandstar_soundness2.py`, exact laws of W and J; evidence only):
  400 random band K with rho^2 <= 1/5 (`outputs/bandstar_soundness2.txt`) and 400 near-Dirac K with rho^2 <= 1/50
  (`outputs/bandstar_soundness2_dirac.txt`). No bound is below its exact value by more than 1e-15; the two equality
  cases, chi^C_h(theta - m) <= kappa + rho^2/(2h) and Lemma 12, are at -8.9e-16 and -2.2e-16 (rounding).
  min(F - E|Z_K|) = 2.1e-4 and min(target - F) = 5.8e-4 on the first sample; 1.5e-7 and 7.3e-7 on the second.
  Box-level record (added 23 Oct for RQ-REF3's remark 2; the status of D18 is unchanged, and so is
  `verify_bandstar.py`). `scripts/bandstar_record.py` reruns the computation with
  `verify_bandstar.py` imported unchanged. It stores every leaf box with its method, option and h, and the full
  certificate of each slope leaf (`outputs/bandstar_cert/`). All 1676 squares match the published log.
  `scripts/bandstar_replay.py` replays the record without the search code. It checks the cover of the triangle, the
  tiling of every square and every leaf certificate, in arb. Result: VALID, with the same counts per method
  (`outputs/bandstar_cert/replay.txt`). Every tampered record in the self-test is rejected
  (`outputs/bandstar_cert/replay_selftest.txt`). RQ-AUD replayed the record leaf by leaf with its own verifier
  (A.34 addendum, 04:51 UTC): all 7,874,211 leaves are certified, the record is VALID, and A.34 stays VALID.
- **D19 (PROVED from D18; A.34 VALID). Corollary 14: ID* reduces to the far region.** If E|Z_K| <= C_5 for every finitely
  supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5, then ID*(C_5)
  holds for every finitely supported probability K on [-1.54, 1.54] (with theta = 0.85 for every K). With RQ-B C19
  (A.26), RQ-C C15 (A.28) and RQ-A MAIN-5 (A.25), Conjecture S for all q is therefore CONDITIONAL only on this
  far-region inequality (RQ-B's part; open; numerical sup about 0.8266, margin about 0.0285).
- **D20 (PROVED from D18 and A.13a; A.34 VALID). Corollary 15: C5 reduces to the far
  region of Theorem 13.** RQ-C made the observation (19:00 UTC); the write-up is RQ-D's.
  - (a) Theorem 13 holds for every probability K on [-1.54, 1.54], not only finitely supported ones. The proof
    approximates by cells, as in Theorem 10, and uses lambda+_theta(K_n) -> lambda+_theta(K).
  - (b) If E|Z_K| <= sqrt(2/e) for every probability K on [-sqrt2, sqrt2] with K([0.85, sqrt2]) < 4/5 and
    K([-sqrt2, -0.85]) < 4/5, then C5 holds. The reason is that max(g, C_5) <= sqrt(2/e), and the support of a C5
    maximiser lies in [-sqrt2, sqrt2] (A.13a), as in Corollary 11.
  - So the hypothesis of D19 implies both ID*(C_5), hence all q, and C5. RQ-C's numerical sup of this far region is
    about 0.827, against about 0.850 for the far region of Corollary 11, with sqrt(2/e) = 0.8578.

## The heavy part of the far region (MAIN_RESULT.pdf Section 7; A.38 VALID, 22:51 UTC, post-verdict text changes confirmed 01:05 UTC; refereed VALID by RQ-REF3, FINAL 03:09 UTC on 23 Oct)

Notation: tau = 17/20, A = 77/50, V+ = K([tau, A]), V- = K([-A, -tau]). Q(a, b) = (a tau + b A)^2/(a + b),
M(a, b) = a tau^2 + b A^2. Light part: V+ < 1/2 and V- < 1/2. Heavy part: V+ >= 1/2 or V- >= 1/2 (inside V+, V- < 4/5).

- **D21 (PROVED; A.38 VALID, 22:51 UTC). Reductions for the heavy part (Lemmas 18-24).**
  - Lemma 18 (chord reduction). K_+ on [tau, A], nu = x^-2 K_+, a+ = int (A - x)/(A - tau) dnu,
    b+ = int (x - tau)/(A - tau) dnu, K_+# = a+ tau^2 delta_tau + b+ A^2 delta_A.
    - (i) Q(a+, b+) <= K_+(R) <= M(a+, b+) (Cauchy-Schwarz; convexity of x^2).
    - (ii) E psi(Z_{K_+ + W}) <= E psi(Z_{K_+# + W}) for convex psi of linear growth and any finite W with bounded
      support. Proof: the jump law is <=_cx its chord law with the same mean; this is preserved by independent sums,
      by mixing over the same Poisson count, and by Poisson colouring.
  - Lemma 19. Q, M and M - Q = ab (A - tau)^2/(a + b) are nondecreasing in each rate (uses 2 tau >= A), and
    Q >= max(a tau^2, b A^2).
  - Lemma 20 (box reduction). Let 1/2 <= V+ < 4/5.
    - The rates satisfy a+ < 28/25 and b+ < 17/50.
    - If (a+, b+) is in a box B = [a1, a2] x [b1, b2], then B is not empty (Q(a1, b1) < 4/5 and M(a2, b2) >= 1/2).
    - Moreover E|Z_K| <= E h_B(Z_W) for some W in W_B. Here h_B(r) = E|tau (N_a1 - a1) + A (N_b1 - b1) + r|, and W_B
      is the set of measures on [-A, tau] u {A} of mass mu_B = 1 - max(Q(a2, b2), 1/2) + M(a2, b2) - M(a1, b1) with
      W({A}) <= cap_B = (b2 - b1) A^2.
    - Proof: lower-corner split of the chord rates, then Gaussian padding up to mu_B (Jensen). The padding needs
      W_1(R) <= mu_B, which follows from the monotonicity of M and of M - Q.
  - Lemma 21: cumulants of Z_W, kappa_j = int x^(j-2) dW, and the moment recursion. Lemma 22: int R dW <=
    mu_B S + cap_B (R(A) - S)_+. Certificate inequalities (a)-(c):
    - (a) cumulant ranges;
    - (b) Farkas emptiness of a (kappa_3, kappa_4) cell;
    - (c) a Lagrangian bound with McCormick envelopes and Hoelder |prod kappa| <= mu_B^(t-1) int |x|^s dW.
  - Lemma 23 (majorant test): a Poisson truncation with a Cauchy-Schwarz tail term, and a Taylor test of the tails at
    +-L. Lemma 24 (cell certificate).
- **D22 (PROVED, computer-assisted, certified; A.38 VALID, 22:51 UTC). Theorem 16 (heavy far region).** For
  every probability Kolmogorov measure K on [-1.54, 1.54] with 1/2 <= K([0.85, 1.54]) < 4/5, or with
  1/2 <= K([-1.54, -0.85]) < 4/5: E|Z_K| < C_5. No finite-support assumption is needed.
  - Certificate: `scripts/verify_plus.py` (md5 c754a7305654c6635025f7e405dd98bb) with `scripts/plus_verify_lib.py`
    (md5 a7db98d4dac237f52493f6d085b97d15). python-flint only: fmpq and arb at 128 bits; no LP solver or float
    decisions.
  - Data: `outputs/plus_cert/certs_v1_r0.jsonl` ... `certs_v1_r4.jsonl`; recorded run
    `outputs/plus_cert/verify_v1.txt` (2026-10-22 22:34:20-22:34:45 UTC, 8 processes; it prints the md5s of the
    verifier and the data).
  - An earlier run (21:47 UTC, `outputs/plus_cert/verify_v1_first.txt`) of a first version of the verifier
    (verify_plus.py md5 0e412f55eda9b9a4c7a92e8e8def58f6, plus_verify_lib.py md5 8111a51880ffc9e29485682579cadb54)
    gave the same counts. That version did not check that box indices lie in their grid, and its polynomial bound
    skipped a non-finite piece bound instead of stopping. The recorded version makes both checks, and the data pass.
  - 436 dyadic (a+, b+) boxes tile [0, 28/25] x [0, 17/50]: levels 0-4 hold 96/134, 71/12, 66/6, 44/3 and 3/1
    certified/empty leaves.
  - The 280 certified boxes carry 1237 (kappa_3, kappa_4) cell certificates: 1236 degree-16 majorants with
    Lagrangian bounds, and 1 Farkas emptiness certificate. 0 failures.
  - Worst certified bound 0.854883 < C_5 = 0.8551004.
  - Controls (`outputs/plus_cert/controls_v1.txt`): with the threshold C_5 - s, 0/0/9/50/187 of the 280 boxes fail
    at s = 0, 1e-4, 3e-4, 1e-3, 3e-3. Removing one box or one cell breaks the tiling test, and so does moving one
    box or cell index out of its grid.
  - Float self-tests (`scripts/test_plus_verify.py`, `outputs/plus_cert/selftest_v1_r*.txt`; evidence only): all
    pass. They include an end-to-end check on 747 random heavy K: E|Z_K| <= certified cell bound - 0.0327.
  - Float evidence on the design's value J (exact moments of the rest, no box, cell or relaxation loss; MAIN_RESULT
    7.4, last paragraph, which also shows that a cell's certified bound is >= J at every K whose rest lies in it):
    - searches found values up to 0.8390 (`outputs/far_extra/plus_scan/`); the best law, rechecked with an LP whose
      measure is checked against the rows, gives 0.83893 (`outputs/far_extra/plus_scan/recheck_best.txt`);
    - at RQ-C's five heavy laws (RQ-C NOTES 22:12), J = 0.814-0.836 and E|Z_K| <= E h_B(Z_W) <= the certified cell
      bound, with cell bound - J = 0.018-0.027 (`scripts/plus_check_laws.py`, `outputs/plus_cert/check_rqc_laws.txt`;
      tolerance check `outputs/plus_cert/plus_lp_tol.txt`).
- **D23 (PROVED from D22, D19, D20; A.38 VALID, 22:51 UTC). Corollary 17: ID* and C5 reduce to the light far region.** If E|Z_K| <= C_5 for
  every finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) < 1/2 and K([-1.54, -0.85]) < 1/2,
  then the hypothesis of D19 holds; hence ID*(C_5) (so Conjecture S for all q, with A.25, A.26, A.28) and C5.
  The light part is RQ-B's (open).

## Mechanisms tested and rejected (evidence for the team; none of these is used in a proof)

- **D3 (NUMERICAL, FAILED mechanism). Pairwise endpoint merging at finite q.** For random positive alpha (n = 5, 8,
  10; q in {0.1, 0.15, 0.2, 0.3}) the profile theta -> E|L| with (alpha_i, alpha_j) replaced by
  r (cos theta, sin theta) has interior maxima above both endpoints, for the two smallest, the two largest and the
  (largest, smallest) pairs alike (worst excess 8.6e-3 at q = 0.3, n = 5). `scripts/explore_pairs2.py`,
  `outputs/explore_pairs2.txt`. (RQ-B Section 10 has an exact counterexample for arbitrary pairs; this adds that no
  canonical choice of pair rescues it.)
- **D4 (NUMERICAL, FAILED mechanism). Level (block) moves.** Moving one level of a multi-level vector
  continuously between its neighbouring levels (variance renormalised) has interior maxima in 204 of 1024 random
  trials; worst excess 3.55e-2 (q = 0.2, levels (0.854, 0.341), multiplicities (1, 4)). `scripts/explore_blocks.py`,
  `outputs/explore_blocks.txt`.
- **D5 (NUMERICAL, FAILED mechanism). Two-copy ("pair") Bellman relaxation.** The exact recursion
  W(f) = (a1 - a0)^2 + |p Delta f0 + q Delta f1|^2 relaxed to two independent means,
  B(a,b) >= (a1-a0)(b1-b0) + p^2 B(a0,b0) + q^2 B(a1,b1) + pq (B(a0,b1) + B(a1,b0)), has least supersolution
  with max_a B(a,a) about 1.038 Phi^2 at q = 0.3 (Phi^2 = max_k k p^(2k-2) = 1 there), from value iteration on an
  81 x 81 grid. So the natural two-function induction does not prove the sharp bound even where Conjecture S is
  known. Float grid computation, not yet confirmed by an explicit finite strategy. `scripts/pair_bellman.py`,
  `outputs/pair_bellman_q0.3.txt`.
