#!/usr/bin/env bash
# Mirror the working tree (without .git and tool folders) to the team store.
# Writes to the store are slow (about 1 s per file), so only files whose store copy is missing or differs are copied.
# Any failed copy is reported and makes the script exit nonzero; LAST_MIRROR.txt then says PARTIAL.
DEST=/cursor/stores/bot/rq/RQ-D
mkdir -p "$DEST" || exit 1
cd /workspace || exit 1
copied=0
failed=0
while IFS= read -r -d '' f; do
  f=${f#./}
  cmp -s "$f" "$DEST/$f" && continue
  if mkdir -p "$DEST/$(dirname "$f")" && cp "$f" "$DEST/$f" && cmp -s "$f" "$DEST/$f"; then
    copied=$((copied + 1))
  else
    echo "mirror FAILED: $f" >&2
    failed=$((failed + 1))
  fi
done < <(find . \( -name .git -o -name agent-tools -o -name terminals -o -name __pycache__ \) -prune -o -type f \
           ! -name '*.aux' ! -name '*.log' ! -name '*.fls' ! -name '*.fdb_latexmk' -print0)
stamp=$(date -u '+%Y-%m-%d %H:%M:%S UTC')
if [ "$failed" -eq 0 ]; then
  echo "$stamp" > "$DEST/LAST_MIRROR.txt"
else
  echo "PARTIAL $stamp ($failed files failed)" > "$DEST/LAST_MIRROR.txt"
fi
echo "mirrored to $DEST at $stamp: $copied files copied, $failed failed"
[ "$failed" -eq 0 ]
