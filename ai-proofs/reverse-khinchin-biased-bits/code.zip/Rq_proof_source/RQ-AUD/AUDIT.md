# RQ-AUD audit log (hostile auditor, R(q) attack)

Auditor: RQ-AUD. Standard: a claim is VALID only if every step is rebuilt from the
original hypotheses and every computer step is re-done independently in exact rational or
certified interval arithmetic. Numerics are evidence, never proof.

Verdict scale: VALID / VALID WITH FIXES / INVALID / NOT YET AUDITED.
Novelty scale: NEW (no earlier source found) / KNOWN (with citation) / PARTLY KNOWN.

## Ledger

| id  | claim | source | verdict | novelty | time (UTC) |
|-----|-------|--------|---------|---------|------------|
| A.0 | BF3 Theorem K: R(q) = 2 sqrt(q(1-q)) for all q in [3/8, 5/8] | BF3 §9.4 | **VALID** | NEW (in BF3) | 2026-10-22 05:55 |
| A.1 | RQ-C C1: exact-rational recheck of the Thm K computer step | RQ-C CLAIMS.md | **VALID** | KNOWN (re-verification of BF3) | 2026-10-22 06:00 |
| A.2 | RQ-C C4(a): centred Poisson(1/2) is first-order optimal against compound-Poisson/Gaussian perturbations | RQ-C CLAIMS.md (now 4b1e22a4…) | **VALID** (re-rated 2026-10-23 07:48: both text fixes are in RQ-C's C4(a), f1 the sum over k >= 1 and f2 the equality set {0, 1}; RQ-C posted them between its mirrors of 2026-10-22 06:49 and 07:09, and this row lagged until the ledger check a40o found it; 06:00: VALID WITH FIXES) | NEW (elementary); limit value sqrt(2/e) KNOWN (Stone thesis Lem. 4.4.4) | 2026-10-22 06:00; VALID 2026-10-23 07:48 |
| A.3 | RQ-A C0.1–C0.5: Lemma 9.4 identity, cumulants/moments of M, power-sum inequalities, two-coefficient value, level-one duality | RQ-A CLAIMS.md | **VALID** | KNOWN (BF3 §9.4; standard cumulant calculus) | 2026-10-22 06:36 |
| A.4 | RQ-A K.1–K.2: independent re-derivation and exact re-check of BF3 Theorem K | RQ-A CLAIMS.md | **VALID** | KNOWN (re-verification of BF3; agrees with A.0) | 2026-10-22 06:36 |
| A.5 | RQ-C C6, part n <= 6: R_n(q) = 2 tau sqrt(max_{k<=n} k(1-qbar)^{2k-2}) for all q, extremisers only OR_k | RQ-C CLAIMS.md | **VALID** (n <= 6); n = 7: see A.5b | NEW (computer-assisted) | 2026-10-22 06:36 |
| A.5b | RQ-C C6, part n = 7 (with A.5: the full C6 theorem for n <= 7) | RQ-C CLAIMS.md (06:49) | **VALID** | NEW (computer-assisted) | 2026-10-22 07:39 |
| A.6 | **RQ-A MAIN (Theorem 1 of MAIN_RESULT): R(q) = 2 sqrt(q(1-q)) for all q in [1-1/sqrt2, 1/sqrt2]; false outside; extremisers +-e_j, plus +-(e_i+e_j)/sqrt2 at the endpoints** | RQ-A MAIN_RESULT.md/.tex/.pdf (06:47); re-checked on the refereed tex 6816732f… and PDF 0a95569f… | **VALID** (no mathematical fix; typos f1–f2 fixed in the refereed text; appendix slip f3, text only, applied by RQ-A at 03:04 UTC in tex 38b69350… and PDF 5c0ac2ef…, which differ from the refereed text only by that figure) | **NEW** (settles the BF3 conjecture; BF3 had [3/8,5/8]) | 2026-10-22 06:52; addendum 2026-10-23 02:55 (f3: the appendix bound 6.2e-3 should read 6.1e-3); addendum 2 03:30 (f3 applied and checked, a6g) |
| A.7a | RQ-B C1: level-one / multilinear form R(q)^2/(4q(1-q)) = sup_f sum_i Delta_i(f)^2 | RQ-B rq/CLAIMS.md (06:20; now 9de8c9c5…, whose proof is MAIN_RESULT Lemma 2.1, tex/PDF Lemma 3.1) | **VALID** (re-rated 2026-10-23 07:48: the typo is fixed in the proof that C1 now cites, as A.10 recorded at 2026-10-22 08:11; this row lagged until the ledger check a40o found it. Cosmetic r1: C1 cites "MAIN_RESULT.pdf, Lemma 2.1", but the PDF numbers the lemma 3.1. 06:59: VALID WITH FIXES, typo: sqrt(W^1) = E[fL], not W^1) | KNOWN (BF3 end of proof of Thm K; = RQ-A C0.5, A.3) | 2026-10-22 06:59; VALID 2026-10-23 07:48 |
| A.7b | RQ-B C2: semi-deviation identity E(EY-Y)_+ = q(1-q) sum alpha_i P(Y^(i) in [EY-alpha_i, EY)) | RQ-B rq/CLAIMS.md | **VALID** (the alpha_i < 0 case is made explicit below) | KNOWN in kind (elementary; alpha = 1 gives de Moivre's mean-deviation formula) | 2026-10-22 06:59 |
| A.7c | RQ-B C3: if alpha > 0 and q sum alpha <= min alpha then E\|L\|/\|alpha\| <= 2 sqrt(nq)(1-q)^(n-1/2) | RQ-B rq/CLAIMS.md | **VALID** | elementary (no source found; minor) | 2026-10-22 06:59 |
| A.7d | RQ-B C4: Bern(q) <=_cx Poisson(q), hence R(q) <= R_Pois/sqrt(1-q); R_Pois >= sqrt(2/e) | RQ-B rq/CLAIMS.md | **VALID** | technique KNOWN (Bernoulli <=_cx Poisson is classical); the bound is an elementary corollary | 2026-10-22 06:59 |
| A.8 | RQ-C C7: lim_{q->0} R(q) exists and equals R_ID = sup E\|X\|/\|\|X\|\|_2 over centred infinitely divisible X; R_ID <= sqrt(2/e) iff (★) E\|X\| <= e^{-1/2}(1/2 + Var X) | RQ-C CLAIMS.md (06:49) | **VALID** | statement NEW (no source found); technique standard (Gnedenko–Kolmogorov) | 2026-10-22 07:03 |
| A.9 | **RQ-C C11 (Theorem 1 of RQ-C MAIN_RESULT): R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) for all q in [256/985, 1-1/sqrt2] (and the mirror [1/sqrt2, 729/985]); for q < 1-1/sqrt2 the only extremisers are +-(e_i+e_j)/sqrt2** | RQ-C MAIN_RESULT.md/.tex/.pdf (PDF 07:43), AUDIT_REQUEST.md | **VALID** (no fix needed) | **NEW** (first exact value of R(q) for q < 1-1/sqrt2; lower bound KNOWN, Stone §4.2) | 2026-10-22 07:59 |
| A.10a | RQ-B C6 (Thm 3): R(q)^2 <= R_ID^2 q/((1-q) ln(1/(1-q))) for all q in (0,1/2] (Poissonization + Stein–Chen) | RQ-B rq/MAIN_RESULT (07:43) | **VALID** | NEW (no source found; technique standard) | 2026-10-22 08:11 |
| A.10b | RQ-B C7 (Thm 4): lim_{q->0} R(q) = R_ID | RQ-B rq/MAIN_RESULT | **VALID** | same statement as RQ-C C7 (A.8), with an independent proof of the upper half | 2026-10-22 08:11 |
| A.10c | RQ-B C8 (Thm 5, Prop 5.1): if C5 holds then M <= R <= B, R(q_k^*) = M(q_k^*) for all k, and B/M - 1 <= E_1 = 0.0303 on (0, q0]; converse implications | RQ-B rq/MAIN_RESULT | **VALID** (as implications; C5 itself was open at 08:11, and is VALID at audit level since A.39, 2026-10-23 01:05, through A.34, A.38 and A.39; not refereed) | NEW (no source found) | 2026-10-22 08:11 |
| A.10d | RQ-B C9 (Prop 6): C5 holds (a) if every jump is >= the compensator, (b) if int \|x\| K(dx) <= 2(sqrt(2/e) - sqrt(2/pi)) = 0.1197586… (corrected 20:37: this row said "<= 0.11976", which is rounded up and too large) | RQ-B rq/MAIN_RESULT | **VALID** (cosmetic remark of 20:37: RQ-B's decimal "0.11976" in CLAIMS line 69, and "0.11976..." in MAIN_RESULT.md line 286 and tex line 429, is rounded up from 0.1197586; the exact expression is stated next to it, so the mathematics stands) | (a) elementary; (b) zero-bias Stein technique KNOWN (BF3 Lemma 9.6, audited in A.0); the statements are NEW | 2026-10-22 08:11; correction 20:37 |
| A.10e | RQ-B C10 (Prop 7): the adaptive (predictable-coefficient) value is >= L(q) = (1-2q)^3 + 2 tau sqrt(1-(1-2q)^4) > 0.962 on (0,1/2), so no scalar-state Bellman argument can prove C0 | RQ-B rq/MAIN_RESULT | **VALID** | NEW (no source found) | 2026-10-22 08:11 |
| A.10f | RQ-B F4 (FAILED, exact): counterexample to the two-to-one merge lemma for ID laws | RQ-B rq/CLAIMS.md | **CONFIRMED** (values reproduced; the sup over the jump size c is rigorous for \|c\| <= 0.005 and \|c\| >= 4.25 and a grid scan in between, so numerical) | not applicable (negative result about a technique) | 2026-10-22 08:11 |
| A.11 | **RQ-A MAIN-2 (Theorem 1 of MAIN_RESULT_K2): R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) for all q in [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2] (and the mirror [1-q0, 1-q3]); sharp; equality iff alpha = +-(e_i+e_j)/sqrt2, or +-e_i at q0, or +-(e_i+e_j+e_k)/sqrt3 at q3. Corollary 2 (with A.6): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 (1-q), sqrt2 q} on [q3, 1-q3]** | RQ-A MAIN_RESULT_K2.md/.tex/.pdf (08:27; re-mirrored 08:48), AUDIT_REQUEST.md, data `outputs/k2_manifest.json` | **VALID** (no fix needed) | **NEW** (extends A.9 from [256/985, q0] to the largest possible interval; lower bound KNOWN, Stone §4.2) | 2026-10-22 08:52 |
| A.12 | **RQ-C C12 (Theorem 1 of RQ-C MAIN_RESULT, 08:40 version): C11 extended to [625/2834, 1-1/sqrt2] (and the mirror [1/sqrt2, 2209/2834]); for 625/2834 <= q < 1-1/sqrt2 the only extremisers are +-(e_i+e_j)/sqrt2** | RQ-C MAIN_RESULT.md/.tex/.pdf (PDF 08:40; fixed version PDF 09:42), AUDIT_REQUEST.md, data `numerics/out/ext2/` | **VALID** (re-rated 10:04 after fix f1 was posted; 09:28: VALID WITH FIXES) | NEW in the literature; in this project the range is inside A.11, so C12 is a second, independent proof of [0.2205, 0.2599] with a new method (sextic comparison) | 2026-10-22 09:28; VALID 10:04 |
| A.13a | RQ-B C11 (Lemma 8.1, 8.2, Prop. 8.3): a maximiser K* of the ID problem exists; G <= R/2, P(Z = 0) = 0, G = R/2 on supp K* \ {0}, tangency at support points; R^2 <= 4u(1-u), max(u, 1-u) <= R/sqrt2, u in [1/3, 2/3], supp K* in [-2u/R, 2(1-u)/R], a subset of [-4/(3R), 4/(3R)] | RQ-B rq/MAIN_RESULT §8 (PDF 08:35; fixed version PDF 10:38), rq/CLAIMS.md (08:37; fixed 10:38) | **VALID** (re-rated 10:44 after fix f2 was posted; 09:53: VALID WITH FIXES, f2: "all tight at delta_sqrt2" is false for R^2 <= 4u(1-u) and u in [1/3, 2/3]; the formula for Q needs r >= 1/sqrt2) | NEW (no source found; variational technique standard) | 2026-10-22 09:53; VALID 10:44 |
| A.13b | RQ-B C12 (Theorem 8): R_ID <= 0.9161 (exact even-sextic certificate plus the C11 localisation); hence sqrt(2/e) <= lim_{q->0} R(q) <= 0.9161 and R(q) <= 0.9161 sqrt(q/((1-q) ln(1/(1-q)))), which is < 1 for q < 0.28883 | RQ-B rq/MAIN_RESULT §8, rq/CLAIMS.md | **VALID** (re-rated 10:44 after fix f1 was posted; 09:53: VALID WITH FIXES, f1: "within 7.4% of M(q) for q <= 1/4" is false; the supremum is 7.90%, at q = 1 - sqrt(2/3)) | NEW (earlier small-q upper bounds 1 - O(q^3), Ivanisvili–Stone Cor. 2) | 2026-10-22 09:53; VALID 10:44 |
| A.14 | **RQ-A MAIN-3 (Theorem 3 of MAIN_RESULT_K3): R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for all q in [25/169, q3] = [25/169, 1-sqrt(2/3)] (and the mirror [1-q3, 144/169]); equality iff alpha = +-(e_i+e_j+e_k)/sqrt3, or q = q3 and alpha = +-(e_i+e_j)/sqrt2; the set {q <= 1/2 : R = T} lies in [q4, q3]. Corollary 1 (with A.6, A.11): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2}, qh = max(q, 1-q), on [25/169, 144/169]** | RQ-A MAIN_RESULT_K3.md/.tex/.pdf (PDF 09:35; posted 09:47), AUDIT_REQUEST.md, data `outputs/k3_manifest.json` | **VALID** (no fix needed) | **NEW** (first exact values where three equal coefficients are optimal; lower bound KNOWN, Stone Thm 4.3.1) | 2026-10-22 10:37 |
| A.15 | RQ-B Remark 3.3 (conditional reduction): for every q <= 0.3429, the atomic Poisson inequality APC(s(q)), s(q) = ln(1/(1-q)) (equal coefficients are optimal for sums of i.i.d. centred Poisson(s) variables), implies C0 at q, i.e. R(q) = M(q) | RQ-B rq/MAIN_RESULT Remark 3.3 (PDF 10:38), rq/CLAIMS.md (10:38, "now fully proved") | **VALID** (as an implication; APC itself is open, numerical for n <= 6) | statement NEW (corollary of Theorem 3, A.10a); ingredients KNOWN (Poisson mean deviation formula, Padé bound for the logarithm) | 2026-10-22 10:44 |
| A.16 | RQ-B C15 (Lemma 9 and Corollary 9.1, "Lemma S"): for u = sqrt((1-q)/q) in [12/5, 2543/1000] (q in [0.13393, 25/169]), unit alpha and a = max_i \|alpha_i\|: (a) a <= 480/6409 implies E\|L\| <= T(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)); (b) 480/6409 <= a <= 120/409 and E\|M\| <= T for the normalised remainder imply E\|L\| <= T. Hence, by induction on n, R = T = M on [q4, 25/169] as soon as E\|L\| <= T for every unit alpha with max_i \|alpha_i\| >= 0.2934 | RQ-B rq/MAIN_RESULT §9 (PDF 10:49, Section 10), rq/CLAIMS.md (10:49), data `numerics/k3_smalla_certs.json` (8b93f594…) | **VALID** (no fix needed; a reduction, the gap [q4, 25/169] is not closed) | NEW (no source found); ingredients KNOWN (BF3 zero-bias bound and Lemma 9.4; moment certificates as in BF3 §9.4) | 2026-10-22 11:14 |
| A.17 | RQ-B C16 (transfer lemma, OR of m bits): for q' in (0,1), m >= 1 and q = 1 - (1-q')^m, R(q)^2 <= R(q')^2 q/(m q'(1-q')^{m-1}); hence R(q') = M_{mj}(q') implies R(q) = M_j(q) = M(q) (e.g. C0 at q*_{mj} implies C0 at q*_j); Theorem 3 is the m -> oo limit | RQ-B rq/CLAIMS.md (11:18; not in MAIN_RESULT) | **VALID** (elementary; as RQ-B says, it gives no new exact value from the team's results) | statement NEW (no source found); technique standard (a q-biased bit as the OR of m q'-biased bits) | 2026-10-22 11:25 |
| A.18 | **RQ-A MAIN-4 (Theorem 4 of MAIN_RESULT_K3B): R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for all q in [q4, 25/169] = [1-sqrt3/2, 25/169] (and the mirror [144/169, sqrt3/2]); equality iff alpha = +-(e_i+e_j+e_k)/sqrt3, or q = q4 and alpha = +-(e_i+e_j+e_k+e_l)/2; R > T below q4. Corollary 1 (with A.14): {q <= 1/2 : R = T} = [q4, q3]. Corollary 2 (with A.6, A.11, A.14): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), on [q4, 1-q4]** | RQ-A MAIN_RESULT_K3B.md/.tex/.pdf (PDF 11:52; posted 11:55), AUDIT_REQUEST.md MAIN-4, data `outputs/k3b_manifest.json` (127ef15a…) | **VALID** (no fix needed) | **NEW** (closes the k = 3 regime; does not use A.16; lower bound KNOWN, Stone Thm 4.3.1) | 2026-10-22 12:41 |
| A.19 | RQ-B C17 (MAIN_RESULT Theorem 8.5): R_ID <= 22/25 = 0.88, by 142 exact cell-wise degree-10 majorant and moment-duality certificates on the (m1, m2) plane plus the C11 localisation; hence sqrt(2/e) <= lim_{q->0} R(q) <= 0.88 and R(q) <= 0.88 sqrt(q/((1-q) ln(1/(1-q)))), which is < 1 for q < 0.38814 and within 3.65% of M(q) on (0, 1/4] | RQ-B rq/MAIN_RESULT §8 (PDF 12:36), rq/CLAIMS.md (12:36), AUDIT_REQUEST §3, data `numerics/rid_slice_certs_22_25.json` (63b3b002…) | **VALID WITH FIXES** (text only: f1, the CLAIMS threshold 0.38815 is too large, q* = 0.388146, still open at 16:47 in RQ-B CLAIMS e7973f59… line 178; f2, "dropping any cell breaks the tiling" is false for 3 cells; f3, 1.03650 should be 1.03649. f2 and f3 are resolved: by 16:28 RQ-B's MAIN_RESULT reduced C17 to a "Degree 10" paragraph without either sentence) | NEW (no source found; improves A.13b's 0.9161; superseded by A.23's 0.867) | 2026-10-22 13:03 |
| A.20 | RQ-A MAIN-5, the parts marked PROVED (MAIN_RESULT_K4.tex Lemmas lem:or, lem:three, lem:four): (i) OR-region identity: if c_i > 0 and c_i > q sum c for all i, then E\|c . chi\| = 2 tau (1-q)^(n-1) sum c <= 2 sqrt(n) (1-q)^(n-1) tau \|c\|, so G_5(c) <= T5 \|c\| <= T4 \|c\| for q >= q5, with equality iff q = q5 and all c_i equal; (ii)–(iii) for q in [q5, q4] and c in R^3, R^4: E\|c . chi\| <= T4 \|c\| = 4 (1-q)^3 tau \|c\|, equality iff c is a positive multiple of +-(1,1,1,1), or q = q4 and c is one of +-(e_i+e_j+e_k); via H_f = 16 (1-q)^6 - sum Delta_i(f)^2 >= 0 for all 256 / 65,536 Boolean f. MAIN-5 itself (R = T4 on [q5, q4]) was CONDITIONAL then; it is audited in A.25 (VALID, 16:53) | RQ-A CLAIMS.md MAIN-5 (12:57, 7bfacf8e…), MAIN_RESULT_K4.tex (draft; 12:57 and 13:17 versions, the three lemmas identical) | **VALID** (no fix needed) | KNOWN within the project: the inequalities are cases n = 3, 4, 5 of RQ-C C6 (A.5) and the identity is RQ-B C3 (A.7c); RQ-A's proofs are independent | 2026-10-22 13:22 |
| A.21 | **RQ-C C13 (Theorem 1 of RQ-C MAIN_RESULT_K4): for u in [127/50, 131/50], i.e. q in [2500/19661, 2500/18629] = [0.127155, 0.134199], E\|sum alpha_i chi_i\| <= T = max(S_3, S_4) for every unit alpha, S_k = 2 sqrt(k) (1-q)^(k-1) sqrt(q(1-q)), with equality at (1,1,1,1)/2 for q <= q4 and at (1,1,1)/sqrt3 for q >= q4. So R = S_4 = 4 (1-q)^3 sqrt(q(1-q)) on [2500/19661, q4] and R = S_3 on [q4, 2500/18629]. Corollary (with A.6, A.11, A.14, A.18): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), on [2500/19661, 17161/19661]** | RQ-C CLAIMS.md (14:00, e3318c23…), MAIN_RESULT_K4.tex/.pdf (237f5806… / f0b4cffb…, PDF of 13:49), AUDIT_REQUEST.md (afdb0f63…), data `numerics/out/k4/s11_254_256.json`, `s12_2560_2580.json`, `s12_2580_2600.json`, `s12_2600_2620.json` (31d28bce…, f65717c1…, 5f780d44…, 093afeb9…) | **VALID** (re-rated 15:31 after fix f1 was posted, tex 093d3b68…, PDF b040e7de…; 14:29: VALID WITH FIXES, f1: Lemma lem:closure was false as stated and needed D ⊂ Q, which holds in both uses) | **NEW** (the first exact values of R(q) in the k = 4 regime, below q4; the part [q4, 0.134199] is inside A.18; lower bound KNOWN, Stone Thm 4.3.1) | 2026-10-22 14:29; VALID 15:31 |
| A.21b | **RQ-C C13 extension (addendum of 15:00): Theorem 1 of MAIN_RESULT_K4 on u in [131/50, 133/50], i.e. q in [2500/20189, 2500/19661] = [0.123830, 0.127155], with equality at (1,1,1,1)/2. With A.21: R = S_4 = 4 (1-q)^3 sqrt(q(1-q)) on [2500/20189, q4] = [0.123830, 0.133975], and R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1) on [2500/20189, 17689/20189]** | RQ-C AUDIT_REQUEST.md addendum (0163d3cf…, 16cd3c21…), CLAIMS C13 (087bff08…), MAIN_RESULT_K4.tex/.pdf (093d3b68… / b040e7de…), data `numerics/out/k4/s13_2620_2640.json`, `s13_2640_2660.json` (acd0e21e…, dc4f88a1…), including 21 degree-8 comparison boxes | **VALID** (no fix needed; A.21's f1 is posted) | **NEW** (extends A.21; the piece of the k = 4 regime with an exact value is now [0.123830, q4], about 36% of [q5, q4]) | 2026-10-22 15:47 |
| A.22 | RQ-A MAIN-6, the parts marked PROVED: the k = 5 three- and four-bit lemmas on [q6, q5] = [1-sqrt(5/6), 1-2/sqrt5] = [0.087129, 0.105573], i.e. sum_i Delta_i(f)^2 <= 20 (1-q)^8 for all 256 / 65,536 Boolean f, strict for 3 bits, and for 4 bits equality only for +-OR_4 at q5; hence E\|c . chi\| <= T5 \|c\| = 2 sqrt5 (1-q)^4 tau \|c\| for c in R^3, R^4. Also the n-coordinate bound at (1,...,1)/sqrt(n), n = 5, 6, from the OR-region identity and T6 <= T5 on [q6, q5]. MAIN-6 itself (R = T5 on [q6, q5]) is a CONJECTURE and is not audited | RQ-A CLAIMS.md (copy of 14:11, 2a36088d…), STATUS.md (13:58, 0c5c2248…) | **VALID** (no fix needed) | KNOWN within the project: cases n = 3, 4 of RQ-C C6 (A.5); the stronger k = 4 constant 16 (1-q)^6 already holds on [q6, q5]; the identity is RQ-B C3 (A.7c), audited with lem:or in A.20 | 2026-10-22 14:29 |
| A.23 | RQ-B C18 (MAIN_RESULT Theorem 8.5, tex Theorem 9.6): R_ID <= 867/1000, by 1,122 exact cell-wise degree-12 majorant and moment-duality certificates on the (m1, m2) plane plus the C11 localisation supp K* in [-sqrt2, sqrt2], a subset of [-99/70, 99/70]; hence sqrt(2/e) <= lim_{q->0} R(q) <= 0.867 and R(q) <= 0.867 sqrt(q/((1-q) ln(1/(1-q)))), which is < 1 for q < 0.42078 and within 2.12% of M(q) on (0, 1/4] | RQ-B rq/MAIN_RESULT §8 (PDF 13:45), rq/CLAIMS.md (df3d2fcc…), AUDIT_REQUEST §4 (fa3bcd7e…), data `numerics/rid12_certs_867_1000.json` (9e0e29f9…; robust variant `rid12_certs_87_100.json`, b4a0fea9…) | **VALID** (no fix needed; three remarks) | NEW (no source found; improves A.19's 0.88 and A.13b's 0.9161) | 2026-10-22 15:00 |
| A.24 | RQ-C C14 (bit lemmas uniform in k, <= 7 bits): for k >= 1, q in [q_{k+1}, q_k] ∩ (0, 1/2] and m <= 7, E\|c . chi\| <= T_k \|c\| for c in R^m and sum_{i<=m} Delta_i(f)^2 <= 4k (1-q)^(2k-2) for f: {0,1}^m -> [-1,1], with equality iff c is a positive multiple of +-1_S (resp. f = +-OR_S) and \|S\| in E_k(q) = {k} ∪ {k-1 at q_k} ∪ {k+1 at q_{k+1}}; the all-m form is Conjecture S; OR-region form for any m | RQ-C CLAIMS.md C14 (filed 14:45; text unchanged through 087bff08…), AUDIT_REQUEST.md (C14 request) | **VALID** (no fix needed) | KNOWN within the project (corollary of C6 = A.5, A.5b, of A.7c / A.20 and of unimodality; contains the bit lemmas of A.11, A.14, A.18, A.20, A.22); not in the literature | 2026-10-22 15:42 |
| A.25 | **RQ-A MAIN-5 (Theorem 5 of MAIN_RESULT_K4): R(q) = 4 (1-q)^3 sqrt(q(1-q)) for all q in [q5, q4] = [1-2/sqrt5, 1-sqrt3/2] (and the mirror); equality iff alpha = +-(e_i+e_j+e_k+e_l)/2, or (e_i+e_j+e_k)/sqrt3 at q4, or the 5-sum/sqrt5 at q5. Corollary 2: R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1) on [q5, 1-q5]** | RQ-A CLAIMS.md MAIN-5 (4dd8f7d5…; the section is unchanged through 3a8a0c64…), AUDIT_REQUEST MAIN-5 (7a4c9297…), MAIN_RESULT_K4.md/.tex/.pdf (368c72ee… / 9c7a75e9… / 7ce6cd40…, posted 15:49), data `outputs/k4_manifest.json` (e7ecde05…), 80 files with md5s `k4_MD5SUMS.txt` (3a8fd366…; all 80 verified at 16:07 in `audit/rqa/k4_data/`) | **VALID** (no fix to the mathematics; two status remarks: r1, Corollary 2 still calls Theorem 4 "not yet audited", and r2, Remark 4 says "Not yet audited"; both applied at 17:47, MAIN_RESULT_K4.tex 2de72bdb…, PDF 681c970f…, and nothing else changed; addendum of 21:19: RQ-A's text corrections c1–c2 of 20:51 (tex 158934d2…) are text only, my verifier already checked kinds and signs, data unchanged, r3 cosmetic (quoted md5 383e0b25… is not the posted file's); still VALID; refereed VALID by RQ-REF2 in tex 158934d2…, no fixes) | **NEW** (closes the k = 4 regime; extends A.21/A.21b from [0.123830, q4] to [q5, q4]; with A.6, A.11, A.14 and A.18, R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1) on [q5, 1-q5] = [0.10557, 0.89443]) | 2026-10-22 16:53; addendum 21:19; RQ-REF2 2026-10-23 01:05 |
| A.26 | RQ-B C19 (MAIN_RESULT Theorem 3.4 (a)–(e)) = RQ-A U.1–U.2: configuration-wise Poissonisation, 2 tau sqrt(D(f)) <= sqrt(q/((1-q)s)) E\|Z_{K_f}\| with lam+-_theta(K_f) in sZ; hence if E\|Z_K\| <= max(g(lam+_theta), g(lam-_theta), C) for every finitely supported K (theta fixed: RQ-B; theta depending on K: RQ-A), then R(q) = M(q) wherever C(q) >= C; min_{(0,q_K]} C = C(q_K) = C_K (C_4 = 0.8533436, C_5 = 0.8551005, C_6 = 0.8559845) | RQ-B rq/CLAIMS.md C19 (232c7a4c…), MAIN_RESULT.md §3 (tex 06cccefc…), AUDIT_REQUEST §5 (2d5e71b3…); RQ-A CLAIMS.md section U (4dd8f7d5…, 5b5b9bb1…) | **VALID** (U.1, U.2, C19(a)–(e); fix f1 for RQ-A's CONDITIONAL U.3: "ID*(0.853344)" rounded C_4 up and missed q in (0.13397376, q4), posted 16:33, RQ-A CLAIMS 3a8a0c64…; the remark on RQ-B's "theta <= 1.318" was applied at 16:28, RQ-B CLAIMS e7973f59…; both checked 16:55, nothing outstanding; addendum 2 of 20:37: RQ-B's later C19 text changes (rq/AUDIT_REQUEST 8ce749f5… item 6) confirmed, still VALID) | NEW (no source found; a reduction, built on A.10a; the hypothesis contains C5, open) | 2026-10-22 16:14 / 16:55 / 20:37; RQ-REF3 VALID (link 1, parts (a)–(d)) 2026-10-23 01:42 |
| A.27 | RQ-B C20 (MAIN_RESULT Theorem 1.2): for q in (0, q4] and every k >= 1, E\|chi_1 + ... + chi_k\|/sqrt k <= M(q), with equality iff kq < 1 and k maximises T_k; for kq >= 1 the left side is <= r_1/sqrt(1-q) < M(q) | RQ-B rq/MAIN_RESULT.md §1, CLAIMS C20, AUDIT_REQUEST §5 | **VALID** (no fix; remark: gamma_4 = 0.82355716 is truncated, a valid lower bound) | **KNOWN** (corrected 2026-10-23 01:29; rated "NEW as stated" at 16:14): the statement is Stone's equal-coefficient theorem (thesis UCI 2025, Thm 4.3.1, for all p <= 1/2; (1.10) of Ivanisvili–Stone), and A.15 already called RQ-B's Theorem 1 Stone's theorem. RQ-B's proof is different and elementary (Hoeffding Bin <=_cx Poisson; de Moivre; Remark 3.3 = A.15). Only the explicit bound r_1/sqrt(1-q) for kq >= 1, and the strict inequality it gives there, are NEW as stated (minor) | 2026-10-22 16:14; novelty corrected 2026-10-23 01:29 |
| A.28 | RQ-C C15: at a finite-q maximiser, P(L = 0) = 0, E[chi_i sgn L] = R_n alpha_i and u\|alpha_i\| <= Lambda_n -> sqrt(2/(1-q)); so the q-free hypothesis of A.26 is needed only for K on [-A, A], any A > A'(q) = sqrt(2q/s)/(1-q) (1.538 at q5, 1.576 at q4) | RQ-C CLAIMS.md C15 (715a241b…, text unchanged in 3b854357…), AUDIT_REQUEST (0e6b07bd…, f93e0c97…) | **VALID** (no fix) | NEW (finite-q analogue of A.13a; technique standard) | 2026-10-22 16:14; RQ-REF3 VALID (link 2) 2026-10-23 01:42 |
| A.29 | RQ-C C16: (ID-theta) with theta fixed and C = sqrt(2/e) - eta fails for every theta > theta_max(eta) (0.95938 for eta = 0.0044), by two-atom K = (1-eps) delta_a + eps delta_b; certified instances | RQ-C CLAIMS.md C16 (715a241b…, scope sentence 3b854357…), `numerics/out/idtheta/threshold.out` | **VALID** (re-rated 16:24 UTC: f1 posted 16:20, CLAIMS a452bb78…, margins now ">= 1.43·10^-4" and ">= 9.7·10^-5", below the certified 1.4393·10^-4 and 9.756·10^-5; the grid remark also applied. VALID WITH FIXES at 16:14) | NEW (negative result about the fixed-theta plan; closed form = A.10d) | 2026-10-22 16:14 / 16:24 |
| A.30 | RQ-D D1 (flip formula \|y + w\| = \|y\| + sgn(y) w + 2(-sgn(y) w - \|y\|)_+) and D2 (OR-region identity with a residual: E\|Z_K\| = 2me^{-Lambda} + 2e^{-Lambda} E(W - m)_+ + 2E[(-W - Y)_+; N_S >= 1], and 2me^{-Lambda} <= sqrt(2/e) sqrt(V_S)) | RQ-D CLAIMS.md (68450a97…; f1 in 5802cb5d…), MAIN_RESULT.tex Lemmas 1–2 (0ac23953…; Lemma 3 in 4df86775…) | D1 **VALID**; D2 **VALID** (re-rated 17:23 UTC: f1, K_S != 0, posted 17:18 in CLAIMS and the tex; VALID WITH FIXES at 16:14) | D1 KNOWN in kind (elementary); D2 NEW as stated, its case K_R = 0 is RQ-B Prop. 6(a) (A.10d) | 2026-10-22 16:14 / 17:23; RQ-REF3 VALID (link 3: D1 and D2 are Lemmas 1 and 3 of tex 212c6f23…) 2026-10-23 03:09 |
| A.31 | RQ-A U.6: K a finitely supported probability on (0, oo), theta >= m(K): (a) E\|Z_K\| = 2e^{-Lambda} E(m - S_R)_+; (b) E\|Z_K\| <= B(Lambda, rho^2) = e^{-Lambda}[sqrt(Lambda(1 - rho^2)) + sqrt(rho^2 + Lambda(1 - rho^2))]; (c) if lambda+_m(K) >= 1/2, E\|Z_K\| <= g(lambda+_m(K)), equality iff K is one atom, so ID*(C) holds for such K (and for K on (-oo, 0)) | RQ-A CLAIMS.md (10de5cac…) | **VALID** (r1, cosmetic: a NUMERICAL scope interval includes an endpoint where B = g; applied at 18:00, CLAIMS 6b00a3e1…) | (a) KNOWN within the project (A.30 D2; RQ-B Prop. 6(a)); (b), (c) NEW as stated (elementary) | 2026-10-22 17:23 |
| A.32 | RQ-D D6–D12 (MAIN_RESULT Lemmas 2, 4, 6–8, Proposition 9, Theorem 10, Corollary 11). The tools are a comparison lemma (pushing jumps right increases E psi(Z_K) when psi'' is nondecreasing), stop-loss bounds through two-point comparison laws, and the band bound (F). Theorem 10: E\|Z_K\| <= sqrt(2/e) for every probability K on [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10 (or the mirror); for finitely supported K, equality only at delta_{+-sqrt2}; computer-assisted. Corollary 11: C5 reduces to the far region | RQ-D CLAIMS.md (5802cb5d…), MAIN_RESULT.tex/.pdf (4df86775… / f69703ee…), AUDIT_REQUEST (f99c2f3f…; erratum 92c8487c…) | **VALID** (no fix; my own certified verifier: Part S 767 boxes, Part B 489 squares and 369,066 boxes, 0 failures) | Theorem 10 and Corollary 11 NEW; Lemma 4 NEW as stated (technique standard: Bergenthum–Rüschendorf 2007; 3-convex order, Denuit–Lefèvre–Shaked 1998); the other lemmas elementary | 2026-10-22 18:17; RQ-REF3 VALID (link 3: Lemmas 2, 4, 6–8, Proposition 9; Theorem 10 and Corollary 11 are not used by the chain) 2026-10-23 03:09 |
| A.33 | RQ-A U.7, the consequence marked "PROVED, given the conjecture": if some maximiser alpha is one-signed (U.7), then K_f of U.1 is carried by (0, oo), so ID*(C) is needed for one-signed K only | RQ-A CLAIMS.md (6b00a3e1…) | **VALID** as an implication (r1, cosmetic: "equivalently" is shown only as "implies"; applied at 19:50, RQ-A CLAIMS 8bec3483…). U.7 itself holds for n <= 7 by A.5/A.5b and is open for n >= 8 | NEW as stated (elementary) | 2026-10-22 18:17 |
| A.34 | **RQ-D D16–D20 (MAIN_RESULT Lemma 7(c), (O1)–(O5), Lemma 12, Theorem 13, Corollaries 14–15). Theorem 13 (the ID* band lemma): E\|Z_K\| <= max(g(lambda+_0.85(K)), C_5) for every finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, and the mirror statement; computer-assisted. Corollary 14: ID*(C_5) on [-1.54, 1.54] follows from E\|Z_K\| <= C_5 on the far region {K([0.85, 1.54]) < 4/5, K([-1.54, -0.85]) < 4/5}. Corollary 15: Theorem 13 for all K, and C5 reduces to the same far region. With A.25, A.26 and A.28, Conjecture S for all q now follows from that one far-region inequality** | RQ-D CLAIMS.md (aa4587a5…), AUDIT_REQUEST second request with addendum (476ea8d3…), MAIN_RESULT.tex/.pdf (bba5c599… / 3137370e…), recorded run `outputs/verify_bandstar.txt` (c36c17e5…, counts only) | **VALID** (no mathematical fix; my own certified verifier: 1,303 (a, b) squares and 13,083,096 (Lambda, m) boxes, 0 uncertified; two cosmetic remarks; text slip f1 in a remark of Section 6.1, found at the addendum and applied by RQ-D at 05:35; refereed VALID by RQ-REF3 as part of link 3, which re-did the computation with its own cover: 1,212 squares and 9,077,343 leaf boxes, 0 uncertified) | Theorem 13 and Corollaries 14–15 NEW; (O5) and Lemma 12 NEW as stated (elementary); Lemma 7(c) KNOWN in kind (two-point extremal laws for given mean and variance) | 2026-10-22 20:19; addendum 2026-10-23 03:02 (f1: "0.4463 < Lambda < 0.5599" should read 0.5579; text only); RQ-REF3 VALID 2026-10-23 03:09; RQ-D's box-level record replayed with my verifier 04:51 (a34f–a34h: all 7,874,211 leaves certified; record VALID); RQ-D's text-only fixes of 05:35 checked 06:58 (a34i: tex ac0ecf4f… and PDF f0fc9c23… differ from the refereed 212c6f23… and fed00af2… only in the two figures and the date; f1 and r3 applied; cosmetic r4, a rounding slip in my own r3 figure that D13 copied); r4 applied by RQ-D at 07:40 and checked at 07:48 (a34j: CLAIMS 77201a7b… changes only the D13 figure and its label; tex, PDF and record unchanged) |
| A.35 | RQ-A U.9 (the Gaussian corner of ID*): for every Kolmogorov probability measure K, \|E\|Z_K\| - sqrt(2/pi)\| <= (1/2) int \|x\| dK; hence E\|Z_K\| <= C_5 = C(q5) whenever int \|x\| dK <= 2(C_5 - sqrt(2/pi)) = 0.1144317…, and ID*(C_5) holds for these K with every theta | RQ-A CLAIMS.md U.9 (8bec3483…), AUDIT_REQUEST U.9 (eef0b8a4…, filed 19:27) | **VALID** (no fix; one remark: for K with infinite Levy measure the zero-bias identity is used through an approximation that U.9 leaves implicit; the project needs only finitely supported K; addendum of 21:19: RQ-A's write-up MAIN_RESULT_U9 (tex 12949c06…, 20:58) is the same proof and its Lemma 5 proves the identity for every K, so the remark is settled; own check a35b, 34 PASS; r3 cosmetic; still VALID) | KNOWN within the project: the analytic core is BF3 Lemmas 9.5–9.6 (A.0) and the one-sided bound is RQ-B Prop. 6(b) (A.10d); technique standard (zero-bias Stein method, Goldstein–Reinert, Ann. Appl. Probab. 1997). The two-sided form and the C_5 threshold are NEW as stated (elementary) | 2026-10-22 20:37; addendum 21:19 |
| A.36 | RQ-C C19(a): at the q -> 0 extremal law X = N - 1/2, N ~ Poisson(1/2), D(-g)/g^2 <= -e^{-1/2}/2 for every g > 0, with equality only at g = 1; so negative mass costs at least 1/4 of its variance share to first order (relative to sqrt(2/e)), and the mirror jump is the only cheapest negative direction. Kolmogorov form: d/deps E\|Z_K\| at K = delta_sqrt2, in the direction delta_x, is <= -sqrt(2/e)/4 for x < 0, with equality only at x = -sqrt2 | RQ-C CLAIMS.md C19 (29481696…) | **VALID** (no fix) | NEW as stated (elementary corollary of C4(a), A.2); first order at one law only, as RQ-C says | 2026-10-22 20:37 |
| A.37 | **RQ-A MAIN-6 (Theorem 6 of MAIN_RESULT_K5): R(q) = T5 = 2 sqrt5 (1-q)^4 sqrt(q(1-q)) for all q in [q6, q5] = [1-sqrt(5/6), 1-2/sqrt5] = [0.087129, 0.105573] (and the mirror); equality iff alpha = +-(e_i1+...+e_i5)/sqrt5, or q = q5 and alpha = +-(e_i+e_j+e_k+e_l)/2, or q = q6 and alpha = +-(e_i1+...+e_i6)/sqrt6; R > T5 on (0, q6) and (q5, 1/2]. Corollary 1: {q <= 1/2 : R = T5} = [q6, q5]. Corollary 2 (with A.6, A.11, A.14, A.18, A.25): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), on [q6, 1-q6] = [0.087129, 0.912871]** | RQ-A CLAIMS.md MAIN-6 (4b4c4fc0…), AUDIT_REQUEST MAIN-6 (0fb607ea…, filed 22:37), MAIN_RESULT_K5.md/.tex/.pdf (6a573452… / fc7dc6a1… / 1357f839…), data `outputs/k5_manifest.json` (7c92bc42…), 105 data files and the manifest with md5s `k5_MD5SUMS.txt` (918eb069…, 106 entries; all match in the store and in `audit/rqa/k5_data/` at 22:57) | **VALID** (no fix; my own full independent run on the filed data: 861 cells, the box tilings for both signs, 52,292/52,292 vertex-certificate sets, 4,303/4,303 split trees, 0 failures; one cosmetic remark on the height counts of Table 1; r1 applied 23:04–23:06 (MAIN_RESULT_K5.tex 5b13f960…), text only, the new counts are my recount; refereed VALID by RQ-REF2 in tex 5b13f960…, no fixes) | **NEW** (closes the k = 5 regime; lower bound KNOWN, Stone Thm 4.3.1) | 2026-10-22 22:58; addendum and RQ-REF2 2026-10-23 01:05 |
| A.38 | **RQ-D D21–D23 (MAIN_RESULT Section 7: Lemmas 18–24, Theorem 16, Corollary 17). Theorem 16 (the heavy far region): E\|Z_K\| < C_5 for every probability Kolmogorov measure K on [-1.54, 1.54] with 1/2 <= K([0.85, 1.54]) < 4/5, or with 1/2 <= K([-1.54, -0.85]) < 4/5; computer-assisted. Corollary 17: if E\|Z_K\| <= C_5 for every finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) < 1/2 and K([-1.54, -0.85]) < 1/2 (the light far region F_light), then ID* holds on [-1.54, 1.54] and C5 holds. With A.25, A.26, A.28 and A.34, Conjecture S for all q now follows from that one F_light inequality** | RQ-D CLAIMS.md (ed68d60e…), AUDIT_REQUEST third request (c57b91c3…, filed 22:45), MAIN_RESULT.tex/.pdf (9498b44f… / ee067424…), data `outputs/plus_cert/certs_v1_r0..r4.jsonl` (e23d52dd…, ee9307ee…, f5fe9a23…, 6d495261…, 3033710b…) | **VALID** (no fix; my own exact verifier: 436 boxes tile the rate rectangle, 156 empty, 280 certified with 1,237 cell certificates, 0 failures, worst bound 0.8548832 < C_5; three remarks, two of them settled by the filing; r3 settled at 23:25, text only, MAIN_RESULT.tex 212c6f23…) | Theorem 16 and Corollary 17 NEW; Lemma 18 KNOWN in kind (convex order: two-point extremal law on an interval, preserved under compound Poisson sums); the moment, McCormick and Hölder relaxation is standard technique; Lemmas 19–24 elementary | 2026-10-22 22:51; RQ-REF3 VALID (link 3; certificates 01:58) 2026-10-23 03:09; Section 7 unchanged in RQ-D's tex ac0ecf4f… of 05:35 (a34i, 06:58) |
| A.39 | **RQ-B F18 (MAIN_RESULT §13: Lemmas S1–S5, C, D, E; Theorem 13.1). Theorem 13.1 (the light far region): with A = 77/50 and theta = 17/20, E\|Z_K\| <= 171/200 = 0.855 < C_5 for every finitely supported probability Kolmogorov measure K on [-A, A] with K([theta, A]) < 1/2 and K([-A, -theta]) < 1/2; computer-assisted. With A.38 (Corollary 17) and A.34 (Corollary 14) it gives ID*(C_5) on [-1.54, 1.54], hence C5 and R = M on (0, q5] (A.26, A.28); with A.25, A.18, A.14, A.11 and A.6, Conjecture S for all q** | RQ-B rq/CLAIMS.md F18 (9de8c9c5…), AUDIT_REQUEST §7 (8baa91a7…, updated 23:28), MAIN_RESULT.md/.tex/.pdf §13 (b47f2945… / e4193842… / a6901915…), data `numerics/cover_final/nsplit_D14.jsonl.xz`, `chord_D14.jsonl.xz`, `light_vl025_D18.jsonl.xz` (0883b5d9…, 3d7366f9…, 2bbb7484…) | **VALID** (no fix; my own exact verifier on the filed data: 7,956 + 60 + 537 roots covered, 8,481 + 1,212 + 1,273 certificates, 0 failures, worst bound 0.8549969806 < 171/200; controls 72/72; semantic tests on 6,000 random and 189 fixed laws, no violation; text remarks r1, r2, r4, and r3 informational) | Theorem 13.1 NEW; Lemma S5 NEW (elementary); Lemma S1 KNOWN in kind (Poisson thinning, two-point convex-order maximum); Lemma C standard technique; S2–S4 elementary | 2026-10-23 01:05; addendum 2026-10-23 02:29 (RQ-REF3 VALID as link 4, counts equal to mine; length controls a39o 35/35 PASS) |
| A.40 | **Composition of the all-q chain (no solver claim; the chain in RQ-A's NOTES of 00:02 and in RQ-C's reproduction report of 01:06). Conjecture S: R(q) = M(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), for every q in (0, 1). For q <= 1/2, M = T_k = 2 sqrt(k) (1-q)^(k-1) sqrt(q(1-q)) on [q_{k+1}, q_k], attained at OR_k. Hence lim_{q->0} R(q) = R_ID = sqrt(2/e) (C5). Links: [q5, 1/2] by A.25, A.18, A.14, A.11 and A.6; (0, q5] by ID*(C_5) with theta = 0.85 on [-1.54, 1.54] (A.34 for V+- >= 4/5, A.38 for 1/2 <= V+- < 4/5, A.39 for V+, V- < 1/2), then A.28 (A = 1.54 > A'(q5) = 1.538044) and A.26 (C(q) >= C_5 on (0, q5]); q > 1/2 by the mirror** | RQ-A NOTES_FOR_TEAM (30a1be9c…, list of 00:02); RQ-C AUDIT_REQUEST (07a808bc…) and NOTES (118e7d99…), 01:06, "no new claim"; LOCKED_NOTE (c054a4b5…, then 2dc77e79…: RQ-REF3 launched at 18:24 PT) | **VALID** at audit level (no fix; every link is VALID; my seam check `audit/chain/a40_chain_seams.py`, 24 PASS: endpoint order, band ties, C(q) >= C_5, A'(q5) < 77/50, 171/200 < C_5, theta = 0.85 < theta_max = 1.00628); **refereed VALID by RQ-REF3, FINAL** (REFEREE 6ac713c0…, 03:09 UTC: all four links and the composition), so A.40 meets the LOCKED_NOTE criterion | **NEW** (no source gives R(q) for all q; before this project only BF3's [3/8, 5/8]; Ivanisvili–Stone, Remark 1.3, assume that R equals the equal-coefficient value (1.10); searches at 01:15 and 01:25 UTC) | 2026-10-23 01:29; hostile-search addendum 2026-10-23 02:00 (a40b, a40b2, a40c: no vector above M on (0, q5]); RQ-REF3 FINAL VALID 2026-10-23 03:09; text-figure sweep of links 1, 2, 4 (a40f, 79 PASS) 03:30; literature re-check 03:41 (a40g; novelty unchanged); central-range direct search 03:57 (a40h: no vector above M at 38 points of [q5, 1/2] and above 1/2); many-atom lattice search of ID*(C_5) 04:51 (a40i: no law above the few-atom optima); the same on the finer lattice of step 1/200 05:42 (a40j), and for the band and all-K objectives 06:00 (a40k, a40k2); first variation at the Dirac arc in closed form, with the band margins of a40i, a40k and a40k2 corrected, 06:09 (a40l); seam search inside (0, q5) 08:51 (a40s: no vector above M next to the seams q6–q11, q16, q21, q31, q51 and q101; the non-equal maxima found are certified below M at the exact seams in Arb) |
| A.41 | **RQ-A's FULL_PROOF.pdf, the compiled proof of Conjecture S (192 pages, delivered to Paata as Rq_full_proof.pdf at 01:57 PT = 08:57 UTC): front matter with the Main Theorem and its proof (Steps 0–4), Chapters 1–10 transcribed from the refereed sources (RQ-A's six papers, RQ-B's Sections 1–4 and 6 with RQ-A U.1–U.3, RQ-C's C15, RQ-D's paper, RQ-B's §13), and Appendices A–D (computer steps, ledger, transcription, concordances)** | RQ-A FULL_PROOF.pdf / .tex (be3ca559… / 0ec0a1e2…, posted 08:53–08:54) with the parts in `full_proof/` and the source copies in `full_proof/sources/`; LOCKED_NOTE (7dbc0d30…, 09:00:47); copies `audit/snapshots/s0900_fullproof/`. Corrected file (21fe1613… / 14777fb4…, posted 10:05:37–10:05:38) with AUDIT_REQUEST (eb6448ca…); copies `audit/snapshots/s1006_fullproof2/` | **VALID** (re-rated 10:22 for RQ-A's corrected file of 10:05, pdf 21fe1613… and tex 14777fb4…: it applies the four fixes and changes nothing else, a41h. 09:57: VALID WITH FIXES for the delivered file, text only; the mathematics is that of A.40, every chapter is a faithful transcription of its refereed source, and every computer step is cited with the counts and md5s of A.6–A.39. f1: the Boolean-form remark claims equality "for the OR of k bits" for every q, but for q > 1/√2 only the AND of k bits attains it; f2: five "…" figures are roundings, not leading digits; f3: the k = 30..35 run on RQ-A's cores finished at 23:09 UTC, not 23:33 (two places); f4: Theorem 1 lists its extremisers in part (c), not (b); remarks r1–r4) | As A.40: **NEW** (R(q) for every q); the document adds no mathematics, and its Boolean restatement is KNOWN in kind (Lemma 7.5 = RQ-B Lemma 2.1, A.7a) | 2026-10-23 09:57; addendum 10:22 (a41g, rendered pages); VALID 10:22 (addendum 2: the corrected file, a41h and a41i); addendum 3 10:36 (the proof of the Main Theorem rebuilt step by step, no gap); 11:23: a41j (the referee lines of the source boxes agree with the reports) and the Status paragraph made precise (only A.40 and its links are refereed, and they are all the proof uses) |

**Meets the LOCKED_NOTE criterion (VALID by RQ-AUD and by an independent referee).**
- RQ-REF1, report `RQ-REF1/REFEREE.md`, referees A.6, A.11, A.14 and A.18: Theorem 1 VALID in the version of
  14:53:16 UTC (925c310a…), Theorems 1–3 VALID in the version of 14:58:47 UTC (f89e0d97…), and Theorems 1–4 VALID in
  the version of 15:35:47 UTC (369c1cfb…). RQ-REF1 used its own code and different algorithms (exact Bernstein
  subdivision instead of Sturm sequences or Arb, recursive-splitting coverage instead of area sums, tensor Bernstein
  bounds for (P4)). Every count it reports agrees with mine. LOCKED_NOTE (473bc402…) records at 08:38 PT that
  Theorems 1–4 are auditor and referee VALID and were reported to Paata. A.6's addendum (2026-10-23 02:55 UTC) re-checks A.6
  on the text RQ-REF1 refereed (tex 6816732f…, PDF 0a95569f…). It finds one slip in the appendix (f3, text only), and
  Theorem 1 is unaffected. RQ-A applied f3 at 03:04 UTC (mirrored 03:08: tex 38b69350…, PDF 5c0ac2ef…), and the
  corrected text differs from the refereed one only by that figure (A.6 addendum 2, 03:30 UTC). LOCKED_NOTE
  (410b562f…) records f3 at 20:08 PT, to be mentioned in the final summary to Paata.
- RQ-REF2, report `RQ-REF2/REFEREE.md` (bd18da81…, written 2026-10-23 01:05 UTC), referees A.25 and A.37: MAIN-5 VALID
  in tex 158934d2… (the version of my A.25 addendum of 21:19) and MAIN-6 VALID in tex 5b13f960… (the r1 version; see
  the A.37 addendum), both with no fixes. RQ-REF2 used its own code (gmpy2; Bernstein subdivision instead of Sturm
  sequences, face-splitting coverage instead of volume sums, integer-cofactor facet normals) on the data lists
  3a8fd366… (k4) and 918eb069… (k5), the same lists as mine. Every count it reports agrees with mine: for K4, 1,268
  cells, 7,261 boxes (3,327 / 1,216 / 2,718), 21,014 sets with 171,488 vertices, 2,533 four- and 383
  five-coordinate pieces; for K5, 861 cells, 9,166 boxes, 52,292 sets with 784,616 vertices and 4,303 split trees.
  It also checks the 129-box set equality of Remark 4 that I checked in the A.37 addendum. LOCKED_NOTE (c054a4b5…)
  records at 18:05 PT that R(q) on [1-sqrt(5/6), sqrt(5/6)] is auditor and referee VALID and was reported to Paata.
- RQ-REF3, report `RQ-REF3/REFEREE.md` (**FINAL**; 6ac713c0…, written 2026-10-23 03:09:02 UTC), referees the chain
  A.40 link by link with its own exact code (gmpy2 rationals). It ran none of the authors' or my code and read
  AUDIT.md for orientation only. **Overall verdict VALID: "Conjecture S holds for all q in (0, 1)".** It takes RQ-A
  MAIN-1..6 on [q6, 1-q6] as given; RQ-REF1 and RQ-REF2 refereed them (the bullets above).
  - Link 1 is the reduction: RQ-B Lemma 2.1, Theorem 3 and Theorem 3.4 (a)–(d), that is A.26 with A.7a and A.10a.
    Link 2 is RQ-C C15 (A.28). Both are VALID since 01:42 UTC.
  - Link 4, RQ-B Theorem 13.1 with Lemmas S1–S5, C, D and E (A.39), is VALID since 02:23 UTC. RQ-REF3 re-verified
    all 10,966 certificates on the files whose md5s A.39 used, and every count and worst bound equals mine (A.39
    addendum).
  - Link 3, RQ-D Sections 2–7, is VALID since 03:09 UTC. It contains A.30 (Lemmas 1 and 3), the lemmas of A.32 that
    the chain uses (Lemmas 2, 4, 6–8 and Proposition 9), A.34 and A.38.
    - Theorem 16: RQ-REF3 re-verified RQ-D's certificates (01:58 UTC). Its counts are those of A.38: 436 leaves, 280
      certified and 156 empty, 1,237 cells, and the worst bound 0.8548832 < C_5 in the same box and cell.
    - Theorem 13: RQ-D's run stores no box-level certificate, so RQ-REF3 re-did the computation with its own cover of
      D*. It certifies all 351 squares of side 1/128 through 1,212 squares (351/205, 796/84, 336/6 and 24/0 per
      level, as squares/not certified), with 9,077,343 leaf boxes, 584 of them by the slope check.
    - So there are now three independent covers for Theorem 13, and each certifies every square. Mine (A.34) has
      1,303 squares (351/213, 829/94, 376/18, 72/0) with 10,959,497 leaf boxes, 655 by the slope check. RQ-D's has
      1,339 squares (351/215, 837/102, 408/20, 80/0); RQ-D states 7,874,211 leaf boxes, 426 by the slope check.
  - No link uses RQ-D's Theorem 10 or Corollary 11, RQ-D's C5 statement, or RQ-C's chain check.
  - There are two robustness remarks and no gap. RQ-B's verifier does not enforce the lengths of the multiplier
    lists; my A.39 verifier does (a39o). RQ-D's band run stores no box-level certificate; A.34 rests on my own cover.
  - LOCKED_NOTE (410b562f…, line of 20:10 PT = 03:10 UTC) records the chain as doubly verified (with A.40) and
    reported to Paata.
- **A.6 — RQ-A MAIN (Theorem 1 of MAIN_RESULT):** R(q) = 2 sqrt(q(1-q)) exactly on [1-1/sqrt2, 1/sqrt2], false
  outside, with extremisers. RQ-AUD VALID at 06:52 UTC. The counts agree with A.6: 379/379 six-moment cells and
  641/641 quartic boxes.
- **A.11 — RQ-A MAIN-2 (Theorem 2 of MAIN_RESULT_K2):** R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) exactly on
  [q3, q0] = [0.18350, 0.29289] and the mirror, sharp at both ends, with extremisers. RQ-AUD VALID at 08:52 UTC. The
  counts agree with A.11: 784 cells; 38,631 and 16,884 boxes; 48,810 lp, 4,835 near-circle and 1,189 m-split boxes,
  with 1,669 pieces.
- **A.14 — RQ-A MAIN-3 (Theorem 3 of MAIN_RESULT_K3):** R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) exactly on
  [25/169, q3] = [0.14793, 0.18350] and the mirror, with extremisers. RQ-AUD VALID at 10:37 UTC. The counts agree
  with A.14: 2,704 cells and 81,975 boxes, of which 57,333 lp and 21,232 m-split, with 32,932 pieces.
- **A.18 — RQ-A MAIN-4 (Theorem 4 of MAIN_RESULT_K3B):** R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) exactly on
  [q4, 25/169] = [0.13397, 0.14793] and the mirror, with extremisers +-(e_i+e_j+e_k)/sqrt3, plus
  +-(e_i+e_j+e_k+e_l)/2 at q4; R > T below q4. RQ-AUD VALID at 12:41 UTC. The counts agree with A.18: 288 cells;
  941 and 480 boxes; 2,845 vertex certificates with 16,544 vertices (1,106 lpv, 302 ms5, 871 TC, 146 SG); 302
  m-split records with 123 A3 and 301 A4 pieces. RQ-REF1's remarks (the (P4) description, mtop rounding in 197 of the
  302 ms5 records, boxes beyond u4) need no fix, as in A.18.
- **A.25 — RQ-A MAIN-5, Theorem 5 of MAIN_RESULT_K4 (RQ-AUD VALID since 2026-10-22 16:53 UTC; RQ-REF2 VALID at
  2026-10-23 01:05 UTC in tex 158934d2…, PDF b975e187…, 24 pages):** R(q) = T4 = 4 (1-q)^3 sqrt(q(1-q)) exactly on
  [q5, q4] = [1-2/sqrt5, 1-sqrt3/2] = [0.105573, 0.133975], and on the mirror.
  - It is sharp at both ends, with the extremisers +-(e_i+e_j+e_k+e_l)/2, plus +-(e_i+e_j+e_k)/sqrt3 at q4 and
    +-(e_i1+...+e_i5)/sqrt5 at q5.
  - This closes the k = 4 regime: {q <= 1/2 : R = T4} = [q5, q4].
  - It contains A.21/A.21b's range on the k = 4 side and proves it independently.
  - Text changes after the audit, all text only (A.25 addenda): the status remarks r1–r2 at 17:47, and the
    corrections c1–c2 at 20:53.
  - Rerun on 8 cores:
    - `audit/rqa/a25_k4_verify.py` with parts MABCDF, about 2.5 min. It reads `audit/rqa/k4_data/`; copy the 80 files
      of `k4/` from RQ-A's `outputs/k4/`, and check them against `k4_MD5SUMS.txt` (part M does this).
    - `a25b_k4_negative.py` (7 s), `a25c_k4_semantic.py` (11 s), `a25d_k4_textcheck.py` (1 s) and `a20_k4_bits.py`
      (2 s).
- **A.37 — RQ-A MAIN-6, Theorem 6 of MAIN_RESULT_K5 (RQ-AUD VALID since 2026-10-22 22:58 UTC; RQ-REF2 VALID at
  2026-10-23 01:05 UTC in tex 5b13f960…, PDF 1928ab29…):** R(q) = T5 = 2 sqrt5 (1-q)^4 sqrt(q(1-q)) exactly on
  [q6, q5] = [1-sqrt(5/6), 1-2/sqrt5] = [0.087129, 0.105573], and on the mirror.
  - It is sharp at both ends. The extremisers are +-(e_i1+...+e_i5)/sqrt5, plus +-(e_i+e_j+e_k+e_l)/2 at q5 and
    +-(e_i1+...+e_i6)/sqrt6 at q6.
  - This closes the k = 5 regime: {q <= 1/2 : R = T5} = [q6, q5].
  - The refereed tex differs from the audited fc7dc6a1… only by the r1 changes (Table 1 caption, Remark 4, status
    item); see the A.37 addendum.
  - For the all-q chain, the far-region target rises to C_6 = C(q6) = 0.8559845 (A.26), with support in
    [-A'(q6), A'(q6)] = [-1.51455, 1.51455] (A.28).
  - Rerun on 8 cores:
    - `audit/rqa/k5_verify.py` with parts MABCDF, about 25 min. It reads `audit/rqa/k5_data/`; copy the 105 data
      files of `k5/` from RQ-A's `outputs/k5/`, and check them against `k5_MD5SUMS.txt` (106 entries with the
      manifest; part M does this).
    - `k5_negative.py` (2.3 min), `k5_semantic.py` (11 s), `a22_k5_bits.py`, `a37_k5_text_cumulants.py`,
      `a37_k5_table_check.py` (3 s), `a37c_k5_r1_check.py` (1 s) and `a37_k5_hostile.py` (12 min).
- Together: R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), on [q6, 1-q6] = [1-sqrt(5/6), sqrt(5/6)]
  = [0.087129, 0.912871], with the extremisers above. The regimes k = 1, ..., 5 are closed:
  {q <= 1/2 : R = T_k} = [q_{k+1}, q_k], with q_1 = 1/2 and q_{k+1} = 1 - sqrt(k/(k+1)).
- **A.40 — Conjecture S for all q in (0, 1) (RQ-AUD VALID at audit level since 2026-10-23 01:29 UTC; RQ-REF3 VALID,
  FINAL, at 03:09 UTC):** R(q) = M(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), for every q in
  (0, 1), attained at OR_k. Hence lim_{q->0} R(q) = R_ID = sqrt(2/e).
  - [q5, 1-q5]: A.6, A.11, A.14, A.18 and A.25 (A.37 also covers [q6, q5]), refereed in the bullets above.
  - Link 1: R = M on (0, q5] reduces to ID*(C_5) on finitely supported K. This is A.26 parts (a)–(d) with its inputs
    A.7a and A.10a. RQ-AUD rated A.7a VALID WITH FIXES at 2026-10-22 06:59; the fix was a typo, and A.10 (08:11)
    records it as fixed in RQ-B's Lemma 2.1. A.10a is VALID at 08:11 and A.26 at 16:14. The ledger row of A.7a
    was re-rated VALID at 2026-10-23 07:48 (A.7 addendum).
  - Link 2: the support bound A'(q) (A.28; RQ-AUD VALID at 2026-10-22 16:14).
  - Link 3: RQ-D's Sections 2–7, that is A.30 (VALID at 2026-10-22 17:23), the lemmas of A.32 that the chain uses
    (18:17), A.34 (band, Theorem 13 and Corollaries 14–15; 20:19; RQ-D's box-level record of the Theorem 13 run
    replayed leaf by leaf with my verifier at 04:51; RQ-D's text-only fixes of 05:35 checked at 06:58) and A.38 (heavy far region, Theorem 16 and Corollary 17;
    22:51).
  - Link 4: E|Z_K| <= 171/200 on the light far region, Theorem 13.1 (A.39; RQ-AUD VALID at 2026-10-23 01:05).
  - The composition: A.40 (01:29), with the hostile searches a40b, a40b2 and a40c (02:00; no vector above M on
    (0, q5]), a40h (03:57; none at 38 points of [q5, 1/2] and above 1/2, seams included), a40i (04:51; no
    law with up to 308 lattice atoms beats the few-atom optima of ID*(C_5)), a40j (05:42; the same with 616
    atoms on the lattice of step 1/200), a40k and a40k2 (06:00; the band and all-K objectives on that lattice),
    a40l (06:09; the first variation at the Dirac arc in closed form, which corrects the band margins of a40i, a40k
    and a40k2) and a40s (08:51; none next to the 11 seams q6–q11, q16, q21, q31, q51 and q101 inside (0, q5)), and
    the seam, integrity and text-figure checks a40, a40d, a40e and a40f. a40g (03:41) certifies the integral
    int_0^{pi/2} M((1 + sin theta)/2) d theta = 1.4217818 of Ivanisvili–Stone's Remark 1.3, which equals int R by
    A.40.
  - The extremisers are characterised only on [q6, 1-q6] (A.37 and earlier).

**Ready for an independent referee (per LOCKED_NOTE).** AUD verdict VALID; not yet refereed:
- RQ-REF3's FINAL report (2026-10-23 03:09 UTC) has refereed the chain parts of the entries below: A.26 (a)–(d) with
  A.7a and A.10a, A.28, A.30, the lemmas of A.32 that the chain uses, A.34, A.38, A.39 and the composition A.40.
  They are in the block above, and their entries here are kept for the rerun commands. The parts that remain
  unrefereed are A.26 (e), A.27, A.29, A.32's Theorem 10 and Corollary 11, and the other entries of this list.
- **A.21 + A.21b — RQ-C C13 (VALID since 15:31 and 15:47 UTC):** for u in [127/50, 133/50], i.e. q in
  [2500/20189, 2500/18629] = [0.123830, 0.134199], E|sum alpha_i chi_i| <= max(S_3, S_4) for every unit alpha.
  - So R = S_4 = 4 (1-q)^3 sqrt(q(1-q)) on [0.123830, q4]. These were the first exact values in the k = 4 regime,
    about 36% of [q5, q4]; A.25 now covers the whole regime by a different method.
  - R = S_3 on [q4, 0.134199]; that part is inside A.18.
  - With A.6, A.11, A.14 and A.18: R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1) on [2500/20189, 17689/20189] =
    [0.12383, 0.87617].
  - It uses only C6 with n = 3, 4 (A.5).
  - The referee should read `RQ-C/MAIN_RESULT_K4.pdf` (9 pages, created 15:05:51 UTC). Its status paragraph is
    stamped 15:20 and the tex 15:10 (remark in A.21); the mathematics is the same.
  - To rerun, for each of the six data files in `audit/rqc/k4_data/`: `a21_c13_verify.py k4_data/<slab>.json` (3–5 min
    on 8 cores), `a21d_c13_sturm.py k4_data/<slab>.json all all` (8–11 min), `a21b_c13_negative.py` (2 min) and
    `a21c_c13_semantic.py` (15 s); also `a21e_splitbox_extremes.py k4_data/*.json` (2 s). The six-slab driver for
    slabs 5 and 6 is `run_a21b.sh`.
- A.6, A.11, A.14 and A.18 (RQ-A MAIN, MAIN-2, MAIN-3, MAIN-4) have been refereed VALID by RQ-REF1, and A.25 and A.37
  (MAIN-5, MAIN-6) by RQ-REF2; see the block above. My rerun commands for them are in their sections and in earlier versions of this list (for A.18:
  `audit/rqa/a18_k3b_verify.py`, `a18d_k3b_textcheck.py`, `a18c_k3b_semantic.py`, `a18b_k3b_negative.py`).
- **A.9 — RQ-C C11 (07:59 UTC):** R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) exactly on [256/985, 1-1/sqrt2]; extremisers.
  The referee should read `RQ-C/MAIN_RESULT.pdf` and may rerun `audit/rqc/a9_c11_verify.py` (seconds) and `a9b_c11_negative.py`.
  With A.6 this gives R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 max(q,1-q)} on [256/985, 729/985].
- A.5 + A.5b — RQ-C C6, the exact finite-n theorem for all n <= 7 and all q (06:36 and 07:39 UTC).
- Minor and elementary (KNOWN or standard): A.3, A.4, A.7a–d, A.8.
- A.20 (13:22 UTC): the k = 4 three- and four-bit lemmas on [q5, q4] and the OR-region identity, which RQ-A marked
  PROVED before MAIN-5 was complete. They are Lemmas 6–8 of MAIN-5, which has been VALID since 16:53 (A.25), and their
  content is already in A.5 and A.7c. A referee checks them as part of A.25. To rerun: `audit/rqa/a20_k4_bits.py`
  (2 s) and `a20b_k4_tests.py` (44 s).
- A.22 (2026-10-22 14:29 UTC): the parts of RQ-A's MAIN-6 marked PROVED, i.e. the k = 5 three- and four-bit lemmas on
  [q6, q5]. Like A.20, they are lemmas of a theorem that is not proved yet (MAIN-6 is a CONJECTURE), and their content
  is already in A.5. To rerun: `audit/rqa/a22_k5_bits.py` (about 1 minute).
- A.24 (2026-10-22 15:42 UTC): RQ-C C14, the bit lemmas for every k at once (m <= 7 bits), with exact equality cases.
  It is a corollary of A.5/A.5b, A.7c and unimodality, and contains A.20 and A.22 and the bit lemmas of A.11, A.14 and
  A.18. Part (d) shows that the all-m form is Conjecture S itself. To rerun: `audit/rqc/a24_c14_check.py` (197 s; all
  Boolean f on <= 4 bits and all LTF classes on <= 6 bits, every k, exact) and `a24b_c14_negative.py` (1 s).
- A.26–A.29 (2026-10-22 16:14 UTC). A.29 was re-rated VALID at 16:24 after RQ-C's fix, and A.26's fix f1 to RQ-A's
  U.3 was posted and checked at 16:55. A.30 (RQ-D D1–D2) was re-rated VALID at 17:23.
  - A.26 is the uniform-in-k reduction (RQ-B C19 = RQ-A U.1–U.2): Conjecture S on (0, q_K] follows from one q-free
    inequality for compound Poisson laws, with constant C_K = C(q_K).
  - A.27 is RQ-B's C20: equal-coefficient competitors for all k when q <= q4.
  - A.28 is RQ-C's C15: maximisers have atoms at most A'(q) = sqrt(2q/s)/(1-q).
  - A.29 is RQ-C's C16: in the q-free target, a fixed theta must be below theta_max(eta) (0.9594 for q <= q4).
  - None of them gives a new exact value of R.
  - To rerun: `audit/uniform/a26_constants.py` (1 s, Arb), `a26b_semantic.py` (17 s), `a26c_u3_gap.py` and
    `a26d_fix_check.py` (the fixed decimals, 1 s).
- A.31 (2026-10-22 17:23 UTC): RQ-A U.6, a one-signed piece of the q-free target ID*. For K >= 0 with
  lambda+_m(K) >= 1/2, E|Z_K| <= g(lambda+_m(K)) (theta = m(K)). It is elementary (half a page) and gives no new exact
  value of R. To rerun: `audit/rqa/a31_u6_check.py` (33 s).
- **A.32 — RQ-D's band lemma, Theorem 10 of `RQ-D/MAIN_RESULT.pdf` (2026-10-22 18:17 UTC; PDF md5 f69703ee…):**
  E|Z_K| <= sqrt(2/e) for every probability K on [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10 or
  K([-sqrt2, -1]) >= 9/10.
  - With Corollary 11, C5 (the q -> 0 limit case R_ID = sqrt(2/e)) is equivalent to the same inequality on the far
    region. It gives no exact value of R.
  - The tools are new: a comparison lemma (pushing jumps right increases E psi(Z_K) when psi'' is nondecreasing) and
    stop-loss bounds through two-point laws.
  - To rerun (python-flint arb): `audit/rqd/a32_band_verify.py S` (0.2 s), `a32_band_verify.py B` (2 s on 8 cores),
    `a32a_unit_tests.py` (1 s) and `a32b_semantic.py 400 8` (2 min 14 s), all with `PYTHONPATH=.` in `audit/rqd/`.
- A.33 (2026-10-22 18:17 UTC): the consequence of RQ-A's CONJECTURE U.7, an elementary implication. There is nothing
  to referee until U.7 is proved; U.7 holds for n <= 7 by A.5/A.5b.
- **A.34 — RQ-D's ID* band lemma, Theorem 13 of `RQ-D/MAIN_RESULT.pdf` (2026-10-22 20:19 UTC; PDF md5 3137370e…):**
  E|Z_K| <= max(g(lambda+_0.85(K)), C_5) for every probability K on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, and
  the mirror statement. C_5 = g(2 ln(5/4)) = 0.85510045.
  - With A.26 (ID* with theta = theta(K) suffices), A.28 (support in [-1.538, 1.538] for q <= q5) and A.25 (with A.6,
    A.11, A.14, A.18 for [q5, 1/2]), Conjecture S for all q now follows from one inequality: E|Z_K| <= C_5 for every
    finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5. That
    far-region inequality was open at 20:19; A.38 (the heavy part) and A.39 (the light part) now prove it.
    Numerically its sup is about 0.8266 (RQ-C C18, RQ-D), a margin of about 0.028.
  - It gives no exact value of R(q) by itself.
  - The referee should read Sections 4 and 6 of the PDF (Lemma 7(c), the list (O1)–(O5), Lemma 12, Theorem 13,
    Corollaries 14–15 and Section 6.1).
  - To rerun (python-flint 0.9.0 arb, in `audit/rqd/`): `a34_bandstar_verify.py run 8` (4 min on 8 cores; writes
    `outputs/a34_squares_shift0.jsonl`), then `a34e_cover_check.py` (0.1 s, exact cover and area check),
    `a34c_controls.py` (1 min), `a34b_semantic.py 600 12 dirac` (and modes band, edge) and `a34d_hostile.py 40 8 0.005`.
- A.35 and A.36 (2026-10-22 20:37 UTC), both elementary, half a page each, and neither gives an exact value of R.
  - A.35 is RQ-A's U.9, |E|Z_K| - sqrt(2/pi)| <= (1/2) int |x| dK. It removes the Gaussian corner
    int |x| dK <= 0.114431 from the far-region inequality. It is KNOWN within the project (BF3 Lemmas 9.5–9.6, RQ-B
    Prop. 6(b)).
  - A.36 is RQ-C's C19(a), the first-order cost of negative mass at delta_sqrt2.
  - To rerun: `audit/rqa/a35_u9_check.py` (13 s) and `audit/rqc/a36_c19a_check.py` (89 s).
  - Addenda of 21:19. RQ-A's 4-page `MAIN_RESULT_U9.pdf` is the readable version of A.35: it is the same proof, and
    its Lemma 5 covers infinite Levy measure. The checks of its decimals and identities are in
    `audit/rqa/a35b_u9_writeup_check.py` (5 s). RQ-A's MAIN-5 text corrections c1–c2 are text only, and A.25 stays
    VALID.
- **A.38 — RQ-D's heavy far region, Theorem 16 of `RQ-D/MAIN_RESULT.pdf` (2026-10-22 22:51 UTC; PDF md5 ee067424…):**
  E|Z_K| < C_5 for every probability K on [-1.54, 1.54] with 1/2 <= K([0.85, 1.54]) < 4/5, and the mirror statement.
  - With A.34 (Corollaries 14–15) and Corollary 17, ID*(C_5) on [-1.54, 1.54] and C5 now follow from one inequality:
    E|Z_K| <= C_5 for every finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) < 1/2 and
    K([-1.54, -0.85]) < 1/2. With A.25, A.26 and A.28, that F_light inequality was the last open step for
    Conjecture S at all q. It is RQ-B's Theorem 13.1, VALID in A.39 (bound 171/200). My float searches put its sup
    near 0.8198 (at delta_sqrt(2/3)), a margin of about 0.035.
  - It gives no exact value of R(q) by itself.
  - The referee should read Section 7 of the PDF: Lemmas 18–24, Theorem 16, Corollary 17 and Section 7.4.
  - To rerun (python-flint 0.9.0, in `audit/rqd/`): `a38_heavy_verify.py heavy_2230/plus_cert 8` (70 s on 8 cores),
    `a38c_heavy_negative.py` (10 s, controls) and `a38b_heavy_semantic.py 300 1 8 random` (also `300 2 8 edge` and
    `200 3 8 kstar`; a few minutes each).
- **A.39 — RQ-B's light far region, Theorem 13.1 of `RQ-B/rq/MAIN_RESULT.pdf` (2026-10-23 01:05 UTC; PDF md5 a6901915…, 19
  pages):** with A = 77/50 and theta = 17/20, E|Z_K| <= 171/200 = 0.855 < C_5 for every finitely supported probability
  K on [-A, A] with K([theta, A]) < 1/2 and K([-A, -theta]) < 1/2.
  - With A.38 (Corollary 17) and A.34 (Corollary 14), ID*(C_5) holds on [-1.54, 1.54], and C5 holds.
  - **With it the chain for Conjecture S is complete at audit level:** R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1)
    for all q in (0, 1).
    - On (0, q5]: A.26 (ID*(C) gives R = M wherever C(q) >= C, and the minimum of C(q) over (0, q5] is C_5) and A.28
      (the support lies in [-1.538, 1.538]).
    - On [q5, 1/2]: A.25 with A.6, A.11, A.14 and A.18. For q > 1/2: the mirror.
    - The extremisers are characterised only on [q6, 1-q6] (A.37 and earlier).
  - Refereed: A.6, A.11, A.14 and A.18 (RQ-REF1), and A.25 and A.37 (RQ-REF2, 01:05). RQ-REF3 (FINAL, 03:09)
    refereed the rest of the chain, all VALID: U.3 with the U.1 inputs A.7a and A.10a, A.28, RQ-D's MAIN_RESULT
    Sections 2–7 (A.30, the lemmas of A.32 that the chain uses, A.34, A.38), and A.39 including Lemma S5.
  - The referee should read §13 of the PDF (Lemmas S1–S5, C, D, E, Theorem 13.1 and §13.6), AUDIT_REQUEST §7, and
    remark r1 of A.39, which lists the conventions a certificate check needs: cap orders, row order, tangent points
    and the safety term.
  - To rerun (python-flint 0.9.0, in `audit/rqb/`): `./a39_final_runs.sh 8`. It runs the three verifier cases (about
    7 min on 8 cores), the semantic tests (about 4 min) and the controls (28 s). Also run `a39n_s5_hostile.py 60000 11`
    (20 s). The conventions are identified by `a39n_identify.py nsplit_0005/nsplit_D14.jsonl.xz 120 1` and
    `a39_identify.py light_2305/chord_D14.jsonl.xz 2` (and the same with `light_vl025_D18.jsonl.xz`). The data and
    the filed texts are in `audit/rqb/nsplit_0005/` and `audit/rqb/light_2305/`.
- **A.40 — the composed all-q chain (2026-10-23 01:29 UTC): VALID at audit level, NEW.** No solver has filed the composed
  statement, so this entry checks that the audited links fit together.
  - Conjecture S holds for every q in (0, 1): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), attained at OR_k. Also
    lim_{q->0} R(q) = R_ID = sqrt(2/e).
  - The seams that were checked:
    - the ranges of A.25, A.18, A.14, A.11 and A.6 meet end to end on [q5, 1/2];
    - the cases of A.34, A.38 and A.39 cover every probability K on [-1.54, 1.54], since V+ + V- <= 1, and they use
      the same closed sets and theta = 0.85;
    - A = 1.54 > A'(q5) = 1.538044, as A.28(f) needs;
    - C(q) >= C_5 on (0, q5], as A.26 needs;
    - theta = 0.85 is below A.29's theta_max = 1.0063.
  - Refereed VALID by RQ-REF3 (FINAL, 2026-10-23 03:09 UTC): the composition and the links A.26 (a)–(d), A.28,
    A.30, A.32 (the lemmas the chain uses), A.34, A.38 and A.39 (the block above). RQ-REF3 did not use RQ-C's chain
    check.
  - To rerun: `audit/chain/a40_chain_seams.py` (0.05 s).
- RQ-B structural results (08:11 UTC): A.10a–e (Poissonization bound, the q -> 0 limit, the conditional exact
  values at q_k^*, two regimes of C5, the adaptive ladder). None of them gives an unconditional exact value of R(q).
  A.15 (10:44 UTC) adds the reduction of Remark 3.3: for q <= 0.3429, C0 at q follows from APC(s(q)). It is
  conditional and elementary; the referee may rerun `audit/rqb/a15_remark33_pade.py` (16 s).
  A.16 (11:14 UTC) reduces the k = 3 gap [q4, 25/169] = [0.13397, 0.14793] to large coefficients: there R(q) = T(q)
  follows from E|L| <= T(q) for every unit alpha with max_i |alpha_i| >= 120/409 = 0.2934. The proof is a zero-bias
  bound for a <= 0.0749 and, for 0.0749 <= a <= 0.2934, 4229 exact moment certificates with induction on n. It is
  conditional and gives no new exact range. The referee should read `RQ-B/rq/MAIN_RESULT.pdf` (PDF of 11:18, which
  differs from the 10:49 version I audited only in the negative-test sentence; Lemma 10.1 and Corollary 10.2 there are
  Lemma 9 and Corollary 9.1 of the md) and may rerun
  `audit/rqb/a16_lemmaS_verify.py` (12 s), `a16d_reproduce_lhs.py`, `a16e_sturm.py`, `a16b_negative.py` and
  `a16c_semantic.py` (the certificate file is in `audit/rqb/c15_data/`).
  A.17 (11:25 UTC) is RQ-B's transfer lemma C16: R(q)^2 <= R(q')^2 q/(m q'(1-q')^{m-1}) for q = 1 - (1-q')^m.
  It is elementary, gives no new exact value from the team's results, and the referee may rerun
  `audit/rqb/a17_transfer_check.py` (10 s).
- **A.12 — RQ-C C12 (VALID since 10:04 UTC):** R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) exactly on [625/2834, 1-1/sqrt2],
  with extremisers. Its range lies inside A.11, so it is a second, independent proof by a different method, not a
  new range. The referee should read `RQ-C/MAIN_RESULT.pdf` (PDF of 09:42) and may rerun
  `audit/rqc/a12_c12_verify.py`, `a12d_c12_sturm.py`, `a12b_c12_negative.py` and `a12c_c12_semantic.py`.
- **A.13a–b — RQ-B C11–C12 (VALID since 10:44 UTC):** maximisers of the infinitely divisible problem exist and have
  P(Z = 0) = 0, u = P(Z > 0) in [1/3, 2/3] and support in [-4/(3R), 4/(3R)]; and R_ID <= 0.9161, hence
  sqrt(2/e) <= lim_{q->0} R(q) <= 0.9161 and R(q) <= 0.9161 sqrt(q/((1-q) ln(1/(1-q)))) < 1 for q < 0.28883. The
  referee should read `RQ-B/rq/MAIN_RESULT.pdf` (PDF of 10:38; §8 of the md is Section 9 of the PDF) and may rerun
  `audit/rqb/a13_rqb_thm8_verify.py` and `a13b_remark33.py`.
- **A.23 — RQ-B C18 (2026-10-22 15:00 UTC):** R_ID <= 867/1000. Hence sqrt(2/e) = 0.85776 <= lim_{q->0} R(q) <= 0.867,
  and R(q) <= 0.867 sqrt(q/((1-q) ln(1/(1-q)))) for all q, which is < 1 for q < 0.42078 and within 2.12% of M(q) on
  (0, 1/4]. This is not an exact value of R(q); it is the team's best bound for small q and supersedes the constant of
  A.13b. It needs A.13a (the localisation) and A.10a–b (Theorems 3 and 4). The referee should read
  `RQ-B/rq/MAIN_RESULT.pdf` (PDF of 13:45; Theorem 9.6 in Section 9 is Theorem 8.5 of the md) and may rerun
  `audit/rqb/a23_c18_verify.py` (87 s on 8 cores; it reads `audit/rqb/c18_data/`), `a23b_c18_negative.py` (28 s) and
  `a23c_c18_semantic.py` (24 s).

Correction (06:52): A.3–A.5 and the N.1 note were first stamped "06:45", which was ahead of the
real time. They were written at about 06:36 UTC and committed at 06:37:02 UTC (commit 79c4fb7).
The stamps are now corrected. From now on every stamp is taken from `date -u` when it is written.

Correction (13:23): A.20 was first stamped "13:24", ahead of the real time; it was written by 13:22 and
committed at 13:22:32 UTC (commit 6de1df1). Its stamps are now 13:22.

## Store access log

- 2026-10-22 05:40: `/cursor/stores/bot/rq/` is readable and writable from this VM. It contains
  only `COMMON.md` and `LOCKED_NOTE.md`; no `RQ-A/`, `RQ-B/`, `RQ-C/` folders yet.
- 2026-10-22 05:55: `RQ-C/` appeared (SOTA, CLAIMS C1–C5, FINDINGS); no `RQ-A/`, `RQ-B/` yet. A recurring 45-minute audit timer is set.
- 2026-10-22 06:00: audited RQ-C C1 (A.1) and C4(a) (A.2).
- 2026-10-22 06:14: `RQ-A/` present (CLAIMS C0, K, N.1–N.2 NUMERICAL). RQ-C added C6 (n <= 6).
- 2026-10-22 06:33: `RQ-B/` present (claims in `RQ-B/rq/CLAIMS.md`: C1–C4 PROVED, elementary).
  RQ-A now claims **MAIN PROVED** (R(q) = 2 sqrt(q(1-q)) on [1-1/sqrt2, 1/sqrt2]); its
  `MAIN_RESULT.md` is referenced but not yet in the store; certificate data is in
  `RQ-A/outputs/cover/` and `RQ-A/outputs/quartic_cover.json`. RQ-C extended C6 to n <= 7.
- 2026-10-22 06:36: recorded A.3, A.4, A.5 (first mis-stamped 06:45; see the correction above). Next:
  A.6 = RQ-A MAIN (top priority), then RQ-B C1–C4 and the n = 7 part of RQ-C C6.
- 2026-10-22 06:48: RQ-A posted `MAIN_RESULT.md/.tex/.pdf` and `AUDIT_REQUEST.md` (06:47). The md5s of
  all nine certificate files equal those of my earlier snapshot (`audit/rqa/rqa_data/MD5SUMS`).
- 2026-10-22 06:52: recorded A.6 (RQ-A MAIN: VALID, NEW).
- 2026-10-22 06:59: recorded A.7 (RQ-B C1–C4).
- 2026-10-22 07:03: RQ-C CLAIMS updated at 06:49: new C7 (PROVED), C8 and C9 (NUMERICAL), C6 now covers n = 7.
  Recorded A.8 (C7).
- 2026-10-22 07:09: snapshots of all three CLAIMS files saved in `audit/snapshots/`. RQ-B re-mirrored (07:08)
  with no change in claims.
- 2026-10-22 07:21: cycle check. No content change in any CLAIMS file since 07:09, and the RQ-A certificate md5s
  are unchanged. RQ-C re-mirrored its numerics; its killer logs show best = Stone value to 1e-13.
- 2026-10-22 07:39: recorded A.5b (RQ-C C6 for n = 7: VALID). Every claim currently tagged PROVED by
  RQ-A, RQ-B and RQ-C has now been audited.
- 2026-10-22 07:46: cycle check; new snapshots `audit/snapshots/*_0747.md`. The RQ-A certificate md5s are unchanged.
  New claims:
  - RQ-A: **MAIN-2 PROVED** (R(q) = 2 sqrt2 (1-q) tau on [1/5, 1-1/sqrt2], two-coordinate split; scripts
    `verify_k2.py`). The write-up `MAIN_RESULT_K2` is "in progress" and RQ-A marks it "not yet audited".
  - RQ-C: **C11 PROVED** with `MAIN_RESULT.md/.tex/.pdf` and an audit request (range [256/985, 1-1/sqrt2]).
  - RQ-B: new `rq/MAIN_RESULT.md/.tex/.pdf` and claims C6 (Poissonization bound), C7 (q -> 0 limit),
    C8 (conditional exact values), C9 (two regimes of C5), C10 (adaptive ladder), F4 (exact counterexample).
- 2026-10-22 07:59: recorded A.9 (RQ-C C11: VALID, NEW). Next: A.10 = RQ-B C6–C10, then RQ-A MAIN-2 (A.11)
  once its write-up exists.
- 2026-10-22 08:11: recorded A.10a–f (RQ-B C6–C10 VALID, F4 confirmed). RQ-A MAIN-2 is still without a write-up
  (no `MAIN_RESULT_K2*` in the store; the last RQ-A mirror was at 07:28).
- 2026-10-22 08:19–08:34 (during the A.11 work): RQ-A posted the MAIN-2 certificate data (my copy
  `audit/rqa/k2_data/`, 08:19) and then, at 08:27, `MAIN_RESULT_K2.md/.tex/.pdf` with MAIN-2 extended from [1/5, q0]
  to [q3, q0] (new b*-files, `one_B.json`, m-split boxes). My copy of that release is `audit/rqa/k2_data_v2/` (08:34).
  The s*-files and `one_A.json` of the two releases are byte-identical. The A.6 text fix f1 now appears in CLAIMS N.1.
- 2026-10-22 08:49: cycle check; new snapshots `audit/snapshots/*_0849.md` (RQ-B claims are in `RQ-B/rq/`).
  - RQ-A (re-mirrored 08:48): `AUDIT_REQUEST.md` now asks for A.11 = MAIN-2 on [q3, q0] with Corollary 2.
    `outputs/k2_MD5SUMS.txt` is unchanged (md5 c6184a11…), and so are all 117 manifest files.
  - RQ-C (08:45): new **C12** PROVED (C11 extended to [625/2834, q0]; sextic two-extremiser comparison), with an
    audit request. This becomes A.12.
  - RQ-B (rq/, 08:37): new **C11** PROVED (structure of maximisers of the ID problem) and **C12** PROVED (R_ID <= 0.9161,
    exact sextic majorant). These become A.13.
- 2026-10-22 08:52: recorded A.11 (RQ-A MAIN-2: VALID, NEW). Next: A.12 (RQ-C C12), then A.13 (RQ-B C11–C12).
- 2026-10-22 09:24: cycle check. The three CLAIMS files are byte-identical to the 08:49 snapshots. RQ-B re-mirrored
  at 09:06 (`rq/CLAIMS.md` unchanged; `rq/MAIN_RESULT.*` re-written at 09:06, my copy for A.13 is
  `audit/rqb/c11c12_text/`). RQ-C's MAIN_RESULT.md/.tex and the ext2 data have the md5s of my copies
  (`audit/rqc/c12_text/`, `audit/rqc/c12_data/`). The A.11 attack runs finished (max ratio 1 + 4e-15, at the known
  extremisers).
- 2026-10-22 09:28: recorded A.12 (RQ-C C12: VALID WITH FIXES, one text fix). Next: A.13 (RQ-B C11–C12).
- 2026-10-22 09:46: `mirror.sh` now copies by content (a local md5 manifest), because the store does not keep
  modification times, so rsync had re-copied all files (12 minutes). A run now takes seconds.
- 2026-10-22 09:53: recorded A.13a–b (RQ-B C11–C12: both VALID WITH FIXES, text fixes f2 and f1). RQ-B re-mirrored
  at 09:28 with unchanged md5s. The missing step of Remark 3.3 (my A.10 text note) is now proved (see A.13).
  New since 09:24:
  - RQ-A CLAIMS (09:47): **MAIN-3 PROVED**, with an audit request; it includes a three-bit lemma for k = 3 on
    [25/169, q3]. This becomes A.14 (top priority).
  - RQ-C CLAIMS changed at 09:49.
- 2026-10-22 10:04: A.12 re-rated VALID (RQ-C posted fix f1; details in A.12).
- 2026-10-22 10:11: cycle check; new snapshots `audit/snapshots/*_1010.md`.
  - RQ-C: CLAIMS C12 records fix f1 (the only change since 08:49). MAIN_RESULT.md/.tex/.pdf have the md5s of my
    copy `audit/rqc/c12_text_v2/`.
  - RQ-A: CLAIMS adds MAIN-3 (= A.14) and records the two cosmetic A.11 points as applied. `MAIN_RESULT_K2.md/.tex`
    were re-posted with text-only changes (Lemma 20 states the y = 0 convention, Definition 23 says "m_c in (0, 1],
    phi(m_c) <= p* < 0", one more negative test, the status line); `outputs/k2_MD5SUMS.txt` is unchanged
    (c6184a11…), so A.11 stands. `MAIN_RESULT_K3.*` and `outputs/k3_MD5SUMS.txt` (613f681e…) match my copies
    `audit/rqa/k3_text/` and `audit/rqa/k3_data/`.
  - RQ-B: `rq/` unchanged since 09:06 (md5s equal to `audit/rqb/c11c12_text/`). The A.13 fixes f1 and f2 are not
    posted yet.
- 2026-10-22 10:36: store check (files read at 10:35).
  - RQ-B (re-mirrored 10:33): `rq/CLAIMS.md` adds C13 and C14 (NUMERICAL), F6 (FAILED) and a team-status paragraph
    saying that the reduction of Remark 3.3 (APC(s(q)) implies C0 for q <= 0.3429) is "now fully proved";
    `rq/MAIN_RESULT.md/.tex` add that proof. The A.13 fixes were not in this version: "7.4%" was still in Theorem 8,
    and "All tight at K* = delta_sqrt2" was still in CLAIMS C11.
  - RQ-A: unchanged since 09:49; `k2_MD5SUMS.txt` (c6184a11…) and `k3_MD5SUMS.txt` (613f681e…) are unchanged.
  - RQ-C (re-mirrored 10:31): CLAIMS, AUDIT_REQUEST and MAIN_RESULT.md/.tex are byte-identical to my copies; only
    numerics scripts and work files changed.
- 2026-10-22 10:37: recorded A.14 (RQ-A MAIN-3: VALID, NEW). Next: A.15 = the RQ-B Remark 3.3 reduction.
- 2026-10-22 10:44: RQ-B re-mirrored again at 10:38 (PDF 10:38:09 UTC), with the A.13 fixes f1 and f2 in
  MAIN_RESULT.md/.tex/.pdf and in CLAIMS C11–C12. My snapshot and copy were taken at about 10:38:40, after this
  re-mirror, so both are of the 10:38 version: `audit/snapshots/RQ-B_CLAIMS_1038.md` (first committed as `_1036`,
  now renamed) and `audit/rqb/r33_text/`. The 10:36 entry describes the 10:33 version I diffed at 10:35; as first
  published, it named this snapshot and said the fixes were missing. Recorded A.13a–b re-rated VALID and A.15
  (RQ-B Remark 3.3) VALID.
- 2026-10-22 10:48–10:50: literature re-check (web search) for exact values of R(q), or of the biased L1–L2
  Khintchine constant, published since 2024. Ivanisvili–Stone (arXiv:2407.04835) state the equal-coefficient
  supremum (their (1.10), proved in their reference [12]) and only *assume* that R(p) equals it. arXiv:2608.29703
  (a sharp small-coefficient Khintchine inequality and the sharp pi/2 theorem) and arXiv:2610.07526 (stability of
  Szarek's inequality with best constant) concern unbiased Rademacher sums. A search-engine summary claimed that
  2407.04835 gives the exact R(p); its text does not. No rating changes: A.6, A.9, A.11, A.12 and A.14 stay NEW.
- 2026-10-22 10:50: cycle check.
  - RQ-B re-mirrored at 10:49–10:50 (PDF pdfTeX 10:49:20 UTC). `rq/CLAIMS.md` adds **C15 (PROVED, new;
    computer-assisted with exact rational arithmetic): "Lemma S", small coefficients in the k = 3 gap**, which is
    `rq/MAIN_RESULT.md` §9 (Lemma 9 and Corollary 9.1), with an audit request. Data: `numerics/k3_smalla_certs.json`
    (8b93f594…). This becomes A.16.
  - Copies: `audit/rqb/c15_text/` and `audit/rqb/c15_data/`, with MD5SUMS. RQ-B's generator, checker and
    negative-test scripts are copied for the record only; I have not read them. Snapshot:
    `audit/snapshots/RQ-B_CLAIMS_1050.md`.
  - RQ-B's `rq/AUDIT_REQUEST.md` says "Updated: Oct 22 2026, ~11:05 UTC", but its mtime is 10:49:56 and I read it at
    about 10:50. The stamp is ahead of the real time.
  - RQ-A and RQ-C: no change. Both CLAIMS files equal the `_1010` snapshots, `k2_MD5SUMS.txt` is c6184a11… and
    `k3_MD5SUMS.txt` is 613f681e….
- 2026-10-22 11:12: store check before publishing A.16. RQ-B's `rq/*` files and `numerics/k3_smalla_*` outputs and
  data are byte-identical to my 10:50 copies. RQ-A is unchanged (last mirror 09:49). RQ-C re-mirrored at 10:37–10:39;
  its CLAIMS is unchanged, and MAIN_RESULT.md/.tex/.pdf and AUDIT_REQUEST.md are byte-identical to
  `audit/rqc/c12_text_v2/`. LOCKED_NOTE is unchanged (e439db3b…).
- 2026-10-22 11:14: recorded A.16 (RQ-B C15: VALID, NEW; a reduction, not a new exact range).
- 2026-10-22 11:22: cycle check. The timer fired at 11:15, while I was finishing A.16.
  - RQ-B re-mirrored at 11:18–11:20 (PDF pdfTeX 11:18:03 UTC).
    - `rq/CLAIMS.md` records A.13, A.14 and A.16. It adds **C16 (PROVED, elementary): a transfer lemma**, which
      becomes A.17, and F7 and F8 (FAILED, numerical; not audited as proofs).
    - `rq/MAIN_RESULT.md/.tex/.pdf` change only in the negative-test sentence of §9, which now states my delta remark
      from A.16. The certificate data and the `k3_smalla_*` outputs are unchanged (8b93f594…).
    - `STATUS.md`: the extension of the cover to a <= 0.40 did not converge and is not pursued. The file is stamped
      "~11:25 UTC" but its mtime is 11:18:19, so the stamp is again ahead of the real time.
    - Copies: `audit/rqb/c16_text/` (with MD5SUMS) and the snapshot `audit/snapshots/RQ-B_CLAIMS_1125.md`. The new
      PDF contains all 153 numbers and all 407 words of 6 or more letters of its tex.
  - RQ-A: unchanged (CLAIMS equal to `_1010`, last mirror 09:49). RQ-C: unchanged since the 11:12 check.
- 2026-10-22 11:25: recorded A.17 (RQ-B C16: VALID). A.16 stands for RQ-B's 11:18 text, since only the
  negative-test sentence changed.
- 2026-10-22 11:27: cycle check. The timer deliveries of 06:00–11:15 arrived together at 11:27; each of those
  cycles was done at the time, the last at 11:22. Nothing in RQ-A/, RQ-B/ or RQ-C/ was newer than 11:21:
  - the three CLAIMS files equal the snapshots `RQ-A_1010`, `RQ-B_1125` and `RQ-C_1010`;
  - RQ-B's `rq/` texts equal `audit/rqb/c16_text/`, and RQ-C's texts equal `audit/rqc/c12_text_v2/`;
  - the certificate manifests are unchanged (RQ-A k2 c6184a11…, k3 613f681e…; RQ-B k3_smalla 8b93f594…), and so
    is LOCKED_NOTE (e439db3b…).

  RQ-C's NOTES_FOR_TEAM (10:05) says that RQ-C now works on the k = 4 side (R(q) = S_4(q) = 4 tau (1-q)^3 on
  [x, q4] with x about 0.115–0.12, and q4 itself), and that RQ-A pushes k = 3 down towards q4 with ten-moment
  certificates.
- 2026-10-22 11:48: own checks while no claim was pending, and a new RQ-A data drop.
  - **H.1, hostile pre-check of the k = 4 side** (no claim yet; floating point, evidence only).
    - Target: unit alpha with E|L| > M(q) = max_k 2 sqrt(kq) (1-q)^(k-1/2), at 13 values of q in
      [q5, q4] = [0.105573, 0.133975].
    - Families: exact enumeration over {0,1}^n for n = 4..16 (duality ascent, 40 starts per n); one to five large
      coefficients plus an equal bulk (binomial, m up to 400, and Gaussian), all sign patterns; two equal blocks
      (c x k1, d x k2) with k1 <= 12 and k2 <= 60.
    - Result: the best ratio is 1 up to rounding (at most 1 + 4e-15) in every family. It is attained only by
      (1,1,1,1)/2, by (1,1,1)/sqrt3 at q4 and by (1,1,1,1,1)/sqrt5 at q5. No counterexample to C0 on the k = 4
      side.
    - Files: `audit/rqc/h1_k4_side_killer.py`, with outputs `audit/rqc/outputs/h1_k4_side_killer_P1.txt` and
      `_P23.txt`.
  - **Ten-moment toolkit** for the certificates both solvers are building: `audit/common/moments10.py`.
    - It gives kappa_j(chi) and the moment polynomials E M^m up to order 12, each derived two independent ways:
      the Bernoulli cumulant recursion against the moment–cumulant recursion, and the power-series exponential
      against set partitions without singletons.
    - It also checks 351 exact moment identities against full enumeration (ALL PASS,
      `audit/common/outputs/moments10_selftest.txt`).
  - **RQ-A data drop, 11:28–11:33** (after my 11:27 check).
    - Contents: `outputs/k3b/` (39 files), `k3b_manifest.json` (127ef15a…), `k3b_MD5SUMS.txt` (2074adcc…; all 37
      sums match my copy), `k3b_stats.txt`, `verify_k3b_ABCDEFG.txt` (ALL PASS), `break_tests_k3b.txt`, and the
      new scripts `cover4/5.py`, `cert4/5.py`, `fourbit.py`, `tenmom.py`, `scan10.py`, `cover_lp10.py` and
      `verify_k3b.py`.
    - The cover is for u in [12/5, 127123/50000] (q from 25/169 down to just below q4), A_S = 7/20. It has 288
      one-coordinate cells of degree <= 10 and 1421 two-coordinate boxes (vertex certificates, 13 near-circle
      boxes, and 302 m-split boxes with 301 four-coordinate near-sphere pieces around (1,1,1,1)/2). It also has a
      four-bit lemma: sum_i Delta_i(f)^2 <= 12(1-q)^4 for all f on 4 bits on [q4, 25/169].
    - This is evidently the closure of the k = 3 gap [q4, 25/169], but CLAIMS.md (53122ed5…, still `_1010`),
      STATUS.md and the MAIN_RESULT texts are unchanged, so nothing is claimed yet.
    - Pre-audit started on my snapshot `audit/rqa/k3b_data/`. Two points are already noted:
      - U_HI = 127123/50000 exceeds u4 = sqrt(3+2 sqrt3) by about 2.4e-7. For q < q4, (1,1,1,1)/2 gives E|L| = S_4 > T,
        so no certificate may assert E|L| <= T there, and every use of the four-bit lemma must be restricted to
        u <= u4.
      - In `break_tests_k3b.txt`, the line "lpv: recomputed cap mbar >= a2/b on the box (sanity, all must hold)"
        reports "rejected 40/40". That is either a labelling slip or 40 failed sanity checks; RQ-A must say which.
- 2026-10-22 12:24: cycle check (timer), and the pre-audit of the k3b data is finished.
  - **RQ-A filed MAIN-4 at 11:55** (Theorem 4 of `MAIN_RESULT_K3B.*`: R = T3 on [q4, 25/169], hence with A.14 on
    [q4, q3]; audit requested). Files: CLAIMS.md df4782a9… (copy `audit/snapshots/RQ-A_CLAIMS_1155.md`; the
    only other change is the A.14 status line), AUDIT_REQUEST.md 06384e72…, MAIN_RESULT_K3B.md 2c755f9e… (copies of
    md/tex/pdf in `audit/rqa/texts/`). The audit is A.18 below.
  - The data are the 11:28–11:33 drop, unchanged: `k3b_manifest.json` (127ef15a…) and `k3b_MD5SUMS.txt`
    (2074adcc…) equal my snapshot, and all 37 sums check in the store. Only `break_tests_k3b.txt` was re-issued.
    Its sanity line now reads "recomputed cap mbar >= min(1, a2/b) on the box (sanity check) holds 40/40" and "ALL
    SANITY CHECKS HOLD". So the 11:48 point was a labelling slip, as `break_tests_k3b.py` (lines 88–98) also shows:
    it counted boxes where the cap condition holds. The other 11:48 point (U_HI > u4) is a statement-scope question
    and is treated in A.18.
  - **Pre-audit results** (my own verifier `audit/rqa/a18_k3b_verify.py`, no RQ-A code; exact rationals, Sturm
    counts).
    - Parts M, A–G pass (outputs `audit/rqa/outputs/a18_k3b_verify_{MABG,CEF,D}.txt`).
    - It checks the md5s; the tilings (288 cells, 941 + 480 boxes, no overlaps, exact volume); kappa_3..10 monotone
      in u; the three- and four-bit lemmas; and 288/288 ten-moment cells with my own moment polynomials
      (`audit/common/moments10.py`).
    - It also checks 13/13 near-circle boxes and 302/302 m-split boxes (123 A3 and 301 A4 near-sphere pieces), and
      2845/2845 vertex-certificate sets (16,544 vertices). The cone enclosure of the patch is proved by exact
      separated minima, never more than one sub-box.
  - **Negative and calibrated tests** (`audit/rqa/a18b_k3b_negative.py`, outputs `a18b_k3b_negative.txt` and
    `_3456.txt`): every corruption is rejected.
    - Cells: c0 - 1/20 rejected 288/288; target T - 2 slack rejected 288/288 while T - slack/2 is accepted
      288/288; cap set to 1 rejected 288/288. The slack is at least 2.49e-5 (median 6.1e-3).
    - Semantic test of the ten-moment bound: 3982 exact (u, beta) triples, minimum gap 2.8e-8 >= 0.
    - Vertex sets (72 sampled): c0 - 1/20, one vertex moved by 1e-6, patch shrink by 10% are each rejected
      72/72, and target - 1% is rejected 23/72.
    - m-split (25 sampled): widened A4 pieces, widened A3 pieces, a removed minus piece, and SG p* = phi(m1) -
      1e-12 are each rejected 25/25.
    - Four-bit lemma: on [q4 - 1e-6, 25/169] it fails for 2 f (+-OR_4); with 12 - 1e-6 in place of 12 it fails
      for 10 f. Both corrupted tilings are rejected.
  - RQ-B: unchanged. `rq/CLAIMS.md` = `_1125` snapshot; AUDIT_REQUEST, MAIN_RESULT.md, STATUS.md and
    NOTE_FOR_RQA_SMALL_A.md equal my copies; `numerics/k3_smalla_certs.json` is 8b93f594…. New, not claims: a
    `mirror.sh`, text extractions of BF3 / Ivanisvili–Stone / ILvHV in `notes/`, and a scaffold README.
  - RQ-C: CLAIMS.md (6d0c1927…) differs from `_1010` only in C12's status line, which now says VALID (A.12,
    10:04). AUDIT_REQUEST and MAIN_RESULT.md equal my `c12_text_v2` copies. NOTES_FOR_TEAM (10:05) and FINDINGS
    have the same content as before. RQ-A's NOTES_FOR_TEAM (12:00) says RQ-A now attacks the k = 4 regime
    from q5 upwards and RQ-C from q4 downwards.
  - Unchanged: LOCKED_NOTE (e439db3b…), COMMON.md, `k2_MD5SUMS.txt` (c6184a11…), `k3_MD5SUMS.txt` (613f681e…).
- 2026-10-22 12:45: recorded A.18 (RQ-A MAIN-4: VALID, NEW). Before publishing I re-checked the store: the
  MAIN_RESULT_K3B md/tex/pdf, AUDIT_REQUEST.md (06384e72…), `k3b_manifest.json` (127ef15a…) and `k3b_MD5SUMS.txt`
  (2074adcc…) still equal the copies I audited. New since 12:24 and not yet read: RQ-B `rq/*` re-issued at 12:36
  (CLAIMS.md now 4dc2340f…) and RQ-A NOTES_FOR_TEAM.md (12:20). They are the next cycle item.
- 2026-10-22 13:03: cycle check (the 12:45 timer arrived while I was finishing A.18), and A.19 recorded.
  - RQ-B: CLAIMS.md (4dc2340f…, copy `audit/snapshots/RQ-B_CLAIMS_1236.md`) adds **C17 (PROVED, audit requested):
    R_ID <= 0.88** (Theorem 8.5), and one sentence on cell-wise majorants under C5. AUDIT_REQUEST.md has a new §3.
    MAIN_RESULT md/tex/pdf were re-issued (PDF 12:36), with only Theorem 8.5 and its remarks added. The audit is A.19:
    VALID WITH FIXES (text only), NEW. It enters the referee list once the three text fixes are posted.
    `k3_smalla_certs.json` is still 8b93f594….
  - RQ-A: NOTES_FOR_TEAM (12:00 content) says MAIN-4 does not use RQ-B's Lemma S (as A.18 found), and that RQ-A now
    works on k = 4 from q5 = 1 - 2/sqrt5 upwards, with RQ-C from q4 downwards.
  - RQ-A, 12:57 drop: CLAIMS.md (7bfacf8e…) adds **MAIN-5 CONDITIONAL**: R = T4 = 4 (1-q)^3 tau on
    [q5, q4] = [0.105573, 0.133975]. The cover is still running, so it is not claimed or filed for audit, and
    MAIN_RESULT_K4.tex/.pdf is a draft. MAIN-5 lists two parts as already PROVED: the k = 4 three- and four-bit
    lemmas on [q5, q4], and the OR-region identity. They are A.20, next. The diff against `_1155` touches only the
    title line and MAIN-5. STATUS.md (13:02) has the same content.
  - RQ-C: CLAIMS.md is still 6d0c1927…; nothing new since 12:10.
- 2026-10-22 13:22: recorded A.20 (the PROVED parts of RQ-A's MAIN-5: VALID, KNOWN within the project).
  - RQ-A, 13:17 drop: MAIN_RESULT_K4.tex/.pdf (d1815206…, copy `audit/rqa/k4_text_1319/`) and STATUS.md (13:16, copy
    `audit/snapshots/RQ-A_STATUS_1319.md`). The diff against the 12:57 text adds a Lemma "facet minima" (an exact
    test of the cone condition (P4) without subdivision) and edits the computer section to match. Lemmas lem:or,
    lem:three and lem:four are unchanged, so A.20 applies to both versions. STATUS says the k = 4 cover restarted at
    13:12 with the exact cone test; there are no failed boxes so far. CLAIMS.md is still 7bfacf8e… and MAIN-5 is still
    CONDITIONAL.
  - RQ-B: `rq/CLAIMS.md` is still 4dc2340f…. The fixes f1–f3 of A.19 are not posted yet.
  - RQ-C, 13:20 re-mirror: CLAIMS.md (bf20c3a4…, copy `audit/snapshots/RQ-C_CLAIMS_1320.md`) has two changes since 10:10.
    C12's status line says VALID (A.12), and a new **C13 is "PROVED (computer-assisted) … pending the independent
    verifier run; NOT YET AUDITED"**: R(q) = max(S_3, S_4) for u in [127/50, 64/25], i.e. q in
    [625/4721, 2500/18629] = [0.132387, 0.134199]. This is R = S_4 on [0.132387, q4], the first piece of the k = 4
    regime, and R = S_3 on [q4, 0.134199], which is inside A.18. The text is a new draft `MAIN_RESULT_K4.tex` (copy
    `audit/rqc/k4_text_1320/`). The data the claim cites is not all in the store. Present: `numerics/out/k4/` with
    `s11_254_256.json.phase2.jsonl` and `.log` (12:09). Missing: `s11_254_256.json` and the verifier output
    `verify_s11_254_256.txt`. AUDIT_REQUEST.md is unchanged. C13 is A.21; I start with the text, and the data check
    waits for the missing files.
  - LOCKED_NOTE is unchanged (e439db3b…).
- 2026-10-22 14:29: recorded A.21 (RQ-C C13: VALID WITH FIXES, NEW) and A.22 (the PROVED parts of RQ-A's MAIN-6: VALID,
  KNOWN within the project). What arrived since 13:22:
  - RQ-C, 13:28: `numerics/out/k4/s11_254_256.json` (31d28bce…) and the verifier output arrived. So the 13:22 note
    "missing" was only a matter of time; the files were copied to the store after my check.
  - RQ-C NOTES_FOR_TEAM.md was written at 13:33 with the stamp "Last update: 13:45 UTC", and again at 14:06 with the
    stamp "14:10 UTC". Both stamps are ahead of the file times. This changes nothing in the mathematics. I only ask
    RQ-C to take stamps from the clock.
  - RQ-C, 13:59–14:02 re-mirror (MIRROR_STAMP 14:02:01Z, commit c34be4c): C13 now covers four slabs,
    u in [127/50, 131/50] (q in [0.127155, 0.134199]), and is filed for audit. Files: CLAIMS.md (e3318c23…),
    MAIN_RESULT_K4.tex (237f5806…), PDF (f0b4cffb…, 8 pages, built 13:49), AUDIT_REQUEST.md (afdb0f63…),
    k4_runs_table.tex (6a17a22d…). The four data files have the md5s stated in AUDIT_REQUEST. Copies:
    `audit/rqc/k4_text_1400/` and `audit/rqc/k4_data/`. At 2026-10-22 14:29 the store still holds exactly these files.
  - RQ-C NOTES (14:06, 361ea2ae…, copy `audit/snapshots/RQ-C_NOTES_1411.md`): RQ-C runs more 0.02-slabs up to
    u = 71/25 = 2.84 (expected by about 17:30) and suggests to RQ-A a job order that would close [q5, q4] with
    MAIN-5. Nothing in it is claimed.
  - RQ-A: CLAIMS.md is now 2a36088d… (copy `audit/snapshots/RQ-A_CLAIMS_1411.md`). The MAIN-4 status line cites A.18,
    and a new **MAIN-6 (k = 5 regime, R = T5 on [q6, q5]) is a CONJECTURE whose cover is running; its PROVED parts are
    the k = 5 bit lemmas**. They are A.22. STATUS.md (13:58, 0c5c2248…) reports a latent defect, now fixed. The range
    enclosure of the cumulant polynomials bisected until the derivative had no root, so it never terminated at the
    critical point of G_9 at u = 2.926. `outputs/k5/logs/p_1.crash1.log` shows that crash ("poly_range: no
    isolation", slab u in [2.92, 2.93]). Theorems 1–4 (A.6, A.11, A.14, A.18) ran to completion, so a
    non-terminating enclosure cannot have passed anything there. My A.21 verifier is not affected: it encloses the
    cumulants kappa_3..kappa_10 by their endpoint values and proves by Sturm sequences that each is monotone on
    [127/50, 71/25]. I have widened that range to always contain the file's region, so later slabs stay covered.
  - RQ-B: `rq/CLAIMS.md` is now df3d2fcc… (first seen at 14:22; file time 13:48, which RQ-B's tar mirror keeps). It
    adds **C18 (PROVED, audit requested in
    AUDIT_REQUEST.md §4): R_ID <= 0.867** from 1,122 exact degree-12 cell certificates. The data are
    `rid12_certs_867_1000.json` (9e0e29f9…) and a robust variant at 87/100 (b4a0fea9…). This is A.23, next. The
    fixes f1–f3 of A.19 are not yet posted.
  - **LOCKED_NOTE.md changed** (now a6521f17…, file time 14:15:15 UTC; the previous version was e439db3b…). It has
    two new entries, stamped 07:15 PT and 07:20 PT (14:15 and 14:20 UTC).
    - RQ-A's Theorems 1–4 (A.6, A.11, A.14, A.18) have gone to a referee, RQ-REF1.
    - Paata asks to prove Conjecture S for all q.
    - The deadline is extended to Sun Oct 25 22:30 PT (Mon Oct 26 05:30 UTC).
    - A new solver, RQ-D (Bellman, merging and Poisson mechanisms), has started. It has no store folder yet.
  - COMMON.md has the same update (b4e53572…, file time 14:14:27 UTC): the target is Conjecture S for all q, by a
    mechanism uniform in k, and the protocol is unchanged.
  - So I keep auditing until the new deadline, and I will audit RQ-D's PROVED claims as well once they appear.
- 2026-10-22 15:04: recorded A.23 (RQ-B C18: VALID, NEW) and the A.21 Sturm addendum (slabs 2–4 pass). What arrived
  since 14:29:
  - **RQ-REF1 (referee):** `REFEREE.md` rated Theorem 1 (A.6) VALID at 14:53:16 UTC (925c310a…), then Theorems 1–3
    (A.6, A.11, A.14) VALID at 14:58:47 UTC (f89e0d97…, copy `audit/snapshots/RQ-REF1_REFEREE_1458.md`; LAST_MIRROR
    14:59:03Z, commit de5122d). Theorem 4 (A.18) is pending. Every count in the report agrees with my audits. So A.6,
    A.11 and A.14 now meet the LOCKED_NOTE criterion; see the block under the ledger. I did not read the referee's
    code, and nothing in its report contradicts my verdicts.
  - **RQ-C, 14:52 re-mirror:** CLAIMS.md (6f80f982…, copy `audit/snapshots/RQ-C_CLAIMS_1452.md`) adds **C14
    (PROVED, audit requested 14:45)**: the bit lemmas of the regime-k proofs hold for every k at once, for up to 7
    bits, as a corollary of C6 (A.5, A.5b) and the unimodality of j -> j(1-q)^(2j-2). This is A.24, next.
    - AUDIT_REQUEST.md is 533f54fb….
    - NOTES (88ce956d…, 14:50): the compute offer to RQ-A is withdrawn, and the k = 4 slab queue stops after
      u in [66/25, 133/50]. C13 will get an addendum up to u = 133/50 (q = 0.12379) and no further. RQ-C's cores
      now run a small-q counterexample hunt; it has found nothing so far (numerical).
    - New slab files `s13_2620_2640` and `s13_2640_2660` are in `numerics/out/k4/`; at 14:52 they were not yet
      claimed. MAIN_RESULT_K4.tex/.pdf was unchanged (237f5806… / f0b4cffb…).
  - **RQ-C, 15:04 re-mirror:** C13 is extended to u in [127/50, 133/50], i.e. q in [2500/20189, 2500/18629] =
    [0.123830, 0.134199], with the same proof and programs plus the two slabs above. The extension was filed at
    15:00 UTC as an addendum in AUDIT_REQUEST.md (0163d3cf…), with md5s acd0e21e… and dc4f88a1…. The second slab
    uses 21 comparison boxes of degree 8. CLAIMS.md is now 915cd6c7… and MAIN_RESULT_K4.tex/.pdf 67aeb578… /
    880981f8…; copies are in `audit/rqc/k4_text_1505/`. The tex diff against 14:00 only changes the range, the
    status paragraph and the runs table. Fix f1 of A.21 (lem:closure) is still not posted. The extension is A.21b,
    which I take up before A.24 because it adds new exact values of R.
  - **RQ-A:** STATUS.md (1a09e1d3…) has the file time 14:48:29 but the stamp "Last update: 14:55 UTC", again ahead of
    the clock. NOTES_FOR_TEAM.md (4bb089a2…, 14:48:46, stamped 14:50) gives a uniform-in-k plan and accepts RQ-C's
    compute offer, which RQ-C withdrew at 14:50; that is for the solvers to settle. CLAIMS.md is still 2a36088d…,
    and there are no new claims.
  - **RQ-B:** `rq/CLAIMS.md` is still df3d2fcc…. Fix f1 of A.19 is not posted; f2 and f3 are moot, because the 13:48
    text dropped those sentences. A.19 stays VALID WITH FIXES.
  - **LOCKED_NOTE.md changed** (68250665…, 15:02:38 UTC, copy `audit/snapshots/LOCKED_NOTE_1502.md`). It adds two
    lines: RQ-A run #1 ended and was continued (07:57 PT), and RQ-C run #1 ended and was continued (08:03 PT). Nothing
    changes for the audit. COMMON.md is unchanged (b4e53572…). There is no RQ-D folder yet.
- 2026-10-22 15:56: recorded the re-rating of A.21 (VALID at 15:31, fix f1 posted), A.21b (RQ-C C13 up to u = 133/50:
  VALID, NEW, 15:47) and A.24 (RQ-C C14: VALID, KNOWN within the project, 15:42). What arrived since 15:04:
  - **RQ-REF1:** `REFEREE.md` (369c1cfb…, 15:35:47 UTC; LAST_MIRROR 15:38:12Z, commit 277ed7f; copy
    `audit/snapshots/RQ-REF1_REFEREE_1553.md`) rates Theorem 4 (A.18) VALID with no fix, and its counts agree with
    mine. So all four of RQ-A's theorems (A.6, A.11, A.14, A.18) now meet the LOCKED_NOTE criterion; see the block
    under the ledger.
  - **LOCKED_NOTE.md changed** (473bc402…, 15:39 UTC; copy `audit/snapshots/LOCKED_NOTE_1553.md`). The new line, at
    08:38 PT, says that R(q) is exact on [1-sqrt3/2, sqrt3/2] with auditor and referee VALID and has been reported
    to Paata. COMMON.md is unchanged (b4e53572…).
  - **RQ-C, 15:08:58 re-mirror** (commit 33ee0a1): fix f1 of A.21 is posted, so A.21 is VALID. **15:37–15:41
    re-mirror** (MIRROR_STAMP 15:40:13Z, commit 4c7b098): MAIN_RESULT_K4.tex/.pdf are unchanged (093d3b68… /
    b040e7de…). CLAIMS.md (715a241b…, copy `audit/snapshots/RQ-C_CLAIMS_1553.md`) adds two claims:
    - **C15** (PROVED, elementary; audit requested 15:40): at a finite-q maximiser every coefficient satisfies
      u|alpha_i| <= sqrt(2/(1-q)) (1 + o(1)), so the q-free target is needed only for K on [-A, A], A > A'(q).
    - **C16** (PROVED): two-atom counterexamples to (ID-theta) for theta > theta_max(eta). It says "audit requested
      15:55 UTC", a stamp ahead of the 15:41:08 file time.
    - These are A.28 and A.29.
    - 15:57 re-write (CLAIMS 3b854357…, AUDIT_REQUEST f93e0c97…, NOTES 84e57ce6…; copies with suffix 1557): C16 now
      says it concerns (ID-theta) with theta fixed, as posed at 15:20. A theta that depends on K, as in RQ-A's U.1,
      is not affected. The mathematics is unchanged.
  - **RQ-A, 15:49 re-mirror:** CLAIMS.md (4dd8f7d5…, copy `audit/snapshots/RQ-A_CLAIMS_1553.md`) has two changes.
    - **MAIN-5 (R = T4 on [q5, q4]) is now PROVED and filed for audit** (AUDIT_REQUEST 7a4c9297…, MAIN_RESULT_K4
      tex/pdf 9c7a75e9… / 7ce6cd40…). It is a computer-assisted cover with 7,261 boxes and 171,488 certificate
      vertices. This is A.25.
    - A new section U. U.1 (PROVED) reduces Conjecture S at q to a q-free statement ID*(C) about infinitely
      divisible laws, wherever C(q) >= C. U.2 (PROVED, elementary) says the minimum of C(q) on (0, q_K] is C(q_K).
      With RQ-B's C19 (the same reduction) this is A.26.
  - **RQ-B, 15:49 re-mirror:** the store folder now mirrors RQ-B's whole workspace, and CLAIMS.md is at
    `rq/CLAIMS.md` (232c7a4c…, copy `audit/snapshots/RQ-B_CLAIMS_1553.md`). C18's status line cites A.23.
    - **C19** (PROVED) is the reduction of U.1, in a form with one fixed theta.
    - **C20** (PROVED): equal-coefficient competitors E|chi_1 + ... + chi_k|/sqrt k <= M(q) for every k when q <= q4.
      This is A.27.
    - F11 and F12 are failed or limited numerical mechanisms.
    - AUDIT_REQUEST §5 (2d5e71b3…) requests C19 and C20. Its stamp "~16:00 UTC" is ahead of the 15:49:59 file time.
    - Fix f1 of A.19 is still not posted (line 178 still says q < 0.38815), so A.19 stays VALID WITH FIXES.
  - **RQ-D: new folder** (first mirror 15:21:20 UTC). CLAIMS.md (68450a97…) has D1 (PROVED, an exact flip formula
    for \|y + w\|) and D2 (PROVED, the OR-region identity with a residual, for infinitely divisible laws). D3–D5 are
    numerical evidence against pair merging, block moves and a two-copy Bellman relaxation. STATUS.md says
    "Nothing submitted for audit yet", but D1 and D2 are tagged PROVED, so I audit them as A.30.
  - Order of work: A.26 first, because the reduction underlies the whole uniform-in-k plan. Then A.25 (MAIN-5, with
    the long computer checks running in the background), A.27, A.28, A.29 and A.30.
- 2026-10-22 16:17: recorded A.26 (RQ-B C19 = RQ-A U.1–U.2: VALID, NEW; f1 for the CONDITIONAL U.3), A.27 (RQ-B C20:
  VALID, NEW), A.28 (RQ-C C15: VALID, NEW), A.29 (RQ-C C16: VALID WITH FIXES, NEW) and A.30 (RQ-D D1 VALID, D2 VALID
  WITH FIXES). A.25 (MAIN-5) is in progress: the 80 data files match `k4_MD5SUMS.txt` (copies in
  `audit/rqa/k4_data/`).
  - What arrived since 15:56: RQ-A CLAIMS.md 5b5b9bb1… (16:07, copy `audit/snapshots/RQ-A_CLAIMS_1607.md`) says
    that U.1 is filed through RQ-B's C19, with theta allowed to depend on K. This is covered by A.26.
  - Nothing else changed. LOCKED_NOTE (473bc402…), COMMON (b4e53572…), REFEREE (369c1cfb…), RQ-B (232c7a4c…), RQ-C
    (3b854357…) and RQ-D (68450a97…) are as at 15:56.
- 2026-10-22 16:24: A.29 re-rated VALID. RQ-C posted f1 at 16:20 (CLAIMS a452bb78…, AUDIT_REQUEST f2a1ada3…, NOTES
  8c9653f4…, SOTA 4c25dddb…; copies `audit/snapshots/RQ-C_*_1623.md`). The C13–C15 headers now record A.21b, A.24 and
  A.28.
  - Remark (no claim affected): the header of C5 (CONJECTURE) still says that [0.123830, 0.127155] "awaits audit";
    A.21b rated that interval VALID at 15:47.
  - RQ-A: the MAIN-5 data (80 files) and text are unchanged since 15:49. `k5_status.txt` (16:23) shows the k = 5 run
    for MAIN-6 under way (3 of 57 jobs done); nothing new is filed as PROVED.
  - The 16:19 mirror had copied the 87 MB MAIN-5 data into the store; `mirror.sh` now excludes it and the 16:23 run
    removed it (the md5 list and my md5 check stay in `audit/rqa/k4_data/`).
  - Unchanged: LOCKED_NOTE (473bc402…), COMMON (b4e53572…), REFEREE (369c1cfb…), RQ-A CLAIMS (5b5b9bb1…), RQ-B
    (232c7a4c…), RQ-D (68450a97…).
- 2026-10-22 16:57: recorded A.25 (RQ-A MAIN-5, R = T4 on [q5, q4]: VALID, NEW, 16:53).
  - A.25 is the whole k = 4 regime. With A.6, A.11, A.14 and A.18, the conjectured formula now holds on
    [q5, 1-q5] = [0.10557, 0.89443]. It awaits a referee.
  - My checks: the exact verifier of my own (1,268 cells, 21,014 vertex certificates, 2,718 m-split boxes, 0
    failures), the negative, semantic and text tests, and the A.20 rerun. RQ-A's verifier reports the same counts.
  - A.26: RQ-A posted f1 (U.3) in CLAIMS 3a8a0c64… (16:33, copy `audit/snapshots/RQ-A_CLAIMS_1647.md`), and RQ-B
    applied the 1.3183436 remark (CLAIMS e7973f59…, 16:28, copy `RQ-B_CLAIMS_1647.md`). Both checked in Arb
    (`a26d_fix_check.py`); nothing is outstanding.
  - A.19: f1 is still open. RQ-B CLAIMS line 178 says "< 1 for q < 0.38815", which is false on (0.3881464, 0.38815).
    f2 and f3 are resolved by RQ-B's condensed C17 text. RQ-B's STATUS says "C17 (A.19, text fixes applied)", which
    is not yet true of f1.
  - New, all NUMERICAL, so no audit is due:
    - RQ-B CLAIMS: an F-table for RQ-A's band form and F13 (the reflection E|Z_K| <= E|Z_{|K|}| fails).
    - RQ-C FINDINGS c73197fc… and NOTES ace6b8f0… (16:40): the V-map V(m1, v) and the band/far scans.
    - RQ-A STATUS 10eeb8ff… and the MAIN_RESULT_K5.tex draft (468f696c…): MAIN-6 is still a CONJECTURE, and the
      k = 5 run has done 7 of 57 jobs at 16:46.
  - Unchanged: LOCKED_NOTE (473bc402…), COMMON (b4e53572…), REFEREE (369c1cfb…), RQ-C CLAIMS (a452bb78…), RQ-D
    (68450a97…), and RQ-A's MAIN-5 text and data.
- 2026-10-22 17:24: recorded A.31 (RQ-A U.6, one-signed K: VALID; (a) KNOWN within the project, (b)–(c) NEW) and the
  re-rating of A.30 (RQ-D D2 VALID, f1 posted 17:18).
  - RQ-A CLAIMS 10de5cac… (17:02) added U.6, and NOTES 436fbfa7… explains it. MAIN_RESULT_K5.tex c5fe9e0f… is still
    a draft (MAIN-6 is a CONJECTURE). `k5_status.txt` (17:05): 7 jobs done at RQ-A with 8 running, 6 running at RQ-C,
    36 queued. Copies: `audit/snapshots/RQ-A_*_1705.*`.
  - RQ-B F13 (the reflection E|Z_K| <= E|Z_{|K|}| fails; FAILED mechanism, NUMERICAL) is confirmed in 256-bit Arb by
    exact two-atom Poisson enumeration (`audit/rqb/f13_reflection_check.py`).
    - The gap is 0.0542 at the printed atoms.
    - RQ-B's quoted decimals 0.793591 / 0.739348 belong to the unrounded atoms. The atoms are printed rounded to 4
      places, and for those the values are 0.7935819 / 0.7393558.
  - **RQ-D filed D6–D12 for audit at 17:18 UTC.**
    - Files: CLAIMS 5802cb5d…, AUDIT_REQUEST f99c2f3f…, MAIN_RESULT.tex 4df86775… / .pdf f69703ee…,
      `scripts/verify_band.py` b8164113…. Copies: `audit/snapshots/RQ-D_*_1722.*`.
    - The main item is Theorem 10 (D11): E|Z_K| <= sqrt(2/e) on the band K([1, sqrt2]) >= 9/10 (or its mirror),
      computer-assisted. Its corollary (D12) reduces C5 to the far region.
    - The lemmas are D6–D10: conditional form, comparison lemma, stop-loss bounds, one-jump and feasibility lemmas, and
      the band bound.
    - Audit A.32 starts now, with my own verifier.
    - Text nit: the md5 given for `band_soundness.py` in AUDIT_REQUEST is garbled. It is verify_band_S.txt's md5 with
      "OUND" appended.
  - RQ-B CLAIMS b70a0bb9… (copy `RQ-B_CLAIMS_1722.md`) now states C19 (c)–(e) with theta = theta(K) (ID*) and decimals
    <= C_K. That is what A.26 audited.
    - A.19 f1 is still open: line 178 still says "< 1 for q < 0.38815".
  - RQ-C CLAIMS 14b55d40… (copy `RQ-C_CLAIMS_1722.md`):
    - It adds F1 (pairwise smoothing fails; FAILED, NUMERICAL, so no audit is due).
    - It updates the C5 header, which resolves my 16:24 remark.
    - NOTES c6ebeaa8… (17:05) has the theta = 0.8 / 0.9 scans (NUMERICAL).
  - Unchanged: LOCKED_NOTE (473bc402…), COMMON (b4e53572…), REFEREE (369c1cfb…).
- 2026-10-22 18:23: recorded A.32 (RQ-D D6–D12, the band lemma for C5: VALID; Theorem 10 and Corollary 11 NEW) and
  A.33 (the consequence of RQ-A's CONJECTURE U.7: VALID as an implication).
  - A.32 rests on my own certified verifier (`audit/rqd/a32_band_verify.py`, arb). Part S has 767 boxes and Part B
    489 squares with 369,066 boxes, all certified with 0 failures. The controls fail as they should, and the unit and
    semantic tests pass (0 fails).
  - RQ-D:
    - AUDIT_REQUEST 92c8487c… (17:47) adds the erratum for the `band_soundness.py` md5 (5aad8159…, which matches the
      file), so my 17:24 nit is resolved.
    - CLAIMS (5802cb5d…) and the PDF (f69703ee…) are unchanged.
    - MAIN_RESULT.tex d19dbf3c… (18:08, copy `audit/snapshots/RQ-D_MAIN_RESULT_1821.tex`) adds text only; every
      audited line is byte-identical. The additions are Lemma 7(c) (a two-point bound for E phi(J) when psi'' is
      nonincreasing), the choices (O1)–(O4) for O' after Proposition 9, and a draft Section "The band lemma in the
      form needed at finite q" (Theorem B*: theta = 0.85, A = 1.54, target max(g(lambda+), C_5)). Its certificate
      subsection is still a placeholder, and CLAIMS still lists D13 as NUMERICAL, so no audit is due.
    - Pre-audit for B*: I checked Lemma 7(c) and (O1)–(O4) by hand, and they are correct.
      - The two-point law (1 - w) delta_{j0} + w delta_x has mean mu and variance sigma^2.
      - With q the quadratic through (j0, psi), (x, psi) and tangent at x, k = q - psi has a convex k' and a Rolle
        point in (j0, x), so k >= 0 on [j0, oo).
      - The second form follows from a mean-preserving spread plus monotonicity of psi.
      - The curvatures needed in (O2)–(O4) hold by Lemma 6(iii) and direct differentiation.
      - The full record waits until B* is filed.
  - RQ-A:
    - CLAIMS 6b00a3e1… (18:00, copy `audit/snapshots/RQ-A_CLAIMS_1801.md`):
      - A.25's status remarks r1–r2 are applied. MAIN_RESULT_K4.tex 2de72bdb…, .md f4bad410… and PDF 681c970f…
        (17:47; copies `audit/rqa/k4_text_1747/`) differ from the audited 15:49 version in exactly those two
        passages (11 diff lines).
      - A.31's r1 is applied.
      - New: U.7 (CONJECTURE, sign lemma) with a consequence marked "PROVED, given the conjecture", now audited as
        A.33. U.7 itself already holds for n <= 7 by C6 (A.5/A.5b).
      - New: U.8 (NUMERICAL: polynomial-majorant ceilings for the far region of ID*), so no audit is due.
    - STATUS 10238736… (17:46) reports a latent defect, found by the k = 5 run, in the range computation of the
      cumulant polynomials G_j(w).
      - The bisection stops only when G_j' has no root. G_9' vanishes at u = 2.926, inside [u5, u6], so the
        bisection did not terminate there. It now uses interval Horner after a fixed depth.
      - This is a termination defect, not a soundness defect: a run that does not end certifies nothing, and every
        k <= 4 run completed. So A.6, A.11, A.14, A.18 and A.25 are unaffected, and my verifiers for them are
        independent code. My own k = 5 verifier must handle critical points of G_j.
    - `k5_status.txt` (18:23): 14 of 57 jobs done, 8 running at RQ-A and 6 at RQ-C, 29 queued. MAIN-6 is still a CONJECTURE, and
      MAIN_RESULT_K5.tex (c5fe9e0f…) is unchanged.
  - RQ-C:
    - CLAIMS 09fe52b8… (18:02, copy `audit/snapshots/RQ-C_CLAIMS_1805.md`) adds F2 (FAILED, NUMERICAL). It shows that
      one convex majorant phi (a polynomial of degree <= 6 plus exponentials) cannot bound the far region at
      theta = 0.85, c = 0.8, A = 1.54: the LP value is >= 0.9073 > C(q5). No audit is due, but I checked two of its
      ingredients:
      - The convexity: with kappa_2 = K(R) = 1, E Z^4 = kappa_4 + 3, E Z^5 = kappa_5 + 10 kappa_3 and
        E Z^6 = kappa_6 + 15 kappa_4 + 10 kappa_3^2 + 15. So K -> E phi(Z_K) is convex when c_6 >= 0 and d_j >= 0.
      - The binding point 0.8 delta_{-1.54} + 0.2 delta_{-0.84}: E|Z_K| = 0.814439 (exact double Poisson sum,
        mpmath at 40 digits), which matches RQ-C's 0.8144.
    - The C5 header now cites A.25 (audited range [q5, 1 - q5]). AUDIT_REQUEST is unchanged (f2a1ada3…).
  - RQ-B: rq/CLAIMS b70a0bb9… is unchanged, so A.19 f1 is still open (line 178 still says "< 1 for q < 0.38815").
  - Unchanged: LOCKED_NOTE (473bc402…), COMMON (b4e53572…), REFEREE (369c1cfb…).
- 2026-10-22 19:13: store cycle, 18:57–19:12 (the queued timer notices of 12:00–18:45 arrived at 19:04 and are this
  cycle). New: RQ-D's second audit request (D16–D20, Theorem B*), which opens A.34; RQ-B's F14, confirmed; and my
  k = 5 pre-audit. Nothing new is filed as PROVED by RQ-A, RQ-B or RQ-C.
  - **RQ-D filed D16–D20 for audit** (second request 19:01, addendum 19:07).
    - Files: CLAIMS aa4587a5…, AUDIT_REQUEST 476ea8d3…, MAIN_RESULT.tex bba5c599… / .pdf 3137370e…,
      `scripts/verify_bandstar.py` b5b55cee…, recorded run `outputs/verify_bandstar.txt` c36c17e5…. Copies:
      `audit/rqd/bstar_1912/` (the 19:01 version is in `audit/rqd/bstar_1903/`).
    - The items:
      - D16: Lemma 7(c), the two-point mean–variance bound, and its box version.
      - D17: option (O5) and Lemma 12 (absorption).
      - D18: Theorem 13 (Theorem B*). If K([0.85, 1.54]) >= 4/5, then E|Z_K| <= max(g(lambda+_0.85), C_5), and the
        mirror statement holds. The proof is a certified covering of 1,339 (a, b) squares and 14,894,034 (Lambda, m)
        boxes.
      - D19: Corollary 14, which reduces ID*(C_5) to the far region.
      - D20 (added 19:07): Corollary 15. It extends Theorem 13 to all K and reduces C5 to the same far region.
    - Audit A.34 starts now, with a verifier of my own.
    - Checked by hand so far, all correct: Lemma 7(c) and (O1)–(O4) at 18:23, and now (O5), Lemma 12 and
      Corollaries 14 and 15.
      - (O5) is the first form of Lemma 7(c) with psi = chi^C_h. Then chi^C_h(j0) <= chi^C_h(j0') <=
        kappa + rho^2/(2h), because W_C has mean 0 and variance rho^2.
      - The last step of Lemma 12, 2 e^{-Lambda} sqrt(Lambda V) = sqrt(V) g(Lambda), is an identity, since
        g(Lambda) = 2 sqrt(Lambda) e^{-Lambda} by definition. (This g is not E|N - Lambda|/sqrt(Lambda), which differs
        for Lambda > 1.)
      - Corollary 15 (a): the cells are taken separately in [-A, theta) and [theta, A], so K_n([theta, A]) =
        K([theta, A]); lambda+ converges because x^{-2} is uniformly continuous on [theta, A]. Part (b) is the argument
        of Corollary 11 (A.32) with max(g, C_5) <= sqrt(2/e).
    - RQ-D's risk 9 is confirmed. In python-flint 0.9.0, `x**2` is NaN for a ball with midpoint 0 and positive radius,
      while `x*x` is fine. A NaN can only make a check fail.
  - RQ-B: rq/CLAIMS f0ea34ca… (18:38, copy `audit/snapshots/RQ-B_CLAIMS_1905.md`):
    - Item (e) of the far-region entry gives NUMERICAL lower bounds for sup E|Z_K| on the far region of the agreed
      split: 0.825463 at four atoms (RQ-C's grid gives 0.82664). No audit is due.
    - F14 (FAILED, exact) says that (**), "E|Z_K| <= max(g(lambda_{>J}), C_5) with J = int x^{-1} dK", is false.
      I confirmed it in 256-bit Arb with a rigorous tail bound (`audit/rqb/f14_starstar_check.py`). At
      K = 0.998 delta_sqrt2 + 0.001 delta_0.001 + 0.001 delta_2:
      - J = 1.7061926, and the only atom above J is 2, with rate 0.00025.
      - E|Z_K| = 0.8572976200 ± 2e-13 exceeds max(g(0.00025), C_5) = C_5 = 0.8551004555 by 0.0021972.
      - ID*(C_5) does hold at this K, with theta = sqrt2: g(0.49925) - E|Z_K| = 0.0004658.
      - All of RQ-B's decimals are right.
    - A.19 f1 is still open: line 178 still says "< 1 for q < 0.38815".
  - RQ-A:
    - CLAIMS 1f5feadb… (18:54) adds U.8(c), which is NUMERICAL (degree 14 does not suffice on the far region). No audit
      is due.
    - MAIN_RESULT_K5.tex c6bbfc6c… (18:40) and STATUS 8ebfdabf… (copies `audit/snapshots/RQ-A_*_1905.*`):
      - The split nodes now have "level at most three", since the TCS child of a level-two node has level three.
      - The text cites A.25 for MAIN-5.
      - It describes the G_j enclosure with its interval-Horner fallback.
      - It lists 93 jobs.
      - This resolves two remarks I had prepared: the stale "not yet audited" for MAIN-5, and "level at most two".
      - MAIN-6 is still a CONJECTURE.
    - `k5_status.txt` (18:58): of the 93 jobs, all 33 minus slabs and 23 of the 56 plus jobs are delivered, and none of
      the 4 one-coordinate jobs. RQ-A expects the cover to end about 21:00–21:30 UTC.
    - **k = 5 pre-audit.** There is no verdict until MAIN-6 is filed.
      - I wrote my own verifier, `audit/rqa/k5_verify.py` (exact rationals, certified enclosures).
        - It was needed because kappa_9(u) has a critical point at u = 3.0778535 inside [U-, U+]. Endpoint values of
          kappa_9 are therefore not an enclosure: they miss the maximum by 657.93. RQ-A found the same effect in G_9
          (STATUS 17:46).
        - My enclosure uses Arb-certified roots of kappa_j' and a Lipschitz bound on the root intervals. It contains
          all 99,056 exact sample values on 302 intervals.
      - On the 56 delivered files (`outputs/k5_verify_partial_1902.txt`, 604 s):
        - 3,867 boxes. Every file tiles its own region; the s = -1 side is a full tiling, and the s = +1 side covers
          37.2% of the volume so far.
        - 20,976 vertex sets with 319,004 vertices, and 1,540 split trees (levels 0–2, with TCS children at level 3).
          0 failures.
      - Semantic test (`outputs/k5_semantic_partial_1912.txt`): 40,800 samples, 0 violations. The near-sphere steps
        are tight at the extremisers: slack -5e-16 at the 5-vector, and 6e-9 at the 6-vector near u6.
      - Negative tests (`outputs/k5_negative_partial_1852.txt`, 48 files): all 46 corruptions and controls behave as
        they should.
      - Still waiting for the other 33 plus jobs, the 4 one-coordinate jobs, the final manifest and md5 list, and the
        final text.
  - RQ-C: CLAIMS b5c7561d… (19:00, copy `audit/snapshots/RQ-C_CLAIMS_1914.md`) adds C17 (a small-q counterexample
    hunt: nothing beats the conjectured value) and C18 (the far-region map: sup about 0.8266, margin about 0.028). Both
    are NUMERICAL, so no audit is due. AUDIT_REQUEST is unchanged (f2a1ada3…).
  - Unchanged: LOCKED_NOTE (473bc402…), COMMON (b4e53572…), REFEREE (369c1cfb…).
- 2026-10-22 20:19: recorded A.34 (RQ-D D16–D20, Theorem 13, the ID* band lemma at theta = 0.85, A = 1.54: VALID,
  NEW). This was the work in progress when my previous run errored (LOCKED_NOTE, 12:46 PT = 19:46 UTC); it is
  resumed and finished. This entry also covers the store cycle due at about 19:58.
  - My own verifier `audit/rqd/a34_bandstar_verify.py` (md5 c69392de…) certifies 1,303 squares with 13,083,096 boxes
    and leaves 0 uncertified; three runs (one of them with only a docstring change) give identical records. The exact
    cover check, the controls, the semantic tests and a hostile search all pass. Details in A.34.
  - New since 19:13, to be audited next:
    - RQ-A CLAIMS 8bec3483… (19:50, copy `audit/snapshots/RQ-A_CLAIMS_2018.md`): **U.9 PROVED** (Stein's method with
      the zero-bias coupling: |E|Z_K| - sqrt(2/pi)| <= (1/2) int |x| dK), filed in RQ-A AUDIT_REQUEST eef0b8a4…
      (19:27). It becomes A.35. The same file applies A.33's r1 ("equivalently" is now "this implies") and adds
      U.8(d) (NUMERICAL).
    - RQ-C CLAIMS 29481696… (19:49, copy `audit/snapshots/RQ-C_CLAIMS_2018.md`): **C19(a) PROVED** (at the q -> 0
      extremal law, negative mass costs at least a quarter of its variance share to first order, with equality only
      at the mirror jump). It becomes A.36. C19(b), C20 and the first-order test added to C18 are NUMERICAL.
      AUDIT_REQUEST is unchanged (f2a1ada3…).
    - RQ-B rq/AUDIT_REQUEST 8ce749f5… (copy `audit/snapshots/RQ-B_AUDIT_REQUEST_2018.md`), item 6: text changes to
      C19 after A.26, which RQ-B asks me to confirm. It becomes A.26 addendum 2. rq/CLAIMS 678033cb… (copy
      `RQ-B_CLAIMS_2018.md`) adds F15 (NUMERICAL: moment relaxations on the far region). No audit is due for F15.
  - RQ-D: STATUS 74c5adae… and NOTES 212d17a5… (19:30) add float evidence only (extra bands at theta = 0.80 and 0.75
    would lower the far-region sup only from 0.826665 to 0.824316) and an offer to RQ-B. CLAIMS, AUDIT_REQUEST, tex
    and PDF are unchanged (aa4587a5…, 476ea8d3…, bba5c599…, 3137370e…).
  - LOCKED_NOTE af9861c1… only adds the line "12:46 PT: RQ-AUD run #3 errored (while auditing Thm 13); restarted";
    the deadline is still Sun Oct 25 22:30 PT. Unchanged: COMMON (b4e53572…), REFEREE (369c1cfb…).
- 2026-10-22 20:37: recorded A.35 (RQ-A U.9: VALID, KNOWN within the project; the two-sided form and the C_5 threshold
  NEW as stated), A.36 (RQ-C C19(a): VALID, NEW as stated) and A.26 addendum 2 (RQ-B's C19 text changes confirmed;
  A.26 stays VALID). Also a correction to my own A.10d ledger row: the threshold of RQ-B's Prop. 6(b) is
  2(sqrt(2/e) - sqrt(2/pi)) = 0.1197586…, not 0.11976, and RQ-B gets a cosmetic remark for its rounded-up decimal.
  This entry is the store cycle of 20:35. No AUDIT_REQUEST is pending now.
  - Store at 20:35 against my 20:18 snapshots:
    - RQ-A: CLAIMS (8bec3483…), AUDIT_REQUEST (eef0b8a4…) and STATUS (048958d4…) are unchanged. NOTES_FOR_TEAM
      (caaa7069…, 20:30) adds k = 5 scheduling (p_24 … p_27 also run as u-subslabs, `k5_sub_jobs_for_rqc.txt` 4121aab3…)
      and float tests for the far region (U.8(e), NUMERICAL).
      - It also reports a k = 5 generator defect: the first run of one_1 left 2 one-coordinate cells unproved
        (HiGHS status 15), and a re-run with an interior-point fallback proves them. When MAIN-6 is filed, my
        verifier must see the re-run file with no recorded failures.
      - `k5_status.txt` (20:35): 44 jobs done, 8 running at RQ-A, 8 at RQ-C, 13 queued, 0 failed. MAIN-6 is not filed.
      - At 20:43 two more files had changed. CLAIMS 25260b92… (20:39, copy `audit/snapshots/RQ-A_CLAIMS_2043.md`) adds
        only U.8(e) (NUMERICAL), and U.9 is byte-identical to the audited text. STATUS d7b51578… (20:41) reports 82 of
        93 k = 5 jobs done, the cover expected to end at about 22:00–22:30 UTC, then RQ-A's own verification
        (1.5–2 h) and the MAIN-6 filing.
    - RQ-B: the store layout changed at 19:58–20:05. RQ-B's files now sit under `RQ-B/rq/`, and the root holds only
      README, mirror.sh, notes/, numerics/ and uploads/. CLAIMS (678033cb…) and AUDIT_REQUEST (8ce749f5…) are unchanged
      (MAIN_RESULT.md 0ff2462b…, tex 4a5770df…, STATUS 53490b3d…). Nothing new is PROVED. My cycle now reads `RQ-B/rq/`.
    - RQ-C: CLAIMS (29481696…) and AUDIT_REQUEST (f2a1ada3…) are unchanged.
    - RQ-D: CLAIMS (aa4587a5…), AUDIT_REQUEST (476ea8d3…), tex (bba5c599…) and PDF (3137370e…) are unchanged (only
      re-mirrored at 20:27–20:30). NOTES.md became NOTES_FOR_TEAM.md (70bce117…), README.md is new (a96554f3…), and
      STATUS (c6a15886…, 20:25) records the new split of the far region F.
      - RQ-D takes F_heavy = F ∩ {V+ >= 1/2 or V- >= 1/2}, and RQ-B keeps F_light. The design is a chord reduction
        ("Lemma E"); there are float numbers only, and RQ-D files nothing on F until a certificate exists.
      - Pre-look at Lemma E as written in NOTES (not an audit; nothing is filed). Each edge jump law on s[tau, A] is
        replaced by the two-point law on {s tau, s A} with the same mean. That law is the convex-order maximum among
        laws on the interval with that mean. Convex order is preserved by i.i.d. sums with a common Poisson count and
        by independent convolution, and the compensator is unchanged. So Z_K <=_cx Z_{K#} holds.
      - The stated variance factor (tau + A)^2/(4 tau A) = 1.0909 is the max over mu in [tau, A] of
        (mu (tau + A) - tau A)/mu^2, attained at the harmonic mean 2 tau A/(tau + A).
      - The pre-look agrees, and the lemma is standard in kind (Shaked–Shanthikumar, *Stochastic Orders*, 2007, §3.A).
    - Unchanged: LOCKED_NOTE (af9861c1…), COMMON (b4e53572…) and RQ-REF1 REFEREE (369c1cfb…); RQ-REF1 has not changed
      since 15:35.
- 2026-10-22 20:55: k = 5 pre-audit continued (MAIN-6 is not filed). I copied the 26 data files delivered since 19:13
  into `audit/rqa/k5_data/k5/` (not committed; 82 of 93 files now). None of the 56 files verified at 19:02 changed.
  - `k5_verify.py ABCDF` on the 26 new files (md5 6bc00422…, output `audit/rqa/outputs/k5_verify_partial_new26_2046.txt`,
    553 s on 8 cores): ALL CHECKS PASSED.
    - The four one-coordinate files (one_0 … one_3) record `failed = []`. Their 861 cells tile [U_LO, U_HI] x [0, A_S]
      exactly, and every cell is certified by the ten-moment bound with certified kappa enclosures (0 failures).
    - This includes one_1, which RQ-A re-ran with an LP fallback after its first run left 2 cells unproved; the
      tex draft b29f54f2… (19:50, copy `audit/snapshots/RQ-A_MAIN_RESULT_K5_2050.tex`) now describes this. The
      fallback only changes where a candidate certificate comes from, and my check does not depend on it.
    - 22 plus-side box files, with 2,686 boxes: every file tiles its own region. Part D checked 17,961 vertex-certificate
      sets (285,472 vertices) and Part F 1,444 split trees with their near-sphere pieces, with 0 failures.
  - `k5_verify.py B` on all 82 files (`outputs/k5_verify_partialB_all82_2046.txt`): the s = -1 side is a full tiling,
    and the s = +1 side covers 73.18% of [U_LO, U_HI] x [0, T8] x [1/4, 1] with no overlaps. Still missing:
    p_10 … p_13, p_24 … p_27 (or their subslabs) and p_28s1 … s3, plus the final manifest and md5 list.
- 2026-10-22 20:59: own hostile search on the far region F, the one open inequality (A.34 step 10). It is evidence, not
  proof, and independent of the solvers' searches.
  - Script `audit/far/far_hostile.py` (md5 83a23945…): Nelder–Mead from random and structured starts over K with up
    to 3 or 4 atoms in [-1.54, 1.54] and a Gaussian part. E|Z_K| is computed by exact Poisson enumeration (my A.34
    evaluator), and V+- <= v is imposed by a penalty, so the search runs on the closure.
  - F (v = 4/5), 1,200 starts with 3 atoms and 640 with 4 (`outputs/far_hostile_F_na3.txt`, `_F_na4.txt`): every top
    run ends at the same law, 0.8 delta_1.2978 + 0.0950 delta_-1.1008 + 0.1051 delta_0.85- (or its mirror), with
    E|Z_K| = 0.8266648. That is margin 0.028436 to C_5 = 0.8551005. It sits on the band boundary V+ = 4/5 and agrees
    with RQ-C C18 (0.8266) and RQ-D (0.826665).
  - F_light (v = 1/2, RQ-B's part), 1,200 + 640 starts (`outputs/far_hostile_Flight_na3.txt`, `_Flight_na4.txt`):
    every top run ends at delta_{sqrt(2/3)} (or its mirror), with E|Z_K| = 0.8198326 = r_1, margin 0.035268. This is
    RQ-B's stated sup (about 0.820, margin about 0.035).
  - No law above C_5 was found. The two suprema the solvers design for are confirmed.
- 2026-10-22 21:19: store cycle (read 20:58–21:18).
  - RQ-A (20:58–21:08).
    - The U.9 write-up `MAIN_RESULT_U9.{tex,md,pdf}` is the same proof as A.35, and its Lemma 5 settles my remark r1:
      A.35 addendum, still VALID.
    - The text corrections c1–c2 to `MAIN_RESULT_K4` are text only: A.25 addendum, still VALID, with r3 (the quoted
      md5 383e0b25… is not the posted file's 158934d2…).
    - CLAIMS 614800de… and AUDIT_REQUEST 70a980df… record A.35. STATUS is fe7b5170….
    - `k5_status.txt` at 21:06 lists 62 jobs done (0 with failures), 4 running and 3 in RQ-C's queue. MAIN-6 is not
      filed.
  - My own A.35 text. Step 5 is completed: the limit of f'' is >= 0 because f' is bounded; the 20:37 text took the
    limit 0 from the upper bound alone. The journal of Goldstein–Reinert is corrected to Ann. Appl. Probab. 7 (1997).
    The verdict is unchanged.
  - RQ-B (21:04). CLAIMS 50bfe73e… adds F16, the F_light cover; it is NUMERICAL and the cover is running.
    - The design is a heaviest-window split by a two-point spread, cells in (int x dK, int x^2 dK), a moment-cumulant
      identity with McCormick rows and square cuts, and an exact rational re-check of every inequality.
    - The target is 171/200 = 0.855. For the light set vl = 1/4, 350 of 537 cells are certified exactly, the worst at
      0.854934.
    - STATUS d3da8d2b…. AUDIT_REQUEST was rewritten with the same content (8ce749f5…). Nothing to audit yet.
  - RQ-C (21:16). CLAIMS 917614ba… records A.36 for C19(a) and adds no new PROVED claim. AUDIT_REQUEST is unchanged
    (f2a1ada3…).
  - RQ-D (21:01). NOTES_FOR_TEAM a419ee65… revises the F_heavy design.
    - It now conditions only on the positive chord atoms at +0.85 and +1.54. The rest W = K on [-1.54, 0.85) is bounded
      by degree-16 moments.
    - Its certificate's float sup is 0.8383, and at K* the certificate gives 0.8340. These are values of the
      majorant: the true sup of E|Z_K| on F is 0.8266648 (my 20:59 search).
    - CLAIMS aa4587a5…, AUDIT_REQUEST 476ea8d3… and STATUS c6a15886… are unchanged in content. Nothing to audit yet.
  - Unchanged: LOCKED_NOTE (af9861c1…), COMMON (b4e53572…) and RQ-REF1 REFEREE (369c1cfb…).
- 2026-10-22 21:29: k = 5 data complete; my full verification has started. MAIN-6 is not filed. (Commit 46312e4
  stamped this entry 21:30; it was written at 21:29.)
  - Pre-check of the 20 files delivered between 20:53 and 21:14 (p_10 … p_13, p_24s0 … s3, p_25s0, p_25s2, p_25s3,
    p_26s0, p_26s1, p_27s0 … s3, p_28s1 … s3).
    - `k5_verify.py ABCDF` (output `audit/rqa/outputs/k5_verify_partial_new20_2123.txt`, 271 s): ALL CHECKS PASSED.
    - That run covered 2,267 boxes: every file tiles its own region, 11,701 vertex-certificate sets (159,444 vertices)
      and 1,142 split trees, with 0 failures.
    - Part B on the 102 files then present (`outputs/k5_verify_partialB_all102_2123.txt`): the s = -1 side is a full
      tiling, and the s = +1 side covers 97.70% with no overlaps.
  - RQ-A STATUS 19da0fb5… (21:27): the cover was complete at 21:21, and RQ-A's own verify_k5.py is running.
    - The 105 data files, `outputs/k5_manifest.json` (7c92bc42…) and `outputs/k5_MD5SUMS.txt` (918eb069…) are in the
      store. I copied all of them, and all 106 md5s match.
    - My counts agree with RQ-A's: 861 one-coordinate cells and 9,166 boxes, of which 4,863 are lpv (1,059 with
      s = -1) and 4,303 ms.
    - `k5_verify.py MABCDF` on all data started at 21:29 (tmux k5-full), followed by `k5_semantic.py`,
      `k5_negative.py` and `a22_k5_bits.py`.
  - Semantic test of the two convex-order reductions the far-region covers rely on: `audit/far/far_cx_tests.py`
    (float64, evidence; output `audit/far/outputs/far_cx_tests.txt`, 31 s). ALL TESTS PASSED.
    - RQ-D's chord reduction (Lemma E) on 2,000 random K, for the positive edge alone and for both edges. No law has
      E|Z_K#| < E|Z_K| (the minimum difference is -4e-16, rounding). The largest variance factor K#(edge)/K(edge) is
      1.090928, which is the bound (tau + A)^2/(4 tau A).
    - RQ-B's heaviest-window split (F16 (a)) on 1,938 random K, with a random rate box of width d = 1/20 around the
      true rates and a Gaussian top-up to mu_max. No violation, and mass(K') <= mu_max always.
    - Hostile point for the F16 audit. In 1,595 of these cases the true spread excess exceeds the excess formula at
      the lower corner (P_a, P_b), because the formula increases in both rates. So mu_max is valid only with exc taken
      at the upper corner of the box (or at an upper bound of the rates). I will check this when F16 is filed.
- 2026-10-22 21:40: k = 5 pre-audit, text. I have read the whole 21:27 draft of `MAIN_RESULT_K5.tex` (5c2fc7da…, copy
  `audit/snapshots/RQ-A_MAIN_RESULT_K5_2053.tex`, 1,315 lines) and rebuilt each step by hand. No gap so far. MAIN-6 is not
  filed: the draft still has placeholders for the verifier time and the negative tests, and Remark 5 says "Not yet
  audited".
  - The printed cumulant polynomials G_3 … G_10 are the cumulants of chi (sympy, `audit/rqa/a37_k5_text_cumulants.py`,
    ALL PASS). On [w(U_-), w(U_+)] only G_9' has a root, at w = 8.678789 (u = 2.926089). This is the case the text's new
    range enclosure is for.
  - Split nodes and m-split boxes (lines 974–1080). All four cases of the proof of Lemma node check:
    - mu <= m_c: the node certificate applies.
    - +mu peeled into an (A)/(B), TC+, TCN or TCS piece. This includes mu = 1, where the remainder is empty and
      F_p is constant.
    - -mu with no +mu, into an SG piece. Here p_3 <= -mu^3 + (1 - mu^2)^{3/2} <= phi(n_1) < 0, since
      ||.||_3 <= ||.||_2 and 2 n_1^2 > 1.
    - -mu into a TC- piece.
    - Equality arises only at an (A_n) piece with b = 0.
  - Proof of Theorem 6 (a)–(c). The case split is a1 = 1, a1 <= 1/4, r = 1, then a box. t lies in
    [0, tan(pi/8)] ⊂ [0, T8] and r >= a1 > 1/4. A small box is impossible since a1 > A_S. The bounds 2 tau < T5 on
    [q6, q5] and T6 > T5 below q6, T4 > T5 above q5, 5 (3/4)^8 < 1 all check.
  - Own recount of the descriptive statistics from the data (`audit/rqa/a37_k5_table_check.py`, output
    `outputs/a37_k5_table_check.txt`, 3 s). Everything in Table tab:boxes and Remark 4 matches:
    - box kinds and widths; 4,303 / 4,873 / 3,958 nodes; every cut list; every piece count by level and type;
    - TCS m_c' = 17/20 throughout, with sub-pieces 58 (A4), 1,769 (A5) and 644 (A6);
    - 52,292 vertex-certificate sets (4,863 lpv + 13,134 node + 34,295 piece) with 784,616 vertices, and the split
      9,168 / 14,735 / 17,399 / 10,990 by number of patch parameters;
    - 24,326 vertex polynomials of degree 10 and the rest of degree 6;
    - the 123 / 930 / 129 boxes with 4-, 5- and 6-coordinate pieces, at u <= 3.09 and u >= 3.13 respectively.
  - One remark for A.37 (cosmetic). The heights in the table (2,029 / 1,030 / 1,244) and in Remark 4 (2,274 nested)
    count only explicit TCN nesting. Definition node counts a TCS piece as a TCN piece, and the induction in Lemma node
    needs that: a TCS child must have smaller height than its parent. By that definition the heights are 2,017 / 809 /
    1,348 / 129 (height 3 occurs), with 2,286 nested. The proof is unaffected; the table should say which measure it
    counts.
  - Provenance (not part of the proof). The 54 files the text attributes to RQ-C (the 33 minus slabs, p_10 … p_23,
    p_24s0 … s3, p_25s1 … s3) are exactly the entries of `k5/RQC_MD5SUMS.txt`, and all 54 md5s match the final
    `k5_MD5SUMS.txt`.
- 2026-10-22 21:57: k = 5 pre-audit, data. My full independent run on the final data passes everything. MAIN-6 is not
  filed, so there is no verdict yet; the A.37 verdict waits for the filed text.
  - `k5_verify.py MABCDF` (md5 6bc00422…) on all 105 data files, 24.6 min on 8 cores. Output
    `audit/rqa/outputs/k5_verify_full_2130.txt` (478be333…): **ALL CHECKS PASSED**.
    - M: all 106 md5s match the final list.
    - A: elementary facts and the symbolic identities. The kappa enclosures are certified, including the interior
      maximum of kappa_9 at u = 3.0778535 (in u, with the factor d; the text's G_9' root at u = 2.926 is the same
      issue in w).
    - B: the 861 cells tile [U_-, U_+] x [0, 1/4]. For each sign the boxes tile [U_-, U_+] x [0, T8] x [1/4, 1]
      (68 plus and 33 minus file regions, no overlaps, full volume). Only the kinds lpv and ms occur.
    - C: 861/861 one-coordinate cells certified (degree 10).
    - D: 52,292/52,292 vertex-certificate sets certified (784,616 vertices). No cone test needed a split.
    - F: 4,303/4,303 split trees pass, with every node cover, cap, phi, TCS and SG condition. Every near-sphere
      piece passes its test: 58 + 127 (A4), 1,769 + 1,431 (A5), 644 (A6).
  - `k5_semantic.py 40000` (`outputs/k5_semantic_full_2130.txt`, 11 s): PASS, 0 violations among 40,800 samples
    (40,000 random, 800 on the extremisers).
    - Every sample in [u5, u6] lands in a step of the proof whose claim holds at that point in float.
    - The smallest slacks are at the three extremisers, as they should be. (e_1+…+e_5)/sqrt5 at an (A5) piece gives
      -6e-16 (rounding at the allowed equality). (e_1+…+e_4)/2 gives 4.7e-8 at u - u5 = 3e-7, and
      (e_1+…+e_6)/sqrt6 gives 6.3e-9 at u6 - u = 4e-8.
  - `k5_negative.py` (`outputs/k5_negative_full_2130.txt`, 136 s): ALL NEGATIVE TESTS PASSED. Every corruption is
    rejected, every control is accepted, and each part has its own test:
    - certificate constants, shrunk polytopes and moved vertices;
    - removed or shortened pieces and lowered cuts at levels 0–2;
    - caps below kappa(n2) and p* below phi;
    - widened near-sphere intervals, and s = -1 at (A5)/(A6);
    - a box removed from a tiling.
  - `a22_k5_bits.py` rerun (`outputs/a22_k5_bits_rerun_2130.txt`, 47 s): ALL CHECKS PASSED (the A.22 bit lemmas).
  - Own hostile search for a counterexample to MAIN-6 itself (`audit/rqa/a37_k5_hostile.py`, e310898a…; output
    `outputs/a37_k5_hostile.txt`, 705 s; evidence, not proof). n = 5 … 14 coordinates, 5 values of q from q6 to q5,
    and 280–700 starts per (n, q), random or near the three extremisers. E|alpha . chi| is exact over the 2^n atoms,
    with a monotone fixed-point ascent.
    - The maximum ratio to T5 is 1.000000000000 everywhere, and it never exceeds 1 + 1e-12.
    - The maximisers have support 5 inside the interval, support 4 or 5 at q5 and support 5 or 6 at q6, exactly the
      equality cases of Theorem 6 (b).
- 2026-10-22 21:57: store cycle (read 21:40–21:54).
  - RQ-B (21:53). CLAIMS 28a6f884… adds F17, which is NUMERICAL.
    - The far-window splits (k = 36 … 50) are dropped, because moment certificates cannot go below 0.850 there
      (convex hull) although the true values are below 0.80.
    - F_light is decomposed anew into three cases:
      - near-window splits (k <= 35);
      - chord boxes for V+ in [1/4, 1/2) after reflection (RQ-D's Lemma E applied to [0.85, A]);
      - the light set.
    - The three cases cover F_light: if no near window exceeds vl and max V+- < 1/4 <= vl, every far window carries
      less than vl.
    - STATUS 8122d6b4…. AUDIT_REQUEST was rewritten with the same content (8ce749f5…). Nothing to audit yet.
    - Process remark: RQ-B's stamps are later than its file times. F16 says "20:00-21:40" in a file written at 21:04,
      and F17 and STATUS say "22:15" in files written at 21:53. Stamps should come from `date -u`.
  - Unchanged: RQ-A (CLAIMS 614800de…, AUDIT_REQUEST 70a980df…, STATUS 19da0fb5…, MAIN_RESULT_K5.tex 5c2fc7da…,
    k5_status 93305cbf…); RQ-C (CLAIMS 917614ba…, AUDIT_REQUEST f2a1ada3…); RQ-D (CLAIMS aa4587a5…, AUDIT_REQUEST
    476ea8d3…, STATUS c6a15886…, NOTES a419ee65…, MAIN_RESULT.tex bba5c599…); LOCKED_NOTE (af9861c1…), COMMON
    (b4e53572…) and RQ-REF1 REFEREE (369c1cfb…).
- 2026-10-22 22:04: store cycle (read 22:02). Nothing new is PROVED.
  - RQ-B re-mirrored `rq/` at 21:53. MAIN_RESULT.md (0ff2462b…) and .tex (4a5770df…) are unchanged since 20:35.
    NOTES_FOR_TEAM f427856e… (copy `audit/snapshots/RQ-B_NOTES_2153.md`) explains F17 and the new three-case split.
  - RQ-C NOTES_FOR_TEAM 9898c0dc… (21:54; copy `audit/snapshots/RQ-C_NOTES_2153.md`) has float coordination only.
    - RQ-D's chord design (tau = 0.85) leaves about 0.016 of room before boxes and cells when the band mass sits next
      to a two-sided residual cluster.
    - Adding RQ-B's heaviest-window two-point split for the residual brings the worst tested law back to K* (0.8279,
      room 0.027).
    - These are evidence, not claims.
  - RQ-D re-mirrored at 21:59 with the same CLAIMS (aa4587a5…) and PDF (3137370e…).
  - RQ-A, LOCKED_NOTE, COMMON and RQ-REF1 are unchanged. MAIN-6 is not filed. Its audit (A.37) is prepared from the
    21:40 and 21:57 entries and will be written when the filed text is in.
- 2026-10-22 22:51: store cycle (read 22:30 and 22:46–22:50).
  - RQ-D filed its third request at 22:45 (AUDIT_REQUEST c57b91c3…): Section 7 of MAIN_RESULT (tex 9498b44f…, PDF
    ee067424…), CLAIMS D21–D23 (ed68d60e…), STATUS 266a539e…, NOTES 5980500d…. It is audited in A.38: VALID. Copies:
    `audit/rqd/heavy_2230/` (as read at 22:30–22:44) and `audit/rqd/heavy_2247/` (as filed). The certificate data have
    not changed since 22:24.
  - RQ-A filed MAIN-6 at 22:37 (CLAIMS 4b4c4fc0…, AUDIT_REQUEST 0fb607ea…, STATUS 659e7922…, NOTES b50500e2…). Its
    audit, A.37, comes next. At 22:30 RQ-A's changes were text only: the U.9 wording in CLAIMS (3bdedd38…) and one word
    in MAIN_RESULT_K5.tex (389a1ce2…).
  - RQ-B (22:22–22:37) asks in AUDIT_REQUEST §7 (e1705191…) for the audit of Theorem 13.1, the light far region
    (MAIN_RESULT.md §13, 8de2ea98…). Cases 2 and 3 of its Lemma D are certified; case 1 (7,956 near-window boxes) is
    still running. Other files: CLAIMS 6aa55361…, STATUS 7a4ccca6…, NOTES cac70a3f… and MAIN_RESULT.tex 607bfae1….
    A.39 will audit this from the text and the certificate data, with my own verifier; case 1 will be added when it is
    filed.
  - RQ-C: FINDINGS 375040bf… and NOTES c7eb6d66… (22:07–22:12) contain float coordination only. CLAIMS 917614ba… and
    AUDIT_REQUEST f2a1ada3… are unchanged.
  - LOCKED_NOTE (312405c7…, 22:42) records the MAIN-6 filing as awaiting RQ-AUD and a referee. COMMON (b4e53572…) and
    RQ-REF1 (REFEREE 369c1cfb…) are unchanged.
  - My own hostile searches of the far region, which are evidence and not proof (`audit/far/`):
    - Many-atom weight ascent on fixed grids (`far_grid_ascent.py`, SLSQP with an analytic gradient; 48 atoms at step
      0.07 and 92 atoms at step 0.035, each plus a Gaussian). Over F the best value is 0.8266615, a K*-type law. Over
      F_light the best is 0.8198316, delta at 0.8166, which is delta_sqrt(2/3). No start comes near C_5.
    - First-order (KKT) check of K* = 0.8 delta_1.2978 + 0.0950 delta_-1.1008 + 0.1051 delta_0.85- by exact
      enumeration (`far_kkt_check.py`): E = 0.8266648118, and the first variation is nonpositive off the band. This
      agrees with RQ-C C18.
    - Free-position search with 5 atoms plus a Gaussian over F (`far_hostile6.py`, 320 starts, 35 min): the best
      value is 0.8266615 at 0.8 delta_1.2966 + 0.104 delta_0.85- + 0.096 delta_-1.101. The 6-atom run and the F_light
      runs are still going.
      - I restarted these runs with `OPENBLAS_NUM_THREADS=1` and 7 workers after numpy threads oversubscribed the
        cores (load 62).
- 2026-10-22 22:58: A.37 (RQ-A MAIN-6) written: VALID, NEW.
  - The filed tex (fc7dc6a1…) differs from my pre-audited 21:27 draft (5c2fc7da…) in six places, none of them in the
    mathematics.
  - The 106 data files match `k5_MD5SUMS.txt` (918eb069…) in the store and in my copy, so my full run of 21:29
    applies to exactly the filed data.
  - RQ-A's recorded verifier and negative tests agree with my counts.
  - Files are in `audit/rqa/k5_filed_2240/`.
- 2026-10-23 01:05: store cycles (read 23:05, 00:04–00:05, 00:34 and 00:59), compared with the 22:51 entry.
  - **RQ-B filed Theorem 13.1 in full.** Case 1 finished at 23:20, AUDIT_REQUEST §7 was updated at 23:28, and the
    files are dated 23:39.
    - New versions: CLAIMS 9de8c9c5… (F18), AUDIT_REQUEST 8baa91a7…, MAIN_RESULT.md b47f2945…, tex e4193842…, PDF
      a6901915…, STATUS 6be8ef66… and NOTES d57ec38d…. The certificates are in `numerics/cover_final/`.
    - Audited in A.39: VALID.
    - Copies: `audit/rqb/light_2305/` (cases 2–3, 23:05) and `audit/rqb/nsplit_0005/` (case 1 and the filed texts).
    - A.19's f1 is still open: rq/CLAIMS line 178 still reads "0.38815"; the correct value is 0.388146.
    - The stamps of this filing are not later than its file times.
  - **RQ-A applied A.37's r1** (23:04–23:06; copies in `audit/rqa/k5_r1_2306/`).
    - New versions: MAIN_RESULT_K5.tex 5b13f960…, .md adb359aa…, .pdf 1928ab29…, CLAIMS 07d8765b…, AUDIT_REQUEST
      35c783bc… and `outputs/k5_stats.txt` e4fa983a….
    - The tex diff is the Table 1 caption, Remark 4 and the status item. The new heights, 2,017 / 809 / 1,348 / 129
      with 2,286 nested, are my counts. k5_stats gains one line with the same numbers. The new sentence of Remark 4
      (height three exactly for the 129 boxes with six-coordinate pieces) holds box by box (`a37c_k5_r1_check.py`).
    - Text only: A.37 stays VALID, and r1 is settled (addendum in A.37).
    - STATUS e741bf25… (00:02), then 5c1fe91d… (00:30), and NOTES 836e6efb…, then 9e3faff3…, are coordination only.
      They say that the referee scope of links 5 and 6 includes A.30 and A.32.
  - **RQ-D (23:20–00:28): text only.**
    - New versions: CLAIMS b9b3d0d9… (status labels "A.34 VALID" and "A.38 VALID"), AUDIT_REQUEST 6308050f…
      (addendum 23:25), tex 212c6f23… and PDF fed00af2….
    - Section 7.4 gains a "Certificate files" paragraph, which settles A.38's r3. Its last paragraph is replaced by
      "The design's value (not part of the proof)". That paragraph shows that the certified cell bound is at least
      J(K), which I checked: Lemma 23, (c) and Jensen. It also gives float searches with J up to 0.8390.
    - STATUS 9b76fc26… and NOTES a3583dbf…: the referee scope of RQ-D's links is MAIN_RESULT Sections 2–7.
    - Nothing in Lemmas 18–24, Theorem 16, Corollary 17, the verifier or the certificates has changed, so A.38 stays
      VALID (addendum in A.38).
  - **RQ-C: nothing to audit.**
    - CLAIMS 917614ba… changed to da9ff390… (C21, NUMERICAL: split-bound designs for the far region). It changed
      again to 4b1e22a4… at 00:32: one C21 paragraph on HiGHS tolerances.
    - NOTES c7eb6d66… changed to 193455c3…. AUDIT_REQUEST f2a1ada3… and FINDINGS 375040bf… are unchanged.
    - RQ-C re-mirrored its whole tree at 00:32–00:36, mostly with the same md5s. MAIN_RESULT_K4.tex is still the
      A.21b version (093d3b68…).
    - The tree also holds older copies of five RQ-B far-region programs under `RQ-C/rqb_far/` (00:36). None matches
      the md5 of a filed RQ-B script, and no RQ-C claim cites them. I did not read them.
  - **LOCKED_NOTE**, 312405c7… then 79b42ae7… then 54e43e23…, has three new entries:
    - 16:10 PT: RQ-REF2 launched for MAIN-5 and MAIN-6;
    - 16:36 PT: F_light reported complete, pending A.39;
    - 17:08 PT: RQ-REF3 planned for the chain U.3 + A.28 + A.34 + A.38 + A.39 once A.39 is VALID.
  - Unchanged: COMMON (b4e53572…) and RQ-REF1 (REFEREE 369c1cfb…). There is no RQ-REF2 directory in the store.
  - **My hostile far-region searches finished** (`audit/far/outputs/far_hostile6_*_na6*`, 6 atoms plus a Gaussian,
    free positions; evidence, not proof):
    - over F, 320 starts in 42 min: best 0.8266615, the K*-type law
      0.8 delta_1.2966 + 0.104 delta_0.85- + 0.096 delta_-1.101;
    - over F_light, 240 starts in 25 min: best 0.8198316, at delta_0.8166 (= delta_sqrt(2/3)).
    - No start reaches C_5.
- 2026-10-23 01:05: A.39 (RQ-B Theorem 13.1, the light far region) written: VALID, NEW. With it the chain for Conjecture S
  is complete at audit level. The links A.26, A.28, A.34, A.38 and A.39 await a referee (RQ-REF3).
- 2026-10-23 01:05: store re-check before publishing.
  - **RQ-REF2 reports** (`RQ-REF2/REFEREE.md` bd18da81…, written 01:05): MAIN-5 (tex 158934d2…) and MAIN-6 (tex
    5b13f960…) VALID, no fixes. Its own code (gmpy2, Bernstein subdivision, face-splitting coverage) on the data
    lists 3a8fd366… and 918eb069…. Every count agrees with A.25 and A.37. So A.25 and A.37 now meet the LOCKED_NOTE
    criterion (block at the top).
  - **LOCKED_NOTE** c054a4b5… adds 18:02 PT (RQ-REF3 scope: U.3, the U.1 inputs A.7a and A.10a, A.28, RQ-D
    Sections 2–7 with A.30, A.32, A.34, A.38, and A.39 with Lemma S5) and 18:05 PT (RQ-REF2 VALID; R(q) on
    [1-sqrt(5/6), sqrt(5/6)] reported to Paata).
  - RQ-A STATUS d7ee76f5… and NOTES 30a1be9c… (01:01): coordination only. They give the same RQ-REF3 scope and note
    that my store copy was unchanged since 23:00 while A.39 was in progress.
- 2026-10-23 01:29: store cycle (read 01:20), literature re-check, the A.27 novelty correction and A.40.
  - **RQ-C (01:06–01:15) filed a reproduction report with no new claim.**
    - New versions: AUDIT_REQUEST 07a808bc… (was f2a1ada3…), FINDINGS a1654cd5… (was 375040bf…), NOTES 118e7d99…
      (was 193455c3…) and README 1a3a1580…. CLAIMS is unchanged (4b1e22a4…). Copies are in `audit/snapshots/s0120/`.
    - Its `numerics/chain_check.py` rederives the coverage and the seams, but the leaves are decided by RQ-B's
      `far_verify` and RQ-D's `check_cell`. So it is independent of RQ-B and RQ-D only in coverage and seams. I did
      not read its code.
    - Its counts agree with mine. F_light cases 1–2: 7,956 and 60 roots, 8,481 and 1,212 leaves, maxima 0.85499698
      and 0.85495525 (A.39). F_heavy: 436 boxes, 1,237 cells, worst 0.854883 (A.38).
    - F_light case 3: RQ-C counts 516 roots and 1,186 leaves; I count 537 roots and 1,273 certificates.
      - RQ-C stops at s <= 20, since m1 < A/4 + 3 theta/4 = 1.0225. My verifier follows Lemma E's text, s < 24.
      - I recounted the root rule by hand: s = 0..20 give 516 cells and s = 21..23 give 9 + 7 + 5 = 21.
      - RQ-B's other 87 records lie under those 21 roots, and 1,186 + 87 = 1,273.
      - Lemma E's "s < 24" is true but more than needed (RQ-C's item o1). A.39 is not affected.
    - Band: RQ-C's rerun of RQ-D's `verify_bandstar.py` reproduces RQ-D's 1,339 squares and 14,894,034 boxes. My
      verifier in A.34 used its own subdivision (1,303 squares, 13,083,096 boxes).
    - Its float semantic tests of 01:14 raised no flag on 6,000 heavy laws or 4,660 light laws. The largest values
      of E|Z_K| were 0.82582 (heavy) and 0.81983 (light), consistent with my searches (0.8266615 and 0.8198316).
    - Item t1 concerns a docstring in RQ-B's `cover_common.py`, which I do not read. RQ-C's reading of Lemma D
      ("> 1/4" and "<= 1/4") is the one I audited.
    - It removed `RQ-C/rqb_far/` at 01:15. These are the stale copies noted in the 01:05 entry.
  - Unchanged since 01:05:
    - RQ-A: CLAIMS 07d8765b…, STATUS d7ee76f5…, NOTES 30a1be9c….
    - RQ-B: CLAIMS 9de8c9c5…, STATUS 6be8ef66…, NOTES d57ec38d….
    - RQ-D: CLAIMS b9b3d0d9…, STATUS 9b76fc26…, NOTES a3583dbf….
    - COMMON b4e53572…, RQ-REF1 369c1cfb… and RQ-REF2 bd18da81….
    - A.19's f1 is still open (rq/CLAIMS line 178 reads "0.38815").
  - **LOCKED_NOTE** c054a4b5… changed to 2dc77e79… (file time 01:22 UTC; copy in `audit/snapshots/s0120/`). It adds
    the entry 18:24 PT: A.39 VALID at 01:05 UTC, the whole chain VALID at audit level, and RQ-C's cross-check found
    no gap. RQ-REF3 (bc-9e55b4c7-6179-53a5-bd6c-8bf60e3906e9) was launched to referee the chain, and Conjecture S
    for all q goes to Paata once RQ-REF3 rates it VALID. The entry's stamp (18:24 PT = 01:24 UTC) is two minutes
    after the file time. There is no RQ-REF3 directory in the store yet.
  - **Literature re-check** (web search at 01:15 and 01:25 UTC). The queries covered the sharp biased L1–L2
    Khintchine constant, the q -> 0 value sqrt(2/e), the level-one weight on the biased cube, and Stone's comparison
    results.
    - Nothing determines R(q) beyond BF3's [3/8, 5/8].
    - The new hits are unrelated: arXiv:2511.07739 (Fourier entropy on the biased cube), 2504.02593 (level-1
      weight), 2410.09607 (vector-valued concentration on the biased cube), and 2610.07526, 2606.30411 and
      2503.07001 (unbiased Rademacher sums).
    - As at 10:48, a search-engine summary reads Ivanisvili–Stone (1.10) as the general supremum. Their text takes
      the sup over a_j^2 = a_j and only assumes that R(p) equals it.
  - **A.27's novelty is corrected to KNOWN.** Its statement is Stone's equal-coefficient theorem (details in A.27).
  - **A.40 written: VALID at audit level, NEW.**
- 2026-10-23 02:00: store cycle (read 01:44). There is no new PROVED claim. RQ-REF3 has posted a first report, and A.40 has
  a hostile-search addendum. Copies of the new files are in `audit/snapshots/s0144/`.
  - **RQ-A (01:33–01:41): status texts only, nothing to audit.**
    - RQ-A put the referee verdicts into the status items of five write-ups. I diffed each new .tex against the
      refereed version I hold. Only the status item changed (6–7 diff lines each):
      - K2: 1cb83e45… -> 280e80ed…;
      - K3: 9f20afc7… -> 00720a0c…;
      - K3B: 53aa11d1… -> efa33947…;
      - K4: 158934d2… -> 01d91659…;
      - K5: 5b13f960… -> bc42dd0f….
    - The dates and audit ids quoted in those items (A.14 10:37, A.18 12:41, RQ-REF1 15:38, RQ-REF2 01:05) are
      correct. MAIN_RESULT.tex is unchanged (6816732f…).
    - CLAIMS 73087f42… changes only status lines; its MAIN-6 and U.9 text is what A.37 and A.35 audited. The U.1–U.3
      text (from "- U.1 PROVED" to just before "- U.4", 3,082 bytes) is byte-identical to CLAIMS 3a8a0c64…, the
      version A.26 audited, and to all 9 later copies I hold, as RQ-A's NOTES say.
    - CLAIMS also remarks that with MAIN-6, ID* is needed only with C = C(q6) = 0.8559844891… and the support bound
      becomes A'(q6) = 1.5146. Arb (200 bits) gives C(q6) = g(5 s6) = g(6 s6) = 0.85598448917381538818 and
      A'(q6) = 1.5145483763172 < 1.5146. The chain does not use this remark; A.40 uses C_5 on (0, q5].
    - AUDIT_REQUEST 11c31b3b…, STATUS 5e96c47f… and NOTES 155b68c3… are coordination only.
  - **RQ-D (01:30): coordination only.** CLAIMS d5ab7dac…, STATUS e3394c0a… and NOTES f89c1f01… name RQ-REF3 as
    the referee of A.30, A.32, A.34 and A.38, record A.39, and file no new claim. MAIN_RESULT.tex is unchanged
    (212c6f23…).
  - **RQ-REF3 (01:42): first report, IN PROGRESS** (`REFEREE.md` c2525146…, README 3d27651a…).
    - Links 1 (the reduction, i.e. A.26 with A.7a and A.10a) and 2 (A.28) are VALID.
    - Links 3 (RQ-D Sections 2–7) and 4 (RQ-B Section 13): hand checks done, certificate re-verification running.
    - Its coverage table is the one in A.40 step 4: V >= 4/5, then 1/2 <= V < 4/5, then V < 1/2, with theta = 17/20
      and A = 77/50.
    - Its constants (`logs/constants.txt`, 27 PASS) agree with my J3–J5: C_5, C_4 < C_5 < C_6, A'(q5) and the
      margin 171/200 < C_5.
    - It refereed the documents I audited: RQ-B tex e4193842…, RQ-D tex 212c6f23… and RQ-C CLAIMS 4b1e22a4….
    - **Update at 01:58 (re-read 02:00; REFEREE.md 7514d22a…, `logs/heavy_verify.txt` c35c35ac…; copies in
      `audit/snapshots/s0200/`): the Theorem 16 certificates are VALID.**
      - Its own `heavy_verify.py` ran 01:56:55–01:57:13 on the certificate files whose md5s A.38 used.
      - Every count equals mine in A.38. The 436 boxes tile the rectangle: 280 are certified and 156 are empty.
        There are 1,237 cells, one of them Farkas-empty, and the worst bound is 0.8548832, in box [6, 3, 6, 39],
        cell (2, 3, 1).
      - Its per-level split, 96/71/66/44/3 certified and 134/12/6/3/1 empty for d = 0..4, is the split of the
        records my A.38 verifier accepted. My verifier does not print it; I counted it from RQ-D's certificate files
        at 02:01.
      - Its bounds are below RQ-D's stored floats by 2.4e-13 to 1.2e-9.
      - All 8 negative controls are rejected. Lowering the target by 1e-4, 3e-4 and 1e-3 makes 0, 9 and 50 boxes
        fail.
      - Theorem 13 (A.34) and link 4 (A.39) are still in progress.
    - There is no chain verdict yet, so the criterion block is unchanged.
  - **02:02 changes (re-read 02:05; copies in `audit/snapshots/s0200/`).**
    - LOCKED_NOTE bf2916eb… adds the entry 19:02 PT (02:02 UTC, the file time). It records RQ-REF3's interim
      verdicts as above and says they are "Not reported (interim)".
    - RQ-A's NOTES e34ed3f2… and STATUS ea761920… record the same interim report. They also say that RQ-A's
      CLAIMS §U uses the closed thresholds. I checked this in CLAIMS 73087f42…: line 250 defines
      lambda+-_theta = int over [theta, oo) and (-oo, -theta], and line 268 counts #{i : beta_i >= theta sqrt(s)}.
  - Unchanged since 01:20:
    - RQ-B rq/: CLAIMS 9de8c9c5…, AUDIT_REQUEST 8baa91a7…, MAIN_RESULT tex e4193842….
    - RQ-C: CLAIMS 4b1e22a4…, AUDIT_REQUEST 07a808bc…, NOTES 118e7d99….
    - LOCKED_NOTE 2dc77e79…, COMMON b4e53572…, RQ-REF1 369c1cfb… and RQ-REF2 bd18da81….
    - A.19's f1 is still open.
  - Own hostile checks: the A.40 addendum (a40b, a40b2 and a40c all PASS; exact spot check PASS).
- 2026-10-23 02:23: store cycle (read 02:07–02:10 and 02:19). There is no new PROVED claim and no new audit request. Five timer
  notifications (fired 22:30–01:30 UTC) arrived together at 02:07, and this entry covers them.
  - **Changed: RQ-D STATUS only (written 02:16:15; 127572d2…, copy in `audit/snapshots/s0219/`). Status text, nothing
    to audit.** It records RQ-REF3's 01:58 interim report and says that the refereed files (tex 212c6f23… and
    certs_v1_r0..r4) are unchanged. Its figures agree with A.38: worst bound 0.8548832 in box [6, 3, 6, 39], cell
    (2, 3, 1). Nit: its stamp "Last update: 2026-10-23 02:17 UTC" is about 45 s later than the file's write time.
  - Unchanged since the 02:00 entry:
    - RQ-A: CLAIMS 73087f42…, AUDIT_REQUEST 11c31b3b…, STATUS ea761920…, NOTES e34ed3f2…, K4 tex 01d91659… and K5
      tex bc42dd0f….
    - RQ-B rq/: CLAIMS 9de8c9c5…, AUDIT_REQUEST 8baa91a7…, MAIN_RESULT.md b47f2945…, tex e4193842…, PDF a6901915…,
      STATUS 6be8ef66… and NOTES d57ec38d….
    - RQ-C: CLAIMS 4b1e22a4…, AUDIT_REQUEST 07a808bc…, NOTES 118e7d99… and FINDINGS a1654cd5….
    - RQ-D: CLAIMS d5ab7dac…, AUDIT_REQUEST 6308050f…, tex 212c6f23… and NOTES f89c1f01….
    - RQ-REF3 REFEREE 7514d22a… (no chain verdict yet, so the criterion block is unchanged), LOCKED_NOTE bf2916eb…,
      COMMON b4e53572…, RQ-REF1 369c1cfb… and RQ-REF2 bd18da81….
    - Still open: A.19's f1 (RQ-B CLAIMS line 178 still says "0.38815"; the value is 0.388146) and A.39's r1–r4
      (text).
  - **Own checks: does the chain still rest on exactly what was audited? Both PASS.**
    - Data (`audit/chain/a40d_data_integrity.py`, run 02:10, A40D_INTEGRITY_PASS). Every file that a chain link's
      computer step depends on is byte-identical in the store to the copy behind my verdict:
      - A.6: the 9 files of `audit/rqa/rqa_data/MD5SUMS` in RQ-A/outputs.
      - A.11, A.14, A.18, A.25 and A.37: RQ-A's k2, k3, k3b, k4 and k5 MD5SUMS lists still have the md5s recorded in
        the verdicts (c6184a11…, 613f681e…, 2074adcc…, 3a8fd366… and 918eb069…). All of their 117, 98, 37, 81 and
        106 entries match, and none is missing.
      - A.38: certs_v1_r0..r4 equal my copies in `audit/rqd/heavy_2230/plus_cert/`.
      - A.39: nsplit_D14, chord_D14 and light_vl025_D18 equal my copies in `audit/rqb/`.
      - The other links read no solver data. A.26 (with A.7a and A.10a) and A.28 are proofs on paper, and A.34's
        computer step is my own subdivision (1,303 squares, 13,083,096 boxes).
    - Texts.
      - RQ-D tex (`audit/chain/a40e_rqd_text_seam.py`, a section-wise diff). Sections 1–6 of the current 212c6f23…
        are byte-identical to those of bba5c599… (A.34); the `\end{document}` line now follows Section 7. From
        4df86775… (A.32) to now, Sections 1–3 and 5 are byte-identical. Section 4 only gained Lemma 7(c) and
        (O1)–(O4), which A.34 audited, and no line of it was removed. Section 7 differs from 9498b44f… (A.38) only by
        the two paragraphs of the A.38 addendum (01:05). The title and abstract changed as well.
      - RQ-C C15 (A.28): the statement and proof are byte-identical to CLAIMS 3b854357…. Only the status at the end
        of the heading changed, from "Audit requested 22 Oct 15:40 UTC" to "RQ-AUD: VALID, NEW (A.28, 16:14 UTC, no
        fix)".
      - RQ-B (A.26): §1–4 of MAIN_RESULT.md (14,459 bytes) are byte-identical to 0ff2462b…, the version of the A.26
        addendum. I keep no copy of that version's tex (4a5770df…), so I re-read §2–3 of the current tex instead:
        Lemma 2.1, Theorem 3 and Theorem 3.4 (a)–(e), with the closed thresholds and k±. They match A.26.
- 2026-10-23 02:29: RQ-REF3 update (read 02:24; `REFEREE.md` 470481ec…, written 02:23:40 UTC; copies in
  `audit/snapshots/s0224/`). **Link 4 (RQ-B §13, A.39) is VALID.**
  - There are 5 new logs. `light_verify_{chord,light,nsplit}.txt` ran 02:13–02:14 UTC on files with the md5s A.39
    used, and each ends "ALL CHECKS PASSED". `light_controls.txt` ends "ALL CONTROLS BEHAVE AS EXPECTED", and
    `light_semantic.txt` (evidence) finds no violation in 4,500 samples. The older logs and the README are unchanged.
  - Its counts and worst bounds equal mine case by case; see the A.39 addendum.
  - Its one remark is about the robustness of RQ-B's checker, and it is not triggered by the data. I checked that my
    own verifier enforces the list lengths, and added 35 controls (a39o, all PASS). A.39 stays VALID.
  - Links 1, 2 and 4 now meet the LOCKED_NOTE criterion, and the block under the ledger lists them. Link 3 (RQ-D
    Sections 2–7) is still in progress, so the chain (A.40) has no referee verdict yet.
  - The rest of the store is as at 02:19.
- 2026-10-23 02:55: store cycle (timer of 02:15, read 02:41; copies in `audit/snapshots/s0241/`). There is no new PROVED claim.
  My own check this cycle re-did A.6 on the refereed text and found one slip in the appendix (f3, text only; see the
  A.6 addendum).
  - **RQ-A (02:32): coordination only.** AUDIT_REQUEST 76c25498…, STATUS 04bece9f… and NOTES_FOR_TEAM 727b9499…
    record RQ-REF3's 02:23 report and my 02:00 and 02:29 entries.
    - Their quotes of my 02:00 entry are accurate. They cite "status texts only, nothing to audit", the dates and
      audit ids, U.1–U.3 being byte-identical to the text A.26 audited, CLAIMS lines 250 and 268, and C(q6) and
      A'(q6).
    - The worst case-1 bound they quote, U = 0.8549969805515450 at N/k35/i0j6 (3.02e-6 below 171/200), is A.39's
      maximum. Their nsplit_D14.jsonl.xz 0883b5d9… is the file A.39 verified.
  - **RQ-A's NOTES say that the k = 30..35 lines of that file are byte-identical to RQ-A's own run. That is right**
    (`audit/rqb/a39p_rqa_k30_35_bytes.py`, A39P_PASS).
    - RQ-A's `certs.jsonl.xz` (f04f8435…, as in its OUTPUT_MD5SUMS) has 1,653 lines. As a multiset they equal the
      1,653 lines of nsplit_D14 with k in 30..35, though in another order. The counts for k = 30..35 are 236, 251,
      251, 281, 302 and 332.
    - Its results file (92ff2f63…) gives U = 0.854996980551545 at N/k35/i0j6, the largest U in it.
    - Its 5 'empty' results (N/k33/i0j5/q33, N/k34/i0j4/q33, N/k34/i0j5/q33, N/k35/i0j4/q33 and N/k35/i0j5/q33) are
      the only certificates in the file with no 'phi'. So they are A.39's 5 empty leaves.
    - Who computed a certificate does not matter for A.39, which verified every line itself.
  - **LOCKED_NOTE 7b361bd0… (02:33)** adds the 19:33 PT line on link 4. It matches RQ-REF3's report (10,966
    certificates re-verified; the remark on multiplier-list lengths) and says "Not reported (interim)".
  - **The md companions of RQ-A's K2–K5 changed only in status.**
    - K2 f25f8f9b…, K3 a15b8952… and K3B 88bf9116… differ from the md files RQ-REF1 refereed (ca0c10a7…, 6427c41c…
      and 2c755f9e…) only in the header status paragraph and the status item of the Remarks. The dates and ids they
      quote (A.11 08:52, A.14 10:37, A.18 12:41, RQ-REF1 15:38) are correct.
    - K4 8b1a75f2… and K5 0f6de67f… are unchanged since 01:44. They differ from my 18:02 and 23:07 copies in the
      status items and, for K4, in the passages c1–c2 that A.25's 21:19 addendum covers.
  - Everything else is unchanged since my last reads (02:19–02:24), including RQ-A's CLAIMS, MAIN_RESULT.tex and .pdf
    and the K2–K5 tex. I now also track RQ-A SOTA a3b7d634…, RQ-A MAIN_RESULT.md 6cdb60b2…, RQ-B SOTA fea14884… and
    RQ-C MAIN_RESULT.md 2ba87a80….
  - Still open: RQ-REF3's link 3 (RQ-D's band Theorem 13), A.19 f1 (RQ-B CLAIMS line 178 still says 0.38815), A.39
    r1–r4, and now A.6 f3.
- 2026-10-23 03:02: own check. I recomputed the checkable figures in the text of link 3, RQ-D's Sections 5–7
  (tex 212c6f23…), with my own code (a34e).
  - The store is unchanged since 02:41 apart from RQ-D's STATUS (706d7b8c…, written 03:02:22 UTC; read 03:02; copy
    `audit/snapshots/s0241/RQ-D_STATUS_0302.md`). It adds one line saying that RQ-REF3 rated link 4 VALID at 02:23
    and that Theorem 13 is the only part of the chain still being re-verified, which agrees with LOCKED_NOTE. Its
    "Last update: 03:03 UTC" is about 40 s ahead of the write time; this is the same minute-rounding nit as at 02:23.
  - There is one slip, in a remark: tex line 617 gives the range where g(Λ) > C_5 as 0.4463 < Λ < 0.5599, and the
    upper end is 0.5579. It is A.34 f1, text only, and A.34 stays VALID; see the A.34 addendum.
  - The other figures agree, including C_5, the controls paragraph, the bounds of line 769 and the location of A.38's
    worst bound.
  - RQ-D's CLAIMS D13 (NUMERICAL) states the Dirac range inexactly (A.34 r3).
- 2026-10-23 03:30: store cycle (read 03:15, re-checked 03:30; copies in `audit/snapshots/s0315/`). RQ-REF3's report
  is FINAL, and RQ-A applied A.6 f3. There is no new PROVED claim.
  - **RQ-REF3 is FINAL** (REFEREE 6ac713c0… and README 74158f98…, written 03:09:02; LAST_MIRROR dbefa43c…). The
    overall verdict is VALID: Conjecture S holds for all q in (0, 1), with RQ-A MAIN-1..6 on [q6, 1-q6] taken as
    given.
    - Link 3 is now VALID. Its Theorem 13 rests on RQ-REF3's own cover (1,212 squares, 9,077,343 leaf boxes, every
      square certified), and its Theorem 16 on RQ-REF3's re-check of RQ-D's certificates (01:58).
    - The verdicts on links 1, 2 and 4 are as in the report of 02:23 (470481ec…, copy in `audit/snapshots/s0224/`).
    - So A.40 meets the LOCKED_NOTE criterion. The criterion block under the ledger now lists A.40 with all its
      links, and the ledger rows of A.26, A.28, A.30, A.32, A.34, A.38 and A.40 record RQ-REF3's verdicts.
  - **LOCKED_NOTE 410b562f… (03:10:04) adds two lines, and both are accurate.**
    - The 20:08 PT line records A.6 f3 as a rounding slip, fixed in the text, with Theorem 1 unaffected, to be
      mentioned in the final summary to Paata.
    - The 20:10 PT line records RQ-REF3's FINAL VALID, the chain as doubly verified with A.40 and reported to Paata,
      and RQ-REF3's two remarks.
    - Their stamps (03:08 and 03:10 UTC) agree with the file times: RQ-A's files 03:08:15–03:08:21, RQ-REF3's
      03:09:02 and LOCKED_NOTE's 03:10:04.
  - **RQ-A (03:08): A.6 f3 applied** (tex 38b69350…, PDF 5c0ac2ef…, md bb6da13b…; AUDIT_REQUEST 36618b82…, STATUS
    5fd5c201…, NOTES 87039e41…, CLAIMS ac1b39c0…, LAST_MIRROR 880f866c…).
    - The tex and md differ from the refereed versions only by the figure and the md's new header paragraph, and
      every figure holds as a bound (a6g, A6G_PASS; A.6 addendum 2). A.6 is VALID with no open fix.
    - The CLAIMS change is a status note on MAIN-1 only.
    - RQ-A's NOTES say that RQ-REF3's report was unchanged since 02:23. That was true when RQ-A wrote (03:07);
      RQ-REF3's FINAL report followed at 03:09.
  - **Own check: the quoted figures in the texts of links 1, 2 and 4** (`audit/chain/a40f_chain_text_figures.py`,
    output `audit/chain/outputs/a40f_chain_text_figures.txt`, A40F_PASS, 79 PASS, 2 s). With link 3's figures (a34e,
    03:02), every quoted decimal in the chain's texts has now been re-checked.
    - RQ-B, tex e4193842… (Sections 3, 4 and 13): every quoted constant rounds or truncates as stated. The table of
      Section 13 matches the three certificate files, and my copies of them are byte-identical to the store's. In
      case 1, 7,922 roots are certified at depth 0, and the other 34 are split into 539 + 5 cells at depth 1, of
      which the 5 are split into 20 at depth 2. At the worst leaf, 171/200 − U = 3.019448e-6.
    - RQ-C C15 (CLAIMS 4b1e22a4…) is byte-identical to the 15:53 text that A.28 audited. A'(0.05), A'(q6), A'(0.1),
      A'(q5), A'(q4) = 1.46976, 1.51455, 1.53085, 1.53804, 1.57599 are as stated, and so are a = 1.49690 for k = 4
      and 99/70 = 1.41429.
    - One display remark, no fix: C15(g) ends "A ≥ 1.538 for q ≤ q_5, A ≥ 1.576 for q ≤ q_4", which gives A'(q5) =
      1.538044 and A'(q4) = 1.5759927 to three places, the first truncated and the second rounded up. The chain uses
      A = 77/50 > A'(q5), which is checked exactly (A.28, A.40, RQ-REF3).
    - RQ-A U.1–U.3 (CLAIMS ac1b39c0…) are byte-identical to the 16:47 text (a26d). Their decimals and the gap point
      q* = 0.13397376 (q4 − q* = 8.36e-7) are as stated.
  - Everything else is unchanged since 02:41–03:02.
  - Still open, all text only: A.19 f1 (RQ-B CLAIMS line 178 still says 0.38815; correct 0.388146), A.39 r1–r4,
    A.34 f1 (RQ-D tex line 617, 0.5599 should be 0.5579) and A.34 r3 (RQ-D CLAIMS D13). A.6 f3 is closed.
- 2026-10-23 03:41: own check, a literature re-check for A.40 (see its last addendum). The novelty is unchanged:
  nothing found determines R(q) beyond BF3's [3/8, 5/8].
  - A preprint of 2026-10-21 by T. S. Tomar (Zenodo, doi 10.5281/zenodo.23533350, not refereed) claims that the L1
    Poincaré constant of the cube is sqrt(pi/2). It treats R(p) as unknown.
  - That claim bears on the application in Ivanisvili–Stone's Remark 1.3. With A.40, their route gives
    C <= int R(p(theta)) d theta = 1.4217818 (my certified value, a40g), which the preprint's sqrt(pi/2) would
    supersede.
  - **RQ-A (03:33): coordination only** (CLAIMS 67c3f27b…, STATUS b233225d…, NOTES 047ab04e…, LAST_MIRROR d44179cb…;
    copies in `audit/snapshots/s0340/`). There is no new claim.
    - STATUS and NOTES record Conjecture S as auditor and referee VALID and reported to Paata (03:10 UTC), and A.6 f3
      as closed. They quote my 03:30 entry ("A.6 is VALID with no open fix"), RQ-REF3's FINAL report (9,077,343
      boxes for Theorem 13, and its two remarks) and LOCKED_NOTE (20:08 and 20:10 PT) accurately.
    - CLAIMS gains a status paragraph at lines 249–254 and nothing else: without those six lines it equals the 03:15
      file byte for byte. U.1–U.3 are still the text that A.26 audited (section md5 71c5186b, as in a40f).
  - The rest of the store is unchanged since 03:30 (re-checked 03:41).
- 2026-10-23 03:57: own check, a direct search on the central range (A.40, last addendum; a40h, evidence only). At 38
  rational points of [q5, 1/2] and above 1/2, including q_k ± 1e-6 at each seam k = 2..5, no vector exceeds M(q):
  the best ratio is M (1 + 1.6e-13), always at +-OR_N, and the best non-equal local maximum found is 0.97495 M.
  - **RQ-D (03:50): coordination only** (CLAIMS e1a82830…, STATUS 141f2e4d…, NOTES fd73a4ef…, README e197e622…,
    LAST_MIRROR 5f124f42…; copies in `audit/snapshots/s0355/`). There is no new claim. AUDIT_REQUEST (6308050f…) and
    MAIN_RESULT.tex (212c6f23…) are unchanged.
    - CLAIMS gains a referee-status paragraph, and three section headings change. Two (the ID* band lemma and the
      heavy far region) now say "refereed VALID by RQ-REF3", and the heading of the C5 band lemma says "not
      refereed". Nothing else differs from the 01:31 file.
    - Its list matches RQ-REF3's link-3 section: D1, D2, D6–D10 and D16–D23, that is Lemmas 1–4, 6–8, 12 and 18–24,
      Proposition 9, Theorems 13 and 16, Corollaries 14, 15 and 17. Theorem 10 and Corollary 11 (D11, D12) are not
      refereed.
    - STATUS quotes RQ-REF3's Theorem 13 counts (1,212 squares, 9,077,343 leaf boxes) and the 03:10 UTC report to
      Paata accurately.
    - README marks Theorems 13 and 16 "refereed VALID" and says the lemmas of Sections 2–4 were refereed. In the tex
      those are Lemmas 1–4, 6–8 and Proposition 9, all in RQ-REF3's hand checks; Theorem 10 and Corollary 11 are in
      Section 5. Its remark that C_6 = 0.8559845 suffices on the light part, given MAIN-6, is the consequence stated
      in A.38.
    - STATUS and NOTES take up RQ-REF3's robustness remark 2. RQ-D will record every leaf box of the Theorem 13 run
      (box, method, option, h) and add a replay checker, in new files only. I will check the record when it is
      posted.
    - The refereed files have the md5s recorded in A.38: `verify_bandstar.py` b5b55cee…, certs_v1_r0..r4 (e23d52dd…,
      ee9307ee…, f5fe9a23…, 6d495261…, 3033710b…), tex 212c6f23… and PDF fed00af2….
    - Cosmetic: the "Last update" stamps of STATUS (03:52) and NOTES (03:53) are later than RQ-D's own mirror time,
      03:50:21 (LAST_MIRROR).
  - The rest of the store is unchanged since 03:41 (re-checked 03:57). Still open, all text only: A.19 f1,
    A.39 r1–r4, A.34 f1 and A.34 r3.
- 2026-10-23 04:03: store cycle (the timers of 03:00 and 03:45 were delivered together at 04:02). The store is unchanged
  since 03:57 (re-checked 04:02 and 04:03). The criterion block's A.40 bullet now lists a40g and a40h.
- 2026-10-23 04:51: store cycle (04:25–04:51). **RQ-D (04:22–04:25) posted the box-level record of the Theorem 13
  run, for RQ-REF3's remark 2. I replayed it leaf by leaf with my own verifier: VALID** (A.34, last addendum; a34f,
  a34g, a34h).
  - The new data are in `outputs/bandstar_cert/`, and there are two new scripts, recorded by md5 only. The refereed
    files are byte-identical: MAIN_RESULT.tex 212c6f23…, `verify_bandstar.py` b5b55cee….
  - Texts, with copies in `audit/snapshots/s0425/`:
    - CLAIMS fba092bb… adds one paragraph under D18 (lines 132–139); the status of D18 is unchanged.
    - AUDIT_REQUEST c31a9c0c… adds a note at the top (04:24, lines 6–41). Without it, the file equals 6308050f… byte
      for byte.
    - STATUS 1a72757d…, NOTES ad666fed…, README dce8b721… and LAST_MIRROR 99f5dd64….
  - What these texts say about the record agrees with my replay: the log of 1,676 squares equals the published one;
    1,339 certified squares, 7,874,211 leaf boxes and 426 slope certificates; the published counts per method; the
    80 hypotenuse squares.
  - RQ-D's three "points I would check first" all hold: the slope paths and r_eff, the (T3)/(T3K) pairing with
    (O5), and the (O3) and (O2) points.
  - The record's format is described only in the docstring of RQ-D's replay script, which I do not read. I read it
    off the data instead (see the addendum).
  - Own check, evidence only: a many-atom lattice search of ID*(C_5) (A.40, last addendum; a40i). No law with up to
    308 lattice atoms and a Gaussian part beats the few-atom optima. In F, heavy and light the best value stays at
    least 0.029 below C_5, and the band and all-K objectives stay <= 0.
  - LOCKED_NOTE (0a104a41…, 04:25:55, copy in `audit/snapshots/s0425/`) adds one line (21:25 PT). It records RQ-D's
    record and replay checker, with numbers that agree with my replay, and says that RQ-A is writing FULL_PROOF.pdf
    for Paata. I will check that write-up against the audited results when it is posted.
  - The rest of the store is unchanged since 04:03 (re-checked 04:51).
- 2026-10-23 05:42: store cycle (the timer of 04:30, delivered at 04:53). At 04:58 the store was unchanged since
  04:50, and RQ-A's FULL_PROOF.pdf was not posted.
  - **From 05:41 the shared store `/cursor/stores/bot/` reads as empty.** The FUSE mount is present, but `rq/` is
    gone; my own store is intact. A check at 05:25 printed no new files, which an empty store would also print.
  - As the original instructions require, I record this here. This entry is in git, and its mirror to `RQ-AUD/`
    waits until the store is readable again.
  - Own check, evidence only: the many-atom search of ID*(C_5) on the finer lattice of step 1/200 (A.40, last
    addendum; a40j). No law beats the few-atom optima, and the lattice optima approach the continuum few-atom
    suprema at the expected rate as the step halves.
  - Still open, all text only: A.19 f1, A.39 r1–r4, A.34 f1 and A.34 r3.
- 2026-10-23 06:00: the shared store still reads as empty (checked 05:43, 05:50, 05:59 and 06:00). This run's event
  log records nothing about it. The commits of 05:42 and 06:00 are pushed, and the mirror waits.
  - Own checks, evidence only: a40k and a40k2 (A.40, last addendum), the band and all-K objectives on the lattice of
    step 1/200. No flags; the band objective stays below 0 by about 0.15ρ. (Corrected at 06:09: those were not the
    band maxima, and the margin is at most 0.12ρ at ρ = 0.02; see the a40l addendum.)
- 2026-10-23 06:09: store cycle (the timers of 05:15 and 06:00, both delivered at 06:01). The shared store is still
  unreadable. `rq/` stats as a directory, but every file and folder in it returns "No such file or directory" (RQ-A/,
  COMMON.md and RQ-AUD/AUDIT.md among them; checked 06:01 to 06:09).
  - Own check, evidence only: a40l (A.40, last addendum), the first variation of ID*(C_5) at the Dirac arc in closed
    form. It shows that my band values of 04:51 and 06:00 (a40i, a40k, a40k2) are not the band maxima; the margins
    are corrected in those addenda. No positive value was found anywhere.
- 2026-10-23 06:12: integrity sweep of my own record. I matched every md5 that AUDIT.md cites next to a file name
  against the files in this repository.
  - Two slips, both in A.37's list of my programs: the lines for `a37_k5_table_check.py` and `a37_k5_hostile.py` gave
    the md5s of their outputs (af3d0736…, 2a1fd7fb…) as those of the scripts (5096b8fb…, e310898a…). Both lines now
    give both md5s. Each file has a single version in git, so nothing that was checked has changed.
  - Every other citation that can be checked here matches a file in this repository; for solver texts, that file is
    my snapshot copy. The few apparent mismatches were lists of md5s or sentences that name two files. Citations of
    store files of which I keep no copy cannot be checked while the store is unreadable.
- 2026-10-23 06:58: store cycle (the timer of 06:45). **The shared store is readable again**, first at my check of
  06:45. It was unreadable at every check from 05:41 on, and the 06:12 entry still found it so.
  - The contents are intact. Every tracked text has its 04:58 md5 except RQ-D's. `RQ-AUD/` still holds my mirror of
    04:52: all 1,280 files of the mirror manifest match, AUDIT.md 59e669e5… among them.
  - **RQ-D (05:35–05:36) applied A.34 f1, A.34 r3 and my line-652 remark.** They are text only and checked in the
    A.34 addendum of 06:58 (a34i). One new cosmetic remark, A.34 r4, is my own rounding slip in r3, which D13 copied.
    Copies are in `audit/snapshots/s0645/`.
  - Nothing else changed since 04:50 (re-checked 06:58):
    - RQ-A CLAIMS 67c3f27b…, AUDIT_REQUEST 36618b82…, STATUS b233225d… and NOTES 047ab04e…;
    - RQ-B rq/ CLAIMS 9de8c9c5…, AUDIT_REQUEST 8baa91a7… and STATUS 6be8ef66…;
    - RQ-C CLAIMS 4b1e22a4…, AUDIT_REQUEST 07a808bc… and NOTES 118e7d99…;
    - RQ-REF3 REFEREE 6ac713c0…, LOCKED_NOTE 0a104a41… and COMMON b4e53572….
  - RQ-A's FULL_PROOF.pdf is not posted.
  - The mirror of my commits of 05:42, 06:00, 06:09, 06:12 and 06:58 follows this entry.
  - Still open, all text only: A.19 f1, A.39 r1–r4 and A.34 r4.
- 2026-10-23 07:05: integrity sweep of my own decimals (a40m). A.34 r4 was a figure of mine written with an ellipsis
  although its last digit was rounded. So I checked every decimal that AUDIT.md writes with an ellipsis: 74
  occurrences, 51 distinct figures. Each is matched to the exact expression it denotes and checked in Arb
  (`audit/chain/a40m_ellipsis_sweep.py` 4cc1e0f6…, output `audit/chain/outputs/a40m_ellipsis_sweep.txt` eb2c1fcf…,
  A40M_PASS after the fixes).
  - Two more slips of the same kind, both mine and cosmetic.
    - In A.6's check of Remark 2, the q with 2τ(q) = G is 0.27014957830950…; I had written the rounding
      0.27014957830951.
    - In the A.34 addendum of 03:02, the upper root of g = C_5 is 0.5578588782…; I had written the rounding
      0.5578588783.
    - Both lines are corrected in place, with markers. What they support (the roundings 0.27015 and 0.5579) is
      unaffected.
  - Two figures are not leading digits, and both are flagged quotes: RQ-B's "0.11976…" (A.10 and A.35, rounded up)
    and RQ-D's D13 "1.3388682…" (A.34 r4).
  - Every other figure has correct leading digits, among them C_4, C_5, C_6, η_4–η_6, 2(C_5 − √(2/π)), A'(q5) and
    the ends of the Dirac arc.
- 2026-10-23 07:48: store cycle (the timer of 07:30).
  - At 07:37 the store was unchanged since 06:55. At 07:42 RQ-D had posted a text-only update (07:40–07:41) that
    applies A.34 r4. It is checked in the A.34 addendum of 07:48 (a34j, A34J_ALL_CONFIRMED); A.34 and A.38 stay
    VALID, and r4 is settled. Copies are in `audit/snapshots/s0742/`.
  - Nothing else changed (re-checked 07:47). No other file outside `RQ-AUD/` is newer than 06:55, and every other
    tracked text keeps its 06:58 md5. RQ-A's FULL_PROOF.pdf is not posted.
  - Own check a40n (`audit/chain/a40n_stamp_check.py` 80b10ff6…, output `audit/chain/outputs/a40n_stamp_check.txt`
    0c5a57ab…, committed at 07:07). No time stamp in AUDIT.md (as of 6fb41b1) is later than the commit that last
    wrote its line: 259 dated stamps and 7 correction markers, A40N_PASS.
  - Own check a40o (`audit/chain/a40o_ledger_open.py` 2d3a4326…). Every ledger row whose current verdict is VALID
    WITH FIXES must be on the latest "Still open" line, and every id on that line must be a ledger row.
    - On commit 1ffea75 it failed (`audit/chain/outputs/a40o_ledger_open_before.txt` d39e2d8e…). Rows A.2 and A.7a
      still read VALID WITH FIXES, although both fixes were posted on 2026-10-22: by 07:09 for A.2 (RQ-C C4(a)), and
      by 08:11 for A.7a (RQ-B Lemma 2.1, recorded in A.10).
    - Both rows are now re-rated VALID, with both proofs rebuilt again (A.2 and A.7 addenda). A.2 is not used by the
      A.40 chain. A.7a is an input of link 1, which always used the corrected Lemma 2.1, so the chain is unaffected.
    - After the re-ratings a40o passes (`audit/chain/outputs/a40o_ledger_open.txt` ea6daa05…).
  - New cosmetic remark A.7a r1 (A.7 addendum). RQ-B's C1 cites "MAIN_RESULT.pdf, Lemma 2.1", but the PDF numbers the
    lemma 3.1. The addendum maps the md numbers of the chain's RQ-B results to their PDF numbers.
  - Still open, all text only: A.19 f1, A.39 r1–r4 and A.7a r1.
- 2026-10-23 07:58: own checks between cycles.
  - a40n on commit 6e1ba54 (`audit/chain/outputs/a40n_stamp_check_6e1ba54.txt` 8e0cc3f0…): 276 dated stamps and 7
    correction markers, none later than the commit that last wrote its line; A40N_PASS.
  - a40p (`audit/chain/a40p_store_manifest.py` d0475682…) writes an md5 manifest of every store file outside
    `RQ-AUD/`. The baseline is `audit/store_manifests/store_0751.tsv` (4531f5a3…): 2,435 files, 950.2 MB, hashed
    07:51:02–07:51:22.
    - My cycle check finds changes by file time (`find -newermt`). That misses a file replaced with its old mtime
      kept (cp -p, rsync -a).
    - From the next cycle on, each cycle also compares a new manifest with the previous one. The repository keeps
      each compare output, and a full manifest only when something changed; the others stay in my private store.
    - The first compare run, at 07:57 (`audit/store_manifests/compare_0751_0757.txt` 7d951dca…), found no change:
      0 files added, removed or changed, and none with a new mtime only.
  - a40q and a40r check the freshness of the A.40 chain's sources (A.40 addendum of 07:58): A40Q_ALL_PASS and
    A40R_ALL_FRESH.
  - Still open, all text only: A.19 f1, A.39 r1–r4 and A.7a r1.
- 2026-10-23 08:51: store cycle (the timer of 08:15).
  - The store was unchanged from 07:57 to 08:41. The a40p compares at 08:15 and 08:41
    (`audit/store_manifests/compare_0757_0815.txt` 6e689eb1…, `audit/store_manifests/compare_0815_0841.txt`
    611013d3…) found 0 files added, removed or changed, and none with a new mtime only.
  - At 08:42:50 RQ-D posted a text-only STATUS.md (61897a51… → 0b573994…; copy in `audit/snapshots/s0844/`). Apart
    from its time line, it adds one sentence: RQ-AUD confirmed A.34 r4 at 07:48 (check a34j), "so nothing is open on
    A.34". This agrees with the A.34 addendum of 07:48.
  - The a40p compare at 08:44 (`audit/store_manifests/compare_0841_0844.txt` 8faefb4b…; full manifest
    `audit/store_manifests/store_0844.tsv` 40236470…) finds that file and RQ-D's LAST_MIRROR.txt changed, and nothing
    else. The compare at 08:51 (`audit/store_manifests/compare_0844_0851.txt` bb9393c0…) finds no change, and every
    other tracked text keeps the md5 it had at 07:48 (re-checked 08:51). RQ-A's FULL_PROOF.pdf is not posted.
  - With nothing new to audit, the cycle ran the hostile check a40s: a direct search next to the seams q6–q11, q16,
    q21, q31, q51 and q101 inside (0, q5) (A.40 addendum of 08:51). A40S_PASS: no vector above M, and the non-equal
    maxima found are certified below M at the exact seams in Arb.
  - Still open, all text only: A.19 f1, A.39 r1–r4 and A.7a r1.
- 2026-10-23 09:57: store cycle (the timers of 09:00 and 09:45).
  - At 08:53–08:54 RQ-A posted FULL_PROOF.pdf (be3ca559…, 192 pages) and FULL_PROOF.tex (0ec0a1e2…). With them came
    the parts in `full_proof/` (front and back matter, the source boxes of Chapters 1–7, 9 and 10, Section 7.6,
    Chapter 8, the three supplements of Chapter 10, the preamble) and seven source copies in `full_proof/sources/`.
    RQ-A also changed STATUS.md, NOTES_FOR_TEAM.md, `.gitignore` and `scripts/mirror.sh`, and added
    `scripts/build_full_proof.py` (d07b95ec…) and `scripts/check_full_proof.py` (0d1b89ae…). I did not read the
    scripts (md5s only).
  - The a40p compare at 09:00 (`audit/store_manifests/compare_0851_0900.txt` c3d268d8…; full manifest
    `audit/store_manifests/store_0900.tsv` 348653f9…) lists exactly these files: 28 added and 5 changed, none with a
    new mtime only. Copies are in `audit/snapshots/s0900_fullproof/`.
  - At 09:00:47 LOCKED_NOTE.md changed (0a104a41… → 7dbc0d30…; copy in `audit/snapshots/s0900_fullproof/top/`). Its
    new line reads "01:57 PT Oct 23: FULL_PROOF.pdf (192 pp, md5 be3ca559) delivered to Paata as Rq_full_proof.pdf".
  - At 09:31 RQ-A posted a text-only STATUS.md (0f928bc3… → 51c05b5d…) and NOTES_FOR_TEAM.md (88a6d86d… →
    539491e1…; copies in `audit/snapshots/s0945/RQ-A/`). They record the delivery, say that RQ-A keeps the file
    unchanged, and ask to be told of any transcription slip.
  - The a40p compare at 09:45 (`audit/store_manifests/compare_0900_0945.txt` 533c062e…; full manifest
    `audit/store_manifests/store_0945.tsv` 10db3796…) finds these two files, RQ-A's LAST_MIRROR.txt and LOCKED_NOTE.md
    changed, and nothing else.
  - At 09:51 RQ-D posted a text-only NOTES_FOR_TEAM.md (563ceb88… → 9f10ed60…; copy in `audit/snapshots/s0956/RQ-D/`).
    - RQ-D checked FULL_PROOF wherever it covers RQ-D's work and found no transcription slip. This agrees with A.41,
      which finds none in Chapter 9 either.
    - It adds one dating remark and says no change is needed. The times 05:35 and 05:36 in two editorial notes of
      Chapter 9 are those of RQ-D's own notes, and its tex commit was made at 05:32.
  - The a40p compare at 09:56 (`audit/store_manifests/compare_0945_0956.txt` 3b74727c…; full manifest
    `audit/store_manifests/store_0956.tsv` 08c2ed7f…) finds that file and RQ-D's LAST_MIRROR.txt changed, and nothing
    else. No file outside `RQ-AUD/` is newer than 09:51:45 (re-checked 09:57).
  - Audit A.41 (section A.41): FULL_PROOF.pdf is VALID WITH FIXES, text only. Its mathematics is that of A.40. The
    fixes f1–f4 are for RQ-A, as its note of 09:31 asks.
  - Own check a40n on commit 6c2c81b (`audit/chain/outputs/a40n_stamp_check_6c2c81b.txt` 9a21218a…): 280 dated stamps
    and 7 correction markers, none later than the commit that last wrote its line; A40N_PASS.
  - Still open, all text only: A.19 f1, A.39 r1–r4, A.7a r1 and A.41 f1–f4.
- 2026-10-23 10:22: store cycle for the timer of 09:45, which was delivered at 10:00, after the cycle of 09:57 had
  covered it; RQ-A's corrected FULL_PROOF.
  - The a40p compare at 10:00 (`audit/store_manifests/compare_0956_1000.txt` dde453ff…) found no change since 09:56: 0
    files added, removed or changed, and none with a new mtime only.
  - At 10:05:37–10:05:41 RQ-A posted a corrected FULL_PROOF for A.41 f1–f4. The a40p compare at 10:06
    (`audit/store_manifests/compare_1000_1006.txt` 1c3bc7af…; full manifest `audit/store_manifests/store_1006.tsv`
    f1a9beb4…) finds 9 files changed and nothing else: FULL_PROOF.tex and .pdf, the parts front.tex, back.tex and
    ch08_c15.tex, and STATUS.md, NOTES_FOR_TEAM.md, AUDIT_REQUEST.md and LAST_MIRROR.txt. Copies are in
    `audit/snapshots/s1006_fullproof2/`.
  - A.41 addendum 2: the corrected file applies the four fixes and changes nothing else (a41h), so A.41 is re-rated
    VALID. The delivered be3ca559… differs from it only in these four text items. RQ-A's replies settle r1, r3 and r4,
    and a41i reproduces the numeral counts of r2 from the rules RQ-A states.
  - A.41 addendum 1, on the delivered file: a41g compares the macro definitions of the eight source papers with
    FULL_PROOF's preamble (A41G_PASS), and a visual check of the rendered pages i, vi and xiii–xvi finds nothing beyond
    f1 and f2.
  - The a40p compare at 10:18 (`audit/store_manifests/compare_1006_1018.txt` aa922184…) finds no change since 10:06. No
    file outside `RQ-AUD/` is newer than 10:05:41 (re-checked 10:22).
  - a40n on commit 723e745 (`audit/chain/outputs/a40n_stamp_check_723e745.txt` 5664db18…): 283 dated stamps and 7
    correction markers, none later than the commit that last wrote its line; A40N_PASS.
  - Still open, all text only: A.19 f1, A.39 r1–r4 and A.7a r1.
- 2026-10-23 10:36: store cycle for the timer of 10:30.
  - The a40p compare at 10:30 (`audit/store_manifests/compare_1022_1030.txt` b32a5877…; full manifest
    `audit/store_manifests/store_1030.tsv` 2d99f78d…) finds one file changed and nothing else: LOCKED_NOTE.md
    (7dbc0d30… → 319fafd7…, 10:25:29; copy in `audit/snapshots/s1030/top/`).
  - Its new line reads "03:25 PT Oct 23: corrected FULL_PROOF.pdf (21fe1613) sent to Paata 03:05 PT; RQ-AUD A.41
    addendum 2 rates it VALID". The md5 is that of the file addendum 2 rates VALID. 03:05 PT is 10:05 UTC, the
    minute in which RQ-A posted the file and 17 minutes before addendum 2. So if the time is right, the file was sent
    before addendum 2 checked it; nothing changes for the audit.
  - At 10:34:29 RQ-A posted text-only STATUS.md (217997d9… → d6d41aaf…) and NOTES_FOR_TEAM.md (d5a3ff89… →
    e521fde2…; copies in `audit/snapshots/s1035/RQ-A/`), stamped 10:35, 31 s after they were written. They record
    addendum 2 and the delivery. The sentence for the coordinator now reads "No statement and no step of a proof
    changes", with a correction marker of 10:33, as addendum 2 suggested; RQ-A also agrees that the "43" on page vii
    is an extraction artefact. So both small points of addendum 2 are settled.
  - The a40p compare at 10:36 (`audit/store_manifests/compare_1030_1036.txt` 44225765…; full manifest
    `audit/store_manifests/store_1036.tsv` 9c6c3c57…) finds these two files and RQ-A's LAST_MIRROR.txt changed, and
    nothing else. No new or changed claim. No file outside `RQ-AUD/` is newer than 10:34:30 (LAST_MIRROR.txt).
  - Own check, A.41 addendum 3: the proof of the Main Theorem in the corrected FULL_PROOF, rebuilt step by step
    against the exact statements it cites; no gap.
  - a40n on commit 6f0da9f (`audit/chain/outputs/a40n_stamp_check_6f0da9f.txt` 698d822a…): 287 dated stamps and 7
    correction markers, none later than the commit that last wrote its line; A40N_PASS.
  - Still open, all text only: A.19 f1, A.39 r1–r4 and A.7a r1.
- 2026-10-23 11:23: store cycle for the timer of 11:15.
  - At 11:02:27–11:02:29 RQ-A posted text-only STATUS.md (d6d41aaf… → 5993ef86…) and NOTES_FOR_TEAM.md (e521fde2… →
    80f4cbc4…; copies in `audit/snapshots/s1115/RQ-A/`), stamped 11:02. They record addendum 3 and the order of
    delivery: the corrected file went to Paata at 10:05 UTC, 17 minutes before addendum 2. RQ-A now stamps an entry
    with the minute in which it is written, rounded down, so no stamp is later than its post. Its summary of the store
    agrees with my compares, and none of the open items it lists (A.19 f1, A.39 r1–r4 and A.7a r1) is RQ-A's.
  - Both files cite the Status paragraph of A.41 ("the mathematics in it already met the LOCKED_NOTE criterion"), and
    NOTES repeats my range "A.6–A.39 and A.40, refereed by RQ-REF1, RQ-REF2 and RQ-REF3". The quote is faithful, but
    the range was loose, because not every item in it is refereed. I have corrected the Status paragraph (A.41,
    marker of 11:23): the refereed mathematics is A.40 with its links, as the block under the ledger lists, and that is
    all the proof of the Main Theorem uses.
  - Own check a41j (`audit/fullproof/a41j_referee_lines.py` 230d098e…, output
    `audit/fullproof/a41j_referee_lines.txt` 5188893a…; A41J_PASS, 25 checks). The "Referee:" lines of the 11 chapter
    source boxes of the corrected FULL_PROOF (tex 14777fb4…) agree with the three reports in the store (369c1cfb…,
    bd18da81…, 6ac713c0…), item by item.
    - Chapters 1–6 say "VALID, no fixes", as RQ-REF1's and RQ-REF2's verdict tables and remarks do.
    - Chapters 7 and 8 name exactly the items of RQ-REF3's links 1 and 2.
    - In Chapter 9 the 24 numbered items share one counter, so item k is RQ-D's item k. Every lemma (1–4, 6–8, 12 and
      18–24) is among RQ-REF3's hand checks for link 3. The only items outside those checks are Theorem 10 and
      Corollary 11, which the box marks as not used by the chain, and Corollary 17, which the link 3 row covers.
    - Chapter 7 cites the equal-coefficient theorem for Step 2, and RQ-REF3's list does not name it. Step 2 needs only
      its elementary direction, the lower bound R >= M, which RQ-REF3 checks by hand (report lines 55–57).
  - The a40p compare at 11:15 (`audit/store_manifests/compare_1036_1115.txt` 72e2a454…; full manifest
    `audit/store_manifests/store_1115.tsv` 60354279…) finds these two files and RQ-A's LAST_MIRROR.txt changed, and
    nothing else. No new or changed claim. No file outside `RQ-AUD/` is newer than 11:02:29 (re-checked 11:23).
  - a40n on commit 5c1b42e (`audit/chain/outputs/a40n_stamp_check_5c1b42e.txt` 7c1d04fe…): 289 dated stamps and 7
    correction markers, none later than the commit that last wrote its line; A40N_PASS.
  - Still open, all text only: A.19 f1, A.39 r1–r4 and A.7a r1.

---

## A.0 BF3 Theorem K on [3/8, 5/8] — verdict VALID (2026-10-22 05:55 UTC)

**Statement audited.** For 3/8 <= q <= 5/8, i.i.d. chi_i with P(chi = sqrt((1-q)/q)) = q,
P(chi = -sqrt(q/(1-q))) = 1-q, and every unit alpha in R^n: E|sum alpha_i chi_i| <= 2 sqrt(q(1-q)).
Hence R(q) = 2 sqrt(q(1-q)) on [3/8, 5/8], attained at n = 1 (alpha = ±e_1).

**Verdict: VALID.** Every step was rebuilt from the hypotheses. Every algebraic identity was
re-derived symbolically. The computer-assisted step was re-done twice, independently of the BF3
scripts (which I never saw): once in exact rational arithmetic following the paper's text, and
once by a structurally different certified proof in Arb ball arithmetic. No gap was found. The
only issues are cosmetic (listed under "Minor remarks"); none affects correctness.

**Novelty: NEW (originates in BF3).** Before BF3 the literature had R(1/2) = 1 (trivial), R(q) < 1
near 3/4 (Ivanisvili–Li–van Handel–Volberg, arXiv:1811.05584), the quantitative bound
R(q) <= 1 - min{4q^3(1-q)^3, (2q-1)^4 q(1-q)}/(45 - 3(q(1-q))^3) (Ivanisvili–Stone,
arXiv:2407.04835, Cor. 2), and the exact supremum over *equal-coefficient* sums (Stone, cited as
[12] in Ivanisvili–Stone, Remark 1.3; thesis UCI 2025, chapter "An Optimization Problem
concerning Binomial RVs"). No earlier proof of an exact value of R(q) for any q != 1/2 was
found (searches through Oct 2026; the 2026 Khintchine papers arXiv:2608.29703 and
arXiv:2608.27908 concern symmetric Rademacher sums). Caveat: Stone's thesis PDF is blocked from
this VM (HTTP 403), so I checked its abstract and table of contents only; RQ-C should confirm.

### Step-by-step audit of the proof (BF3 pp. 29–32)

Notation: tau = sqrt(q(1-q)), theta = 1-2q, kappa = (1-q)/(4q), kappa' = q/(4(1-q)),
a = max|alpha_i| = alpha_1 > 0, b = sqrt(1-a^2), L = a chi_1 + b M.

1. **Reduction to q <= 1/2** (chi -> -chi). Correct.
2. **Constants and identities** qu = (1-q)v = tau, tau v = q, tau u = 1-q, u+v = 1/tau,
   E|chi| = 2tau, 4 kappa' tau^2 = q^2, a_B = kappa/(1-kappa) = (1-q)/(5q-1),
   C_q = (1-2tau^2)/(2tau). All verified as exact rational-function identities
   (`audit/thmK/v1_identities.py`, parametrisation v = sqrt(q/(1-q)), so q = v^2/(1+v^2)).
3. **Lemma 9.4** E|a chi + bM| = 2 tau a + 2 E R_a(bM). Verified on each of the three linear
   regions. (The hypothesis "M bounded" can be weakened to "M integrable"; harmless.)
4. **Lemma 9.5** (Mills ratio bounds). A'(w) = -2e^{-w^2/2}/(1+w^2)^2 and
   B'(w) = -6e^{-w^2/2}/(w^2(w^2+3)^2) verified symbolically; with A, B -> 0 at infinity this gives
   A, B > 0. Correct.
5. **Lemma 9.6** (Stein solution for |x|). Verified: f' - wf = |w| - sqrt(2/pi) (both signs of w
   and w = 0), f is C^1 with f'(0) = -sqrt(2/pi), f'' = sqrt(2/pi) k with k' = (w^3+3w)m - (w^2+2);
   0 < k < k(0) = sqrt(pi/2) by the two Mills bounds, so 0 < f'' < 1 on (0, oo), f'' odd, hence f'
   is 1-Lipschitz. Numerically cross-checked with mpmath (40 digits): f'' in (0.0015, 0.924) on
   (0, 10).
6. **Lemma 9.7** (zero-bias). (i) E[chi G(alpha chi)] = tau(G(alpha u) - G(-alpha v)) =
   alpha E G'(alpha U), U uniform on [-v,u] with density tau. (ii) monotone coupling,
   E|chi - U| = ((1-q)^2+q^2)/(2tau). Both verified exactly.
7. **Case A** (a <= a_A). E[L f(L)] = E f'(L*) needs U_i independent of L_i = L - alpha_i chi_i
   (true: the coupling uses auxiliary randomness private to coordinate i) and I independent of
   everything. Then E|L| - sqrt(2/pi) = E[f'(L) - f'(L*)] <= E|L - L*| =
   sum alpha_i^2 |alpha_i| E|chi_i - U_i| <= a C_q. No induction hypothesis used. Correct.
8. **Case B** (a >= a_B). (y-t)_+ <= y^2/(4t); only one term of R_a is nonzero; the two
   coefficients are kappa tau/a and kappa' tau/a <= kappa tau/a (q <= 1/2); so
   E|L| <= 2tau(a + kappa(1-a^2)/a) = 2tau(1 + (a-1)((1-kappa)a - kappa)/a) <= 2tau, using
   kappa < 1 (q > 1/5) and a >= a_B. Verified.
9. **Case C** (a_A < a < a_B). Inequality (12) R_a(y) <= (kappa' tau/a) y^2 + theta y_+ : both
   outer differences are c times perfect squares (discriminant q^2 - 4 c a tau = 0), the middle
   region is trivial since theta >= 0. E(bM)_+ = (b/2)E|M| <= b tau uses EM = 0 and the induction
   hypothesis E|M| <= 2tau (M is a unit combination of n-1 copies; b > 0 because a_B < 1 for
   q > 1/3). This gives E|L| <= 2tau psi(a), and psi(a) <= 1 <=> P(q, a/b) <= 0 with
   P(q,s) = 32(1-q)^2(1-2q)s^3 + 8q(1-q)(1-8(1-q)^2)s^2 + 8q(1-q)(1-2q)s + q^2. The squaring step
   is legitimate (both sides positive), and the factor 16(1-q)^2 is verified. Correct.
10. **Induction bookkeeping.** Base n = 1 exact; WLOG alpha_1 = max|alpha_i| > 0 by relabelling
    and alpha -> -alpha; b = 0 handled. Cases A, B, C cover (0, 1] once the thresholds satisfy
    (11) and P <= 0 on the Case-C range. Correct.
11. **Level-one equivalence** W^1(f) <= q(1-q) for f: {-1,1}^n -> [0,1]. Both directions correct
    (E[(f - 1/2)L] <= E|L|/2 and f = 1{L > 0} with Cauchy–Schwarz).

### Hand cases q = 3/8, 2/5, 5/12 (exact, `v3_paper_scheme_exact.py`)

All table entries (tau^2, theta, kappa, kappa', a_A, a_B, p_q with coprime integer coefficients as
positive multiples 400, 900, 7056 of the cubic), all values p_q(-1, 0, s-, s+, 2), all s(a)
values and comparisons, all displayed decimals of the Case-A paragraph, and both margins of
Remark 9.8(a) (Case-A margin >= 0.0049; max psi < 0.9935, 0.9664, 0.9539, the latter by an exact
Sturm root count) are verified exactly. Note: "left side of (11) less than 0.9626 / 0.9749 /
0.9804" are equalities 0.7979 + 0.1647 = 0.9626 etc. of the displayed bounds, with strict
inequality coming from the strict bounds on each summand; correct as written.

### The computer-assisted step for all q in [3/8, 1/2]: two independent certificates

**Method P (exact rationals; re-implementation of the paper's text, not of its code).**
`audit/thmK/v3_paper_scheme_exact.py`. 64 intervals [3/8 + j/512, 3/8 + (j+1)/512]; tau_0 = a
64-bit rational lower bound of sqrt(q_0(1-q_0)); a_A = largest multiple of 1e-4 with
79789e-5 + a_A(1-2tau_0^2)/(2tau_0) <= 2tau_0 (pi > 3.14159 certified, which is what
sqrt(2/pi) < 79789e-5 needs: pi > 3.1415498...); rational s_lo <= s(a_A), s_hi >= s(a_B(q_0));
BF3's corner bound on boxes, bisected until negative. Every number stated in the paper is
reproduced exactly: a_A = 194/625 (j = 0), a_A = 4041/10^4 (j = 63), Case C empty exactly for
j >= 48 (q_0 >= 15/32), and **249 boxes with maximal depth 6 when bisecting in s only**
(quadrisection would need 2784 boxes, depth 6). I also checked the validity of the corner bound
itself (coefficient signs and monotonicity on [3/8,1/2]) by hand and by 2e5 random trials
(`v5_sanity_attacks.py`).

**Method S (certified Arb ball arithmetic, different reduction).** `audit/thmK/v2_endpoint_arb.py`.
Lemma (interval property, proved here): for 0 < q <= 1/2 the set {s > 0 : P(q,s) <= 0} is an
interval. Proof: for q < 1/2, P is a cubic with positive leading coefficient and P(q,0) = q^2 > 0,
so it has a negative root; the sum of the roots is -c_2/c_3 > 0 and the product is
-q^2/c_3 < 0, so there is exactly one negative root; a pattern P(x) <= 0 < P(y), P(z) <= 0 with
0 < x < y < z would force three positive roots (with multiplicity) besides it. For q = 1/2,
P = 1/4 - 2s^2. Consequently, taking the *optimal* threshold a*(q) = (2tau - sqrt(2/pi))/C_q
(equality in (11)), Case C at q holds as soon as P(q, s(a*(q))) <= 0 and P(q, s(a_B(q))) <= 0,
where s(a_B)^2 = (1-q)^2/(8q(3q-1)); and Case C is void if a*(q) >= a_B(q). These two
one-variable inequalities were certified with Arb (200-bit balls, sqrt(2/pi) from Arb's rigorous
pi) on an adaptive cover of [3/8, 1/2] by 67 intervals: 52 by the endpoint inequalities (worst
upper bound -2.2e-4 over a whole q-interval of width 1/512), 15 by a* - a_B >= 1.8e-3 (from
q = 0.4707). Control: the same code fails, as it must, on [0.36, 0.37].

Both certificates pass; together with steps 1–11 this proves Theorem K for q in [3/8, 1/2], hence
for [3/8, 5/8] by symmetry.

### Attempt to break the theorem numerically (evidence only)

`v4_break_attempt_numeric.py`: maximise E|alpha.chi| over unit alpha, exact enumeration of all
2^n atoms, n <= 12, monotone L1 power iteration from ~400 random/sparse/near-dictator and
structured starts per (q, n). For every q in {0.30, 0.32, ..., 0.375, ..., 0.5} the maximum ratio
E|L|/(2tau) is exactly 1 (dictator). The optimiser is validated on controls: it finds sqrt(2)(1-q)
at q = 0.20, 0.25, 0.28, 0.29 (two equal coefficients) and 1.4671 at q = 0.1 (five equal
coefficients, above the CLT value 1.3298).

### Where the BF3 method stops (information for RQ-A)

`v6_method_limit.py` (mpmath, informative): with the optimal threshold a*(q), the Case-A/C
interface fails below q = 0.362494 (a* = 0.2924), but the **Case-C/B interface fails first, below
q = 0.3719185** (a = a_B = 0.7307): there psi(a_B) > 1 while the Case-B bound is exactly 1 at
a_B. So extending Theorem K below 0.3719 first requires a better bound for large a (a in
[~0.7, a_B]), e.g. an optimal moment/dual certificate for max E R_a(bM) under EM = 0, EM^2 = 1,
E|M| <= 2tau, and only below 0.3625 a better small-a (Stein) bound.

### Minor remarks (non-fatal; suggested text fixes for BF3)

- (m1) "Bisecting [q_0,q_1] x [s_lo,s_hi]": the count "249 boxes, depth 6" corresponds to
  bisecting in s only; say so.
- (m2) The choice of the rational tau_0 <= sqrt(q_0(1-q_0)) and of s_lo, s_hi is not specified;
  any choice accurate to ~1e-8 reproduces the stated a_A values and box counts.
- (m3) Lemma 9.4: "bounded" can be replaced by "integrable".
- (m4) Literature (not BF3): Ivanisvili–Stone (1.10) as printed, 2 sqrt(N p*) (1-p*)^{N-1}, has an
  exponent typo; the exact value of sup over equal-coefficient sums is
  2 sqrt(N p*) (1-p*)^{N - 1/2} = 2tau sqrt(N)(1-p*)^{N-1} with N = N(p*) (exact check in
  `v5_sanity_attacks.py`: e.g. p = 1/10, N = 5 gives 0.880251, the printed formula 0.927866).
  For p* < 1/2 this needs N p* < 1, true for N = floor(1/(1-(1-p*)^2)).

### Files

- `audit/thmK/v1_identities.py` -> `outputs/v1_identities.txt` (47 exact identities, all OK)
- `audit/thmK/v2_endpoint_arb.py` -> `outputs/v2_endpoint_arb.txt`, `outputs/v2_endpoint_arb_intervals.txt`
- `audit/thmK/v3_paper_scheme_exact.py` -> `outputs/v3_paper_scheme_exact.txt` (58 exact checks, all OK)
- `audit/thmK/v4_break_attempt_numeric.py` -> `outputs/v4_break_attempt_numeric_n12.txt`
- `audit/thmK/v5_sanity_attacks.py` -> `outputs/v5_sanity_attacks.txt`
- `audit/thmK/v6_method_limit.py` -> `outputs/v6_method_limit.txt`

Reproduce: `pip install sympy mpmath python-flint numpy`, then run each script from `audit/thmK/`.

---

## A.1 RQ-C C1 (recheck of the Theorem K computer step) — VALID (2026-10-22 06:00 UTC)

Claim: the 64-interval exact-rational box verification of BF3 holds (also for 16/32/128/256
intervals), with hand cases. Audit: (i) the mathematical content is exactly the computer step
that I certified independently in A.0, twice (Method P exact rationals; Method S Arb, different
reduction); (ii) I read `RQ-C/numerics/bf3_interval_recheck.py`: the square-root bounds round in
the correct directions (`sqrt_lo` floors, `sqrt_hi` is isqrt+1, both re-checked by squaring), the
corner bound is BF3's (validity checked in A.0), a_A is certified by an exact assertion, s_lo <=
s(a_A) and s_hi >= s(a_B(q_0)) are correct; (iii) a copy of the script reproduces its output
(64 intervals: 16 empty, 2784 boxes, depth 6, 0 failures). The box count 2784 for joint q/s
bisection equals my own independent count (A.0, Method P, quadrisection). Their claim is tagged
"modulo the analytic lemmas of BF3 §9.4"; those lemmas are audited VALID in A.0, so C1 + A.0
together give Theorem K. Novelty: KNOWN (it re-verifies BF3).

## A.2 RQ-C C4(a) (first-order optimality of Poisson(1/2)) — VALID WITH FIXES (2026-10-22 06:00 UTC); VALID after the fixes (2026-10-23 07:48 UTC)

Claim: for X = N - lam, N ~ Poisson(lam), adding an independent centred compound-Poisson
component gam(N_eps - eps) changes E|X|/||X||_2 by eps D(gam)/||X||_2 + o(eps), with
D(gam) = phi(gam) - phi(0) - gam phi'(0) - (gam^2/2)E|X|/Var X, phi(g) = E|X+g|; at lam = 1/2,
D <= 0 with equality only at gam = 1.

Rebuilt proof. First order: P(N_eps = 1) = eps + O(eps^2), phi is 1-Lipschitz and differentiable
at 0 (X has no atom at 0 when lam = 1/2), ||X + Y||_2 = sqrt(lam + gam^2 eps). This gives the
stated D. Formulas: for 0 < lam < 1 and gam > 0, every N >= 1 gives N - lam + gam > 0, so
phi(gam) = gam + 2e^{-lam}(lam - gam)_+, and D(gam) = 2e^{-lam}[(gam - lam)_+ - gam^2/2]; at
lam = 1/2 this is -e^{-1/2}gam^2 (gam <= 1/2) and -e^{-1/2}(gam - 1)^2 (gam >= 1/2). For
gam = -g < 0: D(-g) = 2 sum_{k>=1} P(N=k)(g - (k - lam))_+ - e^{-lam} g^2.
Negativity for all g > 0 (shorter than RQ-C's discriminant checks): for g <= 1/2, D = -e^{-1/2}g^2;
for g >= 1/2, (g - (k - 1/2))_+ <= g - 1/2 for k >= 1, so with c = e^{1/2} - 1 in (0,1),
e^{1/2} D(-g) <= 2c(g - 1/2) - g^2 = -(g^2 - 2cg + c) < 0 (discriminant 4c(c-1) < 0).

Independent checks (`audit/rqc/a2_poisson_first_order.py`, mpmath 50 digits): both formulas match
the definition to 1e-49; max D on a grid of gam in [-9.9, 9.9] without {0, 1} is -5.9e-5 < 0;
finite differences d/d eps of the exact ratio match D/||X|| for gam = 1, 2, 0.3, -1, -0.7, 3.

Fixes required: (f1) the sum in the gam < 0 formula must run over k >= 1 (as printed, "sum_k",
including k = 0 adds 2e^{-lam}(g + lam) > 0 and makes the formula wrong; numerically the error is
13.7 on the grid); (f2) "equality only at gam = 1" should read "only at gam in {0, 1}" (gam = 0 is
the trivial perturbation; the Gaussian direction is the limit D(gam)/gam^2 -> -e^{-1/2} < 0, so it
is strictly decreasing at first order). Scope: this is a first-order (critical point) statement
about Lévy-measure perturbations of (1/2)delta_1 with finite second moment; it does not bound
R(q) and does not by itself prove lim R(q) = sqrt(2/e). Novelty: the computation is NEW but
elementary; the value sqrt(2/e) as the limit of the Stone value is KNOWN (Stone thesis,
Lem. 4.4.4, as quoted by RQ-C SOTA K5).

**Re-rated VALID (2026-10-23 07:48 UTC).** Both fixes are in RQ-C's text.
- RQ-C `CLAIMS.md` 4b1e22a4… gives the gamma < 0 formula as D(-g) = sum_{k>=1} 2P(N = k)(g - (k - lam))_+ - e^{-lam} g^2.
  It adds that the k = 0 term is absorbed in phi(gamma) - phi(0) - gamma phi'(0) (f1). It states the equality set as
  gamma in {0, 1}, with gamma = 0 the trivial perturbation (f2).
- Lines 60–100 of that file, which hold all of C4, are byte-identical to my snapshot
  `audit/snapshots/RQ-C_CLAIMS_0709.md` of 2026-10-22 07:09. The A.8 note of 07:03 found the 06:49 text still
  unfixed, so RQ-C posted the fixes between those two mirrors.
- This row should have been re-rated on 2026-10-22, once that copy was in this repository (commit 1785c9d, 07:46). It
  lagged until this cycle's ledger check a40o (store log) found it. C4(a) is not used by the A.40 chain.

I rebuilt the absorption claim of f1 from the definitions. Let 0 < lam < 1 and X = N - lam.
- Since only N = 0 gives X < 0, phi(0) = E|X| = 2 lam e^{-lam}. X has no atom at 0, so phi'(0) = E sgn X = 1 - 2e^{-lam}.
  Hence E|X|/Var X = 2e^{-lam}.
- For g > 0, phi(-g) = E(X - g) + 2E(lam + g - N)_+ = -g + 2 sum_{k>=0} P(N = k)(lam + g - k)_+. Its k = 0 term is
  2e^{-lam}(lam + g).
- So phi(-g) - phi(0) + g phi'(0) = 2 sum_{k>=1} P(N = k)(g - (k - lam))_+ exactly. The terms -g, 2 lam e^{-lam} and
  2g e^{-lam} cancel in pairs, so the k = 0 term is absorbed. Subtracting (g^2/2) 2e^{-lam} gives RQ-C's formula.
The rest of C4(a) is as audited at 06:00, including the quadratic bound credited to A.2 and RQ-C's scope paragraph.

### RQ-C claims not tagged PROVED (noted, not audited as proofs)

C2, C3 (NUMERICAL), C4(b) (NUMERICAL), C5 (CONJECTURE S: R(q) = S_{N(q)}(q) for q <= 1/2). My own
independent search (A.0, n <= 12) agrees with C3 on [0.30, 0.5] and at q = 0.1 found the same
five-equal-coefficient optimum 2 sqrt(Np)(1-p)^{N-1/2} = 0.880251 (N = 5).

---

## A.3 RQ-A C0.1–C0.5 (elementary facts) — VALID (2026-10-22 06:36 UTC)

- C0.1 = BF3 Lemma 9.4, audited in A.0 step 3 (piecewise-linear identity
  E|a chi + y| = 2 tau a + (2q-1)y + 2R_a(y), integrate against the law of bM with E M = 0).
- C0.2: cumulants kappa_3..kappa_6 of chi in u, v (and the equivalent tau-forms used in LP code)
  verified symbolically; moments EM^3..EM^6 from additivity of cumulants
  (mu_6 = kappa_6 + 15 kappa_4 kappa_2 + 10 kappa_3^2 + 15 kappa_2^3, etc.) checked against exact
  enumeration on 30 random rational coefficient vectors (`audit/rqa/a3_elementary.py`,
  `outputs/a3_elementary.txt`).
- C0.3: (sum b^3)^2 <= (sum b^2)(sum b^4) = p4, p4 <= m^2, p4^2 <= p2 p6 = p6, p6 <= m^2 p4,
  |p5| <= m p4; also checked on 2000 exact random vectors.
- C0.4: E|a chi_1 + b chi_2| = (a+b)[q^2 u + q(1-q)(u - v) + (1-q)^2 v] = 2 tau (1-q)(a+b) exactly
  when both mixed atoms a u - b v, b u - a v are >= 0, i.e. q/(1-q) <= b/a <= (1-q)/q. Verified.
- C0.5 = BF3 end of §9.4 (A.0 step 11).
Novelty: KNOWN / standard.

## A.4 RQ-A K.1–K.2 (Theorem K re-verification) — VALID (2026-10-22 06:36 UTC)

K.1 (logic) coincides with my A.0 audit; its earlier caveat "B to be re-checked" is resolved
(B'(w) verified symbolically in A.0 and now also by RQ-A `check_mills.py`). K.2: I read
`RQ-A/scripts/verify_thmK_bf3.py` line by line: sqrt lower/upper bounds round in the correct
direction; tau_0 <= tau(q) and C_0 >= C_q on each interval (C_q decreasing in tau); Case B uses
a_B(q_0) >= a_B(q); the corner bound is BF3's and valid on [3/8,1/2] (each monomial bounded at the
right corner; 8(1-q)^2 - 1 > 0); hand tables exact. A copy of the script reproduces its output byte
for byte (2784 boxes, depth 6, 16 empty intervals = my Method P count). Novelty: KNOWN.

## A.5 RQ-C C6, part n <= 6 — VALID (2026-10-22 06:36 UTC); n = 7 part not yet audited

Claim: for n <= 6 and all q in (0,1), R_n(q) = 2 tau sqrt(max_{1<=k<=n} k(1-qbar)^{2k-2}); the only
extremisers are +-(equal coefficients on k* = min(n, N(qbar)) coordinates) (both k*-1 and k* at
qbar = q_{k*}); every other LTF is strictly worse.

Rebuilt proof.
1. Duality (my own argument, slightly cleaner than RQ-C's): for unit alpha put
   f_alpha = 1{alpha.chi > 0}, an LTF (alpha.chi = (alpha.x - q sum alpha)/tau). Since E[f chi_i] =
   tau E D_i f, E|alpha.chi| = 2 tau <alpha, E D f_alpha> <= 2 tau sqrt(P_{f_alpha}); conversely for
   any Boolean f, alpha = E D f gives E|alpha.chi| >= E[(2f-1) alpha.chi] = 2 tau |alpha| sqrt(P_f).
   So R_n = 2 tau max_{LTF} sqrt(P_f) (ties on {L = 0} are irrelevant). If alpha attains R_n, equality
   in Cauchy-Schwarz forces P_{f_alpha} maximal and alpha parallel to E D f_alpha; with the
   certificate below f_alpha is OR_k or its complement, so alpha = +-1_S/sqrt(k), and
   1{1_S.chi > 0} = OR_S because kq < 1 for k <= N(q). q > 1/2 follows from chi -> -chi.
2. If f has r relevant variables it is an LTF on r variables, so the claim for all n <= 6 is
   equivalent to: P_f < M_r := max_{k<=r} k(1-q)^{2k-2} on [0,1/2] for every LTF f on <= 6 variables
   that is not OR_r or its complement (P_f(0) = r forces OR_r/NOR_r; argmax of k(1-q)^{2k-2} is
   N(q) = floor(1/(q(2-q))) by the ratio test).

Independent computer verification (no RQ-C code used; I read only their output summary):
- Enumeration by a different method (`audit/rqc/a5_ltf6_enum.c`): sorted positive LTFs
  (w_1 >= ... >= w_6 >= 0, w_1 <= W), then all 64 x 720 signed permutations. W = 9 gives 1113
  sorted positive truth tables, **15,028,134** distinct LTFs and **38,456** S_6-classes; W = 14 gives
  the identical class list (md5 equal). From the classes I recover the per-n counts
  2, 4, 14, 104, 1882, 94572, 15028134 for n = 0..6 = OEIS A000609 (completeness), and the class
  counts 10, 34, 178, 1720, 38456 for n = 2..6 (= RQ-C).
- Certificate by a different method (`audit/rqc/a5_ltf6_certify.py`, `outputs/a5_ltf6_certify.txt`):
  every class is checked to be unate; integer polynomials P_f (degree <= 10) are built in FLINT;
  on each piece I_k of [0,1/2] where the k-th term is maximal (rational outer enclosures of
  q_k = 1 - sqrt((k-1)/k), error < 1e-40) the integer polynomial k(1-q)^{2k-2} - P_f is shown to
  have no real root (Arb-certified root isolation, real roots returned with exact zero imaginary
  part; exact Sturm fallback never needed) and to be positive at the midpoint (exact rationals).
  **228,746 strict inequalities certified, 0 failures.** Exactly 12 classes have P_f identical to
  some k(1-q)^{2k-2}: OR_k and NOT OR_k for k = 1..6 (checked from truth tables).
- Runner-up ratios max_q P_f/M_r (float grid, information): 0.9215 (my grid misses the kink at
  q_2; exact value at q_2 is 0.921573), 0.975616, 0.995279, 0.999120 for r = 3..6, agreeing with
  RQ-C's 0.92157, 0.97562, 0.99529, 0.99912.

Erratum found and since corrected by RQ-C. The 06:11 text claimed
P_g < 2p^2 "for all m >= 1, q < 1/2" for g = x_1 or (x_2 and not AND_m); this is false near
q = 1/2 (exact: m = 1, q = 9/20: P_g = 0.719019 > 2p^2 = 0.605; fails for m = 1 iff q > 0.364976;
`audit/rqc/a5b_runnerup_check.py`). It was harmless (M = 1 there). The 06:27 text replaces it by
P_{g_{k,m}} - k p^{2k-2} = p^{2k-4}[-2p q^m(1-kq) + q^{2m}((k-1)q^2 + (m+1)p^2)] < 0 whenever
q((k-1)q^2 + 2p^2) < 2p(1-kq), in particular for q <= q_k: identity verified from truth tables for
k = 2,3,4, m = 1,2,3, and the condition has no root on [0, q_k] for k = 2,3,4 (exact Sturm;
`a5c_runnerup_general.py`). The bracket is decreasing in m for q <= 1/2, so m = 1 is the worst case.

Novelty: NEW (computer-assisted finite-n theorem; BF3 only mentions numerics for n <= 7).
The n = 7 part (IEEE directed rounding, 86M boxes) is queued as A.5b.

## Note on RQ-A N.1 while it was NUMERICAL (hostile LP test, 2026-10-22 06:36 UTC)

Independent column-generation LP (`audit/rqa/h2_moment_lp_colgen.py`, `outputs/h2_moment_lp_colgen.txt`;
my own code; relaxation P33 in [p3^2, p4] is weaker than RQ-A's P33 = p3^2): on 9 values of q in
[q0, 1/2] x 28 values of a, no primal LP value exceeds tau(1-a). Margins agree with RQ-A's scan to
~1e-6 (q0: 2.1e-6 at a = 0.7071; q = 0.2935: 8.60e-4; q = 0.295: 2.98e-3).
Technical points for the rigorous version:
(n1) On a bounded grid the sixth-moment row must allow mass escaping to infinity (EM^6 <= target,
     i.e. dual c6 >= 0); with equality the LP under-estimates when lambda_6 < 0 (seen at q = 1/2,
     a in [0.6, 0.85]: +8e-4; `outputs/h2b_slack_check.txt`). RQ-A's `lp6cert.py` has this slack.
(n2) Typo: sup{E|X| : EX^k = EZ^k, k <= 6} = 0.888074 (4-point Gauss–Hermite, confirmed by LP) equals
     2 tau at q = 0.270150, not 0.2744 (`outputs/h2c_gauss6_absmax.txt`).

## A.6 RQ-A MAIN (Theorem 1 of MAIN_RESULT) — VALID, NEW (2026-10-22 06:52 UTC)

Claim (MAIN_RESULT.md / .tex / .pdf, posted 06:47 UTC). Let q0 = 1 - 1/sqrt2.
(a) For every q in [q0, 1-q0], every n and every unit alpha, E|sum alpha_i chi_i| <= 2 sqrt(q(1-q)).
    Hence R(q) = 2 sqrt(q(1-q)) there.
(b) For q outside [q0, 1-q0], R(q) >= 2 sqrt2 max(q,1-q) sqrt(q(1-q)) > 2 sqrt(q(1-q)).
(c) Inside the open interval the only extremisers are +-e_j. At q0 and 1-q0 they are +-e_j and
    +-(e_i+e_j)/sqrt2.

Verdict: **VALID.** Every step was rebuilt from the definitions. Every computer step was redone by my
own programs (exact rationals, Arb balls from python-flint, and separately sympy Sturm sequences).
These share no code with RQ-A's generators or with RQ-A's `verify_all.py`. The text has two typos
(below). Neither affects the proof.

### Rebuilt proof (chain of lemmas, each re-derived)

1. Symmetry (Lemma 2): -chi^(q) has the law of chi^(1-q). So assume q <= 1/2, i.e. u = sqrt((1-q)/q)
   in [1, u0], u0 = sqrt(1+sqrt2). Rational parametrisation q = 1/(1+u^2).
2. Reduction (Lemma 3 = BF3 Lemma 9.4 = C0.1, audited in A.0 and A.3). Take a = alpha_1 = max|alpha_i|.
   Then a = 1 is trivial. For a < 1, E|L| <= 2 tau iff E R_a(bM) <= tau(1-a), where
   M = sum beta_i chi_i, sum beta_i^2 = 1, max|beta_i| <= min(1, a/b).
3. Moments (Lemmas 4–6 = C0.2–C0.3, A.3): kappa_3..kappa_6 and EM^3..EM^6 in the power sums
   p3..p6. The power-sum region is p3^2 <= p4 <= m^2, p4^2 <= p6 <= m^2 p4, |p5| <= m p4.
4. Six-moment cells (Lemmas 7, 9, Definition 8). I re-derived the domination of R_a(b.) on a cell
   by the lines l1bar = s(u2)(bbar y - a1/u2) and l2bar = (1/(1+u1^2))(-bbar y - a1 u1), with
   bbar >= sqrt(1-a1^2). The sign analysis is on y > 0 and y < 0 separately; it uses monotonicity
   in u, a and b. I also re-derived the bound of E P(M) on the power-sum region term by term:
   kappa_3 >= 0; kappa_4(c4+15c6) is linear in kappa_4; |kappa_5| <= k3+ max|w-10|; kappa_6 is
   decreasing in w for w < 13; the p6 term uses m^2 p4 or p4^2 according to sign; p3^2 <= p4.
   Finally tau(u2)(1-a2) <= tau(u)(1-a). My conditions are identical to Definition 8 (V1)–(V4).
   I wrote my verifier from my own derivation before reading the posted text.
5. Quartic two-extremiser certificate (Lemmas 11, 12, Corollary 13). P = (y+v)^2 S0 is tangent to
   l1 at u and vanishes doubly at -v. P >= 0 and P >= l1 follow from the two discriminants
   (disc S1 = B0^2 - 4c4(s + B0/tau), since u + v = 1/tau). For P >= l2 I use the Taylor
   coefficients at -au/b with my own sufficient condition. That condition is different from
   RQ-A's (Q3), which I also checked by hand: the split f = [e0 + e1 x + eta x^2] +
   x^2[(e2 - eta) + e3 x + c4 x^2] with eta = (e1^-)^2/(4e0) is correct.
   For the comparison step, E P(chi) - E P(M) = c3 k3 (1-p3) + c4 k4 (1-p4) >= (1-p3)(k3 B0 - 4c4).
   This needs k4 < 0 (u^2 < 2+sqrt3), |p3| <= 1, and the identity k3^2 - k4 = 2.
   Then E|L| <= 2 tau (1-q)(a+b) <= 2 sqrt2 (1-q) tau <= 2 tau, because q >= q0.
   Equality forces a = b, q = q0 and p3 = 1. Since sum beta_i^2 (1 - beta_i) = 0 with each
   beta_i <= 1, p3 = 1 means exactly one beta_j = 1.
6. Near-dictator range (Lemma 14). For a >= 9/10: (x-t)_+ <= 27x^4/(256t^3), EM^4 <= 3 and
   u^4 + v^4 <= 6. This gives the constant (486/256)(1-a)(1+a)^2/a^3, which is decreasing and
   equals 361/384 = 0.940104 at a = 9/10.
7. Glue. ubar0 = 776887/500000 >= u0. The pieces cover [1, ubar0] x (0,1):
   a in [0, 16/25]: cells r1; a in [16/25, 77/100]: cells r3 for u <= 611/400 and quartic boxes for
   u >= 611/400; a in [77/100, 9/10]: cells r2; a in [9/10, 1): Lemma 14. In the quartic piece,
   t in [9/25, 471/1000] covers a in [16/25, 77/100], because a(9/25) = 225/353 < 0.64,
   a(471/1000) > 0.77 and a(t) is increasing. The inequality is strict in the cell and
   near-dictator pieces, which gives (c). Part (b) is the two-coefficient value C0.4 (A.3).

### Independent computer verification (RQ-AUD code only)

| step | my program | method | result |
|------|------------|--------|--------|
| 379 six-moment cells, (V1)–(V4) + exact tiling of the 8 rectangles | `audit/rqa/a6_lemmaS_verify.py` | positivity of P, P-l1bar, P-l2bar on R and of the (V4) polynomial on [0, mbar]. Arb-certified root isolation of the integer-scaled polynomials with exactly rationalised, enlarged balls, plus an exact sign at one point. sqrt bounds by integer isqrt. | 379/379 pass, no subdivision needed; all 8 rectangles tiled exactly |
| same cells, second method | `audit/rqa/a6c_lemmaS_sturm_recheck.py` | sympy exact Sturm counting with a Cauchy root bound | 379/379 pass |
| 641 quartic boxes | `audit/rqa/a7_lemmaQ_verify.py` | Arb intervals (120 bits), adaptive bisection of each stored box with the stored c4. The conditions are s > 0, B0 > 0, k4 < 0, bu^2 > a, au^2 > b, both discriminants, k3 B0 - 4c4 >= 0, and my own P >= l2 condition. | 641/641 pass, 75,008 sub-boxes, max depth 5; the hull [611/400, ubar0] x [9/25, 471/1000] is tiled exactly |
| identities, Lemma 14, glue | `audit/rqa/a7b_identities_and_glue.py` | sympy exact | all OK (25 identities and checks) |
| negative tests, cells | `audit/rqa/a6b_lemmaS_negative_tests.py` | corrupt certificates and cells | rejected: P x 0.9 120/120, c0 - 1e-3 120/120, c6 = 0 119/120, u2 + 0.1 120/120, a1 - 0.05 118/118. A valid cell moved to u0 is rejected. The minimum gap P - Rbar is 1.2e-8 > 0. |
| negative tests, quartic | `audit/rqa/a7c_lemmaQ_negative_tests.py` | corrupt c4 or move boxes | rejected: c4 x 3 81/81, c4 / 3 81/81, t moved 81/81; control 0/81 |
| RQ-A's corruption set replayed | `audit/rqa/a6d_corruption_replay.py` | the 160 corruptions of `break_tests.py`, run through my verifier | 126/160 rejected, the same count as RQ-A. All 120 decreases are rejected; 34 of the 40 "c0 + 10%" increases are accepted, which is expected because they have slack. The §7.1 sentence "every tested decrease … is rejected" is therefore accurate. |

Data integrity: the nine certificate files in the store at 06:48 UTC have the same md5 as the snapshot
I verified (`audit/rqa/rqa_data/MD5SUMS`). The sample certificate quoted in §8 of MAIN_RESULT (r1d cell
[24583497/16000000, ubar0] x [63/100, 16/25], including the exact c1 and c5) matches the file. So does
the quartic box at (u0, sqrt2 - 1), [1.5521319, ubar0] x [0.4120313, 0.4155] with c4 = 0.0024140.
Reproducibility: RQ-A's own `verify_all.py`, run on a scratch copy outside the store, prints
`ALL SELECTED PARTS PASSED: A B C D E` (16 s). This is not part of my evidence.

Consistency of the posted text with my reconstruction: I read MAIN_RESULT.md in full. Statement,
Definition 8, Lemmas 7, 9, 11, 12, 14 and the coverage argument agree with what I verified. Every
hypothesis of Lemma 12 that the proof uses (u in (1, 19/10), bu^2 > a, au^2 > b, (Q1), (Q3), (Q4)) is
certified on every box, either by my own conditions or by stronger ones.

### Fixes (text only; no mathematical change)

(f1) Remark 2 (and CLAIMS N.1, `.tex` line 630): "below 2 tau exactly when q > 0.2744" should read
     "q > 0.27015". The 4-point Gauss–Hermite value 0.8880738 equals 2 tau at q = 0.2701496
     (`outputs/h2c_gauss6_absmax.txt`); at q = 0.2744, 2 tau = 0.89242.
(f2) End of the proof of Theorem 1(c): there is a stray "0" before the QED symbol.
Informational: Remark 1's "margin ≈ sqrt2 (q - q0)" is in units of tau. It agrees with my column-
generation LP (8.60e-4 at q = 0.2935, 2.98e-3 at q = 0.295). It is not used in the proof.

### Attempts to break it

- The near-extremiser cells cannot be moved to u >= u0 (a6b; RQ-A break test 3), and quartic boxes
  moved beyond q0 fail in 22/81 cases. This is consistent with sharpness at q0 from (b).
- Earlier hostile numerics found nothing: big coefficients plus a Gaussian remainder (h1), and the
  column-generation LP on the full (q, a) grid (N.1 note).

### Novelty

NEW. BF3 proved R(q) = 2 sqrt(q(1-q)) on [3/8, 5/8] (Theorem K) and conjectured it on
[1 - 1/sqrt2, 1/sqrt2] (COMMON.md; BF3 Remark 9.8). Literature searches (2026) found no proof of the
biased central range. The nearest work, arXiv 2608.27908 and 2608.29703, treats the unbiased case
only. The method (six-moment polynomial majorants plus a quartic two-extremiser certificate, with no
induction) also appears to be new.

Next step under LOCKED_NOTE: AUD rates it VALID, so a fresh independent referee should now be
launched for A.6 before anything is reported to Paata.

Addendum (07:41 UTC), PDF = audited text: `MAIN_RESULT.pdf` (pdfTeX, built 06:41:06 UTC) was compared with
`MAIN_RESULT.tex` by text extraction (pdftotext). All 89 distinct numbers of the source occur in the PDF. Every word
of length >= 6 also occurs, apart from LaTeX package and label names and hyphenation or extraction artifacts
(checked one by one). So the PDF that would be reported is the text audited above.

Addendum (2026-10-23 02:55 UTC): **A.6 re-checked on the refereed text. Theorem 1 and its proof are as audited, and A.6 stays
VALID. There is one new slip in the appendix (f3, text only).**
- **Why.** A.6 audited RQ-A's 06:47 files. I recorded no md5 for them and kept no copy, and RQ-A changed the tex
  afterwards (it was d13b9902… at 08:13). RQ-REF1 refereed tex 6816732f…, PDF 0a95569f… (pdfTeX, built 07:30:18 UTC)
  and md 8bf9a2bb… (its SNAPSHOT_MD5SUMS). The tex and the PDF are still the store's files. The md is now 6cdb60b2…,
  and I hold no copy of 8bf9a2bb….
- **Text.** I read tex 6816732f… in full (656 lines) against my A.6 reconstruction.
  - The statement, Definition 8 (V1)–(V4), Lemmas 7, 9, 11, 12 ((Q1), (Q3), (Q4)) and 14, Section 7 and the proof
    agree with what A.6 verified.
  - f1 is fixed: line 630 reads "q>0.27015 (the value 0.8880738 equals 2τ at q=0.2701496)". f2 is fixed: line 614
    ends in "\hfill$\square$".
  - The md states Theorem 1 (a)–(c) as the tex does. Its lines on the 1.77e-3 minimum (272), Remark 2 (311) and the
    appendix (319) have the same text as the tex.
- **PDF** (`audit/rqa/a6f_pdf_vs_tex.py`, A6F_PASS). All 82 distinct numbers and all 320 distinct words of six or more
  letters in the tex body occur in the PDF's extracted text. Both fixes are in it, and "0.2744" occurs in neither file.
- **Figures** (`audit/rqa/a6e_text_recheck.py`, output `audit/rqa/outputs/a6e_text_recheck.txt`). It uses exact fmpq,
  and Arb with box subdivision, on the data A.6 verified (md5s as in a40d).
  - Table 1: the eight regions and the cell counts are as stated (94, 59, 32, 71, 16, 47, 16 and 44; 379 in all), and
    no cell failed.
  - Appendix sample cell of r1d: c1 = 114188429368/981419917709 and c5 = -22338039/10529058835 exactly, and the
    seven rounded coefficients are as stated.
  - Section 7.2: the region Q, 641 boxes, every c4 > 0, and no failure.
    - a(9/25) = 225/353 < 16/25 and a(471/1000) = 942000/1221841 > 77/100 exactly.
    - The minimum of κ3B0 − 4c4 over all boxes is at the corner (12233137/8000000, 9/25) of box 640, with value
      1.7771026e-3. RQ-A's "minimum certified lower bound 1.77e-3" is 7.1e-6 below it.
  - Appendix box: exactly one box contains (u0, √2−1) in its interior. It is
    [2483411/1600000, ū0] × [2637/6400, 831/2000], with c4 = 13162/5452309 ≈ 0.0024140, as stated.
    - 4c4s − B0² ≥ 5.7e-4 holds. My certified lower bound is 5.7245e-4 (64 × 64 split). The exact minimum over the
      corners is 5.7266702e-4, at (2483411/1600000, 831/2000).
  - Remark 2: G = E|X| for the 4-point Gauss–Hermite law is 0.88807383397711…. 2τ(q) = G at q = 0.27014957830950….
    Both round as stated (0.8880738 and 0.8881; 0.2701496 and 0.27015). (Corrected at 07:05: the q figure read
    0.27014957830951 with an ellipsis, which is its rounding, not its leading digits; a40m.)
- **(f3) The appendix bound κ3B0 − 4c4 ≥ 6.2·10⁻³ is false.** It is at tex line 653, md line 319 and the end of the
  PDF.
  - At the corner (ū0, 2637/6400) of that box the exact value is 6.1635125·10⁻³. My certified lower bound over the
    box is 6.1597·10⁻³. The text should read "≥ 6.1·10⁻³".
  - RQ-A's outputs log no per-box bounds; `quartic_cover.log` says only "boxes verified: 641, failed: 0". So I cannot
    tell whether 6.2 is a rounding of 6.16 or a bound that a program printed. In the second case that program's
    enclosure is unsound, and RQ-A should find out why.
  - Theorem 1 is unaffected. Lemma 12 needs only κ3B0 − 4c4 > 0. A.6 certified that on all 641 boxes with my own
    code, and a6e certifies it again (8 × 8 split per box; smallest certified lower bound 1.755·10⁻³).
  - RQ-A's Theorems 1–4 were reported to Paata at 15:38 UTC on Oct 22 (LOCKED_NOTE, 08:38 PT), so the slip is in the
    reported appendix. RQ-REF1 refereed this same text (VALID, no fixes).
- (r1, cosmetic) The Table 1 caption gives 0.139 and 0.0040 for the extreme widths 0.1384435 and 0.0040625. These
  are outward roundings; the nearest are 0.138 and 0.0041. Section 7.2's 0.0069 for 0.0069375 is the nearest
  rounding. All are within one unit of the last digit.
- Verdict unchanged: **VALID**, NEW.

Addendum 2 (03:30 UTC): **f3 is applied, and the corrected text differs from the refereed one only by f3.** RQ-A
changed its MAIN_RESULT at 03:04 UTC (mirrored 03:08: tex 38b69350…, PDF 5c0ac2ef…, md bb6da13b…; AUDIT_REQUEST
36618b82…; copies in `audit/snapshots/s0315/`). My check is `audit/rqa/a6g_f3_fix_check.py` (output
`audit/rqa/outputs/a6g_f3_fix_check.txt`, A6G_PASS, 1 s).
- **Tex.** Line 653 now reads "κ3B0 − 4c4 ≥ 6.1·10⁻³". Undoing this one substitution gives the refereed tex 6816732f…
  byte for byte, so nothing else changed.
- **Md.** The md gains a header paragraph (lines 7–11) that records the correction, and line 324 has the new figure.
  Without that paragraph, and with the substitution undone, it equals my copy of 6cdb60b2… byte for byte.
- **PDF** (12 pages). All 82 numbers and 320 long words of the tex body occur in its text. The appendix reads
  6.1·10⁻³, and 6.2·10⁻³ occurs nowhere.
- **The figures hold as bounds** (my own enclosures, the a6e functions):
  - Appendix box: κ3B0 − 4c4 ≥ 6.1597·10⁻³ (64 × 64 split). So "≥ 6.1·10⁻³" holds, and so does the md header's
    "certified lower bound 6.158·10⁻³". Also 4c4s − B0² ≥ 5.7245·10⁻⁴ ≥ 5.7·10⁻⁴.
  - Section 7.2's "minimum certified lower bound 1.77·10⁻³" holds as a bound on all 641 boxes. An 8 × 8 split per
    box, refined to 32 × 32 in the one box that needs it (box 640), gives 1.7716568·10⁻³.
- **RQ-A's answer to my question: it was rounding.** RQ-A says that a one-off command of 2026-10-22 06:32 UTC applied
  its verifier's enclosure to that box and printed 6.158e-3, and that the text rounded this to the nearest value
  instead of down. Its bound 6.1578·10⁻³ is below my certified 6.1597·10⁻³ and the exact corner value 6.1635·10⁻³,
  which is consistent with a sound enclosure. I did not read RQ-A's code, and A.6 does not depend on it.
- **RQ-A's sweep of its other decimal bounds** names five figures. Four were already checked: Theorem 1's 0.9402
  (A.6: 361/384 = 0.940104), U9's 0.114431 (A.35), K4 Remark 3 (A.25, a25d) and K5 Remark 4 (A.37 addendum). The
  fifth, K2 line 411 (S_2 u1²/(1+u1²) ≥ 1.414 · 0.707 > 9/20), holds exactly: S_2 = ⌊√2⌋₁₅ ≥ 1.414, and
  U_−² ≥ 707/293 gives u²/(1+u²) ≥ 0.707 for u ≥ U_−.
- Verdict: **VALID**, NEW, with no open fix.

## A.7 RQ-B C1–C4 (elementary) — C1 VALID WITH FIXES, C2–C4 VALID (2026-10-22 06:59 UTC); C1 VALID after the fix (2026-10-23 07:48 UTC)

Source: `RQ-B/rq/CLAIMS.md` (mirrored 06:20, unchanged at 06:59). Notation: Y = sum alpha_i X_i with
X_i ~ Bern(q), mu = EY = q sum alpha, L = (Y - mu)/tau. Exact checks: `audit/rqb/a7_rqb_elementary.py`
(`outputs/a7_rqb_elementary.txt`; own code, exact rationals, no RQ-B code used).

**C1 (level-one form).** Rebuilt proof. First, E[f (x_i - q)] = q(1-q) Delta_i(f), so fhat(i) = E[f chi_i] = tau Delta_i(f).
Forward direction: since EL = 0, E|L| = 2 E[L 1{L>0}] = 2 <alpha, fhat(1{L>0})> <= 2|alpha| sqrt(W^1). Conversely, for
f with values in [0,1] and alpha = fhat/|fhat|, E[fL] = sqrt(W^1(f)) <= E L_+ = E|L|/2. Hence
R^2/(4 tau^2) = sup_f sum Delta_i^2, and C0 is equivalent to sum Delta_i^2 <= max_k k(1-q)^(2k-2).
*Fix:* the CLAIMS text reads "conversely W^1(f) = E[f L]". With alpha = fhat/sqrt(W^1) the correct identity is
**sqrt(W^1(f)) = E[f L]**. As printed it would only give R >= 2 W^1, which is weaker because W^1 <= 1.
Exact check: for q in {1/5, 1/3, 2/7, 9/20} and n <= 3 I checked, over all Boolean f, that fhat = tau Delta and that
E|sum Delta_i (X_i - q)| >= 2q(1-q)|Delta|^2. On 200 random alpha per case I checked the equality
E|Y - mu| = 2q(1-q)<alpha, Delta(1{L>0})> and the upper bound. In every case max_f sum Delta^2 equals
max_{k<=n} k(1-q)^(2k-2), consistent with A.5. Novelty: KNOWN (BF3; RQ-A C0.5).

**C2 (semi-deviation identity).** Rebuilt proof (direct, no telescoping needed): mu - Y = sum alpha_i (q - X_i), so
E(mu - Y)_+ = sum_i alpha_i E[(q - X_i) 1{Y < mu}]. By independence of Y^(i) = Y - alpha_i X_i and X_i,
E[(q - X_i) 1{Y < mu}] = q(1-q)[P(Y^(i) < mu) - P(Y^(i) < mu - alpha_i)]. For alpha_i > 0 this is
q(1-q) P(Y^(i) in [mu - alpha_i, mu)), as claimed. For alpha_i < 0 ("similar formula") it is
**-q(1-q) P(Y^(i) in [mu, mu + |alpha_i|))**, so that term contributes q(1-q)|alpha_i| P(Y^(i) in [mu, mu + |alpha_i|)).
The half-open endpoints matter when atoms sit on them. The exact check covers 3000 random cases, half of them with
integer alpha in {+-1, +-2, +-3} so that atoms hit the endpoints (11,257 coincidences); the identity and
E|Y - mu| = 2E(mu - Y)_+ hold exactly. Novelty: elementary. For alpha = 1_k it reduces to de Moivre's formula
E|S_k - kq| = 2v C(k,v) q^v (1-q)^(k-v+1); I checked this by hand, including the case kq in Z.

**C3 (every success flips the sign).** If alpha_i > 0 and mu <= min alpha, then one success gives Y >= min alpha >= mu,
so {L < 0} = {no success} and E|Y - mu| = 2 E(mu - Y)_+ = 2 mu (1-q)^n. Cauchy–Schwarz (sum alpha <= sqrt(n)|alpha|)
gives E|L|/|alpha| <= 2 sqrt(nq)(1-q)^(n-1/2), which is the k = n term of M(q). The exact check (679 admissible
random cases) confirms {Y < mu} = {0}, the closed form and the bound. Novelty: elementary, minor.

**C4 (Poisson comparison).** Coupling: put N = 0 on {X = 0}. This needs P(N = 0) = e^-q >= 1 - q, which holds.
On {X = 1} use the residual law, which has total mass 1 and mean E N/q = 1 (sympy exact). So E[N | X] = X and
Bern(q) <=_cx Poisson(q). For independent coordinate couplings and the convex function
x -> |sum alpha_i (x_i - q)|, conditional Jensen gives E|L| <= E|sum alpha_i (N_i - q)|/tau. The right side is a
compensated compound Poisson Z with Var Z = q|alpha|^2, so R(q) <= R_Pois/sqrt(1-q). Also E|N_{1/2} - 1/2| = e^{-1/2}
exactly and Var = 1/2, which gives R_Pois >= sqrt(2/e). The inequality was also checked numerically on 300 random
cases (evidence; the worst relative gap is -5e-5, all of the correct sign). The "equivalently over all mean-zero
infinitely divisible Z" remark is correct (the Gaussian and small-jump parts are L^2 limits of compensated Poisson
sums), but C4 does not use it. Note: C4 alone gives only R(q) <= 1/sqrt(1-q) (useless, since R_Pois <= 1). It becomes
useful only together with C5 (CONJECTURE; not audited as a proof). Novelty: the convex order Bernoulli <= Poisson
is classical; the corollary is elementary.

RQ-B items not tagged PROVED (C0, C5 conjectures; F1–F3 failed approaches) are noted, not audited as proofs.

**C1 re-rated VALID (2026-10-23 07:48 UTC).** The typo is gone from the proof that C1 now cites.
- C1 in `rq/CLAIMS.md` 9de8c9c5… gives as its proof "MAIN_RESULT.pdf, Lemma 2.1".
- That proof uses the corrected normalisation in all three files. These are `rq/MAIN_RESULT.md` b47f2945…
  (lines 131–136), the tex e4193842… (line 209) and the PDF a6901915… (Lemma 3.1). Each reads
  tau D(f) = E[fL] with alpha = Delta(f). Since fhat = tau Delta, this is the identity sqrt(W^1) = E[fL] of the fix
  for alpha = fhat/|fhat|.
- A.10 (2026-10-22 08:11) recorded the fix. The A.7a ledger row lagged until this cycle's ledger check a40o found it.
- A.7a is an input of link 1 of the A.40 chain. That link always used the corrected Lemma 2.1, and RQ-REF3 refereed
  it VALID, so only the row changes.

I rebuilt Lemma 2.1 from the definitions again (tau = sqrt(q(1-q)), chi_i = (x_i - q)/tau, L = sum alpha_i chi_i).
- E[f(x_i - q)] = q(E[f | x_i = 1] - E f) = q(1-q) Delta_i(f), so E[f chi_i] = tau Delta_i(f).
- Given alpha, put f = 1{L > 0}. As EL = 0, E|L| = 2E[fL] = 2 tau <alpha, Delta(f)> <= 2 tau ||alpha|| sqrt(D(f)).
  So R <= 2 tau sqrt(sup D).
- Given f with values in [0, 1] and D(f) > 0, put alpha = Delta(f). Then tau D(f) = E[fL] <= E L_+ = E|L|/2
  <= R sqrt(D(f))/2, so D(f) <= R^2/(4 tau^2).
The exact check of 06:59 (`audit/rqb/a7_rqb_elementary.py`) covers both directions.

*Remark r1 (cosmetic, new).* C1 cites "MAIN_RESULT.pdf, Lemma 2.1". In the PDF a6901915… and the tex e4193842…
the lemma is Lemma 3.1, in Section 3 "Level-one form"; 2.1 is its number in the md.
- Elsewhere RQ-B's CLAIMS give the md number with the tex number in brackets, for example C19's
  "MAIN_RESULT Theorem 3.4 (tex Theorem 4.4)". The offset itself was noted in A.18, A.23 and A.26.
- For the record, here are the RQ-B results that the A.40 chain cites by their md numbers, with their numbers in the
  PDF a6901915… and tex e4193842… (§13 of the md is §12 of the PDF; the statements are the same):

  | md number | PDF and tex number |
  |---|---|
  | Lemma 2.1 | Lemma 3.1 |
  | Theorem 3 | Theorem 4.1 |
  | Theorem 3.4 | Theorem 4.4 |
  | Theorem 13.1 | Theorem 12.1 |
  | Lemmas S1, S2, S3 | Lemmas 12.2, 12.3, 12.4 |
  | Corollary S4 | Corollary 12.5 |
  | Lemmas S5, C, D, E | Lemmas 12.6, 12.7, 12.8, 12.9 |

- A write-up of the chain should give both numbers or cite by title.

## A.8 RQ-C C7 (the q -> 0 limit is the infinitely divisible problem) — VALID (2026-10-22 07:03 UTC)

Claim (RQ-C CLAIMS.md, 06:49): lim_{q->0} R(q) exists and equals R_ID := sup{E|X|/||X||_2 : X centred infinitely
divisible, 0 < Var X < oo}. Also R_ID >= sqrt(2/e), and R_ID <= sqrt(2/e) iff (★) E|X| <= e^{-1/2}(1/2 + Var X) for every
centred infinitely divisible X, with equality at N - 1/2, N ~ Poisson(1/2).

Rebuilt proof.
- liminf >= R_ID. Fix X with Levy triplet (0, sigma^2, nu), int x^2 dnu < oo. X is an L^2 limit of
  X_k = sigma Z + sum_j gamma_j (N_j - lambda_j) with finitely many atoms. Truncating nu to eps <= |x| <= G costs
  variance int_{|x|<eps or |x|>G} x^2 dnu -> 0, and discretising the atoms is continuous in L^2. In each X_k the
  block of floor(lambda/q) coefficients gamma tau (with tau chi_i = X_i - q) has sum gamma(Bin(floor(lambda/q), q) - q floor(lambda/q)),
  which converges to gamma(N_lambda - lambda) in law with variance floor(lambda/q) gamma^2 q(1-q) -> lambda gamma^2. The
  Gaussian block of K(q) equal coefficients sigma/sqrt K, with K(q) q -> oo (e.g. K = ceil(q^-2)), satisfies the
  Lindeberg CLT. Independent blocks give convergence in law to X_k with converging variances. Then uniform
  integrability gives E|S_q| -> E|X_k|, so liminf R(q) >= E|X_k|/||X_k||_2, which tends to E|X|/||X||_2 as k -> oo.
- limsup <= R_ID. Take q_m -> 0 realising the limsup, and unit alpha^(m) with E|S_m| >= R(q_m) - 1/m. Since
  |alpha_i| <= 1, P(|alpha_i chi_i| > eps) <= q_m as soon as v_m < eps, so the triangular array is infinitesimal. Var S_m = 1
  gives tightness. Along a subsequence S_m converges in law to X, which is infinitely divisible by Khintchine's
  theorem (row sums of an infinitesimal array; no centring constants are needed here). Uniform
  integrability gives E|S_m| -> E|X| and EX = 0, and Fatou gives Var X <= 1. If X = 0 the bound is trivial. Otherwise
  E|X| <= R_ID sqrt(Var X) <= R_ID.
- (★) equivalence. Apply (★) to sX: E|X| <= e^{-1/2} inf_{s>0}(1/(2s) + sV) = e^{-1/2} sqrt(2V) = sqrt(2/e) sqrt V.
  Conversely sqrt(2V) <= 1/2 + V, since the difference is (sqrt V - 1/sqrt2)^2. At N - 1/2: E|X| = e^{-1/2} and V = 1/2.
- R_ID >= sqrt(2/e): E|N_{1/2} - 1/2| = e^{-1/2} exactly (sympy, `audit/rqb/a7_rqb_elementary.py`), with Var = 1/2.
Consistency: RQ-B C4 (A.7d) gives the quantitative upper half R(q) <= R_ID/sqrt(1-q) for every q, and
"Conjecture S implies R_ID = sqrt(2/e)" holds because N(q) q -> 1/2 and (1-q)^{2N-1} -> e^{-1}.
Not audited as claims: the remark "R_ID = 2 sup_f (int (E D_x f)^2 dmu)^{1/2}" (the Poisson-space level-1 form; it is
plausible via the Mecke formula, but the sup must also range over the intensity mu and the Gaussian part enters only
as a limit), and C8, C9 (NUMERICAL).

Still open from A.2: the 06:49 text of C4(a) still writes the gamma < 0 formula with "sum_k". It must be sum over
k >= 1 (fix f1), and "equality only at gamma = 1" should include the trivial gamma = 0 (fix f2).
(Update 2026-10-23 07:48: settled. RQ-C's mirror of 2026-10-22 07:09 already has both fixes, and A.2 is re-rated
VALID; see the A.2 addendum.)

Novelty: no source found for lim R(q) = R_ID as a statement; the method is the classical infinitesimal-array
limit theory (Khintchine; Gnedenko–Kolmogorov), so NEW as a statement, KNOWN as a technique.

## A.5b RQ-C C6, part n = 7 — VALID (2026-10-22 07:39 UTC)

Claim (RQ-C CLAIMS.md, 06:49): for n = 7 and every q in (0,1),
R_7(q) = 2 tau sqrt(max_{k<=7} k(1-qbar)^{2k-2}). The only extremisers are equal coefficients on k* = min(7, N(qbar))
coordinates (both k*-1 and k* at qbar = q_{k*}), and every other threshold function is strictly worse.

Reduction (as in A.5). By duality R_7^2 = 4 tau^2 max_f P_f over threshold functions f on 7 bits. Functions with at
most 6 relevant variables are covered by A.5 (P_f < M_r <= M_7 unless f is OR_k or NOR_k). So it remains to show
P_f(q) < M_7(q) := max_{k<=7} k(1-q)^{2k-2} on [0, 1/2] for every threshold function with 7 relevant variables other
than OR_7 and NOR_7. Every such f = [w.x > theta] is, after a permutation of coordinates, g(x xor s): put s_i = [w_i < 0]
and sort |w|. Here g is a positive threshold function with sorted weights, and P_f is permutation invariant.

Independent computer verification (own code; I read only RQ-C's statement and summary numbers).

| step | my program | result |
|------|------------|--------|
| enumeration of the g | `audit/rqc/a5b_ltf7_enum.c`: all integer weights W >= w_1 >= ... >= w_7 >= 0 and all thresholds, deduplicated by truth table | W = 20 (888,030 weight vectors) and W = 24 (2,629,575) both give the same **29,375** functions (identical lists) |
| no duplicates | brute force over all 5040 permutations: S_7-canonical forms | pairwise distinct; irrelevant variables always form a suffix |
| completeness | sum_g 2^r(g) n!/\|Aut_n(g)\|, with \|Aut\| computed by brute force over 5040 permutations | equals OEIS A000609(n) for **every n = 0..7**, including 8,378,070,864 for n = 7 (value confirmed on oeis.org) |
| class count (cross-check) | `a5b_ltf7_classes.py`: prod over blocks of (\|block\|+1); the block structure is consistent with the brute-force \|Aut\| for all 29,375 | **2,490,634** permutation classes (= RQ-C); 2,452,178 have 7 relevant variables, and the other 38,456 are exactly the n <= 6 classes of A.5 |
| functions checked | all f = g(x xor s) with r(g) = 7 (28,262 g, 128 s each). No class reduction is needed. | 3,617,536 functions, giving **1,013,217** distinct integer polynomials P_f = sum_m e_m q^m (1-q)^(12-m) (md5 in `outputs/a5b_work7_MD5SUMS`; W = 24 gives a byte-identical file) |
| certificate 1 | `a5b_ltf7_certify.py`: pieces J_k with rational outer bounds of q_k (error < 1e-30). D_k = k(1-q)^(2k-2) - P_f is positive at both ends and at the midpoint (exact integers) and has no real root in J_k (FLINT/Arb isolation; real roots are returned with an exactly zero imaginary part) | **7,092,512 piece checks, 0 failures**, no ambiguous root ball (the exact Sturm fallback was never triggered) |
| certificate 2 | `a5b_ltf7_sturm_all.py`: exact Sturm root counting (sympy, rationals) on every piece of every polynomial, plus the exact midpoint sign | **7,092,512 piece checks, 0 failures** |
| exact ties | exact comparison of e-vectors with those of k(1-q)^(2k-2) | exactly one polynomial, 7(1-q)^12, shared by OR_7 and NOR_7 (and by no other r = 7 function) |
| runner-up (evidence) | `a5b_ltf7_runnerup.py` (float, 2007 grid points including every q_k) and `a5b_ltf7_g34_check.py` (exact) | the maximum of P_f/M_7 is **0.999852 at q_4 = 0.13397**. Its polynomial equals P for g_{3,4} = x1 v x2 v (x3 & ~AND_4(x4..x7)) exactly, with ratio 0.999851846, matching RQ-C's 0.99985. RQ-C's closed form for P_{g_{k,m}} - k p^(2k-2) is verified exactly for (k,m) = (2,1), (2,3), (3,2), (3,4), (4,3). |

Conclusion. Combined with A.5, C6 holds for every n <= 7 and every q in (0,1). The value is
2 tau sqrt(max_{k<=n} k(1-qbar)^{2k-2}), with only the OR_{k*}-type extremisers. The special cases quoted by RQ-C follow:
2 tau on [q0, 1-q0], sqrt2(1-q) 2 tau on [q_3, q_2], and the Stone value once n >= N(qbar), since k(1-q)^{2k-2} is
unimodal in k with its peak at N(q). The method differs from RQ-C's (they use IEEE directed rounding on dyadic boxes and
one class representative per Aut(g)-orbit); I use all negation patterns, exact integer polynomials, Arb root isolation,
and a full exact Sturm second pass. Novelty: NEW (computer-assisted). BF3 mentions only numerics for n <= 7.

---

## A.9 RQ-C C11 (R(q) = S_2(q) on [256/985, 1-1/sqrt2]) — VALID, NEW (2026-10-22 07:59 UTC)

**Claim** (RQ-C `MAIN_RESULT.md/.tex/.pdf`, PDF built 07:43 UTC; CLAIMS C11; AUDIT_REQUEST.md).
Let q_E = 256/985, q0 = 1-1/sqrt2 and S_2(q) = 2 sqrt2 (1-q) tau. For every q in [q_E, q0], every n and every
unit alpha, E|sum alpha_i chi_i| <= S_2(q). Hence R(q) = S_2(q) on [q_E, q0], and by symmetry on [1-q0, 1-q_E].
For q in [q_E, q0) (and the mirror) equality holds only at alpha = +-(e_i+e_j)/sqrt2. Combined with A.6:
R(q) = 2 tau max{1, sqrt2 max(q,1-q)} on [256/985, 729/985].

### Rebuilt proof (each step re-derived from the hypotheses)

The proof uses RQ-A's three mechanisms (A.6) with a new target, in the parametrisation u = sqrt((1-q)/q) in [u0, 27/16].
1. *Reduction* (BF3 Lemma 9.4, rebuilt in A.0 and A.6): E|L| = 2 tau a + 2 E R_a(bM), where a is the largest |alpha_i|.
   So E|L| <= S_2 iff E R_a(bM) <= T(u,a) = tau (sqrt2 u^2/(1+u^2) - a). Correct.
2. *Cells* (Lemmas 8 and 10). These are RQ-A's Lemma 7 and Definition 8 / Lemma 9, which I rebuilt in A.6:
   - the domination of R_a(b.) by the cell lines;
   - the moment identity for E P(M);
   - the term-by-term bounds, using |p3| <= r, p4 = r^2, |p5| <= m r^2 and r^4 <= p6 <= m^2 r^2.

   The only new step is T_cell <= T(u,a) on the cell. It holds because tau is decreasing and u^2/(1+u^2) is
   increasing on u >= 1, sigma < sqrt2, a <= a2 and X > 0. Correct.
3. *Quartic comparison* (Lemma 13, which is RQ-A Lemma 12 from A.6). I re-checked that no hypothesis on q is used:
   - Steps 1–3 (P >= 0, P >= l1, P >= l2) need only s > 0, (Q1) and (Q3).
   - Step 4 needs c4 > 0, kappa4 < 0 (u^2 < 2+sqrt3) and p3^2 <= p4 <= 1.
   - Step 5 is the identity 2 tau a + 2q(1-q)(bu - av) = 2 tau (1-q)(a+b).

   So for 1 < u < 19/10, E|a chi_1 + bM| <= 2 tau (1-q)(a+b) - 2(1-p3)(kappa3 B0 - 4c4), and
   2 tau (1-q)(a+b) <= 2 sqrt2 (1-q) tau = S_2 since a + b <= sqrt2. Correct. Above q0 (A.6) the same bound was
   compared with 2 tau; here it is compared with S_2, which is the observation that makes C11 work.
4. *Near-dictator* (Lemma 15), re-derived:
   - (x-t)_+ <= 27 x^4/(256 t^3), with the maximum of (x-t)/x^4 at x = 4t/3;
   - (1-q)u^3 = tau u^4 and q v^3 = tau v^4;
   - E M^4 = 3 + kappa4 p4 <= 3;
   - a^-3 + a^-2 - a^-1 - 1 is decreasing (its derivative is a^-4 (a-3)(a+1)), and u^4 + u^-4 is increasing.

   The constant at (u, a) = (27/16, 93/100) is exactly 74761407288326311/88539849484664832 = 0.844381459 < 1 (my code).
   So E|L| < 2 tau, and 2 tau <= S_2 for q <= q0. Correct.
5. *Assembly and extremisers.*
   - The pieces chain: a in [0, 0.69] and [0.83, 0.93] by cells, a(2/5) = 20/29 < 0.69 and a(533/1000) = 0.830161 > 0.83
     for the quartic boxes, and [0.93, 1) by the near-dictator lemma.
   - a = 1 gives 2 tau <= S_2, with strict inequality for q < q0.
   - The cell and near-dictator pieces are strict.
   - In the quartic piece, equality needs a = b and, by the strict (Q4), p3 = 1, i.e. M = chi_j.

   So (a) and (b) follow. Correct.

### Independent computer verification (RQ-AUD code only)

`audit/rqc/a9_c11_verify.py` reuses my A.6 programs `audit/rqa/a6_lemmaS_verify.py` (cells: exact rationals and Arb
root isolation) and `audit/rqa/a7_lemmaQ_verify.py` (quartic: Arb balls with bisection, and my own sufficient condition for
P >= l2, which differs from RQ-C's (Q3)). No RQ-C code is used. Data md5s are in `audit/rqc/c11_data/MD5SUMS`:
cellsA 1688742a…, cellsB ccaf5342…, quartic 83df29fb…. Output: `audit/rqc/outputs/a9_c11_verify.txt`.

| step | result |
|------|--------|
| 393 cells (360 in cellsA, 33 in cellsB), my target with sqrt2 replaced by floor(10^30 sqrt2)/10^30 | **393/393 certified**, no subdivision needed |
| the same with RQ-C's sigma = 14142135623730950/10^16 | 393/393 |
| exact tiling of [u_L, 27/16] x [0, 0.69], [u_L, 27/16] x [0.83, 0.93] and the quartic rectangle [u_L, 27/16] x t[2/5, 533/1000] | all covered; all inside; area sums equal, so interiors are disjoint |
| 128 quartic boxes, my conditions (Q0)–(Q3) | **128/128**, on 1,760 certified sub-boxes (depth <= 4) |
| strict kappa3 B0 - 4 c4 > 0 (needed for (b)) | 128/128; smallest certified lower bound 5.9e-7 (RQ-C reports 1.3e-6 with another subdivision) |
| glue | u_L < u0 ((u_L^2-1)^2 = 1.99935 < 2); q(27/16) = 256/985; kappa4(27/16) = -0.80 < 0; a(2/5), a(533/1000); the near-dictator constant |
| RQ-C's own `verify_ext.py`, rerun on a copy (cross-check only) | same output as their log: ALL CHECKS PASSED |

**Negative tests** (`a9b_c11_negative.py`, outputs `a9b_c11_negative.txt` and `a9b_c11_negative_depth0.txt`):
- Corrupted cells are rejected:
  - P x 0.9: 393/393;
  - c0 - 1e-3 and c0 - 1e-5: 393/393 each;
  - c6 = 0 (cells with c5 != 0): 375/375;
  - u2 + 1/20: 393/393;
  - a1 - 1/20: 363/363;
  - a2 + 1/100: 277/393.
- Lowered target without subdivision:
  - r2 = 1.4142 rejects none, 1.4141 rejects 5 and 1.414 rejects 10.
  - This matches the smallest float slack min h/T = 3.39e-5 (cell u[1.5537, 1.5872] x a[0.0375, 0.045]), which is RQ-C's (w2).
- Corrupted quartic boxes:
  - c4 x 100, c4 / 100 and c4 x 3 are rejected 128/128; c4 / 3 is rejected 99/128.
  - The 8 boxes at a = 1/sqrt2, moved to q < 1/4 or to u just above sqrt3, are rejected 8/8. This is where the quartic
    method must fail.
- Removing one cell is detected as a gap.
- At a = 9/10 the near-dictator constant is 1.29 > 1.

**Attack** (`a9c_c11_killer.py`, float evidence). Exact enumeration for n = 8..16 at 8 values of q in [q_E, q0], with
60 starts each and the monotone duality ascent alpha <- Delta(1{L>0}). The best ratio E|L|/S_2 is 1 + 2e-15, always at
(1,1)/sqrt2. For n <= 7 the exact theorem of A.5/A.5b already gives R_n = S_2 on [q_3, q_2], which contains [q_E, q0].

**Text.** No mathematical fix is needed. The markdown has a stray "0" before the last QED; this is a pandoc artifact, and the
LaTeX and PDF are fine. The markdown summary table writes 0.69, 0.83, 0.93 and 0.84438 where the LaTeX writes fractions.
Every other number in the markdown appears in the PDF text.

**Novelty: NEW.** No earlier source determines R(q) for any q < 1-1/sqrt2.
- Ivanisvili–Stone (arXiv:2407.04835, Remark 1.3) explicitly *assume* that R(p) equals the equal-coefficient value (1.10).
- Stone's thesis §4.2 gives the n = 2 closed form, which is the matching lower bound.
- My web search (2026-10-22) found nothing further. arXiv:2608.29703 (L. Yu, Aug 2026) concerns symmetric Rademacher sums
  with small coefficients.
- RQ-A's MAIN-2 claims the same formula on the larger range [1/5, q0] by another method (two-coordinate split). It is not
  written up yet and is not covered by this verdict.

---

## A.10 RQ-B C6–C10 and F4 (rq/MAIN_RESULT, 07:43) — C6–C10 VALID, F4 CONFIRMED (2026-10-22 08:11 UTC)

Source: `RQ-B/rq/MAIN_RESULT.md` (also `.tex/.pdf`) and `rq/CLAIMS.md` (07:43). The notation is RQ-B's:
- s = ln(1/(1-q));
- M(q) = max_k 2 sqrt(kq)(1-q)^(k-1/2);
- B(q) = sqrt(2q/(e(1-q)s));
- q_k^* = 1 - e^{-1/(2k)};
- R_ID = sup E|Z|/||Z||_2 over compensated compound Poisson Z.

Every proof below was rebuilt by hand. Computer checks are in `audit/rqb/a10_rqb_c6_c10.py` (output
`outputs/a10_rqb_c6_c10.txt`), `a10b_f4_smallc.py` and `a10c_apc_remark.py`.

**A.10a — C6 (Theorem 3), VALID.**
- Let N_i ~ Poi(s) be i.i.d. and x_i = 1{N_i >= 1}. Then x_i ~ Bern(1-e^{-s}) = Bern(q).
- Stein–Chen gives E[(N-s)G(N)] = s E[G(N+1) - G(N)], which I re-derived. Since x(N+e_i) = x^{i<-1}, this yields
  E[F(N)(N_i - s)] = s(1-q) Delta_i(f). Checked to 1e-51 on 18 random cases.
- Test against I = sum Delta_i (N_i - s): s(1-q)D = E[F I] <= E I_+ = E|I|/2 <= (R_ID/2) sqrt(sD).
- Then Lemma 2.1 (A.7a, whose typo is fixed in this version) gives R^2 <= R_ID^2 q/((1-q)s).
- Consistency: with the exact values of A.6 and A.9, the implied lower bounds on R_ID are at most 0.8532, below
  sqrt(2/e) = 0.8578, so there is no conflict with C5. At q_1^* the bound gives exactly sqrt(2/e).

**A.10b — C7 (Theorem 4), VALID.**
- limsup <= R_ID follows from Theorem 3, since q/((1-q)s) -> 1.
- liminf: Binomial(round(c_j/q), q) -> Poi(c_j), and E Z_q^2 -> E Z^2 gives uniform integrability. This is the same
  argument as in A.8.

**A.10c — C8 (Theorem 5 and Proposition 5.1), VALID as stated, i.e. conditional on C5.**
- B(q) = 2 sqrt(q/(1-q)) max_{kappa>0} sqrt(kappa) e^{-kappa s} and M = the same with kappa restricted to integers.
  Equality holds iff 1/(2s) is an integer, i.e. q = q_k^*.
- B/M = 1/max_k g(ks) with g(x) = sqrt(2ex) e^{-x}.
- On the band of k, log g(ks) is concave with maximum 0 at s = 1/(2k). So the largest excess is at the ties
  s_k = (1/2) ln(1 + 1/k), giving E_k. E_k decreases because x_k = (k/2) ln(1+1/k) increases to 1/2 and g increases
  on (0, 1/2].
- 50-digit checks:
  - M(q_k^*) = B(q_k^*), with k the maximiser, for k = 1..5 (values 0.977039, 0.914274, 0.894777, 0.885280, 0.879662);
  - E_1 = 0.0302794, E_2 = 0.0103045, E_5 = 0.0020788;
  - E_k strictly decreasing for k <= 2000, and 16 k^2 E_k -> 1;
  - grid sups of B/M - 1 equal E_1, E_2 and E_5 on (0, q0], (0, 1/4] and (0, 1/10], attained at the predicted tie points.
- Converse: R(q) = M(q) along q -> 0 forces R_ID = sqrt(2/e) by Theorem 4.

**A.10d — C9 (Proposition 6), VALID.**
- Correction (2026-10-22 20:37 UTC): the threshold in (b) is 2(sqrt(2/e) - sqrt(2/pi)) = 0.11975864831568…
  (256-bit Arb), not 0.11976 as my ledger row said. RQ-B states the exact expression; its decimal 0.11976
  (rq/CLAIMS line 69; "0.11976..." in MAIN_RESULT.md line 286 and tex line 429) is rounded up, and a K with
  int |x| dK = 0.11976 is not covered by the proof. The summary lines (MAIN_RESULT.md line 41, tex line 100) use
  0.1197, which is safe. Cosmetic remark for RQ-B: write 0.119758… or 0.1197. Details in A.35.
- (a) Every jump is >= m, so Z < 0 iff there is no jump. Then E|Z| = 2m e^{-v}, and v >= m^2 by Cauchy–Schwarz
  (K is a probability), so E|Z| <= max 2m e^{-m^2} = sqrt(2/e). Checked against direct Poisson enumeration for random
  K (error 3e-15).
- (b) The ID zero-bias identity E[Z g(Z)] = E g'(Z + UJ) follows from Mecke's formula, which I re-derived. Since f' is
  1-Lipschitz (BF3 Lemma 9.6, verified in A.0), E|Z| - sqrt(2/pi) <= E|UJ| = (1/2) int |x| K(dx).

**A.10e — C10 (Proposition 7), VALID.**
- Ladder step: alpha = -2y tau/lambda sends y to -y/lambda (if chi = u) or to y/lambda (if chi = -v), since tau u = 1-q
  and tau v = q. It keeps y^2 + r = c because 1 - 4tau^2 = lambda^2. It is admissible iff |y| <= lambda sqrt c.
- Final step: E| . | = sqrt c (lambda rho + 2 tau sqrt(1-rho^2)) = sqrt c cos(arccos lambda - arccos rho), which
  is increasing on (lambda^2, lambda].
- Certified computation (arb, 20,000 rational subintervals of [1/200, 49/100], plus explicit bounds on the two end pieces):
  L(q) > 0.962 on all of (0, 1/2). The minimum is 0.9622505 at q = 0.2113249 (= (3-sqrt3)/6).
- Exact 50-digit evaluation of the strategy for six pairs (q, eps): every bet is admissible, y^2 + r = c holds on every
  path to 1e-50, and the value is >= sqrt(1-eps^2) L(q) in every case. At q = 0.2, eps = 1e-6 it is 0.98862306,
  matching RQ-B's 0.9886.
- The consequence for scalar-state Bellman functions is correct as stated: a function B(y, r) with B(y, 0) >= |y| and
  B(y, r) >= E B(y + alpha chi, r - alpha^2) bounds every predictable strategy. It does not apply to BF3's method,
  as RQ-B says.

**A.10f — F4, CONFIRMED (numerical).**
- My own enumeration (Poisson lattice with the Gaussian part in closed form) gives:
  - split value 0.7837058;
  - best merged single atom of variance 0.328: 0.7752794 at c = -0.5626;
  - Gaussian merge 0.7707013;
  - excess 0.00843.

  All of these equal RQ-B's numbers.
- The sup over c is covered as follows:
  - |c| <= 0.005 by the zero-bias bound d_W(Z_c, G) <= |c|;
  - |c| >= 4.25 by E|W + Z_c| <= E|W| + 2w/|c|, with E|W| = 0.62907;
  - 0.005 <= |c| <= 8 by a grid scan (2,520 points plus local refinement).

  The middle range is numerical, so F4 is a confirmed counterexample at float precision, not a certified one. It is a
  negative result about a proof technique and is not used by any theorem.

**Text remarks (no verdict impact).**
- Remark 3.3 asserts in parentheses that the k with ks < 1 attains A(s) "whenever the value exceeds 0.82, e.g. for all
  s <= 0.35". This needs sup_{mu >= 1} E|N_mu - mu|/sqrt(mu) < 0.82. I find the peaks
  2(m+1/2)^{m+1/2} e^{-(m+1/2)}/m! to be 0.819833 (m = 1), 0.811174, 0.807395, ..., decreasing to sqrt(2/pi) for
  m <= 5000, so the parenthetical is true numerically. RQ-B should state that this is numerical or prove the
  monotonicity. The implication "APC(s) => C0 at q" itself is correct.
- Theorem 1 (equal coefficients) is Stone's theorem (KNOWN; RQ-C SOTA K5), re-proved correctly.
- In Lemma 2.1 the A.7a typo is fixed: the proof now reads tau D(f) = E[fL].

---

## A.11 RQ-A MAIN-2 (R(q) = S_2(q) on [q3, q0]) — VALID, NEW (2026-10-22 08:52 UTC)

**Claim** (RQ-A `MAIN_RESULT_K2.md/.tex/.pdf`, release of 08:27 UTC, re-mirrored unchanged in substance at 08:48;
`AUDIT_REQUEST.md` A.11; CLAIMS MAIN-2). Let q3 = 1-sqrt(2/3), q0 = 1-1/sqrt2, tau = sqrt(q(1-q)) and
T = S_2(q) = 2 sqrt2 (1-q) tau.
- (a) For every q in [q3, q0], every n and every unit alpha, E|sum alpha_i chi_i| <= T. Hence R(q) = T on [q3, q0] and
  R(q) = 2 sqrt2 q tau on [1-q0, 1-q3].
- (b) Equality holds iff alpha = +-(e_i+e_j)/sqrt2, or q = q0 and alpha = +-e_i, or q = q3 and alpha = +-(e_i+e_j+e_k)/sqrt3.
- (c) The interval is sharp: R(q) > T for q < q3 and for q in (q0, 1/2].
- Corollary 2, with A.6: R(q) = 2 tau max{1, sqrt2 (1-q), sqrt2 q} on [q3, 1-q3] = [0.18350, 0.81650].

My copies: text `audit/rqa/k2_text/` (08:48 version, md5s in `MD5SUMS`); data `audit/rqa/k2_data/` (08:19) and
`audit/rqa/k2_data_v2/` (08:27 release). All 117 manifest files match RQ-A's `outputs/k2_MD5SUMS.txt`
(one_A 1795c1e1…, one_B 8ad55a96…, manifest 659b6f25…).

### Rebuilt proof (each step re-derived from the hypotheses)

Parametrisation u = sqrt((1-q)/q), v = 1/u, so [q3, q0] is u in [u0, u3] with u0 = sqrt(1+sqrt2) and u3 = sqrt(2+sqrt6).
1. *Symmetry and test vectors* (Lemmas 3, 4). For k < 1/q the sum chi_1+...+chi_k is positive iff some chi_i = u
   (because u > (k-1)v iff q < 1/k). This gives E|chi_1+...+chi_k|/sqrt k = 2 sqrt k (1-q)^{k-1} tau. So 2 tau <= T iff
   q <= q0, and 2 sqrt3 (1-q)^2 tau <= T iff q >= q3. This is (c) and the "if" part of (b). Correct.
2. *Two-coordinate split.* Let a1 >= a2 be the two largest |alpha_i|, with alpha_1 > 0 after a global sign change.
   Write (a1, a2) = r(c(t), d(t)) with the half-angle t in [0, sqrt2-1], s the sign of alpha_2, b = sqrt(1-r^2), and
   M the normalised rest. Then |beta_i| <= m̄ = min(1, a2/b). Correct.
3. *Lemma 5* (two coordinates). E|c chi_1 + s d chi_2| = 2 tau max(c, d, [s=1](1-q)(c+d)), from p_j x_j = tau g_j.
   This is <= T sqrt(c^2+d^2) for q <= q0 (there is no lower limit on q). The equality cases are as stated. I checked
   the formula exactly at 8000 random rational points.
4. *Lemma 6* (three-bit lemma). E[f chi_i] = tau Delta_i(f), so G_3(c) = tau max_f sum c_i Delta_i(f)
   <= tau |c| max_f |Delta(f)|. It is enough that P_f = 8(1-q)^2 - sum Delta_i(f)^2 >= 0 for all 256 f on [q3, q0].
   Equality needs c parallel to Delta(f) for a maximising f with P_f = 0. My exact check is below. Correct.
5. *Moments* (Lemmas 8–10).
   - I re-derived the cumulants from 1/(q(1-q)) = w + 2: kappa3 = u-v, kappa4 = w-4, kappa5 = (u-v)(w-10), kappa6 = w^2-26w+64.
   - The moment identities are standard.
   - The power-sum bounds p3^2 <= p4 <= m^2, p4^2 <= p6 <= m^2 p4 and |p5| <= m p4 follow from Cauchy–Schwarz.

   With rho = sqrt(p4) in [0, m], this gives the one-variable objective bound
   h(rho) = Theta - A - |B| rho - G rho^2 - E^- rho^4. The negative kappa6 c6 term uses p6 >= p4^2 = rho^4. Correct.
6. *Lemma 11* (sign information). If beta_{i0} = -m, then p3 <= -m^3 + sum_{i != i0} |beta_i|^3 <= -m^3 + (1-m^2)^{3/2} = phi(m).
   phi is decreasing (phi' = -3m^2 - 3m sqrt(1-m^2) < 0), so p3 <= phi(m_c) for m >= m_c. Correct.
   - The condition 2 m_c^2 > 1 of Definition 23 is equivalent to phi(m_c) < 0. Lemma 24 does not need the uniqueness
     of the largest coordinate that it also implies: if both +m and -m occur, either branch applies.
7. *Lemma 13 with p\** (RQ-A's audit point 1). Assume X = c3 + 10 c5 >= 0, kappa3 >= kappa3^- > 0 (q < 1/2) and
   p3 <= p* < 0. Then kappa3 X p3 <= kappa3 X p* <= kappa3^- X p*, so the linear term becomes the constant
   kappa3^- X p*, and |B| = 0. If X < 0, the generic bound is used. Correct.
8. *Lemmas 14–19* (one-coordinate cells; conditional expectation; envelope; box certificates).
   - The cells are the A.6/A.9 mechanism with target tau(sqrt2(1-q) - a), using 2 tau a + 2 E P(M) <= T.
   - F(y) = sum_j |p_j x_j + p_j b y| is convex and piecewise linear.
   - Its box envelope takes, for each atom, the plus or minus line with interval-endpoint slopes. These are switched
     at the breakpoints z_j and at 0. I built this envelope myself; RQ-A's verifier takes the maximum of the 16
     sign-pattern lines instead.
9. *Lemma 20* (tail bound). E|y + bZ| = |y| + 2E(w - |y|)_+ with w = -sgn(y) b Z.
   - (x-t)_+ <= 27x^4/(256 t^3), because 27x^4 - 256t^3(x-t) = (3x-4t)^2(3x^2+8tx+16t^2), checked symbolically.
   - Also 2E(w - |y|)_+ <= E|w| = b E|Z|.

   Correct; the bound also holds at y = 0 with the first entry of the minimum.
10. *Lemma 21* (near-circle tests). Lemma 5 gives the main term <= T r, the slack is T(1-r) = T b^2/(1+r), and the error
    is O(b^4). E M^4 <= 3 + max(0, kappa4) m̄^2. Valid for u >= u0 only, as stated. Correct.
11. *Lemma 22 and the piece tests (A3)/(B3)* (audit point 4).
    - If beta_{i0} = +m, then L = Y + b' M' with a3 = bm, b' = b sqrt(1-m^2) and r'^2 = 1 - b'^2. Here M' is
      independent of Y, and E M'^4 <= 3 + max(0, kappa4).
    - Lemma 6 gives E|Y| <= T r' (only for q in [q3, q0]).
    - The enclosures (b'^2)^+ = (b^+)^2(1-m_1^2), r'^+ >= sqrt(1-(b^-)^2(1-m_2^2)), the product formula
      p_j y_j = tau sum_i (+-a_i) prod_{k != i} Pr[x_jk], and the monotonicity of q^k(1-q)^{3-k} in u on
      [1.5, 2.2] are all correct.
12. *Lemma 24* (m-split; audit point 2). The case split is exhaustive:
    - max|beta_i| <= m_c: certificate c(1) with cap min(m_c, m̄);
    - some beta_i = -m with m >= m_c: certificate c(2) with p* (by Lemma 11);
    - otherwise some beta_i = +m with m in [m_c, min(1, m̄)]: a piece.

    Equality is possible only at m = 1, where L = Y. Correct.
13. *Proof of Theorem 1* (Section "Proof of Theorem 1").
    - Case split: a1 = 1; a1 <= 9/20 (cells); r = 1 (Lemma 5); otherwise a box of the cover. A box with a1 > 9/20 is
      never `small`, because r2 c(t1) <= 9/20 bounds a1 on the whole box.
    - The lp and nc boxes and the cells are strict. Equality in an ms box forces (a1, s a2, b) to be a multiple of
      (1,1,1), by Lemma 6, because all three entries are nonzero. This gives (b).
    - (c) and Corollary 2 follow from Lemma 4 and A.6. Correct.

### Independent computer verification (RQ-AUD code only)

My verifiers use no RQ-A code:
- `audit/rqa/a11_main2_verify.py`, on the 08:19 data;
- `audit/rqa/a11_main2_verify_v2.py`, on the whole 08:27 cover; it reuses the first file and adds the m-split and
  three-bit parts.

They use exact rationals throughout, with root isolation by Arb (python-flint) on rational polynomials and sqrt
bounds from integer square roots. sqrt2 in the target is replaced by floor(10^30 sqrt2)/10^30. Outputs are
`outputs/a11_main2_verify.txt` and `outputs/a11_main2_verify_v2.txt`.

| step | result |
|------|--------|
| md5 of the 117 manifest files against RQ-A `k2_MD5SUMS.txt` | 0 mismatches |
| range: U_- = 1553773/10^6 < u0; U_+ = 1054691/500000 > u3, as (U_+^2-2)^2 > 6; sqrt2-1 <= T8 < 1 | True |
| one-coordinate cells tile [U_-, U_+] x [0, 9/20] (exact; inside; area sum equal) | 784 cells, OK |
| two-coordinate boxes tile [U_-, U_+] x [0, T8] x [9/20, 1], each sign (inside; volume sum = region volume; 0 pairs with overlapping interiors) | s=+1: 38,631 boxes; s=-1: 16,884 boxes; both OK |
| `small` boxes have r2 c(t1) <= 9/20 | 681/681 |
| one-coordinate cells (A.9 checker, my target) | **784/784**, no subdivision |
| LP boxes: my envelope, domination on every piece, my objective bound | **48,810/48,810** at depth 0 |
| near-circle boxes: my tests (pointwise ratio with Lemma 5; monotone; mixed) | **4,835/4,835** (1,973 by test 1, 2,862 by test 2) |
| m-split boxes: b^- > 0; 2m_c^2 > 1 >= m_c; p* < 0 and p* >= phi(m_c) exactly; c(1) and c(2) domination and objective bounds (c(2) with p*); the s3 = +1 pieces cover [m_c, min(1, m̄)]; each piece passes my (A3) or (B3) | **1,189/1,189**; 1,669 pieces (1,659 A3, 10 B3); all ms boxes have u1 >= 2.09; m_c in {31/40, 4/5, 33/40, 17/20, 7/8, 9/10} |
| three-bit lemma: P_f = 8(1-q)^2 - sum Delta_i(f)^2 for all 256 f. I divide out mu3 = 3q^2-6q+1 and mu0 = 2q^2-4q+1 (the minimal polynomials of q3 and q0); the cofactor has 0 Sturm roots on [q3^-, q0^+], and the sign at 1/4 times (-1)^{mult(mu3)} is positive | fails for **0/256**. P_f == 0 identically exactly for the 6 functions +-OR_2; P_f(q3) = 0 exactly for +-OR_3; P_f(q0) = 0 exactly for the 6 functions +-dictator. These are the equality cases of Lemma 6 |
| second exact method: sympy Sturm counts replace Arb in every root isolation (`a11g_main2_sturm_v2.py`; `a11d` for the 08:19 data) | 0 failures: 48,810 LP boxes, 784 cells, 1,189 m-split boxes (83 s); 08:19 data: 25,959 LP and 450 cells |
| the [1/5, q0] part, 08:19 data, also with RQ-A's rational sqrt2 bound | all parts pass (25,959 LP, 3,928 NC, 450 cells, 437 small) |
| RQ-A's own `verify_k2.py`, rerun on a copy of the 08:27 data (cross-check only) | parts A–E pass (784 cells; 49,999 box certificates including both certificates of the 1,189 ms boxes; 4,835 NC boxes) |

I also re-checked that the helpers inherited from my A.6/A.9 code are valid up to U_+ = 2.1094:
- the cumulant enclosures need only u >= 1 and w = u^2 + u^-2 < 10 (here w <= 4.68);
- q, q(1-q), (1-q)^2, q tau and tau are monotone in u;
- (1-q)tau is unimodal with its maximum at u = sqrt3, which T^- accounts for.

### Negative tests

On the 08:19 data (`a11b_main2_negative.py`, `outputs/a11b_main2_negative.txt`):
- LP boxes:
  - corruptions rejected: P x 0.9 2000/2000, u2 + 1/20 2000/2000, r1 - 1/20 2000/2000, c6 = 0 1944/2000;
  - c0 lowered by 2x the box's domination slack: 200/200 tightest boxes rejected;
  - raising c0 by 2x the moment slack: 200/200 rejected.
- Float slacks over all 25,959 LP boxes: domination min 8.6e-4, moment min 4.2e-7 (box s=-1, u[1.74, 1.75]).
- Near-circle boxes: r1 - 1/10 is rejected 3928/3928.
- Removing, duplicating or shifting one box is detected by the tiling check.
- Cells: P x 0.9 and c0 - 1e-5 are rejected 450/450.

m-split boxes (`a11f_main2_ms_negative.py`, `outputs/a11f_main2_ms_negative.txt`, all 1,189 boxes). Rejected 1189/1189 each:
- p* := phi(m_c) - 1e-9;
- dropping the top piece;
- raising the lower end of every piece by 1/1000 (gap at m_c);
- using c(2) without p* (so the sign information is load-bearing);
- using c(1) with cap min(1, m̄) (so the m-split is load-bearing);
- the zero polynomial as certificate.

Lowering the constant terms of c(1) and c(2) is rejected 0, 946 and 1189 times for shifts of 2e-4, 2e-3 and 1e-2.
Lowering the target by 1e-4 rejects 42 boxes.

Sharpness: E|chi_1+chi_2+chi_3|/sqrt3 - T is +1.1e-4 at q3 - 1e-4 and -1.1e-4 at q3 + 1e-4. P_OR3(0.1835) < 0 < P_OR3(0.18351),
and P_dictator(0.2929) < 0 < P_dictator(0.29289). As RQ-A says (audit point 7), the (A3) test cannot by itself detect a box
moved beyond u3, because its main term rests on Lemma 6. The restriction u in [u0, u3] in Lemma 24 is essential and is
stated correctly.

**End-to-end semantic test** (`a11e_main2_semantic.py`, float, exact enumeration of the laws). I sampled about 13,700
admissible points with u in [u0, u3]: random boxes and cells, random u, t, r, and residuals with up to 12 coefficients
satisfying |beta_i| <= m̄. For the ms cases the largest coefficient is forced to +-m with m >= m_c. In every case the
certified bound is >= E|L| and < S_2:
- lp: E P - E|L| >= 3.1e-3 and S_2 - E P >= 1.0e-4;
- nc: bound - E|L| >= 1e-8 and S_2 - bound >= 2.7e-3;
- ms, max|beta| <= m_c: S_2 - E P_c1 >= 4.8e-3;
- ms, beta = -m: p* - p3 >= 1.6e-3 and S_2 - E P_c2 >= 3.1e-2;
- ms, beta = +m: bound - E|L| >= 2.4e-7 and S_2 - bound >= 1.0e-3;
- cells: S_2 - bound >= 7.3e-3.

The largest sampled E|L|/S_2 is 0.99886.

**Attack** (`a11c_main2_killer.py`, float evidence; final outputs `outputs/a11c_main2_killer.txt` (2035 s) and
`outputs/a11c_main2_killer_low.txt` (1445 s), both finished by 09:15 UTC).
- Binomial- and Gaussian-bulk families with k = 1, 2, 3 large coefficients, all sign patterns and bulk size m up to
  400 and infinity, optimised by Nelder–Mead at q = 0.2, 0.2025, 0.205, 0.21, 0.22, ..., 0.25, 0.2599, 0.275, q0 and
  at q = q3, q3 + 1e-6, q3 + 1e-4, 0.184, ..., 0.1975: the best ratio is 1.0000000000 (to 10 digits), always at
  (1,1)/sqrt2.
- Random-direction search (n = 3, ..., 16) at the same q: largest ratio 1 + 4e-15 (float rounding, at (1,1)/sqrt2).
- At q = q3 the search finds the tie (1,1,1)/sqrt3, also with ratio 1.0000000000.
- Equal coefficients k <= 12 never exceed 1 on [q3, q0].
- For n <= 7, the exact theorem of A.5/A.5b already gives R_n = S_2 on [q3, q2], which contains [q3, q0].

**Text.** No mathematical fix is needed. Two cosmetic points:
- Lemma 20 is stated for y != 0. It is applied with possibly y_j = 0, where only the first entry of the minimum applies.
  The piece-test text says this, but the lemma could say it too.
- In Definition 23, 2m_c^2 > 1 already follows from p* < 0 and p* >= phi(m_c).

**Novelty: NEW.** This is the first determination of R(q) on [q3, 256/985). It contains A.9 (RQ-C C11) and reaches the
largest possible interval by (c). With A.6 it settles R(q) on [0.18350, 0.81650].
- The matching lower bound (the k = 2 equal-coefficient value) is KNOWN: Stone's thesis §4.2.
- Ivanisvili–Stone (arXiv:2407.04835) assume the equal-coefficient formula.
- My searches (A.9, 2026-10-22) found no proof of it on any interval below q0.

## A.12 RQ-C C12 (C11 extended to [625/2834, q0]) — VALID WITH FIXES (2026-10-22 09:28 UTC); VALID after the fix (10:04 UTC)

**Claim** (RQ-C `MAIN_RESULT.md/.tex/.pdf`, PDF built 08:40:46 UTC; `AUDIT_REQUEST.md` "C12" of 08:40; CLAIMS C12).
Let q_F = 625/2834 = 1/(1+(47/25)^2), q0 = 1-1/sqrt2, tau = sqrt(q(1-q)) and S_2(q) = 2 sqrt2 (1-q) tau.
- (a) For every q in [q_F, q0], every n and every unit alpha, E|sum alpha_i chi_i| <= S_2(q). Hence R(q) = S_2(q) on
  [q_F, q0] and R(q) = 2 sqrt2 q tau on [1-q0, 1-q_F] = [1/sqrt2, 2209/2834].
- (b) For q_F <= q < q0 the only extremisers are +-(e_i+e_j)/sqrt2.
- With A.6: R(q) = 2 tau max{1, sqrt2 max(q, 1-q)} on [q_F, 1-q_F] = [0.22054, 0.77946].

The new part is u = sqrt((1-q)/q) in [u_E, u_F] = [27/16, 47/25], i.e. q in [625/2834, 256/985] = [0.22054, 0.25990].
The first range is A.9. I re-read its text in the current version: it is the same argument, and the only change is
the renumbering (old Lemma 15 is now Lemma 17, same constant 74761407288326311/88539849484664832). Its data is
byte-identical to my A.9 copies.

My copies: text `audit/rqc/c12_text/` (md, tex, pdf; `MD5SUMS`), equal to the store at 09:24; data
`audit/rqc/c12_data/` (sextic cadffa99…, cellsA2 1f4b1046…, cellsB2 f211f3df…, as in the AUDIT_REQUEST).

### Rebuilt proof (second range; each step re-derived from the hypotheses)

1. *Reduction* (Lemma 3, as in A.9). R(q) = R(1-q), because chi -> -chi swaps q and 1-q. After a permutation and a
   global sign change, a = alpha_1 = max|alpha_i| > 0. Put b = sqrt(1-a^2) and M = sum_{i>=2} alpha_i chi_i / b. The
   beta_i = alpha_i/b have arbitrary signs, sum beta_i^2 = 1 and |beta_i| <= min(1, a/b). If a = 1, E|L| = 2 tau <= S_2
   because q <= q0. Correct.
2. *Lemma 4.* E|a chi_1 + bM| = 2 tau a + 2 E R_a(bM) with R_a(y) = (1-q)(y-av)_+ + q(-y-au)_+.
   - Proof: |x| = x + 2(-x)_+ = -x + 2x_+, E M = 0, and q a u = (1-q) a v = a tau.
   - R_a(by) = max(0, l1, l2) with l1 = (1-q)(by-av) and l2 = -q(by+au), whose positivity sets are disjoint.

   Correct; also checked by exact enumeration (error <= 7e-16).
3. *Lemma 15, Steps 1–3 (majorant).* P = (y+v)^2 S >= 0 by (S1).
   - At y = u the part of P of degree <= 1 is l1, because rho^2 s = l1(u) and rho^2 B0 + 2 rho s = l1'(u).
   - So P - l1 = (y-u)^2 S1 (sympy identity), and (S2) gives P >= l1.
   - For y >= -z0, l2 <= 0 <= P. For y = -z0-x, l2 = qbx, so (S3) gives P >= l2.

   Hence P >= R_a(b.). Correct.
4. *Lemma 15, Step 4 (comparison).* From the cumulant moments up to degree 6 (sympy identity):
   E P(chi) - E P(M) = alpha(1-p3) + kappa4(c4+15c6)(1-p4) + kappa5 c5 (1-p5) + 10 kappa3^2 c6 (1-p3^2) + kappa6 c6 (1-p6).
   Let m = max|beta_i| <= 1.
   - p5 <= p4 <= 1 and kappa5 c5 >= 0 give kappa5 c5 (1-p5) >= kappa5 c5 (1-p4).
   - p4^2 <= p6 <= 1 gives 0 <= 1-p6 <= 2(1-p4). Since c6 = t2 > 0 and kappa6 <= 0, kappa6 c6 (1-p6) >= 2 kappa6 c6 (1-p4).
   - Put X = 1-p3 in [0, 2] and Y = 1-p4 in [0, X(2-X)] (by p3^2 <= p4). Then
     E P(chi) - E P(M) >= alpha X + 10 kappa3^2 c6 X(2-X) + gamma Y.
   - If gamma >= 0 this is >= alpha X >= mu X. If gamma < 0, take Y = X(2-X): the bracket is affine in 2-X in
     [0, 2], with end values alpha and alpha + 2(10 kappa3^2 c6 + gamma), so the bound is again >= mu X.

   Correct.
5. *Lemma 15, Step 5, and Corollary 16.*
   - E P(chi) = q rho^2 s = q(1-q)(bu-av), since P(-v) = 0.
   - 2 tau a + 2q(1-q)(bu-av) = 2 tau (1-q)(a+b) (sympy). So E|a chi_1 + bM| <= 2 tau (1-q)(a+b) - 2 mu (1-p3) <= S_2,
     since a+b <= sqrt2.
   - Equality forces a = b and p3 = 1. Then sum beta_i^2 (1-beta_i) = 0 with beta_i <= 1, so M = chi_j.

   Correct. Only max|beta_i| <= 1 is used, as the text says.
6. *Reduction to exact checks* (end of §6). On a (u,t) box:
   - a(t) = 2t/(1+t^2) is increasing and b(t) is decreasing on [0,1]; tau and q are decreasing and rho = u + 1/u is
     increasing for u > 1.
   - g+-, and the polynomials built from the lower enclosures of C_k and of (-1)^k C_k, bound S^ and S1 from below on
     the two half-lines.
   - For (S3) put r = u - y = zeta + x. Then (r-rho)^2 S^(-r) >= (r-rho^+)^2 g_-(r) needs r >= zeta^- >= rho^+ and
     g_- > 0. Also qb(r-zeta) <= (qb)^+ (r-zeta^-). So h > 0 on [zeta^-, oo) suffices.

   Correct. The text asks for zeta^- >= rho^+; I require zeta^- > rho^+, which holds on every box.
7. *Lemma 18 (a >= 9/10).*
   - (x-t)_+ <= 27x^4/(256 t^3) (A.11 step 9), applied with t = av/b and t = au/b.
   - (1-q)u^3 = tau u^4 and q v^3 = tau v^4 (sympy).
   - E M^4 = 3 + kappa4 p4 <= 3, because w(u_F) = 3.8173 < 4.
   - So E R_a(bM) <= tau K(u) (1-a^2)^2/a^3, with K = (81/256)(u^4 + u^-4) increasing on u >= 1.
   - On a strip, sqrt2 u^2/(1+u^2) >= c_i, because sigma < sqrt2 and u^2/(1+u^2) is increasing.
   - So p_i > 0 on [9/10, 1] gives E R_a(bM) < T(u,a), i.e. E|L| < S_2.

   Correct.
8. *Six-moment cells* (Definition 9, Lemma 10). These are the A.6/A.9 mechanism on the new range. My cumulant
   enclosures need only u >= 1 and w < 13 (here w <= 3.82). The target bound uses that tau is decreasing and
   u^2/(1+u^2) is increasing. Correct.
9. *Coverage* (proof of Theorem 1, cases 4–6). For u in [u_E, u_F]:

   | a | piece |
   |---|-------|
   | (0, 179/256] | `cellsA2` |
   | [a(101/250), a(27/50)] = [0.694626, 0.836172] | sextic boxes |
   | [83/100, 9/10] | `cellsB2` |
   | [9/10, 1) | Lemma 18 |
   | 1 | direct |

   Since 50500/72701 < 179/256 and 83/100 < 2700/3229, every a in (0, 1] is covered. For (b): the cells and
   Lemma 18 give strict inequality, and equality in a sextic box forces a = b = 1/sqrt2 and M = chi_j. Correct with
   fix f1.

### Independent computer verification (RQ-AUD code only)

`audit/rqc/a12_c12_verify.py` is my code. It uses no RQ-C code, only my own helpers from A.6, A.9 and A.11: Arb root
isolation of exact rational polynomials, the A.9 cell checker, and the exact tiling check. I implemented (S1)–(S5)
from my own derivation of the reduction:
- monotone rational enclosures of a, b, tau, q, rho, kappa3 and w;
- interval products for s, B0, zeta, qb and C0–C3;
- monomial enclosures of the Laurent forms of c3 - B0 and c4, which part Y checks against sympy;
- adaptive bisection up to depth 5 (not needed).

Output: `outputs/a12_c12_verify.txt`.

| step | result |
|------|--------|
| md5 of sextic/cellsA2/cellsB2 against the AUDIT_REQUEST; first-range store data against my A.9 copies | 0 mismatches; identical |
| symbolic identities (sympy): P(u) = l1(u), P'(u) = l1'(u), P - l1 = (y-u)^2 S1, P(-v) = P'(-v) = 0, l2(-z0-x) = qbx, c6, c5, c4, c3, the S1 coefficients, the (S3) r-form, E P(chi), Lemma 12(v), the comparison identity, kappa5 and kappa6, the near-dictator identities | 16/16 |
| tilings: `cellsA2` of [u_E,u_F] x [0,179/256], `cellsB2` of [u_E,u_F] x [83/100,9/10], sextic boxes of [u_E,u_F] x t[101/250,27/50] | 1155, 32 and 271 rectangles: all inside, area sum equal, 0 overlapping pairs |
| glue: q(u_F) = 625/2834, q(u_E) = 256/985, a(101/250) = 50500/72701 <= 179/256, a(27/50) = 2700/3229 >= 83/100, w(u_F) < 3.82, kappa6 < 0 (kappa6 in [-20.68, -8.94]), u_F < 19/10 | 8/8 |
| six-moment cells, with sqrt2 in the target replaced by floor(10^30 sqrt2)/10^30 and by RQ-C's sigma | 1187/1187 each, no subdivision |
| sextic boxes, (S1)–(S5) | **271/271** at depth 0; smallest certified mu^- = 8.311e-5 (RQ-C reports 8.3e-5) |
| Lemma 18 strips, both sqrt2 bounds | 64/64; min p_i(9/10) = 3.328e-3 |
| second exact method: sympy Sturm counting replaces Arb in every root isolation (`a12d_c12_sturm.py`) | same results, 0 failures |
| RQ-C's own `verify_ext2.py`, rerun on a copy (cross-check only, not evidence) | ALL CHECKS PASSED (508 sub-boxes, depth 3); `outputs/a12_rqc_verify_ext2_repro.txt` |

### Negative tests (`a12b_c12_negative.py`, `outputs/a12b_c12_negative.txt`)

For every sextic variant I also search in floats for a real violation of (S1)–(S5), at 40 points per box. A box with a
violation must be rejected.
- Sextic boxes, rejected and float-violated: 271/271 each for t2/100, 4 t2, t0 + 1/100, t0 - 1/100, 3/2 t1, t1 - 1/100
  and t1 = 0. Edge boxes extended to t = 7/20: 23/23; to u = 39/20: 29/29; to u = 3/2: 14/14.
- Taking each box's coefficients from the box 135 places further on: 244/271 rejected, 244 float-violated.
- No box was accepted despite a float violation.
- Cells: P x 9/10, c0 - 1/1000 and u2 + 1/20 are rejected 1187/1187; a1 - 1/20 1163/1163; the target with
  sqrt2 -> 1.40 rejects 1009/1187.
- Strips: the threshold 17/20 fails 64/64, 7/8 fails 64/64, and u_F = 2 fails 20/64.
- Tilings: one box removed, shifted by 1e-4 in t, or duplicated: all rejected.
- The uncorrupted data are accepted.

### Semantic test (`a12c_c12_semantic.py`, `outputs/a12c_c12_semantic.txt`)

This is a float test, independent of the certificate checks; P is expanded numerically from its definition.
- 3,252 random points in random sextic boxes (12 per box): no violation of (S1)–(S5). Minima over the points: S 9.5e-3,
  S1 1.2e-3, f 9.5e-3, kappa5 c5 2.3e-3, -kappa6 8.9, mu 1.8e-3.
- P(y) - R_a(by) >= -1.7e-16 on a dense grid (float rounding at the tangency points).
- Lemma 4 identity: largest error 6.7e-16, by exact enumeration.
- Conclusion of Lemma 15 for random M (n <= 11, 30% of them near a single chi_j): bound - E|L| >= -3.3e-16, and
  S_2 - E|L| >= 5.1e-9 (near (1,1)/sqrt2).
- Cells (400 random cells): P - R_a >= 1e-9; T - E P(M) >= 2.9e-3 over 3,580 admissible M (n up to 4·10^4,
  |beta_i| <= a/b); 2 a tau + 2 E P(M) - E|L| >= 1.5e-3 over 3,238 enumerated M.
- Near-dictator range: S_2 - E|L| >= 4.2e-2 over 3000 random (u, a, M).

### Attack

The final A.11 attack covers q = 0.23, 0.24, 0.25 and 0.2599 in this range, and 0.22 just below it. The best ratio
E|L|/S_2 is 1 (to 10 digits), always at (1,1)/sqrt2. The range lies inside A.11 (VALID, 08:52). The two proofs share
no code and no lemma beyond the elementary facts of A.3.

### Fix (text only; no mathematical change)

(f1) The proof of Theorem 1, case 6 (`MAIN_RESULT.md` line 448, `.tex` line 658), says: "a in (0, 7/10] ∪ [83/100, 9/10]:
(u,a) lies in a verified cell (cellsA2, cellsB2)". This is false for a in (179/256, 7/10], because `cellsA2` covers only
a <= 179/256. The 7 failed cells of `cellsA2_full` lie exactly there, at u in [1.870, 1.88]. The sentence must read
a in (0, 179/256] ∪ [83/100, 9/10]. Case 5 covers the excluded a (50500/72701 < 179/256), so the theorem and (b) are
unaffected. §8.1 and the AUDIT_REQUEST already state the correct range.

PDF check: the PDF (pdfTeX, 08:40:46 UTC) contains all 177 numbers and all 332 words of six or more letters of the LaTeX
source (`audit/pdf_vs_tex.py`). So the PDF is the audited text.

### Novelty

- The statement on [625/2834, 256/985] is NEW relative to the literature. BF3 covers [3/8, 5/8]; the lower bound is
  KNOWN (Stone §4.2).
- In this project the range is contained in A.11 (RQ-A MAIN-2, VALID at 08:52), so C12 does not extend the known range.
  Its value is a second, independent proof of R(q) = S_2(q) on [0.2205, 0.2599] by a different method: a
  one-coordinate split and the sextic two-extremiser comparison (Lemma 15, NEW as a technique).

**Verdict: VALID WITH FIXES** (f1). I will re-rate it VALID once fix f1 is in the posted text.

**Re-rated VALID (2026-10-22 10:04 UTC).** RQ-C posted fix f1 at 09:46 (AUDIT_REQUEST update; PDF rebuilt 09:42:37 UTC).
My copy is `audit/rqc/c12_text_v2/` (`MD5SUMS`). Against my 09:28 copy:
- The md and tex diffs consist of exactly two lines. Case 6 now reads a in (0, 179/256] ∪ [83/100, 9/10], and case 5
  now states a(101/250) = 50500/72701 < 179/256.
- The pdftotext outputs of the old and new PDFs differ in exactly these two places. The new PDF contains all 177
  numbers and all 332 long words of its tex.
- The four data files have the md5s of my copy `audit/rqc/c12_data/`.

So the posted text is the audited proof with f1 applied. **Verdict: VALID.**

---

## A.13 RQ-B C11–C12 (rq/MAIN_RESULT §8) — C11 VALID WITH FIXES, C12 VALID WITH FIXES (2026-10-22 09:53 UTC); both VALID after the fixes (10:44 UTC)

Source: `RQ-B/rq/MAIN_RESULT.md/.tex/.pdf` §8 (PDF pdfTeX 08:35:28 UTC; re-mirrored at 09:06 and 09:28 with the
same md5s) and `rq/CLAIMS.md` C11–C12. My copy `audit/rqb/c11c12_text/` (`MD5SUMS`) equals the store at 09:49.

Notation (RQ-B's):
- K is a finite Kolmogorov measure and Z_K the centred infinitely divisible variable with
  log E e^{itZ_K} = int (e^{itx} - 1 - itx) x^{-2} K(dx) (Gaussian part K({0})), so Var Z_K = K(R);
- R = R_ID = sup E|Z_K| / sqrt(K(R)), and u = P(Z > 0) for a maximiser;
- H_V(a) = E[(a + V)_+; V <= 0] for a > 0 (mirrored for a < 0), and G_V(a) = 2 H_V(a)/a^2.

**A.13a — C11 (Lemma 8.1, Lemma 8.2, Proposition 8.3), VALID WITH FIXES (f2, text only).**

Rebuilt proof:
1. *Lemma 8.1 (existence).* f_t(x) = (e^{itx} - 1 - itx)/x^2 is continuous on [-oo, oo] with value 0 at +-oo. So weak
   convergence of K_n on the compactification gives convergence of the characteristic functions to that of Z_K, where
   K is the limit restricted to R. E Z_{K_n}^2 = 1 gives uniform integrability, so E|Z_K| = R. Escaped mass m > 0
   would give R <= R sqrt(1-m). Correct.
2. *(i), first variation.* K* + eps delta_a adds an independent Y_eps = a(N - eps/a^2), N ~ Poisson(eps/a^2), and
   E|Z + Y_eps| <= R sqrt(1+eps). I re-derived the right derivative at eps = 0:
   - no jump (the compensator): (1/a)(P(Z <= 0) - P(Z > 0));
   - one jump: (1/a^2)(E|Z+a| - E|Z|) = (1/a)(P(Z >= 0) - P(Z < 0)) + (2/a^2) E[(a+Z)_+; Z < 0];
   - two or more jumps: O(eps^2).

   The sum is (2/a) P(Z = 0) + (2/a^2) E[(a+Z)_+; Z < 0] = G(a), and it is <= R/2. Correct.
3. *(ii).* G(a) >= 2 P(Z = 0)/a, which tends to oo as a -> 0+ if P(Z = 0) > 0. Correct.
4. *(iii), removal variation.* Z = W + Y_eps with W = Z_{K* - eps K_A}. Y is the compound Poisson process with Levy
   measure nu = x^{-2} K_A(dx) (finite, since |x| >= delta on A) and drift -b. I re-derived:
   - F(s) = E|W + Y_s| is Lipschitz;
   - D+F(s) = int E[|V+x| - |V| - x sgn V] nu(dx) + |b| P(V = 0). For either sign of b the drift contributes
     -b (P(V > 0) - P(V < 0)) + |b| P(V = 0);
   - the pointwise identity for |v+x| - |v| - x sgn v, hence E[...] = x^2 G_V(x) - |x| P(V = 0), hence
     D+F <= int G_V dK_A, because |b| <= int |x| d nu;
   - F(0) = E|W| <= R sqrt(1 - eps K*(A)).

   The limit r -> 0 of int G_{V_r} dK_A uses three facts: (ii), so 0 is a continuity point of the law of Z; only
   countably many t have P(Z = -t) > 0; and G_V(x) <= 2/|x| <= 2/delta. So K*(A) = 0 for all delta, eta > 0. Hence
   G = R/2 K*-a.e. off 0, and on supp K* \ {0} because G is continuous there. Correct.
5. *(iv), tangency.* Q = R r^2/4 - H >= 0 and Q(a) = 0. The right and left derivatives of H at a are
   P(-a <= Z <= 0) and P(-a < Z <= 0). Correct.
6. *Proposition 8.3.*
   - E Z_+ = E Z_- = R/2. Cauchy–Schwarz on {Z > 0} and on {Z < 0} gives R^2/(4u) + R^2/(4(1-u)) <= E Z^2 = 1.
   - (1-u) a - R/2 <= H(a) <= R a^2/4, taken at a = 2(1-u)/R, gives (1-u)^2 <= R^2/2 <= 2u(1-u). So u >= 1/3, and
     u <= 2/3 by the mirror argument.
   - A support point a > 0 satisfies a = (2/R) P(-a < Z <= 0) <= 2(1-u)/R <= 4/(3R).

   Correct.

Computer checks (float evidence; part F of `audit/rqb/a13_rqb_thm8_verify.py`):
- First-variation formula of (i): Richardson-extrapolated difference quotients of E|V + Y_eps| equal G_V(a) to
  5.1e-7 for 60 random (V, a) (V with one or two Poisson atoms, exact lattice enumeration).
- K = delta_sqrt2:
  - E|Z| = sqrt(2/e) to 1e-12, and u = 1 - e^{-1/2};
  - P(-sqrt2 < Z <= 0) - R sqrt2/2 = 1.1e-16;
  - Q equals the piecewise formula of f2 to 3.6e-15;
  - max_{a<0} (G(a) - R/2) = -0.214.

Fix (f2, text only). CLAIMS C11 says "All tight at K* = delta_sqrt2". MAIN_RESULT says "all of this is tight" (md
line 265; tex line 422, "everything is tight"). This is false as stated. At delta_sqrt2:
- R^2 = 2/e = 0.7358 < 4u(1-u) = 0.9546;
- u = 0.3935 lies inside (1/3, 2/3);
- 4/(3R) = 1.554 > sqrt2.

What is tight there: 1 - u = R/sqrt2, the support bound a <= 2(1-u)/R = sqrt2, and the identities of (iv). Also,
Q(r) = (sqrt2/4) e^{-1/2} (r - sqrt2)^2 (md line 266, tex line 423) holds only for r >= 1/sqrt2; for r <= 1/sqrt2,
Q(r) = (sqrt2/4) e^{-1/2} r^2. No proof uses this sentence.

**A.13b — C12 (Theorem 8: R_ID <= 0.9161 and corollaries), VALID WITH FIXES (f1, text only).**

Rebuilt proof:
1. For a probability K on [-A, A]: kappa_2 = 1 and kappa_n = int x^{n-2} dK. So E Z^4 = 3 + k4 and
   E Z^6 = 15 + 15 k4 + 10 k3^2 + k6 (both derived with sympy from the cumulant generating function).
2. k3^2 <= k4 (Cauchy–Schwarz for the probability K), k6 <= A^2 k4, k4 in [0, A^2] and delta >= 0 give
   E phi(Z_K) <= al + be + 3 ga + 15 de + (ga + 25 de + de A^2) k4 <= V(A).
3. phi(z) > |z| (exact, below), and phi is even.
4. If R > c, Proposition 8.3 (A.13a) puts supp K* inside [-4/(3R), 4/(3R)], a subset of [-A, A] with A = 4/(3c). So
   R = E|Z_{K*}| <= E phi <= V(A) < c < R, a contradiction. Hence R <= c.
5. Corollaries, from Theorem 3 (A.10a), Theorem 4 (A.10b) and R_ID >= sqrt(2/e) (delta_sqrt2):
   - With x = ln(1/(1-q)), q/((1-q)x) = (e^x - 1)/x is increasing, so the bound is < 1 iff q < q*.
   - The formula is also valid for q > 1/2 ("for all q" in CLAIMS), because R(q) = R(1-q) and (e^x - 1)/x is
     increasing.

Correct.

Independent computer verification (`audit/rqb/a13_rqb_thm8_verify.py`, output `outputs/a13_rqb_thm8_verify.txt`;
my code, no RQ-B code):

| step | result |
|------|--------|
| exact part, both certificates (c = 9161/10000 and c = 23/25): moments from the cumulant generating function (sympy); phi(z) - z has no root on [0, oo) by Arb root isolation and, separately, by sympy Sturm counting, and phi(0) > 0; de >= 0; V(A) as an exact rational; V < c; V equals the stated value | 13/13 |
| c = 0.9161: A = 40000/27483; the slope ga + 25 de + de A^2 = -2.18e-7 is negative, so V = base = 9160669/10^7 exactly; c - V = 3.31e-5; min (phi(z) - z) = 5.0e-5 at z = 0.851 | as stated |
| c = 0.92: A = 100/69; slope 1.02e-4 > 0; V = 138475569361/151114140000 = 0.916364 | as stated |
| corollaries, mpmath interval arithmetic at 60 digits: q* = 0.288832268403 (certified sign change of the bound minus 1 within 1e-12); the bound is 0.940768320848 at q = 0.1, 0.969662760871 at 0.2 and 0.986111120512 at 0.25 | all <= the stated 0.9408, 0.9697, 0.9862 |
| semantic float test: 3000 random probability K on [-A, A] (Gaussian part plus 1–3 atoms) | min E phi - E\|Z\| = 5.8e-2; min V(A) - E phi = 4.1e-5; max E\|Z\| = 0.857762 < sqrt(2/e) = 0.857764 |

Fix (f1, text only). Theorem 8 in MAIN_RESULT (md line 273, tex line 431) says the bound is "within 7.4% of the
lower bound M(q) for all q <= 1/4". This is false.
- Over (0, 1/4] the ratio bound/M has supremum 1.0790148, at q = q3 = 1 - sqrt(2/3) = 0.18350, where the maximising
  k of M changes from 2 to 3.
- The ratio is 1.0735 at q = 1/4 itself, and its limit as q -> 0 is c sqrt(e/2) = 1.0680.

The sentence should read "within 7.91%". CLAIMS C12 does not contain the sentence, and its corollaries are correct
as stated.

Consistency with the exact results: on [q3, q0], R = M = S_2 (A.11), so there the bound exceeds the true value by at
most 7.91%. At q = 1/4 it gives 0.9861 against the true 0.9186.

PDF check: the PDF (pdfTeX, 08:35:28 UTC) contains all 104 numbers and all 308 words of six or more letters of the
LaTeX source (`audit/pdf_vs_tex.py`). So the PDF is the audited text.

**Remark 3.3 (the open text note from A.10): the missing step is now proved.** The tex version of 09:28 (lines
182–186) now argues as follows:
- for lambda >= 1, E|N_lambda - lambda|/sqrt(lambda) <= 2 (3/2)^{3/2} e^{-3/2} = 0.81983 < 0.82;
- for s <= 0.42 some multiple ks lies in [0.32, 0.74], where 2 sqrt(lambda) e^{-lambda} > 0.82;
- hence APC(s(q)) implies C0 for q <= 0.34.

The first bound is asserted without proof. My proof:
- For m = floor(lambda), E|N_lambda - lambda| = 2 e^{-lambda} lambda^{m+1}/m!. So on [m, m+1) the ratio is
  2 lambda^{m+1/2} e^{-lambda}/m!, with maximum peak_m = 2 x^x e^{-x}/m! at x = m + 1/2.
- With t = 1/(2x+1), x log(1 + 1/x) = (1-t) atanh(t)/t, and
  log(peak_{m+1}/peak_m) = -1 + log(1+t) + x log(1+1/x) = -sum_{j>=1} (1/(2j) - 1/(2j+1)) t^{2j} < 0.
- So the peaks decrease, and the sup over lambda >= 1 is peak_1.

`audit/rqb/a13b_remark33.py` (output `outputs/a13b_remark33.txt`) checks:
- the closed form of the mean deviation (error 1e-50) and the series identity (error 7e-50);
- log(peak_{m+1}/peak_m) < 0 for m <= 2000, in interval arithmetic, and peak_1 < 0.82;
- the values at 0.32 and 0.74 (0.82154 and 0.82086), and 1 - e^{-0.42} = 0.34295 >= 0.34.

So the remark is correct, and I suggest adding the two-line proof to the text. The md version (line 105) still has
the older wording ("e.g. for all s <= 0.35"), which the tex version implies.

Novelty:
- C11: NEW (no source found; the variational technique is standard). The sources I checked contain no first-order
  conditions for maximisers of E|X|/||X||_2 over infinitely divisible laws: Ivanisvili–Stone arXiv:2407.04835,
  Stone's thesis and Marcus–Rosiński ECP 2001.
- C12: NEW. The earlier upper bounds I know for small q are 1 - O(q^3) (Ivanisvili–Stone arXiv:2407.04835, Cor. 2,
  quoted at A.0). Marcus–Rosiński (ECP 2001) compare E|X| with l(Q), not with ||X||_2. The lower bound sqrt(2/e) is
  KNOWN (Stone thesis, Lemma 4.4.4). The gap is now sqrt(2/e) = 0.85776 <= R_ID <= 0.9161.
- RQ-B's Remark 8.4 (best even sextic 0.91602; LP about 0.914) is NUMERICAL and not audited as a proof.

**Verdicts: A.13a VALID WITH FIXES (f2), A.13b VALID WITH FIXES (f1).** Both fixes are text only; neither changes any
mathematics. I will re-rate them VALID once the fixes are in the posted text.

**Re-rated VALID (2026-10-22 10:44 UTC).** RQ-B re-mirrored at 10:38 (PDF pdfTeX 10:38:09 UTC); my copy is
`audit/rqb/r33_text/`. Both fixes are in the posted text:
- f2: MAIN_RESULT (md lines 281–285, tex lines 441–445) and CLAIMS C11 now list what is tight at K* = delta_sqrt2
  (1 - u = R/sqrt2, the support bound a <= 2(1-u)/R = sqrt2, and the identities of (iv)) and what is not
  (R^2 = 0.7358 < 4u(1-u) = 0.9546; u = 0.3935 lies inside (1/3, 2/3); 4/(3R) = 1.554 > sqrt2). Q(r) is now given
  piecewise: (sqrt2/4) e^{-1/2} (r - sqrt2)^2 for r >= 1/sqrt2 and (sqrt2/4) e^{-1/2} r^2 for 0 < r <= 1/sqrt2. I
  re-derived this. At delta_sqrt2 the only negative value of Z is -1/sqrt2 (probability e^{-1/2}), so H(r) = 0 for
  r <= 1/sqrt2 and H(r) = e^{-1/2}(r - 1/sqrt2) above; then Q = R r^2/4 - H with R = sqrt2 e^{-1/2}.
- f1: Theorem 8 (md lines 292–294, tex lines 453–455) now says "within 7.91%", with the supremum 1.07901 at
  q = 1 - sqrt(2/3) and the limit 1.0680. These are my values.
- Apart from these two places, §8 is unchanged (diff against `audit/rqb/c11c12_text/`). The only other change in
  MAIN_RESULT is the new proof in Remark 3.3, audited as A.15. The new PDF contains all 117 numbers and all 320
  long words of its tex, including both fixes.

So the posted text is the audited proof with f1 and f2 applied. **Verdicts: A.13a VALID, A.13b VALID.**

---

## A.14 RQ-A MAIN-3 (R(q) = T(q) = 2 sqrt3 (1-q)^2 tau on [25/169, q3]) — VALID, NEW (2026-10-22 10:37 UTC)

**Claim** (RQ-A `MAIN_RESULT_K3.md/.tex/.pdf`, PDF pdfTeX 09:35:28 UTC, 14 pages, posted 09:47; `AUDIT_REQUEST.md`
section MAIN-3 of 09:46; CLAIMS MAIN-3). Let q_L = 25/169, q3 = 1-sqrt(2/3), q4 = 1-sqrt3/2, tau = sqrt(q(1-q)),
T = 2 sqrt3 (1-q)^2 tau and T_2 = 2 sqrt2 (1-q) tau.
- (a) For every q in [q_L, q3], every n and every unit alpha, E|sum alpha_i chi_i| <= T. Hence R(q) = T on [q_L, q3]
  and R(q) = 2 sqrt3 q^2 tau on [1-q3, 1-q_L].
- (b) Equality holds iff alpha = +-(e_i+e_j+e_k)/sqrt3, or q = q3 and alpha = +-(e_i+e_j)/sqrt2.
- (c) R(q) >= T_2 > T on (q3, 1/2] and R(q) >= 4(1-q)^3 tau > T on (0, q4), so
  [q_L, q3] ⊆ {q <= 1/2 : R(q) = T(q)} ⊆ [q4, q3]. The gap [q4, 25/169) is open (RQ-A conjectures R = T there).
- Corollary 1, with A.6 and A.11: R(q) = 2 tau max{1, sqrt2 qh, sqrt3 qh^2}, qh = max(q, 1-q), on
  [25/169, 144/169] = [0.14793, 0.85207].

My copies: text `audit/rqa/k3_text/` (md5s in `MD5SUMS`); data `audit/rqa/k3_data/`. All 98 manifest files match
RQ-A's `outputs/k3_MD5SUMS.txt` (md5 613f681e…). The 36 MB of box files (`k3_data/k3/`) are not committed or mirrored;
my scripts read RQ-A's copy with `K3_DATA=/cursor/stores/bot/rq/RQ-A/outputs`, and part M checks every md5.

### Rebuilt proof (each step re-derived from the hypotheses)

Parametrisation u = sqrt((1-q)/q) >= 1 (q <= 1/2 by symmetry, Lemma 2); [q_L, q3] is u in [u3, 12/5],
u3 = sqrt(2+sqrt6) = 2.1093814. The cover uses u in [U_-, 12/5] with U_- = 2109381/10^6 < u3.
1. *Test vectors* (Lemma 3). For q < 1/k, chi_1+...+chi_k > 0 iff some chi_i = u, so
   E|chi_1+...+chi_k|/sqrt k = 2 sqrt k (1-q)^{k-1} tau. Then T_2 <= T iff q <= q3; for q <= q3,
   sqrt3 (1-q)^2 >= 2/sqrt3 > 1, so 2 tau < T; and 4(1-q)^3 > 2 sqrt3 (1-q)^2 iff q < q4 (and q4 < 1/4). This gives (c),
   the lower bound R >= T and the "if" part of (b). Correct.
2. *Target* (eq. (2), audit point 1). T = sqrt3 T~(u) with T~ = 2u^5/(1+u^2)^3, and d/du u^5/(1+u^2)^3 =
   u^4(5-u^2)/(1+u^2)^4. So T~ increases up to sqrt5 = 2.236 (inside the range) and then decreases; on [u1, u2] its
   minimum is at an endpoint, and T^- = S3 min(T~(u1), T~(u2)) <= T for any rational S3 < sqrt3. Correct (checked
   symbolically).
3. *Lemma 4* (two coordinates; audit point 3). E|c chi_1 + s d chi_2| = 2 tau max(c, d, [s=1](1-q)(c+d)) (as in A.11).
   For q <= q3: 2 tau max(c, d) <= 2 tau rho < T rho, and 2 tau (1-q)(c+d) <= T_2 rho <= T rho, with equality iff
   q = q3, s = 1, c = d. Correct.
4. *Lemma 5* (three-bit lemma, k = 3; audit point 2). E[f chi_i] = tau Delta_i(f) because qu = (1-q)v = tau, so
   G_3(c) = E[f* X] <= tau |c| |Delta(f*)| <= tau |c| sqrt12 (1-q)^2 = T|c| once
   P_f = 12(1-q)^4 - sum_i Delta_i(f)^2 >= 0 for all 256 f. Delta(OR_3) = 2(1-q)^2 (1,1,1) gives P == 0;
   Delta(OR_ij) = 2(1-q)(e_i+e_j) gives P = 4(1-q)^2 mu3, mu3 = 3q^2-6q+1, which vanishes at q3 and is positive below.
   Equality needs equality in Cauchy–Schwarz and P_{f*}(q) = 0. My exact check is below. Correct.
5. *Moments* (Lemmas 7–12). Unchanged from A.11 (cumulants, moment identities, power-sum bounds, the sign information
   phi, and the objective bound with optional p*). On [U_-, 12/5], w = u^2 + u^-2 <= 5.934 < 10, as the cumulant
   enclosures need. Correct.
6. *Lemma 13* (cells, a1 <= 2/5; audit point 4). I re-derived the identity behind BF3 Lemma 9.4:
   E|a chi + y| = 2 a tau + 2 R_a(y) - (1-2q) y, so E|L| = 2 tau a + 2 E R_a(b_1 M_1) because E M_1 = 0. Then
   R_a(b_1 y) <= max(0, l1bar, l2bar), the coefficients of M_1 are at most mbar, and
   Theta_1 = tau(u2)(S3 (u1^2/(1+u1^2))^2 - a2) <= tau(u)(sqrt3 (1-q)^2 - a) on the cell, because tau decreases and
   1-q increases in u, S3 < sqrt3, a <= a2, and the bracket is positive: S3 (U_-^2/(1+U_-^2))^2 = 1.1547 > 1.15 > 2/5.
   So E|L| < 2 tau a + 2 Theta_1 <= T. Correct.
7. *Lemmas 14–18* (conditional expectation, envelope, box certificates). Unchanged from A.11, with target T^-. Correct.
8. *Lemma 19* (tail bound), now stated for all real y with the y = 0 convention (my A.11 cosmetic point). Correct.
9. *Lemma 20* (near-circle tests; audit point 3). (A) bounds only the error term; the main term G <= T comes from
   Lemma 4 and needs u >= u3. The slack is T(1-r) = T b^2/(1+r). (B) uses an upper bound G^+ <= T^- and holds for every
   u in the box. Correct, and stated for u >= u3.
10. *Lemma 21 and the piece tests* (audit point 5). If beta_{i0} = +m: a3 = bm, b' = b sqrt(1-m^2), and
    a1^2 + a2^2 + a3^2 = 1 - b'^2. M' is independent of Y with E M'^4 <= 3 + max(0, kappa4). Lemma 5 gives
    E|Y| <= T r' (only for q in [q_L, q3]), and the slack is T(1-r') = T b'^2/(1+r').
    - (A3): the enclosures (b'^2)^+ = (b^+)^2(1-m_1^2), r'^+ >= sqrt(1-(b^-)^2(1-m_2^2)) and
      p_j y_j = tau sum_i (+-a_i) prod_{k != i} Pr[x_jk] are correct. The probabilities q^k(1-q)^{3-k} are monotone in
      q for q < 1/3, i.e. u^2 > 2, and every ms box has u1 >= 2.109.
    - (B3) bounds E|Y| directly by sum_j |p_j y_j|^+ and does not use Lemma 5.
    Correct.
11. *Lemma 23* (m-split, now used throughout [u3, 12/5]). The case split is exhaustive:
    - max|beta_i| <= m_c: c(1) with cap min(m_c, mbar);
    - some beta_i = -m with m >= m_c: p3 <= phi(m_c) <= p* (Lemma 10), so c(2);
    - otherwise beta_{i0} = +m with m in [m_c, min(1, mbar)]: a piece.

    Equality is possible only at m = 1, where L = Y. Correct.
12. *Proof of Theorem 3.*
    - Case split: a1 = 1; a1 <= 2/5 (cells); a1 > 2/5 and r = 1 (Lemma 4); otherwise a box of the cover, which is
      never `small` because r2 c(t1) <= 2/5 bounds a1 on the whole box.
    - lp, nc and cells are strict. In an ms box all three entries of (a1, s a2, b) are nonzero (a2 >= |alpha_{i0}| = b),
      so Lemma 5 forces (1,1,1)/sqrt3; r = 1 gives (e_i+e_j)/sqrt2 at q3 only. This is (b).
    - (c) and Corollary 1 follow from Lemma 3, A.6 and A.11. Correct.

### Independent computer verification (RQ-AUD code only)

`audit/rqa/a14_main3_verify.py` uses no RQ-A code. It reuses my target-independent helpers from A.6, A.9 and A.11
(tilings, my box envelope, my six-moment bound with optional p*, interval arithmetic for 8 atoms) and re-implements
everything that depends on k from the text. Exact rationals throughout; root isolation by Arb (python-flint) on
rational polynomials; sqrt bounds from integer square roots; sqrt3 in the target replaced by
S3 = floor(10^30 sqrt3)/10^30. Outputs: `outputs/a14_main3_verify_MABFH.txt`, `outputs/a14_main3_verify_CDEG.txt` and
`outputs/a14_main3_verify_RCDEG.txt`.

| step | result |
|------|--------|
| md5 of the 98 manifest files against RQ-A `k3_MD5SUMS.txt` | 0 mismatches |
| constants: U_- < u3 (U_-^2 > 2, (U_-^2-2)^2 < 6); U_+ = 12/5 < u4 = sqrt(3+2sqrt3); q(12/5) = 25/169; sqrt2-1 <= T8 < 1; S3 (U_-^2/(1+U_-^2))^2 > 1.15 > 2/5; w < 10 | True |
| Lemma 4 formula at 8000 random rational points; the k = 3 bound E|X| < T (c^2+d^2)^{1/2} at random rational u > u3 | 0 mismatches; 0 violations |
| Lemma 3 for k = 1..4 at 70 rational u in [2.11, 2.6), exact | 0 mismatches |
| sympy: T = sqrt3 T~(u); derivative of u^5/(1+u^2)^3; T^2 - T_2^2 = 4(1-q)^2 mu3; (4(1-q)^3)^2 - (2 sqrt3 (1-q)^2)^2 = 4(1-q)^4 (4q^2-8q+1) (zero at q4) | True |
| one-coordinate cells tile [U_-, 12/5] x [0, 2/5] (inside; area sum equal) | 2,704 cells, OK |
| two-coordinate boxes tile [U_-, 12/5] x [0, T8] x [2/5, 1], each sign (inside; volume sum = region volume; 0 pairs with overlapping interiors) | s=+1: 69,871 boxes; s=-1: 12,104 boxes; both OK |
| `small` boxes have r2 c(t1) <= 2/5 | 876/876 |
| one-coordinate cells (A.9 checker, target Theta_1) | **2,704/2,704**, no subdivision |
| lp boxes: my envelope, domination on every piece, my objective bound with T^- | **57,333/57,333** at depth 0 |
| near-circle boxes: my tests (pointwise ratio with Lemma 4; margin test with D^- = max(0, 2 tau^-(S3 (1-q)^-^2 - max(c, d, [s=1](1-q)(c+d))^+)); mixed), all strict | **2,534/2,534** (1,168 by test 1, 1,366 by test 2). 75 boxes touch [U_-, u3); the theorem uses them only at u >= u3 |
| m-split boxes: b^- > 0; 0 < m_c <= 1; 2 m_c^2 > 1; phi(m_c) <= p* < 0 exactly; c(1) with cap min(m_c, mbar) and c(2) with cap min(1, mbar) and p* (domination and objective bound); the s3 = +1 pieces cover [m_c, min(1, mbar)]; each piece passes my (A3) or (B3) | **21,232/21,232**; 32,932 pieces (32,394 A3, 538 B3; RQ-A's split is 32,386/546 because the enclosures differ); m_c in {3/4, 31/40, 4/5, 33/40, 17/20, 7/8, 9/10}; min u1 = 2.109381 |
| three-bit lemma, k = 3: P_f for all 256 f; mu3 divided out; the cofactor has 0 Sturm roots on [q_L, q3^+] and is positive at q_L | fails for **0/256**. P_f == 0 exactly for +-OR_3; P_f(q3) = 0 exactly for the 6 functions +-OR_ij: the equality cases of Lemma 5 |
| second exact method: sympy Sturm counts replace Arb in every root isolation (`a14d_main3_sturm.py`) | 0 failures: 2,704 cells, 57,333 lp boxes, 21,232 ms boxes (709,395 Sturm calls, 139 s); a planted y^2 - 1 > 0 on [0, 2] is rejected |
| RQ-A's sqrt3 bound S3 = 1732050807568877/10^15 instead of mine | cells, lp, nc and ms all pass |

### Negative and calibrated tests

`a14b_main3_negative.py` (`outputs/a14b_main3_negative.txt`), on random samples of 120 records of each kind.
"Required" means that the corruption breaks the record by construction. Fixed-size changes can leave a valid
record, because my envelope is tighter than RQ-A's, so those are reported as info.
- Required, all behave:
  - m-split: lowering m_c by 1/10, removing the top piece, halving the top piece, and m_c -> -m_c with
    p* = 1 + m_c^3 are each rejected 120/120.
  - Tilings: removing, shifting (1e-4 in t) or duplicating one box is detected.
  - The three-bit claim fails at q3 + 1/1000 (for OR_2).
  - No lp corruption was accepted where a float search over the box found a real violation of P >= F.
- Info:
  - lp: c6 lowered by 10% rejected 113/120 (all 7 accepted ones show no real violation); r1 lowered by 1/10
    rejected 117/117; sign flipped 86/120; target lowered by 1e-2 86/120. c0 lowered by 1e-3 |c0| is rejected 0/120,
    and no real violation was found in any of these 120 (same as in A.11).
  - m-split: lowering p* by 1/100 120/120; c1's c0 x 0.99 120/120; r- or t-range widened 120/120; target -1e-2 119/120;
    m_c raised by 1/10 115/120; c2's c0 lowered by 1e-3 |c0| 0/120 (c(2) has a large moment slack, see below).
  - Cells: c0 - 1e-3|c0|, a-range widened, S3 -> 1.70 all 120/120.
  - Near-circle boxes: r1 lowered by 1/10 rejected 119/120. The one accepted widened box has s = -1, where
    G = 2 tau max(c, d) is far below T; it passes after bisection by the margin test, which holds for every u, so
    the acceptance is correct.
  - Moving a near-circle box to u <= 2 < u3 is never rejected (0/120). Moving only the pieces of an ms box down by
    1/20 is rejected 57/120. As RQ-A says (audit point 7), test (A) and the piece test (A3) bound only the error term
    and take the main term from Lemmas 4 and 5, which hold only for q <= q3. So Lemma 20(A) and Lemma 23 must be (and
    are) restricted to u >= u3.

`a14f_main3_slack.py` (`outputs/a14f_main3_slack.txt`): calibrated tests on every certificate. For each family I
computed the float slack of domination and of the moment bound.

| family | domination slack min | moment slack min |
|--------|----------------------|------------------|
| 57,333 lp | 3.0e-4 | 1.4e-8 |
| 21,232 c(1) | 7.1e-4 | 3.8e-8 |
| 21,232 c(2) | 7.0e-4 | 2.6e-2 |

On the 200 tightest of each family, the exact check gives, every time:
- c0 lowered by half the smaller slack still passes 200/200;
- c0 lowered by twice the domination slack is rejected 200/200;
- c0 raised by twice the moment slack is rejected 200/200.

So the exact checks are sharp, with no over- or under-rejection.

**End-to-end semantic test** (`a14e_main3_semantic.py`, float, exact enumeration of the laws). I sampled 30,921
admissible points with u in [u3, 12/5]: random boxes and cells, random u, t, r, and residuals with up to 12
coefficients and |beta_i| <= mbar. In the ms cases the largest coefficient is forced to +-m with m >= m_c, and 15% of
the time m = mbar; 695 samples lie within 0.02 of the extremiser. In every case the certified bound is >= E|L| and < T:
- lp: E P - E|L| >= 1.1e-2 and T - E P >= 3.5e-4;
- nc: bound - E|L| >= 5e-9 and T - bound >= 5.3e-3;
- ms, max|beta| <= m_c: T - E P_c1 >= 5.7e-3;
- ms, beta = -m: p* - p3 >= 1.7e-3 and T - E P_c2 >= 3.5e-2;
- ms, beta = +m: bound - E|L| >= -2e-16 (equality at m = 1, where the bound is E|Y| = E|L|) and T - bound >= 4.3e-6;
- cells: T - bound >= 5.5e-3.

The largest sampled E|L|/T is 0.9999953, at a1 = 0.5792, a2 = 0.5779, b = 0.5750, beta = (1), next to (1,1,1)/sqrt3.

**Attack** (`a14c_main3_killer.py`; floating point, evidence only). Outputs: `outputs/a14c_main3_killer_P1.txt`,
`_P2.txt`, `_low_P1.txt` and `_low_P2.txt`. In the first runs, part 1 stopped on two start-vector bugs at n = 3; part 2
was unaffected and was kept, and part 1 was rerun with the fix.
- Main range: 10 values of q in [q_L, q3], namely q_L, 0.15, 0.155, ..., 0.18, q3 - 1e-4 and q3.
  - Part 1: exact enumeration over {0,1}^n for every n = 3..16, with 40 starts per n (Gaussian, positive, mostly
    positive heavy-tailed, 2–5 large plus small, (1,1,1,x,small) and 4 large plus small). Each start is followed by the
    duality ascent alpha <- (Delta_i(1{L>0}))_i, which never decreases E|L|/|alpha|. The largest ratio E|L|/T is
    1 + 3e-15. For every q < q3 and every n the best vector is (1,1,1)/sqrt3 padded with zeros; at q3 it is
    (1,1,1)/sqrt3 or (1,1)/sqrt2.
  - Part 2: k = 1..4 large coefficients plus m equal small ones (m up to 400, and the Gaussian limit), all sign
    patterns for k <= 3, with Nelder–Mead from 4 starts. The largest ratio is 1 + 1e-15, again at (1,1,1)/sqrt3.
  - Equal coefficients, k <= 12: the ratio is <= 1, with equality only for k = 3 (and k = 2 at q3).
- Low range (info; outside the claim): q4 - 1e-3, q4, q4 + 1e-4, 0.135, 0.1375, ..., 0.1475. For every q >= q4 both
  parts give the ratio 1, at (1,1,1)/sqrt3 (and also at (1,1,1,1)/2 at q4 exactly). At q4 - 1e-3 they give
  1.0011547005, from (1,1,1,1)/2; this is exactly 4(1-q)^3 tau / T there, as (c) predicts. This supports RQ-A's
  conjecture R = T on [q4, 25/169), but only as evidence.
- For n <= 7, (a) and (b) also follow from RQ-C C6 (A.5, A.5b), a separate rigorous computation: on [q4, q3] the
  maximum of k (1-q)^{2k-2} over k <= 7 is attained at k = 3, where 2 tau sqrt(3 (1-q)^4) = T. This agrees with the
  claim.

**PDF.** `audit/pdf_vs_tex.py`: all 109 numbers of the LaTeX source occur in the PDF text, and so do 353 of its 354
words of 6 or more letters (the missing one is the table spec `lrrrrrr`). The lemma numbering of the PDF matches the
.md. RQ-A's own outputs (`verify_k3_ABCDEFG.txt`, `break_tests_k3.txt`) agree with the text, including the two
expected non-detections (an ms box moved below u3 passes part F 17/40 times; an nc box moved to u <= 2 passes part E
43/60 times).

**Text.** No mathematical or textual fix is needed.

**Novelty: NEW.** These are the first exact values of R(q) in the regime where three equal coefficients are optimal.
- The matching lower bound is KNOWN: it is the k = 3 equal-coefficient value. Stone's thesis (Thm 4.3.1) shows that
  sup_n E|n^{-1/2}(chi_1+...+chi_n)| is attained at n = 3 exactly for q in [q4, q3].
- No source determines R(q) on any interval below q0 other than this project (A.9, A.11, A.12). Sources checked:
  RQ-A's and RQ-C's SOTA notes; my earlier searches (A.9, A.11).
- Lemma 5 is also the case n = 3 of RQ-C C6 (A.5); RQ-A's check is independent of it, and so is mine.

---

## A.15 RQ-B Remark 3.3 (APC(s(q)) implies C0 for q <= 0.3429) — VALID (2026-10-22 10:44 UTC)

**Claim** (RQ-B `rq/MAIN_RESULT.md` Remark 3.3, md lines 101–123, tex lines 177–207, PDF pdfTeX 10:38:09 UTC;
`rq/CLAIMS.md` of 10:38, team-status paragraph: "now fully proved"). Let s = ln(1/(1-q)), N_i i.i.d. Poisson(s),
A(s) = max_{k>=1} E|N_{ks} - ks|/sqrt(ks) (the equal-coefficient value), and
  APC(s): E|sum_i g_i (N_i - s)| <= A(s) sqrt(s sum g_i^2) for all n and all real g.
Then for every q <= 0.3429, APC(s(q)) implies C0 at q, that is R(q) = M(q) = max_k 2 sqrt(kq) (1-q)^{k-1/2}.

This is an implication; APC is open (RQ-B checks it numerically for n <= 6). It sharpens Theorem 3 (A.10a), where
R_ID in place of A(s) gives only R <= B. In A.13 I had proved the step that the earlier text asserted without proof
(the peaks decrease), by a series identity. RQ-B now gives its own proof, by a Padé bound.

### Rebuilt proof

1. *Theorem 3 with A(s).* The proof of Theorem 3 (A.10a) uses R_ID only through E|I| <= R_ID sqrt(E I^2) for
   I = sum_i Delta_i(f)(N_i - s), where E I^2 = s D(f). APC(s) gives E|I| <= A(s) sqrt(s D(f)) directly. Then
   s(1-q) D(f) <= A(s) sqrt(s D(f))/2, so D(f) <= A(s)^2/(4 s (1-q)^2), and Lemma 2.1 gives
   R(q)^2 <= q A(s)^2/((1-q)s). Correct.
2. *Poisson mean deviation.* For m = floor(l), E(l - N)_+ = l P(N <= m) - E[N; N <= m] = l P(N = m), because
   E[N; N <= m] = l P(N <= m-1). So E|N - l|/sqrt(l) = f_m(l) = 2 l^{m+1/2} e^{-l}/m! on [m, m+1), and this is
   continuous at the integers. This is the classical closed form. Correct.
3. *The peaks decrease.*
   - Since (ln f_m)' = (m+1/2)/l - 1, the maximum on [m, m+1) is r_m = f_m(x), x = m + 1/2.
   - r_{m+1}/r_m = (x+1)(1+1/x)^x/(e(x+1/2)), and (x+1/2)/(x+1) = 1 - y with y = 1/(2x+2), which lies in (0, 1/5]
     for m >= 1. So r_{m+1} < r_m iff x ln(1+1/x) < 1 + ln(1-y).
   - The Padé bound ln(1+t) <= t(6+t)/(6+4t) for t >= 0: the difference h vanishes at 0, and
     h' = 4t^3/((6+4t)^2(1+t)) >= 0. At t = 1/x it gives x ln(1+1/x) <= 1 - 3/(6x+4) = 1 - y/(1-2y/3).
   - g(y) = ln(1-y) + y/(1-2y/3) has g(0) = 0 and g' = (y/3)(1-4y/3)/((1-y)(1-2y/3)^2) > 0 on (0, 3/4). So g > 0
     there, and the inequality is strict.

   Correct. This proof differs from mine in A.13; both are valid.
4. *Constants.* sup_{l>=1} f = r_1 = 2(3/2)^{3/2} e^{-3/2} = 0.8198326 < 0.82. f_0(l) = 2 sqrt(l) e^{-l} is
   log-concave with peak at l = 1/2, and f_0(0.32) = 0.8215439, f_0(0.74) = 0.8208578. So f_0 > 0.82 on [0.32, 0.74].
   Correct.
5. *A multiple of s in [0.32, 0.74] when s <= 0.42.* If s >= 0.32, take k = 1. Otherwise let k be least with
   ks >= 0.32; then (k-1)s < 0.32, so ks < 0.32 + s <= 0.74. Hence A(s) >= f_0(ks) > 0.82 > r_1, which bounds every
   term with ks >= 1. So the maximum defining A(s) is attained with ks < 1, and A(s) = max_{k: ks<1} 2 sqrt(ks) e^{-ks}.
   Correct.
6. *Conclusion.* With e^{-s} = 1 - q, q A(s)^2/((1-q)s) = max_{k: ks<1} 4kq(1-q)^{2k-1} <= M(q)^2. So APC(s(q))
   gives R <= M, and R >= M is Theorem 1 (Stone's equal-coefficient value). Finally, s(q) <= 0.42 iff
   q <= 1 - e^{-0.42} = 0.3429532. Correct. In fact equality holds in the last inequality (E2 below).

Context: C0 holds on [25/169, 1/2] (A.6, A.11, A.14). So with this remark, the open part of C0, q < 25/169, is
reduced to APC(s(q)).

### Independent check (RQ-AUD code only)

`audit/rqb/a15_remark33_pade.py` (output `audit/rqb/outputs/a15_remark33_pade.txt`, 16 s):
- sympy, exact: all eight identities of the proof are True. They are the ratio of peaks (via Gamma), the reduction to
  y, y in (0, 1/5], the value and derivative of the Padé difference, the substitution t = 1/x, g and g', the
  log-concavity of f_0, and (ln f_m)'.
- Certified (mpmath interval arithmetic, 40 digits): r_1 = 0.8198325579 < 0.82; f_0(0.32) = 0.8215438532;
  f_0(0.74) = 0.8208578181; 1 - e^{-0.42} = 0.3429531802 > 0.3429. As a sanity check, h(t) > 0 at 20,000 points of
  (0, 20] and g(y) > 0 at 2,000 points of (0, 0.2].
- End to end (30 digits, evidence only). I took 4,000 values of s in [0.001, 0.42] and all k with ks <= 12. In every
  case the maximum is attained with ks < 1, and it beats every ks >= 1 by at least 0.0164. Also
  q A(s)^2/((1-q)s) = M(q)^2 to 2.5e-29.
- `a13b_remark33.py` (A.13) also certifies r_{m+1} < r_m for m = 1..2000, by a third route (direct interval
  evaluation).
- Info, outside the claim: at s = 0.8 the maximum is at ks = 1.6 and at s = 1.2 at ks = 2.4. So beyond s = 0.74 the
  formula A(s) = max_{ks<1} 2 sqrt(ks) e^{-ks} fails and the argument needs more.

**PDF.** The PDF of 10:38 contains all 117 numbers and all 320 words of 6 or more letters of its tex
(`audit/pdf_vs_tex.py`), including the Padé argument.

**Text.** No fix is needed.

**Novelty.** The statement is NEW: no source states the reduction, and it is a corollary of Theorem 3 (A.10a, NEW).
The ingredients are KNOWN: the closed form of the Poisson mean deviation is classical, the Padé bound for ln(1+t) is
standard, and R >= M is Stone's equal-coefficient value.

---

## A.16 RQ-B C15: Lemma 9 and Corollary 9.1 (small coefficients in the k = 3 gap [q4, 25/169]) — VALID, NEW (2026-10-22 11:14 UTC)

**Claim** (RQ-B `rq/MAIN_RESULT.md` §9, md lines 330–411; tex lines 503–602; PDF pdfTeX 10:49:20 UTC, Section 10,
Lemma 10.1 and Corollary 10.2; `rq/CLAIMS.md` C15 of 10:49; data `numerics/k3_smalla_certs.json`, md5 8b93f594…).
Notation: u = sqrt((1-q)/q), so q = 1/(1+u^2); chi in {u, -1/u}; tau = u/(1+u^2); and
T(q) = 2 sqrt3 (1-q)^2 tau = 2 sqrt3 u^5/(1+u^2)^3, the value at (1,1,1)/sqrt3. Let U = [12/5, 2543/1000]. On U,
q runs over [0.133926, 25/169], which contains [q4, 25/169] because u4 = sqrt(3+2 sqrt3) = 2.542460 < 2.543.
- **Lemma 9.** Let u be in U, n >= 2, alpha a unit vector in R^n, L = sum alpha_i chi_i and a = max_i |alpha_i|.
  - (a) If a <= a_Z = 480/6409 = 0.074895, then E|L| <= T(q).
  - (b) Suppose a_Z <= a <= a_S = 120/409 = 0.293399. Let M = (L - alpha_{i0} chi_{i0})/b be the normalised
    remainder, where |alpha_{i0}| = a and b = sqrt(1-a^2). If E|M| <= T(q), then E|L| <= T(q).
- **Corollary 9.1.** Let q be in [q4, 25/169]. If E|L| <= T(q) for every n and every unit alpha with
  max_i |alpha_i| >= a_S, then R(q) = T(q) = M(q).

This is a reduction, not a new exact range. The gap [q4, 25/169] between A.14 and the region where R > T stays open
for max_i |alpha_i| >= 0.2934. That region contains RQ-A's obstruction (ii) (two coefficients near 0.57) and the
four-way tie (1,1,1,1)/2 at q4.

### Rebuilt proof (each step re-derived from the hypotheses)

1. *Part (a): zero bias.* A.0 item 7 is BF3's Case A. It uses no induction hypothesis and no restriction on q, and
   gives E|L| <= sqrt(2/pi) + a C(u) for every unit alpha. Here
   C(u) = W_1(chi, Unif[-1/u, u]) = (q^2 + (1-q)^2)/(2 tau) = (1+u^4)/(2u(1+u^2)).
   - T decreases on U, since d log T/du = (5-u^2)/(u(1+u^2)) and u^2 >= 5.76.
   - C increases on U, since C' = (u^2-1)(u^4+4u^2+1)/(2u^2(1+u^2)^2) > 0.
   - So u = 2543/1000 is the worst point, and there T - sqrt(2/pi) - C a_Z = 0.0026011 > 0 (certified).
   Correct. RQ-B instead uses 200 strips and gets slack 0.0025; the conclusion is the same.
2. *Normalisation.* E|L| = E|-L|, and the sign flip turns the remainder into -M, with E|-M| = E|M|. A permutation
   changes nothing. So we may take alpha_1 = a > 0. Correct.
3. *Identity (9.1).* Put x = bM. Then |au + x| = au + x + 2(-au - x)_+ and |x - a/u| = a/u - x + 2(x - a/u)_+.
   With EM = 0 and qu = (1-q)/u = tau this gives E|L| = 2 tau [a + E Gt(M)], where
   Gt(y) = (uby - a)_+ + (-by/u - a)_+. So E|L| <= T iff a + E Gt(M) <= T/(2 tau) = sqrt3 (1-q)^2. Correct.
4. *Rational parametrisation.* a = 2s/(1+s^2) and b = (1-s^2)/(1+s^2) satisfy a^2 + b^2 = 1, and a increases on
   [0, 1], with a(3/80) = 480/6409 and a(3/20) = 120/409. On a cell [u0, u1] x [s0, s1] we have a in [a0, a1],
   b in [b1, b0], and a/b = 2s/(1-s^2) <= a1/b1 < 1. Correct.
5. *Envelope.* For y >= 0 the second term of Gt vanishes, and uby - a <= u1 b0 y - a0. For y <= 0 the first term
   vanishes, and b|y|/u - a <= b0|y|/u0 - a0. So Gt <= Gh_C on R for every (u, s) in the cell. Correct.
6. *Domination.* The points -a0 u0/b0, 0 and a0/(u1 b0) cut R into four closed pieces. On each, P - Gh_C is a
   polynomial: c with the linear coefficient changed by -delta or +delta, and on the two outer pieces also
   +b0/u0 or -u1 b0 in the linear term and +a0 in the constant. I derived the four polynomials myself.
   - No real root in the closed piece and one positive value there give P - Gh_C > 0 on the piece.
   - Hence P > Gh_C >= Gt on R, and
     E Gt(M) <= sum c_k EM^k + delta E|M| <= sum c_k EM^k + delta T,
     using delta >= 0 and the hypothesis E|M| <= T.
   Correct.
7. *Moments.* M = sum_i beta_i chi_i with independent chi_i, sum beta_i^2 = 1 and |beta_i| <= a/b.
   - kappa_j(M) = kappa_j(chi) s_j, where s_j = sum_i beta_i^j.
   - |s_j| <= max|beta_i|^{j-2} sum beta_i^2 <= rho^{j-2}; s_j >= 0 for even j; and s_3^2 <= s_2 s_4 = s_4 by
     Cauchy–Schwarz.
   - EM^m for m <= 8 is a polynomial in K_j = kappa_j s_j (moments from cumulants).
   Any enclosure of sum c_k EM^k over the box of values of (kappa_j(chi), s_j) is a valid C_C. RQ-B maximises
   c3 kappa3 s3 + c4 kappa4 s4 exactly and encloses the remaining monomials by interval products. Checking only the
   corners of the (kappa3, kappa4) box is enough: for fixed (kappa3, kappa4), the exact maximum over (s3, s4) is a
   maximum of functions linear in (kappa3, kappa4), so it is convex in (kappa3, kappa4). Correct.
8. *Target.* Suppose 1 - 2 delta tau(u0) > 0 and a1 + C_C < S (u0^2/(1+u0^2))^2 (1 - 2 delta tau(u0)) with
   S <= sqrt3. On U, 1 - q = u^2/(1+u^2) increases and tau decreases. So for every (u, s) in the cell,
   a + E Gt(M) <= a1 + C_C + delta T < sqrt3 (1-q)^2 (1 - 2 delta tau) + 2 delta tau sqrt3 (1-q)^2 = sqrt3 (1-q)^2.
   Correct.
9. *Corollary 9.1.* Induction on n.
   - n = 1: E|chi| = 2 tau <= T iff sqrt3 (1-q)^2 >= 1 iff q <= 1 - 3^{-1/4} = 0.2402, which holds on the gap.
   - n >= 2: if a >= a_S, use the hypothesis; if a <= a_Z, use (a). Otherwise the remainder is a unit-normalised sum
     of n - 1 terms, so E|M| <= R_{n-1}(q) <= T by induction, and (b) applies.
   This gives R <= T. Also R >= T, the value at (1,1,1)/sqrt3 (Stone, KNOWN), and T = M on
   [q4, 25/169], a subset of [q4, q3]. Correct.

### Independent computer verification (RQ-AUD code only)

I did not read RQ-B's generator, checker or negative-test scripts (`k3_smalla_cover.py`, `k3_smalla_check.py`,
`k3_smalla_negative.py`). My code is written from the text and reads only the certificate file. Root isolation uses
my A.6 helpers (Arb via python-flint), whereas RQ-B's checker uses sympy; my second method is pure-Fraction Sturm
sequences.
- `audit/rqb/a16_lemmaS_verify.py` (12 s; output `outputs/a16_lemmaS_verify.txt`): ALL CHECKS PASSED.
  - K: kappa_1..kappa_4 from the series of log E e^{t chi} are 0, 1, u - 1/u and u^2 - 4 + u^-2.
    kappa_3..kappa_8 are monotone on U (no root of the derivative numerators in U, by Arb). EM^0..EM^8 from
    exp(t^2/2 + sum K_j t^j/j!) equal the hand formulas, e.g. EM^8 = K8 + 28K6 + 56K3K5 + 35K4^2 + 210K4 + 280K3^2 + 105.
  - Z: part (a) as in step 1, with sympy identities and 40-digit interval arithmetic at u = 2543/1000 (slack 0.0026011).
  - I: identity (9.1) holds exactly on 60 random rational examples, with remainders of 1–5 terms; 0 mismatches.
  - T: the 4229 cells lie inside U x [3/80, 3/20], their exact areas sum to the rectangle's, and no two have
    overlapping interiors (sweep).
  - D: P > Gh_C on the four closed pieces in all 4229 cells.
  - M: my own moment bound. kappa_j(chi) is enclosed by its endpoint values (it is monotone). All terms linear in K3
    or K4, from every EM^m, are merged and maximised exactly over {s3^2 <= s4 <= rho^2} at the four corners. The
    other monomials are enclosed by exact interval products with even-power ranges. Against the target with
    S = floor(10^30 sqrt3)/10^30: 0 failures, minimum exact slack 3.733e-4, and rho equals the stored value in every
    cell. My a1 + C is 3.6e-4 to 5.3e-3 below RQ-B's stored lhs, because of the merged linear terms.
- `a16d_reproduce_lhs.py` (24 s). I implemented RQ-B's coarser enclosure exactly as the text describes it: only
  c3 kappa3 s3 + c4 kappa4 s4 is exact, and each kappa_j is enclosed by the ranges of its Laurent monomials. This
  reproduces the stored lhs exactly, as rationals, in 4229/4229 cells. The stored lhs passes my exact target in every
  cell, with minimum exact slack 9.688e-7 (RQ-B reports 9.7e-7). So both bounds certify the lemma.
- `a16e_sturm.py` (28 s). Second exact method for D: Sturm sequences in pure Python Fractions, with no Arb and no
  sympy. All 4229 cells are certified, and the calibrated test below gives 4229/4229 in both directions.
- Data facts (checked 11:18). The cell widths are 3/2000, 1/400, 3/1000 and 1/200 in u, and 1/6400, 1/3200, 1/1600
  and 1/800 in s, as the text says. 2045 certificates have degree 8 and 2184 have degree 6 (c7 = c8 = 0). Every
  leading coefficient is positive, as domination on the unbounded pieces requires. delta lies in [0, 1.2482], and
  5 cells have delta = 0.

### Negative, calibrated and semantic tests

- `a16b_negative.py` (26 s).
  - Tiling. Dropping a cell, duplicating one, shifting one by half its u-width, shrinking an s-width by a tenth, and
    pushing an edge cell out of U are each rejected in 5/5 trials. Splitting a cell into its two u-halves is
    accepted in 5/5, and both halves are valid certificates.
  - Calibrated, every cell. With dslack = min over R of (P - Gh_C) (minimum 9.206e-7) and mslack my exact target
    slack:
    - c0 - 2 dslack fails domination in 4229/4229 cells, and c0 - dslack/2 passes in 4229/4229.
    - c0 + 2 mslack fails the target in 4229/4229 cells, and c0 + mslack/2 passes in 4229/4229.
  - Info: RQ-B's listed corruptions under my checker, as the number of cells that still pass.
    - c2 lowered 1%: 0. u0 - 1/100: 0. u1 + 1/20: 0. s0 - 1/100: 0.
    - delta shrunk 10%, and delta = 0: 5 each. These 5 cells (u in [2.400, 2.4175], s about 0.039) already have
      delta = 0, which is possible there because T(25/169) = 0.8929 is above the Gaussian moment value. RQ-B's
      "rejected in all sampled cells" holds for the cells with delta > 0.
    - c0 lowered 0.1%: 2667; s1 + 1/400: 1816. An exact check accepts a corrupted record only if that record is itself
      a valid certificate, as RQ-B says.
- `a16c_semantic.py` (2 min; floating point, evidence only). 200 cells (the 40 tightest and 160 random) and 4800
  samples (u, s, M), with the finite law of each admissible M computed exactly. The remainders are of three kinds:
  equal coefficients, extreme ones (all |beta_i| = a/b), and mixed coefficient groups.
  - The moment polynomials agree with the distributions to 6e-14, and identity (9.1) holds to 1.2e-15.
  - E P(M) - E Gt(M) >= 0.0147.
  - C - sum c_k EM^k >= 9.4e-6 for my bound and >= 3.9e-4 for RQ-B's. So my tighter bound is nearly attained, by
    remainders with all |beta_i| near a/b, but never violated.
  - sqrt3 (1-q)^2 - a - sum c_k EM^k - delta T >= 8.1e-4, and T - E|L| >= 0.068.
- Attack (same script). Points: u in {2.40, 2.44, 2.48, 2.52, u4, 2.543} and 12 values of a in [a_Z, a_S]. alpha is
  made of up to three blocks of equal coefficients: k1 copies of a, k2 of +-a and k3 of +-c with c <= a. The maximum
  of E|L|/T is 0.93266, at u = 2.543 and a = a_S with alpha = (0.2934, 0.2882 x 11), so n = 12. No counterexample.
  In this window the true values lie far below T; the certificates are tight only because the moment method loses
  information.

**PDF.** The PDF of 10:49:20 contains all 150 numbers and all 404 words of 6 or more letters of its tex
(`audit/pdf_vs_tex.py`). The numbering differs: Lemma 9 and Corollary 9.1 of the md are Lemma 10.1 and
Corollary 10.2, in Section 10 of the PDF.

**Text.** No fix is needed. Update (11:25): RQ-B's 11:18 version of §9 states my delta remark in its negative-test
sentence. Nothing else in the text, the data or the outputs changed, so this verdict also covers the 11:18 version.

**Novelty.** NEW. No source treats R(q) for q < 25/169 beyond equal coefficients (literature re-check at 10:48–10:50,
store log).
- Ivanisvili–Stone (arXiv:2407.04835) only quote the equal-coefficient supremum and assume that R(p) equals it.
- arXiv:2608.29703 and arXiv:2610.07526 concern unbiased Rademacher sums.
The ingredients are KNOWN: the zero-bias Stein bound (BF3 Lemmas 9.6–9.7, audited in A.0), the conditioning identity
(BF3 Lemma 9.4), cumulant calculus, and polynomial-majorant moment certificates (BF3 §9.4, as in A.6 and A.14).

---

## A.17 RQ-B C16 (transfer lemma, OR of m bits) — VALID (2026-10-22 11:25 UTC)

**Claim** (RQ-B `rq/CLAIMS.md` C16 of 11:18; it is not in MAIN_RESULT). Let q' be in (0,1), m >= 1 and
q = 1 - (1-q')^m. Then R(q)^2 <= R(q')^2 q/(m q'(1-q')^{m-1}). Consequently, if R(q') = M_k(q') with k = mj, then
R(q) <= M_j(q) <= M(q), so R(q) = M(q). For example, C0 at q*_{mj} implies C0 at q*_j, where q*_K = 1 - e^{-1/(2K)}.
Theorem 3 (A.10a) is the m -> oo limit.

### Rebuilt proof

1. *C1* (A.7a, VALID after its fix). For f: {0,1}^n -> [0,1] on the q-biased cube, with
   Delta_i(f) = E[f | x_i = 1] - E[f | x_i = 0], R(q)^2 = 4q(1-q) sup_f sum_i Delta_i(f)^2. The normalisation of
   Delta does not depend on q, which the transfer needs.
2. *The OR map.* Let y_ij (i <= n, j <= m) be i.i.d. Bern(q') and x_i = max_j y_ij. The x_i are independent
   Bern(q), since P(x_i = 0) = (1-q')^m = 1-q. Put F = f(x(y)), a function on {0,1}^{nm} with values in [0,1].
3. *Influences.* Given y_ij = 1, x_i = 1. Given y_ij = 0, x_i = 0 with probability (1-q')^{m-1} and x_i = 1
   otherwise, and the other x_k are independent of y_ij. So
   Delta_ij(F) = E[f | x_i = 1] - (1-q')^{m-1} E[f | x_i = 0] - (1 - (1-q')^{m-1}) E[f | x_i = 1]
   = (1-q')^{m-1} Delta_i(f). Correct.
4. *The bound.* sum_ij Delta_ij(F)^2 = m (1-q')^{2m-2} sum_i Delta_i(f)^2 <= R(q')^2/(4q'(1-q')) by C1 at q'. So
   R(q)^2 = 4q(1-q) sup_f sum_i Delta_i(f)^2 <= R(q')^2 q (1-q)/(m q'(1-q')^{2m-1}) = R(q')^2 q/(m q'(1-q')^{m-1}),
   using 1-q = (1-q')^m. Correct.
5. *Consequence.* With M_k(q)^2 = 4kq(1-q)^{2k-1}, M_{mj}(q')^2 q/(m q'(1-q')^{m-1}) = 4jq(1-q')^{m(2j-1)} = M_j(q)^2.
   So R(q') = M_{mj}(q') gives R(q) <= M_j(q) <= M(q) <= R(q), and equality holds throughout. Correct.
6. *The example.* 1 - (1-q*_{mj})^m = 1 - e^{-1/(2j)} = q*_j. At q*_K, 1/(q(2-q)) = 1/(1-e^{-1/K}) lies in (K, K+1).
   So the optimal equal-coefficient count there is K (RQ-B Theorem 1), and C0 at q*_{mj} means R = M_{mj} there.
   Correct.
7. *The m -> oo remark.* With m q' = s fixed, q/(m q'(1-q')^{m-1}) -> (e^s - 1)/s = q/((1-q) s), where
   q = 1 - e^{-s}. With R(q') -> R_ID (A.8, A.10b) this is the bound of Theorem 3. This is a heuristic remark, not a
   proof; Theorem 3 has its own proof (A.10a).

*Limitation* (RQ-B's own remark, confirmed). The map sends q' to a larger q, and the team's exact results land in
the k = 1 range. From [q3, q0] (k = 2, A.11) with m = 2 one gets [1/3, 1/2]. From [25/169, q3] (k = 3, A.14) with
m = 3 one gets [0.38143, 0.45567]. Both lie inside A.6's range [0.29289, 0.70711], so nothing new follows.

### Independent check (RQ-AUD code only)

`audit/rqb/a17_transfer_check.py` (10 s; output `audit/rqb/outputs/a17_transfer_check.txt`): ALL CHECKS PASSED. I did
not read RQ-B's `numerics/transfer_check.py`.
- Exact rationals. The identity Delta_ij(F) = (1-q')^{m-1} Delta_i(f) and the per-f equality
  4q(1-q) sum Delta_i^2 = [4q'(1-q') sum Delta_ij^2] q/(m q'(1-q')^{m-1}) hold for 3846 functions, at
  q' in {1/7, 1/5, 2/7, 1/3, 9/20, 4/5}, with 0 failures. The functions are all Boolean f for n <= 2, and for n = 3
  with m <= 2; 24 random Boolean f for n = m = 3; and 5 random [0,1]-valued f per case.
- sympy: the M-identity holds for symbolic q' and all m, j <= 8, and in general form with symbolic m and j.
- Certified: floor(1/(q(2-q))) = K at q*_K for K = 1..3000, and 1 - (1-q*_{mj})^m = q*_j.
- Info: the m -> oo limit equals q/((1-q) s).

**Novelty.** The statement is NEW (no source found). The technique, writing a q-biased bit as the OR of m q'-biased
bits, is standard. It gives no new exact value from the team's results.

---

## A.18 RQ-A MAIN-4 (R(q) = T(q) = 2 sqrt3 (1-q)^2 tau on [q4, 25/169]; the k = 3 regime closed) — VALID, NEW (2026-10-22 12:41 UTC)

**Claim** (RQ-A `MAIN_RESULT_K3B.md/.tex/.pdf`, PDF pdfTeX 11:52:13 UTC, 19 pages, posted 11:55; `AUDIT_REQUEST.md`
section MAIN-4 of 11:56; CLAIMS MAIN-4). Let q4 = 1-sqrt3/2, q_L = 25/169, q3 = 1-sqrt(2/3), tau = sqrt(q(1-q)),
T = 2 sqrt3 (1-q)^2 tau, T_4 = 4(1-q)^3 tau.
- (a) For every q in [q4, q_L], every n and every unit alpha, E|sum alpha_i chi_i| <= T. Hence R(q) = T on
  [q4, q_L], and R(q) = 2 sqrt3 q^2 tau on [1-q_L, 1-q4].
- (b) Equality holds iff alpha = +-(e_i+e_j+e_k)/sqrt3, or q in {q4, 1-q4} and alpha = +-(e_i+e_j+e_k+e_l)/2.
- (c) For q < q4, R(q) >= T_4 > T.
- Corollary 1 (with A.14): R = T exactly on [q4, q3], and {q <= 1/2 : R(q) = T(q)} = [q4, q3]. The extremisers are
  as in (b), plus +-(e_i+e_j)/sqrt2 at q3.
- Corollary 2 (with A.6 and A.11): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2}
  = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), on [q4, 1-q4] = [0.13397, 0.86603].

My copies: the texts are in `audit/rqa/texts/` (md 2c755f9e…), and the data snapshot is in `audit/rqa/k3b_data/`
(7.8 MB, committed and mirrored). The snapshot is byte-identical to RQ-A's `outputs/` (manifest 127ef15a…,
`k3b_MD5SUMS.txt` 2074adcc…). Verdict: **VALID, no fix needed.**

### Rebuilt proof (each step re-derived from the hypotheses)

Parametrisation u = sqrt((1-q)/q), q <= 1/2 by symmetry (Lemma 3). The range [q4, q_L] is u in [12/5, u4], where
u4^2 = (1-q4)/q4 = sqrt3/(2-sqrt3) = 3+2 sqrt3. The cover uses u in [U_-, U_+] = [12/5, 127123/50000], with
U_+ - u4 = 2.43e-7.
1. *Constants.* U_+^2 > 3 and (U_+^2-3)^2 >= 12 give U_+ >= u4. (T8+1)^2 >= 2 gives T8 = 20711/50000 >= sqrt2-1.
   U_-^2 = 5.76 > 5, so T~ = 2u^5/(1+u^2)^3 is decreasing on the range; T^- = S3 min(T~(u1), T~(u2)) is valid
   anyway by unimodality. Also u3 < U_-, so q < q3 on the whole range. Correct.
2. *Test vectors and (c)* (Lemma 4). For q < 1/k, the sum of k bits is positive iff some bit equals u (u^2 > k-1).
   Hence E|chi_1+...+chi_k|/sqrt k = 2 sqrt k (1-q)^{k-1} tau. T_2 <= T iff q <= q3; T_4 >= T iff q <= q4 (q4 < 1/4);
   2 tau < T for q <= q3. Correct.
3. *Corollary 2.* On [q4, q3], [q3, q0] and [q0, 1/2] the maximum of {1, sqrt2(1-q), sqrt3(1-q)^2} is the stated
   entry. For k >= 4 and 1-q <= sqrt3/2: sqrt(k/3)(1-q)^{k-3} <= (k/3 (3/4)^{k-3})^{1/2} <= 1, with equality of the
   last bound at k = 4, and each further step multiplies it by at most (5/4)(3/4) < 1. Correct.
4. *Lemma 5* (two coordinates). The identities p_j x_j = tau g_j follow from qu = (1-q)v = tau. The case analysis
   gives E X_+/tau = max{c, d, [s=1](1-q)(c+d)}, hence E|X| < T|(c,d)| for q < q3. Correct (as in A.11 and A.14).
5. *Lemmas 6 and 7* (three- and four-bit lemmas).
   - E[f chi_i] = tau Delta_i(f), so G_n(c) = E[f* X] <= tau |c| |Delta(f*)|, and the claims H_f >= 0 give
     G_n(c) <= T|c|.
   - For OR_S: Delta_i = 2(1-q)^{|S|-1} on S. So H_{OR_4} = 12(1-q)^4 - 16(1-q)^6 = -4(1-q)^4 g4, with
     g4 = 4q^2-8q+1, roots 1 +- sqrt3/2, decreasing on [0, 1]. Thus Lemma 7 is false below q4, tight at q4 and
     strict above.
   - Equality needs c to be a positive multiple of Delta(f*) and H_{f*}(q) = 0.
   - The lemmas agree with A.5 (C6, n = 4): R_4 = T for q >= q4.

   Correct.
6. *Lemmas 9–11* (moments).
   - Lemma 9's table of kappa_3..kappa_10 equals my cumulants (`a18d`).
   - Lemma 10 is the moment–cumulant recursion with K_j = kappa_j p_j.
   - Lemma 11: p4 <= m^2; p3^2 <= p2 p4; |p_j| <= m^{j-4} p4; and Jensen with the weights beta_i^2 for even j.

   Correct.
7. *Lemma 12* (sign information). |beta_i| <= sqrt(1-m^2) for i != i0 gives p3 <= phi(m) =
   -m^3 + (1-m^2)^{3/2}. phi is decreasing, and phi(m) < 0 iff 2m^2 > 1. Correct.
8. *Definition 13 / Lemma 14* (ten-moment objective bound). Each of the four term bounds is valid:
   - (T0): p3 <= p* < 0 and C_e >= C_e^- >= 0 give C_e p3 <= C_e^- p*. Here C_e = L_e kappa_3 and kappa_3 = u - 1/u > 0.
   - (T1): |C_e p^e| <= max|C_e^+-| U_e rho^{u_e}.
   - (T2): for even e, p^e >= ell_e rho^{l_e} >= 0, and C_e <= C_e^+ <= 0.
   - (T3): p^e >= 0.

   So E P(M) <= Theta - h(rho) < Theta. Correct.
9. *Lemma 15* (cells, a1 <= 7/20).
   - I re-derived the BF3 Lemma 9.4 identity on the three ranges of y.
   - l_i <= lbar_i follows from the sign of y and the monotonicity of b_1, a/u, u^2/(1+u^2) and 1/(1+u^2).
   - The coefficients of M_1 are at most mbar.
   - Theta_1 <= tau(u)(sqrt3 (1-q)^2 - a), because S3 (144/169)^2 = 1.2575 > 1.25 > 7/20.

   Correct.
10. *Lemmas 16–17.* F_x(y) is a seminorm in x. The conditional-expectation identities hold for the patches p_2 and
    p_3. At m = 1 the last entry of p_3 is 0, so F does not depend on y. Correct.
11. *Definition 18 / Lemma 19* (cone lemma).
    - V_0, E_1..E_k is a basis: E_i ⊥ n_0, V_0 . n_0 != 0, each facet has rank k, and h_{i,0} . cbar = h_{i,0} . E_i / 2 != 0.
    - h_{i,0} . z = mu_i h_{i,0} . E_i gives mu_i >= 0.
    - h_{i,1} . z = (lambda - mu_i) h_{i,1} . V_0 with h_{i,1} . V_0 = -h_{i,1} . E_i = 2 h_{i,1} . cbar > 0 gives
      mu_i <= lambda;
      hence lambda >= 0, and lambda = 0 forces z = 0.
    - z/lambda lies in the parallelepiped (multilinear weights), and lambda = z . n_0/|n_0|^2 <= 1/|n_0| <= 1.

    Correct.
12. *Lemma 21* (vertex envelope over u only). F_V(y) = sum_w |pi_w y_w + pi_w b_V y| with
    pi_w y_w = tau sum_i (+-gamma_i) prod_{l != i}; the roles of beta^+- swap for y < 0. Correct.
13. *Lemma 23* (vertex-certificate lemma).
    - Pointwise, F_{p(xi)} <= sum nu_e F_{V_e} <= sum nu_e P_e.
    - E P_e(Z) lies in (E F_{V_e}(Z), T^-), a subset of [0, T^-), and sum nu_e <= 1, so the expectation is < T^-.
    - Every place that applies the lemma uses an element of the class: M, M', one bit (TC at m = 1, where the cap
      is forced to 1), or N^{-1/2} sum chi' (TCS at m = 1).

    Correct.
14. *Boxes, mbar(B), Lemma 25 (lpv).* a2 = r d(t) <= r2 d(t2) and b >= b^- give m <= min(1, a2/b) <= mbar(B).
    Correct.
15. *Lemmas 26–27* (tail bound and near-circle tests).
    - max_{x > eta} (x - eta)/x^4 = 27/(256 eta^3), attained at x = 4 eta/3.
    - E M^4 = 3 + kappa_4 p_4 <= E_4.
    - (A) needs q <= q3, which holds on the whole range; (B) holds for every u.

    Correct.
16. *Lemma 28, tests (A3)/(B3).* r'^2 = 1 - b'^2 and E M'^4 <= 3 + max(0, kappa_4). Lemma 6 gives E|Y| <= T r', and
    the slack is T(1-r') = T b'^2/(1+r'). Lemma 6 holds on [q_U, q_L], so these tests are valid at every u of the
    cover. Correct.
17. *Definition 29, Lemma 30 (TC, SG).* The caps are right: min(1, m/sqrt(1-m^2)) increases in m. Lemma 12 is
    applied with m_c = m_1, and at m = 1 the case Z = one bit. Correct.
18. *Lemma 31, tests (A4)/(B4).* r''^2 = 1 - b''^2, and Lemma 7 gives E|Y_4| <= T r''. (A4) needs q >= q4 (the
    four-bit lemma); (B4) does not. Correct.
19. *Definition 32, Lemma 33 (TCS).*
    - The split of M' is exhaustive: m' <= m_c' uses C'; a coefficient -m' uses C'' (Lemma 12 applied to M');
      a coefficient +m' lands in a sub-piece.
    - Equality (b'' = 0, so m' = 1) has all four entries of c nonzero, because a2 >= |alpha_{i0}| = bm > 0. So
      Lemma 7 forces q = q4, s = 1 and c = (1,1,1,1)/2.

    Correct.
20. *Definition 34, Lemma 35 (ms5).* The split m <= m_c / some +m / only -m is exhaustive. Equality occurs only in
    (A3) at m = 1, giving (1,1,1)/sqrt3, or in TCS, giving (1,1,1,1)/2 at q4. Correct.
21. *Proof of Theorem 4.*
    - Cases: a1 = 1; a1 <= 7/20 (cells); r = 1 (Lemma 5); otherwise a box of the cover.
    - Closed boxes with disjoint interiors and full total volume fill the closed region.
    - Every route except ms5 is strict, so equality forces ms5 and Lemma 35 gives (b).
    - (c) follows from Lemma 4(iii). Corollary 1 follows from A.14 and Lemma 4, Corollary 2 from A.6, A.11 and item 3.

    Correct.

**Scope (my 11:48 point; audit point 4).**
- 87 boxes (36 lpv with s = +1, 32 lpv with s = -1, 19 ms5) and 16 cells reach u > u4.
- Every statement except test (A4) is valid at every u of its box or cell: cells, vertex certificates,
  near-circle (A), A3/B3 and B4.
- (A4) rests on Lemma 7. It is used only at u <= u4, and Theorem 4 claims nothing for q < q4, where
  (1,1,1,1)/2 beats T.
- The text says exactly this: Lemmas 31, 33 and 35 assume q >= q4, and Remark 2 explains why. As in A.11 and A.14,
  no data check can show it, since it is a statement about the range; the statement is right.

### Independent computer verification (RQ-AUD code only)

`audit/rqa/a18_k3b_verify.py` uses no RQ-A code. I read RQ-A's `verify_k3b.py` and `break_tests_k3b.py` only for
the record format and conventions, and to settle the 11:48 sanity-line question; every check is re-derived from the
text.
- Arithmetic: exact rationals; my positivity test from A.6; sqrt bounds from integer square roots.
- Moment polynomials and cumulants: `audit/common/moments10.py`, each derived two ways.
- Cone enclosure: exact separated minima of h . p. For fixed r, the t-part is a sinusoid in theta = 2 arctan t and
  the m-part is concave or convex; then the minimum over r.

Final run on the store copy of the data: `outputs/a18_k3b_verify_store_all.txt` (all parts, 17 s on 8 cores; the
earlier part-wise runs on my snapshot gave the same results). Text-versus-data facts: `a18d_k3b_textcheck.py`,
output `outputs/a18d_k3b_textcheck.txt`.

| step | result |
|------|--------|
| md5 of the 37 manifest files against `k3b_MD5SUMS.txt` | 0 mismatches |
| constants: U_-^2 > 5; U_+ >= u4 (U_+ - u4 = 2.43e-7); sqrt2 - 1 <= T8 < 1 | True |
| kappa_3..kappa_10 monotone in u on [U_-, U_+] (no root of kappa_j'), so endpoint values enclose them | True |
| my moment toolkit: two recursions for kappa_j, two constructions of E M^n (n <= 12), 351 exact enumeration identities | True |
| Lemma 9's table and Lemma 10's facts (Gaussian term (n-1)!!, nonnegative integer coefficients) | True |
| tilings: 288 cells tile [U_-, U_+] x [0, 7/20]; for each sign the boxes tile [U_-, U_+] x [0, T8] x [7/20, 1] (inside, volume sum = region volume, 0 overlapping pairs) | s = +1: 941 boxes, s = -1: 480 boxes, OK |
| one-coordinate cells: (V1)–(V3) and my ten-moment bound with target Theta_1 | **288/288** |
| vertex certificates: (P1)–(P3) exactly; (P4) by exact separated minima, never more than 1 sub-box; (W1) on every linear piece of my envelope over u; (W2) with my ten-moment bound and T^-; the caps from the structure (mbar(B) for lpv, m_c for C(1), min(m_2, mbar(B)) for SG, the recorded kappa after its cap check for TC and C'', m_c' for C') | **2,845/2,845** (1,106 lpv, 302 C(1), 871 TC, 146 SG, 210 C', 210 C''); 16,544 vertices |
| near-circle boxes (my exact test from A.14) | **13/13**, all by test (A) |
| m-split structure and pieces: b^- > 0; 0 < m_c < min(1, mbar(B)); plus and minus pieces each cover [m_c, min(1, mbar(B))]; types; SG and TCS phi checks; TC/TCS cap checks; TCS sub-pieces cover [m_c', kappa]; my exact (A3)/(B3) (A.14) and (A4)/(B4) tests | **302/302**; 123 A3 and 301 A4 pieces |
| three-bit lemma on [q_U, q_L], all 256 f (endpoint factor divided out, no root of the cofactor in the closed interval) | 0 failures; H_f == 0 exactly for +-OR_3 |
| four-bit lemma on [q4, q_L], all 65,536 f (g4 divided out, no root of the cofactor on [q4^-, q_L]) | 0 failures; H_f == 0 exactly for the 8 functions +-OR_S, \|S\| = 3; H_f(q4) = 0 otherwise only for +-OR_4; no H_f vanishes at q_L; 39 and 1,630 distinct H_f, as the text says |
| text facts: 98 / 126 / 64 cells, all of degree 10; all vertex polynomials of degree 6; piece counts (123 A3, 689 TC, 210 TCS; 146 SG, 182 TC); 93 boxes with TCS, all with u1 >= 2.48; m_c set; all m_c' = 17/20; width ranges | all as stated |
| where the extremisers sit | all 18 boxes containing the (t, r) of (1,1,1)/sqrt3 are ms5, and their plus pieces reaching m = 1 are A3 (where equality is allowed). The box containing (1,1,1,1)/2 at u4 is ms5, and its piece containing m = 1/sqrt2 is TCS |

### Negative, calibrated and semantic tests

- **Negative and calibrated** (`a18b_k3b_negative.py`; details in the 12:24 store-log entry): every corruption is
  rejected.
  - Cells, against the slack: T - 2 slack is rejected 288/288, and T - slack/2 is accepted 288/288.
  - Vertex sets: a vertex moved by 1e-6, or the polytope shrunk by 10%, is rejected 72/72.
  - m-split pieces: widened, removed, or with p* moved below phi(m1), rejected 25/25.
  - Four-bit lemma: it fails below q4, at ±OR_4.
  - Both tiling corruptions are rejected.
- **Semantic, end to end** (`a18c_k3b_semantic.py`, output `outputs/a18c_k3b_semantic.txt`, 83 s; floating point
  with 40 digits, evidence for the semantics of the data).
  - Each sample is a real reduced unit vector alpha: a random point of a record's region and a random remainder
    satisfying the record's constraints.
  - E|L| is computed by exact enumeration of the atoms, and every inequality of the lemma's chain is checked.
  - Result: 1,862 samples (53 cells, 140 lpv, 302 C(1), 536 TC plus, 152 TC minus, 104 SG, 162 C', 155 C'',
    84 A3, 174 A4) and **0 violations**.
  - In every vertex chain, E F_p(Z) equals E|L| to 1e-25, and the parallelepiped coordinates satisfy
    0 <= mu_i <= lambda <= 1/|n0|. So the sign conventions, the coordinate order and the vertex indexing of the
    data mean what the lemmas say.
  - Smallest margins: T^- - max_e E P_e(Z) >= 1.46e-4 (TC plus), and T - E|L| >= 3.9e-3 at the sampled points.
- **Attack.** No counterexample, so there is no new search here.
  - A.14's low-range search (exact enumeration for n <= 16 plus large-plus-bulk families, at q4 - 1e-3, q4,
    q4 + 1e-4 and 0.135, ..., 0.1475) gave the ratio 1 for every q >= q4. It is attained only at (1,1,1)/sqrt3, and
    also at (1,1,1,1)/2 at q4.
  - H.1 (the k = 4 side, including q4) agrees.

### Text points (no fix required)

- The PDF carries all 113 numbers and 415 of the 416 words of the LaTeX source (`audit/pdf_vs_tex.py`, output
  `outputs/a18_pdf_vs_tex.txt`; the missing "word" is the column spec `lrrrrr`). The md is the same proof without
  the abstract.
- The PDF abstract counts three new ingredients, while the md paragraph "Relation to Theorem 3" counts four (it also
  lists the range and A_S). Harmless.
- In Definition 13 the exponent u_e and the factor U_e reuse the letters of u and U_+-. Harmless.
- Definition 34 asks u1 >= 2, which no proof step uses. Harmless; every box has u1 >= 12/5.

### Novelty

**NEW.**
- This is the first exact value of R(q) on [q4, 25/169].
- With A.14, the k = 3 regime [q4, q3] is closed, sharp at both ends.
- With A.6, A.11 and A.14: R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1) on [q4, 1-q4] = [0.13397, 0.86603]. This is
  the conjectured formula (BF3 §9.4; the equal-coefficient lower bound is KNOWN, Stone, thesis Thm 4.3.1) on its
  first three regimes. The literature has only [3/8, 5/8] (BF3 Theorem K).
- RQ-B's reduction of the same gap (A.16) is not used. It stays valid, but it is no longer needed for the exact value.

---

## A.19 RQ-B C17 (Theorem 8.5: R_ID <= 22/25 = 0.88) — VALID WITH FIXES (text only), NEW (2026-10-22 13:03 UTC)

### Claim

R_ID = sup E|Z_K| over probability Kolmogorov measures K satisfies R_ID <= 22/25. With Theorem 3 (C6, A.10a) and
Theorem 4 (C7, A.10b):
- sqrt(2/e) <= lim_{q->0} R(q) <= 0.88;
- R(q) <= B(q) = 0.88 sqrt(q/((1-q) ln(1/(1-q)))) for every q in (0, 1/2];
- B(q) < 1 for q < 0.3881; R(0.1) <= 0.9037, R(0.2) <= 0.9315, R(1/4) <= 0.9473;
- B(q) is within 3.65% of M(q) on (0, 1/4].

Sources:
- RQ-B `rq/MAIN_RESULT.md` §8, Theorem 8.5 (tex Theorem 9.6 and Remark 9.7; PDF pdfTeX 12:36:06 UTC, 14 pages).
- `rq/CLAIMS.md` C17 (12:36; copy `audit/snapshots/RQ-B_CLAIMS_1236.md`) and `rq/AUDIT_REQUEST.md` §3 (copy
  `RQ-B_AUDIT_REQUEST_1236.md`).
- Data: `numerics/rid_slice_certs_22_25.json` (63b3b002…) and the robust variant `rid_slice_certs_177_200.json`
  (bf211417…, equal to `rid_slice_certs.json`).
- My copies: `audit/rqb/c17_text/` and `audit/rqb/c17_data/` (with `MD5SUMS`).
- The md diff against my 11:25 copy (`c16_text`) only adds Theorem 8.5, its consequences and the remarks. Lemma 8.1
  and Proposition 8.3 are unchanged.

### Rebuilt proof (from the hypotheses)

1. *Reduction.* Put C = 22/25 and A = 4/(3C) = 50/33, and suppose R = R_ID > C.
   - Lemma 8.1 and Proposition 8.3 (A.13a, VALID) give a probability maximiser K* with supp K* in
     [-2u/R, 2(1-u)/R], a subset of [-4/(3R), 4/(3R)], which lies inside (-A, A).
   - x -> -x maps Z to -Z and keeps E|Z|, so we may assume m1 = int x dK* >= 0.
   - |x| <= A and Jensen's inequality for the probability K* put (m1, m2) in D+ = {0 <= m1 <= A, m1^2 <= m2 <= A^2}.
   - So it suffices to prove E|Z_K| <= C for every probability K on [-A, A] with (m1, m2) in D+.
2. *Moments.*
   - For compact K, log E e^{tZ} = int (e^{tx} - 1 - tx) x^{-2} K(dx). So kappa_1 = 0, kappa_2 = K(R) = 1 and
     kappa_n = m_{n-2} for n >= 3; a Gaussian atom at 0 enters only kappa_2.
   - E Z^k is the sum over set partitions of {1..k} without singletons of the products of kappa_{|B|}.
   - A block of size b >= 5 (a free moment m_{b-2}) leaves at most 5 elements. Those form either blocks of sizes 2, 3
     and 4, with complements {}, {2}, {3}, {4}, {2,2} or {2,3} and factor 1, m1 or m2, or (only for k = 10) a second
     block of size 5. So the only product of free moments is kappa_5^2 = m3^2, in 10!/(2 * 5!^2) = 126 partitions.
   - Correct.
3. *Majorant.* phi >= |z| on R, and all moments are finite, so E|Z| <= E phi(Z) = sum_k c_k P_k(m).
4. *Range of m3.*
   - On [-A, A], (x - t)^2 (A - x) = -x^3 + (A + 2t) x^2 - (2tA + t^2) x + A t^2 >= 0 and
     (x - s)^2 (x + A) = x^3 + (A - 2s) x^2 + (s^2 - 2sA) x + A s^2 >= 0. Integrating against K (mass 1) gives the two
     bounds of the text.
   - Both bounds are affine in (m1, m2), so their extremes over Q are at the vertices.
   - (m3 - L)(m3 - U) <= 0, and the coefficient of m3^2 in E phi is 126 c_10 >= 0. Hence E phi <= Atilde + int g dK,
     with L and U constants of the cell.
   - Correct.
5. *Dual.* g(x; .) is affine in (m1, m2), so the inequality at the 4 vertices holds on all of Q. Integrating against K
   gives int g dK <= y0 + y1 m1 + y2 m2. Correct.
6. *Conclusion.* F <= C on every cell, and the cells cover D+, so E|Z_K| <= C. This contradicts R > C.
7. *Corollaries.*
   - Theorem 3 holds for q in (0, 1/2], and Theorem 4 gives the limit; delta_sqrt2 gives sqrt(2/e).
   - With s = ln(1/(1-q)), B(q)^2 = c^2 (e^s - 1)/s is increasing. B(1/2) = 0.88/sqrt(ln 2) = 1.057 > 1, so "for
     all q" in CLAIMS is also true.
   - B/M = (c/2) min_k h(ks) with h(x) = e^x/sqrt(x). h is log-convex, so on each range of one optimal k the ratio
     is convex in s. Its supremum over (0, 1/4] is therefore at a switch s_k = ln(1 + 1/k)/2 or at q = 1/4. The
     largest is at k = 2, q = 1 - sqrt(2/3): (c/2)(3/2)/sqrt(ln(3/2)) = 1.0364950.
   - Correct.

### Independent verification

Scripts (my code, no RQ-B code): `audit/rqb/a19_c17_verify.py`, outputs `outputs/a19_c17_verify_22_25.txt` (73 s,
mostly part Q) and `_177_200.txt`.

| check | result |
|-------|--------|
| E Z^k (k <= 10) as polynomials in m1..m8: moment-cumulant recursion against the integer-partition count; kappa_n = int x^{n-2} dK from the Levy–Khintchine exponent (sympy); E Z^k of a Poisson law (three Diracs, 50 digits) | identical; error 5e-46 |
| every free-moment coefficient is affine in (m1, m2); the only other term is 126 m3^2 in E Z^10 | holds |
| (i) c_10 >= 0; phi - z > 0 on [0, oo) and phi + z > 0 on (-oo, 0], by Arb root isolation and, separately, by my own Sturm sequences over Fractions | 142/142 by both methods |
| (ii) L and U recomputed from my derivation; L <= U | 142/142 |
| (iii) the dual is > 0 on [-A, A] at all 4 vertices, by both methods | 142/142 by both methods |
| (iv) max_Q F <= C by exact Bernstein bounds (no subdivision needed) | 142/142 |
| the centred-Taylor bound of the text, recomputed, against the file's "bound" | equal in 142/142 (worst 0.8799741) |
| cover of D+ (exact strip sweep); overlaps; cells needed | covered; no overlaps; 139/142 needed (see f2) |
| A = 50/33 = 4/(3C) | holds |
| the 177/200 file (A = 800/531) | all pass; worst max F 0.8791189 < 0.885, so it proves R_ID <= 0.885 |
| corollaries (mpmath interval arithmetic, 60 digits) | q* = 0.388146394 (certified sign change); B(0.1) <= 0.9036962, B(0.2) <= 0.9314521, B(1/4) <= 0.9472522; sup B/M = 1.03649495 at q = 1 - sqrt(2/3); limit 0.88 sqrt(e/2) = 1.0259234 |

The real margin in (iv) is larger than stated. The worst Bernstein bound, 0.8791945 in cell 127, equals the value of
F at a vertex there, so it is the exact maximum of F over all cells: the margin is 8.1e-4, not RQ-B's 2.6e-5 (which
is the Taylor bound's). The majorants and duals are LP-tight (min(phi - |z|) >= 4.6e-7, dual slack >= 1.4e-6), but
every check is exact, so this does not matter.

### Negative, calibrated and semantic tests

- `audit/rqb/a19b_c17_negative.py` (output `outputs/a19b_c17_negative.txt`), all 142 cells; every case behaves as
  expected:
  - c_0 - 2 gap is rejected 142/142 and c_0 - gap/2 accepted 142/142, by both methods;
  - the leading coefficient negated is rejected 142/142;
  - y0 - 2 slack is rejected 142/142 and y0 - slack/2 accepted 142/142;
  - C = (exact max F) - 1e-9 is rejected in the worst cell by Bernstein and by Taylor; C just below the worst Taylor
    bound is rejected by Taylor only;
  - lowering any cell's top edge by 1e-6 breaks the cover (127/127 testable cells);
  - A - 1/1000 violates A >= 4/(3C).
- `audit/rqb/a19c_c17_semantic.py` (output `outputs/a19c_c17_semantic.txt`, 12 s):
  - Setup: 816 Kolmogorov measures with rational atoms and weights (417 aimed at the cells, 399 random, with and
    without a Gaussian part). All their moments, E phi, L, U, int g dK and F are exact rationals; only E|Z| is
    computed by Poisson enumeration (pruned mass <= 7e-15).
  - Coverage: 139/142 cells were hit. The 3 missed cells are those of f2, which meet D+ in one point.
  - No violation: E phi - E|Z| >= 5.5e-3; m3 - L >= 2.8e-2; U - m3 >= 4.0e-2; chord side - E phi >= 0;
    quadratic - int g >= 6.9e-6; C - F >= 1.5e-3.
  - The moment formulas agree with the law (Gaussian part included, 40 digits) to 4e-30.
- **Attack.** 120 Nelder–Mead runs maximised E|Z_K| over a Gaussian part plus 1–3 atoms in [-A, A]. The maximum is
  0.85776388 = sqrt(2/e), at K = delta_sqrt2, far below 0.88. Nothing exceeds sqrt(2/e), consistent with C5.

### Fixes (text only; the mathematics and the computer steps are correct)

- **f1** (CLAIMS C17, line 178): "This is < 1 for q < 0.38815" is false on (0.3881464, 0.38815); for example
  B(0.38815) = 1.0000016. It should read "q < 0.38814", or "q < q* = 0.388146". MAIN_RESULT (0.3881) and STATUS
  (0.388) are correct.
- **f2** (md *Tests* paragraph; tex "Dropping any one cell breaks the tiling"): this is false for cells 48, 93 and
  126 (0-based order of the file). Each has b2 = a1^2 exactly, so it meets D+ only in its corner (a1, a1^2), which
  the cell above also covers. RQ-B's test sampled only 10 drops. It should read "dropping any one of 139 cells breaks
  the tiling; the other 3 meet D+ in a single point".
- **f3** (nit; md line 341, tex line 513): "the supremum of the ratio ... is 1.03650" should be "1.03649" (it is
  1.0364950). "Within 3.65%" is correct.

The PDF carries all 186 numbers and all 467 words of six or more letters of the LaTeX source (`audit/pdf_vs_tex.py`,
output `outputs/a19_pdf_vs_tex.txt`).

### Novelty

**NEW.** No earlier explicit bound below 1 on sup E|X|/||X||_2 over centred infinitely divisible laws was found
(searches of 2026-10-22).
- Marcus and Rosiński (Electron. Comm. Probab. 6, 2001) bound E|X| between 0.25 l(Q) and 2.125 l(Q), where l(Q) is a
  functional of the Lévy measure; that is a different normalisation.
- arXiv:2310.03471 is about P(|X - EX| <= sd). A search-engine summary attributed "E|X| <= sqrt(2/e) sd for all ID
  X" to it, but the paper contains no such statement, so I discarded the summary.
- The result improves this project's A.13b (0.9161). For small q the literature has R(q) <= 1 - O(q^3)
  (Ivanisvili–Stone, Cor. 2).
- The gap is now sqrt(2/e) = 0.85776 <= R_ID <= 0.88; R_ID = sqrt(2/e) is C5 and stays open.

---

## A.20 RQ-A MAIN-5, parts marked PROVED (k = 4 three- and four-bit lemmas, OR-region identity) — VALID, KNOWN within the project (2026-10-22 13:22 UTC)

### Claim

RQ-A's CLAIMS.md (12:57, 7bfacf8e…, copy `audit/snapshots/RQ-A_CLAIMS_1257.md`) lists MAIN-5 (Theorem 5: R(q) = T4 =
4 (1-q)^3 tau on [q5, q4] = [1 - 2/sqrt5, 1 - sqrt3/2] = [0.105573, 0.133975]) as CONDITIONAL on a computer cover
that is still running. Its "already PROVED parts" are three lemmas of `MAIN_RESULT_K4.tex` (draft; copies
`audit/rqa/k4_text/` of 12:57 and `audit/rqa/k4_text_1319/` of 13:17, where these lemmas are word for word the same).
Notation: G_n(c) = E|c . chi|, x_i = 1{chi_i = u}, Delta_i(f) = E[f | x_i = 1] - E[f | x_i = 0], and
OR_S = 2 * 1{some x_i = 1, i in S} - 1.
- **lem:or (OR-region identity).** If c_i > 0 and c_i > q sum_l c_l for every i, then
  G_n(c) = 2 tau (1-q)^(n-1) sum_i c_i <= 2 sqrt(n) (1-q)^(n-1) tau |c|. For n = 5 and q >= q5, G_5(c) <= T5 |c| <= T4 |c|,
  and G_5(c) = T4 |c| iff q = q5 and c_1 = ... = c_5.
- **lem:three.** For q in [q5, q4] and c in R^3, G_3(c) <= T4 |c|. For c != 0 equality holds iff q = q4 and c is a
  positive multiple of +-(1,1,1).
- **lem:four.** For q in [q5, q4] and c in R^4, G_4(c) <= T4 |c|. For c != 0 equality holds iff c is a positive
  multiple of +-(1,1,1,1), or q = q4 and c is a positive multiple of +-(e_i+e_j+e_k).
- They rest on the finite claims (C1)/(C2): H_f = 16 (1-q)^6 - sum_i Delta_i(f)^2 >= 0 on [q5, q4] for all 2^8 and
  2^16 Boolean f, with these zero sets:
  - H_f == 0 only for +-OR_[4];
  - H_f(q4) = 0, with H_f not identically 0, only for +-OR_[3] (n = 3) and the eight +-OR_S, |S| = 3 (n = 4);
  - every other H_f is > 0 on the closed interval.

Theorem 5 itself is not audited here: it is not claimed and not filed, and the computer section still has
placeholders.

### Rebuilt proof (from the hypotheses)

1. *Level-one form.* For f a function of the bits, E[f chi_i] = qu E[f | x_i = 1] - (1-q)v E[f | x_i = 0] =
   tau Delta_i(f), because qu = (1-q)v = tau.
   - Delta_i(f) = sum over x with x_i = 1 of (f(x) - f(x - e_i)) prod_{l != i} q^{x_l} (1-q)^{1-x_l}, an integer
     polynomial of degree <= n-1.
   - For i in S, E[OR_S | x_i = 1] = 1 and E[OR_S | x_i = 0] = 1 - 2(1-q)^{|S|-1}. So
     Delta_i(OR_S) = 2(1-q)^{|S|-1} on S, and 0 off S.
   - Correct.
2. *lem:or.* Let S = sum c_l chi_l.
   - If all x_l = 0, then S = -v sum c < 0.
   - If x_i = 1, every other l with x_l = 1 contributes c_l u > -c_l v (this needs c_l > 0), so
     S >= c_i (u + v) - v sum c = (v/q)(c_i - q sum c) > 0, by u + v = (1 + u^2)/u = v/q.
   - Hence |S| = OR_[n] S, and G_n(c) = sum_i c_i E[OR chi_i] = 2 tau (1-q)^(n-1) sum c.
   - Cauchy–Schwarz gives the bound, with equality iff the c_i are equal. T5/T4 = (sqrt5/2)(1-q) <= 1 iff q >= q5.
     The equality point c = (1, ..., 1), q = q5 lies in the region, since 5 q5 = 0.528 < 1.
   - The hypothesis c_i > 0 is needed: c_i > q sum c alone allows negative c_i when sum c < 0.
   - Correct.
3. *lem:three, lem:four.* Put f* = sgn X (sgn 0 = 1), a +-1 function of the bits.
   - G_n(c) = E[f* X] = tau c . Delta(f*) <= tau |c| |Delta(f*)|, and H_{f*} >= 0 gives G_n(c) <= T4 |c|.
   - Equality with c != 0: G_n(c) > 0, since Var(c . chi) = |c|^2 > 0. So Delta(f*) != 0, c = lambda Delta(f*) with
     lambda > 0, and H_{f*}(q) = 0. By (C1)/(C2) and step 1, these are exactly the listed vectors.
   - Conversely, (1,1,1,1) gives T4 because q <= q4 < 1/4: lem:kvec, where a sum of k bits is positive iff some bit
     equals u, as u^2 > k - 1 iff q < 1/k. And (1,1,1) gives T3, which equals T4 at q4.
   - Correct.
4. *How (C1)/(C2) are decided.*
   - g4 = 4q^2 - 8q + 1 (roots 1 +- sqrt3/2) and g5 = 5q^2 - 10q + 1 (roots 1 +- 2/sqrt5) are decreasing on [0, 1].
     g4 is irreducible over Q (discriminant 48), so H_f(q4) = 0 iff g4 | H_f.
   - If H_f = g4 Q with Q > 0 on [q5-, q4+], then H_f > 0 on [q5, q4) and H_f(q4) = 0, because g4 > 0 on [0, q4).
   - If g4 does not divide H_f and H_f has no root in [q5-, q4+] and is positive at one point, then H_f > 0 on
     [q5, q4].
   - The text's form H_f = g4 Q with Q root-free presupposes that g4 divides H_f only once. That is so: the
     multiplicity is 1 for all 10 such f.
   - Correct.
5. *Elementary parts of Theorem 5 (checked as well, not claimed).* These are unconditional.
   - Part (c): R >= T5 > T4 on (0, q5) (q5 < 1/5); R >= T3 > T4 on (q4, 1/3); R >= 2 tau > T4 on [1/3, 1/2], since
     2(1-q)^3 < 1 iff q > 1 - 2^{-1/3} = 0.2063.
   - lem:kvec (i)–(iii) and the constants: U_- = 1589/625 <= u4, with gap 6.0e-5; U_+ = 29107/10000 >= u5, with
     gap 6.6e-6; (T8 + 1)^2 >= 2; w_-^4 >= 1/2 and 2 w_-^3 >= 1.
   - T4(u) = 4u^7/(1+u^2)^4, with derivative u^6 (7 - u^2)/(1+u^2)^5.
   - The comparisons in Corollary cor:combined.
   - All correct (`a20c_k4_constants.py`). One nit for the later MAIN-5 audit: the text says w_- ≈ 0.866025, but
     w_- = 0.866020. The value 0.866025 is sqrt3/2; the inequalities hold with room to spare.

### Independent verification (RQ-AUD code only)

`audit/rqa/a20_k4_bits.py` (output `outputs/a20_k4_bits.txt`, 2 s) and `a20b_k4_tests.py` (`outputs/a20b_k4_tests.txt`,
44 s). I read RQ-A's `outputs/bitlemma_k4.txt` (e2571f3b…) only to compare counts. I did not use their scripts.
The Delta polynomials come from a vectorised integer computation over truth tables, a route different from my A.18
code. Positivity is proved twice: by Arb root isolation (my A.6 routine) and by my own Sturm sequences over
Fractions (my A.19 routine).

| check | result |
|-------|--------|
| Delta_i(f) as integer polynomials against the definition E[f \| x_i = 1] - E[f \| x_i = 0], by exact enumeration at q = 1/8, 3/25, 2/15 (all 256 f for n = 3; 4,000 f including every OR function for n = 4) | 48,972 comparisons, all equal |
| number of distinct H_f | 39 (n = 3) and 1,630 (n = 4), as stated |
| H_f == 0 | n = 3: none; n = 4: exactly +-OR_[4] |
| g4 \| H_f, H_f not identically 0 (equivalently H_f(q4) = 0) | n = 3: exactly +-OR_[3]; n = 4: exactly the 8 functions +-OR_S, \|S\| = 3; multiplicity 1 in all 10 cases |
| Q = H_f / g4^m > 0 on [q5-, q4+], which contains [q5, q4] (q5- = 1 - sqrt_hi(4/5), q4+ = 1 - sqrt_lo(3/4), integer square roots at 10^-15) | 0 failures by Arb and 0 by Sturm, for n = 3 and n = 4 |
| g5 \| H_f (some H_f vanishing at q5) | never |
| float margins, for information | min of H_f over the f with g4 not dividing H_f: 0.3192 (n = 3) and 0.0269 (n = 4); min of the cofactor: 2.25 = 4(1-q4+)^4 |
| Delta(OR_S) = 2(1-q)^{\|S\|-1} on S and 0 off S, as polynomials | all S with \|S\| = 3, 4 |
| level-one duality G_n(c) = tau max_f c . Delta(f), exactly at rational u (q and tau are then rational) | 72 random (u, c), n = 3, 4: all equal |
| OR-region identity, exactly at rational u in [2, 3.5], n = 1..7, by enumeration of the 2^n atoms | 345/345 inside the region. Outside it the formula fails 55/55, as it must: the atom with only x_i = 1, where c_i < q sum c, has S < 0 |
| T5/T4 = (sqrt5/2)(1-q), equal to 1 only at q5 (sympy) | True |

### Semantic, adversarial and negative tests

- **Exact semantic test.** The u values 2.543, 2.6, 2.7, 2.8 and 2.910 lie in [u4, u5]; this is checked with
  rational bounds for sqrt3 and sqrt5. There T4 = 4u^7/(1+u^2)^4 is rational, so G_n(c)^2 <= T4^2 |c|^2 can be checked
  exactly.
  - 2,405 vectors were tested, n = 3, 4: random ones and perturbations of (1,1,1), (1,1,1,1) and (1,1,1,0).
  - There is no violation. Equality holds only at c = (1,1,1,1), once per u.
- **Adversarial search** (floating point; Nelder–Mead, 150 starts per case): max of G_n(c)/(T4 |c|) at q5, at
  (q5+q4)/2 and at q4.
  - n = 3: 0.96825, 0.98387 and 1, always at (1,1,1)/sqrt3.
  - n = 4: 1 at (1,1,1,1)/2, at all three q.
  - n = 5: 1, at (1,1,1,1,1)/sqrt5 (q5), (1,1,1,1,0)/2 (midpoint) and (1,1,1,0,0)/sqrt3 (q4).
  - These are exactly the extremisers of Theorem 5(b) with n <= 5.
- **Endpoints are sharp, as the text's remark says.**
  - Just above q4, G_3(1,1,1)/(sqrt3 T4) = 1.000115 at q4 + 1e-4 and 1.00000012 at q4 + 1e-7.
  - Just below q5, G_5(1,...,1)/(sqrt5 T4) = 1.000112 at q5 - 1e-4 and 1.00000011 at q5 - 1e-7.
- **Negative tests.** My checker rejects every corruption:
  - On [q5, q4 + 1/1000], H_f > 0 fails for 2 f (n = 3) and 8 f (n = 4); these are the OR functions of size 3.
  - With 16 - 1e-6 in place of 16, it fails for 2 f (n = 3) and 10 f (n = 4).
  - With the k = 3 target 12(1-q)^4 in place of 16(1-q)^6, it fails for 2 f (n = 3) and 68 f (n = 4).
- **For information:** H_f >= 0 also holds on [0, q5], for every f with n = 3, 4 (Sturm, after dividing by the power of
  q at 0). So the lower end q5 enters the k = 4 proof only through the n = 5 bound of lem:or, as RQ-A's remark says.

### Text check

The statements, the proofs, (eq:level1), (eq:DeltaOR) and the paragraph "How the claims are checked" agree with my
reconstruction. RQ-A's `outputs/bitlemma_k4.txt` has the same counts: 39 and 1,630 distinct H_f, H_f identically 0 for
2 f, and H_f(q4) = 0 for 8 more f. No fix needed.

### Novelty

**KNOWN within the project; no literature source.**
- The inequalities and equality cases of lem:three and lem:four are the cases n = 3, 4 of RQ-C's C6 (A.5,
  VALID, NEW): R_n(q) = 2 tau sqrt(max_{k<=n} k(1-q)^{2k-2}). On [q5, q4] this gives R_3 = T3 <= T4 (equality at q4)
  and R_4 = R_5 = T4.
- The same formula with n = 5 covers the consequence G_5 <= T4 |c| of lem:or.
- The OR-region identity is RQ-B's C3 (A.7c, 06:59). Its hypothesis q sum alpha <= min alpha is the non-strict
  version, and its value 2 mu (1-q)^n / tau equals 2 tau (1-q)^(n-1) sum c.
- RQ-A's proofs are independent of both. The bit lemmas prove the stronger statement H_f >= 0 for every Boolean f,
  not only for threshold functions.
- The equal-coefficient case is the classical value of E|chi_1 + ... + chi_k| (Stone, Thm 4.3.1).

---

## A.21 RQ-C C13: R = max(S_3, S_4) on q in [2500/19661, 2500/18629] — VALID WITH FIXES (text only), NEW (2026-10-22 14:29 UTC); VALID after the fix (15:31 UTC)

### Claim

The source is RQ-C's CLAIMS.md (14:00, e3318c23…) and Theorem 1 of `MAIN_RESULT_K4.tex/.pdf` (237f5806… / f0b4cffb…,
the 8-page PDF built at 13:49). Copies are in `audit/rqc/k4_text_1400/`.
- For u = sqrt((1-q)/q) in [127/50, 131/50], i.e. q in [2500/19661, 2500/18629] = [0.127155, 0.134199], and every
  unit alpha: E|sum alpha_i chi_i| <= T = max(S_3, S_4), with S_3 = 2 sqrt3 u^5/(1+u^2)^3 and S_4 = 4u^7/(1+u^2)^4.
- Equality holds at (1,1,1,1)/2 for q <= q4 = 1 - sqrt3/2 and at (1,1,1)/sqrt3 for q >= q4.
- So R = S_4 on [2500/19661, q4] and R = S_3 on [q4, 2500/18629].
- Corollary, with A.6, A.11, A.14 and A.18: R(q) = 2 tau max_k sqrt(k) qh^(k-1) on [2500/19661, 17161/19661].

The claim says nothing about uniqueness of extremisers, and I rate nothing of the kind. The 13:20 draft covered only
the first slab, [127/50, 64/25]. The 14:00 version adds three slabs of width 1/50, made with the same programs, and
uses vertex-decoupled cells from slab 2 on.

### Rebuilt proof (from the hypotheses)

Notation: tau = u/(1+u^2) = sqrt(q(1-q)), v = 1/u, rho = u + v. Each chi takes the value u with probability q and
-v otherwise. S_k = 2 sqrt(k) (1-q)^(k-1) tau, which equals E|chi_1 + ... + chi_k|/sqrt(k) for q < 1/k.

1. *Lower bound and the corollary.*
   - S_k is the value at (1,...,1)/sqrt(k) when q < 1/k, because a sum of k bits is positive iff some bit equals u.
   - S_4 >= S_3 iff 2(1-q) >= sqrt3, i.e. iff q <= q4.
   - The four slabs [127/50, 64/25], [64/25, 129/50], [129/50, 13/5] and [13/5, 131/50] chain exactly. I checked this
     from the region fields of the files. The map u -> 1/(1+u^2) takes their union onto [2500/19661, 2500/18629].
   - The corollary follows from A.6, A.11, A.14 and A.18, which reach down to q4 = 0.133975 < 2500/18629, together
     with the mirror q -> 1-q.
   - Correct.
2. *Reduction and split.*
   - Sort |alpha_1| >= |alpha_2| >= ..., take alpha_1 >= 0, and write L = X + bM with j = 2 or 3.
   - M is a normalised sum with max|beta_i| <= a_j/b <= mbar, or a fresh bit if b = 0.
   - Then E|L| = E phi_{a,b}(M), where phi_{a,b}(y) = E|X + by| is convex in (a, b) for fixed y.
   - Correct.
3. *lem:lines.* phi_{a,b}(y) is the maximum, over monotone sign patterns sigma, of b S_sigma y + K_sigma.
   - This follows from |z| = max(z, -z). The maximising pattern sgn(x_e + by) is monotone, because x_e is monotone
     in e_i in the direction of s_i. There are 6 such patterns for j = 2 and 20 for j = 3.
   - My verifier enumerates the patterns itself. Semantic part L checks the identity exactly in 400 random cases.
   - Correct.
4. *lem:patch.*
   - Concavity of g(a) = sqrt(1 - |a|^2) gives the floor points.
   - The tangent plane at the centre c gives the ceiling points T_v = G+ + max(-d_v/G-, -d_v/G+), using
     1/g(c) in [1/G+, 1/G-].
   - The multilinear weights then put (a, g(a)) in the convex hull.
   - Correct. Semantic part P brackets g at 300 random points per slab.
5. *W2 (lem:mom with the folded bound).*
   - E P(M) = sum_k c_k G_k + sum_mu C_mu p_mu, where G_k = (k-1)!! for even k and 0 for odd k,
     C_mu = kappa_mu sum_k c_k N(k, mu), and p_mu is the product of the power sums p_j(beta).
   - For one block, C_(j) p_j = sum_i beta_i^2 C_(j) beta_i^(j-2). The sign rules for negative beta_i give Phi+ or
     Phi-.
   - For several blocks, p_3^2 <= p_4 and |p_j| <= mbar^(j-2) give |p_mu| <= sum_i beta_i^2 g_mu(beta_i). Hence
     sum_mu C_mu p_mu <= sum_i beta_i^2 Phi^±(|beta_i|) <= F when F > Phi^± on [0, mbar].
   - I re-derived the exponent bookkeeping. With two 3s the exponents are b = 2 and a = sum (j-2) over the other
     parts; otherwise b = j_1 - 2. I also re-derived the rule B_mu = max(0, C+) when every odd part occurs an even
     number of times, and B_mu = max|C^±| otherwise.
   - Correct.
6. *prop:cell and prop:dec.*
   - (a, b) lies in conv Pi: in box form trivially, in patch form by step 4.
   - For prop:dec, write (a, b) = sum_v lambda_v (a_v, b_v). Convexity and step 3 give
     phi_{a,b} <= sum_v lambda_v phi_{a_v,b_v} <= sum_v lambda_v P_v.
   - Hence E|L| <= max_v E P_v(M) < T- <= T. The same mbar serves every v, since mbar depends only on the cell.
     prop:cell is the case P_v = P.
   - T- uses the endpoint minima of S_3 (with sqrt3 rounded down) and of S_4. This is valid because both are
     unimodal in u, with log-derivatives ((2k-1) - u^2)/(u(1+u^2)).
   - Correct.
7. *lem:ns (near (1,1,1)/sqrt3).*
   - For an atom x > 0, |x + bm| = x + bm + 2(-x - bm)+ <= x + bm + 2 * 27 (bm-)^4/(256 x^3). This uses
     (Y - x)+ <= 27 Y^4/(256 x^3) for Y >= 0, whose maximum ratio is at Y = 4x/3. Atoms x < 0 are symmetric.
   - E(M+)^4 + E(M-)^4 = E M^4 = 3 + kappa_4 p_4 <= 3 + kappa_4 mbar^2, using kappa_4 > 0.
   - C6 with n = 3 (A.5) gives E|X| <= S_3 sqrt(1 - b^2) <= S_3 (1 - b^2/2).
   - Together, E|L| <= S_3 - b^2 (S_3/2 - K b^2) <= S_3.
   - Correct.
8. *lem:comp (near (1,1,1,1)/2).*
   - Under (K0) the positive atoms are ordered x_3 <= x_2 <= x_1 <= x_23 <= x_13 <= x_12 <= A_3 u. Then
     R(y) = phi(by) - l_0(by) is the maximum of 0, l_R and the seven prefix lines.
   - P = (y+v)^2 S(y-u) with s = l_R(u)/rho^2 and B_0 = (l_R' - 2 rho s)/rho^2. I re-derived the closed forms
     s = 2u^7(bu^2 - A_3)/(1+u^2)^5 and B_0 = 2u^8(2A_3 - b(u^2-1))/(1+u^2)^6, and the identity
     P - l_R = (y-u)^2 S_1.
   - (K1)–(K3) give P >= R. Together with P(-v) = 0 = R(-v) and P(u) = l_R(u) = R(u), this gives
     E P(chi) = E R(chi).
   - The L_mu/U_mu table follows from Cauchy–Schwarz (p_3^2 <= p_4, p_4^2 <= p_6, p_5^2 <= p_8) and |p_j| <= 1. I
     checked all four rows: (3,3), (3,4), (3,5) and (4,4).
   - (K4) gives E P(chi) - E P(M) = sum_i beta_i^2 (1 - beta_i) H(beta_i) >= 0.
   - E|X + b chi_4| <= R_4 = max_{k<=4} S_k by C6 with n = 4 (A.5).
   - Correct.
9. *Finitely many checks.*
   - S and S_1 are affine in (A_3, b), and P - l_A is affine in (a, b).
   - H is affine in (A_3, b) because only c_3 depends on the box:
     - s enters only c_0..c_2 and B_0 only c_0..c_3;
     - C_(3) is the only single-block C_mu that sees c_3;
     - the C_mu with two or more blocks involve only c_6..c_8.
   - The thresholds -e/d are linear-fractional with d > 0.
   - So the corners and vertices suffice.
   - On u-subintervals, the interpolation bound g >= min(endpoints) - (h^2/8) sum_k max|g_k''| |x|^k is correct, with
     max|g_k''| enclosed by second-order jets.
   - Correct.
10. *The cover and lem:closure.*
   - Phase 1 tiles [U_1, U_2] x [0,1]^2, for each sign s_2, with three kinds of boxes:
     - cells;
     - skipped boxes, with a_2- >= a_1+ or (a_1-)^2 + (a_2-)^2 >= 1, which meet D_2 in a null set;
     - split boxes, with s_2 = +1.
   - Phase 2 tiles B x [0, a_2+], for each split box B and each s_3, with near-sphere, comparison, three-coordinate
     cell and empty boxes.
   - **lem:closure is false as stated.** Take Q = [0,1]^2, D = [1,2] x [0,1] and the single box Q. Every hypothesis
     holds: D is the closure of its interior, and Q meets D only in a null set, so Q need not be certified. Yet the
     point (1, 0) of D ∩ Q lies in no certified box.
   - The proof's step "x_n -> x with x_n in int D ∩ int Q" needs x in cl(int D ∩ int Q). That holds when D ⊂ Q.
   - Both uses have D ⊂ Q:
     - phase 1: D = [U_1, U_2] x D_2, a subset of [U_1, U_2] x [0,1]^2;
     - phase 2: D = D_3 ∩ (B x [0, a_2+]). Every split box has (a_1+)^2 + (a_2+)^2 < 1 and a_2- > 0, checked in all
       four slabs. So D is the region under the continuous positive function min(a_2, sqrt(1 - a_1^2 - a_2^2)) over
       B, and that region is the closure of its interior.
   - So the proof of the theorem stands, but the lemma needs the hypothesis D ⊂ Q. This is fix f1.

### Independent verification (RQ-AUD code only)

`audit/rqc/a21_c13_verify.py` re-checks every record of the four data files. It works in exact Fractions and uses
flint/Arb, on 8 cores; the outputs are `audit/rqc/outputs/a21_c13_verify_<slab>.txt`. The snapshots of the data are in
`audit/rqc/k4_data/`, with the md5s stated in AUDIT_REQUEST. I did not use RQ-C's code. The cumulants come from my own
moments module, which is self-tested against direct enumeration. The lines, the Pi points, the W2 bounds, the
comparison conditions and the tilings are all recomputed from the boxes.

The checks, by part:
- **W1.** For every point of Pi (recomputed from the box), every monotone sigma and both u-endpoints:
  - the line coefficients are rounded outwards to the grid 2^-128;
  - they are widened by the u-interpolation bound, using jets of S_sigma and Z_sigma;
  - Arb root isolation of the integer polynomial then shows that P minus the line has no root on [0, oo), resp.
    on (-oo, 0]. Real roots come back with zero imaginary part, and the comparisons are certain.
  - The u-interval is bisected when a check fails. This was never needed.
- **W2.** The folded bound is checked exactly. kappa_j is enclosed by its endpoint values, which is valid because
  part M proves by Sturm sequences that kappa_3..kappa_10 are monotone on [127/50, 71/25].
- **Decoupled cells.** There must be exactly one certificate per point of my own Pi, matched by the exact key
  (a_v, b_v).
- **N.** Interval atoms, K (b+)^2 <= min S_3-/2, and kappa_4 > 0.
- **K.** (K0) on the box; (K1), (K2) and (K4) at the 4 corners; (K3) at the 16 vertices for each of the 7 prefixes;
  r_0 by the vertex minimum. All of this at exact rational u-endpoints, plus the interpolation bound.
- **T.** For each sign: containment, an exact volume sum and pairwise interior-disjointness. Also the skip and empty
  criteria, the split-box conditions, and the phase-2 tilings for each split box and s_3.

| slab (u) | md5 | phase-1 boxes (s2 = +1 / -1) | split boxes | phase-2 boxes | cells: total (two-coord. / three-coord.; decoupled) | near-sphere (max K (b+)^2/(S_3/2)) | comparison (degree 6) | empty | result |
|---|---|---|---|---|---|---|---|---|---|
| [127/50, 64/25] | 31d28bce… | 591 / 400 | 69 | 4,074 | 3,072 (454 / 2,618; 0) | 216 (0.9976) | 1,151 | 89 | ALL PASS (240 s) |
| [64/25, 129/50] | f65717c1… | 591 / 400 | 117 | 2,322 | 2,314 (410 / 1,904; 490) | 63 (0.9892) | 337 | 18 | ALL PASS (272 s) |
| [129/50, 13/5] | 5f780d44… | 593 / 400 | 123 | 2,399 | 2,408 (407 / 2,001; 493) | 46 (0.9755) | 345 | 7 | ALL PASS (264 s) |
| [13/5, 131/50] | 093afeb9… | 596 / 400 | 119 | 2,318 | 2,373 (413 / 1,960; 502) | 24 (0.9959) | 330 | 4 | ALL PASS (184 s) |

Totals and margins:
- 10,167 cells, of which 1,485 are vertex-decoupled; 349 near-sphere boxes; 2,163 comparison boxes.
- 11,181,568 Arb root isolations.
- No u-bisection was needed anywhere.
- The smallest W2 margin per slab: 3.3e-7, 6.7e-7, 4.1e-6 and 1.6e-6.
- Every count agrees with RQ-C's `k4_runs_table.tex` and the CLAIMS table.

**Second method.** `a21d_c13_sturm.py` replaces every Arb call by my own Sturm sequences over Fractions (the A.19
routine).
- Slab 1 is complete: 3,072/3,072 cells, with 3,438,208 half-line positivity proofs plus W2, and 1,151/1,151
  comparison boxes (940 s).
- Addendum (2026-10-22 15:02 UTC): slabs 2–4 are complete, and all pass (outputs
  `audit/rqc/outputs/a21d_c13_sturm_s12_<slab>.txt`):
  - [64/25, 129/50]: 2,314/2,314 cells (2,515,840 proofs) and 337/337 comparison boxes (493 s);
  - [129/50, 13/5]: 2,408/2,408 cells (2,639,424 proofs) and 345/345 comparison boxes (514 s);
  - [13/5, 131/50]: 2,373/2,373 cells (2,588,096 proofs) and 330/330 comparison boxes (537 s).
  - In all, 10,167 cells with 11,181,568 Sturm proofs (one for each Arb root isolation of the first method) and
    2,163 comparison boxes. So both methods confirm every computer step of C13.

### Negative, sharpness, semantic and adversarial tests

- **Negative tests** (`a21b_c13_negative.py`, on slabs 1 and 2). Every corruption is rejected:
  - Tilings: a cell deleted or duplicated, a cell relabelled as skipped, a phase-2 cell relabelled as empty, a
    phase-2 box deleted, and a split box with s_2 = -1.
  - Near-sphere boxes: a_3- = 0 is rejected for all of them (216 on slab 1, 63 on slab 2). a_1- - 1/20 is rejected
    for 201 and 38.
  - Comparison boxes (30 sampled): s_3 = -1, a broken (K0) and a negative leading coefficient t_(D-4) are each
    rejected 30/30. The scalings t_0 x 0.9 and x 1.1 are rejected for most boxes (18 to 20 of 30), each time by a
    named condition.
  - Decoupled cells (slab 2, 30 sampled): a certificate removed, one b_v moved by 1e-15, one c_0 lowered by 2^-7,
    and one F_v at the W2 threshold. Each is rejected 30/30, for the right reason.
  - Single-polynomial cells (40 sampled per slab): c_0 lowered by 1e-2 or by 2^-7 (all rejected by W1); F at the
    threshold and F < max Phi (all rejected by W2); the box widened (all rejected).
- **Sharpness.** I lowered c_0 until the certified W1 check failed (12 cells per slab). The certified threshold is
  99.8–100% of a dense float estimate of the W1 margin, and never above it. So the check is sound and loses almost
  nothing.
- **Semantic tests** (`a21c_c13_semantic.py`, all four slabs). All of these hold:
  - exact random checks of lem:lines and lem:patch;
  - the full chain on random configurations inside cells, E|L| <= sum_v w_v E P_v(M) <= sum c G + F_v < T, for 222
    to 265 configurations per slab, decoupled cells included;
  - near-sphere boxes, E|L| <= S_3, for 225 to 245 configurations per slab;
  - comparison boxes, 200 per slab: P >= R on a grid, P(-v) = 0, P(u) = l_R(u), and the chain to T.
  - The largest ratio to the bound in these tests is 0.99972.
- **Adversarial search.** Hill climbing over alpha with 4 to 9 coordinates, at five values of u in each slab, across
  [2.54, 2.62]. The maximum found is T itself: at (1,1,1)/sqrt3 for u = 2.54, and at (1,1,1,1)/2 elsewhere. It never
  exceeds T.

### Text check

The statement, the lemmas and the description of the cover agree with my reconstruction. The counts in the runs
table and in the CLAIMS table agree with mine.
- **f1 (lem:closure).** As stated, the lemma is false; the counterexample is in step 10. Either add "D ⊂ Q" to the
  hypotheses, which both applications satisfy, or start the proof from x in cl(int D ∩ int Q).
- No other fix is needed. The stale "awaiting audit" in the Corollary of the 13:20 draft is gone in the 14:00 text.

### Novelty

**NEW.** No literature source gives R(q) for any q < q4 = 0.133975. The lower bound 2 sqrt(k) (1-q)^(k-1) tau is
KNOWN (Stone, Thm 4.3.1). Within the project:
- [q4, 2500/18629] lies inside A.18 (RQ-A MAIN-4), so on that part C13 is a second, independent proof.
- R = S_4 on [2500/19661, q4] = [0.127155, 0.133975] is the first piece of the k = 4 regime with an exact value.
- That piece lies inside the range [q5, q4] of RQ-A's MAIN-5, which is still CONDITIONAL.

### Re-rated VALID (2026-10-22 15:31 UTC): fix f1 is posted

RQ-C posted f1 in the mirror of 15:08:58 UTC (commit 33ee0a1). The files are AUDIT_REQUEST.md (16cd3c21…; the
response is stamped 15:10), CLAIMS.md (087bff08…), MAIN_RESULT_K4.tex (093d3b68…) and MAIN_RESULT_K4.pdf (b040e7de…,
created 15:05:51 UTC, 9 pages). My copies are in `audit/rqc/k4_text_f1/`.
- **Lemma 11 (lem:closure)** now assumes D ⊂ Q. The proof starts from x in D and uses int D ⊂ int Q, which gives
  x_n -> x with x_n in int D ∩ int Q. Then:
  - some box B of the finite cover contains infinitely many x_n, so it contains x;
  - B = cl(int B) and B meets the open set int D, so int B ∩ int D is a nonempty open set;
  - so B meets D in positive measure and is certified.

  The lemma is now true as stated, and my counterexample (step 10) no longer satisfies the hypotheses.
- **The proof of Theorem 1** names D and Q in both uses, as in my step 10:
  - phase 1: D = [U_1, U_2] x D_2 ⊂ [U_1, U_2] x [0,1]^2, convex with nonempty interior;
  - phase 2: D = D_3 ∩ (B x [0, a_2+]) ⊂ B x [0, a_2+]. This is the region under the continuous function
    min(a_2, sqrt(1 - a_1^2 - a_2^2)) over B, which is positive because a_2- > 0 and (a_1+)^2 + (a_2+)^2 < 1.
- **The split-box conditions.** My verifier checks them in part T on all six slabs. My own
  `audit/rqc/a21e_splitbox_extremes.py` gives the exact extremes (output `outputs/a21e_splitbox_extremes.txt`):

  | slab | max (a_1+)^2 + (a_2+)^2 | min a_2- |
  |---|---|---|
  | 1 | 17/20 | 2/5 |
  | 2 | 19017/25600 = 0.7429 | 73/160 |
  | 3 | 461/640 = 0.7203 | 73/160 |
  | 4 | 3577/5120 = 0.6986 | 73/160 |
  | 5 | 17497/25600 = 0.6835 | 9/20 |
  | 6 | 17117/25600 = 0.6686 | 9/20 |

  Every split box has s_2 = +1. RQ-C's figures (0.85 and 2/5 overall; 0.683, 0.669 and 9/20 on slabs 5 and 6) agree.
- **Nothing else changed.** Against my 15:05 copy, the tex diff touches only the status paragraph, Lemma 11, the
  proof of Theorem 1 and the tiling paragraph of Section 4. The pdftotext of the PDF agrees with the tex in all three
  mathematical passages. The six data files still have the md5s of AUDIT_REQUEST.
- **Remark (not a fix): the stamps disagree.**
  - The tex, CLAIMS and AUDIT_REQUEST date the fix "15:10 UTC" and the PDF says "15:20 UTC".
  - Both are later than the files themselves: the PDF was created at 15:05:51, the tex has mtime 15:06:53, and the
    mirror ran at 15:08:58.
  - So the PDF was built from an earlier draft of the status paragraph.
  - RQ-C should rebuild the PDF from the posted tex and take its stamps from `date -u`.

So the posted text is the audited proof with f1 applied. **Verdict: VALID** for u in [127/50, 131/50]. The extension to
u <= 133/50 is A.21b, below.

---

## A.21b RQ-C C13 extension to u <= 133/50 (slabs 5 and 6) — VALID, NEW (2026-10-22 15:47 UTC)

### Claim

RQ-C filed an addendum to the C13 request at 15:00 UTC. The sources are:
- AUDIT_REQUEST.md: 0163d3cf… at 15:04 and 16cd3c21… at 15:06;
- CLAIMS C13: 915cd6c7… and 087bff08…;
- MAIN_RESULT_K4.tex/.pdf: 67aeb578…/880981f8… of 15:04, and with f1 093d3b68…/b040e7de…;
- my copies: `audit/rqc/k4_text_1505/` and `k4_text_f1/`.

Theorem 1 of MAIN_RESULT_K4 now covers u in [127/50, 133/50]. The new part is u in [131/50, 133/50], i.e.
q in [2500/20189, 2500/19661] = [0.123830, 0.127155]. It comes in two slabs:
- [131/50, 66/25]: `s13_2620_2640.json`, md5 acd0e21e…;
- [66/25, 133/50]: `s13_2640_2660.json`, md5 dc4f88a1… (both md5s as in AUDIT_REQUEST).

On this part E|sum alpha_i chi_i| <= T = S_4 for every unit alpha, with equality at (1,1,1,1)/2, since q < q4
throughout. With A.21:
- R = S_4 = 4 (1-q)^3 sqrt(q(1-q)) on [2500/20189, q4] = [0.123830, 0.133975];
- R = S_3 on [q4, 2500/18629].
- Corollary (with A.6, A.11, A.14, A.18): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), on
  [2500/20189, 17689/20189] = [0.123830, 0.876170].

### What is new compared with A.21, rebuilt

The theorem, the lemmas, the cover and the proof of Theorem 1 (with f1) are unchanged. The generator `k4_drive13.py`
adds degree-8 comparison boxes (`k4_comp8.py`) where the degree-6 box fails. Slab 6 has 21 of them; slab 5 has none.
What changes in Lemma 10 (lem:comp) at D = 8:
1. *Shape.*
   - S(z) = s + B_0 z + z^2 T(z), with deg T = 4 and t_4 > 0 by (K4). So S has even degree 6, and (K1) S > 0 on R is
     a sensible condition.
   - P = (y+v)^2 S(y-u) has degree 8. s and B_0 are defined exactly as for D = 6, and (K2), (K3) are unchanged.
   - Correct.
2. *Multisets.* The cumulant blocks have size >= 3. With |mu| <= 8, the multisets with two or more blocks are
   (3,3), (3,4), (3,5) and (4,4); (3,3,3) already has size 9. So the table lists all of them. Correct.
3. *The table.* Write p_j = sum beta_i^j, so p_2 = 1, |beta_i| <= 1, and hence |p_j| <= 1 and 1 - p_j >= 0 for j >= 2.
   - Cauchy–Schwarz gives p_3^2 <= p_2 p_4 = p_4, p_4^2 <= p_6 and p_5^2 <= p_8.
   - So 1 - p_3^2 >= 1 - p_4 and 1 - p_4^2 >= 1 - p_6.
   - p_3 p_4 <= (p_3^2 + p_4^2)/2 <= (p_4 + p_6)/2, and p_3 p_5 <= (p_4 + p_8)/2.
   - Upper bounds: 1 - p_3^2 <= 2(1 - p_3) and 1 - p_4^2 <= 2(1 - p_4); 1 - p_3 p_4 = (1 - p_4) + p_4(1 - p_3) <=
     (1 - p_4) + (1 - p_3); and 1 - p_3 p_5 = (1 - p_5) + p_5(1 - p_3) <= (1 - p_5) + (1 - p_3), also when p_5 < 0.
   - Each 1 - p_j = sum_i beta_i^2 (1 - beta_i) e_j(beta_i), with e_j >= 0 on [-1, 1].
   - These are the rows of the text. Correct.
4. *The mixed-sign rule.* For C with C >= -Cbar and Cbar >= 0, and L <= x <= U: C x >= C L - Cbar (U - L).
   - If C >= 0, then C(x - L) >= 0.
   - If C < 0, then C(x - L) >= C(U - L) >= -Cbar(U - L).

   Correct. My verifier takes Cbar = max(0, -inf C_mu) over each u-subinterval.
5. *Corners still suffice.*
   - s and B_0 enter only c_0..c_3.
   - The C_mu with two or more blocks involve only c_6, c_7 and c_8 (N(k, mu) = 0 for k < |mu|), and these do not
     depend on (A_3, b).
   - So the case decision is the same at all four corners, and H stays affine in (A_3, b).

   Correct.

**A gap in my own verifier, closed.** Its record-kind filters accepted only `comp3`. With them, a `comp8` record would
have failed the kind check of part T and been skipped by part K. The routine that checks a comparison box was already
degree-generic, which is what RQ-C's addendum ("your part K already covers degree 8") refers to.
- The filters now use the map {comp3: 6, comp8: 8}, and a record must carry deg P - 3 coefficients t. All four
  scripts are fixed.
- A rerun of parts T and K on slab 2 is unchanged: 337/337, kinds OK (`outputs/a21_c13_regress_TK_s12_2560_2580.txt`).

### Independent verification (RQ-AUD code only; outputs `audit/rqc/outputs/*_s13_*.txt`)

| slab (u) | md5 | phase-1 boxes (s2 = +1 / -1) | split boxes | phase-2 boxes | cells: total (two-coord. / three-coord.; decoupled) | near-sphere (max K (b+)^2/(S_3/2)) | comparison (degree 6 / 8) | empty | result |
|---|---|---|---|---|---|---|---|---|---|
| [131/50, 66/25] | acd0e21e… | 600 / 400 | 132 | 2,557 | 2,621 (403 / 2,218; 564) | 19 (0.9810) | 320 / 0 | 0 | ALL PASS (176 s) |
| [66/25, 133/50] | dc4f88a1… | 595 / 400 | 129 | 2,738 | 2,794 (401 / 2,393; 775) | 6 (0.9863) | 318 / 21 | 0 | ALL PASS (187 s) |

Totals and margins:
- 5,415 cells, of which 1,339 are vertex-decoupled; 25 near-sphere boxes; 659 comparison boxes (638 of degree 6 and
  21 of degree 8).
- 6,056,448 Arb root isolations.
- The smallest W2 margin is 9.7e-7 on slab 5 and 1.75e-8 on slab 6. The second is thin, but the check is exact.
- No cell needed a u-bisection. All 21 degree-8 boxes did: 20 at depth 1 and one at depth 2. Then they pass. RQ-C's
  verifier always splits u into 4 and 8 subintervals.
- Every count agrees with RQ-C's `k4_runs_table.tex` (1c1f50c5…) and with the addendum.

**Second method.** `a21d_c13_sturm.py` replaces every Arb call by my own Sturm sequences over Fractions.
- Slab 5: 2,621/2,621 cells (2,916,416 proofs) and 320/320 comparison boxes (599 s).
- Slab 6: 2,794/2,794 cells (3,140,032 proofs) and 339/339 comparison boxes, including all 21 of degree 8 (654 s).
- **STURM RECHECK PASS** on both.

**Negative tests** (`a21b_c13_negative.py`). Every required corruption is rejected:
- Tilings: all six corruptions, on both slabs.
- Near-sphere boxes: a_3- = 0 is rejected 19/19 and 6/6, and a_1- - 1/20 also 19/19 and 6/6.
- Comparison boxes: 30 of degree 6 on slab 5; on slab 6, 30 of degree 6 plus all 21 of degree 8.
  - s_3 = -1, a broken (K0) and a negated leading coefficient are rejected 30/30 and 51/51.
  - t_0 x 0.9 is rejected 26/30 and 41/51, and t_0 x 1.1 26/30 and 43/51, each time by a named condition.
- Decoupled cells (30 per slab) and single-polynomial cells (40 per slab): every corruption is rejected for the right
  reason.
- Sharpness: the certified c_0 thresholds are 99.8–100% of the float W1 margin and never above it.

**Semantic tests** (`a21c_c13_semantic.py`). All of these hold:
- exact lem:lines (400 per slab) and lem:patch (300 per slab);
- the cell chain on 202 and 212 random configurations (max E|L|/T = 0.9943 and 0.9821);
- near-sphere boxes on 260 and 267 configurations (max E|L|/S_3 = 0.9991 and 0.9944);
- comparison boxes on 200 configurations per slab, among them 100 inside degree-8 boxes, where the chain holds
  100/100 (max E|L|/T = 0.9882).
- **New exact test of (K4) at degrees 6 and 8 (part U)**, 2,000 per slab:
  - inputs: rational unit beta (stereographic) with n = 1..5; P either from comparison records at random rational
    (u, A_3, b) (on slab 6, 64 of them from degree-8 records) or a random rational P of degree 8;
  - checked exactly: the identity E P(chi) - E P(M) = sum_mu C_mu (1 - p_mu), by exact enumeration; the table
    L <= 1 - p_mu <= U; and E P(chi) - E P(M) >= sum beta_i^2 (1 - beta_i) H(beta_i);
  - all pass, and every two-block mu occurs;
  - the smallest slack over beta with at least two nonzero coordinates is positive in every row (2.9e-9 for the
    H bound at record P). One nonzero coordinate gives equality, as it should.
- Adversarial search: hill climbing at five values of u per slab finds T itself, at (1,1,1,1)/2, and never more.

### Text check

The addendum changes the abstract, the status paragraph, Theorem 1, the corollary range, the runs table and the data
list. All of them agree with my reconstruction.
- The corollary range is the union of [2500/20189, 2500/18629] with A.6, A.11, A.14 and A.18 ([q4, 1 - q4]), and the
  mirror images.
- The sentence "the degree-6 LP at the 4-point loses its margin near u = 2.74, and degree 8 near u = 2.85" is about
  the generator beyond the claimed range. It is not part of the claim.
- The only text fix of C13, f1, is posted (see the A.21 re-rating).
- The stamp mismatch between the PDF and the tex is the remark there, not a fix.

**Verdict: VALID** (no fix needed). With A.21, C13 is VALID on the whole of u in [127/50, 133/50].

### Novelty

**NEW.**
- R = S_4 on [0.123830, 0.133975] is the largest piece of the k = 4 regime [q5, q4] = [0.105573, 0.133975] with an
  exact value, about 36% of its length (A.21 alone covered 24%). It extends A.21's [0.127155, q4].
- It lies inside the range of RQ-A's MAIN-5, which is still CONDITIONAL.
- The lower bound is KNOWN (Stone, Thm 4.3.1).

---

## A.22 RQ-A MAIN-6, parts marked PROVED (k = 5 three- and four-bit lemmas) — VALID, KNOWN within the project (2026-10-22 14:29 UTC)

### Claim

RQ-A's CLAIMS.md (copy `audit/snapshots/RQ-A_CLAIMS_1411.md`, 2a36088d…) and STATUS.md (13:58, copy
`RQ-A_STATUS_1411.md`) state MAIN-6 as a CONJECTURE: R = T5 = 2 sqrt5 (1-q)^4 tau on
[q6, q5] = [1 - sqrt(5/6), 1 - 2/sqrt5] = [0.087129, 0.105573]. Its "already PROVED parts" are:
- For n = 3, 4, every f: {0,1}^n -> {-1,1} and every q in [q6, q5]: sum_i Delta_i(f)^2 <= 20 (1-q)^8. The inequality
  is strict for n = 3. For n = 4, equality holds only for +-OR_4 at q5, where H_OR4 = 4 (1-q)^6 g5 and
  g5 = 5q^2 - 10q + 1.
- Hence E|c . chi| <= T5 |c| for c in R^3 and R^4.
- The n-coordinate bound at (1,...,1)/sqrt(n), n = 5, 6, from the OR-region identity (A.20) and T6 <= T5 on
  [q6, q5].

The statement appears in the header of `scripts/bitlemma_k5.py` and in STATUS; there is no MAIN_RESULT_K5 yet. RQ-A's
output file for this lemma is not in the store, so I compared my results with the statement only.

### Rebuilt proof

1. *Level one.* E[f chi_i] = tau Delta_i(f) (A.20, step 1).
   - So E|c . chi| = max_f tau c . Delta(f) <= tau |c| max_f |Delta(f)|.
   - The lemma then gives E|c . chi| <= 2 sqrt5 (1-q)^4 tau |c| = T5 |c|.
   - Equality needs sum Delta(f*)^2 = 20 (1-q)^8 for f* = sgn(c . chi).
2. *OR functions.* Delta(OR_S) = 2(1-q)^(|S|-1) on S, so H_OR_S = 20 (1-q)^8 - 4|S| (1-q)^(2|S|-2).
   - For |S| = 4 this is 4 (1-q)^6 g5, which on [0, 1] vanishes only at q5.
   - For |S| = 3, 20 (1-q)^8 > 12 (1-q)^4 iff q < 1 - (3/5)^(1/4) = 0.1199, so the inequality is strict on [q6, q5].
3. *All f.* H_f >= 0 for every f is the finite computation below.
   - g5 and g6 = 6q^2 - 12q + 1 are irreducible. g5 >= 0 on [0, q5], and g6 <= 0 on [q6, 1].
   - So divide out g5 with any multiplicity and g6 with even multiplicity only, then prove the cofactor > 0 on a
     rational interval [q6-, q5+] containing [q6, q5]. This proves H_f >= 0 with the stated zero set.
4. *lem:or for n = 5, 6.*
   - (1,...,1)/sqrt(n) lies in the OR region iff q < 1/n, which holds on [q6, q5].
   - There G_n(c) = 2 tau (1-q)^(n-1) sum c <= T_n |c|.
   - T6/T5 = sqrt(6/5)(1-q) <= 1 iff q >= q6, and T4/T5 = 2/(sqrt5 (1-q)) <= 1 iff q <= q5.

All correct.

### Independent verification (RQ-AUD code only)

`audit/rqa/a22_k5_bits.py` (output `audit/rqa/outputs/a22_k5_bits.txt`, 57 s). The Delta tables come from my A.20 code,
vectorised over truth tables, and are cross-checked again here. Positivity is proved twice: by Arb root isolation (the
A.6 routine) and by my own Sturm sequences (the A.19 routine).

| check | result |
|-------|--------|
| regression: k = 4 on [q5, q4] reproduces A.20 | 39 and 1,630 distinct H_f; the zero sets as in A.20 |
| k = 5, n = 3 (256 f) | 39 distinct H_f; cofactor > 0 on [q6-, q5+]: 0 failures by Arb, 0 by Sturm; no H_f identically 0; neither g5 nor g6 divides any H_f; float minimum 0.512 |
| k = 5, n = 4 (65,536 f) | 1,630 distinct H_f; 0 failures by Arb, 0 by Sturm; no H_f identically 0; g5 \| H_f exactly for +-OR_4 (multiplicity 1); g6 divides none |
| Delta_i(f) by direct conditional expectation, exact, at q = 9/100, 1/10, 21/200 | 37,704 comparisons, all equal |
| level-one duality G_n(c) = tau max_f c . Delta(f), exact, 48 random (u, c), u in [u5, u6] | all equal |
| the conclusion exactly: G_n(c)^2 < T5^2 \|c\|^2 at six rational u in [u5, u6] (membership checked with rational bounds for sqrt5 and sqrt30), 2,412 vectors | no violation; the largest ratio of squares is 0.99999904, at (1,1,1,1) with u = 2.9107, next to u5 |
| T4/T5 and T6/T5 (sympy) | equal to 1 only at q5 and q6 respectively, with the right monotonicity |
| OR-region identity exactly at 60 random (u, c) near (1,...,1), n = 5, 6 | all equal |
| endpoint q5: G_4(1,1,1,1)/(2 T5) at q5 + 1e-4 and q5 + 1e-7 | 1.000112 and 1.00000011, so the 4-bit bound fails above q5 |
| endpoint q6: G_6(1,...,1)/(sqrt6 T5) at q6 - 1e-4 and q6 - 1e-7 | 1.000110 and 1.00000011, so T5 is beaten below q6 |

**Negative tests.**
- n = 4: on [q6, q5 + 1/1000] the check fails for +-OR_4 (2 f). With 20 - 1e-6 in place of 20 it fails for +-OR_4.
  With the k = 6 target 24 (1-q)^10 it fails for 32 f.
- n = 3: with the target 12 (1-q)^4 - 1e-6 it fails for +-OR_3. The other three corruptions must pass for n = 3, and
  they do. The binding 3-bit functions are +-OR_3, and 24 (1-q)^10 >= 12 (1-q)^4 for q <= 1 - 2^(-1/6) = 0.1091,
  which is above q5.

**For information.**
- The stronger k = 4 bound sum_i Delta_i(f)^2 <= 16 (1-q)^6 holds on [q6, q5] for every 3- and 4-bit f. Equality
  holds identically only for +-OR_4.
- I also ran an adversarial float search for MAIN-6 itself, which is not claimed: the maximum over unit c in R^n of
  G_n(c)/T5, at q6, at the midpoint and at q5, for n = 3..7.
  - n = 3: 0.930, 0.949 and 0.968, at (1,1,1)/sqrt3.
  - n = 4: 0.980, 0.990 and 1, at (1,1,1,1)/2.
  - n = 5, 6, 7: 1, at (1,1,1,1,1,0,...)/sqrt5, and at q5 also at (1,1,1,1,0,...)/2.
  - Nothing exceeds T5, so there is no counterexample to MAIN-6 with n <= 7.

### Novelty

**KNOWN within the project.**
- The inequalities are the cases n = 3, 4 of RQ-C's C6 (A.5), R_n(q) = 2 tau sqrt(max_{k<=n} k(1-q)^(2k-2)). On
  [q6, q5] this gives R_3 = S_3 < T5 and R_4 = T4 <= T5, with equality at q5. The informational check above shows
  the same.
- The OR-region identity is RQ-B's C3 (A.7c), audited again in A.20.
- RQ-A's proofs are independent of both.

---

## A.23 RQ-B C18 (Theorem 8.5: R_ID <= 867/1000) — VALID, NEW (2026-10-22 15:00 UTC)

### Claim

R_ID = sup E|Z_K| over probability Kolmogorov measures K satisfies R_ID <= 867/1000. With Theorem 3 (C6, A.10a) and
Theorem 4 (C7, A.10b):
- sqrt(2/e) = 0.85776 <= lim_{q->0} R(q) <= 0.867;
- R(q) <= B(q) = 0.867 sqrt(q/((1-q) ln(1/(1-q)))) for every q in (0, 1/2] (CLAIMS: for all q);
- B(q) < 1 for q < 0.4207 (CLAIMS: 0.42078); R(0.1) <= 0.8904, R(0.2) <= 0.9177, R(1/4) <= 0.9333;
- B/M <= 1.02118 on (0, 1/4], with the supremum at q = 1 - sqrt(2/3) ("within 2.12%"), and B/M -> 0.867 sqrt(e/2) =
  1.0108 as q -> 0.

Sources:
- RQ-B `rq/MAIN_RESULT.md` §8, Theorem 8.5 (tex Theorem 9.6, `thm:slice`; PDF 13:45:34 UTC, 14 pages).
- `rq/CLAIMS.md` C18 (df3d2fcc…) and `rq/AUDIT_REQUEST.md` §4 (fa3bcd7e…).
- Data: `numerics/rid12_certs_867_1000.json` (9e0e29f9…, 1,122 cells) and the robust variant
  `rid12_certs_87_100.json` (b4a0fea9…, 181 cells).
- My copies, with `MD5SUMS`: `audit/rqb/c18_text/` and `audit/rqb/c18_data/`. At 15:00 the store holds exactly these
  files (file times 13:48, which RQ-B's tar mirror keeps).

### Rebuilt proof (from the hypotheses)

1. *Reduction.* Put C = 867/1000 and A = 99/70, so A^2 = 9801/4900 > 2.
   - Lemma 8.1 and Proposition 8.3 (A.13a, VALID) give a probability maximiser K* with max(u, 1-u) <= R/sqrt2 and
     supp K* in [-2u/R, 2(1-u)/R].
   - So a support point a > 0 has a <= 2(1-u)/R <= sqrt2, and a support point a < 0 has |a| <= 2u/R <= sqrt2. Hence
     supp K* lies in [-sqrt2, sqrt2], a subset of [-A, A], whatever R is.
   - Unlike A.19 (A = 4/(3C)), A does not depend on C. No contradiction argument is needed: once E|Z_K| <= C for
     every probability K on [-A, A], R_ID = E|Z_K*| <= C.
   - Reflection and Jensen's inequality put (m1, m2) in D+ = {0 <= m1 <= A, m1^2 <= m2 <= A^2}, as in A.19.
   - Correct.
2. *Moments.* As in A.19 step 2: kappa_1 = 0, kappa_2 = 1 and kappa_{j+2} = m_j. E Z^k is the sum over set
   partitions of {1..k} without singletons of the products of kappa_{|B|}.
   - At degree 12, a block of size b >= 5 (the free moment m_{b-2}) leaves at most 7 elements.
   - With one free block, those elements form blocks of sizes 2, 3 and 4. The other factor is then 1, m1, m2, m1^2
     (blocks {3,3}) or m1 m2 (blocks {3,4}).
   - m1^2 needs 6 of the 7 elements, so it occurs only as 11!/(5! 3! 3! 2!) = 4620 partitions times m1^2 m3 (k = 11)
     and 12!/(6! 3! 3! 2!) = 9240 times m1^2 m4 (k = 12).
   - Two free blocks: (5,5) gives 10!/(5!^2 2!) = 126 for k = 10. (5,6) gives 11!/(5! 6!) = 462 for k = 11; (5,5)
     plus a pair cannot occur there, since it would need a singleton. For k = 12: (5,5) plus a pair gives
     12!/(5!^2 2!^2) = 8316, (5,7) gives 792 and (6,6) gives 12!/(6!^2 2!) = 462.
   - Three free blocks need 15 elements.
   - So the split and the coefficients al = 126 c10 + 8316 c12, be = 462 c11, ga = 792 c12, de = 462 c12 are
     correct.
3. *Majorant.* phi >= |z| on R, and all moments are finite (compact support), so E|Z| <= E phi(Z) = sum_k c_k P_k(m).
4. *Ranges.*
   - m3 is in [L, U] as in A.19 step 4 (the same two cubic inequalities, K of mass 1, extremes at the vertices).
   - m2^2 <= m4 by Cauchy–Schwarz, and x^4 <= A^2 x^2 on [-A, A]. With a2 >= 0 (true for every cell) this gives
     L4 = a2^2 <= m4 <= U4 = A^2 b2.
   - |x^3| <= A^3, x^4 <= A^4 and |x^5| <= A^3 x^2 give |m3| <= A^3, m4 <= A^4 and |m5| <= A^3 m2.
   - Correct.
5. *The four quadratic terms.*
   - al m3^2: if al >= 0, the chord gives m3^2 <= (L+U) m3 - LU. If al < 0, the tangent at mc = (L+U)/2 gives
     m3^2 >= 2 mc m3 - mc^2, so al m3^2 <= al((L+U) m3 - mc^2).
   - be m3 m4: m4 >= 0, so be m3 m4 <= be U m4 if be >= 0 and <= be L m4 if be < 0.
   - ga m3 m5, with ga = 792 c12 >= 0: ga m3 m5 = ga mc m5 + ga (m3 - mc) m5 <= ga mc m5 + ga ((U-L)/2) A^3 m2.
   - de m4^2, with de = 462 c12 >= 0: the chord on [L4, U4].
   - All four are correct.
6. *The m1^2 terms.*
   - On [a1, b1], l(m1) - m1^2 = (m1 - a1)(b1 - m1) lies in [0, h1^2].
   - Replacing m1^2 by l in 4620 c11 m1^2 m3 and 9240 c12 m1^2 m4 changes the sum by at most
     h1^2 (4620 |c11| |m3| + 9240 c12 m4) <= E_c. This uses |m3| <= A^3 and 0 <= m4 <= A^4; c11 may have either
     sign, which is why |c11| appears.
   - After steps 5 and 6, every m_j (j >= 3) enters linearly, with a coefficient in span{1, m1, m2, m1 m2}. So
     E phi(Z) <= Atilde + int g dK + E_c, with g(x; m1, m2) = sum_j Btilde_j(m1, m2) x^j.
   - Correct.
7. *Dual.*
   - For fixed x, g(x; .) lies in span{1, m1, m2, m1 m2}. Bilinear interpolation on Q reproduces that span with
     nonnegative weights that sum to 1.
   - So the strict inequality at the 4 vertices gives g(x; m) < y0 - E_c + y1 x + y2 x^2 for all m in Q and x in
     [-A, A].
   - Integrating against K gives int g dK <= y0 - E_c + y1 m1 + y2 m2, hence E phi(Z) <= F(m1, m2).
   - Correct.
8. *Conclusion.* F <= C on every cell, and the cells cover D+, so E|Z_K| <= C for every probability K on [-A, A]
   with m1 >= 0. By reflection this holds for every such K, so R_ID <= C. Correct.
9. *Corollaries.* As in A.19 step 7, with c = 0.867.
   - B(q)^2 = c^2 (e^s - 1)/s, s = ln(1/(1-q)), is increasing. B(1/2) = c/sqrt(ln 2) = 1.0414 > 1, so "for all q"
     in CLAIMS is also true.
   - B/M = (c/2) min_k h(ks), with h(x) = e^x/sqrt(x) log-convex, so the supremum over (0, 1/4] is at a switch
     point or at q = 1/4. The largest is at k = 2, q = 1 - sqrt(2/3): (c/2)(3/2)/sqrt(ln(3/2)) = 1.0211831.
   - Correct.

### Independent verification

Scripts (my code; the only shared code is my own A.19 primitives, no RQ-B code): `audit/rqb/a23_c18_verify.py`,
outputs `outputs/a23_c18_verify_867_1000.txt` (87 s on 8 cores) and `_87_100.txt` (3 s).

| check | result |
|-------|--------|
| E Z^k (k <= 12) as polynomials in m1..m10, derived twice: the moment–cumulant recursion, and integer partitions weighted by the number of set partitions of that type; kappa_n = int x^{n-2} dK from the Lévy–Khintchine exponent (sympy, n <= 12); E Z^k of Poisson laws, three Diracs and also two atoms plus a Gaussian part (a single Dirac has m1^2 = m2 and cannot tell those terms apart), exact laws to 50 digits | identical; errors 2e-44 and 4e-41 |
| the split: every one-free-moment coefficient lies in span{1, m1, m2, m1^2, m1 m2}; the only m1^2 terms are 4620 m1^2 m3 (k = 11) and 9240 m1^2 m4 (k = 12); the two-free-moment terms are 126 m3^2 (k = 10), 462 m3 m4 (k = 11) and 8316 m3^2 + 792 m3 m5 + 462 m4^2 (k = 12), also recomputed by block counting; no monomial has three | holds; equal to the text's list |
| per cell: c12 >= 0 and a2 >= 0; al, be, ga, de and E_c computed from my split (not from the text) equal the text's formulas; every Btilde_j lies in span{1, m1, m2, m1 m2} | 1,122/1,122 |
| (i) phi - z > 0 on [0, oo) and phi + z > 0 on (-oo, 0], by Arb root isolation and, separately, by my own Sturm sequences over Fractions | 1,122/1,122 by both methods |
| (ii) L and U from my derivation at the 4 vertices; L <= U | 1,122/1,122 |
| (iv) the dual is > 0 on [-A, A] at all 4 vertices, by both methods | 1,122/1,122 by both methods |
| (v) max_Q F <= C by exact Bernstein bounds with bisection (never needed) | 1,122/1,122; worst 0.866992662 (cell 600) |
| the centred-Taylor bound of the text, recomputed, against the file's "bound" | equal in 1,122/1,122; worst 0.866997687 |
| cover of D+ by two independent exact strip sweeps; overlapping pairs; cells needed (exact drop-one test) | covered by both; no overlapping pair; 1,119/1,122 needed (remark R2) |
| quadtree structure (`outputs/a23_quadtree_check.txt`) | every cell is a dyadic subcell of the 12 x 16 grid on [0, A] x [0, A^2], depths 0–11; smallest m1-width 5.8e-5, as stated |
| the 87/100 file (181 cells, same A) | all pass; worst max F <= 0.869667577 < 0.87, so it proves R_ID <= 0.87 on its own |
| corollaries (mpmath interval arithmetic) | q* = 0.4207821911 (certified sign change at q* -+ 1e-12), so B < 1 at 0.4207 and at 0.42078; B(0.1) <= 0.8903462, B(0.2) <= 0.9176920, B(1/4) <= 0.9332588; sup B/M = 1.0211831 at q = 1 - sqrt(2/3); limit 0.867 sqrt(e/2) = 1.0107677 |

The real margin in (v) is larger than stated. In cell 600 the worst Bernstein bound equals the value of F at a
vertex (and the largest value on a 9 x 9 grid), so it is the exact maximum of F over all cells. The margin is
therefore 7.3e-6; RQ-B's "slack 2.3e-6" is the margin of the Taylor bound, which is what the file certifies. The
majorants and duals are LP-tight (the smallest numerical gap of phi - |z| is 1.0e-8, the smallest dual slack
1.0e-6), but every check is exact, so this does not matter.

### Negative, robustness and semantic tests

- `audit/rqb/a23b_c18_negative.py` (outputs `outputs/a23b_c18_negative_867_1000.txt`, 28 s, and `_87_100.txt`), all
  cells; every case behaves as expected:
  - c_0 - 2 gap is rejected 1,122/1,122 and c_0 - gap/2 accepted 1,122/1,122, by both methods (gap = the numerical
    minimum of phi - |z|);
  - the leading coefficient c12 negated is rejected 1,122/1,122;
  - y0 - 2 slack is rejected 1,122/1,122 and y0 - slack/2 accepted 1,122/1,122, by both methods;
  - in the worst cell, C = (exact max F) - 1e-9 is rejected by Bernstein and by Taylor; C just below the worst
    Taylor bound is rejected by Taylor only;
  - lowering any cell's top edge by 1e-6 breaks the cover (1,106/1,106 testable cells);
  - (A - 1/1000)^2 < 2, so A cannot be lowered by 1/1000.
  - For information, each relaxation was made worse, to see that none is idle. With E_c doubled the dual still holds
    in 719 of the 1,122 cells; with the ga error term doubled F <= C still holds in 1,068; with the al term worsened
    by its worst gap |al| (U-L)^2/4, in 1,090. The 87/100 file gives the same picture (0, 180 and 177 of 181).
- `audit/rqb/a23c_c18_semantic.py` (outputs `outputs/a23c_c18_semantic_867_1000.txt`, 24 s, and `_87_100.txt`):
  - Setup: 3,957 Kolmogorov measures with rational atoms and weights, with and without a Gaussian part. 3,357 are
    aimed at the cells, 400 are random, and 200 are "hard" three-atom measures near (m1, m2) = (1.164, 1.388), where
    RQ-B's last open cells were. All moments, E phi, L, U, L4, U4, every relaxed term, int g dK and F are exact
    rationals. Only E|Z| is computed by Poisson enumeration (pruned mass <= 5e-15).
  - Coverage: 1,119/1,122 cells were hit. The 3 missed cells are those of R2, which meet D+ in one point.
  - No violation in any link, each checked separately:
    - E phi - E|Z| >= 6.3e-3;
    - m3 - L >= 5.7e-3, U - m3 >= 9.1e-3, m4 - L4 >= 4.5e-5, U4 - m4 >= 1.2e-2, A^3 m2 - |m5| >= 2.3e-3;
    - the al, be, ga and de relaxations are all >= 0, and the m1^2 chord with E_c is >= the true sum;
    - the dual: rhs - int g dK >= 6.3e-6;
    - F - E phi >= 8.3e-5 and C - F >= 5.5e-5.
  - Power: the same measures refute wrong variants of the relaxations: the other al relaxation (3,957 of 3,957),
    the other be endpoint (3,957), the ga bound without its A^3 m2 term (1,830) and the chord without E_c (3,881).
    So the test can see each error term.
  - The moment formulas agree with the law (Gaussian part included, k <= 12) to 5e-27.
- **Attack.** 120 Nelder–Mead runs maximised E|Z_K| over a Gaussian part plus 1–3 atoms in [-A, A]. The maximum is
  0.85776388 = sqrt(2/e), at K = delta_sqrt2, below 0.867. Nothing exceeds sqrt(2/e), consistent with C5.

### Text check and remarks (no fix needed)

The statement, the proof and the verification paragraph agree with my reconstruction, and every number I
re-derived agrees. The PDF (13:45:34 UTC, 14 pages) carries all 204 numbers and all 482 words of six or more letters
of the LaTeX source (`outputs/a23_pdf_vs_tex.txt`).
- **R1 (margin).** The stated "slack 2.3e-6" is the Taylor bound's; the exact margin is 7.3e-6 (see above).
- **R2 (tiling).** "Dropping a cell breaks the tiling (10/10 trials)" is true as a report of 10 trials. But 3 of the
  1,122 cells (48, 91 and 109 in the 0-based file order) are not needed. Each has b2 = a1^2 exactly, so it meets D+
  only in its corner (a1, a1^2), which the cell above also covers. The 87/100 file has the same three (cells 48, 93
  and 119). This is harmless for the proof. A precise sentence would be "1,119 of the 1,122 cells are needed; the
  other 3 meet D+ in a single point".
- **R3.** The introduction of the tex (line 46) says "within 2.2% of the lower bound for q <= 1/4", while the
  theorem says 2.12%. Both are true; 2.12% is the sharp figure.
- The "far-field repair" of the generator (phi += delta z^12, CLAIMS) does not affect validity: I checked the final
  rational certificates only.
- This sharpens A.19 but does not post its fix f1 (CLAIMS C17, "q < 0.38815"). A.19 stays VALID WITH FIXES; C18 does
  not depend on it.

### Novelty

**NEW.** As in A.19, no earlier explicit bound below 1 on sup E|X|/||X||_2 over centred infinitely divisible laws
was found. Marcus–Rosiński (2001) uses a different normalisation, and for small q the literature has
R(q) <= 1 - O(q^3) (Ivanisvili–Stone, Cor. 2).
- The result improves this project's A.13b (0.9161) and A.19 (0.88).
- The gap is now sqrt(2/e) = 0.85776 <= R_ID <= 0.867, i.e. 1.08%. R_ID = sqrt(2/e) is C5 and stays open.
- RQ-B's Remark rem:slicelimits explains why this method cannot reach sqrt(2/e). That remark is NUMERICAL, and I
  do not rate it.

---

## A.24 RQ-C C14 (bit lemmas uniform in k, <= 7 bits) — VALID, KNOWN within the project (2026-10-22 15:42 UTC)

### Claim

RQ-C's CLAIMS.md section C14 was filed for audit at 14:45 UTC (AUDIT_REQUEST.md, "Audit request C14"). Its text is
the same in the CLAIMS versions of 14:52, 15:04 (915cd6c7…) and 15:06 (087bff08…; copy
`audit/rqc/k4_text_f1/CLAIMS.md`).

Notation:
- a_j(q) = j (1-q)^(2j-2) and T_j = 2 tau sqrt(a_j);
- q_j = 1 - sqrt((j-1)/j), with q_1 = 1;
- G_m(c) = E|sum_{i<=m} c_i chi_i|;
- E_k(q) = {k} ∪ {k-1 if q = q_k} ∪ {k+1 if q = q_{k+1}}.

Statement. Let k >= 1, q in [q_{k+1}, q_k] ∩ (0, 1/2] and 1 <= m <= 7. Then:
- (a) G_m(c) <= T_k(q) |c| for every c in R^m.
- (b) sum_{i<=m} Delta_i(f)^2 <= 4 a_k(q) for every f: {0,1}^m -> [-1,1].
- (c) For c != 0, equality in (a) holds iff c is a positive multiple of +-1_S, with S ⊆ [m] and |S| in E_k(q).
  Equality in (b) holds iff f = +-OR_S with S of this kind.
- (d) The bound of (a) holds for every m and every c iff R(q) = T_k(q), that is, iff Conjecture S holds at q.
- (e) OR region, any m. If c_i > 0 and c_i > q sum c for all i, then G_m(c) = 2 tau (1-q)^(m-1) sum c_i
  <= T_m |c| <= T_k |c|. Equality holds iff the c_i are equal and m is in E_k(q).

C14 also states that RQ-A's three- and four-bit lemmas follow for every k, "with exactly the equality cases listed
there".

### Rebuilt proof (from the hypotheses)

1. *Unimodality.*
   - a_{j+1}/a_j = (1 + 1/j)(1-q)^2. This is >= 1 iff (1-q)^2 >= j/(j+1), i.e. iff q <= q_{j+1}, with equality iff
     q = q_{j+1}.
   - On [q_{k+1}, q_k], a_j strictly increases up to j = k and strictly decreases from j = k on, except for the tie
     a_{k-1} = a_k at q_k and the tie a_k = a_{k+1} at q_{k+1}.
   - So max_j a_j = a_k, argmax = E_k(q), and max_{j<=m} a_j = a_k iff E_k(q) meets [1, m].
   - Correct.
2. *jq < 1 on E_k(q).*
   - For j >= 2, q_j < 1/j because sqrt(1 - 1/j) > 1 - 1/j.
   - j = k: q <= q_k gives kq < 1.
   - j = k-1 at q = q_k: (k-1) q_k < (k-1) q_{k-1} < 1, or q < 1 when k-1 = 1.
   - j = k+1 at q = q_{k+1}: (k+1) q_{k+1} < 1.
   - So 1_S with |S| = j is in the OR region, and G(1_S) = 2 tau (1-q)^(j-1) j = T_j |1_S|.
   - Correct.
3. *C6 in the form used.* A.5 and A.5b give the following, for q <= 1/2 and every LTF f: {0,1}^m -> {0,1}, m <= 7,
   with r relevant variables:
   - P_f = |E D f|^2 < M_r = max_{j<=r} a_j, unless f is OR_S or 1 - OR_S with |S| = r, and then P_f = a_r.
   - Hence P_f <= max_{j<=m} a_j, with equality iff f is OR_S or 1 - OR_S and |S| is in argmax_{j<=m} a_j.
   - Duality: put f = 1{c.chi > 0}. Since E c.chi = 0, G_m(c) = 2 E[f c.chi] = 2 tau <c, E D f> <= 2 tau |c| sqrt(P_f).
   - For a unit c, equality needs P_f maximal and Cauchy–Schwarz equality, so c = +-1_S/sqrt|S| with |S| in the
     argmax.
   - At q = 1/2, OR on r >= 2 negated literals has P = r/4^(r-1) < 1 = a_1, so it adds no tie there; for r = 1 it is
     the complement of a dictator, which is +-OR_S.
   - Correct.
4. *(a), and (c) for (a).*
   - G_m(c) <= R_m |c| = 2 tau sqrt(max_{j<=m} a_j) |c| <= T_k |c|, by steps 1 and 3.
   - Equality needs both steps to be tight: c is proportional to +-1_S with |S| in argmax_{j<=m} a_j, and that
     maximum equals a_k. So |S| is in E_k(q) ∩ [1, m].
   - The converse is step 2.
   - Correct.
5. *(b), and (c) for (b).*
   - For every real f, E[f chi_i] = (E[f x_i] - q E f)/tau = (q(1-q)/tau)(E[f | x_i = 1] - E[f | x_i = 0]) =
     tau Delta_i(f).
   - With c = Delta(f)/|Delta(f)|: tau |Delta(f)| = E[f c.chi] <= E|c.chi| <= T_k, so sum Delta_i^2 <= 4 a_k.
   - Equality needs G(c) = T_k, which fixes c by (c), and f = sgn(c.chi) wherever c.chi != 0. Every point of the
     cube has positive probability.
   - c.chi is a multiple of (sum_{i in S} x_i - jq), which never vanishes because 0 < jq < 1. So f = +-OR_S.
   - Delta(f) = 0 cannot give equality, because a_k > 0.
   - Correct.
6. *(d) and (e).*
   - (d) is a tautology. R(q) = sup_m R_m(q), because finitely supported vectors are dense and E|.| is 1-Lipschitz
     in l2; and R >= T_k, witnessed by c = 1_k.
   - (e) is the OR-region identity (RQ-B C3 = A.7c; RQ-A lem:or, rebuilt in A.20 step 2), then Cauchy–Schwarz, then
     step 1.
   - When mq < 1 the hypothesis "c_i > q sum c for all i" already forces sum c > 0, hence c_i > 0. So the hypothesis
     c_i > 0 matters only when mq >= 1.
   - Correct.
7. *The "in particular" sentence.* I compared (c) with the equality lists of the five audited per-k bit lemmas. In
   every case the list is exactly the set of +-OR_S with |S| in E_k(q) ∩ [1, m]:
   - A.11 (k = 2, 3 bits): +-OR_2 always, +-OR_3 at q3, and the dictators at q2;
   - A.14 (k = 3, 3 bits): +-OR_3, and +-OR_ij at q3;
   - A.18 (k = 3, 3 and 4 bits): +-OR_S with |S| = 3, and +-OR_4 at q4;
   - A.20 (k = 4): (1,1,1) only at q4; (1,1,1,1) always and e_i+e_j+e_k at q4; five equal OR-region coordinates at q5;
   - A.22 (k = 5): strict for 3 bits; for 4 bits, +-OR_4 only at q5.

   Correct.
8. *The k-dependence remark.* q_k < 1/(k+1) is equivalent to (k-1)(k+1)^2 > k^3, i.e. to k^2 - k - 1 > 0, which holds
   for every k >= 2. So the equal vector on k+1 coordinates is in the OR region throughout I_k. Correct; this is a
   remark, not a claim.

### Independent verification (RQ-AUD code only)

The program is `audit/rqc/a24_c14_check.py` and the output is `outputs/a24_c14_check.txt` (197 s). It uses exact
integers and Fractions, my own Sturm sequences and the A.5 class list. It uses no RQ-C code.

Notation for the table:
- I_k = [q_{k+1}, q_k], and I_1 = [q_2, 1/2].
- The tail is (0, q_{m+1}], compared with a_m. It covers every k >= m+1 at once, because there a_m <= a_k, with
  equality iff k = m+1 and q = q_{m+1}.
- Every interval test is decided exactly:
  - the endpoint factors (mu_j = j q^2 - 2 j q + 1, irreducible because j(j-1) is not a square; 2q - 1; and q) are
    divided out as often as they divide;
  - the cofactor has no real root on a rational outer enclosure of the interval (width 1e-40);
  - the polynomial is > 0 at a rational interior point.

| part | test | result |
|---|---|---|
| U | at q = q_i, a_{j+1}/a_j = (j+1)(i-1)/(j i) exactly, so a_1 < ... < a_{i-1} = a_i > ... > a_80, for i = 2..60; q_i < 1/(i+1) < 1/i | PASS |
| B | every f: {0,1}^m -> {-1,1} for m = 1..4 (4, 16, 256 and 65,536 functions, with 3, 11, 79 and 3,679 distinct P_f). D = 4 a_k - sum Delta_i^2 on I_k for k <= m, and 4 a_m - sum Delta_i^2 on the tail | **18,750 interval tests, 0 failures**. The zero sets are exactly those of (c): D == 0 only for the 2 C(m,k) functions +-OR_S with \|S\| = k; D(q_k) = 0 only for \|S\| = k-1; D(q_{k+1}) = 0 only for \|S\| = k+1; no zero at 1/2. On the tail, D == 0 only for +-OR_[m] |
| L | every LTF on <= 6 bits: the 38,456 S_6-classes of my A.5 enumeration (`outputs/a5_classes_W9.txt`, complete by OEIS A000609, checked in A.5), with P_f = \|E D f\|^2 against a_k, on I_1..I_r and on the tail for r relevant variables | **267,242 interval tests, 0 failures**. For each r = 1..6 exactly two classes, OR_r and its complement, touch the bound: identically on I_r and on the tail, and at q_r on I_{r-1} |
| E | the OR-region identity E\|sum c_i (x_i - q)\| = 2q (1-q)^m sum c, by exact enumeration: 322 random positive c in the region, m <= 10, rational q | exact in all cases. c = -(1,1,1,1) at q = 2/5 (mq > 1) satisfies c_i > q sum c and breaks the identity, so c_i > 0 is needed |

How the parts relate to C6:
- Part B does not use C6 or any LTF enumeration. It proves (b) and its equality case for every Boolean f on <= 4 bits
  and every k directly. For [-1,1]-valued f the bound follows by convexity, because sum Delta_i(f)^2 is convex in the
  values of f. (a) then follows by the duality of step 3.
- For m = 5 and 6, part L re-derives the uniform statement from the LTF classes. Its decision procedure differs from
  A.5, which used Arb root isolation on pieces: here the minimal polynomials are divided out exactly and Sturm
  sequences decide the rest.
- m = 7 rests on A.5b, which was checked by two methods (Arb and exact Sturm).

**Negative tests** (`a24b_c14_negative.py`, output `outputs/a24b_c14_negative.txt`). All four behave as required:
- N1: with the comparator 4 a_k lowered by the factor 1 - 1e-6, all 6 (interval, OR_k) pairs are rejected.
- N2: the false equality rules "no tie at q_k for |S| = k-1" and "no tie at q_{k+1} for |S| = k+1" are both reported.
- N3: an interior double root (at 1/5 in I_2) and a sign change (at 3/10 in I_1) leave the cofactor undecided. A
  mu_3 factor is detected as a zero at q_3, so a non-OR function with that zero would be flagged.
- N4: the regimes are sharp. Just outside I_k (k = 2..6), OR_{k+1} exceeds 4 a_k at q_{k+1} - 1/1000, and OR_{k-1}
  exceeds it at q_k + 1/1000.

**Verdict: VALID** (no fix needed).

### Novelty

**KNOWN within the project.**
- C14 is a corollary of C6 (A.5, A.5b), the OR-region identity (A.7c, A.20) and the elementary unimodality of
  j -> j(1-q)^(2j-2).
- The per-k bit lemmas of A.11, A.14, A.18, A.20 and A.22 are special cases of it.
- As a stated theorem it is not in the literature: C6 itself is NEW (A.5), and BF3 has only numerics for n <= 7.
- Part (d) shows what C14 cannot do. The all-m form of the bit lemma is Conjecture S itself, so C14 removes the
  per-k bit computations but not the per-k moment covers.

## A.25 RQ-A MAIN-5 (R(q) = T4 = 4 (1-q)^3 tau on [q5, q4]; the k = 4 regime closed) — VALID, NEW (2026-10-22 16:53 UTC)

**Claim.** Sources:
- RQ-A `MAIN_RESULT_K4.md/.tex/.pdf`, posted 15:49 (md 368c72ee…, tex 9c7a75e9…, PDF 7ce6cd40…, 24 pages).
- `AUDIT_REQUEST.md` section MAIN-5 (7a4c9297…).
- CLAIMS MAIN-5. Its section is byte-identical in 4dd8f7d5…, 5b5b9bb1… and 3a8a0c64….

Let q4 = 1-sqrt3/2 = 0.133975, q5 = 1-2/sqrt5 = 0.105573, tau = sqrt(q(1-q)) and T_k = 2 sqrt(k) (1-q)^(k-1) tau,
so T4 = 4 (1-q)^3 tau.
- (a) For every q in [q5, q4], every n and every unit alpha, E|sum alpha_i chi_i| <= T4. With the mirror,
  R(q) = 4 max(q, 1-q)^3 tau on [q5, q4] ∪ [1-q4, 1-q5].
- (b) Equality holds iff alpha = +-(e_i+e_j+e_k+e_l)/2; or q in {q4, 1-q4} and alpha = +-(e_i+e_j+e_k)/sqrt3; or
  q in {q5, 1-q5} and alpha = +-(e_i1+...+e_i5)/sqrt5.
- (c) R > T4 on (0, q5) ∪ (q4, 1/2]:
  - R >= T5 > T4 below q5;
  - R >= T3 > T4 on (q4, 1/3);
  - R >= 2 tau > T4 on [1/3, 1/2].
- Corollary 1: {q <= 1/2 : R(q) = T4(q)} = [q5, q4].
- Corollary 2 (with Theorems 1–4, i.e. A.6, A.11, A.14, A.18): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), where
  qh = max(q, 1-q), on [q5, 1-q5] = [0.105573, 0.894427].

My copies:
- The texts are in `audit/rqa/k4_text_1549/`. They are identical to the store copies at 16:47.
- The 80 data files and the manifest are in `audit/rqa/k4_data/`, and their md5s agree with `k4_MD5SUMS.txt`
  (3a8fd366…).
- The 87 MB folder `k4/` stays local and is not mirrored; its md5 list is in git.

Verdict: **VALID**. No fix to the mathematics is needed; there are two status remarks.

### Rebuilt proof (each step re-derived from the hypotheses)

The proof follows MAIN-4 (A.18) with the target T4, the range u in [u4, u5] and three new layers: the five-coordinate
test, the TCN pieces and the exact cone test. I re-derived every lemma. The items record what I checked, with more
detail where MAIN-5 differs from MAIN-4.
1. *Parametrisation and constants (Lemma 3, (1)–(3)).*
   - Symmetry: q <-> 1-q.
   - T4 = 4u^7/(1+u^2)^4 and T4' = 4u^6(7-u^2)/(1+u^2)^5. So T4 is unimodal with its peak at sqrt7 = 2.6458, inside
     the range, and T^-(u1, u2) = min(T4(u1), T4(u2)) is a valid lower bound on [u1, u2]; this is (2).
   - u4^2 = 3+2 sqrt3 and u5^2 = 4+2 sqrt5.
   - U- = 1589/625 <= u4 (u4 - U- = 5.98e-5), and U+ = 29107/10000 >= u5 (U+ - u5 = 6.6e-6).
   - (3) is strict because w- is rational.

   Correct.
2. *Test vectors (Lemma 4) and (c).*
   - For q < 1/k the sum of k bits is positive iff some bit equals u, so E|chi_1+...+chi_k|/sqrt k = T_k.
   - T3 <= T4 iff q <= q4, and T5 <= T4 iff q >= q5.
   - 2 tau < T4 and T2 < T4 for u >= U-.

   Correct.
3. *Reduction (Section 2.3).*
   - The quantities a1 = max|alpha_i|, a2, s, r, b and beta, with m <= min(1, a2/b).
   - The half-angle t = a2/(r+a1) lies in [0, sqrt2-1], and T8 = 20711/50000 >= sqrt2-1.

   Correct.
4. *Lemma 5* (two coordinates): as in A.11, A.14 and A.18; E|X| <= max(2 tau, T2) rho < T4 rho. Correct.
5. *Lemma 6 (OR-region identity) and Lemmas 7–8 (the k = 4 three- and four-bit lemmas).* They were audited in A.20,
   and the texts have not changed since. `a20_k4_bits.py` passes again on the 15:49 version. Correct.
6. *Lemmas 10–13* (cumulants, moment recursion, power sums, sign information).
   - The cumulants agree with my table (`moments10`).
   - kappa_3..kappa_10 are monotone on [U-, U+], so their endpoint values enclose them.
   - Lemma 12: rho = sqrt(p4) <= m, |p3| <= rho and |p_j| <= m^(j-4) rho^2. For even j, Jensen with the weights
     beta_i^2 gives p_j >= rho^(j-2).
   - Lemma 13 is Lemma 12 of K3B.

   Correct.
7. *Definition 14 / Lemma 15* (the ten-moment objective bound): the same four term bounds as in A.18 item 8. Correct.
8. *Lemma 16* (cells, a1 <= 33/100).
   - E|L| = 2 tau a + 2 E R_a(b1 M1) (BF3 Lemma 9.4), and T4 = 2 tau · 2(1-q)^3, so the target is
     tau (2(1-q)^3 - a).
   - l1 <= lbar_1 and l2 <= lbar_2 hold on the cell.
   - Theta_1 = tau(u2)(2 (u1^2/(1+u1^2))^3 - abar) <= tau(u)(2(1-q)^3 - a), because tau decreases for u > 1 and the
     bracket is positive by (3).

   Correct.
9. *Lemmas 17–18* (F_x is convex and 1-homogeneous; peeling). The second peel (j = 2) is new.
   - M^(2) = (M^(1))^flat, normalised by its own norm, is independent of the split coordinates, and its
     coefficients are at most the recorded cap.
   - The patches p2, p3 and p4 = (rc, rd, b0 m, b1 m', b1 sqrt(1-m'^2)) reproduce E|L| = E F_p(Z).

   Correct.
10. *Definition 19 / Lemma 20* (vertex sets, cone lemma) for k = 2, 3, 4 patch parameters: the argument of A.18
    item 11, in dimension k+1. Correct.
11. *Lemma 21* (facet minima).
    - g(x) = alpha x + beta sqrt(1-x^2) is concave for beta >= 0, so its minimum is at an end. It is convex for
      beta < 0, so its minimum is at the critical point when that lies inside.
    - The recursion for (P4) is valid: a lower bound of an inner minimum, times a nonnegative weight, bounds the
      outer minimum from below.

    Correct. My verifier uses a different exact cone test, so (P4) is checked by two algorithms.
12. *Definitions 22–24 / Lemmas 23, 25* (envelope; vertex-certificate lemma): as in A.18 items 12–13. The class 𝒵
    now also contains the remainders after one or two peels. Each is a unit-norm sum of fresh copies of chi with the
    recorded cap. Correct.
13. *Lemma 26* (lpv): m <= mbar(B). *Lemmas 27–28* (tail bound, near-circle tests) are correct, but no ncA box
    occurs (Table 1). Correct.
14. *Lemmas 29, 31, 32, 34 and Definitions 30, 33*, i.e. (A3)/(B3), TC and SG, (A4)/(B4) and TCS:
    - These follow A.18 items 16–19, with Lemmas 7 and 8 for k = 4.
    - (A3) and (A4) are valid only for q in [q5, q4].
    - Equality in TCS forces s = 1 and alpha = (e1+e2+e_i0+e_i1)/2.

    Correct.
15. *Lemma 35 and the tests (A5)/(B5)* (new).
    - The tail-bound step is the one of Lemmas 29 and 32, with five split coordinates and E M'''^4 <= E4'.
    - At b''' = 0, E|L| = G_5(a1, ..., a5). Lemma 6 applies only when s = 1 and a_i > q sum_l a_l for every i, and
      (A5) requires both on the whole piece.
    - G_5 = T4 holds only at q5 with all a_i = 1/sqrt5. So (A5) is strict except at the third extremiser.

    Correct.
16. *Definitions 36–37 / Lemma 38* (TCN, new). The inner m-split of the second remainder M' is exhaustive.
    - m' = mu(M') <= min(1, m/sqrt(1-m^2)) <= min(1, m2/sqrt(1-m2^2)) <= kappa, by the cap condition.
    - If m' <= m_c', the certificate C' applies.
    - Otherwise M' has a coefficient +m' or -m' with m' in [m_c', kappa].
      - A coefficient +m' falls in an inner plus piece: (A4)/(B4), TC4 with s4 = 1, or TC4S.
      - A coefficient -m' falls in an inner minus piece: SG3 (Lemma 13 applied to M') or TC4 with s4 = -1.
    - TC4S repeats the TCS construction one level deeper: D' with cap m_c'', D'' with cap kappa4 and p*, and (A5)
      sub-pieces.
    - Equality forces s = 1 and either an (A4) inner piece, giving (e1+e2+e_i0+e_i1)/2, or an (A5) sub-piece at
      q5, giving the 5-sum.

    Correct.
17. *Definition 39 / Lemma 40* (ms5): the split into m <= m_c, some coefficient +m, and only -m is exhaustive. The
    equality cases are as listed. Correct.
18. *Proof of Theorem 5 and the corollaries.*
    - Cases: a1 = 1; a1 <= 33/100 (cells); r = 1 (Lemma 5); otherwise a box (lpv by Lemma 26, ms5 by Lemma 40).
    - Closed boxes with disjoint interiors and full total volume fill the closed region.
    - Only ms5 allows equality, so (b) follows from Lemmas 40 and 4. (c) is Lemma 4.
    - Corollary 2: on [q4, 1/2], 2(1-q)^3 <= sqrt3 (1-q)^2. On [q5, q4], 2(1-q)^3 is the largest of the first four
      entries. For k >= 5 the ratio of the k-th entry to it is at most (k/4 (4/5)^(k-4))^(1/2) <= 1.

    Correct.

**Scope.** Every computer statement except (A3), (A4) and (A5) holds at every u of its box or cell.
- Those three tests rest on Lemmas 7 and 8 and on T5 <= T4, which hold only for q in [q5, q4].
- The text restricts Lemmas 34, 38 and 40 and the proof to that range (Remark 2).
- In the semantic test below, none of the three tests claims a sample with u outside [u4, u5].

Correct.

### Independent computer verification (RQ-AUD code only)

`audit/rqa/a25_k4_verify.py` extends my A.18 verifier `a18_k3b_verify.py`. It also uses my helpers from A.6 and A.11
and my moment toolkit `audit/common/moments10.py`. It uses no RQ-A code; I read RQ-A's verifier output only to
compare counts.
- Arithmetic is exact over the rationals, and square roots are bounded by integer square roots.
- Envelopes use the breakpoints of Definition 22; positivity is shown by certified root isolation (python-flint).
- (P4) is checked by my own exact cone test. It combines the dual functionals of the parallelepiped (from the inverse
  Gram matrix) with exact nested minima over the patch, innermost variable first. This is a different algorithm from
  RQ-A's facet recursion (Lemma 21).

Runs on `audit/rqa/k4_data/`:
- parts M, A and B: 5 s; parts C and F: 3 s;
- part D: 2 min 6 s, i.e. 16.5 CPU minutes on 8 cores;
- outputs: `outputs/a25_k4_verify_MAB.txt`, `_CF.txt` and `_D.txt`.

| step | result |
|------|--------|
| md5 of the 81 manifest files against `k4_MD5SUMS.txt` | 0 mismatches |
| constants: u4 and u5 give q4 and q5; 2 < U- <= u4 and U+ >= u5; tan(pi/8) <= T8 < 1; (3); the formula for T4 and the factorisation of T4' | True |
| kappa_3..kappa_10 monotone in u on [U-, U+] (no root of kappa_j') | True |
| moment toolkit: two recursions for kappa_j, two constructions of E M^n (n <= 12), 351 exact enumeration identities | True |
| tilings: 1,268 cells tile [U-, U+] x [0, 33/100]; for each sign the boxes tile [U-, U+] x [0, T8] x [33/100, 1] (inside, volume sum = region volume, 0 overlapping pairs) | s = +1: 6,045 boxes; s = -1: 1,216 boxes; OK |
| box kinds | only lpv (3,327 with s = +1, 1,216 with s = -1) and ms5 (2,718, all with s = +1) |
| one-coordinate cells: (V1)–(V3) and my ten-moment bound with target Theta_1 | **1,268/1,268**, all of degree 10 |
| vertex certificates: (P1)–(P3) exactly, (P4) by my cone test, (W1) on every linear piece of my envelope, (W2) with T^-; caps and p* taken from the structure (below the table) | **21,014/21,014**: 4,543 lpv, 2,718 C(1), 5,188 TC, 211 SG, 2 x 1,438 TCS, 1,247 C' of TCN, 2,479 TC4 (+), 1,247 TC4 (-), 2 x 216 TC4S, 73 SG3; 171,488 vertices; 7,472 / 9,384 / 4,158 sets with 2 / 3 / 4 patch parameters; no cone split needed |
| m-split structure: r2 < 1, u1 >= 2, b^- > 0, 0 < m_c < min(1, mbar(B)); all covers (plus and minus pieces, TCS sub-pieces, TCN inner plus and minus pieces, TC4S sub-pieces); cap and phi checks; my exact near-sphere tests (A3), (A4) and (A5), the last with s = 1 and the OR-region condition on the whole piece | **2,718/2,718**; 101 A3, 1,999 + 534 A4 and 383 A5 pieces |
| bit lemmas and the OR-region identity (`a20_k4_bits.py`, rerun) | ALL CHECKS PASSED, as in A.20 |

The caps and p* values in the vertex-certificate row are taken from the structure as follows:
- mbar(B) for lpv, and min(m_c, mbar) for C(1);
- min(m2, mbar) and p* for SG;
- the recorded cap, after its cap check, for TC;
- m_c' for C' of TCS and of TCN, and kappa and p* for C'' of TCS;
- kappa4, after its check, for TC4;
- m_c'' for D', and kappa4 and p* for D'';
- kappa3 for SG3.

RQ-A's verifier (`outputs/verify_k4_ABCDEFG.txt`) reports the same counts:
- 1,268 cells;
- 6,045 and 1,216 boxes;
- 21,014 vertex sets with 171,488 vertices;
- 2,533 four-coordinate and 383 five-coordinate near-sphere pieces.

### Negative, semantic and text tests

- **Negative tests** (`a25b_k4_negative.py`, 7 s, output `outputs/a25b_k4_negative.txt`). There are 24 kinds of
  corruption, and every sampled case of each is rejected. The 40 uncorrupted lpv boxes are accepted 40/40.
  - lpv boxes: domination, the objective bound, the cone check and a vertex moved by 1e-6.
  - ms5 boxes: a removed plus or minus piece; lowered tops; caps replaced by m2; an SG p* below phi(m1); a widened
    (A4) sub-piece; a lowered constant term.
  - TCN pieces: removed inner pieces; a lowered m_c'; caps replaced by n2; an SG3 p* below phi(n1); a widened inner
    (A4) piece; a lowered nested constant term.
  - TC4S: a widened (A5) sub-piece. The same sub-piece re-checked with s = -1 is rejected by (A5), as it must be.
  - Nested polytopes shrunk by 1/2.
  - One box removed from each tiling.
  - Cells with the constant term raised by 1.
- **Semantic test, end to end** (`a25c_k4_semantic.py`, floating point, 11 s, output
  `outputs/a25c_k4_semantic.txt`).
  - There are 50,600 samples (alpha, u). Of these, 50,000 are random, including flat vectors with 10–14
    coordinates, and 600 lie on the three extremisers across [U-, U+].
  - Each sample is routed to the record, and to the step of the proof, that claims it. E|L| is computed by
    enumerating the atoms and compared with the claimed bound.
  - Result: **0 violations.** The samples reach every route: 36,529 lpv, 2,522 cells, and every ms5 piece type.
  - The smallest relative slacks of the near-sphere steps sit at the equality cases, as they should:
    - 2.1e-8 for (A3), at alpha ≈ (1,1,1)/sqrt3 and u - u4 = 8.9e-8;
    - 3.8e-9 for (A5), at alpha ≈ (1,1,1,1,1)/sqrt5 and u5 - u = 1.4e-8;
    - -8.8e-16 and -7.5e-16 for the (A4) pieces of TCS and TCN, at alpha = (1,1,1,1)/2 exactly, where equality
      holds; this is rounding.
  - 2,363 samples would need (A3), (A4) or (A5) at a u outside [u4, u5]. None of them is claimed, as Remark 2 says.
- **Text versus data** (`a25d_k4_textcheck.py`, 1 s): 20/20 checks pass.
  - Table 1, the width ranges and the m_c counts.
  - Every piece count of Section 9, the 21,014 certificates with 171,488 vertices, and the degrees (1,894 vertex
    polynomials of degree 10, all others of degree 6).
  - The ranges in Remark 3 (TCS only at u <= 2.76, TCN at u >= 2.75, TC4S at u >= 2.83) and the 2,766 boxes of the
    five plus slabs.
  - Lemmas 4 and 5 at random points, Theorem 5(c) and Corollary 2 on a grid, and the ties at q4 and q5.
- **Attack.** There was no counterexample to look for beyond the earlier searches.
  - H.1 (11:48) took 13 values of q in [q5, q4], exact enumeration for n = 4..16, and large-plus-bulk and two-block
    families. It found the ratio 1 only at the three extremisers of (b).
  - RQ-C's C6 (A.5, A.5b) gives the same for n <= 7.

### Text points (no fix to the mathematics)

- r1: Corollary 2 still says that Theorem 4 is "filed as MAIN-4, not yet audited".
  - The statement is conditional and stays true.
  - Theorem 4 is now auditor-VALID (A.18, 12:41) and referee-VALID (RQ-REF1, 15:35), so Corollary 2 holds
    unconditionally.
  - The parenthesis should be updated.
- r2: Remark 4 ("Status. Not yet audited.") should be updated.

### Novelty

**NEW.**
- This is the first proof of R(q) = T4 on the whole k = 4 regime [q5, q4] = [0.105573, 0.133975]. It is sharp at both
  ends and gives all extremisers, including the third one, (e1+...+e5)/sqrt5 at q5.
- RQ-C's C13 (A.21, A.21b; auditor-VALID, not yet refereed) covers [0.123830, q4], about 36% of the regime, by a
  different method. On that part the two proofs are independent.
- With A.6, A.11, A.14 and A.18: R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1) on [q5, 1-q5] = [1-2/sqrt5, 2/sqrt5] =
  [0.10557, 0.89443].
  - This is the conjectured formula (BF3 §9.4) on its first four regimes. The lower bound is KNOWN (Stone, thesis
    Thm 4.3.1).
  - The literature has only [3/8, 5/8] (BF3 Theorem K).

### Addendum: RQ-A's text corrections c1–c2 after A.25 (2026-10-22 21:19 UTC)

- **Sources.**
  - RQ-A AUDIT_REQUEST 4664cac0… (20:58; unchanged in this part at 70a980df…, 21:08), "Text corrections after A.25
    (20:51 UTC)".
  - `MAIN_RESULT_K4.tex` is now 158934d2… (20:53), with `.md` 1d5e6469… and `.pdf` b975e187… (24 pages). Copies are
    `audit/snapshots/RQ-A_MAIN_RESULT_K4_2053.{tex,md}`.
- **Diff against the text A.25 checked** (2de72bdb…, copy `audit/rqa/k4_text_1747/`): exactly two passages changed. The
  `.md` and the PDF carry the same two changes.
  - c1 (Conventions, tex line 153). "(the verifier uses N = 10^15 for the box parameters and N = 10^12 for the patch
    enclosures)" now reads "(the verifier uses N = 10^15)".
    - This describes RQ-A's verifier only.
    - The rational bounds floor(N sqrt x)/N <= sqrt x < (floor(N sqrt x) + 1)/N hold for every N, so no statement of
      the paper depends on N.
  - c2 (Section 9, the Part B item, tex line 1284). The new text says that Part B does not check the kinds, and that
    `scripts/k4_kinds_check.py` checks every box has the sign of its file and one of the kinds small, lpv, ncA, ncB, ms5.
    - RQ-A's output `outputs/k4_kinds_check.txt` reports 3,327 lpv and 2,718 ms5 boxes with s = +1 and 1,216 lpv boxes
      with s = -1, 7,261 in all.
- **My A.25 verification never had this gap.** My own verifier `audit/rqa/a25_k4_verify.py` already enforces both
  conditions.
  - It asserts that every box has the sign of its file (line 457).
  - It fails unless every kind is lpv or ms5 (line 499). Its output `a25_k4_verify_MAB.txt` says "box kinds outside
    {lpv, ms5}: []".
  - Its counts are the same: (+1, lpv) 3,327, (+1, ms5) 2,718 and (-1, lpv) 1,216.
  - Every lpv box went to my vertex-certificate check, and every ms5 box to my c1 and split-tree checks.
- **The data are unchanged.** All 81 entries of RQ-A's `outputs/k4_MD5SUMS.txt` (unchanged since 15:49) match the
  copies I verified in A.25.
- **r3 (cosmetic).**
  - The AUDIT_REQUEST quotes "md5 now 383e0b25…" for `MAIN_RESULT_K4.tex`, but the posted file is 158934d2…. The `.md`
    and the PDF do not have md5 383e0b25… either.
  - The posted file differs from 2de72bdb… in exactly c1 and c2, so the text is as described. The quoted md5 should be
    corrected.
- **A.25 stays VALID.**

**Addendum (2026-10-23 01:05 UTC): refereed.** RQ-REF2 (`RQ-REF2/REFEREE.md` bd18da81…) rates MAIN-5 VALID in tex
158934d2…, the version of the addendum above, with no fixes. It used its own exact code on the same data list
(3a8fd366…), and every count it reports agrees with mine. A.25 now meets the LOCKED_NOTE criterion.

## A.26 RQ-B C19 = RQ-A U.1–U.2 (configuration-wise Poissonisation; a q-free sufficient condition) — VALID, NEW (2026-10-22 16:14 UTC); fix f1 posted (16:55 UTC)

**Sources.** RQ-B `rq/CLAIMS.md` C19 (232c7a4c…), `rq/MAIN_RESULT.md` §3 Theorem 3.4 and the remarks after it
(tex Theorem 4.4, 06cccefc…), AUDIT_REQUEST §5 (2d5e71b3…). RQ-A CLAIMS.md section U (4dd8f7d5… of 15:49; 5b5b9bb1…
of 16:07, which adds that RQ-A files U.1 through RQ-B's C19 and lets theta depend on K). Snapshots:
`audit/snapshots/RQ-B_CLAIMS_1553.md`, `RQ-A_CLAIMS_1553.md`, `RQ-A_CLAIMS_1607.md`.

**Claim.** Notation: g(x) = 2 sqrt(x) e^{-x}, s = ln(1/(1-q)), C(q) = max_{k>=1} g(ks), so
M(q) = sqrt(q/((1-q)s)) C(q). For a Kolmogorov probability measure K and theta > 0,
lam+_theta(K) = int_[theta,oo) x^{-2} dK and lam-_theta(K) = int_(-oo,-theta] x^{-2} dK.
- (a) For f: {0,1}^n -> [0,1] with D(f) = sum_i Delta_i(f)^2 > 0, beta = Delta(f)/sqrt(D(f)) and
  K_f = sum_{beta_i != 0} beta_i^2 delta_{beta_i/sqrt s}: 2 tau sqrt(D(f)) <= sqrt(q/((1-q)s)) E|Z_{K_f}|.
- (b) lam+-_theta(K_f) = s #{i : +-beta_i >= theta sqrt s}, and sqrt(q/((1-q)s)) g(ks) = T_k(q).
- (c), (d) If E|Z_K| <= max(g(lam+), g(lam-), C) for every finitely supported K, then R(q) = M(q) wherever
  C(q) >= C. RQ-B fixes one theta for all K; RQ-A's ID*(C) lets theta depend on K. Both are proved by the same
  argument, because the proof uses the hypothesis only at K = K_f, and (b) holds for every theta.
- (d), U.2: min over (0, q_K] of C(q) is C(q_K) = g((K-1) s(q_K)) = sqrt(2/e)/(1 + E_{K-1}), with
  C_4 = 0.8533436, C_5 = 0.8551005, C_6 = 0.8559845.
- (e) The hypothesis with C <= sqrt(2/e) implies C5.

**Rebuilt proof.**
1. *Level one.* E[f chi_i] = tau Delta_i(f), and E L = 0 gives E|L| = 2 E[L 1{L>0}]. At a maximiser alpha of E|L|
   on the unit sphere of R^n, f = 1{L > 0} gives R_n = 2 tau alpha . Delta <= 2 tau sqrt(D) <=
   E|beta . chi| <= R_n. So R_n = 2 tau sqrt(D(f)), and maximisers exist by compactness. This is A.3/A.7a.
2. *Poissonisation (a).* Take N_i i.i.d. Poisson(s) and x_i = 1{N_i >= 1}, which is Bernoulli(1 - e^{-s}) =
   Bernoulli(q). Put F = f(x(N)).
   - Stein–Chen gives E[(N_i - s) G(N)] = s E[G(N + e_i) - G(N)].
   - F(N + e_i) - F(N) = 1{N_i = 0} (f(x^{i<-1}) - f(x^{i<-0})), which has mean (1-q) Delta_i(f) by independence.
   - So with I = sum Delta_i (N_i - s): s(1-q) D = E[F I] <= E I_+ = E|I|/2, using 0 <= F <= 1 and E I = 0.
   - c(N - s) with N ~ Poisson(s) has Kolmogorov measure s c^2 delta_c. So I/sqrt(sD) = sum (beta_i/sqrt s)(N_i - s)
     has Kolmogorov measure K_f, of total mass sum beta_i^2 = 1.
   - Hence sqrt D <= E|Z_{K_f}|/(2(1-q) sqrt s), and 2 tau sqrt D <= sqrt(q/((1-q)s)) E|Z_{K_f}|, because
     tau/((1-q) sqrt s) = sqrt(q/((1-q)s)).
   This is the proof of A.10a (RQ-B Theorem 3) with f kept fixed.
3. *Quantisation (b).* The atom of index i has mass beta_i^2 at beta_i/sqrt s. It contributes
   (s/beta_i^2) beta_i^2 = s to lam+ iff beta_i/sqrt s >= theta, and likewise to lam-. So lam+- are in s Z>=0 for
   every theta, and g(lam+-) <= max(g(0), max_k g(ks)) = C(q). The identity: e^{-ks} = (1-q)^k gives
   sqrt(q/((1-q)s)) 2 sqrt(ks) e^{-ks} = 2 sqrt(kq)(1-q)^{k-1/2} = T_k = S_k.
4. *Conclusion (c), (d).* If C <= C(q), then R_n <= sqrt(q/((1-q)s)) max(g(lam+), g(lam-), C) <=
   sqrt(q/((1-q)s)) C(q) = M(q). Taking the sup over n, R(q) <= M(q), and R(q) >= M(q) by the OR_k test functions.
   Only the existence of one theta for K = K_f is used, so RQ-A's K-dependent form ID*(C) suffices.
5. *The minimum (U.2, (d)).* At q_k: 1 - q_k = sqrt((k-1)/k), so s(q_k) = (1/2) ln(k/(k-1)).
   - The ratio g(ks)/g((k-1)s) = sqrt(k/(k-1)) e^{-s} equals 1 at s = s(q_k).
   - (k-1)s(q_k) < 1/2 < k s(q_k), because x ln(1 + 1/x) < 1 and -k ln(1 - 1/k) > 1. Since g is unimodal with peak
     at 1/2, C(q_k) = g((k-1) s(q_k)) = g(k s(q_k)).
   - On [q_{k+1}, q_k] the maximiser is k, and ln g(ks) is concave in s. So the minimum of C on that band is at an
     end.
   - (k-1) s(q_k) = (1/2)(k-1) ln(1 + 1/(k-1)) increases to 1/2, and g increases on (0, 1/2). So C(q_k) increases in
     k, and the minimum over (0, q_K] is C(q_K).
   - RQ-B's form sqrt(2/e)/(1 + E_{K-1}) is the same number: Proposition 5.1 (A.10c) gives B/M = 1/max_k g_B(ks)
     with g_B = sqrt(e/2) g.
   - As K -> oo, eta_K = sqrt(2/e) - C(q_K) ~ sqrt(2/e) h^2 with h = 1/2 - (K-1) s(q_K) ~ 1/(4(K-1)). So
     eta_K ~ sqrt(2/e)/(16 K^2), as both solvers state.
6. *(e).* g <= g(1/2) = sqrt(2/e), so E|Z_K| <= sqrt(2/e) for every finitely supported K on R \ {0}. Such K are
   weakly dense among Kolmogorov probability measures, and E|Z_K| is continuous along weakly convergent K of mass 1,
   since E Z^2 = 1 gives uniform integrability. This density step is the one already used for C7 (A.8); RQ-B's
   one-line "(e)" leaves it implicit.
7. *Remarks of RQ-B.*
   - Remark 4.5(2), tightness along delta_a for a >= max(theta, 1): E|Z_{delta_a}| = a E|N_l - l| with l = 1/a^2 <= 1,
     which is 2 a l e^{-l} = g(l). Correct.
   - Remark 4.5(3), "theta <= 1.318 is necessary": the argument (a Dirac below theta has lam+- = 0) excludes exactly
     theta > 1/sqrt(4 s(q4)) = 1.3183436. So the decimal should read 1.3183 or more; 1.318 overstates the
     necessary condition by 3.4e-4. This is a remark, not part of (a)–(e).
   - RQ-C's C16 (A.29) gives the much stronger necessary condition theta < theta_max(eta) for a fixed theta.

**A fix in RQ-A's CONDITIONAL U.3** (not a PROVED claim, but a stated implication). U.3 says "With MAIN-1..4: ID*(0.853344)
implies Conjecture S for all q". But 0.853344 is C_4 = 0.853343568… rounded *up*. With C = 0.853344, step 4 needs
C(q) >= 0.853344. For q just below q4, C(q) = g(4 s(q)) < 0.853344, so the implication says nothing on
(q*, q4) = (0.13397376, 0.13397460), an interval of length 8.4e-7. MAIN-1..4 start at q4 and do not cover it.
- **f1:** state U.3 with C_4 itself, or with any decimal <= 0.8533435.
- The constants for MAIN-5 and MAIN-6 are rounded down (C_5 = 0.855100455 >= 0.855100, C_6 = 0.855984489 >= 0.855984)
  and are fine.
- RQ-B's statement uses the exact C_K and is fine.

**Independent checks (RQ-AUD code only).**

| script | what it checks | result |
|---|---|---|
| `audit/uniform/a26_constants.py` (256-bit Arb) | s(q_K), the tie g((K-1)s) = g(Ks), (K-1)s < 1/2 < Ks and RQ-B's E_{K-1} form for K = 2..12; C(q_K) increasing; C_4, C_5, C_6 and eta_K to the quoted digits; eta_K 16(K-1)^2/sqrt(2/e) = 0.8987, 0.98999, 0.99900, 0.99990 for K = 10^1..10^4; min of C on a 4,000-point grid of (0, q_K] is C(q_K) for K = 4, 5, 6; RQ-B Remark 4.5 constants | PASS (109 PASS lines in all, shared with A.27–A.29) |
| `audit/uniform/a26b_semantic.py` S1 | (a) on 89 random [0,1]-valued and Boolean f (n <= 4, q in {0.05, 0.1, 0.13, 0.2, 0.3}), with E\|Z_{K_f}\| by direct Poisson enumeration; lam+- = s k+- for five theta; the Stein–Chen identity to 6.4e-16; (a) is an equality at f = OR_k when ks <= 1; (b) in ball arithmetic for k <= 14 | PASS (min slack in (a): -2.2e-16, rounding) |
| `audit/uniform/a26c_u3_gap.py` | the gap of U.3 with 0.853344: q* = 0.133973760, q4 - q* = 8.358e-7 | finding f1 |

The equality of (a) at OR_k is worth noting. The Poissonisation loses nothing at the conjectured extremisers, so it
is a reduction of Conjecture S, not a weakening of it.

**Verdict: VALID** for U.1, U.2 and C19 (a)–(e). The CONDITIONAL U.3 needs the text fix f1. There is a remark on RQ-B's
"theta <= 1.318".

**Novelty: NEW** (no source found). It is a reduction of Conjecture S for all q <= q_K, uniform in k, to one q-free
inequality about compound Poisson laws, and it does not settle any new value of R. It refines A.10a: the
Poissonisation is kept per configuration, and the jump counts are quantised in s Z. The hypothesis contains C5, which
is open.

### Fix f1 posted and remark applied (2026-10-22 16:55 UTC)

- **RQ-A, CLAIMS 3a8a0c64… (mirrored 16:33).**
  - U.3 now reads "ID*(C(q_4)) implies Conjecture S for all q; any decimal C <= 0.8533435 may be used in place of
    C(q_4) (C must not exceed C(q_4) …)". This is f1.
  - U.2 now gives C(q_K) and eta_K to ten digits, truncated, and says that a margin eta used in place of eta_K must
    be >= eta_K, with the examples 0.00443, 0.00267 and 0.00178.
  - Nothing else in CLAIMS changed; in particular the MAIN-5 section is byte-identical.
- **RQ-B, CLAIMS e7973f59…, MAIN_RESULT md/tex and AUDIT_REQUEST (16:28).** Remark 4.5(3) now reads
  "theta <= a_4 = 1/sqrt(4 s(q4)) = 1.3183436 is necessary", and the Dirac range of Remark 4.5(2) is
  [1.3183436, 1.5222920].
- Checked by `audit/uniform/a26d_fix_check.py` (256-bit Arb, output `outputs/a26d_fix_check.txt`): ALL CHECKS PASSED
  (23 PASS lines, 0 FAIL).
  - C(q_4) = 0.853343568496…, C(q_5) = 0.855100455470… and C(q_6) = 0.855984489173…
  - eta_4 = 0.004420316464…, eta_5 = 0.002663429489… and eta_6 = 0.001779395786…
  - All six quoted decimals are correct truncations. Each margin is >= eta_K, and each example C is <= C(q_K).
  - 0.853344 > C(q_4), so the fix was needed. Every 7-place decimal <= C(q_4) is <= 0.8533435.
  - 1/sqrt(4 s(q4)) = 1.31834356235…, so 1.3183436 is correctly rounded, and 1.318 fell short of it by 3.4e-4. The
    exact expression is the one stated, so the rounding direction does not matter.
- **A.26 is VALID with nothing outstanding**: U.1, U.2, U.3 as an implication, and C19 (a)–(e) with its remarks.

### Addendum 2: RQ-B's C19 text changes after A.26 confirmed (2026-10-22 20:37 UTC)

**Sources.** RQ-B rq/AUDIT_REQUEST 8ce749f5… §6 ("C19 text changes after A.26 (please confirm; no new mathematics)"),
rq/MAIN_RESULT.md 0ff2462b… (Theorem 3.4 and its remarks, lines 175–235; intro lines 30–41), MAIN_RESULT.tex 4a5770df…
(lines 94, 293–302, 348–349) and rq/CLAIMS 678033cb… (C19, lines 221–231). At 20:35 RQ-B's files sit in the store
under `RQ-B/rq/` (the root of RQ-B now holds only `README.md`, `mirror.sh`, `notes/`, `numerics/`, `rq/`, `uploads/`);
CLAIMS and AUDIT_REQUEST are byte-identical to my 20:18 snapshots.

The four announced changes, each checked in md, tex and CLAIMS:
1. **Remark 3 and Remark 2.** "theta <= a_4 = 1/sqrt(4 s(q4)) = 1.3183436 is necessary", and the Dirac range is
   [a_4, b_4] = [1/sqrt(4 s(q4)), 1/sqrt(3 s(q4))] = [1.3183436, 1.5222920]. Arb gives a_4 = 1.31834356235… and
   b_4 = 1.52229202121…; both decimals are correctly rounded and the exact expressions are stated. This was already
   confirmed at 16:55; the text is unchanged since.
2. **theta = theta(f) in (c), theta = theta(K) in (d).** (c) asks for some theta(f) > 0 per f, and (d) defines ID*(C)
   with theta(K), with (ID-theta, C) as the stronger one-theta form. The proof of (d) adds "(b) holds for every
   theta, so the proof of (c) applies". This is exactly step 4 of A.26: the hypothesis is used only at K = K_f, and
   the quantisation lam+- in sZ holds for every theta. Remark (1) says that ID*(C_4) implies Conjecture S, with
   ID*(C_5) or ID*(C_6) after RQ-A's k = 4 (resp. k = 4, 5) covers. That is an implication from audited pieces
   (A.25 for k = 4; the k = 5 cover is not yet filed), so its wording is fine. The citation of RQ-C's C16 for the
   failure of the one-theta form (theta_max = 0.9594 for C_4) is correct as a failure statement: theta_max is
   decreasing in eta, so theta_max(eta_4) <= theta_max(0.0044) = 0.95938 < 0.9594 (A.29).
3. **(e)** now spells out the density step: finitely supported laws are weakly dense among mean-zero, variance-one ID
   laws, and E|Z_K| is continuous along weakly convergent K of mass 1 by uniform integrability. This is A.26 step 6.
4. **Constants.** C_4 = 0.85334356…, C_5 = 0.85510045…, C_6 = 0.85598448…, with "a decimal C may replace C_K only if
   C <= C_K (e.g. 0.8533435, 0.855100, 0.855984)". The intro bullet (md line 36, tex line 94) no longer says
   0.853344.

`audit/uniform/a26e_c19_text_check.py` (256-bit Arb, md5 1788e61b…, output `outputs/a26e_c19_text_check.txt`, 0.07 s):
ALL CHECKS PASSED (24 PASS lines).
- C_4 = 0.853343568496…, C_5 = 0.855100455470…, C_6 = 0.855984489173…; the three 8-digit truncations and the three
  example decimals are all <= C_K.
- sqrt(2/e) - C_K = 0.00442031646…, 0.00266342948…, 0.00177939578…; RQ-B's 0.0044203, 0.0026634 and 0.0017794 are
  correctly rounded. The last is rounded up, which is the safe direction for a margin.
- The tie g((K-1) s(q_K)) = g(K s(q_K)) holds to 1e-70 for K = 4, 5, 6, and 3 s(q4) < 1/2 < 4 s(q4).

Cosmetic (no change needed): Remark (2) says "g(x) >= C_4 iff x in [0.4315, 0.5754]". The exact set is
[3 s(q4), 4 s(q4)] = [0.43152310…, 0.57536414…]; the quoted endpoints are correctly rounded to 4 places and the quoted
interval contains the exact one, so the "iff" holds only up to rounding. The remark goes on with the exact range
[a_4, b_4], which is what matters.

**A.26 stays VALID**, with nothing outstanding.

## A.27 RQ-B C20 (Theorem 1.2: equal-coefficient competitors for all k, q <= q4) — VALID (2026-10-22 16:14 UTC); novelty corrected to KNOWN (2026-10-23 01:29 UTC)

**Claim.** For K >= 4, q in (0, q_K] and every k >= 1: E|chi_1 + ... + chi_k|/sqrt k <= M(q), with equality iff kq < 1
and k maximises T_k. For kq >= 1 the left side is <= r_1/sqrt(1-q) < M(q), with r_1 = 2 (3/2)^{3/2} e^{-3/2}.
Since (0, q_K] is inside (0, q4], the statement is really about q <= q4.
Sources: RQ-B `rq/MAIN_RESULT.md` §1 Theorem 1.2 (tex Theorem 2.3), CLAIMS C20, AUDIT_REQUEST §5.

**Rebuilt proof.**
1. *kq < 1.* E(kq - S)_+ = kq P(S = 0) = kq (1-q)^k for S ~ Bin(k, q), so E|S - kq| = 2kq(1-q)^k. Dividing by
   tau sqrt k gives 2 sqrt(kq)(1-q)^{k-1/2} = T_k = S_k <= M. Equality holds iff k maximises.
2. *Bernoulli(q) <=_cx Poisson(q).* The means agree. For the stop-loss transforms:
   - for t <= 0 both are q - t;
   - for t >= 1 the Bernoulli one is 0;
   - for t in [0, 1], E(N_q - t)_+ = q - t + t e^{-q} >= q - t + t(1-q) = q(1-t) = E(X - t)_+.
   The order is closed under independent sums (condition on one summand at a time), so Bin(k, q) <=_cx Poi(kq).
   This is Hoeffding's classical comparison.
3. *kq >= 1.* E|S - kq| <= E|N_{kq} - kq| <= r_1 sqrt(kq), by Remark 3.3 (audited in A.15: r_m decreases for m >= 1,
   and f_m peaks at m + 1/2). So the left side is <= r_1 sqrt(kq)/(tau sqrt k) = r_1/sqrt(1-q).
4. *Strictness.* sqrt(1-q) M(q) = sqrt(q/s) C(q). Here q/s(q) is decreasing, because s/q = sum q^{j-1}/j increases,
   and C(q) >= C_4 on (0, q4] (A.26). So sqrt(1-q) M(q) >= gamma_4 = sqrt(q4/s(q4)) C_4 = 0.82355716 > r_1 =
   0.81983256, with margin 0.0037.

**Independent checks.**
- `a26_constants.py` part 2 checks r_1, gamma_4, gamma_5 = 0.83179 and gamma_6 = 0.83684 to the quoted digits, the
  margin, the monotonicity of q/s on a grid, and RQ-B's remark that sqrt(1-q3) M(q3) = 0.80775 < r_1 (the
  argument does not reach [q4, 1/2]).
- `a26b_semantic.py` S2 checks the statement itself in exact rationals, by direct binomial sums:
  - 21,993 pairs (q, k) with q in (0, q4] on two grids (j/1000 and 1/d) and k <= 300 (k <= 6/q + 2);
  - E|sum chi|^2/k <= M(q)^2 holds in every case;
  - all 164 equality cases have kq < 1 and k maximising, and r_1^2/(1-q) bounds every kq >= 1 case (ball
    arithmetic);
  - de Moivre's formula agrees on every kq >= 1 case with k <= 120.
- **Remark** (no fix): "gamma_4 = 0.8235571" is truncated (0.82355716 rounds to 0.8235572). As a lower bound it is
  correct, which is the direction the proof uses.

**Verdict: VALID** (no fix needed). **Novelty: KNOWN** (corrected 2026-10-23 01:29 UTC; at 16:14 this said "NEW as
stated (elementary)"). The ingredients are KNOWN: Hoeffding's Bin <=_cx Poisson, de Moivre's mean deviation, and
Remark 3.3 (A.15). On [q4, 1/2] it is contained in Theorems 1–4.

**Novelty correction (2026-10-23 01:29 UTC).** The 16:14 rating was wrong.
- The statement, sup_k E|chi_1 + ... + chi_k|/sqrt(k) = M(q) attained at k = N(q), is Stone's equal-coefficient
  theorem: thesis UCI 2025, Thm 4.3.1, for every p <= 1/2. It is quoted as (1.10) of Ivanisvili–Stone
  (arXiv:2407.04835), proved in their reference [12].
- I rely on RQ-C's reading of the thesis (SOTA K5), because my VM cannot download it. A.15 had already recorded RQ-B's
  Theorem 1 as Stone's theorem.
- RQ-B's proof is different from Stone's and elementary.
- NEW as stated (minor): only the explicit bound r_1/sqrt(1-q) for kq >= 1, and the strict inequality it gives there.
- A.27 is not a link of the all-q chain (A.40), so nothing else changes.

## A.28 RQ-C C15 (finite-q localisation of maximisers) — VALID, NEW (2026-10-22 16:14 UTC)

**Claim** (RQ-C CLAIMS C15, text unchanged from 715a241b… to 3b854357…). At a maximiser alpha of E|L| on the unit sphere of R^n:
- (a) P(L = 0) = 0 and E[chi_i sgn L] = R_n alpha_i;
- (b) R_n u alpha_i = 2(1-q) P(-alpha_i u < L' < alpha_i v) <= 2 p-, for alpha_i > 0, and symmetrically for
  alpha_i < 0;
- (c) the stop-loss bounds E[(L + a)_+; L < 0], E[(a - L)_+; L > 0] <= delta/(2q) + R a^2/(4(1-q));
- (d) p-+^2 <= R(R_n + delta/q)/(2(1-q)), and R_n^2 <= 4 p+ p-;
- (e) u|alpha_i| <= Lambda_n -> sqrt(2/(1-q));
- (f) consequently RQ-A's q-free hypothesis is needed only for K on [-A, A], for any A > A'(q) = sqrt(2q/s)/(1-q);
- (g) A' increases in q, with the quoted values.

**Rebuilt proof.**
- (a) phi(t) = E|L + t chi_i| <= R_n |alpha + t e_i| =: G(t), with equality at t = 0, and phi is convex. So
  G'(0) <= phi'_-(0) <= phi'_+(0) <= G'(0) = R_n alpha_i. Then phi'_+ - phi'_- = 2 E[|chi_i|; L = 0] = 0, and
  |chi_i| >= min(u, v) > 0.
- (b) L' is independent of chi_i, and qu = (1-q)v = tau. For alpha_i > 0, sgn(x + alpha_i u) - sgn(x - alpha_i v)
  is 2 on the open interval and 1 at its two ends. The ends are null, since P(L' = -alpha_i u) =
  P(chi_i = u, L' = -alpha_i u)/q <= P(L = 0)/q = 0. Multiplying by u uses tau u = 1-q. On {chi_i = -v} (probability
  1-q, independent of L'), L < 0 whenever L' < alpha_i v; this gives <= 2 p-.
- (c) Append an independent chi with coefficient beta; then E|L + beta chi| <= R sqrt(1 + beta^2) <= R(1 + beta^2/2).
  - I checked the two identities |x + a| - |x| = a(1 - 2 1{x<0}) + 2(x+a)_+ 1{x<0} and
    |x - b| - |x| = b(1 - 2 1{x>0}) + 2(b-x)_+ 1{x>0} case by case.
  - The linear terms cancel because qa = (1-q)b = tau beta and p+ + p- = 1.
  - Then beta^2 = a^2 q/(1-q).
- (d) H(a) >= a p- - R_n/2. Maximising a p- - R a^2/(4(1-q)) at a = 2(1-q) p-/R gives (1-q) p-^2/R. The last bound
  is Cauchy–Schwarz on E[L(1{L>0} - p+)], with E L^2 = 1.
- (e) Combine (b) and (d). As n -> oo, R_n -> R and delta -> 0.
- (f) A maximiser f* of |Delta(f)| gives the unit vector alpha* = Delta(f*)/|Delta(f*)|, with R_n <= 2 tau |Delta(f*)|
  <= E|alpha* . chi| <= R_n. So (a)–(e) apply to alpha*, and K-tilde = K_{f*} has atoms alpha*_i/sqrt s, with
  |alpha*_i| <= Lambda_n/u. The contradiction argument works because R_n -> R and the support bound converges.
- (g) d/dq ln A'^2 = 1/q - 1/((1-q)s) + 2/(1-q) > 0 iff s(1+q) > q, which holds since s > q. A'(q) -> sqrt2 as q -> 0.
  At OR_k with q = q_{k+1}, K-tilde = delta_a with a = (k s(q_{k+1}))^{-1/2} = sqrt(2/(k ln(1 + 1/k))).

**Independent checks.**
- `a26_constants.py` part 3 checks A'(0.05), A'(q6), A'(0.1), A'(q5), A'(q4) = 1.46976, 1.51455, 1.53085, 1.53804,
  1.57599 and the OR_4 atom 1.49690 at q5, with a = 1/sqrt(4 s(q5)) exactly. It also checks that A' is monotone on a
  grid, and that (a_k/sqrt2 - 1) 4k -> 1 (0.9723, 0.9971, 0.99971 for k = 10, 100, 1000).
- `a26b_semantic.py` S3 takes maximisers found numerically for n = 3, 4, 5 and q in {0.14, 0.2, 0.3, 0.45}, where
  R = M is audited (A.6–A.18), and in each case R_n = M(q) to 1e-10. It checks:
  - (a) to 4e-8 and (b) to 6e-8;
  - (c) on a 60-point grid of a (min slack 2.6e-5);
  - (d) and (e) hold.
  - The bound in (b) is attained at OR_k (slack -3e-8, optimiser accuracy), as RQ-C says.

**Verdict: VALID** (no fix needed). **Novelty: NEW** (no source found). It is the finite-q analogue of RQ-B's
Lemma 8.2 and Proposition 8.3 (A.13a), and the variational technique is standard. Its content for the plan: any band/far
split for q <= q_K must allow atoms up to A'(q_K) (1.538 for q <= q5, 1.576 for q <= q4), beyond RQ-B's 99/70.

## A.29 RQ-C C16 ((ID-theta) with theta fixed fails for theta > theta_max(eta)) — VALID WITH FIXES (text only), NEW (2026-10-22 16:14 UTC); VALID after the fix (16:24 UTC)

**Claim** (RQ-C CLAIMS C16, 715a241b…; the 15:57 version 3b854357… adds the scope sentence: theta fixed, as posed at
15:20; RQ-A's K-dependent theta is not affected). Let C = sqrt(2/e) - eta, let a* > sqrt2 solve g(1/a*^2) = C, and let
theta_max = 2/(a*(1 + sqrt(1 - 2/a*^2))). Then for every theta in (theta_max, a*) some two-atom K = (1-eps) delta_a +
eps delta_b, with a in (theta, a*) and b in (theta_max, theta), violates (ID-theta). The claim also gives a table of
a* and theta_max, the inverse thresholds, and certified instances.

**Rebuilt proof.**
- (i) If a >= theta > b > m = (1-eps)/a + eps/b, every jump exceeds the compensator m. So Z_K < 0 iff there is no
  jump, and E|Z_K| = 2 m e^{-lambda}, with lam+ = (1-eps)/a^2 and lam- = 0.
- (ii) I redid the derivative: d/deps [2 m e^{-lambda} - g((1-eps) lambda_0)] at eps = 0 is
  e^{-lambda_0}(2 sqrt(mu) - 2 mu sqrt(lambda_0) - sqrt(lambda_0)) = -(e^{-lambda_0}/sqrt(lambda_0))(2x^2 - 2x + lambda_0),
  with x = 1/(ab). It is positive iff b is strictly between b-(a) and b+(a).
- (iii) g(1/a^2) > C for a in (sqrt2, a*). b-(a*) = theta_max < theta. b+(a) > a, since a(1 - sqrt(1 - 2 lambda_0))
  < 2/a. b > b-(a) > 1/a = m(0), so (i) applies for small eps. For small eps > 0 the maximum is g(lam+), by
  continuity.
- RQ-C's 15:57 scope remark is also correct. If theta <= b, both atoms count, lam+ = lambda, and Cauchy–Schwarz
  m^2 <= lambda gives 2 m e^{-lambda} <= g(lambda). So these K do not contradict RQ-A's ID*.

**Independent checks.**
- `a26_constants.py` part 4 (Arb, certified bisection with rational brackets) gives a* = 1.44906, 1.48159, 1.49749,
  1.52203, 1.56997 and theta_max = 1.13318, 1.03987, 1.00506, 0.95938, 0.88820 for eta = 0.0005, 0.0018, 0.0027,
  0.0044, 0.0087. The inverse thresholds are eta < 0.0028567 (theta = 1.0), 0.0078156 (0.9) and 0.018254 (0.8). The
  quoted 0.00286, 0.00782 and 0.0183 are roundings of these.
- It also recomputes all seven certified instances, with the parameters of RQ-C's output
  `numerics/out/idtheta/threshold.out` for the two that CLAIMS does not list. All seven satisfy a >= theta > b > m
  and violate (ID-theta).
- `a26b_semantic.py` S4 checks the closed form against direct Poisson enumeration (error 8e-16).
- **f1 (text).** Two certified margins in CLAIMS are rounded *up* and are false as written:
  - theta = 1.0, eta = 0.0044: "E|Z_K| - g(lam+) >= 1.44·10^-4"; the value is 1.43926·10^-4, as RQ-C's own output
    also shows;
  - theta = 1.2, eta = 0.0005: "excess >= 9.8·10^-5"; the value is 9.7558·10^-5.
  - The corrected bounds 1.43·10^-4 and 9.7·10^-5 pass. Both instances remain counterexamples.
- **Remark.** In "Below the thresholds … (theta = 0.95, eta = 0.0044: best -7.4·10^-6)", the number is E|Z| - C. The
  binding quantity E|Z| - max(g(lam+), C) is -1.69·10^-5. The conclusion (no violation) is the same.

**Verdict: VALID WITH FIXES** (text only, f1). **Novelty: NEW.** It is a negative result about a proof plan: a fixed
theta must be < theta_max(eta), 0.9594 for q <= q4. The closed form is RQ-B Prop. 6(a) (A.10d).

**Re-rated VALID (2026-10-22 16:24 UTC).** RQ-C applied f1 at 16:20 (CLAIMS a452bb78…, AUDIT_REQUEST f2a1ada3…;
copies `audit/snapshots/RQ-C_*_1623.md`). C16 now quotes E|Z_K| - g(lam+) >= 1.43·10^-4 and excess >= 9.7·10^-5. Both
are below my certified values 1.43926·10^-4 and 9.7558·10^-5 (`a26_constants.py` checks the corrected bounds: PASS).
The "below the thresholds" line now quotes the binding quantity, -1.69·10^-5 at theta = 0.95, eta = 0.0044; my value
is -1.69006·10^-5. The value -9.6·10^-6 at theta = 1.0, eta = 0.0027 was already the binding quantity. No other line
of C16 changed (diff against the 15:57 snapshot).

## A.30 RQ-D D1 (flip formula) and D2 (OR-region identity with a residual) — D1 VALID; D2 VALID WITH FIXES; KNOWN in kind / NEW as stated (2026-10-22 16:14 UTC)

**Sources.** RQ-D CLAIMS.md (68450a97…), MAIN_RESULT.tex Lemmas 1–2 (0ac23953…). RQ-D's STATUS says "nothing
submitted for audit yet", but both claims are tagged PROVED, so they are audited here.

**D1.** For y != 0: |y + w| = |y| + sgn(y) w + 2(-sgn(y) w - |y|)_+. Hence E|Y + W| = E|Y| + 2E[(-sgn(Y) W - |Y|)_+]
for independent Y, W with finite first moments, E W = 0 and P(Y = 0) = 0.
- Rebuilt: write y = s|y|, so y + w = s(|y| + s w), and split on the sign of |y| + s w.
- E[sgn(Y) W] = E sgn(Y) · E W = 0.
- Checked exactly on 20,000 random rational pairs (`a26b_semantic.py` S5).
- **VALID.** KNOWN in kind (elementary).

**D2.** The setting is K = K_S + K_R with K_S carried by [theta, oo), Lambda = int x^{-2} dK_S, m = int x^{-1} dK_S
and theta > m. With Y = Z_{K_S} and W = Z_{K_R} independent:
E|Z_K| = 2 m e^{-Lambda} + 2 e^{-Lambda} E(W - m)_+ + 2 E[(-W - Y)_+; N_S >= 1]. Also 2 m e^{-Lambda} <= sqrt(2/e) sqrt(V_S),
"with equality iff K_S is a single atom and Lambda = 1/2".

Rebuilt proof:
1. Y = sum_{j <= N_S} J_j - m, with N_S ~ Poisson(Lambda) and J_j >= theta.
2. So Y = -m on {N_S = 0}, and Y >= theta - m > 0 otherwise.
3. Hence E|Y| = 2m e^{-Lambda}.
4. D1, with independence of W and (Y, N_S), gives the identity.
5. Cauchy–Schwarz gives m^2 <= Lambda V_S, and 2 sqrt(Lambda) e^{-Lambda} <= sqrt(2/e).

Checks:
- The identity was checked on 40 random pairs (K_S, K_R) with one or two atoms each, by direct Poisson enumeration
  (max error 9.8e-15, `a26b_semantic.py` S5).
- The equality at K_S = delta_sqrt2 was also checked.
- **f1.** The equality clause is false for K_S = 0, which the statement allows (the zero measure is carried by
  [theta, oo), and theta > m = 0).
  - Then 2 m e^{-Lambda} = 0 = sqrt(2/e) sqrt(V_S), but K_S is not a single atom.
  - In the same case the proof's "P(Y = 0) = 0" fails, because Y = 0. The identity itself still holds: it reads
    E|W| = 2 E W_+.
  - Fix: assume K_S != 0.
- **Verdict: VALID WITH FIXES** (f1).
- **Novelty:** for K_R = 0 it is RQ-B Prop. 6(a) (A.10d). The residual form is elementary and NEW as stated (no
  source found).

The remark after Lemma 2 (a first-order tangency at x = 2m = sqrt2) is a heuristic and is not claimed. I checked its
arithmetic: the first-order cost 2 e^{-1/2}(x - m)/x^2 per unit residual mass equals the slack e^{-1/2}/sqrt2 exactly
at x = sqrt2, and (x - m)/x^2 is maximal at x = 2m.

### D2 re-rated VALID (2026-10-22 17:23 UTC): fix f1 is posted

- RQ-D CLAIMS.md 5802cb5d… (17:18, copy `audit/snapshots/RQ-D_CLAIMS_1722.md`), D2: "K = K_S + K_R with **K_S != 0**
  carried by [theta, oo), theta > m"; equality "in the first iff K_S is a single atom, in both iff
  K_S = V delta_{sqrt(2V)}".
- MAIN_RESULT.tex 4df86775… (17:19), Lemma 3 (the lemmas are renumbered): the same hypothesis, and the proof now says
  where K_S != 0 is used ("P(Y = 0) = 0 ... m > 0").
- The new equality clause, checked by hand:
  - With K_S != 0, m^2 <= Lambda V is an equality iff x^{-1} is K_S-a.e. constant, i.e. K_S is one atom.
  - g(Lambda) = sqrt(2/e) iff Lambda = 1/2. For K_S = V delta_x, Lambda = V/x^2, which is 1/2 iff x = sqrt(2V).
  - Then m = sqrt(V/2) and 2 m e^{-1/2} = sqrt(2/e) sqrt(V).
- **D2: VALID.** A.30 has nothing outstanding.

---

## A.31 RQ-A U.6 (one-signed K: exact form, the bound B(Lambda, rho^2), and ID* when lambda+_m(K) >= 1/2) — VALID; (a) KNOWN within the project, (b)–(c) NEW as stated (2026-10-22 17:23 UTC)

**Sources.**
- RQ-A CLAIMS.md 10de5cac… (17:02), U.6; copy `audit/snapshots/RQ-A_CLAIMS_1705.md`.
- NOTES_FOR_TEAM.md 436fbfa7… (17:05).
- I read RQ-A's outputs `sp_scarf_region.txt`, `sp_half_check.txt` and `sp_idstar_scan_J2.txt`. None of RQ-A's code
  is used.

### Claim

- **Setting.**
  - K is a finitely supported probability measure on (0, oo), m = m(K) = int x^{-1} dK, and theta >= m.
  - Lambda = lambda+_theta(K) = int_[theta, oo) x^{-2} dK, and rho^2 = K((0, theta)).
  - S_R is the sum of the jumps below theta, m_R = E S_R, and m_S = m - m_R.
- **(a)** E|Z_K| = 2 e^{-Lambda} E(m - S_R)_+ = 2 e^{-Lambda} [m_S + E(S_R - m)_+].
- **(b)** E|Z_K| <= B(Lambda, rho^2) := e^{-Lambda} [sqrt(Lambda (1 - rho^2)) + sqrt(rho^2 + Lambda (1 - rho^2))].
- **(c)** If lambda+_m(K) >= 1/2, then E|Z_K| <= g(lambda+_m(K)), with equality iff K is a single atom.
  - So ID*(C) holds for such K with theta = m(K), for every C.
  - The same holds for K carried by (-oo, 0), by reflection.
- **Not claimed.** "Scope and limits" (i)–(iii) and the NUMERICAL companions.

### Rebuilt proof (from the hypotheses)

1. Z_K = S - m, where S >= 0 is the sum of all jumps. The Levy measure x^{-2} K is finite because min supp K > 0.
   Since E Z_K = 0, E|Z_K| = 2 E(Z_K)_- = 2 E(m - S)_+.
2. On {N_S >= 1}, S is at least one jump >= theta >= m, so (m - S)_+ = 0. On {N_S = 0}, S = S_R.
   - N_S and S_R are independent: they are counts of a Poisson random measure on disjoint sets.
   - So E(m - S)_+ = P(N_S = 0) E(m - S_R)_+ = e^{-Lambda} E(m - S_R)_+.
   - (m - S_R)_+ = (m - S_R) + (S_R - m)_+ together with E S_R = m_R gives the second form.
3. (b): Let W = S_R - m_R. Then E W = 0 and E W^2 = int_(0, theta) x^2 x^{-2} dK = rho^2.
   - E(W - t)_+ = (E|W - t| - t)/2 <= (sqrt(rho^2 + t^2) - t)/2, by Cauchy–Schwarz.
   - S_R - m = W - m_S. With t = m_S: E|Z_K| <= e^{-Lambda} [m_S + sqrt(rho^2 + m_S^2)].
   - This is increasing in m_S >= 0, and m_S = int_[theta, oo) x^{-1} dK <= sqrt(Lambda K([theta, oo))) =
     sqrt(Lambda (1 - rho^2)), by Cauchy–Schwarz.
4. (c): Take theta = m and h(t) = sqrt(Lambda (1 - t)) + sqrt(t + Lambda (1 - t)). Then
   2 h'(t) = (1 - Lambda)/sqrt(t + Lambda (1 - t)) - Lambda/sqrt(Lambda (1 - t)).
   - For Lambda >= 1/2 this is < 0 on (0, 1), because 1 - Lambda <= Lambda and t + Lambda (1 - t) > Lambda (1 - t).
   - Also rho^2 < 1, because Lambda > 0.
   - So B = e^{-Lambda} h(rho^2) <= e^{-Lambda} h(0) = g(Lambda), with equality only at rho^2 = 0.
5. Equality case.
   - At rho^2 = 0, E|Z_K| = 2 m e^{-Lambda}, and m <= sqrt(Lambda) with equality iff K is one atom.
   - Conversely, delta_x has lambda+_m = x^{-2} if x >= 1 and 0 if x < 1, since m = 1/x.
   - So the single atoms under the hypothesis are delta_x with 1 <= x <= sqrt2, and E|Z_{delta_x}| = g(1/x^2) for them.
6. ID*.
   - ID*(C) lets theta depend on K, and m(K) > 0. So g(lambda+_m) <= max(g(lambda+_m), g(lambda-_m), C).
   - For the reflection, take K~(B) = K(-B). Then Z_{K~} = -Z_K and lambda-_theta(K) = lambda+_theta(K~).
7. Equality in (b) holds iff rho^2 = 0 and K is one atom. This is not stated, but my tests require it.
   - For rho^2 > 0, equality would need |W - t| to be a.s. constant. That is impossible, because a nondegenerate
     compound Poisson W with positive jumps has unbounded support.

### Independent verification (RQ-AUD code only)

The script is `audit/rqa/a31_u6_check.py`, with output `outputs/a31_u6_check.txt`.
- It runs in 33 s and prints 26 PASS lines, 0 FAIL and 1 REMARK.
- Atoms, weights, m, theta and all partial sums are exact Fractions, so every sign and every split x >= theta is
  decided exactly. Probabilities are 256-bit Arb.

| check | result |
|---|---|
| Evaluator E1: full enumeration, sign-free, Cauchy–Schwarz tail <= 2^-99 | 200 random K: agrees with E2 |
| Evaluator E2: the finite sum 2 E(m - S)_+ over {S < m} | used for (b) and (c) |
| (a), both forms, against E1 | 300 random (K, theta); theta = m, an atom above m, or m + U(0, 0.5) |
| (b) | 40,000 (K, theta) from 20,000 random K (1–5 atoms, residual mass <= 0.9, residual atoms >= 0.04): equality to 2^-200 in the 5,440 one-point cases, strict in the other 34,560 (smallest 3.6e-10, near a one-point K) |
| (c) | 12,074 K with lambda+_m >= 1/2: equality in the 2,304 one-point cases, strict in the other 9,770 |
| equality in (c) | delta_x at x = 1, 1.1, 1.2, 1.3, 1.4142, 1.41421356 and sqrt2 (E\|Z\| = g(1/x^2) to 2^-200) |
| hostile search (Nelder–Mead, 60 feasible starts per case, re-certified at rational points with the same big/residual split) | (c), rho^2 >= 0.01: sup of E\|Z_K\| - g(lambda+_m) = -0.00365 (2 and 3 atoms), at about 0.99 delta_1.002 + 0.01 delta_0.69, a big atom at x ~ m; (c), two atoms 0.05 apart with rho^2 = 0: -2.4e-5; (b): -1.1e-5 (rho^2 >= 0.01) and -6.4e-6 (two separated atoms). No violation. |
| negative test: theta < m | theta = 0.5 < m = 0.9487, atom 0.6 in [theta, m): (a) fails (0.81660 against 0.67812), so theta >= m is needed |
| scope (i) instance | 0.95 delta_1.4 + 0.05 delta_0.05: m = 1.679 > 1.4, lambda+_m = 0, E\|Z_K\| = 0.83611 > g(0) = 0 |

Scope (ii) is numerical and not claimed; I checked it anyway.
- h is concave in rho^2, as a sum of square roots of affine functions. So {B > c} is an interval, and its two
  endpoints decide each stated range.
- At Lambda = 0.49, 0.3 and 0.005, the stated ranges lie inside {B > max(g(Lambda), C(q5))}.
- Closed form: for 1/4 < Lambda < 1/2 with g(Lambda) > C, {B > g(Lambda)} = (0, 8 Lambda (1 - 2 Lambda)).
  - With s = sqrt(1 - t), h(t) = h(0) becomes s^2 - 4 Lambda s + 4 Lambda - 1 = 0, so s = 1 or s = 4 Lambda - 1.
  - This gives 0.0784 at Lambda = 0.49 and exactly 0.36 at Lambda = 0.45, both checked in Arb.
- **r1 (cosmetic).** CLAIMS says "[0.001, 0.36] at Lambda = 0.45". At rho^2 = 0.36, B = g(Lambda) exactly, so B > max
  fails at that endpoint.
  - RQ-A's own grid output (`sp_scarf_region.txt`) correctly gives [0.001, 0.359].
  - Write (0, 0.36), or [0.001, 0.359].

Scope (iii), F13: RQ-B's reflection counterexample is confirmed in `audit/rqb/f13_reflection_check.py` (see the store
log, 17:23).

### Verdict and novelty

- **VALID.** Remark r1 concerns only a NUMERICAL scope sentence, so no fix is needed.
- (a) is KNOWN within the project. It is A.30's D2 with the flip term zero, and for rho^2 = 0 it is RQ-B Prop. 6(a)
  (A.10d).
- (b) and (c) are NEW as stated. They are elementary, and I found no earlier source.
- Use for the project:
  - (c) settles the q-free target ID* only for one-signed K with lambda+_m(K) >= 1/2.
  - RQ-A's limits (i)–(iii) are correct. The tight window lambda+ < 1/2 and two-signed K stay open.
- r1 was applied at 18:00 (RQ-A CLAIMS 6b00a3e1…: "[0.001, 0.359] at Lambda = 0.45", with the closed form).

---

## A.32 RQ-D D6–D12 (comparison lemma, stop-loss bounds, band bound; Theorem 10, the band lemma for C5; Corollary 11) — VALID; Theorem 10 and Corollary 11 NEW, Lemma 4 NEW as stated (2026-10-22 18:17 UTC)

**Sources.**
- RQ-D CLAIMS.md 5802cb5d… (17:18; unchanged in the re-mirror of 18:06), D6–D12. Copy
  `audit/snapshots/RQ-D_CLAIMS_1722.md`.
- MAIN_RESULT.tex 4df86775… and .pdf f69703ee… (17:19): Lemmas 2–8, Remark 5, Proposition 9, Theorem 10,
  Corollary 11 and Section 5.1. Copy `audit/snapshots/RQ-D_MAIN_RESULT_1722.tex`.
  - The tex of 18:08 (d19dbf3c…, copy `RQ-D_MAIN_RESULT_1821.tex`) only adds text: Lemma 7(c), the choices
    (O1)–(O4) and a draft Section on Theorem B*. Everything audited here is byte-identical in it (store log, 18:23).
- AUDIT_REQUEST.md f99c2f3f… (17:18) and 92c8487c… (17:47).
  - The 17:47 version adds only an erratum: the md5 of `scripts/band_soundness.py` is now 5aad8159…, which matches
    the file.
  - This resolves my text nit of 17:24.
- I read RQ-D's recorded outputs `verify_band_S.txt` (00d374ef…) and `verify_band_B.txt` (4b010e6b…) for their
  counts. None of RQ-D's code is used or run.

### Claim

- **Setting.**
  - K is a Kolmogorov measure on R; its atom at 0 is the Gaussian part. Z_K is the centred infinitely divisible law
    with E Z_K^2 = K(R).
  - g(l) = 2 sqrt(l) e^{-l}, and T = sqrt(2/e) = g(1/2) = max g.
  - For K_S = K|[theta, A]: V = K_S(R), Lambda = int x^{-2} dK_S and m = int x^{-1} dK_S.
  - K_R = K - K_S, with a = K_R((0, theta)), b = K_R([-A, 0]) (the Gaussian part is in b), rho^2 = a + b and
    W = Z_{K_R}.
- **D6 (Lemma 2).** Let E W = 0 and E W^2 = rho^2. Then l(y) = E|y + W| is convex and 1-Lipschitz, and
  l(y) = y + 2E(-W - y)_+ = -y + 2E(W + y)_+. Also |y| <= l(y) <= sqrt(y^2 + rho^2), and E|Y + W| = E l(Y) for Y
  independent of W.
- **D7 (Lemma 4).** Let psi be C^1, with psi' absolutely continuous and psi'' nondecreasing and bounded. Let K be
  finitely supported, with T(x) >= x on supp K. Then E psi(Z_K) <= E psi(Z_{T#K}).
  - Remark 5: the lemma fails for psi = (w - t)_+.
  - Remark 5 also says that psi_{t,h} = (w - t + h)_+^2/(4h) is the smallest admissible majorant of (w - t)_+
    touching it at t + h. This part is "not used".
- **D8 (Lemma 6).** Put W_B = theta (N_{a/theta^2} - a/theta^2) + sqrt(b) G, W_C = A (N_{b/A^2} - b/A^2) + sqrt(a) G
  and chi_h(t) = (2h)^{-1} E(W_* - t + h)_+^2. Then:
  - (i) 2E(W - t)_+ <= chi^B_h(t) and 2E(-W - t)_+ <= chi^C_h(t);
  - (ii) both left sides are <= sqrt(t^2 + rho^2) - t;
  - (iii) chi is C^1, convex and nonincreasing in t;
  - (iv) chi is nondecreasing in a and in b, and chi^B is nondecreasing in theta.
- **D9 (Lemmas 7, 8).**
  - The chord and variance bounds for E phi(J).
  - The jump law of K_S has mean mu_1 = m/Lambda and variance (Lambda V - m^2)/Lambda^2.
  - (Lambda, m, V) satisfy F1–F5.
- **D10 (Proposition 9).** E|Z_K| <= e^{-Lambda}(m + c_B) + Lambda e^{-Lambda} O + m Lambda e^{-Lambda} +
  P_2(Lambda) c_C.
  - Here P_2 = 1 - e^{-Lambda}(1 + Lambda), c_B >= 2E(W - m)_+, c_C >= 2E(-W - (2 theta - m))_+ and
    O >= E l(J - m).
  - Equivalently, the bound is 2m e^{-Lambda} + e^{-Lambda} c_B + Lambda e^{-Lambda} O' + P_2 c_C, with
    O' >= 2E(-W - (J - m))_+.
  - No sign condition on theta - m is needed.
- **D11 (Theorem 10).** Let K be a probability Kolmogorov measure on [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10 or
  K([-sqrt2, -1]) >= 9/10. Then E|Z_K| <= sqrt(2/e).
  - For finitely supported K, equality holds only at delta_{+-sqrt2}.
  - The proof is computer-assisted, with theta = 1 and A = sqrt2.
- **D12 (Corollary 11).** Call {K([1, sqrt2]) < 9/10 and K([-sqrt2, -1]) < 9/10} the far region. If
  E|Z_K| <= sqrt(2/e) for every probability K on [-sqrt2, sqrt2] in the far region, then C5 holds.
- **Not claimed.** Section 6 (D13, the ID* band at theta = 0.85, NUMERICAL), D14 and D15.

### Rebuilt proof (from the hypotheses)

1. **Lemma 2.**
   - l is an average of the convex 1-Lipschitz maps y -> |y + w|.
   - The two identities follow from |u| = u + 2(-u)_+ = -u + 2u_+ and E W = 0.
   - Jensen gives |y| <= l(y), and Cauchy–Schwarz gives l(y) <= sqrt(y^2 + rho^2).
   - E|Y + W| = E l(Y) is Fubini.
2. **Lemma 4, Step 1** (psi in C^2, |psi''| <= M).
   - D_x psi(z) = int_0^1 (1 - u) psi''(z + ux) du is nondecreasing in x, because psi'' is.
   - D_0 psi = psi''/2 is the Gaussian generator, and D_x psi is continuous in x. So T may send atoms to 0, as
     Lemma 6 does: the pushed mass becomes Gaussian.
   - Let Phi(s) = E psi(X + Z_{sL}). Since Z_{(s+delta)L} = Z_{sL} + Y_delta, Taylor's formula with integral remainder
     splits into the events of no jump, one jump and at least two jumps.
   - The last event contributes O(delta^2), by the bound M Y^2/2 and Poisson moments.
   - So the right derivative is E (G_L psi)(X + Z_{sL}), with G_L psi = sum_x L({x}) D_x psi. It is continuous in s
     (bounded continuous integrand, weakly continuous law), so Phi is C^1.
   - Let Psi(t) = E psi(Z_{(1-t)K} + Z'_{tK'}), with K' = T#K. The two partial derivatives are jointly continuous, so
     Psi'(t) = sum_x K({x}) E[D_{T(x)} psi - D_x psi](...) >= 0.
3. **Lemma 4, Step 2.**
   - psi_eps = psi * phi_eps has psi_eps'' = psi'' * phi_eps, which is nondecreasing and bounded.
   - psi' is Lipschitz, so |psi_eps - psi| <= eps C (1 + |w|), and E|Z| < oo gives the limit.
4. **Remark 5.**
   - The counterexample is exact: E(Z_{delta_sqrt2})_+ = T/2, while E(Z_{delta_2})_+ = g(1/4)/2 = e^{-1/4}/2 < T/2.
   - The minimality paragraph is not used, but I rebuilt it, and it is correct:
     - psi'' >= 0, because psi is bounded below.
     - psi'' dv on (u*, h) is a probability with a nondecreasing density, i.e. a mixture of uniform laws on [s, h].
     - For V ~ U[s, h], E max(V, w) = F_w((s + h)/2). F_w is C^1, convex and nondecreasing (checked by hand).
     - Jensen and E_mu V = psi(u*) >= 0 give psi >= psi_{0,h} on [max(u*, -h), h]. Monotonicity extends this to the
       left of u*.
     - For w > h: a nondecreasing density bounded by c = psi''(h-), with mass 1 and nonnegative mean, forces
       c >= 1/(2h).
5. **Lemma 6.**
   - (i): psi_{t,h} >= (w - t)_+. Apply Lemma 4 with T = theta on (0, theta) and T = 0 on [-A, 0]. Then
     T#K_R = a delta_theta + b delta_0 and Z_{T#K_R} = W_B; the Gaussian part is in b, and T(0) = 0.
   - The C side follows by reflection. K~(B) = K_R(-B) is carried by (-theta, A]. Take T = A on [0, A], including
     the reflected Gaussian atom, and T = 0 on (-theta, 0).
   - (ii): 2E(W - t)_+ = E|W - t| - t, then Cauchy–Schwarz.
   - (iii): differentiate under E.
   - (iv): Jensen with an independent centred Poisson or Gaussian summand.
6. **Lemmas 7 and 8.**
   - 7(a) is convexity, and 7(b) is Taylor with Gamma'' <= kappa.
   - The jump law nu_S/Lambda has mean m/Lambda and second moment V/Lambda.
   - F1–F5 come from integrating pointwise inequalities on [theta, A] against K_S. F5 is
     (x^{-1} - A^{-1})(theta^{-1} - x^{-1}) >= 0, and F4 is Cauchy–Schwarz.
7. **Proposition 9.**
   - Z_K = Y + W with Y = S_{N_S} - m. So E|Z_K| = sum_n P(N_S = n) E l(S_n - m), by Lemma 2 and conditioning on N_S.
     This step uses no relation between theta and m.
   - n = 0: l(-m) = m + 2E(W - m)_+.
   - n = 1: the term is Lambda e^{-Lambda} E l(J - m).
   - n >= 2: S_n - m >= 2 theta - m, and y -> E(-W - y)_+ is nonincreasing, so l(S_n - m) <= S_n - m + c_C.
   - sum_{n>=2} P(N_S = n) E(S_n - m) = E Y + m e^{-Lambda} - Lambda e^{-Lambda}(mu_1 - m) = m Lambda e^{-Lambda},
     using E Y = 0 and Lambda mu_1 = m.
   - Second form: E l(J - m) = mu_1 - m + 2E(-W - (J - m))_+, and
     e^{-Lambda} m + Lambda e^{-Lambda}(mu_1 - m) + m Lambda e^{-Lambda} = 2m e^{-Lambda}.
8. **Theorem 10, rho^2 = 0.**
   - Then K = K_S on [1, sqrt2], and delta_1 gives 2/e < T.
   - Otherwise m < 1 = theta. Lemma 3 with K_R = 0 gives E|Z_K| = 2m e^{-Lambda} <= g(Lambda) <= T, with equality
     iff K = delta_sqrt2.
9. **Theorem 10, 0 < rho^2 <= 1/10.**
   - Use Proposition 9 (second form) with c_B = min(chi^B_h(m), CS(m)) and c_C = min(chi^C_h(2 - m), CS(2 - m)).
     Here CS(t) = sqrt(t^2 + rho^2) - t.
   - O' is the chord on [1 - m, sqrt2 - m] of the convex function phi(y) = 2E(-W - y)_+. Its endpoint values are
     bounded by min(chi^C_h, CS), and its weight is w1 = (mu_1 - 1)/(sqrt2 - 1), in [0, 1].
   - So E|Z_K| <= F(a, b, Lambda, m), and F < T on the feasible set by the certified computation below.
   - The inequality is strict, so there is no equality case with rho^2 > 0.
10. **General K.**
    - Take finitely supported K_n in the band with K_n -> K weakly, using cells inside [1, sqrt2] and inside
      [-sqrt2, 1).
    - Z_{K_n} -> Z_K in law, because the integrand of the Levy–Khintchine exponent is bounded and continuous.
    - E Z^2 = 1 gives uniform integrability, so E|Z_{K_n}| -> E|Z_K|.
11. **Corollary 11.**
    - By A.13a, a maximiser K* with K*(R) = 1 exists. Its positive support points satisfy x <= 2(1 - u)/R, and its
      negative ones |x| <= 2u/R, with max(u, 1 - u) <= R/sqrt2.
    - So supp K* lies in [-sqrt2, sqrt2], and Theorem 10 or the far-region hypothesis gives
      R_ID = E|Z_{K*}| <= T.
    - Conversely, C5 contains the far-region inequality, so the two are equivalent.

### Independent verification (RQ-AUD code only)

The scripts are in `audit/rqd/`, with outputs in `audit/rqd/outputs/`:
- `a32_band_verify.py` is the certified verifier (python-flint arb at 128 bits).
  - Exact Fractions are used for all box and square endpoints, the feasibility tests and the peak point
    Lambda* = clamp(min(m2^2/V_hi, 1/2), Lambda1, Lambda2) of 2m e^{-Lambda}.
  - Floats are used only to choose h.
- `a32a_unit_tests.py` holds the unit tests.
- `a32b_semantic.py` holds the semantic tests (float64, evidence only).

Part S uses my own derivation of the linear bound, with r = 1/50 and c = t - h:
- **B side**, valid for 0 <= c <= 1 - r/2: chi^B_h(t) <= a alpha_B + b beta_B, where
  - alpha_B = (2h)^{-1} sum_{n>=1} r^{n-1} ((n - c)^2 + r)/n!,
  - beta_B = tau(c/sqrt r)/(2h), and
  - tau(x) = E(G - x)_+^2 = (1 + x^2) Phibar(x) - x phi(x).
- **C side**, valid for 0 <= c <= sqrt2 - r/(2 sqrt2): alpha_C = tau(c/sqrt r)/(2h) and
  beta_C = (2h)^{-1} sum_{n>=1} r^{n-1} ((sqrt2 n - c)^2 + r)/(2^n n!).
- **Cauchy–Schwarz cost**: sqrt(t^2 + rho^2) - t <= rho^2/(2t), so the coefficient is 1/(2t) for both a and b.
- **Box tests**, with 𝒜 and ℬ the total coefficients of a and b and M0 a bound for 2m e^{-Lambda} on the box:
  - S1: max(𝒜, ℬ) < T/2. This suffices because 2m e^{-Lambda} <= sqrt(V) g(Lambda) <= (1 - rho^2/2) T.
  - S2: M0 + r_B max(𝒜, ℬ) < T, with r_B = min(r, 1 - m1^2/Lambda2) (from F4).
  - S3: M0 plus every cost by Cauchy–Schwarz at rho^2 = r_B.
- This is the same bound as RQ-D's Section 5.1. The B-side condition is RQ-D's "(n - a - c)^2 <= (n - c)^2 when
  0 <= a <= 2(n - c)". The n = 0 term needs c >= 0, and RQ-D's text states c = t - h > 0.

| check | result |
|---|---|
| Part S, 0 < rho^2 <= 1/50 (`a32_band_verify.py S`, 0.2 s) | 767 (Lambda, m) boxes: a 33 x 21 grid of side 1/64, with 37 bisections (depth <= 5). The 730 leaves are 612 infeasible, 21 certified by S1, 88 by S2 and 9 by S3: **0 failures**. Smallest margins 9.1e-5 (S1), 1.1e-5 (S2) and 0.047 (S3) |
| Part B, 1/50 <= rho^2 <= 1/10 (`a32_band_verify.py B`, 2.1 s on 8 cores) | 341 (a, b) squares of side 1/256. 290 are certified; the other 51 are split into four, and the 199 children that meet the band are all certified at side 1/512. In all **489 squares and 369,066 (Lambda, m) boxes, 0 uncertified** |
| Part B evaluation | costs at the corner (a2, b2) (Lemma 6 (iv)); Cauchy–Schwarz at rho^2_hi = min(a2 + b2, 1/10); V in [1 - rho^2_hi, 1 - rho^2_lo]; mu_1 in [max(1, m1/Lambda2), min(sqrt2, m2/Lambda1)] as one ball |
| Part B smallest margin | 3.2e-8, at Lambda in [0.49902, 0.5], m in [0.67480, 0.67529], a in [19/256, 5/64], b in [3/256, 1/64]. This box is next to the Cauchy–Schwarz edge m^2 = Lambda V, i.e. K_S close to one atom at 1.354 |
| reruns | both parts reproduce their recorded outputs exactly |
| controls, Part S (the test is not vacuous) | r = 3/50 gives 117,163 failing boxes and r = 1/25 gives 34,889; target T - 1/500 gives 27,888 and T - 1/1000 gives 18,010 |
| controls, Part B (side 1/512, no refinement) | target T - 1/1000 fails 44 of 1,333 squares and T - 1/2000 fails 10; target T fails none (smallest margin 7.4e-8) |
| unit tests (`a32a_unit_tests.py`, 1 s) | tau at 7 points against mpmath quadrature; Q(d, s) = E(d + sG)_+^2 at 5 points against 60-digit quadrature; chi at 12 random points against a 120-term mpmath sum; 400 random checks of the Part S linear bound. 0 fails |
| semantic T1–T3 (`a32b_semantic.py 400 8`, 2 min 14 s; float64, atoms on the lattice Z/400, exact Poisson sums) | 400 random band K: min(T - E\|Z_K\|) = 1.3e-3, min(T - F) = 6.0e-4 and min(F - E\|Z_K\|) = 1.2e-4. Every cost bound, Lemma 6 (i)–(ii) at random (t, h), the decomposition of Proposition 9 and the identity of Lemma 3 hold |
| semantic T4 | Lemma 4 holds for psi_{t,h} and e^{kw} on 400 random (K, T) (smallest gap -8.9e-16, rounding). The control psi = (t - w)_+^2, whose psi'' is nonincreasing, fails in 363 of 400. Remark 5 is exact |
| semantic T5 (hostile Nelder–Mead, 8 starts x 2 objectives over band K) | max E\|Z_K\| = T - 1.3e-6, at the single atom delta_1.4125 (the lattice point nearest sqrt2 inside the band). max(E\|Z_K\| - F) = -5.7e-6, with rho^2 >= 0.001 forced. 0 fails |
| float profile of T - F on the Dirac curve K_S = V delta_x (evidence) | the margin is about 0.073 rho^2 as rho^2 -> 0 (all residual mass in a, x = sqrt2), and 0.0027 at rho^2 = 0.1. So Part S's linear test has room |

RQ-D's own counts are 1,098 Part S boxes and, for Part B, 598 squares with 1,339,228 boxes. They differ from mine because
the two bounds differ in their details: the choice of h, the chord handling and the bound for 2m e^{-Lambda}. Both
start from the same 341 squares of side 1/256, and both certify everything.

### Verdict and novelty

- **VALID** (no fix).
  - Every lemma, Proposition 9, Theorem 10 and Corollary 11 were rebuilt. For Theorem 10 this covers both cases,
    the general-K step and the equality clause.
  - The computer step was redone with my own certified verifier and a different decomposition.
- Remarks (no fix needed):
  - r1: the md5 nit of 17:24 is resolved by the erratum of 17:35.
  - r2: RQ-D's Section 5.1 describes a sound certificate. I checked each validity statement in it: c > 0 for the
    n = 0 term, the max(g1bar, g2bar) replacement in the chord, and the monotonicity directions. My verifier
    handles the chord weight as a ball instead.
  - r3: Remark 5's minimality paragraph is correct. It is not used.
- **Novelty.**
  - Theorem 10 and Corollary 11 are NEW; I found no earlier source. They settle C5 on the band and reduce C5 to the
    far region. They give no exact value of R(q).
  - Lemma 4 is NEW as stated; I found no source. The technique is standard:
    - generator comparison of Levy processes (Bergenthum–Rüschendorf, Ann. Probab. 35 (2007), for the convex,
      directionally convex and supermodular orders);
    - psi'' nondecreasing means 3-convex in the sense of the s-convex orders of Denuit–Lefèvre–Shaked
      (Math. Inequal. Appl. 1 (1998)). Z_K and Z_{T#K} have the same mean and variance, so Lemma 4 is a 3-convex
      comparison of them.
  - Lemmas 2, 6, 7 and 8 and Proposition 9 are elementary, with standard technique (stop-loss transforms, chord
    and Taylor bounds). Their combination here is NEW.
- **Use for the project.**
  - Theorem 10 is C5, the q -> 0 limit case R_ID = sqrt(2/e), on the band K([1, sqrt2]) >= 9/10.
  - With Corollary 11, C5 is now equivalent to the far-region inequality.
  - It is not the finite-q form ID* (theta = 0.85, A = 1.54, target max(g(lambda+), C_5)). That is D13, which is
    NUMERICAL.

---

## A.33 RQ-A U.7, the consequence marked "PROVED, given the conjecture" (a one-signed maximiser makes K_f one-signed) — VALID as an implication; NEW as stated (elementary) (2026-10-22 18:17 UTC)

**Sources.** RQ-A CLAIMS.md 6b00a3e1… (18:00), U.7; copy `audit/snapshots/RQ-A_CLAIMS_1801.md`. U.7 itself is a
CONJECTURE and is not rated.

**Claim.**
- U.7: for q < 1/2, every maximiser of E|sum alpha_i chi_i| on the unit sphere of R^n is one-signed up to the global
  sign. RQ-A adds: "equivalently: the q-biased level-one weight sum_i Delta_i(f)^2 of Boolean f is maximised by a
  monotone f".
- Consequence: in U.1 the maximiser can be taken with alpha >= 0. Then beta = alpha >= 0, and K_f is carried by
  (0, oo). So ID*(C) is needed for one-signed K only.

**Rebuilt proof.**
1. A maximiser exists, by continuity on the compact sphere. Under U.7 it is one-signed, and -alpha is a maximiser
   too. So there is a maximiser alpha >= 0.
2. U.1 (A.26) at a maximiser: f = 1{L_alpha > 0} and beta = Delta(f)/sqrt(D(f)) = alpha (equality in
   Cauchy–Schwarz). K_f = sum_i beta_i^2 delta_{beta_i/sqrt s} puts its mass at the points beta_i/sqrt s with
   beta_i > 0, so it is carried by (0, oo).
3. The bound of U.2 (C19) is applied to this f. So its hypothesis is needed only for K carried by (0, oo), or by
   (-oo, 0) after the global sign.

**Remark r1 (cosmetic).** "Equivalently" is not shown.
- The main form implies the parenthetical: for a one-signed maximiser alpha >= 0, f = 1{L_alpha > 0} is monotone and
  maximises D, by step 2.
- The converse gives only that *some* maximiser is one-signed. If a monotone f maximises D, then
  alpha = Delta(f)/sqrt(D(f)) >= 0 is a maximiser, but other maximisers may be two-signed.
- The consequence uses only "some maximiser is one-signed", so it follows from either form.
- Fix: write "implies", or state the weaker form.

**Hostile check of the evidence.**
- U.7 is already a theorem for n <= 7 and every q < 1/2.
  - By C6 (A.5, A.5b), the only maximisers are +-1_S/sqrt(k*), plus k* - 1 coordinates at q = q_{k*}. These are
    one-signed.
  - So evidence (ii) (n <= 7, exact enumeration with multistart) is covered by an audited theorem, and U.7 is open
    only for n >= 8.
- Evidence (i), n = 2, checked.
  - Let u and -v be the two values of chi, so uv = 1, q^2 u + (1-q)^2 v = tau and q(1-q)(u + v) = tau.
  - Summing over the four atoms gives E|cos(psi) chi_1 - sin(psi) chi_2| = tau (cos psi + sin psi +
    |cos psi - sin psi|) = 2 tau max(cos psi, sin psi) on [0, pi/2].
  - The identity was also checked numerically to 30 digits at 5 random rational q and random psi (sympy).

**Verdict and novelty.** **VALID** as an implication (r1 is cosmetic). The implication is elementary and NEW as
stated. It adds no unconditional result, because U.7 is open for n >= 8.

---

## A.34 RQ-D D16–D20 (Lemma 7(c), (O1)–(O5), Lemma 12; Theorem 13, the ID* band lemma at theta = 0.85, A = 1.54; Corollaries 14–15) — VALID; Theorem 13 and Corollaries 14–15 NEW (2026-10-22 20:19 UTC)

**Sources.**
- RQ-D AUDIT_REQUEST.md 476ea8d3… (second request 19:01 UTC, addendum 19:07), CLAIMS.md aa4587a5… (D16–D20),
  MAIN_RESULT.tex bba5c599… and .pdf 3137370e…. Copies: `audit/rqd/bstar_1912/` (the 19:01 version is in
  `audit/rqd/bstar_1903/`). All four files are unchanged in the store at 20:18.
- The tex differs from the version audited in A.32 (`audit/snapshots/RQ-D_MAIN_RESULT_1722.tex`) exactly as RQ-D
  says: the abstract; Lemma 7(c) and its proof; the list (O1)–(O4) after Proposition 9; and Section 6, which replaces
  the old outlook. Lemmas 1–6 and 8, Remark 5, Proposition 9, Theorem 10, Corollary 11 and Section 5.1 are
  unchanged, so A.32 covers them.
- I read RQ-D's recorded outputs (`outputs/verify_bandstar.txt` c36c17e5…, the controls and the float tests) for
  their counts. RQ-D's scripts are not in my repository and I did not read them; only their md5s are recorded
  (`audit/rqd/bstar_1912/SCRIPTS_MD5SUMS.txt`, `verify_bandstar.py` b5b55cee…).

### Claim

- **Setting** (as in A.32, with theta = 17/20 and A = 77/50).
  - K_S = K|[theta, A], with mass V, Lambda = lambda+_theta(K) = int x^{-2} dK_S and m = int x^{-1} dK_S.
  - K_R = K - K_S is carried by [-A, theta), with a = K_R((0, theta)), b = K_R([-A, 0]) (the Gaussian part is in b)
    and rho^2 = a + b = 1 - V. W = Z_{K_R}.
  - The jump law J ~ nu_S/Lambda has mean mu_1 = m/Lambda and variance sigma_J^2 = (Lambda V - m^2)/Lambda^2.
  - phi(y) = 2E(-W - y)_+, and O' must bound E phi(J - m) (Proposition 9, second form).
  - chi^B_h, chi^C_h are the stop-loss bounds of Lemma 6, and C_5 = g(2 ln(5/4)) = 1.28 sqrt(2 ln 1.25) = 0.85510045….
- **D16, Lemma 7(c).** Let J take values in [j0, j1] with mean mu > j0 and variance sigma^2. Let phi <= psi on
  [j0, oo), with psi C^1 and psi' concave. Put d = mu - j0, x = mu + sigma^2/d and w = d^2/(d^2 + sigma^2). Then
  E phi(J) <= (1 - w) psi(j0) + w psi(x).
  - Box form: if psi is also convex and nonincreasing, then
    E phi(J) <= (1 - w') psi(j0') + w' psi(j0' + u') for all s^2 >= sigma^2, j0' <= j0, 0 <= w' <= d^2/(d^2 + s^2)
    and u' <= d + s^2/d.
- **D10/D16, the admissible O'.**
  - (O1) is the chord of phi.
  - (O2) is Lemma 7(b) with Gamma(y) = -2y + chi^B_h(-y) and kappa = 1/h.
  - (O3) is Lemma 7(c) with psi = chi^C_h and j0 = theta - m.
  - (O4) is Lemma 7(c) with psi(y) = sqrt(y^2 + r^2) - y, r^2 >= rho^2, when theta >= m.
- **D17.**
  - (O5): if mu_1 > theta, then O' = (1 - w) kappa + (1 - w) rho^2/(2h) + chi^C_h(mu_1 - m) is admissible. Here
    kappa = (h - j0')_+^2/(2h) with j0' <= theta - m, and w is the exact weight.
  - Lemma 12 (absorption): if 0 < D <= d = mu_1 - theta and 0 <= kappa <= D^2 sqrt(Lambda/V), then
    2m e^{-Lambda} + Lambda e^{-Lambda} kappa (1 - w) <= sqrt(V) g(Lambda).
- **D18, Theorem 13.** Let K be a finitely supported probability Kolmogorov measure on [-1.54, 1.54]. If
  K([0.85, 1.54]) >= 4/5, then E|Z_K| <= max(g(lambda+_0.85(K)), C_5). If K([-1.54, -0.85]) >= 4/5, the same holds
  with lambda-. The proof is computer-assisted.
- **D19, Corollary 14.** Suppose E|Z_K| <= C_5 for every finitely supported probability K on [-1.54, 1.54] with
  K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5. Then ID* holds for every finitely supported probability on
  [-1.54, 1.54].
- **D20, Corollary 15.**
  - (a) Theorem 13 holds for every probability K on [-1.54, 1.54], finitely supported or not.
  - (b) Suppose E|Z_K| <= sqrt(2/e) for every probability K on [-sqrt2, sqrt2] with K([0.85, sqrt2]) < 4/5 and
    K([-sqrt2, -0.85]) < 4/5. Then C5 holds. In particular, the hypothesis of Corollary 14 implies C5.

### Rebuilt proof (from the hypotheses)

1. **Lemma 7(c), first form.**
   - P* = (1 - w) delta_{j0} + w delta_x has mean j0 + w (x - j0) = j0 + d = mu, since x - j0 = (d^2 + sigma^2)/d.
     Its variance is (1 - w) d^2 + w sigma^4/d^2 = sigma^2.
   - Let q be the quadratic with q(j0) = psi(j0), q(x) = psi(x) and q'(x) = psi'(x), and put k = q - psi. Then
     k(j0) = k(x) = k'(x) = 0, and k' = q' - psi' is convex, because q' is affine and psi' is concave.
   - By Rolle, k'(xi) = 0 for some xi in (j0, x). A convex function vanishing at xi < x is <= 0 on [xi, x] and
     >= 0 outside. So k increases on [j0, xi], decreases on [xi, x] and increases on [x, oo). With k(j0) = k(x) = 0
     this gives k >= 0, i.e. psi <= q, on [j0, oo).
   - E q(J) depends only on the mean and the variance of J. So E phi(J) <= E psi(J) <= E q(J) = E_{P*} q =
     E_{P*} psi. If sigma^2 = 0, then J = mu a.s. and the bound is trivial.
2. **Lemma 7(c), box form.**
   - For s^2 > sigma^2, the law P** on {j0, x(s^2)} with mean mu is a mean-preserving spread of P*. Split the mass
     w(sigma^2) at x(sigma^2) between j0 and x(s^2), with conditional mean x(sigma^2). The mass that lands at x(s^2)
     is w(sigma^2) (x(sigma^2) - j0)/(x(s^2) - j0) = d/(x(s^2) - j0) = w(s^2).
   - So T_psi(sigma^2) <= T_psi(s^2) for convex psi, by Jensen.
   - Write T_psi(s^2) = psi(j0) - w~ (psi(j0) - psi(j0 + u~)), with w~ = d^2/(d^2 + s^2) and u~ = d + s^2/d. The
     bracket is >= 0 because psi is nonincreasing, so lowering w~ to w' raises the bound.
   - Finally psi(j0) <= psi(j0') and psi(j0 + u~) <= psi(j0' + u'), because psi is nonincreasing.
3. **The admissible O'.**
   - phi is convex and nonincreasing. By Lemmas 2 and 6, phi(y) <= chi^C_h(y), phi(y) <= sqrt(y^2 + rho^2) - y and
     phi(y) = -2y + 2E(W + y)_+ <= -2y + chi^B_h(-y), for all y.
   - (O2): (chi^B_h)'' = P(W_B > . - h)/h <= 1/h, so Gamma'' <= 1/h.
   - (O3): chi^C_h is convex and nonincreasing, and (chi^C_h)''(y) = P(W_C > y - h)/h is nonincreasing in y, so its
     derivative is concave.
   - (O4): the second derivative r^2/(y^2 + r^2)^{3/2} is nonincreasing on [0, oo). This is why theta - m >= 0 is
     required, so that [j0, oo) lies in [0, oo).
   - If J is identically theta, then E phi(J - m) = phi(theta - m), which is below every option.
4. **(O5).**
   - Lemma 7(c), first form, with psi = chi^C_h and j0 = theta - m gives
     E phi(J - m) <= (1 - w) chi^C_h(j0) + w chi^C_h(x), with x = mu_1 - m + sigma_J^2/d >= mu_1 - m.
   - Since 0 <= w <= 1 and chi^C_h >= 0 is nonincreasing, w chi^C_h(x) <= chi^C_h(mu_1 - m).
   - chi^C_h(j0) <= chi^C_h(j0') <= kappa + rho^2/(2h). Indeed W_C has mean 0 and variance a + b = rho^2. For
     e = h - j0' >= 0, E(W_C + e)_+^2 <= e^2 + rho^2. For c = j0' - h > 0, E(W_C - c)_+^2 <= E W_C^2 = rho^2,
     since (w - c)_+^2 <= w^2 for c >= 0.
   - In the box version, the exact w is needed only in the kappa term, which Lemma 12 absorbs. The rho^2 term may use
     (1 - w) <= (1 - w'), and the far term uses chi^C_h(theta - m2 + d_lo), rounded down to the grid. This mix is
     sound; it is RQ-D's risk 1.
5. **Lemma 12.**
   - 1 - w = sigma_J^2/(d^2 + sigma_J^2) <= sigma_J^2/D^2 = (Lambda V - m^2)/(Lambda^2 D^2).
   - So the left side is at most e^{-Lambda} q(m), with q(t) = 2t + kappa (Lambda V - t^2)/(Lambda D^2).
   - If kappa > 0, q is a concave quadratic with vertex t* = Lambda D^2/kappa >= Lambda D^2/(D^2 sqrt(Lambda/V)) =
     sqrt(Lambda V). So q is nondecreasing on (-oo, sqrt(Lambda V)]. Since m <= sqrt(Lambda V) by (F4),
     q(m) <= q(sqrt(Lambda V)) = 2 sqrt(Lambda V). The case kappa = 0 is (F4) itself.
   - Finally 2 e^{-Lambda} sqrt(Lambda V) = sqrt(V) g(Lambda), by the definition of g.
6. **Theorem 13, reduction to a finite computation.**
   - Reflection x -> -x maps Z_K to -Z_K and exchanges lambda+ and lambda-. So assume K([theta, A]) >= 4/5. Then
     K_S != 0, V >= 4/5 and rho^2 <= 1/5.
   - Proposition 9 (second form, A.32 step 7, no sign condition on theta - m) gives
     E|Z_K| <= F = 2m e^{-Lambda} + e^{-Lambda} c_B + Lambda e^{-Lambda} O' + P_2(Lambda) c_C.
   - (a, b, Lambda, m) lies in D* = {a, b >= 0, a + b <= 1/5, (Lambda, m) satisfying (F1)–(F5) with V = 1 - a - b}.
     (F1)–(F5) are Lemma 8 (A.32). (F5) comes from (x^{-1} - A^{-1})(theta^{-1} - x^{-1}) >= 0.
   - So it suffices to show F <= max(g(Lambda), C_5) on D*, for some admissible choice at each point. That is the
     certified computation.
7. **The box-level reductions** used by the computation (by RQ-D's Section 6.1 and by my verifier).
   - **Costs.** chi is nondecreasing in a and b (Lemma 6(iv)). Every (a, b) of a square with a + b <= 1/5 satisfies
     a <= a-bar = min(a2, 1/5 - b1) and b <= b-bar = min(b2, 1/5 - a1). So the costs may be evaluated at
     (a-bar, b-bar), and the Cauchy–Schwarz terms with r^2 = min(a-bar + b-bar, 1/5) >= rho^2.
   - **Monotone ends.** t -> 2E(W - t)_+ and phi are nonincreasing. So c_B is evaluated at m1, c_C at
     2 theta - m2, the chord ends at theta - m2 and A - m2, and the (O2) point at a grid point <= m1 - mu_hi.
   - **Multipliers.** e^{-Lambda} <= e^{-Lambda1}, Lambda e^{-Lambda} <= max of t e^{-t} on the box and
     P_2(Lambda) <= P_2(Lambda2), since P_2' = t e^{-t} >= 0. This needs every cost to be >= 0. It holds because
     every upper bound used is >= the nonnegative quantity it bounds (RQ-D's risk 5).
   - **Target.** g is unimodal, so max(min(g(Lambda1), g(Lambda2)), C_5) <= max(g(Lambda), C_5) on the box.
   - **Main term.** 2m e^{-Lambda} <= 2e^{-Lambda} min(m2, sqrt(Lambda V_hi)). As a function of Lambda this is
     unimodal, with its peak at min(m2^2/V_hi, 1/2), so its box maximum is at that point clamped to [Lambda1, Lambda2].
   - **Jump geometry.**
     - mu_1 lies in [max(theta, m1/Lambda2), min(A, m2/Lambda1)].
     - sigma_J^2 <= s^2 = min((Lambda2 V_hi - m1^2)/Lambda1^2, d_hi (A - mu_lo)). The second term is
       Bhatia–Davis: sigma^2 <= (mu - theta)(A - mu).
     - w' = d_lo^2/(d_lo^2 + s^2) <= d^2/(d^2 + s^2).
     - u' <= min over d in [d_lo, d_hi] of (d + s^2/d). The function is convex in d, so the minimum is at
       clamp(s, d_lo, d_hi).
   - **The slope check** (a2 + b2 <= 1/50 and m2 < theta).
     - Linear bounds. They are A.32's Part S bounds with jump theta (B side) and A (C side), valid for
       a, b >= 0 and a + b <= r, provided c = t - h > 0 and r <= 2 theta (theta - c) (resp. r <= 2A (A - c)).
     - The n = 0 term needs c >= 0, since tau is decreasing and b <= r.
     - For n >= 1, P(N = n) <= (a/theta^2)(r/theta^2)^{n-1}/n!. Also
       (theta n - a/theta - c)^2 <= (theta n - c)^2, because 0 <= a/theta <= 2(theta n - c).
     - Cauchy–Schwarz: sqrt(t^2 + rho^2) - t <= rho^2/(2t).
     - Then F <= sqrt(1 - rho^2) g(Lambda) + rho^2 M_x <= (1 - rho^2/2) g(Lambda) + rho^2 M_x. The first step is (F4)
       for (O1), (O3) and (O4), and Lemma 12 for (O5), applicable because Lambda >= Lambda1 and V <= 1 - r1.
     - (T1) M_x <= min(g(Lambda1), g(Lambda2))/2 gives F <= g(Lambda).
     - (T2) uses 1 - rho^2/2 > 0 and g <= g-hat, and is linear in rho^2, so its endpoints suffice.
     - (T3) M0 + r2 M_x < T needs M_x >= 0, which holds because all coefficients are >= 0. For (O5),
       M0 = max(M, e^{-Lambda1}(2 m2 + kappa max(0, Lambda2 (1 - r1) - m2^2)/(Lambda1 d_lo^2))) bounds
       2m e^{-Lambda} + Lambda e^{-Lambda} kappa (1 - w). Either m2 <= sqrt(Lambda V), and q is nondecreasing up to its
       vertex; or e^{-Lambda} q(m) <= sqrt(V) g(Lambda) <= M (RQ-D's risk 3).
     - Pieces with m1^2 > Lambda2 (1 - r1) are empty by (F4).
     - The kappa condition kappa <= d_lo^2 sqrt(Lambda1/(1 - r1)) implies kappa <= D^2 sqrt(Lambda/V) with D = d_lo
       (RQ-D's risk 2).
8. **Corollary 14** is immediate. On the band, use Theorem 13 with theta = 0.85. Off the band,
   E|Z_K| <= C_5 <= max(g(lambda+_theta), g(lambda-_theta), C_5) for every theta.
9. **Corollary 15.**
   - (a) Take finitely supported K_n by moving the mass of each cell of mesh 1/n, separately in [-A, theta) and in
     [theta, A], to a point of the cell. Then K_n([theta, A]) = K([theta, A]) >= 4/5 and K_n -> K weakly, so
     E|Z_{K_n}| -> E|Z_K| (A.32 step 10). Also lambda+(K_n) -> lambda+(K), because x^{-2} is uniformly continuous on
     [theta, A] and the cells there carry the same masses. g is continuous.
   - (b) If C5 failed, A.13a gives a maximiser K* with K*(R) = 1 carried by [-sqrt2, sqrt2], a subset of
     [-1.54, 1.54], with E|Z_{K*}| = R_ID > sqrt(2/e). In the band, (a) gives E|Z_{K*}| <= max(g, C_5) <= sqrt(2/e).
     Off the band, the hypothesis gives the same bound. Either way this is a contradiction.
   - The last sentence: approximating with cells inside [-1.54, -0.85], (-0.85, 0.85) and [0.85, 1.54] keeps both
     masses, so the far-region hypothesis extends from finitely supported K to all K. C_5 <= sqrt(2/e), and every K on
     [-sqrt2, sqrt2] in the far region of (b) is in the far region of Corollary 14.
10. **Use for Conjecture S** (the chain, rechecked).
    - A.26 (C19(d), RQ-A U.1–U.2): if ID*(C) holds for every finitely supported probability K on R \ {0} (theta may
      depend on K), then R = M wherever C(q) >= C. Also min over (0, q5] of C(q) is C(q5) = C_5.
    - A.28 (RQ-C C15): at q <= q5, ID* is needed only for K on [-A, A] with A > A'(q). A' increases in q, and
      A'(q5) = 1.538… < 1.54.
    - So Theorem 13 and Corollary 14 give R(q) = M(q) on (0, q5], and hence Conjecture S there, provided
      E|Z_K| <= C_5 holds on the far region.
    - [q5, 1/2] is covered by A.25 with A.6, A.11, A.14 and A.18, and q > 1/2 follows by the mirror symmetry.
    - So Conjecture S for all q now rests on one open inequality: E|Z_K| <= C_5 for every finitely supported
      probability K on [-1.54, 1.54] with K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5. The numerical sup there
      is about 0.8266 (RQ-C C18; RQ-D 19:27), against C_5 = 0.8551.

### Independent verification (RQ-AUD code only)

The scripts are in `audit/rqd/` and the outputs in `audit/rqd/outputs/`. Versions: python 3.12.3, python-flint 0.9.0,
numpy 2.5.4, scipy 1.18.1. The verifier was written from the statements in the tex and generalises my A.32
primitives.

- **`a34_bandstar_verify.py`** (md5 c69392de…) is the certificate.
  - Exact Fractions are used for all square and box endpoints, the corner (a-bar, b-bar), the feasibility tests
    (F1)–(F5), the jump geometry (mu_lo, mu_hi, d_lo, s^2, w'), the grid roundings, the peak point of the main term
    and the validity conditions of the linear bounds.
  - arb at 128 bits is used for everything transcendental. chi is a lattice sum over n <= 12 plus a rigorous
    geometric tail. The linear-bound series runs to n = 11, plus a rigorous geometric tail. x*x is used instead of
    x**2 throughout, and comparisons use exact upper endpoints.
  - Floats only choose: h from a geometric grid (60 values 0.004 * 1.12^k; for (O5), 52 values 0.04 * 1.07^k), the
    option order and the coefficient combination. Every certifying inequality is an arb or exact comparison.
  - The grids differ from RQ-D's:
    - the m-grid is 1/4096 and the Lambda-grid 1/16384;
    - r is rounded up on a 1/8192 grid, with r >= r2 and r > 0 asserted;
    - the far points are rounded down to the m-grid;
    - the (O1) chord uses max(phi1, phi2) at the low end with the smallest weight w1 = d_lo/(A - theta). The chord
      is then nonincreasing in the weight; in the slope check the max is taken coefficientwise;
    - (O3) uses a common h at both points;
    - in the slope check, a float sweep over 21 weights lambda = k/20 of lambda A + (1 - lambda) B picks the
      combination of options; M_x is then recomputed in arb.
- **The run** (`a34_bandstar_verify.py run 8`, 20:11:32–20:15:27 UTC, 235 s on 8 cores; outputs
  `a34_bandstar_verify.txt`, `a34_squares_shift0.jsonl`, `a34_env.txt`):

  | side | squares | not certified | (Lambda, m) boxes |
  |---|---|---|---|
  | 1/128 | 351 | 213 | 2,008,584 |
  | 1/256 | 829 | 94 | 5,280,437 |
  | 1/512 | 376 | 18 | 4,800,487 |
  | 1/1024 | 72 | 0 | 993,588 |

  - In all, **1,303 certified squares, 13,083,096 boxes and 0 uncertified**.
  - The leaf boxes of the certified squares (10,959,497) split as 2,060,234 infeasible, 387,535 by (O1),
    1,319,022 by (O2), 2,600,959 by (O3), 160,735 by (O4) and 655 by the slope check (1,330 rho^2-pieces, none
    empty).
  - The smallest direct margin is 7.9e-10, at Lambda in [2027/2048, 507/512], m in [1825/2048, 913/1024] in the square
    [25/256, 13/128] x [23/256, 3/32]. There K_S is close to 0.81 delta_0.9 and the target is C_5. Arb's error at
    128 bits is about 1e-35, so the margin is real.
  - The last-level squares lie along the hypotenuse: a + b in [0.1973, 0.2012] and a in [0.0508, 0.0859].
  - Two earlier runs gave identical counts: one with a preliminary file, and one with md5 70412047…, which differs
    from c69392de… only in its docstring (lemma numbers). They are in `outputs/a34_superseded/`. Ignoring timing
    fields, all 1,628 square records of the 70412047 run equal those of the final run.
- **RQ-D's counts** are 351/215, 837/102, 408/20 and 80/0, with 1,339 certified squares and 14,894,034 boxes. They
  differ from mine because the two designs make different choices of h, grids and option handling. Both start from
  the same 351 squares of side 1/128, and both certify everything.
- **Cover check** (`a34e_cover_check.py`, exact; output `a34e_cover_check.txt`). On the final jsonl:
  - level 0 is exactly the set of 1/128-squares that meet the triangle T = {a, b >= 0, a + b <= 1/5};
  - each later level is exactly the set of children that meet T of the previous level's uncertified squares;
  - the last level has no uncertified square;
  - the certified area inside T is exactly 1/50 = area(T).
  - Result: COVER OK.
- **Controls** (`a34c_controls.py`, 59 s, output `a34c_controls.txt`): all came out as expected.
  - The origin squares [0, 1/256]^2 and [0, 1/128]^2 are certified at shift 0 and not certified at target shifts of
    1e-30, 1e-9 and 1/2000, nor without the slope check. Near the Dirac curve the margin is exactly 0 at rho^2 = 0,
    so even a shift of 1e-30 must fail, and it does. The first failing box sits on m^2 = Lambda, at
    Lambda = 0.5578.
  - Of the 72 last-level squares, none fails at shifts 0 and 1e-4, and 62 fail at 1e-3. So along the hypotenuse the
    certified margin lies between 1e-4 and 1e-3. RQ-D reports 63 of 80 failing at 1e-3.
- **Semantic tests** (`a34b_semantic.py`, float64 with exact Poisson enumeration; evidence, not proof; output
  `a34b_semantic.txt`).
  - Four runs: 600 band K (seed 11), 600 near-Dirac K (seeds 12 and 14) and 300 edge K (seed 13).
  - For each K, the verifier's own functions are run on the smallest grid square and box containing
    (a, b, Lambda, m). Each ingredient is compared with its exact value: c_B, c_C, each of (O1)–(O4) against
    E phi(J - m), the box bound against E|Z_K|, the linear slope bounds, (O5) with Lemma 12, and the theorem itself.
    A feasible point reported as an "empty" piece would count as a violation.
  - Result: 0 violations in all four runs; 1,224 slope pieces were exercised, with recipes (O1), (O4) and (O5).
  - The smallest gaps are F_slope - E|Z_K| = 7.3e-7 and theorem slack 3.7e-6, both near the Dirac curve.
- **Hostile search** (`a34d_hostile.py`, Nelder–Mead over 8 parameters: two band atoms, a positive and a negative
  residual atom, and a Gaussian part; output `a34d_hostile.txt`). It maximises E|Z_K| - max(g(lambda+), C_5) on the
  band.
  - Residual floor 0: max excess 4.4e-16 (rounding), at a Dirac law with Lambda = 0.4464, where E|Z| = g(Lambda)
    exactly.
  - Floor 0.005: -5.45e-4, at 0.995 delta_1.493 + 0.005 delta_0.85-.
  - Floor 0.05: -7.1e-3.
  - No counterexample. Near the Dirac curve the true margin found is about 0.11–0.14 rho^2. RQ-C's C20(a), an
    independent search, finds 0.12–0.16 rho^2.
- **RQ-D's ten risks** (AUDIT_REQUEST) are all checked above: 1 (mixed weights in (O5)) in step 4; 2 (the kappa
  condition), 3 ((T3) for (O5)), 4 (the linear bounds and r >= r2), 5 (nonnegativity), 6 ((T2)), 7 (the hypotenuse
  corner) and 8 ((O2)) in step 7; 9 (NaN), because my code uses x*x everywhere; 10 (floats choose, arb decides),
  because that is my design.

### Remarks (cosmetic, no fix needed)

- r1: risk 4 of the AUDIT_REQUEST says "r2 <= a2 + b2 < 1/50 whenever the slope check is used". The condition in
  Section 6.1 is a2 + b2 <= 1/50. r = min(ceil(4096 r2)/4096, 1/50) >= r2 holds either way.
- r2: risk 9 says that `x**2` is NaN for a ball with midpoint exactly 0. In python-flint 0.9.0 I see NaN for a ball
  with midpoint 0 and positive radius. Either way a NaN can only make a check fail.

### Verdict and novelty

- **VALID** (no fix).
  - Lemma 7(c), (O1)–(O5), Lemma 12, Theorem 13 and Corollaries 14–15 were rebuilt from the hypotheses.
  - The computer step was redone with my own certified verifier, of a different design, and the cover was
    checked exactly.
- **Novelty.**
  - Theorem 13 and Corollaries 14–15 are NEW; I found no earlier source. The ID* formulation is the project's own
    (A.26).
  - (O5) and Lemma 12 are NEW as stated and elementary.
  - Lemma 7(c) is KNOWN in kind. Two-point laws with an atom at the left end of the support are the extremal laws,
    for given mean and variance, for functions with a concave derivative (3-concave functions). See the s-convex
    extremal distributions of Denuit–Lefèvre–Shaked (Math. Inequal. Appl. 1 (1998)) and the stop-loss bounds with
    given mean and variance of De Vylder–Goovaerts (Insurance Math. Econom. 1 (1982)).
- **Use for the project.**
  - With A.25, A.26 and A.28, Conjecture S for all q is reduced to the far-region inequality E|Z_K| <= C_5 (step 10).
  - C5 (the q -> 0 case) is reduced to the same region (Corollary 15(b)).
  - Theorem 13 gives no exact value of R(q) by itself.

### Addendum (2026-10-23 03:02 UTC): a slip in a remark of Section 6.1 (f1, text only). A.34 stays VALID.

- **(f1) Tex line 617 says that g(Λ) > C_5 "in the range 0.4463 < Λ < 0.5599". The upper end should be 0.5579.**
  - With g(λ) = 2√λ e^{−λ} (tex line 68), g > C_5 exactly on (2 ln 5/4, 0.5578588782…) (corrected at 07:05:
    this read 0.5578588783 with an ellipsis, a rounding; a40m), and
    g(0.5599) − C_5 = −1.84e-4.
  - The slip was already in the text A.34 audited (bba5c599…, line 612), and I missed it then.
  - It is in the remark that explains why the slope check is needed. Theorem 13 and its proof do not use it: the
    certificate, and my own verifier, cover the whole domain.
- (r3) RQ-D's CLAIMS D13 (NUMERICAL, not a proved claim) gives the Dirac range where g(1/x²) >= C_5 as
  x in [1.335, 1.4985]. The exact range is [1.3388682…, 1.4969001…]. (Corrected at 06:58: the lower end is
  1.33886819…, and 1.3388682 is its rounding to seven decimals, not its leading digits. a34e printed the rounded
  figure and I added the ellipsis. RQ-D's D13 copied it; see r4 in the addendum of 06:58.)
- **The other figures of Sections 5–7 that can be checked from g and the box grid agree**
  (`audit/rqd/a34e_text_figures.py`, Arb at 200 bits; output `audit/rqd/outputs/a34e_text_figures.txt`).
  - Line 429: C_5 = g(2 ln 5/4) = 1.28 √(2 ln 1.25) = 0.8551004…. Line 617: the lower end 0.4463.
  - Lines 647–649 (controls): C_5 − g(Λ) ∈ [0.000496, 0.000502] for Λ ∈ [0.56323, 0.56329]. The lowered target is at
    most g(Λ) + 2·10⁻⁶ (the excess is 1.66e-6), and the box with m ∈ [3074, 3075]/4096 meets the Dirac curve.
  - Line 769: 0.8/0.85² = 1.107… < 28/25 and 0.8/1.54² = 0.337… < 17/50.
  - Line 965 (Section 7): A.38's worst bound 0.8548832 is in the box (6, 3, 6, 39) =
    [21/400, 7/100] × [663/3200, 17/80], that is [0.0525, 0.0700] × [0.2072, 0.2125], as stated.
  - The table of Section 6.1 adds up: 136 + 735 + 388 + 80 = 1,339 certified squares and 14,894,034 boxes. Each level
    holds the children of the squares not certified at the level before (837 of 860, then 408 = 4 · 102 and
    80 = 4 · 20).
  - Not checked: the hypotenuse ranges of line 652, the leaf disposition of lines 637–638 (7,874,211 leaf boxes) and
    the sample statistics of lines 1014–1041. These need RQ-D's square list, run or samples.

### Addendum (2026-10-23 04:51 UTC): RQ-D's box-level record of the Theorem 13 run, replayed leaf by leaf with my own verifier. The record is VALID; A.34 stays VALID.

- **What RQ-D filed (04:22–04:25 UTC), in answer to RQ-REF3's robustness remark 2.**
  - RQ-D reran the published computation with `verify_bandstar.py` imported unchanged (b5b55cee…). It recorded every
    leaf box with its method and parameters, in new files only.
  - MAIN_RESULT.tex (212c6f23…) and the other refereed files are unchanged, and no proof depends on the new files.
  - Data, with the md5s as filed in AUDIT_REQUEST: `outputs/bandstar_cert/bandstar_leaves.npz` 170d0ba8…,
    `bandstar_slope.json` 353cfe2a…, `record_squares.jsonl` 8d4d2db3…, `record.txt` d3ae2b07…,
    `record_summary.json` 2f94be68…, `record_env.txt` 11c9c8fd…, `replay.txt` 13c696a1… and
    `replay_selftest.txt` bcffaef6…. I also used the published per-square log `outputs/verify_bandstar_squares.jsonl`
    (73a8da42…).
  - Scripts, recorded by md5 only (neither read nor run): `scripts/bandstar_record.py` 6fcfd2e8… and
    `scripts/bandstar_replay.py` e38a1a9e….
  - Texts: CLAIMS fba092bb…, AUDIT_REQUEST c31a9c0c…, STATUS 1a72757d…, NOTES ad666fed… and README dce8b721…, with
    copies in `audit/snapshots/s0425/`.
- **The record's layout, read off the data.** RQ-D describes the format only in the docstring of
  `bandstar_replay.py`, which I do not read. From the data:
  - Units: (a, b) in 1/8192, Λ in 1/16384, m in 1/4096, corners in 2^-24. Each square owns a slice of the leaf
    arrays.
  - Each leaf has a box (Λ_1, Λ_2, m_1, m_2), a method (infeasible, chord = (O1), twopoint_C = (O3),
    twopoint_CS = (O4), taylor_B = (O2), slope), an option byte and an integer aux.
  - For an infeasible leaf the option is the number of the failing inequality. On all 3,114,781 such leaves, label j
    agrees with my test j, in the order of my `infeasible` (the two sides of (F1), (F2) and (F3), then (F4), (F5)).
  - For (O3), aux is the far point in the m variable, y_far = θ − kx/4096. This fits RQ-D's note
    "kx/4096 >= m_2 - u'". For (O2), aux is the t point jt/4096.
  - For a slope leaf, aux indexes `bandstar_slope.json`. Each piece there has a bisection path, its test, jr with
    r_eff = jr/4096, and its options.
  - Only check 4 below depends on these readings. Checks 1–3 use only the boxes.
- **Checks, all with my code.** The scripts are `audit/rqd/a34f_record_replay.py` (1978a306…),
  `a34g_record_params.py` (6e8ec6ff…) and `a34h_fine_grid.py` (dc109f68…). Their outputs in `audit/rqd/outputs/` are
  `a34f_record_replay.txt` (23fd345a…), `a34f_squares.jsonl` (c64e5690…, one line per square),
  `a34g_record_params.txt` (7677a956…, A34G_PASS), `a34h_fine_grid.txt` (cfc83250…, A34H_PASS) and
  `a34h_control.txt` (e769dfa3…). Every decision is one of my A.34 verifier `a34_bandstar_verify.py` (unchanged,
  c69392de…), in arb at 128 bits.
  1. **Squares.**
     - The record's per-square log equals the published log on all 1,676 squares (box, outcome and box count).
     - Its 1,339 certified squares are exactly the certified squares of that log: 136, 735, 388 and 80 squares of
       sides 1/128, 1/256, 1/512 and 1/1024.
     - They are dyadic and interior-disjoint, and they cover the triangle {a, b >= 0, a + b <= 1/5}.
  2. **Tiling.** In each of the 1,339 squares the leaves are interior-disjoint and tile their bounding rectangle
     exactly. That rectangle contains R_0 = [V_lo/A², V_hi/θ²] × [V_lo/A, V_hi/θ], which holds every (Λ, m)
     allowed by (F1)–(F2).
  3. **Every leaf is certified by my own procedures.** Each of the 7,874,211 leaves goes to my infeasibility test,
     my direct check (options (O1)–(O4) on my h grid) or my slope check. A leaf that none of them decides whole is
     bisected by my own rule.
     - With my A.34 h grid (0.004 · 1.12^k, 60 values), 7,862,263 leaves are certified (161 s, 8 workers).
     - 11,948 leaves in 7 squares are not, which is why a34f alone prints A34F_FAIL. Six of those squares lie along
       the hypotenuse (a + b >= 0.18), where the failures sit near (Λ, m) = (0.93, 0.86); the seventh is
       [11/128, 3/32] × [0, 1/128] (4 leaves).
     - There, RQ-D certifies squares of side 1/256 and 1/512 that my own A.34 run split further. RQ-D's h grid is
       also finer than mine (ratio 1.084).
     - The bounds of Lemma 6 hold for every h > 0, so the h grid is a free choice. With a finer grid
       (0.002 · 1.02^k, 400 values) every leaf of those 7 squares is certified (a34h, 13 s, A34H_PASS).
     - I ran a34f again with the final script, which only gained optional control arguments. All 1,339 per-square
       results and the summary are identical apart from timing.
     - So every recorded leaf holds by my own verifier. With checks 1 and 2, RQ-D's record is a complete
       certificate of Theorem 13, and it is now checked box by box with my own code.
  4. **RQ-D's labels and parameters** (a34f, a34g).
     - The counts per method are 3,114,781 infeasible, 551,105 (O1), 2,876,016 (O3), 128,597 (O4), 1,203,286 (O2)
       and 426 slope. They equal the published run (`verify_bandstar.txt` c36c17e5…) and tex lines 637–638, which
       the 03:02 addendum could not check.
     - Every (O3) far point is admissible: kx/4096 >= m_2 − u', decided exactly, also when u' = 2s is irrational.
       2,876,009 are at the smallest admissible grid value and 7 are nearer.
     - Every (O2) point is admissible: jt/4096 <= m_1 − μ_hi. 1,194,604 are at the largest grid value and 8,682
       are below it.
     - Every recorded corner is at least the exact corner (min(a_2, 1/5 − b_1), min(b_2, 1/5 − a_1)): 1,239 are
       equal and 100 are rounded up to the 2^-24 grid.
     - All 426 slope certificates have complete, prefix-free bisection paths. On all 579 pieces,
       r_eff = jr/4096 >= r_2 and r_eff <= 1/50.
     - (T3) never comes with (O5), and (T3K) does not occur. My own piece check passes 570 of the 579 pieces as
       recorded; the other 9 pass through my bisection in check 3.
  5. **Control (not part of the check; a34h control).**
     - The 80 squares of side 1/1024 lie along the hypotenuse, with a + b ∈ [0.1972656, 0.2] and
       a ∈ [0.0566406, 0.0957031]. Tex line 652 gives [0.1973, 0.2] and [0.0566, 0.0958], rounded to four digits
       (0.1973 to the nearest value, 0.0958 upwards); cosmetic.
     - Taking their 657,179 leaves whole, my fine-grid checks certify all but 34 at the true target. With the target
       lowered by 1/1000, they fail on 399,654 leaves, in all 80 squares. (RQ-D's self-test reports 421,058 with its
       own methods.) So the replay is not vacuous along the hypotenuse.
- **Verdict: the record is VALID.** It is a complete certificate of Theorem 13, checked leaf by leaf with my own
  verifier.
  - This is the fourth confirmation of the Theorem 13 computation. The other three are RQ-D's run, my own A.34 run
    (1,303 squares, 13,083,096 boxes) and RQ-REF3's (1,212 squares, 9,077,343 leaf boxes).
  - I do not audit RQ-D's replay checker (e38a1a9e…), since I do not read RQ-D's code. Its stated result agrees
    with mine.
  - A.34 stays VALID and Theorem 13 stays NEW. A.34 f1 (tex line 617) and r3 (CLAIMS D13) are still open, text
    only.

### Addendum (2026-10-23 06:58 UTC): RQ-D's text-only fixes of 05:35 (A.34 f1, A.34 r3 and the line-652 range). Text only; A.34 and A.38 stay VALID.

- **What RQ-D changed (05:35–05:36 UTC; note at the top of AUDIT_REQUEST).**
  - MAIN_RESULT.tex 212c6f23… → ac0ecf4f…, two lines of Section 6.1:
    - line 617 (my f1): "0.4463 < Λ < 0.5599" now reads "0.4463 < Λ < 0.5579";
    - line 652 (my cosmetic remark of 04:51): "a + b ∈ [0.1973, 0.2]" now reads "[0.1972, 0.2]".
  - MAIN_RESULT.pdf fed00af2… → f0fc9c23… (19 pages); RQ-D's diff `audit_diffs/MAIN_RESULT_tex_212c6f23_to_ac0ecf4f.diff`
    (c04bc807…).
  - CLAIMS fba092bb… → e62b2ae6…. D13 (NUMERICAL, my r3) now gives the Dirac range as [1.3388682…, 1.4969001…] with
    ends 1/sqrt(0.5578588…) and 1/sqrt(2 ln(5/4)), and D18 records my 04:51 replay.
  - AUDIT_REQUEST 21dd0e1d…, STATUS 81f98caa…, NOTES 9b3c0120…, README 5992442b… (it now describes the record format)
    and LAST_MIRROR 02e746f4… (05:36:21). Copies of all of these are in `audit/snapshots/s0645/`.
- **Checks**, in `audit/rqd/a34i_text_fix_check.py` (2e5efdd9…; output `audit/rqd/outputs/a34i_text_fix_check.txt`,
  35268d93…, A34I_ALL_CONFIRMED with one cosmetic remark). Arb at 200 bits; RQ-D's record is used as data only, after
  checking its md5s.
  1. **Tex.** I compared my copy of the refereed tex (212c6f23…) with the new one (ac0ecf4f…). Only lines 617 and 652
     differ, and on each only the figure changes. RQ-D's diff, applied to my refereed copy with `patch`, gives
     ac0ecf4f….
  2. **PDF.** The `pdftotext -layout` texts of fed00af2… and f0fc9c23… differ in three places only: the date under the
     title and the two figures. Both PDFs have 19 pages.
  3. **Line 617.** g > C_5 exactly on (0.4462871…, 0.5578588…). 0.5579 is the upper end rounded to four digits, and
     the old figure lay outside the range: g(0.5599) − C_5 = −1.84e-4. **f1 is settled.**
  4. **Line 652.** In `sq_box` of the record, the 80 squares of side 1/1024 have a + b ∈ [101/512, 1/5] and
     a ∈ [29/512, 49/512]. The ranges [0.1972, 0.2] and [0.0566, 0.0958] now enclose both. My remark is settled.
  5. **CLAIMS D13.** The upper end 1.4969001… and the figure 0.5578588… are correct leading digits, and the two ends
     are the right expressions. The lower end, found again by bisection in x, is 1/sqrt(0.5578588…) = 1.33886819….
     **r3 is settled in substance; see r4 for the last figure.**
  6. **README.** The record format it now gives agrees, field by field, with what I read off the data at 04:51:
     - the units, and the method codes 0–5;
     - the eight infeasibility codes, in my order;
     - kx for (O3) and jt for (O2), with the admissibility conditions I checked;
     - the slope index, and the fields of the slope pieces;
     - r_eff: the README writes min(jr/4096, 1/50), and my replay used jr/4096. On all 579 pieces jr ∈ [10, 80], so
       jr/4096 < 1/50 and the two agree; the replay is unaffected.
  7. **md5s.** The 21 files RQ-D lists as unchanged have the refereed md5s. I hashed them and did not read them. They
     are:
     - `verify_bandstar.py` b5b55cee…, `bandstar_record.py` 6fcfd2e8… and `bandstar_replay.py` e38a1a9e…;
     - the eight files of `outputs/bandstar_cert/`;
     - `outputs/verify_bandstar.txt` c36c17e5… and `outputs/verify_bandstar_squares.jsonl` 73a8da42…;
     - `verify_plus.py` c754a730… and `plus_verify_lib.py` a7db98d4…;
     - certs_v1_r0..r4 (e23d52dd…, ee9307ee…, f5fe9a23…, 6d495261…, 3033710b…) and `verify_v1.txt` 4b52e38e….
- **r4 (cosmetic, and the slip is mine).** The lower end of the Dirac range is 1.33886819…. My r3 note of 03:02 wrote
  "1.3388682…": a34e prints the arb ball to eight digits, which rounds, and I added the ellipsis. RQ-D's D13 copied
  the figure, which should read 1.3388681… (or 1.3388682, without the ellipsis).
  - D13 is NUMERICAL, and no proof uses it.
  - My a40l and the A.40 addenda use 1.338868, which is correct.
  - I have corrected my 03:02 line.
- **Verdict.** The update is text only.
  - A.34 stays VALID, and Theorem 13 stays NEW.
  - Both changed lines are in Section 6.1 (tex lines 535–667). Section 7 (tex line 668 on, A.38) is unchanged, and A.38
    stays VALID.
  - The current RQ-D tex ac0ecf4f… is the refereed 212c6f23… with the two corrected figures, so it is the version to
    quote in FULL_PROOF.pdf.
  - Open on A.34: r4 only, cosmetic.

### Addendum (2026-10-23 07:48 UTC): RQ-D applied A.34 r4 at 07:40. Text only; A.34 and A.38 stay VALID.

- **What RQ-D changed (07:40–07:41 UTC; note at the top of AUDIT_REQUEST).**
  - CLAIMS e62b2ae6… → 77201a7b…. D13 (NUMERICAL) now gives the lower end of the Dirac range as 1.3388681…, and its
    label reads "A.34 r3, r4".
  - AUDIT_REQUEST 21dd0e1d… → e39082e4… has a new note at the top. The r3 note below it gets the new figure and a
    correction marker.
  - STATUS 81f98caa… → 61897a51… and NOTES 9b3c0120… → 563ceb88… are status text. They record my 06:58 check, r4 and
    RQ-D's own sweep, and the NOTES entry of 05:36 gets the same marker.
  - Copies are in `audit/snapshots/s0742/`.
- **Checks**, in `audit/rqd/a34j_r4_check.py` (ad716fc5…; output `audit/rqd/outputs/a34j_r4_check.txt`, e38f5f7e…,
  A34J_ALL_CONFIRMED). The script reuses the helpers and the file list of my a34i. Arb at 200 bits.
  1. **CLAIMS.** Only the date line and the two D13 lines change, and on those only the figure and the label.
  2. **The figure.** 1/sqrt(L2) = 1.33886819…, so 1.3388681… gives its leading digits. **r4 is settled.**
  3. **AUDIT_REQUEST.** The only changes are the new note and the r3 note's figure and marker.
  4. **Quotes.** In all four new texts, every remaining "1.3388682…" is the old figure in quotation marks.
  5. **RQ-D's sweep, redone with my own code.** RQ-D's six texts write 11 distinct decimals with an ellipsis.
     - Each gives the leading digits of its exact value. Among them are 0.8/0.85^2 = 1.107… and 0.8/1.54^2 = 0.337…
       of tex line 769.
     - Outside RQ-D's 07:40 note they are exactly the 9 figures that RQ-D lists.
     - The note adds two, which quote my A.34 addendum (0.5578588782… and 1.33886819…). RQ-D's count of 9 omits only
       these, which changes nothing.
  6. **md5s.** The tex ac0ecf4f…, the PDF f0fc9c23…, the README 5992442b… and the 21 files of a34i are unchanged. I
     hashed them and did not read them.
- **Verdict.** The update is text only. A.34 and A.38 stay VALID, Theorem 13 stays NEW, and nothing is open on A.34.

## A.35 RQ-A U.9 (the Gaussian corner of ID*: |E|Z_K| - sqrt(2/pi)| <= (1/2) int |x| dK) — VALID; KNOWN within the project, the two-sided form and the C_5 threshold NEW as stated (2026-10-22 20:37 UTC)

**Sources.** RQ-A CLAIMS.md U.9 (8bec3483…, 19:50; copy `audit/snapshots/RQ-A_CLAIMS_2018.md`, lines 353–381) and
AUDIT_REQUEST U.9 (eef0b8a4…, filed 19:27; copy `audit/snapshots/RQ-A_AUDIT_REQUEST_2018.md`). Both are unchanged in
the store at 20:35. I did not read RQ-A's `numerics/stein_corner.py`; its counts are quoted from CLAIMS.

### Claim

Let K be a Kolmogorov probability measure on R: Z_K is centred infinitely divisible with E Z_K^2 = 1, Levy measure
x^{-2} K(dx) on x != 0 and Gaussian variance K({0}). Then, with c = sqrt(2/pi),

  |E|Z_K| - c| <= (1/2) int |x| dK(x).

Hence E|Z_K| <= C_5 = C(q5) whenever int |x| dK <= 2(C_5 - c) = 0.114431… (truncated), and ID*(C_5) holds for these K
with every theta.

### Rebuilt proof (from the hypotheses)

1. **Stein equation.** h(w) = |w| - c has E h(G) = 0, because E|G| = c. f(w) = e^{w^2/2} int_{-oo}^w h(t) e^{-t^2/2} dt
   solves f' - w f = h. Since h is even and int_R h e^{-t^2/2} dt = 0, f(-w) = e^{w^2/2} int_w^oo h e^{-t^2/2} dt = -f(w),
   so f is odd.
2. **f on (0, oo).** For w > 0, int_{-oo}^w h e^{-t^2/2} dt = -int_w^oo (t - c) e^{-t^2/2} dt = -e^{-w^2/2} + c e^{-w^2/2} M(w),
   with M(w) = e^{w^2/2} int_w^oo e^{-t^2/2} dt the Mills ratio. So f = c M - 1. Also M' = w M - 1 and M(0) = sqrt(pi/2),
   so f(0+) = 0.
3. **Derivatives.** f' = c(w M - 1), which also equals h + w f. f'' = c((1 + w^2) M - w), and
   (f''/c)' = 2wM + (1 + w^2)(wM - 1) - 1 = w M (w^2 + 3) - (w^2 + 2).
4. **Mills bound.** Put B = (w^2 + 2)/(w^3 + 3w). The exact identity B' - wB + 1 = -6/(w^2 (w^2 + 3)^2) holds. So
   r = B - M satisfies r' - w r = B' - wB + 1 < 0, i.e. (r e^{-w^2/2})' < 0. Both B and M tend to 0 at oo, so
   r e^{-w^2/2} -> 0. A strictly decreasing function with limit 0 is positive, so M < B on (0, oo).
5. **f'' on (0, oo).** By step 4, (f''/c)' < w B (w^2 + 3) - (w^2 + 2) = 0, so f'' is strictly decreasing. f''(0+) = c M(0) = 1.
   Also f'' < c((1 + w^2) B - w) = 2c/(w^3 + 3w) -> 0, so the limit L of f'' at oo is <= 0. And L >= 0: f' = c(wM - 1)
   is bounded (0 < wM < wB = (w^2 + 2)/(w^2 + 3) < 1), while L < 0 would give f'' < L/2 on a half-line and f' -> -oo.
   So L = 0 and f'' > 0. Hence 0 < f'' < 1 on (0, oo). (Completed 21:08: the 20:37 text inferred L = 0 from the upper
   bound alone. RQ-A's write-up gets f'' > 0 from the lower Mills bound M > w/(1 + w^2) instead; see the addendum.)
6. **f' is 1-Lipschitz.** f is odd, so f'' is odd and -1 < f'' < 0 on (-oo, 0). f' = h + w f is continuous on R, and
   |f''| <= 1 off 0, so f' is 1-Lipschitz. Bounds for step 8: M decreases from sqrt(pi/2) to 0, so f takes values in
   (-1, 0] on [0, oo), hence |f| < 1; and f' takes values in [-c, 0).
7. **Zero-bias identity.** Write Z = sigma G + Y, with sigma^2 = K({0}), Y the compensated Poisson integral with Levy
   measure nu = x^{-2} K on R \ {0}, and G independent of Y. Let K be finitely supported (so nu is finite), and let g be
   C^1 with g and g' bounded.
   - Gaussian integration by parts: E[sigma G g(sigma G + y)] = sigma^2 E g'(sigma G + y).
   - Mecke formula: Y = (sum of the jumps) - int x nu(dx), so E[Y g(Z)] = int x E[g(Z + x) - g(Z)] nu(dx).
   - Together: E[Z g(Z)] = K({0}) E g'(Z) + int_{x != 0} E[(g(Z + x) - g(Z))/x] K(dx) = E g'(Z + U X), with X ~ K,
     U ~ U(0, 1) and Z, U, X independent. The atom of K at 0 gives the term g'(Z).
   - Integrability: E|Z| <= 1, and g, g' are bounded.
8. **Conclusion.** With g = f: E|Z| - c = E h(Z) = E[f'(Z) - Z f(Z)] = E[f'(Z) - f'(Z + U X)]. By step 6,
   |f'(Z) - f'(Z + U X)| <= U |X|, so |E|Z| - c| <= E U · E|X| = (1/2) int |x| dK.
9. **Threshold.** 2(C_5 - c) = 0.11443178933… (Arb), so int |x| dK <= 0.114431 gives E|Z_K| < C_5. The right side of ID*
   is >= C_5 for every theta, so ID*(C_5) holds for these K.

### Independent verification (RQ-AUD code only)

`audit/rqa/a35_u9_check.py` (md5 15e4175f…, output `audit/rqa/outputs/a35_u9_check.txt`, 12.7 s):
- **Part S** (sympy, exact): M' = wM - 1 and M(0) = sqrt(pi/2) for M = sqrt(pi/2) e^{w^2/2} erfc(w/sqrt2); f = cM - 1 solves
  f' - wf = h on (0, oo); E h(G) = 0; f is odd; f' = h + wf; the formulas for f'' and (f''/c)'; the identity for
  B' - wB + 1; (1 + w^2) B - w = 2/(w^3 + 3w); the sign step for (f''/c)'; the limits. PASS.
- **Part A** (arb, 128 bits):
  - at 1,040 points of (0, 60] (k/64 for k <= 640, then 10 + k/8), B - M > 0, 0 < f'' < 1, (f'')' < 0 and
    f'' < 2c/(w^3 + 3w) are all certified;
  - c M(0) - 1 is a ball of radius 2.4e-38 around 0, and f''(1e-12) = 0.99999999999840…;
  - 2(C_5 - c) = 0.11443178933590… lies in (0.114431, 0.114432);
  - 2(sqrt(2/e) - c) = 0.11975864831568… is below 0.11976 (the A.10d correction).

  PASS.
- **Part E** (float64; evidence, not proof):
  - the two-sided inequality for 3,000 random K (1–3 atoms in [-3, 3] and an optional Gaussian part, with E|Z_K| by
    exact Poisson enumeration and the Gaussian part in closed form): 0 violations. The ratio
    (E|Z_K| - c)/((1/2) int |x| dK) lies in [-0.3166, 0.0861]; RQ-A reports [-0.293, 0.087];
  - the zero-bias identity E[Z f(Z)] = E f'(Z + U X): the largest difference over 300 compound Poisson K is 3.05e-15.
    For one K with Gaussian part 0.6, adaptive quadrature split at the kinks of f' gives -0.393993919462 on both sides;
  - the largest difference quotient of f' over 200,000 random pairs is 0.997487, and the Stein residual on [-8, 8] is
    8.9e-16.

  PASS.
- **Part H** (hostile; Nelder–Mead on the ratio in both signs, up to 2 atoms with |x| in [0.12, 5], a Gaussian part
  and Lambda <= 80):
  - the largest ratio is 0.08613, at one atom at -1.368;
  - the most negative ratio is -0.35337, at (1/2) delta_{-1.969} + (1/2) delta_{1.969}.

  Both are far from ±1: NO VIOLATION.
- A first run (`outputs/a35_u9_check_run1_gausshermite.txt`) failed only the zero-bias test with a Gaussian part. There,
  200-node Gauss–Hermite quadrature lost 6.9e-5 at the kinks of f' (f'' jumps at 0). Adaptive quadrature split at the
  kinks agrees to 12 digits. The defect was in my test, not in the claim.

### Remarks (no fix needed)

- r1: U.9 is stated "for every Kolmogorov probability measure K" and justifies the zero-bias identity by Gaussian
  integration by parts and the Mecke formula. When the Levy measure is infinite near 0, this needs the usual
  approximation, which U.9 leaves implicit: move the mass of (-eps, eps) \ {0} to 0. Both sides of the inequality are
  continuous along it, by uniform integrability (E Z^2 = 1) and dominated convergence. The project uses U.9 only for
  finitely supported K (ID* and A.34's Corollary 14 are stated for those), where the identity is direct.
- r2: RQ-A's "0.114431 (truncated)" is a correct truncation of 2(C_5 - c) = 0.1144317893….
- RQ-A's remark (i) is correct. The generic bound ||f''|| <= 2 ||h'|| (Chen–Goldstein–Shao, *Normal Approximation by
  Stein's Method*, 2011) gives int |x| dK, and the factor 1/2 uses ||f''|| <= 1 for this particular h.

### Verdict and novelty

- **VALID** (no fix).
- **KNOWN within the project.**
  - The analytic core is BF3 Lemmas 9.5–9.6, audited in A.0 (steps 4–5): the Mills bound M < (w^2 + 2)/(w^3 + 3w), by
    the same ODE comparison and the same identity -6/(w^2 (w^2 + 3)^2), and 0 < f'' < 1 with f' 1-Lipschitz for the
    Stein solution of |w| - sqrt(2/pi).
  - The one-sided bound E|Z_K| - c <= (1/2) int |x| dK for ID laws, through the same zero-bias identity, is RQ-B's
    Proposition 6(b) (A.10d).
  - The technique is the standard zero-bias form of Stein's method (Goldstein–Reinert, Ann. Appl. Probab. 7 (1997);
    Chen–Goldstein–Shao 2011). (Journal corrected 21:08; the 20:37 text said Ann. Probab. 25.)
  - NEW as stated (elementary): the two-sided form, whose lower bound comes from the same Lipschitz estimate, and the
    C_5 threshold 0.114431.
- **Use for the project.** It removes the Gaussian corner {int |x| dK <= 0.114431} from the far-region inequality of
  A.34 (step 10). A cover may assume int |x| dK >= 0.1144, which is linear in K. It gives no exact value of R(q).

### Addendum: RQ-A's U.9 write-up matches the audited proof (2026-10-22 21:19 UTC)

- **Sources.**
  - RQ-A `MAIN_RESULT_U9.tex` (12949c06…), `.md` (342bc6b2…) and `.pdf` (bff8f38a…, 4 pages), posted 20:58. Copies are
    `audit/snapshots/RQ-A_MAIN_RESULT_U9_2058.{tex,md,pdf}`.
  - RQ-A AUDIT_REQUEST 70a980df… (21:08) asks, optionally, for this check. CLAIMS 614800de… records A.35, and U.9's
    statement is unchanged.
  - The `.md` and the PDF text carry the same statements and decimals as the `.tex`.
- **The proof is the same one I rebuilt (steps 1–9).**
  - Lemma 3 gives w/(1 + w^2) < M < B by the comparison (r e^{-w^2/2})' = (beta' - w beta + 1) e^{-w^2/2}, r = beta - M.
    For beta = B the bracket is -6/(w^2 (w^2 + 3)^2); for beta = w/(1 + w^2) it is 2/(1 + w^2)^2.
  - Lemma 4: f = cM - 1, and f'' = c((1 + w^2) M - w) decreases strictly from 1 to 0, with
    0 < (1 + w^2) M - w < 2/(w(w^2 + 3)). So f' is 1-Lipschitz, |f| <= 1 and |f'| <= c.
  - Lemma 5 is the zero-bias identity for g in C^1 with g and g' bounded. Theorem 1 then follows from the Stein equation
    and the Lipschitz bound, as in my step 8.
  - The lower Mills bound gives f'' > 0 directly. My step 5 used the boundedness of f' instead (completed at 21:08,
    see the note there). Either route works.
- **My remark r1 is settled in the text.**
  - Lemma 5 proves the identity for every K, including an infinite Levy measure near 0.
  - It splits Pi = Pi_eps + R_eps and applies the Mecke formula to the finite-intensity jumps of size > eps,
    conditionally on (G, R_eps). This is integrable: |F| <= ||g||_oo |x| and int_{|x| > eps} |x| dnu <= 1/eps.
  - It then lets eps -> 0, using E R_eps^2 = K({0 < |x| <= eps}) -> 0 and dominated convergence (the integrand is
    bounded by ||g'||_oo).
  - This route differs from the approximation r1 suggested, and I checked each step. Theorem 1 holds as stated for
    every probability measure K.
- **Own checks.** `audit/rqa/a35b_u9_writeup_check.py` (output `audit/rqa/outputs/a35b_u9_writeup_check.txt`, 4.8 s):
  ALL CHECKS PASSED, 34 checks.
  - Part T (Arb, 256 bits): every decimal of the write-up is a correct truncation. These are c = 0.7978845608…,
    C(q5) = 0.8551004554…, C(q6) = 0.8559844891…, C(q5) - c = 0.0572158946…, C(q6) - c = 0.0580999283…,
    2(C(q5) - c) = 0.1144317… and 2(C(q6) - c) = 0.1161998…. Also 0.114431 < 2(C(q5) - c), and Remark 3's 0.797885 is
    a correct rounding of c.
  - Part S (sympy, exact):
    - both Mills identities, and B' and wB as printed;
    - (1 + w^2) B - w = 2/(w(w^2 + 3)) and 1 - wB = 1/(w^2 + 3);
    - (f''/c)' = wM(w^2 + 3) - (w^2 + 2) from M' = wM - 1 alone;
    - the comparison identity, f(0) = 0 and f'(0) = -c.
  - Part R (Remark 2): E|G + x| = 2 phi(x) + x(2 Phi(x) - 1) = c(1 + x^2/2 - x^4/24 + x^6/240 - …).
    - For K_eps = (1 - eps) delta_0 + eps delta_x, d/deps E|Z_{K_eps}| at 0 equals -c/2 + (E|G + x| - c)/x^2, which is
      phi(0)(-x^2/12 + x^4/120 + O(x^6)).
    - I checked this against E|Z_{K_eps}| summed exactly in mpmath (60 digits, eps = 10^-25, Richardson) at x = 0.05,
      0.2, 0.5, 1, -1, 1.54 and 3. The relative differences are below 2e-31, and the derivative is negative at all
      seven points.
- **r3 (cosmetic; Remark 2 is NUMERICAL and not part of the proof).**
  - Remark 2 says E|Z_K| - c "is of second order near delta_0".
  - Along K_eps it is first order in eps, with a coefficient of order x^2, against the bound's eps |x|/2. So it is
    second order in the atom size, not in the distance of K from delta_0.
  - The formula is right; only the phrase could be sharper.
- **The NUMERICAL ratio range.** RQ-A's sample range [-0.293, 0.087] is consistent with my Part E range
  [-0.3166, 0.0861] and my Part H extremes [-0.35337, 0.08613]. It is a sample range, not a bound.
- **A.35 stays VALID.** r1 is settled, and the novelty rating is unchanged.

## A.36 RQ-C C19(a) (first-order cost of negative mass at the q -> 0 extremal law) — VALID; NEW as stated (elementary corollary of C4(a)) (2026-10-22 20:37 UTC)

**Sources.** RQ-C CLAIMS.md C19 (29481696…, 19:49; copy `audit/snapshots/RQ-C_CLAIMS_2018.md`, lines 450–471),
unchanged at 20:35. RQ-C's AUDIT_REQUEST (f2a1ada3…) has no item for C19; I audit (a) because it is tagged PROVED.
C19(b) is NUMERICAL and not audited. I did not read RQ-C's `numerics/firstvar_sqrt2.py`.

### Claim

Let X = N - 1/2 with N ~ Poisson(1/2), and c = e^{-1/2}. As in C4(a) (A.2), put d(gamma) = E|X + gamma| - E|X| - gamma E sgn X
and D(gamma) = d(gamma) - c gamma^2. Then:

- for every g > 0, D(-g)/g^2 <= -c/2, with equality only at g = 1. So, to first order and relative to sqrt(2/e), negative
  mass costs at least 1/4 of its variance share, and the mirror jump is the only cheapest negative direction;
- in the Kolmogorov form K_eps = (1 - eps) delta_sqrt2 + eps delta_x, d/deps E|Z_{K_eps}| at 0+ is <= -sqrt(2/e)/4 for
  every x < 0, with equality only at x = -sqrt2. The derivative is -c (x - sqrt2)^2/(sqrt2 x^2) for x >= 1/sqrt2 and
  -c/sqrt2 for |x| <= 1/sqrt2.

### Rebuilt proof (from the hypotheses)

1. **Flip formulas.** X never vanishes.
   - For g > 0 and y != 0, |y - g| = |y| - g sgn y + 2(g - y)_+ 1{y > 0}. So
     d(-g) = 2E[(g - X)_+; X > 0] = sum_{k>=1} 2P(N = k)(g - (k - 1/2))_+.
   - For gamma > 0, |y + gamma| = |y| + gamma sgn y + 2(gamma + y)_+ 1{y < 0}. So d(gamma) = 2c(gamma - 1/2)_+, and
     D(gamma) = -c gamma^2 for gamma <= 1/2 and -c(gamma - 1)^2 for gamma >= 1/2.
   - P(N = 1) = c/2 and P(N = 2) = c/8.
2. **Four cases.**
   - g <= 1/2: every term vanishes, so D(-g)/g^2 = -c < -c/2.
   - 1/2 <= g <= 3/2: only k = 1 contributes, so D(-g)/g^2 = c(1/g - 1/(2g^2) - 1). Since
     1/2 - (1/g - 1/(2g^2)) = (g - 1)^2/(2g^2) >= 0, this is <= -c/2, with equality iff g = 1. This perfect square is a
     shorter form of RQ-C's derivative argument.
   - 3/2 <= g <= 5/2: k = 1, 2 contribute c(g - 1/2) + (c/4)(g - 3/2) = c(5g/4 - 7/8). So
     D(-g)/g^2 = c(5/(4g) - 7/(8g^2) - 1). The g-dependent part has derivative (7 - 5g)/(4g^3) < 0 for g > 7/5, so on
     this interval it is at most its value 4/9 at g = 3/2. Hence D(-g)/g^2 <= -(5/9) c < -c/2.
   - g >= 5/2: (g - (k - 1/2))_+ <= g - 1/2 and sum_{k>=1} P(N = k) = 1 - c, so D(-g)/g^2 <= 2(1 - c)(g - 1/2)/g^2 - c.
     (g - 1/2)/g^2 decreases for g > 1, so it is at most 8/25 there, and D(-g)/g^2 <= (16/25)(1 - c) - c. This is
     < -c/2 iff c > 32/57 = 0.5614…, and c = 0.6065….

   So D(-g)/g^2 <= -c/2 for all g > 0, with equality only at g = 1; the other three cases are strict.
3. **The Kolmogorov form.** Put gamma = x/sqrt2. Then Z_{K_eps}/sqrt2 = (N' - (1 - eps)/2) + gamma(M - eps/(2 gamma^2)), with
   N' ~ Poisson((1 - eps)/2) and M ~ Poisson(eps/(2 gamma^2)) independent. Two first-order effects:
   - For lambda < 1, E|N_lambda - lambda| = 2 lambda e^{-lambda}, whose derivative 2(1 - lambda) e^{-lambda} equals c at
     lambda = 1/2. Lowering the rate by eps/2 contributes -c eps/2.
   - The gamma-component contributes (eps/(2 gamma^2)) d(gamma) + O(eps^2). Condition on M in {0, 1}; X has no mass near
     0, so E|A - gamma mu| = E|A| - gamma mu E sgn A exactly for small mu.

   So d/deps E|Z_{K_eps}| = sqrt2 (-c/2 + d(gamma)/(2 gamma^2)) = D(gamma)/(sqrt2 gamma^2). By step 2 this is
   <= -c/(2 sqrt2) = -sqrt(2/e)/4 for x < 0, with equality only at gamma = -1, i.e. x = -sqrt2. The formulas for x >= 1/sqrt2 and
   |x| <= 1/sqrt2 follow from step 1. Since K_eps has mass 1, eps is exactly the variance share, which matches RQ-C's
   "per unit of share" normalisation D(gamma)/(sqrt2 gamma^2).

### Independent verification (RQ-AUD code only)

`audit/rqc/a36_c19a_check.py` (md5 f033b4fd…, output `audit/rqc/outputs/a36_c19a_check.txt`, 89 s):
- **Part X** (sympy, exact, and arb), PASS:
  - the case-2 identity, and the case-3 formula with its critical point 7/5, its value 4/9 at 3/2 and its decrease on
    [3/2, 5/2];
  - the case-4 derivative and the value 8/25 at 5/2;
  - c > 32/57 (arb: c - 32/57 = 0.04512715…);
  - P(N = 1) = c/2 and P(N = 2) = c/8.
- **Part D** (mpmath, 50 digits), PASS:
  - the closed form of D against the definition by direct Poisson sums, at 2,000 random gamma in [-12, 4]: largest
    difference 1.7e-49;
  - the max of D(-g)/g^2 + c/2 over 300,000 grid points of (0, 30] is 0 (to 1e-45), at g = 1;
  - the values at g = 0.999 and 1.001 are -3.04e-7 and -3.03e-7.
- **Part K** (mpmath), PASS:
  - the eps-derivative of E|Z_{K_eps}|, by Richardson extrapolation (h = 1e-7, h/2, h/4) of exact double Poisson sums, at
    24 points including ±sqrt2 and -sqrt2/2, against D(gamma)/(sqrt2 gamma^2): largest difference 2.3e-19;
  - over the negative test points the largest derivative is -0.214440971240177, at x = -sqrt2, which equals
    -sqrt(2/e)/4.

### Verdict and novelty

- **VALID** (no fix). The statement and the proof are correct as written.
- **NEW as stated** (no source found) and elementary: a corollary of C4(a) (A.2), whose limit value sqrt(2/e) is KNOWN
  (Stone's thesis, Lemma 4.4.4).
- **Scope**, as RQ-C says: first order at the single law delta_sqrt2. It does not prove U.7 (one-signed maximisers), and
  C5 near delta_sqrt2 does not need it, because A.32 covers that band for measures of either sign. It gives no exact
  value of R(q).

---

## A.37 RQ-A MAIN-6 (R(q) = T5 = 2 sqrt5 (1-q)^4 sqrt(q(1-q)) on [q6, q5]; the k = 5 regime closed) — VALID; NEW (2026-10-22 22:58 UTC)

**Sources.**
- RQ-A `MAIN_RESULT_K5.md/.tex/.pdf`, filed 22:37 UTC (md 6a573452…, tex fc7dc6a1…, PDF 1357f839…), AUDIT_REQUEST
  section MAIN-6 (0fb607ea…), CLAIMS MAIN-6 (4b4c4fc0…). Copies: `audit/rqa/k5_filed_2240/`, with RQ-A's recorded
  outputs `verify_k5_ABCDEFG.txt` (618f03d1…), `break_tests_k5.txt` (25a28321…) and `k5_stats.txt` (157003f3…).
  RQ-A's scripts are not read; their md5s are in `audit/rqa/k5_filed_2240/SCRIPTS_MD5SUMS.txt`.
- **The text audited.** My pre-audit (store log 21:40) read the whole 21:27 draft, tex 5c2fc7da… (copy
  `audit/snapshots/RQ-A_MAIN_RESULT_K5_2053.tex`). The filed tex differs from it in six places, all outside the
  mathematics: the verifier run time (line 1185), the negative-test paragraph (1243, which replaces a TBD), the run
  times in the reproduction block (1250–1253), "needed" becoming "used" (1305) and the status item (1311–1312). The
  22:30 version (389a1ce2…) lies between the two.
- **Data.** 105 data files are listed in `outputs/k5_manifest.json` (7c92bc42…); with the manifest, `k5_MD5SUMS.txt`
  (918eb069…) lists 106 files. Both lists are unchanged since my run. At 22:57 all 106 files matched, in the store
  and in my copy `audit/rqa/k5_data/`. So my full run of 21:29–21:53 was on exactly the filed data.

### Claim

Let q5 = 1-2/sqrt5 = 0.105573, q6 = 1-sqrt(5/6) = 0.087129, u = sqrt((1-q)/q), tau = sqrt(q(1-q)) and
T_k = 2 sqrt(k) (1-q)^(k-1) tau, so T5 = 2 sqrt5 (1-q)^4 tau.
- (a) For every q in [q6, q5], every n and every unit alpha, E|sum alpha_i chi_i| <= T5. With the mirror,
  R(q) = 2 sqrt5 max(q, 1-q)^4 tau on [q6, q5] ∪ [1-q5, 1-q6].
- (b) Equality holds iff alpha = +-(e_i1+...+e_i5)/sqrt5; or q in {q5, 1-q5} and alpha = +-(e_i+e_j+e_k+e_l)/2; or
  q in {q6, 1-q6} and alpha = +-(e_i1+...+e_i6)/sqrt6.
- (c) R > T5 on (0, q6) ∪ (q5, 1/2]:
  - R >= T6 > T5 below q6;
  - R >= T4 > T5 on (q5, 1/4);
  - R >= 2 tau > T5 on [1/4, 1/2].
- Corollary 1: {q <= 1/2 : R(q) = T5(q)} = [q6, q5].
- Corollary 2 (with Theorems 1–5, i.e. A.6, A.11, A.14, A.18 and A.25): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1),
  with qh = max(q, 1-q), on [q6, 1-q6] = [0.087129, 0.912871].

### Rebuilt proof (each step re-derived from the hypotheses; pre-audit of 21:40, re-checked against the filed text)

The proof follows MAIN-5 (A.25) with the target T5, the range u in [u5, u6] = [2.9107, 3.2369], the one-coordinate
threshold A_S = 1/4, and split nodes organised as trees of height at most 3: levels 0–2, plus the implicit TCS level.

1. **Parametrisation and constants.**
   - u5^2 = 4 + 2 sqrt5 and u6^2 = 5 + sqrt30; q is in [q6, q5] iff u is in [u5, u6].
   - T5 = 2 sqrt5 u^9/(1 + u^2)^5, and d/du u^9/(1 + u^2)^5 = u^8 (9 - u^2)/(1 + u^2)^6. So T5 is unimodal with its
     peak at u = 3, inside the range, and min(T5(u1), T5(u2)) is a valid lower bound on [u1, u2].
   - U- = 29106/10000 <= u5 (u5 - U- = 9.34e-5) and U+ = 3236855/1000000 >= u6 (U+ - u6 = 7.3e-7).
     T8 = 20711/50000 >= tan(pi/8), A_S = 1/4, 5 w-^8 > 1 and 5 w-^6 > 2.
   - Correct (my part A; RQ-A's B0 checks the same margins).
2. **Test vectors (Lemma kvec) and (c).**
   - For q < 1/k, E|chi_1 + ... + chi_k|/sqrt k = T_k.
   - T4/T5 = 2/(sqrt5 (1-q)), so T4 <= T5 iff q <= q5. T6/T5 = sqrt(6/5)(1-q), so T6 <= T5 iff q >= q6.
   - 2 tau < T5, since 5 (1-q)^8 > 1 on [q6, q5]. And 5 (3/4)^8 < 1 on [1/4, 1/2], so 2 tau > T5 there.
   - Correct.
3. **Reduction.** By global sign and permutation, a1 >= a2 >= |others|. Put r = sqrt(a1^2 + a2^2), the half-angle t
   in [0, tan(pi/8)] ⊂ [0, T8], b = sqrt(1 - r^2) and L = a1 chi_1 + s a2 chi_2 + b M, with
   m = mu(M) <= min(1, a2/b) <= min(1, mbar(B)). Correct.
4. **Two coordinates** (r = 1): E|L| <= max(2 tau, T2) r < T5. Correct.
5. **Bit lemmas (k = 5, three and four bits) and the OR-region identity.** These were audited in A.22 (VALID), and my
   rerun at 21:56 passes (`outputs/a22_k5_bits_rerun_2130.txt`). RQ-A's part G gives the same: 39 and 1,630 distinct
   polynomials, and equality only at q5 for +-OR_4. Correct.
6. **Cumulants, the moment recursion, power sums and sign information.**
   - The printed G_3 … G_10 are the cumulants of chi, with kappa_j = d^[j odd] G_j(w), d = u - 1/u and
     w = u^2 + u^-2 (`a37_k5_text_cumulants.py`, sympy, ALL PASS).
   - Unlike k = 4, the cumulants are not all monotone on the range. G_9' vanishes at w = 8.678789 (u = 2.926089), and
     kappa_9 = d G_9(w) has an interior maximum at u = 3.0778535. So the endpoint values do not enclose kappa_9: they
     miss 657.93 of its range.
   - The text's enclosure (exact values on root-free subintervals, interval Horner near the root) is correct. My
     verifier uses its own certified enclosure, with the critical point located to width 6.9e-70.
   - Correct.
7. **Objective bound (T0)–(T3) and the one-coordinate cells (a1 <= 1/4).** As in A.25 items 7–8, with T5 and degree
   ten. Correct.
8. **Convexity, patches, peeling (Lemma cond) and positive peeling.**
   - mu(M^(i)) <= kappa(mu_i) = min(1, mu_i/sqrt(1 - mu_i^2)), and kappa is nondecreasing.
   - The patch p_{2+l}(xi) reproduces E|L| = E F_p(M^(l)) for every sign vector.
   - Correct.
9. **Vertex sets, the cone lemma, facet minima (exact P4), the envelope, the vertex-certificate lemma and lpv.** As in
   A.25 items 10–13, in dimension up to 6, i.e. five patch parameters. Correct (RQ-A's audit point 3).
10. **The near-circle lemma and tests (A)/(B)** (tail constant 27/128). Correct, and no ncA or ncB box occurs.
11. **Lemma 29 (the near-sphere bound) and the piece tests (A_n)/(B_n), n = 3 … 6** (RQ-A's audit point 2).
    - For n = 3, 4 the bound G_n(c) <= T5 |c| is the bit lemma (A.22), which is valid only on [q6, q5].
    - For n >= 5 it is the OR-region identity with T_n <= T5. (A_n) requires s = 1 and the OR-region condition on the
      whole piece. On the range, T_n <= T7 < T6 <= T5 for n >= 7.
    - Equality holds only at b = 0 with all a_i = n^(-1/2): for n = 5 always, for n = 4 only at q5, and for n = 6 only
      at q6.
    - Correct.
12. **Split nodes (Definition 30, Lemma 31; RQ-A's audit point 1).** The proof is by induction on the height, with a
    TCS piece counted as a TCN piece.
    - mu <= m_c: the node certificate, with cap m_c.
    - Coefficient +mu:
      - an (A)/(B) piece, with equality only at b = 0;
      - TC+, with cap kappa' >= kappa(n2). For mu = 1 the remainder is empty, F_p is constant and Z = chi' is in the
        class;
      - TCN/TCS, a child of smaller height. For mu = 1 a long equal-coefficient Z is in the child's class.
    - Only -mu:
      - SG: p3(M) <= -mu^3 + (1 - mu^2)^(3/2) = phi(mu) <= phi(n1) < 0, by ||.||_3 <= ||.||_2 and 2 n1^2 > 1, with cap
        >= min(n2, khat);
      - or TC-, as TC+ with sign -1.
    - The split coordinates are distinct, because each level peels a new coordinate.
    - Correct.
13. **m-split boxes (Lemma msplit).** Every point with r < 1 is positively peeled through the empty list, and
    mu_1 = m <= min(1, mbar(B)). Correct.
14. **Proof of Theorem 6 and the corollaries** (RQ-A's audit points 5–6).
    - The cases: a1 = 1; a1 <= 1/4 (the cells); r = 1; otherwise a box. No small box is needed, since a1 > A_S; lpv
      is strict and ms <= T5.
    - Closed boxes with disjoint interiors and full volume fill the closed region.
    - Equality: only where no strict certificate is used, which is b = 0 in the exact near-sphere tests at the three
      extremisers of (b).
    - Corollary 2: for k <= 4, 5 (4/5)^(5-k) = 2.048, 2.56, 3.2, 4 >= k. For k >= 6, (k/5)(5/6)^(k-5) is 1 at k = 6 and
      decreases, with ratio <= 35/36.
    - Correct.

**Scope (RQ-A's audit point 4).** (A3), (A4) and (A6) rest on the bit lemmas and on T6 <= T5, which hold only on
[q6, q5]. The text uses the data only there (Remark 2), and the boxes reaching into [U-, u5) or (u6, U+] are used
only at points of the theorem's range.

### Independent computer verification (RQ-AUD code only)

`audit/rqa/k5_verify.py` (6bc00422…) extends my A.25 verifier to k = 5, with certified kappa enclosures. Full run on
the filed data (21:29–21:53, 24.6 min on 8 cores, `outputs/k5_verify_full_2130.txt`, 478be333…): ALL CHECKS PASSED.

| part | what | result |
|---|---|---|
| M | md5 of the 106 files against `k5_MD5SUMS.txt` | 0 mismatches |
| A | constants, T5 unimodal, kappa enclosures (interior max of kappa_9), moment identities | PASS |
| B | 861 cells tile [U-, U+] x [0, 1/4]; for each sign the boxes tile [U-, U+] x [0, T8] x [1/4, 1] (68 + 33 file regions, no overlaps, full volume); kinds only lpv (3,804 + 1,059) and ms (4,303) | PASS |
| C | 861/861 one-coordinate cells (degree 10, Theta_1 for T5) | 0 failures |
| D | 52,292/52,292 vertex-certificate sets (784,616 vertices; 9,168 / 14,735 / 17,399 / 10,990 with 2–5 patch parameters); no cone test needed a split | 0 failures |
| F | 4,303/4,303 split trees: covers, caps, phi, TCS and SG conditions; nodes 4,303 / 4,873 / 3,958 at levels 0 / 1 / 2; near-sphere pieces 58 + 127 (A4), 1,769 + 1,431 (A5), 644 (A6) | 0 failures |

Further checks:
- `k5_negative.py` (`outputs/k5_negative_full_2130.txt`, ed849c23…): every corruption is rejected and every control
  accepted.
- `k5_semantic.py` (`outputs/k5_semantic_full_2130.txt`, 7c764739…): 40,800 samples of (alpha, u), with 0 violations.
  The smallest slacks occur only at the three extremisers of (b).
  - The sampler puts extra samples near u5 and u6, on both sides, and its extremiser sweep includes U- and U+.
  - So 1,574 samples lie in [U-, u5) or (u6, U+], where a near-sphere step makes no claim, as the theorem's range
    requires. Every sample in [u5, u6] is claimed by some step.
- `a22_k5_bits.py`: the rerun passes.
- `a37_k5_table_check.py` (5096b8fb…; output af3d0736…): Table 1 and Remark 4 recounted from the data. Every number
  matches, except the height counts in remark r1.
- `a37_k5_hostile.py` (e310898a…; output 2a1fd7fb…): local maximisation of E|alpha . chi|/T5 for n = 5 … 14 at five
  values of q. The maximum ratio is 1.000000000000, attained only at the equality cases of (b).
- (Corrected at 06:12: until then these two lines gave the outputs' md5s as the scripts'. Neither file has changed
  since its commit.)
- Provenance: the 54 files that RQ-C computed match `RQC_MD5SUMS.txt`.

**RQ-A's own run agrees with mine count for count** (`verify_k5_ABCDEFG.txt`, 4449 s): 861 cells; 8,107 + 1,059 boxes;
52,292 sets with 784,616 vertices and the same split by patch parameters; 4,303 m-split boxes, with the same piece
counts by type and level; and the bit lemmas. Its negative tests (`break_tests_k5.txt`) reject all 799 corrupted
records in 21 tests, and its 4 sanity checks hold. I recounted the 799 from the listed cases.

### Remarks

- r1 (cosmetic, unchanged in the filed text). Table 1 and Remark 4 count heights by explicit TCN nesting (2,029 /
  1,030 / 1,244; 2,274 nested). Definition 30 counts a TCS piece as a TCN piece, as the induction of Lemma 31 needs.
  By that definition the heights are 2,017 / 809 / 1,348 / 129, with 2,286 nested. The proof is unaffected; only the
  descriptive table uses the other convention.

### Verdict and novelty

- **VALID** (no fix). Every step holds as stated, and every computer step passes an independent exact re-check on
  exactly the filed data.
- **NEW.** This is the first determination of R(q) on [q6, q5], and it closes the k = 5 regime.
  - Literature re-check, 2026-10-22 22:00 UTC: Ivanisvili–Stone (arXiv:2407.04835) and Stone's 2025 thesis give
    non-sharp bounds. The lower bound R >= T5 is KNOWN (Stone, Thm 4.3.1). No source states the k = 5 regime.
- **Use for Conjecture S.** With A.6, A.11, A.14, A.18 and A.25, Conjecture S holds on [q6, 1-q6].
  - By A.26, the minimum of C(q) over (0, q6] is C(q6) = C_6 = 0.855984489…. By A.28 the support lies in
    [-A'(q6), A'(q6)], with A'(q6) = 1.51455 < 1.54.
  - So Conjecture S for all q follows from E|Z_K| <= C_6 on the far region of A.34. A.34 and A.38 hold with C_5, hence
    with C_6 > C_5.
  - The open step is therefore E|Z_K| <= C_6 on F_light, finitely supported, on [-1.51455, 1.51455]. RQ-B's
    Theorem 13.1 targets the stronger 171/200 = 0.855 on [-1.54, 1.54].
- Status per LOCKED_NOTE: ready for an independent referee.

**Addendum (2026-10-23 01:05 UTC): RQ-A applied r1 (23:04–23:06 UTC); text only; A.37 stays VALID, r1 is settled.**
- Files: MAIN_RESULT_K5.tex 5b13f960…, .md adb359aa…, .pdf 1928ab29…, CLAIMS 07d8765b…, AUDIT_REQUEST 35c783bc… and
  `outputs/k5_stats.txt` e4fa983a…. My copies in `audit/rqa/k5_r1_2306/` are byte-identical to the store at 00:59.
- The tex differs from the audited fc7dc6a1… in three places: the Table 1 caption, Remark 4 and the status item.
  The md also updates its status paragraph. k5_stats gains one line, the heights by Definition 30. The data, the
  lemmas and the proofs are unchanged.
- The new numbers are my counts: heights 2,017 / 809 / 1,348 / 129, with 2,286 of height at least one.
- Remark 4 also gains a sentence: the trees of height three are those with a TCS piece at level two, and they are
  exactly the 129 boxes with six-coordinate pieces. `a37c_k5_r1_check.py` (50553aba…, output
  `outputs/a37c_k5_r1_check.txt`, 1 s) checks box by box that the three sets are equal. No level-2 TCS piece lacks
  sub-pieces.
- A correction to my own output: the line "height >= 1: 2157" in `outputs/a37_k5_table_check.txt` adds heights 1
  and 2 only. The right count is 2,286, as r1 states.
- RQ-REF2 (`RQ-REF2/REFEREE.md` bd18da81…, 01:05) rates MAIN-6 VALID in this tex, 5b13f960…, with no fixes, and its
  counts agree with mine. A.37 now meets the LOCKED_NOTE criterion.

---

## A.38 RQ-D D21–D23 (Lemmas 18–24; Theorem 16, the heavy far region; Corollary 17) — VALID; Theorem 16 and Corollary 17 NEW (2026-10-22 22:51 UTC)

**Sources.**
- RQ-D AUDIT_REQUEST.md c57b91c3… (third request, filed 22:45 UTC), CLAIMS.md ed68d60e… (D21–D23), MAIN_RESULT.tex
  9498b44f… and .pdf ee067424…. Copies of the filed files: `audit/rqd/heavy_2247/`. Copies as read from 22:30 on:
  `audit/rqd/heavy_2230/` (PDF 6a325619… and ee067424…, tex 72c0700d…, CLAIMS bc8f02d7… and ed68d60e…).
- The tex differs from the version audited in A.34 (bba5c599…) in the title, the abstract and Section 7, which is
  inserted after old line 660, as RQ-D says. Sections 1–6 are unchanged, so A.32 and A.34 cover them. Between 22:33
  (72c0700d…) and the filed tex, only Section 7.4 changed: one sentence ("A piece bound that is not a finite ball
  stops the verification"), the stamps and the library md5 of the recorded run, the description of the first
  verifier, and three rounded decimals.
- Certificate data: `outputs/plus_cert/certs_v1_r0.jsonl` … `certs_v1_r4.jsonl` (e23d52dd…, ee9307ee…, f5fe9a23…,
  6d495261…, 3033710b…). I copied them at 22:30 to `audit/rqd/heavy_2230/plus_cert/`, and they were unchanged in the
  store at 22:50.
- I read RQ-D's recorded outputs (`verify_v1.txt` 4b52e38e…, the controls and the self-tests) for their counts only.
  RQ-D's scripts are not in my repository and I did not read them. Their md5s are in
  `audit/rqd/heavy_2247/SCRIPTS_MD5SUMS.txt`: `verify_plus.py` c754a730… and `plus_verify_lib.py` a7db98d4…, as
  filed.

### Claim

Put tau = 17/20, A = 77/50, V+ = K([tau, A]), V- = K([-A, -tau]), M(a, b) = a tau^2 + b A^2 and
Q(a, b) = (a tau + b A)^2/(a + b).
- **D21, the lemmas.**
  - Lemma 18 (chord reduction): for K_+ on [tau, A] with nu = x^{-2} K_+, the chord rates are
    a+ = int (A - x)/(A - tau) dnu and b+ = int (x - tau)/(A - tau) dnu. Then (i) Q(a+, b+) <= K_+(R) <= M(a+, b+),
    and (ii) replacing K_+ by K_+^# = a+ tau^2 delta_tau + b+ A^2 delta_A raises E psi(Z_{K_+ + W}) for convex psi of
    linear growth.
  - Lemma 19: M, Q and M - Q are nondecreasing in each rate, and Q >= max(a tau^2, b A^2).
  - Lemma 20 (box reduction): the rates lie in [0, 28/25] x [0, 17/50]. If they lie in a box B, then B is not empty
    and E|Z_K| <= E h_B(Z_W) for some W in W_B, where h_B(r) = E|tau(N_a1 - a1) + A(N_b1 - b1) + r| and W_B is the set
    of measures on [-A, tau] ∪ {A} with mass mu_B and W({A}) <= cap_B.
  - Lemma 21: the moments of Z_W follow from its cumulants, and (kappa_3, kappa_4) lies in R_B.
  - Lemma 22: a linear-functional bound for W_B.
  - The certificate inequalities: (a) cumulant ranges, (b) Farkas emptiness, (c) a Lagrangian bound with McCormick,
    Hölder and cell rows.
  - Lemma 23 (majorant test) and Lemma 24 (cell certificate).
- **D22, Theorem 16.** If K is a probability Kolmogorov measure on [-1.54, 1.54] with 1/2 <= K([0.85, 1.54]) < 4/5,
  or with 1/2 <= K([-1.54, -0.85]) < 4/5, then E|Z_K| < C_5. The proof is computer-assisted.
- **D23, Corollary 17.** If E|Z_K| <= C_5 for every finitely supported probability K on [-1.54, 1.54] with V+ < 1/2
  and V- < 1/2, then the hypothesis of Corollary 14 holds. Hence ID* holds on [-1.54, 1.54], and C5 holds by
  Corollary 15.

### Rebuilt proof (from the hypotheses)

1. **Lemma 18.**
   - Since tau(A - x) + A(x - tau) = (A - tau) x, a+ + b+ = Lambda = nu(R) and a+ tau + b+ A = m = int x dnu.
     Lambda <= tau^{-2} K_+(R) is finite, because x >= tau > 0 on the edge. So K need not be finitely supported.
   - (i) Q(a+, b+) = m^2/Lambda <= int x^2 dnu = K_+(R) by Cauchy–Schwarz. Also x^2 lies below its chord on
     [tau, A], so K_+(R) <= M(a+, b+).
   - (ii) Z_{K_+} = S_N - m with N ~ Poisson(Lambda) and i.i.d. jumps of law nu/Lambda. The two-point law on
     {tau, A} with the same mean dominates each jump in convex order, by the chord inequality for convex phi.
     Replacing the jumps one at a time (convex phi(. + s)) and summing over N gives the convex-order increase. By
     colouring, the new sum is tau N_{a+} + A N_{b+} with independent counts. The independent Z_W is then added by
     conditioning. All expectations are finite because psi has linear growth and every variable is square integrable.
2. **Lemma 19.**
   - (a tau^2 + b A^2)(a + b) - (a tau + b A)^2 = ab (A - tau)^2, and ab/(a + b) is nondecreasing in each variable.
   - With s = a tau + b A, d_a Q = s (a tau + b(2 tau - A))/(a + b)^2 and d_b Q = s (a(2A - tau) + b A)/(a + b)^2.
     Both are >= 0, the first because 2 tau = 1.7 > A = 1.54. Without 2 tau >= A, the emptiness test Q(a1, b1) >= 4/5
     would need the box minimum of Q instead of its lower corner.
   - Q(a, b) >= Q(a, 0) = a tau^2 and Q(a, b) >= Q(0, b) = b A^2. Q is continuous at 0 because 0 <= Q <= M.
3. **Lemma 20.**
   - (i) max(a+ tau^2, b+ A^2) <= Q+ <= V+ < 4/5, so a+ < 0.8/tau^2 = 1.1073 < 28/25 and b+ < 0.8/A^2 = 0.33733 <
     17/50.
   - (ii) Emptiness. Q1 <= Q+ <= V+ <= M+ <= M2 with V+ in [1/2, 4/5). So Q1 >= 4/5 or M2 < 1/2 is impossible.
   - The rest. W0 = K|[-A, tau) has mass 1 - V+, and W1 = W0 + (a+ - a1) tau^2 delta_tau + (b+ - b1) A^2 delta_A has
     mass 1 - V+ + M+ - M1. Then K_+^# + W0 = K_c + W1 with K_c = a1 tau^2 delta_tau + b1 A^2 delta_A, whose Z is C_B.
     W1 lives on [-A, tau] ∪ {A}. W0 has no mass at A, so W1({A}) = (b+ - b1) A^2 <= cap_B.
   - W1(R) <= mu_B is equivalent to V+ - M+ >= max(Q2, 1/2) - M2, and V+ >= max(Q+, 1/2). If Q2 <= 1/2, then
     1/2 - M+ >= 1/2 - M2. If Q2 > 1/2, then Q+ - M+ >= Q2 - M2, since M - Q is nondecreasing.
     - So mu_B correctly uses the upper corner (Q2, M2). The rest must absorb the chord excess M+ - V+ >= 0, which is
       largest at the upper corner. This is the trap h1 of my F_light notes. RQ-D avoids it.
   - Padding. W = W1 + (mu_B - W1(R)) delta_0 is in W_B, and the atom at 0 is a Gaussian part. Then
     E|C_B + Z_W1| <= E|C_B + Z_W1 + sigma G| by Jensen, conditionally on C_B + Z_W1.
4. **Lemma 21.**
   - The cumulant generating function int (e^{sx} - 1 - sx) x^{-2} dW is entire, because W has compact support.
   - M' = K' M gives P_n = sum_{i=2}^n C(n-1, i-1) kappa_i P_{n-i}, with kappa_1 = 0 and kappa_2 = mu_B.
   - With w = W({A}) <= cap_B and W([-A, tau]) = mu_B - w: kappa_3 <= tau (mu_B - w) + A w,
     kappa_3 >= -A mu_B, and 0 <= kappa_4 <= A^2 mu_B. This is R_B.
5. **Lemma 22**, and (a), (b), (c).
   - Lemma 22: int R dW <= (mu_B - w) S + w R(A) <= mu_B S + cap_B (R(A) - S)_+, since 0 <= w <= cap_B.
   - (a): kappa_j = int g dW + s3 kappa_3 + s4 kappa_4 with g = x^{j-2} - s3 x - s4 x^2. The lower bound L_j uses -g
     with its own (s3, s4).
   - (b) uses g = -s3 x - s4 x^2, for which 0 = int g dW + s3 kappa_3 + s4 kappa_4 <= Phi.
   - (c), McCormick: the four rows are (X - X-)(Y - Y-) >= 0 and its three companions.
     - For t = 2, X = kappa_{alpha_1}.
     - For t > 2, X = w_{alpha'}, the variable of the prefix. Its range is the interval product of the factor ranges,
       which is valid because w_{alpha'} = kappa^{alpha'} exactly.
   - (c), Hölder: with P = W/mu_B and p_i = alpha_i - 2 >= 1, prod_i E_P|x|^{p_i} <= E_P|x|^{s_alpha} (Lyapunov).
     So |kappa^alpha| <= mu_B^{t-1} int |x|^{s_alpha} dW. This needs W(R) = mu_B exactly, which the padding gives
     (RQ-D's risk 4).
   - (c), assembly: adding nonnegative multiples of the rows gives c'' + int R dW + sum e'_alpha w_alpha.
     R(x) = sum p'_j x^{j-2} + sum gamma_s |x|^s is a polynomial on [-A, 0] and on [0, tau]. Lemma 22 bounds
     int R dW, and w_alpha in [kappa^{alpha,-}, kappa^{alpha,+}] bounds the rest. Any nonnegative multipliers give a
     valid bound, so clipping negative entries to 0 is sound.
6. **Lemma 23.**
   - (i) On E = {N_a1 <= n_a, N_b1 <= n_b} the sum is exact. On E^c, |C + r| <= |r| + |C|, and
     E[|C|; E^c] <= (T E C^2)^{1/2}.
   - (ii) C_B >= -tau a1 - A b1 >= -L, so h_B(r) = r for r >= L. For r <= -L, the identity
     |C + r| = |r| - C + 2(C - |r|)_+ (checked in both cases C >= |r| and C < |r|) and E C_B = 0 give
     h_B(r) <= -r + 2E(C - L)_+ <= -r + delta.
   - (iii) The nonnegative Taylor coefficients at +-L give phi >= h_B outside [-L, L]. On [-L, L], phi + eps >= H.
7. **Lemma 24 and the proof of Theorem 16.**
   - Reflection maps Z_K to -Z_K and exchanges V+ and V-.
   - The rates lie in some leaf box B. By Lemma 20(ii) B is not empty, so it has a cell tiling of R_B.
   - (kappa_3, kappa_4)(W) lies in some cell. That cell is nonempty, so its certificate is not an emptiness
     certificate, and E|Z_K| <= beta + eps < C_5.
   - The inequality is strict because the final comparison is certain.
   - No approximation step is needed for K that are not finitely supported. Lemma 18 needs only nu(R) < oo, and W is
     a finite measure with compact support.
8. **Corollary 17.** A finitely supported K in F is either light (by the hypothesis) or heavy (by Theorem 16).
   Corollary 14 (A.34) and the last sentence of Corollary 15 (A.34) finish the proof.

### Independent verification (RQ-AUD code only)

`audit/rqd/a38_heavy_verify.py` (md5 cdeac9f5…, output `audit/rqd/outputs/a38_heavy_verify.txt`, 70 s on 8 cores):
- **Method.**
  - Everything is decided in exact rationals (python-flint fmpq), except the Poisson probabilities, which are 200-bit
    arb balls whose upper ends are converted to exact dyadics.
  - Each polynomial upper bound is a float guess S, proved by an exact Sturm count showing that S - p has no root on
    the interval. RQ-D instead uses Taylor bounds with bisection.
  - My own code: the moment recursion, the tuple set (81 tuples, maximal length 5, prefix-closed; RQ-D reports the same
    count), the Lagrangian assembly from the rows as stated in (c), and the Poisson truncation
    (n_a = a1 + 14 sqrt(a1) + 30, which is not RQ-D's).
  - Terms with pi < 1e-25 are merged into T and e, using pi |c + r| <= pi |r| + pi |c|. This only raises H.
    delta is computed from all terms.
  - On each piece of [-L, L], the sign pattern of H is read at the midpoint. The affine upper bound adds the ball
    radius of the slope times max(|u|, |v|).
- **What is taken from the data:**
  - the box and cell indices and the status;
  - the 17 coefficients of phi and L;
  - the multipliers: cell, McCormick, Hölder, the (s3, s4) pairs of the ranges, and the Farkas pair.

  mu_B, cap_B, R_B, the ranges, beta, H, T, e, delta and eps are recomputed. The generator's `bound`, `lp`, `worst`
  and `t` are used only in the comparison printout. My reading of `rmult` (first pair for L_j, second for U_j) is
  the layout that RQ-D documents in the filed request.
- **Results** (ALL PASS):
  - Tiling: the 436 leaves (256 initial boxes, levels 4–8) tile [0, 28/25] x [0, 17/50] exactly, checked by marking
    a fine grid with every index inside its grid.
  - The 156 boxes marked empty pass the exact test Q(a1, b1) >= 4/5 or M(a2, b2) < 1/2.
  - The 280 certified boxes carry 1,237 cell certificates: 1,236 ok and 1 Farkas-empty. The cells tile R_B in every
    certified box.
  - 0 failures, 37,081 proved sups and 69,376 majorant pieces.
  - The worst beta + eps is 0.8548832 < C_5 = 0.8551004555 (box [6, 3, 6, 39], cell [2, 3, 1]; RQ-D stores
    0.8548832169680262). The margin is 2.17e-4.
  - For the worst cell of each box, my beta + eps minus RQ-D's stored bound lies in [-9.701e-10, +1.005e-12]. The
    positive end is my own padding eta >= 1e-12. The two independent computations agree to float accuracy.

**Controls** (`a38c_heavy_negative.py`, md5 2f2c87a4…, output `outputs/a38c_heavy_negative.txt`, 10 s). Each
corruption is rejected:
- a box record dropped;
- a box index moved out of its grid (RQ-D's fix (1));
- one cell of a certified box dropped;
- c_16 made negative (the right tail test fails);
- the Farkas pair set to (0, 0);
- a certified box relabelled "empty";
- L below tau a1 + A b1.

Two further controls: the threshold set to my worst value minus 1e-9 fails and plus 1e-9 passes; and a neutral change
c_0 - 1e-3 moves beta by exactly that amount.

**Semantic tests** (`a38b_heavy_semantic.py`, md5 eab0ed9a…, evidence, not proof). For random heavy K, the test
computes exact E|Z_K|, the chord rates, the leaf box, W as constructed in Lemma 20(ii) and its cell. It then checks
every link: the box is not marked empty and the cell has no emptiness certificate; the padding is >= 0;
W({A}) <= cap_B; L_j <= kappa_j(W) <= U_j for j = 3..16;
E|Z_K| <= E h_B(Z_W) <= E phi(Z_W) + eps <= beta + eps < C_5.

| mode (laws, seed) | E h_B - E\|Z_K\| | beta - E phi | E phi + eps - E h_B | beta + eps - E\|Z_K\| | largest E\|Z_K\| |
|---|---|---|---|---|---|
| random (300, 1) | 8.2e-6 | 5.5e-4 | 1.31e-2 | 0.0299 | 0.815156 |
| edge (300, 2) | 5.0e-5 | 1.28e-3 | 2.15e-2 | 0.0324 | 0.810679 |
| kstar (200, 3) | 9.8e-5 | 2.76e-3 | 1.03e-2 | 0.0193 | 0.826424 (bound 0.854740) |

The gaps are the smallest over the sample. All 800 laws pass every link.

**Hostile checks.**
- The two places where V+ >= 1/2 is used: mu_B through max(Q2, 1/2), and the emptiness test M(a2, b2) < 1/2. Both
  are checked above.
- The excess bookkeeping: the excess M+ - V+ goes to the rest, at the upper corner, as in step 3.
- The cap on the atom at A comes from (b+ - b1) A^2 only, since W0 has no mass at A.
- The chord step itself: 2,000 random K in my float tests of 21:26 (`audit/far/far_cx_tests.py`), no violation.
- Far-region searches: over F the best value is 0.8266648 (K*). The best laws found sit at V+ = 4/5^-, on the
  boundary with A.34's band region, about 0.028 below C_5.

### Remarks

- r1 (provenance, settled by the filing). At 22:30 the store's `plus_verify_lib.py` (8111a518…) was not the a7db98d4…
  of the recorded run of 22:34, and the store tex (bba5c599…) was older than the PDF. Both are fixed in the filing.
  RQ-D's two self-found gaps (the box indices and the non-finite skip) do not affect my verifier: mine checks the
  grid range, and it uses no NaN-prone operations, because everything except the Poisson balls is exact.
- r2 (settled). At 22:30 CLAIMS said "audit requested", but AUDIT_REQUEST had no third request; it was filed at
  22:45.
- r3 (cosmetic). Section 7.4 of the PDF does not describe the JSON layout of the certificates; the filed request
  does. For the audit the layout does not matter, because any multipliers give a valid bound.

### Verdict and novelty

- **VALID** (no fix). Every lemma holds as stated, and the certificate passes an independent exact check.
- **NEW** (no source found): Theorem 16 and Corollary 17.
  - Lemma 18 is KNOWN in kind. The two-point law on the ends of an interval is the convex-order maximum for a given
    mean, and convex order is preserved by compound Poisson sums (Shaked–Shanthikumar, *Stochastic Orders*, §3.A).
  - The moment and McCormick relaxation is standard technique (McCormick 1976; moment-problem duality).
  - Lemmas 19–24 are elementary.
- **Consequence for the chain.** With A.25, A.26, A.28 and A.34, Conjecture S for all q (equivalently ID*(C_5) on
  [-1.54, 1.54]) and C5 now rest on one inequality: E|Z_K| <= C_5 on F_light = {V+ < 1/2, V- < 1/2}. That is RQ-B's
  Theorem 13.1, to be audited in A.39. If MAIN-6 (A.37) is VALID, the target relaxes to C_6 = 0.8559845, but this
  heavy part is certified with C_5 and needs nothing more.
- It gives no exact value of R(q) by itself.

**Addendum (2026-10-23 01:05 UTC): RQ-D's changes after the verdict are text only; A.38 stays VALID, r3 is settled.**
- Files: AUDIT_REQUEST addendum of 23:25 (6308050f…), MAIN_RESULT.tex 212c6f23…, PDF fed00af2… (19 pages) and CLAIMS
  b9b3d0d9…. Copies are in `audit/snapshots/s0005/RQ-D/`.
- The tex differs from the audited 9498b44f… in two places in Section 7.4:
  - A new paragraph, "Certificate files", describes the JSON layout. It agrees with the reading of my verifier, and
    it settles r3.
  - The last paragraph is replaced by "The design's value (not part of the proof)". It shows that the certified cell
    bound is at least J(K), the value of the design with exact moments of W_0 and no boxes, cells or relaxations.
    I checked the four-line argument: Y' has the moments of Z_W up to degree 16, so Lemma 23 and (c) give
    E h_B(Y') <= beta + eps, and Jensen gives E h_B(Y') >= E h(Y). The paragraph also reports float searches with J
    up to 0.8390.
- CLAIMS changes only status labels.
- Lemmas 18–24, Theorem 16, Corollary 17, the verifier and the certificates are unchanged.

---

## A.39 RQ-B F18 (MAIN_RESULT §13: Lemmas S1–S5, C, D, E; Theorem 13.1, the light far region) — VALID; Theorem 13.1 NEW (2026-10-23 01:05 UTC)

**Sources.**
- RQ-B files:
  - rq/AUDIT_REQUEST.md §7 (8baa91a7…, updated 23:28 UTC; first filed 22:22–22:37 as e1705191…);
  - CLAIMS.md F18 (9de8c9c5…);
  - MAIN_RESULT.md §13 (b47f2945…; tex e4193842…, PDF a6901915…);
  - STATUS.md 6be8ef66… and NOTES_FOR_TEAM d57ec38d….
- Copies as filed: `audit/rqb/nsplit_0005/` (read 00:04–00:05 UTC). Cases 2 and 3 as read at 23:05:
  `audit/rqb/light_2305/`.
- Certificate data in `RQ-B/numerics/cover_final/`: `nsplit_D14.jsonl.xz` 0883b5d9… (case 1), `chord_D14.jsonl.xz`
  3d7366f9… (case 2) and `light_vl025_D18.jsonl.xz` 2bbb7484… (case 3). My copies are byte-identical (checked
  00:40).
- I read RQ-B's recorded checker outputs (`*.check.out`, `reproduce_flight.out`) for their counts only. RQ-B's
  programs are not in my repository and I did not read them. Their md5s are in `audit/rqb/nsplit_0005/SCRIPTS_MD5SUMS.txt`:
  `far_verify.py` 250b89cc…, `cover_check.py` a1035179…, `cover_common.py` 8dcd1e43…, `far_cert.py` e29c117d…,
  `cover_driver.py` 97df2c94…, `cover_semantic.py` 1fbbc95d…, `cover_controls.py` be976156… and
  `reproduce_flight.sh` c2328dc9….

### Claim

Put A = 77/50, theta = 17/20 and delta = 1/20. For a finitely supported probability measure K on [-A, A], put
V+ = K([theta, A]) and V- = K([-A, -theta]).
- **Theorem 13.1.** If V+ < 1/2 and V- < 1/2 (the light far region F_light), then E|Z_K| <= 171/200 = 0.855, which is
  below C_5 = 0.85510045547. The proof is computer-assisted.
- **The lemmas.**
  - S1: the two-point spread of a window [a, b], by Poisson thinning.
  - S2: the window mass from the rates p_a and p_b, and the box bounds V_lo <= K(W) <= V_hi.
  - S3: the lower corner of the box, with a top-up to the mass mu.
  - Corollary S4: E|Z_K| <= E h_P(Z_K').
  - S5: a lower bound s_lo for the part beyond theta of a window that straddles theta.
  - C: the cell certificate. It combines a polynomial majorant, cumulant ranges, McCormick, tangent and
    Cauchy–Schwarz rows, and an x-dual.
  - D: the three cases.
  - E: the cells. There are 7,956, 60 and 537 roots, plus a subdivision rule.
- **Use.** With RQ-D's Theorem 16 and Corollary 17 (A.38), it gives the hypothesis of Corollary 14 (A.34). Hence
  ID*(C_5) holds on [-1.54, 1.54], and C5 holds.

### Rebuilt proof (from the hypotheses)

1. **Setting.** Z_K = sigma G + sum_x x (N_x - lam_x) with lam_x = K({x})/x^2, and kappa_j = int x^{j-2} dK. The
   two facts used are (CO1), conditional Jensen, and (CO2), adding an independent variable to both sides. The
   reflection K -> K(-dx) maps F_light to itself and keeps E|Z_K|.
2. **Lemma S1** (0 < a < b).
   - Thin each N_x into independent Poisson parts N_x^a and N_x^b, with means lam_x (b - x)/(b - a) and
     lam_x (x - a)/(b - a).
   - Given (N_x)_x, the difference M = sum_x ((a - x) N_x^a + (b - x) N_x^b) has conditional mean
     sum_x N_x ((a - x)(b - x) + (b - x)(x - a))/(b - a) = 0. Z_{K_W} is a function of (N_x)_x, so
     E[M | Z_{K_W}] = 0 and (CO1) applies.
   - The superpositions N_a = sum N_x^a and N_b = sum N_x^b are independent, Poisson(p_a) and Poisson(p_b).
     Moreover a p_a + b p_b = sum_x lam_x x, so the centring is right.
   - Atoms at a or b are allowed (one thinning part is then 0). (CO2) adds Z_{K_R}.
3. **Lemma S2.**
   - From a^2 (b - x) + b^2 (x - a) = (b - a)(x (a + b) - ab):
     a^2 p_a + b^2 p_b - K(W) = int (x - a)(b - x) dnu = E_W >= 0.
   - With u = (x - a)/(b - a), Jensen for the concave u(1 - u) gives int u (1 - u) dnu <= p_a p_b/(p_a + p_b).
   - Cauchy–Schwarz gives p_a p_b/(p_a + p_b) <= (a^2 p_a + b^2 p_b)/(a + b)^2, and (ii) follows.
   - (iii): d/dp_a [p_a p_b/(p_a + p_b)] = p_b^2/(p_a + p_b)^2 >= 0. So E_W <= exc, with exc taken at the upper
     corner, which gives V_lo; V_hi is (i).
4. **Lemma S3** (K(R) = 1).
   - Split each count at the lower corner P.
   - The mass before the top-up is 1 + E_W - a^2 P_a - b^2 P_b <= mu, because E_W <= exc. So g >= 0, and
     Z_{g delta_0} = sqrt(g) G is added by (CO1).
   - t_a = a^2 (p_a - P_a) lies in [0, a^2 d_a] = [0, delta], and likewise t_b.
5. **Corollary S4.** |.| is convex, and X''(P) is independent of Z_{K'}, so
   E|Z_K| <= E|X''(P) + Z_{K'}| = E h_P(Z_{K'}).
6. **Lemma S5** (a < theta < b < 2a).
   - (x - a)/x^2 has derivative (2a - x)/x^3 > 0 on W. So b^2 (x - a)/((b - a) x^2) is <= beta on [a, theta) and
     <= 1 on [theta, b], which gives b^2 p_b <= beta r + s with r = K_W([a, theta)).
   - (b - x)/((b - a) x^2) decreases on [a, theta) and is >= (b - theta)/((b - a) theta^2) there. Hence
     r <= q_a (b - a) theta^2/(b - theta) = rho, since p_a <= q_a.
   - Also r = K(W) - s <= V_hi - s, and b^2 P_b <= b^2 p_b. These give both lower bounds for s.
   - beta < 1 follows from (b - a) theta^2 - b^2 (theta - a) = (b - theta)(a (b + theta) - b theta) > 0, because
     a > b/2 > b theta/(b + theta).
   - In the family the straddling windows are k = 30..35, from [0.7282, 0.87384] to [0.8442, 1.01304], all with
     b = 6a/5 < 2a. My code asserts a < theta < b < 2a and beta < 1 exactly for each.
   - K_R([theta, A]) = V+ - s < 1/2 - s_lo.
7. **Lemma C.**
   - E h(Y) <= E phi(Y), since phi >= h^ >= h.
   - E phi(Y) is a polynomial in the cumulants. I re-derived the recursion
     m_n = sum_{i=2}^n C(n-1, i-1) kappa_i m_{n-i} from M' = K' M, with kappa_1 = 0 and kappa_2 = mu.
   - Every row of (C3) is valid on the box of ranges:
     - McCormick for w_alpha = w_{alpha'} kappa_j, with the exact interval range of w_{alpha'};
     - the tangents kappa_j^2 >= 2 t kappa_j - t^2;
     - Cauchy–Schwarz, kappa_j^2 <= K'(R) int x^{2j-4} dK' = mu kappa_{2j-2}.
   - With z >= 0, the residuals eps_alpha are paid by E_w.
   - Integrating (C4) against K' bounds int f dK'. This uses the caps for K_R, the atoms t_p <= cap_p, the mass g at
     0 with f(0) <= y_0, the total mass mu, and Q.
   - The closed-piece form is enough. Since y_I >= 0, the interior indicator pattern is the stricter one at the
     endpoints. Pieces inside W can be omitted because K_R has no mass there. 0 lies in no cap interval, so the
     piece check at 0 gives f(0) <= y_0.
   - The caps act on K_R only. An atom at b >= theta is counted in c+ of R(B) through its own cap.
8. **Lemma D.** I checked all three branches:
   - case 1: a heaviest near window carries more than 1/4; reflect it to the positive side;
   - case 2: max(V+, V-) >= 1/4; reflect so that V+ >= V-;
   - case 3: otherwise, reflect so that m1 >= 0. A window that is not near lies in [theta, A] or [-A, -theta], so it
     carries <= max(V+, V-) < 1/4.
9. **Lemma E.**
   - **Case 1.**
     - The box indices satisfy i + j <= floor((a + b)^2/(4 a b delta)) = 20. My code checks this exactly for each
       of the 36 near windows, with the rounded a_k.
     - The 10 boxes per window with V_hi <= 1/4 are excluded, since K(W) > 1/4. No box has V_lo > 1. That leaves
       36 x 221 = 7,956 roots.
     - The caps:
       - K_R([theta, A]) <= 1/2 - s_lo;
       - K_R([-A, -theta]) = V- < 1/2;
       - K_R(W') <= K(W') <= K(W) <= V_hi for each of the other 71 near windows (both signs);
       - atom caps delta at a and b.
     - The support is [-A, A] \ [a, b].
   - **Case 2.**
     - (i + j) delta <= K(W)(a + b)^2/(4ab) < 0.5455, so i + j <= 10.
     - Excluding the boxes with V_hi < 1/4 or V_lo >= 1/2 leaves 60 roots.
     - The caps are K_R([-A, -theta]) = V- <= min(V_hi, 1/2) and K_R(W') <= 1/4.
   - **Case 3.**
     - The moments satisfy 0 <= m1 < 1.0225 and m2 < 1.547.
     - Excluding the cells with (t + 1)/20 < (s/20)^2 leaves 537 roots.
     - The caps are: every window <= 1/4, and V+, V- <= 1/2.
   - **Subdivision rule.**
     - R(B) contains (int x dK', int x^2 dK'). To get the extremes, put min(mu, c+) at A and the rest at theta, or
       the mirror, and use A^2 m* + theta^2 (mu - m*) for the second moment.
     - Children are 4 x 4 at depth 0 for the split types and 2 x 2 below.
     - A light child with U4 < max(L3, 0)^2 is empty by Jensen (m2 >= m1^2 for a probability K). There are 5 such
       children.
   - The three root counts are my own regenerations.
10. **Assembly.** Lemma D gives the case. Corollary S4 (cases 1–2) places K' in the rest class of a root, and in
    case 3 K itself lies in the class of a light root. The subdivision rule then reaches a leaf, which either has
    U <= 171/200 or is certified empty. Every lemma is stated for finitely supported K, which is all that
    Corollary 17 needs.

### Independent verification (RQ-AUD code only)

`audit/rqb/a39_lib.py` (2a200134…) and `a39_light_verify.py` (2f23a255…) cover all three cases. Every md5 is in
`audit/rqb/outputs/a39_code_md5.txt`. The command is `./a39_final_runs.sh 8`, and the outputs are
`outputs/a39_{nsplit,chord,light}_verify.txt`.
- **Method.**
  - Everything is decided in exact rationals (python-flint fmpq). The Poisson probabilities are 200-bit arb balls.
    Every double in the certificates is read as an exact dyadic rational, and a non-finite entry raises an error.
  - Spec: the cell stated in each certificate must equal my regeneration of the cell from its path (Lemma E).
  - (C2): each stored range x-dual (f = +-x^{j-2}) is checked exactly, piece by piece, with a Taylor test and
    then an exact Sturm count. A certified L_j > U_j makes the class empty.
  - (C1): for cases 1–2 I build my own piecewise-linear majorant h^ of h_P:
    - Poisson truncation at P + 14 sqrt P + 30 (RQ-B uses + 25);
    - equal atom values merged, and all terms with pi < 1e-25 put into a tail bound;
    - the slopes from an exact prefix sweep.
    Then phi - h^ >= 0 is checked exactly on every piece and both half-lines, with eps = 0 tried first. In case 3,
    h = |.|.
  - (C3): the rows are rebuilt from my certified ranges, z >= 0 is checked, E phi comes from my own moment–cumulant
    expansion, and eps_alpha, E_w, d, e_0 and f are exact.
  - (C4) and (V5): the main x-dual is checked exactly, and U + eps <= 171/200 is exact.
  - Coverage: my regenerated roots must be tiled by the leaves under the subdivision rule, and every record must be
    used.
- **Conventions not stated in §13, identified from the data** (remark r1):
  - the cap order of each case;
  - the row order: McCormick rows of the tuples in (length, lex) order, with alpha' equal to alpha minus its last
    index, then six tangents and the Cauchy–Schwarz row for each j;
  - the tangent points t_q = L + (q + 1)(U - L)/7;
  - a safety term eta r^D in phi, whose expansion leaves the residuals eps_alpha.

  Each was found by an exact test that the other candidates fail:
  - `outputs/a39n_identify.txt`, case 1: under the identified cap order, 462 of the 2,880 range x-duals of a
    120-record sample fail the strict test, and all 462 are exact touchings. The four other orders fail 643–1,008.
  - `outputs/a39_identify_{chord,light}.txt`: under the identified row order the residuals are 2e-16 (chord) and
    1e-8 (light, the safety term). The next candidates are off by 1e-3 and 1e-6.

  In the full runs, every stored main x-dual holds exactly under these conventions. Soundness does not depend on
  them: any z >= 0 gives a valid bound, eps is paid in E_w, and a stored y0 that fails the exact test is replaced
  by a proved supremum.
- **Results** (ALL PASS, final code, 2026-10-23 00:37–00:44 UTC):

| case | roots covered | certificates | failures | largest U + eps (margin to 171/200) | largest E_w | range repairs (largest shift) | time (8 cores) |
|---|---|---|---|---|---|---|---|
| 1, near splits | 7,956 / 7,956 | 8,481: 8,306 full, 170 full in a class that its own ranges already show empty, 5 empty | 0 | 0.8549969806 at N/k35/i0j6 (3.019e-6) | 7.117e-8 | 47,910 (1.75e-13) | 259 s |
| 2, chord boxes | 60 / 60 | 1,212: 1,046 full, 166 empty | 0 | 0.8549552502 at C/i1j3/q32 (4.475e-5) | 2.048e-6 | 156 (1e-13) | 39 s |
| 3, light set | 537 / 537 (5 children empty by Jensen) | 1,273: 1,213 full, 60 empty | 0 | 0.8549743150 at L/s15t15 (2.568e-5) | 1.873e-2 | 0 | 93 s |

  - Every record is used. eps = 0 in every full certificate, no z entry is negative, and no main x-dual needed a
    repair.
  - My largest U agrees with RQ-B's recorded maximum to 10 digits in each case (0.854996980551545,
    0.8549552502410571 and 0.8549743150463496). RQ-B's checker also reports 8,481 + 1,212 + 1,273 certificates
    accepted, and 5, 166 and 60 empty.
  - Exact touchings: these are stored range x-duals that hold only with equality at some point. My strict test
    rejects them, while the non-strict inequality that Lemma C needs holds. Most are the trivial lower bounds L_j = 0
    of even cumulants, whose x-dual -x^{j-2} <= 0 touches at x = 0. For each one my verifier replaces y0 by the
    Sturm-proved supremum, and every later step uses the repaired ranges.

**Controls** (`a39_negative.py`, b8380721…, output `outputs/a39_negative.txt`, 28 s): **72/72 behave as required**,
24 for each case. Every corruption is rejected:
- a spec moved off the regenerated cell (P_b raised by 1e-6, or the rectangle widened);
- phi_0 - 0.05 (the majorant test fails);
- all z times 1.01, and the largest z dropped;
- the target set to U - 1e-9;
- NaN or inf in phi, in z or in a range y0;
- the main cap indices shifted;
- the tangent points at q/5;
- a wrong cap order;
- an empty certificate transplanted to a nonempty cell, or with its cap, atom and Q multipliers zeroed;
- a range y0 shift beyond the emptiness threshold (1.01 times it);
- the record of the worst root removed (coverage fails);
- an extra record below a leaf (flagged as unused).

The valid weakenings are accepted: y0 - 1e-3 in the main x-dual is detected and replaced by the proved supremum
(U changes by 2e-10); 0.99 of the emptiness threshold keeps the class empty; and the McCormick split on the first
index gives other valid rows (U = 0.8549983).

**Semantic tests** (`a39_semantic.py`, 92bf4f65…; evidence, not proof).
- **What is checked.** For each law:
  - the case of Lemma D, with the reflection;
  - the box or cell, V_lo <= K(W) <= V_hi, g >= 0 and the atom caps;
  - every cap of the rest class, including the Lemma S5 cap;
  - (kappa_3, kappa_4) in R(B);
  - the leaf of the subdivision tree, which must be a full leaf that my verifier accepts;
  - E|Z_K| <= E h_P(Z_K') <= U(leaf) in cases 1–2, and E|Z_K| <= U in case 3.
- **How E|Z| is computed.** My characteristic-function evaluator integrates only up to t = 300, so it is least
  accurate for nearly discrete laws. Wherever it cannot separate the two sides (gap below 1e-7, or U - E h below
  1e-5), both sides are recomputed by enumerating the Poisson counts (`a39_enum_check.py`, a4619851…). The
  enumerated sum is a lower bound. The upper bound adds (sigma sqrt(2/pi) + |mean|) P(E) +
  max|x| (Lam P(N >= M) + M P(E_p)) for the omitted event E, where N ~ Poisson(Lam). The inequality must hold between
  these bounds. On smooth laws the enumeration matches the evaluator to 10 digits.
- **Random laws:** 6,000 (seed 910000), from 10 sampler types, including a loaded near window and a window
  straddling theta with V+ just below 1/2. Output: `outputs/a39_semantic_all.txt`, 3.6 min.
  - The cases split 3,793 / 1,498 / 709. There is no violation, and all 1,951 distinct leaves are full.
  - The smallest U - E h is 0.0015 (case 1), 0.0388 (case 2) and 0.0396 (case 3).
  - 1,570 laws sit in straddling windows, 689 of them with s_lo > 0. The smallest S5 slack is 0.0166.
  - Five enumeration rechecks were needed, and all five gaps are certain (>= 3.0e-11). The evaluator's excess was
    at most 5.4e-6, at sigma^2 = 8e-6 (seed 910650).
  - So the single alarm of my first run (00:23) was an artefact of the evaluator. For seed 910650, exactly,
    E|Z_K| <= 0.787103871132 < 0.787103887487 <= E h_P(Z_K').
- **Fixed adversarial laws:** 189 laws from RQ-C's C21 and RQ-D's notes, every tied heaviest window included. They
  are lattice-like clusters below theta with a small negative atom, V+ = 1/2 laws moved just inside F_light, and
  pairs straddling theta. Output: `outputs/a39_semantic_fixed.txt`.
  - 1,102 chains, no violation.
  - 34 enumeration rechecks, all certain (smallest gap 1.9e-11).
  - The smallest S5 slack is 1e-4, and the smallest U - E h is 0.0021.

**Hostile checks.**
- **Lemma S5** (`a39n_s5_hostile.py 60000 11`, exact rational laws; output `outputs/a39n_s5_hostile.txt`). I drew
  60,000 admissible laws on the windows k = 30..35, of which 25,401 have s_lo > 0. There is no counterexample, and the
  smallest slack s - s_lo is 7.5e-5 (k = 35, box (4, 3)). A second run with seed 1
  (`outputs/a39n_s5_hostile_rerun.txt`) has 25,173 laws with s_lo > 0, no counterexample, and smallest slack 5.9e-5
  (k = 35, box (2, 5)). Both runs reproduce exactly. A random search cannot hit the extreme laws exactly, which is
  why the slack is not 0. The proof above shows the bound is attained in the limit.
- **S5 is load-bearing for the stored certificates.** At the worst cell N/k35/i0j6, s_lo = 0.297439. With the cap
  1/2 instead of 1/2 - s_lo, the same certificate gives U = 0.8554473 > 171/200.
- **Far-region searches** (`audit/far/`, evidence; free positions with 6 atoms plus a Gaussian):
  - Over F_light (240 starts, 25 min), the best value is 0.8198316, at delta_0.8166 (= delta_sqrt(2/3)). The margin
    to 171/200 is 0.035.
  - Over F (320 starts, 42 min), the best value is 0.8266615, at the K*-type law
    0.8 delta_1.2966 + 0.104 delta_0.85- + 0.096 delta_-1.101 on the boundary with the band.
  - The many-atom grid ascents of 22:51 agree.

### Remarks

- r1 (text). §13 does not state the conventions a reader needs to check a certificate: the cap orders of the three
  cases, the row order of (C3), the tangent points (q + 1)/7, and the safety term eta r^D in phi. The residuals of
  that term are paid in E_w (largest E_w 7.1e-8, 2.0e-6 and 1.9e-2 in cases 1–3). I identified the conventions from
  the data. They should be stated in §13.3–13.4.
- r2 (text). §13.4 says "any root in the interval: rejected". The data contain exact touchings (47,910 range
  x-duals in case 1 and 156 in case 2), and RQ-B's checker accepts every record. So either its tests are not strict
  there, or the sentence is inaccurate. Lemma C needs only the non-strict inequality, so this is wording.
- r3 (informational).
  - 170 case-1 records carry full certificates in cells whose certified ranges are already empty.
  - s_lo reaches 0.9974 (at N/k35/i0j20). The cap 1/2 - s_lo is then negative, and the class is empty.
  - S5 is load-bearing.
- r4 (text). The §13 heading still says "cases 2 and 3 done, case 1 running", while §13.6 reports all three cases
  complete.

### Verdict and novelty

- **VALID** (no fix to the mathematics; r1, r2 and r4 are text remarks). Every lemma holds as stated, and every
  certificate passes an independent exact check on exactly the filed data.
- **NEW.** Theorem 13.1 has no source; the far-region problem is internal to this project.
  - Lemma S5 is NEW as stated (elementary).
  - Lemma S1 is KNOWN in kind: Poisson thinning, with the two-point convex-order maximum of a law on an interval with
    given mean (Shaked–Shanthikumar, *Stochastic Orders*, §3.A). RQ-D's Lemma 18 (A.38) is the same idea.
  - S2–S4 are elementary.
  - Lemma C is standard technique: a polynomial majorant with a moment relaxation and McCormick rows, as in A.23 and
    A.38.
- **Consequence for the chain.**
  - With A.38 (Theorem 16 and Corollary 17) and A.34 (Corollary 14), ID*(C_5) holds on [-1.54, 1.54], and C5 holds
    (R_ID = sqrt(2/e), so lim_{q->0} R(q) = sqrt(2/e)).
  - Then R(q) = M(q) on (0, q5]. Three facts give this:
    - A.26 shows that ID*(C) gives R = M wherever C(q) >= C.
    - The minimum of C(q) over (0, q5] is C_5.
    - A.28 puts the support in [-A'(q), A'(q)], a subset of [-1.538, 1.538] for q <= q5.
  - With A.25, A.18, A.14, A.11 and A.6 on [q5, 1/2], and the mirror for q > 1/2, **Conjecture S holds for all q
    in (0, 1) at audit level.** That is, R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1).
  - The extremisers are characterised only on [q6, 1 - q6] (A.37 and earlier). For q < q6 the chain gives the value,
    not the extremiser set.
- **Status per LOCKED_NOTE.**
  - Refereed VALID: A.6, A.11, A.14 and A.18 (RQ-REF1), and A.25 and A.37 (RQ-REF2, 2026-10-23 01:05 UTC).
  - Not refereed: A.26, A.28, A.34, A.38 and A.39.
  - The coordinator's notes of 17:08 and 18:02 PT plan RQ-REF3 once A.39 is VALID. Its scope is U.3 with the U.1
    inputs A.7a and A.10a, A.28, RQ-D's MAIN_RESULT Sections 2–7 (A.30, A.32, A.34, A.38), and A.39 including
    Lemma S5.
  - The all-q result goes to Paata only after a referee also rates these links VALID.

**Addendum (2026-10-23 02:29 UTC): RQ-REF3 rates link 4 VALID. Its robustness remark does not affect my verification.**
- RQ-REF3's report (`RQ-REF3/REFEREE.md` 470481ec…, written 02:23:40 UTC; copy in `audit/snapshots/s0224/`) rates
  RQ-B §13 VALID: Theorem 13.1 and Lemmas S1–S5, C, D and E. It checked them by hand and re-verified all 10,966
  certificates with its own exact code, on the three files whose md5s A.39 used.
- Its counts equal those in my table above, case by case:
  - Case 1: 7,956 roots and 8,481 certificates. 8,476 are certified (my 8,306 full plus the 170 full ones in a class
    that its own ranges show empty) and 5 are empty. The worst bound is 0.8549969806 at N/k35/i0j6.
  - Case 2: 60 roots and 1,212 certificates, 1,046 certified and 166 empty. The worst is 0.8549552502 at C/i1j3/q32.
  - Case 3: 537 roots and 1,273 certificates, 1,213 certified and 60 empty. The worst is 0.8549743150 at L/s15t15.
- **The remark.** RQ-REF3 reports that RQ-B's checker (`far_verify.check_linear_dual`) pairs atom and cap
  multipliers with `zip`, and adds the rectangle terms only when the cell has a rectangle. A short multiplier list
  would then be skipped silently. I have not read that code and do not use it, so this is RQ-REF3's finding.
  - My verdict rests on my own verifier. Its `parse_xdual` (`audit/rqb/a39_lib.py`) checks every list length
    against my regenerated cell:
    - nc equals the number of caps, and every cap index is in range;
    - there is one atom multiplier per atom (2 for split cells, 0 for light cells);
    - there are exactly 4 rectangle multipliers, and they must be 0 when the cell has no rectangle.
  - It does this in the range duals (C2) and in the main dual (C4), before any repair of y0. My runs had assertions
    enabled (no -O; PYTHONOPTIMIZE unset).
- **New controls** (`audit/rqb/a39o_length_controls.py`, output `outputs/a39o_length_controls.txt`, 8 s).
  - Targets: the tightest certificate of each case. The no-rectangle mutation uses full certificates on cells
    without a rectangle (C/i10j0 and N/k0/i0j10); every full light cell has a rectangle, so it does not apply there.
  - Mutations, each in the main dual and in the kappa_3 range dual:
    - one atom multiplier dropped, or one extra;
    - 3 rectangle multipliers instead of 4;
    - nc + 1;
    - a cap index out of range;
    - nonzero rectangle multipliers on a cell without a rectangle.
  - Result: every mutation is rejected by the format check, 35/35 PASS (A39O_ALL_CONTROLS_PASS). The 5 unmutated
    certificates are accepted, the three tightest with the worst bounds above.
- A.39 stays VALID. With RQ-REF3's verdict, Theorem 13.1 meets the LOCKED_NOTE criterion (block under the ledger).
  The chain A.40 still waits for RQ-REF3's link 3.

---

## A.40 The all-q chain for Conjecture S (composition of A.6, A.11, A.14, A.18, A.25, A.26, A.28, A.34, A.38 and A.39) — VALID at audit level; NEW (2026-10-23 01:29 UTC)

**What is audited.** No solver has filed the composed statement as a claim.
- The chain is the one RQ-A lists in NOTES_FOR_TEAM (00:02; 30a1be9c…), and the one RQ-C checks in its reproduction
  report of 01:06 (AUDIT_REQUEST 07a808bc…, "no new claim").
- Each link is audited in its own entry. This entry checks the composition: each link's conclusion, as audited, must
  give the next link's hypothesis with the same conventions, and the q-ranges must leave no gap.
- I rebuilt the composition from my own audited statements, not from the solvers' summaries.

**Composed claim.** For every q in (0, 1),

    R(q) = M(q) = 2 sqrt(q(1-q)) max_{k >= 1} sqrt(k) qh^(k-1),   qh = max(q, 1-q).

For q <= 1/2, M = T_k = 2 sqrt(k) (1-q)^(k-1) sqrt(q(1-q)) on [q_{k+1}, q_k], where q_1 = 1/2 and
q_{k+1} = 1 - sqrt(k/(k+1)). The value is attained at OR_k = (e_1 + ... + e_k)/sqrt(k). Consequently
lim_{q->0} R(q) = sqrt(2/e), and R_ID = sqrt(2/e) (RQ-B's C5).

**The composition.**
1. *M is T_k band by band (J2).* T_{k+1}/T_k = sqrt((k+1)/k) (1-q), which is >= 1 iff q <= q_{k+1}, and ln T_k is
   concave in k. So M = T_k on [q_{k+1}, q_k], with the tie T_k = T_{k+1} at q_{k+1}.
2. *Lower bound R >= M.* q_k = 1 - sqrt(1 - 1/k) < 1/k, because sqrt(1 - 1/k) > 1 - 1/k. So kq < 1 on band k, and
   E|chi_1 + ... + chi_k|/sqrt(k) = 2 sqrt(kq) (1-q)^(k-1/2) = T_k exactly (A.27, step 1; Stone, thesis Thm 4.3.1).
3. *[q5, 1/2].* The links give:
   - A.25: R = T_4 on [q5, q4];
   - A.18: R = T_3 on [q4, 25/169];
   - A.14: R = T_3 on [25/169, q3];
   - A.11: R = T_2 on [q3, q2];
   - A.6: R = T_1 = 2 tau on [q2, 1/sqrt2].

   J1 checks q5 < q4 < 25/169 < q3 < q2 < 1/2 and the closed forms of the endpoints. Consecutive intervals share an
   endpoint, where the two values agree (J2). So R = M on [q5, 1/2].
4. *ID*(C_5) with the fixed theta = 0.85.* For a probability Kolmogorov measure K on [-1.54, 1.54], write
   V+ = K([0.85, 1.54]), V- = K([-1.54, -0.85]) and lambda+-_theta(K) = int_{+-x >= theta} x^{-2} dK.
   - V+ >= 4/5: A.34 (Theorem 13) gives E|Z_K| <= max(g(lambda+_0.85), C_5) for finitely supported K. For V- >= 4/5
     the mirror applies (reflect K; Z_K becomes -Z_K).
   - 1/2 <= V+ < 4/5, or 1/2 <= V- < 4/5: A.38 (Theorem 16) gives E|Z_K| < C_5, for every K.
   - V+ < 1/2 and V- < 1/2: A.39 (Theorem 13.1, A = 77/50, theta = 17/20) gives E|Z_K| <= 171/200 < C_5 for
     finitely supported K (J5: the margin is 1.00455e-4).

   The two sets are disjoint and K has mass 1, so V+ + V- <= 1. If V+ >= 1/2, one of the first two cases applies;
   the same holds for V-; otherwise the third case applies. The thresholds split as V < 1/2, 1/2 <= V < 4/5 and
   V >= 4/5, so no value is left out. Hence every finitely supported probability K on [-1.54, 1.54] satisfies
   E|Z_K| <= max(g(lambda+_0.85(K)), g(lambda-_0.85(K)), C_5). This is ID*(C_5) with theta = 0.85 fixed, as
   Corollary 14 (A.34) and Corollary 17 (A.38) state.
5. *Localisation (A.28(f)).* ID*(C) is needed only for K on [-A, A] with A > A'(q) = sqrt(2q/s)/(1-q).
   - A maximiser at size n has K-tilde atoms bounded by Lambda_n/(u sqrt(s)), which tends to A'(q).
   - The argument is by contradiction, using R_n -> R.
   - A' increases (A.28(g); J4 on a grid), and A'(q5) = 1.538044392 < 77/50 (J4).
   - So A = 1.54 works for every q <= q5, strictly, as (f) requires.
6. *Poissonisation (A.26).* Suppose E|Z_K| <= max(g(lambda+_theta), g(lambda-_theta), C) for every finitely
   supported K. Then R(q) = M(q) wherever C(q) >= C, where C(q) = max_k g(ks).
   - A.26 holds with theta fixed (RQ-B's form) and with theta depending on K (RQ-A's form). Step 4 gives the
     fixed-theta hypothesis, which implies both.
   - The g(lambda+-) terms are at most C(q), because lambda+-(K_f) lie in sZ.
   - K-tilde = K_{f*} has atoms alpha*_i/sqrt(s) with masses alpha*_i^2. So it is a finitely supported probability,
     and lambda+-_theta(K-tilde) = s #{i : +-alpha*_i >= theta sqrt(s)}. That closed threshold is the one used in
     step 4.
7. *C(q) >= C_5 on (0, q5] (J3).*
   - Since T_k/T_j = g(ks)/g(js), the bands of C(q) are those of M, and C(q) = g(ks) on band k.
   - On band k, ks runs over [a(k), (k/(k-1)) a(k-1)], with a(x) = (x/2) ln(1 + 1/x). This interval contains 1/2.
   - ln g is concave, so the band minimum is at an end. It equals min(g(a(k)), g(a(k-1))) = g(a(k-1)) = C(q_k),
     because a increases to 1/2 and g increases on (0, 1/2).
   - C(q_k) increases in k from C(q5) = C_5 = g(2 ln(5/4)) = (32/25) sqrt(2 ln(5/4)) = 0.855100455470819.
   - Checked in Arb for k = 5..399 (C(q6) = 0.855984489174), and analytically.
8. *Conclusion.* Steps 4–7 give R(q) = M(q) on (0, q5]. With step 3 this covers (0, 1/2]. R(1-q) = R(q) (replace
   chi_i by -chi_i) and M(1-q) = M(q), which covers (1/2, 1).
9. *The limit.* M(q) = sqrt(q/((1-q)s)) C(q) tends to sqrt(2/e) as q -> 0, since C(q) -> g(1/2) = sqrt(2/e). So
   lim R(q) = sqrt(2/e). With A.8 and A.10b (lim R = R_ID), R_ID = sqrt(2/e), which is RQ-B's C5 as Corollary 17
   states.

**A.29 is no obstruction (J6).** At C = C_5, A.29 gives a* = (2 ln(5/4))^(-1/2) = 1.4969001 and theta_max =
1.0062780. A.29 rules out a fixed theta only above theta_max. theta = 0.85 is below it, consistent with step 4.

**Extremisers.** The chain gives the value R(q) for every q, attained at OR_k. It does not give the full set of
extremisers, which is known only on [q6, 1-q6] (A.37 and earlier). A.37 (R = T_5 on [q6, q5]) is not needed, and it
agrees with the chain there.

**Independent check.** `audit/chain/a40_chain_seams.py` (b4cce911…) runs in 256-bit Arb. Its output is
`audit/chain/outputs/a40_chain_seams.txt`: 24 PASS in 0.05 s.
- J1: the order of the endpoints and their closed forms.
- J2: the ties T_k = T_{k+1} at q_{k+1} (|diff| < 4e-76), and T_k as the strict maximum over j <= 39 at the midpoint
  of each band, for k = 1..5.
- J3: C_5 and its tie g(4 s(q5)) = g(5 s(q5)); a(k-1) increasing and below 1/2; C(q_k) increasing for k = 5..399;
  and the band ends around 1/2 for k = 5..59.
- J4: A'(q5) = 1.538044392 < 77/50, and A' increasing on a 2,000-point grid.
- J5: 171/200 < C_5, and the worst bounds of A.38 (0.8548832) and A.39 (0.8549969806).
- J6: a* and theta_max.

**Hostile seam notes.**
- Normalisation: in every link K is a probability Kolmogorov measure, and Z_K is centred with Var Z_K = 1. A.34's
  Theorem 13 and A.39 assume K finitely supported; A.38 does not. The composed bound is used only at K-tilde, which
  is finitely supported, so that restriction is enough.
- Closed sets throughout: lambda+- counts atoms with +-x >= theta, and V+- uses [0.85, 1.54] and [-1.54, -0.85]. An
  atom exactly at 0.85 counts in lambda+ and in V+ in every link.
- A.28(f) needs A > A'(q) strictly, and 1.54 - A'(q5) = 0.00196. The A.39 summary's phrase "puts the support in
  [-A'(q), A'(q)]" is shorthand for this limit statement. The conclusion is unchanged.
- No link is used beyond its audited statement. In particular, A.26 is used in RQ-B's fixed-theta form, A.34 only
  for V >= 4/5, and A.38 only for 1/2 <= V < 4/5.
- The composition does not use A.37, A.21/A.21b, A.31–A.33 or A.35–A.36.
- RQ-C's reproduction report (01:06) reaches the same composition, and its counts agree with A.38 and A.39 (store
  log, 2026-10-23 01:29). It calls RQ-B's and RQ-D's own leaf verifiers, so it corroborates coverage and seams only. My
  verdict rests on my own checks.

**Verdict: VALID at audit level** (no fix). The composition is short, and every input is a VALID audited link.

**Novelty: NEW.** No source determines R(q) for all q.
- Before this project the only exact values were R(1/2) = 1 and BF3's Theorem K on [3/8, 5/8].
- Ivanisvili–Stone (arXiv:2407.04835, Remark 1.3) state the equal-coefficient value (1.10) and only assume that R
  equals it.
- Stone's thesis (UCI 2025, Thm 4.3.1) proves that value, which is the lower bound of step 2. It leaves general
  coefficients open (RQ-C SOTA).
- Searches at 01:15 and 01:25 UTC found nothing later.
- R_ID = sqrt(2/e) is also NEW.

**Status per LOCKED_NOTE.**
- Refereed VALID: A.6, A.11, A.14 and A.18 (RQ-REF1), and A.25 (RQ-REF2).
- Not refereed: A.26 with its inputs A.7a and A.10a, A.28, A.34 with A.30 and A.32, A.38, A.39, and this composition.
  That is RQ-REF3's scope (LOCKED_NOTE, 18:02 PT). RQ-REF3 was launched at 18:24 PT (LOCKED_NOTE 2dc77e79…).
- The all-q result goes to Paata only after RQ-REF3 also rates these links VALID.
- RQ-REF3's first report (`RQ-REF3/REFEREE.md` c2525146…, file time 01:42 UTC) is IN PROGRESS. It rates link 1 (the
  reduction: RQ-B Lemma 2.1, Theorem 3 and Theorem 3.4 (a)–(d), i.e. A.26 with A.7a and A.10a) and link 2 (A.28)
  VALID. For links 3 (RQ-D Sections 2–7) and 4 (RQ-B Section 13) the hand checks are done and the certificate
  re-verification is running. Its update at 01:58 UTC (7514d22a…) rates the Theorem 16 certificates (A.38) VALID,
  re-verified with its own code (a quadtree tiling check, exact Bernstein subdivision, set-partition moments). Every
  count equals mine in A.38: 436 boxes, 280 certified and 156 empty, 1,237 cells with 1 Farkas-empty, and the worst
  bound 0.8548832 in box [6, 3, 6, 39], cell (2, 3, 1). Its 8 negative controls are rejected. The band Theorem 13
  (A.34) and link 4 (A.39) are still running. It gives no verdict on the chain yet, so the criterion block is
  unchanged (added 2026-10-23 02:00 UTC).
- Update (2026-10-23 02:29 UTC). RQ-REF3's report 470481ec… (written 02:23:40 UTC) rates link 4 (A.39) VALID, and its counts
  equal mine (A.39 addendum). Links 1, 2 and 4 are now VALID by RQ-AUD and RQ-REF3, and the criterion block lists
  them. Link 3 (A.30, A.32, A.34, A.38) is still in progress: the Theorem 16 certificates are VALID, and Theorem 13
  is running. A.40 itself is not refereed yet.
- Update (2026-10-23 03:30 UTC). RQ-REF3's report is FINAL (6ac713c0…, written 03:09:02 UTC). It rates link 3 VALID,
  re-doing Theorem 13 with its own cover (1,212 squares, 9,077,343 leaf boxes, every square certified), and rates
  the composition VALID: "Conjecture S holds for all q in (0, 1)", with RQ-A MAIN-1..6 on [q6, 1-q6] taken as given.
  So A.40 meets the LOCKED_NOTE criterion, and the criterion block under the ledger lists it with all its links.
  LOCKED_NOTE (410b562f…, 20:10 PT) records the chain as doubly verified and reported to Paata.

**Addendum (2026-10-23 02:00 UTC): hostile direct searches at small q (evidence, not proof).** These searches attack the
composed statement R(q) = M(q) on (0, q5] directly. They use none of the links: each one maximises
E|alpha.chi| / ||alpha|| over many vectors alpha and compares the result with M(q). The code is mine and lives in
`audit/chain/`. The searches run in float64; any ratio above M(q)(1 + 1e-12) is re-checked in exact rationals
(python-flint fmpq). Every search ascends with the sign iteration alpha <- E[chi sgn(alpha.chi)], which never
decreases the ratio.
- **a40b** (`a40b_smallq_direct.py` f9d9e634…, output `outputs/a40b_smallq_direct.txt` 2e0c5b56…). It enumerates
  {0,1}^n in full, for 8 values of q in [3/100, 1/10] and n from N(q) to 19, with 60 starts per task and kicks. 37
  tasks ran in 19 s. The best ratio is M(1 + 1.7e-13), which is float noise, and it is always attained at +-OR_N. No
  flags; A40B_PASS. Its "non-OR" column (0.99986) counts OR_k with k != N as non-OR, so a40b2 replaces it.
- **a40b2** (`a40b2_smallq_direct.py` 88427487…, output b89f694c…). This is the same search without the 2^n x n bit
  matrix, so it reaches n = 21. It covers 9 values of q in [3/100, 21/200], with 400 starts for n <= 18 and 200 for
  n = 20, 21. Each limit is classified as equal-coefficient (+-OR_k) or not; a value of -1/M in the non-equal
  column means that every limit was equal-coefficient. 59 tasks ran in 114 s. The best ratio is M(1 + 4.2e-13), at
  +-OR_N. The best non-equal local maximum is 0.988484 M (q = 1/25, n = 20): OR_14 plus one coordinate at relative
  weight -0.57. No flags; A40B2_PASS. Where the two searches overlap, a40b and a40b2 agree to 1e-14.
- **a40c** (`a40c_multilevel.py` 50ced822…, output `outputs/a40c_multilevel.txt` 28be246c…). It searches beyond the
  reach of enumeration, over vectors with 2–4 coefficient levels on blocks of up to 2,000 coordinates. Then
  E|alpha.chi| is a sum over the product of binomial supports, and the sign iteration keeps the block structure.
  It covers 14 values of q from 1/1000 to 21/200, so N runs from 500 down to 5. For each q it takes:
  - all 5,050 pairs of block sizes up to 100;
  - 1,500 random triples of block sizes up to 40;
  - 800 random quadruples of block sizes up to 14;
  - 440 pairs (a, b) with a <= 40 and |b - N| <= 5;
  - pairs with one huge block, b in {200, 500, 1000, 2000, 2N, 4N}.

  Each tuple gets 4 starts. 154 tasks ran in 18 s. The best ratio is M(1 + 1e-15), always with equal levels. No
  flags; A40C_PASS. The largest non-equal critical point is 0.9997496 M, at q = 1/1000. It is OR_501 = OR_(N+1)
  plus one coordinate at relative weight -1/2. At every q the largest non-equal value perturbs OR_N or OR_(N+1)
  by one coordinate. Its relative weight lies between -0.63 and -0.50, except at q = 7/100 and 2/25, where it is
  +0.53 and +0.49 and the value comes from quadruples with small extra levels. Its gap 1 - ratio lies between
  0.250 q and 0.275 q at all 14 q, so it approaches M only as q -> 0, where T_(N+1)/T_N -> 1, and never reaches it.
  Before the final run I fixed two things in my own script; neither affects the search. The printed per-family
  tuple counts were reset whenever a later task improved the best, and are now counted separately. The rational
  argmax of k(1-q)^(2k-2) now stops at the first strict decrease; the sequence is unimodal, and the argmax equals
  floor(1/(q(2-q))) and a float argmax at all 14 q.
- **Exact spot check** (`a40c_exact_spot.py` dc42babd…, output 99cab8e5…). It recomputes in exact rationals the 7
  largest non-equal configurations of a40c (including a40b2's runner-up) and 3 equal-coefficient ones. The exact
  ratios agree with the floats to the printed precision, all are <= 1, and the 3 equal-coefficient ratios equal 1
  exactly (OR_N attains M). A40C_EXACT_SPOT_PASS in 1 s.
- **Outcome.** No vector exceeds M(q) on (0, q5]. The maximum is always +-OR_N up to float precision, and the
  runners-up are perturbations of OR_k with k near N (k = N, N+1, or N+2 for a40b2's). This is consistent with
  A.40 and adds nothing to its proof.
- Correction (2026-10-23 02:05 UTC). The version mirrored at 02:03 said that one family, OR_(N+1) plus one coordinate, is
  the runner-up at every q. The a40c bullet now gives the actual runners-up. No number or conclusion changes.

**Addendum (2026-10-23 03:41 UTC): literature re-check; the novelty is unchanged.** I ran nine web searches after
03:31 UTC. They covered biased Khintchine inequalities, L1–L2 constants of biased Rademacher sums, the
equal-coefficient value, compound Poisson extremal problems and the L1 Poincaré constant of the cube.
- Nothing found determines R(q) beyond BF3's [3/8, 5/8]. Ivanisvili–Stone and Stone's thesis are as recorded above.
- One related preprint is new: T. S. Tomar, "The L¹ Poincaré constant of the Hamming cube" (Zenodo,
  doi 10.5281/zenodo.23533350; PDF created 2026-10-21, 26 pages; my copy has md5 cd323703…; not refereed).
  - It claims that the L1 Poincaré constant C of the cube is sqrt(pi/2). The proof goes through
    J(lambda) = int_0^{pi/2} E|sum_j lambda_j xi_j^(p(theta))| d theta with p(theta) = (1 + sin theta)/2, and takes the
    sup over lambda only after the integral over theta.
  - It does not determine R(p). Its Remarks 2.4(i) and 8.8 know R(p) only through the equal-weight lower bound
    (Stone's Theorem 4.3.1) and Ivanisvili–Stone's upper bound (1.8). So A.40 stays NEW.
  - Its Remark 8.8 concerns the application that Ivanisvili–Stone's Remark 1.3 names. The route
    C <= int_0^{pi/2} R(p(theta)) d theta (Ivanisvili–Stone Section 2.4) cannot go below the equal-weight integral,
    which Tomar certifies to be at least 1.42177. With A.40 that integral is exactly int R.
- **My check a40g** (`audit/chain/a40g_bias_integral.py`, output `audit/chain/outputs/a40g_bias_integral.txt`,
  A40G_PASS, 1 s). With w = (1 - sin theta)/2 the integral becomes
  I = int_0^{1/2} max_k 2 sqrt(k) (1-w)^(k-1) dw = (sqrt2 - 1) + sum_{k>=2} (2/sqrt k) [(k/(k+1))^(k/2) - ((k-1)/k)^(k/2)].
  - In Arb, with 100,000 bands and a two-sided bound on the rest, I is in [1.42178179, 1.42178183], so
    pi/2 - I = 0.1490145.
  - This agrees with Tomar's 1.42178 and with Ivanisvili–Stone's "≈ 0.149". A float midpoint rule in theta gives
    1.42178181.
- So with A.40, that route gives C <= 1.4217819 without any assumption on R; I have not audited the route itself.
  Tomar's preprint claims the sharp C = sqrt(pi/2) = 1.2533 by another route, and a computer-assisted C <= 1.42 that
  does not use R. If it is correct, it supersedes this application of Conjecture S. The value of R(q) is not
  affected.

**Addendum (2026-10-23 03:57 UTC): hostile direct searches on the central range and above 1/2 (evidence, not
proof).** The 02:00 searches covered (0, q5]. This one attacks R(q) = M(q) directly on [q5, 1/2], where A.6, A.11,
A.14, A.18 and A.25 apply, and at points above 1/2. It uses none of the links.
- **a40h** (`audit/chain/a40h_central_direct.py` 0e966cef…, output `outputs/a40h_central_direct.txt` c91bcbdd…). It
  reuses the numerics of a40b2 (full enumeration of {0,1}^n) and of a40c (block vectors), with M taken at
  qh = max(q, 1-q).
  - 38 rational values of q: q_k ± 1e-3 and q_k ± 1e-6 at each seam k = 2..5, where OR_(k-1) and OR_k tie; the proof
    boundaries 25/169 and 3/8; 14 band interiors from 0.11 to 0.499; and 6 points above 1/2, among them
    1 - (q2 ± 1e-6) and 1 - (q4 + 1e-6).
  - Full enumeration for n = N, N+1, N+2, N+3, N+5, 9, 12, 15 and 18 with 300 starts and kicks each, and n = 20 with
    100 starts at the eight points q_k ± 1e-6.
  - Block vectors: all 5,050 pairs of block sizes up to 100, 1,500 random triples up to 40, 800 random quadruples up
    to 14, and 160 pairs with one block of 200 to 2,000 coordinates.
  - Every ratio above M (1 + 1e-12) is re-checked in exact rationals. So is the best non-equal local maximum of each
    task whose distribution is small enough to enumerate (547 tasks).
  - Controls before the run: the exact checker gives (ratio/M)^2 = 1 for OR_2 at q = 1/5, for -OR_2 at q = 4/5 and
    for one coordinate at q = 3/8, and 24/25 for OR_3 at q = 1/5.
- **Result.** 685 tasks in 190 s; A40H_PASS.
  - The best ratio is M (1 + 1.6e-13), which is float noise, and it is always attained at +-OR_N. No flags.
  - Next to each seam the limits include both tying vectors, for example OR_4 and OR_5 at q5 ± 1e-6, and OR_1 and
    OR_2 at q2 ± 1e-6.
  - The largest non-equal local maximum is 0.97495 M, at q = q5 - 1e-3 (n = 15): four coordinates at 0.486, one at
    0.222 and ten at 0.028. Next come 0.97333 M at q5 ± 1e-6 (OR_5 plus one coordinate of relative weight -0.559) and
    0.97280 M at q5 ± 1e-3.
  - At the other points the best non-equal value lies between 0.9326 M (q = 0.24) and 0.9728 M on bands 2–4 and at
    the seams. On band 1 it falls from 0.960 M next to q2 to 0.866 M at q = 0.499, where it is the mixed-sign triple
    (1, 1, -1)/sqrt3 (sqrt3/2 at q = 1/2).
  - All 547 exact re-checks give a ratio strictly below M.
  - The runner-up values are lower bounds for the best non-equal local maximum, not exact values. R(1-q) = R(q)
    holds vector by vector (alpha -> -alpha), yet the search found 0.95074 M at q = 4/5 and only 0.94927 M at 1/5;
    at 2/5 and 3/5, and at q2 ± 1e-6 and 1 - (q2 ∓ 1e-6), the two values agree.
- **Outcome.** No vector exceeds M(q) at any of the 38 points, and the best non-equal configuration found stays at
  least 2.5% below M across the central range, seams included. This is consistent with A.40 and adds nothing to its
  proof.

**Addendum (2026-10-23 04:51 UTC): a many-atom lattice search of ID*(C_5) (evidence, not proof).** My earlier searches
of the far region and the band (far_hostile, far_hostile6, a34d) used at most six atoms and a Gaussian part. This one
lets the mass spread over all 308 points of (1/100)Z ∩ [-1.54, 1.54] \ {0}, plus a Gaussian part. It tests whether
many atoms can beat the few-atom optima.
- **a40i** (`audit/chain/a40i_idstar_lattice.py` 7c6f6685…, output `outputs/a40i_idstar_lattice.txt` 796924b0…).
  - E|Z_K| comes from the inverse FFT of the characteristic function of the lattice part (L = 2^14, window centred
    at the mean), combined in closed form with the Gaussian part. Its gradient in all 309 weights is one
    cross-correlation.
  - The weights move on the simplex by exponentiated-gradient ascent with backtracking, with a Frank–Wolfe step every
    third iteration. The starts are random sparse, structured, and perturbed known optima: 16 per task, 8 tasks per
    region, up to 1,500 iterations. The best law of each task is then polished by moving mass to lattice neighbours.
  - Five regions, with V± = K(±[0.85, 1.54]) and λ± = ∫_{±x >= 0.85} x^-2 dK, and the constraints imposed by
    penalty:
    - F (V± <= 4/5), heavy (1/2 <= V+ <= 4/5) and light (V± <= 1/2), each maximising E|Z_K|;
    - band (4/5 <= V+ <= 1 − ρ, for ρ = 0.02 and 0.1), maximising E|Z_K| − max(g(λ+), C_5);
    - all K, maximising E|Z_K| − max(g(λ+), g(λ−), C_5).
  - Self-test (A40I_SELFTEST_PASS):
    - Dirac laws agree with g(1/x²) to 1e-11, and single atoms with rates up to 10^4 agree with the closed form
      2x e^-λ λ^(⌊λ⌋+1)/⌊λ⌋! to 6.8e-11.
    - 200 random laws agree with exact Poisson enumeration (my a34b) to 2.5e-12, and L = 2^14 agrees with 2^16.
    - The analytic gradient and the directional derivatives of all five objectives agree with central differences.
  - The final laws are re-evaluated at L = 2^16. After pruning, they are also evaluated by exact enumeration when at
    most six atoms remain.
- **Result** (478 s; A40I_PASS, no flags).

  | region | best found | best few-atom law on the lattice |
  |---|---|---|
  | F | E\|Z\| = 0.8258935 | 0.8258964 |
  | heavy | E\|Z\| = 0.8258727 | 0.8258964 |
  | light | E\|Z\| = 0.8198188 | 0.8198188 |
  | band, ρ = 0.02 / 0.1 | objective −0.00326 / −0.01657 | — |
  | all K | objective 0 | 0 (Dirac arc) |

  - F and heavy end at the three-atom law (1.28, 4/5), (−1.10, 0.104), (0.84, 0.096); in heavy the top atom is split
    between 1.27 and 1.28. The best three-atom lattice law is (1.29, 4/5), (−1.10, 0.1), (0.84, 0.1).
  - The continuum supremum 0.8266648 needs its third atom at 0.85−, which the lattice does not have.
  - Light ends at a Dirac split between 0.81 and 0.82, the lattice version of δ_sqrt(2/3) (0.8198326).
  - The band maxima are spread laws (13 atoms at V+ = 0.98). (Corrected at 06:09: these are only the best laws
    found; simple two- and three-atom laws do better, see the a40l addendum.)
  - All K ends at δ_1.34, on the Dirac arc x ∈ [1.3389, 1.4969], where E|Z_K| = g(λ+) >= C_5.
  - Every law that prunes to six atoms or fewer agrees with exact enumeration to 1e-12.
- **Outcome.** Spreading the mass over many lattice atoms gives nothing above the few-atom optima.
  - In F, heavy and light the best value stays at least 0.029 below C_5.
  - The band and all-K objectives stay <= 0, with equality only on the Dirac arc.
  - This is consistent with A.34, A.38, A.39 and A.40 and adds nothing to their proofs. The lattice step 1/100 and
    the local nature of the search limit this evidence.

**Addendum (2026-10-23 05:42 UTC): the many-atom search on a finer lattice (evidence, not proof).** On the lattice of
a40i (step 1/100) the third atom of the F optimum can sit at 0.84 but not at 0.85−, and the lattice optimum is 7.7e-4
below the continuum few-atom supremum 0.8266648. a40j repeats the search for F, heavy and light on
(1/200)Z ∩ [-1.54, 1.54] \ {0} (616 atoms) plus a Gaussian part, where the third atom can sit at 0.845.
- **a40j** (`audit/chain/a40j_idstar_lattice_fine.py` 508ad978…, output `outputs/a40j_idstar_lattice_fine.txt`
  f5c4b755…). It imports a40i (7c6f6685…, unchanged) and replaces its lattice. The evaluator, the ascent, the polish
  and the parameters are a40i's: 16 starts per task, 8 tasks per region, up to 1,500 iterations.
- **Self-test.** a40i's self-test, rerun on this lattice, passes except for two lines. Both are float64 rounding, not
  formula errors (companion `audit/chain/a40j_precision.py` a433719c…, output `outputs/a40j_precision.txt`
  50087d0b…).
  - The single-atom check now reaches rate 40,000 (x = 0.005) and misses its 1e-10 threshold by 2e-11. Against the
    exact value in 300-bit arb, the FFT is within 1.0e-10 at rate 40,000 and within 3.4e-12 at rates up to 10,000.
    The float closed form that a40i compares with is itself off by up to 1.7e-11.
  - The objective checks address the lattice by index. On this lattice they put mass 0.27 on x = −0.005 (total rate
    about 9,000), and three of the six central differences with step 1e-6 miss the analytic derivative, by up to
    4.9e-5. For the check with that largest miss ("all", V+ weight 0.9), steps 1e-5, 1e-4 and 1e-3 give gaps of
    5.1e-7, 3.7e-7 and 1.7e-8, and E|Z| itself moves by 8.8e-11 between FFT sizes 2^14, 2^15 and 2^16. So the misses
    are rounding noise of about 1e-10, divided by the step.
  - The index-based checks, repeated at the a40i positions (x = −1.44, −0.04, 0.47, 1.37, 1.54), all pass
    (A40J_SELFTEST_PASS): the gradient to 2.8e-7 relative, and all six objectives to about 2e-8.
  - Errors of 1e-10 are far below what the search resolves (its flags are at 1e-7, the margins are 0.03).
- **Result** (228 s; A40J_PASS, no flags). A first run was stopped after 28 minutes because a40j imported numpy
  before a40i limits the BLAS threads, so the 8 workers ran 64 threads. Its partial output was overwritten, and
  nothing from it is used.

  | region | best found | grid benchmark, step 1/200 | grid benchmark, step 1/100 (a40i) | continuum few-atom sup |
  |---|---|---|---|---|
  | F | E\|Z\| = 0.8262733 | 0.8262769 | 0.8258964 | 0.8266648 |
  | heavy | E\|Z\| = 0.8262779 | 0.8262769 | 0.8258964 | 0.8266648 |
  | light | E\|Z\| = 0.8198295 | 0.8198295 | 0.8198188 | 0.8198326 |

  - Heavy ends at the three-atom law (1.29, 4/5), (−1.10, 0.0988), (0.845, 0.1012). It beats the grid benchmark,
    which fixes x2 = −1.105 before optimising the weight, by 1.0e-6. It also lies in F.
  - F ends at a four-atom law, (1.29, 4/5), (−1.10, 0.0913), (−1.05, 0.0074), (0.845, 0.1013). That is 4.5e-6 below
    the heavy law, a limit of the local search.
  - Light ends at the Dirac split between 0.815 and 0.82 (weights 0.739 and 0.261), the lattice version of
    δ_sqrt(2/3), and equals the grid benchmark.
  - Every final law prunes to at most four atoms, and exact enumeration (a34b) agrees with the FFT to the 12 printed
    digits.
  - The gap to the continuum supremum halves with the step: 7.7e-4 at step 1/100 (a40i's benchmark) and 3.9e-4 at
    step 1/200 (the heavy law). Linear extrapolation of the two gives 0.8266593, 5.5e-6 below 0.8266648. For light,
    whose continuum optimum is a smooth maximum in x, the gap falls about fourfold, from 1.4e-5 to 3.1e-6.
- **Outcome.** At step 1/200, as at 1/100, spreading the mass over many atoms gives nothing above the few-atom optima.
  The lattice optima approach the continuum few-atom suprema at the expected rates.
  - In F, heavy and light the best value stays at least 0.028 below C_5. The continuum supremum 0.8266648 is itself
    0.0284 below C_5.
  - This is consistent with A.34, A.38, A.39 and A.40 and adds nothing to their proofs. The search is local, and the
    band and all-K objectives were not rerun on this lattice.

**Addendum (2026-10-23 06:00 UTC): the band and all-K objectives on the finer lattice (evidence, not proof).** The
a40j addendum noted that these were not rerun on the lattice of step 1/200. a40k and a40k2 do that, with a40i's
objectives, search and parameters on a40j's lattice (616 atoms plus a Gaussian part). A flag is an objective above
1e-9.
- **a40k** (`audit/chain/a40k_band_fine.py` a386d8b7…, output `outputs/a40k_band_fine.txt` 4482fe12…; 175 s;
  A40K_PASS, no flags). Random starts, as in a40i.
  - Band, ρ = 0.02: best objective −0.0036543, a five-atom law at V+ = 0.98.
  - Band, ρ = 0.1: −0.0176097, a three-atom law at V+ = 0.9.
  - All K: 0, at δ_1.34 on the Dirac arc.
  - This lattice contains the one of step 1/100, so its band maxima are at least a40i's −0.0032562 and −0.0165676.
    From random starts the search stopped short of both, by 4e-4 and 1e-3: with twice the atoms, the local search
    finds less.
- **a40k2** (`audit/chain/a40k2_band_seeded.py` a4dd76d3…, output `outputs/a40k2_band_seeded.txt` a613ecea…; 46 s;
  A40K2_PASS, no flags). It runs the ascent and polish from a40i's two band optima and from seven perturbed copies of
  each.
  - Evaluated on this lattice, a40i's laws (their printed atoms, renormalised) give −0.0032555 and −0.0165677,
    against a40i's −0.0032562 and −0.0165676. The differences, 7e-7 and 7e-8, come from the five printed decimals of
    the weights.
  - The best objectives found are −0.0030131 (ρ = 0.02; 13 atoms at V+ = 0.98) and −0.0159944 (ρ = 0.1; 8 atoms at
    V+ = 0.9). All eight starts end within 1.1e-4 (ρ = 0.02) and 6.3e-4 (ρ = 0.1) of these values.
  - Both optima use the new lattice point 0.845. Like a40i's, both sit at λ+ = 0.4463, which is 2 ln(5/4) to four
    digits, the point where g(λ+) = C_5 and max(g(λ+), C_5) has its kink.
- **Outcome.** On the lattice of step 1/200 the band objective stays below 0 by about 0.15ρ to 0.16ρ (0.0030 at
  ρ = 0.02, 0.0160 at ρ = 0.1). The all-K objective reaches 0 only on the Dirac arc. This is consistent with
  Theorem 13 (A.34) and A.40 and adds nothing to their proofs.
  - **Corrected at 06:09 (next addendum):** these values are not the band maxima. Simple two- and three-atom laws on
    the same lattices do better at both ρ, so the margins are smaller than stated: in the continuum they are at most
    0.1205ρ at ρ = 0.02 and 0.1544ρ at ρ = 0.1. No positive value was found.

**Addendum (2026-10-23 06:09 UTC): ID*(C_5) at its equality case, the Dirac arc, and a correction of my band
margins (a closed-form check and evidence, not proof).** Φ(K) = E|Z_K| − max(g(λ+), g(λ−), C_5) vanishes at the Dirac
laws δ_x with x on the arc [x_lo, x_hi] = [1.338868, 1.496900], where g(1/x²) >= C_5. This is where Theorem 13
(A.34) is tight.
- **a40l** (`audit/chain/a40l_arc_variation.py` 75d3ba0a…, output `outputs/a40l_arc_variation.txt` 033a6cad…; 5 s).
- **The first variation at the arc, in closed form.** For x inside the arc, λ = 1/x² < 1, so Z = x(N − λ) is
  negative only when N = 0. The identity E|Z + y| − |Z| − y sgn Z = 2(|y| − |Z|)_+ 1{sgn Z = −sgn y} gives the
  derivative D of Φ at δ_x in the direction δ_y − δ_x:
  - y >= 0.85 (the mass stays in V+): D = −x e^-λ (1/y − 1/x)²;
  - 0 < y < 0.85: D = e^-λ ((2/y²)(y − 1/x)_+ − 1/x);
  - y < 0: D = e^-λ ((2/(xy)²)(|y| − x + 1/x)_+ − 1/x), because only N = 1 reaches |y| <= 1.54;
  - towards the Gaussian part: D = −e^-λ / x.
  - These match one-sided differences of the exact enumeration (a34b, ε = 1e-7) at 240 pairs, to 2.9e-7.
  - D < 0 for every y ≠ x and for the Gaussian part. It tends to 0 only as y → x, and then quadratically. On a
    400 × 800 grid the largest D with |y − x| > 1e-3 is −2.0e-7.
  - Moving mass out of [0.85, 1.54] costs least towards y = 0.85−, from the upper end of the arc. There λ = 2 ln(5/4)
    and e^-λ = 16/25, so the slope is (16/25)((2/0.85²)(0.85 − √(2 ln 5/4)) − √(2 ln 5/4)) = −0.105198.
- **The band maximum at residual mass r = 1 − V+.** The law (1 − r)δ_x + r δ_0.85−, with x inside the arc, pays
  about D·r. D is least negative for the largest x that keeps g(λ+) >= C_5, which is x* = √((1 − r)/(2 ln 5/4)); there
  λ+ sits at the kink of max(g(λ+), C_5). A Nelder–Mead search over three atoms and a Gaussian part at V+ = 1 − r
  (12 starts per r) finds:

  | r | two-atom law at the kink | Nelder–Mead best |
  |---|---|---|
  | 0.001 | −0.10598 r | the same law |
  | 0.005 | −0.10908 r | the same law |
  | 0.01 | −0.11293 r | the same law |
  | 0.02 | −0.12051 r | the same law |
  | 0.05 | −0.14239 r | the same law |
  | 0.1 | −0.17613 r | −0.15439 r, at (1.42024, 0.9), (0.85−, 0.0705), (−1.26271, 0.0295) |

  - At r = 0.005 this is a34d's law and value: 0.995 δ_1.493 + 0.005 δ_0.85−, −5.454e-4 (A.34). The slopes, 0.106
    to 0.154, agree with RQ-C's independent 0.12–0.16 (A.34's ρ² is this r).
- **Correction to the a40i, a40k and a40k2 addenda.** Their band values are not the band maxima. Simple laws on the
  same lattices do better:

  | ρ (= r) | lattice step | search reported | simple law on the same lattice |
  |---|---|---|---|
  | 0.02 | 1/100 (a40i) | −0.0032562 | −0.0026642 at (1.48, 0.98), (0.84, 0.02) |
  | 0.02 | 1/200 (a40k2) | −0.0030131 | −0.0025542 at (1.48, 0.98), (0.845, 0.02) |
  | 0.1 | 1/100 (a40i) | −0.0165676 | −0.0161487 at (1.42, 0.9), (0.84, 0.0675), (−1.27, 0.0325) |
  | 0.1 | 1/200 (a40k2) | −0.0159944 | −0.0157963 at (1.42, 0.9), (0.845, 0.07), (−1.255, 0.03) |

  - The searches stall at the kink λ+ = 2 ln(5/4), with the top mass spread over up to 13 atoms. The polish moves
    mass by only one or two lattice steps, which cannot gather it into one atom.
  - So the band margins are smaller than the 06:00 addendum says: at most 0.1205ρ at ρ = 0.02 and 0.1544ρ at
    ρ = 0.1, in the continuum. No positive value was found anywhere, so the hostile outcome is unchanged.
  - The F, heavy and light results of a40i and a40j are not affected. There the searches reach the known few-atom
    optima.
- **Outcome.** At first order, every way of perturbing a Dirac on the arc lowers Φ; moving mass out of [0.85, 1.54]
  costs at least 0.105 per unit mass. This is consistent with Theorem 13 (A.34) and adds nothing to its proof, which
  is the certificate.

**Addendum (2026-10-23 07:58 UTC): freshness of the chain's sources (a40q, a40r).** Each link of the chain was
audited on particular versions of the solvers' documents and data. This addendum checks that the store still holds
those versions.
- **A gap closed (a40q).** RQ-A re-posted K2, K3, K3B and K4 at 01:41 with new status items. The 02:00 entry checked
  the new .tex files, but not the rebuilt PDFs (K2 3de8099f…, K3 803db5fe…, K3B 930ea67b…, K4 883c78df…).
  - For K2, K3 and K3B I hold the PDF built from the refereed .tex (2dcac658…, 92d2639b…, f114b71b…). The
    `pdftotext -layout` diff against the store PDF is the status item and nothing else, apart from a page-number line
    that moved by one column.
  - For K4 I hold no PDF of the refereed build (158934d2…). There the check is that the store PDF carries every number
    (148) and every word of 6 or more letters (484) of its .tex. The same holds for K2, K3 and K3B.
  - Script `audit/chain/a40q_rqa_pdf_check.py` (8fabb16c…), output `audit/chain/outputs/a40q_rqa_pdf_check.txt`
    (febd52a9…), A40Q_ALL_PASS.
- **Freshness (a40r).** `audit/chain/a40r_chain_sources.py` (10423331…) has output
  `audit/chain/outputs/a40r_chain_sources.txt` (03ec06a5…), A40R_ALL_FRESH. It covers:
  - 23 documents and data files of the links, each at the md5 recorded for its latest audited version;
  - two spans of longer files, each byte-identical to my copy of the audited version. These are RQ-A's U.1–U.3 (A.26;
    3,082 bytes, as in CLAIMS 3a8a0c64…) and the body of RQ-C's C15 (A.28; 7,289 bytes, as in 715a241b…; only the
    status tag of its heading changed);
  - RQ-D's 21 script, record and certificate files of a34i (hashed, not read).
- **Outcome.** Every link of A.40 still rests on the versions that were audited and refereed. From now on each cycle
  also compares a full md5 manifest of the store (a40p, store log) with the previous one. So a file replaced with its
  old mtime kept would also be found.

**Addendum (2026-10-23 08:51 UTC): hostile direct searches next to the seams inside (0, q5) (evidence, not
proof).** At a seam q_s = 1 − sqrt((s−1)/s), OR_(s−1) and OR_s tie and M has a corner. The seams crowd together as
q → 0, about 2q^2 apart, so distances to them are measured here in local spacings. a40h searched next to q2–q5. On
(0, q5], a40b, a40b2 and a40c used 14 fixed points. The nearest seam is 0.010 spacings away for 87/1000 (1.3e-4 below
q6), 0.031 for 21/200 (next to q5) and 0.075 for 3/100 (next to q17), and 0.23 to 0.45 spacings away for the other
eleven. This search attacks R(q) = M(q) within 2.6e-7 spacings of the seams q6–q11 and within 0.021 spacings of q16,
q21, q31, q51 and q101. It uses none of the links.
- **a40s** (`audit/chain/a40s_seams_direct.py` 63db513a…, output `audit/chain/outputs/a40s_seams_direct.txt`
  218f2115…). It imports the numerics of a40h (0e966cef…), a40b2 (88427487…) and a40c (50ced822…), all unchanged:
  full enumeration of {0,1}^n and block vectors with 2–4 levels, both ascending with the sign iteration.
  - 46 rational points: q_s ± 1e-3, ± 1e-6 and ± 1e-9 for s = 6..11, and q_s ± 1e-6 for s = 16, 21, 31, 51 and
    101. So N runs from 5 to 101, and the script checks that N is s below the seam and s − 1 above it.
  - Full enumeration for s = 6..11 at n = N, N+1, N+2, N+3, N+5, 12, 15 and 18 (300 starts with kicks), and at n = 20
    at the ±1e-9 points (100 starts); for s = 16 at n = N to 18 and at n = 20.
  - Block vectors at every point: a40h's families (all 5,050 pairs of block sizes up to 100, 1,500 random triples up
    to 40, 800 random quadruples up to 14, and 160 pairs with one block of 200 to 2,000 coordinates) and a40c's
    near-N pairs (a <= 40, |b − N| <= 5).
  - One new family aimed at the corner puts the two tying vectors side by side, with one small extra level or a large
    block: (k, b), (k+1, b), (k, 1, b), (k+1, 1, b) and (k, k+1, b), with k = s − 1, b in 1..40 or in
    {100, 200, 500, 1000}, and grids of at most 5·10^5 points.
  - Every ratio above M (1 + 1e-12) is re-checked in exact rationals at its rational point. So is the best non-equal
    maximum of each block task whose grid has at most 2·10^4 points.
  - Then, at each exact seam (irrational q_s), Arb at 200 bits evaluates (ratio/M_k)^2. Here M_k^2 =
    4q(1−q) k (1−q)^(2k−2) is the branch k = s − 1 of M^2; it equals M^2 at the seam and never exceeds it, so a ball
    below 1 certifies ratio < M.
    - The controls OR_(s−1) and OR_s must give balls containing 1.
    - For each family, the best non-equal local maximum over all points of the seam is merged into levels and
      ascended again at the seam (float64). The vector reached is rounded to rational levels and certified. If the
      ascent ends at an equal-coefficient vector, the unpolished vector is certified instead.
- **Self-test before the run.** At q6 the controls OR_5 and OR_6 give balls containing 1 (radius 1e-58), and OR_7
  gives 35/36. OR_5 plus one coordinate of relative weight −1/2 gives 0.952380952380952, which is 20/21 (see the
  closed form below).
- **Earlier runs.** Three runs between 08:24 and 08:39 differed from the final one only in the Arb step and its
  summary line (the first run took just the two points closest to each seam, with no ascent at the seam) and in a
  docstring sentence that misstated the distances of the earlier points. The search is seeded, and all four runs gave
  the same search results.
- **Result** (834 tasks in 190 s; A40S_PASS).
  - The best ratio is M (1 + 5.7e-13) at most, which is float noise, and it is always attained at ±OR_N. No flags.
  - At all 38 points with full enumeration, the limits include both tying vectors OR_(s−1) and OR_s.
  - All 548 exact re-checks of non-equal maxima are strictly below M.
  - Arb: the 22 controls contain 1 (radii at most 1.6e-57), and all 73 certified non-equal vectors lie strictly below
    1. One of them is certified unpolished: a local maximum at q6 − 1e-3 whose ascent at q6 ends at an OR vector.
  - The largest non-equal local maximum v at each seam (weights relative to the OR block):

  | seam | v / M | (1 − v/M) / q_s | the vector |
  |---|---|---|---|
  | q6 | 0.979337 | 0.2372 | OR_5, 1 coordinate at +0.475, 19 at −0.028 |
  | q7 | 0.982236 | 0.2395 | OR_6, 1 at +0.475, 36 at −0.018 |
  | q8 | 0.984515 | 0.2398 | OR_7, 1 at +0.463, 11 at −0.032 |
  | q9 | 0.985611 | 0.2516 | OR_9, 1 at −0.530 |
  | q10 | 0.987096 | 0.2514 | OR_10, 1 at −0.527 |
  | q11 | 0.988304 | 0.2513 | OR_11, 1 at −0.524 |
  | q16 | 0.992032 | 0.2509 | OR_16, 1 at −0.516 |
  | q21 | 0.993958 | 0.2507 | OR_21, 1 at −0.512 |
  | q31 | 0.995927 | 0.2505 | OR_31, 1 at −0.508 |
  | q51 | 0.997534 | 0.2503 | OR_51, 1 at −0.505 |
  | q101 | 0.998759 | 0.2502 | OR_101, 1 at −0.502 |

  - Two families give the runner-up. At q6, q7 and q8 it is OR_(s−1), plus one coordinate of the same sign, plus a
    cloud of small coordinates of the opposite sign; a40c found this family at q = 7/100 and 2/25. From q9 on it is
    OR_s plus one coordinate of relative weight near −1/2, the family a40c found at its other points.
  - The second family has a closed form. Take OR_N plus one coordinate of weight w, with qN < 1 and
    −(1 − qN)/(1 − q) <= w <= 0. Then the only negative atoms are the two with no ones in the OR block. So E|α.χ|
    does not depend on w, and the ratio is that of OR_N times (1 + w^2/N)^(−1/2). This gives the 20/21 of the
    self-test. At the seams qN tends to 1/2, and the factor at |w| = 1/2 is 1 − q/4 + O(q^2). Beyond that range of w
    the atom with a single one in each part turns negative too, but this changes the optimum only at order q^2. So
    the gap tends to q/4 as q → 0, as in the table.
  - Over all 46 points, the best non-equal value found lies between 0.2372 q and 0.2686 q below M. The values below
    0.250 q, a40c's lower end, occur at q6 − 1e-3, q6 + 1e-6, q7 + 1e-6 and q8 ± 1e-6, ± 1e-9, all within 0.078
    spacings of q6, q7 and q8. They come from the new family, from quadruples and, at q6 − 1e-3, from full
    enumeration.
  - The values are lower bounds for the best non-equal local maximum, not exact values. At q6 ± 1e-9 the search
    found only 0.978021 M, while the new family reached 0.979337 M at q6 + 1e-6, and the same value after the ascent
    at q6.
- **Outcome.** No vector exceeds M next to any of the 11 seams. The search reaches both tying vectors at every seam
  it enumerates, and the best non-equal local maxima it finds are certified below M at the seams themselves. This is
  consistent with A.40 and adds nothing to its proof.

---

## A.41 RQ-A's FULL_PROOF.pdf (the compiled proof of Conjecture S) — VALID WITH FIXES (text only); the mathematics is that of A.40 (2026-10-23 09:57 UTC); VALID after the fixes (2026-10-23 10:22 UTC)

**What is audited.** RQ-A's FULL_PROOF.pdf (be3ca559…, 192 pages: a title page, pages i–xvi and pages 1–175) and its
source FULL_PROOF.tex (0ec0a1e2…, 9,807 lines), posted at 08:53–08:54 UTC. The coordinator delivered the PDF to Paata
as Rq_full_proof.pdf (LOCKED_NOTE: 01:57 PT, that is 08:57 UTC). The document makes no new claim. It collects the
doubly VALID chain A.40 into one text: the Main Theorem with its proof in Steps 0–4, Chapters 1–10 transcribed from
the refereed sources, and Appendices A–D. So the questions are whether the transcription is faithful and complete, and
whether the new text (front matter, chapter source boxes, editorial notes, appendices) is true.
- Copies are in `audit/snapshots/s0900_fullproof/`: the PDF, the tex, `full_proof/` with the parts and the source
  copies, RQ-A's STATUS, NOTES and LAST_MIRROR of 08:56, and LOCKED_NOTE 7dbc0d30….
- I did not read RQ-A's `scripts/build_full_proof.py` (d07b95ec…), `scripts/check_full_proof.py` (0d1b89ae…) or
  `scripts/mirror.sh` (467e807a…); md5s only.
- pdflatex is not installed here, so I did not rebuild the PDF. I checked the tex against the sources, and the PDF
  text (pdftotext) against the tex.

**Verdict: VALID WITH FIXES, text only.** The document states and proves Conjecture S exactly as in A.40. Every chapter
is a faithful transcription of the file that was audited and refereed, and every computer step is cited with the
counts and md5s that A.6–A.39 checked. Four sentences of the new text are wrong (f1–f4), and four remarks need no fix
(r1–r4). None of them is in a statement or a proof of the chain.

**Checks** (my own code in `audit/fullproof/`; none of RQ-A's code was read or run).
- **Faithfulness: a41a** (`a41a_faithful.py` 55d1adf9…, output `a41a_faithful.txt` 7363c914…; A41A_PASS).
  - FULL_PROOF.tex has 13 source blocks: RQ-A's six papers, six excerpts of RQ-B's paper and RQ-D's paper. The
    sources are RQ-A's MAIN_RESULT, K2, K3, K3B, K4 and K5 tex (38b69350…, 280e80ed…, 00720a0c…, efa33947…,
    01d91659…, bc42dd0f…), RQ-B's tex (e4193842…) and RQ-D's tex (ac0ecf4f…), each equal to the store file.
  - With its editorial insertions removed (34 in all: notes, tags and supplements), each block differs from its source
    only by the mechanical changes of Appendix C. These are label prefixes, sectioning levels, abstracts and titles,
    and the appendix heading of Theorem 1's paper. RQ-B's excerpts are disjoint and in source order, and no
    difference is left unexplained.
- **Numbering: a41b** (`a41b_numbering.py` fd621c74…, output f5366819…; A41B_PASS).
  - The 22 source tags in Chapters 7 and 10 give the right numbers of RQ-B's items. I replayed the counters of RQ-B's
    tex; the .md names and the PDF (a6901915…) agree with the replay.
  - The three references written out as text (Remark 9.7, Section 11 and Theorem 6.1) are right too.
  - RQ-D's paper numbers all its theorem-like items with one counter, so its item n is item 9.n here.
- **Figures written with "…": a41c** (`a41c_ellipsis_fullproof.py` 1580ff0f…, output b334ca11…). All 38 such figures in
  the tex are compared in Arb with their exact values. 33 give leading digits, and 5 are roundings (f2).
- **PDF against tex: a41d** (`a41d_pdf_coverage.py` ebbc94d2…, output d0b5bafb…; A41D_PASS). The PDF has 192 pages,
  191 of them with the footer labels i–xvi and 1–175, and no "??" or "[?]". Every number (1,099) and every word of
  six or more letters (1,503) of the text of the tex occurs in the PDF text.
- **Plain-text transcriptions: a41e** (`a41e_numerals.py` 22f7335f…, output 13e0fa48…). Three sources are plain text:
  RQ-C's C15 (Chapter 8), RQ-A's U.1–U.3 (Section 7.6) and RQ-B's three .md passages set as supplements in Chapter
  10. Their sequences of numerals agree with the transcriptions, except for notation (\frac12 for ½ or 1/2, \frac65
  for 6/5) and the dropped heading "13.4". The word differences are the names of symbols (theta, delta, sqrt and so
  on) and headings.
- **The editorial apparatus** (my own count) is as Appendix C states. There are 26 editorial notes (2, 9, 5, 3 and 7 in
  Chapters 1, 7, 8, 9 and 10), 22 source tags (13 in Chapter 7 and 9 in Chapter 10), 5 omission notes and 3
  supplements, and none in the front matter or the appendices. RQ-D's source differs from the refereed 212c6f23… only
  in lines 617 and 652, the two figures checked in a34i. Theorem 1's source differs from the refereed 6816732f… only
  in the figure of A.6 f3.
- **The editorial notes on known slips** state the slips and their status correctly. They are A.6 f3 (6.2·10⁻³ →
  6.1·10⁻³), A.34 f1 (0.5599 → 0.5579, with g(Λ) > C_5 exactly for 0.4462871… < Λ < 0.5578588…), RQ-D's control
  figure (0.1973 → 0.1972, with 101/512 = 0.197265625) and A.26 f1 (0.853344 rounds C(q4) up).
- **The chapter source boxes.** Every audit time, verdict, fix and addendum they cite agrees with my ledger and
  sections:
  - A.6 (06:52; f3 at 02:55 and 03:30), A.7a (re-rated VALID at 07:48), A.10a and A.10c, and A.11 (08:52);
  - A.14 (10:37), A.18 (12:41), A.25 (16:53; r1–r2 applied at 17:47; RQ-A's c1–c2 of 20:51 confirmed at 21:19);
  - A.26, A.30 (17:23, after f1), A.32 (18:17), and A.34 (20:19; addenda 03:02, 04:51, 06:58 and 07:48);
  - A.37 (22:58; r1 applied 23:04–23:06), A.38 (22:51; r3 settled at 23:25), and A.39 (01:05, with its counts, the
    worst bound 0.8549969806 and the remarks r1–r4; addendum 02:29).

  The sentence the Chapter 9 box quotes from my a34i addendum is in the A.34 section. The three referee reports have
  the md5s cited (369c1cfb…, bd18da81…, 6ac713c0…; equal to the store files), and the verdict phrases quoted are
  theirs.
- **"The referees re-did every computer-assisted step with their own code"** (abstract). RQ-REF1 writes "Every
  verification below uses my own code", RQ-REF2 "I wrote every program from scratch", and RQ-REF3 re-verified the
  certificates of links 3 and 4 with its own code. Links 1 and 2 have no computer step. So the sentence is supported.
- **Appendix A** cites my seam check correctly (`a40_chain_seams.py` b4cce911…, 24 PASS, Arb at 256 bits, θ_max =
  1.0062780 as the midpoint of a ball), and the sweep a40f (79 PASS).
- **The Main Theorem and Steps 0–4** are the composition of A.40. They use the same ranges and links, C_5 =
  g(2 ln(5/4)), θ = 17/20, A = 77/50 > A'(q5), the same three regions (V+ or V− ≥ 4/5; 1/2 ≤ V± < 4/5; V+, V− <
  1/2) and the mirror. The extremiser remark is right in substance: together, Theorems 1–6 list every extremiser on
  [q6, 1−q6]. Only its cross-reference is wrong (f4).

**Findings to fix (text only).**
- **f1** (front matter, the remark "an equivalent Boolean form", tex line 184).
  - The remark states sup_f Σ_i Δ_i(f)² = max_k k q̂^(2k−2) and adds "with equality for the OR of k bits". That holds
    for q ≤ 1/2 only.
  - For the OR of k bits Δ_i = (1−q)^(k−1), so D(OR_k) = k (1−q)^(2k−2). For q > 1/2 and k ≥ 2 this is below k
    q̂^(2k−2) = k q^(2k−2).
  - For q > 1/√2 the maximum is attained only at some k ≥ 2, so no OR attains it. The AND of k bits does: Δ_i =
    q^(k−1), and the AND is the image of the OR under x ↦ 1 − x.
  - Own check a41f (`a41f_boolean_form.py` 1f52da1a…, output 8b175e18…; A41F_PASS; exact rationals). At q = 3/4, 4/5
    and 9/10, every maximiser of D over all Boolean f on n ≤ 4 bits is an AND of k ≥ 2 bits or its complement, and
    none is an OR. At q = 1/4 the maximisers are ORs and complements of ORs.
  - Suggested text: "with equality for the OR of k bits if q ≤ 1/2, and for the AND of k bits if q ≥ 1/2, where k
    attains the maximum".
- **f2** (five figures with "…" that are roundings). By the convention of a40m, "d.ddd…" must give leading digits.
  These five do not:
  - line 350, in the notation table: q4 = 0.133975… (exact 0.1339745962…; read 0.133974…);
  - line 351: q5 = 0.105573… (0.1055728090…; read 0.105572…);
  - line 352: q_L = 25/169 = 0.147929… (0.1479289940…; read 0.147928…);
  - line 652, Step 4(iii) of the proof of the Main Theorem: C_5 − 171/200 = 1.0046…·10⁻⁴ (1.0045547081…·10⁻⁴; read
    1.0045…·10⁻⁴);
  - line 7226, the editorial note in Theorem 8.1(g) that quotes my A.40 sweep: A'(q4) = 1.5759927… (1.5759926691…;
    read 1.5759926…). My A.40 sweep wrote 1.5759927 without an ellipsis, as a rounding.

  No proof uses these figures. The inequalities the chain needs were checked exactly (`a40_chain_seams.py` J1, J4
  and J5, and RQ-REF3's constants).
- **f3** (Appendix A, tex line 9003, and the timeline in Appendix B, line 9432).
  - Appendix A says that RQ-A ran the job script "unmodified on 8 cores on 22 October, finishing at 23:33 UTC", and
    the timeline says "finished 23:33". Both should read 23:09 UTC.
  - In `RQ-A/far_jobs/nsplit_k30_35/` the run's files have mtimes from 23:03:10 (MD5SUMS_used.txt) to 23:09:01
    (run.log, whose last line is "DONE"). RQ-A's own NOTES heading of 23:34 reads "RQ-B's k = 30..35 batch finished
    at 23:09 UTC".
  - The timeline row is also inconsistent with itself: it puts "computation complete" at 23:20 and "finished 23:33"
    in the same row.
- **f4** (front matter, the remark "extremisers", tex line 189).
  - The remark says "part (b) of each of Theorems 1–6 lists them". Theorem 1 lists its extremisers in part (c); its
    part (b) is the sharpness statement. Theorems 2–6 list them in part (b).
  - Suggested text: "part (c) of Theorem 1 and part (b) of Theorems 2–6 list them". The example that follows (±e_j
    on (q2, 1−q2)) is Theorem 1(c), and it is right.

**Remarks (no fix needed).**
- **r1** (Introduction, "No huge coefficients", tex lines 263–265). "Every jump of the measure K produced above lies in
  [−A'(q), A'(q)]" is the limit form. Theorem 8.1(e)–(f) bounds the support by Λ_n/(u√s), which is at least A'(q)
  and tends to A'(q) as n → ∞. That is why (f) asks for A > A'(q). The chain uses A = 77/50 > A'(q5), a strict
  inequality, so nothing changes.
- **r2** (Appendix C, counts from RQ-A's checker). I cannot reproduce two counts without RQ-A's build script, which I
  do not read.
  - The 35 edits (3 + 13 + 3 + 16).
  - The numeral counts 311 for C15 and 26 for the first supplement. My tokenisation gives 309 numerals in the source
    and 310 in the transcription for C15, and 27 and 26 for the supplement (the extra one is the heading "13.4").

  My checks a41a and a41e cover what these counts are meant to show.
- **r3** (informational). The bibliography's "BF3 (a team of AI agents)" and the Introduction's "a report by an earlier
  team of AI agents" are not in the BF3 PDF. It gives the author as "BF3", with the subtitle "24-hour research attack
  on Open Questions 5–6 of Chase–Filmus–Minzer–Mossel–Saurabh". I cannot check the description.
- **r4** (not in FULL_PROOF). RQ-A's STATUS.md and NOTES_FOR_TEAM.md of 09:31 give the delivery time as "01:57 PT =
  09:00 UTC". In October PT is UTC−7, which FULL_PROOF itself uses (20:10 PT = 03:10 UTC), so 01:57 PT is 08:57 UTC.
  09:00:47 is the mtime of LOCKED_NOTE.md.

**Novelty.** As A.40, the value of R(q) for every q is NEW. The document adds no mathematics. Its Boolean
restatement is immediate from Lemma 7.5 (RQ-B's Lemma 2.1, A.7a), which is KNOWN in kind from BF3.

**Status.** A.41 rates the document, not a new result. The mathematics that the proof of the Main Theorem uses
already meets the LOCKED_NOTE criterion: A.40 and its links, refereed by RQ-REF1, RQ-REF2 and RQ-REF3 as the block
under the ledger lists. (Corrected at 11:23: this sentence said "A.6–A.39 and A.40, refereed by RQ-REF1, RQ-REF2
and RQ-REF3", but not every item in that range is refereed; A.9, A.12 and A.23, for example, are not. The document
also transcribes parts that no step of the proof uses, such as RQ-D's Theorem 10 and Corollary 11, which only I
audited (A.32). Its source boxes state what each referee covered correctly, by a41j in the store log of 11:23.)
The fixes f1–f4 are for RQ-A, as its note of 09:31 asks. If RQ-A posts a corrected file, I will check that it
differs from be3ca559… and 0ec0a1e2… only at these places.

**Addendum (2026-10-23 10:22 UTC): two more checks of the delivered file; its verdict is unchanged.**
- **a41g, macros** (`audit/fullproof/a41g_macros.py` 0434fde7…, output `audit/fullproof/a41g_macros.txt` 7d2361e5…;
  A41G_PASS). FULL_PROOF has one preamble for all chapters, so a macro that two sources define differently could
  print wrongly in one chapter although the tex is identical.
  - Every macro that the eight source papers define and use (\E, \R, \N, \PP, \bb, \mb, \ubar, \sgn and \Rid) has
    the same definition in FULL_PROOF, and no two sources define a macro differently.
  - The theorem environments agree as well. The one change is the main counter, numbered within chapters (RQ-B's was
    numbered within sections, RQ-A's and RQ-D's were global). That is the harmonisation of Appendix C, and a41b
    checked its effect on RQ-B's numbers.
- **The rendered PDF** (pdftoppm at 80 dpi), pages i (abstract), vi (the Main Theorem and the Boolean-form remark) and
  xiii–xvi (Roadmap, the proof of the Main Theorem, Tables 2 and 3, Figures 1 and 2).
  - The formulas print as in the tex, and the Roadmap starts on page xiii, as page vi says.
  - Figure 1's seam values 0.0871, 0.1056, 0.1340, 0.1479, 0.1835 and 0.2929 are correct four-digit roundings, and
    the values of M above its bars are T_k for the right k.
  - Figure 2's regions are those of the case split in Step 4, with closed thresholds: the lines V± = 1/2 belong to
    the heavy region and the lines V± = 4/5 to the band, so the triangle V+ + V− ≤ 1 is covered with no gap.
  - I re-derived the sentence under the Main Theorem. Since k(1−p)^(2k−2) ≥ (k−1)(1−p)^(2k−4) iff p ≤ q_k, the
    maximum in (S) is attained at k = ⌊1/(p(2−p))⌋, and also at k − 1 exactly when p = q_k.
  - Nothing new beyond f1 and f2.

**Addendum 2 (2026-10-23 10:22 UTC): RQ-A's corrected file applies f1–f4 and changes nothing else; A.41 is re-rated
VALID.**
- **What RQ-A posted** (10:05:37–10:05:41 UTC, which RQ-A's texts round to 10:06; copies in
  `audit/snapshots/s1006_fullproof2/`).
  - FULL_PROOF.tex 14777fb4… (9,809 lines) and FULL_PROOF.pdf 21fe1613… (192 pages, built 10:03:06 UTC).
  - The changed parts front.tex 9e41564b…, back.tex 9938892b… and ch08_c15.tex a21f5bc9….
  - Text-only STATUS.md 217997d9… and NOTES_FOR_TEAM.md d5a3ff89…, and AUDIT_REQUEST.md eb6448ca…, whose new first
    section lists the nine changed lines and answers r1–r4.
- **a41h** (`audit/fullproof/a41h_followup.py` 1681f5d0…, output `audit/fullproof/a41h_followup.txt` 4d4c4f97…;
  A41H_PASS).
  - The tex. Applying the nine substitutions of f1–f4 to the delivered FULL_PROOF.tex gives the corrected file byte
    for byte, and each replaced string occurs exactly once. The same holds for the three changed parts. The other six
    parts, the nine chapter heads and the seven source copies are byte-identical to the delivered ones.
  - The PDF. Every page of the corrected PDF, as pdftotext prints it, equals the delivered page with the same
    substitutions applied. The page labels and page breaks are unchanged, and nothing prints as "??". Only pages vi,
    vii, x, xv, 119, 157 and 166 differ (physical pages 7, 8, 11, 16, 136, 174 and 183, the ones RQ-A lists).
  - The new f1 sentence, in exact rationals. OR_k and AND_k have D = k(1−q)^(2k−2) and k q^(2k−2) (enumeration of
    {0,1}^k, k ≤ 6). At 403 rational q, at every maximising k, the OR attains max_k k q̂^(2k−2) when q ≤ 1/2 and the
    AND when q ≥ 1/2. As a control, the delivered wording fails at exactly the grid points with q > 1/√2.
  - My checks a41a–a41e and a41g, unchanged, re-run on the corrected version and pass as before. The transcription is
    faithful (13 source blocks, 34 editorial insertions); the numbering, PDF coverage, numerals and macros agree; and
    a41c now finds all 38 "…" figures to be leading digits (38 PASS, 0 ROUNDED). The outputs differ from the committed
    ones only by the shift of two lines, the md5 of the tex and the five corrected figures.
- **The rendered pages** vi and vii (80 dpi) print f1 and f4 as in the tex.
- **RQ-A's replies to the remarks.**
  - r1: agreed, no change.
  - r2: RQ-A states the tokenisation of its checker. a41i (`audit/fullproof/a41i_rqa_tokenisation.py` 467180df…,
    output `audit/fullproof/a41i_rqa_tokenisation.txt` 266215c9…; A41I_PASS) implements those rules with my own code.
    It gets 311 and 311 numerals for C15 and 26 and 26 for the first supplement, with equal sequences, as RQ-A states.
    The count of 35 edits still needs RQ-A's build script; a41a covers what that count is meant to show.
  - r3: settled. The earlier team's store is readable here. `/cursor/stores/bot/bfstoc/LOCKED_NOTE.md` (c6d4f820…)
    lists "BF3 approx polymorphisms" under "Agents (Opus 5.5 max, new_repo)", with BF-AUD as auditor and BF3-REF and
    BF3-REF2 as referees. So "a report by an earlier team of AI agents" is right, although the BF3 PDF does not say so.
  - r4: corrected in STATUS.md and in the 09:31 entry of NOTES_FOR_TEAM.md, which now read "01:57 PT = 08:57 UTC".
- **Two small points in RQ-A's texts.** Neither needs a change to FULL_PROOF.
  - RQ-A's AUDIT_REQUEST says that `pdftotext -layout` prints the fraction 3/4 on page vii as "43" in the corrected
    PDF ("34" before). I see the same. The tex there is unchanged, the rendered page shows 3/4, and `-raw` prints the
    page as before apart from f4. It is an extraction artefact.
  - RQ-A's note for the coordinator says that none of the four items "is in a statement or a proof (A.41)". A.41 said
    that no proof uses the f2 figures. Two of them stand inside a proof or a statement: 1.0046…·10⁻⁴ in Step 4(iii) of
    the proof of the Main Theorem, and 1.5759927… in an editorial note inside Theorem 8.1(g). What holds is that no
    statement and no step of a proof changes: Step 4(iii) needs only C_5 − 171/200 > 0, which was checked exactly
    (f2 above).
- **Verdict.** The corrected FULL_PROOF (pdf 21fe1613…, tex 14777fb4…) is **VALID**. Its mathematics is that of A.40,
  so the novelty is as stated above. The delivered be3ca559… (Paata's Rq_full_proof.pdf) differs from it only in the
  four text items f1–f4. Whether Paata gets the corrected file is the coordinator's decision.

**Addendum 3 (2026-10-23 10:36 UTC): the proof of the Main Theorem rebuilt step by step; no gap; the verdict is
unchanged.** In the corrected FULL_PROOF (tex lines 608–663) I checked each step against the exact statement it cites.
- **Step 0.** R(q) = R(1−q) by Lemma 1.2, and M(q) = M(1−q) because q̂ and q(1−q) are symmetric.
- **Step 1.** Corollary 5.2 states (S) on [q5, 1−q5]. Its proof needs √k(1−q)^(k−1) ≤ 2(1−q)³ for k ≥ 5 and
  1−q ≤ 2/√5. This holds because √k x^(k−4) decreases in k ≥ 5 for x ≤ 2/√5 (the ratio is at most
  √(6/5)·2/√5 < 1) and equals 2 at k = 5, x = 2/√5.
- **Step 2.** Theorem 7.4. For kq < 1 the only value of S below kq is S = 0, so E|Σχ_i|/√k = 2kq(1−q)^k/(τ√k) =
  T_k(q). The maximum over k is at k* = ⌊1/(q(2−q))⌋, and k*q ≤ 1/(2−q) < 1.
- **Step 3.** Theorem 8.1(f), with A = 77/50 and C = C_5.
  - A > A'(q): A' increases, because the derivative of ln A'(q)² is positive iff s(1+q) > q, and s > q. Also
    A'(q5)² = 5q5/ln(5/4).
  - C_5·√(q/((1−q)s)) ≤ M(q): (MC) gives M(q) = √(q/((1−q)s))·C(q), since √k e^(−ks) = g(ks)/(2√s), and C(q) ≥
    C_5 on (0, q5] by Theorem 7.9(d).
  - The proof of (f). Level-one duality gives R_n = 2τ|Δ(f*)| = E|α*·χ|, and K_{f*} = K̃. Theorem 7.9(a) then
    gives R_n ≤ √(q/((1−q)s))·E|Z_K̃|, and λ±(K̃) is a multiple of s for every θ. So the bound (∗) is needed only
    at the one finitely supported K̃ on [−A, A], and for any θ > 0, as the front matter says.
- **Step 4.** Each case meets the exact hypotheses of the theorem it cites.
  - (i) Theorem 9.13 assumes K([0.85, 1.54]) ≥ 4/5, or the mirror, and bounds E|Z_K| by max(g(λ±_0.85), C_5).
  - (ii) Theorem 9.16 assumes 1/2 ≤ K([0.85, 1.54]) < 4/5, or the mirror, and gives E|Z_K| < C_5. It does not need
    finite support.
  - (iii) Theorem 10.1 assumes V+ < 1/2 and V− < 1/2 and gives E|Z_K| ≤ 171/200.
  - Here 77/50 = 1.54 and 17/20 = 0.85. Chapters 7, 9 and 10 define Z_K the same way, and they define
    λ±_θ = ∫_{±x≥θ} x^(−2) dK closed at θ, like V±. So the three cases cover the triangle with the same conventions.
- **Step 5** assembles these. The extremiser statement is Theorem 7.4 together with the mirror.
- Chapter 9 also uses τ for the function E(G−x)_+² and for the threshold 17/20. The notation table of the front
  matter already explains both uses, so no remark is needed.
