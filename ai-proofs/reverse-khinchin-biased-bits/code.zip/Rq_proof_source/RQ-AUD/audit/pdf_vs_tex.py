"""Check that a PDF carries the text of its LaTeX source: every number of the source (outside comments) must occur
in the pdftotext output, and every word of length >= 6 outside LaTeX commands, environments and \\texttt{...}.
Usage: python3 pdf_vs_tex.py SOURCE.tex DOC.pdf
"""
import re
import subprocess
import sys


def main():
    tex = open(sys.argv[1]).read()
    tex = re.sub(r'(?<!\\)%.*', '', tex)
    pdf = subprocess.run(['pdftotext', '-raw', sys.argv[2], '-'], capture_output=True, text=True).stdout
    pdf_flat = re.sub(r'-\n', '', pdf)
    pdf_flat = re.sub(r'\s+', ' ', pdf_flat)
    pdf_nospace = pdf_flat.replace(' ', '')
    body = tex.split(r'\begin{document}', 1)[-1]
    nums = sorted(set(re.findall(r'\d+(?:\.\d+)?', body)), key=lambda s: (len(s), s))
    miss_n = [n for n in nums if n not in pdf_nospace]
    stripped = re.sub(r'\\(?:texttt|label|ref|eqref|cite|begin|end|url|href)\{[^}]*\}', ' ', body)
    stripped = re.sub(r'\\[A-Za-z]+', ' ', stripped)
    words = sorted(set(w for w in re.findall(r'[A-Za-z]{6,}', stripped)))
    pdf_low = pdf_nospace.lower()
    miss_w = [w for w in words if w.lower() not in pdf_low]
    print(f"numbers in source: {len(nums)}, missing in PDF: {len(miss_n)} {miss_n[:40]}")
    print(f"words (>= 6 letters) in source: {len(words)}, missing in PDF: {len(miss_w)} {miss_w[:60]}")


if __name__ == '__main__':
    main()
