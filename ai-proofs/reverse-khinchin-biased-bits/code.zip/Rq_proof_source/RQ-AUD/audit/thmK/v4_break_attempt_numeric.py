"""RQ-AUD: attempt to BREAK Theorem K numerically (evidence only, not proof).

For q on a grid and n <= NMAX, maximise E|alpha.chi| over unit alpha with exact enumeration of
all 2^n atoms.  Optimiser: the monotone L1 power iteration alpha <- E[sign(alpha.chi) chi]/norm,
which never decreases E|alpha.chi| (E|a'.chi| >= E[sgn(a.chi) a'.chi] = |E[sgn(a.chi) chi]|
>= E|a.chi|), started from random Gaussian directions, random sparse directions, and structured
starts (equal coefficients, one big + equal small, two equal).  Reports max E|L|/(2 tau).
"""
import numpy as np
import itertools
import sys
import time

rng = np.random.default_rng(20261022)


def atoms(q, n):
    u, v = np.sqrt((1 - q) / q), np.sqrt(q / (1 - q))
    bits = np.array(list(itertools.product([1, 0], repeat=n)), dtype=np.int8)  # 1 -> value u
    X = np.where(bits == 1, u, -v)
    k = bits.sum(axis=1)
    p = q**k * (1 - q)**(n - k)
    return X, p


def EabsL(alpha, X, p):
    return float(p @ np.abs(X @ alpha))


def power_iter(alpha, X, p, iters=200):
    alpha = alpha / np.linalg.norm(alpha)
    val = EabsL(alpha, X, p)
    for _ in range(iters):
        L = X @ alpha
        sg = np.sign(L)
        sg[sg == 0] = 1.0
        g = (p * sg) @ X
        nrm = np.linalg.norm(g)
        new = g / nrm
        nv = EabsL(new, X, p)
        if nv <= val + 1e-15:
            break
        alpha, val = new, nv
    return val, alpha


def structured_starts(n):
    S = [np.ones(n)]
    for k in range(1, n):
        for big in (0.95, 0.9, 0.8, 0.7, 0.5):
            a = np.zeros(n)
            a[0] = big
            a[1:k + 1] = np.sqrt((1 - big**2) / k)
            S.append(a)
    a = np.zeros(n); a[:2] = 1; S.append(a)
    for sgn in itertools.product([1, -1], repeat=min(n, 4)):
        a = np.zeros(n); a[:len(sgn)] = sgn; S.append(a)
    return S


def search(q, n, restarts):
    X, p = atoms(q, n)
    tau = np.sqrt(q * (1 - q))
    best, best_a = -1, None
    starts = structured_starts(n)
    for _ in range(restarts):
        a = rng.standard_normal(n)
        if rng.random() < 0.5:
            mask = rng.random(n) < rng.uniform(0.2, 1.0)
            if mask.sum() == 0:
                mask[0] = True
            a = a * mask
        if rng.random() < 0.3:
            a[0] += rng.uniform(1, 4) * np.linalg.norm(a)  # near-dictator perturbation
        starts.append(a)
    for a in starts:
        val, al = power_iter(a, X, p)
        if val > best:
            best, best_a = val, al
    return best / (2 * tau), best_a


if __name__ == '__main__':
    NMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 12
    qs = [0.30, 0.32, 0.34, 0.36, 0.37, 0.375, 0.38, 0.39, 0.40, 0.42, 0.44, 0.46, 0.48, 0.49, 0.5]
    t0 = time.time()
    print(f"max_n E|L|/(2tau) over unit alpha, n <= {NMAX} (1.000000 means no beat of the dictator)")
    print("two-equal-coefficient value sqrt(2)(1-q) shown for comparison")
    for q in qs:
        row = []
        overall, arg = 0, None
        for n in range(2, NMAX + 1):
            restarts = 400 if n <= 10 else 150
            r, a = search(q, n, restarts)
            row.append(r)
            if r > overall + 1e-12:
                overall, arg = r, (n, a)
        n_, a_ = arg
        top = np.sort(np.abs(a_))[::-1][:4]
        print(f"q={q:.3f}  max ratio={overall:.9f} (n={n_}, |alpha| top={np.round(top, 4)})  sqrt2(1-q)={np.sqrt(2)*(1-q):.6f}"
              f"  {'VIOLATION of E|L|<=2tau' if overall > 1 + 1e-9 else ''}")
        sys.stdout.flush()
    print(f"time {time.time()-t0:.1f}s")
