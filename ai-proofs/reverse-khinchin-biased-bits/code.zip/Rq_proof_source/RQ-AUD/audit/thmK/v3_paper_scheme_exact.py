"""RQ-AUD, audit of BF3 Theorem K, Method P: from-scratch exact-rational re-implementation of the
box scheme *as described in the text* of BF3 Section 9.4 ("Other values of q"), written without
access to khintchine_interval.py, plus exact checks of the three hand cases q = 3/8, 2/5, 5/12.

Only Python integers / fractions.Fraction are used for the proof steps (no floating point).
"""
from fractions import Fraction as F
from math import isqrt
import sys

OK = True


def check(name, cond):
    global OK
    OK &= bool(cond)
    print(f"[{'OK' if cond else 'FAIL'}] {name}")


def sqrt_lo(x, bits=64):
    """Rational r with 0 <= r <= sqrt(x)."""
    N = (x.numerator << (2 * bits)) // x.denominator
    r = F(isqrt(N), 1 << bits)
    assert r * r <= x
    return r


def sqrt_hi(x, bits=64):
    """Rational r with r >= sqrt(x)."""
    N = -((-x.numerator << (2 * bits)) // x.denominator)  # ceil
    m = isqrt(N)
    if m * m < N:
        m += 1
    r = F(m, 1 << bits)
    assert r * r >= x
    return r


def P(q, s):
    return (32 * (1 - q)**2 * (1 - 2 * q) * s**3 + 8 * q * (1 - q) * (1 - 8 * (1 - q)**2) * s**2
            + 8 * q * (1 - q) * (1 - 2 * q) * s + q**2)


def corner_ub(q1, q2, s1, s2):
    """BF3's upper bound for P on [q1,q2] x [s1,s2] (valid for [q1,q2] in [3/8,1/2], s1 >= 0)."""
    return (32 * (1 - q1)**2 * (1 - 2 * q1) * s2**3 - 8 * q1 * (1 - q1) * (8 * (1 - q2)**2 - 1) * s1**2
            + 8 * q2 * (1 - q2) * (1 - 2 * q1) * s2 + q2**2)


# --- the constant 79789/10^5 >= sqrt(2/pi):  needs pi >= 2/(79789/10^5)^2.
C0 = F(79789, 10**5)
pi_needed = 2 / C0**2
check(f"pi > 3.14159 implies sqrt(2/pi) < 79789/10^5   (needs pi > {float(pi_needed):.10f})",
      F(314159, 10**5) > pi_needed)
# pi > 3.14159: certify with a rigorous Arb enclosure (only place Arb is used in this file).
from flint import arb, ctx  # noqa: E402
ctx.prec = 100
check("pi > 314159/100000 (Arb enclosure of pi)", arb.pi() > arb(314159) / 100000)


def tau_lo(q):
    return sqrt_lo(q * (1 - q))


# ---------------------------------------------------------------- hand cases
print("\n== Hand cases q = 3/8, 2/5, 5/12 (exact) ==")
table = {
    F(3, 8): dict(tau2=F(15, 64), th=F(1, 4), ka=F(5, 12), kp=F(3, 20), aA=F(3, 10), aB=F(5, 7),
                  pq=(200, -255, 30, 9), sm=F(31, 100), sp=F(21, 20),
                  vals=(-476, 9, F(-2473, 10000), F(-729, 80), 649)),
    F(2, 5): dict(tau2=F(6, 25), th=F(1, 5), ka=F(3, 8), kp=F(1, 6), aA=F(1, 3), aB=F(3, 5),
                  pq=(360, -564, 60, 25), sm=F(7, 20), sp=F(1),
                  vals=(-959, 25, F(-1531, 200), -119, 769)),
    F(5, 12): dict(tau2=F(35, 144), th=F(1, 6), ka=F(7, 20), kp=F(5, 28), aA=F(7, 20), aB=F(7, 13),
                   pq=(2352, -4340, 420, 225), sm=F(9, 25), sp=F(1),
                   vals=(-6887, 225, F(-1195767, 15625), -1343, 2521)),
}
for q, T in table.items():
    th, ka, kp = 1 - 2 * q, (1 - q) / (4 * q), q / (4 * (1 - q))
    check(f"q={q}: tau^2, theta, kappa, kappa' as tabulated",
          (q * (1 - q), th, ka, kp) == (T['tau2'], T['th'], T['ka'], T['kp']))
    check(f"q={q}: a_B = kappa/(1-kappa) = {T['aB']}", ka / (1 - ka) == T['aB'] == (1 - q) / (5 * q - 1))
    cub = (2 * th, th**2 + 2 * kp - 1, 2 * th * kp, kp**2)
    lam = F(T['pq'][0]) / cub[0]
    from math import gcd
    g = 0
    for c in T['pq']:
        g = gcd(g, abs(c))
    check(f"q={q}: p_q = {lam} * cubic, coprime integer coefficients, positive multiple",
          lam > 0 and all(F(T['pq'][i]) == lam * cub[i] for i in range(4)) and g == 1)
    pq = lambda s, c=T['pq']: c[0] * s**3 + c[1] * s**2 + c[2] * s + c[3]
    vals = tuple(pq(F(x)) for x in (-1, 0, T['sm'], T['sp'], 2))
    check(f"q={q}: p_q(-1,0,s-,s+,2) = {tuple(str(x) for x in T['vals'])}", vals == tuple(F(x) for x in T['vals']))
    check(f"q={q}: sign pattern -,+,-,-,+  => roots in (-1,0),(0,s-),(s+,2); p_q<0 on [s-,s+]",
          vals[0] < 0 < vals[1] and vals[2] < 0 and vals[3] < 0 and vals[4] > 0)
    # s(a_A) >= s-  <=>  a_A^2/(1-a_A^2) >= s-^2 ;  s(a_B) <= s+  <=>  a_B^2/(1-a_B^2) <= s+^2
    sA2, sB2 = T['aA']**2 / (1 - T['aA']**2), T['aB']**2 / (1 - T['aB']**2)
    check(f"q={q}: [s(a_A), s(a_B)] in [s-, s+]   (s(a_A)^2={sA2}, s(a_B)^2={sB2})",
          sA2 >= T['sm']**2 and sB2 <= T['sp']**2)
    # (11): sqrt(2/pi) + a_A C_q <= 2 tau.  Rigorous: C0 + a_A (1-2tau^2)/(2 tau_lo) <= 2 tau_lo.
    tl = tau_lo(q)
    lhs = C0 + T['aA'] * (1 - 2 * q * (1 - q)) / (2 * tl)
    check(f"q={q}: (11) with a_A={T['aA']}: 79789e-5 + a_A C_q <= 2tau  (margin >= {float(2*tl - lhs):.5f})",
          lhs <= 2 * tl)
    # margin statement of Remark 9.8(a): 2tau - 0.7979 - a_A C_q >= 0.0049 (uses C_q upper bound)
    Cq_hi = (1 - 2 * q * (1 - q)) / (2 * tl)
    marg = 2 * tl - F(7979, 10**4) - T['aA'] * Cq_hi
    check(f"q={q}: Remark 9.8(a) Case A margin 2tau - 0.7979 - a_A C_q = {float(marg):.6f} >= 0.0049", marg >= F(49, 10**4))

# Displayed rounded numbers in the hand proof (Case A paragraph)
print("\n   displayed decimal bounds of the Case-A paragraph:")
for q, Cq_claim, Cq_ub, aCq_ub, lhs_ub, two_tau_lb in [
        (F(3, 8), "17/(8 sqrt15)", F(5487, 10**4), F(1647, 10**4), F(9626, 10**4), F(9682, 10**4)),
        (F(2, 5), "13/(10 sqrt6)", F(5308, 10**4), F(1770, 10**4), F(9749, 10**4), F(9797, 10**4)),
        (F(5, 12), "37/(12 sqrt35)", F(5212, 10**4), F(1825, 10**4), F(9804, 10**4), F(9860, 10**4))]:
    T = table[q]
    Cq2 = (1 - 2 * q * (1 - q))**2 / (4 * q * (1 - q))  # C_q^2 exactly
    check(f"q={q}: C_q = {Cq_claim} < {Cq_ub}", Cq2 < Cq_ub**2)
    check(f"q={q}: a_A C_q < {aCq_ub}", T['aA']**2 * Cq2 < aCq_ub**2)
    # sqrt(2/pi) < 0.7979 and a_A C_q < aCq_ub strictly, so their sum is < lhs_ub as soon as
    # 0.7979 + aCq_ub <= lhs_ub (equality holds for all three displayed values).
    check(f"q={q}: 0.7979 + {aCq_ub} <= {lhs_ub}", F(7979, 10**4) + aCq_ub <= lhs_ub)
    check(f"q={q}: 2tau > {two_tau_lb}", 4 * q * (1 - q) > two_tau_lb**2)
    check(f"q={q}: {lhs_ub} < {two_tau_lb}", lhs_ub < two_tau_lb)
check("sqrt(2/pi) < 0.7979 (pi > 3.14159 => 2/pi < 0.7979^2)", F(2 * 10**5, 314159) < F(7979, 10**4)**2)
# s-values displayed: s(3/10)=3/sqrt91>0.31, s(5/7)=5/sqrt24<1.05, s(1/3)=1/sqrt8>0.35, s(3/5)=3/4,
# s(7/20)=7/sqrt351>0.36, s(7/13)=7/sqrt120<1
for a_, val2, rel, bound in [(F(3, 10), F(9, 91), '>', F(31, 100)), (F(5, 7), F(25, 24), '<', F(105, 100)),
                             (F(1, 3), F(1, 8), '>', F(35, 100)), (F(3, 5), F(9, 16), '=', F(3, 4)),
                             (F(7, 20), F(49, 351), '>', F(36, 100)), (F(7, 13), F(49, 120), '<', F(1))]:
    s2 = a_**2 / (1 - a_**2)
    cond = (s2 == val2) and ((rel == '>' and s2 > bound**2) or (rel == '<' and s2 < bound**2) or (rel == '=' and s2 == bound**2))
    check(f"s({a_})^2 = {val2}, s({a_}) {rel} {bound}", cond)

# psi margins quoted in Remark 9.8(a): max psi over [a_A,a_B] below 0.9935, 0.9664, 0.9539.
# Exact check: psi(a) <= M  <=>  s + kappa'/s + theta <= M sqrt(1+s^2)   (s = a/b);
# with LHS > 0 this is (s + theta + kappa'/s)^2 <= M^2 (1+s^2), i.e. a cubic inequality in s.
print("\n   psi margins of Remark 9.8(a) (exact Sturm check of the cubic on [s(a_A), s(a_B)]):")
import sympy as sp  # noqa: E402
S = sp.symbols('s')
for q, Mb in [(F(3, 8), F(9935, 10**4)), (F(2, 5), F(9664, 10**4)), (F(5, 12), F(9539, 10**4))]:
    T = table[q]
    th, kp = sp.Rational(1 - 2 * q), sp.Rational(kp_ := q / (4 * (1 - q)))
    M = sp.Rational(Mb)
    poly = sp.Poly(sp.expand(S**2 * ((S + th + kp / S)**2 - M**2 * (1 + S**2))), S)
    lo2, hi2 = sp.Rational(T['aA']**2 / (1 - T['aA']**2)), sp.Rational(T['aB']**2 / (1 - T['aB']**2))
    # interval [sqrt(lo2), sqrt(hi2)] is enclosed by rational [l, h] with l <= sqrt(lo2), h >= sqrt(hi2)
    l = sp.Rational(sqrt_lo(F(int(lo2.p), int(lo2.q)), 40))
    h = sp.Rational(sqrt_hi(F(int(hi2.p), int(hi2.q)), 40))
    nroots = sp.Poly(poly).count_roots(l, h)
    neg = poly.eval(l) < 0 and poly.eval(h) < 0 and nroots == 0
    check(f"q={q}: max psi on [a_A, a_B] < {Mb}", neg)

# ---------------------------------------------------------------- general q: the paper's scheme
print("\n== General q in [3/8,1/2]: BF3 scheme re-implemented (64 intervals, a_A in 10^-4 Z) ==")


def best_aA(tau0):
    # largest multiple of 1e-4 with C0 + aA (1-2tau0^2)/(2tau0) <= 2tau0
    amax = (2 * tau0 - C0) * 2 * tau0 / (1 - 2 * tau0**2)
    k = (amax * 10**4).numerator // (amax * 10**4).denominator
    aA = F(k, 10**4)
    assert C0 + aA * (1 - 2 * tau0**2) / (2 * tau0) <= 2 * tau0
    assert not (C0 + (aA + F(1, 10**4)) * (1 - 2 * tau0**2) / (2 * tau0) <= 2 * tau0)
    return aA


def bisect(q1, q2, s1, s2, depth, mode, stats):
    ub = corner_ub(q1, q2, s1, s2)
    if ub < 0:
        stats['boxes'] += 1
        stats['maxdepth'] = max(stats['maxdepth'], depth)
        return True
    if depth >= 30:
        return False
    qm, sm = (q1 + q2) / 2, (s1 + s2) / 2
    if mode == 'quad':
        parts = [(q1, qm, s1, sm), (q1, qm, sm, s2), (qm, q2, s1, sm), (qm, q2, sm, s2)]
    elif mode == 's-only':
        parts = [(q1, q2, s1, sm), (q1, q2, sm, s2)]
    else:  # alternate: bisect s at even depth, q at odd depth
        parts = [(q1, q2, s1, sm), (q1, q2, sm, s2)] if depth % 2 == 0 else [(q1, qm, s1, s2), (qm, q2, s1, s2)]
    return all(bisect(*p, depth + 1, mode, stats) for p in parts)


rows = []
for j in range(64):
    q0, q1 = F(3, 8) + F(j, 512), F(3, 8) + F(j + 1, 512)
    t0 = tau_lo(q0)
    aA = best_aA(t0)
    aB0 = (1 - q0) / (5 * q0 - 1)
    rows.append((j, q0, q1, aA, aB0))

check("a_A = 194/625 for j = 0", rows[0][3] == F(194, 625))
check("a_A = 4041/10^4 for j = 63", rows[63][3] == F(4041, 10**4))
empty = [r[0] for r in rows if r[3] >= r[4]]
check(f"Case C empty (a_A >= a_B(q0)) exactly for j >= 48  (found j in {empty[0]}..{empty[-1]}, count {len(empty)})",
      empty == list(range(48, 64)))
check("q0 = 15/32 at j = 48", rows[48][1] == F(15, 32))

for mode in ['quad', 's-only', 'alternate']:
    stats = {'boxes': 0, 'maxdepth': 0}
    allok = True
    for (j, q0, q1, aA, aB0) in rows:
        if aA >= aB0:
            continue
        s_lo = sqrt_lo(aA**2 / (1 - aA**2), 40)
        s_hi = sqrt_hi(aB0**2 / (1 - aB0**2), 40)
        allok &= bisect(q0, q1, s_lo, s_hi, 0, mode, stats)
    check(f"bisection mode '{mode}': P < 0 certified on all 48 boxes; leaves = {stats['boxes']}, max depth = {stats['maxdepth']}", allok)

# A direct check that the paper's argument (with these a_A) also holds pointwise at the j-grid:
worst = None
for (j, q0, q1, aA, aB0) in rows:
    if aA >= aB0:
        continue
    for q in (q0, q1):
        for s2 in (aA**2 / (1 - aA**2), ((1 - q) / (5 * q - 1))**2 / (1 - ((1 - q) / (5 * q - 1))**2)):
            sv = sqrt_hi(s2, 50)  # any point near the endpoint; informative only
            val = P(q, sv)
            worst = val if worst is None or val > worst else worst
print(f"   (informative) largest P at grid endpoints: {float(worst):.6f}")

print("\nALL CHECKS OK" if OK else "\nSOME CHECK FAILED")
sys.exit(0 if OK else 1)
