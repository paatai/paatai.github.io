"""RQ-AUD, audit of BF3 Theorem K: symbolic re-derivation of every identity in Section 9.4.

Independent of the BF3 scripts.  Everything is checked with sympy as an exact identity
(simplify(lhs - rhs) == 0) or an exact sign statement.  Run: python3 v1_identities.py
"""
import sympy as sp

y, a, b, s, w, t, V, vv = sp.symbols('y a b s w t V v', positive=True)
ok = True
# Rational parametrisation: v = sqrt(q/(1-q)) > 0, so q = v^2/(1+v^2), 1-q = 1/(1+v^2),
# u = 1/v, tau = sqrt(q(1-q)) = v/(1+v^2).  Then every identity below is an identity of
# rational functions in v (no branch issues), and q ranges over (0,1) as v ranges over (0,oo).
q = vv**2 / (1 + vv**2)


def check(name, expr_zero):
    global ok
    z = sp.simplify(sp.together(sp.expand(expr_zero)))
    good = (z == 0)
    ok &= good
    print(f"[{'OK' if good else 'FAIL'}] {name}" + ("" if good else f"   residual={z}"))


u = 1 / vv
v = vv
tau = vv / (1 + vv**2)
check("parametrisation: u^2 = (1-q)/q", u**2 - (1 - q) / q)
check("parametrisation: v^2 = q/(1-q)", v**2 - q / (1 - q))
check("parametrisation: tau^2 = q(1-q)", tau**2 - q * (1 - q))
theta = 1 - 2 * q
kap = (1 - q) / (4 * q)
kapp = q / (4 * (1 - q))

# Basic identities (stated after the definitions in 9.4)
check("E chi = q u - (1-q) v = 0", q * u - (1 - q) * v)
check("E chi^2 = q u^2 + (1-q) v^2 = 1", q * u**2 + (1 - q) * v**2 - 1)
check("q u = tau", q * u - tau)
check("(1-q) v = tau", (1 - q) * v - tau)
check("tau v = q", tau * v - q)
check("tau u = 1-q", tau * u - (1 - q))
check("u + v = 1/tau", u + v - 1 / tau)
check("E|chi| = q u + (1-q) v = 2 tau", q * u + (1 - q) * v - 2 * tau)
check("4 kappa' tau^2 = q^2", 4 * kapp * tau**2 - q**2)
check("a_B = kappa/(1-kappa) = (1-q)/(5q-1)", kap / (1 - kap) - (1 - q) / (5 * q - 1))
check("C_q = (q^2+(1-q)^2)/(2 tau) = (1-2tau^2)/(2tau)",
      (q**2 + (1 - q)**2) / (2 * tau) - (1 - 2 * tau**2) / (2 * tau))
check("C_q = 1/(2tau) - tau", (1 - 2 * tau**2) / (2 * tau) - (1 / (2 * tau) - tau))

# Lemma 9.4: pointwise identity E_chi|a chi + y| = 2 tau a + (2q-1) y + 2 R_a(y),
# checked on each of the three regions where the absolute values/positive parts are linear.
# Region I: y > a v  (then a u + y > 0, y - a v > 0): R_a = (1-q)(y - a v)
lhs = q * (a * u + y) + (1 - q) * (y - a * v)
rhs = 2 * tau * a + (2 * q - 1) * y + 2 * (1 - q) * (y - a * v)
check("Lemma 9.4 region y > a v", lhs - rhs)
# Region II: -a u <= y <= a v: R_a = 0
lhs = q * (a * u + y) + (1 - q) * (a * v - y)
rhs = 2 * tau * a + (2 * q - 1) * y
check("Lemma 9.4 region -a u <= y <= a v", lhs - rhs)
# Region III: y < -a u: R_a = q(-y - a u)
lhs = q * (-(a * u + y)) + (1 - q) * (a * v - y)
rhs = 2 * tau * a + (2 * q - 1) * y + 2 * q * (-y - a * u)
check("Lemma 9.4 region y < -a u", lhs - rhs)

# Lemma 9.5 (Mills ratio): derivative computations.
x = sp.symbols('x', positive=True)
gauss_tail = sp.Integral(sp.exp(-x**2 / 2), (x, w, sp.oo))
A = gauss_tail - w / (1 + w**2) * sp.exp(-w**2 / 2)
B = (w**2 + 2) / (w**3 + 3 * w) * sp.exp(-w**2 / 2) - gauss_tail
check("A'(w) = -2 e^{-w^2/2}/(1+w^2)^2", sp.diff(A, w) + 2 * sp.exp(-w**2 / 2) / (1 + w**2)**2)
check("B'(w) = -6 e^{-w^2/2}/(w^2 (w^2+3)^2)",
      sp.diff(B, w) + 6 * sp.exp(-w**2 / 2) / (w**2 * (w**2 + 3)**2))
print("     (A, B -> 0 as w -> oo is immediate: every term is O(e^{-w^2/2}/w).)")

# Lemma 9.6 (Stein function): with m' = w m - 1 treat m as a symbol obeying this ODE.
m = sp.Function('m')
mw = m(w)
dm = w * mw - 1
f = sp.sqrt(2 / sp.pi) * mw - 1
fp = sp.sqrt(2 / sp.pi) * dm
check("Stein eq. f' - w f = w - sqrt(2/pi) for w > 0", fp - w * f - (w - sp.sqrt(2 / sp.pi)))
fpp = sp.sqrt(2 / sp.pi) * (dm + w * dm.subs(mw, mw))  # d/dw (w m - 1) = m + w m'
fpp = sp.sqrt(2 / sp.pi) * (mw + w * dm)
check("f'' = sqrt(2/pi) k, k = (1+w^2) m - w", fpp - sp.sqrt(2 / sp.pi) * ((1 + w**2) * mw - w))
k = (1 + w**2) * mw - w
dk = sp.diff(k, w).subs(sp.Derivative(mw, w), dm)
check("k' = (w^3+3w) m - (w^2+2)", dk - ((w**3 + 3 * w) * mw - (w**2 + 2)))
check("upper Mills bound <=> w m < (w^2+2)/(w^2+3) < 1: (w^2+2)/(w^3+3w)*w = (w^2+2)/(w^2+3)",
      (w**2 + 2) / (w**3 + 3 * w) * w - (w**2 + 2) / (w**2 + 3))
print("     m(0) = sqrt(pi/2) => f(0) = 0, f'(0+) = -sqrt(2/pi), f''(0+) = sqrt(2/pi) k(0) = 1.")
check("sqrt(2/pi)*sqrt(pi/2) = 1", sp.sqrt(2 / sp.pi) * sp.sqrt(sp.pi / 2) - 1)

# Lemma 9.7 (zero-bias): (i) E[chi G(alpha chi)] = tau (G(alpha u) - G(-alpha v)) and density of
# U on [-v,u] is 1/(u+v) = tau.  (ii) coupling cost.
check("q u G1 - (1-q) v G2 = tau (G1 - G2)  [coefficients]", q * u - tau)
check("density of U = 1/(u+v) = tau", 1 / (u + v) - tau)
cost = sp.integrate(V / tau, (V, 0, 1 - q)) + sp.integrate((1 - V) / tau, (V, 1 - q, 1))
check("coupling: E|chi - U| = ((1-q)^2+q^2)/(2 tau)", cost - ((1 - q)**2 + q**2) / (2 * tau))
# The coupling: U = -v + V/tau; V<1-q -> chi=-v, so |chi-U| = V/tau; V>=1-q -> chi=u,
# |chi - U| = |u + v - V/tau| = (1-V)/tau.
check("u + v - V/tau = (1 - V)/tau", u + v - V / tau - (1 - V) / tau)

# Case B
check("(y-t)_+ bound: y^2/(4t) - (y-t) = (y-2t)^2/(4t)", y**2 / (4 * t) - (y - t) - (y - 2 * t)**2 / (4 * t))
check("(1-q)/(4 a v) = kappa tau / a", (1 - q) / (4 * a * v) - kap * tau / a)
check("q/(4 a u) = kappa' tau / a", q / (4 * a * u) - kapp * tau / a)
check("kappa - kappa' = (1-2q)/(4q(1-q))", kap - kapp - (1 - 2 * q) / (4 * q * (1 - q)))
check("a + kappa(1-a^2)/a = 1 + (a-1)((1-kappa)a - kappa)/a",
      a + kap * (1 - a**2) / a - (1 + (a - 1) * ((1 - kap) * a - kap) / a))
check("kappa < 1 <=> q > 1/5:  1 - kappa = (5q-1)/(4q)", 1 - kap - (5 * q - 1) / (4 * q))

# Case C, inequality (12): c = kappa' tau / a.
c = kapp * tau / a
check("4 c a tau = q^2", 4 * c * a * tau - q**2)
right = c * y**2 - q * y + a * tau
check("y > av: c y^2 + theta y - (1-q)(y - a v) = c y^2 - q y + a tau",
      c * y**2 + theta * y - (1 - q) * (y - a * v) - right)
check("   ... = c (y - q/(2c))^2  (zero discriminant)", right - c * (y - q / (2 * c))**2)
left = c * y**2 + q * y + a * tau
check("y < -au: c y^2 - q(-y - a u) = c y^2 + q y + a tau", c * y**2 - q * (-y - a * u) - left)
check("   ... = c (y + q/(2c))^2", left - c * (y + q / (2 * c))**2)

# psi(a) and the polynomial P(q,s)
bb = sp.sqrt(1 - a**2)
psi = a + kapp * (1 - a**2) / a + theta * bb
check("2 tau a + 2 c b^2 + 2 theta b tau = 2 tau psi(a)",
      2 * tau * a + 2 * c * (1 - a**2) + 2 * theta * bb * tau - 2 * tau * psi)
# s = a/b, so a = s/sqrt(1+s^2), b = 1/sqrt(1+s^2).
a_s = s / sp.sqrt(1 + s**2)
b_s = 1 / sp.sqrt(1 + s**2)
check("psi(a)/b = s + kappa'/s + theta  and 1/b = sqrt(1+s^2)",
      (a_s + kapp * b_s**2 / a_s + theta * b_s) / b_s - (s + kapp / s + theta))
cub = 2 * theta * s**3 + (theta**2 + 2 * kapp - 1) * s**2 + 2 * theta * kapp * s + kapp**2
check("s^2[(s+theta+kappa'/s)^2 - (1+s^2)] = 2 theta s^3 + (theta^2+2kappa'-1)s^2 + 2theta kappa' s + kappa'^2",
      s**2 * ((s + theta + kapp / s)**2 - (1 + s**2)) - cub)
P = (32 * (1 - q)**2 * (1 - 2 * q) * s**3 + 8 * q * (1 - q) * (1 - 8 * (1 - q)**2) * s**2
     + 8 * q * (1 - q) * (1 - 2 * q) * s + q**2)
check("16(1-q)^2 * cubic = P(q,s)  (eq. (13))", 16 * (1 - q)**2 * cub - P)

# The coefficients of P on [3/8,1/2]: signs and monotonicity used for the box bound.
c3 = 32 * (1 - q)**2 * (1 - 2 * q)
c2 = 8 * q * (1 - q) * (1 - 8 * (1 - q)**2)
c1 = 8 * q * (1 - q) * (1 - 2 * q)
check("P = c3 s^3 + c2 s^2 + c1 s + q^2", P - (c3 * s**3 + c2 * s**2 + c1 * s + q**2))
print("     sign facts on [3/8,1/2] (exact, by hand): 1-2q in [0,1/4], 8(1-q)^2-1 in [1, 17/8] => c2 <= -8q(1-q) < 0;")
print("     q(1-q) increasing, 1-2q and 8(1-q)^2-1 decreasing in q => corner bound of the paper is valid.")

# The level-one equivalence: for f = 1{x1 = 1}: fhat({1}) = E[f chi] = q u = tau.
check("fhat({1}) for f = 1{x1=1}: q u = tau", q * u - tau)

# s(a_B)^2 in closed form (used by my endpoint method):  s(a)^2 = a^2/(1-a^2)
aB = (1 - q) / (5 * q - 1)
check("s(a_B)^2 = (1-q)^2 / (8 q (3q-1))", aB**2 / (1 - aB**2) - (1 - q)**2 / (8 * q * (3 * q - 1)))

print()
print("ALL IDENTITIES OK" if ok else "SOME IDENTITY FAILED")
