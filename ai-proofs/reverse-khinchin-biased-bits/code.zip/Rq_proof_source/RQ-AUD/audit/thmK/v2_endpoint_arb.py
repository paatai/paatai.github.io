"""RQ-AUD, audit of BF3 Theorem K, Method S (independent of the BF3 scripts and of the BF3
box scheme): certified ball arithmetic (Arb via python-flint), endpoint reduction.

Facts used (proved in AUDIT.md, A.0):
 (F1) For fixed q in (0,1/2], {s > 0 : P(q,s) <= 0} is an interval.  [q < 1/2: P is a cubic with
      leading coefficient > 0, P(q,0) = q^2 > 0, so it has exactly one negative root; three sign
      changes on (0,oo) would give four roots.  q = 1/2: P = 1/4 - 2 s^2.]
 (F2) With the optimal Case-A threshold a*(q) = (2 tau - sqrt(2/pi)) / C_q, Case A covers
      a <= a*(q) (equality in (11) is allowed), Case B covers a >= a_B(q), and Case C needs
      P(q, s) <= 0 for s(a*) < s < s(a_B).  By (F1) it suffices that
      P(q, s(a*(q))) <= 0 and P(q, s(a_B(q))) <= 0, OR that Case C is empty: a*(q) >= a_B(q).
 Here s(a) = a / sqrt(1-a^2) and s(a_B)^2 = (1-q)^2 / (8 q (3q-1)).

The script covers [3/8, 1/2] by an adaptive bisection into q-intervals Q and certifies, on each
Q, either  min(a* - a_B) > 0  or  max P(q, s(a*(q))) < 0 and max P(q, s(a_B(q))) < 0,
with all quantities enclosed by Arb balls over the whole interval Q (interval extension).
"""
from flint import arb, fmpq, ctx
import sys

ctx.prec = 200


def interval(lo, hi):
    return arb(lo).union(arb(hi))


def P(q, s):
    return (32 * (1 - q)**2 * (1 - 2 * q) * s**3 + 8 * q * (1 - q) * (1 - 8 * (1 - q)**2) * s**2
            + 8 * q * (1 - q) * (1 - 2 * q) * s + q**2)


SQ2PI = (arb(2) / arb.pi()).sqrt()


def quantities(Q):
    tau = (Q * (1 - Q)).sqrt()
    C = (1 - 2 * tau**2) / (2 * tau)
    astar = (2 * tau - SQ2PI) / C
    aB = (1 - Q) / (5 * Q - 1)
    sA = astar / (1 - astar**2).sqrt()
    sB = (1 - Q) / (8 * Q * (3 * Q - 1)).sqrt()
    return tau, C, astar, aB, sA, sB


def certify(lo, hi, depth, log, stats):
    Q = interval(lo, hi)
    tau, C, astar, aB, sA, sB = quantities(Q)
    if (astar - aB) > 0:
        stats['empty'] += 1
        log.append((lo, hi, depth, 'CaseC-empty', (astar - aB).lower()))
        return True
    pA, pB = P(Q, sA), P(Q, sB)
    if pA < 0 and pB < 0:
        stats['endpoints'] += 1
        log.append((lo, hi, depth, 'P(sA)<0,P(sB)<0', max(pA.upper(), pB.upper())))
        return True
    if depth > 40:
        log.append((lo, hi, depth, 'FAILED', None))
        return False
    mid = (lo + hi) / 2
    return certify(lo, mid, depth + 1, log, stats) and certify(mid, hi, depth + 1, log, stats)


def main(lo, hi, n0):
    stats = {'empty': 0, 'endpoints': 0}
    log = []
    okall = True
    for j in range(n0):
        a = lo + (hi - lo) * fmpq(j, n0)
        b = lo + (hi - lo) * fmpq(j + 1, n0)
        okall &= certify(a, b, 0, log, stats)
    return okall, stats, log


if __name__ == '__main__':
    lo, hi = fmpq(3, 8), fmpq(1, 2)
    ok, stats, log = main(lo, hi, 64)
    print(f"Method S (Arb, prec={ctx.prec} bits): q in [{lo}, {hi}]")
    print(f"sqrt(2/pi) enclosure: {SQ2PI}")
    print(f"intervals certified: {len(log)}  (Case C empty: {stats['empty']},"
          f" endpoint inequalities: {stats['endpoints']}),  max depth {max(r[2] for r in log)}")
    worst_end = max((r for r in log if r[3].startswith('P')), key=lambda r: r[4])
    worst_empty = min((r for r in log if r[3].startswith('CaseC')), key=lambda r: r[4])
    print(f"worst endpoint margin: max P <= {worst_end[4]} on q in [{float(worst_end[0]):.8f}, {float(worst_end[1]):.8f}]")
    print(f"worst Case-C-empty margin: a* - a_B >= {worst_empty[4]} on q in [{float(worst_empty[0]):.8f}, {float(worst_empty[1]):.8f}]")
    switch = [r for r in log if r[3].startswith('CaseC')]
    print(f"Case C certified empty from q = {float(min(r[0] for r in switch)):.8f} on")
    print("RESULT:", "CERTIFIED" if ok else "FAILED")
    with open('outputs/v2_endpoint_arb_intervals.txt', 'w') as fh:
        for r in log:
            fh.write(f"[{r[0]}, {r[1]}] depth={r[2]} {r[3]} bound={r[4]}\n")
    # Sanity: the same machinery must FAIL just below 3/8 (Remark 9.8(b) of BF3: q <= 0.37).
    ok2, _, log2 = main(fmpq(36, 100), fmpq(37, 100), 4)
    bad = [r for r in log2 if r[3] == 'FAILED']
    print(f"control run on [0.36, 0.37] (expected to fail): {'fails as expected' if not ok2 else 'UNEXPECTEDLY CERTIFIED'}"
          f" (first failing q-interval [{float(bad[0][0]):.6f}, {float(bad[0][1]):.6f}])" if bad else "")
    sys.exit(0 if ok else 1)
