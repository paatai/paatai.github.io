"""RQ-AUD: where exactly does the BF3 Case A/B/C method (with the optimal Case-A threshold a*(q))
stop working below q = 3/8?  Floating/mpmath root finding: informative, not a proof."""
import mpmath as mp
mp.mp.dps = 30
def P(q, s):
    return (32*(1-q)**2*(1-2*q)*s**3 + 8*q*(1-q)*(1-8*(1-q)**2)*s**2 + 8*q*(1-q)*(1-2*q)*s + q**2)
def ends(q):
    tau = mp.sqrt(q*(1-q)); C = (1-2*tau**2)/(2*tau)
    a = (2*tau - mp.sqrt(2/mp.pi))/C; aB = (1-q)/(5*q-1)
    return a, aB, a/mp.sqrt(1-a**2), (1-q)/mp.sqrt(8*q*(3*q-1))
qA = mp.findroot(lambda q: P(q, ends(q)[2]), 0.363)
qB = mp.findroot(lambda q: P(q, ends(q)[3]), (0.371, 0.372), solver="bisect")
print(f"lower end (Case A/C interface, s = s(a*)): P(q, s(a*(q))) = 0 at q = {mp.nstr(qA, 12)}; a*(q) = {mp.nstr(ends(qA)[0], 8)}")
print(f"upper end (Case C/B interface, s = s(a_B)): P(q, s(a_B(q))) = 0 at q = {mp.nstr(qB, 12)}; a_B(q) = {mp.nstr(ends(qB)[1], 8)}")
print(f"=> the BF3 method with optimal threshold works exactly for q >= {mp.nstr(max(qA, qB), 10)} (bracketed roots), the binding constraint being the {'upper' if qB > qA else 'lower'} end")
for q in [0.36, 0.365, 0.37, 0.371, 0.372, 0.373, 0.375]:
    q = mp.mpf(q); a, aB, sA, sB = ends(q)
    print(f"  q={mp.nstr(q,4)}: a*={mp.nstr(a,6)}, a_B={mp.nstr(aB,6)}, P(s(a*))={mp.nstr(P(q,sA),5)}, P(s(a_B))={mp.nstr(P(q,sB),5)}")
