"""RQ-AUD: randomized attacks on the auxiliary facts used by the two certificates, plus an exact
check of the equal-coefficient formula quoted in Ivanisvili-Stone (arXiv:2407.04835, (1.10)).
Evidence/sanity only for (1)-(3); (4) is exact.
"""
from fractions import Fraction as F
import numpy as np
import mpmath as mp
from math import comb

rng = np.random.default_rng(7)


def P(q, s):
    return (32 * (1 - q)**2 * (1 - 2 * q) * s**3 + 8 * q * (1 - q) * (1 - 8 * (1 - q)**2) * s**2
            + 8 * q * (1 - q) * (1 - 2 * q) * s + q**2)


def corner_ub(q1, q2, s1, s2):
    return (32 * (1 - q1)**2 * (1 - 2 * q1) * s2**3 - 8 * q1 * (1 - q1) * (8 * (1 - q2)**2 - 1) * s1**2
            + 8 * q2 * (1 - q2) * (1 - 2 * q1) * s2 + q2**2)


# (1) BF3 corner bound >= P on random boxes in [3/8,1/2] x [0,3]
worst = np.inf
for _ in range(200000):
    q1, q2 = np.sort(rng.uniform(3 / 8, 1 / 2, 2))
    s1, s2 = np.sort(rng.uniform(0, 3, 2))
    q, s = rng.uniform(q1, q2), rng.uniform(s1, s2)
    worst = min(worst, corner_ub(q1, q2, s1, s2) - P(q, s))
print(f"(1) corner bound - P, min over 2e5 random (box, point): {worst:.3e}  ({'OK' if worst >= -1e-12 else 'VIOLATED'})")

# (2) interval property: for q in (0,1/2], sign pattern of P(q,.) on a fine s-grid in (0,50]
bad = 0
for q in np.concatenate([rng.uniform(0.01, 0.5, 3000), [0.5, 3 / 8]]):
    ss = np.linspace(1e-6, 50, 200001)
    neg = P(q, ss) <= 0
    changes = np.count_nonzero(neg[1:] != neg[:-1])
    if changes > 2:
        bad += 1
print(f"(2) interval property of {{s>0: P(q,s)<=0}}: violations on 3002 q's: {bad}")

# (3) Stein solution of Lemma 9.6 (mpmath, 40 digits): f' - w f = |w| - sqrt(2/pi), 0 < f'' < 1 on w>0
mp.mp.dps = 40
m = lambda w: mp.e**(w**2 / 2) * mp.quad(lambda x: mp.e**(-x**2 / 2), [w, mp.inf])
f = lambda w: mp.sqrt(2 / mp.pi) * m(w) - 1
fp = lambda w: mp.sqrt(2 / mp.pi) * (w * m(w) - 1)
fpp = lambda w: mp.sqrt(2 / mp.pi) * ((1 + w**2) * m(w) - w)
mx_res, mn_fpp, mx_fpp = 0, 1, 0
for w in [mp.mpf(k) / 20 for k in range(1, 200)]:
    mx_res = max(mx_res, abs(fp(w) - w * f(w) - (w - mp.sqrt(2 / mp.pi))))
    mn_fpp, mx_fpp = min(mn_fpp, fpp(w)), max(mx_fpp, fpp(w))
print(f"(3) Stein eq. residual max {mp.nstr(mx_res, 3)}; f'' range on (0,10): [{mp.nstr(mn_fpp, 6)}, {mp.nstr(mx_fpp, 6)}] (must be in (0,1))")


# (4) equal-coefficient sums (exact):  X = sum_{j<=N} xi_j,  E|X| / sqrt(N)
def E_abs_equal(p, N):
    # xi = u w.p. p, -v w.p. 1-p;  X = K u - (N-K) v = (K - N p)/tau  (u+v = 1/tau, v tau = p)
    # so E|X| * tau = sum_K C(N,K) p^K (1-p)^(N-K) |K - N p|   (exact rational)
    return sum(comb(N, K) * p**K * (1 - p)**(N - K) * abs(K - N * p) for K in range(N + 1))


print("(4) equal-coefficient sums, exact:  tau*E|X| vs  N p (1-p)^N  (the closed form when N p < 1)")
for p, N in [(F(1, 10), 5), (F(1, 5), 2), (F(1, 4), 2), (F(3, 10), 1), (F(1, 20), 10)]:
    lhs = E_abs_equal(p, N)
    rhs = 2 * N * p * (1 - p)**N
    pm = mp.mpf(p.numerator) / p.denominator
    exact_ratio = (mp.mpf(lhs.numerator) / lhs.denominator) / mp.sqrt(pm * (1 - pm)) / mp.sqrt(N)
    print(f"    p={p}, N={N}: tau E|X| == 2 N p (1-p)^N exactly: {lhs == rhs};"
          f" E|X|/sqrt(N) exact {float(exact_ratio):.6f}; 2 sqrt(Np)(1-p)^(N-1/2) = {float(2*mp.sqrt(N*pm)*(1-pm)**(N-0.5)):.6f};"
          f" Iv-S (1.10) as printed, exponent N-1: {float(2*mp.sqrt(N*pm)*(1-pm)**(N-1)):.6f}")
