"""RQ-AUD check of the PROVED parts of RQ-A MAIN-5 (MAIN_RESULT_K4.tex, Lemmas lem:or, lem:three, lem:four).
Own code only.  The Delta polynomials are computed by a vectorised integer computation over all truth tables (a
different route from a18's counting key), and positivity is proved twice (Arb root isolation; own Sturm sequences).

 B  bit lemmas, n = 3 (256 f) and n = 4 (65,536 f): H_f(q) = 16 (1-q)^6 - sum_i Delta_i(f)^2,
    Delta_i(f) = E[f | x_i = 1] - E[f | x_i = 0], on [q5, q4] = [1 - 2/sqrt5, 1 - sqrt3/2]:
    - H_f >= 0 there; H_f == 0 exactly for +-OR_[4] (n = 4) and for no f (n = 3);
    - H_f(q4) = 0 (i.e. g4 = 4q^2 - 8q + 1 divides H_f, g4 irreducible) exactly for +-OR_[3] (n = 3) and the eight
      +-OR_S, |S| = 3 (n = 4), and these are > 0 on [q5, q4);
    - every other H_f is > 0 on [q5, q4]; no H_f vanishes at q5 (g5 = 5q^2 - 10q + 1 divides none);
    - the numbers of distinct H_f (39 and 1630), and Delta(OR_S) = 2 (1-q)^(|S|-1) on S.
 O  OR-region identity: for c_i > 0 and c_i > q sum c, E|c . chi| = 2 tau (1-q)^(n-1) sum c; checked exactly at
    rational u (then q, tau, v are rational) for n = 1..7 against full enumeration; plus the converse failure
    outside the region, and T5 <= T4 iff q >= q5.
"""
import os
import sys
import time
from fractions import Fraction as Fr
from math import comb

import numpy as np
from flint import fmpq_poly

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqb'))
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo  # noqa: E402
from a19_c17_verify import sturm_positive  # noqa: E402


def delta_coeffs(n):
    """integer coefficient arrays (monomial basis in q, low -> high) of Delta_i(f) for all f: {0,1}^n -> {-1,1};
    f is indexed by its truth table bits (bit x of the index = [f(x) = 1]), x = sum_l x_l 2^l."""
    N = 1 << n
    nf = 1 << N
    idx = np.arange(nf, dtype=np.int64)
    F = np.where(((idx[:, None] >> np.arange(N)[None, :]) & 1) == 1, 1, -1).astype(np.int64)
    out = []
    for i in range(n):
        xs = [x for x in range(N) if (x >> i) & 1]
        W = np.zeros((len(xs), n), dtype=np.int64)
        for r, x in enumerate(xs):
            k = bin(x).count('1') - 1
            m = n - 1 - k
            for j in range(m + 1):
                W[r, k + j] += comb(m, j) * (-1) ** j
        D = F[:, xs] - F[:, [x ^ (1 << i) for x in xs]]
        out.append(D @ W)
    return F, out


def H_coeffs(n):
    F, deltas = delta_coeffs(n)
    nf = F.shape[0]
    H = np.zeros((nf, 7), dtype=np.int64)
    for j in range(7):
        H[:, j] = 16 * comb(6, j) * (-1) ** j
    for d in deltas:
        for a in range(n):
            for b in range(n):
                H[:, a + b] -= d[:, a] * d[:, b]
    return F, deltas, H


def or_table(n, S, sign):
    N = 1 << n
    return tuple(sign * (1 if any((x >> i) & 1 for i in S) else -1) for x in range(N))


def part_B():
    t0 = time.time()
    ok = True
    g4 = fmpq_poly([1, -8, 4])
    g5 = fmpq_poly([1, -10, 5])
    assert g4.factor()[1] == [(g4 / 4, 1)] or len(g4.factor()[1]) == 1
    q5lo = 1 - sqrt_hi(Fr(4, 5))
    q4hi = 1 - sqrt_lo(Fr(3, 4))
    q4lo = 1 - sqrt_hi(Fr(3, 4))
    assert q5lo < q4lo
    for n, n_expected in ((3, 39), (4, 1630)):
        F, deltas, H = H_coeffs(n)
        uniq, inv = np.unique(H, axis=0, return_inverse=True)
        inv = np.ravel(inv)
        tables = [tuple(int(v) for v in row) for row in F]
        zero_f, g4_f, bad, bad_sturm, g5_div = [], [], 0, 0, 0
        cls = {}
        mult = {}
        qgrid = np.linspace(float(q5lo), float(q4hi), 4001)
        margin_plain, margin_cof = float('inf'), float('inf')
        for u_i, row in enumerate(uniq):
            coeffs = [int(v) for v in row]
            members = np.nonzero(inv == u_i)[0]
            if not any(coeffs):
                zero_f += [tables[m] for m in members]
                cls[u_i] = 'zero'
                continue
            P = fmpq_poly(coeffs)
            m4 = 0
            while P.degree() >= 2:
                qq, rr = divmod(P, g4)
                if rr == 0:
                    P, m4 = qq, m4 + 1
                else:
                    break
            if divmod(fmpq_poly(coeffs), g5)[1] == 0:
                g5_div += 1
            Q = [Fr(int(c.p), int(c.q)) for c in P.coeffs()]
            # g4 > 0 on [0, q4) and g4(q4) = 0, so H = g4^m4 Q >= 0 on [q5, q4] iff Q > 0 there; we prove Q > 0 on
            # the slightly larger [q5lo, q4hi] (and, when m4 = 0, this already gives H > 0 on [q5, q4])
            a_ok = positive_on(Q, q5lo, q4hi)[0]
            s_ok = sturm_positive(Q, q5lo, q4hi)
            bad += not a_ok
            bad_sturm += not s_ok
            if m4:
                g4_f += [tables[m] for m in members]
            cls[u_i] = f'g4^{m4}'
            mult[m4] = mult.get(m4, 0) + len(members)
            qmin = float(np.polynomial.polynomial.polyval(qgrid, [float(c) for c in Q]).min())
            if m4:
                margin_cof = min(margin_cof, qmin)
            else:
                margin_plain = min(margin_plain, qmin)
        sets = list(__import__('itertools').combinations(range(n), 3))
        or3 = {or_table(n, S, sg) for S in sets for sg in (1, -1)}
        orn = {or_table(n, tuple(range(n)), sg) for sg in (1, -1)}
        if n == 3:
            want_zero, want_g4 = set(), orn
        else:
            want_zero, want_g4 = orn, or3
        okn = (len(uniq) == n_expected and bad == 0 and bad_sturm == 0 and set(zero_f) == want_zero
               and set(g4_f) == want_g4 and g5_div == 0)
        # Delta(OR_S) = 2 (1-q)^(|S|-1) on S, 0 off S, as polynomials
        okOR = True
        for S in [tuple(range(n))] + sets:
            fidx = tables.index(or_table(n, S, 1))
            for i in range(n):
                want = [0] * n
                if i in S:
                    m = len(S) - 1
                    for j in range(m + 1):
                        want[j] = 2 * comb(m, j) * (-1) ** j
                okOR &= [int(v) for v in deltas[i][fidx]] == want
        # float sanity: min over the interval of all H_f
        qs = np.linspace(float(q5lo), float(q4hi), 2001)
        V = np.polynomial.polynomial.polyval(qs, uniq.T.astype(float))
        nonzero_rows = np.any(uniq != 0, axis=1)
        q4f = 1 - np.sqrt(3) / 2
        inner = qs <= q4f
        mins = V[nonzero_rows][:, inner].min(axis=1)
        print(f"B  n = {n}: {F.shape[0]} functions, {len(uniq)} distinct H_f (stated {n_expected}); Q = H/g4^m > 0 on "
              f"[q5-, q4+] fails for {bad} (Arb) / {bad_sturm} (Sturm); H == 0 for {len(zero_f)} f "
              f"(as stated: {set(zero_f) == want_zero}); g4 | H != 0 for {len(g4_f)} f (as stated: "
              f"{set(g4_f) == want_g4}); g5 | H for {g5_div}; Delta(OR_S) formula: {okOR}; float min of the nonzero "
              f"H_f on [q5, q4]: {mins.min():.3e}  ({time.time() - t0:.1f}s)", flush=True)
        print(f"   n = {n}: multiplicity of g4 in H_f (number of f): {dict(sorted(mult.items()))}; float margins on "
              f"[q5-, q4+]: min H_f over g4 ∤ H_f = {margin_plain:.6f}, min of H_f/g4^m over g4 | H_f = "
              f"{margin_cof:.6f}", flush=True)
        ok &= okn and okOR
    return ok


def part_O(rng):
    ok = True
    worst = Fr(0)
    tested = 0
    outside_fail = 0
    outside = 0
    for trial in range(400):
        n = 1 + trial % 7
        u = Fr(int(rng.integers(200, 350)), 100)
        q = 1 / (1 + u * u)
        v = 1 / u
        tau = u / (1 + u * u)
        c = [Fr(int(rng.integers(100, 160)), 100) for _ in range(n)]
        inside = all(ci > q * sum(c) for ci in c)
        G = Fr(0)
        for x in range(1 << n):
            k = bin(x).count('1')
            p = q**k * (1 - q)**(n - k)
            s = sum((c[l] * (u if (x >> l) & 1 else -v) for l in range(n)), Fr(0))
            G += p * abs(s)
        formula = 2 * tau * (1 - q)**(n - 1) * sum(c)
        if inside:
            tested += 1
            if G != formula:
                ok = False
                worst = max(worst, abs(G - formula))
        else:
            outside += 1
            outside_fail += G != formula
    print(f"O  OR-region identity at rational u in [2, 3.5], n = 1..7: exact equality in {tested} cases inside the "
          f"region ({'all' if ok else 'NOT all'}); outside the region the formula fails in {outside_fail}/{outside}",
          flush=True)
    # T5 <= T4 iff q >= q5: T5/T4 = (sqrt5/2)(1-q)
    import sympy as sp
    qq = sp.Symbol('q')
    ratio = sp.simplify((2 * sp.sqrt(5) * (1 - qq)**4) / (4 * (1 - qq)**3))
    root = sp.solve(sp.Eq(ratio, 1), qq)
    okT = len(root) == 1 and sp.simplify(root[0] - (1 - 2 / sp.sqrt(5))) == 0
    print(f"O  T5/T4 = {ratio}, equal to 1 only at q = {root} (= q5: {okT}), decreasing in q", flush=True)
    return ok and okT and outside_fail > 0


def main():
    t0 = time.time()
    rng = np.random.default_rng(20261022)
    ok = part_B()
    ok &= part_O(rng)
    print(f"RESULT: {'ALL CHECKS PASSED' if ok else 'FAILURES'} ({time.time() - t0:.0f}s)", flush=True)


if __name__ == '__main__':
    main()
