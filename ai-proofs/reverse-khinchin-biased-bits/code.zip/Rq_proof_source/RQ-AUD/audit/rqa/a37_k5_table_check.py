"""A.37 (RQ-AUD): recompute the descriptive statistics of RQ-A's k = 5 data (Table tab:boxes and Remark 4 of
MAIN_RESULT_K5.tex) from the data files. These numbers are not part of the proof; a mismatch would show that the
text and the data drifted apart. Own code; reads only the JSON data in k5_data/."""
import json, os, sys, time
from fractions import Fraction as Fr
from collections import Counter, defaultdict

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'k5_data')


def main():
    t0 = time.time()
    man = json.load(open(os.path.join(DATA, 'k5_manifest.json')))
    kinds = Counter()
    wid = {'u': [], 't': [], 'r': []}
    heights = Counter()
    nodes = Counter()
    cuts = defaultdict(Counter)
    pieces = defaultdict(Counter)
    tcs_mc = Counter()
    tcs_sub = defaultdict(Counter)
    vsets = Counter()
    nvert = 0
    by_params = Counter()
    deg = Counter()
    ncoord_boxes = defaultdict(list)
    shape_bad = []

    def cert(rec, where):
        nonlocal nvert
        vsets[where] += 1
        nv = len(rec['V'])
        nvert += nv
        by_params[len(rec['n0']) - 1] += 1
        for c in rec['C']:
            deg[len(c) - 1] += 1
        if nv != 2 ** (len(rec['n0']) - 1):
            shape_bad.append(where)

    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        for bx in d['boxes']:
            s, kd = bx['s'], bx['kind']
            kinds[(s, kd)] += 1
            b = [Fr(x) for x in bx['box']]
            wid['u'].append(b[1] - b[0]); wid['t'].append(b[3] - b[2]); wid['r'].append(b[5] - b[4])
            if kd == 'lpv':
                cert(bx, 'lpv')
                continue
            ns_here = Counter()

            def node(nd, lev):
                nodes[lev] += 1
                cuts[lev][nd['mc']] += 1
                cert(nd['c1'], 'node')
                h = 0
                for pc in nd['plus']:
                    tp = pc['type']
                    pieces[(lev, 'plus')][tp if tp[0] not in 'AB' else '(%s)' % tp] += 1
                    if tp[0] in 'AB':
                        ns_here[int(tp[1:])] += 1
                    elif tp == 'TC':
                        cert(pc, 'piece')
                    elif tp == 'TCN':
                        h = max(h, 1 + node(pc, lev + 1))
                    elif tp == 'TCS':
                        h = max(h, 1)
                        tcs_mc[pc['mc']] += 1
                        cert(pc['c1'], 'piece'); cert(pc['c2'], 'piece')
                        for _, _, typ in pc['sub']:
                            tcs_sub[lev][typ] += 1
                            ns_here[int(typ[1:])] += 1
                for pc in nd['minus']:
                    pieces[(lev, 'minus')][pc['type']] += 1
                    cert(pc, 'piece')
                return h

            heights[node(bx, 0)] += 1
            for n in ns_here:
                ncoord_boxes[n].append((b[0], b[1]))

    print('A.37 k5 table check (RQ-AUD), data', DATA)
    print('kinds', dict(sorted(kinds.items())))
    for k in 'utr':
        print(f'widths in {k}: min {float(min(wid[k])):.5f}, max {float(max(wid[k])):.5f}')
    print('heights of ms trees', dict(sorted(heights.items())), '; height >= 1:', heights[1] + heights[2])
    print('nodes per level', dict(sorted(nodes.items())))
    for lev in sorted(cuts):
        print(f'cuts level {lev}:', ', '.join(f'{c} ({n})' for c, n in cuts[lev].most_common()))
    for key in sorted(pieces):
        print(f'pieces level {key[0]} {key[1]}:', dict(sorted(pieces[key].items())))
    print('TCS m_c\' values', dict(tcs_mc))
    for lev in sorted(tcs_sub):
        print(f'TCS sub-pieces at level {lev}:', dict(tcs_sub[lev]))
    print('vertex-certificate sets', sum(vsets.values()), dict(vsets), '; split nodes', vsets['node'] + vsets['piece'])
    print('vertices', nvert, '; sets by number of patch parameters', dict(sorted(by_params.items())),
          '; shape problems', len(shape_bad))
    print('vertex polynomial degrees', dict(sorted(deg.items())))
    for n in sorted(ncoord_boxes):
        L = ncoord_boxes[n]
        print(f'{n}-coordinate near-sphere pieces: {len(L)} boxes, u from {float(min(a for a, _ in L)):.4f} '
              f'to {float(max(b for _, b in L)):.4f}')
    print(f'time {time.time() - t0:.1f} s')


if __name__ == '__main__':
    main()
