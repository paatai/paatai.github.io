"""Negative tests for my MAIN-3 verifier (a14_main3_verify.py): corrupted certificates, boxes, pieces, targets and
tilings must be rejected. For lp-box corruptions a float search also looks for a real violation of (W1),
P(y) >= F(y) at points of the box, so that a rejection can be matched with a genuine defect.
Required: corruptions that break the record by construction (pieces no longer reaching m_c, a removed or halved top
piece, negative m_c, tiling defects, the three-bit claim above q3), and no lp certificate accepted where the float
search finds a real violation. Fixed-size changes of certificates or boxes may leave a valid record (my envelope is
tighter than RQ-A's), so they are info; the sharp checks are calibrated to each certificate's slack in
a14f_main3_slack.py."""
import json
import os
import random
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
import a14_main3_verify as K  # noqa: E402

V, V2 = K.V, K.V2
S3 = K.S3_MINE


def load():
    man = json.load(open(os.path.join(K.DATA, 'k3_manifest.json')))
    boxes = {1: [], -1: []}
    for fn in man['two_files']:
        d = json.load(open(os.path.join(K.DATA, fn)))
        for bx in d['boxes']:
            boxes[d['s']].append((tuple(Fr(x) for x in bx['box']), bx['kind'], bx))
    cells = []
    for fn in man['one_files']:
        for cl in json.load(open(os.path.join(K.DATA, fn)))['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]))
    return boxes, cells


def float_w1_violation(box, s, c, npts=30, seed=0):
    """min over random points of the box and a y-grid of P(y) - F(y), F the exact conditional expectation"""
    rng = np.random.default_rng(seed)
    u1, u2, t1, t2, r1, r2 = [float(x) for x in box]
    cf = [float(x) for x in c]
    ys = np.linspace(-8, 8, 4001)
    P = np.polyval(cf[::-1], ys)
    worst = np.inf
    for _ in range(npts):
        u, t, r = rng.uniform(u1, u2), rng.uniform(t1, t2), rng.uniform(r1, min(r2, 1 - 1e-12))
        q = 1 / (1 + u * u)
        v = 1 / u
        cc, dd = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)
        a1, a2, b = r * cc, s * r * dd, np.sqrt(1 - r * r)
        F = np.zeros_like(ys)
        for x1, p1 in ((u, q), (-v, 1 - q)):
            for x2, p2 in ((u, q), (-v, 1 - q)):
                F += p1 * p2 * np.abs(a1 * x1 + a2 * x2 + b * ys)
        worst = min(worst, float(np.min(P - F)))
    return worst


def lp_job(args):
    box, s, c, mode, seed = args
    c = list(c)
    bx = list(box)
    s3 = S3
    if mode == 'c0':
        c[0] -= abs(c[0]) / 1000
    elif mode == 'c6':
        c[6] -= abs(c[6]) / 10
    elif mode == 'r_down':
        bx[4] = max(K.A_S, bx[4] - Fr(1, 10))
        if bx[4] == box[4]:
            return None
    elif mode == 'sign':
        s = -s
    elif mode == 'u_down':
        bx[0], bx[1] = bx[0] - Fr(1, 20), bx[1] - Fr(1, 20)
    elif mode == 'target_1e-3':
        s3 = S3 * (1 - Fr(1, 1000))
    elif mode == 'target_1e-2':
        s3 = S3 * (1 - Fr(1, 100))
    bx = tuple(bx)
    blo, _ = V.b_range(bx[4], bx[5])
    ok = K.box_cert_ok(bx, s, c, V.mbar_of(bx[3], bx[5], blo), None, s3)[0]
    viol = float_w1_violation(bx, s, c, seed=seed) if mode in ('c0', 'c6', 'r_down', 'sign') else None
    return ok, viol


def nc_job(args):
    box, s, mode = args
    bx = list(box)
    if mode == 'r_down':
        bx[4] = max(K.A_S, bx[4] - Fr(1, 10))
        if bx[4] == box[4]:
            return None
    elif mode == 'u_to_2':
        w = bx[1] - bx[0]
        bx[0], bx[1] = Fr(2) - w, Fr(2)
    elif mode == 'target_1e-2':
        return K.nc_rec((tuple(bx), s, S3 * (1 - Fr(1, 100))))[0]
    return K.nc_rec((tuple(bx), s, S3))[0]


def ms_job(args):
    box, s, rec, mode = args
    rec = json.loads(json.dumps(rec))
    bx = box
    s3 = S3
    mc = Fr(rec['mcut'])
    if mode == 'mc_down':
        rec['mcut'] = str(mc - Fr(1, 10))
    elif mode == 'mc_up':
        if mc + Fr(1, 10) > 1:
            return None
        rec['mcut'] = str(mc + Fr(1, 10))
    elif mode == 'top_removed':
        top = max(rec['pieces'], key=lambda p: Fr(p[1]))
        rec['pieces'] = [p for p in rec['pieces'] if p is not top]
    elif mode == 'top_halved':
        i = max(range(len(rec['pieces'])), key=lambda j: Fr(rec['pieces'][j][1]))
        p = rec['pieces'][i]
        rec['pieces'][i] = [p[0], str((Fr(p[0]) + Fr(p[1])) / 2), p[2], p[3]]
    elif mode == 'pstar_down':
        rec['p3max'] = str(Fr(rec['p3max']) - Fr(1, 100))
    elif mode == 'c2_c0':
        rec['c2'][0] = str(Fr(rec['c2'][0]) - abs(Fr(rec['c2'][0])) / 1000)
    elif mode == 'c1_c0':
        rec['c'][0] = str(Fr(rec['c'][0]) * Fr(99, 100))
    elif mode == 'neg_mc':
        rec['mcut'] = str(-mc)
        rec['p3max'] = str(1 + mc**3)
    elif mode == 'r_down':
        nb = list(box)
        nb[4] = max(K.A_S, nb[4] - Fr(1, 20))
        if nb[4] == box[4]:
            return None
        bx = tuple(nb)
    elif mode == 't_down':
        nb = list(box)
        nb[2] = max(Fr(0), nb[2] - Fr(1, 20))
        if nb[2] == box[2]:
            return None
        bx = tuple(nb)
    elif mode == 'target_1e-2':
        s3 = S3 * (1 - Fr(1, 100))
    elif mode == 'pieces_only_u_down':
        nb = list(box)
        nb[0], nb[1] = nb[0] - Fr(1, 20), nb[1] - Fr(1, 20)
        top = min(Fr(1), V.mbar_of(nb[3], nb[5], V.b_range(nb[4], nb[5])[0]))
        pcs = sorted((Fr(p[0]), Fr(p[1])) for p in rec['pieces'] if p[2] == 1)
        reach = mc
        for m1, m2 in pcs:
            if m1 > reach:
                break
            reach = max(reach, m2)
        if mc < top and reach < top:
            return False
        return all(K.piece_test(tuple(nb), s, m1, m2, s3) is not None for m1, m2 in pcs)
    return K.ms_check((bx, s, rec, s3))[0]


def cell_job(args):
    cl, mode = args
    u1, u2, a1, a2, c = cl
    c = list(c)
    s3 = S3
    if mode == 'c0':
        c[0] -= abs(c[0]) / 1000
    elif mode == 'a_wide':
        a1, a2 = max(Fr(0), a1 - Fr(1, 10)), min(Fr(2, 5), a2 + Fr(1, 10))
    elif mode == 'S3_1.70':
        s3 = Fr(170, 100)
    elif mode == 'target_1e-2':
        s3 = S3 * (1 - Fr(1, 100))
    return K.cell_rec((u1, u2, a1, a2, c, s3))[0]


def main():
    t0 = time.time()
    rnd = random.Random(2026)
    boxes, cells = load()
    lps = [(b[0], s, [Fr(x) for x in b[2]['c']]) for s in (1, -1) for b in boxes[s] if b[1] == 'lp']
    ncs = [(b[0], s) for s in (1, -1) for b in boxes[s] if b[1].startswith('nc')]
    mss = [(b[0], s, b[2]) for s in (1, -1) for b in boxes[s] if b[1] == 'ms']
    L, N, M, C = rnd.sample(lps, 120), rnd.sample(ncs, 120), rnd.sample(mss, 120), rnd.sample(cells, 120)
    allok = True
    with Pool(8) as pool:
        base = pool.map(lp_job, [(bx, s, c, 'none', 0) for bx, s, c in L])
        print(f"lp  uncorrupted sample accepted: {sum(1 for r in base if r[0])}/{len(base)}", flush=True)
        allok &= all(r[0] for r in base)
        for mode in ('c0', 'c6', 'r_down', 'sign', 'u_down', 'target_1e-3', 'target_1e-2'):
            res = [r for r in pool.map(lp_job, [(bx, s, c, mode, i) for i, (bx, s, c) in enumerate(L)]) if r is not None]
            rej = sum(1 for ok, _ in res if not ok)
            extra = ""
            if res and res[0][1] is not None:
                viol = sum(1 for _, v in res if v < 0)
                acc_viol = sum(1 for ok, v in res if ok and v < 0)
                extra = f"; float (W1) violation found in {viol}; accepted despite a violation: {acc_viol}"
                allok &= acc_viol == 0
            print(f"lp  {mode:12s}: rejected {rej}/{len(res)}{extra} (info)", flush=True)
        base = pool.map(nc_job, [(bx, s, 'none') for bx, s in N])
        print(f"nc  uncorrupted sample accepted: {sum(base)}/{len(base)}", flush=True)
        allok &= all(base)
        for mode in ('r_down', 'u_to_2', 'target_1e-2'):
            res = [r for r in pool.map(nc_job, [(bx, s, mode) for bx, s in N]) if r is not None]
            print(f"nc  {mode:12s}: rejected {sum(1 for r in res if not r)}/{len(res)} (info)", flush=True)
        base = pool.map(ms_job, [(bx, s, rec, 'none') for bx, s, rec in M])
        print(f"ms  uncorrupted sample accepted: {sum(base)}/{len(base)}", flush=True)
        allok &= all(base)
        for mode in ('mc_down', 'top_removed', 'top_halved', 'pstar_down', 'c2_c0', 'c1_c0', 'neg_mc', 'r_down', 't_down',
                     'mc_up', 'target_1e-2', 'pieces_only_u_down'):
            res = [r for r in pool.map(ms_job, [(bx, s, rec, mode) for bx, s, rec in M]) if r is not None]
            info = mode in ('mc_up', 'target_1e-2', 'pieces_only_u_down', 'c1_c0', 'c2_c0', 'pstar_down', 'r_down', 't_down')
            print(f"ms  {mode:18s}: rejected {sum(1 for r in res if not r)}/{len(res)}{' (info)' if info else ''}", flush=True)
            if not info:
                allok &= not any(res)
        base = pool.map(cell_job, [(cl, 'none') for cl in C])
        print(f"one uncorrupted sample accepted: {sum(base)}/{len(base)}", flush=True)
        allok &= all(base)
        for mode in ('c0', 'a_wide', 'S3_1.70', 'target_1e-2'):
            res = pool.map(cell_job, [(cl, mode) for cl in C])
            print(f"one {mode:12s}: rejected {sum(1 for r in res if not r)}/{len(res)} (info)", flush=True)
    reg3 = (K.U_LO, K.U_HI, Fr(0), K.T8, K.A_S, Fr(1))
    bm = [b[0] for b in boxes[-1]]
    i = rnd.randrange(len(bm))
    removed = bm[:i] + bm[i + 1:]
    sh = list(bm[i])
    sh[2], sh[3] = sh[2] + Fr(1, 10**4), sh[3] + Fr(1, 10**4)
    shifted = bm[:i] + [tuple(sh)] + bm[i + 1:]
    dup = bm + [bm[i]]
    outs = []
    for name, bl in (('removed', removed), ('shifted 1e-4 in t', shifted), ('duplicated', dup)):
        ins, voleq, nov = V.tiling3(reg3, bl)
        acc = ins and voleq and nov == 0
        outs.append(acc)
        print(f"tiling s=-1, one box {name}: accepted {acc}", flush=True)
    allok &= not any(outs)
    import sympy as sp
    q = sp.Symbol('q')
    d_or2 = 2 * (1 - q)
    P = sp.Poly(12 * (1 - q)**4 - 2 * d_or2**2, q)
    q3 = 1 - sp.sqrt(sp.Rational(2, 3))
    fail_above = P.eval(sp.nsimplify(q3 + sp.Rational(1, 1000))) < 0
    print(f"three-bit claim (k=3) fails at q3 + 1/1000 for OR_2: {bool(fail_above)}")
    allok &= bool(fail_above)
    bad_low, _, _, _ = three_bit_low()
    print(f"three-bit claim (k=3) on [1/100, 25/169] (info: no lower end from three bits): failures {bad_low}")
    print(f"RESULT: {'ALL NEGATIVE TESTS BEHAVE AS REQUIRED' if allok else 'SOME NEGATIVE TEST MISBEHAVED'} ({time.time() - t0:.0f}s)")


def three_bit_low():
    import sympy as sp
    from itertools import product
    q = sp.Symbol('q')
    pts = list(product((0, 1), repeat=3))
    bad = 0
    for vals in product((-1, 1), repeat=8):
        f = dict(zip(pts, vals))
        D = []
        for i in range(3):
            e1 = e0 = 0
            for xx in pts:
                w = sp.Integer(1)
                for j in range(3):
                    if j != i:
                        w *= q if xx[j] else (1 - q)
                if xx[i]:
                    e1 += f[xx] * w
                else:
                    e0 += f[xx] * w
            D.append(sp.expand(e1 - e0))
        P = sp.Poly(sp.expand(12 * (1 - q)**4 - sum(d * d for d in D)), q)
        if P.is_zero:
            continue
        if P.count_roots(sp.Rational(1, 100), sp.Rational(25, 169)) or P.eval(sp.Rational(1, 100)) <= 0:
            bad += 1
    return bad, None, None, None


if __name__ == '__main__':
    main()
