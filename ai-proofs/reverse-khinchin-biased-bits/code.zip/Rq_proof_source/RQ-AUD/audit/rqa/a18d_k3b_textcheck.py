"""A.18 (RQ-A Theorem 4, MAIN_RESULT_K3B): checks of the statements in the text against my own code and the data.

1. Lemma 9: kappa_j = d^[j odd] G_j(w), w = u^2 + u^-2, d = u - 1/u, j = 3..10, against my cumulants (moments10.KAP).
2. Lemma 10: Gaussian term (n-1)!!, nonnegative integer coefficients of mu_n in K_3..K_10, n <= 10.
3. Lemmas 6/7: number of distinct polynomials H_f (text: 39 for n = 3, 1 630 for n = 4).
4. Section 9 data facts: cells per file and degrees, vertex-polynomial degrees, piece counts, TCS boxes and their u1,
   m_c values, width ranges; boxes reaching beyond u4.
5. Where the extremisers sit: every box containing (t, r) = (sqrt2 - 1, sqrt(2/3)) (the point (1,1,1)/sqrt3) or
   (sqrt2 - 1, 1/sqrt2) (the point (1,1,1,1)/2) for some u in [U_-, u4] must be ms5; report the plus piece types that
   contain m = 1 resp. m = 1/sqrt2 there.
"""
import json
import os
import sys
from fractions import Fraction as Fr
from math import sqrt

import sympy as sp

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'common'))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from moments10 import KAP, MOM  # noqa: E402
import a18_k3b_verify as A  # noqa: E402

DATA = A.DATA
ok_all = True


def report(name, ok, detail=""):
    global ok_all
    ok_all &= bool(ok)
    print(f"{'PASS' if ok else 'FAIL'}  {name}" + (f": {detail}" if detail else ""), flush=True)


# 1. Lemma 9
u = sp.Symbol('u', positive=True)
w = u**2 + u**-2
d = u - 1 / u
G = {3: 1, 4: w - 4, 5: w - 10, 6: w**2 - 26 * w + 64, 7: w**2 - 56 * w + 244,
     8: w**3 - 120 * w**2 + 1188 * w - 2176, 9: w**3 - 246 * w**2 + 4044 * w - 11080,
     10: w**4 - 502 * w**3 + 14604 * w**2 - 86728 * w + 126976}
bad = []
for j in range(3, 11):
    mine = sum(sp.Rational(c.numerator, c.denominator) * u**e for e, c in KAP[j].items())
    text = (d if j % 2 else 1) * G[j]
    if sp.simplify(sp.expand(mine - text)) != 0:
        bad.append(j)
report("Lemma 9 cumulant table (j = 3..10) equals my kappa_j", not bad, f"mismatches {bad}")

# 2. Lemma 10
okg, okint = True, True
for n in range(0, 11):
    exp_g = Fr(1)
    if n % 2:
        exp_g = Fr(0)
    else:
        for k in range(n - 1, 0, -2):
            exp_g *= k
    zero = None
    for e, c in MOM[n].items():
        if all(x == 0 for x in e):
            zero = c
        if c < 0 or c.denominator != 1:
            okint = False
    if n and (zero or Fr(0)) != exp_g:
        okg = False
report("Lemma 10: Gaussian term (n-1)!! and nonnegative integer coefficients (n <= 10)", okg and okint)

# 3. distinct H_f
for nb, claim in ((3, 39), (4, 1630)):
    cache, seen, pts, q = A.bit_polys(nb)
    distinct = {tuple(P.all_coeffs()) if not P.is_zero else () for P in cache.values()}
    report(f"Lemma 6/7: number of distinct H_f for n = {nb} is {claim}", len(distinct) == claim,
           f"mine {len(distinct)} (from {len(cache)} Delta-classes of {2 ** (2 ** nb)} functions)")

# 4. data facts
man, cells, boxes = A.load()
per_file = [len(json.load(open(os.path.join(DATA, fn)))['cells']) for fn in man['one_files']]
report("one-coordinate cells per file 98 / 126 / 64", per_file == [98, 126, 64], f"{per_file}")
degs = {max(i for i, c in enumerate(cl[4]) if c != 0) for cl in cells}
report("all one-coordinate cells have degree 10", degs == {10}, f"degrees {sorted(degs)}")
uw = [float(c[1] - c[0]) for c in cells]
aw = [float(c[3] - c[2]) for c in cells]
print(f"      cell widths: u {min(uw):.2e} .. {max(uw):.4f}, a {min(aw):.4f} .. {max(aw):.4f}"
      f" (text: 6.2e-4 .. 0.0175, 0.022 .. 0.044)")


def vrecs(bx):
    if bx['kind'] == 'lpv':
        yield 'lpv', bx
        return
    if bx['kind'] != 'ms5':
        return
    yield 'c1', bx['c1']
    for side in ('plus', 'minus'):
        for pc in bx[side]:
            if pc['type'] in ('TC', 'SG'):
                yield pc['type'], pc
            elif pc['type'] == 'TCS':
                yield 'TCS1', pc['c1']
                yield 'TCS2', pc['c2']


vdeg, nvert, nrec = set(), 0, 0
for bx in boxes:
    for _, rec in vrecs(bx):
        nrec += 1
        nvert += len(rec['V'])
        for cc in rec['C']:
            cc = [Fr(x) for x in cc]
            vdeg.add(max(i for i, c in enumerate(cc) if c != 0))
report("vertex certificates: 2845 sets, 16544 vertices, all polynomials of degree 6",
       nrec == 2845 and nvert == 16544 and vdeg == {6}, f"{nrec} sets, {nvert} vertices, degrees {sorted(vdeg)}")

cnt = {}
tcs_boxes, tcs_u1, mcs, mc2s, nsub, subkinds = 0, [], set(), set(), 0, {}
for bx in boxes:
    if bx['kind'] != 'ms5':
        continue
    mcs.add(Fr(bx['mc']))
    has = False
    for side in ('plus', 'minus'):
        for pc in bx[side]:
            cnt[(side, pc['type'])] = cnt.get((side, pc['type']), 0) + 1
            if pc['type'] == 'TCS':
                has = True
                mc2s.add(Fr(pc['mc']))
                nsub += len(pc['sub'])
                for _, _, k in pc['sub']:
                    subkinds[k] = subkinds.get(k, 0) + 1
    if has:
        tcs_boxes += 1
        tcs_u1.append(Fr(bx['box'][0]))
exp = {('plus', 'A3'): 123, ('plus', 'TC'): 689, ('plus', 'TCS'): 210, ('minus', 'SG'): 146, ('minus', 'TC'): 182}
report("ms5 pieces: plus 123 A3, 689 TC, 210 TCS; minus 146 SG, 182 TC (1350)", cnt == exp, f"{dict(sorted(cnt.items()))}")
report("TCS: m_c' = 17/20 throughout, 301 sub-pieces", mc2s == {Fr(17, 20)} and nsub == 301,
       f"m_c' {sorted(mc2s)}, {nsub} sub-pieces, recorded kinds {subkinds}")
report("TCS pieces occur in 93 boxes, all with u1 >= 2.48", tcs_boxes == 93 and min(tcs_u1) >= Fr(248, 100),
       f"{tcs_boxes} boxes, min u1 {float(min(tcs_u1))}")
want = {Fr(2, 5), Fr(9, 20), Fr(1, 2), Fr(3, 5), Fr(3, 4), Fr(4, 5), Fr(17, 20), Fr(9, 10)}
report("ms5 m_c values {2/5, 9/20, 1/2, 3/5, 3/4, 4/5, 17/20, 9/10}", mcs == want, f"{sorted(mcs)}")
W = {k: [] for k in 'utr'}
for bx in boxes:
    b = [Fr(x) for x in bx['box']]
    W['u'].append(float(b[1] - b[0]))
    W['t'].append(float(b[3] - b[2]))
    W['r'].append(float(b[5] - b[4]))
print(f"      box widths: u {min(W['u']):.2e} .. {max(W['u']):.4f}, t {min(W['t']):.2e} .. {max(W['t']):.4f},"
      f" r {min(W['r']):.2e} .. {max(W['r']):.4f} (text: 2.46e-3 .. 0.01, 3.2e-3 .. 0.104, 5.1e-3 .. 0.081)")

u4 = sqrt(3 + 2 * sqrt(3))
beyond = {}
for bx in boxes:
    if float(Fr(bx['box'][1])) > u4:
        beyond[(bx['s'], bx['kind'])] = beyond.get((bx['s'], bx['kind']), 0) + 1
print(f"      boxes with u2 > u4 (used only for u <= u4): {dict(sorted(beyond.items()))};"
      f" cells with u2 > u4: {sum(1 for c in cells if float(c[1]) > u4)}")

# 5. extremisers (every box has u1 < u4, so every box meets [U_-, u4])
def sym_in(lo, hi, val):
    return sp.Rational(lo.numerator, lo.denominator) <= val <= sp.Rational(hi.numerator, hi.denominator)


T3 = sp.sqrt(2) - 1
R3 = sp.sqrt(sp.Rational(2, 3))
R4 = 1 / sp.sqrt(2)
U4 = sp.sqrt(3 + 2 * sp.sqrt(3))
hits3, hits4 = [], []
for bx in boxes:
    if bx['s'] != 1:
        continue
    b = [Fr(x) for x in bx['box']]
    assert b[0] < U4
    if sym_in(b[2], b[3], T3) and sym_in(b[4], b[5], R3):
        hits3.append(bx)
    if sym_in(b[2], b[3], T3) and sym_in(b[4], b[5], R4) and sym_in(b[0], b[1], U4):
        hits4.append(bx)
k3 = {bx['kind'] for bx in hits3}
report("boxes containing (1,1,1)/sqrt3 (any u) are all ms5", k3 == {'ms5'}, f"{len(hits3)} boxes, kinds {k3}")
pt3 = {}
for bx in hits3:
    for pc in bx['plus']:
        if Fr(pc['m'][1]) == 1:
            pt3[pc['type']] = pt3.get(pc['type'], 0) + 1
report("in those boxes the plus pieces containing m = 1 are A3 (equality allowed there)", set(pt3) == {'A3'}, f"{pt3}")
k4 = {bx['kind'] for bx in hits4}
report("boxes containing (1,1,1,1)/2 at u = u4 are all ms5", k4 == {'ms5'}, f"{len(hits4)} boxes, kinds {k4}")
pt4 = {}
for bx in hits4:
    for pc in bx['plus']:
        if sym_in(Fr(pc['m'][0]), Fr(pc['m'][1]), R4):
            pt4[pc['type']] = pt4.get(pc['type'], 0) + 1
report("in those boxes the plus pieces containing m = 1/sqrt2 are TCS", set(pt4) == {'TCS'}, f"{pt4}")

S3 = A.S3
report("Lemma 15: S3 (144/169)^2 > 1.25 > 7/20", S3 * Fr(144, 169)**2 > Fr(5, 4) > Fr(7, 20), f"{float(S3 * Fr(144, 169) ** 2):.5f}")
print("RESULT:", "ALL PASS" if ok_all else "SOME CHECKS FAILED")
