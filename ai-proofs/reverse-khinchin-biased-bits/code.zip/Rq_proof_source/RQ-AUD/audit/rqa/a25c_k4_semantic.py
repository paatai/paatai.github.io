"""RQ-AUD semantic test of RQ-A's MAIN-5 data (Theorem 5, R = T4 on [q5, q4]), floating point, own code.

For sampled unit alpha and u in [U_LO, U_HI] this follows the case analysis of the proof (reduction, one-coordinate
cell, lpv box, m-split box: c1, plus pieces A3 / TC / TCS / TCN with their inner levels, minus pieces SG / TC) down
to the step that makes the claim, and compares the claim with the exact value E|L| (enumeration of all 2^n atoms):
 - steps that end in a vertex certificate, a one-coordinate cell or Lemmas 4-5 claim E|L| < T4(u) at every u of
   their box, also outside [u4, u5]; vertex certificates even claim E|L| < T^-(u1, u2);
 - steps that end in a near-sphere test (A3), (A4), (A5) claim E|L| <= T4 only for q in [q5, q4].
Samples: perturbations of the extremisers (e1+e2+e3+e4)/2, (e1+e2+e3)/sqrt3, (e1+..+e5)/sqrt5 and of
(e1+e2)/sqrt2, e1 at scales 1e-1..1e-4, random alpha with heavy or light tails (n = 3..9), and spread-out alpha
with n = 10..13 (mostly max|alpha_i| <= 33/100, the one-coordinate cells); u uniform on the range and
concentrated near u4 and u5 (on both sides, where T3 resp. T5 exceeds T4).
"""
import json
import math
import os
import sys
import time
from fractions import Fraction as Fr

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('K4_DATA', os.path.join(HERE, 'k4_data'))
U_LO, U_HI, A_S = 1589 / 625, 29107 / 10000, 0.33
U4 = math.sqrt(3 + 2 * math.sqrt(3))
U5 = math.sqrt(4 + 2 * math.sqrt(5))


def T4(u):
    return 4 * u**7 / (1 + u * u)**4


def EabsL(alpha, u):
    n = len(alpha)
    q = 1 / (1 + u * u)
    bits = ((np.arange(2**n)[:, None] >> np.arange(n)) & 1).astype(bool)
    vals = np.where(bits, u, -1 / u) @ np.asarray(alpha)
    k = bits.sum(1)
    p = q**k * (1 - q)**(n - k)
    return float(np.sum(p * np.abs(vals)))


def load():
    man = json.load(open(os.path.join(DATA, 'k4_manifest.json')))
    boxes = {1: [], -1: []}
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        boxes[d['s']] += d['boxes']
    idx = {}
    for s in (1, -1):
        arr = np.array([[float(Fr(x)) for x in bx['box']] for bx in boxes[s]])
        idx[s] = arr
    return boxes, idx


def fl(x):
    return float(Fr(x))


def peel(beta, sign):
    """index of a coefficient equal to sign * max|beta|, and the normalised remainder"""
    m = np.max(np.abs(beta))
    cand = np.where(np.isclose(beta, sign * m, rtol=0, atol=1e-15))[0]
    if len(cand) == 0:
        return None, None
    i = cand[0]
    rest = np.delete(beta, i)
    if m >= 1 - 1e-15 or len(rest) == 0:
        return i, np.zeros(0)
    return i, rest / np.linalg.norm(rest)


def has(beta, sign):
    m = np.max(np.abs(beta))
    return bool(np.any(np.isclose(beta, sign * m, rtol=0, atol=1e-15)))


def pieces_containing(pieces, x, key='m'):
    return [p for p in pieces if fl(p[key][0]) - 1e-15 <= x <= fl(p[key][1]) + 1e-15]


def claim(alpha, u, boxes, idx):
    """('lt', T) : E|L| < T claimed; ('le', T): E|L| <= T claimed; (None, why): no claim at this q"""
    a = np.array(sorted(alpha, key=lambda x: -abs(x)))
    if a[0] < 0:
        a = -a
    in_range = U4 - 1e-12 <= u <= U5 + 1e-12
    a1 = a[0]
    if a1 >= 1 - 1e-15:
        return ('lt', T4(u)), 'e1'
    if a1 <= A_S:
        return ('lt', T4(u)), 'cell'
    a2 = abs(a[1])
    s = 1 if a[1] >= 0 else -1
    r = math.hypot(a1, a2)
    if r >= 1 - 1e-15:
        return ('lt', T4(u)), 'two'
    th = math.atan2(a2, a1)
    t = math.tan(th / 2)
    arr = idx[s]
    hit = np.where((arr[:, 0] <= u) & (u <= arr[:, 1]) & (arr[:, 2] <= t) & (t <= arr[:, 3])
                   & (arr[:, 4] <= r) & (r <= arr[:, 5]))[0]
    if len(hit) == 0:
        return (None, 'no box'), 'nobox'
    bx = boxes[s][hit[0]]
    u1, u2 = fl(bx['box'][0]), fl(bx['box'][1])
    Tm = min(T4(u1), T4(u2))
    if bx['kind'] == 'lpv':
        return ('lt', Tm), 'lpv'
    beta = a[2:] / np.linalg.norm(a[2:])
    m = float(np.max(np.abs(beta)))
    if m <= fl(bx['mc']):
        return ('lt', Tm), 'c1'
    if has(beta, 1):
        pcs = pieces_containing(bx['plus'], m)
        if not pcs:
            return (None, 'no plus piece'), 'plus-gap'
        pc = pcs[0]
        tp = pc['type']
        if tp == 'A3':
            return (('le', T4(u)) if in_range else (None, 'A3 outside [q5,q4]')), 'A3'
        if tp == 'TC':
            return ('lt', Tm), 'TC+'
        _, Mp = peel(beta, 1)
        if m >= 1 - 1e-15 or len(Mp) == 0:
            return ('lt', Tm), tp + ' m=1'
        mp = float(np.max(np.abs(Mp)))
        if tp == 'TCS':
            if mp <= fl(pc['mc']):
                return ('lt', Tm), 'TCS c1'
            if has(Mp, -1):
                return ('lt', Tm), 'TCS c2'
            subs = [x for x in pc['sub'] if fl(x[0]) - 1e-15 <= mp <= fl(x[1]) + 1e-15]
            if not subs:
                return (None, 'TCS sub gap'), 'TCS-gap'
            return (('le', T4(u)) if in_range else (None, 'A4 outside')), 'TCS A4'
        if tp == 'TCN':
            if mp <= fl(pc['mc']):
                return ('lt', Tm), 'TCN c1'
            if not has(Mp, 1):
                ips = pieces_containing(pc['minus'], mp)
                if not ips:
                    return (None, 'TCN minus gap'), 'TCN-gap'
                return ('lt', Tm), 'TCN ' + ips[0]['type'] + '-'
            ips = pieces_containing(pc['plus'], mp)
            if not ips:
                return (None, 'TCN plus gap'), 'TCN-gap'
            ip = ips[0]
            if ip['type'] == 'A4':
                return (('le', T4(u)) if in_range else (None, 'A4 outside')), 'TCN A4'
            if ip['type'] == 'TC4':
                return ('lt', Tm), 'TCN TC4+'
            _, Mpp = peel(Mp, 1)
            if mp >= 1 - 1e-15 or len(Mpp) == 0:
                return ('lt', Tm), 'TC4S m1=1'
            mpp = float(np.max(np.abs(Mpp)))
            if mpp <= fl(ip['mc']):
                return ('lt', Tm), 'TC4S d1'
            if not has(Mpp, 1):
                return ('lt', Tm), 'TC4S d2'
            subs = [x for x in ip['sub'] if fl(x[0]) - 1e-15 <= mpp <= fl(x[1]) + 1e-15]
            if not subs:
                return (None, 'TC4S sub gap'), 'TC4S-gap'
            return (('le', T4(u)) if in_range else (None, 'A5 outside')), 'TC4S A5'
        return (None, 'type ' + tp), 'unknown'
    pcs = pieces_containing(bx['minus'], m)
    if not pcs:
        return (None, 'no minus piece'), 'minus-gap'
    return ('lt', Tm), 'minus ' + pcs[0]['type']


def samples(rng, N):
    bases = [np.array([1, 1, 1, 1]) / 2, np.ones(3) / math.sqrt(3), np.ones(5) / math.sqrt(5),
             np.ones(2) / math.sqrt(2), np.array([1.0])]
    for i in range(N):
        kind = i % 5
        n = int(rng.integers(3, 10))
        if kind < 3:
            base = bases[int(rng.integers(0, len(bases)))]
            n = max(n, len(base))
            v = np.zeros(n)
            v[:len(base)] = base
            v = v + 10.0**(-int(rng.integers(1, 5))) * rng.standard_normal(n)
        elif kind == 3:
            v = rng.standard_normal(n) * np.abs(rng.standard_normal(n))**int(rng.integers(0, 3))
        else:
            n = int(rng.integers(10, 15))
            v = rng.choice((-1.0, 1.0), n) * (1 + 0.2 * rng.random(n))
            v[0] *= 1 + 0.6 * rng.random()
        v = v / np.linalg.norm(v)
        z = rng.random()
        if z < 0.5:
            u = U_LO + (U_HI - U_LO) * rng.random()
        elif z < 0.75:
            u = U4 + (rng.random() - 0.5) * 2 * (U4 - U_LO) * 1.0
        else:
            u = U5 + (rng.random() - 0.5) * 2 * (U_HI - U5) * 1.0
        u = min(max(u, U_LO), U_HI)
        yield v, u


def main():
    t0 = time.time()
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 40000
    boxes, idx = load()
    rng = np.random.default_rng(25)
    stats, viol, noclaim, worst, worst_at = {}, [], {}, {}, {}
    special = []
    for k in range(200):
        for base, n in ((np.ones(3) / math.sqrt(3), 3), (np.ones(5) / math.sqrt(5), 5), (np.ones(4) / 2, 4)):
            u = U_LO + (U_HI - U_LO) * k / 199
            special.append((base, u))
    allsamp = list(samples(rng, N)) + special
    for v, u in allsamp:
        (kind, T), step = claim(v, u, boxes, idx)
        stats[step] = stats.get(step, 0) + 1
        if kind is None:
            noclaim[T] = noclaim.get(T, 0) + 1
            continue
        E = EabsL(v, u)
        gap = (T - E) / T
        if gap < worst.get(step, 9):
            worst[step] = gap
            worst_at[step] = (u, v)
        if (kind == 'lt' and not E < T) or (kind == 'le' and E > T * (1 + 1e-12)):
            viol.append((step, kind, u, E, T, v))
    print(f"semantic test of the MAIN-5 data: {len(allsamp)} (alpha, u) samples ({N} random, {len(special)} on the"
          f" three extremisers for u across [U_LO, U_HI]); {time.time() - t0:.0f}s")
    print("claims by the step of the proof that makes them:", dict(sorted(stats.items())))
    print("no claim (near-sphere test outside [q5, q4]; any gap would be listed here too):", noclaim)
    print("smallest relative slack (T - E|L|)/T per step:", {k: f"{v:.3e}" for k, v in sorted(worst.items())})
    print("where the smallest slack of each near-sphere step occurs (u - u4, u5 - u, sorted |alpha_i| > 1e-3):")
    for k in sorted(worst_at):
        if any(t in k for t in ('A3', 'A4', 'A5')):
            u, v = worst_at[k]
            big = sorted((abs(x) for x in v if abs(x) > 1e-3), reverse=True)
            print(f"   {k}: slack {worst[k]:.3e}, u - u4 = {u - U4:.3e}, u5 - u = {U5 - u:.3e}, |alpha| =",
                  np.round(big, 6))
    print(f"violations: {len(viol)}")
    for x in viol[:20]:
        print("   VIOLATION", x[:5], np.round(x[5], 6))
    gaps = sum(v for k, v in noclaim.items() if 'gap' in k or 'no ' in k)
    print(f"RESULT: {'PASS' if not viol and gaps == 0 else 'FAIL'}")


if __name__ == '__main__':
    main()
