"""A.6 addendum: is RQ-A's refereed MAIN_RESULT.pdf (0a95569f, built 07:30:18 UTC) the text of
MAIN_RESULT.tex (6816732f)? Same method as the 07:41 addendum: every distinct number of the source
must occur in the extracted PDF text, and every long word too (the misses are listed for reading).
Also locates the two A.6 fixes and the appendix line in both files.
"""
import os as _os
_ROOT = _os.path.abspath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "..", ".."))  # archive root
import hashlib
import re
import subprocess
import sys

TEX = _os.path.join(_ROOT, "RQ-A/MAIN_RESULT.tex")
PDF = _os.path.join(_ROOT, "RQ-A/MAIN_RESULT.pdf")
EXPECT = {TEX: "6816732f", PDF: "0a95569f"}


def main():
    ok = True
    for p, h in EXPECT.items():
        got = hashlib.md5(open(p, "rb").read()).hexdigest()
        print(f"md5 {p.rsplit('/', 1)[1]}: {got[:8]} (expected {h})")
        ok &= got.startswith(h)
    tex = open(TEX, encoding="utf-8").read()
    pdf = subprocess.run(["pdftotext", "-enc", "UTF-8", PDF, "-"], capture_output=True, text=True, check=True).stdout
    pdf_join = re.sub(r"-\n", "", pdf)
    pdf_flat = re.sub(r"\s+", "", pdf_join)

    body = tex[tex.index("\\begin{document}"):]
    body_nocmd = re.sub(r"\\(label|ref|eqref|cite|begin|end|usepackage|texttt|label)\{[^}]*\}", " ", body)
    nums = sorted(set(re.findall(r"\d+(?:\.\d+)?", body_nocmd)) - {str(i) for i in range(10)})
    miss_n = [n for n in nums if n not in pdf_flat]
    print(f"distinct numbers (>= 2 chars) in the tex body: {len(nums)}; missing from the PDF text: {miss_n}")
    ok &= not miss_n

    words = sorted({w for w in re.findall(r"(?<![\\A-Za-z])[A-Za-z]{6,}", body_nocmd)})
    pdf_words = set(re.findall(r"[A-Za-z]+", pdf_join))
    pdf_low = pdf_join.lower()
    miss_w = [w for w in words if w not in pdf_words and w.lower() not in pdf_low]
    print(f"distinct words (>= 6 letters) in the tex body: {len(words)}; not found in the PDF text: {miss_w}")

    for label, pat in (("f1 fix 'q>0.27015'", r"q\s*>\s*0\.27015"), ("f1 value 0.2701496", r"0\.2701496"),
                       ("old value 0.2744", r"0\.2744"), ("appendix '6.2'", r"6\.2\s*(\\cdot\s*10\^\{-3\}|·\s*10)"),
                       ("appendix '5.7'", r"5\.7\s*(\\cdot\s*10\^\{-4\}|·\s*10)")):
        nt = len(re.findall(pat, tex))
        npdf = len(re.findall(pat, pdf_join))
        print(f"{label}: tex {nt}, pdf {npdf}")
    m = re.search(r"use Lemma~\\ref\{lem:sym\}\.(.{0,40})", tex)
    print(f"f2: end of proof of Theorem 1(c) in the tex: {m.group(0)!r}")
    ok &= m.group(1).startswith("\\hfill$\\square$")
    i = pdf_join.find("use Lemma")
    print(f"f2: the PDF text around it: {pdf_join[i:i + 30]!r}")
    print("A6F_PASS" if ok else "A6F_FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
