"""RQ-AUD independent verifier for RQ-A MAIN-2 (Theorem 2 of RQ-A STATUS):
    E|sum alpha_i chi_i| <= S_2(q) = 2 sqrt2 (1-q) tau  for every unit alpha and every q in [1/5, 1-1/sqrt2].
Written from the statement in RQ-A CLAIMS.md (MAIN-2) and the mathematics; RQ-A's verify_k2.py, cert2c.py,
nearcircle.py are NOT imported or re-used.  Only RQ-AUD code (A.6 / A.9 machinery) and the RQ-A certificate
data (polynomials and boxes, copied to k2_data/ with md5s) are used.

Parametrisation: u = sqrt((1-q)/q) in [u0, 2] (q in [1/5, q0]), tau = u/(1+u^2), q tau = u/(1+u^2)^2 (decreasing
for u >= 1), (1-q) tau = u^3/(1+u^2)^2 (increasing on [1, sqrt3], decreasing after), S_2 = 2 sqrt2 u^3/(1+u^2)^2.

Reduction.  Sort |alpha_i| decreasingly, alpha_1 = a1 > 0, s = sign(alpha_2), r = sqrt(a1^2+a2^2), (a1, a2) =
r (c, d), c = (1-t^2)/(1+t^2), d = 2t/(1+t^2), t in [0, sqrt2-1], b = sqrt(1-r^2), M = b^-1 sum_{i>=3} alpha_i chi_i,
|beta_i| <= a2/b.  E|L| = E F(M), F(y) = sum_j |X_j + B_j y|, X_j = p_j x_j, B_j = p_j b over the 4 atoms of
a1 chi_1 + s a2 chi_2.  n <= 2 (b = 0): Lemma 2C.  r < 9/20 or a1 <= 9/20: one-coordinate cells (k=2 target).

Checks:
 A  elementary facts (exact): Lemma 2C at random rational points, the factorisation behind the quartic tail bound,
    atom products, glue constants.
 B  tilings: 450 one-coordinate cells tile [U_LO,2] x [0,9/20]; for s = +-1 the boxes lie in
    [U_LO,2] x [0,T8] x [9/20,1], have pairwise disjoint interiors and total volume = region volume (=> cover).
 C  one-coordinate cells: A.9 cell check with target tau(u2)(r2 u1^2/(1+u1^2) - a2), r2 < sqrt2.
 D  LP boxes: OWN envelope (q tau and (1-q) tau enclosed as functions of u, c+-d by monotonicity), the pieces of
    the convex piecewise-linear majorant, P - piece > 0 on each closed piece interval (Arb root isolation),
    and the six-moment bound T_lo - A - (|B| r + G r^2 + Eneg r^4) > 0 on [0, mbar]; bisection (same P) if needed.
 E  near-circle boxes: E|L| <= r G + sum_j p_j min(b, (27/128) b^4 E M^4 / (r |y_j|)^3), G <= S_2 (Lemma 2C,
    needs u >= u0); three sufficient tests (pointwise ratio, monotone, mixed); bisection if needed.
 F  'small' boxes: r2 c(t1) <= 9/20.
"""
import json
import os
import random
import sys
import time
from fractions import Fraction as Fr
from math import isqrt
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo, kappa_ranges, imul, tiles  # noqa: E402

DATA = os.environ.get('K2_DATA', os.path.join(HERE, 'k2_data'))
U_LO, U_HI, T8, A_S = Fr(1553773, 10**6), Fr(2), Fr(20711, 50000), Fr(9, 20)
D30 = 10**30
R2_MINE = Fr(isqrt(2 * D30 * D30), D30)
R2_RQA = Fr(282842712474619, 200000000000000)
assert R2_MINE**2 < 2 and R2_RQA**2 < 2
SQ2_HI = sqrt_hi(Fr(2))
SQ3_HI = sqrt_hi(Fr(3))
K27 = Fr(27, 128)


# ---------------------------------------------------------------- interval helpers (closed intervals as tuples)
def iadd(a, b):
    return (a[0] + b[0], a[1] + b[1])


def ineg(a):
    return (-a[1], -a[0])


def imm(a, b):
    ps = (a[0] * b[0], a[0] * b[1], a[1] * b[0], a[1] * b[1])
    return (min(ps), max(ps))


def iabs_lo(a):
    if a[0] > 0:
        return a[0]
    if a[1] < 0:
        return -a[1]
    return Fr(0)


def f_qtau(u):
    return u / (1 + u * u)**2


def f_pt(u):
    return u**3 / (1 + u * u)**2


def r_qtau(u1, u2):
    return (f_qtau(u2), f_qtau(u1))


def r_pt(u1, u2):
    lo = min(f_pt(u1), f_pt(u2))
    hi = 3 * SQ3_HI / 16 if u1 * u1 <= 3 <= u2 * u2 else max(f_pt(u1), f_pt(u2))
    return (lo, hi)


def cfun(t):
    return (1 - t * t) / (1 + t * t)


def dfun(t):
    return 2 * t / (1 + t * t)


def r_c(t1, t2):
    return (cfun(t2), cfun(t1))


def r_d(t1, t2):
    return (dfun(t1), dfun(t2))


def r_cpd(t1, t2):
    f = lambda t: (1 - t * t + 2 * t) / (1 + t * t)
    hi = SQ2_HI if (t1 + 1)**2 <= 2 <= (t2 + 1)**2 else max(f(t1), f(t2))
    return (min(f(t1), f(t2)), hi)


def r_cmd(t1, t2):
    f = lambda t: (1 - t * t - 2 * t) / (1 + t * t)
    return (f(t2), f(t1))


def r_probs(u1, u2):
    q1, q2 = 1 / (1 + u1 * u1), 1 / (1 + u2 * u2)
    pq = (q2 * (1 - q2), q1 * (1 - q1))
    return [(q2 * q2, q1 * q1), pq, pq, ((1 - q1)**2, (1 - q2)**2)]


def b_range(r1, r2):
    blo = sqrt_lo(1 - r2 * r2) if r2 < 1 else Fr(0)
    return blo, sqrt_hi(1 - r1 * r1)


def mbar_of(t2, r2, blo):
    a2hi = r2 * dfun(t2)
    return min(Fr(1), a2hi / blo) if blo > 0 else Fr(1)


def T_lo(u1, u2, r2v):
    return 2 * r2v * min(f_pt(u1), f_pt(u2))


# ---------------------------------------------------------------- D: LP boxes
def atoms_X(u1, u2, t1, t2, r1, r2, s):
    A, Bv = r_qtau(u1, u2), r_pt(u1, u2)
    C, Dd = r_c(t1, t2), r_d(t1, t2)
    CS = r_cpd(t1, t2) if s == 1 else r_cmd(t1, t2)
    sD = Dd if s == 1 else ineg(Dd)
    inner = [imm(A, CS),
             iadd(imm(Bv, C), ineg(imm(A, sD))),
             iadd(ineg(imm(A, C)), imm(Bv, sD)),
             ineg(imm(Bv, CS))]
    R = (r1, r2)
    return [imm(R, x) for x in inner]


def envelope_pieces(X, B):
    z = [(-X[j][0] - X[j][1]) / (B[j][0] + B[j][1]) for j in range(4)]
    pts = sorted(set(z + [Fr(0)]))
    ivs = [(None, pts[0])] + [(pts[i], pts[i + 1]) for i in range(len(pts) - 1)] + [(pts[-1], None)]
    out = []
    for lo, hi in ivs:
        y = hi - 1 if lo is None else (lo + 1 if hi is None else (lo + hi) / 2)
        right = y > 0
        icpt = slope = Fr(0)
        for j in range(4):
            if y > z[j]:
                icpt += X[j][1]
                slope += B[j][1] if right else B[j][0]
            else:
                icpt -= X[j][0]
                slope -= B[j][0] if right else B[j][1]
        out.append((lo, hi, icpt, slope))
    return out


def moment_ok(c, u1, u2, mbar, T):
    k3, k4, k5, k6, k3sq = kappa_ranges(u1, u2)
    c0, c1, c2, c3, c4, c5, c6 = c
    A = c0 + c2 + 3 * c4 + 15 * c6
    Babs = max(abs(x) for x in imul(k3, c3 + 10 * c5))
    Chi = imul(k4, c4 + 15 * c6)[1]
    Dabs = max(abs(x) for x in imul(k5, c5))
    Ehi = imul(k6, c6)[1]
    Fhi = max(imul(k3sq, 10 * c6)[1], 0)
    G = Chi + Dabs * mbar + Fhi + (Ehi * mbar * mbar if Ehi > 0 else 0)
    Eneg = Ehi if Ehi < 0 else Fr(0)
    if T - A <= 0:
        return False, "T <= A"
    ok, why = positive_on([T - A, -Babs, -G, Fr(0), -Eneg], lo=Fr(0), hi=mbar)
    return ok, ("" if ok else "moment: " + why)


def lp_once(box, s, c, r2v):
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = b_range(r1, r2)
    X = atoms_X(u1, u2, t1, t2, r1, r2, s)
    B = [(p[0] * blo, p[1] * bhi) for p in r_probs(u1, u2)]
    for lo, hi, icpt, slope in envelope_pieces(X, B):
        ok, why = positive_on([c[0] - icpt, c[1] - slope] + list(c[2:]), lo=lo, hi=hi)
        if not ok:
            return False, "dom: " + why
    return moment_ok(c, u1, u2, mbar_of(t2, r2, blo), T_lo(u1, u2, r2v))


def split8(box):
    u1, u2, t1, t2, r1, r2 = box
    um, tm, rm = (u1 + u2) / 2, (t1 + t2) / 2, (r1 + r2) / 2
    return [(a, b, c_, d, e, f) for (a, b) in ((u1, um), (um, u2)) for (c_, d) in ((t1, tm), (tm, t2))
            for (e, f) in ((r1, rm), (rm, r2))]


def lp_rec(args, depth=0, maxdepth=3):
    box, s, c, r2v = args
    ok, why = lp_once(box, s, c, r2v)
    if ok:
        return True, 1, depth, ""
    if depth >= maxdepth:
        return False, 0, depth, why
    leaves, md = 0, depth
    for sb in split8(box):
        ok, lv, d2, why2 = lp_rec((sb, s, c, r2v), depth + 1, maxdepth)
        if not ok:
            return False, 0, d2, why2
        leaves += lv
        md = max(md, d2)
    return True, leaves, md, ""


# ---------------------------------------------------------------- E: near-circle boxes
def atoms_y(u1, u2, t1, t2, s):
    U, V = (u1, u2), (1 / u2, 1 / u1)
    C, Dd = r_c(t1, t2), r_d(t1, t2)
    CS = r_cpd(t1, t2) if s == 1 else r_cmd(t1, t2)
    sD = Dd if s == 1 else ineg(Dd)
    return [imm(CS, U), iadd(imm(C, U), ineg(imm(sD, V))), iadd(ineg(imm(C, V)), imm(sD, U)), ineg(imm(CS, V))]


def nc_once(box, s, r2v):
    u1, u2, t1, t2, r1, r2 = box
    if r1 <= 0:
        return False, "r1 = 0"
    T = T_lo(u1, u2, r2v)
    blo, bhi = b_range(r1, r2)
    mbar = mbar_of(t2, r2, blo)
    k4hi = u2 * u2 + 1 / (u2 * u2) - 4
    E4 = 3 + max(Fr(0), k4hi) * mbar * mbar
    ys = [iabs_lo(y) for y in atoms_y(u1, u2, t1, t2, s)]
    ph = [p[1] for p in r_probs(u1, u2)]
    # lower bound of S_2 - G = 2 tau (sqrt2 (1-q) - max(c, d, [s=1](1-q)(c+d))) (>= 0 for u >= u0, Lemma 2C)
    tau_lo = u2 / (1 + u2 * u2)
    om_lo, om_hi = u1 * u1 / (1 + u1 * u1), u2 * u2 / (1 + u2 * u2)
    C, Dd = r_c(t1, t2), r_d(t1, t2)
    mx = max(C[1], Dd[1], om_hi * r_cpd(t1, t2)[1] if s == 1 else Fr(0))
    Dlo = max(Fr(0), 2 * tau_lo * (r2v * om_lo - mx))
    # test 1 (pointwise ratio): sum_j p_j err_j <= (b^2/(1+r)) K E4 bhi^2 (1+r2)/r1^3 sum p_j/|y_j|^3 <= T b^2/(1+r)
    if all(y > 0 for y in ys):
        S = sum(p / y**3 for p, y in zip(ph, ys))
        if K27 * E4 * bhi * bhi * (1 + r2) / r1**3 * S <= T:
            return True, "1"
    # test 2 (monotone): sum p_j min(bhi, K bhi^4 E4/(r1 |y_j|)^3) <= T (1-r2) + r1 Dlo
    lhs = Fr(0)
    for p, y in zip(ph, ys):
        e = bhi if y == 0 else min(bhi, K27 * bhi**4 * E4 / (r1 * y)**3)
        lhs += p * e
    if lhs <= T * (1 - r2) + r1 * Dlo:
        return True, "2"
    # test 3 (mixed): zero atoms contribute <= bhi, others <= K E4 bhi^2 b^2/(r1 |y|)^3; need for b in [blo,bhi]:
    #   b^2 (Cnz - T/(1+r2)) + bhi Cz <= r1 Dlo
    Cz = sum(p for p, y in zip(ph, ys) if y == 0)
    Cnz = sum(p * K27 * E4 * bhi * bhi / (r1 * y)**3 for p, y in zip(ph, ys) if y > 0)
    coef = Cnz - T / (1 + r2)
    bw = bhi if coef > 0 else blo
    if bw * bw * coef + bhi * Cz <= r1 * Dlo:
        return True, "3"
    return False, "nc tests fail"


def nc_rec(args, depth=0, maxdepth=4):
    box, s, r2v = args
    ok, why = nc_once(box, s, r2v)
    if ok:
        return True, 1, depth, why
    if depth >= maxdepth:
        return False, 0, depth, why
    leaves, md = 0, depth
    for sb in split8(box):
        ok, lv, d2, why2 = nc_rec((sb, s, r2v), depth + 1, maxdepth)
        if not ok:
            return False, 0, d2, why2
        leaves += lv
        md = max(md, d2)
    return True, leaves, md, "bisected"


# ---------------------------------------------------------------- B: 3-D tiling
def tiling3(region, boxes):
    inside = all(region[0] <= b[0] < b[1] <= region[1] and region[2] <= b[2] < b[3] <= region[3]
                 and region[4] <= b[4] < b[5] <= region[5] for b in boxes)
    vol = sum((b[1] - b[0]) * (b[3] - b[2]) * (b[5] - b[4]) for b in boxes)
    full = (region[1] - region[0]) * (region[3] - region[2]) * (region[5] - region[4])
    ranks = []
    for dim in range(3):
        vals = sorted({b[2 * dim] for b in boxes} | {b[2 * dim + 1] for b in boxes})
        idx = {v: i for i, v in enumerate(vals)}
        ranks.append(np.array([[idx[b[2 * dim]], idx[b[2 * dim + 1]]] for b in boxes], dtype=np.int64))
    lo = np.stack([ranks[d][:, 0] for d in range(3)], 1)
    hi = np.stack([ranks[d][:, 1] for d in range(3)], 1)
    n = len(boxes)
    overl = 0
    CH = 400
    for i0 in range(0, n, CH):
        L, H = lo[i0:i0 + CH, None, :], hi[i0:i0 + CH, None, :]
        ov = np.all((L < hi[None, :, :]) & (lo[None, :, :] < H), axis=2)
        ov[np.arange(min(CH, n - i0)), np.arange(i0, min(i0 + CH, n))] = False
        overl += int(ov.sum())
    return inside, vol == full, overl // 2


# ---------------------------------------------------------------- A: elementary facts
def lemma2c_exact(trials=4000, seed=11):
    rnd = random.Random(seed)
    bad = 0
    for _ in range(trials):
        u = Fr(rnd.randint(1001, 4000), 1000)
        v = 1 / u
        q = 1 / (1 + u * u)
        tau = u / (1 + u * u)
        c, d = Fr(rnd.randint(0, 999), 1000), Fr(rnd.randint(0, 999), 1000)
        for s in (1, -1):
            e = Fr(0)
            for x1, p1 in ((u, q), (-v, 1 - q)):
                for x2, p2 in ((u, q), (-v, 1 - q)):
                    e += p1 * p2 * abs(c * x1 + s * d * x2)
            val = 2 * tau * max(c, d, (1 - q) * (c + d) if s == 1 else Fr(0))
            bad += (e != val)
    return bad


def symbolic_checks():
    import sympy as sp
    x, t = sp.symbols('x t', positive=True)
    f1 = sp.expand(27 * x**4 - 256 * t**3 * (x - t) - (3 * x - 4 * t)**2 * (3 * x**2 + 8 * t * x + 16 * t**2))
    u = sp.symbols('u', positive=True)
    q = 1 / (1 + u**2)
    v = 1 / u
    tau = u / (1 + u**2)
    e1 = sp.simplify(q * u - tau)
    e2 = sp.simplify((1 - q) * v - tau)
    e3 = sp.simplify(q * tau - u / (1 + u**2)**2)
    e4 = sp.simplify((1 - q) * tau - u**3 / (1 + u**2)**2)
    du = sp.factor(sp.diff(u**3 / (1 + u**2)**2, u))
    dq = sp.factor(sp.diff(u / (1 + u**2)**2, u))
    tt = sp.symbols('tt', real=True)
    dcpd = sp.factor(sp.diff((1 - tt**2 + 2 * tt) / (1 + tt**2), tt))
    dcmd = sp.factor(sp.diff((1 - tt**2 - 2 * tt) / (1 + tt**2), tt))
    return f1 == 0 and e1 == 0 and e2 == 0 and e3 == 0 and e4 == 0, (du, dq, dcpd, dcmd)


def main():
    t0 = time.time()
    allok = True
    parts = sys.argv[1] if len(sys.argv) > 1 else 'ABCDEF'
    print("MAIN-2 verifier (RQ-AUD), data:", DATA)
    man = json.load(open(os.path.join(DATA, 'k2_manifest.json')))
    assert Fr(man['U_LO']) == U_LO and Fr(man['U_HI']) == U_HI and Fr(man['T8']) == T8 and Fr(man['A_S']) == A_S
    if 'A' in parts:
        ok1 = (U_LO * U_LO - 1)**2 < 2 and (U_LO + Fr(1, 10**6))**2 > 1 + SQ2_HI
        ok2 = 1 / (1 + U_HI * U_HI) == Fr(1, 5)
        ok3 = (T8 + 1)**2 >= 2 and T8 < 1
        bad = lemma2c_exact()
        okS, ders = symbolic_checks()
        print(f"A  U_LO < u0 < U_LO + 1e-6: {ok1}; q(2) = 1/5: {ok2}; sqrt2-1 <= T8 < 1: {ok3}")
        print(f"A  Lemma 2C value 2 tau max(c, d, [s=+1](1-q)(c+d)) at 8000 random rational points: {bad} mismatches")
        print(f"A  27x^4 - 256t^3(x-t) = (3x-4t)^2(3x^2+8tx+16t^2), q u = (1-q) v = tau, q tau, (1-q) tau: {okS}")
        print(f"A  derivatives (monotonicity used): d/du (1-q)tau = {ders[0]}; d/du q tau = {ders[1]};"
              f" d/dt (c+d) = {ders[2]}; d/dt (c-d) = {ders[3]}")
        allok &= ok1 and ok2 and ok3 and bad == 0 and okS

    one = json.load(open(os.path.join(DATA, 'cover_k2', 'one_A.json')))
    cells = [(Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]) for cl in one['cells']]
    boxes = {1: [], -1: []}
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['s'] in (1, -1) and not d['failed']
        for bx in d['boxes']:
            assert bx['s'] == d['s']
            boxes[d['s']].append((tuple(Fr(x) for x in bx['box']), bx['kind'], [Fr(x) for x in bx['c']] if bx['kind'] == 'lp' else None))
    kinds = {}
    for s in (1, -1):
        for _, k, _ in boxes[s]:
            kinds[k] = kinds.get(k, 0) + 1
    print(f"data: {len(cells)} one-coordinate cells; boxes s=+1: {len(boxes[1])}, s=-1: {len(boxes[-1])}; kinds {kinds}")

    if 'B' in parts:
        reg1 = (U_LO, U_HI, Fr(0), A_S)
        tok, gap = tiles(reg1, [cl[:4] for cl in cells])
        inside = all(reg1[0] <= cl[0] < cl[1] <= reg1[1] and reg1[2] <= cl[2] < cl[3] <= reg1[3] for cl in cells)
        area = sum((cl[1] - cl[0]) * (cl[3] - cl[2]) for cl in cells) == (reg1[1] - reg1[0]) * (reg1[3] - reg1[2])
        print(f"B  one-coordinate cells tile {[str(x) for x in reg1]}: {'OK' if tok else 'GAP ' + str(gap)}; inside {inside}; area equal {area}")
        allok &= tok and inside and area
        reg3 = (U_LO, U_HI, Fr(0), T8, A_S, Fr(1))
        for s in (1, -1):
            ins, voleq, nov = tiling3(reg3, [b[0] for b in boxes[s]])
            print(f"B  s={s:+d}: {len(boxes[s])} boxes inside region {ins}; volume sum == region volume {voleq};"
                  f" pairs with overlapping interiors {nov}  => {'TILING OK' if ins and voleq and nov == 0 else 'TILING FAIL'}", flush=True)
            allok &= ins and voleq and nov == 0

    if 'F' in parts:
        smalls = [(b[0], s) for s in (1, -1) for b in boxes[s] if b[1] == 'small']
        badsm = [bx for bx, s in smalls if not (bx[5] * cfun(bx[2]) <= A_S)]
        print(f"F  'small' boxes: {len(smalls)}; with r2 c(t1) > 9/20: {len(badsm)}")
        allok &= not badsm

    if 'C' in parts:
        from a9_c11_verify import check_cell_rec as cell1
        for name, r2v in (('MINE', R2_MINE), ('RQA-S2', R2_RQA)):
            with Pool(8) as pool:
                res = pool.map(cell1, [(cl[0], cl[1], cl[2], cl[3], cl[4], r2v) for cl in cells], chunksize=4)
            nf = sum(1 for r in res if not r[0])
            for cl, r in zip(cells, res):
                if not r[0]:
                    print(f"   FAIL[{name}] cell u[{float(cl[0]):.6f},{float(cl[1]):.6f}] a[{float(cl[2]):.4f},{float(cl[3]):.4f}]: {r[3]}")
            print(f"C  one-coordinate cells, r2={name}: failures {nf}/{len(cells)}, sub-cells {sum(r[1] for r in res)},"
                  f" max depth {max(r[2] for r in res)}, {time.time() - t0:.0f}s", flush=True)
            allok &= nf == 0

    if 'D' in parts:
        lps = [(b[0], s, b[2]) for s in (1, -1) for b in boxes[s] if b[1] == 'lp']
        for name, r2v in (('MINE', R2_MINE),) if 'R' not in parts else (('MINE', R2_MINE), ('RQA-S2', R2_RQA)):
            with Pool(8) as pool:
                res = pool.map(lp_rec, [(bx, s, c, r2v) for bx, s, c in lps], chunksize=16)
            nf = sum(1 for r in res if not r[0])
            depths = {}
            for r in res:
                if r[0]:
                    depths[r[2]] = depths.get(r[2], 0) + 1
            for (bx, s, c), r in zip(lps, res):
                if not r[0]:
                    print(f"   FAIL[{name}] s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.5f},{float(bx[3]):.5f}]"
                          f" r[{float(bx[4]):.5f},{float(bx[5]):.5f}]: {r[3]}")
            print(f"D  LP boxes, r2={name}: failures {nf}/{len(lps)}; certified at depth {dict(sorted(depths.items()))};"
                  f" sub-boxes {sum(r[1] for r in res)}, {time.time() - t0:.0f}s", flush=True)
            allok &= nf == 0

    if 'E' in parts:
        ncs = [(b[0], s) for s in (1, -1) for b in boxes[s] if b[1].startswith('nc')]
        with Pool(8) as pool:
            res = pool.map(nc_rec, [(bx, s, R2_MINE) for bx, s in ncs], chunksize=16)
        nf = sum(1 for r in res if not r[0])
        how = {}
        for r in res:
            if r[0]:
                how[r[3]] = how.get(r[3], 0) + 1
        for (bx, s), r in zip(ncs, res):
            if not r[0]:
                print(f"   FAIL s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.5f},{float(bx[3]):.5f}]"
                      f" r[{float(bx[4]):.5f},{float(bx[5]):.5f}]: {r[3]}")
        below = sum(1 for bx, s in ncs if (bx[0] * bx[0] - 1)**2 < 2)
        print(f"E  near-circle boxes: failures {nf}/{len(ncs)}; passed by test {how}; sub-boxes {sum(r[1] for r in res)};"
              f" boxes touching the sliver [U_LO, u0) (argument applies only at u >= u0): {below}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0

    print(f"RESULT: {'ALL CHECKS PASSED' if allok else 'FAILURES'} (parts {parts}, {time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
