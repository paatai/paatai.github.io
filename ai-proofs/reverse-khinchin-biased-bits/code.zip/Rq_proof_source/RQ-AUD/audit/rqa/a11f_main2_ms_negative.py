"""Negative tests for RQ-AUD's m-split checks (a11_main2_verify_v2.py, part G) and the three-bit lemma (part H).

Each variant corrupts one ingredient of the 1189 m-split boxes of the 08:27 release; a sound and sensitive checker
must reject every corrupted box where the ingredient is load-bearing.
  V1  p* := phi(m_c) - 1e-9                          (sign lemma violated)       -> reject all
  V2  drop the piece with the largest m2             (cover of [m_c, mtop] lost) -> reject all with m_c < min(1, mbar)
  V3  lower ends of all pieces raised by 1/1000      (gap at m_c)                -> reject all with m_c < min(1, mbar)
  V4  c2 with cap min(1, mbar) but without p*        (p* information dropped)    -> count passes (m-split needed?)
  V5  c1 with cap min(1, mbar)                       (no m-split at all)         -> count passes
  V6  c1 and c2 constant terms lowered by 2e-4, 2e-3, 1e-2, 5e-2 (domination slack) -> count rejections
  V7  target lowered by 1e-4                         (slack)                     -> count rejections
  V8  zero polynomial as certificate                 (domination check non-vacuous) -> reject all
Sharpness of the range end (exact/float evidence):
  S1  E|chi_1 + chi_2 + chi_3|/sqrt3 - S_2 changes sign at q3 (> 0 just below q3, < 0 just above);
  S2  P_f(q) < 0 for f = OR_3 just below q3 and P_f(q) < 0 for f = dictator just above q0 (exact rationals).
"""
import json
import os
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import a11_main2_verify_v2 as W  # noqa: E402

V = W.V


def phi_float(mc):
    return -mc**3 + (1 - mc * mc)**1.5


def job(args):
    box, s, rec, var = args
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = V.b_range(r1, r2)
    mbar = V.mbar_of(t2, r2, blo)
    mc = Fr(rec['mcut'])
    top = min(Fr(1), mbar)
    r = dict(rec)
    if var == 'V1':
        r['p3max'] = str(Fr(phi_float(float(mc))).limit_denominator(10**15) - Fr(1, 10**9))
        return W.ms_check((box, s, r))[0], mc < top
    if var == 'V2':
        pcs = [p for p in rec['pieces'] if p[2] == 1]
        if not pcs:
            return W.ms_check((box, s, r))[0], False
        mx = max(Fr(p[1]) for p in pcs)
        r['pieces'] = [p for p in rec['pieces'] if not (p[2] == 1 and Fr(p[1]) == mx)]
        return W.ms_check((box, s, r))[0], mc < top
    if var == 'V3':
        r['pieces'] = [[str(Fr(p[0]) + Fr(1, 1000)), p[1], p[2], p[3]] for p in rec['pieces']]
        return W.ms_check((box, s, r))[0], mc < top
    T = V.T_lo(u1, u2, V.R2_MINE)
    c1 = [Fr(x) for x in rec['c']]
    c2 = [Fr(x) for x in rec['c2']]
    if var == 'V4':
        return W.moment_ok_p(c2, u1, u2, top, T, None)[0], mc < top
    if var == 'V5':
        return W.dominance_ok(box, s, c1)[0] and W.moment_ok_p(c1, u1, u2, top, T)[0], mc < top
    if var.startswith('V6'):
        dl = {'V6a': Fr(2, 10**4), 'V6b': Fr(2, 10**3), 'V6c': Fr(1, 10**2), 'V6d': Fr(5, 10**2)}[var]
        c1b, c2b = list(c1), list(c2)
        c1b[0] -= dl
        c2b[0] -= dl
        ok1 = W.dominance_ok(box, s, c1b)[0]
        ok2 = W.dominance_ok(box, s, c2b)[0]
        return ok1 and ok2, True
    if var == 'V8':
        return W.dominance_ok(box, s, [Fr(0)] * 7)[0], True
    if var == 'V7':
        T2 = T - Fr(1, 10**4)
        ok = (W.moment_ok_p(c1, u1, u2, min(mc, mbar), T2)[0] and W.moment_ok_p(c2, u1, u2, top, T2, Fr(rec['p3max']))[0])
        return ok, True
    raise ValueError(var)


def sharpness():
    import sympy as sp
    out = []
    q3 = 1 - np.sqrt(2 / 3)
    for dq in (-1e-4, -1e-6, 1e-6, 1e-4):
        q = q3 + dq
        u, v = np.sqrt((1 - q) / q), np.sqrt(q / (1 - q))
        e3 = sum(q**k * (1 - q)**(3 - k) * {0: 1, 1: 3, 2: 3, 3: 1}[k] * abs(k * u - (3 - k) * v) for k in range(4)) / np.sqrt(3)
        s2 = 2 * np.sqrt(2) * (1 - q) * np.sqrt(q * (1 - q))
        out.append(f"S1 q = q3{dq:+.0e}: E|chi1+chi2+chi3|/sqrt3 - S_2 = {e3 - s2:+.3e}")
    qs = sp.Symbol('q')
    pts = [(a, b, c) for a in (0, 1) for b in (0, 1) for c in (0, 1)]

    def P_of(f):
        D = []
        for i in range(3):
            e = 0
            for x in pts:
                w = 1
                for j in range(3):
                    if j != i:
                        w *= qs if x[j] else (1 - qs)
                e += (f[x] if x[i] else -f[x]) * w
            D.append(e)
        return sp.expand(8 * (1 - qs)**2 - sum(d * d for d in D))

    or3 = {x: (1 if any(x) else -1) for x in pts}
    dic = {x: (1 if x[0] else -1) for x in pts}
    p_or3, p_dic = P_of(or3), P_of(dic)
    for name, P, qv in (('OR_3', p_or3, sp.Rational(18350, 100000)), ('OR_3', p_or3, sp.Rational(18351, 100000)),
                        ('dictator', p_dic, sp.Rational(29289, 100000)), ('dictator', p_dic, sp.Rational(29290, 100000))):
        out.append(f"S2 P_{name}({qv}) = {float(P.subs(qs, qv)):+.3e}")
    return out


def main():
    t0 = time.time()
    man = json.load(open(os.path.join(W.D_NEW, 'k2_manifest.json')))
    mss = []
    for fn in man['two_files']:
        d = json.load(open(W.path_of(fn)))
        for bx in d['boxes']:
            if bx['kind'] == 'ms':
                mss.append((tuple(Fr(x) for x in bx['box']), d['s'], bx))
    print(f"{len(mss)} m-split boxes")
    with Pool(8) as pool:
        for var in ('V1', 'V2', 'V3', 'V4', 'V5', 'V6a', 'V6b', 'V6c', 'V6d', 'V7', 'V8'):
            res = pool.map(job, [(b, s, r, var) for b, s, r in mss], chunksize=8)
            rel = [ok for ok, needed in res if needed]
            print(f"{var}: boxes where the ingredient is load-bearing {len(rel)}; passed {sum(rel)}, rejected {len(rel) - sum(rel)}"
                  f"; ({time.time() - t0:.0f}s)", flush=True)
    for line in sharpness():
        print(line)


if __name__ == '__main__':
    main()
