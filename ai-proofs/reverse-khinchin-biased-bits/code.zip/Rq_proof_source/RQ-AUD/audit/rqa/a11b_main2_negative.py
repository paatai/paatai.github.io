"""Negative tests and cross-checks for the RQ-AUD MAIN-2 verifier (a11_main2_verify.py).

1. Second exact method: sympy Sturm counts replace the Arb root isolation on a random sample of LP boxes.
2. Semantic test of the envelope: at random points of random LP boxes, the true F(y) = sum_j |X_j + B_j y|
   (float) is <= my envelope F_box(y) and <= P(y).
3. Corrupted LP certificates (depth 0): P*0.9, c0 - eps, c6 = 0, wrong sign s, enlarged boxes, lowered target.
4. Slack: float margins of dominance and of the moment bound for every LP box; the tightest boxes are re-run with
   c0 lowered by 0.5x and 2x their dominance/moment slack.
5. Near-circle boxes: lowered target, enlarged boxes (r1 - 1/10, t-range doubled).
6. Tiling: one box removed, one duplicated, one shifted.
7. One-coordinate cells: P*0.9, c0 - 1e-5, a2 + 1/100, lowered target.
"""
import json
import os
import random
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np
import sympy as sp

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import a11_main2_verify as V  # noqa: E402

rnd = random.Random(20261022)
xs = sp.Symbol('x')


def cauchy_bound(coeffs):
    cs = list(coeffs)
    while cs[-1] == 0:
        cs.pop()
    return 1 + max(abs(c) for c in cs[:-1]) / abs(cs[-1])


def sturm_positive_on(coeffs, lo=None, hi=None):
    cs = list(coeffs)
    while cs and cs[-1] == 0:
        cs.pop()
    Bd = cauchy_bound(cs)
    lo2 = -Bd - 1 if lo is None else lo
    hi2 = Bd + 1 if hi is None else hi
    P = sp.Poly([sp.Rational(c.numerator, c.denominator) for c in reversed(cs)], xs)
    n = P.count_roots(sp.Rational(lo2.numerator, lo2.denominator), sp.Rational(hi2.numerator, hi2.denominator))
    if n:
        return False, f"{n} roots"
    mid = (lo2 + hi2) / 2
    return sum(c * mid**k for k, c in enumerate(cs)) > 0, ""


def sturm_job(args):
    V.positive_on = sturm_positive_on
    return V.lp_once(*args)


def load():
    man = json.load(open(os.path.join(V.DATA, 'k2_manifest.json')))
    boxes = []
    for fn in man['two_files']:
        d = json.load(open(os.path.join(V.DATA, fn)))
        for bx in d['boxes']:
            boxes.append((tuple(Fr(x) for x in bx['box']), d['s'], bx['kind'], [Fr(x) for x in bx['c']] if bx['kind'] == 'lp' else None))
    one = json.load(open(os.path.join(V.DATA, 'cover_k2', 'one_A.json')))
    cells = [(Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]) for cl in one['cells']]
    return boxes, cells


def lp0(args):
    return V.lp_once(*args)[0]


def nc0(args):
    return V.nc_once(*args)[0]


def F_true(y, u, t, r, s):
    q = 1 / (1 + u * u)
    v = 1 / u
    c, d = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)
    b = np.sqrt(max(0.0, 1 - r * r))
    tot = np.zeros_like(y)
    for x1, p1 in ((u, q), (-v, 1 - q)):
        for x2, p2 in ((u, q), (-v, 1 - q)):
            tot += p1 * p2 * np.abs(r * (c * x1 + s * d * x2) + b * y)
    return tot


def env_float(y, pieces):
    out = np.full_like(y, -np.inf)
    for lo, hi, ic, sl in pieces:
        out = np.maximum(out, float(ic) + float(sl) * y)
    return out


def semantic_job(args):
    box, s, c, seed = args
    rg = np.random.default_rng(seed)
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = V.b_range(r1, r2)
    X = V.atoms_X(u1, u2, t1, t2, r1, r2, s)
    B = [(p[0] * blo, p[1] * bhi) for p in V.r_probs(u1, u2)]
    pieces = V.envelope_pieces(X, B)
    y = np.concatenate([np.linspace(-12, 12, 2401), np.array([-200.0, -60, -30, 30, 60, 200])])
    Py = np.polyval([float(x) for x in c[::-1]], y)
    Fb = env_float(y, pieces)
    worst_env, worst_P = -np.inf, np.inf
    for _ in range(12):
        u = float(u1) + rg.random() * float(u2 - u1)
        t = float(t1) + rg.random() * float(t2 - t1)
        r = float(r1) + rg.random() * float(r2 - r1)
        Ft = F_true(y, u, t, r, s)
        worst_env = max(worst_env, float(np.max(Ft - Fb)))
        worst_P = min(worst_P, float(np.min(Py - Ft)))
    return worst_env, worst_P


def slack_job(args):
    box, s, c = args
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = V.b_range(r1, r2)
    X = V.atoms_X(u1, u2, t1, t2, r1, r2, s)
    B = [(p[0] * blo, p[1] * bhi) for p in V.r_probs(u1, u2)]
    cf = np.array([float(x) for x in c])
    dom = np.inf
    for lo, hi, ic, sl in V.envelope_pieces(X, B):
        a = -40.0 if lo is None else float(lo)
        b = 40.0 if hi is None else float(hi)
        y = np.linspace(a, b, 3001)
        g = np.polyval(cf[::-1], y) - (float(ic) + float(sl) * y)
        i = int(np.argmin(g))
        yy = np.linspace(y[max(i - 1, 0)], y[min(i + 1, len(y) - 1)], 2001)
        g2 = np.polyval(cf[::-1], yy) - (float(ic) + float(sl) * yy)
        dom = min(dom, float(g.min()), float(g2.min()))
    k3, k4, k5, k6, k3sq = V.kappa_ranges(u1, u2)
    c0, c1, c2, c3, c4, c5, c6 = c
    A = c0 + c2 + 3 * c4 + 15 * c6
    Babs = max(abs(x) for x in V.imul(k3, c3 + 10 * c5))
    Chi = V.imul(k4, c4 + 15 * c6)[1]
    Dabs = max(abs(x) for x in V.imul(k5, c5))
    Ehi = V.imul(k6, c6)[1]
    Fhi = max(V.imul(k3sq, 10 * c6)[1], 0)
    mbar = V.mbar_of(t2, r2, blo)
    G = Chi + Dabs * mbar + Fhi + (Ehi * mbar * mbar if Ehi > 0 else 0)
    Eneg = Ehi if Ehi < 0 else Fr(0)
    T = V.T_lo(u1, u2, V.R2_MINE)
    rho = np.linspace(0, float(mbar), 4001)
    h = float(T - A) - float(Babs) * rho - float(G) * rho**2 - float(Eneg) * rho**4
    return dom, float(h.min())


def rate(res):
    return f"{sum(1 for r in res if not r)}/{len(res)} rejected"


def main():
    t0 = time.time()
    boxes, cells = load()
    lps = [(b[0], b[1], b[3]) for b in boxes if b[2] == 'lp']
    ncs = [(b[0], b[1]) for b in boxes if b[2].startswith('nc')]
    print(f"loaded {len(lps)} LP boxes, {len(ncs)} NC boxes, {len(cells)} cells ({time.time() - t0:.0f}s)", flush=True)

    # 1. Sturm cross-check on a sample
    samp = rnd.sample(lps, 400)
    with Pool(8) as pool:
        res = pool.map(sturm_job, [(bx, s, c, V.R2_MINE) for bx, s, c in samp], chunksize=4)
    print(f"1. Sturm (sympy count_roots) instead of Arb on {len(samp)} random LP boxes: {sum(1 for r in res if not r[0])} failures ({time.time() - t0:.0f}s)", flush=True)

    # 2. semantic test
    samp = rnd.sample(lps, 3000)
    with Pool(8) as pool:
        res = pool.map(semantic_job, [(bx, s, c, i) for i, (bx, s, c) in enumerate(samp)], chunksize=16)
    we = max(r[0] for r in res)
    wp = min(r[1] for r in res)
    print(f"2. semantic: 3000 LP boxes x 12 random points x 2407 y: max(F_true - F_box) = {we:.3e} (must be <= ~1e-15);"
          f" min(P - F_true) = {wp:.3e} (must be > 0) ({time.time() - t0:.0f}s)", flush=True)

    # 3. corrupted LP certificates
    samp = rnd.sample(lps, 2000)
    tests = []
    tests.append(("P*0.9", [(bx, s, [x * Fr(9, 10) for x in c], V.R2_MINE) for bx, s, c in samp]))
    for eps in (Fr(1, 10**3), Fr(1, 10**5), Fr(1, 10**7)):
        tests.append((f"c0-{float(eps):.0e}", [(bx, s, [c[0] - eps] + c[1:], V.R2_MINE) for bx, s, c in samp]))
    tests.append(("c6=0", [(bx, s, c[:6] + [Fr(0)], V.R2_MINE) for bx, s, c in samp]))
    tests.append(("wrong sign s", [(bx, -s, c, V.R2_MINE) for bx, s, c in samp]))
    tests.append(("r1-1/20", [((bx[0], bx[1], bx[2], bx[3], max(Fr(0), bx[4] - Fr(1, 20)), bx[5]), s, c, V.R2_MINE) for bx, s, c in samp]))
    tests.append(("t-range x2", [((bx[0], bx[1], max(Fr(0), 2 * bx[2] - bx[3]), bx[3], bx[4], bx[5]), s, c, V.R2_MINE) for bx, s, c in samp]))
    tests.append(("u2+1/20", [((bx[0], bx[1] + Fr(1, 20), bx[2], bx[3], bx[4], bx[5]), s, c, V.R2_MINE) for bx, s, c in samp]))
    for r2v in (Fr(14142, 10**4), Fr(14141, 10**4), Fr(1414, 1000), Fr(141, 100)):
        tests.append((f"target sqrt2 -> {float(r2v)}", [(bx, s, c, r2v) for bx, s, c in samp]))
    with Pool(8) as pool:
        for name, args in tests:
            res = pool.map(lp0, args, chunksize=16)
            print(f"3. LP corruption {name}: {rate(res)}", flush=True)

    # 4. slack of all LP boxes; tightest boxes re-run with c0 lowered
    with Pool(8) as pool:
        sl = pool.map(slack_job, lps, chunksize=32)
    dom = np.array([x[0] for x in sl])
    mom = np.array([x[1] for x in sl])
    print(f"4. float slack over all {len(lps)} LP boxes: dominance min {dom.min():.3e}, 1% quantile {np.quantile(dom, 0.01):.3e},"
          f" median {np.median(dom):.3e}; moment min {mom.min():.3e}, 1% quantile {np.quantile(mom, 0.01):.3e}, median {np.median(mom):.3e}"
          f" ({time.time() - t0:.0f}s)", flush=True)
    ib = int(np.argmin(dom))
    im = int(np.argmin(mom))
    for lab, i in (("tightest dominance", ib), ("tightest moment", im)):
        bx, s, c = lps[i]
        print(f"   {lab}: s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.6f},{float(bx[3]):.6f}] r[{float(bx[4]):.6f},{float(bx[5]):.6f}]"
              f" dom slack {dom[i]:.3e}, moment slack {mom[i]:.3e}")
    order = np.argsort(np.minimum(dom, mom))[:200]
    half, dbl = [], []
    for i in order:
        bx, s, c = lps[i]
        e = min(dom[i], mom[i])
        if e <= 0:
            continue
        # lowering c0 by e decreases P - piece by e and increases T - A by e: affects dominance only
        half.append((bx, s, [c[0] - Fr(e * 0.5).limit_denominator(10**18)] + c[1:], V.R2_MINE))
        dbl.append((bx, s, [c[0] - Fr(dom[i] * 2.0).limit_denominator(10**18)] + c[1:], V.R2_MINE))
    with Pool(8) as pool:
        r1 = pool.map(lp0, half, chunksize=4)
        r2 = pool.map(lp0, dbl, chunksize=4)
    print(f"   200 tightest boxes: c0 lowered by 0.5 x min slack -> {sum(r1)}/{len(r1)} still pass;"
          f" c0 lowered by 2 x dominance slack -> {rate(r2)}", flush=True)
    upm = []
    for i in np.argsort(mom)[:200]:
        bx, s, c = lps[i]
        upm.append((bx, s, [c[0] + Fr(float(mom[i]) * 2.0).limit_denominator(10**18)] + c[1:], V.R2_MINE))
    with Pool(8) as pool:
        r3 = pool.map(lp0, upm, chunksize=4)
    print(f"   200 tightest moment margins: c0 raised by 2 x moment slack -> {rate(r3)}", flush=True)

    # 5. NC corruptions
    tests = [("target sqrt2 -> 1.41", [(bx, s, Fr(141, 100)) for bx, s in ncs]),
             ("target sqrt2 -> 1.4", [(bx, s, Fr(14, 10)) for bx, s in ncs]),
             ("target sqrt2 -> 1.3", [(bx, s, Fr(13, 10)) for bx, s in ncs]),
             ("r1-1/10", [((bx[0], bx[1], bx[2], bx[3], bx[4] - Fr(1, 10), bx[5]), s, V.R2_MINE) for bx, s in ncs]),
             ("r1-1/40", [((bx[0], bx[1], bx[2], bx[3], bx[4] - Fr(1, 40), bx[5]), s, V.R2_MINE) for bx, s in ncs]),
             ("t-range x2", [((bx[0], bx[1], max(Fr(0), 2 * bx[2] - bx[3]), bx[3], bx[4], bx[5]), s, V.R2_MINE) for bx, s in ncs])]
    with Pool(8) as pool:
        for name, args in tests:
            res = pool.map(nc0, args, chunksize=16)
            print(f"5. NC corruption {name}: {rate(res)}", flush=True)

    # 6. tiling corruptions
    reg3 = (V.U_LO, V.U_HI, Fr(0), V.T8, V.A_S, Fr(1))
    for s in (1, -1):
        bs = [b[0] for b in boxes if b[1] == s]
        k = rnd.randrange(len(bs))
        rm = bs[:k] + bs[k + 1:]
        dup = bs + [bs[k]]
        bx = bs[k]
        sh = bs[:k] + [(bx[0] + Fr(1, 10**6), bx[1] + Fr(1, 10**6)) + bx[2:]] + bs[k + 1:]
        out = []
        for lab, bb in (("removed", rm), ("duplicated", dup), ("shifted u by 1e-6", sh)):
            ins, voleq, nov = V.tiling3(reg3, bb)
            out.append(f"{lab}: inside {ins}, volume {voleq}, overlaps {nov} -> {'REJECTED' if not (ins and voleq and nov == 0) else 'ACCEPTED'}")
        print(f"6. tiling s={s:+d}: " + '; '.join(out), flush=True)

    # 7. one-coordinate cells
    from a9_c11_verify import check_cell_rec as cell1
    tests = [("P*0.9", [(cl[0], cl[1], cl[2], cl[3], [x * Fr(9, 10) for x in cl[4]], V.R2_MINE) for cl in cells]),
             ("c0-1e-5", [(cl[0], cl[1], cl[2], cl[3], [cl[4][0] - Fr(1, 10**5)] + cl[4][1:], V.R2_MINE) for cl in cells]),
             ("a2+1/100", [(cl[0], cl[1], cl[2], cl[3] + Fr(1, 100), cl[4], V.R2_MINE) for cl in cells]),
             ("target sqrt2 -> 1.414", [(cl[0], cl[1], cl[2], cl[3], cl[4], Fr(1414, 1000)) for cl in cells]),
             ("target sqrt2 -> 1.41", [(cl[0], cl[1], cl[2], cl[3], cl[4], Fr(141, 100)) for cl in cells])]
    with Pool(8) as pool:
        for name, args in tests:
            res = pool.starmap(cell1, [(a, 0, 0) for a in args], chunksize=4)
            print(f"7. one-coordinate cells {name} (depth 0): {rate([r[0] for r in res])}", flush=True)
    print(f"done ({time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
