"""MAIN-6 text check (own code): the printed cumulant polynomials G_3..G_10 of Lemma cum in MAIN_RESULT_K5.tex,
kappa_j = d^[j odd] G_j(w), w = u^2 + v^2, d = u - v, v = 1/u, against cumulants computed here from the moments
m_k = (u^k + (-1)^k u^(2-k))/(1+u^2) by the moment-cumulant recursion; also m_3 = u - v, m_4 = w - 1, and the
position of the critical point of G_9 (u ~ 2.926) and that G_j' (j != 9) has no root for u in [U_-, U_+]."""
import sympy as sp
u = sp.symbols('u', positive=True)
v = 1 / u
w = sp.symbols('w')
m = {k: (u ** k + (-1) ** k * u ** (2 - k)) / (1 + u ** 2) for k in range(0, 13)}
kap = {}
for n in range(1, 11):
    kap[n] = sp.simplify(m[n] - sum(sp.binomial(n - 1, k - 1) * kap[k] * m[n - k] for k in range(1, n)))
G = {3: 1 + 0 * w, 4: w - 4, 5: w - 10, 6: w ** 2 - 26 * w + 64, 7: w ** 2 - 56 * w + 244,
     8: w ** 3 - 120 * w ** 2 + 1188 * w - 2176, 9: w ** 3 - 246 * w ** 2 + 4044 * w - 11080,
     10: w ** 4 - 502 * w ** 3 + 14604 * w ** 2 - 86728 * w + 126976}
ok = True
print('kappa_1 = 0:', sp.simplify(kap[1]) == 0, ' kappa_2 = 1:', sp.simplify(kap[2] - 1) == 0)
ok &= sp.simplify(kap[1]) == 0 and sp.simplify(kap[2] - 1) == 0
print('m_3 = u - v:', sp.simplify(m[3] - (u - v)) == 0, ' m_4 = w - 1:', sp.simplify(m[4] - (u ** 2 + v ** 2 - 1)) == 0)
for j in range(3, 11):
    target = (u - v) ** (j % 2) * G[j].subs(w, u ** 2 + v ** 2)
    good = sp.simplify(sp.together(kap[j] - target)) == 0
    ok &= good
    print(f'G_{j} as printed: {good}')
U_lo, U_hi = sp.Rational(29106, 10000), sp.Rational(3236855, 1000000)
wlo, whi = U_lo ** 2 + U_lo ** -2, U_hi ** 2 + U_hi ** -2
for j in range(4, 11):
    Gp = sp.Poly(sp.diff(G[j], w), w)
    roots = [r for r in sp.Poly(Gp, w).real_roots() if wlo <= r <= whi] if Gp.degree() > 0 else []
    us = [sp.N(sp.sqrt((r + sp.sqrt(r ** 2 - 4)) / 2), 8) for r in roots]
    print(f"G_{j}': roots with w in [w(U_-), w(U_+)] = {[sp.N(r, 10) for r in roots]} (u = {us})")
    if j == 9:
        ok &= len(roots) == 1 and abs(us[0] - 2.926) < 0.001
    else:
        ok &= len(roots) == 0
print('ALL CHECKS PASSED' if ok else 'FAILURES')
