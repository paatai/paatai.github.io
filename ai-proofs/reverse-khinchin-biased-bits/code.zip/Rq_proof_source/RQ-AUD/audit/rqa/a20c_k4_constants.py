"""RQ-AUD pre-audit of the elementary facts of MAIN_RESULT_K4.tex (Theorem 5 (c), Lemma kvec, Corollary combined,
the constants U-, U+, T8, w-).  Exact rationals and sympy; own code."""
from fractions import Fraction as Fr

import sympy as sp

ok = True
q, u = sp.symbols('q u', positive=True)
tau = sp.sqrt(q * (1 - q))
T = {k: 2 * sp.sqrt(k) * (1 - q)**(k - 1) * tau for k in (1, 2, 3, 4, 5)}
q4 = 1 - sp.sqrt(3) / 2
q5 = 1 - 2 / sp.sqrt(5)

# Lemma kvec (i), (ii): T3/T4 = sqrt3/(2(1-q)), T5/T4 = (sqrt5/2)(1-q)
r34 = sp.simplify(T[3] / T[4])
r54 = sp.simplify(T[5] / T[4])
ok &= sp.simplify(r34 - sp.sqrt(3) / (2 * (1 - q))) == 0 and sp.simplify(r54 - sp.sqrt(5) * (1 - q) / 2) == 0
ok &= sp.solve(sp.Eq(r34, 1), q) == [q4] and sp.solve(sp.Eq(r54, 1), q) == [q5]
print("kvec (i), (ii): T3/T4 =", r34, " T5/T4 =", r54, " ratio 1 only at q4 resp. q5:", ok)

# Theorem 5 (c): T5 > T4 on (0, q5) with q5 < 1/5; T3 > T4 on (q4, 1/3); 2 tau > T4 on [1/3, 1/2]
qc = 1 - sp.Rational(1, 2)**sp.Rational(1, 3)
okc = bool(q5 < sp.Rational(1, 5)) and bool(q4 < sp.Rational(1, 3)) and bool(qc < sp.Rational(1, 3))
okc &= sp.solve(sp.Eq(2 * (1 - q)**3, 1), q) == [qc]
print(f"Theorem 5(c): q5 = {float(q5):.6f} < 1/5, q4 = {float(q4):.6f} < 1/3, 2(1-q)^3 = 1 at q = "
      f"{float(qc):.6f} < 1/3: {okc}")
ok &= okc

# parametrisation: T4 = 4u^7/(1+u^2)^4 and its derivative; u4^2 = 3 + 2 sqrt3, u5^2 = 4 + 2 sqrt5
qu = 1 / (1 + u**2)
T4u = sp.simplify((4 * (1 - q)**3 * tau).subs(q, qu))
d = sp.factor(sp.diff(u**7 / (1 + u**2)**4, u))
okp = sp.simplify(T4u - 4 * u**7 / (1 + u**2)**4) == 0 and sp.simplify(d - u**6 * (7 - u**2) / (1 + u**2)**5) == 0
okp &= sp.simplify((1 - q4) / q4 - (3 + 2 * sp.sqrt(3))) == 0 and sp.simplify((1 - q5) / q5 - (4 + 2 * sp.sqrt(5))) == 0
print("T4(u) = 4u^7/(1+u^2)^4, derivative u^6(7-u^2)/(1+u^2)^5, u4^2 = 3+2sqrt3, u5^2 = 4+2sqrt5:", okp)
ok &= okp

# constants
Um, Up, T8 = Fr(1589, 625), Fr(29107, 10000), Fr(20711, 50000)
okk = Um**2 > 3 and (Um**2 - 3)**2 <= 12 and Up**2 > 4 and (Up**2 - 4)**2 >= 20 and (T8 + 1)**2 >= 2
wm = Um**2 / (1 + Um**2)
okk &= wm**4 >= Fr(1, 2) and 2 * wm**3 >= 1 and Um >= 2
u4 = sp.sqrt(3 + 2 * sp.sqrt(3))
u5 = sp.sqrt(4 + 2 * sp.sqrt(5))
print(f"U- = {float(Um)} <= u4 = {float(u4):.9f} (gap {float(u4 - sp.Rational(1589, 625)):.2e}); U+ = {float(Up)} >= "
      f"u5 = {float(u5):.9f} (gap {float(sp.Rational(29107, 10000) - u5):.2e}); (T8+1)^2 >= 2; w- = {float(wm):.9f}, "
      f"w-^4 = {float(wm**4):.6f}, 2 w-^3 = {float(2 * wm**3):.6f}: {okk}")
ok &= okk

# Corollary combined: on [q5, q4] 2(1-q)^3 is the largest of {1, sqrt2(1-q), sqrt3(1-q)^2, 2(1-q)^3}; k >= 5 terms
okC = Fr(3, 4)**2 > Fr(1, 2) and 4 * Fr(27, 64) > 1
seq = [Fr(k, 4) * Fr(4, 5)**(k - 4) for k in range(5, 60)]
okC &= seq[0] == 1 and all(b < a for a, b in zip(seq, seq[1:]))
print("Corollary combined: (3/4)^2 > 1/2, 2 (3/4)^(3/2) > 1, (k/4)(4/5)^(k-4) = 1 at k = 5 and decreasing:", okC)
ok &= okC

print("RESULT:", "ALL CHECKS PASSED" if ok else "FAILURES")
