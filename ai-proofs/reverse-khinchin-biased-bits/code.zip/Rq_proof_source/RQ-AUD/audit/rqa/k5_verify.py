"""RQ-AUD independent verifier for RQ-A's MAIN-6 (Theorem 6 of MAIN_RESULT_K5, u in [29106/10000, 3236855/1000000]):
    E|sum alpha_i chi_i| <= T5 = 2 sqrt5 (1-q)^4 tau  for every unit alpha and every q in [q6, q5].

RQ-A code is not used. The k-independent parts are my own helpers from A.6, A.11, A.18 and A.25 (exact tilings,
positivity by certified root isolation, the ten-moment objective bound, the dual-functional cone test, atom
enclosures, vertex envelopes, cap and phi checks). New here:
 - target T5(u) = 2 sqrt5 u^9/(1+u^2)^5; d/du u^9/(1+u^2)^5 = u^8 (9-u^2)/(1+u^2)^6, so T5 is unimodal and its
   minimum over [u1, u2] is the smaller end value; sqrt5 is replaced by a rational lower bound (10^-30);
 - cumulant enclosures without a monotonicity assumption: kappa_9 has a critical point in [U_LO, U_HI]. Every root
   of kappa_j' there is enclosed in a certified rational interval (Arb ball, refined by exact bisection), kappa_j is
   monotone between them, and on a root interval [x1, x2] it stays within kappa_j(x1) +- L_j (x2 - x1), L_j a
   rational bound of |kappa_j'| on [U_LO, U_HI]. The objective bound of A.18 is run with these enclosures;
 - patches with any number j of peeled coordinates: h.p = r (h1 c + h2 d) + b0 w0, w_{i-1} = h_{i+2} mu_i +
   sqrt(1-mu_i^2) w_i, w_j = h_{k+1}; the minimum is taken innermost first (the weights are >= 0, so a lower bound
   of an inner minimum is a valid input outside);
 - split nodes of any level, walked recursively: cut certificate, plus pieces A_n/B_n, TC+, TCN (child node with
   its own range), TCS; minus pieces SG, TC-; every cap, cut, phi and cover condition checked exactly;
 - near-sphere tests with n = 3, 4, 5, 6 coordinates; (A_n) with n >= 5 also requires s = 1 and
   a_i^- > q^+ sum_l a_l^+ (the OR-region condition).
Parts: M md5s, A elementary facts, B tilings, C one-coordinate cells, D vertex certificates, F split trees and
near-sphere pieces. The bit lemmas are A.22 (`a22_k5_bits.py`).
"""
import glob
import hashlib
import json
import os
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import a11_main2_verify as V  # noqa: E402
import a18_k3b_verify as K3B  # noqa: E402
import a25_k4_verify as K4  # noqa: E402
from a6_lemmaS_verify import positive_on, real_roots_q, sqrt_hi, sqrt_lo, tiles  # noqa: E402
from moments10 import KAP, leval  # noqa: E402

DATA = os.environ.get('K5_DATA', os.path.join(HERE, 'k5_data'))
U_LO, U_HI, T8, A_S = Fr(29106, 10000), Fr(3236855, 1000000), Fr(20711, 50000), Fr(1, 4)
K27 = Fr(27, 128)
NJ = 10
S5_LO = sqrt_lo(Fr(5))
MAX_CONE_BOXES = int(os.environ.get('K5_CONE_BOXES', '256'))


def T5n(u):
    """T5(u) / sqrt5"""
    return 2 * u**9 / (1 + u * u)**5


def T5_lo(u1, u2):
    return S5_LO * min(T5n(u1), T5n(u2))


def theta1_5(u1, u2, a_hi):
    om1 = u1 * u1 / (1 + u1 * u1)
    return u2 / (1 + u2 * u2) * (S5_LO * om1**4 - a_hi)


# ---------------------------------------------------------------- cumulant enclosures
def _deriv_coeffs(lp):
    """u^N kappa'(u) as a coefficient list (low -> high) for the Laurent polynomial kappa = sum c_e u^e"""
    d = {e - 1: e * c for e, c in lp.items() if e != 0}
    lo = min(d)
    out = [Fr(0)] * (max(d) - lo + 1)
    for e, c in d.items():
        out[e - lo] += c
    return out


def _peval(cs, x):
    acc = Fr(0)
    for c in reversed(cs):
        acc = acc * x + c
    return acc


def _refine(cs, a, b, steps=110):
    fa, fb = _peval(cs, a), _peval(cs, b)
    if fa == 0:
        return a, a
    if fb == 0:
        return b, b
    if (fa > 0) == (fb > 0):
        return a, b
    for _ in range(steps):
        m = (a + b) / 2
        fm = _peval(cs, m)
        if fm == 0:
            return m, m
        if (fm > 0) == (fa > 0):
            a, fa = m, fm
        else:
            b = m
    return a, b


CRIT, LIP = {}, {}
for _j in range(3, NJ + 1):
    _cs = _deriv_coeffs(KAP[_j])
    CRIT[_j] = [_refine(_cs, a, b) for a, b in real_roots_q(_cs) if b >= U_LO and a <= U_HI]
    LIP[_j] = sum(abs(e * c) * max(U_LO**(e - 1), U_HI**(e - 1)) for e, c in KAP[_j].items() if e != 0)


def kap_iv5(j, u1, u2):
    """rational enclosure of kappa_j on [u1, u2] within [U_LO, U_HI]"""
    assert U_LO <= u1 <= u2 <= U_HI
    lp = KAP[j]
    a, b = leval(lp, u1), leval(lp, u2)
    lo, hi = min(a, b), max(a, b)
    for c1, c2 in CRIT[j]:
        x1, x2 = max(c1, u1), min(c2, u2)
        if x1 > x2:
            continue
        f1, e = leval(lp, x1), LIP[j] * (x2 - x1)
        lo, hi = min(lo, f1 - e), max(hi, f1 + e)
    return lo, hi


K3B.kap_iv = kap_iv5


# ---------------------------------------------------------------- C: one-coordinate cells
def cell_once5(u1, u2, a1, a2, c):
    if len(c) - 1 > NJ:
        return False, "degree"
    bh = sqrt_hi(1 - a1 * a1)
    s1 = u2 * u2 / (1 + u2 * u2)
    s2 = 1 / (1 + u1 * u1)
    P = list(c)
    ok, why = positive_on(P)
    if not ok:
        return False, "P > 0: " + why
    ok, why = positive_on([P[0] + s1 * a1 / u2, P[1] - s1 * bh] + P[2:], lo=(a1 / u2) / bh)
    if not ok:
        return False, "P > l1: " + why
    ok, why = positive_on([P[0] + s2 * a1 * u1, P[1] + s2 * bh] + P[2:], hi=-(a1 * u1) / bh)
    if not ok:
        return False, "P > l2: " + why
    b2 = sqrt_lo(1 - a2 * a2)
    mh = min(Fr(1), a2 / b2)
    T = theta1_5(u1, u2, a2)
    if T <= 0:
        return False, "Theta1 <= 0"
    return K3B.objective_ok(c, u1, u2, mh, T)


def cell_job(args):
    return cell_once5(*args)


# ---------------------------------------------------------------- D: vertex certificates
def patch_dot_lo5(h, box):
    """lower bound of h . p_k over a parameter box ((t), (r), (mu_1), ..., (mu_j))"""
    (t1, t2), (r1, r2) = box[0], box[1]
    g = K3B.sin_min_t(h[0], h[1], t1, t2)
    j = len(box) - 2
    w = h[j + 2]
    for i in range(j, 0, -1):
        w = K3B.sin_min_m(h[i + 1], w, box[i + 1][0], box[i + 1][1])

    def f_lo(r):
        s2 = 1 - r * r
        s = (sqrt_lo(s2) if w >= 0 else sqrt_hi(s2)) if s2 > 0 else Fr(0)
        return g * r + w * s
    lo = min(f_lo(r1), f_lo(r2))
    if w < 0 and g < 0:
        rs2 = g * g / (g * g + w * w)
        if r1 * r1 <= rs2 <= r2 * r2:
            lo = min(lo, -sqrt_hi(g * g + w * w))
    return lo


def cone_contains5(X, H, n0, max_boxes=MAX_CONE_BOXES):
    assert all(0 <= a <= b <= 1 for a, b in X)
    stack, used = [tuple(X)], 0
    while stack:
        box = stack.pop()
        used += 1
        if used > max_boxes:
            return False, used
        if patch_dot_lo5(n0, box) > 0 and all(patch_dot_lo5(h, box) >= 0 for h in H):
            continue
        w = [b - a for a, b in box]
        i = max(range(len(box)), key=lambda j: w[j])
        if w[i] == 0:
            return False, used
        mid = (box[i][0] + box[i][1]) / 2
        for half in ((box[i][0], mid), (mid, box[i][1])):
            nb = list(box)
            nb[i] = half
            stack.append(tuple(nb))
    return True, used


def vjob_check5(job):
    name, rec, X, sig, box, cap, p3max = job
    u1, u2 = box[0], box[1]
    n0 = [Fr(x) for x in rec['n0']]
    Vs = [[Fr(x) for x in v] for v in rec['V']]
    Cs = [[Fr(x) for x in cc] for cc in rec['C']]
    if (len(sig) != len(X) or len(n0) != len(X) + 1 or any(len(v) != len(X) + 1 for v in Vs) or len(Cs) != len(Vs)
            or len(Vs) != 2**len(X)):
        return False, name + " shape", 0
    if not (0 < cap <= 1) or (p3max is not None and not p3max < 0):
        return False, name + " cap/p*", 0
    H, why = K3B.cone_functionals(n0, Vs)
    if H is None:
        return False, name + " " + why, 0
    ok, used = cone_contains5(X, H, n0)
    if not ok:
        return False, f"{name} cone ({used} sub-boxes)", used
    T = T5_lo(u1, u2)
    for v, c in zip(Vs, Cs):
        ok, why = K4.vertex_ok4(c, v, sig, u1, u2, cap, T, p3max)
        if not ok:
            return False, f"{name} {why}", used
    return True, name, used


def box_basics(bx):
    box = tuple(Fr(x) for x in bx['box'])
    u1, u2, t1, t2, r1, r2 = box
    blo, _ = V.b_range(r1, r2)
    mb = V.mbar_of(t2, r2, blo)
    return box, blo, mb


def vertex_jobs5(bx):
    """all vertex-certificate sets of a box; parameter box, sign vector, cap and p* come from the tree position"""
    box, blo, mb = box_basics(bx)
    s = bx['s']
    X0 = ((box[2], box[3]), (box[4], box[5]))
    if bx['kind'] == 'lpv':
        return [('lpv', bx, X0, (1, s), box, mb, None)], []
    if bx['kind'] != 'ms':
        return [], ['kind ' + str(bx['kind'])]
    jobs, bad = [], []

    def node(nd, X, sig, khat, lev):
        jobs.append((f'L{lev} cut', nd['c1'], X, sig, box, Fr(nd['mc']), None))
        for pc in nd['plus']:
            n1, n2 = Fr(pc['m'][0]), Fr(pc['m'][1])
            Xn = X + ((n1, n2),)
            tp = pc['type']
            if tp[0] in 'AB':
                continue
            cap = Fr(pc['cap'])
            if not K3B.cap_after(n2, cap):
                bad.append(f'L{lev} {tp} cap')
            if tp == 'TC':
                jobs.append((f'L{lev} TC+', pc, Xn, sig + (1,), box, cap, None))
            elif tp == 'TCN':
                node(pc, Xn, sig + (1,), cap, lev + 1)
            elif tp == 'TCS':
                mc2, pst = Fr(pc['mc']), Fr(pc['pst'])
                if not (0 < mc2 < cap <= 1 and K3B.phi_ok(pst, mc2)):
                    bad.append(f'L{lev} TCS cut/phi')
                jobs.append((f'L{lev + 1} TCS cut', pc['c1'], Xn, sig + (1,), box, mc2, None))
                jobs.append((f'L{lev + 1} TCS SG', pc['c2'], Xn, sig + (1,), box, cap, pst))
            else:
                bad.append(f'L{lev} plus type {tp}')
        for pc in nd['minus']:
            n1, n2 = Fr(pc['m'][0]), Fr(pc['m'][1])
            tp = pc['type']
            cap = Fr(pc['cap'])
            if tp == 'SG':
                pst = Fr(pc['pst'])
                if not (K3B.phi_ok(pst, n1) and cap >= min(n2, khat)):
                    bad.append(f'L{lev} SG phi/cap')
                jobs.append((f'L{lev} SG', pc, X, sig, box, cap, pst))
            elif tp == 'TC':
                if not K3B.cap_after(n2, cap):
                    bad.append(f'L{lev} TC- cap')
                jobs.append((f'L{lev} TC-', pc, X + ((n1, n2),), sig + (-1,), box, cap, None))
            else:
                bad.append(f'L{lev} minus type {tp}')
    node(bx, X0, (1, s), min(Fr(1), mb), 0)
    return jobs, bad


# ---------------------------------------------------------------- F: near-sphere tests, split trees
def near_n5(box, s, levels):
    """split coordinates a_{i+2} = b_{i-1} mu_i (mu_i in levels[i-1]) with positive signs; L = Y_n + b_j N with N a
    normalised remainder independent of the n = 2 + j bits of Y_n. Returns 'A<n>' / 'B<n>' if a test passes."""
    u1, u2, t1, t2, r1, r2 = box
    n = 2 + len(levels)
    T = T5_lo(u1, u2)
    blo, bhi = V.b_range(r1, r2)
    if blo <= 0:
        return None
    a2 = (r1 * V.dfun(t1), r2 * V.dfun(t2))
    coefs = [(r1 * V.cfun(t2), r2 * V.cfun(t1)), a2 if s == 1 else (-a2[1], -a2[0])]
    b2 = (blo * blo, bhi * bhi)
    bb = (blo, bhi)
    for x1, x2 in levels:
        if not (0 < x1 < x2 <= 1):
            return None
        coefs.append((bb[0] * x1, bb[1] * x2))
        b2 = (b2[0] * (1 - x2 * x2), b2[1] * (1 - x1 * x1))
        bb = (sqrt_lo(b2[0]) if b2[0] > 0 else Fr(0), sqrt_hi(b2[1]) if b2[1] > 0 else Fr(0))
    rq = min(Fr(1), sqrt_hi(1 - b2[0]))
    E4 = 3 + max(Fr(0), u2 * u2 + 1 / (u2 * u2) - 4)
    U, Vn = (u1, u2), (-1 / u1, -1 / u2)
    q = (1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    qb = (1 - q[1], 1 - q[0])
    tau = (u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))
    atoms = []
    for code in range(2**n):
        e = [(code >> (n - 1 - i)) & 1 for i in range(n)]
        w = [q if ei else qb for ei in e]
        p = Fr(1)
        for x in w:
            p *= x[1]
        y = (Fr(0), Fr(0))
        py = (Fr(0), Fr(0))
        for i in range(n):
            y = K3B.iadd(y, K3B.imulI(coefs[i], U if e[i] else Vn))
            oth = (Fr(1), Fr(1))
            for l in range(n):
                if l != i:
                    oth = (oth[0] * w[l][0], oth[1] * w[l][1])
            t = (oth[0] * tau[0], oth[1] * tau[1]) if e[i] else (-oth[1] * tau[1], -oth[0] * tau[0])
            py = K3B.iadd(py, K3B.imulI(coefs[i], t))
        atoms.append((p, K3B.iabs_lo(y), max(abs(py[0]), abs(py[1]))))
    a_ok = True
    if n >= 5:
        tot_hi = sum(c[1] for c in coefs)
        a_ok = s == 1 and all(c[0] > q[1] * tot_hi for c in coefs)
    if a_ok and all(yl > 0 for _, yl, _ in atoms):
        S = sum(p / yl**3 for p, yl, _ in atoms)
        if K27 * E4 * b2[1] * (1 + rq) * S < T:
            return f"A{n}"
    tot = Fr(0)
    for p, yl, apy in atoms:
        e = bb[1] if yl == 0 else min(bb[1], K27 * b2[1] * b2[1] * E4 / yl**3)
        tot += apy + p * e
    return f"B{n}" if tot < T else None


def tree_check5(args):
    bx, = args
    box, blo, mb = box_basics(bx)
    s = bx['s']
    u1, u2, t1, t2, r1, r2 = box
    if not (r2 < 1 and u1 >= 2 and blo > 0):
        return False, "r2 < 1, u1 >= 2, b- > 0", {}
    top = min(Fr(1), mb)
    kinds = {}

    def note(k):
        kinds[k] = kinds.get(k, 0) + 1

    def ns_type_ok(tp, n):
        return tp[0] in 'AB' and tp[1:].isdigit() and int(tp[1:]) == n

    def node(nd, levels, khat, lev):
        mc = Fr(nd['mc'])
        note(f'node L{lev}')
        if not (0 < mc <= 1 and 0 < khat <= 1):
            return f'cut/range L{lev}'
        if mc >= khat:
            note(f'cut >= range L{lev}')
        for side in ('plus', 'minus'):
            if not K3B.covers([(Fr(p['m'][0]), Fr(p['m'][1])) for p in nd[side]], mc, khat):
                return f'cover {side} L{lev}'
        for pc in nd['plus']:
            n1, n2 = Fr(pc['m'][0]), Fr(pc['m'][1])
            tp = pc['type']
            lv = levels + [(n1, n2)]
            if tp[0] in 'AB':
                if not ns_type_ok(tp, lev + 3):
                    return f'near-sphere type {tp} at L{lev}'
                k = near_n5(box, s, lv)
                if k is None:
                    return f'near-sphere {lev + 3} at L{lev}: {[(float(a), float(b)) for a, b in lv]}'
                note(f'L{lev} plus {k}')
                continue
            cap = Fr(pc['cap'])
            if not (0 < cap <= 1 and K3B.cap_after(n2, cap)):
                return f'{tp} cap L{lev}'
            if tp == 'TC':
                note(f'L{lev} plus TC')
            elif tp == 'TCN':
                note(f'L{lev} plus TCN')
                err = node(pc, lv, cap, lev + 1)
                if err:
                    return err
            elif tp == 'TCS':
                note(f'L{lev} plus TCS')
                mc2, pst = Fr(pc['mc']), Fr(pc['pst'])
                if not (0 < mc2 < cap and K3B.phi_ok(pst, mc2)):
                    return f'TCS cut/phi L{lev}'
                sub = [(Fr(a), Fr(b), typ) for a, b, typ in pc['sub']]
                if not K3B.covers([(a, b) for a, b, _ in sub], mc2, cap):
                    return f'TCS sub cover L{lev}'
                for a, b, typ in sub:
                    if not ns_type_ok(typ, lev + 4):
                        return f'TCS sub type {typ} at L{lev}'
                    k = near_n5(box, s, lv + [(a, b)])
                    if k is None:
                        return f'TCS near-sphere {lev + 4} at L{lev}: {[(float(x), float(y)) for x, y in lv + [(a, b)]]}'
                    note(f'L{lev + 1} TCS plus {k}')
            else:
                return f'plus type {tp} L{lev}'
        for pc in nd['minus']:
            n1, n2 = Fr(pc['m'][0]), Fr(pc['m'][1])
            tp = pc['type']
            cap = Fr(pc['cap'])
            if not 0 < cap <= 1:
                return f'minus cap L{lev}'
            if tp == 'SG':
                if not (K3B.phi_ok(Fr(pc['pst']), n1) and cap >= min(n2, khat)):
                    return f'SG phi/cap L{lev}'
            elif tp == 'TC':
                if not K3B.cap_after(n2, cap):
                    return f'TC- cap L{lev}'
            else:
                return f'minus type {tp} L{lev}'
            note(f'L{lev} minus {tp}')
        return None

    err = node(bx, [], top, 0)
    if Fr(bx['cap']) < top:
        note('recorded root cap < min(1, mbar)')
    return (err is None), (err or ""), kinds


# ---------------------------------------------------------------- A: elementary facts
def part_A():
    import sympy as sp
    import random
    u = sp.Symbol('u', positive=True)
    ok = True
    s5, s30 = sp.sqrt(5), sp.sqrt(30)
    u5 = sp.sqrt(4 + 2 * s5)
    u6 = sp.sqrt(5 + s30)
    q = 1 / (1 + u**2)
    okq = (sp.simplify(q.subs(u, u5) - (1 - 2 / s5)) == 0
           and sp.simplify(q.subs(u, u6) - (1 - sp.sqrt(sp.Rational(5, 6)))) == 0)
    okU = (U_LO >= 2 and (U_LO**2 <= 4 or (U_LO**2 - 4)**2 <= 20) and U_HI**2 >= 5 and (U_HI**2 - 5)**2 >= 30)
    okT8 = (T8 + 1)**2 >= 2 and T8 < 1
    wm = U_LO**2 / (1 + U_LO**2)
    okw = 5 * wm**8 > 1 and 5 * wm**6 > 2
    okS5 = S5_LO > 0 and S5_LO**2 <= 5
    print(f"A  u5 = sqrt(4+2sqrt5), u6 = sqrt(5+sqrt30) give q5 = 1-2/sqrt5, q6 = 1-sqrt(5/6): {okq};"
          f" 2 <= U_LO <= u5 and U_HI >= u6: {okU} (u5 - U_LO = {float(u5 - sp.Rational(29106, 10000)):.3e},"
          f" U_HI - u6 = {float(sp.Rational(3236855, 1000000) - u6):.3e}); tan(pi/8) <= T8 < 1: {okT8};"
          f" 5 w-^8 > 1, 5 w-^6 > 2: {okw}; sqrt5- <= sqrt5: {okS5}")
    ok &= okq and okU and okT8 and okw and okS5
    T5s = 2 * s5 * u**9 / (1 + u**2)**5
    okT5 = sp.simplify(T5s - 2 * s5 * (1 - q)**4 * u * q) == 0
    okd = sp.simplify(sp.diff(u**9 / (1 + u**2)**5, u) - u**8 * (9 - u**2) / (1 + u**2)**6) == 0
    print(f"A  T5(u) = 2sqrt5 (1-q)^4 tau = 2sqrt5 u^9/(1+u^2)^5: {okT5}; d/du u^9/(1+u^2)^5 = u^8(9-u^2)/(1+u^2)^6"
          f" (unimodal, max at u = 3): {okd}")
    ok &= okT5 and okd
    lo_s, hi_s = sp.Rational(U_LO.numerator, U_LO.denominator), sp.Rational(U_HI.numerator, U_HI.denominator)
    crit_ok, rep = True, []
    for j in range(3, NJ + 1):
        expr = sum(sp.Rational(c.numerator, c.denominator) * u**e for e, c in KAP[j].items())
        P = sp.Poly(sp.numer(sp.together(sp.diff(expr, u))), u)
        n = P.count_roots(lo_s, hi_s)
        mine = [(a, b) for a, b in CRIT[j] if a >= U_LO and b <= U_HI]
        crit_ok &= n == len(mine) and len(CRIT[j]) == len(mine)
        if CRIT[j]:
            rep.append(f"kappa_{j}: {n} root(s) of kappa_j' in [U_LO,U_HI] (sympy), enclosure(s) "
                       + ", ".join(f"[{float(a):.12f}, {float(b):.12f}] width {float(b - a):.1e}" for a, b in CRIT[j]))
    print(f"A  critical points of kappa_3..kappa_{NJ} on [U_LO, U_HI]: " + ("; ".join(rep) if rep else "none")
          + f"; enclosures agree with exact root counts: {crit_ok}")
    ok &= crit_ok
    rng = random.Random(5)
    worst, nsamp, samp_ok = 0.0, 0, True
    ivs = [(U_LO, U_HI)] + [(c1 - Fr(1, 100), c2 + Fr(1, 100)) for j in CRIT for c1, c2 in CRIT[j]]
    for _ in range(300):
        a = U_LO + (U_HI - U_LO) * Fr(rng.randint(0, 10**6), 10**6)
        ivs.append((a, min(U_HI, a + Fr(rng.randint(1, 2000), 10**5))))
    for a, b in ivs:
        a, b = max(a, U_LO), min(b, U_HI)
        for j in range(3, NJ + 1):
            lo, hi = kap_iv5(j, a, b)
            for k in range(41):
                x = a + (b - a) * Fr(k, 40)
                val = leval(KAP[j], x)
                samp_ok &= lo <= val <= hi
                nsamp += 1
            if j == 9 and any(c1 <= b and a <= c2 for c1, c2 in CRIT[9]):
                exact_hi = max(leval(KAP[j], a + (b - a) * Fr(k, 4000)) for k in range(4001))
                worst = max(worst, float((hi - exact_hi) / hi))
    print(f"A  kappa enclosures contain {nsamp} exact sample values on {len(ivs)} intervals: {samp_ok};"
          f" kappa_9 upper end exceeds the 4001-point sample maximum by at most {worst:.2e} (relative)")
    ok &= samp_ok
    iv9 = kap_iv5(9, U_LO, U_HI)
    endp = max(leval(KAP[9], U_LO), leval(KAP[9], U_HI))
    print(f"A  kappa_9 on [U_LO, U_HI]: enclosure [{float(iv9[0]):.6f}, {float(iv9[1]):.6f}], end values max"
          f" {float(endp):.6f} (the endpoint enclosure would be wrong by {float(iv9[1] - endp):.4f});"
          f" objective bound uses this enclosure: {K3B.kap_iv is kap_iv5}")
    ok &= iv9[1] > endp and K3B.kap_iv is kap_iv5
    import moments10
    ok &= moments10.self_test()
    return ok


# ---------------------------------------------------------------- data
def load(files=None):
    if files is None:
        man = json.load(open(os.path.join(DATA, 'k5_manifest.json')))
        assert Fr(man['U_LO']) == U_LO and Fr(man['U_HI']) == U_HI and Fr(man['T8']) == T8 and Fr(man['A_S']) == A_S
        one_files, two_files = man['one_files'], man['two_files']
    else:
        one_files = [f for f in files if os.path.basename(f).startswith('one_')]
        two_files = [f for f in files if not os.path.basename(f).startswith('one_')]
    cells, boxes, regions = [], [], []
    for fn in one_files:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['K'] == 5 and not d['failed'] and d['D'] <= NJ, fn
        for cl in d['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]))
    for fn in two_files:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['s'] in (1, -1) and not d['failed'] and d['K'] == 5 and Fr(d['A_S']) == A_S, fn
        reg = tuple(Fr(x) for x in d['region'])
        regions.append((fn, d['s'], reg))
        for bx in d['boxes']:
            assert bx['s'] == d['s'], fn
            bx['_file'] = fn
            boxes.append(bx)
    return one_files, two_files, cells, boxes, regions


def main():
    t0 = time.time()
    parts = sys.argv[1] if len(sys.argv) > 1 else 'MABCDF'
    files = None
    if len(sys.argv) > 2:
        files = []
        for pat in sys.argv[2:]:
            files += sorted(os.path.relpath(f, DATA) for f in glob.glob(os.path.join(DATA, pat)))
    allok = True
    one_files, two_files, cells, boxes, regions = load(files)
    kinds = {}
    for bx in boxes:
        kinds[(bx['s'], bx['kind'])] = kinds.get((bx['s'], bx['kind']), 0) + 1
    print(f"k5 verifier (RQ-AUD), data {DATA}: {len(one_files)} cell files, {len(two_files)} box files; {len(cells)} cells,"
          f" {len(boxes)} boxes, kinds {dict(sorted(kinds.items()))}", flush=True)
    if 'M' in parts:
        pub = {}
        for line in open(os.path.join(DATA, 'k5_MD5SUMS.txt')):
            h, fn = line.split()
            pub[fn.replace('outputs/', '')] = h
        listed = one_files + two_files + ([] if files else ['k5_manifest.json'])
        mism = [fn for fn in listed if hashlib.md5(open(os.path.join(DATA, fn), 'rb').read()).hexdigest() != pub.get(fn)]
        print(f"M  md5 of the {len(listed)} files vs k5_MD5SUMS.txt: {len(mism)} mismatches {mism[:5]}", flush=True)
        allok &= not mism
    if 'A' in parts:
        allok &= part_A()
    if 'B' in parts:
        if cells:
            reg1 = (U_LO, U_HI, Fr(0), A_S)
            tok, gap = tiles(reg1, [cl[:4] for cl in cells])
            inside = all(reg1[0] <= cl[0] < cl[1] <= reg1[1] and reg1[2] <= cl[2] < cl[3] <= reg1[3] for cl in cells)
            area = (sum((cl[1] - cl[0]) * (cl[3] - cl[2]) for cl in cells)
                    == (reg1[1] - reg1[0]) * (reg1[3] - reg1[2]))
            print(f"B  {len(cells)} one-coordinate cells tile [U_LO,U_HI] x [0,A_S]: {'OK' if tok else 'GAP ' + str(gap)};"
                  f" inside {inside}; area {area}", flush=True)
            allok &= tok and inside and area
        else:
            print("B  no one-coordinate cells in this data set (not yet delivered)", flush=True)
        nbad = 0
        for fn, s, reg in regions:
            bs = [tuple(Fr(x) for x in bx['box']) for bx in boxes if bx['_file'] == fn]
            ins, voleq, nov = V.tiling3(reg, bs)
            if not (ins and voleq and nov == 0):
                nbad += 1
                print(f"   TILING FAIL {fn}: inside {ins}, volume {voleq}, overlaps {nov}")
        print(f"B  each of the {len(regions)} box files tiles its own region: failures {nbad}", flush=True)
        allok &= nbad == 0
        reg3 = (U_LO, U_HI, Fr(0), T8, A_S, Fr(1))
        for s in (1, -1):
            regs = [reg for fn, ss, reg in regions if ss == s]
            if not regs:
                print(f"B  s={s:+d}: no box files in this data set", flush=True)
                allok &= files is not None
                continue
            ins, voleq, nov = V.tiling3(reg3, regs)
            full = (reg3[1] - reg3[0]) * (reg3[3] - reg3[2]) * (reg3[5] - reg3[4])
            vol = sum((r[1] - r[0]) * (r[3] - r[2]) * (r[5] - r[4]) for r in regs)
            print(f"B  s={s:+d}: {len(regs)} file regions inside {ins}, overlapping pairs {nov}, volume fraction of"
                  f" [U_LO,U_HI]x[0,T8]x[1/4,1] covered {float(vol / full):.6f}"
                  f" => {'FULL TILING' if ins and voleq and nov == 0 else 'partial' if ins and nov == 0 else 'FAIL'}",
                  flush=True)
            allok &= ins and nov == 0
            if files is None:
                allok &= voleq
        unknown = {bx['kind'] for bx in boxes} - {'lpv', 'ms'}
        print(f"B  box kinds outside {{lpv, ms}}: {sorted(unknown)}", flush=True)
        allok &= not unknown
    if 'C' in parts and cells:
        with Pool(8) as pool:
            res = pool.map(cell_job, [(cl[0], cl[1], cl[2], cl[3], cl[4]) for cl in cells], chunksize=2)
        nf = 0
        for cl, r in zip(cells, res):
            if not r[0]:
                nf += 1
                print(f"   FAIL cell u[{float(cl[0]):.6f},{float(cl[1]):.6f}] a[{float(cl[2]):.4f},{float(cl[3]):.4f}]: {r[1]}")
        degs = {}
        for cl in cells:
            degs[len(cl[4]) - 1] = degs.get(len(cl[4]) - 1, 0) + 1
        print(f"C  one-coordinate cells (ten-moment bound with certified kappa enclosures, Theta_1 for T5): failures"
              f" {nf}/{len(cells)}; degrees {degs}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    if 'D' in parts:
        jobs, bad = [], []
        for bx in boxes:
            j, b = vertex_jobs5(bx)
            jobs += j
            bad += b
        nv = sum(len(j[1]['V']) for j in jobs)
        npar = {}
        for j in jobs:
            npar[len(j[2])] = npar.get(len(j[2]), 0) + 1
        print(f"D  {len(jobs)} vertex-certificate sets ({nv} vertices; by number of patch parameters"
              f" {dict(sorted(npar.items()))}); record-side cap/phi/type problems: {len(bad)} {bad[:3]}", flush=True)
        allok &= not bad
        jobs.sort(key=lambda j: -len(j[1]['V']))
        with Pool(8) as pool:
            res = pool.map(vjob_check5, jobs, chunksize=2)
        nf = 0
        byname = {}
        for jb, r in zip(jobs, res):
            byname[jb[0]] = byname.get(jb[0], 0) + 1
            if not r[0]:
                nf += 1
                bx = jb[4]
                if nf <= 30:
                    print(f"   FAIL {r[1]} sig={jb[3]} u[{float(bx[0]):.6f},{float(bx[1]):.6f}]"
                          f" t[{float(bx[2]):.5f},{float(bx[3]):.5f}] r[{float(bx[4]):.5f},{float(bx[5]):.5f}]"
                          f" X={[(float(a), float(b)) for a, b in jb[2]]} cap={float(jb[5]):.6f}"
                          f" p*={None if jb[6] is None else float(jb[6])}")
        used = [r[2] for r in res]
        print(f"D  vertex certificates: failures {nf}/{len(jobs)}; sets by role {dict(sorted(byname.items()))};"
              f" cone sub-boxes max {max(used) if used else 0}, sets needing a split {sum(1 for x in used if x > 1)};"
              f" {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    if 'F' in parts:
        mss = [bx for bx in boxes if bx['kind'] == 'ms']
        with Pool(8) as pool:
            res = pool.map(tree_check5, [(bx,) for bx in mss], chunksize=2)
        nf = 0
        kk = {}
        for bx, r in zip(mss, res):
            if not r[0]:
                nf += 1
                b = [float(Fr(x)) for x in bx['box']]
                if nf <= 30:
                    print(f"   FAIL ms s={bx['s']:+d} box {b} ({bx['_file']}): {r[1]}")
            for k, v in r[2].items():
                kk[k] = kk.get(k, 0) + v
        mcs = sorted({bx['mc'] for bx in mss}, key=Fr)
        print(f"F  split trees: failures {nf}/{len(mss)}; nodes, pieces and near-sphere tests"
              f" {dict(sorted(kk.items()))}; root cuts {mcs}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    print(f"RESULT: {'ALL CHECKS PASSED' if allok else 'FAILURES'} (parts {parts}, {time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
