"""Second exact method on the whole MAIN-3 cover: sympy Sturm counts replace the Arb root isolation of
a14_main3_verify.py for every one-coordinate cell, every lp box and every m-split box (c1 and c2 domination and
the moment bounds with and without p*). The near-circle and piece tests use no root isolation."""
import json
import os
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
import a14_main3_verify as K  # noqa: E402
import a11b_main2_negative as N  # noqa: E402

CALLS = [0]


def counting_sturm(coeffs, lo=None, hi=None):
    CALLS[0] += 1
    return N.sturm_positive_on(coeffs, lo=lo, hi=hi)


def patch():
    K.positive_on = counting_sturm
    K.V2.positive_on = counting_sturm
    K.V.positive_on = counting_sturm


def lp_job(args):
    patch()
    box, s, c = args
    blo, _ = K.V.b_range(box[4], box[5])
    CALLS[0] = 0
    ok = K.box_cert_ok(box, s, c, K.V.mbar_of(box[3], box[5], blo), None, K.S3_MINE)[0]
    return ok, CALLS[0]


def cell_job(args):
    patch()
    CALLS[0] = 0
    ok = K.cell_once(*args)[0]
    return ok, CALLS[0]


def ms_job(args):
    patch()
    CALLS[0] = 0
    ok = K.ms_check(args)[0]
    return ok, CALLS[0]


if __name__ == '__main__':
    t0 = time.time()
    man = json.load(open(os.path.join(K.DATA, 'k3_manifest.json')))
    lps, mss, cells = [], [], []
    for fn in man['two_files']:
        d = json.load(open(os.path.join(K.DATA, fn)))
        for bx in d['boxes']:
            box = tuple(Fr(x) for x in bx['box'])
            if bx['kind'] == 'lp':
                lps.append((box, d['s'], [Fr(x) for x in bx['c']]))
            elif bx['kind'] == 'ms':
                mss.append((box, d['s'], bx, K.S3_MINE))
    for fn in man['one_files']:
        for cl in json.load(open(os.path.join(K.DATA, fn)))['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']], K.S3_MINE))
    probe = N.sturm_positive_on([Fr(-1), Fr(0), Fr(1)], lo=Fr(0), hi=Fr(2))
    with Pool(8) as pool:
        r2 = pool.map(cell_job, cells, chunksize=4)
        r1 = pool.map(lp_job, lps, chunksize=32)
        r3 = pool.map(ms_job, mss, chunksize=8)
    f = lambda rs: sum(1 for ok, _ in rs if not ok)
    c = lambda rs: sum(n for _, n in rs)
    print(f"planted probe y^2 - 1 > 0 on [0, 2] is rejected: {probe[0] is False} ({probe[1]})")
    print(f"Sturm (sympy count_roots) re-check of the MAIN-3 cover, depth 0: one-coordinate cells {f(r2)} failures / {len(r2)}"
          f" ({c(r2)} Sturm calls); lp boxes {f(r1)} failures / {len(r1)} ({c(r1)} calls); m-split boxes {f(r3)} failures"
          f" / {len(r3)} ({c(r3)} calls) ({time.time() - t0:.0f}s)")
    print("RESULT:", "ALL CHECKS PASSED" if f(r1) == f(r2) == f(r3) == 0 and probe[0] is False else "FAILURES")
