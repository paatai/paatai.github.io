"""RQ-AUD semantic test of RQ-A's MAIN-6 data (Theorem 6, R = T5 on [q6, q5]), floating point, own code.

For sampled unit alpha and u in [U_LO, U_HI] this follows the case analysis of the proof (reduction, one-coordinate
cell, lpv box, split tree: cut certificate, plus pieces A_n / TC / TCS / TCN with their child nodes, minus pieces
SG / TC) down to the step that makes the claim, and compares the claim with the exact value E|L| (enumeration of
all 2^n atoms):
 - steps that end in a vertex certificate or a one-coordinate cell claim E|L| < T5(u) at every u of their box, also
   outside [u5, u6]; vertex certificates even claim E|L| < min(T5(u1), T5(u2)) (up to the sqrt5 rounding);
 - steps that end in a near-sphere test (A3)..(A6) claim E|L| <= T5 only for q in [q6, q5].
Samples: perturbations of (e1+..+e5)/sqrt5, (e1+..+e4)/2, (e1+..+e6)/sqrt6, (e1+e2+e3)/sqrt3, (e1+e2)/sqrt2 and e1
at scales 1e-1..1e-4, random alpha with heavy or light tails (n = 3..10), and spread-out alpha with n = 10..13;
u uniform on the range and concentrated near u5 and u6 (on both sides, where T4 resp. T6 exceeds T5).
Usage: k5_semantic.py N [file globs relative to the data directory]   (default: all box files present)
"""
import glob
import json
import math
import os
import sys
import time
from fractions import Fraction as Fr

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.environ.get('K5_DATA', os.path.join(HERE, 'k5_data'))
U_LO, U_HI, A_S = 29106 / 10000, 3236855 / 1000000, 0.25
U5 = math.sqrt(4 + 2 * math.sqrt(5))
U6 = math.sqrt(5 + math.sqrt(30))


def T5(u):
    return 2 * math.sqrt(5) * u**9 / (1 + u * u)**5


def EabsL(alpha, u):
    n = len(alpha)
    q = 1 / (1 + u * u)
    bits = ((np.arange(2**n)[:, None] >> np.arange(n)) & 1).astype(bool)
    vals = np.where(bits, u, -1 / u) @ np.asarray(alpha)
    k = bits.sum(1)
    p = q**k * (1 - q)**(n - k)
    return float(np.sum(p * np.abs(vals)))


def load(pats):
    files = []
    for pat in pats:
        files += sorted(glob.glob(os.path.join(DATA, pat)))
    boxes = {1: [], -1: []}
    for fn in files:
        if os.path.basename(fn).startswith(('one_', 'k5_')) or not fn.endswith('.json'):
            continue
        d = json.load(open(fn))
        boxes[d['s']] += d['boxes']
    idx = {s: np.array([[float(Fr(x)) for x in bx['box']] for bx in boxes[s]]).reshape(-1, 6) for s in (1, -1)}
    return boxes, idx, files


def fl(x):
    return float(Fr(x))


def peel(beta, sign):
    """the normalised remainder after removing one coefficient equal to sign * max|beta|"""
    m = np.max(np.abs(beta))
    cand = np.where(np.isclose(beta, sign * m, rtol=0, atol=1e-15))[0]
    rest = np.delete(beta, cand[0])
    if m >= 1 - 1e-15 or len(rest) == 0 or np.linalg.norm(rest) < 1e-300:
        return None
    return rest / np.linalg.norm(rest)


def has(beta, sign):
    m = np.max(np.abs(beta))
    return bool(np.any(np.isclose(beta, sign * m, rtol=0, atol=1e-15)))


def containing(pieces, x, key='m'):
    return [p for p in pieces if fl(p[key][0]) - 1e-15 <= x <= fl(p[key][1]) + 1e-15]


def claim(alpha, u, boxes, idx):
    a = np.array(sorted(alpha, key=lambda x: -abs(x)))
    if a[0] < 0:
        a = -a
    in_range = U5 - 1e-12 <= u <= U6 + 1e-12
    a1 = a[0]
    if a1 >= 1 - 1e-15:
        return ('lt', T5(u)), 'e1'
    if a1 <= A_S:
        return ('lt', T5(u)), 'cell'
    a2 = abs(a[1])
    s = 1 if a[1] >= 0 else -1
    r = math.hypot(a1, a2)
    if r >= 1 - 1e-15:
        return ('lt', T5(u)), 'two'
    t = math.tan(math.atan2(a2, a1) / 2)
    arr = idx[s]
    hit = np.where((arr[:, 0] <= u) & (u <= arr[:, 1]) & (arr[:, 2] <= t) & (t <= arr[:, 3])
                   & (arr[:, 4] <= r) & (r <= arr[:, 5]))[0]
    if len(hit) == 0:
        return (None, 'no box (file not delivered)'), 'nobox'
    bx = boxes[s][hit[0]]
    Tm = min(T5(fl(bx['box'][0])), T5(fl(bx['box'][1])))
    if bx['kind'] == 'lpv':
        return ('lt', Tm), 'lpv'
    beta = a[2:] / np.linalg.norm(a[2:])
    node, lev = bx, 0
    while True:
        m = float(np.max(np.abs(beta)))
        if m <= fl(node['mc']):
            return ('lt', Tm), f'L{lev} cut'
        if not has(beta, 1):
            pcs = containing(node['minus'], m)
            if not pcs:
                return (None, f'L{lev} minus gap'), 'gap'
            return ('lt', Tm), f"L{lev} {pcs[0]['type']}-"
        pcs = containing(node['plus'], m)
        if not pcs:
            return (None, f'L{lev} plus gap'), 'gap'
        pc = pcs[0]
        tp = pc['type']
        if tp[0] in 'AB':
            return (('le', T5(u)) if in_range else (None, f'{tp} outside [q6,q5]')), f'L{lev} {tp}'
        if tp == 'TC':
            return ('lt', Tm), f'L{lev} TC+'
        nxt = peel(beta, 1)
        if nxt is None:
            return ('lt', Tm), f'L{lev} {tp} m=1'
        if tp == 'TCS':
            mp = float(np.max(np.abs(nxt)))
            if mp <= fl(pc['mc']):
                return ('lt', Tm), f'L{lev + 1} TCS cut'
            if not has(nxt, 1):
                return ('lt', Tm), f'L{lev + 1} TCS SG'
            subs = [x for x in pc['sub'] if fl(x[0]) - 1e-15 <= mp <= fl(x[1]) + 1e-15]
            if not subs:
                return (None, f'L{lev + 1} TCS sub gap'), 'gap'
            typ = subs[0][2]
            return (('le', T5(u)) if in_range else (None, f'{typ} outside [q6,q5]')), f'L{lev + 1} TCS {typ}'
        if tp != 'TCN':
            return (None, 'type ' + tp), 'unknown'
        node, lev, beta = pc, lev + 1, nxt


def samples(rng, N):
    bases = [np.ones(5) / math.sqrt(5), np.ones(4) / 2, np.ones(6) / math.sqrt(6), np.ones(3) / math.sqrt(3),
             np.ones(2) / math.sqrt(2), np.array([1.0])]
    for i in range(N):
        kind = i % 5
        n = int(rng.integers(3, 11))
        if kind < 3:
            base = bases[int(rng.integers(0, len(bases)))]
            n = max(n, len(base))
            v = np.zeros(n)
            v[:len(base)] = base
            v = v + 10.0**(-int(rng.integers(1, 5))) * rng.standard_normal(n)
        elif kind == 3:
            v = rng.standard_normal(n) * np.abs(rng.standard_normal(n))**int(rng.integers(0, 3))
        else:
            n = int(rng.integers(10, 14))
            v = rng.choice((-1.0, 1.0), n) * (1 + 0.2 * rng.random(n))
            v[0] *= 1 + 0.6 * rng.random()
        v = v / np.linalg.norm(v)
        z = rng.random()
        if z < 0.5:
            u = U_LO + (U_HI - U_LO) * rng.random()
        elif z < 0.75:
            u = U5 + (rng.random() - 0.5) * 2 * (U5 - U_LO)
        else:
            u = U6 + (rng.random() - 0.5) * 2 * (U_HI - U6)
        yield v, min(max(u, U_LO), U_HI)


def main():
    t0 = time.time()
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 40000
    pats = sys.argv[2:] or ['k5/*.json']
    boxes, idx, files = load(pats)
    rng = np.random.default_rng(26)
    stats, viol, noclaim, worst, worst_at = {}, [], {}, {}, {}
    special = []
    for k in range(200):
        u = U_LO + (U_HI - U_LO) * k / 199
        for base in (np.ones(5) / math.sqrt(5), np.ones(4) / 2, np.ones(6) / math.sqrt(6), np.ones(3) / math.sqrt(3)):
            special.append((base, u))
    allsamp = list(samples(rng, N)) + special
    for v, u in allsamp:
        (kind, T), step = claim(v, u, boxes, idx)
        stats[step] = stats.get(step, 0) + 1
        if kind is None:
            noclaim[T] = noclaim.get(T, 0) + 1
            continue
        E = EabsL(v, u)
        gap = (T - E) / T
        if gap < worst.get(step, 9):
            worst[step] = gap
            worst_at[step] = (u, v)
        if (kind == 'lt' and not E < T) or (kind == 'le' and E > T * (1 + 1e-12)):
            viol.append((step, kind, u, E, T, v))
    print(f"semantic test of the MAIN-6 data ({len(files)} files, {len(boxes[1])} + {len(boxes[-1])} boxes):"
          f" {len(allsamp)} (alpha, u) samples ({N} random, {len(special)} on four extremisers for u across"
          f" [U_LO, U_HI]); {time.time() - t0:.0f}s")
    print("claims by the step of the proof that makes them:", dict(sorted(stats.items())))
    print("no claim (near-sphere test outside [q6, q5], or box file not yet delivered; gaps would be listed here):",
          noclaim)
    print("smallest relative slack (T - E|L|)/T per step:", {k: f"{v:.3e}" for k, v in sorted(worst.items())})
    print("where the smallest slack of each near-sphere step occurs (u - u5, u6 - u, sorted |alpha_i| > 1e-3):")
    for k in sorted(worst_at):
        if any(f' {t}' in k for t in ('A3', 'A4', 'A5', 'A6', 'B3', 'B4', 'B5', 'B6')):
            u, v = worst_at[k]
            big = sorted((abs(x) for x in v if abs(x) > 1e-3), reverse=True)
            print(f"   {k}: slack {worst[k]:.3e}, u - u5 = {u - U5:.3e}, u6 - u = {U6 - u:.3e}, |alpha| =",
                  np.round(big, 6))
    print(f"violations: {len(viol)}")
    for x in viol[:20]:
        print("   VIOLATION", x[:5], np.round(x[5], 6))
    gaps = sum(v for k, v in noclaim.items() if 'gap' in k or 'type' in k)
    print(f"RESULT: {'PASS' if not viol and gaps == 0 else 'FAIL'}"
          f" ({noclaim.get('no box (file not delivered)', 0)} samples fell in slabs whose files are not yet delivered)")


if __name__ == '__main__':
    main()
