"""RQ-AUD attack on RQ-A MAIN-2: search for unit alpha with E|sum alpha_i chi_i| > S_2(q) = 2 sqrt2 (1-q) tau
for q in [1/5, 1-1/sqrt2].  Evidence only (floating point).

Part 1: exact enumeration over {0,1}^n, n = 3..16, duality ascent alpha <- (Delta_i(1{L>0}))_i (never decreases
        E|L|/|alpha|), random and structured starts.
Part 2: families with a binomial bulk: alpha = (a_1, ..., a_k, b/sqrt m, ..., b/sqrt m) (m equal small
        coefficients, k = 1, 2, 3 large ones, all sign patterns), E|L| computed exactly from the binomial law;
        Nelder-Mead over the large coefficients, m up to 400, plus the Gaussian bulk (m = infinity).
"""
import itertools
import sys
import time

import numpy as np
from scipy.optimize import minimize
from scipy.special import erf
from scipy.stats import binom

rng = np.random.default_rng(20261022 + 11)
QS = [0.2, 0.2025, 0.205, 0.21, 0.22, 0.23, 0.24, 0.25, 256 / 985, 0.275, 1 - 2 ** -0.5]
Q3 = 1 - np.sqrt(2 / 3)
QS_LOW = [Q3, Q3 + 1e-6, Q3 + 1e-4, 0.184, 0.185, 0.1875, 0.19, 0.1925, 0.195, 0.1975]
NS = list(range(3, 17))
STARTS = int(sys.argv[1]) if len(sys.argv) > 1 else 40
if len(sys.argv) > 2 and sys.argv[2] == 'low':
    QS = QS_LOW


def S2(q):
    return 2 * np.sqrt(2) * (1 - q) * np.sqrt(q * (1 - q))


def tables(n, q):
    X = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1).astype(np.float64)
    k = X.sum(1)
    w = q ** k * (1 - q) ** (n - k)
    tau = np.sqrt(q * (1 - q))
    chi = (X - q) / tau
    return X, w, chi


def value(alpha, w, chi):
    return float(w @ np.abs(chi @ alpha)) / float(np.linalg.norm(alpha))


def ascent(alpha, X, w, chi, iters=300):
    best = value(alpha, w, chi)
    q1 = X.T @ w
    for _ in range(iters):
        f = ((chi @ alpha) > 0).astype(np.float64)
        e1 = (X * (f * w)[:, None]).sum(0) / q1
        e0 = ((1 - X) * (f * w)[:, None]).sum(0) / (1 - q1)
        new = e1 - e0
        if np.linalg.norm(new) == 0:
            break
        v = value(new, w, chi)
        if v <= best + 1e-15:
            break
        alpha, best = new, v
    return best, alpha


def part1():
    worst = (0, None)
    for q in QS:
        line = []
        for n in NS:
            X, w, chi = tables(n, q)
            top, topa = 0, None
            for s in range(STARTS):
                kind = s % 5
                if kind == 0:
                    a0 = rng.normal(size=n)
                elif kind == 1:
                    a0 = np.abs(rng.normal(size=n))
                elif kind == 2:
                    a0 = rng.exponential(size=n) * rng.choice([-1, 1], size=n, p=[0.2, 0.8])
                elif kind == 3:
                    k = rng.integers(2, min(n, 4) + 1)
                    a0 = 0.15 * np.abs(rng.normal(size=n))
                    a0[:k] = 1 + 0.2 * rng.normal(size=k)
                else:
                    a0 = np.full(n, 0.2 * rng.random())
                    a0[:2] = 1.0
                    a0[2] = rng.random()
                v, a = ascent(a0, X, w, chi)
                if v > top:
                    top, topa = v, a
            r = top / S2(q)
            if r > worst[0]:
                worst = (r, q, n)
            sa = np.sort(np.abs(topa))[::-1]
            sa = sa / np.linalg.norm(sa)
            line.append(f"n={n}:{r:.10f}[{','.join(f'{x:.3f}' for x in sa[:3])}]")
        print(f"P1 q={q:.6f}: " + ' '.join(line), flush=True)
    print(f"P1 max ratio E|L|/S_2: {worst[0]:.15f} at q={worst[1]:.6f}, n={worst[2]}", flush=True)
    return worst


def bulk_law(q, m):
    """atoms and weights of the normalised sum of m chi's"""
    tau = np.sqrt(q * (1 - q))
    k = np.arange(m + 1)
    return (k - m * q) / (tau * np.sqrt(m)), binom.pmf(k, m, q)


def big_atoms(q, a):
    u, v = np.sqrt((1 - q) / q), np.sqrt(q / (1 - q))
    xs, ps = np.array([0.0]), np.array([1.0])
    for ai in a:
        xs = np.concatenate([xs + ai * u, xs - ai * v])
        ps = np.concatenate([ps * q, ps * (1 - q)])
    return xs, ps


def eabs_family(q, a, m):
    a = np.asarray(a, dtype=float)
    s = float(a @ a)
    if s >= 1:
        return -1.0
    b = np.sqrt(1 - s)
    xs, ps = big_atoms(q, a)
    if m == 0:
        return float(ps @ np.abs(xs)) / np.sqrt(s)
    if m == np.inf:
        z = xs / b
        phi = np.exp(-z * z / 2) / np.sqrt(2 * np.pi)
        return float(ps @ (xs * erf(z / np.sqrt(2)) + 2 * b * phi))
    ys, ws = bulk_law(q, m)
    return float(ps @ (np.abs(xs[:, None] + b * ys[None, :]) @ ws))


def part2():
    worst = (0, None)
    ms = list(range(1, 41)) + [50, 60, 80, 100, 150, 200, 300, 400, np.inf]
    for q in QS:
        best_line = []
        for k in (1, 2, 3):
            topk = (0, None)
            for signs in itertools.product([1, -1], repeat=k - 1):
                sg = np.array((1,) + signs, dtype=float)
                for m in ms:
                    def f(x):
                        a = sg * np.abs(x)
                        if a @ a >= 0.999999:
                            return 10.0
                        return -eabs_family(q, a, m) / S2(q)
                    starts = [np.full(k, 0.95 / np.sqrt(k)), np.full(k, 0.7 / np.sqrt(k)),
                              np.array([0.9] + [0.3] * (k - 1)), rng.random(k) * 0.8]
                    for x0 in starts:
                        res = minimize(f, x0, method='Nelder-Mead', options={'xatol': 1e-10, 'fatol': 1e-13, 'maxiter': 4000})
                        r = -res.fun
                        if r > topk[0]:
                            topk = (r, (m, sg * np.abs(res.x)))
            if topk[0] > worst[0]:
                worst = (topk[0], q, k, topk[1])
            m_, a_ = topk[1]
            best_line.append(f"k={k}: {topk[0]:.10f} (m={m_}, a={np.round(a_, 4).tolist()})")
        print(f"P2 q={q:.6f}: " + '; '.join(best_line), flush=True)
    print(f"P2 max ratio E|L|/S_2 over the families: {worst[0]:.15f} at q={worst[1]:.6f}, k={worst[2]}, (m, a)={worst[3]}", flush=True)
    return worst


def equal_k():
    for q in QS:
        vals = []
        for k in range(1, 13):
            xs, ps = big_atoms(q, np.full(k, 1 / np.sqrt(k)))
            vals.append(float(ps @ np.abs(xs)) / S2(q))
        print(f"EQ q={q:.6f}: equal-coefficient ratios k=1..12: " + ' '.join(f'{v:.6f}' for v in vals), flush=True)


if __name__ == '__main__':
    t0 = time.time()
    equal_k()
    w2 = part2()
    w1 = part1()
    print(f"OVERALL max ratio {max(w1[0], w2[0]):.15f} ({time.time() - t0:.0f}s)")
