"""Calibrated negative tests for the MAIN-3 box certificates (my verifier a14_main3_verify.py, k = 3 target).

For every lp certificate and for both certificates (c1: cap min(m_c, mbar); c2: cap min(1, mbar) and p3 <= p*) of every
m-split box, the float slack of the dominance condition, min_y P(y) - F_B(y) with my envelope F_B, and of the moment
condition, min over rho in [0, m*] of h(rho) (Lemma 12 with the target T-(u1, u2)), are computed. On the 200 tightest
certificates of each family the exact check is re-run with
  c0 lowered by 0.5 x min(slacks)   -> must still pass (no over-rejection),
  c0 lowered by 2 x dominance slack -> must be rejected (dominance fails),
  c0 raised by 2 x moment slack     -> must be rejected (moment bound fails).
Lowering c0 by e lowers P - (every envelope line) by e and raises T - A by e, so the first change keeps both conditions."""
import json
import os
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
import a14_main3_verify as K  # noqa: E402

V = K.V
S3 = K.S3_MINE


def slack(box, s, c, mstar, pstar):
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = V.b_range(r1, r2)
    X = V.atoms_X(u1, u2, t1, t2, r1, r2, s)
    B = [(p[0] * blo, p[1] * bhi) for p in V.r_probs(u1, u2)]
    cf = np.array([float(x) for x in c])
    dom = np.inf
    for lo, hi, ic, sl in V.envelope_pieces(X, B):
        a = -40.0 if lo is None else float(lo)
        b = 40.0 if hi is None else float(hi)
        y = np.linspace(a, b, 4001)
        g = np.polyval(cf[::-1], y) - (float(ic) + float(sl) * y)
        i = int(np.argmin(g))
        yy = np.linspace(y[max(i - 1, 0)], y[min(i + 1, len(y) - 1)], 2001)
        g2 = np.polyval(cf[::-1], yy) - (float(ic) + float(sl) * yy)
        dom = min(dom, float(g.min()), float(g2.min()))
    k3, k4, k5, k6, k3sq = K.kappa_ranges(u1, u2)
    c0, c1, c2, c3, c4, c5, c6 = c
    A = c0 + c2 + 3 * c4 + 15 * c6
    Xc = c3 + 10 * c5
    if pstar is not None and Xc >= 0:
        A += k3[0] * Xc * pstar
        Babs = Fr(0)
    else:
        Babs = max(abs(x) for x in K.imul(k3, Xc))
    Chi = K.imul(k4, c4 + 15 * c6)[1]
    Dabs = max(abs(x) for x in K.imul(k5, c5))
    Ehi = K.imul(k6, c6)[1]
    Fhi = max(K.imul(k3sq, 10 * c6)[1], 0)
    G = Chi + Dabs * mstar + Fhi + (Ehi * mstar * mstar if Ehi > 0 else 0)
    Eneg = Ehi if Ehi < 0 else Fr(0)
    T = K.T3_lo(u1, u2, S3)
    rho = np.linspace(0, float(mstar), 4001)
    h = float(T - A) - float(Babs) * rho - float(G) * rho**2 - float(Eneg) * rho**4
    return dom, float(h.min())


def slack_job(args):
    box, s, c, mstar, pstar = args
    return slack(box, s, c, mstar, pstar)


def exact_job(args):
    box, s, c, mstar, pstar = args
    return K.box_cert_ok(box, s, c, mstar, pstar, S3)[0]


def fam_report(name, items, pool, out):
    sl = pool.map(slack_job, items, chunksize=32)
    dom = np.array([x[0] for x in sl])
    mom = np.array([x[1] for x in sl])
    print(f"{name}: {len(items)} certificates; float slack: dominance min {dom.min():.3e}, 1% quantile {np.quantile(dom, 0.01):.3e},"
          f" median {np.median(dom):.3e}; moment min {mom.min():.3e}, 1% quantile {np.quantile(mom, 0.01):.3e},"
          f" median {np.median(mom):.3e}", flush=True)
    ok_all = bool(dom.min() > 0 and mom.min() > 0)
    order = np.argsort(np.minimum(dom, mom))[:200]
    half, dbl = [], []
    for i in order:
        box, s, c, mstar, pstar = items[i]
        e = min(dom[i], mom[i])
        half.append((box, s, [c[0] - Fr(e * 0.5).limit_denominator(10**18)] + list(c[1:]), mstar, pstar))
        dbl.append((box, s, [c[0] - Fr(dom[i] * 2.0).limit_denominator(10**18)] + list(c[1:]), mstar, pstar))
    upm = []
    for i in np.argsort(mom)[:200]:
        box, s, c, mstar, pstar = items[i]
        upm.append((box, s, [c[0] + Fr(float(mom[i]) * 2.0).limit_denominator(10**18)] + list(c[1:]), mstar, pstar))
    r1 = pool.map(exact_job, half, chunksize=4)
    r2 = pool.map(exact_job, dbl, chunksize=4)
    r3 = pool.map(exact_job, upm, chunksize=4)
    p1, j2, j3 = sum(r1), sum(1 for r in r2 if not r), sum(1 for r in r3 if not r)
    print(f"  200 tightest: c0 - 0.5 x min slack still passes {p1}/{len(r1)}; c0 - 2 x dominance slack rejected {j2}/{len(r2)};"
          f" c0 + 2 x moment slack rejected {j3}/{len(r3)}", flush=True)
    out.append(ok_all and p1 == len(r1) and j2 == len(r2) and j3 == len(r3))


def main():
    t0 = time.time()
    man = json.load(open(os.path.join(K.DATA, 'k3_manifest.json')))
    lps, c1s, c2s = [], [], []
    for fn in man['two_files']:
        d = json.load(open(os.path.join(K.DATA, fn)))
        for bx in d['boxes']:
            box = tuple(Fr(x) for x in bx['box'])
            blo, _ = V.b_range(box[4], box[5])
            mbar = V.mbar_of(box[3], box[5], blo)
            if bx['kind'] == 'lp':
                lps.append((box, d['s'], [Fr(x) for x in bx['c']], mbar, None))
            elif bx['kind'] == 'ms':
                mc = Fr(bx['mcut'])
                c1s.append((box, d['s'], [Fr(x) for x in bx['c']], min(mc, mbar), None))
                c2s.append((box, d['s'], [Fr(x) for x in bx['c2']], min(Fr(1), mbar), Fr(bx['p3max'])))
    out = []
    with Pool(8) as pool:
        fam_report("lp certificates", lps, pool, out)
        fam_report("m-split c1 certificates (cap min(m_c, mbar))", c1s, pool, out)
        fam_report("m-split c2 certificates (cap min(1, mbar), p3 <= p*)", c2s, pool, out)
    print(f"RESULT: {'ALL CALIBRATED TESTS BEHAVE AS REQUIRED' if all(out) else 'SOME CALIBRATED TEST MISBEHAVED'}"
          f" ({time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
