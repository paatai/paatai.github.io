"""RQ-AUD negative tests for the MAIN-6 verifier `k5_verify.py`: corrupted copies of RQ-A's records must be rejected
by my check functions (seed 26). Each line reports rejected/total; a corruption that is still accepted is listed,
and counts as a failure only where the corrupted record is certainly invalid. Also unit tests of the two new
helpers: the nested patch minimum (against dense sampling) and the cumulant enclosure (against exact values).
Usage: k5_negative.py [file globs relative to the data directory]   (default: all box files present)"""
import copy
import glob
import math
import os
import random
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import k5_verify as W  # noqa: E402
import a18_k3b_verify as K3B  # noqa: E402
import a11_main2_verify as V  # noqa: E402

RES = []


def report(name, rejected, total, must=True, verb='rejected'):
    ok = rejected == total if must else True
    RES.append(ok)
    print(f"{'PASS' if ok else 'FAIL'} {name}: {verb} {rejected}/{total}" + ("" if must else " (informative)"),
          flush=True)


def jobs_ok(bx):
    jobs, bad = W.vertex_jobs5(bx)
    return not bad and all(W.vjob_check5(j)[0] for j in jobs)


def tree_ok(bx):
    return W.tree_check5((bx,))[0]


def get(b, path):
    for k in path:
        b = b[k]
    return b


def vsets(bx):
    """(path, role, number of patch parameters) of every vertex set of an ms box"""
    out = []

    def node(nd, path, lev):
        out.append((path + ('c1',), f'L{lev} cut', 2 + lev))
        for side in ('plus', 'minus'):
            for i, pc in enumerate(nd[side]):
                p = path + (side, i)
                tp = pc['type']
                if tp == 'TC':
                    out.append((p, f'L{lev} TC{"+" if side == "plus" else "-"}', 3 + lev))
                elif tp == 'SG':
                    out.append((p, f'L{lev} SG', 2 + lev))
                elif tp == 'TCS':
                    out.extend([(p + ('c1',), f'L{lev + 1} TCS cut', 3 + lev),
                                (p + ('c2',), f'L{lev + 1} TCS SG', 3 + lev)])
                elif tp == 'TCN':
                    node(pc, p, lev + 1)
    node(bx, (), 0)
    return out


def nodes(bx):
    out = []

    def node(nd, path, lev):
        out.append((path, lev))
        for i, pc in enumerate(nd['plus']):
            if pc['type'] == 'TCN':
                node(pc, path + ('plus', i), lev + 1)
    node(bx, (), 0)
    return out


def ns_pieces(bx):
    """(levels list, s, n, recorded type) of every near-sphere piece of an ms box"""
    out = []

    def node(nd, lv, lev):
        for pc in nd['plus']:
            m = (Fr(pc['m'][0]), Fr(pc['m'][1]))
            tp = pc['type']
            if tp[0] in 'AB':
                out.append((lv + [m], lev + 3, tp))
            elif tp == 'TCS':
                for a, b, typ in pc['sub']:
                    out.append((lv + [m, (Fr(a), Fr(b))], lev + 4, typ))
            elif tp == 'TCN':
                node(pc, lv + [m], lev + 1)
    node(bx, [], 0)
    return out


def shrink(rec, f):
    Vs = [[Fr(x) for x in v] for v in rec['V']]
    cen = [sum(v[i] for v in Vs) / len(Vs) for i in range(len(Vs[0]))]
    rec['V'] = [[str(c + f * (x - c)) for x, c in zip(v, cen)] for v in Vs]


def unit_patch(rnd):
    """lower bound of h.p_k over random parameter boxes (j = 0..3 peeled coordinates) vs dense sampling"""
    bad, worst = 0, 0.0
    for trial in range(300):
        j = trial % 4
        h = [Fr(rnd.randint(-1000, 1000), 997) for _ in range(j + 3)]
        box = []
        for i in range(j + 2):
            lo = Fr(rnd.randint(0, 900), 1000) if i != 0 else Fr(rnd.randint(0, 400), 1000)
            hi = min(Fr(1), lo + Fr(rnd.randint(1, 100), 1000))
            box.append((lo, hi))
        lb = float(W.patch_dot_lo5(h, tuple(box)))
        grids = [np.linspace(float(a), float(b), 9 if j >= 2 else 25) for a, b in box]
        mesh = np.meshgrid(*grids, indexing='ij')
        t, r = mesh[0], mesh[1]
        c, d = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)
        val = float(h[0]) * r * c + float(h[1]) * r * d
        b = np.sqrt(np.maximum(0, 1 - r * r))
        for i in range(j):
            mu = mesh[2 + i]
            val = val + float(h[2 + i]) * b * mu
            b = b * np.sqrt(np.maximum(0, 1 - mu * mu))
        val = val + float(h[2 + j]) * b
        mn = float(val.min())
        if lb > mn + 1e-12:
            bad += 1
        worst = max(worst, mn - lb)
    return bad, worst


def main():
    t0 = time.time()
    rnd = random.Random(26)
    pats = sys.argv[1:] or ['k5/p_*.json', 'k5/m_*.json']
    files = []
    for pat in pats:
        files += sorted(os.path.relpath(f, W.DATA) for f in glob.glob(os.path.join(W.DATA, pat)))
    _, _, cells, boxes, regions = W.load(files)
    lpv = [bx for bx in boxes if bx['kind'] == 'lpv']
    ms = [bx for bx in boxes if bx['kind'] == 'ms']
    pool = Pool(8)

    bad, worst = unit_patch(rnd)
    report(f'unit: nested patch minimum (j = 0..3) above the sampled minimum (worst gap below {worst:.2e})', 300 - bad,
           300, verb='consistent')
    bad = 0
    for _ in range(200):
        a = W.U_LO + (W.U_HI - W.U_LO) * Fr(rnd.randint(0, 10**5), 10**5)
        b = min(W.U_HI, a + Fr(rnd.randint(1, 3000), 10**5))
        for j in range(3, W.NJ + 1):
            lo, hi = W.kap_iv5(j, a, b)
            xs = [a + (b - a) * Fr(k, 64) for k in range(65)]
            bad += any(not lo <= W.leval(W.KAP[j], x) <= hi for x in xs)
    report('unit: cumulant enclosures contain the exact values (200 random u-intervals, j = 3..10, 65 points)', 1600 - bad,
           1600, verb='consistent')
    c9 = W.CRIT[9][0][0]
    tight = (c9 - Fr(1, 1000), c9 + Fr(1, 1000))
    lo, hi = W.kap_iv5(9, *tight)
    ends = max(W.leval(W.KAP[9], tight[0]), W.leval(W.KAP[9], tight[1]))
    report('unit: around the kappa_9 critical point the enclosure exceeds the end values (non-monotone case handled)',
           int(hi > ends), 1, verb='detected')

    sample = rnd.sample(lpv, min(40, len(lpv)))
    for name in ('constant term -1/20 (domination)', 'constant term +1 (objective bound)',
                 'polytope shrunk 10% about its centre (cone)', 'one vertex moved by 1e-6 (parallelepiped)'):
        bs = []
        for bx in sample:
            b = copy.deepcopy(bx)
            j = rnd.randrange(len(b['C']))
            if name.startswith('constant term -'):
                b['C'][j][0] = str(Fr(b['C'][j][0]) - Fr(1, 20))
            elif name.startswith('constant term +'):
                b['C'][j][0] = str(Fr(b['C'][j][0]) + 1)
            elif name.startswith('polytope'):
                shrink(b, Fr(9, 10))
            else:
                b['V'][j][0] = str(Fr(b['V'][j][0]) + Fr(1, 10**6))
            bs.append(b)
        res = pool.map(jobs_ok, bs)
        report('lpv: ' + name, sum(1 for r in res if not r), len(bs))
    res = pool.map(jobs_ok, sample)
    report(f'lpv: the {len(sample)} uncorrupted boxes (control)', sum(1 for r in res if r), len(sample), verb='accepted')

    allnodes = [(bx, path, lev) for bx in ms for path, lev in nodes(bx)]
    by_lev = {}
    for x in allnodes:
        by_lev.setdefault(x[2], []).append(x)
    for lev in sorted(by_lev):
        pick = rnd.sample(by_lev[lev], min(25, len(by_lev[lev])))
        for name in ('remove one plus piece', 'remove one minus piece', 'lower the top of every piece by 1/100',
                     'lower the cut by 1/50'):
            bad = 0
            for bx, path, _ in pick:
                b = copy.deepcopy(bx)
                nd = get(b, path)
                if name == 'remove one plus piece':
                    nd['plus'].pop(rnd.randrange(len(nd['plus'])))
                elif name == 'remove one minus piece':
                    nd['minus'].pop(rnd.randrange(len(nd['minus'])))
                elif name.startswith('lower the top'):
                    for side in ('plus', 'minus'):
                        top = max(Fr(p['m'][1]) for p in nd[side])
                        for pc in nd[side]:
                            if Fr(pc['m'][1]) == top:
                                pc['m'][1] = str(top - Fr(1, 100))
                else:
                    nd['mc'] = str(Fr(nd['mc']) - Fr(1, 50))
                bad += not tree_ok(b)
            report(f'level-{lev} nodes: {name} (coverage)', bad, len(pick))

    caps = [(bx, path + (side, i)) for bx, path, lev in allnodes for side in ('plus', 'minus')
            for i, pc in enumerate(get(bx, path)[side]) if pc['type'] in ('TC', 'TCS', 'TCN') and Fr(pc['m'][1]) < 1]
    pick = rnd.sample(caps, min(100, len(caps)))
    bad = badt = 0
    for bx, p in pick:
        b = copy.deepcopy(bx)
        get(b, p)['cap'] = get(b, p)['m'][1]
        bad += bool(W.vertex_jobs5(b)[1])
        badt += not tree_ok(b)
    report('TC/TCS/TCN cap replaced by its n2 < kappa(n2) (cap check in part D)', bad, len(pick))
    report('TC/TCS/TCN cap replaced by its n2 < kappa(n2) (cap check in part F)', badt, len(pick))
    phis = [(bx, path + (side, i)) for bx, path, lev in allnodes for side in ('plus', 'minus')
            for i, pc in enumerate(get(bx, path)[side]) if pc['type'] in ('SG', 'TCS')]
    pick = rnd.sample(phis, min(40, len(phis)))
    bad = badt = 0
    for bx, p in pick:
        b = copy.deepcopy(bx)
        pc = get(b, p)
        m1 = Fr(pc['mc']) if pc['type'] == 'TCS' else Fr(pc['m'][0])
        pc['pst'] = str(K3B.sqrt_lo((1 - m1 * m1)**3) - m1**3 - Fr(1, 100))
        bad += bool(W.vertex_jobs5(b)[1])
        badt += not tree_ok(b)
    report(f'SG/TCS value p* lowered to phi(m) - 1/100 (phi check in parts D and F, {len(pick)} pieces)',
           min(bad, badt), len(pick))

    nsp = [(bx, lv, n, tp) for bx in ms for lv, n, tp in ns_pieces(bx)]
    by_n = {}
    for x in nsp:
        by_n.setdefault(x[2], []).append(x)
    for n in sorted(by_n):
        pick = rnd.sample(by_n[n], min(30, len(by_n[n])))
        box_of = lambda bx: tuple(Fr(x) for x in bx['box'])
        ctrl = sum(W.near_n5(box_of(bx), bx['s'], lv) is not None for bx, lv, _, _ in pick)
        report(f'near-sphere n={n}: recorded pieces pass (control)', ctrl, len(pick), verb='accepted')
        wid = sum(W.near_n5(box_of(bx), bx['s'], lv[:-1] + [(lv[-1][0] / 4, lv[-1][1])]) is None
                  for bx, lv, _, _ in pick)
        report(f'near-sphere n={n}: last interval widened from [x1, x2] to [x1/4, x2]', wid, len(pick))
        if n >= 5:
            sg = sum(W.near_n5(box_of(bx), -1, lv) != f'A{n}' for bx, lv, _, _ in pick)
            report(f'near-sphere n={n}: re-checked with s = -1 does not pass (A{n}) (OR-region condition needs s = 1)',
                   sg, len(pick))

    roles = {}
    for bx in ms:
        for path, role, d in vsets(bx):
            roles.setdefault(d, []).append((bx, path, role))
    for d in sorted(roles):
        pick = rnd.sample(roles[d], min(24, len(roles[d])))
        for name in ('constant term -1/20', 'shrunk by 1/2 (cone)'):
            bs = []
            for bx, path, role in pick:
                b = copy.deepcopy(bx)
                rec = get(b, path)
                if name.startswith('constant'):
                    jj = rnd.randrange(len(rec['C']))
                    rec['C'][jj][0] = str(Fr(rec['C'][jj][0]) - Fr(1, 20))
                else:
                    shrink(rec, Fr(1, 2))
                bs.append(b)
            res = pool.map(jobs_ok, bs)
            report(f'vertex sets with {d} patch parameters: {name}', sum(1 for r in res if not r), len(bs))
    flips = [(bx, path + ('plus', i)) for bx, path, lev in allnodes for i, pc in enumerate(get(bx, path)['plus'])
             if pc['type'] == 'TC']
    pick = rnd.sample(flips, min(24, len(flips)))
    bs = []
    for bx, p in pick:
        b = copy.deepcopy(bx)
        nd = get(b, p[:-2])
        pc = nd['plus'].pop(p[-1])
        nd['minus'].append(pc)
        nd['plus'].append({'m': pc['m'], 'type': 'TC', 'cap': '1', 'n0': pc['n0'], 'V': pc['V'], 'C': pc['C']})
        bs.append(b)
    res = pool.map(jobs_ok, bs)
    report('TC+ certificate reused as TC- (sign of the peeled coordinate flipped; informative)',
           sum(1 for r in res if not r), len(bs), must=False)

    for s in (1, -1):
        for fn, ss, reg in [x for x in regions if x[1] == s][:3]:
            bs = [tuple(Fr(x) for x in bx['box']) for bx in boxes if bx['_file'] == fn]
            bs.pop(rnd.randrange(len(bs)))
            ins, voleq, nov = V.tiling3(reg, bs)
            report(f'tiling of {fn} with one box removed', int(not (ins and voleq and nov == 0)), 1)
    if cells:
        cs = rnd.sample(cells, min(30, len(cells)))
        bad = sum(not W.cell_once5(u1, u2, a1, a2, [c[0] + 1] + list(c[1:]))[0] for u1, u2, a1, a2, c in cs)
        report('one-coordinate cells: constant term +1 (objective bound)', bad, len(cs))
    pool.close()
    print(f"RESULT: {'ALL NEGATIVE TESTS PASSED' if all(RES) else 'SOME CORRUPTION ACCEPTED'} ({time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
