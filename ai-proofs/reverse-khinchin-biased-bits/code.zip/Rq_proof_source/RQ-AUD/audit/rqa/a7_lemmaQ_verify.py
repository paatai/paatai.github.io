"""RQ-AUD independent verifier for RQ-A Lemma Q (quartic two-extremiser certificate), from my own
derivation (RQ-A code not consulted).  Arb ball arithmetic (python-flint) with box bisection.

Parametrisation a = 2t/(1+t^2), b = (1-t^2)/(1+t^2), q = 1/(1+u^2), v = 1/u, tau = u/(1+u^2).
Certificate: P(y) = (y+v)^2 Q(y), Q(y) = s + B0 (y-u) + c4 (y-u)^2 with
   s  = tau^2 (1-q)(b u - a v) = tau^3 (b u^2 - a)   [so P(u) = l1(u)],
   B0 = tau^2 (1-q) b - 2 tau s = tau^4 (2a - b(u^2-1))  [so P'(u) = l1'(u)],
   l1(y) = (1-q)(b y - a v), l2(y) = q(-b y - a u), R_a(b y) = max(0, l1, l2).
Derived here:  P - l1 = (y-u)^2 Q1(y), Q1 = c4 z^2 + (2c4/tau + B0) z + (c4/tau^2 + 2B0/tau + s), z = y-u,
   disc(Q1) = B0^2 - 4 c4 (s + B0/tau);  disc(Q) = B0^2 - 4 c4 s.
   E P(M) - E P(chi) = c3 k3 (p3 - 1) + c4 k4 (p4 - 1),  c3 = B0 - 2 c4 k3,  k3^2 - k4 = 2,
   which is <= 0 for all |p3| <= sqrt(p4) <= 1 if c4 >= 0, k4 < 0 and k3 c3 + 2 k4 c4 = k3 B0 - 4 c4 >= 0.
Conditions certified on every box (for all (u,t) in the box):
   (Q0) s > 0, B0 > 0, c4 > 0, k4 < 0, b u^2 > a (R_a(bu) = l1(u)), a u^2 > b (R_a(-bv) = 0),
        v^2 <= b/a <= u^2 (two-coefficient formula E|a chi1 + b chi2| = 2 tau (1-q)(a+b));
   (Q1) 4 c4 s - B0^2 > 0                       => Q > 0 => P >= 0;  and then disc(Q1) < 0 => P >= l1;
   (Q2) k3 B0 - 4 c4 >= 0                       => E P(M) <= E P(chi) = E R_a(b chi);
   (Q3) P(y2 - w) - q b w >= 0 for w >= 0, y2 = -a u/b, via its Taylor coefficients e0..e4:
        e0, e1, e2 >= 0 and (e3 >= 0 or 4 e2 e4 >= e3^2).
Conclusion on the box: E|a chi + bM| <= E|a chi1 + b chi2| = 2 tau (1-q)(a+b) <= 2 tau for q >= q0.
"""
import json
import sys
import time
from fractions import Fraction as Fr

from flint import arb, ctx

ctx.prec = 120
PATH = sys.argv[1] if len(sys.argv) > 1 else 'rqa_data/quartic_cover.json'


def A(x):
    return arb(x.numerator) / arb(x.denominator)


def ball(lo, hi):
    lo, hi = A(lo), A(hi)
    return (lo + hi) / 2 + arb(0, ((hi - lo) / 2).upper()) if False else arb.union(lo, hi)


def conditions(u, t, c4):
    one = arb(1)
    a = 2 * t / (one + t * t)
    b = (one - t * t) / (one + t * t)
    v = one / u
    q = one / (one + u * u)
    p = u * u / (one + u * u)
    tau = u / (one + u * u)
    s = tau**3 * (b * u * u - a)
    B0 = tau**4 * (2 * a - b * (u * u - 1))
    k3 = u - v
    k4 = u * u + v * v - 4
    out = {}
    out['s>0'] = s > 0
    out['B0>0'] = B0 > 0
    out['k4<0'] = k4 < 0
    out['bu2>a'] = b * u * u - a > 0
    out['au2>b'] = a * u * u - b > 0
    out['b/a<=u2'] = u * u * a - b >= 0
    out['b/a>=v2'] = b - v * v * a >= 0
    out['Q1'] = 4 * c4 * s - B0 * B0 > 0
    out['Q1b'] = 4 * c4 * (s + B0 / tau) - B0 * B0 > 0
    out['Q2'] = k3 * B0 - 4 * c4 >= 0
    # P(y) coefficients: (y^2 + 2 v y + v^2)(c4 y^2 + B y + G)
    B = B0 - 2 * c4 * u
    G = s - B0 * u + c4 * u * u
    P = [v * v * G, 2 * v * G + v * v * B, G + 2 * v * B + v * v * c4, B + 2 * v * c4, c4]
    y2 = -a * u / b
    # Taylor coefficients of P at y2: d_k = P^{(k)}(y2)/k!
    d = []
    for k in range(5):
        acc = arb(0)
        for j in range(k, 5):
            binom = [1, 1, 1, 1, 1]
            from math import comb
            acc += comb(j, k) * P[j] * y2**(j - k)
        d.append(acc)
    # P(y2 - w) = sum d_k (-w)^k ; minus q b w
    e0, e1, e2, e3, e4 = d[0], -d[1] - q * b, d[2], -d[3], d[4]
    # h(w) = e0 + e1 w + e2 w^2 + e3 w^3 + e4 w^4 >= 0 on w >= 0, by either
    # (A) e0, e1, e2 >= 0 and (e3 >= 0 or e3^2 <= 4 e2 e4), or
    # (B) h = (sqrt(e0) + e1 w/(2 sqrt(e0)))^2 + w^2 (D/(4e0) + e3 w + e4 w^2), D = 4 e0 e2 - e1^2:
    #     e0 > 0, D >= 0 and (e3 >= 0 or e0 e3^2 <= D e4).
    condA = (e0 >= 0) and (e1 >= 0) and (e2 >= 0) and ((e3 >= 0) or (4 * e2 * e4 - e3 * e3 >= 0))
    D = 4 * e0 * e2 - e1 * e1
    condB = (e0 > 0) and (D >= 0) and ((e3 >= 0) or (D * e4 - e0 * e3 * e3 >= 0))
    out['Q3'] = condA or condB
    return out


def check_box(u1, u2, t1, t2, c4, depth=0, maxdepth=12, stats=None):
    c4b = A(c4)
    res = conditions(arb.union(A(u1), A(u2)), arb.union(A(t1), A(t2)), c4b)
    if c4 > 0 and all(res.values()):
        stats['leaves'] += 1
        stats['maxdepth'] = max(stats['maxdepth'], depth)
        return True, None
    if depth >= maxdepth:
        return False, [k for k, val in res.items() if not val]
    um, tm = (u1 + u2) / 2, (t1 + t2) / 2
    for (x1, x2) in ((u1, um), (um, u2)):
        for (s1, s2) in ((t1, tm), (tm, t2)):
            ok, why = check_box(x1, x2, s1, s2, c4, depth + 1, maxdepth, stats)
            if not ok:
                return False, why
    return True, None


def tiles(region, boxes):
    U1, U2, T1, T2 = region
    us = sorted({U1, U2} | {x for bx in boxes for x in (bx[0], bx[1]) if U1 <= x <= U2})
    ts = sorted({T1, T2} | {x for bx in boxes for x in (bx[2], bx[3]) if T1 <= x <= T2})
    for i in range(len(us) - 1):
        um = (us[i] + us[i + 1]) / 2
        for j in range(len(ts) - 1):
            tm = (ts[j] + ts[j + 1]) / 2
            if not any(bx[0] <= um <= bx[1] and bx[2] <= tm <= bx[3] for bx in boxes):
                return False, (float(um), float(tm))
    return True, None


def main():
    t0 = time.time()
    d = json.load(open(PATH))
    boxes = [(Fr(bx['u1']), Fr(bx['u2']), Fr(bx['t1']), Fr(bx['t2']), Fr(bx['c4'])) for bx in d['boxes']]
    region = [Fr(x) for x in d['region']]
    print("region field:", d['region'])
    U1, U2 = min(bx[0] for bx in boxes), max(bx[1] for bx in boxes)
    T1, T2 = min(bx[2] for bx in boxes), max(bx[3] for bx in boxes)
    print(f"box hull: u [{U1} , {U2}] = [{float(U1)}, {float(U2)}], t [{T1}, {T2}] = [{float(T1):.6f}, {float(T2):.6f}]")
    a_of = lambda t: 2 * t / (1 + t * t)
    print(f"a(t) range: [{float(a_of(T1)):.6f}, {float(a_of(T2)):.6f}]; needs a(T1) <= 16/25: {a_of(T1) <= Fr(16, 25)}, a(T2) >= 77/100: {a_of(T2) >= Fr(77, 100)}")
    ok_t, gap = tiles((U1, U2, T1, T2), boxes)
    print("tiling of hull:", "OK" if ok_t else f"GAP at {gap}")
    stats = {'leaves': 0, 'maxdepth': 0}
    fails = 0
    for bx in boxes:
        ok, why = check_box(*bx, stats=stats)
        if not ok:
            fails += 1
            print(f"  FAIL box u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.6f},{float(bx[3]):.6f}] c4={float(bx[4]):.6g}: {why}")
    print(f"boxes {len(boxes)}, failures {fails}, certified sub-boxes {stats['leaves']}, max depth {stats['maxdepth']}, {time.time() - t0:.1f}s")


if __name__ == '__main__':
    main()
