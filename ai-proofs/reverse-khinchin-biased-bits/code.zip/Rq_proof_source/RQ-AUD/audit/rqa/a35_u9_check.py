"""A.35: independent checks of RQ-A U.9 (Gaussian corner of ID*).

Claim: for every Kolmogorov probability measure K on R,
    | E|Z_K| - sqrt(2/pi) | <= (1/2) int |x| dK(x),
hence E|Z_K| <= C5 = g(2 ln 5/4) whenever int |x| dK <= 2 (C5 - sqrt(2/pi)) = 0.11443178...

Parts (own code; RQ-A's numerics/stein_corner.py is not used):
  S  sympy, exact: the Stein solution f = c M - 1 on (0, oo), M' = w M - 1, f'' and (f''/c)', the identity
     B' - w B + 1 = -6/(w^2 (w^2+3)^2), the closed form (1+w^2) B - w = 2/(w^3+3w), oddness of f.
  A  arb (python-flint, 128 bits), certified at sample points: 0 < f'' < 1, (f''/c)' < 0, M < B on (0, 60];
     f''(0+) = 1; the constant 2 (C5 - c) > 0.114431.
  E  exact enumeration (float64, evidence): two-sided inequality for random K (atoms + Gaussian part), the zero-bias
     identity E[Z f(Z)] = E f'(Z + U X) for compound Poisson K (exact sums) and for one K with a Gaussian part
     (adaptive quadrature split at the kinks of f'), and |f'(a) - f'(b)| <= |a - b| across 0.
  H  hostile Nelder-Mead on the ratio (E|Z_K| - c) / ((1/2) int |x| dK), both signs, atoms in [-5, 5].

Usage: python3 a35_u9_check.py [S|A|E|H|all]
"""
import math
import sys

import numpy as np
from scipy.optimize import minimize
from scipy.special import erfcx, ndtr
from scipy.stats import poisson

C = math.sqrt(2 / math.pi)


def part_S():
    import sympy as sp
    w = sp.symbols('w', positive=True)
    c = sp.sqrt(2 / sp.pi)
    M = sp.sqrt(sp.pi / 2) * sp.exp(w ** 2 / 2) * sp.erfc(w / sp.sqrt(2))
    ok = {}
    ok['M_ode'] = sp.simplify(sp.diff(M, w) - (w * M - 1)) == 0
    ok['M0'] = sp.simplify(M.subs(w, 0) - sp.sqrt(sp.pi / 2)) == 0
    f = c * M - 1
    ok['stein_pos'] = sp.simplify(sp.diff(f, w) - w * f - (w - c)) == 0
    t = sp.symbols('t', real=True)
    inner = sp.integrate((t - c) * sp.exp(-t ** 2 / 2), (t, w, sp.oo))
    f_def = -sp.exp(w ** 2 / 2) * inner
    ok['f_formula'] = sp.simplify(sp.expand_func(f_def - f).rewrite(sp.erfc)) == 0
    tot = sp.integrate((sp.Abs(t) - c) * sp.exp(-t ** 2 / 2), (t, -sp.oo, sp.oo))
    ok['Eh_zero'] = sp.simplify(tot) == 0
    v = sp.symbols('v', positive=True)
    f_neg = sp.exp(v ** 2 / 2) * sp.integrate((-t - c) * sp.exp(-t ** 2 / 2), (t, -sp.oo, -v))
    ok['odd'] = sp.simplify(sp.expand_func(f_neg + f.subs(w, v)).rewrite(sp.erfc)) == 0
    Ms = sp.Function('M')(w)
    fs = c * Ms - 1
    sub = {sp.Derivative(Ms, w): w * Ms - 1}
    f1 = sp.diff(fs, w).subs(sub)
    f2 = sp.expand(sp.diff(f1, w).subs(sub))
    ok['f2'] = sp.simplify(f2 - c * ((1 + w ** 2) * Ms - w)) == 0
    f3 = sp.expand(sp.diff(f2 / c, w).subs(sub))
    ok['f3'] = sp.simplify(f3 - (w * Ms * (w ** 2 + 3) - (w ** 2 + 2))) == 0
    ok['f1_equals_h_plus_wf'] = sp.simplify(f1 - ((w - c) + w * fs)) == 0
    B = (w ** 2 + 2) / (w ** 3 + 3 * w)
    ok['B_identity'] = sp.simplify(sp.diff(B, w) - w * B + 1 + 6 / (w ** 2 * (w ** 2 + 3) ** 2)) == 0
    ok['B_f2_gap'] = sp.simplify((1 + w ** 2) * B - w - 2 / (w ** 3 + 3 * w)) == 0
    ok['B_f3_sign'] = sp.simplify((w * B * (w ** 2 + 3) - (w ** 2 + 2))) == 0
    ok['B_limit'] = sp.limit(w * B, w, sp.oo) == 1
    for k, val in ok.items():
        print(f"S {k}: {val}")
    assert all(ok.values())
    print("PART S PASS")


def part_A():
    from flint import arb, ctx
    ctx.prec = 128
    c = (2 / arb.pi()).sqrt()
    half_pi = (arb.pi() / 2).sqrt()
    two = arb(2)

    def Mills(x):
        return half_pi * (x * x / 2).exp() * (x / two.sqrt()).erfc()

    print("A c*M(0) - 1 =", c * half_pi - 1)
    assert abs(c * half_pi - 1) < arb(10) ** -30
    bad = 0
    npts = 0
    pts = [arb(k) / 64 for k in range(1, 641)] + [arb(10) + arb(k) / 8 for k in range(1, 401)]
    for x in pts:
        Mx = Mills(x)
        B = (x * x + 2) / (x * x * x + 3 * x)
        f2 = c * ((1 + x * x) * Mx - x)
        f3 = x * Mx * (x * x + 3) - (x * x + 2)
        npts += 1
        if not (B - Mx > 0 and f2 > 0 and f2 < 1 and f3 < 0 and f2 < c * 2 / (x * x * x + 3 * x)):
            bad += 1
    print(f"A sample points in (0, 60]: {npts}, not certified: {bad}")
    assert bad == 0
    eps = arb(1) / 10 ** 12
    f2_small = c * ((1 + eps * eps) * Mills(eps) - eps)
    print("A f''(1e-12) =", f2_small)
    assert f2_small < 1 and f2_small > 1 - arb(10) ** -11
    C5 = arb(32) / 25 * (2 * (arb(5) / 4).log()).sqrt()
    thr = 2 * (C5 - c)
    print("A C5 =", C5, " 2(C5 - c) =", thr)
    assert thr > arb(114431) / 10 ** 6
    assert thr < arb(114432) / 10 ** 6
    sqrt2e = (2 / arb(1).exp()).sqrt()
    thrB = 2 * (sqrt2e - c)
    print("A 2(sqrt(2/e) - c) =", thrB, "(RQ-B Prop. 6(b) threshold; 0.11976 exceeds it:", thrB < arb(11976) / 10 ** 5, ")")
    print("PART A PASS")


def mills(x):
    return math.sqrt(math.pi / 2) * erfcx(x / math.sqrt(2))


def f_stein(x):
    x = np.asarray(x, dtype=float)
    a = np.abs(x)
    val = C * math.sqrt(math.pi / 2) * erfcx(a / math.sqrt(2)) - 1
    return np.sign(x) * val


def fp_stein(x):
    a = np.abs(np.asarray(x, dtype=float))
    return C * (a * math.sqrt(math.pi / 2) * erfcx(a / math.sqrt(2)) - 1)


def law(atoms, weights, tol=1e-16):
    """Support points and probabilities of Y = sum_i x_i (N_i - lam_i), lam_i = w_i / x_i^2."""
    ys = np.array([0.0])
    ps = np.array([1.0])
    for x, wgt in zip(atoms, weights):
        lam = wgt / (x * x)
        nmax = int(lam + 12 * math.sqrt(lam) + 40)
        n = np.arange(nmax + 1)
        pn = poisson.pmf(n, lam)
        ys = (ys[:, None] + x * (n[None, :] - lam)).ravel()
        ps = (ps[:, None] * pn[None, :]).ravel()
        keep = ps > tol * 1e-3
        ys, ps = ys[keep], ps[keep]
    return ys, ps


def E_abs(atoms, weights, s2):
    ys, ps = law(atoms, weights)
    if s2 <= 0:
        return float(np.sum(ps * np.abs(ys)))
    s = math.sqrt(s2)
    z = ys / s
    val = ys * (1 - 2 * ndtr(-z)) + 2 * s * np.exp(-z * z / 2) / math.sqrt(2 * math.pi)
    return float(np.sum(ps * val))


def random_K(rng):
    k = int(rng.integers(1, 4))
    atoms = rng.uniform(0.15, 1.6, size=k) * rng.choice([-1, 1], size=k)
    s2 = float(rng.uniform(0, 1)) if rng.random() < 0.6 else 0.0
    wts = rng.dirichlet(np.ones(k)) * (1 - s2)
    lam = wts / atoms ** 2
    if np.max(lam) > 60:
        return random_K(rng)
    return list(atoms), list(wts), s2


def part_E(n=3000, seed=35):
    rng = np.random.default_rng(seed)
    worst_hi = -1e9
    worst_lo = 1e9
    viol = 0
    for _ in range(n):
        atoms, wts, s2 = random_K(rng)
        ez = E_abs(atoms, wts, s2)
        half_l1 = 0.5 * sum(abs(x) * w for x, w in zip(atoms, wts))
        r = (ez - C) / half_l1
        worst_hi = max(worst_hi, r)
        worst_lo = min(worst_lo, r)
        if abs(ez - C) > half_l1 + 1e-12:
            viol += 1
    print(f"E two-sided inequality: {n} random K, violations {viol}, ratio range [{worst_lo:.4f}, {worst_hi:.4f}]")
    zb_err = 0.0
    for _ in range(300):
        atoms, wts, _s = random_K(rng)
        tot = sum(wts)
        wts = [w / tot for w in wts]
        ys, ps = law(atoms, wts)
        lhs = float(np.sum(ps * ys * f_stein(ys)))
        rhs = 0.0
        for x, w in zip(atoms, wts):
            rhs += w * float(np.sum(ps * (f_stein(ys + x) - f_stein(ys)) / x))
        zb_err = max(zb_err, abs(lhs - rhs))
    print(f"E zero-bias identity E[Z f(Z)] = E f'(Z + U X), 300 compound Poisson K: max |lhs - rhs| = {zb_err:.2e}")
    from scipy.integrate import quad
    atoms, wts = [0.7, -1.1], [0.25, 0.15]
    s2 = 0.6
    ys, ps = law(atoms, wts)
    sg = math.sqrt(s2)

    def gauss_mean(fun, y, kinks):
        dens = lambda g: math.exp(-g * g / 2) / math.sqrt(2 * math.pi)
        pts = sorted(set([-12.0, 12.0] + [k for k in kinks if -12 < k < 12]))
        tot = 0.0
        for lo, hi in zip(pts[:-1], pts[1:]):
            tot += quad(lambda g: fun(y + sg * g) * dens(g), lo, hi, epsabs=1e-14, epsrel=1e-13, limit=200)[0]
        return tot

    lhs = 0.0
    rhs = 0.0
    for y, p in zip(ys, ps):
        if p < 1e-15:
            continue
        lhs += p * gauss_mean(lambda z: z * float(f_stein(z)), y, [-y / sg])
        rhs += p * s2 * gauss_mean(lambda z: float(fp_stein(z)), y, [-y / sg])
        for x, w in zip(atoms, wts):
            rhs += p * w * gauss_mean(lambda z: (float(f_stein(z + x)) - float(f_stein(z))) / x, y,
                                      [-y / sg, -(y + x) / sg])
    print(f"E zero-bias identity with Gaussian part 0.6 (adaptive quadrature split at the kinks): lhs {lhs:.12f} "
          f"rhs {rhs:.12f}")
    a = rng.uniform(-5, 5, size=200000)
    b = a + rng.normal(0, 0.5, size=200000)
    lip = np.max(np.abs(fp_stein(a) - fp_stein(b)) / np.abs(a - b))
    xs = np.linspace(-8, 8, 160001)
    stein_res = np.max(np.abs(fp_stein(xs) - xs * f_stein(xs) - (np.abs(xs) - C)))
    print(f"E sup |f'(a) - f'(b)|/|a - b| over 200,000 pairs = {lip:.6f}; Stein equation residual on [-8, 8] = {stein_res:.2e}")
    ok = viol == 0 and zb_err < 1e-10 and abs(lhs - rhs) < 1e-9 and lip <= 1 + 1e-9 and stein_res < 1e-12
    print("PART E PASS" if ok else "PART E FAIL")
    return ok


XMAX = 5.0


def unpack(p):
    k = (len(p) - 1) // 2
    atoms = [float(np.clip(p[i], -XMAX, XMAX)) for i in range(k)]
    atoms = [a if abs(a) >= 0.12 else math.copysign(0.12, a if a != 0 else 1.0) for a in atoms]
    raw = np.exp(np.clip(np.array(list(p[k:2 * k]) + [p[-1]]), -30, 30))
    raw = raw / raw.sum()
    return atoms, list(raw[:k]), float(raw[-1])


def ratio(p, sign):
    atoms, wts, s2 = unpack(p)
    lam = [w / (x * x) for x, w in zip(atoms, wts)]
    if max(lam) > 80:
        return 1e3
    half_l1 = 0.5 * sum(abs(x) * w for x, w in zip(atoms, wts))
    if half_l1 < 1e-9:
        return 1e3
    return -sign * (E_abs(atoms, wts, s2) - C) / half_l1


def part_H(starts=24, seed=36):
    rng = np.random.default_rng(seed)
    out = {}
    for sign in (+1, -1):
        best = (-1e9, None)
        for _ in range(starts):
            k = int(rng.integers(1, 4))
            p0 = np.concatenate([rng.uniform(-3, 3, k), rng.normal(0, 1, k), [rng.normal(-1, 1)]])
            res = minimize(ratio, p0, args=(sign,), method='Nelder-Mead',
                           options={'maxiter': 3000, 'xatol': 1e-7, 'fatol': 1e-10})
            val = -res.fun
            if val > best[0]:
                best = (val, unpack(res.x))
        out[sign] = best
        atoms, wts, s2 = best[1]
        print(f"H sign {sign:+d}: max of sign*(E|Z| - c)/((1/2) int|x| dK) = {best[0]:.5f} at atoms "
              f"{[round(a, 4) for a in atoms]}, weights {[round(w, 4) for w in wts]}, gaussian {s2:.4f}")
    ok = out[1][0] < 1 and out[-1][0] < 1
    print("PART H: NO VIOLATION" if ok else "PART H: VIOLATION")
    return ok


if __name__ == '__main__':
    what = sys.argv[1] if len(sys.argv) > 1 else 'all'
    if what in ('S', 'all'):
        part_S()
    if what in ('A', 'all'):
        part_A()
    if what in ('E', 'all'):
        part_E()
    if what in ('H', 'all'):
        part_H()
