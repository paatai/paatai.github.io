"""RQ-AUD attack on RQ-A MAIN-3: search for unit alpha with E|sum alpha_i chi_i| > T(q) = 2 sqrt3 (1-q)^2 tau
for q in [25/169, q3]. Evidence only (floating point).

Part 1: exact enumeration over {0,1}^n, n = 3..16, duality ascent alpha <- (Delta_i(1{L>0}))_i (never decreases
        E|L|/|alpha|), random and structured starts.
Part 2: families with a binomial bulk: alpha = (a_1, ..., a_k, b/sqrt m, ..., b/sqrt m) (m equal small
        coefficients, k = 1..4 large ones, sign patterns), E|L| computed exactly from the binomial law;
        Nelder-Mead over the large coefficients, m up to 400, plus the Gaussian bulk (m = infinity).
Mode 'low' (info): q in [q4, 25/169) and just below q4, where (1,1,1,1)/2 overtakes (1,1,1)/sqrt3.
"""
import itertools
import sys
import time
from multiprocessing import Pool

import numpy as np
from scipy.optimize import minimize
from scipy.special import erf
from scipy.stats import binom

Q3 = 1 - np.sqrt(2 / 3)
Q4 = 1 - np.sqrt(3) / 2
QL = 25 / 169
QS = [QL, 0.15, 0.155, 0.16, 0.165, 0.17, 0.175, 0.18, Q3 - 1e-4, Q3]
QS_LOW = [Q4 - 1e-3, Q4, Q4 + 1e-4, 0.135, 0.1375, 0.14, 0.1425, 0.145, 0.1475]
NS = list(range(3, 17))
STARTS = int(sys.argv[1]) if len(sys.argv) > 1 else 40
if len(sys.argv) > 2 and sys.argv[2] == 'low':
    QS = QS_LOW
PARTS = sys.argv[3] if len(sys.argv) > 3 else '12'


def T3(q):
    return 2 * np.sqrt(3) * (1 - q)**2 * np.sqrt(q * (1 - q))


def tables(n, q):
    X = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1).astype(np.float64)
    k = X.sum(1)
    w = q ** k * (1 - q) ** (n - k)
    tau = np.sqrt(q * (1 - q))
    chi = (X - q) / tau
    return X, w, chi


def value(alpha, w, chi):
    return float(w @ np.abs(chi @ alpha)) / float(np.linalg.norm(alpha))


def ascent(alpha, X, w, chi, iters=300):
    best = value(alpha, w, chi)
    q1 = X.T @ w
    for _ in range(iters):
        f = ((chi @ alpha) > 0).astype(np.float64)
        e1 = (X * (f * w)[:, None]).sum(0) / q1
        e0 = ((1 - X) * (f * w)[:, None]).sum(0) / (1 - q1)
        new = e1 - e0
        if np.linalg.norm(new) == 0:
            break
        v = value(new, w, chi)
        if v <= best + 1e-15:
            break
        alpha, best = new, v
    return best, alpha


def part1_q(q):
    rng = np.random.default_rng(int(q * 1e9) + 7)
    line, worst = [], (0, None)
    for n in NS:
        X, w, chi = tables(n, q)
        top, topa = 0, None
        for s in range(STARTS):
            kind = s % 6
            if kind == 0:
                a0 = rng.normal(size=n)
            elif kind == 1:
                a0 = np.abs(rng.normal(size=n))
            elif kind == 2:
                a0 = rng.exponential(size=n) * rng.choice([-1, 1], size=n, p=[0.2, 0.8])
            elif kind == 3:
                k = rng.integers(2, min(n, 5) + 1)
                a0 = 0.15 * np.abs(rng.normal(size=n))
                a0[:k] = 1 + 0.2 * rng.normal(size=k)
            elif kind == 4:
                a0 = np.full(n, 0.2 * rng.random())
                a0[:3] = 1.0
                if n > 3:
                    a0[3] = rng.random()
            else:
                k = min(4, n)
                a0 = np.zeros(n)
                a0[:k] = 1 + 0.1 * rng.normal(size=k)
                a0[k:] = 0.1 * rng.random()
            v, a = ascent(a0, X, w, chi)
            if v > top:
                top, topa = v, a
        r = top / T3(q)
        if r > worst[0]:
            worst = (r, q, n)
        sa = np.sort(np.abs(topa))[::-1]
        sa = sa / np.linalg.norm(sa)
        line.append(f"n={n}:{r:.10f}[{','.join(f'{x:.3f}' for x in sa[:4])}]")
    return f"P1 q={q:.6f}: " + ' '.join(line), worst


def bulk_law(q, m):
    tau = np.sqrt(q * (1 - q))
    k = np.arange(m + 1)
    return (k - m * q) / (tau * np.sqrt(m)), binom.pmf(k, m, q)


def big_atoms(q, a):
    u, v = np.sqrt((1 - q) / q), np.sqrt(q / (1 - q))
    xs, ps = np.array([0.0]), np.array([1.0])
    for ai in a:
        xs = np.concatenate([xs + ai * u, xs - ai * v])
        ps = np.concatenate([ps * q, ps * (1 - q)])
    return xs, ps


def eabs_family(q, a, m):
    a = np.asarray(a, dtype=float)
    s = float(a @ a)
    if s >= 1:
        return -1.0
    b = np.sqrt(1 - s)
    xs, ps = big_atoms(q, a)
    if m == 0:
        return float(ps @ np.abs(xs)) / np.sqrt(s)
    if m == np.inf:
        z = xs / b
        phi = np.exp(-z * z / 2) / np.sqrt(2 * np.pi)
        return float(ps @ (xs * erf(z / np.sqrt(2)) + 2 * b * phi))
    ys, ws = bulk_law(q, m)
    return float(ps @ (np.abs(xs[:, None] + b * ys[None, :]) @ ws))


def part2_q(q):
    rng = np.random.default_rng(int(q * 1e9) + 11)
    worst = (0, None)
    best_line = []
    for k in (1, 2, 3, 4):
        ms = list(range(1, 41)) + [50, 60, 80, 100, 150, 200, 300, 400, np.inf] if k <= 3 else \
            list(range(1, 13)) + [16, 20, 30, 50, 100, 200, np.inf]
        pats = list(itertools.product([1, -1], repeat=k - 1)) if k <= 3 else [(1, 1, 1), (1, 1, -1), (1, -1, -1)]
        topk = (0, None)
        for signs in pats:
            sg = np.array((1,) + signs, dtype=float)
            for m in ms:
                def f(x):
                    a = sg * np.abs(x)
                    if a @ a >= 0.999999:
                        return 10.0
                    return -eabs_family(q, a, m) / T3(q)
                starts = [np.full(k, 0.95 / np.sqrt(k)), np.full(k, 0.7 / np.sqrt(k)),
                          np.array([0.9] + [0.3] * (k - 1)), rng.random(k) * 0.8]
                for x0 in starts:
                    res = minimize(f, x0, method='Nelder-Mead', options={'xatol': 1e-10, 'fatol': 1e-13, 'maxiter': 4000})
                    r = -res.fun
                    if r > topk[0]:
                        topk = (r, (m, sg * np.abs(res.x)))
        if topk[0] > worst[0]:
            worst = (topk[0], q, k, topk[1])
        m_, a_ = topk[1]
        best_line.append(f"k={k}: {topk[0]:.10f} (m={m_}, a={np.round(a_, 4).tolist()})")
    return f"P2 q={q:.6f}: " + '; '.join(best_line), worst


def equal_k():
    for q in QS:
        vals = []
        for k in range(1, 13):
            xs, ps = big_atoms(q, np.full(k, 1 / np.sqrt(k)))
            vals.append(float(ps @ np.abs(xs)) / T3(q))
        print(f"EQ q={q:.6f}: equal-coefficient ratios k=1..12: " + ' '.join(f'{v:.6f}' for v in vals), flush=True)


if __name__ == '__main__':
    t0 = time.time()
    equal_k()
    best = []
    with Pool(8) as pool:
        if '2' in PARTS:
            r2 = pool.map(part2_q, QS)
            for line, _ in r2:
                print(line, flush=True)
            w2 = max((w for _, w in r2), key=lambda w: w[0])
            best.append(w2[0])
            print(f"P2 max ratio E|L|/T over the families: {w2[0]:.15f} at q={w2[1]:.6f}, k={w2[2]}, (m, a)={w2[3]} ({time.time() - t0:.0f}s)", flush=True)
        if '1' in PARTS:
            r1 = pool.map(part1_q, QS)
            for line, _ in r1:
                print(line, flush=True)
            w1 = max((w for _, w in r1), key=lambda w: w[0])
            best.append(w1[0])
            print(f"P1 max ratio E|L|/T: {w1[0]:.15f} at q={w1[1]:.6f}, n={w1[2]}", flush=True)
    print(f"OVERALL max ratio (parts {PARTS}) {max(best):.15f} ({time.time() - t0:.0f}s)")
