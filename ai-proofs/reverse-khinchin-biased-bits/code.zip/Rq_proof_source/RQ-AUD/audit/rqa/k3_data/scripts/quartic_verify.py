"""Rigorous verification of the quartic two-extremiser certificate on a (u,t) box.

Parametrisation: q = 1/(1+u^2) (u >= 1), a = 2t/(1+t^2), b = (1-t^2)/(1+t^2) (0 < t < 1).
For each sub-box a rational constant c4 is chosen (floating point heuristics) and the
following are verified with exact rational interval arithmetic (outward dyadic rounding):
  (T)  b u^2 - a > 0 and a u^2 - b > 0                      (two-point regime);
  (Q1) 4 c4 s - B0^2 > 0, B0 > 0                            (P >= 0, and Q2: P >= l1);
  (Q4) kappa3 B0 - 4 c4 >= 0, c4 > 0                         (E P(M) <= E P(chi));
  (Q3) e0 > 0 and e2 - min(e1,0)^2/(4 e0) - min(e3,0)^2/(4 c4) > 0   (P >= l2).
See MAIN_RESULT (Lemma Q) for why these imply E|L| <= 2 tau (1-q)(a+b).

Usage: python3 quartic_verify.py <u_lo> <u_hi> <t_lo> <t_hi> <outfile>
"""
import json
import sys
import time
from fractions import Fraction as Fr
from math import floor, ceil

import numpy as np

SH = 120
SC = 1 << SH


def rd(x):
    return Fr(floor(x * SC), SC)


def ru(x):
    return Fr(ceil(x * SC), SC)


class I:
    __slots__ = ("lo", "hi")

    def __init__(self, lo, hi=None):
        if hi is None:
            hi = lo
        lo, hi = Fr(lo), Fr(hi)
        assert lo <= hi
        self.lo, self.hi = rd(lo), ru(hi)

    def __add__(self, o):
        o = o if isinstance(o, I) else I(o)
        return I(self.lo + o.lo, self.hi + o.hi)

    __radd__ = __add__

    def __neg__(self):
        return I(-self.hi, -self.lo)

    def __sub__(self, o):
        o = o if isinstance(o, I) else I(o)
        return I(self.lo - o.hi, self.hi - o.lo)

    def __rsub__(self, o):
        return I(o) - self

    def __mul__(self, o):
        o = o if isinstance(o, I) else I(o)
        p = (self.lo * o.lo, self.lo * o.hi, self.hi * o.lo, self.hi * o.hi)
        return I(min(p), max(p))

    __rmul__ = __mul__

    def inv(self):
        assert self.lo > 0 or self.hi < 0, "division by interval containing 0"
        return I(1 / self.hi, 1 / self.lo)

    def __truediv__(self, o):
        o = o if isinstance(o, I) else I(o)
        return self * o.inv()

    def __rtruediv__(self, o):
        return I(o) * self.inv()

    def sq(self):
        if self.lo >= 0:
            return I(self.lo ** 2, self.hi ** 2)
        if self.hi <= 0:
            return I(self.hi ** 2, self.lo ** 2)
        return I(0, max(self.lo ** 2, self.hi ** 2))

    def __pow__(self, n):
        r = I(1)
        for _ in range(n):
            r = r * self
        return r


def box_quantities(u1, u2, t1, t2, c4):
    """Interval enclosures of all certificate quantities over the box (exact c4)."""
    u1, u2, t1, t2, c4 = map(Fr, (u1, u2, t1, t2, c4))
    assert 1 <= u1 <= u2 and 0 < t1 <= t2 < 1
    U = I(u1, u2)
    a = I(2 * t1 / (1 + t1 * t1), 2 * t2 / (1 + t2 * t2))          # increasing in t
    b = I((1 - t2 * t2) / (1 + t2 * t2), (1 - t1 * t1) / (1 + t1 * t1))  # decreasing in t
    U2 = I(u1 * u1, u2 * u2)
    X = U2 - 1
    tau = I(u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))                # decreasing for u >= 1
    q = I(1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    v = I(1 / u2, 1 / u1)
    T1 = b * U2 - a
    T2 = a * U2 - b
    B0 = tau ** 4 * (2 * a - b * X)
    s = tau ** 3 * T1
    k3 = X * v
    Q1 = 4 * c4 * s - B0.sq()
    Q4 = k3 * B0 - 4 * c4
    out = dict(T1=T1, T2=T2, B0=B0, s=s, Q1=Q1, Q4=Q4)
    if T2.lo <= 0 or T1.lo <= 0:
        return out
    B = B0 - 2 * c4 * U
    G = s - B0 * U + c4 * U2
    z0 = a * U / b
    d = T2 / (b * U)
    g1 = 2 * c4 * z0 - B
    g0 = c4 * z0.sq() - B * z0 + G
    d2 = d.sq()
    e0 = d2 * g0
    e1 = d2 * g1 + 2 * d * g0 - q * b
    e2 = d2 * c4 + 2 * d * g1 + g0
    e3 = 2 * d * c4 + g1
    out.update(e0=e0, e1=e1, e2=e2, e3=e3)
    if e0.lo > 0:
        m1 = min(e1.lo, Fr(0))
        m3 = min(e3.lo, Fr(0))
        out["Q3"] = e2.lo - m1 * m1 / (4 * e0.lo) - m3 * m3 / (4 * c4)
    return out


class D:
    """Interval value together with interval enclosures of d/du and d/dt (forward mode)."""
    __slots__ = ("v", "du", "dt")

    def __init__(self, v, du=None, dt=None):
        self.v = v if isinstance(v, I) else I(v)
        self.du = du if du is not None else I(0)
        self.dt = dt if dt is not None else I(0)

    @staticmethod
    def c(x):
        return x if isinstance(x, D) else D(I(x))

    def __add__(self, o):
        o = D.c(o)
        return D(self.v + o.v, self.du + o.du, self.dt + o.dt)

    __radd__ = __add__

    def __neg__(self):
        return D(-self.v, -self.du, -self.dt)

    def __sub__(self, o):
        o = D.c(o)
        return D(self.v - o.v, self.du - o.du, self.dt - o.dt)

    def __rsub__(self, o):
        return D.c(o) - self

    def __mul__(self, o):
        o = D.c(o)
        return D(self.v * o.v, self.du * o.v + self.v * o.du, self.dt * o.v + self.v * o.dt)

    __rmul__ = __mul__

    def inv(self):
        iv = self.v.inv()
        m = -(iv.sq())
        return D(iv, self.du * m, self.dt * m)

    def __truediv__(self, o):
        return self * D.c(o).inv()

    def __rtruediv__(self, o):
        return D.c(o) * self.inv()

    def sq(self):
        return D(self.v.sq(), 2 * self.v * self.du, 2 * self.v * self.dt)

    def __pow__(self, n):
        r = D(I(1))
        for _ in range(n):
            r = r * self
        return r


def smooth_quantities(U, T, c4, s1=1, s3=1):
    """The certificate quantities as arithmetic expressions in U (=u) and T (=t)."""
    a = 2 * T / (1 + T * T)
    b = (1 - T * T) / (1 + T * T)
    U2 = U * U
    X = U2 - 1
    tau = U / (1 + U2)
    q = 1 / (1 + U2)
    T1 = b * U2 - a
    T2 = a * U2 - b
    B0 = tau ** 4 * (2 * a - b * X)
    s = tau ** 3 * T1
    Q1 = 4 * c4 * s - B0.sq()
    Q4 = X / U * B0 - 4 * c4
    B = B0 - 2 * c4 * U
    G = s - B0 * U + c4 * U2
    z0 = a * U / b
    d = T2 / (b * U)
    g1 = 2 * c4 * z0 - B
    g0 = c4 * z0.sq() - B * z0 + G
    d2 = d.sq()
    e0 = d2 * g0
    e1 = d2 * g1 + 2 * d * g0 - q * b
    e2 = d2 * c4 + 2 * d * g1 + g0
    e3 = 2 * d * c4 + g1
    H = e2 - s1 * e1.sq() / (4 * e0) - s3 * e3.sq() / (4 * c4)
    return dict(T1=T1, T2=T2, B0=B0, Q1=Q1, Q4=Q4, e0=e0, e1=e1, e3=e3, H=H)


def mv_lower(u1, u2, t1, t2, c4, s1=1, s3=1):
    """Rigorous lower bounds of the quantities over the box via the mean value form,
    intersected with the naive interval enclosure."""
    uc, tc = (u1 + u2) / 2, (t1 + t2) / 2
    hu, ht = (u2 - u1) / 2, (t2 - t1) / 2
    cen = smooth_quantities(D(I(uc)), D(I(tc)), c4, s1, s3)
    box = smooth_quantities(D(I(u1, u2), I(1), I(0)), D(I(t1, t2), I(0), I(1)), c4, s1, s3)
    out = {}
    for k in cen:
        mv = cen[k].v + box[k].du * I(-hu, hu) + box[k].dt * I(-ht, ht)
        out[k] = (max(mv.lo, box[k].v.lo), min(mv.hi, box[k].v.hi))
    return out


def check_box(u1, u2, t1, t2, c4):
    """True only if all certificate conditions hold on the whole box (rigorous)."""
    c4 = Fr(c4)
    u1, u2, t1, t2 = map(Fr, (u1, u2, t1, t2))
    assert 1 <= u1 <= u2 and 0 < t1 <= t2 < 1
    if c4 <= 0:
        return False, "c4"
    try:
        pre = mv_lower(u1, u2, t1, t2, c4)
    except AssertionError:
        return False, "div"
    if pre["T1"][0] <= 0 or pre["T2"][0] <= 0:
        return False, "T"
    if pre["B0"][0] <= 0 or pre["Q1"][0] <= 0:
        return False, "Q1"
    if pre["Q4"][0] < 0:
        return False, "Q4"
    if pre["e0"][0] <= 0:
        return False, "Q3e0"
    # min(e,0)^2 <= e^2 always, and = 0 when e >= 0 on the box
    s1 = 0 if pre["e1"][0] >= 0 else 1
    s3 = 0 if pre["e3"][0] >= 0 else 1
    fin = mv_lower(u1, u2, t1, t2, c4, s1, s3) if (s1, s3) != (1, 1) else pre
    if fin["H"][0] <= 0:
        return False, "Q3"
    return True, "ok"


# ---------- floating point choice of c4 ----------
def fpieces(u, t, c4):
    a, b = 2 * t / (1 + t * t), (1 - t * t) / (1 + t * t)
    v = 1 / u
    tau = u / (1 + u * u)
    X = u * u - 1
    q = 1 / (1 + u * u)
    B0 = tau ** 4 * (2 * a - b * X)
    s = tau ** 3 * (b * u * u - a)
    B = B0 - 2 * c4 * u
    G = s - B0 * u + c4 * u * u
    z0 = a * u / b
    d = z0 - v
    g1 = 2 * c4 * z0 - B
    g0 = c4 * z0 * z0 - B * z0 + G
    e0 = d * d * g0
    e1 = d * d * g1 + 2 * d * g0 - q * b
    e2 = d * d * c4 + 2 * d * g1 + g0
    e3 = 2 * d * c4 + g1
    c4lo = B0 * B0 / (4 * s)
    c4hi = X / u * B0 / 4
    q3 = e2 - min(e1, 0) ** 2 / (4 * e0) - min(e3, 0) ** 2 / (4 * c4) if e0 > 0 else -1
    return c4lo, c4hi, q3


def choose_c4(u1, u2, t1, t2, n=300):
    pts = [(u, t) for u in (u1, (u1 + u2) / 2, u2) for t in (t1, (t1 + t2) / 2, t2)]
    lo = max(fpieces(u, t, 1e-3)[0] for (u, t) in pts)
    hi = min(fpieces(u, t, 1e-3)[1] for (u, t) in pts)
    if hi <= lo:
        return None
    best = None
    for c4 in np.linspace(lo, hi, n)[1:-1]:
        sc = min(min((c4 - fpieces(u, t, c4)[0]) / c4, (fpieces(u, t, c4)[1] - c4) / c4,
                     fpieces(u, t, c4)[2] / 0.01) for (u, t) in pts)
        if best is None or sc > best[0]:
            best = (sc, c4)
    return Fr(best[1]).limit_denominator(10 ** 7)


def cover(u_lo, u_hi, t_lo, t_hi, nu=4, nt=8, maxdepth=12, log=print):
    us = [u_lo + (u_hi - u_lo) * Fr(i, nu) for i in range(nu + 1)]
    ts = [t_lo + (t_hi - t_lo) * Fr(j, nt) for j in range(nt + 1)]
    stack = [(us[i], us[i + 1], ts[j], ts[j + 1], 0) for i in range(nu) for j in range(nt)]
    done, failed = [], []
    t0 = time.time()
    while stack:
        u1, u2, t1, t2, dep = stack.pop()
        c4 = choose_c4(float(u1), float(u2), float(t1), float(t2))
        ok, why = (False, "noc4") if c4 is None else check_box(u1, u2, t1, t2, c4)
        if ok:
            done.append({"u1": str(u1), "u2": str(u2), "t1": str(t1), "t2": str(t2), "c4": str(c4)})
            continue
        if dep >= maxdepth:
            failed.append((float(u1), float(u2), float(t1), float(t2), why))
            log("FAILED box u[%.6f,%.6f] t[%.6f,%.6f] (%s)" % (float(u1), float(u2), float(t1), float(t2), why))
            continue
        um, tm = (u1 + u2) / 2, (t1 + t2) / 2
        for (x1, x2) in [(u1, um), (um, u2)]:
            for (y1, y2) in [(t1, tm), (tm, t2)]:
                stack.append((x1, x2, y1, y2, dep + 1))
    log("boxes verified: %d, failed: %d, %.0fs" % (len(done), len(failed), time.time() - t0))
    return done, failed


if __name__ == "__main__":
    u_lo, u_hi, t_lo, t_hi = (Fr(x) for x in sys.argv[1:5])
    done, failed = cover(u_lo, u_hi, t_lo, t_hi)
    json.dump({"region": [str(u_lo), str(u_hi), str(t_lo), str(t_hi)], "boxes": done, "failed": failed},
              open(sys.argv[5], "w"))
