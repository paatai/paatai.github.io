"""Statistics of a two-coordinate / one-coordinate cover listed in outputs/k<K>_manifest.json
(box counts per kind and sign, width ranges, m-split pieces).  Usage: [RQ_K=3] python3 cover_stats.py"""
import json
import os
from collections import Counter
from fractions import Fraction as Fr

K = int(os.environ.get("RQ_K", "2"))
OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "outputs")
man = json.load(open(os.path.join(OUT, "k%d_manifest.json" % K)))

ncell = 0
for fn in man["one_files"]:
    dd = json.load(open(os.path.join(OUT, fn)))
    ncell += len(dd["cells"])
print("one-coordinate cells: %d in %d files" % (ncell, len(man["one_files"])))

cnt = {1: Counter(), -1: Counter()}
wmin, wmax = [Fr(10)] * 3, [Fr(0)] * 3
npieces, ptype, mcs, umin_ms = 0, Counter(), Counter(), None
for fn in man["two_files"]:
    dd = json.load(open(os.path.join(OUT, fn)))
    s = dd["s"]
    for bx in dd["boxes"]:
        cnt[s][bx["kind"]] += 1
        b = [Fr(x) for x in bx["box"]]
        for i in range(3):
            w = b[2 * i + 1] - b[2 * i]
            wmin[i], wmax[i] = min(wmin[i], w), max(wmax[i], w)
        if bx["kind"] == "ms":
            mcs[bx["mcut"]] += 1
            umin_ms = b[0] if umin_ms is None else min(umin_ms, b[0])
            for p in bx["pieces"]:
                if p[2] == 1:
                    npieces += 1
                    ptype[p[3] if len(p) > 3 else "?"] += 1
kinds = ["lp", "ncA", "ncB", "ms", "small"]
for s in (1, -1):
    row = [cnt[s][k] for k in kinds]
    print("s=%+d  " % s + "  ".join("%s %d" % (k, n) for k, n in zip(kinds, row)) + "  total %d" % sum(row))
print("total boxes %d" % sum(sum(c.values()) for c in cnt.values()))
print("widths: u [%s, %s]  t [%s, %s]  r [%s, %s]" % tuple(
    "%.3g" % float(x) for pair in zip(wmin, wmax) for x in pair))
print("ms boxes: min u1 %s; pieces (s3=+1) %d, types %s; m_c values %s" % (
    umin_ms, npieces, dict(ptype), dict(sorted(mcs.items(), key=lambda kv: Fr(kv[0])))))
