"""BF3 Lemma 9.5: symbolic check of A'(w) and B'(w) (closes CLAIMS K.1)."""
import sympy as sp
w = sp.symbols("w", positive=True)
E = sp.exp(-w ** 2 / 2)
# d/dw int_w^oo e^{-x^2/2} dx = -E
dA = -E - sp.diff(w / (1 + w ** 2) * E, w)
dB = sp.diff((w ** 2 + 2) / (w ** 3 + 3 * w) * E, w) + E
assert sp.simplify(dA - (-2 * E / (1 + w ** 2) ** 2)) == 0
assert sp.simplify(dB - (-6 * E / (w ** 2 * (w ** 2 + 3) ** 2))) == 0
print("BF3 Lemma 9.5: A'(w) = -2e^{-w^2/2}/(1+w^2)^2, B'(w) = -6e^{-w^2/2}/(w^2(w^2+3)^2): verified")
m = sp.Function("m")
# Lemma 9.6: k = (1+w^2) m - w, with m' = w m - 1: k' = (w^3+3w) m - (w^2+2)
mm = sp.Symbol("mm")
kprime = 2 * w * mm + (1 + w ** 2) * (w * mm - 1) - 1
assert sp.expand(kprime - ((w ** 3 + 3 * w) * mm - (w ** 2 + 2))) == 0
print("BF3 Lemma 9.6: k'(w) = (w^3+3w) m - (w^2+2): verified")
