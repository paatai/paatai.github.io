"""Six-moment LP against the k=2 target 2 sqrt2 (1-q) tau on q in [q3, q0] (floating point)."""
import sys
import numpy as np
from moment_lp3 import lp6
qs = [float(x) for x in sys.argv[1:]] or [0.1835, 0.19, 0.2, 0.22, 0.24, 0.26, 0.28, 0.29]
As = np.unique(np.round(np.concatenate([np.arange(0.01, 0.999, 0.02), [0.5, 0.55, 0.5774, 0.6, 0.65, 0.7, 0.7071, 0.72, 0.75, 0.8]]), 4))
for q in qs:
    tgt = np.sqrt(2) * (1 - q)
    out = []
    for a in As:
        r = lp6(q, a, tails=False, absM=False, N=3001)[1]
        out.append(r / tgt)
    out = np.array(out)
    i = np.argmax(out)
    print("q=%.4f  max ratio/target %.6f at a=%.4f ; a with ratio>1: %s" % (q, out[i], As[i], As[out > 1 + 1e-9][:12]), flush=True)
    print("     ", " ".join("%.3f:%.4f" % (a, r) for a, r in zip(As[::3], out[::3])), flush=True)
