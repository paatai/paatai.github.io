"""Float exploration of the m-split near the k=3 point (1,1,1)/sqrt3 (evidence only).

Branch m <= mcut: two-coordinate six-moment LP with mbar = min(mcut, a2/b).
Branch m >= mcut: three-coordinate near-sphere test
   (27/128) E4 b'^2 (1+r') sum_j p_j/|y_j|^3 <= T,   b' = b sqrt(1-m^2), r' = sqrt(1-b'^2),
   y_j atoms of a1 chi1 + a2 chi2 + b m chi3, E4 = 3 + max(0, kappa4).
usage: msplit_explore.py u [mcuts...]
"""
import sys
import numpy as np
import lp2c


def atoms3(u, a):
    v = 1 / u
    q = 1 / (1 + u * u)
    ys, ps = [], []
    for x1, p1 in ((u, q), (-v, 1 - q)):
        for x2, p2 in ((u, q), (-v, 1 - q)):
            for x3, p3 in ((u, q), (-v, 1 - q)):
                ys.append(a[0] * x1 + a[1] * x2 + a[2] * x3)
                ps.append(p1 * p2 * p3)
    return np.array(ys), np.array(ps)


def nsphere_ratio(u, a1, a2, b, m):
    q = 1 / (1 + u * u)
    T = lp2c.target(q)
    k4 = u * u + 1 / (u * u) - 4
    E4 = 3 + max(0.0, k4)
    bp = b * np.sqrt(1 - m * m)
    rp = np.sqrt(1 - bp * bp)
    ys, ps = atoms3(u, (a1, a2, b * m))
    return 27 / 128 * E4 * bp * bp * (1 + rp) * np.sum(ps / np.abs(ys) ** 3) / T


if __name__ == "__main__":
    u = float(sys.argv[1])
    mcuts = [float(x) for x in sys.argv[2:]] or [0.6, 0.65, 0.7, 0.75, 0.8]
    q = 1 / (1 + u * u)
    T = lp2c.target(q)
    print("u=%.6f q=%.6f T=%.6f" % (u, q, T))
    grid = np.arange(0.47, 0.70, 0.02)
    for mc in mcuts:
        worst_lp, worst_ns = (9, None), (0, None)
        for a1 in grid:
            for a2 in grid:
                if a2 > a1 or a1 * a1 + a2 * a2 >= 1:
                    continue
                b = np.sqrt(1 - a1 * a1 - a2 * a2)
                mb = min(1.0, a2 / b)
                if mb <= mc:
                    continue
                val = lp2c.solve(q, a1, a2, 1, mcap=mc)
                if T - val < worst_lp[0]:
                    worst_lp = (T - val, (round(a1, 3), round(a2, 3)))
                rat = max(nsphere_ratio(u, a1, a2, b, m) for m in np.linspace(mc, mb, 6))
                if rat > worst_ns[0]:
                    worst_ns = (rat, (round(a1, 3), round(a2, 3)))
        print("mcut=%.3f  LP branch worst margin %.3e at %s   near-sphere worst ratio %.4f at %s"
              % (mc, worst_lp[0], worst_lp[1], worst_ns[0], worst_ns[1]), flush=True)
