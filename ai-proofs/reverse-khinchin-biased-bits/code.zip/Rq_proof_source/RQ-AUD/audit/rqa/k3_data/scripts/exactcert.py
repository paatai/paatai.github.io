"""Exact rational verification of six-moment certificates on cells (u,a).

A cell is (u1,u2,a1,a2) with rationals 1 <= u1 <= u2, 0 <= a1 <= a2 < 1, plus rationals
b1bar >= sqrt(1-a1^2) and mbar >= min(1, a2/sqrt(1-a2^2)).
A certificate is a list of 7 rationals c_0..c_6, P(y) = sum c_k y^k.

Verified conditions (all exact):
 (V1) P(y) > 0 for all real y;
 (V2) P(y) - l1(y) > 0 for all real y, l1(y) = (u2^2/(1+u2^2)) (b1bar y - a1/u2);
 (V3) P(y) - l2(y) > 0 for all real y, l2(y) = (1/(1+u1^2)) (-b1bar y - a1 u1);
 (V4) A + max_{0<=r<=mbar} g(r) <= tau(u2) (1-a2), with A, g as in the notes (interval
      bounds for the cumulants over [u1,u2]).
Together with the lemmas in MAIN_RESULT these give E|L| <= 2 tau for every unit alpha whose
largest coefficient a lies in [a1,a2], for every q = 1/(1+u^2), u in [u1,u2].
"""
from fractions import Fraction as Fr
from math import isqrt
import sympy

Y = sympy.Symbol("y")


def fr(x):
    return x if isinstance(x, Fr) else Fr(x)


def sqrt_up(x, den=10 ** 15):
    """rational r >= sqrt(x) (x rational >= 0)"""
    x = fr(x)
    n = isqrt(x.numerator * den * den // x.denominator) + 1
    r = Fr(n, den)
    assert r * r >= x
    return r


def sqrt_lo(x, den=10 ** 15):
    x = fr(x)
    n = isqrt(x.numerator * den * den // x.denominator)
    r = Fr(n, den)
    assert r * r <= x
    return r


def kappa_intervals(u1, u2):
    """rational enclosures of k3, k3^2, k4, k5, k6 over u in [u1,u2] (1 <= u1 <= u2)."""
    u1, u2 = fr(u1), fr(u2)
    assert 1 <= u1 <= u2
    k3 = (u1 - 1 / u1, u2 - 1 / u2)                # increasing, >= 0
    w = (u1 * u1 + 1 / (u1 * u1), u2 * u2 + 1 / (u2 * u2))  # increasing for u >= 1
    assert w[1] < 13
    k4 = (w[0] - 4, w[1] - 4)
    wm10 = (w[0] - 10, w[1] - 10)
    prods = [k3[i] * wm10[j] for i in (0, 1) for j in (0, 1)]
    k5 = (min(prods), max(prods))
    f6 = lambda t: t * t - 26 * t + 64            # decreasing on t < 13
    k6 = (f6(w[1]), f6(w[0]))
    k3sq = (k3[0] ** 2, k3[1] ** 2)
    return k3, k3sq, k4, k5, k6


def imul_hi(iv, c):
    """max over x in iv of x*c"""
    return max(iv[0] * c, iv[1] * c)


def absmax(iv):
    return max(abs(iv[0]), abs(iv[1]))


def poly_positive(coeffs):
    """True iff the rational polynomial sum coeffs[k] y^k is > 0 on all of R (exact)."""
    # strip trailing zeros
    cs = list(coeffs)
    while cs and cs[-1] == 0:
        cs.pop()
    if not cs:
        return False
    deg = len(cs) - 1
    if deg % 2 == 1 or cs[-1] <= 0:
        return False
    p = sympy.Poly([sympy.Rational(c.numerator, c.denominator) for c in reversed(cs)], Y, domain="QQ")
    if p.count_roots() != 0:
        return False
    return cs[0] > 0


def max_quartic_upper(beta, gamma, eps, m, target, depth=0, lo=Fr(0), hi=None, maxdepth=40):
    """Check beta r + gamma r^2 + eps r^4 <= target for all r in [lo,hi] (beta >= 0)."""
    if hi is None:
        hi = m
    ub = beta * hi + (gamma * hi * hi if gamma > 0 else gamma * lo * lo) + \
        (eps * hi ** 4 if eps > 0 else eps * lo ** 4)
    if ub <= target:
        return True
    if depth >= maxdepth:
        return False
    mid = (lo + hi) / 2
    return max_quartic_upper(beta, gamma, eps, m, target, depth + 1, lo, mid, maxdepth) and \
        max_quartic_upper(beta, gamma, eps, m, target, depth + 1, mid, hi, maxdepth)


def objective_ok(c, u1, u2, a2, mbar, return_slack=False, target_fn=None, p3max=None):
    """With p3max < 0 (residual known to satisfy p3 <= p3max) and c3 + 10 c5 >= 0, the cubic
    term kappa3 p3 (c3 + 10 c5) is at most k3_lo (c3 + 10 c5) p3max < 0 (kappa3 >= k3_lo > 0)."""
    c = [fr(x) for x in c]
    k3, k3sq, k4, k5, k6 = kappa_intervals(u1, u2)
    A = c[0] + c[2] + 3 * c[4] + 15 * c[6]
    Bbar = k3[1] * abs(c[3] + 10 * c[5])
    if p3max is not None and fr(p3max) < 0 and c[3] + 10 * c[5] >= 0:
        assert k3[0] > 0
        A += k3[0] * (c[3] + 10 * c[5]) * fr(p3max)
        Bbar = Fr(0)
    Chi = imul_hi(k4, c[4] + 15 * c[6])
    Dbar = absmax(k5) * abs(c[5])
    Ehi = imul_hi(k6, c[6])
    Fhi = max(Fr(0), imul_hi((10 * k3sq[0], 10 * k3sq[1]), c[6]))
    gamma = Chi + Dbar * mbar + Fhi
    eps = Fr(0)
    if Ehi >= 0:
        gamma += Ehi * mbar * mbar
    else:
        eps = Ehi
    u2 = fr(u2)
    tau2 = u2 / (1 + u2 * u2)
    if target_fn is None:
        target = tau2 * (1 - fr(a2)) - A
    else:
        target = target_fn(fr(u1), u2, fr(a2)) - A
    ok = max_quartic_upper(Bbar, gamma, eps, fr(mbar), target)
    if return_slack:
        return ok, target
    return ok


def lines(u1, u2, a1, b1bar):
    u1, u2, a1, b1bar = map(fr, (u1, u2, a1, b1bar))
    s1 = u2 * u2 / (1 + u2 * u2)
    l1 = (-s1 * a1 / u2, s1 * b1bar)           # (intercept, slope)
    s2 = 1 / (1 + u1 * u1)
    l2 = (-s2 * a1 * u1, -s2 * b1bar)
    return l1, l2


def verify_cell(c, u1, u2, a1, a2, b1bar, mbar, target_fn=None):
    c = [fr(x) for x in c]
    assert fr(b1bar) ** 2 >= 1 - fr(a1) ** 2 and fr(b1bar) >= 0
    a2 = fr(a2)
    if a2 * a2 < Fr(1, 2):
        # need mbar >= a2/b2  <=>  mbar^2 (1-a2^2) >= a2^2
        assert fr(mbar) ** 2 * (1 - a2 * a2) >= a2 * a2
    else:
        assert fr(mbar) >= 1
    l1, l2 = lines(u1, u2, a1, b1bar)
    if not poly_positive(c):
        return False, "V1"
    d1 = list(c); d1[0] -= l1[0]; d1[1] -= l1[1]
    if not poly_positive(d1):
        return False, "V2"
    d2 = list(c); d2[0] -= l2[0]; d2[1] -= l2[1]
    if not poly_positive(d2):
        return False, "V3"
    if not objective_ok(c, u1, u2, a2, mbar, target_fn=target_fn):
        return False, "V4"
    return True, "ok"
