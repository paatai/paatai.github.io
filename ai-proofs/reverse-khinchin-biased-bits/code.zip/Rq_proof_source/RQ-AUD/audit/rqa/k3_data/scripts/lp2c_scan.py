"""Grid scan of the two-coordinate LP bound against the k=2 target.

usage: lp2c_scan.py q a1lo a1hi a2lo a2hi step [bmin]
Prints the smallest margins T - LP (over both signs of alpha_2) and any failures.
"""
import sys
import numpy as np
import lp2c

q, a1lo, a1hi, a2lo, a2hi, step = map(float, sys.argv[1:7])
bmin = float(sys.argv[7]) if len(sys.argv) > 7 else 0.0
T = lp2c.target(q)
rows = []
fails = []
for a1 in np.arange(a1lo, a1hi + 1e-12, step):
    for a2 in np.arange(a2lo, min(a1, a2hi) + 1e-12, step):
        if 1 - a1 * a1 - a2 * a2 < bmin * bmin or a2 <= 0:
            continue
        for s2 in (1, -1):
            try:
                val = lp2c.solve(q, a1, a2, s2)
                rows.append((T - val, a1, a2, s2, val / T))
            except RuntimeError as e:
                fails.append((a1, a2, s2))
rows.sort()
print("q=%.5f T=%.6f points=%d fails=%d" % (q, T, len(rows), len(fails)))
for r in rows[:15]:
    print("  margin %.3e  a1=%.4f a2=%.4f s=%+d ratio=%.6f" % r)
for f in fails[:10]:
    print("  FAIL", f)
