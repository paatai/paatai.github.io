"""Two-coordinate split, six-moment LP (float exploration).

alpha sorted: a1 = |alpha_1| >= a2 = |alpha_2| >= |alpha_i| (i >= 3), b = sqrt(1-a1^2-a2^2),
L = a1 chi_1 + a2 chi_2 + b M, M = sum beta_i chi_i, |beta| = 1, |beta_i| <= m = min(1, a2/b).
E|L| = E F(M) with F(y) = E|X + b y|, X = a1 chi_1 + a2 chi_2 (4 atoms).
The LP maximises E F(M) over laws on a grid subject to the six-moment relaxation
(same rows as lp6cert.solve_lp).  Value is an upper bound for E|L| (up to grid effects).
"""
import numpy as np
from scipy.optimize import linprog


def kappas(u):
    v = 1.0 / u
    w = u * u + v * v
    return (u - v, w - 4, (u - v) * (w - 10), w * w - 26 * w + 64)


def atoms(q, a1, a2, s1=1, s2=1):
    u = np.sqrt((1 - q) / q)
    v = 1 / u
    xs = []
    ps = []
    for x1, p1 in ((u, q), (-v, 1 - q)):
        for x2, p2 in ((u, q), (-v, 1 - q)):
            xs.append(s1 * a1 * x1 + s2 * a2 * x2)
            ps.append(p1 * p2)
    return np.array(xs), np.array(ps)


def Fvals(y, xs, ps, b):
    return (ps[None, :] * np.abs(xs[None, :] + b * y[:, None])).sum(axis=1)


def solve(q, a1, a2, s2=1, K=12.0, N=2401, ntan=41, ret_c=False, mcap=1.0, p3max=None):
    last = None
    for (KK, NN, meth) in ((K, N, "highs"), (K, N - 400, "highs"), (K, N + 600, "highs"),
                           (K, N, "highs-ipm"), (K, N, "highs-ds"), (K + 1, N - 2, "highs")):
        try:
            return _solve(q, a1, a2, s2, KK, NN, ntan, ret_c, meth, mcap, p3max)
        except RuntimeError as e:
            last = e
    raise last


def _solve(q, a1, a2, s2, K, N, ntan, ret_c, meth, mcap=1.0, p3max=None):
    u = np.sqrt((1 - q) / q)
    k3, k4, k5, k6 = kappas(u)
    b = np.sqrt(max(0.0, 1 - a1 * a1 - a2 * a2))
    m = 1.0 if a2 >= b else a2 / b
    m = min(m, mcap)
    xs, ps = atoms(q, a1, a2, 1, s2)
    far = np.concatenate([np.arange(13.0, 40.0, 1.0), [45, 50, 60, 80, 100, 150, 200.0]])
    y = np.concatenate([-far[::-1], np.linspace(-K, K, N), far])
    R = Fvals(y, xs, ps, b)
    nY = len(y)
    nv = nY + 6
    I3, I4, I5, I6, I33, IZ = nY, nY + 1, nY + 2, nY + 3, nY + 4, nY + 5
    Aeq = np.zeros((7, nv)); beq = np.zeros(7)
    for k in range(7):
        Aeq[k, :nY] = y ** k
    Aeq[6, IZ] = 1.0
    beq[0] = 1; beq[1] = 0; beq[2] = 1
    Aeq[3, I3] = -k3
    Aeq[4, I4] = -k4; beq[4] = 3
    Aeq[5, I5] = -k5; Aeq[5, I3] = -10 * k3
    Aeq[6, I4] = -15 * k4; Aeq[6, I33] = -10 * k3 * k3; Aeq[6, I6] = -k6; beq[6] = 15
    Aub = []; bub = []

    def row():
        return np.zeros(nv)
    for c in np.linspace(-m, m, ntan):
        r = row(); r[I33] = -1; r[I3] = 2 * c; Aub.append(r); bub.append(c * c)
        r = row(); r[I3] = 2 * c; r[I4] = -1; Aub.append(r); bub.append(c * c)
    r = row(); r[I33] = 1; r[I4] = -1; Aub.append(r); bub.append(0)
    r = row(); r[I6] = 1; r[I4] = -m * m; Aub.append(r); bub.append(0)
    for c in np.linspace(0, m * m, ntan):
        r = row(); r[I4] = 2 * c; r[I6] = -1; Aub.append(r); bub.append(c * c)
    r = row(); r[I5] = 1; r[I4] = -m; Aub.append(r); bub.append(0)
    r = row(); r[I5] = -1; r[I4] = -m; Aub.append(r); bub.append(0)
    p3hi = m if p3max is None else min(m, p3max)
    bounds = [(0, None)] * nY + [(-m, p3hi), (0, m * m), (-m ** 3, m ** 3), (0, m ** 4), (0, m * m), (0, None)]
    cobj = np.zeros(nv); cobj[:nY] = -R
    res = linprog(cobj, A_ub=np.array(Aub), b_ub=np.array(bub), A_eq=Aeq, b_eq=beq, bounds=bounds,
                  method=meth)
    if res.status != 0:
        raise RuntimeError(res.message)
    val = -res.fun
    if ret_c:
        return val, -np.array(res.eqlin.marginals), (xs, ps, b, m)
    return val


def target(q):
    tau = np.sqrt(q * (1 - q))
    return 2 * np.sqrt(2) * (1 - q) * tau


if __name__ == "__main__":
    import sys
    qs = [float(x) for x in sys.argv[1:]] or [0.28, 0.25, 0.22, 0.20, 0.19, 0.185]
    for q in qs:
        T = target(q)
        tau = np.sqrt(q * (1 - q))
        worst = (9, None)
        rows = []
        for a1 in np.arange(0.30, 0.999, 0.02):
            for a2 in np.arange(0.02, a1 + 1e-9, 0.02):
                if a1 * a1 + a2 * a2 >= 0.999:
                    continue
                best = -1
                for s2 in (1, -1):
                    try:
                        val = solve(q, a1, a2, s2)
                    except RuntimeError:
                        val = 9
                    best = max(best, val)
                ratio = best / T
                rows.append((a1, a2, ratio))
                if T - best < worst[0]:
                    worst = (T - best, (a1, a2, ratio))
        bad = [r for r in rows if r[2] > 1 - 1e-9]
        print("q=%.4f  T=%.6f  2tau=%.6f  worst margin %.3e at a1=%.2f a2=%.2f ratio=%.6f  #bad=%d"
              % (q, T, 2 * tau, worst[0], worst[1][0], worst[1][1], worst[1][2], len(bad)), flush=True)
        for r in sorted(bad, key=lambda r: -r[2])[:12]:
            print("   bad a1=%.2f a2=%.2f ratio=%.6f" % r)
