"""Feasibility scan for the k = 3 regime (floating point, evidence only).

Target T3 = 2 sqrt3 (1-q)^2 tau, the value of (e1+e2+e3)/sqrt3, for q in [q4, q3],
q4 = 1 - sqrt(3/4) = 0.133975, q3 = 1 - sqrt(2/3) = 0.183503.

usage:
  scan_k3.py one q1 q2 ...      one-coordinate six-moment LP: max_a ratio E|L| / T3
  scan_k3.py two q1 q2 ...      two-coordinate LP margins over (a1, a2), s = +-1, and m-split
                                diagnostics (capped LP, p3-sign LP, near-sphere ratio) where the
                                uncapped LP fails
"""
import sys
from multiprocessing import Pool

import numpy as np

import lp2c
from moment_lp3 import lp6
from msplit_explore import atoms3


def T3(q):
    return 2 * np.sqrt(3) * (1 - q) ** 2 * np.sqrt(q * (1 - q))


def one(q):
    tgt = np.sqrt(3) * (1 - q) ** 2              # T3 / (2 tau)
    As = np.unique(np.round(np.concatenate([np.arange(0.0025, 0.1, 0.0025), np.arange(0.1, 0.999, 0.02),
                                            [0.5774, 0.7071]]), 4))
    out = []
    for a in As:
        r = lp6(q, a, tails=False, absM=False, N=3001)[1]
        out.append(r / tgt)
    out = np.array(out)
    i = np.argmax(out)
    lines = ["q=%.4f  T3=%.6f  max ratio %.6f at a=%.4f ; a with ratio>1: %s"
             % (q, T3(q), out[i], As[i], As[out > 1 + 1e-9][:20])]
    lines.append("      " + " ".join("%.4f:%.4f" % (a, r) for a, r in zip(As[::4], out[::4])))
    return "\n".join(lines)


def nsphere_ratio3(u, a1, a2, b, m):
    q = 1 / (1 + u * u)
    k4 = u * u + 1 / (u * u) - 4
    E4 = 3 + max(0.0, k4)
    bp = b * np.sqrt(max(0.0, 1 - m * m))
    rp = np.sqrt(1 - bp * bp)
    ys, ps = atoms3(u, (a1, a2, b * m))
    if np.min(np.abs(ys)) < 1e-9:
        return 99.0
    return 27 / 128 * E4 * bp * bp * (1 + rp) * np.sum(ps / np.abs(ys) ** 3) / T3(q)


def phi(m):
    return -m ** 3 + (1 - m * m) ** 1.5


def two(q, step=0.03, mcuts=(0.75, 0.8, 0.85)):
    u = np.sqrt((1 - q) / q)
    T = T3(q)
    grid = np.arange(0.45, 0.999, step)
    worst = {1: (9, None), -1: (9, None)}
    fails = []
    for a1 in grid:
        for a2 in np.arange(0.0, a1 + 1e-9, step):
            if a1 * a1 + a2 * a2 >= 0.998:
                continue
            b = np.sqrt(1 - a1 * a1 - a2 * a2)
            mb = min(1.0, a2 / b) if b > 0 else 1.0
            for s in (1, -1):
                try:
                    mar = T - lp2c.solve(q, a1, a2, s)
                except RuntimeError:
                    mar = -9
                if mar < worst[s][0]:
                    worst[s] = (mar, (round(a1, 3), round(a2, 3)))
                if mar < 1e-3:
                    diag = []
                    for mc in mcuts:
                        if mb <= mc:
                            diag.append("mc=%.2f: mb<=mc" % mc)
                            continue
                        cap = T - lp2c.solve(q, a1, a2, s, mcap=mc)
                        p3l = T - lp2c.solve(q, a1, a2, s, p3max=phi(mc))
                        rat = max(nsphere_ratio3(u, a1, s * a2, b, m) for m in np.linspace(mc, mb, 6))
                        diag.append("mc=%.2f: cap %+.1e p3 %+.1e ns %.2f" % (mc, cap, p3l, rat))
                    fails.append("   s=%+d a1=%.3f a2=%.3f b=%.3f mb=%.3f LP %+.2e | %s"
                                 % (s, a1, a2, b, mb, mar, " | ".join(diag)))
    head = ("q=%.4f u=%.4f T3=%.6f  worst LP margin s=+1: %.2e at %s;  s=-1: %.2e at %s;  #fail=%d"
            % (q, u, T, worst[1][0], worst[1][1], worst[-1][0], worst[-1][1], len(fails)))
    return "\n".join([head] + fails)


if __name__ == "__main__":
    mode = sys.argv[1]
    qs = [float(x) for x in sys.argv[2:]]
    f = one if mode == "one" else two
    with Pool(min(8, len(qs))) as pool:
        for res in pool.imap(f, qs):
            print(res, flush=True)
