import sys, numpy as np
from moment_lp3 import lp6
qs = [1 - 1 / np.sqrt(2), 0.2935, 0.295, 0.30, 0.31, 0.32, 0.34, 0.36, 0.38, 0.40, 0.43, 0.46, 0.49, 0.5]
As = np.concatenate([np.arange(0.002, 0.999, 0.01), [0.6, 0.65, 0.7, 0.7071, 0.71, 0.72, 0.75, 0.8, 0.9, 0.95, 0.99, 0.995]])
As = np.unique(np.round(As, 4))
for q in qs:
    rs = []
    for a in As:
        r = lp6(q, a, tails=False, absM=False, N=3001)[1]
        rs.append(r)
    rs = np.array(rs)
    marg = 1 - rs
    # margin relative to (1-a) near a=1
    i = np.argmin(marg)
    bad = As[marg < 0]
    print("q=%.5f  min margin %.6f at a=%.4f ; #a with ratio>1: %d %s" % (q, marg[i], As[i], len(bad), bad[:10]), flush=True)
    np.save("../outputs/scan_lp6_q%.5f.npy" % q, np.vstack([As, rs]))
