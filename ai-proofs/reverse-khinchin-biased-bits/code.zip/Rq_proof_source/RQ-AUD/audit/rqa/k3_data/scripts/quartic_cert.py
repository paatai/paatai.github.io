"""Explore quartic certificates P >= R_a(b .) touching at u and -v (floating point)."""
import sys
import numpy as np
from rqlib import params


def quartic(q, a, c4):
    u, v, tau = params(q)
    b = np.sqrt(1 - a * a)
    # P(y) = (y+v)^2 (c4 y^2 + B y + G); impose P(u)=r0, P'(u)=r1
    r0 = (1 - q) * (b * u - a * v)
    r1 = (1 - q) * b
    w = u + v
    # P(u) = w^2 (c4 u^2 + B u + G) = r0
    # P'(u) = 2 w (c4 u^2 + B u + G) + w^2 (2 c4 u + B) = r1
    s = r0 / w ** 2                 # = c4 u^2 + B u + G
    B = (r1 - 2 * w * s) / w ** 2 - 2 * c4 * u
    G = s - c4 * u ** 2 - B * u
    # expand to coefficients c0..c4
    # (y^2 + 2 v y + v^2)(c4 y^2 + B y + G)
    c = np.zeros(5)
    c[4] = c4
    c[3] = B + 2 * v * c4
    c[2] = G + 2 * v * B + v * v * c4
    c[1] = 2 * v * G + v * v * B
    c[0] = v * v * G
    return c


def check(q, a, c4, verbose=False):
    u, v, tau = params(q)
    b = np.sqrt(1 - a * a)
    c = quartic(q, a, c4)
    y = np.linspace(-15, 15, 300001)
    P = np.polyval(c[::-1], y)
    R = (1 - q) * np.maximum(b * y - a * v, 0) + q * np.maximum(-b * y - a * u, 0)
    gap = (P - R).min()
    k3 = (1 - 2 * q) / tau
    k4 = 1 / tau ** 2 - 6
    cond = c[3] * k3 + 2 * c[4] * k4
    return gap, cond, c


if __name__ == "__main__":
    q = float(sys.argv[1]) if len(sys.argv) > 1 else 1 - 1 / np.sqrt(2)
    for a in [0.3, 0.4, 0.5, 0.55, 0.6, 0.65, 0.7, 0.7071, 0.75, 0.8, 0.85, 0.9, 0.92]:
        best = None
        for c4 in np.concatenate([np.linspace(0, 0.2, 401), np.linspace(0.2, 3, 281)]):
            gap, cond, c = check(q, a, c4)
            ok = gap > -1e-9 and cond >= -1e-12 and c4 >= 0
            if ok:
                best = (c4, gap, cond) if best is None else best
        print("a=%.4f  feasible c4 (first): %s" % (a, best))
