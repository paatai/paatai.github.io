"""Independent re-verification of the computer-assisted steps of Theorem 2 (k = 2 regime).

Shares no code with the scripts that produced the certificates (cert2c, nearcircle, nsphere3,
cover2c, cover_k2, cover_k3, cover_lp6, exactcert); it reuses only the Sturm/tiling helpers of
verify_all.py.
Parts:
  A. symbolic identities (sympy): atom products p_j x_j = r tau g_j, two-coordinate values,
     half-angle parametrisation, the quartic tail bound;
  B. exact coverage: one-coordinate cells tile [U_LO,U_HI] x [0,A_S]; for each sign s the
     two-coordinate boxes tile [U_LO,U_HI] x [0,T8] x [A_S,1];
  C. one-coordinate cells with the k = 2 (or k = 3) target (own Sturm code, strict);
  D. two-coordinate six-moment boxes: envelope as a maximum over 16 sign patterns, checked
     on each half-line by Sturm counting; objective checked strictly on [0, mbar];
  E. near-circle boxes: mpmath outward-rounded interval arithmetic, strict;
  F. m-split boxes: the three-coordinate near-sphere pieces cover [mcut, min(1, mbar)] and pass
     test A3 or B3 (mpmath intervals, strict);
  G. the three-bit lemma for all 256 Boolean f on [q3, q0] (exact Sturm), with equality cases.
With RQ_K=3 the same checks are made for the k = 3 regime (Theorem 3): target 2 sqrt3 (1-q)^2 tau,
data listed in outputs/k3_manifest.json, three-bit lemma sum_i Delta_i^2 <= 12 (1-q)^4 on
[1/(1+U_HI^2), q3].
Usage: [RQ_K=3] python3 verify_k2.py [A B C D E F G]
"""
import glob
import json
import os
import sys
import time
from fractions import Fraction as Fr

from verify_all import (sturm_seq, sign_changes, p_eval, p_strip, roots_in, positive_everywhere,
                        sqrt_hi, sqrt_lo, check_tiling)

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "outputs")
K = int(os.environ.get("RQ_K", "2"))
assert K in (2, 3)
MANIFEST = os.path.join(OUT, "k%d_manifest.json" % K)
A_S = Fr(json.load(open(MANIFEST)).get("A_S", "9/20"))


def say(*a):
    print(*a, flush=True)


def load_manifest():
    m = json.load(open(MANIFEST))
    return Fr(m["U_LO"]), Fr(m["U_HI"]), Fr(m["T8"]), m["one_files"], m["two_files"]


def target_red(w):
    """target / sqrt(K) as a rational function of u = w: K=2: 2u^3/(1+u^2)^2, K=3: 2u^5/(1+u^2)^3"""
    return 2 * w ** 3 / (1 + w * w) ** 2 if K == 2 else 2 * w ** 5 / (1 + w * w) ** 3


# ----------------------------------------------------------------------------- A
def part_A():
    import sympy as sp
    u, r, t, c, d, a1, a2, x, tt = sp.symbols("u r t c d a1 a2 x tt", positive=True)
    q = 1 / (1 + u ** 2)
    v = 1 / u
    tau = u / (1 + u ** 2)
    assert sp.simplify(q * u - tau) == 0 and sp.simplify((1 - q) * v - tau) == 0
    for s in (1, -1):
        atoms = [(q * q, (c + s * d) * u), (q * (1 - q), c * u - s * d * v),
                 ((1 - q) * q, -c * v + s * d * u), ((1 - q) ** 2, -(c + s * d) * v)]
        g = [q * (c + s * d), (1 - q) * c - s * q * d, -q * c + s * (1 - q) * d, -(1 - q) * (c + s * d)]
        for (p, y), gj in zip(atoms, g):
            assert sp.simplify(p * r * y - r * tau * gj) == 0
        # sum of p_j = 1 and mean zero
        assert sp.simplify(sum(p for p, _ in atoms) - 1) == 0
        assert sp.simplify(sum(p * y for p, y in atoms)) == 0
    say("A1 atom products p_j x_j = r tau g_j (both signs), sum p_j = 1, mean 0: OK")
    # two-coordinate values: E X_+ over the positive atoms
    Xp_all = q * q * (c + d) * u + q * (1 - q) * (c * u - d * v) + q * (1 - q) * (d * u - c * v)
    assert sp.simplify(Xp_all - tau * (1 - q) * (c + d)) == 0
    assert sp.simplify(q * q * (c + d) * u + q * (1 - q) * (c * u - d * v) - tau * c) == 0
    assert sp.simplify(q * q * (c - d) * u + q * (1 - q) * (c * u + d * v) - tau * c) == 0
    assert sp.simplify(q * (1 - q) * (c * u + d * v) + (1 - q) ** 2 * (d - c) * v - tau * d) == 0
    assert sp.simplify(q * q * (c + d) * u - q * tau * (c + d)) == 0
    say("A2 two-coordinate values 2 tau (1-q)(c+d), 2 tau c, 2 tau d: OK")
    cc, dd = (1 - tt ** 2) / (1 + tt ** 2), 2 * tt / (1 + tt ** 2)
    assert sp.simplify(cc ** 2 + dd ** 2 - 1) == 0
    assert sp.simplify(dd / (1 + cc) - tt) == 0
    # (x - 1)_+ <= 27 x^4 / 256: max of (x-1)/x^4 on x > 1 is at x = 4/3 with value 27/256
    f = (x - 1) / x ** 4
    crit = sp.solve(sp.diff(f, x), x)
    assert crit == [sp.Rational(4, 3)] and sp.simplify(f.subs(x, sp.Rational(4, 3)) - sp.Rational(27, 256)) == 0
    # target 2 sqrt2 (1-q) tau = 2 sqrt2 u^3/(1+u^2)^2, derivative sign u^2 (3 - u^2)
    T = 2 * sp.sqrt(2) * (1 - q) * tau
    assert sp.simplify(T - 2 * sp.sqrt(2) * u ** 3 / (1 + u ** 2) ** 2) == 0
    dT = sp.factor(sp.diff(u ** 3 / (1 + u ** 2) ** 2, u))
    assert sp.simplify(dT - u ** 2 * (3 - u ** 2) / (1 + u ** 2) ** 3) == 0
    # k = 3 target 2 sqrt3 (1-q)^2 tau = 2 sqrt3 u^5/(1+u^2)^3, derivative sign u^4 (5 - u^2)
    T3 = 2 * sp.sqrt(3) * (1 - q) ** 2 * tau
    assert sp.simplify(T3 - 2 * sp.sqrt(3) * u ** 5 / (1 + u ** 2) ** 3) == 0
    dT3 = sp.diff(u ** 5 / (1 + u ** 2) ** 3, u)
    assert sp.simplify(dT3 - u ** 4 * (5 - u ** 2) / (1 + u ** 2) ** 4) == 0
    say("A3 half-angle parametrisation, quartic tail constant 27/256, unimodality of both targets: OK")
    return True


# ----------------------------------------------------------------------------- B
def check_tiling3(region, boxes, name):
    for b in boxes:
        for k in range(3):
            assert region[2 * k] <= b[2 * k] < b[2 * k + 1] <= region[2 * k + 1], (name, b)
    vol = lambda b: (b[1] - b[0]) * (b[3] - b[2]) * (b[5] - b[4])
    assert sum(vol(b) for b in boxes) == vol(region), (name, float(sum(vol(b) for b in boxes) / vol(region)))
    bs = sorted(boxes)
    for i in range(len(bs)):
        for j in range(i + 1, len(bs)):
            if bs[j][0] >= bs[i][1]:
                break
            ov = all(min(bs[i][2 * k + 1], bs[j][2 * k + 1]) > max(bs[i][2 * k], bs[j][2 * k]) for k in range(3))
            assert not ov, (name, bs[i], bs[j])


def part_B():
    U_LO, U_HI, T8, one_files, two_files = load_manifest()
    assert T8 > 0 and (T8 + 1) ** 2 >= 2              # T8 >= sqrt2 - 1
    if K == 2:
        assert U_LO ** 4 - 2 * U_LO ** 2 - 1 < 0      # U_LO^2 < 1 + sqrt2, i.e. U_LO < u0
        if U_HI > 2:
            assert U_HI ** 2 > 2 and (U_HI ** 2 - 2) ** 2 >= 6   # U_HI^2 >= 2 + sqrt6, i.e. U_HI >= u3
            say("B0 U_LO < u0 = sqrt(1+sqrt2) and U_HI >= u3 = sqrt(2+sqrt6): OK")
    else:
        assert U_LO ** 2 <= 2 or (U_LO ** 2 - 2) ** 2 < 6        # U_LO^2 < 2 + sqrt6, i.e. U_LO < u3
        assert U_LO > 2 and U_HI ** 2 < 3 + 2 * sqrt_lo(Fr(3))   # U_HI < u4 = sqrt(3+2 sqrt3)
        say("B0 U_LO < u3 = sqrt(2+sqrt6) and U_HI = %s < u4 = sqrt(3+2sqrt3): OK" % U_HI)
    # one-coordinate cells
    rects = []
    for fn in one_files:
        dd = json.load(open(os.path.join(OUT, fn)))
        assert dd.get("target") == "k%d" % K and not dd["failed"], fn
        rects += [tuple(Fr(cl[k]) for k in ("u1", "u2", "a1", "a2")) for cl in dd["cells"]]
    check_tiling((U_LO, U_HI, Fr(0), A_S), rects, "one-coordinate")
    say("B1 one-coordinate cells: %d rectangles tile [%s,%s] x [0,%s]: OK" % (len(rects), U_LO, U_HI, A_S))
    for s in (1, -1):
        boxes = []
        nsmall = 0
        for fn in two_files:
            dd = json.load(open(os.path.join(OUT, fn)))
            if dd["s"] != s:
                continue
            assert not dd["failed"], fn
            assert dd.get("K", 2) == K and Fr(dd.get("A_S", "9/20")) == A_S, fn
            for bx in dd["boxes"]:
                b = tuple(Fr(x) for x in bx["box"])
                boxes.append(b)
                if bx["kind"] == "small":
                    t1, r2 = b[2], b[5]
                    assert r2 * (1 - t1 * t1) / (1 + t1 * t1) <= A_S
                    nsmall += 1
        # slabs may be stored in several files; tile the union
        us = sorted({b[0] for b in boxes} | {b[1] for b in boxes})
        check_tiling3((U_LO, U_HI, Fr(0), T8, A_S, Fr(1)), boxes, "two-coordinate s=%d" % s)
        say("B2 two-coordinate boxes, s=%+d: %d boxes (%d with a1 <= A_S) tile [%s,%s] x [0,%s] x [%s,1]: OK"
            % (s, len(boxes), nsmall, U_LO, U_HI, T8, A_S))
    return True


# ----------------------------------------------------------------------------- C
S2 = sqrt_lo(Fr(2))
SK = sqrt_lo(Fr(K))


def kappa_box(u1, u2):
    k3lo, k3hi = u1 - 1 / u1, u2 - 1 / u2
    wlo, whi = u1 * u1 + 1 / (u1 * u1), u2 * u2 + 1 / (u2 * u2)
    assert whi < 13 and k3lo >= 0
    return k3lo, k3hi, wlo, whi


def objective_strict(c, u1, u2, mb, target, p3max=None):
    """target - A - (Bb r + gam r^2 + eps r^4) > 0 on [0, mb]  (Lemma 9 bound on E P(M)).
    If the residual is known to satisfy p3 <= p3max < 0 and c3 + 10 c5 >= 0, the cubic term
    kappa3 p3 (c3 + 10 c5) is bounded by the constant k3lo (c3 + 10 c5) p3max."""
    k3lo, k3hi, wlo, whi = kappa_box(u1, u2)
    k5abs = k3hi * max(abs(wlo - 10), abs(whi - 10))
    A = c[0] + c[2] + 3 * c[4] + 15 * c[6]
    Bb = k3hi * abs(c[3] + 10 * c[5])
    if p3max is not None and p3max < 0 and c[3] + 10 * c[5] >= 0:
        assert k3lo > 0
        A += k3lo * (c[3] + 10 * c[5]) * p3max
        Bb = Fr(0)
    Ch = max((wlo - 4) * (c[4] + 15 * c[6]), (whi - 4) * (c[4] + 15 * c[6]))
    Db = k5abs * abs(c[5])
    Eh = max((wlo * wlo - 26 * wlo + 64) * c[6], (whi * whi - 26 * whi + 64) * c[6])
    Fh = max(Fr(0), 10 * k3lo ** 2 * c[6], 10 * k3hi ** 2 * c[6])
    gam = Ch + Db * mb + Fh + (Eh * mb * mb if Eh >= 0 else 0)
    eps = Eh if Eh < 0 else Fr(0)
    h0 = target - A
    if h0 <= 0:
        return False
    h = p_strip([h0, -Bb, -gam, Fr(0), -eps])
    if len(h) > 1 and roots_in(h, Fr(0), mb) != 0:
        return False
    return p_eval(h, mb) > 0


def check_one(cell):
    u1, u2, a1, a2 = (Fr(cell[k]) for k in ("u1", "u2", "a1", "a2"))
    c = [Fr(x) for x in cell["c"]]
    assert len(c) == 7 and 1 <= u1 < u2 and 0 <= a1 < a2 <= A_S
    b1 = sqrt_hi(1 - a1 * a1)
    mb = min(Fr(1), a2 / sqrt_lo(1 - a2 * a2))
    s1 = u2 * u2 / (1 + u2 * u2)
    L1 = [-s1 * a1 / u2, s1 * b1]
    s2 = 1 / (1 + u1 * u1)
    L2 = [-s2 * a1 * u1, -s2 * b1]
    if not positive_everywhere(c):
        return "V1"
    if not positive_everywhere([c[0] - L1[0], c[1] - L1[1]] + c[2:]):
        return "V2"
    if not positive_everywhere([c[0] - L2[0], c[1] - L2[1]] + c[2:]):
        return "V3"
    # target for E R_a(bM): tau(u)(sqrt2 (1-q) - a) >= tau(u2)(S2 u1^2/(1+u1^2) - a2) on the cell;
    # K=3: tau(u)(sqrt3 (1-q)^2 - a) >= tau(u2)(S3 (u1^2/(1+u1^2))^2 - a2)
    w1 = u1 * u1 / (1 + u1 * u1)
    tgt = u2 / (1 + u2 * u2) * ((S2 * w1 if K == 2 else SK * w1 * w1) - a2)
    assert tgt > 0
    if not objective_strict(c, u1, u2, mb, tgt):
        return "V4"
    return "ok"


def part_C():
    U_LO, U_HI, T8, one_files, two_files = load_manifest()
    t0 = time.time()
    n = 0
    for fn in one_files:
        for cell in json.load(open(os.path.join(OUT, fn)))["cells"]:
            res = check_one(cell)
            assert res == "ok", (fn, cell["u1"], cell["u2"], cell["a1"], cell["a2"], res)
            n += 1
    say("C one-coordinate cells (k=%d target): %d re-verified exactly, %.0fs: OK" % (K, n, time.time() - t0))
    return True


# ----------------------------------------------------------------------------- D
def roots_pos(p):
    """number of distinct real roots in (0, +inf)"""
    seq = sturm_seq(p)
    v0 = sign_changes([p_eval(s_, Fr(0)) for s_ in seq if s_])
    vinf = sign_changes([s_[-1] for s_ in seq if s_])
    return v0 - vinf


def roots_neg(p):
    """number of distinct real roots in (-inf, 0)"""
    pm = [cf * (-1) ** k for k, cf in enumerate(p)]
    return roots_pos(pm)


def box_quantities(u1, u2, t1, t2, r1, r2):
    q = (1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    qb = (1 - q[1], 1 - q[0])
    tau = (u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))
    c = ((1 - t2 * t2) / (1 + t2 * t2), (1 - t1 * t1) / (1 + t1 * t1))
    d = (2 * t1 / (1 + t1 * t1), 2 * t2 / (1 + t2 * t2))
    blo = sqrt_lo(1 - r2 * r2) if r2 < 1 else Fr(0)
    bhi = sqrt_hi(1 - r1 * r1)
    return q, qb, tau, c, d, (r1, r2), (blo, bhi)


def imul(x, y):
    ps = [x[0] * y[0], x[0] * y[1], x[1] * y[0], x[1] * y[1]]
    return (min(ps), max(ps))


def iadd(x, y):
    return (x[0] + y[0], x[1] + y[1])


def ineg(x):
    return (-x[1], -x[0])


def envelope_terms(box, s):
    u1, u2, t1, t2, r1, r2 = box
    q, qb, tau, c, d, r, b = box_quantities(u1, u2, t1, t2, r1, r2)
    sd = d if s == 1 else ineg(d)
    g = [imul(q, iadd(c, sd)), iadd(imul(qb, c), ineg(imul(q, sd))),
         iadd(ineg(imul(q, c)), imul(qb, sd)), ineg(imul(qb, iadd(c, sd)))]
    p = [imul(q, q), imul(q, qb), imul(q, qb), imul(qb, qb)]
    rt = imul(r, tau)
    terms = []
    for gj, pj in zip(g, p):
        px = imul(rt, gj)
        pb = imul(pj, b)
        assert pb[0] >= 0
        terms.append((px, pb))
    return terms, b


def dominates(c, terms):
    """c(y) > F_box(y) for all real y (F_box = sum of per-atom maxima of two lines)."""
    import itertools
    # y >= 0: each term <= max(px_hi + pb_hi y, -px_lo - pb_lo y); y <= 0: slopes pb_lo, -pb_hi
    for pat in itertools.product((0, 1), repeat=len(terms)):
        for side in (1, -1):
            icpt, slope = Fr(0), Fr(0)
            for (px, pb), choice in zip(terms, pat):
                if choice == 0:
                    icpt += px[1]
                    slope += pb[1] if side == 1 else pb[0]
                else:
                    icpt += -px[0]
                    slope += -pb[0] if side == 1 else -pb[1]
            dpoly = list(c)
            dpoly[0] -= icpt
            dpoly[1] -= slope
            if dpoly[0] <= 0:
                return "dom0"
            nroots = roots_pos(dpoly) if side == 1 else roots_neg(dpoly)
            if nroots != 0:
                return "dom"
    return "ok"


def mbar_box(t2, r2, blo):
    """upper bound for max|beta_i| <= min(1, a2/b) on the box (exact, no rounding)."""
    a2hi = r2 * 2 * t2 / (1 + t2 * t2)
    return Fr(1) if (blo == 0 or a2hi >= blo) else a2hi / blo


def phi_ok(mcut, p3max):
    """0 > p3max >= -mcut^3 + (1-mcut^2)^(3/2) and 1/2 < mcut^2, 0 < mcut <= 1 (exact).  Then a
    residual whose largest coefficient is -m with m >= mcut has p3 <= -m^3 + (1-m^2)^(3/2) <= p3max."""
    if not (0 < mcut <= 1 and 2 * mcut * mcut > 1 and p3max < 0):
        return False
    rhs = p3max + mcut ** 3
    return rhs >= 0 and (1 - mcut * mcut) ** 3 <= rhs * rhs


def check_two(bx, U_LO):
    box = tuple(Fr(x) for x in bx["box"])
    s = bx["s"]
    c = [Fr(x) for x in bx["c"]]
    u1, u2, t1, t2, r1, r2 = box
    assert len(c) == 7 and 1 <= u1 < u2 and 0 <= t1 < t2 <= 1 and 0 <= r1 < r2 <= 1
    terms, b = envelope_terms(box, s)
    dm = dominates(c, terms)
    if dm != "ok":
        return dm
    mb = mbar_box(t2, r2, b[0])
    tgt = SK * min(target_red(u1), target_red(u2))
    if bx["kind"] == "lp":
        if not objective_strict(c, u1, u2, mb, tgt):
            return "obj"
        return "ok"
    # m-split box: c covers residuals with max|beta_i| <= mcut, c2 those with p3 <= p3max
    assert bx["kind"] == "ms"
    mcut, p3max = Fr(bx["mcut"]), Fr(bx["p3max"])
    c2 = [Fr(x) for x in bx["c2"]]
    assert len(c2) == 7
    if not phi_ok(mcut, p3max):
        return "phi"
    if not objective_strict(c, u1, u2, min(mb, mcut), tgt):
        return "obj1"
    dm = dominates(c2, terms)
    if dm != "ok":
        return dm + "2"
    if not objective_strict(c2, u1, u2, mb, tgt, p3max=p3max):
        return "obj2"
    return "ok"


def iter_boxes(two_files, kinds):
    for fn in two_files:
        dd = json.load(open(os.path.join(OUT, fn)))
        for bx in dd["boxes"]:
            if bx["kind"] in kinds:
                yield fn, bx


def part_D(nproc=8):
    U_LO, U_HI, T8, one_files, two_files = load_manifest()
    t0 = time.time()
    from multiprocessing import Pool
    items = [bx for _, bx in iter_boxes(two_files, ("lp", "ms"))]
    with Pool(nproc) as pool:
        res = pool.starmap(check_two, [(bx, U_LO) for bx in items], chunksize=20)
    bad = [(bx["box"], bx["s"], r_) for bx, r_ in zip(items, res) if r_ != "ok"]
    assert not bad, bad[:5]
    nms = sum(1 for bx in items if bx["kind"] == "ms")
    say("D two-coordinate six-moment boxes: %d re-verified exactly (16 sign patterns x 2 half-lines,"
        " strict objective; %d of them m-split boxes with two certificates each), %.0fs: OK"
        % (len(items), nms, time.time() - t0))
    return True


# ----------------------------------------------------------------------------- E
def check_nc(bx):
    from mpmath import iv
    iv.prec = 120

    def I(x):
        x = Fr(x)
        return iv.mpf(x.numerator) / iv.mpf(x.denominator)

    def hull(a, b):
        return iv.mpf([a.a, b.b])

    box = tuple(Fr(x) for x in bx["box"])
    s = bx["s"]
    u1, u2, t1, t2, r1, r2 = box
    assert r1 > 0
    U = hull(I(u1), I(u2))
    V = 1 / U
    q = hull(1 / (1 + I(u2) ** 2), 1 / (1 + I(u1) ** 2))
    qb = 1 - q
    tau = hull(I(u2) / (1 + I(u2) ** 2), I(u1) / (1 + I(u1) ** 2))
    c = hull((1 - I(t2) ** 2) / (1 + I(t2) ** 2), (1 - I(t1) ** 2) / (1 + I(t1) ** 2))
    d = hull(2 * I(t1) / (1 + I(t1) ** 2), 2 * I(t2) / (1 + I(t2) ** 2))
    sd = d if s == 1 else -d
    R1, R2 = I(r1), I(r2)
    bhi2 = (1 - R1 * R1).b                       # b^2 <= 1 - r1^2
    ys = [(c + sd) * U, c * U - sd * V, -c * V + sd * U, -(c + sd) * V]
    ps = [q * q, q * qb, q * qb, qb * qb]
    absy = []
    for y in ys:
        if y.a > 0:
            absy.append(iv.mpf([y.a, y.b]))
        elif y.b < 0:
            absy.append(iv.mpf([-y.b, -y.a]))
        else:
            absy.append(iv.mpf([0, max(-y.a, y.b)]))
    # target >= min over the endpoints (unimodal); sqrt(K) enclosed by iv
    Tlo = min((iv.sqrt(K) * target_red(I(u1))).a, (iv.sqrt(K) * target_red(I(u2))).a)
    Tlo = iv.mpf(Tlo)
    k4hi = (I(u2) ** 2 + 1 / I(u2) ** 2 - 4).b
    # E M^4 = 3 + k4 p4 with p4 <= mb^2, mb >= min(1, a2/b) on the box
    a2hi = r2 * 2 * t2 / (1 + t2 * t2)
    blo = sqrt_lo(1 - r2 * r2) if r2 < 1 else Fr(0)
    mb = Fr(1) if (blo == 0 or a2hi >= blo) else a2hi / blo
    E4 = 3 + iv.mpf(max(k4hi, 0)) * I(mb) ** 2
    C27 = iv.mpf(27) / 128
    # test A (needs u >= u0 for G <= T; all atoms away from zero)
    if all(a_.a > 0 for a_ in absy):
        S = sum(p_ / a_ ** 3 for p_, a_ in zip(ps, absy))
        lhs = C27 * E4 * iv.mpf(bhi2) * (1 + R2) / R1 ** 3 * S
        if lhs.b < Tlo.a:
            return "ok"
    # test B;  G = E|c chi_1 + s d chi_2| = sum_j p_j |y_j| = tau sum_j |g_j|  (part A1)
    gs = [q * (c + sd), qb * c - q * sd, -q * c + qb * sd, -qb * (c + sd)]
    G = tau * sum(iv.mpf([0, max(abs(g_.a), abs(g_.b))]) if g_.a <= 0 <= g_.b else abs(g_) for g_ in gs)
    margin = Tlo - G
    if margin.a <= 0:
        return "fail"
    bhi = iv.sqrt(iv.mpf(bhi2))
    lhs = iv.mpf(0)
    for p_, a_ in zip(ps, absy):
        e = bhi
        if a_.a > 0:
            e2 = C27 * iv.mpf(bhi2) ** 2 * E4 / (R1 ** 3 * a_ ** 3)
            e = e if e.b <= e2.b else e2
        lhs += p_ * e
    rhs = Tlo * (1 - R2) + R1 * margin
    return "ok" if lhs.b < rhs.a else "fail"


def part_E(nproc=8):
    U_LO, U_HI, T8, one_files, two_files = load_manifest()
    t0 = time.time()
    from multiprocessing import Pool
    items = [bx for _, bx in iter_boxes(two_files, ("ncA", "ncB"))]
    with Pool(nproc) as pool:
        res = pool.map(check_nc, items, chunksize=50)
    bad = [(bx["box"], bx["s"]) for bx, r_ in zip(items, res) if r_ != "ok"]
    assert not bad, bad[:5]
    say("E near-circle boxes: %d re-verified (mpmath intervals, prec 120, strict), %.0fs: OK"
        % (len(items), time.time() - t0))
    return True


# ----------------------------------------------------------------------------- F
def check_ms3(bx):
    """Near-sphere pieces of an m-split box: for m >= mcut with alpha_3 = +b m (s3 = +1),
    L = a1 chi1 + s a2 chi2 + a3 chi3 + b' M', a3 = b m, b'^2 = b^2 (1 - m^2), E M'^4 <= 3 + k4+.
    Piece test A3 (with the three-bit lemma, part G):
        (27/128) E4 b'^2 (1 + r') sum_j p_j / |y_j|^3 < T;
    piece test B3: E|Y| + sum_j p_j min(b', (27/128) b'^4 E4/|y_j|^3) < T."""
    from mpmath import iv
    iv.prec = 120

    def I(x):
        x = Fr(x)
        return iv.mpf(x.numerator) / iv.mpf(x.denominator)

    def hull(a, b):
        return iv.mpf([a.a, b.b])

    def absI(y):
        if y.a > 0:
            return iv.mpf([y.a, y.b])
        if y.b < 0:
            return iv.mpf([-y.b, -y.a])
        return iv.mpf([0, max(-y.a, y.b)])

    box = tuple(Fr(x) for x in bx["box"])
    s = bx["s"]
    u1, u2, t1, t2, r1, r2 = box
    if not (u1 >= 2):                    # m-split boxes only occur with u >= 2 (both regimes)
        return "u-range"
    mcut = Fr(bx["mcut"])
    blo = sqrt_lo(1 - r2 * r2) if r2 < 1 else Fr(0)
    bhi = sqrt_hi(1 - r1 * r1)
    if blo <= 0:
        return "b"
    mb = mbar_box(t2, r2, blo)
    pieces = sorted((Fr(p_[0]), Fr(p_[1])) for p_ in bx["pieces"] if p_[2] == 1)
    cur = mcut
    for m1, m2 in pieces:
        if not (0 < m1 < m2 <= 1) or m1 > cur:
            return "gap"
        cur = max(cur, m2)
    if cur < min(Fr(1), mb):
        return "top"
    U = hull(I(u1), I(u2))
    V = 1 / U
    q = hull(1 / (1 + I(u2) ** 2), 1 / (1 + I(u1) ** 2))
    qb = 1 - q
    tau = hull(I(u2) / (1 + I(u2) ** 2), I(u1) / (1 + I(u1) ** 2))
    c = hull((1 - I(t2) ** 2) / (1 + I(t2) ** 2), (1 - I(t1) ** 2) / (1 + I(t1) ** 2))
    d = hull(2 * I(t1) / (1 + I(t1) ** 2), 2 * I(t2) / (1 + I(t2) ** 2))
    R = hull(I(r1), I(r2))
    a1 = R * c
    a2 = R * d if s == 1 else -(R * d)
    Tlo = min((iv.sqrt(K) * target_red(I(u1))).a, (iv.sqrt(K) * target_red(I(u2))).a)
    k4hi = (I(u2) ** 2 + 1 / I(u2) ** 2 - 4).b
    E4 = 3 + iv.mpf(max(k4hi, 0))
    C27 = iv.mpf(27) / 128
    for m1, m2 in pieces:
        a3 = hull(I(blo) * I(m1), I(bhi) * I(m2))
        bp2 = iv.mpf((I(bhi) ** 2 * (1 - I(m1) ** 2)).b)            # b'^2 <= bhi^2 (1 - m1^2)
        rp = iv.mpf(min(iv.sqrt(1 - I(blo) ** 2 * (1 - I(m2) ** 2)).b, 1))   # r' upper bound
        coef = (a1, a2, a3)
        atoms = []
        for es in [(e1, e2, e3) for e1 in (1, -1) for e2 in (1, -1) for e3 in (1, -1)]:
            pr = [q if e == 1 else qb for e in es]
            p_ = pr[0] * pr[1] * pr[2]
            y = sum((coef[i] * (U if es[i] == 1 else -V) for i in range(3)), iv.mpf(0))
            py = sum((coef[i] * pr[(i + 1) % 3] * pr[(i + 2) % 3] * (tau if es[i] == 1 else -tau)
                      for i in range(3)), iv.mpf(0))           # p_j y_j, using q u = (1-q) v = tau
            atoms.append((p_, py, absI(y)))
        ok = False
        if all(ay.a > 0 for _, _, ay in atoms):
            S = sum((p_ / ay ** 3 for p_, _, ay in atoms), iv.mpf(0))
            lhs = C27 * E4 * bp2 * (1 + rp) * S
            ok = lhs.b < Tlo
        if not ok:
            bp = iv.sqrt(bp2)
            tot = iv.mpf(0)
            for p_, py, ay in atoms:
                e = bp
                if ay.a > 0:
                    e2 = C27 * bp2 ** 2 * E4 / ay ** 3
                    e = e if e.b <= e2.b else e2
                tot += absI(py) + p_ * e
            ok = tot.b < Tlo
        if not ok:
            return "piece"
    return "ok"


def part_F(nproc=8):
    U_LO, U_HI, T8, one_files, two_files = load_manifest()
    t0 = time.time()
    from multiprocessing import Pool
    items = [bx for _, bx in iter_boxes(two_files, ("ms",))]
    with Pool(nproc) as pool:
        res = pool.map(check_ms3, items, chunksize=20)
    bad = [(bx["box"], bx["s"], r_) for bx, r_ in zip(items, res) if r_ != "ok"]
    assert not bad, bad[:5]
    npc = sum(len([p_ for p_ in bx["pieces"] if p_[2] == 1]) for bx in items)
    say("F m-split boxes: near-sphere pieces (s3=+1) cover [mcut, mbar] and pass (mpmath, strict): "
        "%d boxes, %d pieces, %.0fs: OK" % (len(items), npc, time.time() - t0))
    return True


# ----------------------------------------------------------------------------- G
def part_G():
    """Three-bit lemma: for every f: {0,1}^3 -> {-1,1} and q in [q3, q0] (q3 = 1 - sqrt(2/3),
    q0 = 1 - 1/sqrt2): sum_i Delta_i(f)^2 <= 8 (1-q)^2, Delta_i(f) = E[f | x_i = 1] - E[f | x_i = 0].
    Since E[f chi_i] = tau Delta_i(f), this gives E|c1 chi1 + c2 chi2 + c3 chi3| <= |c| T.
    K=3: sum_i Delta_i(f)^2 <= 12 (1-q)^4 on [1/(1+U_HI^2), q3], giving the same with T = T3."""
    import itertools
    import sympy as sp
    q = sp.Symbol("q")
    pts = list(itertools.product((0, 1), repeat=3))

    def frlist(expr):
        cs = sp.Poly(sp.expand(expr), q).all_coeffs()[::-1]
        return p_strip([Fr(int(sp.Rational(x).p), int(sp.Rational(x).q)) for x in cs])

    def pdivmod(n, d):
        n = list(n)
        quo = [Fr(0)] * max(1, len(n) - len(d) + 1)
        while len(n) >= len(d) and any(n):
            k = len(n) - len(d)
            f_ = n[-1] / d[-1]
            quo[k] = f_
            for i in range(len(d)):
                n[i + k] -= f_ * d[i]
            n = p_strip(n)
        return p_strip(quo), n

    m3 = [Fr(1), Fr(-6), Fr(3)]                  # 3q^2 - 6q + 1, root q3
    m0 = [Fr(1), Fr(-4), Fr(2)]                  # 2q^2 - 4q + 1, root q0
    q3lo, q3hi = 1 - sqrt_hi(Fr(2, 3)), 1 - sqrt_lo(Fr(2, 3))
    q0lo, q0hi = 1 - sqrt_hi(Fr(1, 2)), 1 - sqrt_lo(Fr(1, 2))
    assert p_eval(m3, q3lo) > 0 > p_eval(m3, q3hi) and p_eval(m0, q0lo) > 0 > p_eval(m0, q0hi)
    assert q3hi < q0lo

    def no_root_closed(p, lo, hi):
        return p_eval(p, lo) != 0 and roots_in(p, lo, hi) == 0

    def nonneg_on(p):
        """p >= 0 on [q3, q0]; returns (ok, tight_at_q3, tight_at_q0)."""
        if not p:
            return True, True, True
        if not (no_root_closed(p, q3hi, q0lo) and p_eval(p, q3hi) > 0):
            return False, None, None
        Q3, rem3 = pdivmod(p, m3)
        if not rem3:                              # p = m3 Q3, m3 <= 0 on [q3, q3hi]
            ok3 = no_root_closed(Q3, q3lo, q3hi) and p_eval(Q3, q3hi) < 0
            t3 = True
        else:
            ok3 = no_root_closed(p, q3lo, q3hi) and p_eval(p, q3hi) > 0
            t3 = False
        Q0, rem0 = pdivmod(p, m0)
        if not rem0:                              # p = m0 Q0, m0 >= 0 on [q0lo, q0]
            ok0 = no_root_closed(Q0, q0lo, q0hi) and p_eval(Q0, q0lo) > 0
            t0_ = True
        else:
            ok0 = no_root_closed(p, q0lo, q0hi) and p_eval(p, q0lo) > 0
            t0_ = False
        return ok3 and ok0, t3, t0_

    U_LO, U_HI, T8, one_files, two_files = load_manifest()
    qL = 1 / (1 + U_HI * U_HI)                   # K=3: left end of the range [qL, q3]
    if K == 3:
        assert qL < q3lo

    def nonneg_k3(p):
        """p >= 0 on [qL, q3]; returns (ok, tight_at_q3).  m3 >= 0 on [qL, q3]."""
        if not p:
            return True, True
        if not (no_root_closed(p, qL, q3lo) and p_eval(p, qL) > 0):
            return False, None
        Q3, rem3 = pdivmod(p, m3)
        if not rem3:                              # p = m3 Q3, m3 >= 0 on [q3lo, q3]
            return no_root_closed(Q3, q3lo, q3hi) and p_eval(Q3, q3lo) > 0, True
        return no_root_closed(p, q3lo, q3hi) and p_eval(p, q3lo) > 0, False

    ident, at3, at0 = [], [], []
    for vals in itertools.product((-1, 1), repeat=8):
        f = dict(zip(pts, vals))
        S = 0
        for i in range(3):
            Di = 0
            for x in pts:
                if x[i] == 1:
                    xo = list(x)
                    xo[i] = 0
                    w = 1
                    for k in range(3):
                        if k != i:
                            w *= q if x[k] == 1 else 1 - q
                    Di += w * (f[x] - f[tuple(xo)])
            S += Di ** 2
        if K == 2:
            p = frlist(8 * (1 - q) ** 2 - S)
            ok, t3, t0_ = nonneg_on(p)
        else:
            p = frlist(12 * (1 - q) ** 4 - S)
            ok, t3 = nonneg_k3(p)
            t0_ = False
        assert ok, vals
        if not p:
            ident.append(vals)
        else:
            if t3:
                at3.append(vals)
            if t0_:
                at0.append(vals)

    def table(g):
        return tuple(g(x) for x in pts)
    OR2 = [table(lambda x, i=i, j=j: 1 if (x[i] or x[j]) else -1) for i, j in ((0, 1), (0, 2), (1, 2))]
    OR3 = [table(lambda x: 1 if any(x) else -1)]
    DIC = [table(lambda x, i=i: 1 if x[i] else -1) for i in range(3)]
    neg = lambda L: L + [tuple(-v for v in t) for t in L]
    if K == 2:
        assert sorted(ident) == sorted(neg(OR2)), ident
        assert sorted(at3) == sorted(neg(OR3)), at3
        assert sorted(at0) == sorted(neg(DIC)), at0
        say("G three-bit lemma: all 256 f satisfy sum_i Delta_i^2 <= 8(1-q)^2 on [q3, q0] (exact Sturm);"
            " equality: identically only for +-OR_2 (6 f), at q3 only for +-OR_3, at q0 only for"
            " +-dictators: OK")
    else:
        assert sorted(ident) == sorted(neg(OR3)), ident
        assert sorted(at3) == sorted(neg(OR2)), at3
        assert not at0
        say("G three-bit lemma (k=3): all 256 f satisfy sum_i Delta_i^2 <= 12(1-q)^4 on [%s, q3] "
            "(exact Sturm); equality: identically only for +-OR_3, at q3 only for +-OR_2 (6 f), "
            "nowhere else: OK" % qL)
    return True


if __name__ == "__main__":
    parts = [p_ for p_ in sys.argv[1:] if not p_.startswith("-")] or ["A", "B", "C", "D", "E", "F", "G"]
    for p_ in parts:
        globals()["part_" + p_]()
    say("ALL SELECTED PARTS PASSED:", " ".join(parts))
