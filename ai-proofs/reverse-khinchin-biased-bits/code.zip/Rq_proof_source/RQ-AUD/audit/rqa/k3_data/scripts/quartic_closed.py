"""Closed-form quartic two-extremiser certificate (floating-point exploration).

P(y) = (y+v)^2 (c4 y^2 + B y + G), tangent to l1(y) = (1-q)(b y - a v) at y = u and to 0 at
y = -v.  With tau = u/(1+u^2), X = u^2-1:
  B0 = tau^4 (2a - bX),  s = tau^3 (b u^2 - a),  B = B0 - 2 c4 u,  G = s - B0 u + c4 u^2,
  Q1 (and Q2):  c4 > B0^2/(4 s);     Q4:  c4 <= kappa3 B0 / 4,  kappa3 = X/u;
  Q3: f(x) = P(-z0-x) - q b x > 0 for x >= 0 (z0 = a u / b), coefficients e0..e4 below;
      sufficient: e0 > 0, e2 > min(e1,0)^2/(4 e0) + min(e3,0)^2/(4 c4).
"""
import numpy as np


def ab(t):
    return 2 * t / (1 + t * t), (1 - t * t) / (1 + t * t)


def pieces(u, t, c4):
    a, b = ab(t)
    v = 1 / u
    tau = u / (1 + u * u)
    X = u * u - 1
    q = 1 / (1 + u * u)
    B0 = tau ** 4 * (2 * a - b * X)
    s = tau ** 3 * (b * u * u - a)
    B = B0 - 2 * c4 * u
    G = s - B0 * u + c4 * u * u
    z0 = a * u / b
    d = z0 - v
    g1 = 2 * c4 * z0 - B
    g0 = c4 * z0 * z0 - B * z0 + G
    e0 = d * d * g0
    e1 = d * d * g1 + 2 * d * g0 - q * b
    e2 = d * d * c4 + 2 * d * g1 + g0
    e3 = 2 * d * c4 + g1
    c4lo = B0 * B0 / (4 * s)
    c4hi = X / u * B0 / 4
    q3 = e2 - min(e1, 0) ** 2 / (4 * e0) - min(e3, 0) ** 2 / (4 * c4) if e0 > 0 else -1
    return c4lo, c4hi, q3, (e0, e1, e2, e3)


def best_c4(u, t, n=400):
    c4lo, c4hi, _, _ = pieces(u, t, 1e-3)
    best = None
    for c4 in np.linspace(c4lo, c4hi, n)[1:-1]:
        _, _, q3, _ = pieces(u, t, c4)
        sc = min((c4 - c4lo) / c4hi, (c4hi - c4) / c4hi, q3 / 0.05)
        if best is None or sc > best[0]:
            best = (sc, c4, q3)
    return best, c4lo, c4hi


if __name__ == "__main__":
    import sys
    u0 = np.sqrt(1 + np.sqrt(2))
    for q in [1 - 1 / np.sqrt(2), 0.295, 0.2975, 0.30, 0.3025]:
        u = np.sqrt((1 - q) / q)
        row = []
        for a in [0.62, 0.63, 0.64, 0.66, 0.68, 0.7071, 0.73, 0.75, 0.77, 0.78]:
            t = (1 - np.sqrt(1 - a * a)) / a
            (sc, c4, q3), lo, hi = best_c4(u, t)
            row.append("%.4f/%.5f" % (sc, c4))
        print("q=%.4f u=%.5f " % (q, u) + " ".join(row))
