"""Six-moment cover for the k = 3 regime: target E R_a(bM) < tau (sqrt3 (1-q)^2 - a).

On a cell [u1,u2] x [a1,a2] (u >= 1) the target is bounded below by
tau(u2) (S3 (u1^2/(1+u1^2))^2 - a2), S3 = rational lower bound of sqrt3 (tau decreasing,
1-q = u^2/(1+u^2) increasing in u).
Usage: python3 cover_k3.py <u_lo> <u_hi> <a_lo> <a_hi> <outfile> [nu na]
"""
import json
import sys
from fractions import Fraction as Fr
import cover_lp6
from exactcert import sqrt_lo

S3 = sqrt_lo(Fr(3))


def target_k3(u1, u2, a2):
    w = u1 * u1 / (1 + u1 * u1)
    return u2 / (1 + u2 * u2) * (S3 * w * w - a2)


cover_lp6.TARGET_FN = target_k3

if __name__ == "__main__":
    u_lo, u_hi, a_lo, a_hi = (Fr(s) for s in sys.argv[1:5])
    nu = int(sys.argv[6]) if len(sys.argv) > 6 else 4
    na = int(sys.argv[7]) if len(sys.argv) > 7 else 8
    done, failed = cover_lp6.cover(u_lo, u_hi, a_lo, a_hi, nu, na)
    json.dump({"region": [str(u_lo), str(u_hi), str(a_lo), str(a_hi)], "target": "k3", "S3": str(S3),
               "cells": done, "failed": failed}, open(sys.argv[5], "w"))
    print("cells verified: %d, failed: %d" % (len(done), len(failed)))
