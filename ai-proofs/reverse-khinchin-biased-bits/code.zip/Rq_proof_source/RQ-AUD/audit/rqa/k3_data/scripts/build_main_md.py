"""Regenerate <NAME>.md from <NAME>.tex (pandoc) plus a header from notes/.

Usage: python3 build_main_md.py [NAME]   (NAME = MAIN_RESULT (default), MAIN_RESULT_K2 or MAIN_RESULT_K3)
"""
import os
import re
import subprocess
import sys

HEADERS = {"MAIN_RESULT": "main_md_header.md", "MAIN_RESULT_K2": "main_k2_md_header.md",
           "MAIN_RESULT_K3": "main_k3_md_header.md"}
name = sys.argv[1] if len(sys.argv) > 1 else "MAIN_RESULT"
root = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..")
body = subprocess.run(["pandoc", os.path.join(root, name + ".tex"), "-f", "latex", "-t", "gfm",
                       "--wrap=none"], capture_output=True, text=True, check=True).stdout
body = re.sub(r'<div[^>]*>\n?', '', body)
body = body.replace('</div>\n', '')
# equation numbers as in the PDF (from the .aux file of the last LaTeX run)
eqno = dict(re.findall(r'\\newlabel\{(eq:[^}]*)\}\{\{([^}]*)\}',
                       open(os.path.join(root, name + ".aux")).read()))
for lab, num in eqno.items():
    body = body.replace('\\label{%s}' % lab, '\\tag{%s}' % num)
    body = re.sub(r'<a href="#%s" data-reference-type="eqref" data-reference="%s">\[[^\]]*\]</a>'
                  % (re.escape(lab), re.escape(lab)), '(%s)' % num, body)
body = re.sub(r'\\label\{[^}]*\}\s*', '', body)
body = re.sub(r'<a href="#[^"]*" data-reference-type="ref" data-reference="[^"]*">([^<]*)</a>', r'\1', body)
body = re.sub(r'\n{3,}', '\n\n', body)
# pandoc numbers \newtheorem*{thmthree}{Theorem 3} as if it were a numbered environment
body = body.replace('**Theorem 3 1**', '**Theorem 3**')
header = open(os.path.join(root, "notes", HEADERS[name])).read()
open(os.path.join(root, name + ".md"), "w").write(header + body)
print("%s.md written (%d chars)" % (name, len(header + body)))
