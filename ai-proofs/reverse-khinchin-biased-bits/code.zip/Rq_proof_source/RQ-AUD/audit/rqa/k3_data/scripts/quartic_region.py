"""Feasible c4-range of the quartic certificate tangent at u and -v (floating point)."""
import numpy as np
from rqlib import params


def coeffs(q, a, c4):
    u, v, tau = params(q)
    b = np.sqrt(1 - a * a)
    r0 = (1 - q) * (b * u - a * v); r1 = (1 - q) * b; w = u + v
    s = r0 / w ** 2
    B = (r1 - 2 * w * s) / w ** 2 - 2 * c4 * u
    G = s - c4 * u ** 2 - B * u
    c = np.array([v * v * G, 2 * v * G + v * v * B, G + 2 * v * B + v * v * c4, B + 2 * v * c4, c4])
    return c, B, G


def conds(q, a, c4):
    u, v, tau = params(q)
    b = np.sqrt(1 - a * a)
    c, B, G = coeffs(q, a, c4)
    k3 = u - v; k4 = u * u + v * v - 4
    Q1 = 4 * c4 * G - B * B                    # >0  => quadratic factor positive
    # P - l1 = (y-u)^2 * Q (Q quadratic): compute by polynomial division
    l1 = np.array([-(1 - q) * a * v, (1 - q) * b, 0, 0, 0])
    d = c - l1
    quot, rem = np.polydiv(d[::-1], np.array([1, -2 * u, u * u]))
    Q2 = 4 * quot[0] * quot[2] - quot[1] ** 2 if len(quot) == 3 else -1
    # P - l2 >= 0 numerically
    y = np.linspace(-12, 0, 24001)
    P = np.polyval(c[::-1], y)
    l2 = q * (-b * y - a * u)
    Q3 = (P - l2).min()
    Q4 = k3 * c[3] + 2 * k4 * c4
    return Q1, Q2, Q3, Q4


if __name__ == "__main__":
    q0 = 1 - 1 / np.sqrt(2)
    for q in [q0, 0.295, 0.30, 0.305, 0.31, 0.32]:
        line = []
        for a in [0.58, 0.6, 0.62, 0.65, 0.68, 0.7071, 0.73, 0.76, 0.78, 0.8, 0.82]:
            feas = [c4 for c4 in np.linspace(0.0, 0.03, 301)
                    if (lambda t: t[0] > 0 and t[1] > 0 and t[2] > 0 and t[3] > 0)(conds(q, a, c4))]
            line.append("[%.4f,%.4f]" % (min(feas), max(feas)) if feas else "   none    ")
        print("q=%.4f " % q + " ".join(line))
