"""Numerical landscape of F(alpha)=E|sum alpha_i chi_i| on the unit sphere (evidence only).

Power iteration alpha <- grad F(alpha)/|grad F(alpha)| is monotone for the convex 1-homogeneous F.
"""
import itertools
import sys
import numpy as np
from rqlib import params


def atoms(n, q):
    u, v, _ = params(q)
    X = np.array(list(itertools.product([u, -v], repeat=n)))
    k = (X > 0).sum(axis=1)
    P = q ** k * (1 - q) ** (n - k)
    return X, P


def F_and_grad(alpha, X, P):
    L = X @ alpha
    s = np.sign(L)
    return float(P @ np.abs(L)), (P * s) @ X


def power_iter(alpha, X, P, iters=500):
    alpha = alpha / np.linalg.norm(alpha)
    Fv = 0
    for _ in range(iters):
        Fv, g = F_and_grad(alpha, X, P)
        na = g / np.linalg.norm(g)
        if np.linalg.norm(na - alpha) < 1e-13:
            break
        alpha = na
    Fv, g = F_and_grad(alpha, X, P)
    return alpha, Fv


def main(q, n, starts=2000, seed=0):
    rng = np.random.default_rng(seed)
    X, P = atoms(n, q)
    tau = params(q)[2]
    found = {}
    for s in range(starts):
        a0 = rng.standard_normal(n)
        if s % 3 == 1:
            a0 = np.abs(a0)
        alpha, Fv = power_iter(a0, X, P)
        key = tuple(np.round(np.sort(np.abs(alpha))[::-1], 4))
        r = Fv / (2 * tau)
        if key not in found or found[key][0] < r:
            found[key] = (r, alpha)
    res = sorted(found.items(), key=lambda kv: -kv[1][0])
    print("q=%.6f n=%d  #critical shapes=%d" % (q, n, len(res)))
    for key, (r, alpha) in res[:15]:
        print("  ratio %.6f  |alpha| sorted %s  signs %s" % (r, key, np.sign(np.round(alpha, 4)).astype(int)))


if __name__ == "__main__":
    q = float(sys.argv[1])
    n = int(sys.argv[2])
    starts = int(sys.argv[3]) if len(sys.argv) > 3 else 1000
    main(q, n, starts)
