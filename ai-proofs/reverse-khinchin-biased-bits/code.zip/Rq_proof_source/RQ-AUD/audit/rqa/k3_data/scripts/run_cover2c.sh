#!/bin/bash
# usage: run_cover2c.sh tag u1 u2 s   (two-coordinate cover of one u-slab)
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$(dirname "$0")"
python3 cover2c.py "$2" "$3" "$4" ../outputs/cover2c/$1.json 1 8 11 16 > ../outputs/cover2c/$1.log 2>&1
