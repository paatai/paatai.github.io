"""Adaptive cover of (u,t,r) boxes for the two-coordinate split; target from cert2c (RQ_K=2 or 3).

usage: [RQ_K=3] [RQ_AS=2/5] cover2c.py u_lo u_hi s outfile [nu nt nr maxdepth] [ms]
Every box of [u_lo,u_hi] x [0,T8] x [0,1] is verified either by a near-circle test (A/B,
nearcircle.py) or by an exact six-moment certificate (cert2c.py); otherwise it is bisected.
With "ms", a box may also be verified by the m-split (try_msplit): a certificate capped at
max|beta_i| <= mcut plus three-coordinate near-sphere pieces (nsphere3.py) for m >= mcut.
"""
import json
import os
import sys
import time
from fractions import Fraction as Fr
import cert2c
import nearcircle
import nsphere3
from exactcert import sqrt_up

T8 = Fr(41422, 100000)          # > sqrt(2) - 1 = 0.414213...
WT = (1, 2, 1)                  # weights of the u, t, r widths for the bisection rule


A_S = Fr(os.environ.get("RQ_AS", "9/20"))   # boxes with a1 <= A_S everywhere: one-coordinate cover


def a1_hi(t1, r2):
    return r2 * (1 - t1 * t1) / (1 + t1 * t1)


MCUTS = tuple(Fr(29 + k, 40) for k in range(8))          # 0.725, 0.75, ..., 0.9; all > 1/sqrt2


def phi_hi(mcut):
    """Rational upper bound of -m^3 + (1-m^2)^(3/2) at m = mcut (needs mcut^2 >= 1/2).  If the
    largest residual coefficient is beta_1 = -m with m >= mcut, then
    p3 <= -m^3 + max_{i>=2}|beta_i| (1-m^2) <= -m^3 + (1-m^2)^(3/2) <= phi_hi(mcut)."""
    assert 2 * mcut * mcut >= 1
    return -mcut ** 3 + (1 - mcut * mcut) * sqrt_up(1 - mcut * mcut)


def try_msplit(u1, u2, t1, t2, r1, r2, s):
    """m-split (m = max|beta_i|, attained at beta_1 with sign s3):
      m <= mcut:            certificate c1 with mbar capped at mcut;
      m >= mcut, s3 = -1:   certificate c2 valid for residuals with p3 <= phi_hi(mcut);
      m >= mcut, s3 = +1:   three-coordinate near-sphere pieces covering [mcut, mtop]."""
    P = cert2c.cell_params(u1, u2, t1, t2, r1, r2)
    if P["b"].lo <= 0:
        return None
    mtop = min(Fr(1), P["mbar"] + Fr(1, 10 ** 9))
    for mcut in MCUTS:
        if mcut >= P["mbar"]:
            return None
        pieces = nsphere3.check_ms(u1, u2, t1, t2, r1, r2, s, mcut, mtop)
        if pieces is None:
            continue
        c1, why = cert2c.try_cell(u1, u2, t1, t2, r1, r2, s, mcap=mcut)
        if c1 is None:
            return None
        p3m = phi_hi(mcut)
        c2, why = cert2c.try_cell(u1, u2, t1, t2, r1, r2, s, p3max=p3m)
        if c2 is None:
            continue
        return {"box": [str(x) for x in (u1, u2, t1, t2, r1, r2)], "s": s, "kind": "ms",
                "mcut": str(mcut), "mtop": str(mtop), "p3max": str(p3m),
                "c": [str(x) for x in c1], "c2": [str(x) for x in c2], "pieces": pieces}
    return None


def cover(u_lo, u_hi, s, nu=8, nt=4, nr=8, maxdepth=14, log=print, use_lp=True, r_lo=A_S,
          msplit=False):
    us = [u_lo + (u_hi - u_lo) * Fr(i, nu) for i in range(nu + 1)]
    ts = [T8 * Fr(j, nt) for j in range(nt + 1)]
    rs = [r_lo + (1 - r_lo) * Fr(k, nr) for k in range(nr + 1)]
    stack = [(us[i], us[i + 1], ts[j], ts[j + 1], rs[k], rs[k + 1], 0)
             for i in range(nu) for j in range(nt) for k in range(nr)]
    done, failed = [], []
    t0 = time.time()
    nlp = 0
    while stack:
        u1, u2, t1, t2, r1, r2, dep = stack.pop()
        if a1_hi(t1, r2) <= A_S:
            done.append({"box": [str(x) for x in (u1, u2, t1, t2, r1, r2)], "s": s, "kind": "small"})
            continue
        ok, why = nearcircle.check_box(u1, u2, t1, t2, r1, r2, s) if r1 > 0 else (False, "r1=0")
        if ok:
            done.append({"box": [str(x) for x in (u1, u2, t1, t2, r1, r2)], "s": s, "kind": "nc" + why})
            continue
        if use_lp:
            nlp += 1
            cert, why = cert2c.try_cell(u1, u2, t1, t2, r1, r2, s)
            if cert is not None:
                done.append({"box": [str(x) for x in (u1, u2, t1, t2, r1, r2)], "s": s, "kind": "lp",
                             "c": [str(x) for x in cert]})
                continue
            if msplit:
                rec = try_msplit(u1, u2, t1, t2, r1, r2, s)
                if rec is not None:
                    done.append(rec)
                    continue
                why += "+ms"
        if dep >= maxdepth:
            failed.append([float(x) for x in (u1, u2, t1, t2, r1, r2)] + [why])
            log("FAILED box u[%.5f,%.5f] t[%.5f,%.5f] r[%.5f,%.5f] (%s)" %
                (float(u1), float(u2), float(t1), float(t2), float(r1), float(r2), why))
            continue
        w = [(u2 - u1) * WT[0], (t2 - t1) * WT[1], (r2 - r1) * WT[2]]
        k = max(range(3), key=lambda i: w[i])
        if k == 0:
            m = (u1 + u2) / 2
            stack += [(u1, m, t1, t2, r1, r2, dep + 1), (m, u2, t1, t2, r1, r2, dep + 1)]
        elif k == 1:
            m = (t1 + t2) / 2
            stack += [(u1, u2, t1, m, r1, r2, dep + 1), (u1, u2, m, t2, r1, r2, dep + 1)]
        else:
            m = (r1 + r2) / 2
            stack += [(u1, u2, t1, t2, r1, m, dep + 1), (u1, u2, t1, t2, m, r2, dep + 1)]
        if (len(done) + len(failed)) % 200 == 0:
            log("  progress: %d done, %d stack, %d failed, %d lp, %.0fs" %
                (len(done), len(stack), len(failed), nlp, time.time() - t0))
    return done, failed


if __name__ == "__main__":
    u_lo, u_hi = Fr(sys.argv[1]), Fr(sys.argv[2])
    s = int(sys.argv[3])
    out = sys.argv[4]
    ms = "ms" in sys.argv[5:]
    extra = [int(x) for x in sys.argv[5:] if x != "ms"][:4]
    nu, nt, nr, md = (extra + [8, 4, 8, 14][len(extra):]) if extra else (8, 4, 8, 14)

    def log(msg):
        print(msg, flush=True)
    t0 = time.time()
    done, failed = cover(u_lo, u_hi, s, nu, nt, nr, md, log=log, msplit=ms)
    json.dump({"region": [str(u_lo), str(u_hi), "0", str(T8), str(A_S), "1"], "s": s, "A_S": str(A_S),
               "K": cert2c.K_TARGET, "boxes": done,
               "failed": failed}, open(out, "w"))
    kinds = {}
    for d in done:
        kinds[d["kind"]] = kinds.get(d["kind"], 0) + 1
    log("boxes verified: %d %s, failed: %d, time %.0fs" % (len(done), kinds, len(failed), time.time() - t0))
