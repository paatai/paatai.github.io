"""Floating-point helpers for exploring R(q) (numerical evidence only, not proofs)."""
import numpy as np
from math import sqrt, pi, erf, exp

SQ2PI = sqrt(2 / pi)


def params(q):
    u = sqrt((1 - q) / q)
    v = sqrt(q / (1 - q))
    tau = sqrt(q * (1 - q))
    return u, v, tau


def dist_sum(alpha, q, tol=1e-12):
    """Exact (float) law of sum alpha_i chi_i as (values, probs), merging near-equal atoms."""
    u, v, _ = params(q)
    vals = np.array([0.0])
    probs = np.array([1.0])
    for a in alpha:
        nv = np.concatenate([vals + a * u, vals - a * v])
        npr = np.concatenate([probs * q, probs * (1 - q)])
        order = np.argsort(nv, kind="mergesort")
        nv = nv[order]
        npr = npr[order]
        # merge atoms closer than tol
        keep = np.ones(len(nv), dtype=bool)
        if len(nv) > 1:
            d = np.diff(nv) < tol
            if d.any():
                # cumulative grouping
                grp = np.concatenate([[0], np.cumsum(~d)])
                ng = grp[-1] + 1
                gv = np.zeros(ng)
                gp = np.zeros(ng)
                np.add.at(gp, grp, npr)
                np.add.at(gv, grp, nv * npr)
                nz = gp > 0
                gv[nz] /= gp[nz]
                nv, npr = gv[nz], gp[nz]
        vals, probs = nv, npr
    return vals, probs


def EabsL(alpha, q):
    vals, probs = dist_sum(alpha, q)
    return float(np.dot(np.abs(vals), probs))


def ratio(alpha, q):
    alpha = np.asarray(alpha, dtype=float)
    nrm = np.linalg.norm(alpha)
    return EabsL(alpha / nrm, q) / (2 * params(q)[2])


def Phi(x):
    return 0.5 * (1 + erf(x / sqrt(2)))


def phi(x):
    return exp(-x * x / 2) / sqrt(2 * pi)


def Epos_gauss(t, s=1.0):
    """E (sZ - t)_+ for Z ~ N(0,1), s > 0."""
    x = t / s
    return s * (phi(x) - x * (1 - Phi(x)))
