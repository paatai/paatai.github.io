"""Independent re-verification of every computer-assisted step of the RQ-A proof.

Shares no code with the scripts that produced the certificates.  Parts:
  A. symbolic identities (sympy, exact): Lemma 9.4, cumulants, moment formulas, quartic
     certificate closed forms;
  B. exact coverage of the parameter rectangle [1, U0] x [0, 1] by the pieces;
  C. six-moment cells: own Sturm sequences (Fractions), own cumulant enclosures, objective
     bound checked by Sturm counting on [0, mbar];
  D. quartic boxes: mpmath outward-rounded interval arithmetic with adaptive subdivision,
     using the stored constant c4 of each box;
  E. near-dictator inequality (exact).
Usage: python3 verify_all.py            (all parts)
       python3 verify_all.py A B ...    (selected parts)
"""
import glob
import json
import os
import sys
import time
from fractions import Fraction as Fr
from math import isqrt

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "outputs")
U0BAR = Fr(1553774, 10 ** 6)          # rational upper bound for u0 = sqrt(1+sqrt2)
A_ND = Fr(9, 10)                       # near-dictator threshold
UQ = Fr(611, 400)                      # quartic box: u in [UQ, U0BAR]
TQ = (Fr(9, 25), Fr(471, 1000))        # quartic box: t range
AQ = (Fr(16, 25), Fr(77, 100))         # a range that the quartic box must contain


def say(*a):
    print(*a, flush=True)


# ----------------------------------------------------------------------------- A
def part_A():
    import sympy as sp
    y, u, a, b, c4, x, t = sp.symbols("y u a b c4 x t", real=True)
    q = 1 / (1 + u ** 2)
    v = 1 / u
    tau = u / (1 + u ** 2)
    # chi takes u w.p. q and -v w.p. 1-q (q = 1/(1+u^2) <=> u = sqrt((1-q)/q))
    assert sp.simplify(q * u - (1 - q) * v) == 0
    assert sp.simplify(q * u ** 2 + (1 - q) * v ** 2 - 1) == 0
    assert sp.simplify(tau - sp.sqrt(q * (1 - q))).subs(u, sp.Rational(3, 2)) == 0
    # Lemma 9.4: q|au+y| + (1-q)|y-av| = (2q-1) y + 2 tau a + 2 R_a(y), all three regimes
    R1 = (1 - q) * (y - a * v)      # y > a v
    R2 = q * (-y - a * u)           # y < -a u
    lhs_hi = q * (a * u + y) + (1 - q) * (y - a * v)
    lhs_mid = q * (a * u + y) + (1 - q) * (a * v - y)
    lhs_lo = -q * (a * u + y) + (1 - q) * (a * v - y)
    rhs = (2 * q - 1) * y + 2 * tau * a
    assert sp.simplify(lhs_hi - rhs - 2 * R1) == 0
    assert sp.simplify(lhs_mid - rhs) == 0
    assert sp.simplify(lhs_lo - rhs - 2 * R2) == 0
    # cumulants of chi
    mom = [sp.simplify(q * u ** k + (1 - q) * (-v) ** k) for k in range(7)]
    m2, m3, m4, m5, m6 = mom[2], mom[3], mom[4], mom[5], mom[6]
    k3 = m3
    k4 = m4 - 3 * m2 ** 2
    k5 = m5 - 10 * m3 * m2
    k6 = m6 - 15 * m4 * m2 - 10 * m3 ** 2 + 30 * m2 ** 3
    w = u ** 2 + v ** 2
    assert sp.simplify(k3 - (u - v)) == 0
    assert sp.simplify(k4 - (w - 4)) == 0
    assert sp.simplify(k5 - (u - v) * (w - 10)) == 0
    assert sp.simplify(k6 - (w ** 2 - 26 * w + 64)) == 0
    say("A1 Lemma 9.4 identity and cumulants of chi: OK")
    # moment formulas for M = sum beta_i chi_i, |beta| = 1, exact enumeration (rational u)
    import itertools
    for uu in (Fr(3, 2), Fr(7, 5), Fr(1), Fr(31, 20)):
        qq = 1 / (1 + uu * uu)
        vv = 1 / uu
        K3 = uu - vv; W = uu * uu + vv * vv
        K4 = W - 4; K5 = K3 * (W - 10); K6 = W * W - 26 * W + 64
        for beta in ([Fr(3, 5), Fr(4, 5)], [Fr(2, 3), Fr(-2, 3), Fr(1, 3)],
                     [Fr(1, 2), Fr(1, 2), Fr(-1, 2), Fr(1, 2)], [Fr(12, 13), Fr(-5, 13)]):
            assert sum(bb * bb for bb in beta) == 1
            EM = [Fr(0)] * 7
            for signs in itertools.product((0, 1), repeat=len(beta)):
                pr = Fr(1); val = Fr(0)
                for bb, s_ in zip(beta, signs):
                    pr *= qq if s_ else 1 - qq
                    val += bb * (uu if s_ else -vv)
                for k in range(7):
                    EM[k] += pr * val ** k
            p = [sum(bb ** j for bb in beta) for j in range(7)]
            assert EM[1] == 0 and EM[2] == 1
            assert EM[3] == K3 * p[3]
            assert EM[4] == 3 + K4 * p[4]
            assert EM[5] == K5 * p[5] + 10 * K3 * p[3]
            assert EM[6] == 15 + 15 * K4 * p[4] + 10 * K3 ** 2 * p[3] ** 2 + K6 * p[6]
    say("A2 moment formulas of M (exact enumeration, 16 cases): OK")
    # quartic certificate closed forms
    B0 = tau ** 4 * (2 * a - b * (u ** 2 - 1))
    s = tau ** 3 * (b * u ** 2 - a)
    B = B0 - 2 * c4 * u
    G = s - B0 * u + c4 * u ** 2
    P = (y + v) ** 2 * (c4 * y ** 2 + B * y + G)
    l1 = (1 - q) * (b * y - a * v)
    l2 = -q * (b * y + a * u)
    assert sp.simplify((P - l1).subs(y, u)) == 0
    assert sp.simplify(sp.diff(P - l1, y).subs(y, u)) == 0
    assert sp.simplify(B ** 2 - 4 * c4 * G - (B0 ** 2 - 4 * c4 * s)) == 0
    quo, rem = sp.div(sp.Poly(sp.expand((P - l1) * u ** 8 * (1 + u ** 2) ** 4), y),
                      sp.Poly((y - u) ** 2, y))
    assert sp.simplify(rem.as_expr()) == 0
    S1 = sp.Poly(sp.simplify(quo.as_expr() / (u ** 8 * (1 + u ** 2) ** 4)), y)
    d2c, d1c, d0c = [S1.coeff_monomial(y ** k) for k in (2, 1, 0)]
    assert sp.simplify(d2c - c4) == 0
    assert sp.simplify(d1c ** 2 - 4 * d2c * d0c - (B0 ** 2 - 4 * c4 * (s + B0 * (u + v)))) == 0
    Pp = sp.Poly(sp.expand(P), y)
    c3 = Pp.coeff_monomial(y ** 3)
    K3s, K4s = u - v, u ** 2 + v ** 2 - 4
    assert sp.simplify(K3s * c3 + 2 * K4s * c4 - (K3s * B0 - 4 * c4)) == 0
    assert sp.simplify(Pp.coeff_monomial(y ** 4) - c4) == 0
    # E P(chi) = q (1-q)(b u - a v) and the two-point value
    EPchi = sp.simplify(q * P.subs(y, u) + (1 - q) * P.subs(y, -v))
    assert sp.simplify(EPchi - q * (1 - q) * (b * u - a * v)) == 0
    assert sp.simplify(2 * tau * a + 2 * q * (1 - q) * (b * u - a * v) - 2 * tau * (1 - q) * (a + b)) == 0
    # Q3 expansion: P(-z0-x) - l2(-z0-x) = e0 + e1 x + e2 x^2 + e3 x^3 + c4 x^4
    z0 = a * u / b
    d = z0 - v
    g1 = 2 * c4 * z0 - B
    g0 = c4 * z0 ** 2 - B * z0 + G
    e = [d ** 2 * g0, d ** 2 * g1 + 2 * d * g0 - q * b, d ** 2 * c4 + 2 * d * g1 + g0, 2 * d * c4 + g1, c4]
    f = sp.expand((P - l2).subs(y, -z0 - x))
    fp = sp.Poly(f, x)
    for k in range(5):
        assert sp.simplify(fp.coeff_monomial(x ** k) - e[k]) == 0
    assert sp.simplify(l2.subs(y, -z0 - x) - q * b * x) == 0
    # Pythagorean parametrisation
    aa, bb = 2 * t / (1 + t ** 2), (1 - t ** 2) / (1 + t ** 2)
    assert sp.simplify(aa ** 2 + bb ** 2 - 1) == 0
    say("A3 quartic certificate closed forms (tangency, discriminants, Q4, E P(chi), Q3 expansion): OK")
    return True


# ----------------------------------------------------------------------------- B
def rect_area(r):
    return (r[1] - r[0]) * (r[3] - r[2])


def check_tiling(region, rects, name):
    for r in rects:
        assert region[0] <= r[0] < r[1] <= region[1] and region[2] <= r[2] < r[3] <= region[3], (name, r)
    rs = sorted(rects)
    # pairwise interior disjointness (sweep in u)
    for i in range(len(rs)):
        for j in range(i + 1, len(rs)):
            if rs[j][0] >= rs[i][1]:
                break
            ov_u = min(rs[i][1], rs[j][1]) - max(rs[i][0], rs[j][0])
            ov_a = min(rs[i][3], rs[j][3]) - max(rs[i][2], rs[j][2])
            assert not (ov_u > 0 and ov_a > 0), (name, rs[i], rs[j])
    tot = sum(rect_area(r) for r in rects)
    assert tot == rect_area(region), (name, float(tot / rect_area(region)))
    # closed rectangles, disjoint interiors, full total area => union is the whole region


def a_of_t(t):
    return 2 * t / (1 + t * t)


def part_B():
    pieces = []
    files = sorted(glob.glob(os.path.join(OUT, "cover", "*.json")))
    ncell = 0
    for fn in files:
        d = json.load(open(fn))
        region = tuple(Fr(x) for x in d["region"])
        rects = [tuple(Fr(c[k]) for k in ("u1", "u2", "a1", "a2")) for c in d["cells"]]
        assert not d["failed"], fn
        check_tiling(region, rects, fn)
        pieces.append(region)
        ncell += len(rects)
    dq = json.load(open(os.path.join(OUT, "quartic_cover.json")))
    qreg = tuple(Fr(x) for x in dq["region"])
    assert qreg == (UQ, U0BAR, TQ[0], TQ[1]) and not dq["failed"]
    qrects = [tuple(Fr(c[k]) for k in ("u1", "u2", "t1", "t2")) for c in dq["boxes"]]
    check_tiling(qreg, qrects, "quartic")
    # a(t) increasing on [0,1]: the quartic box covers a in [a(t1), a(t2)] which contains AQ
    assert a_of_t(TQ[0]) <= AQ[0] and a_of_t(TQ[1]) >= AQ[1]
    pieces.append((UQ, U0BAR, AQ[0], AQ[1]))
    pieces.append((Fr(1), U0BAR, A_ND, Fr(1)))
    # union of pieces = [1, U0BAR] x [0, 1]: check on the grid of all breakpoints
    us = sorted({p[0] for p in pieces} | {p[1] for p in pieces})
    as_ = sorted({p[2] for p in pieces} | {p[3] for p in pieces})
    assert us[0] == 1 and us[-1] == U0BAR and as_[0] == 0 and as_[-1] == 1
    for i in range(len(us) - 1):
        for j in range(len(as_) - 1):
            cu, ca = (us[i] + us[i + 1]) / 2, (as_[j] + as_[j + 1]) / 2
            assert any(p[0] <= cu <= p[1] and p[2] <= ca <= p[3] for p in pieces), (cu, ca)
    u0sq = 1 + 2 ** 0.5
    assert U0BAR ** 4 - 2 * U0BAR ** 2 - 1 > 0 and U0BAR > 1   # U0BAR^2 > 1+sqrt2
    say("B coverage: %d six-moment cells in %d rectangles, %d quartic boxes, near-dictator strip;"
        " union = [1, %s] x [0, 1]: OK" % (ncell, len(files), len(qrects), U0BAR))
    return True


# ----------------------------------------------------------------------------- C
def p_strip(p):
    p = list(p)
    while p and p[-1] == 0:
        p.pop()
    return p


def p_rem(n, d):
    n = list(n)
    dd = len(d) - 1
    lc = d[-1]
    while len(n) - 1 >= dd and n:
        k = len(n) - 1 - dd
        f = n[-1] / lc
        for i in range(len(d)):
            n[k + i] -= f * d[i]
        n.pop()
        n = p_strip(n)
    return n


def p_eval(p, x):
    r = Fr(0)
    for c in reversed(p):
        r = r * x + c
    return r


def sturm_seq(p):
    p = p_strip(p)
    seq = [p, p_strip([i * p[i] for i in range(1, len(p))])]
    while seq[-1] and len(seq[-1]) > 1:
        r = p_rem(seq[-2], seq[-1])
        if not r:
            break
        seq.append([-c for c in r])
    return seq


def sign_changes(vals):
    s = [v for v in vals if v != 0]
    return sum(1 for i in range(len(s) - 1) if (s[i] > 0) != (s[i + 1] > 0))


def roots_real_line(p):
    seq = sturm_seq(p)
    at_pinf = [q_[-1] for q_ in seq if q_]
    at_minf = [q_[-1] * (-1) ** (len(q_) - 1) for q_ in seq if q_]
    return sign_changes(at_minf) - sign_changes(at_pinf)


def roots_in(p, lo, hi):
    """number of distinct real roots in (lo, hi]"""
    seq = sturm_seq(p)
    return sign_changes([p_eval(q_, lo) for q_ in seq if q_]) - sign_changes([p_eval(q_, hi) for q_ in seq if q_])


def positive_everywhere(p):
    p = p_strip(p)
    return len(p) % 2 == 1 and p[-1] > 0 and p[0] > 0 and roots_real_line(p) == 0


def sqrt_hi(x, den=10 ** 15):
    n = isqrt(x.numerator * den * den // x.denominator) + 1
    r = Fr(n, den)
    assert r * r >= x
    return r


def sqrt_lo(x, den=10 ** 15):
    n = isqrt(x.numerator * den * den // x.denominator)
    r = Fr(n, den)
    assert r * r <= x
    return r


def check_cell(cell):
    u1, u2, a1, a2 = (Fr(cell[k]) for k in ("u1", "u2", "a1", "a2"))
    c = [Fr(x) for x in cell["c"]]
    assert len(c) == 7 and 1 <= u1 < u2 and 0 <= a1 < a2 < 1
    b1 = sqrt_hi(1 - a1 * a1)                  # b <= b1 on the cell
    if 2 * a2 * a2 >= 1:
        mb = Fr(1)
    else:
        mb = min(Fr(1), a2 / sqrt_lo(1 - a2 * a2))
        assert mb * mb * (1 - a2 * a2) >= a2 * a2 or mb == 1
    # R_a(b y) <= max(0, L1(y), L2(y)) on the cell
    s1 = u2 * u2 / (1 + u2 * u2)
    L1 = [-s1 * a1 / u2, s1 * b1]
    s2 = 1 / (1 + u1 * u1)
    L2 = [-s2 * a1 * u1, -s2 * b1]
    if not positive_everywhere(c):
        return "V1"
    if not positive_everywhere([c[0] - L1[0], c[1] - L1[1]] + c[2:]):
        return "V2"
    if not positive_everywhere([c[0] - L2[0], c[1] - L2[1]] + c[2:]):
        return "V3"
    # cumulant ranges on [u1,u2] (u >= 1): k3 = u - 1/u increasing >= 0, w = u^2 + u^-2
    # increasing, k4 = w - 4, k5 = k3 (w - 10), k6 = w^2 - 26 w + 64 (decreasing for w < 13)
    k3lo, k3hi = u1 - 1 / u1, u2 - 1 / u2
    wlo, whi = u1 * u1 + 1 / (u1 * u1), u2 * u2 + 1 / (u2 * u2)
    assert whi < 13 and k3lo >= 0
    k5abs = k3hi * max(abs(wlo - 10), abs(whi - 10))
    A = c[0] + c[2] + 3 * c[4] + 15 * c[6]
    Bb = k3hi * abs(c[3] + 10 * c[5])
    Ch = max((wlo - 4) * (c[4] + 15 * c[6]), (whi - 4) * (c[4] + 15 * c[6]))
    Db = k5abs * abs(c[5])
    Eh = max((wlo * wlo - 26 * wlo + 64) * c[6], (whi * whi - 26 * whi + 64) * c[6])
    Fh = max(Fr(0), 10 * k3lo ** 2 * c[6], 10 * k3hi ** 2 * c[6])
    gam = Ch + Db * mb + Fh + (Eh * mb * mb if Eh >= 0 else 0)
    eps = Eh if Eh < 0 else Fr(0)
    target = u2 / (1 + u2 * u2) * (1 - a2) - A
    # need target - (Bb r + gam r^2 + eps r^4) > 0 on [0, mb]
    h = p_strip([target, -Bb, -gam, Fr(0), -eps])
    if target <= 0:
        return "V4"
    if len(h) > 1 and roots_in(h, Fr(0), mb) != 0:
        return "V4"
    if p_eval(h, mb) <= 0:
        return "V4"
    return "ok"


def part_C():
    t0 = time.time()
    n = 0
    for fn in sorted(glob.glob(os.path.join(OUT, "cover", "*.json"))):
        d = json.load(open(fn))
        for cell in d["cells"]:
            r = check_cell(cell)
            assert r == "ok", (fn, cell["u1"], cell["u2"], cell["a1"], cell["a2"], r)
            n += 1
    say("C six-moment certificates: %d cells re-verified exactly (own Sturm code), %.0fs: OK" % (n, time.time() - t0))
    return True


# ----------------------------------------------------------------------------- D
def part_D():
    import mpmath
    from mpmath import iv
    iv.prec = 120

    def ivr(x):
        x = Fr(x)
        return iv.mpf(x.numerator) / iv.mpf(x.denominator)

    def lo(z):
        return z.a

    def hi(z):
        return z.b

    def sq(z):
        if z.a >= 0:
            return z * z
        if z.b <= 0:
            return z * z
        m = max(abs(z.a), abs(z.b))
        return iv.mpf([0, m * m])

    def quantities(u1, u2, t1, t2, c4):
        U = iv.mpf([ivr(u1).a, ivr(u2).b])
        T = iv.mpf([ivr(t1).a, ivr(t2).b])
        C4 = ivr(c4)
        # a = 2t/(1+t^2) increasing, b = (1-t^2)/(1+t^2) decreasing on [0,1]
        a = iv.mpf([(2 * ivr(t1) / (1 + ivr(t1) ** 2)).a, (2 * ivr(t2) / (1 + ivr(t2) ** 2)).b])
        b = iv.mpf([((1 - ivr(t2) ** 2) / (1 + ivr(t2) ** 2)).a, ((1 - ivr(t1) ** 2) / (1 + ivr(t1) ** 2)).b])
        U2 = U * U
        X = U2 - 1
        # tau = u/(1+u^2) decreasing for u >= 1; q = 1/(1+u^2) decreasing
        tau = iv.mpf([(ivr(u2) / (1 + ivr(u2) ** 2)).a, (ivr(u1) / (1 + ivr(u1) ** 2)).b])
        q = iv.mpf([(1 / (1 + ivr(u2) ** 2)).a, (1 / (1 + ivr(u1) ** 2)).b])
        v = 1 / U
        T1 = b * U2 - a
        T2 = a * U2 - b
        B0 = tau ** 4 * (2 * a - b * X)
        s = tau ** 3 * T1
        Q1 = 4 * C4 * s - sq(B0)
        Q4 = X * v * B0 - 4 * C4
        B = B0 - 2 * C4 * U
        G = s - B0 * U + C4 * U2
        # coefficients of P(y) = (y+v)^2 (c4 y^2 + B y + G), then Taylor shift to y = -z0 - x
        p0 = v * v * G
        p1 = 2 * v * G + v * v * B
        p2 = G + 2 * v * B + v * v * C4
        p3 = B + 2 * v * C4
        p4 = C4
        z0 = a * U / b
        m = -z0
        # f(x) = P(m - x) - q b x ;  P(m - x) = sum_k P^{(k)}(m)/k! (-x)^k
        P0 = (((p4 * m + p3) * m + p2) * m + p1) * m + p0
        P1 = ((4 * p4 * m + 3 * p3) * m + 2 * p2) * m + p1
        P2 = (6 * p4 * m + 3 * p3) * m + p2
        P3 = 4 * p4 * m + p3
        e0, e1, e2, e3 = P0, -P1 - q * b, P2, -P3
        return dict(T1=T1, T2=T2, B0=B0, Q1=Q1, Q4=Q4, e0=e0, e1=e1, e2=e2, e3=e3, C4=C4)

    def ok_box(u1, u2, t1, t2, c4):
        Q = quantities(u1, u2, t1, t2, c4)
        if not (lo(Q["T1"]) > 0 and lo(Q["T2"]) > 0 and lo(Q["B0"]) > 0 and lo(Q["Q1"]) > 0
                and lo(Q["Q4"]) > 0 and lo(Q["e0"]) > 0):
            return False
        m1 = min(lo(Q["e1"]), 0)
        m3 = min(lo(Q["e3"]), 0)
        # f(x) >= (sqrt(e0) + e1^- x/(2 sqrt e0))^2 + x^2 (e2 - (e1^-)^2/(4e0) + e3 x + c4 x^2)
        H = iv.mpf(lo(Q["e2"])) - iv.mpf(m1) ** 2 / (4 * iv.mpf(lo(Q["e0"]))) - iv.mpf(m3) ** 2 / (4 * Q["C4"])
        return lo(H) > 0

    def verify(u1, u2, t1, t2, c4, depth=0):
        if ok_box(u1, u2, t1, t2, c4):
            return 1
        if depth >= 7:
            raise AssertionError(("quartic box failed", float(u1), float(u2), float(t1), float(t2)))
        um, tm = (u1 + u2) / 2, (t1 + t2) / 2
        return sum(verify(x1, x2, y1, y2, c4, depth + 1)
                   for (x1, x2) in ((u1, um), (um, u2)) for (y1, y2) in ((t1, tm), (tm, t2)))

    t0 = time.time()
    dq = json.load(open(os.path.join(OUT, "quartic_cover.json")))
    nsub = 0
    for bx in dq["boxes"]:
        u1, u2, t1, t2 = (Fr(bx[k]) for k in ("u1", "u2", "t1", "t2"))
        c4 = Fr(bx["c4"])
        assert c4 > 0 and 1 <= u1 < u2 and 0 < t1 < t2 < 1
        nsub += verify(u1, u2, t1, t2, c4)
    say("D quartic certificate: %d boxes re-verified with mpmath interval arithmetic (%d sub-boxes), %.0fs: OK"
        % (len(dq["boxes"]), nsub, time.time() - t0))
    return True


# ----------------------------------------------------------------------------- E
def part_E():
    # for a in [9/10, 1), u in [1, u0]:  (81/256) (1-a)(1+a)^2 (u^4+v^4) / a^3 <= 0.95 < 1
    # (1-a)(1+a)^2/a^3 is decreasing on (0,1); u^4 + u^-4 is increasing on u >= 1 and
    # equals 6 at u0 (u0^4 = 3+2sqrt2).
    a = A_ND
    val = Fr(81, 256) * (1 - a) * (1 + a) ** 2 * 6 / a ** 3
    assert val < Fr(95, 100), float(val)
    say("E near-dictator constant at a = 9/10: %.6f < 1: OK" % float(val))
    return True


if __name__ == "__main__":
    parts = sys.argv[1:] or ["A", "B", "C", "D", "E"]
    for p_ in parts:
        globals()["part_" + p_]()
    say("ALL SELECTED PARTS PASSED:", " ".join(parts))
