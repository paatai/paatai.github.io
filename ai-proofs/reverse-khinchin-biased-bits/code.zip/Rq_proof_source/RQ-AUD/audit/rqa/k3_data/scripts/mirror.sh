#!/bin/bash
# mirror working folder to the bot store; copies only files whose md5 changed since the last
# successful mirror from this machine (state in /tmp; if it is missing, everything is copied)
DEST=/cursor/stores/bot/rq/RQ-A
STATE=/tmp/rqa_mirror_md5.txt
mkdir -p "$DEST"
cd /workspace || exit 1
NEW=$(mktemp)
{ ls -1d *.md *.pdf *.tex .gitignore 2>/dev/null
  find scripts outputs notes tex -type f ! -path '*__pycache__*' 2>/dev/null; } | sort -u |
  xargs -d '\n' md5sum | sort > "$NEW"
touch "$STATE"
n=0
while IFS= read -r line; do
  f="${line:34}"
  mkdir -p "$DEST/$(dirname "$f")" && cp -f "$f" "$DEST/$f" || { echo "copy failed: $f"; exit 1; }
  n=$((n + 1))
done < <(comm -23 "$NEW" <(sort "$STATE"))
mv -f "$NEW" "$STATE"
date -u > "$DEST/LAST_MIRROR.txt"
echo "mirrored $n changed files"
