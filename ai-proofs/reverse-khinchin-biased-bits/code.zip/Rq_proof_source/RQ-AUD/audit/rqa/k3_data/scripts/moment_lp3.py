"""Moment LP with cumulant-structure constraints up to order 6 (floating point exploration).

Variables: weights w_j >= 0 on grid y_j, plus auxiliary power sums p3,p4,p5,p6,P33 (P33 ~ p3^2).
"""
import sys
import numpy as np
from scipy.optimize import linprog
from rqlib import params
from moment_lp import tail_constraints


def cumulants(q):
    u, v, tau = params(q)
    t2 = tau * tau
    th = 1 - 2 * q
    k3 = th / tau
    k4 = (1 - 6 * t2) / t2
    k5 = th * (1 - 12 * t2) / tau ** 3
    k6 = (1 - 30 * t2 + 120 * t2 * t2) / t2 ** 2
    return k3, k4, k5, k6


def lp6(q, a, m=None, order=6, tails=True, absM=True, K=10.0, N=4001, verbose=False, tail_ts=None):
    u, v, tau = params(q)
    b = np.sqrt(1 - a * a)
    if m is None:
        m = min(1.0, a / b)
    k3, k4, k5, k6 = cumulants(q)
    y = np.linspace(-K, K, N)
    R = (1 - q) * np.maximum(b * y - a * v, 0) + q * np.maximum(-b * y - a * u, 0)
    nY = len(y)
    # variable vector: [w (nY), p3, p4, p5, p6, P33]
    nv = nY + 5
    I3, I4, I5, I6, I33 = nY, nY + 1, nY + 2, nY + 3, nY + 4
    Aeq, beq, Aub, bub = [], [], [], []

    def row():
        return np.zeros(nv)

    r = row(); r[:nY] = 1; Aeq.append(r); beq.append(1)
    r = row(); r[:nY] = y; Aeq.append(r); beq.append(0)
    r = row(); r[:nY] = y ** 2; Aeq.append(r); beq.append(1)
    if order >= 3:
        r = row(); r[:nY] = y ** 3; r[I3] = -k3; Aeq.append(r); beq.append(0)
    if order >= 4:
        r = row(); r[:nY] = y ** 4; r[I4] = -k4; Aeq.append(r); beq.append(3)
    if order >= 5:
        r = row(); r[:nY] = y ** 5; r[I5] = -k5; r[I3] = -10 * k3; Aeq.append(r); beq.append(0)
    if order >= 6:
        r = row(); r[:nY] = y ** 6; r[I4] = -15 * k4; r[I33] = -10 * k3 * k3; r[I6] = -k6; Aeq.append(r); beq.append(15)
    # power-sum constraints
    bounds = [(0, None)] * nY + [(-m, m), (0, m * m), (-m ** 3, m ** 3), (0, m ** 4), (0, m * m)]
    # P33 >= p3^2 (tangents), P33 <= p4
    for c in np.linspace(-m, m, 41):
        r = row(); r[I33] = -1; r[I3] = 2 * c; Aub.append(r); bub.append(c * c)
    r = row(); r[I33] = 1; r[I4] = -1; Aub.append(r); bub.append(0)
    # p3^2 <= p4 (tangents): 2c p3 - c^2 <= p4
    for c in np.linspace(-m, m, 41):
        r = row(); r[I3] = 2 * c; r[I4] = -1; Aub.append(r); bub.append(c * c)
    # p6 <= m^2 p4 ; p6 >= p4^2 (tangents)
    r = row(); r[I6] = 1; r[I4] = -m * m; Aub.append(r); bub.append(0)
    for c in np.linspace(0, m * m, 41):
        r = row(); r[I4] = 2 * c; r[I6] = -1; Aub.append(r); bub.append(c * c)
    # |p5| <= m p4
    r = row(); r[I5] = 1; r[I4] = -m; Aub.append(r); bub.append(0)
    r = row(); r[I5] = -1; r[I4] = -m; Aub.append(r); bub.append(0)
    if absM:
        r = row(); r[:nY] = np.abs(y); Aub.append(r); bub.append(2 * tau)
    if tails:
        ts = np.linspace(0.25, 5, 20) if tail_ts is None else tail_ts
        for fn, bd in tail_constraints(q, ts):
            r = row(); r[:nY] = fn(y); Aub.append(r); bub.append(bd)
    cobj = np.zeros(nv); cobj[:nY] = -R
    res = linprog(cobj, A_ub=np.array(Aub), b_ub=np.array(bub), A_eq=np.array(Aeq), b_eq=np.array(beq),
                  bounds=bounds, method="highs")
    if res.status != 0:
        return None, None, res
    val = -res.fun
    if verbose:
        w = res.x[:nY]; idx = w > 1e-7
        print("   support:", list(zip(np.round(y[idx], 3), np.round(w[idx], 5))))
        print("   p3,p4,p5,p6,P33 =", np.round(res.x[nY:], 5))
    return val, (2 * tau * a + 2 * val) / (2 * tau), res


if __name__ == "__main__":
    q = float(sys.argv[1]) if len(sys.argv) > 1 else 1 - 1 / np.sqrt(2)
    print("q=%.5f cumulants k3..k6 =" % q, np.round(cumulants(q), 4))
    for a in [0.1, 0.12, 0.15, 0.17, 0.2, 0.25, 0.3, 0.4, 0.5, 0.6, 0.7071, 0.8, 0.85, 0.9, 0.95, 0.98]:
        r4 = lp6(q, a, order=4)[1]
        r6 = lp6(q, a, order=6)[1]
        r6nt = lp6(q, a, order=6, tails=False)[1]
        r6na = lp6(q, a, order=6, tails=False, absM=False)[1]
        print("a=%.4f  ord4: %.5f  ord6: %.5f  ord6 no tails: %.5f  ord6 no tails no |M|: %.5f" % (a, r4, r6, r6nt, r6na))
