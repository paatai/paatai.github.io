"""Three-coordinate near-sphere test for the m-split (exact rational interval arithmetic).

Box (u,t,r,s) as in cert2c.py, plus an interval [m1,m2] for m = max_i |beta_i| and a sign s3.
For alpha sorted (a1 >= a2 >= |alpha_3| >= ...), m = |alpha_3|/b, so a3 := |alpha_3| = b m and
    L = a1 chi_1 + s a2 chi_2 + s3 a3 chi_3 + b' M',   b' = b sqrt(1-m^2),
with M' of unit variance whose coefficients are at most 1 in absolute value, so
E M'^4 <= E4 := 3 + max(0, kappa4).  With Y = a1 chi_1 + s a2 chi_2 + s3 a3 chi_3 (atoms y_j,
probabilities p_j) and r' = sqrt(1-b'^2) = |(a1,a2,a3)|:
    E|L| <= E|Y| + sum_j p_j e_j,   e_j = min(b', (27/128) b'^4 E4/|y_j|^3).
  (A3) if q >= q3 then E|Y| <= r' T (three-bit lemma), so it suffices that
       (27/128) E4 b'^2 (1+r') sum_j p_j/|y_j|^3 <= T            (uses 1-r' = b'^2/(1+r'));
  (B3) directly: E|Y| + sum_j p_j e_j <= T.
"""
from fractions import Fraction as Fr
from cert2c import I, cell_params, T_lo
from exactcert import sqrt_lo, sqrt_up
from nearcircle import absI

K27 = Fr(27, 128)


def atoms3(P, s, s3, a3):
    """List of (p_j interval, p_j y_j interval, y_j interval) for the 8 atoms."""
    u = I(P["u1"], P["u2"])
    v = I(1 / P["u2"], 1 / P["u1"])
    q, qb, tau = P["q"], P["qb"], P["tau"]
    a1 = P["r"] * P["c"]
    a2 = P["r"] * P["d"]
    coef = (a1, a2 if s == 1 else -a2, a3 if s3 == 1 else -a3)
    out = []
    for e1 in (1, -1):
        for e2 in (1, -1):
            for e3 in (1, -1):
                es = (e1, e2, e3)
                pr = [q if e == 1 else qb for e in es]
                p = pr[0] * pr[1] * pr[2]
                y = I(0)
                py = I(0)
                for i in range(3):
                    y = y + coef[i] * (u if es[i] == 1 else -v)
                    other = pr[(i + 1) % 3] * pr[(i + 2) % 3]
                    py = py + coef[i] * other * (tau if es[i] == 1 else -tau)
                out.append((p, py, y))
    return out


def check_piece(P, s, s3, m1, m2, T, E4):
    """Return 'A3', 'B3' or None for the m-interval [m1, m2] (0 < m1 < m2 <= 1)."""
    blo, bhi = P["b"].lo, P["b"].hi
    a3 = I(blo * m1, bhi * m2)
    bp2hi = bhi * bhi * (1 - m1 * m1)
    bphi = sqrt_up(bp2hi) if bp2hi > 0 else Fr(0)
    rphi = min(Fr(1), sqrt_up(1 - blo * blo * (1 - m2 * m2)))
    at = atoms3(P, s, s3, a3)
    ys = [absI(y) for (_, _, y) in at]
    if all(y.lo > 0 for y in ys):
        S = sum(p.hi / y.lo ** 3 for (p, _, _), y in zip(at, ys))
        if K27 * E4 * bp2hi * (1 + rphi) * S <= T:
            return "A3"
    tot = Fr(0)
    for (p, py, _), y in zip(at, ys):
        e = bphi
        if y.lo > 0:
            e = min(e, K27 * bp2hi * bp2hi * E4 / y.lo ** 3)
        tot += absI(py).hi + p.hi * e
        if tot > T:
            return None
    return "B3"


def check_ms(u1, u2, t1, t2, r1, r2, s, mcut, mtop, max_pieces=16, s3_list=(1,)):
    """Cover m in [mcut, mtop] by A3/B3 pieces for each s3 in s3_list; list of pieces or None."""
    P = cell_params(u1, u2, t1, t2, r1, r2)
    if P["b"].lo <= 0:
        return None
    T = T_lo(P["u1"], P["u2"])
    u2f = P["u2"]
    k4hi = u2f * u2f + 1 / (u2f * u2f) - 4
    E4 = 3 + max(Fr(0), k4hi)
    pieces = []
    for s3 in s3_list:
        stack = [(Fr(mcut), Fr(mtop), 0)]
        n = 0
        while stack:
            m1, m2, dep = stack.pop()
            kind = check_piece(P, s, s3, m1, m2, T, E4)
            if kind is not None:
                pieces.append([str(m1), str(m2), s3, kind])
                continue
            n += 1
            if dep >= 4 or n > max_pieces:
                return None
            mm = (m1 + m2) / 2
            stack += [(m1, mm, dep + 1), (mm, m2, dep + 1)]
    return pieces
