"""Near-circle boxes for the two-coordinate split (exact rational interval arithmetic).

For a point (u,t,r,s) (notation of cert2c.py) let y_j be the atoms of c chi_1 + s d chi_2 and
G = E|c chi_1 + s d chi_2| = tau sum_j |g_j|.  For every admissible M (E M^2 = 1, E M^4 <= E4):
    E|L| <= r G + sum_j p_j err_j,   err_j = min(b, (27/128) b^4 E4 / (r^3 |y_j|^3)),
and we need E|L| <= T := 2 sqrt2 (1-q) tau.  Since G <= T (two-coordinate value) and
1 - r = b^2/(1+r), it suffices that
  (A)  (27/128) E4 b^2 (1+r)/r^3 sum_j p_j/|y_j|^3 <= T      (all atoms away from 0), or
  (B)  sum_j p_j err_j <= T(1-r) + r(T-G).
Each test is checked on the whole box with interval bounds.
"""
from fractions import Fraction as Fr
from cert2c import I, cell_params, T_lo, atoms_g

K27 = Fr(27, 128)


def atoms_y(P, s):
    c, d = P["c"], P["d"]
    u1, u2 = P["u1"], P["u2"]
    u = I(u1, u2)
    v = I(1 / u2, 1 / u1)
    sd = d if s == 1 else -d
    return [(c + sd) * u, c * u - sd * v, -(c * v) + sd * u, -((c + sd) * v)]


def absI(x):
    if x.lo >= 0:
        return I(x.lo, x.hi)
    if x.hi <= 0:
        return I(-x.hi, -x.lo)
    return I(0, max(-x.lo, x.hi))


def check_box(u1, u2, t1, t2, r1, r2, s):
    P = cell_params(u1, u2, t1, t2, r1, r2)
    r1, r2 = P["r"].lo, P["r"].hi
    if r1 <= 0:
        return False, "r1=0"
    T = T_lo(P["u1"], P["u2"])
    u2f = P["u2"]
    k4hi = u2f * u2f + 1 / (u2f * u2f) - 4
    E4 = 3 + max(Fr(0), k4hi) * P["mbar"] ** 2
    g, p = atoms_g(P, s)
    ys = [absI(y) for y in atoms_y(P, s)]
    bhi = P["b"].hi
    # test A
    if all(y.lo > 0 for y in ys):
        S = sum(pj.hi / y.lo ** 3 for pj, y in zip(p, ys))
        lhs = K27 * E4 * bhi * bhi * (1 + r2) / r1 ** 3 * S
        if lhs <= T:
            return True, "A"
    # test B
    G = P["tau"].hi * sum(absI(gj).hi for gj in g)
    if T - G < 0:
        return False, "G"
    lhs = Fr(0)
    for pj, y in zip(p, ys):
        e = bhi
        if y.lo > 0:
            e = min(e, K27 * bhi ** 4 * E4 / (r1 ** 3 * y.lo ** 3))
        lhs += pj.hi * e
    rhs = T * (1 - r2) + r1 * (T - G)
    if lhs <= rhs:
        return True, "B"
    return False, "AB"
