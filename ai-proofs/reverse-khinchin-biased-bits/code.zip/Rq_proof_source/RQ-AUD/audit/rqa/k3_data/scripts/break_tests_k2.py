"""Negative tests for Theorem 2 (and, with RQ_K=3, Theorem 3): the independent verifier
(verify_k2.py) must reject corrupted data.

For random samples of each box kind, corrupt one ingredient and count how often the verifier's
check functions reject the record.  Also checks that the three-bit claim fails just outside
its range ([q3, q0] for k = 2; above q3 for k = 3).  Output: outputs/break_tests_k2.txt
(RQ_K=3: outputs/break_tests_k3.txt).
"""
import copy
import json
import os
import random
from fractions import Fraction as Fr

import verify_k2 as V

random.seed(20261022)
U_LO, U_HI, T8, ONE, TWO = V.load_manifest()
K, A_S = V.K, V.A_S


def rejected_ms(bx):
    """an m-split record is accepted only if both part D (certificates) and part F (pieces) pass"""
    return V.check_two(bx, U_LO) != "ok" or V.check_ms3(bx) != "ok"


def sample(kinds, k):
    items = [bx for _, bx in V.iter_boxes(TWO, kinds)]
    return random.sample(items, min(k, len(items)))


def frs(xs):
    return [Fr(x) for x in xs]


def setc(bx, key, c):
    bx[key] = [str(x) for x in c]


lines = []


def report(name, nrej, ntot):
    s = "%-62s rejected %3d / %3d" % (name, nrej, ntot)
    print(s, flush=True)
    lines.append(s)


# ---------------------------------------------------------------- m-split boxes
ms = sample(("ms",), 40)
assert all(not rejected_ms(bx) for bx in ms)


def corrupt_ms(f):
    """returns (rejected, changed): records left unchanged by f are not counted"""
    n = m = 0
    for bx in ms:
        b2 = copy.deepcopy(bx)
        f(b2)
        if b2 != bx:
            m += 1
            n += rejected_ms(b2)
    return n, m


def lower_mcut(b):
    b["mcut"] = str(Fr(b["mcut"]) - Fr(1, 10))


def raise_mcut(b):
    b["mcut"] = str(min(Fr(1), Fr(b["mcut"]) + Fr(1, 10)))


def drop_top_piece(b):
    ps = sorted(b["pieces"], key=lambda p: Fr(p[1]))
    b["pieces"] = ps[:-1] if len(ps) > 1 else [[ps[0][0], str((Fr(ps[0][0]) + Fr(ps[0][1])) / 2), ps[0][2]]]


def lower_p3max(b):
    b["p3max"] = str(Fr(b["p3max"]) - Fr(1, 100))


def drop_c2_const(b):
    c = frs(b["c2"])
    c[0] -= Fr(1, 1000)
    setc(b, "c2", c)


def shrink_c1_const(b):
    c = frs(b["c"])
    c[0] *= Fr(99, 100)
    setc(b, "c", c)


def widen_r(b):
    bb = frs(b["box"])
    bb[4] = max(A_S, bb[4] - Fr(1, 20))
    b["box"] = [str(x) for x in bb]


def widen_t(b):
    bb = frs(b["box"])
    bb[2] = max(Fr(0), bb[2] - Fr(1, 20))
    b["box"] = [str(x) for x in bb]


report("ms: m_c lowered by 1/10 (pieces no longer reach m_c)", *corrupt_ms(lower_mcut))
report("ms: m_c raised by 1/10 (capped certificate must cover more)", *corrupt_ms(raise_mcut))
report("ms: top piece removed / halved", *corrupt_ms(drop_top_piece))
report("ms: p* lowered by 1/100 (below phi(m_c))", *corrupt_ms(lower_p3max))
report("ms: constant term of c2 lowered by 1/1000", *corrupt_ms(drop_c2_const))
report("ms: constant term of c1 multiplied by 99/100", *corrupt_ms(shrink_c1_const))
report("ms: r-interval widened downwards by 1/20", *corrupt_ms(widen_r))
report("ms: t-interval widened downwards by 1/20", *corrupt_ms(widen_t))
# p* = 1 + m_c^3 satisfies the phi inequality for -m_c, so only the guards 0 < m_c, p* < 0 reject it
report("ms: phi_ok(-m_c, 1 + m_c^3) (guards 0 < m_c, p* < 0)",
       sum(not V.phi_ok(-Fr(bx["mcut"]), 1 + Fr(bx["mcut"]) ** 3) for bx in ms), len(ms))

# boxes moved out of the range of the three-bit lemma (k = 2: beyond u3, i.e. q < q3; k = 3: below
# u3, i.e. q > q3): part F cannot see this (the bound E|Y| <= r'T is Lemma 'three'); the
# certificates of part D may or may not fail.  Informational.
DU = Fr(1, 20) if K == 2 else -Fr(1, 20)


def move_u(b):
    bb = frs(b["box"])
    bb[0], bb[1] = bb[0] + DU, bb[1] + DU
    b["box"] = [str(x) for x in bb]


n_d = n_f = 0
for bx in ms:
    b2 = copy.deepcopy(bx)
    move_u(b2)
    n_d += V.check_two(b2, U_LO) != "ok"
    n_f += V.check_ms3(b2) != "ok"
DUS = "+1/20" if K == 2 else "-1/20"
report("ms (info): u shifted by %s, part D only" % DUS, n_d, len(ms))
report("ms (info): u shifted by %s, part F only %s" % (DUS, "(expected 0)" if K == 2 else "(no range check)"),
       n_f, len(ms))

# ---------------------------------------------------------------- lp boxes
lp = sample(("lp",), 60)
assert all(V.check_two(bx, U_LO) == "ok" for bx in lp)


def corrupt_lp(f):
    n = m = 0
    for bx in lp:
        b2 = copy.deepcopy(bx)
        f(b2)
        if b2 != bx:
            m += 1
            n += V.check_two(b2, U_LO) != "ok"
    return n, m


def lp_const(b):
    c = frs(b["c"])
    c[0] -= Fr(1, 1000) * max(abs(c[0]), Fr(1, 100))
    setc(b, "c", c)


def lp_c6(b):
    c = frs(b["c"])
    c[6] -= Fr(1, 10) * max(abs(c[6]), Fr(1, 100))
    setc(b, "c", c)


def lp_flip_sign(b):
    b["s"] = -b["s"]


def lp_widen_r(b):
    bb = frs(b["box"])
    bb[4] = max(A_S, bb[4] - Fr(1, 10))
    b["box"] = [str(x) for x in bb]


report("lp: c0 lowered by 1e-3 |c0|", *corrupt_lp(lp_const))
report("lp: c6 lowered by 1e-1 |c6|", *corrupt_lp(lp_c6))
report("lp: r-interval widened downwards by 1/10", *corrupt_lp(lp_widen_r))
report("lp (info): sign s flipped", *corrupt_lp(lp_flip_sign))

# ---------------------------------------------------------------- near-circle boxes
nc = sample(("ncA", "ncB"), 60)
assert all(V.check_nc(bx) == "ok" for bx in nc)


def corrupt_nc(f):
    n = m = 0
    for bx in nc:
        b2 = copy.deepcopy(bx)
        f(b2)
        if b2 != bx:
            m += 1
            n += V.check_nc(b2) != "ok"
    return n, m


def nc_widen_r(b):
    bb = frs(b["box"])
    bb[4] = max(A_S, bb[4] - Fr(1, 10))
    b["box"] = [str(x) for x in bb]


def nc_below_u0(b):
    bb = frs(b["box"])
    w = bb[1] - bb[0]
    # k = 2: u <= 3/2 < u0 (q > q0), k = 3: u <= 2 < u3 (q > q3): the two-coordinate value exceeds T
    top = Fr(3, 2) if K == 2 else Fr(2)
    bb[0], bb[1] = top - w, top
    b["box"] = [str(x) for x in bb]


report("nc: r-interval widened downwards by 1/10", *corrupt_nc(nc_widen_r))
# test (A) bounds only the error term; G <= T is Lemma 'two', valid only for q <= q0.  Informational.
report("nc (info): box moved to u <= 3/2 < u0 (q > q0)" if K == 2 else
       "nc (info): box moved to u <= 2 < u3 (q > q3)", *corrupt_nc(nc_below_u0))

# ---------------------------------------------------------------- one-coordinate cells
cells = []
for fn in ONE:
    cells += json.load(open(os.path.join(V.OUT, fn)))["cells"]
cells = random.sample(cells, 40)
assert all(V.check_one(cl) == "ok" for cl in cells)


def corrupt_one(f):
    n = m = 0
    for cl in cells:
        c2 = copy.deepcopy(cl)
        f(c2)
        if c2 != cl:
            m += 1
            n += V.check_one(c2) != "ok"
    return n, m


def one_const(cl):
    c = frs(cl["c"])
    c[0] -= Fr(1, 1000) * max(abs(c[0]), Fr(1, 100))
    setc(cl, "c", c)


def one_widen_a(cl):
    cl["a2"] = str(min(A_S, Fr(cl["a2"]) + Fr(1, 10)))
    cl["a1"] = str(max(Fr(0), Fr(cl["a1"]) - Fr(1, 10)))


report("one: c0 lowered by 1e-3 |c0|", *corrupt_one(one_const))
report("one (info): a-interval widened by 1/10 each side", *corrupt_one(one_widen_a))

# ---------------------------------------------------------------- three-bit claim is sharp
import sympy as sp

q = sp.Symbol("q")
q3 = 1 - sp.sqrt(sp.Rational(2, 3))
q0 = 1 - 1 / sp.sqrt(2)
if K == 2:
    P_or3 = 8 * (1 - q) ** 2 - 3 * (2 * (1 - q) ** 2) ** 2
    P_dic = 8 * (1 - q) ** 2 - 4
    neg3 = sp.N(P_or3.subs(q, q3 - sp.Rational(1, 1000))) < 0
    neg0 = sp.N(P_dic.subs(q, q0 + sp.Rational(1, 1000))) < 0
    s = ("three-bit claim fails at q3 - 1/1000 (OR_3): %s; at q0 + 1/1000 (dictator): %s"
         % (neg3, neg0))
else:
    P_or2 = 12 * (1 - q) ** 4 - 2 * (2 * (1 - q)) ** 2
    neg3 = neg0 = sp.N(P_or2.subs(q, q3 + sp.Rational(1, 1000))) < 0
    s = "three-bit claim (k=3) fails at q3 + 1/1000 (OR_2): %s" % neg3
print(s)
lines.append(s)
assert neg3 and neg0

open(os.path.join(V.OUT, "break_tests_k%d.txt" % K), "w").write("\n".join(lines) + "\n")
print("BREAK_TESTS_K%d_DONE" % K)
