"""Moment LP with polynomial moment constraints from the cumulant structure (evidence only)."""
import sys
import numpy as np
from scipy.optimize import linprog
from rqlib import params
from moment_lp import tail_constraints


def lp_bound_poly(q, a, use3=True, use4=True, coef_bound=None, tails=True, K=8.0, N=3201, verbose=False, absM=True):
    u, v, tau = params(q)
    b = np.sqrt(1 - a * a)
    th = 1 - 2 * q
    y = np.linspace(-K, K, N)
    R = (1 - q) * np.maximum(b * y - a * v, 0) + q * np.maximum(-b * y - a * u, 0)
    A_eq = [np.ones_like(y), y, y ** 2]
    b_eq = [1, 0, 1]
    A_ub, b_ub = [], []
    if absM:
        A_ub.append(np.abs(y)); b_ub.append(2 * tau)
    m = 1.0 if coef_bound is None else min(1.0, coef_bound)
    k3 = th / tau          # kappa_3(chi)
    k4 = th ** 2 / tau ** 2 - 2  # kappa_4(chi) (negative on the central range)
    if use3:
        A_ub.append(y ** 3); b_ub.append(k3 * m)
        A_ub.append(-y ** 3); b_ub.append(k3 * m)
    if use4:
        # E M^4 = 3 + k4 p4,  p4 in [p3^2, m^2] (p4 <= max|beta|^2), k4<0
        A_ub.append(y ** 4); b_ub.append(3 + k4 * 0)      # <= 3 (p4 >= 0)
        A_ub.append(-y ** 4); b_ub.append(-(3 + k4 * m * m))  # >= 3 + k4 m^2
        # p4 >= p3^2 linearised: p4 >= 2c p3 - c^2, p3 = EM^3/k3, p4 = (EM^4-3)/k4
        for c in np.linspace(-1, 1, 41):
            # (EM^4 - 3)/k4 >= 2c EM^3/k3 - c^2  ->  EM^4 - 3 <= k4(2c EM^3/k3 - c^2) (k4<0)
            A_ub.append(y ** 4 - (k4 * 2 * c / k3) * y ** 3); b_ub.append(3 - k4 * c * c)
    if tails:
        for fn, bd in tail_constraints(q, np.linspace(0.25, 5, 20)):
            A_ub.append(fn(y)); b_ub.append(bd)
    res = linprog(-R, A_ub=np.array(A_ub), b_ub=np.array(b_ub), A_eq=np.array(A_eq), b_eq=np.array(b_eq),
                  bounds=(0, None), method="highs")
    if res.status != 0:
        return None, None
    val = -res.fun
    if verbose:
        p = res.x; idx = p > 1e-9
        print("   support:", list(zip(np.round(y[idx], 3), np.round(p[idx], 5))))
    return val, (2 * tau * a + 2 * val) / (2 * tau)


if __name__ == "__main__":
    q = float(sys.argv[1]) if len(sys.argv) > 1 else 1 - 1 / np.sqrt(2)
    print("q=%.5f" % q)
    for a in [0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.7071, 0.72, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98]:
        b = np.sqrt(1 - a * a)
        r1 = lp_bound_poly(q, a, use4=False)[1]
        r2 = lp_bound_poly(q, a)[1]
        r3 = lp_bound_poly(q, a, coef_bound=a / b)[1]
        print("a=%.4f  +M3: %.5f  +M3,M4: %.5f  +coef<=a/b: %.5f" % (a, r1, r2, r3))
