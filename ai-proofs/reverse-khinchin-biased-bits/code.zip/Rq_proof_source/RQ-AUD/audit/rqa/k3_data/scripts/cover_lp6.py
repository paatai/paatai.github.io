"""Adaptive cover of a (u,a) region by exactly verified six-moment certificates.

TARGET_FN (module global) overrides the target tau(u2)(1-a2) of Theorem 1 (used by cover_k2.py).

Usage: python3 cover_lp6.py <u_lo> <u_hi> <a_lo> <a_hi> <outfile> [nu na]
All cell corners are rationals; certificates are stored as exact rationals (strings).
"""
import json
import sys
import time
from fractions import Fraction as Fr
import numpy as np
from lp6cert import solve_lp, Rcell, cell_data
from exactcert import verify_cell, sqrt_up, lines, fr


def rationalize(c, den=10 ** 12):
    return [Fr(x).limit_denominator(den) for x in c]


YS = np.concatenate([-np.logspace(np.log10(40), 4, 3000)[::-1], np.linspace(-40, 40, 400001),
                     np.logspace(np.log10(40), 4, 3000)])


def gap_profile(cr, u1, u2, a1, b1bar):
    l1, l2 = lines(u1, u2, a1, b1bar)
    cf = np.array([float(x) for x in cr])
    P = np.polyval(cf[::-1], YS)
    R = np.maximum(0, np.maximum(float(l1[1]) * YS + float(l1[0]), float(l2[1]) * YS + float(l2[0])))
    return P - R


def float_min_gap(cr, u1, u2, a1, b1bar, ycut=4.0):
    g = gap_profile(cr, u1, u2, a1, b1bar)
    near = np.abs(YS) <= ycut
    gn = g[near]
    i = np.argmin(gn)
    yn = YS[near]
    lo, hi = yn[max(i - 2, 0)], yn[min(i + 2, len(yn) - 1)]
    l1, l2 = lines(u1, u2, a1, b1bar)
    cf = np.array([float(x) for x in cr])
    yy = np.linspace(lo, hi, 20001)
    gg = np.polyval(cf[::-1], yy) - np.maximum(0, np.maximum(float(l1[1]) * yy + float(l1[0]),
                                                              float(l2[1]) * yy + float(l2[0])))
    far = ~near
    # required c6 increment to fix far deficits
    d6 = 0.0
    if (g[far] < 0).any():
        d6 = float(np.max(-g[far][g[far] < 0] / YS[far][g[far] < 0] ** 6))
    return min(gn.min(), gg.min()), d6


def mbar_for(a2):
    a2 = fr(a2)
    if a2 * a2 >= Fr(1, 2):
        return Fr(1)
    # mbar >= a2/sqrt(1-a2^2): take a2 / sqrt_lo(1-a2^2)
    from exactcert import sqrt_lo
    m = a2 / sqrt_lo(1 - a2 * a2)
    return min(m, Fr(1)) if m < 1 else Fr(1)


TARGET_FN = None


def try_cell(u1, u2, a1, a2):
    b1bar = sqrt_up(1 - fr(a1) ** 2)
    mbar = mbar_for(a2)
    try:
        c, val, _ = solve_lp(float(u1), float(u2), float(a1), float(a2), uref=float(u2))
    except Exception as e:
        return None, "lp:" + str(e)[:40]
    # force c6 > 0 slightly if needed
    if c[6] <= 1e-9:
        c[6] = 1e-9
    cr = rationalize(c)
    why = "?"
    for attempt in range(8):
        gap, d6 = float_min_gap(cr, u1, u2, a1, b1bar)
        cc = list(cr)
        if d6 > 0:
            cc[6] += Fr(d6 * 2 * (2 ** attempt)).limit_denominator(10 ** 15)
            gap, _ = float_min_gap(cc, u1, u2, a1, b1bar)
        shift = Fr(max(0.0, -gap) * 1.5 + 1e-10 * (10 ** attempt)).limit_denominator(10 ** 15)
        cc[0] += shift
        ok, why = verify_cell(cc, u1, u2, a1, a2, b1bar, mbar, target_fn=TARGET_FN)
        if ok:
            return cc, "ok"
        if why == "V4":
            return None, "V4"
        if why != "V4" and attempt >= 2:
            cr = list(cc)
    return None, why


def cover(u_lo, u_hi, a_lo, a_hi, nu=4, na=8, maxdepth=16, log=print):
    cells = []
    us = [u_lo + (u_hi - u_lo) * Fr(i, nu) for i in range(nu + 1)]
    as_ = [a_lo + (a_hi - a_lo) * Fr(j, na) for j in range(na + 1)]
    stack = [(us[i], us[i + 1], as_[j], as_[j + 1], 0) for i in range(nu) for j in range(na)]
    done = []
    failed = []
    t0 = time.time()
    while stack:
        u1, u2, a1, a2, d = stack.pop()
        cert, why = try_cell(u1, u2, a1, a2)
        if cert is not None:
            done.append({"u1": str(u1), "u2": str(u2), "a1": str(a1), "a2": str(a2),
                         "c": [str(x) for x in cert]})
            continue
        if d >= maxdepth:
            failed.append((float(u1), float(u2), float(a1), float(a2), why))
            log("FAILED cell u[%.5f,%.5f] a[%.5f,%.5f] (%s)" % (float(u1), float(u2), float(a1), float(a2), why))
            continue
        # bisect the longer side (cells stay roughly square in (u, a))
        if u2 - u1 > a2 - a1:
            um = (u1 + u2) / 2
            for (x1, x2) in [(u1, um), (um, u2)]:
                stack.append((x1, x2, a1, a2, d + 1))
        else:
            am = (a1 + a2) / 2
            for (y1, y2) in [(a1, am), (am, a2)]:
                stack.append((u1, u2, y1, y2, d + 1))
        if len(done) % 50 == 0:
            log("  progress: %d done, %d stack, %d failed, %.0fs" % (len(done), len(stack), len(failed), time.time() - t0))
    return done, failed


if __name__ == "__main__":
    u_lo, u_hi, a_lo, a_hi = (Fr(s) for s in sys.argv[1:5])
    out = sys.argv[5]
    nu = int(sys.argv[6]) if len(sys.argv) > 6 else 4
    na = int(sys.argv[7]) if len(sys.argv) > 7 else 8
    done, failed = cover(u_lo, u_hi, a_lo, a_hi, nu, na)
    json.dump({"region": [str(u_lo), str(u_hi), str(a_lo), str(a_hi)], "cells": done,
               "failed": failed}, open(out, "w"))
    print("cells verified: %d, failed: %d" % (len(done), len(failed)))
