#!/bin/bash
# usage: run_cover.sh name u_lo u_hi a_lo a_hi [nu na]
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
cd "$(dirname "$0")"
python3 -u cover_lp6.py "$2" "$3" "$4" "$5" ../outputs/cover/$1.json ${6:-4} ${7:-8} > ../outputs/cover/$1.log 2>&1
echo "EXIT $?" >> ../outputs/cover/$1.log
