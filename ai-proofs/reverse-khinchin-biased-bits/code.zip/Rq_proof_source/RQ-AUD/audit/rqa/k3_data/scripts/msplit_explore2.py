"""Where does the uncapped two-coordinate LP fail near u3, and does the m-split cover it? (evidence)

usage: msplit_explore2.py u step mcut1 [mcut2 ...]
For each (a1,a2) on a grid (s = +1) prints the uncapped LP margin; where it is below 2e-3 it
reports, for each mcut, the capped LP margin and the worst near-sphere ratio over m in [mcut, mbar].
"""
import sys
import numpy as np
import lp2c
from msplit_explore import nsphere_ratio

if __name__ == "__main__":
    u = float(sys.argv[1])
    step = float(sys.argv[2])
    mcuts = [float(x) for x in sys.argv[3:]]
    q = 1 / (1 + u * u)
    T = lp2c.target(q)
    grid = np.arange(0.45, 0.72, step)
    for a1 in grid:
        for a2 in grid:
            if a2 > a1 + 1e-12 or a1 * a1 + a2 * a2 >= 0.999:
                continue
            b = np.sqrt(1 - a1 * a1 - a2 * a2)
            mb = min(1.0, a2 / b)
            full = T - lp2c.solve(q, a1, a2, 1)
            if full > 2e-3:
                continue
            out = []
            for mc in mcuts:
                if mb <= mc:
                    out.append("mc=%.2f: LPcap n/a" % mc)
                    continue
                cap = T - lp2c.solve(q, a1, a2, 1, mcap=mc)
                rat = max(nsphere_ratio(u, a1, a2, b, m) for m in np.linspace(mc, mb, 8))
                out.append("mc=%.2f: cap %+.2e ns %.3f" % (mc, cap, rat))
            print("a1=%.3f a2=%.3f b=%.3f mbar=%.3f full %+.2e | %s" % (a1, a2, b, mb, full, " | ".join(out)),
                  flush=True)
