#!/bin/bash
# usage: run_k3.sh two tag u1 u2 s     (two-coordinate cover of one u-slab, k = 3 target, m-split on)
#        run_k3.sh one tag u1 u2       (one-coordinate cells on [u1,u2] x [0, 2/5], k = 3 target)
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 RQ_K=3 RQ_AS=2/5
cd "$(dirname "$0")"
OUT=../outputs/k3
if [ "$1" = two ]; then
  python3 cover2c.py "$3" "$4" "$5" $OUT/cover2c/$2.json 1 8 12 18 ms > $OUT/cover2c/$2.log 2>&1
else
  python3 cover_k3.py "$3" "$4" 0 2/5 $OUT/one/$2.json 6 8 > $OUT/one/$2.log 2>&1
fi
