"""Two-coordinate split: exact cell envelopes, LP candidates and exact verification.

Coordinates of a cell: u in [u1,u2] (q = 1/(1+u^2)), t in [t1,t2] with 0 <= t1 < t2 <= 1,
r in [r1,r2] with 0 <= r1 < r2 <= 1, and a sign s in {+1,-1}.  The point (u,t,r,s) stands for
    a1 = r c(t),  a2 = r d(t),  c = (1-t^2)/(1+t^2),  d = 2t/(1+t^2),  b = sqrt(1-r^2),
    L = a1 chi_1 + s a2 chi_2 + b M,  M = sum beta_i chi_i,  |beta| = 1,  |beta_i| <= min(1, a2/b).
E|L| = E F(M), F(y) = sum_j p_j |x_j + b y| over the four atoms x_j of a1 chi_1 + s a2 chi_2.
With qu = (1-q)v = tau:  p_j x_j = r tau g_j  where
    g_(u,u) = q (c + s d),  g_(u,-v) = (1-q) c - s q d,  g_(-v,u) = -q c + s (1-q) d,
    g_(-v,-v) = -(1-q)(c + s d),
and p_j = q^2, q(1-q), q(1-q), (1-q)^2.

Envelope: with A+_j = max(p_j x_j), A-_j = max(-p_j x_j), beta+-_j = max/min(p_j b) over the cell,
    F_cell(y) = sum_j max(A+_j + beta+_j y, A-_j - beta-_j y)   (y >= 0)
    F_cell(y) = sum_j max(A+_j + beta-_j y, A-_j - beta+_j y)   (y <= 0)
dominates F for every point of the cell and is convex; its pieces are lines.
"""
import os
from fractions import Fraction as Fr
import numpy as np
from scipy.optimize import linprog
from exactcert import poly_positive, objective_ok, sqrt_lo, sqrt_up, fr

# target: k = 2 (default): 2 sqrt2 (1-q) tau;  k = 3 (RQ_K=3): 2 sqrt3 (1-q)^2 tau
K_TARGET = int(os.environ.get("RQ_K", "2"))
assert K_TARGET in (2, 3)
S2LO = sqrt_lo(Fr(2))
SKLO = sqrt_lo(Fr(K_TARGET))


class I:
    __slots__ = ("lo", "hi")

    def __init__(self, lo, hi=None):
        self.lo = fr(lo)
        self.hi = fr(lo if hi is None else hi)
        assert self.lo <= self.hi

    def __add__(self, o):
        o = o if isinstance(o, I) else I(o)
        return I(self.lo + o.lo, self.hi + o.hi)

    __radd__ = __add__

    def __neg__(self):
        return I(-self.hi, -self.lo)

    def __sub__(self, o):
        return self + (-(o if isinstance(o, I) else I(o)))

    def __rsub__(self, o):
        return I(o) - self

    def __mul__(self, o):
        o = o if isinstance(o, I) else I(o)
        ps = (self.lo * o.lo, self.lo * o.hi, self.hi * o.lo, self.hi * o.hi)
        return I(min(ps), max(ps))

    __rmul__ = __mul__

    def __repr__(self):
        return "[%.6g, %.6g]" % (float(self.lo), float(self.hi))


def tau_of(u):
    return u / (1 + u * u)


def T_of(u):
    """target value / sqrt(k):  k=2: 2 u^3/(1+u^2)^2 (times sqrt2 gives 2 sqrt2 (1-q) tau);
    k=3: 2 u^5/(1+u^2)^3 (times sqrt3 gives 2 sqrt3 (1-q)^2 tau)."""
    if K_TARGET == 2:
        return 2 * u ** 3 / (1 + u * u) ** 2
    return 2 * u ** 5 / (1 + u * u) ** 3


def T_lo(u1, u2):
    """rational lower bound of the target on [u1,u2]; u^3/(1+u^2)^2 (max at sqrt3) and
    u^5/(1+u^2)^3 (max at sqrt5) are unimodal, so the minimum is at an endpoint."""
    return SKLO * min(T_of(fr(u1)), T_of(fr(u2)))


def cell_params(u1, u2, t1, t2, r1, r2):
    u1, u2, t1, t2, r1, r2 = map(fr, (u1, u2, t1, t2, r1, r2))
    assert 1 <= u1 < u2 and 0 <= t1 < t2 <= 1 and 0 <= r1 < r2 <= 1
    q = I(1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    qb = I(u1 * u1 / (1 + u1 * u1), u2 * u2 / (1 + u2 * u2))
    tau = I(tau_of(u2), tau_of(u1))
    c = I((1 - t2 * t2) / (1 + t2 * t2), (1 - t1 * t1) / (1 + t1 * t1))
    d = I(2 * t1 / (1 + t1 * t1), 2 * t2 / (1 + t2 * t2))
    r = I(r1, r2)
    blo = sqrt_lo(1 - r2 * r2) if r2 < 1 else Fr(0)
    bhi = sqrt_up(1 - r1 * r1)
    b = I(blo, bhi)
    a2hi = r2 * d.hi
    if blo == 0 or a2hi >= blo:
        mbar = Fr(1)
    else:
        mbar = min(Fr(1), a2hi / blo)
        # rounding of mbar upward to a short rational
        mb = Fr(int(mbar * 10 ** 12) + 1, 10 ** 12)
        mbar = min(Fr(1), mb)
    return dict(q=q, qb=qb, tau=tau, c=c, d=d, r=r, b=b, mbar=mbar, u1=u1, u2=u2)


def atoms_g(P, s):
    q, qb, c, d = P["q"], P["qb"], P["c"], P["d"]
    if s == 1:
        cs = c + d
        g = [q * cs, qb * c - q * d, -(q * c) + qb * d, -(qb * cs)]
    else:
        cs = c - d
        g = [q * cs, qb * c + q * d, -(q * c) - qb * d, -(qb * cs)]
    p = [q * q, q * qb, q * qb, qb * qb]
    return g, p


def envelope(P, s):
    """Return (Aplus, Aminus, bminus, bplus) per atom, exact rationals."""
    g, p = atoms_g(P, s)
    rt = P["r"] * P["tau"]
    out = []
    for gj, pj in zip(g, p):
        px = rt * gj
        pb = pj * P["b"]
        out.append((px.hi, -px.lo, pb.lo, pb.hi))
    return out


def env_pieces(env):
    """Lines (intercept, slope) of the convex function F_cell, exact."""
    pts = sorted(set([Fr(0)] + [(Am - Ap) / (bm + bp) for (Ap, Am, bm, bp) in env if bm + bp > 0]))
    # sample one point inside each piece and the slope/intercept there
    probes = [pts[0] - 1] + [(pts[i] + pts[i + 1]) / 2 for i in range(len(pts) - 1)] + [pts[-1] + 1]
    lines = []
    for y in probes:
        icpt, slope = Fr(0), Fr(0)
        for (Ap, Am, bm, bp) in env:
            if y >= 0:
                l1 = (Ap, bp); l2 = (Am, -bm)
            else:
                l1 = (Ap, bm); l2 = (Am, -bp)
            v1 = l1[0] + l1[1] * y
            v2 = l2[0] + l2[1] * y
            ln = l1 if v1 >= v2 else l2
            icpt += ln[0]; slope += ln[1]
        if (icpt, slope) not in lines:
            lines.append((icpt, slope))
    return lines


def Fcell_float(y, env):
    tot = np.zeros_like(y)
    for (Ap, Am, bm, bp) in env:
        Ap, Am, bm, bp = float(Ap), float(Am), float(bm), float(bp)
        pos = y >= 0
        l1 = np.where(pos, Ap + bp * y, Ap + bm * y)
        l2 = np.where(pos, Am - bm * y, Am - bp * y)
        tot += np.maximum(l1, l2)
    return tot


def kappas(u):
    v = 1.0 / u
    w = u * u + v * v
    return (u - v, w - 4, (u - v) * (w - 10), w * w - 26 * w + 64)


def lp_cert(env, uref, m, K=12.0, N=2401, ntan=41, p3max=None):
    last = None
    for (KK, NN, meth) in ((K, N, "highs"), (K, N - 400, "highs"), (K, N + 600, "highs"),
                           (K, N, "highs-ipm"), (K, N, "highs-ds"), (K + 1, N - 2, "highs")):
        try:
            return _lp(env, uref, m, KK, NN, ntan, meth, p3max)
        except RuntimeError as e:
            last = e
    raise last


def _lp(env, uref, m, K, N, ntan, meth, p3max=None):
    k3, k4, k5, k6 = kappas(uref)
    far = np.concatenate([np.arange(K + 1, 40.0, 1.0), [45, 50, 60, 80, 100, 150, 200.0]])
    y = np.concatenate([-far[::-1], np.linspace(-K, K, N), far])
    R = Fcell_float(y, env)
    nY = len(y)
    nv = nY + 6
    I3, I4, I5, I6, I33, IZ = nY, nY + 1, nY + 2, nY + 3, nY + 4, nY + 5
    Aeq = np.zeros((7, nv)); beq = np.zeros(7)
    for k in range(7):
        Aeq[k, :nY] = y ** k
    Aeq[6, IZ] = 1.0
    beq[0] = 1; beq[1] = 0; beq[2] = 1
    Aeq[3, I3] = -k3
    Aeq[4, I4] = -k4; beq[4] = 3
    Aeq[5, I5] = -k5; Aeq[5, I3] = -10 * k3
    Aeq[6, I4] = -15 * k4; Aeq[6, I33] = -10 * k3 * k3; Aeq[6, I6] = -k6; beq[6] = 15
    Aub = []; bub = []

    def row():
        return np.zeros(nv)
    for cc in np.linspace(-m, m, ntan):
        r = row(); r[I33] = -1; r[I3] = 2 * cc; Aub.append(r); bub.append(cc * cc)
        r = row(); r[I3] = 2 * cc; r[I4] = -1; Aub.append(r); bub.append(cc * cc)
    r = row(); r[I33] = 1; r[I4] = -1; Aub.append(r); bub.append(0)
    r = row(); r[I6] = 1; r[I4] = -m * m; Aub.append(r); bub.append(0)
    for cc in np.linspace(0, m * m, ntan):
        r = row(); r[I4] = 2 * cc; r[I6] = -1; Aub.append(r); bub.append(cc * cc)
    r = row(); r[I5] = 1; r[I4] = -m; Aub.append(r); bub.append(0)
    r = row(); r[I5] = -1; r[I4] = -m; Aub.append(r); bub.append(0)
    p3hi = m if p3max is None else min(m, float(p3max))
    bounds = [(0, None)] * nY + [(-m, p3hi), (0, m * m), (-m ** 3, m ** 3), (0, m ** 4), (0, m * m), (0, None)]
    cobj = np.zeros(nv); cobj[:nY] = -R
    res = linprog(cobj, A_ub=np.array(Aub), b_ub=np.array(bub), A_eq=Aeq, b_eq=beq, bounds=bounds,
                  method=meth)
    if res.status != 0:
        raise RuntimeError(res.message)
    return -np.array(res.eqlin.marginals), -res.fun


YS = np.concatenate([-np.logspace(np.log10(40), 4, 3000)[::-1], np.linspace(-40, 40, 200001),
                     np.logspace(np.log10(40), 4, 3000)])


def float_gap(cr, env, ycut=4.0):
    cf = np.array([float(x) for x in cr])
    g = np.polyval(cf[::-1], YS) - Fcell_float(YS, env)
    near = np.abs(YS) <= ycut
    gn = g[near]
    i = int(np.argmin(gn))
    yn = YS[near]
    lo, hi = yn[max(i - 2, 0)], yn[min(i + 2, len(yn) - 1)]
    yy = np.linspace(lo, hi, 4001)
    gg = np.polyval(cf[::-1], yy) - Fcell_float(yy, env)
    far = ~near
    d6 = 0.0
    if (g[far] < 0).any():
        d6 = float(np.max(-g[far][g[far] < 0] / YS[far][g[far] < 0] ** 6))
    return min(gn.min(), gg.min()), d6


def verify(c, P, s, env=None, p3max=None):
    """Exact verification of a certificate c (7 rationals) for the cell P and sign s."""
    c = [fr(x) for x in c]
    if env is None:
        env = envelope(P, s)
    for (icpt, slope) in env_pieces(env):
        d = list(c); d[0] -= icpt; d[1] -= slope
        if not poly_positive(d):
            return False, "dom"
    tl = T_lo(P["u1"], P["u2"])
    ok = objective_ok(c, P["u1"], P["u2"], Fr(0), P["mbar"], target_fn=lambda u1, u2, a2: tl, p3max=p3max)
    return (True, "ok") if ok else (False, "obj")


def rationalize(c, den=10 ** 12):
    return [Fr(float(x)).limit_denominator(den) for x in c]


def try_cell(u1, u2, t1, t2, r1, r2, s, mcap=None, p3max=None):
    """Certificate for the cell; with mcap only residuals with max|beta_i| <= mcap are covered,
    with p3max only residuals with p3 = sum beta_i^3 <= p3max."""
    P = cell_params(u1, u2, t1, t2, r1, r2)
    if mcap is not None:
        P["mbar"] = min(P["mbar"], fr(mcap))
    env = envelope(P, s)
    m = float(P["mbar"])
    try:
        c, val = lp_cert(env, float(P["u2"]), m, p3max=p3max)
    except Exception as e:
        return None, "lp"
    if float(T_lo(P["u1"], P["u2"])) - val < 0:
        return None, "lpval"
    if c[6] <= 1e-9:
        c[6] = 1e-9
    cr = rationalize(c)
    why = "?"
    for attempt in range(6):
        gap, d6 = float_gap(cr, env)
        cc = list(cr)
        if d6 > 0:
            cc[6] += Fr(d6 * 2 * (2 ** attempt)).limit_denominator(10 ** 15)
            gap, _ = float_gap(cc, env)
        shift = Fr(max(0.0, -gap) * 1.5 + 1e-10 * (10 ** attempt)).limit_denominator(10 ** 15)
        cc[0] += shift
        ok, why = verify(cc, P, s, env, p3max=p3max)
        if ok:
            return cc, "ok"
        if why == "obj":
            return None, "obj"
        if attempt >= 2:
            cr = list(cc)
    return None, why
