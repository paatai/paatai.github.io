"""Moment-LP exploration for the induction step (floating point, evidence only).

L = a chi + b M, E|L| = 2 tau a + 2 E R_a(bM),  R_a(y) = (1-q)(y-av)_+ + q(-y-au)_+.
We maximise E R_a(bM) over laws of M on a grid subject to linear constraints.
"""
import sys
import numpy as np
from scipy.optimize import linprog
from rqlib import params, Epos_gauss


def subgauss_sigma2(q):
    # Kearns-Saul optimal sub-Gaussian variance proxy of chi (q != 1/2)
    _, _, tau = params(q)
    if abs(q - 0.5) < 1e-12:
        return 1.0
    return (1 - 2 * q) / (2 * np.log((1 - q) / q)) / tau ** 2


def lp_bound(q, a, grid=None, extra=(), absM=True, verbose=False):
    u, v, tau = params(q)
    b = np.sqrt(1 - a * a)
    if grid is None:
        grid = np.concatenate([np.linspace(-6, 6, 2401), np.linspace(-20, -6.01, 200), np.linspace(6.01, 20, 200)])
    y = grid
    R = (1 - q) * np.maximum(b * y - a * v, 0) + q * np.maximum(-b * y - a * u, 0)
    A_eq = [np.ones_like(y), y, y ** 2]
    b_eq = [1, 0, 1]
    A_ub, b_ub = [], []
    if absM:
        A_ub.append(np.abs(y))
        b_ub.append(2 * tau)
    for (fn, bound) in extra:
        A_ub.append(fn(y))
        b_ub.append(bound)
    res = linprog(-R, A_ub=np.array(A_ub) if A_ub else None, b_ub=np.array(b_ub) if b_ub else None,
                  A_eq=np.array(A_eq), b_eq=np.array(b_eq), bounds=(0, None), method="highs")
    val = -res.fun
    if verbose:
        p = res.x
        idx = p > 1e-9
        print("   support:", list(zip(np.round(y[idx], 3), np.round(p[idx], 5))))
    return val, 2 * tau * a + 2 * val


def tail_constraints(q, ts, sigma2=None, coef_bound=None):
    """Rigorous-type upper bounds on E(M-t)_+ and E(-M-t)_+ valid for every M in the class:
    min of: (sqrt(1+t^2)-t)/2 (variance 1), tau (E|M|<=2tau), Chernoff with sub-Gaussian proxy."""
    if sigma2 is None:
        sigma2 = subgauss_sigma2(q)
    _, _, tau = params(q)
    cons = []
    for t in ts:
        bnds = [(np.sqrt(1 + t * t) - t) / 2]
        if t >= 0:
            bnds.append(tau)
            # E(X-t)_+ <= inf_l E e^{l(X-t)}/(e l)
            lam = np.linspace(0.05, 20, 4000)
            bnds.append(np.min(np.exp(lam ** 2 * sigma2 / 2 - lam * t) / (np.e * lam)))
        ub = min(bnds)
        cons.append((lambda y, t=t: np.maximum(y - t, 0), ub))
        cons.append((lambda y, t=t: np.maximum(-y - t, 0), ub))
    return cons


if __name__ == "__main__":
    q = float(sys.argv[1]) if len(sys.argv) > 1 else 1 - 1 / np.sqrt(2)
    u, v, tau = params(q)
    print("q=%.5f 2tau=%.5f sigma2_subG=%.4f" % (q, 2 * tau, subgauss_sigma2(q)))
    ts = np.linspace(0.25, 5, 20)
    tc = tail_constraints(q, ts)
    for a in [0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7071, 0.75, 0.8, 0.85, 0.9, 0.95, 0.98]:
        v1, B1 = lp_bound(q, a)
        v2, B2 = lp_bound(q, a, extra=tc)
        print("a=%.4f  LP{1,M,M2,|M|}: E|L|/2tau <= %.5f   +tails: %.5f" % (a, B1 / (2 * tau), B2 / (2 * tau)))
