"""Negative tests: the independent verifier must reject corrupted or false certificates."""
import json, random, glob, os
from fractions import Fraction as Fr
import sympy
import verify_all as V

random.seed(1)
# 1. own Sturm counting vs sympy on random polynomials (incl. repeated roots)
y = sympy.Symbol("y")
for trial in range(300):
    deg = random.choice([2, 4, 6])
    if trial % 3 == 0:
        r = [Fr(random.randint(-5, 5), random.randint(1, 4)) for _ in range(deg // 2)]
        p = sympy.Poly(sympy.prod([(y - sympy.Rational(x.numerator, x.denominator)) ** 2 for x in r]) + random.choice([0, sympy.Rational(1, 10**6), -sympy.Rational(1, 10**6)]), y)
    else:
        p = sympy.Poly([random.randint(-9, 9) for _ in range(deg)] + [random.randint(1, 9)], y)
    coeffs = [Fr(int(c.p), int(c.q)) for c in reversed(p.all_coeffs())]
    assert V.roots_real_line(coeffs) == p.count_roots(), (p, V.roots_real_line(coeffs), p.count_roots())
    lo, hi = Fr(-1, 3), Fr(7, 4)
    assert V.roots_in(coeffs, lo, hi) == p.count_roots(sympy.Rational(-1, 3), sympy.Rational(7, 4)) - (1 if p.eval(sympy.Rational(-1, 3)) == 0 else 0)
print("1. Sturm counting agrees with sympy on 300 random polynomials")

# 2. corrupted six-moment certificates must fail
d = json.load(open(sorted(glob.glob(os.path.join(V.OUT, "cover", "*.json")))[3]))
bad = 0
for cell in d["cells"][:40]:
    for k, delta in [(0, Fr(-1, 10**4)), (0, Fr(1, 10)), (2, Fr(-1, 100)), (6, Fr(-1, 10**3))]:
        cc = dict(cell); c = [Fr(x) for x in cell["c"]]; c[k] += delta * max(abs(c[k]), Fr(1, 100))
        cc["c"] = [str(x) for x in c]
        if V.check_cell(cc) != "ok":
            bad += 1
print("2. corrupted certificates rejected: %d / 160" % bad)
# widen a cell in a: must eventually fail (V4 or V2) when widened a lot
cell = d["cells"][0]
cc = dict(cell); cc["a2"] = str(min(Fr(cell["a2"]) + Fr(1, 5), Fr(99, 100)))
print("   widened cell:", V.check_cell(cc))

# 3. false region: u slightly beyond u0 near a = 1/sqrt2 must be impossible to certify
from cover_lp6 import try_cell
for (u1, u2, a1, a2) in [("15537/10000", "15540/10000", "7070/10000", "7072/10000"),
                         ("1.7", "1.701", "0.7071", "0.7072"), ("1.56", "1.5601", "0.7071", "0.7072")]:
    c, why = try_cell(Fr(u1), Fr(u2), Fr(a1), Fr(a2))
    print("3. cell u[%s,%s] a[%s,%s] beyond q0: %s" % (u1, u2, a1, a2, why))

# 4. quartic boxes with corrupted c4 must fail in the mpmath verifier
import mpmath
from quartic_verify import check_box
dq = json.load(open(os.path.join(V.OUT, "quartic_cover.json")))
rej = 0; tot = 0
for bx in dq["boxes"][::40]:
    u1, u2, t1, t2 = (Fr(bx[k]) for k in ("u1", "u2", "t1", "t2"))
    for f in (Fr(1, 3), Fr(3)):
        tot += 1
        ok, why = check_box(u1, u2, t1, t2, Fr(bx["c4"]) * f)
        rej += (not ok)
print("4. quartic boxes with c4 scaled by 1/3 or 3 rejected: %d / %d" % (rej, tot))
