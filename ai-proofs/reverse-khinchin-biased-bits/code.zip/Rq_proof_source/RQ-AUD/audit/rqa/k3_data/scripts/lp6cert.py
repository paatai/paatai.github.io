"""Six-moment LP: numerical dual certificates for a cell in (u,a) space.

Cell: u in [u1,u2] (q = 1/(1+u^2), so q decreases with u), a in [a1,a2].
Worst-case data on the cell:
  l1(y) = (u2^2/(1+u2^2)) (b1 y - a1/u2)          (right line, sup over the cell)
  l2(y) = (1/(1+u1^2)) (-b1 y - a1 u1)              (left line, sup over the cell)
  R_cell(y) = max(0, l1(y), l2(y))  >=  R_a(b y) for all (u,a) in the cell,
  m = min(1, a2/b2) (coefficient bound of M), target tau(u2)(1-a2).
The LP maximises E R_cell(M) over laws on a grid with the moment identities at a reference u.
Returns the polynomial coefficients c_0..c_6 (floats) from the duals of the moment rows.
"""
import numpy as np
from scipy.optimize import linprog


def kappas(u):
    v = 1.0 / u
    w = u * u + v * v
    return (u - v, w - 4, (u - v) * (w - 10), w * w - 26 * w + 64)


def cell_data(u1, u2, a1, a2):
    b1 = np.sqrt(1 - a1 * a1)
    b2 = np.sqrt(1 - a2 * a2)
    m = 1.0 if a2 >= b2 else a2 / b2
    l1 = (u2 * u2 / (1 + u2 * u2) * b1, -u2 * u2 / (1 + u2 * u2) * a1 / u2)   # slope, intercept
    l2 = (-b1 / (1 + u1 * u1), -a1 * u1 / (1 + u1 * u1))
    tau2 = u2 / (1 + u2 * u2)
    return l1, l2, m, tau2


def Rcell(y, l1, l2):
    return np.maximum(0, np.maximum(l1[0] * y + l1[1], l2[0] * y + l2[1]))


def solve_lp(u1, u2, a1, a2, uref=None, K=10.0, N=3001, ntan=41):
    if uref is None:
        uref = 0.5 * (u1 + u2)
    k3, k4, k5, k6 = kappas(uref)
    l1, l2, m, tau2 = cell_data(u1, u2, a1, a2)
    far = np.concatenate([np.arange(11.0, 40.0, 1.0), [45, 50, 60, 80, 100, 150, 200.0]])
    y = np.concatenate([-far[::-1], np.linspace(-K, K, N), far])
    R = Rcell(y, l1, l2)
    nY = len(y)
    nv = nY + 6
    I3, I4, I5, I6, I33, IZ = nY, nY + 1, nY + 2, nY + 3, nY + 4, nY + 5
    Aeq = np.zeros((7, nv)); beq = np.zeros(7)
    for k in range(7):
        Aeq[k, :nY] = y ** k
    Aeq[6, IZ] = 1.0   # mass at infinity in the 6th moment: dual c6 >= 0
    beq[0] = 1; beq[1] = 0; beq[2] = 1
    Aeq[3, I3] = -k3
    Aeq[4, I4] = -k4; beq[4] = 3
    Aeq[5, I5] = -k5; Aeq[5, I3] = -10 * k3
    Aeq[6, I4] = -15 * k4; Aeq[6, I33] = -10 * k3 * k3; Aeq[6, I6] = -k6; beq[6] = 15
    Aub = []; bub = []

    def row():
        return np.zeros(nv)
    for c in np.linspace(-m, m, ntan):
        r = row(); r[I33] = -1; r[I3] = 2 * c; Aub.append(r); bub.append(c * c)     # P33 >= p3^2
        r = row(); r[I3] = 2 * c; r[I4] = -1; Aub.append(r); bub.append(c * c)      # p4 >= p3^2
    r = row(); r[I33] = 1; r[I4] = -1; Aub.append(r); bub.append(0)                # P33 <= p4
    r = row(); r[I6] = 1; r[I4] = -m * m; Aub.append(r); bub.append(0)             # p6 <= m^2 p4
    for c in np.linspace(0, m * m, ntan):
        r = row(); r[I4] = 2 * c; r[I6] = -1; Aub.append(r); bub.append(c * c)      # p6 >= p4^2
    r = row(); r[I5] = 1; r[I4] = -m; Aub.append(r); bub.append(0)                 # |p5| <= m p4
    r = row(); r[I5] = -1; r[I4] = -m; Aub.append(r); bub.append(0)
    bounds = [(0, None)] * nY + [(-m, m), (0, m * m), (-m ** 3, m ** 3), (0, m ** 4), (0, m * m), (0, None)]
    cobj = np.zeros(nv); cobj[:nY] = -R
    res = linprog(cobj, A_ub=np.array(Aub), b_ub=np.array(bub), A_eq=Aeq, b_eq=beq, bounds=bounds,
                  method="highs")
    if res.status != 0:
        raise RuntimeError(res.message)
    c = -np.array(res.eqlin.marginals)   # P(y) = sum c_k y^k >= R on grid
    return c, -res.fun, (l1, l2, m, tau2)


def sup_Phi_float(c, k3, k4, k5, k6, m, nr=2001):
    A = c[0] + c[2] + 3 * c[4] + 15 * c[6]
    B = k3 * (c[3] + 10 * c[5])
    C = k4 * (c[4] + 15 * c[6])
    D = k5 * c[5]
    E = k6 * c[6]
    F = 10 * k3 * k3 * c[6]
    r = np.linspace(0, m, nr)
    g = abs(B) * r + (C + abs(D) * m + max(F, 0)) * r ** 2 + (E * m * m * r ** 2 if E >= 0 else E * r ** 4)
    return A + g.max()


if __name__ == "__main__":
    import sys
    q0 = 1 - 1 / np.sqrt(2)
    for (q, a) in [(q0 + 0.002, 0.3), (0.35, 0.5), (0.31, 0.7071), (0.4, 0.85), (q0 + 0.001, 0.05)]:
        u = np.sqrt((1 - q) / q)
        c, val, (l1, l2, m, tau2) = solve_lp(u, u, a, a)
        y = np.linspace(-30, 30, 600001)
        P = np.polyval(c[::-1], y)
        gap = (P - Rcell(y, l1, l2)).min()
        k = kappas(u)
        S = sup_Phi_float(c, *k, m)
        print("q=%.4f a=%.4f LPval=%.6f  supPhi=%.6f  minGap=%.2e  ratio=%.5f  c=%s" % (
            q, a, val, S, gap, (2 * tau2 * a + 2 * max(S, val)) / (2 * tau2), np.array2string(c, precision=5)))
