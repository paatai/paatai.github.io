"""Numerical evidence (not proof): exact-enumeration E|L|/(2 tau) <= 1 on [q0, 1/2]."""
import numpy as np
import sympy as sp

rng = np.random.default_rng(7)
q0 = 1 - 1 / np.sqrt(2)


def EabsL(alpha, q):
    u = np.sqrt((1 - q) / q); v = 1 / u
    vals = np.zeros(1); pr = np.ones(1)
    for al in alpha:
        vals = np.concatenate([vals + al * u, vals - al * v]); pr = np.concatenate([pr * q, pr * (1 - q)])
        if len(vals) > 4096:   # merge atoms on a fine grid to keep size manageable
            key = np.round(vals, 12)
            uk, inv = np.unique(key, return_inverse=True)
            pr = np.bincount(inv, weights=pr); vals = uk
    return float(np.sum(pr * np.abs(vals)))


worst = (0, None, None)
qs = [q0, q0 + 1e-6, q0 + 1e-3, 0.30, 0.32, 0.35, 0.375, 0.4, 0.45, 0.5]
count = 0
for q in qs:
    tau = np.sqrt(q * (1 - q))
    cands = []
    for _ in range(400):
        n = rng.integers(2, 13)
        kind = rng.integers(0, 4)
        if kind == 0:
            al = rng.normal(size=n)
        elif kind == 1:
            al = np.abs(rng.normal(size=n))
        elif kind == 2:
            al = np.ones(n) + 0.1 * rng.normal(size=n)
        else:
            al = np.concatenate([[1, 1], 0.2 * rng.normal(size=n - 2)])
        cands.append(al / np.linalg.norm(al))
    for a in np.linspace(0.05, 0.99, 48):
        b = np.sqrt(1 - a * a)
        for k in (1, 2, 3, 5, 8):
            cands.append(np.concatenate([[a], b * np.ones(k) / np.sqrt(k)]))
            cands.append(np.concatenate([[a], -b * np.ones(k) / np.sqrt(k)]))
    for al in cands:
        r = EabsL(al, q) / (2 * tau); count += 1
        if r > worst[0]:
            worst = (r, q, np.round(al, 4))
print("vectors tested: %d; max ratio %.12f at q=%.6f alpha=%s" % (count, worst[0], worst[1], worst[2]))
print("(1,1)/sqrt2 at q0: ratio %.15f" % (EabsL(np.array([1, 1]) / np.sqrt(2), q0) / (2 * np.sqrt(q0 * (1 - q0)))))
print("(1,1)/sqrt2 at q0-1e-3: ratio %.9f (>1: the range cannot be extended)" % (EabsL(np.array([1, 1]) / np.sqrt(2), q0 - 1e-3) / (2 * np.sqrt((q0 - 1e-3) * (1 - q0 + 1e-3)))))
# BF3 Lemma 9.5 derivative identities (closing CLAIMS K.1)
w = sp.symbols("w", positive=True)
m = sp.exp(w ** 2 / 2) * sp.integrate(sp.exp(-sp.Symbol("s") ** 2 / 2), (sp.Symbol("s"), w, sp.oo))
A = m - w / (1 + w ** 2) * 1  # placeholder form check below uses the paper's A, B definitions
