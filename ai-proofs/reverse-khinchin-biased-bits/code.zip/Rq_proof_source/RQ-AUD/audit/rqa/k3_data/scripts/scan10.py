"""Ten-moment feasibility scan (floating point, evidence only).

Primal moment LP: maximise E F(M) over distributions of M on a grid whose moments up to order
10 equal the moment-cumulant expressions in kappa_j p_j (kappa_2 = p_2 = 1), with the power-sum
monomials relaxed to boxes / McCormick envelopes for a fixed rho = sqrt(p4) and cap m.
The value at each rho is an optimistic estimate of what a degree-10 certificate can give.

usage: scan10.py one q1 q2 ...     one-coordinate route, ratio (2 tau a + 2 E R_a(bM)) / T3
"""
import sys
from multiprocessing import Pool

import numpy as np
from scipy.optimize import linprog


def kappas(u):
    v = 1 / u
    w = u * u + v * v
    d = u - v
    k = {2: 1.0, 3: d, 4: w - 4, 5: d * (w - 10), 6: w * w - 26 * w + 64}
    u2 = u * u
    k[7] = d * (u2 ** 4 - 56 * u2 ** 3 + 246 * u2 ** 2 - 56 * u2 + 1) / u ** 4
    k[8] = (u2 ** 6 - 120 * u2 ** 5 + 1191 * u2 ** 4 - 2416 * u2 ** 3 + 1191 * u2 ** 2 - 120 * u2 + 1) / u ** 6
    k[9] = d * (u2 ** 6 - 246 * u2 ** 5 + 4047 * u2 ** 4 - 11572 * u2 ** 3 + 4047 * u2 ** 2 - 246 * u2 + 1) / u ** 6
    k[10] = (u2 ** 8 - 502 * u2 ** 7 + 14608 * u2 ** 6 - 88234 * u2 ** 5 + 156190 * u2 ** 4 - 88234 * u2 ** 3
             + 14608 * u2 ** 2 - 502 * u2 + 1) / u ** 8
    return k


# E M^n = sum over set partitions of [n] into blocks of size >= 2 of prod K_|block|, K_j = kappa_j p_j.
# Each entry: (multiplicity, tuple of block sizes other than 2) ; blocks of size 2 contribute K_2 = 1.
MOM = {
    0: [(1, ())], 1: [], 2: [(1, ())], 3: [(1, (3,))], 4: [(1, (4,)), (3, ())],
    5: [(1, (5,)), (10, (3,))],
    6: [(1, (6,)), (15, (4,)), (10, (3, 3)), (15, ())],
    7: [(1, (7,)), (21, (5,)), (35, (3, 4)), (105, (3,))],
    8: [(1, (8,)), (28, (6,)), (56, (3, 5)), (35, (4, 4)), (210, (4,)), (280, (3, 3)), (105, ())],
    9: [(1, (9,)), (36, (7,)), (84, (3, 6)), (126, (4, 5)), (378, (5,)), (1260, (3, 4)), (280, (3, 3, 3)),
        (1260, (3,))],
    10: [(1, (10,)), (45, (8,)), (120, (3, 7)), (210, (4, 6)), (126, (5, 5)), (630, (6,)), (2520, (3, 5)),
         (1575, (4, 4)), (2100, (3, 3, 4)), (3150, (4,)), (6300, (3, 3)), (945, ())],
}


def check_mom():
    """Gaussian check: all K_j = 0 for j >= 3 gives (n-1)!!"""
    for n, terms in MOM.items():
        g = sum(c for c, bl in terms if bl == ())
        dfact = 0 if n % 2 else int(np.prod(np.arange(n - 1, 0, -2))) if n else 1
        assert g == dfact, (n, g, dfact)


def lp_value(F, u, m, rho, order=10, K=9.0, N=2401):
    """max E F(M) for the relaxation at (rho, m)."""
    k = kappas(u)
    y = np.linspace(-K, K, N)
    p4 = rho * rho
    # monomial variables (p4 fixed): index map
    names = ["p3", "p5", "p6", "p7", "p8", "p9", "p10", "P33", "P35", "P36", "P37", "P55", "P333"]
    idx = {nm: N + i for i, nm in enumerate(names)}
    nv = N + len(names)
    lo = {"p3": -rho, "p5": -m * p4, "p6": p4 * p4, "p7": -m ** 3 * p4, "p8": p4 ** 3, "p9": -m ** 5 * p4,
          "p10": p4 ** 4}
    hi = {"p3": rho, "p5": m * p4, "p6": m * m * p4, "p7": m ** 3 * p4, "p8": m ** 4 * p4, "p9": m ** 5 * p4,
          "p10": m ** 6 * p4}
    bounds = [(0, None)] * N
    for nm in names:
        if nm in lo:
            bounds.append((lo[nm], hi[nm]))
        else:
            bounds.append((None, None))
    Aeq, beq, Aub, bub = [], [], [], []

    def row():
        return np.zeros(nv)

    def mono(bl):
        """linear expression (dict var->coef, const) for prod_{j in bl} p_j with p4 fixed"""
        bl = tuple(sorted(bl))
        c = 1.0
        rest = []
        for j in bl:
            if j == 4:
                c *= p4
            else:
                rest.append(j)
        rest = tuple(rest)
        key = {(): None, (3,): "p3", (5,): "p5", (6,): "p6", (7,): "p7", (8,): "p8", (9,): "p9", (10,): "p10",
               (3, 3): "P33", (3, 5): "P35", (3, 6): "P36", (3, 7): "P37", (5, 5): "P55", (3, 3, 3): "P333"}[rest]
        return key, c

    for n in range(order + 1):
        r = row()
        sc = K ** n
        r[:N] = y ** n / sc
        const = 0.0
        for mult, bl in MOM[n]:
            kprod = mult * np.prod([k[j] for j in bl]) if bl else mult
            key, c = mono(bl)
            if key is None:
                const += kprod * c
            else:
                r[idx[key]] -= kprod * c / sc
        Aeq.append(r)
        beq.append(const / sc)
    # P33 >= p3^2 (tangents), P33 <= p4
    for c in np.linspace(-rho, rho, 21):
        r = row(); r[idx["P33"]] = -1; r[idx["p3"]] = 2 * c; Aub.append(r); bub.append(c * c)
    r = row(); r[idx["P33"]] = 1; Aub.append(r); bub.append(p4)
    # P55 >= p5^2 (tangents), P55 <= p4 p6
    for c in np.linspace(-m * p4, m * p4, 11):
        r = row(); r[idx["P55"]] = -1; r[idx["p5"]] = 2 * c; Aub.append(r); bub.append(c * c)
    r = row(); r[idx["P55"]] = 1; r[idx["p6"]] = -p4; Aub.append(r); bub.append(0)

    def mccormick(P, x, X, xl, xh, Xl, Xh):
        # P = x X: P >= xl X + Xl x - xl Xl, P >= xh X + Xh x - xh Xh, P <= xh X + Xl x - xh Xl, P <= xl X + Xh x - xl Xh
        for (a, bb, cst, sgn) in [(xl, Xl, xl * Xl, 1), (xh, Xh, xh * Xh, 1), (xh, Xl, xh * Xl, -1),
                                  (xl, Xh, xl * Xh, -1)]:
            r = row()
            if sgn == 1:   # -P + a X + bb x <= cst
                r[idx[P]] = -1; r[idx[X]] += a; r[idx[x]] += bb; Aub.append(r); bub.append(cst)
            else:          # P - a X - bb x <= -cst
                r[idx[P]] = 1; r[idx[X]] -= a; r[idx[x]] -= bb; Aub.append(r); bub.append(-cst)

    mccormick("P35", "p3", "p5", -rho, rho, lo["p5"], hi["p5"])
    mccormick("P36", "p3", "p6", -rho, rho, lo["p6"], hi["p6"])
    mccormick("P37", "p3", "p7", -rho, rho, lo["p7"], hi["p7"])
    mccormick("P333", "p3", "P33", -rho, rho, 0.0, p4)
    cobj = np.zeros(nv)
    cobj[:N] = -F(y)
    res = linprog(cobj, A_ub=np.array(Aub), b_ub=np.array(bub), A_eq=np.array(Aeq), b_eq=np.array(beq),
                  bounds=bounds, method="highs")
    if res.status != 0:
        return None
    return -res.fun


def T3(q):
    return 2 * np.sqrt(3) * (1 - q) ** 2 * np.sqrt(q * (1 - q))


def one_point(args):
    q, a, order = args
    u = np.sqrt((1 - q) / q)
    v = 1 / u
    tau = np.sqrt(q * (1 - q))
    b = np.sqrt(1 - a * a)
    m = min(1.0, a / b)

    def F(y):
        return (1 - q) * np.maximum(b * y - a * v, 0) + q * np.maximum(-b * y - a * u, 0)

    best = -1
    for rho in np.linspace(0, m, 9):
        val = lp_value(F, u, m, rho, order=order)
        if val is not None:
            best = max(best, (2 * tau * a + 2 * val) / T3(q))
    return best


def F_two(q, a1, a2, s):
    u = np.sqrt((1 - q) / q)
    v = 1 / u
    b = np.sqrt(max(0.0, 1 - a1 * a1 - a2 * a2))
    xs, ps = [], []
    for x1, p1 in ((u, q), (-v, 1 - q)):
        for x2, p2 in ((u, q), (-v, 1 - q)):
            xs.append(a1 * x1 + s * a2 * x2)
            ps.append(p1 * p2)

    def F(y):
        return sum(p * np.abs(x + b * y) for x, p in zip(xs, ps))
    return F, b


def two_point(args):
    q, a1, a2, s, mcap, order = args
    u = np.sqrt((1 - q) / q)
    F, b = F_two(q, a1, a2, s)
    if b < 1e-9:
        return F(np.zeros(1))[0] / T3(q)
    m = min(1.0, a2 / b, mcap)
    best = -1
    for rho in np.linspace(0, m, 9):
        val = lp_value(F, u, m, rho, order=order)
        if val is not None:
            best = max(best, val / T3(q))
    return best


if __name__ == "__main__":
    check_mom()
    if sys.argv[1] == "two":
        # two-coordinate route on a grid of (a1, a2), s = +1, with caps on max|beta|
        q = float(sys.argv[2])
        order = int(sys.argv[3]) if len(sys.argv) > 3 else 10
        grid = [(a1, a2) for a1 in np.arange(0.40, 0.76, 0.05) for a2 in np.arange(0.30, 0.76, 0.05)
                if a2 <= a1 + 1e-9 and a1 * a1 + a2 * a2 < 1]
        for mcap in (1.0, 0.85, 0.75):
            with Pool(int(__import__("os").environ.get("NPROC", "8"))) as pool:
                rs = pool.map(two_point, [(q, a1, a2, 1, mcap, order) for a1, a2 in grid])
            worst = sorted(zip(rs, grid), reverse=True)[:6]
            print("order %d q=%.4f mcap=%.2f worst ratios: %s" % (order, q, mcap, " ".join(
                "%.4f@(%.2f,%.2f)" % (r, g[0], g[1]) for r, g in worst)), flush=True)
        sys.exit(0)
    mode = sys.argv[1]
    if mode == "gauss":
        # sanity: E|M| bound for Gaussian moments (rho = 0) at orders 6, 8, 10
        for order in (6, 8, 10):
            print(order, lp_value(np.abs, 2.0, 1e-9, 0.0, order=order))
    elif mode == "one":
        qs = [float(x) for x in sys.argv[2:]]
        As = [0.01, 0.03, 0.05, 0.08, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5]
        for order in (6, 10):
            with Pool(int(__import__("os").environ.get("NPROC", "8"))) as pool:
                for q in qs:
                    rs = pool.map(one_point, [(q, a, order) for a in As])
                    print("order %d q=%.4f T3=%.5f max ratio %.5f ; " % (order, q, T3(q), max(rs))
                          + " ".join("%.2f:%.4f" % (a, r) for a, r in zip(As, rs)), flush=True)
