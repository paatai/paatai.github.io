"""Six-moment cover for the k = 2 regime: target E R_a(bM) < tau (sqrt2 (1-q) - a).

On a cell [u1,u2] x [a1,a2] (u >= 1) the target is bounded below by
tau(u2) (S2 u1^2/(1+u1^2) - a2), S2 = rational lower bound of sqrt2 (tau decreasing,
1-q = u^2/(1+u^2) increasing in u).
Usage: python3 cover_k2.py <u_lo> <u_hi> <a_lo> <a_hi> <outfile> [nu na]
"""
import json
import sys
from fractions import Fraction as Fr
import cover_lp6
from exactcert import sqrt_lo

S2 = sqrt_lo(Fr(2))


def target_k2(u1, u2, a2):
    return u2 / (1 + u2 * u2) * (S2 * u1 * u1 / (1 + u1 * u1) - a2)


cover_lp6.TARGET_FN = target_k2

if __name__ == "__main__":
    u_lo, u_hi, a_lo, a_hi = (Fr(s) for s in sys.argv[1:5])
    nu = int(sys.argv[6]) if len(sys.argv) > 6 else 4
    na = int(sys.argv[7]) if len(sys.argv) > 7 else 8
    done, failed = cover_lp6.cover(u_lo, u_hi, a_lo, a_hi, nu, na)
    json.dump({"region": [str(u_lo), str(u_hi), str(a_lo), str(a_hi)], "target": "k2", "S2": str(S2),
               "cells": done, "failed": failed}, open(sys.argv[5], "w"))
    print("cells verified: %d, failed: %d" % (len(done), len(failed)))
