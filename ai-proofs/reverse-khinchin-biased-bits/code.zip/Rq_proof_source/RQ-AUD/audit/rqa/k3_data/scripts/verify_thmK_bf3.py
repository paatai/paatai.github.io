"""Independent exact re-check of the arithmetic in BF3 Theorem K (Sec. 9.4), q in [3/8, 1/2].

Written from the statement of the proof only (not from BF3's scripts). Exact rational arithmetic.
Checks: (11) Case A thresholds on 64 intervals; Case B hypotheses; Case C via the box bound on
P(q,s) with bisection; hand-case tables for q = 3/8, 2/5, 5/12.
"""
from fractions import Fraction as Fr
from math import isqrt

SQ2PI_UP = Fr(79789, 10 ** 5)   # sqrt(2/pi) < 0.79789 since pi > 3.14159 (checked below)


def sqrt_lo(x, prec=10 ** 12):
    """rational lower bound for sqrt(x), x >= 0 rational"""
    n = isqrt((x.numerator * prec * prec) // x.denominator)
    return Fr(n, prec)


def sqrt_hi(x, prec=10 ** 12):
    lo = sqrt_lo(x, prec)
    hi = lo + Fr(1, prec)
    assert hi * hi >= x
    return hi


def check_sqrt2pi():
    # sqrt(2/pi) < 0.79789  <=>  2/pi < 0.79789^2  <=> pi > 2/0.79789^2
    need = Fr(2) / (SQ2PI_UP ** 2)
    assert need < Fr(314159, 10 ** 5), float(need)
    return float(need)


def P(q, s):
    return 32 * (1 - q) ** 2 * (1 - 2 * q) * s ** 3 + 8 * q * (1 - q) * (1 - 8 * (1 - q) ** 2) * s ** 2 \
        + 8 * q * (1 - q) * (1 - 2 * q) * s + q ** 2


def box_bound(q1, q2, s1, s2):
    return 32 * (1 - q1) ** 2 * (1 - 2 * q1) * s2 ** 3 - 8 * q1 * (1 - q1) * (8 * (1 - q2) ** 2 - 1) * s1 ** 2 \
        + 8 * q2 * (1 - q2) * (1 - 2 * q1) * s2 + q2 ** 2


def prove_box(q1, q2, s1, s2, depth=0, maxdepth=14, stats=None):
    if box_bound(q1, q2, s1, s2) < 0:
        stats["boxes"] += 1
        stats["maxdepth"] = max(stats["maxdepth"], depth)
        return True
    if depth >= maxdepth:
        return False
    qm = (q1 + q2) / 2
    sm = (s1 + s2) / 2
    return all(prove_box(a, b, c, d, depth + 1, maxdepth, stats)
               for (a, b) in [(q1, qm), (qm, q2)] for (c, d) in [(s1, sm), (sm, s2)])


def s_of_a_lo(a):
    # s = a/sqrt(1-a^2) >= a / sqrt_hi(1-a^2)
    return a / sqrt_hi(1 - a * a)


def s_of_a_hi(a):
    return a / sqrt_lo(1 - a * a)


def main():
    print("pi lower bound needed for sqrt(2/pi)<0.79789:", check_sqrt2pi())
    total_boxes = 0
    maxd = 0
    emptyC = 0
    for j in range(64):
        q0 = Fr(3, 8) + Fr(j, 512)
        q1 = Fr(3, 8) + Fr(j + 1, 512)
        tau0 = sqrt_lo(q0 * (1 - q0))       # tau increasing on [0,1/2]
        C0 = (1 - 2 * tau0 ** 2) / (2 * tau0)  # C_q = 1/(2tau) - tau decreasing in tau
        # largest multiple of 1e-4 with SQ2PI_UP + aA*C0 <= 2 tau0
        aA = Fr(int(((2 * tau0 - SQ2PI_UP) / C0) * 10 ** 4), 10 ** 4)
        assert SQ2PI_UP + aA * C0 <= 2 * tau0
        # Case B on [q0,q1]: a >= aB(q) where aB(q)=(1-q)/(5q-1) decreasing; need q>=1/3 and aB<=1
        aB0 = (1 - q0) / (5 * q0 - 1)
        assert q0 >= Fr(1, 3) and aB0 <= 1
        if aA >= aB0:
            emptyC += 1
            continue
        stats = {"boxes": 0, "maxdepth": 0}
        slo = s_of_a_lo(aA)
        shi = s_of_a_hi(aB0)
        ok = prove_box(q0, q1, slo, shi, stats=stats)
        assert ok, (j, float(aA), float(aB0))
        total_boxes += stats["boxes"]
        maxd = max(maxd, stats["maxdepth"])
        if j in (0, 47, 63):
            print("j=%d aA=%s aB(q0)=%s [s_lo,s_hi]=[%.4f,%.4f] boxes=%d" % (j, aA, aB0, slo, shi, stats["boxes"]))
    print("Case C empty on %d intervals; total boxes %d; max depth %d" % (emptyC, total_boxes, maxd))
    # hand cases
    for q, aA, aB, poly, slo, shi in [
        (Fr(3, 8), Fr(3, 10), Fr(5, 7), (200, -255, 30, 9), Fr(31, 100), Fr(21, 20)),
        (Fr(2, 5), Fr(1, 3), Fr(3, 5), (360, -564, 60, 25), Fr(7, 20), Fr(1)),
        (Fr(5, 12), Fr(7, 20), Fr(7, 13), (2352, -4340, 420, 225), Fr(9, 25), Fr(1)),
    ]:
        th = 1 - 2 * q
        kap = (1 - q) / (4 * q)
        kapp = q / (4 * (1 - q))
        assert kap / (1 - kap) == aB
        cub = [2 * th, th * th + 2 * kapp - 1, 2 * th * kapp, kapp * kapp]
        ratio = Fr(poly[0]) / cub[0]
        assert all(Fr(poly[i]) == ratio * cub[i] for i in range(4)), q
        f = lambda s: sum(Fr(poly[i]) * s ** (3 - i) for i in range(4))
        vals = [f(Fr(-1)), f(Fr(0)), f(slo), f(shi), f(Fr(2))]
        assert vals[0] < 0 < vals[1] and vals[2] < 0 and vals[3] < 0 and vals[4] > 0
        assert s_of_a_lo(aA) > slo and s_of_a_hi(aB) < shi
        tau2 = q * (1 - q)
        C = (1 - 2 * tau2)  # C_q * 2tau
        # (11): sqrt(2/pi) + aA*C/(2tau) <= 2tau  <=>  aA*C <= 2tau*(2tau - sqrt(2/pi)); check with bounds
        tau_lo = sqrt_lo(tau2)
        assert SQ2PI_UP + aA * C / (2 * tau_lo) <= 2 * tau_lo
        print("hand case q=%s OK: values %s" % (q, [str(x) for x in vals]))
    print("ALL BF3 Theorem K arithmetic checks passed")


if __name__ == "__main__":
    main()
