# MAIN RESULT 5 (RQ-A): $R(q)=4(1-q)^3\sqrt{q(1-q)}$ for every $q\in[1-\frac2{\sqrt5},\,1-\frac{\sqrt3}2]$, the whole $k=4$ regime

**Status:** PROVED (computer-assisted; every computer step is exact rational arithmetic or certified
interval arithmetic, and was re-done by an independent program). **Awaiting RQ-AUD audit.**
Do not report outside the team before the audit and an independent referee rate it VALID.

PDF version (same content, LaTeX): `MAIN_RESULT_K4.pdf` (source `MAIN_RESULT_K4.tex`).
This file was generated from the LaTeX source with pandoc, so the two contain the same proof.

**One-command check:** `cd scripts && python3 verify_k4.py` (about six minutes on 8 cores). It prints
`ALL REQUESTED PARTS PASS (A B C D E F G)`. The output is in `outputs/verify_k4_ABCDEFG.txt`.
Negative tests: `python3 break_tests_k4.py` (output `outputs/break_tests_k4.txt`). Data: the 80 files listed
in `outputs/k4_manifest.json` (md5 sums in `outputs/k4_MD5SUMS.txt`).

This determines $R$ exactly on the whole regime where four equal coefficients are optimal:
$R(q)=4(1-q)^3\sqrt{q(1-q)}$ for $q\in[q_5,q_4]=[1-\frac2{\sqrt5},1-\frac{\sqrt3}2]$, and this is exactly the set
of $q\le\frac12$ where the formula holds. Extremisers: $(e_i+e_j+e_k+e_l)/2$; also $(e_i+e_j+e_k)/\sqrt3$ at
$q_4$ and $(e_{i_1}+\dots+e_{i_5})/\sqrt5$ at $q_5$. With Theorems 1–4 (audited VALID as A.6, A.11, A.14 and
A.18): $R(q)=2\sqrt{q(1-q)}\max_{k\ge1}\sqrt k\,\hat q^{k-1}$, $\hat q=\max(q,1-q)$, for all
$q\in[1-\frac2{\sqrt5},\frac2{\sqrt5}]$.

## Map of the proof

| piece | region | lemma | verification |
|---|---|---|---|
| one-coordinate cells (degree 10) | $a_1\le 33/100$ (1,268 cells) | Lemmas 10–16 | `outputs/k4/one_*.json`, exact (Sturm) |
| vertex certificates (`lpv`) | 4,543 boxes | Lemmas 17–26 | `outputs/k4/{p,m}_*.json`, exact (Sturm, Gaussian elimination, exact facet minima) |
| $m$-split boxes (`ms5`) | 2,718 boxes near $(e_1+e_2+e_3)/\sqrt3$, $(e_1+\dots+e_4)/2$ and $(e_1+\dots+e_5)/\sqrt5$ | Lemmas 18, 29–40 | exact + interval arithmetic |
| OR-region identity, three- and four-bit lemmas | all $c\in\mathbb R^3$, $c\in\mathbb R^4$ | Lemmas 6–8 | exact Sturm, 256 and 65,536 Boolean functions |

No near-circle boxes (Lemmas 27–28) were needed for $k=4$.

---

# Statement

Fix $q\in(0,1)$ and put $$u=\sqrt{\tfrac{1-q}{q}},\qquad v=\frac1u,\qquad \tau=\sqrt{q(1-q)} .$$ Let $\chi,\chi_1,\chi_2,\dots$ be i.i.d. with $\Pr[\chi=u]=q$ and $\Pr[\chi=-v]=1-q$, so that $\mathbb{E}\chi=0$, $\mathbb{E}\chi^2=1$ and $\mathbb{E}|\chi|=2\tau$. Let $$R(q)=\sup_{n\ge1}\ \sup_{\alpha\in\mathbb{R}^n\setminus\{0\}}\frac{\mathbb{E}|\sum_{i=1}^n\alpha_i\chi_i|}{|\alpha|_2}.$$ Put $$q_4=1-\tfrac{\sqrt3}{2}\approx0.133975,\qquad q_5=1-\tfrac{2}{\sqrt5}\approx0.105573,$$ $$T_2=2\sqrt2\,(1-q)\,\tau,\quad T_3=2\sqrt3\,(1-q)^2\,\tau,\quad T_4=4(1-q)^3\,\tau,\quad
T_5=2\sqrt5\,(1-q)^4\,\tau .$$

**Theorem 5**.

1.  *For every $q\in[q_5,q_4]$, every $n\ge1$ and every $\alpha\in\mathbb{R}^n$ with $|\alpha|_2=1$, $$\mathbb{E}\Big|\sum_{i=1}^n\alpha_i\chi_i\Big|\le 4(1-q)^3\sqrt{q(1-q)} .$$ For $q\in[1-q_4,1-q_5]$ the same holds with $1-q$ replaced by $q$. Consequently $R(q)=4\max(q,1-q)^3\sqrt{q(1-q)}$ for $q\in[q_5,q_4]\cup[1-q_4,1-q_5]$.*

2.  *(Extremisers.) Let $q\in[q_5,q_4]\cup[1-q_4,1-q_5]$. Equality in (a) holds if and only if $\alpha=\pm\frac12(e_i+e_j+e_k+e_l)$ with $i,j,k,l$ distinct, or $q\in\{q_4,1-q_4\}$ and $\alpha=\pm\frac1{\sqrt3}(e_i+e_j+e_k)$ with $i,j,k$ distinct, or $q\in\{q_5,1-q_5\}$ and $\alpha=\pm\frac1{\sqrt5}(e_{i_1}+\dots+e_{i_5})$ with $i_1,\dots,i_5$ distinct.*

3.  *(Sharpness.) $R(q)>T_4(q)$ for $q\in(0,q_5)\cup(q_4,\frac12]$. More precisely, $R(q)\ge T_5(q)>T_4(q)$ for $q<q_5$, $R(q)\ge T_3(q)>T_4(q)$ for $q_4<q<\frac13$, and $R(q)\ge2\tau>T_4(q)$ for $\frac13\le q\le\frac12$.*

**Corollary 1** (the whole $k=4$ regime). *$\{q\in(0,\tfrac12]:\ R(q)=T_4(q)\}=[q_5,q_4]$, and $\{q\in[\frac12,1):\ R(q)=4q^3\tau\}=[1-q_4,1-q_5]$.*

*Proof.* Theorem 5(a) and (c), and Lemma 3 for the mirror statement. ◻

**Corollary 2**. *Assume Theorem 4 of `MAIN_RESULT_K3B` ($R=T_3$ on $[q_4,\frac{25}{169}]$; filed as MAIN-4, not yet audited). Then, with Theorem 1 of `MAIN_RESULT` ($R(q)=2\tau$ on $[1-\frac1{\sqrt2},\frac1{\sqrt2}]$, audited VALID as A.6), Theorem 2 of `MAIN_RESULT_K2` ($R=T_2$ on $[1-\sqrt{2/3},1-\frac1{\sqrt2}]$, A.11, VALID) and Theorem 3 of `MAIN_RESULT_K3` ($R=T_3$ on $[\frac{25}{169},1-\sqrt{2/3}]$, A.14, VALID), $$R(q)=2\sqrt{q(1-q)}\,\max\{1,\ \sqrt2\,\hat q,\ \sqrt3\,\hat q^{\,2},\ 2\hat q^{\,3}\}
=2\sqrt{q(1-q)}\,\max_{k\ge1}\sqrt k\,\hat q^{\,k-1},\qquad \hat q=\max(q,1-q),$$ for all $q\in[q_5,1-q_5]=[1-\frac2{\sqrt5},\frac2{\sqrt5}]$.*

*Proof.* By Lemma 3 let $q\le\frac12$, so $\hat q=1-q$. On $[q_4,\frac12]$, Corollary 2 of `MAIN_RESULT_K3B` (which combines Theorems 1–4) gives $R(q)=2\tau\max\{1,\sqrt2(1-q),\sqrt3(1-q)^2\}$; there $2(1-q)^3\le\sqrt3(1-q)^2$ because $1-q\le\frac{\sqrt3}2$, so adding the entry $2\hat q^{\,3}$ does not change the maximum. On $[q_5,q_4]$, Theorem 5 gives $R(q)=2\tau\cdot2(1-q)^3$, and $2(1-q)^3$ is the largest of the four entries there: $2(1-q)^3\ge\sqrt3(1-q)^2$ iff $1-q\ge\frac{\sqrt3}2$; $(1-q)^2\ge\frac34>\frac1{\sqrt2}$ gives $2(1-q)^3>\sqrt2(1-q)$; and $2(1-q)^3\ge2(\frac34)^{3/2}>1$. This proves the first formula. For the second, let $k\ge5$ and $1-q\le\frac2{\sqrt5}$ (i.e. $q\ge q_5$). Then $\sqrt k(1-q)^{k-1}\le2(1-q)^3$ iff $\frac{\sqrt k}2(1-q)^{k-4}\le1$, and $\frac{\sqrt k}2(1-q)^{k-4}\le(\frac k4(\frac45)^{k-4})^{1/2}$. The sequence $\frac k4(\frac45)^{k-4}$ equals $1$ at $k=5$ and decreases for $k\ge5$, since $\frac{k+1}{k}\cdot\frac45\le\frac65\cdot\frac45<1$. So on $[q_5,\frac12]$ the terms with $k\ge5$ never exceed the term with $k=4$. ◻

Part (c) and the lower bound $R\ge T_4$ in (a) are elementary (Lemma 4). The content is the upper bound in (a), and (b).

#### Relation to Theorem 4.

The proof follows `MAIN_RESULT_K3B` (Theorem 4) step by step. The changes are:

1.  the target $T_4$, the range $u\in[u_4,u_5]$ (Section 2) and the threshold $A_S=\frac{33}{100}$ of the one-coordinate route;

2.  $k=4$ versions of the three- and four-bit lemmas ($\sum_i\Delta_i(f)^2\le16(1-q)^6$ on $[q_5,q_4]$; Lemmas 7 and 8);

3.  the *OR-region identity* (Lemma 6): if every $c_i$ exceeds $q\sum_jc_j$, then $\mathbb{E}|c\cdot\chi|=2\tau(1-q)^{n-1}\sum_ic_i$. It gives the five-coordinate near-sphere bound (Lemma 35) near the third extremiser $(e_1+\dots+e_5)/\sqrt5$, which ties with $(e_1+\dots+e_4)/2$ at $q_5$;

4.  one more level of the $m$-split (Section 8.3): pieces of type <span class="sans-serif">TCN</span>, with vertex certificates for patches with four split coordinates and an inner $m$-split of the second remainder;

5.  an exact check of the cone condition (P4) of the vertex sets by a chain of one-variable minima (Lemma 21), instead of the interval bisection used for Theorem 4.

The lemmas that are unchanged from Theorem 4 are proved again here, so that the document can be read on its own.

#### Conventions.

$x_+=\max(x,0)$. All polynomials in the computer-assisted parts have rational coefficients. “Verified” means verified in exact rational arithmetic or in outward-rounded interval arithmetic, as specified in Section 9. For a rational $x\ge0$ and an integer $N\ge1$, *rational lower and upper bounds of $\sqrt x$* are $\lfloor N\sqrt x\rfloor/N$ and $(\lfloor N\sqrt x\rfloor+1)/N$ computed with integer square roots (the verifier uses $N=10^{15}$ for the box parameters and $N=10^{12}$ for the patch enclosures).

# Reductions

## Symmetry and parametrisation

**Lemma 3**. *The law of $-\chi^{(q)}$ is the law of $\chi^{(1-q)}$. Hence $\mathbb{E}|\sum\alpha_i\chi^{(q)}_i|=\mathbb{E}|\sum\alpha_i\chi^{(1-q)}_i|$, $R(q)=R(1-q)$, and the extremisers for $q$ and $1-q$ coincide.*

*Proof.* $-\chi^{(q)}$ takes the value $-u_q$ with probability $q$ and $v_q$ with probability $1-q$; since $u_{1-q}=v_q$ and $v_{1-q}=u_q$, this is the law of $\chi^{(1-q)}$. Finally $|\sum\alpha_i(-\chi_i)|=|\sum\alpha_i\chi_i|$. ◻

From now on $q\le\frac12$, i.e. $u\ge1$, and $$\tag{1}
q=\frac{1}{1+u^2},\quad 1-q=\frac{u^2}{1+u^2},\quad v=\frac1u,\quad \tau=\frac{u}{1+u^2},\quad
qu=(1-q)v=\tau .$$ On $u\ge1$, $\tau$ and $q$ are decreasing and $1-q$ is increasing in $u$. The target is $$T_4=4(1-q)^3\tau=\frac{4u^7}{(1+u^2)^4},\qquad
\frac{d}{du}\frac{u^7}{(1+u^2)^4}=\frac{u^6(7-u^2)}{(1+u^2)^5},$$ so $T_4$ is increasing on $[1,\sqrt7]$ and decreasing on $[\sqrt7,\infty)$. Hence, for $1\le u_1<u_2$ and $u\in[u_1,u_2]$, $$\tag{2}
T_4(u)\ \ge\ T^-(u_1,u_2):=\min\{T_4(u_1),T_4(u_2)\}:$$ if $u\le\sqrt7$ then $T_4$ is increasing on $[u_1,u]$, and if $u\ge\sqrt7$ it is decreasing on $[u,u_2]$. For rational $u_1,u_2$ the number $T^-(u_1,u_2)$ is rational. The range $q\in[q_5,q_4]$ corresponds to $u\in[u_4,u_5]$ with $$u_4=\sqrt{3+2\sqrt3}\approx2.5424598,\qquad u_5=\sqrt{4+2\sqrt5}\approx2.9106935,$$ because $(1-q_4)/q_4=\frac{\sqrt3}{2-\sqrt3}=\sqrt3(2+\sqrt3)=3+2\sqrt3$ and $(1-q_5)/q_5=\frac{2}{\sqrt5-2}=2(\sqrt5+2)=4+2\sqrt5$. We fix the rationals $$U_-=\frac{1589}{625}=2.5424\ \le u_4,\qquad U_+=\frac{29107}{10000}=2.9107\ \ge u_5 .$$ Indeed $U_-^2>3$ and $(U_-^2-3)^2\le12$, so $U_-^2\le3+2\sqrt3$; and $U_+^2>4$ and $(U_+^2-4)^2\ge20$, so $U_+^2\ge4+2\sqrt5$. The computations cover $u\in[U_-,U_+]$; the theorem uses only $u\in[u_4,u_5]$. We also record that $U_-\ge2$ and that $w_-=U_-^2/(1+U_-^2)$ (the value of $1-q$ at $u=U_-$) satisfies $$\tag{3}
w_-^4\ge\tfrac12,\qquad 2w_-^3\ge1$$ (exact check; $w_-\approx0.866025$). Since $w_-$ is rational and $2^{1/4},2^{1/3}$ are irrational, both inequalities are strict, and since $1-q$ increases with $u$, $(1-q)^4>\frac12$ and $2(1-q)^3>1$ for all $u\ge U_-$.

## Values of a few vectors

**Lemma 4**. *Let $k\ge1$ and $q<1/k$. Then $\mathbb{E}|\chi_1+\dots+\chi_k|/\sqrt k=2\sqrt k\,(1-q)^{k-1}\tau$. In particular $\mathbb{E}|\chi_1|=2\tau$, and $\mathbb{E}|\chi_1+\dots+\chi_k|/\sqrt k=T_k$ for $k=2,3,4,5$ and $q<1/k$. Moreover, for all $q\in(0,1)$:*

1.  *$T_3\le T_4$ iff $q\le q_4$, with equality iff $q=q_4$;*

2.  *$T_5\le T_4$ iff $q\ge q_5$, with equality iff $q=q_5$;*

3.  *for $u\ge U_-$ (in particular for $q\in[q_5,q_4]$): $2\tau<T_4$ and $T_2<T_4$.*

*Proof.* Let $S=\chi_1+\dots+\chi_k$ and let $x_i=\mathbf 1\{\chi_i=u\}$. If some $x_i=1$ then $S\ge u-(k-1)v>0$, because $u^2>k-1$ is equivalent to $q<1/k$. If all $x_i=0$ then $S=-kv<0$. So $|S|=fS$ with $f=1-2\cdot\mathbf 1\{\text{all }x_i=0\}$. Since $\mathbb{E}\chi_i=0$, $\mathbb{E}[f\chi_i]=-2\mathbb{E}[\chi_i\mathbf 1\{\text{all }x=0\}]=-2(1-q)^k(-v)=2(1-q)^{k-1}(1-q)v=2(1-q)^{k-1}\tau$. Summing over $i$ gives $\mathbb{E}|S|=2k(1-q)^{k-1}\tau$. The comparisons: (i) $2\sqrt3(1-q)^2\le4(1-q)^3$ iff $1-q\ge\frac{\sqrt3}2$; (ii) $2\sqrt5(1-q)^4\le4(1-q)^3$ iff $1-q\le\frac2{\sqrt5}$; (iii) $2\tau<4(1-q)^3\tau$ iff $2(1-q)^3>1$, and $2\sqrt2(1-q)<4(1-q)^3$ iff $(1-q)^4>\frac12$; both hold for $u\ge U_-$ by (3). ◻

## Splitting off the two largest coefficients

Let $|\alpha|_2=1$ and $L=\sum\alpha_i\chi_i$. Changing the sign of $\alpha$ and permuting coordinates does not change $\mathbb{E}|L|$. So we may assume $$a_1:=\alpha_1=\max_i|\alpha_i|>0,\qquad a_2:=|\alpha_2|=\max_{i\ge2}|\alpha_i|,\qquad
|\alpha_3|\ge|\alpha_4|\ge\cdots,$$ and we put $s=\operatorname{sgn}\alpha_2\in\{1,-1\}$ ($s=1$ if $\alpha_2=0$), $$r=\sqrt{a_1^2+a_2^2}\in(0,1],\qquad b=\sqrt{1-r^2}.$$ If $r<1$, let $\beta_i=\alpha_i/b$ for $i\ge3$ and $M=\sum_{i\ge3}\beta_i\chi_i$. Then $$L=a_1\chi_1+s\,a_2\chi_2+bM,\qquad \sum_{i\ge3}\beta_i^2=1,\qquad
m:=\max_{i\ge3}|\beta_i|=\frac{|\alpha_3|}{b}\le\min\Big(1,\frac{a_2}{b}\Big),$$ and $M$ is independent of $(\chi_1,\chi_2)$. We use half-angle coordinates for $(a_1,a_2)$: $$a_1=r\,c(t),\quad a_2=r\,d(t),\qquad c(t)=\frac{1-t^2}{1+t^2},\quad d(t)=\frac{2t}{1+t^2},\qquad
t=\frac{a_2}{r+a_1}.$$ Since $0\le a_2\le a_1$, the angle $\theta$ with $\tan\theta=a_2/a_1$ is in $[0,\pi/4]$ and $t=\tan(\theta/2)\in[0,\sqrt2-1]$. We fix $T_8=\frac{20711}{50000}=0.41422\ge\sqrt2-1$ (indeed $(T_8+1)^2\ge2$). On $[0,1]$, $c$ is decreasing and $d$ is increasing in $t$, both are $\ge0$, and $c^2+d^2=1$. Thus every unit $\alpha$ gives a point $$(u,t,r,s)\in[U_-,U_+]\times[0,T_8]\times(0,1]\times\{1,-1\}\qquad(u\in[u_4,u_5]).$$ We put $A_S=\frac{33}{100}$. If $a_1\le A_S$ we use the one-coordinate route of Section 5; otherwise $r\ge a_1>A_S$ and we use the two-coordinate route of Sections 6–8.

# Exact evaluations

## Two coordinates

**Lemma 5** (two-coordinate value). *Let $q\le\frac12$, $c,d\ge0$, $s\in\{1,-1\}$, and $X=c\chi_1+s\,d\chi_2$. List the atoms of $X$ as $(\chi_1,\chi_2)=(u,u),(u,-v),(-v,u),(-v,-v)$, with probabilities $p=(q^2,\,q(1-q),\,q(1-q),\,(1-q)^2)$ and values $x_j$. Then $p_jx_j=\tau g_j$ with $$\tag{4}
g=\big(q(c+sd),\ (1-q)c-s\,q\,d,\ -q\,c+s(1-q)d,\ -(1-q)(c+sd)\big),$$ and $$\mathbb{E}|X|=2\tau\max\{c,\ d,\ [s=1]\,(1-q)(c+d)\}$$ (the last entry is present only for $s=1$). Consequently $\mathbb{E}|X|\le\max(2\tau,T_2)\sqrt{c^2+d^2}$, and if $u\ge U_-$ and $(c,d)\ne0$, then $\mathbb{E}|X|<T_4\sqrt{c^2+d^2}$.*

*Proof.* The identities $p_jx_j=\tau g_j$ follow from (1); for example $q(1-q)(cu-sdv)=(1-q)\tau c-q\tau sd$. Since $\mathbb{E}X=0$, $\mathbb{E}|X|=2\mathbb{E}X_+=2\tau\sum_j(g_j)_+$. For $s=1$: $g_1\ge0\ge g_4$, so $\mathbb{E}X_+/\tau=q(c+d)+((1-q)c-qd)_++((1-q)d-qc)_+$. If both middle terms are nonnegative this equals $(1-q)(c+d)$, and then $(1-q)(c+d)-c=(1-q)d-qc\ge0$ and similarly $\ge d$. If only the first is nonnegative it equals $q(c+d)+(1-q)c-qd=c$, and $(1-q)(c+d)-c=(1-q)d-qc<0$, while $c\ge d$ (otherwise $(1-q)d-qc\ge (1-2q)c\ge 0$). The case where only the second is nonnegative is symmetric. Both negative would give $(1-q)(c+d)<q(c+d)$, impossible for $q\le\frac12$ unless $c=d=0$. In all cases $\mathbb{E}X_+/\tau=\max\{c,d,(1-q)(c+d)\}$. For $s=-1$: $g_2\ge0\ge g_3$. If $c\ge d$ then $g_1\ge0\ge g_4$ and $\mathbb{E}X_+/\tau=q(c-d)+(1-q)c+qd=c$. If $c<d$ then $g_1<0<g_4$ and $\mathbb{E}X_+/\tau=(1-q)c+qd+(1-q)(d-c)=d$. So $\mathbb{E}X_+/\tau=\max(c,d)$.

For the bound let $\rho=\sqrt{c^2+d^2}$. Then $\max(c,d)\le\rho$ and $(1-q)(c+d)\le\sqrt2(1-q)\rho$, so $\mathbb{E}|X|\le\max(2\tau\rho,2\sqrt2(1-q)\tau\rho)=\max(2\tau,T_2)\rho$. For $u\ge U_-$ and $\rho>0$ this is $<T_4\rho$ by Lemma 4(iii). ◻

## Bits, OR functions and the OR region

For $n\ge1$, $f:\{0,1\}^n\to[-1,1]$ and $x_i=\mathbf 1\{\chi_i=u\}$ put $\Delta_i(f)=\mathbb{E}[f\mid x_i=1]-\mathbb{E}[f\mid x_i=0]$, a polynomial in $q$. Then, by (1), $$\tag{5}
\mathbb{E}[f\chi_i]=qu\,\mathbb{E}[f\mid x_i=1]-(1-q)v\,\mathbb{E}[f\mid x_i=0]=\tau\,\Delta_i(f).$$ For $c\in\mathbb{R}^n$ write $G_n(c)=\mathbb{E}|c_1\chi_1+\dots+c_n\chi_n|$. For a set $S\subseteq\{1,\dots,n\}$ let $\mathrm{OR}_S=2\cdot\mathbf 1\{\exists i\in S:x_i=1\}-1$. By the computation in the proof of Lemma 4, $$\tag{6}
\Delta_i(\mathrm{OR}_S)=2(1-q)^{|S|-1}\ (i\in S),\qquad \Delta_i(\mathrm{OR}_S)=0\ (i\notin S).$$ (For $i\in S$: $\mathbb{E}[\mathrm{OR}_S\mid x_i=1]=1$ and $\mathbb{E}[\mathrm{OR}_S\mid x_i=0]=1-2(1-q)^{|S|-1}$; for $i\notin S$, $\mathrm{OR}_S$ does not depend on $x_i$.)

**Lemma 6** (OR-region identity). *Let $n\ge1$, $q\in(0,1)$ and $c\in\mathbb{R}^n$ with $c_i>0$ and $c_i>q\sum_{l=1}^nc_l$ for every $i$. Then $$G_n(c)=2\tau(1-q)^{n-1}\sum_{i=1}^nc_i\ \le\ 2\sqrt n\,(1-q)^{n-1}\tau\,|c| .$$ In particular, for $n=5$ and $q\ge q_5$: $G_5(c)\le T_5|c|\le T_4|c|$, and $G_5(c)=T_4|c|$ holds if and only if $q=q_5$ and $c_1=\dots=c_5$.*

*Proof.* Let $S=\sum_lc_l\chi_l$. If all $x_l=0$ then $S=-v\sum_lc_l<0$. Otherwise pick $i$ with $x_i=1$. Every $l$ with $x_l=1$ contributes $c_lu$ instead of $-c_lv$, a gain of $c_l(u+v)>0$, so $S\ge c_iu-v\sum_{l\ne i}c_l=c_i(u+v)-v\sum_lc_l$. By (1), $u+v=(1+u^2)/u=v/q$, so $S\ge\frac vq\big(c_i-q\sum_lc_l\big)>0$. Hence $|S|=\mathrm{OR}_{\{1,\dots,n\}}\cdot S$, and by (5) and (6), $G_n(c)=\sum_ic_i\mathbb{E}[\mathrm{OR}\,\chi_i]=\tau\sum_ic_i\cdot2(1-q)^{n-1}$. The inequality is Cauchy–Schwarz, $\sum_ic_i\le\sqrt n|c|$, with equality iff all $c_i$ are equal. For $n=5$ the bound is $T_5|c|$, and $T_5\le T_4$ for $q\ge q_5$ with equality iff $q=q_5$ (Lemma 4(ii)). So $G_5(c)=T_4|c|$ forces equality in both steps, i.e. $c_1=\dots=c_5$ and $q=q_5$; conversely these give equality. ◻

## Three and four bits for $k=4$

**Lemma 7** (three-bit lemma for $k=4$). *Let $q\in[q_5,q_4]$ and $c\in\mathbb{R}^3$. Then $G_3(c)\le T_4\,|c|$. For $c\ne0$ equality holds if and only if $q=q_4$ and $c$ is a positive multiple of $\pm(e_1+e_2+e_3)$.*

**Lemma 8** (four-bit lemma for $k=4$). *Let $q\in[q_5,q_4]$ and $c\in\mathbb{R}^4$. Then $G_4(c)\le T_4\,|c|$. For $c\ne0$ equality holds if and only if $c$ is a positive multiple of $\pm(e_1+e_2+e_3+e_4)$, or $q=q_4$ and $c$ is a positive multiple of $\pm(e_i+e_j+e_k)$ for distinct $i,j,k$.*

*Proof of Lemmas 7 and 8.* Let $n\in\{3,4\}$, $X=c\cdot\chi$ and $f^*=\operatorname{sgn}X$ (with $\operatorname{sgn}0=1$), a function of $(x_1,\dots,x_n)$ with values $\pm1$. By (5) and Cauchy–Schwarz, $$G_n(c)=\mathbb{E}[f^*X]=\tau\sum_ic_i\Delta_i(f^*)\le\tau|c|\,|\Delta(f^*)| .$$ For $f:\{0,1\}^n\to\{-1,1\}$ put $H_f(q)=16(1-q)^6-\sum_{i=1}^n\Delta_i(f)^2$, a polynomial with integer coefficients. *Claims* (finite exact computations, Section 9, part G):

1.  ($n=3$, all $2^8$ functions) $H_f\ge0$ on $[q_5,q_4]$; no $H_f$ vanishes identically; $H_f(q_4)=0$ exactly for $f=\pm\mathrm{OR}_{\{1,2,3\}}$, and these two $H_f$ are $>0$ on $[q_5,q_4)$; every other $H_f$ is $>0$ on $[q_5,q_4]$.

2.  ($n=4$, all $2^{16}$ functions) $H_f\ge0$ on $[q_5,q_4]$; $H_f\equiv0$ exactly for $f=\pm\mathrm{OR}_{\{1,2,3,4\}}$; $H_f(q_4)=0\not\equiv H_f$ exactly for the eight functions $f=\pm\mathrm{OR}_S$ with $|S|=3$, and these eight $H_f$ are $>0$ on $[q_5,q_4)$; every other $H_f$ is $>0$ on $[q_5,q_4]$.

Given the claims, $G_n(c)\le\tau|c|\cdot4(1-q)^3=T_4|c|$ on $[q_5,q_4]$. If equality holds with $c\ne0$, then $\Delta(f^*)\ne0$, $c$ is a positive multiple of $\Delta(f^*)$, and $H_{f^*}(q)=0$. By the claims and (6): for $n=3$, $q=q_4$, $f^*=\pm\mathrm{OR}_{\{1,2,3\}}$ and $\Delta(f^*)=\pm2(1-q)^2(1,1,1)$; for $n=4$, either $f^*=\pm\mathrm{OR}_{\{1,2,3,4\}}$ and $\Delta(f^*)=\pm2(1-q)^3(1,1,1,1)$, or $q=q_4$, $f^*=\pm\mathrm{OR}_S$ with $|S|=3$ and $\Delta(f^*)=\pm2(1-q)^2\sum_{i\in S}e_i$. Conversely these vectors attain $T_4|c|$ by Lemma 4: $(1,1,1,1)$ gives $T_4$ for $q<\frac14$, and at $q_4$, $e_i+e_j+e_k$ gives $T_3=T_4$ (the fourth coordinate does not contribute).

*How the claims are checked.* For each $f$, $\Delta_i(f)=\sum_{x:x_i=1}(f(x)-f(x-e_i))
\prod_{l\ne i}q^{x_l}(1-q)^{1-x_l}$ is computed as an integer polynomial, and the distinct polynomials $H_f$ are tested (39 for $n=3$, 1 630 for $n=4$). Let $g_4(q)=4q^2-8q+1$ and $g_5(q)=5q^2-10q+1$, with roots $q_4$ and $q_5$ in $(0,1)$ ($4(1-q)^2=3$, resp. $5(1-q)^2=4$); both are decreasing on $[0,1]$, and $g_4$ is irreducible over $\mathbb Q$ (its discriminant $48$ is not a square). Take rationals $q_5^-<q_5$ and $q_4^+>q_4$ from rational bounds of $\sqrt{4/5}$ and $\sqrt{3/4}$, with $g_5(q_5^-)>0$ and $g_4(q_4^+)<0$ (and $q_5^+<q_4^-$ for the companion bounds). For $H_f\not\equiv0$: either $g_4\mid H_f$, $H_f=g_4Q$, where $Q$ has no root in $[q_5^-,q_4^+]$ (Sturm) and $Q(q_5^-)>0$; then $Q>0$ on $[q_5,q_4]$, and $H_f=g_4Q\ge0$ there with equality only at $q_4$, since $g_4>0$ on $[0,q_4)$. Or $g_4\nmid H_f$, and $H_f$ has no root in $[q_5^-,q_4^+]$ and $H_f(q_5^-)>0$, so $H_f>0$ on $[q_5,q_4]$. Since $g_4$ is irreducible, $H_f(q_4)=0$ iff $g_4\mid H_f$. The lists of functions with $H_f\equiv0$ and with $g_4\mid H_f$ are compared with the truth tables of the OR functions. As a check of (6): for $n=3$, $H_{\mathrm{OR}_{\{1,2,3\}}}=16(1-q)^6-12(1-q)^4=4(1-q)^4g_4(q)$, and for $n=4$, $H_{\mathrm{OR}_{\{1,2,3,4\}}}=16(1-q)^6-4\cdot4(1-q)^6=0$. ◻

*Remark 9*. Lemmas 7 and 8 are the cases $n=3,4$ of RQ-C’s result C6 ($R_n(q)=2\tau\sqrt{\max_{k\le n}k(1-q)^{2k-2}}$ for $q\le\frac12$ and $n\le7$, audited VALID as A.5, A.5b). Our check is independent of it. Both lemmas are false for $q>q_4$, where $(e_1+e_2+e_3)/\sqrt3$ gives $T_3>T_4$, and the bound $G_5\le T_4|c|$ of Lemma 6 is false for $q<q_5$, where $(e_1+\dots+e_5)/\sqrt5$ gives $T_5>T_4$. These are the only places where the ends $q_4$ and $q_5$ of Theorem 5 enter the proof.

# Moments of the remainder

**Lemma 10** (cumulants). *Let $w=u^2+v^2$ and $d=u-v$. The cumulants of $\chi$ are $\kappa_1=0$, $\kappa_2=1$ and $\kappa_j=d^{[j\text{ odd}]}G_j(w)$ for $3\le j\le10$, where $$\begin{aligned}
G_3&=1, & G_4&=w-4,\\
G_5&=w-10, & G_6&=w^2-26w+64,\\
G_7&=w^2-56w+244, & G_8&=w^3-120w^2+1188w-2176,\\
G_9&=w^3-246w^2+4044w-11080, & G_{10}&=w^4-502w^3+14604w^2-86728w+126976.
\end{aligned}$$*

*Proof.* By (1), $m_k=\mathbb{E}\chi^k=qu^k+(1-q)(-v)^k=(u^k+(-1)^ku^{2-k})/(1+u^2)$. The cumulants are determined by the recursion $\kappa_n=m_n-\sum_{k=1}^{n-1}\binom{n-1}{k-1}\kappa_km_{n-k}$. For example $m_3=u-v$, $m_4=w-1$, so $\kappa_3=d$ and $\kappa_4=m_4-3=w-4$. The identities for $j\le10$ are verified symbolically (sympy, part A1 of the verifier: the difference of the two sides simplifies to $0$ as a rational function of $u$). ◻

**Lemma 11** (moments from cumulants). *Let $M=\sum\beta_i\chi_i$ (finite sum) with $\sum\beta_i^2=1$ and power sums $p_j=\sum_i\beta_i^j$. Then $M$ has cumulants $K_1=0$, $K_2=1$, $K_j=\kappa_jp_j$, and $\mathbb{E}M^n=\mu_n(K_3,\dots,K_n)$ for $n\le10$, where $\mu_0=1$ and $$\mu_n=\sum_{k=2}^{n}\binom{n-1}{k-1}K_k\,\mu_{n-k}\qquad(K_2=1).$$ Each $\mu_n$ is a polynomial in $K_3,\dots,K_{10}$ with nonnegative integer coefficients; we write $\mu_n=\sum_eN_n(e)\prod_{j=3}^{10}K_j^{e_j}$ over exponent vectors $e=(e_3,\dots,e_{10})$. The term with $e=0$ is the Gaussian moment: $N_n(0)=(n-1)!!$ for even $n$ and $0$ for odd $n$.*

*Proof.* Cumulants of independent sums add and $K_j(\beta\chi)=\beta^j\kappa_j$, so $K_j(M)=\kappa_jp_j$, with $K_1=0$ and $K_2=\sum\beta_i^2=1$. The recursion is the moment–cumulant relation $m_n=\sum_{k=1}^{n}\binom{n-1}{k-1}K_km_{n-k}$ with $K_1=0$. The value at $K_3=\dots=K_{10}=0$ is the $n$-th moment of a standard Gaussian. (Part A2 of the verifier checks the recursion against the Gaussian moments and against $\mathbb{E}\chi^n$ at $u=\frac52$ for $n\le10$.) ◻

**Lemma 12** (power sums). *Let $\sum\beta_i^2=1$, $\max|\beta_i|\le m\le1$ and $\rho=\sqrt{p_4}$. Then $0\le\rho\le m$, $|p_3|\le\rho$, $|p_j|\le m^{j-4}\rho^2$ for $5\le j\le10$, and $p_j\ge\rho^{j-2}$ for even $j\ge4$.*

*Proof.* $p_4\le m^2\sum\beta_i^2=m^2$. Cauchy–Schwarz gives $p_3^2=(\sum\beta_i\beta_i^2)^2\le p_2p_4=p_4$. For $j\ge5$, $|p_j|\le\sum|\beta_i|^{j-4}\beta_i^4\le m^{j-4}p_4$. For even $j\ge4$, Jensen’s inequality for the probability weights $\beta_i^2$ and the convex function $x\mapsto x^{(j-2)/2}$ gives $p_j=\sum\beta_i^2(\beta_i^2)^{(j-2)/2}\ge(\sum\beta_i^2\beta_i^2)^{(j-2)/2}=\rho^{j-2}$. ◻

**Lemma 13** (sign information). *Let $\sum\beta_i^2=1$, $m=\max|\beta_i|$, and suppose $\beta_{i_0}=-m$ for some $i_0$. If $m\ge m_c\in(0,1]$, then $p_3\le\varphi(m_c):=-m_c^3+(1-m_c^2)^{3/2}$. Moreover $\varphi(m)<0$ iff $2m^2>1$.*

*Proof.* For $i\ne i_0$, $|\beta_i|\le(\sum_{i\ne i_0}\beta_i^2)^{1/2}=\sqrt{1-m^2}$. Hence $p_3=-m^3+\sum_{i\ne i_0}\beta_i^3\le-m^3+\sqrt{1-m^2}\sum_{i\ne i_0}\beta_i^2=\varphi(m)$, and $\varphi'(m)=-3m^2-3m\sqrt{1-m^2}\le0$, so $\varphi(m)\le\varphi(m_c)$. Finally $\varphi(m)<0$ iff $(1-m^2)^{3/2}<m^3$ iff $1-m^2<m^2$. ◻

#### Cumulant enclosures.

For $1\le u_1\le u\le u_2$: $d=u-1/u$ and $w=u^2+u^{-2}$ are increasing and $d\ge0$, so $d\in[d^-,d^+]=[u_1-\frac1{u_1},u_2-\frac1{u_2}]$ and $w\in[w^-,w^+]=[u_1^2+u_1^{-2},u_2^2+u_2^{-2}]$. Let $[G_j^-,G_j^+]$ be the exact range of the polynomial $G_j$ on $[w^-,w^+]$ (computed by isolating the real roots of $G_j'$ by Sturm sequences and bisection). Then $\kappa_j\in[\kappa_j^-,\kappa_j^+]$, where this is $[G_j^-,G_j^+]$ for even $j$ and the interval product $[d^-,d^+]\cdot[G_j^-,G_j^+]$ for odd $j$.

**Definition 14** (objective bound). Let $D\le10$, $c=(c_0,\dots,c_D)\in\mathbb Q^{D+1}$, $1<u_1<u_2$ rationals, $m^*\in(0,1]$, $p^*<0$ optional, and $\Theta$ a target. Put $L_e=\sum_nc_nN_n(e)$ and $A=L_0=\sum_{n\text{ even}}c_n(n-1)!!$. For every $e\ne0$ with $L_e\ne0$ let $[C_e^-,C_e^+]$ be the interval product $L_e\prod_j[\kappa_j^-,\kappa_j^+]^{e_j}$, and put $$u_e=e_3+2\sum_{j\ge4}e_j,\qquad U_e=\prod_{j\ge5}(m^*)^{(j-4)e_j}.$$ Call $e$ *even* if $e_j$ is even for every odd $j$. For even $e$ let $(\ell_e,l_e)=(0,0)$ if $e_j>0$ for some odd $j$, and $(\ell_e,l_e)=(1,\sum_{j\text{ even}}(j-2)e_j)$ otherwise. Define the term bounds

1.  if $p^*$ is given, $e=(1,0,\dots,0)$ (i.e. the monomial $p_3$) and $C_e^-\ge0$: replace $A$ by $A+C_e^-p^*$, and $b_e=0$;

2.  otherwise, if $e$ is not even: $b_e(\rho)=\max(|C_e^-|,|C_e^+|)\,U_e\,\rho^{u_e}$;

3.  if $e$ is even and $C_e^+\le0$: $b_e(\rho)=C_e^+\,\ell_e\,\rho^{l_e}$;

4.  if $e$ is even and $C_e^+>0$: $b_e(\rho)=C_e^+\,U_e\,\rho^{u_e}$.

We say that *$c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$* if $h(\rho)=\Theta-A-\sum_eb_e(\rho)>0$ for all $\rho\in[0,m^*]$.

**Lemma 15** (expectation bound). *Suppose $c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$ and let $P(y)=\sum_nc_ny^n$. Then $\mathbb{E}P(M)<\Theta$ for every $u\in[u_1,u_2]$ and every $M=\sum\beta_i\chi_i$ with $\sum\beta_i^2=1$, $\max|\beta_i|\le m^*$ and, if $p^*$ is given, $p_3\le p^*$.*

*Proof.* By Lemma 11, $\mathbb{E}P(M)=\sum_nc_n\mu_n=L_0+\sum_{e\ne0}C_ep^e$ with $C_e=L_e\prod_j\kappa_j^{e_j}\in[C_e^-,C_e^+]$ and $p^e=\prod_jp_j^{e_j}$. Let $\rho=\sqrt{p_4}\in[0,m^*]$. By Lemma 12, $|p^e|\le\rho^{e_3}(\rho^2)^{e_4}\prod_{j\ge5}(m^{*\,j-4}\rho^2)^{e_j}=U_e\rho^{u_e}$; if $e$ is even then $p^e\ge0$ (odd power sums appear to even powers, and $p_j\ge0$ for even $j$); and if moreover $e_j=0$ for all odd $j$, then $p^e\ge\prod_{j\text{ even}}\rho^{(j-2)e_j}=\rho^{l_e}$. Hence: in case (T0), $p_3\le p^*<0$ and $C_e\ge C_e^-\ge0$ give $C_ep_3\le C_ep^*\le C_e^-p^*$; in case (T1), $C_ep^e\le|C_e||p^e|\le b_e(\rho)$; in case (T2), $C_e\le C_e^+\le0$ and $p^e\ge\ell_e\rho^{l_e}\ge0$ give $C_ep^e\le C_e^+p^e\le C_e^+\ell_e\rho^{l_e}$; in case (T3), $p^e\ge0$ gives $C_ep^e\le C_e^+p^e\le C_e^+U_e\rho^{u_e}$. Summing, $\mathbb{E}P(M)\le\Theta-h(\rho)<\Theta$. ◻

# The one-coordinate route ($a_1\le\frac{33}{100}$)

Here we split off only $a=a_1$: $L=a\chi_1+b_1M_1$ with $b_1=\sqrt{1-a^2}$ and $M_1=\sum_{i\ge2}(\alpha_i/b_1)\chi_i$, whose coefficients are at most $\min(1,a/b_1)$ in absolute value. For $y\in\mathbb{R}$, $$\mathbb{E}|a\chi+y|=2\tau a+2R_a(y)-(1-2q)y,\qquad R_a(y)=\max\{0,\ (1-q)(y-av),\ q(-y-au)\}$$ (BF3, Lemma 9.4; Lemma 3 of `MAIN_RESULT`, audited VALID). Indeed $\mathbb{E}|a\chi+y|=q|au+y|+(1-q)|y-av|$ equals $2\tau a-(1-2q)y$ for $-au\le y\le av$ (using $qau=(1-q)av=\tau a$), $y$ for $y>av$, and $-y$ for $y<-au$, and so does the right-hand side. Conditioning on $M_1$ and using $\mathbb{E}M_1=0$, $$\mathbb{E}|L|=2\tau a+2\mathbb{E}R_a(b_1M_1),\qquad\text{so}\qquad \mathbb{E}|L|<T_4\iff\mathbb{E}R_a(b_1M_1)<\tau\big(2(1-q)^3-a\big).$$

A *cell* is $[u_1,u_2]\times[\underline a,\overline a]$ with rationals $1<u_1<u_2$ and $0\le\underline a<\overline a\le A_S$. Let $\bar b$ be a rational upper bound of $\sqrt{1-\underline a^2}$, $\bar m=\min\{1,\overline a/\beta\}$ with $\beta$ a rational lower bound of $\sqrt{1-\overline a^2}$, and $$\bar\ell_1(y)=\frac{u_2^2}{1+u_2^2}\Big(\bar by-\frac{\underline a}{u_2}\Big),\quad
\bar\ell_2(y)=\frac{1}{1+u_1^2}\big(-\bar by-\underline au_1\big),\quad
\Theta_1=\tau(u_2)\Big(2\Big(\frac{u_1^2}{1+u_1^2}\Big)^3-\overline a\Big).$$ A *cell certificate* is $c\in\mathbb Q^{D+1}$, $D\le10$, with $P(y)=\sum c_ny^n$ such that (V1) $P>0$, (V2) $P>\bar\ell_1$, (V3) $P>\bar\ell_2$ on $\mathbb{R}$, and (V4) $c$ satisfies the objective bound for $(u_1,u_2,\bar m,-,\Theta_1)$.

**Lemma 16**. *If a cell with $u_1\ge U_-$ has a certificate, then $\mathbb{E}|L|<T_4$ for every $u\in[u_1,u_2]$ and every unit $\alpha$ with $\underline a\le\max_i|\alpha_i|\le\overline a$.*

*Proof.* For $u\in[u_1,u_2]$, $a\in[\underline a,\overline a]$ and $b_1=\sqrt{1-a^2}$ we have $R_a(b_1y)=\max\{0,\ell_1,\ell_2\}$ with $\ell_1=\frac{u^2}{1+u^2}(b_1y-\frac au)$ and $\ell_2=\frac1{1+u^2}(-b_1y-au)$. If $\ell_1(y)>0$ then $y>0$ and $0<b_1y-\frac au\le\bar by-\frac{\underline a}{u_2}$, and $\frac{u^2}{1+u^2}\le\frac{u_2^2}{1+u_2^2}$, so $\ell_1(y)\le\bar\ell_1(y)$. If $\ell_2(y)>0$ then $y<0$ and $0<-b_1y-au\le-\bar by-\underline au_1$, and $\frac1{1+u^2}\le\frac1{1+u_1^2}$, so $\ell_2(y)\le\bar\ell_2(y)$. So by (V1)–(V3), $R_a(b_1y)<P(y)$ for all $y$, and $\mathbb{E}R_a(b_1M_1)\le\mathbb{E}P(M_1)$. Since $a/\sqrt{1-a^2}$ is increasing, the coefficients of $M_1$ are at most $\bar m$ in absolute value. By Lemma 15, $\mathbb{E}P(M_1)<\Theta_1$. Finally $\Theta_1\le\tau(u)(2(1-q)^3-a)$, because $\tau(u)\ge\tau(u_2)$, $(1-q)^3\ge(\frac{u_1^2}{1+u_1^2})^3$, $a\le\overline a$, and the bracket is positive: $2(\frac{u_1^2}{1+u_1^2})^3\ge2w_-^3\ge1>\frac{33}{100}\ge\overline a$ by (3) (the verifier also asserts $\Theta_1>0$ for every cell). ◻

# The two-coordinate route: vertex certificates

## The functions $F_x$, nested patches and peeling

Let $k\in\{2,3,4\}$ and a sign vector $\sigma\in\{1,-1\}^k$ with $\sigma_1=1$. For $x\in\mathbb{R}^{k+1}$ and $y\in\mathbb{R}$ put $$F_x(y)=\mathbb{E}\Big|\sum_{i=1}^k\sigma_ix_i\chi_i+x_{k+1}\,y\Big| ,$$ where $\chi_1,\dots,\chi_k$ are i.i.d. normalised $q$-biased bits. We use $\sigma=(1,s)$ for $k=2$, $\sigma=(1,s,s_3)$ for $k=3$ and $\sigma=(1,s,s_3,s_4)$ for $k=4$.

**Lemma 17**. *For fixed $q$ and $y$, the map $x\mapsto F_x(y)$ is convex and positively homogeneous of degree one. Consequently, if $x=\sum_l\nu_lV_l$ with $\nu_l\ge0$, then $F_x(y)\le\sum_l\nu_lF_{V_l}(y)$.*

*Proof.* $F_x(y)$ is the expectation of the absolute value of a linear function of $x$, i.e. a seminorm of $x$. A seminorm $N$ satisfies $N(\sum\nu_lV_l)\le\sum\nu_lN(V_l)$ for $\nu_l\ge0$. ◻

The *patches* are the maps, for $j\in\{0,1,2\}$ and $k=2+j$, $$p_k(t,r,\mu_1,\dots,\mu_j)=\big(rc(t),\,rd(t),\,b_0\mu_1,\,\dots,\,b_{j-1}\mu_j,\,b_j\big),\qquad
b_0=\sqrt{1-r^2},\quad b_i=b_{i-1}\sqrt{1-\mu_i^2},$$ for $t\in[0,1]$ and $r,\mu_1,\dots,\mu_j\in[0,1]$. Thus $p_2(t,r)=(rc,rd,b_0)$, $p_3(t,r,m)=(rc,rd,b_0m,b_0\sqrt{1-m^2})$ and $p_4(t,r,m,m')=(rc,rd,b_0m,b_1m',b_1\sqrt{1-m'^2})$. Their values are unit vectors with nonnegative entries: $b_{i-1}^2\mu_i^2+b_i^2=b_{i-1}^2$, so $|p_k|^2=r^2c^2+r^2d^2+b_0^2=1$.

#### Peeling.

Let $N=\sum_{i\in I}\gamma_i\chi_i$ be a finite sum with $\sum\gamma_i^2=1$, and $\mu(N)=\max_i|\gamma_i|$. If $\mu=\mu(N)<1$ and $\gamma_{i^*}=\varsigma\mu$ with $\varsigma\in\{1,-1\}$, the *peeled remainder* is $N^\flat=\sum_{i\in I\setminus\{i^*\}}(\gamma_i/\sqrt{1-\mu^2})\chi_i$. Then $$\tag{7}
N=\varsigma\mu\chi_{i^*}+\sqrt{1-\mu^2}\,N^\flat,\qquad \sum_{i\ne i^*}\frac{\gamma_i^2}{1-\mu^2}=1,\qquad
\mu(N^\flat)\le\min\Big(1,\frac{\mu}{\sqrt{1-\mu^2}}\Big),$$ and $N^\flat$ is independent of $\chi_{i^*}$: indeed $\sum_{i\ne i^*}\gamma_i^2=1-\mu^2$, and each $|\gamma_i|$ is at most $\mu$ and at most $\sqrt{1-\mu^2}$. If $\mu(N)=1$, then $N=\varsigma\chi_{i^*}$ (all other coefficients vanish).

**Lemma 18** (conditional expectation). *Consider a point with $r<1$ and remainder $M$, and let $j\in\{0,1,2\}$. Put $M^{(0)}=M$ and, for $i=1,\dots,j$, let $\mu_i=\mu(M^{(i-1)})$, attained by the coefficient $\varsigma_i\mu_i$ of $\chi_{l_i}$, and $M^{(i)}=(M^{(i-1)})^\flat$ if $\mu_i<1$.*

1.  *If $\mu_1,\dots,\mu_j<1$, then $\mathbb{E}|L|=\mathbb{E}F_{p_{2+j}(t,r,\mu_1,\dots,\mu_j)}(M^{(j)})$ with $\sigma=(1,s,\varsigma_1,\dots,\varsigma_j)$, the bits being $\chi_1,\chi_2,\chi_{l_1},\dots,\chi_{l_j}$; here $M^{(j)}$ is independent of these bits, $\sum$(coefficients of $M^{(j)}$)$^2=1$, and $\mu(M^{(j)})\le\min(1,\mu_j/\sqrt{1-\mu_j^2})$ if $j\ge1$.*

2.  *If $j\ge1$, $\mu_1,\dots,\mu_{j-1}<1$ and $\mu_j=1$, then $L=a_1\chi_1+sa_2\chi_2+\sum_{i<j}\varsigma_ib_{i-1}\mu_i\chi_{l_i}+\varsigma_jb_{j-1}\chi_{l_j}$, and $F_{p_{2+j}(t,r,\mu_1,\dots,\mu_j)}(y)=\mathbb{E}|L|$ for every $y\in\mathbb{R}$ (with the same $\sigma$).*

*Proof.* $L=a_1\chi_1+sa_2\chi_2+b_0M^{(0)}$ with $(a_1,a_2)=(rc(t),rd(t))$, and by (7), if $\mu_i<1$, $b_{i-1}M^{(i-1)}=\varsigma_ib_{i-1}\mu_i\chi_{l_i}+b_iM^{(i)}$. By induction $L=a_1\chi_1+sa_2\chi_2+\sum_{i\le j}\varsigma_ib_{i-1}\mu_i\chi_{l_i}+b_jM^{(j)}$, where the bits are distinct and independent of $M^{(j)}$; conditioning on $M^{(j)}$ gives (i), and the bound on $\mu(M^{(j)})$ is (7). In (ii), $M^{(j-1)}=\varsigma_j\chi_{l_j}$, which gives the formula for $L$; the last entry of $p_{2+j}$ is $b_j=b_{j-1}\sqrt{1-1}=0$, so $F_{p_{2+j}}(y)$ does not depend on $y$ and equals $\mathbb{E}|L|$. ◻

## Vertex sets and the cone lemma

**Definition 19** (vertex set). Let $X=\prod_{i=1}^k[\xi_i^-,\xi_i^+]$ be a box of patch parameters ($(t,r)$ for $k=2$, $(t,r,m)$ for $k=3$, $(t,r,m,m')$ for $k=4$) and $p=p_k$. A *vertex set for $X$* is a vector $n_0\in\mathbb Q^{k+1}$ and $2^k$ vectors $V_\epsilon\in\mathbb Q^{k+1}$, indexed by $\epsilon\in\{0,1\}^k$, such that:

1.  $|n_0|^2\ge1$ and $V_\epsilon\cdot n_0=|n_0|^2$ for all $\epsilon$;

2.  (parallelepiped) $V_\epsilon=V_0+\sum_i\epsilon_iE_i$ with $E_i=V_{e_i}-V_0$;

3.  (facets) for each $i$ and $\delta\in\{0,1\}$ the $2^{k-1}$ vertices with $\epsilon_i=\delta$ span a linear subspace of dimension $k$; let $h_{i,\delta}$ be a normal vector of it, oriented so that $h_{i,\delta}\cdot\bar c>0$ for the centre $\bar c=V_0+\frac12\sum_iE_i$ (and $h_{i,\delta}\cdot\bar c\ne0$ is required);

4.  (enclosure) $h_{i,\delta}\cdot p(\xi)\ge0$ for all $i,\delta$ and all $\xi\in X$.

**Lemma 20** (cone lemma). *Let $(n_0,(V_\epsilon))$ be a vertex set for $X$. Then for every $\xi\in X$ there are $\nu_\epsilon\ge0$ with $p(\xi)=\sum_\epsilon\nu_\epsilon V_\epsilon$ and $\sum_\epsilon\nu_\epsilon\le1/|n_0|\le1$.*

*Proof.* First, $V_0,E_1,\dots,E_k$ is a basis of $\mathbb{R}^{k+1}$. Indeed $E_i\cdot n_0=0$ by (P1) and $V_0\cdot n_0=|n_0|^2\ne0$, so $V_0\notin\operatorname{span}\{E_i\}$. By (P2) the face $\{\epsilon_i=0\}$ spans $S_i=\operatorname{span}(V_0,\{E_j\}_{j\ne i})$, which has dimension $k$ by (P3); hence the $k$ vectors $V_0,\{E_j\}_{j\ne i}$ are linearly independent. Moreover $\bar c-V_0-\frac12\sum_{j\ne i}E_j=\frac12E_i$ and $h_{i,0}\cdot\bar c\ne0$ with $h_{i,0}\perp S_i$, so $E_i\notin S_i$. Thus the $k+1$ vectors are independent.

Let $z\in\mathbb{R}^{k+1}$ with $h_{i,\delta}\cdot z\ge0$ for all $i,\delta$, and write $z=\lambda V_0+\sum_i\mu_iE_i$. Since $h_{i,0}\perp S_i$, $h_{i,0}\cdot z=\mu_i\,h_{i,0}\cdot E_i$, and $h_{i,0}\cdot\bar c=\frac12h_{i,0}\cdot E_i>0$; so $\mu_i\ge0$. The face $\{\epsilon_i=1\}$ spans $\operatorname{span}(V_0+E_i,\{E_j\}_{j\ne i})$, so $h_{i,1}\cdot E_j=0$ ($j\ne i$) and $h_{i,1}\cdot V_0=-h_{i,1}\cdot E_i$; then $h_{i,1}\cdot\bar c=-\frac12h_{i,1}\cdot E_i>0$, so $h_{i,1}\cdot V_0>0$, and $h_{i,1}\cdot z=(\lambda-\mu_i)\,h_{i,1}\cdot V_0$; so $\mu_i\le\lambda$. If $\lambda=0$ then $z=0$. Otherwise $z/\lambda=V_0+\sum_i\theta_iE_i$ with $\theta_i=\mu_i/\lambda\in[0,1]$, which is a point of the parallelepiped $\operatorname{conv}\{V_\epsilon\}$, i.e. a convex combination $\sum\omega_\epsilon V_\epsilon$ (take $\omega_\epsilon=\prod_i\theta_i^{\epsilon_i}(1-\theta_i)^{1-\epsilon_i}$). So $z=\sum\nu_\epsilon V_\epsilon$ with $\nu=\lambda\omega\ge0$ and $\sum\nu_\epsilon=\lambda$. Finally $z\cdot n_0=\lambda|n_0|^2$, so $\lambda=z\cdot n_0/|n_0|^2\le|z|/|n_0|$.

By (P4), $z=p(\xi)$ satisfies the hypothesis, and $|p(\xi)|=1$. ◻

Condition (P4) is checked without subdivision: the minimum of a linear functional over a parameter box of a patch is the end of a short chain of one-variable minimisations.

**Lemma 21** (facet minima). *For $\alpha,\beta\in\mathbb{R}$ and $-1\le x^-<x^+\le1$ let $g(x)=\alpha x+\beta\sqrt{1-x^2}$ and $\mathfrak m(\alpha,\beta;x^-,x^+)=\min_{x\in[x^-,x^+]}g(x)$.*

1.  *If $\beta\ge0$, then $\mathfrak m(\alpha,\beta;x^-,x^+)=\min(g(x^-),g(x^+))$.*

2.  *If $\beta<0$, put $R=\sqrt{\alpha^2+\beta^2}$ and $x^*=-\alpha/R$. Then $\mathfrak m(\alpha,\beta;x^-,x^+)=-R$ if $x^-\le x^*\le x^+$, and $\mathfrak m(\alpha,\beta;x^-,x^+)=\min(g(x^-),g(x^+))$ otherwise.*

3.  *$\mathfrak m(\alpha,\beta;x^-,x^+)$ is nondecreasing in $\beta$, and also in $\alpha$ if $x^-\ge0$.*

*Let $k=2+j$ with $j\in\{0,1,2\}$, let $X=[t^-,t^+]\times[r^-,r^+]\times\prod_{i=1}^j[\mu_i^-,\mu_i^+]$ with $0\le t^-<t^+\le1$, $0\le r^-<r^+\le1$ and $0\le\mu_i^-<\mu_i^+\le1$, and let $h\in\mathbb{R}^{k+1}$. Put $W_j=h_{k+1}$, $W_{i-1}=\mathfrak m(h_{i+2},W_i;\mu_i^-,\mu_i^+)$ for $i=j,j-1,\dots,1$, $A=\mathfrak m(h_1,h_2;c(t^+),c(t^-))$ and $G=\mathfrak m(A,W_0;r^-,r^+)$. Then $$\min_{\xi\in X}h\cdot p_k(\xi)=G.$$ If in this recursion each value of $\mathfrak m$ is replaced by a lower bound of it (and the later steps are applied to these lower bounds), the result is a lower bound of $G$.*

*Proof.* (i) The function $x\mapsto\sqrt{1-x^2}$ is concave on $[-1,1]$, so for $\beta\ge0$ the function $g$ is concave, and the minimum of a concave function over an interval is attained at an endpoint.

\(ii\) For $\beta<0$ the function $g$ is convex. By the Cauchy–Schwarz inequality, $g(x)\ge-R\,|(x,\sqrt{1-x^2})|=-R$ for all $x\in[-1,1]$. Moreover $R>0$, $|x^*|\le1$ and $\sqrt{1-x^{*2}}=|\beta|/R=-\beta/R$, so $g(x^*)=-\alpha^2/R-\beta^2/R=-R$. Thus $x^*$ is a minimum point of $g$ on $[-1,1]$. If $x^*\in[x^-,x^+]$, the minimum over $[x^-,x^+]$ is $-R$. Otherwise $[x^-,x^+]$ lies in $[-1,x^*]$ or in $[x^*,1]$, where the convex function $g$ is nonincreasing, respectively nondecreasing, so the minimum is attained at an endpoint.

\(iii\) For every $x\in[-1,1]$, $g(x)$ is nondecreasing in $\beta$ because $\sqrt{1-x^2}\ge0$, and nondecreasing in $\alpha$ if $x\ge0$. Minima over $x$ of pointwise nondecreasing families are nondecreasing.

Now the patch. Put $w_j=h_{k+1}$ and $w_{i-1}(\mu_i,\dots,\mu_j)=h_{i+2}\mu_i+\sqrt{1-\mu_i^2}\;w_i(\mu_{i+1},\dots,\mu_j)$ for $i=j,\dots,1$. Since $b_i=b_{i-1}\sqrt{1-\mu_i^2}$, we have $b_{i-1}w_{i-1}=h_{i+2}\,b_{i-1}\mu_i+b_iw_i$, and therefore $$h\cdot p_k(t,r,\mu_1,\dots,\mu_j)=r\,\big(h_1c(t)+h_2d(t)\big)+b_0\,w_0(\mu_1,\dots,\mu_j),\qquad b_0=\sqrt{1-r^2}.$$ First, $\min w_{i-1}=W_{i-1}$, the minimum being over $\mu_l\in[\mu_l^-,\mu_l^+]$ for $l\ge i$. This holds for $i-1=j$, since $w_j=h_{k+1}=W_j$. If it holds for $i$, then for fixed $\mu_i$ the minimum of $w_{i-1}$ over $\mu_{i+1},\dots,\mu_j$ is $h_{i+2}\mu_i+\sqrt{1-\mu_i^2}\,W_i$, because the weight $\sqrt{1-\mu_i^2}$ is nonnegative and $w_i$ does not depend on $\mu_i$. Minimising over $\mu_i\in[\mu_i^-,\mu_i^+]$ gives $\mathfrak m(h_{i+2},W_i;\mu_i^-,\mu_i^+)=W_{i-1}$.

Second, $c$ is a decreasing bijection of $[t^-,t^+]$ onto $[c(t^+),c(t^-)]$, and $d(t)=\sqrt{1-c(t)^2}$ for $t\in[0,1]$ (because $c^2+d^2=1$ and $d\ge0$). Hence $\min_{t\in[t^-,t^+]}(h_1c(t)+h_2d(t))=
\mathfrak m(h_1,h_2;c(t^+),c(t^-))=A$.

Third, for fixed $r$ the two brackets depend on disjoint sets of parameters and have the nonnegative weights $r$ and $b_0$, so the minimum over $t$ and $\mu$ is $rA+\sqrt{1-r^2}\,W_0$. Minimising over $r\in[r^-,r^+]$ gives $G$.

The last statement follows from (iii) by induction along the recursion: in the steps for $W_{i-1}$ the replaced value enters as $\beta$, and in the step for $G$ the values $A$ and $W_0$ enter as $\alpha$ and $\beta$, with $x=r\ge r^-\ge0$. ◻

#### Checking (P4).

(P4) holds if and only if $G(h_{i,\delta})\ge0$ for all $2k$ facet normals. A rational lower bound of $G$ is computed by the recursion of Lemma 21 in exact rational arithmetic: an endpoint value $g(x^\pm)$ is bounded below using a rational lower bound of $\sqrt{1-(x^\pm)^2}$ if $\beta\ge0$ and a rational upper bound if $\beta<0$; the value $-R$ is bounded below by $-R^+$ with $R^+\ge R$ rational; and the condition $x^-\le x^*\le x^+$ is decided exactly. For rationals $p,q$ the sign of $p-qR$ is: $\ge0$ if $p\ge0\ge q$; $<0$ if $p\le0\le q$ and $(p,q)\ne(0,0)$; the sign of $p^2-q^2R^2$ if $p,q>0$; and the sign of $q^2R^2-p^2$ if $p,q<0$. Then $x^-\le x^*$ if and only if $p-qR\ge0$ for $(p,q)=(-\alpha,x^-)$, and $x^*\le x^+$ if and only if $p-qR\le0$ for $(p,q)=(-\alpha,x^+)$. (P4) is accepted if the lower bound is $\ge0$ for every facet normal.

## Vertex envelopes and vertex certificates

Fix a $u$-interval $[u_1,u_2]$ with $u_1>1$. For a vertex $V\in\mathbb Q^{k+1}$ let $\gamma=(\sigma_1V_1,\dots,\sigma_kV_k)$ and $b_V=V_{k+1}$. The atoms of $\sum_i\gamma_i\chi_i$ are indexed by $\omega\in\{u,-v\}^k$, with probability $\pi_\omega=\prod_iq^{[\omega_i=u]}(1-q)^{[\omega_i=-v]}$ and value $y_\omega=\sum_i\gamma_i\omega_i$, and by (1) $$\pi_\omega y_\omega=\tau\sum_i\gamma_i\,(\pm1)_i\prod_{l\ne i}q^{[\omega_l=u]}(1-q)^{[\omega_l=-v]},
\qquad(\pm1)_i=+1\text{ if }\omega_i=u,\ -1\text{ otherwise}.$$ Using $q\in[\frac1{1+u_2^2},\frac1{1+u_1^2}]$, $1-q\in[\frac{u_1^2}{1+u_1^2},\frac{u_2^2}{1+u_2^2}]$ and $\tau\in[\tau(u_2),\tau(u_1)]$, interval arithmetic gives rational enclosures $\pi_\omega y_\omega\in[\eta_\omega^-,\eta_\omega^+]$ and $\pi_\omega\in[\pi_\omega^-,\pi_\omega^+]$, valid for all $u\in[u_1,u_2]$. Put $[\beta_\omega^-,\beta_\omega^+]=[\min(\pi_\omega^-b_V,\pi_\omega^+b_V),\max(\pi_\omega^-b_V,\pi_\omega^+b_V)]$.

**Definition 22** (vertex envelope). $\Phi_V(y)=\sum_\omega\max(\eta_\omega^++\beta_\omega^+y,\ -\eta_\omega^--\beta_\omega^-y)$ for $y\ge0$, and $\Phi_V(y)=\sum_\omega\max(\eta_\omega^++\beta_\omega^-y,\ -\eta_\omega^--\beta_\omega^+y)$ for $y<0$.

**Lemma 23** (envelope). *$F_V(y)\le\Phi_V(y)$ for all $y\in\mathbb{R}$ and all $u\in[u_1,u_2]$. On each closed half-line, $\Phi_V$ is continuous and piecewise linear, with breakpoints among the points where the two lines of one summand cross.*

*Proof.* $F_V(y)=\sum_\omega\pi_\omega|y_\omega+b_Vy|=\sum_\omega|\pi_\omega y_\omega+\pi_\omega b_V\,y|$ and $|z|=\max(z,-z)$. For $y\ge0$: $\pi_\omega y_\omega+\pi_\omega b_Vy\le\eta_\omega^++\beta_\omega^+y$ and $-\pi_\omega y_\omega-\pi_\omega b_Vy\le-\eta_\omega^--\beta_\omega^-y$, since $\pi_\omega b_V\in[\beta_\omega^-,\beta_\omega^+]$ (whatever the sign of $b_V$). For $y<0$ the roles of $\beta^\pm$ are exchanged. ◻

**Definition 24** (vertex certificate). Let $X$ be a parameter box, $\sigma$ a sign vector, $[u_1,u_2]$ a $u$-interval, $m^*\in(0,1]$ a cap, and $p^*<0$ optional. A *vertex certificate for $(X,\sigma,[u_1,u_2],m^*,p^*)$* is a vertex set $(n_0,(V_\epsilon))$ for $X$ and coefficient vectors $c^{(\epsilon)}\in\mathbb Q^{D+1}$, $D\le10$, with $P_\epsilon(y)=\sum_nc^{(\epsilon)}_ny^n$, such that for every $\epsilon$: (W1) $P_\epsilon(y)>\Phi_{V_\epsilon}(y)$ for all $y\in\mathbb{R}$; and (W2) $c^{(\epsilon)}$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,T^-(u_1,u_2))$.

(W1) is checked as follows: on each half-line, $\Phi_V$ coincides on each interval between consecutive breakpoints with one line $\lambda_0+\lambda_1y$ (one choice of line per summand); for every such line, $P_\epsilon-\lambda_0-\lambda_1y$ is shown to be positive on all of $\mathbb{R}$ by Sturm sequences.

**Lemma 25** (vertex certificate lemma). *Let a vertex certificate for $(X,\sigma,[u_1,u_2],m^*,p^*)$ be given. Let $\mathcal Z$ be the class of random variables $Z=\sum\beta_i\chi_i'$ (finite sums of i.i.d. copies of $\chi$, independent of $\chi_1,\dots,\chi_k$) with $\sum\beta_i^2=1$, $\max|\beta_i|\le m^*$ and, if $p^*$ is given, $p_3\le p^*$. Then for every $u\in[u_1,u_2]$, every $\xi\in X$ and every $Z\in\mathcal Z$, $$\mathbb{E}F_{p(\xi)}(Z)<T^-(u_1,u_2)\le T_4(u).$$*

*Proof.* By Lemma 20, $p(\xi)=\sum\nu_\epsilon V_\epsilon$ with $\nu\ge0$ and $\sum\nu_\epsilon\le1$. By Lemmas 17 and 23 and (W1), for every $y$, $F_{p(\xi)}(y)\le\sum_\epsilon\nu_\epsilon F_{V_\epsilon}(y)\le\sum_\epsilon\nu_\epsilon P_\epsilon(y)$. Taking expectations over $Z$, $\mathbb{E}F_{p(\xi)}(Z)\le\sum_\epsilon\nu_\epsilon\mathbb{E}P_\epsilon(Z)$. By (W1) and Lemma 23, $\mathbb{E}P_\epsilon(Z)>\mathbb{E}F_{V_\epsilon}(Z)\ge0$, and by (W2) and Lemma 15, $\mathbb{E}P_\epsilon(Z)<T^-$. Since $\sum\nu_\epsilon\le1$ and $\max_\epsilon\mathbb{E}P_\epsilon(Z)\ge0$, $\sum_\epsilon\nu_\epsilon\mathbb{E}P_\epsilon(Z)\le\max_\epsilon\mathbb{E}P_\epsilon(Z)<T^-$. Finally $T^-\le T_4(u)$ by (2). ◻

Two members of $\mathcal Z$ are used repeatedly: $Z=N^{-1/2}(\chi_1'+\dots+\chi_N')$ with $N^{-1/2}\le m^*$ (no $p^*$), and, if $m^*=1$, $Z=\chi_1'$ (no $p^*$).

## Boxes

A *box* is $B=[u_1,u_2]\times[t_1,t_2]\times[r_1,r_2]$ with rationals $1<u_1<u_2$, $0\le t_1<t_2\le1$, $0\le r_1<r_2\le1$, together with a sign $s$. Let $b^-$ be a rational lower bound of $\sqrt{1-r_2^2}$ ($b^-=0$ if $r_2=1$), and define $\bar m(B)=1$ if $b^-=0$ or $r_2d(t_2)\ge b^-$, and $\bar m(B)=r_2d(t_2)/b^-$ otherwise. Then $\bar m(B)\in(0,1]$ and $m\le\min(1,a_2/b)\le\bar m(B)$ at every point of $B$ with $r<1$, because $a_2=rd(t)\le r_2d(t_2)$ and $b\ge b^-$. A box of kind <span class="sans-serif">lpv</span> carries a vertex certificate for $([t_1,t_2]\times[r_1,r_2],(1,s),[u_1,u_2],\bar m(B),-)$. A box of kind <span class="sans-serif">small</span> satisfies $r_2c(t_1)\le A_S$, so $a_1=rc(t)\le A_S$ on it.

**Lemma 26**. *At every point of an <span class="sans-serif">lpv</span> box with $r<1$, $\mathbb{E}|L|<T_4$.*

*Proof.* By Lemma 18 ($j=0$), $\mathbb{E}|L|=\mathbb{E}F_{p_2(t,r)}(M)$, and $M\in\mathcal Z$ since $m\le\bar m(B)$. Apply Lemma 25. ◻

# Near $(e_1+e_2)/\sqrt2$: the near-circle lemma

**Lemma 27** (tail bound). *Let $y\in\mathbb{R}$, $b\ge0$ and let $Z$ be a random variable with $\mathbb{E}Z=0$ and $\mathbb{E}Z^4<\infty$. Then $$\mathbb{E}|y+bZ|\le|y|+\min\Big(b\,\mathbb{E}|Z|,\ \frac{27}{128}\,\frac{b^4\mathbb{E}Z^4}{|y|^3}\Big),$$ where for $y=0$ the minimum is read as its first entry. The same convention is used below whenever this bound is applied at a point where $y=0$.*

*Proof.* The first bound is the triangle inequality. For the second ($y\ne0$), $|y+z|-|y|-\operatorname{sgn}(y)z=2(-\operatorname{sgn}(y)z-|y|)_+\le2(|z|-|y|)_+$, and $\mathbb{E}[\operatorname{sgn}(y)bZ]=0$. For $x\ge0$ and $\eta>0$, $(x-\eta)_+\le\frac{27}{256}x^4/\eta^3$: the maximum of $(x-\eta)/x^4$ over $x>\eta$ is at $x=\frac43\eta$ and equals $\frac{27}{256}\eta^{-3}$. Hence $\mathbb{E}|y+bZ|-|y|\le2\cdot\frac{27}{256}\,b^4\mathbb{E}Z^4/|y|^3$. ◻

**Lemma 28** (near-circle tests). *Let $B$ be a box with $r_1>0$ and $u_1\ge U_-$. Let $y_j$ ($j=1,\dots,4$) be the atoms of $c\chi_1+sd\chi_2$, so that the atoms of $a_1\chi_1+sa_2\chi_2$ are $ry_j$. Let $\eta_j\ge0$ be a lower bound of $|y_j|$ on $B$, $p_j^+$ an upper bound of $p_j$, $b^+$ an upper bound of $\sqrt{1-r_1^2}$, and $E_4=3+\max(0,w^+-4)\,\bar m(B)^2$. Let $T^-=T^-(u_1,u_2)$.*

1.  *If all $\eta_j>0$ and $\frac{27}{128}E_4(b^+)^2\frac{1+r_2}{r_1^3}\sum_jp_j^+\eta_j^{-3}<T^-$, then $\mathbb{E}|L|<T_4$ at every point of $B$ with $r<1$.*

2.  *Let $G^+$ be an upper bound of $\mathbb{E}|c\chi_1+sd\chi_2|=\tau\sum_j|g_j|$ on $B$ with $G^+\le T^-$, and $e_j^+=\min\big(b^+,\frac{27}{128}(b^+)^4E_4/(r_1^3\eta_j^3)\big)$ ($e_j^+=b^+$ if $\eta_j=0$). If $\sum_jp_j^+e_j^+<T^-(1-r_2)+r_1(T^--G^+)$, then $\mathbb{E}|L|<T_4$ at every point of $B$ with $r<1$.*

*Proof.* At a point of $B$ with $r<1$, condition on $(\chi_1,\chi_2)$ and apply Lemma 27 with $Z=M$. Here $\mathbb{E}M^4=3+\kappa_4p_4\le E_4$ by Lemma 11, since $p_4\le m^2\le\bar m(B)^2$ and $\kappa_4=w-4\le w^+-4$; also $\mathbb{E}|M|\le1$. This gives $\mathbb{E}|L|\le rG+\sum_jp_je_j$, where $G=\mathbb{E}|c\chi_1+sd\chi_2|$ and $e_j=\min(b,\frac{27}{128}b^4E_4/(r^3|y_j|^3))$. (A) By Lemma 5 ($u\ge U_-$, $c^2+d^2=1$), $G<T_4$. Since $1-r=b^2/(1+r)$ and $b>0$, $\sum_jp_je_j\le\frac{27}{128}\frac{b^4E_4}{r^3}\sum_j\frac{p_j}{|y_j|^3}
\le b^2\cdot\frac{27}{128}E_4(b^+)^2\frac{1}{r_1^3}\sum_j\frac{p_j^+}{\eta_j^3}
<\frac{b^2T^-}{1+r_2}\le T_4(1-r)$. So $\mathbb{E}|L|<rT_4+T_4(1-r)=T_4$. (B) $\mathbb{E}|L|\le rG^++\sum_jp_j^+e_j^+<rG^++T^-(1-r_2)+r_1(T^--G^+)\le rG^++T^-(1-r)+r(T^--G^+)=T^-\le T_4$, using $r_1\le r\le r_2$ and $T^--G^+\ge0$. ◻

Boxes of kind <span class="sans-serif">ncA</span> pass test (A) or test (B).

# Near the extremisers: the $m$-split

In our coordinates the extremisers are the following points (all with $s=1$ and $t=\sqrt2-1$, since $a_1=a_2$):

- $(e_1+e_2+e_3+e_4)/2$, for every $q\in[q_5,q_4]$: $a_1=a_2=\frac12$, $b=\frac1{\sqrt2}$, $M=(\chi_3+\chi_4)/\sqrt2$, so $m=\frac1{\sqrt2}$, and after peeling $\chi_3$, $M'=\chi_4$, $m'=1$;

- $(e_1+e_2+e_3)/\sqrt3$, at $q_4$: $a_1=a_2=b=\frac1{\sqrt3}$, $M=\chi_3$, $m=1$;

- $(e_1+\dots+e_5)/\sqrt5$, at $q_5$: $a_1=a_2=\frac1{\sqrt5}$, $b=\sqrt{3/5}$, $M=(\chi_3+\chi_4+\chi_5)/\sqrt3$, $m=\frac1{\sqrt3}$; after peeling, $M'=(\chi_4+\chi_5)/\sqrt2$, $m'=\frac1{\sqrt2}$, and $M''=\chi_5$, $m''=1$.

Equality holds at these points, so no certificate with a strict bound can contain them. We split according to $m=\max_{i\ge3}|\beta_i|$ and the sign of a largest remaining coefficient, and inside some pieces we peel off the largest coefficient and split the new remainder again, up to five split coordinates in total. We write $M'=M^{(1)}$, $m'=\mu(M')$, $M''=M^{(2)}$, $m''=\mu(M'')$ (Lemma 18), and $$a_3=bm,\quad b'=b\sqrt{1-m^2},\quad a_4=b'm',\quad b''=b'\sqrt{1-m'^2},\quad a_5=b''m'',\quad
b'''=b''\sqrt{1-m''^2},$$ so that $L=a_1\chi_1+sa_2\chi_2+bM$, $bM=\pm a_3\chi_{i_0}+b'M'$, $b'M'=\pm a_4\chi_{i_1}+b''M''$ and $b''M''=\pm a_5\chi_{i_2}+b'''M'''$, with the signs of the peeled coefficients. Throughout, $E_4'=3+\max(0,\kappa_4)$; for any remainder $N=\sum\gamma_i\chi_i$ with $\sum\gamma_i^2=1$, $\mathbb{E}N^4=3+\kappa_4\sum\gamma_i^4\le E_4'$ by Lemma 11 (as $0\le\sum\gamma_i^4\le1$), and $\mathbb{E}|N|\le1$.

## Three split coordinates

**Lemma 29** (three-coordinate near-sphere bound). *Consider a point with $r<1$ and suppose $\beta_{i_0}=+m$ for some $i_0\ge3$. Let $Y=a_1\chi_1+sa_2\chi_2+a_3\chi_{i_0}$ with atoms $y_j$ and probabilities $p_j$ ($j=1,\dots,8$), and $r'=\sqrt{a_1^2+a_2^2+a_3^2}=\sqrt{1-b'^2}$. Then $$\mathbb{E}|L|\le\mathbb{E}|Y|+\sum_jp_j\min\Big(b',\ \frac{27}{128}\frac{b'^4E_4'}{|y_j|^3}\Big).$$ If moreover $q\in[q_5,q_4]$, all $y_j\ne0$ and $\frac{27}{128}E_4'\,b'^2(1+r')\sum_jp_j|y_j|^{-3}<T_4$, then $\mathbb{E}|L|<T_4$ if $b'>0$, and if $b'=0$ then $\mathbb{E}|L|=G_3(a_1,sa_2,a_3)\le T_4$.*

*Proof.* If $m=1$ then $b'=0$ and $L=Y$. Otherwise $L=Y+b'M'$ with $M'$ independent of $Y$ (Lemma 18), and conditioning on $(\chi_1,\chi_2,\chi_{i_0})$ and applying Lemma 27 with $Z=M'$ gives the first bound. By Lemma 7, $\mathbb{E}|Y|=G_3(a_1,sa_2,a_3)\le T_4r'$. If $b'>0$, the hypothesis and $1-r'=b'^2/(1+r')$ give $\sum_jp_j\frac{27}{128}\frac{b'^4E_4'}{|y_j|^3}<T_4\frac{b'^2}{1+r'}=T_4(1-r')$, hence $\mathbb{E}|L|<T_4r'+T_4(1-r')=T_4$. ◻

#### Piece tests (A3), (B3).

Let $B$ be a box with $b^->0$ and $[m_1,m_2]\subset(0,1]$. On $B\times[m_1,m_2]$ we enclose $a_1=rc(t)$, $a_2=rd(t)$, $a_3=bm\in[b^-m_1,b^+m_2]$, $b'^2\le(b'^2)^+:=(b^+)^2(1-m_1^2)$, and $r'\le r'^+:=\min\big(1,\sqrt{1-(b^-)^2(1-m_2^2)}\big)$ (recall $r'^2=1-b^2(1-m^2)$). The atoms $y_j=a_1x_{j1}+sa_2x_{j2}+a_3x_{j3}$ ($x\in\{u,-v\}^3$) and the products $p_jy_j=\tau\sum_i(\pm a_i)\prod_{l\ne i}\Pr[x_{jl}]$ (by $qu=(1-q)v=\tau$) are enclosed in interval arithmetic. Let $\eta_j$ be a lower bound of $|y_j|$, $p_j^+$ an upper bound of $p_j$, and $E_4'^+=3+\max(0,w^+-4)$. The piece passes

- test (A3) if all $\eta_j>0$ and $\frac{27}{128}E_4'^+(b'^2)^+(1+r'^+)\sum_jp_j^+\eta_j^{-3}<T^-(u_1,u_2)$;

- test (B3) if $\sum_j\big(|p_jy_j|^++p_j^+\min\big(b'^+,\frac{27}{128}((b'^2)^+)^2E_4'^+/\eta_j^3\big)\big)<T^-(u_1,u_2)$, where $|p_jy_j|^+$ is an upper bound of $|p_jy_j|$, $b'^+$ an upper bound of $\sqrt{(b'^2)^+}$, and the second entry of the minimum is omitted if $\eta_j=0$.

By Lemma 29, if a piece passes (A3), then at every point of $B$ with $q\in[q_5,q_4]$ and every remainder with $\beta_{i_0}=+m$, $m\in[m_1,m_2]$, we have $\mathbb{E}|L|<T_4$ if $b'>0$, and $\mathbb{E}|L|=G_3(a_1,sa_2,bm)\le T_4$ if $b'=0$. If it passes (B3), then $\mathbb{E}|L|<T_4$ at every $u\in[u_1,u_2]$ by the first bound of Lemma 29 alone ($\mathbb{E}|Y|=\sum_j|p_jy_j|$).

**Definition 30** (pieces of type <span class="sans-serif">TC</span> and <span class="sans-serif">SG</span>). Let $B$ be a box with $b^->0$, sign $s$, and $[m_1,m_2]\subset(0,1]$.

- A <span class="sans-serif">TC</span> piece with sign $s_3\in\{1,-1\}$ is a rational cap $\kappa\in(0,1]$ with $\kappa\ge\min(1,m_2/\sqrt{1-m_2^2})$ (that is, $\kappa=1$, or $m_2<1$ and $\kappa^2(1-m_2^2)\ge m_2^2$), and a vertex certificate for $([t_1,t_2]\times[r_1,r_2]\times[m_1,m_2],(1,s,s_3),[u_1,u_2],\kappa,-)$.

- An <span class="sans-serif">SG</span> piece (for $s_3=-1$) is a rational $p^*$ with $2m_1^2>1$ and $\varphi(m_1)\le p^*<0$, a rational cap $\kappa\in(0,1]$ with $\kappa\ge\min(m_2,\bar m(B))$, and a vertex certificate for $([t_1,t_2]\times[r_1,r_2],(1,s),[u_1,u_2],\kappa,p^*)$.

**Lemma 31**. *Let $B$ be a box with $b^->0$ and consider a point of $B$ with $r<1$ whose remainder has $m=\max_{i\ge3}|\beta_i|\in[m_1,m_2]$ and $\beta_{i_0}=s_3m$.*

1.  *If $[m_1,m_2]$ carries a <span class="sans-serif">TC</span> piece with sign $s_3$, then $\mathbb{E}|L|<T_4$.*

2.  *If $s_3=-1$ and $[m_1,m_2]$ carries an <span class="sans-serif">SG</span> piece, then $\mathbb{E}|L|<T_4$.*

*Proof.* (i) If $m<1$, Lemma 18 ($j=1$) gives $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,m)}(M')$ with $\mu(M')\le\min(1,m/\sqrt{1-m^2})\le\min(1,m_2/\sqrt{1-m_2^2})\le\kappa$, so $M'\in\mathcal Z$ and Lemma 25 applies. If $m=1$, then $m_2=1$ and $\kappa=1$, and $\mathbb{E}|L|=F_{p_3(t,r,1)}(y)$ for every $y$ (Lemma 18(ii)); taking $Z=\chi'\in\mathcal Z$, $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,1)}(Z)<T_4$ by Lemma 25. (ii) By Lemma 13 with $m_c=m_1$, $p_3(M)\le\varphi(m_1)\le p^*$. Also $m\le m_2$ and $m\le\bar m(B)$, so $m\le\kappa$. Thus $M\in\mathcal Z$, and Lemmas 18 ($j=0$) and 25 give $\mathbb{E}|L|<T_4$. ◻

## Four split coordinates

**Lemma 32** (four-coordinate near-sphere bound). *Consider a point with $r<1$, $\beta_{i_0}=+m$ with $m<1$, and suppose that $M'$ has the coefficient $+m'$ at $\chi_{i_1}$, where $m'=\mu(M')$. Let $Y_4=a_1\chi_1+sa_2\chi_2+a_3\chi_{i_0}+a_4\chi_{i_1}$ with atoms $y_j$ and probabilities $p_j$ ($j=1,\dots,16$), and $r''=\sqrt{a_1^2+a_2^2+a_3^2+a_4^2}=\sqrt{1-b''^2}$. Then $$\mathbb{E}|L|\le\mathbb{E}|Y_4|+\sum_jp_j\min\Big(b'',\ \frac{27}{128}\frac{b''^4E_4'}{|y_j|^3}\Big).$$ If moreover $q\in[q_5,q_4]$, all $y_j\ne0$ and $\frac{27}{128}E_4'\,b''^2(1+r'')\sum_jp_j|y_j|^{-3}<T_4$, then $\mathbb{E}|L|<T_4$ if $b''>0$, and if $b''=0$ then $\mathbb{E}|L|=G_4(a_1,sa_2,a_3,a_4)\le T_4$.*

*Proof.* If $m'=1$ then $b''=0$ and $L=Y_4$ (Lemma 18(ii) with $j=2$). Otherwise $L=Y_4+b''M''$ with $M''$ independent of $Y_4$; conditioning on the four bits of $Y_4$ and applying Lemma 27 with $Z=M''$ gives the first bound. By Lemma 8, $\mathbb{E}|Y_4|=G_4(a_1,sa_2,a_3,a_4)\le T_4r''$. If $b''>0$, the hypothesis and $1-r''=b''^2/(1+r'')$ give $\mathbb{E}|L|<T_4r''+T_4(1-r'')=T_4$. ◻

#### Piece tests (A4), (B4).

Let $B$ be a box with $b^->0$, $[m_1,m_2]\subset(0,1]$ and $[n_1,n_2]\subset(0,1]$. On $B\times[m_1,m_2]\times[n_1,n_2]$ (with $m\in[m_1,m_2]$, $m<1$, and $m'\in[n_1,n_2]$) we enclose $a_1,a_2,a_3$ as in (A3), $b'^2\in[(b'^2)^-,(b'^2)^+]=[(b^-)^2(1-m_2^2),(b^+)^2(1-m_1^2)]$, $b'$ by the square roots of these bounds, $a_4=b'm'\in[b'^-n_1,b'^+n_2]$, $b''^2\le(b''^2)^+:=(b'^2)^+(1-n_1^2)$, and $r''\le r''^+:=\min\big(1,\sqrt{1-(b'^2)^-(1-n_2^2)}\big)$. The 16 atoms and the products $p_jy_j$ are enclosed as in (A3). The piece passes

- test (A4) if all $\eta_j>0$ and $\frac{27}{128}E_4'^+(b''^2)^+(1+r''^+)\sum_jp_j^+\eta_j^{-3}<T^-(u_1,u_2)$;

- test (B4) if $\sum_j\big(|p_jy_j|^++p_j^+\min\big(b''^+,\frac{27}{128}((b''^2)^+)^2E_4'^+/\eta_j^3\big)\big)<T^-(u_1,u_2)$.

**Definition 33** (pieces of type <span class="sans-serif">TCS</span>). Let $B$ be a box with $b^->0$, sign $s$, and $[m_1,m_2]\subset(0,1]$. A <span class="sans-serif">TCS</span> piece is: a rational cap $\kappa\in(0,1]$ with $\kappa\ge\min(1,m_2/\sqrt{1-m_2^2})$; a rational $m_c'\in(0,1]$ and a rational $p'^*$ with $2m_c'^2>1$ and $\varphi(m_c')\le p'^*<0$; a vertex certificate $\mathcal C'$ for $(X_3,(1,s,1),[u_1,u_2],m_c',-)$ and a vertex certificate $\mathcal C''$ for $(X_3,(1,s,1),[u_1,u_2],\kappa,p'^*)$, where $X_3=[t_1,t_2]\times[r_1,r_2]\times[m_1,m_2]$; and sub-pieces $[n_1,n_2]\subset(0,1]$, each passing (A4) or (B4) (on $B\times[m_1,m_2]\times[n_1,n_2]$), whose union contains $[m_c',\kappa]$.

**Lemma 34**. *Let $[m_1,m_2]$ carry a <span class="sans-serif">TCS</span> piece for $B$. At every point of $B$ with $r<1$ and $q\in[q_5,q_4]$ whose remainder has $\beta_{i_0}=+m$, $m=\max|\beta_i|\in[m_1,m_2]$, we have $\mathbb{E}|L|\le T_4$. Equality forces $s=1$ and $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$ for some $i_1\notin\{1,2,i_0\}$.*

*Proof.* If $m=1$: $\mathbb{E}|L|=F_{p_3(t,r,1)}(y)$ for every $y$ (Lemma 18(ii)); take $Z=N^{-1/2}(\chi_1'+\dots+\chi_N')$ with $N^{-1/2}\le m_c'$, which belongs to the class of $\mathcal C'$. Lemma 25 gives $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,1)}(Z)<T_4$.

Now let $m<1$. By Lemma 18, $$\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,m)}(M'),\qquad m'=\mu(M')\le\min\big(1,m/\sqrt{1-m^2}\big)\le\kappa .$$

- If $m'\le m_c'$: $M'$ is in the class of $\mathcal C'$, and Lemma 25 gives $\mathbb{E}|L|<T_4$.

- If $m'\ge m_c'$ and $M'$ has the coefficient $-m'$ at some $\chi_{i_1}$: by Lemma 13, $p_3(M')\le\varphi(m_c')\le p'^*$, and $m'\le\kappa$, so $M'$ is in the class of $\mathcal C''$, and $\mathbb{E}|L|<T_4$.

- Otherwise $M'$ has the coefficient $+m'$ at some $\chi_{i_1}$, with $m'\in[m_c',\kappa]$, so $m'$ lies in a sub-piece $[n_1,n_2]$, and $m\in[m_1,m_2]$. If the sub-piece passes (B4), Lemma 32 (first bound) gives $\mathbb{E}|L|<T_4$. If it passes (A4), Lemma 32 gives $\mathbb{E}|L|<T_4$ when $b''>0$, and $\mathbb{E}|L|=G_4(c)\le T_4$ with $c=(a_1,sa_2,a_3,a_4)$, $|c|=1$, when $b''=0$.

In the last case with $b''=0$ (so $m'=1$ and $a_4=b'>0$, as $m<1$), equality means $G_4(c)=T_4|c|$. All entries of $c$ are nonzero ($a_1>0$, $a_2\ge|\alpha_{i_0}|=a_3=bm>0$, $a_4>0$), so by Lemma 8 (the alternative $c\parallel e_i+e_j+e_k$ has a zero entry), $c$ is a positive multiple of $\pm(1,1,1,1)$; since $a_1,a_3,a_4>0$, $s=1$ and $a_1=a_2=a_3=a_4=\frac12$, i.e. $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$. ◻

## Five split coordinates

**Lemma 35** (five-coordinate near-sphere bound). *Consider a point with $r<1$, $\beta_{i_0}=+m$ with $m<1$, $M'$ with the coefficient $+m'$ at $\chi_{i_1}$ ($m'=\mu(M')<1$), and $M''$ with the coefficient $+m''$ at $\chi_{i_2}$ ($m''=\mu(M'')$). Let $Y_5=a_1\chi_1+sa_2\chi_2+a_3\chi_{i_0}+a_4\chi_{i_1}+a_5\chi_{i_2}$ with atoms $y_j$ and probabilities $p_j$ ($j=1,\dots,32$), and $r'''=|(a_1,\dots,a_5)|=\sqrt{1-b'''^2}$. Then $$\mathbb{E}|L|\le\mathbb{E}|Y_5|+\sum_jp_j\min\Big(b''',\ \frac{27}{128}\frac{b'''^4E_4'}{|y_j|^3}\Big).$$ If moreover $s=1$, $q\in[q_5,q_4]$, $a_i>0$ and $a_i>q\sum_{l=1}^5a_l$ for $i=1,\dots,5$, all $y_j\ne0$, and $\frac{27}{128}E_4'\,b'''^2(1+r''')\sum_jp_j|y_j|^{-3}<T_4$, then $\mathbb{E}|L|<T_4$ if $b'''>0$, and if $b'''=0$ then $\mathbb{E}|L|=2\tau(1-q)^4\sum_ia_i\le T_4$, with equality if and only if $q=q_5$ and $a_1=\dots=a_5=\frac1{\sqrt5}$.*

*Proof.* If $m''=1$ then $b'''=0$ and $L=Y_5$ (as in Lemma 18(ii), one level deeper: $M''=\chi_{i_2}$). Otherwise peel $M''$ once more: $b''M''=a_5\chi_{i_2}+b'''M'''$ with $M'''=(M'')^\flat$ independent of the five bits of $Y_5$ (7), so $L=Y_5+b'''M'''$; conditioning on the five bits and applying Lemma 27 with $Z=M'''$ gives the first bound. Under the extra hypotheses, Lemma 6 (applied to $(a_1,\dots,a_5)$, as $s=1$) gives $\mathbb{E}|Y_5|=G_5(a)=2\tau(1-q)^4\sum_ia_i\le T_4r'''$, with equality iff $q=q_5$ and $a_1=\dots=a_5$. If $b'''>0$, the hypothesis and $1-r'''=b'''^2/(1+r''')$ give $\mathbb{E}|L|<T_4r'''+T_4(1-r''')=T_4$. If $b'''=0$, then $r'''=1$, $\mathbb{E}|L|=\mathbb{E}|Y_5|\le T_4$, and equality holds iff $q=q_5$ and $a_i=\frac1{\sqrt5}$ for all $i$. ◻

#### Piece tests (A5), (B5).

Let $B$ be a box with $b^->0$ and $[m_1,m_2],[n_1,n_2],[o_1,o_2]\subset(0,1]$. On $B\times[m_1,m_2]\times[n_1,n_2]\times[o_1,o_2]$ (with $m\in[m_1,m_2]$, $m'\in[n_1,n_2]$, $m''\in[o_1,o_2]$, $m,m'<1$) we enclose $a_1,\dots,a_4$ and $b''^2$ as in (A4) (with $(b''^2)^-=(b'^2)^-(1-n_2^2)$), $b''$ by the square roots of the bounds of $b''^2$, $a_5=b''m''\in[b''^-o_1,b''^+o_2]$, $b'''^2\le(b'''^2)^+:=(b''^2)^+(1-o_1^2)$, and $r'''\le r'''^+:=\min\big(1,\sqrt{1-(b''^2)^-(1-o_2^2)}\big)$. The 32 atoms and the products $p_jy_j$ are enclosed as before. Let $a_i^-$ and $a_i^+$ be the lower and upper bounds of $a_i$ and $q^+=\frac1{1+u_1^2}$. The piece passes

- test (A5) if $s=1$, $a_i^->q^+\sum_{l=1}^5a_l^+$ for $i=1,\dots,5$, all $\eta_j>0$, and $\frac{27}{128}E_4'^+(b'''^2)^+(1+r'''^+)\sum_jp_j^+\eta_j^{-3}<T^-(u_1,u_2)$;

- test (B5) if $\sum_j\big(|p_jy_j|^++p_j^+\min\big(b'''^+,\frac{27}{128}((b'''^2)^+)^2E_4'^+/\eta_j^3\big)\big)<T^-(u_1,u_2)$.

In (A5), $\sum_la_l^+>0$ (as $a_1^+>0$), so the first condition also gives $a_i>0$, and it implies $a_i>q\sum_la_l$ at every point. Thus, by Lemma 35: if a piece passes (A5), then at every point with $q\in[q_5,q_4]$ in its range, $\mathbb{E}|L|<T_4$ if $b'''>0$ and $\mathbb{E}|L|\le T_4$ if $b'''=0$, with equality only as in Lemma 35; if it passes (B5), then $\mathbb{E}|L|<T_4$ at every $u\in[u_1,u_2]$ by the first bound alone ($\mathbb{E}|Y_5|=\sum_j|p_jy_j|$), for either sign $s$.

**Definition 36** (inner pieces). Let $B$ be a box with $b^->0$ and sign $s$, $[m_1,m_2]\subset(0,1]$, $X_3=[t_1,t_2]\times[r_1,r_2]\times[m_1,m_2]$, $[n_1,n_2]\subset(0,1]$ and $X_4=X_3\times[n_1,n_2]$.

- A <span class="sans-serif">TC4</span> piece with sign $s_4\in\{1,-1\}$ is a rational cap $\kappa_4\in(0,1]$ with $\kappa_4\ge\min(1,n_2/\sqrt{1-n_2^2})$ and a vertex certificate for $(X_4,(1,s,1,s_4),[u_1,u_2],\kappa_4,-)$.

- A <span class="sans-serif">TC4S</span> piece is: a rational cap $\kappa_4\in(0,1]$ with $\kappa_4\ge\min(1,n_2/\sqrt{1-n_2^2})$; a rational $m_c''$ and a rational $p''^*$ with $2m_c''^2>1$, $\varphi(m_c'')\le p''^*<0$ and $m_c''<\kappa_4$; a vertex certificate $\mathcal D'$ for $(X_4,(1,s,1,1),[u_1,u_2],m_c'',-)$ and a vertex certificate $\mathcal D''$ for $(X_4,(1,s,1,1),[u_1,u_2],\kappa_4,p''^*)$; and sub-pieces $[o_1,o_2]\subset(0,1]$, each passing (A5) or (B5) on $B\times[m_1,m_2]\times[n_1,n_2]\times[o_1,o_2]$, whose union contains $[m_c'',\kappa_4]$.

- An <span class="sans-serif">SG3</span> piece is a rational $p'^*$ with $2n_1^2>1$ and $\varphi(n_1)\le p'^*<0$, a rational cap $\kappa_3\in(0,1]$ with $\kappa_3\ge n_2$ or $\kappa_3\ge\min(1,m_2/\sqrt{1-m_2^2})$, and a vertex certificate for $(X_3,(1,s,1),[u_1,u_2],\kappa_3,p'^*)$.

**Definition 37** (pieces of type <span class="sans-serif">TCN</span>). Let $B$ be a box with $b^->0$, sign $s$, and $[m_1,m_2]\subset(0,1]$. A <span class="sans-serif">TCN</span> piece is: a rational cap $\kappa\in(0,1]$ with $\kappa\ge\min(1,m_2/\sqrt{1-m_2^2})$; a rational $m_c'$ with $0<m_c'<\kappa$; a vertex certificate $\mathcal C'$ for $(X_3,(1,s,1),[u_1,u_2],m_c',-)$; *inner plus pieces* $[n_1,n_2]\subset(0,1]$, each passing (A4) or (B4) on $B\times[m_1,m_2]\times[n_1,n_2]$ or carrying a <span class="sans-serif">TC4</span> piece with $s_4=1$ or a <span class="sans-serif">TC4S</span> piece, whose union contains $[m_c',\kappa]$; and *inner minus pieces* $[n_1,n_2]\subset(0,1]$, each carrying an <span class="sans-serif">SG3</span> piece or a <span class="sans-serif">TC4</span> piece with $s_4=-1$, whose union contains $[m_c',\kappa]$.

**Lemma 38**. *Let $[m_1,m_2]$ carry a <span class="sans-serif">TCN</span> piece for $B$. At every point of $B$ with $r<1$ and $q\in[q_5,q_4]$ whose remainder has $\beta_{i_0}=+m$, $m=\max|\beta_i|\in[m_1,m_2]$, we have $\mathbb{E}|L|\le T_4$. Equality forces $s=1$ and either $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$, or $q=q_5$ and $\alpha=\frac1{\sqrt5}(e_1+e_2+e_{i_0}+e_{i_1}+e_{i_2})$, for some distinct $i_1,i_2\notin\{1,2,i_0\}$.*

*Proof.* If $m=1$: as in Lemma 34, $\mathbb{E}|L|=F_{p_3(t,r,1)}(y)$ for every $y$, and $Z=N^{-1/2}(\chi_1'+\dots+\chi_N')$ with $N^{-1/2}\le m_c'$ is in the class of $\mathcal C'$; so $\mathbb{E}|L|<T_4$.

Let $m<1$. By Lemma 18 ($j=1$), $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,m)}(M')$ and $m'=\mu(M')\le\min(1,m/\sqrt{1-m^2})\le\kappa$.

1.  $m'\le m_c'$: $M'$ is in the class of $\mathcal C'$, and $\mathbb{E}|L|<T_4$ (Lemma 25).

2.  $m'\ge m_c'$, and $M'$ has no coefficient $+m'$, so it has the coefficient $-m'$ at some $\chi_{i_1}$. Then $m'\in[m_c',\kappa]$ lies in an inner minus piece $[n_1,n_2]$.

    - <span class="sans-serif">SG3</span>: by Lemma 13 (with $m_c=n_1\le m'$), $p_3(M')\le\varphi(n_1)\le p'^*$; and $m'\le\kappa_3$, since $m'\le n_2$ and $m'\le\min(1,m_2/\sqrt{1-m_2^2})$. So $M'$ is in the class of the <span class="sans-serif">SG3</span> certificate (patch $p_3$, $\sigma=(1,s,1)$), and $\mathbb{E}|L|<T_4$.

    - <span class="sans-serif">TC4</span> with $s_4=-1$: if $m'<1$, Lemma 18 ($j=2$, $\varsigma_2=-1$) gives $\mathbb{E}|L|=\mathbb{E}F_{p_4(t,r,m,m')}(M'')$ with $\mu(M'')\le\min(1,n_2/\sqrt{1-n_2^2})\le\kappa_4$, so $\mathbb{E}|L|<T_4$ by Lemma 25. If $m'=1$, then $n_2=1$, $\kappa_4=1$, $\mathbb{E}|L|=F_{p_4(t,r,m,1)}(y)$ for every $y$ (Lemma 18(ii)), and $Z=\chi'$ gives $\mathbb{E}|L|<T_4$.

3.  $m'\ge m_c'$ and $M'$ has the coefficient $+m'$ at some $\chi_{i_1}$. Then $m'\in[m_c',\kappa]$ lies in an inner plus piece $[n_1,n_2]$, and $m\in[m_1,m_2]$.

    - (A4) or (B4): Lemma 32 gives $\mathbb{E}|L|<T_4$, except in case (A4) with $b''=0$, where $\mathbb{E}|L|=G_4(a_1,sa_2,a_3,a_4)\le T_4$, with equality only for $s=1$ and $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$ (exactly as in the proof of Lemma 34).

    - <span class="sans-serif">TC4</span> with $s_4=1$: as for $s_4=-1$ above (now $\varsigma_2=+1$), $\mathbb{E}|L|<T_4$.

    - <span class="sans-serif">TC4S</span>: if $m'=1$, then $\mathbb{E}|L|=F_{p_4(t,r,m,1)}(y)$ for every $y$, and $Z=N^{-1/2}(\chi_1'+\dots+\chi_N')$ with $N^{-1/2}\le m_c''$ is in the class of $\mathcal D'$; so $\mathbb{E}|L|<T_4$. If $m'<1$, then $\mathbb{E}|L|=\mathbb{E}F_{p_4(t,r,m,m')}(M'')$ with $m''=\mu(M'')\le\min(1,n_2/\sqrt{1-n_2^2})\le\kappa_4$, and: if $m''\le m_c''$, $M''$ is in the class of $\mathcal D'$; if $m''\ge m_c''$ and $M''$ has no coefficient $+m''$, it has the coefficient $-m''$, so $p_3(M'')\le\varphi(m_c'')\le p''^*$ (Lemma 13) and $M''$ is in the class of $\mathcal D''$; in both cases $\mathbb{E}|L|<T_4$. Otherwise $M''$ has the coefficient $+m''$ at some $\chi_{i_2}$ with $m''\in[m_c'',\kappa_4]$, so $m''$ lies in a sub-piece $[o_1,o_2]$, and Lemma 35 (via (A5) or (B5)) gives $\mathbb{E}|L|<T_4$, except in case (A5) with $b'''=0$, where $\mathbb{E}|L|\le T_4$ with equality only if $q=q_5$ and $a_1=\dots=a_5=\frac1{\sqrt5}$ (and $s=1$, which (A5) requires). In that case $m''=1$, $M''=\chi_{i_2}$, and $\alpha=\frac1{\sqrt5}(e_1+e_2+e_{i_0}+e_{i_1}+e_{i_2})$.

The indices $i_0,i_1,i_2$ are distinct and different from $1,2$, because each peeling removes the peeled coordinate from the remainder. ◻

## The $m$-split boxes

**Definition 39** ($m$-split box). An $m$-split box (kind <span class="sans-serif">ms5</span>) is a box $B$ with sign $s$, $r_2<1$ (so $b^->0$) and $u_1\ge2$, together with: a rational $m_c$ with $0<m_c<\min(1,\bar m(B))$; a vertex certificate $\mathcal C^{(1)}$ for $([t_1,t_2]\times[r_1,r_2],(1,s),[u_1,u_2],m_c,-)$; *plus pieces* $[m_1,m_2]$, each of type (A3), (B3), <span class="sans-serif">TC</span> with $s_3=1$, <span class="sans-serif">TCS</span> or <span class="sans-serif">TCN</span>, whose union contains $[m_c,\min(1,\bar m(B))]$; and *minus pieces* $[m_1,m_2]$, each of type <span class="sans-serif">SG</span> or <span class="sans-serif">TC</span> with $s_3=-1$, whose union contains $[m_c,\min(1,\bar m(B))]$.

**Lemma 40** ($m$-split lemma). *Let $B$ be an $m$-split box. At every point of $B$ with $r<1$ and $q\in[q_5,q_4]$ we have $\mathbb{E}|L|\le T_4$. Equality forces $s=1$ and one of: $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$; or $q=q_4$ and $\alpha=\frac1{\sqrt3}(e_1+e_2+e_{i_0})$; or $q=q_5$ and $\alpha=\frac1{\sqrt5}(e_1+e_2+e_{i_0}+e_{i_1}+e_{i_2})$ (with distinct indices outside $\{1,2\}$).*

*Proof.* Recall $m\le\min(1,\bar m(B))$. If $m\le m_c$, use $\mathcal C^{(1)}$: by Lemmas 18 ($j=0$) and 25, $\mathbb{E}|L|<T_4$. Let $m\ge m_c$. If $\beta_{i_0}=+m$ for some $i_0$, then $m$ lies in a plus piece. A piece (B3) or <span class="sans-serif">TC</span> gives $\mathbb{E}|L|<T_4$ (Lemma 31(i) for <span class="sans-serif">TC</span>). A piece (A3) gives $\mathbb{E}|L|<T_4$ if $b'>0$, and $\mathbb{E}|L|=G_3(a_1,sa_2,b)\le T_4$ if $b'=0$ (i.e. $m=1$); in the latter case equality forces, by Lemma 7, $q=q_4$ and $(a_1,sa_2,b)$ to be a positive multiple of $\pm(1,1,1)$, so $s=1$, $a_1=a_2=b=\frac1{\sqrt3}$ and $\beta=e_{i_0}$. A piece <span class="sans-serif">TCS</span> gives $\mathbb{E}|L|\le T_4$ with equality only as in Lemma 34, and a piece <span class="sans-serif">TCN</span> gives $\mathbb{E}|L|\le T_4$ with equality only as in Lemma 38. Otherwise the maximum $m$ is attained only by negative coefficients, $\beta_{i_0}=-m$, and $m$ lies in a minus piece; Lemma 31 gives $\mathbb{E}|L|<T_4$. ◻

# Computer verification

All scripts and outputs are in the repository (`scripts/`, `outputs/`). Floating point (HiGHS linear programming via scipy, numpy) is used only to *find* certificates. Every *verification* is exact or uses outward-rounded interval arithmetic.

## Data

The list of data files is `outputs/k4_manifest.json` ($U_-=\frac{1589}{625}$, $U_+=\frac{29107}{10000}$, $T_8=\frac{20711}{50000}$, $A_S=\frac{33}{100}$); md5 sums are in `outputs/k4_MD5SUMS.txt`.

- One-coordinate cells: `outputs/k4/one_0.json`, …, `one_3.json` ($u\in[U_-,\frac{66}{25}]$, $[\frac{66}{25},\frac{273}{100}]$, $[\frac{273}{100},\frac{141}{50}]$, $[\frac{141}{50},U_+]$; 256, 257, 300 and 455 cells, all with degree-ten certificates), covering $u\in[U_-,U_+]$ and $a\in[0,\frac{33}{100}]$.

- Two-coordinate boxes: `outputs/k4/p_i.json` ($s=+1$) and `outputs/k4/m_i.json` ($s=-1$) for $i=0,\dots,37$, on the $u$-slabs $[U_-,\frac{255}{100}]$, $[\frac{255}{100},\frac{256}{100}]$, …, $[\frac{290}{100},\frac{291}{100}]$, $[\frac{291}{100},U_+]$. For each sign the boxes cover $[U_-,U_+]\times[0,T_8]\times[\frac{33}{100},1]$. Each file records $K=4$ and $A_S=\frac{33}{100}$. Each box record has its kind and data: <span class="sans-serif">small</span>, <span class="sans-serif">lpv</span> ($n_0$, the vertices and one coefficient vector per vertex), <span class="sans-serif">ncA</span>, and <span class="sans-serif">ms5</span> ($m_c$, $\mathcal C^{(1)}$ and the pieces, with their vertex certificates, caps, $p^*$ values, sub-pieces and, for <span class="sans-serif">TCN</span>, the inner pieces).

| sign   | <span class="sans-serif">lpv</span> | <span class="sans-serif">ncA</span> | <span class="sans-serif">ms5</span> | <span class="sans-serif">small</span> | total |
|:-------|------------------------------------:|------------------------------------:|------------------------------------:|--------------------------------------:|------:|
| $s=+1$ |                               3 327 |                                   0 |                               2 718 |                                     0 | 6 045 |
| $s=-1$ |                               1 216 |                                   0 |                                   0 |                                     0 | 1 216 |

Two-coordinate boxes for Theorem 5. Widths range from $7\cdot10^{-4}$ to $0.01$ in $u$, from $3.2\cdot10^{-3}$ to $0.104$ in $t$ and from $5.2\cdot10^{-3}$ to $0.084$ in $r$. The <span class="sans-serif">ms5</span> boxes use $m_c=\frac12$ (2 194 boxes), $\frac9{20}$ (240), $\frac34$ (104), $\frac45$ (64), $\frac35$ (62), $\frac{17}{20}$ (25), $\frac9{10}$ (18) and $\frac25$ (11). Each has exactly one minus piece (211 <span class="sans-serif">SG</span>, 2 507 <span class="sans-serif">TC</span>) and between one and eight plus pieces (5 467 in total: 101 (A3), 2 681 <span class="sans-serif">TC</span>, 1 438 <span class="sans-serif">TCS</span> and 1 247 <span class="sans-serif">TCN</span>). The <span class="sans-serif">TCS</span> pieces have $m_c'=\frac{17}{20}$ (1 223) or $\frac45$ (215) and 1 999 sub-pieces, all of type (A4). The <span class="sans-serif">TCN</span> pieces have $m_c'=\frac{13}{20}$ (1 193), $\frac35$ (38) or $\frac{11}{20}$ (16), and cap $\kappa=1$ (364) or $\kappa\in[0.681,0.999]$ (883); their inner plus pieces are 534 (A4), 2 479 <span class="sans-serif">TC4</span> and 216 <span class="sans-serif">TC4S</span> (all with $m_c''=\frac{17}{20}$; 383 sub-pieces, all of type (A5)), and their inner minus pieces are 1 247 <span class="sans-serif">TC4</span> and 73 <span class="sans-serif">SG3</span>. In total there are 21 014 vertex certificates (4 543 <span class="sans-serif">lpv</span>, 2 718 $\mathcal C^{(1)}$, 5 188 <span class="sans-serif">TC</span>, 211 <span class="sans-serif">SG</span>, $2\times1\,438$ in <span class="sans-serif">TCS</span>, 1 247 $\mathcal C'$ of <span class="sans-serif">TCN</span>, 3 726 <span class="sans-serif">TC4</span>, $2\times216$ in <span class="sans-serif">TC4S</span>, 73 <span class="sans-serif">SG3</span>) with 171 488 vertices; 7 472 of them have two patch parameters, 9 384 three and 4 158 four. The polynomials of 1 894 vertices have degree $10$, all others degree $6$.

## Generation

`scripts/run_k4.sh` writes the 80 jobs to `outputs/k4/jobs_all.txt` and runs them (7 parallel jobs by default). A two-coordinate job is `RQ_K=4 RQ_AS=33/100 RQ_MSD=5 RQ_TCN=`$\theta$` python3 cover5.py u1 u2 s out.json `$\nu$` 4 8 16`, with $\theta=1$ for the slabs with $u_1\ge\frac{275}{100}$ and $\theta=0$ otherwise, and $\nu=1$ except for the plus slabs in $[\frac{286}{100},\frac{289}{100}]$ ($\nu=4$) and $[\frac{289}{100},\frac{291}{100}]$ ($\nu=8$), just below $u_5$: it bisects $[u_1,u_2]\times[0,T_8]\times[\frac{33}{100},1]$ adaptively ($\nu$ initial $u$-intervals, 4 initial $t$-intervals, 8 $r$-intervals, depth $\le16$) and on each box tries, in order: <span class="sans-serif">small</span>; the near-circle tests (`nearcircle.py`); a vertex certificate (`cert5.py`); from depth 5 on, the $m$-split (`cover5.try_ms5`, with $m_c\in\{\frac9{10},\frac{17}{20},\frac45,\frac34,\frac12,\frac9{20},\frac25,\frac35\}$; plus pieces in the order (A3)/(B3), <span class="sans-serif">TC</span>, <span class="sans-serif">TCS</span> with $m_c'\in\{\frac{17}{20},\frac45,\frac34\}$, and, if $\theta=1$, <span class="sans-serif">TCN</span> with $m_c'\in\{\frac{13}{20},\frac35,\frac{11}{20}\}$, whose inner plus pieces are tried as (A4)/(B4), <span class="sans-serif">TC4</span> and <span class="sans-serif">TC4S</span> with $m_c''\in\{\frac{17}{20},\frac45,\frac34\}$, and whose inner minus pieces are tried as <span class="sans-serif">SG3</span> and <span class="sans-serif">TC4</span>). Vertex sets with two or three patch parameters come from `cert5.py` (as for Theorem 4) and those with four parameters from `cert6.py`: $n_0$ is a rational approximation of the patch point at the centre with $|n_0|\ge1$, the polytope is a box in an exactly orthogonal rational basis of $n_0^\perp$ that contains the gnomonic projection of a $7^k$ (cert5) or $5^k$ (cert6) grid of the patch with a relative margin (none, enlarged to 1%, 4%, 10% and 25% if the cone check fails), and its corners are the vertices. The cone check is the exact test of Lemma 21 (`sphmin.py`; for $K=4$ `cert5.py` uses it as well). The coefficient vectors come from a discretised moment linear program (degree $6$, or $10$ if degree $6$ fails), rounded to rationals and repaired; (W1), (W2) and (P1)–(P4) are checked exactly before a record is accepted. One-coordinate cells come from `cover_lp10.py` (degree-ten certificates). No box or cell failed.

The data were produced on 22 October 2026 between 13:12 and 15:33 UTC on one machine with 8 cores (at most 8 jobs at a time). The two-coordinate jobs took 8.5 hours in total (at most 75 minutes each); the five plus slabs in $[\frac{286}{100},\frac{291}{100}]$ took 40% of this time and produced 2 766 of the 7 261 boxes. These five slabs were first started with $\nu=1$, progressed too slowly and were restarted with the values of $\nu$ above; the jobs unfinished at that moment were restarted with unchanged commands (`outputs/k4/jobs_only*.txt`, `outputs/k4/logs/`).

## Independent verification

`python3 verify_k4.py` re-checks everything from the data files, and all parts pass (output `outputs/verify_k4_ABCDEFG.txt`; 367 seconds on 8 cores, 46 minutes of CPU time). It shares no code with the generators (`cert2c`, `cert4`, `cert5`, `cert6`, `sphmin`, `cover5`, `cover_lp10`, `tenmom`, `nsphere3`, `nearcircle`, `exactcert`, `fourbit`, `bitlemma_k4`). It reuses the generic exact helpers of `verify_k3b.py` (the verifier of Theorem 4: moment polynomials, objective bound, facet normals, atom enclosures, envelopes, cap and $\varphi$ checks, interval coverage) and the Sturm-sequence, integer-square-root and tiling helpers of `verify_all.py` (the verifier of Theorem 1, audited in A.6). Its parts:

1.  Symbolic identities (sympy). Lemma 10: the cumulants of $\chi$, computed from its moments, are $d^{[j\text{ odd}]}G_j(w)$ for $j=3,\dots,10$. Lemma 11: the recursion reproduces the Gaussian moments, and also the moments of $\chi$ at $u=\frac52$, up to order ten.

2.  Coverage (exact). $2\le U_-\le u_4$ (checked as $U_-^2\le3$ or $(U_-^2-3)^2\le12$); $U_+\ge u_5$ (checked as $U_+^2\ge4$ and $(U_+^2-4)^2\ge20$); (3); and $T_8\ge\sqrt2-1$. The cells tile $[U_-,U_+]\times[0,\frac{33}{100}]$. For each sign the boxes tile $[U_-,U_+]\times[0,T_8]\times[\frac{33}{100},1]$: they lie in the region, have pairwise disjoint interiors and total volume equal to the volume of the region (a closed subset of full measure is dense, so it is the whole region). Every <span class="sans-serif">small</span> box satisfies $r_2c(t_1)\le A_S$. Every file has $K=4$ and $A_S=\frac{33}{100}$, and no file lists a failed box.

3.  One-coordinate cells: (V1)–(V3) by Sturm sequences; $\Theta_1>0$; (V4) strictly (Definition 14 re-implemented: the polynomials $\mu_n$ from the recursion, the monomial bounds, and a Sturm count of the roots of $h$ on $[0,\bar m]$ together with $h(0)>0$).

4.  Vertex certificates of every level: all <span class="sans-serif">lpv</span> records, and inside <span class="sans-serif">ms5</span> records $\mathcal C^{(1)}$, <span class="sans-serif">TC</span>, <span class="sans-serif">SG</span>, $\mathcal C'$ and $\mathcal C''$ of <span class="sans-serif">TCS</span>, and inside <span class="sans-serif">TCN</span> pieces $\mathcal C'$, <span class="sans-serif">TC4</span> (both signs), $\mathcal D'$ and $\mathcal D''$ of <span class="sans-serif">TC4S</span>, and <span class="sans-serif">SG3</span>. (P1) and (P2) exactly; (P3) by exact Gaussian elimination (rank $k$ of each facet, normal vector, orientation by the centre); (P4) by the recursion of Lemma 21 as described after it, in an implementation of its own (exact sign decisions, integer square-root bounds, no rounding of intermediate values); (W1) on every linear piece of every vertex envelope (Definition 22, recomputed from the atom enclosures over $[u_1,u_2]$); (W2) strictly with the target $T^-(u_1,u_2)$. The sign vector, caps and $p^*$ values are taken from the structure: $\bar m(B)$ (recomputed exactly) for <span class="sans-serif">lpv</span>, $m_c$ for $\mathcal C^{(1)}$, $m_c'$ for $\mathcal C'$, $m_c''$ for $\mathcal D'$, and the recorded cap $\kappa\in(0,1]$ and the recorded $p^*<0$ for the others.

5.  Near-circle boxes: mpmath interval arithmetic (120 bits), tests (A)/(B) strictly, with $T^-=\min(T_4(u_1),T_4(u_2))$ enclosed in interval arithmetic.

6.  $m$-split structure: $r_2<1$, $u_1\ge2$, $0<m_c<\min(1,\bar m(B))$; the plus pieces and the minus pieces each cover $[m_c,\min(1,\bar m(B))]$; each (A3)/(B3) piece passes its test (mpmath, 120 bits, strict); the cap conditions $\kappa=1$ or $\kappa^2(1-m_2^2)\ge m_2^2$ of <span class="sans-serif">TC</span>, <span class="sans-serif">TCS</span> and <span class="sans-serif">TCN</span>, and the analogous conditions with $n_2$ for <span class="sans-serif">TC4</span> and <span class="sans-serif">TC4S</span>; the $\varphi$ conditions ($0<m\le1$, $2m^2>1$, $p^*<0$, and $p^*\ge\varphi(m)$, checked as $p^*+m^3\ge0$ and $(p^*+m^3)^2\ge(1-m^2)^3$) of <span class="sans-serif">SG</span>, <span class="sans-serif">TCS</span>, <span class="sans-serif">SG3</span> and <span class="sans-serif">TC4S</span>; the cap conditions of <span class="sans-serif">SG</span> ($\kappa\ge\min(m_2,\bar m(B))$) and <span class="sans-serif">SG3</span> ($\kappa_3\ge n_2$ or the cap condition with $m_2$); $0<m_c'<\kappa\le1$ for <span class="sans-serif">TCN</span> and $m_c''<\kappa_4$ for <span class="sans-serif">TC4S</span>; all nested covers (sub-pieces of <span class="sans-serif">TCS</span> and <span class="sans-serif">TC4S</span>, inner plus and minus pieces of <span class="sans-serif">TCN</span>); and each (A4)/(B4) and (A5)/(B5) piece passes its test (mpmath, strict; (A5) includes $s=1$ and the OR-region condition).

7.  The claims (C1) and (C2) of Lemmas 7 and 8, for all $2^8$ and all $2^{16}$ functions, exactly as described there, including the lists of equality cases ($\pm$OR of three bits at $q_4$ only; $\pm$OR of four bits identically; $\pm$OR of three of the four bits at $q_4$ only).

The generator side has its own exact check of the bit lemmas (`scripts/bitlemma_k4.py`, output `outputs/bitlemma_k4.txt`, same result).

#### Negative tests.

`python3 break_tests_k4.py` corrupts random samples of records (seed 11) and runs the check functions of `verify_k4.py` on them (9 seconds; output `outputs/break_tests_k4.txt`). Every corruption below is rejected in every case. On 40 <span class="sans-serif">lpv</span> boxes: lowering the constant term of one vertex polynomial by $\frac1{20}$ (domination fails), raising it by $1$ (the objective bound fails), shrinking the polytope by $10\%$ about its centre (the cone check fails) and moving one vertex by $10^{-6}$ (the hyperplane/parallelepiped check fails). On 25 <span class="sans-serif">ms5</span> boxes: removing one plus piece or one minus piece, and lowering the top of the pieces by $\frac1{100}$ (coverage fails); replacing a <span class="sans-serif">TC</span>/<span class="sans-serif">TCS</span>/<span class="sans-serif">TCN</span> cap by $m_2$ (97 cases; the cap check fails); lowering an <span class="sans-serif">SG</span> value $p^*$ to $\varphi(m_1)-\frac1{100}$ (25 cases); widening an (A4)/(B4) sub-piece from $[n_1,n_2]$ to $[\frac{n_1}2,n_2]$ (25 cases; the near-sphere test fails); lowering the constant term of a <span class="sans-serif">TC</span> vertex polynomial by $\frac1{20}$ (20 cases). On 25 <span class="sans-serif">TCN</span> pieces: removing one inner plus or minus piece, or lowering the inner cut $m_c'$ by $\frac1{50}$ without adding pieces (coverage fails); replacing a <span class="sans-serif">TC4</span>/<span class="sans-serif">TC4S</span> cap by $n_2$ (the cap check fails); lowering the constant term of one nested vertex polynomial ($\mathcal C'$, <span class="sans-serif">TC4</span> or <span class="sans-serif">TC4S</span>) by $\frac1{20}$. On 25 pieces each: lowering an <span class="sans-serif">SG3</span> value to $\varphi(n_1)-\frac1{100}$; widening an (A5)/(B5) sub-piece from $[o_1,o_2]$ to $[\frac{o_1}4,o_2]$ (the near-sphere test fails); re-checking an (A5) sub-piece with $s=-1$ (test (A5) must not pass, since the OR-region identity needs $s=1$). On 40 nested polytopes with three or four patch parameters: shrinking by $\frac12$ about the centre (the cone check fails). Finally, removing one box from the tiling, for each sign. Two sanity checks (not corruptions) hold: on the same 40 <span class="sans-serif">lpv</span> boxes the recomputed cap $\bar m(B)$ is at least $\min(1,a_2/b)$ on the box, and for 20 nested vertex sets the exact facet minima of the cone check are at most the minima of $h\cdot p$ over a $7^k$ sample of the patch and within $10^{-3}|h|_\infty$ of them.

## Reproducing

    pip install numpy scipy sympy mpmath
    cd scripts
    python3 verify_k4.py          # parts A-G, about 6 minutes on 8 cores
    python3 break_tests_k4.py     # negative tests, about 10 seconds
    python3 bitlemma_k4.py        # bit lemmas (generator-side check)
    bash run_k4.sh                # regenerate all data (8.5 job-hours)

# Proof of Theorem 5

*(a)* By Lemma 3 let $q\in[q_5,q_4]$, i.e. $u\in[u_4,u_5]\subseteq[U_-,U_+]$. Reduce $\alpha$ as in Section 2.3.

1.  $a_1=1$: $\alpha=e_1$ and $\mathbb{E}|L|=2\tau<T_4$ (Lemma 4(iii)).

2.  $a_1\le\frac{33}{100}$: $(u,a_1)$ lies in a cell, and Lemma 16 gives $\mathbb{E}|L|<T_4$.

3.  $a_1>\frac{33}{100}$ and $r=1$: $L=a_1\chi_1+sa_2\chi_2$, and Lemma 5 gives $\mathbb{E}|L|<T_4$.

4.  $a_1>\frac{33}{100}$ and $r<1$: $(u,t,r)$ lies in a box of the cover for the sign $s$ (part B), since $t\in[0,\sqrt2-1]\subseteq[0,T_8]$ and $r\ge a_1>\frac{33}{100}$. It is not a <span class="sans-serif">small</span> box, since $a_1>A_S$. If it is <span class="sans-serif">lpv</span>, Lemma 26 gives $\mathbb{E}|L|<T_4$. If it is <span class="sans-serif">ncA</span>, Lemma 28 gives $\mathbb{E}|L|<T_4$. If it is <span class="sans-serif">ms5</span>, Lemma 40 gives $\mathbb{E}|L|\le T_4$.

So $\mathbb{E}|L|\le T_4$ always, and $(e_1+e_2+e_3+e_4)/2$ attains $T_4$ (Lemma 4, $q<\frac14$). Hence $R(q)=T_4(q)$. For $q\in[1-q_4,1-q_5]$ use Lemma 3: $R(q)=R(1-q)=4q^3\tau$.

*(b)* Equality can occur only in the <span class="sans-serif">ms5</span> case of (4). By Lemma 40, after the reduction, $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$, or $q=q_4$ and $\alpha=\frac1{\sqrt3}(e_1+e_2+e_{i_0})$, or $q=q_5$ and $\alpha=\frac1{\sqrt5}(e_1+e_2+e_{i_0}+e_{i_1}+e_{i_2})$. Undoing the reduction (global sign and permutation) gives the list in (b). Conversely, each listed vector attains $T_4$ at the stated $q$ (Lemma 4): $(e_i+e_j+e_k+e_l)/2$ gives $T_4$ for $q<\frac14$; $(e_i+e_j+e_k)/\sqrt3$ gives $T_3=T_4$ at $q_4$; and $(e_{i_1}+\dots+e_{i_5})/\sqrt5$ gives $T_5=T_4$ at $q_5$. For $q\ge\frac12$ use Lemma 3.

*(c)* For $q<q_5<\frac15$, $R(q)\ge\mathbb{E}|\chi_1+\dots+\chi_5|/\sqrt5=T_5(q)>T_4(q)$ by Lemma 4 and (ii). For $q_4<q<\frac13$, $R(q)\ge T_3(q)>T_4(q)$ by Lemma 4 and (i). For $\frac13\le q\le\frac12$, $R(q)\ge\mathbb{E}|\chi_1|=2\tau$, and $2\tau>4(1-q)^3\tau$ because $(1-q)^3\le(\frac23)^3<\frac12$.$\square$

# Remarks

1.  **The $k=4$ regime is closed.** $R(q)=4(1-q)^3\sqrt{q(1-q)}$ holds exactly on $[q_5,q_4]$, which is the largest possible interval (Corollary 1). Both ends are ties: at $q_4$ with $(e_1+e_2+e_3)/\sqrt3$, at $q_5$ with $(e_1+\dots+e_5)/\sqrt5$. Given Theorem 4, Corollary 2 confirms the conjecture $R(q)=2\tau\max_k\sqrt k\,\hat q^{\,k-1}$ (BF3, Stone; RQ-C’s Conjecture S) on $[q_5,1-q_5]$. The next regime, $k=5$ on $[q_6,q_5]$ with $q_6=1-\sqrt{5/6}$, is not treated here.

2.  **Range of the computations.** The boxes and cells cover $u\in[U_-,U_+]$, slightly more than $[u_4,u_5]$. Outside $[u_4,u_5]$ the bit lemmas or the bound $T_5\le T_4$ fail, and tests (A3), (A4), (A5) would claim too much there; this is why the near-sphere lemmas, Lemmas 34, 38 and 40, and the proof of Theorem 5 use the data only for $q\in[q_5,q_4]$.

3.  **Where the method is tight.** The $m$-split is used in 2 718 of the 6 045 boxes with $s=+1$ and in none with $s=-1$. <span class="sans-serif">TCS</span> pieces occur in 684 boxes, all with $u\le2.76$; <span class="sans-serif">TCN</span> pieces occur in 1 124 boxes, all with $u\ge2.75$ (they are enabled only there), and <span class="sans-serif">TC4S</span> pieces, the only place where test (A5) is used, in 96 boxes, all with $u\ge2.83$. The five plus slabs in $[2.86,2.91]$, next to $u_5$, are the most expensive part of the cover (2 766 boxes and 40% of the generation time; see the statistics after Table 1 and `outputs/k4_stats.txt`, written by `scripts/cover_stats5.py`).

4.  **Status.** Not yet audited. The computer steps have been run twice (generator and independent verifier), and the verifier rejects corrupted data (negative tests above).
