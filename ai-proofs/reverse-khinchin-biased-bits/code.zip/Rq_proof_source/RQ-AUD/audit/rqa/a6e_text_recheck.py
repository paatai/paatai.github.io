"""A.6 addendum: check the numbers stated in RQ-A's refereed MAIN_RESULT.tex (6816732f) against the
cover data that A.6 verified (audit/rqa/rqa_data, md5s checked by a40d).

Exact rationals (python-flint fmpq) where the text gives exact values; Arb balls with box
subdivision for the certified lower bounds of Lemma 12's (Q1) and (Q4) quantities.
Own code; nothing of RQ-A's is imported or read.
"""
import glob
import json
import os
from fractions import Fraction

from flint import arb, ctx, fmpq

ctx.prec = 200
DATA = "audit/rqa/rqa_data"
UBAR = fmpq(776887, 500000)
FAILS = []


def Q(s):
    f = Fraction(s)
    return fmpq(f.numerator, f.denominator)


def check(name, cond, detail=""):
    print(("PASS " if cond else "FAIL ") + name + (f": {detail}" if detail else ""))
    if not cond:
        FAILS.append(name)


def rounds_to(x, stated):
    """x (Fraction or float) rounds to the decimal string `stated` at its number of decimals."""
    dec = len(stated.split(".")[1])
    half = Fraction(1, 2 * 10 ** dec)
    return abs(Fraction(x) - Fraction(stated)) <= half


def within_ulp(x, stated):
    dec = len(stated.split(".")[1])
    return abs(Fraction(x) - Fraction(stated)) <= Fraction(1, 10 ** dec)


def range_claim(name, lo, hi, slo, shi):
    """A stated range 'from slo to shi' read as approximate: each end within one unit of its last place."""
    near = rounds_to(lo, slo) and rounds_to(hi, shi)
    encl = Fraction(slo) <= lo and hi <= Fraction(shi)
    check(name, within_ulp(lo, slo) and within_ulp(hi, shi),
          f"true {float(lo):.7f}..{float(hi):.7f}; nearest rounding: {near}; stated range encloses true: {encl}")


def exact_forms(u, t, c4):
    a = 2 * t / (1 + t * t)
    b = (1 - t * t) / (1 + t * t)
    tau = u / (1 + u * u)
    B0 = tau ** 4 * (2 * a - b * (u * u - 1))
    s = tau ** 3 * (b * u * u - a)
    return 4 * c4 * s - B0 * B0, (u - 1 / u) * B0 - 4 * c4


def fq(x):
    return float(x.p) / float(x.q)


def iv(lo, hi):
    return arb(lo).union(arb(hi))


def forms(U, T, c4):
    a = 2 * T / (1 + T * T)
    b = (1 - T * T) / (1 + T * T)
    tau = U / (1 + U * U)
    kap3 = U - 1 / U
    B0 = tau ** 4 * (2 * a - b * (U * U - 1))
    s = tau ** 3 * (b * U * U - a)
    return 4 * c4 * s - B0 * B0, kap3 * B0 - 4 * c4


def lower_over_box(u1, u2, t1, t2, c4, which, n):
    """Certified lower bound of forms(...)[which] over [u1,u2]x[t1,t2] using an n x n split."""
    best = None
    c4a = arb(c4)
    for i in range(n):
        ua, ub = u1 + (u2 - u1) * i / n, u1 + (u2 - u1) * (i + 1) / n
        for j in range(n):
            ta, tb = t1 + (t2 - t1) * j / n, t1 + (t2 - t1) * (j + 1) / n
            lb = forms(iv(ua, ub), iv(ta, tb), c4a)[which].lower()
            if best is None or lb < best:
                best = lb
    return best


def grid_min(u1, u2, t1, t2, c4, which, n=41):
    m = None
    for i in range(n + 1):
        u = arb(u1 + (u2 - u1) * i / n)
        for j in range(n + 1):
            t = arb(t1 + (t2 - t1) * j / n)
            val = float(forms(u, t, arb(c4))[which].mid())
            m = val if m is None else min(m, val)
    return m


def main():
    # Section 2: ubar and u0.
    check("ubar^4 - 2 ubar^2 - 1 > 0", UBAR ** 4 - 2 * UBAR ** 2 - 1 > 0)
    u0 = (1 + arb(2).sqrt()).sqrt()
    check("u0 = sqrt(1+sqrt2) ~ 1.5537740 (7 dp)", rounds_to(Fraction(str(u0.mid().str(30, radius=False))), "1.5537740"),
          u0.str(15))
    check("ubar > u0", arb(UBAR) > u0)

    # Table 1: per-file regions and counts, total 379, width ranges.
    table = {"r1a": (("1", "776887/500000", "0", "4/25"), 94), "r1b": (("1", "776887/500000", "4/25", "8/25"), 59),
             "r1c": (("1", "776887/500000", "8/25", "12/25"), 32), "r1d": (("1", "776887/500000", "12/25", "16/25"), 71),
             "r2a": (("1", "13/10", "77/100", "9/10"), 16), "r2b": (("13/10", "776887/500000", "77/100", "9/10"), 47),
             "r3a": (("1", "13/10", "16/25", "77/100"), 16), "r3b": (("13/10", "611/400", "16/25", "77/100"), 44)}
    cells = {}
    for f in sorted(glob.glob(os.path.join(DATA, "cover", "*.json"))):
        name = os.path.basename(f)[:-5]
        d = json.load(open(f))
        cells[name] = d["cells"]
        reg, cnt = table[name]
        check(f"{name}: region {reg} and {cnt} cells, none failed",
              [Q(x) for x in d["region"]] == [Q(x) for x in reg] and len(d["cells"]) == cnt and len(d["failed"]) == 0,
              f"{len(d['cells'])} cells")
    allc = [c for v in cells.values() for c in v]
    check("total cells 379", len(allc) == 379, str(len(allc)))
    wu = [Fraction(c["u2"]) - Fraction(c["u1"]) for c in allc]
    wa = [Fraction(c["a2"]) - Fraction(c["a1"]) for c in allc]
    for nm, w in (("u", wu), ("a", wa)):
        for lab, val in (("min", min(w)), ("max", max(w))):
            c = next(c for c in allc if Fraction(c[nm + "2"]) - Fraction(c[nm + "1"]) == val)
            print(f"     cell {nm}-width {lab} = {val} = {float(val):.7f} at u [{c['u1']}, {c['u2']}], a [{c['a1']}, {c['a2']}]")
    range_claim("Table 1 caption: cell u-widths 0.0079 to 0.139", min(wu), max(wu), "0.0079", "0.139")
    range_claim("Table 1 caption: cell a-widths 0.0040 to 0.0325", min(wa), max(wa), "0.0040", "0.0325")

    # Appendix: the sample cell of r1d.
    key = ("24583497/16000000", "776887/500000", "63/100", "16/25")
    hit = [c for c in cells["r1d"] if tuple(Q(c[k]) for k in ("u1", "u2", "a1", "a2")) == tuple(Q(x) for x in key)]
    check("sample cell found once in r1d", len(hit) == 1)
    cs = [Q(x) for x in hit[0]["c"]]
    check("sample cell has 7 coefficients", len(cs) == 7)
    check("c1 = 114188429368/981419917709", cs[1] == fmpq(114188429368, 981419917709), str(cs[1]))
    check("c5 = -22338039/10529058835", cs[5] == fmpq(-22338039, 10529058835), str(cs[5]))
    stated = ["0.0281054", "0.1163502", "0.1316753", "0.0212156", "-0.0041259", "-0.0021216", "0.0003276"]
    for k, (c, s) in enumerate(zip(hit[0]["c"], stated)):
        check(f"c{k} ~ {s}", rounds_to(Fraction(c), s), f"{float(Fraction(c)):.10f}")

    # Section 7.2: the quartic cover.
    d = json.load(open(os.path.join(DATA, "quartic_cover.json")))
    boxes = d["boxes"]
    check("Q region [611/400, ubar] x [9/25, 471/1000]",
          [Q(x) for x in d["region"]] == [fmpq(611, 400), UBAR, fmpq(9, 25), fmpq(471, 1000)])
    check("641 boxes, none failed, every c4 > 0",
          len(boxes) == 641 and len(d["failed"]) == 0 and all(Q(b["c4"]) > 0 for b in boxes), str(len(boxes)))
    bu = [Fraction(b["u2"]) - Fraction(b["u1"]) for b in boxes]
    bt = [Fraction(b["t2"]) - Fraction(b["t1"]) for b in boxes]
    range_claim("7.2: box u-widths 0.0008 to 0.0033", min(bu), max(bu), "0.0008", "0.0033")
    range_claim("7.2: box t-widths 0.0017 to 0.0069", min(bt), max(bt), "0.0017", "0.0069")
    a = lambda t: 2 * t / (1 + t * t)
    check("a(9/25) = 225/353 < 16/25", a(fmpq(9, 25)) == fmpq(225, 353) and fmpq(225, 353) < fmpq(16, 25))
    check("a(471/1000) = 942000/1221841 > 77/100",
          a(fmpq(471, 1000)) == fmpq(942000, 1221841) and fmpq(942000, 1221841) > fmpq(77, 100))

    # Appendix: the box containing (u0, sqrt2 - 1).
    t0 = arb(2).sqrt() - 1
    inside = [b for b in boxes if arb(Q(b["u1"])) < u0 < arb(Q(b["u2"])) and arb(Q(b["t1"])) < t0 < arb(Q(b["t2"]))]
    check("exactly one box contains (u0, sqrt2-1) in its interior", len(inside) == 1, str(len(inside)))
    bx = inside[0]
    u1, u2, t1, t2, c4 = (Q(bx[k]) for k in ("u1", "u2", "t1", "t2", "c4"))
    print(f"     box: u [{bx['u1']}, {bx['u2']}], t [{bx['t1']}, {bx['t2']}], c4 = {bx['c4']}")
    check("box u1 ~ 1.5521319, u2 = ubar", rounds_to(Fraction(bx["u1"]), "1.5521319") and u2 == UBAR)
    check("box t1 ~ 0.4120313, t2 ~ 0.4155", rounds_to(Fraction(bx["t1"]), "0.4120313") and rounds_to(Fraction(bx["t2"]), "0.4155"),
          f"t2 = {float(Fraction(bx['t2'])):.10f}")
    check("box c4 ~ 0.0024140", rounds_to(Fraction(bx["c4"]), "0.0024140"), f"{float(Fraction(bx['c4'])):.10f}")
    for which, thr, label in ((0, fmpq(57, 100000), "4 c4 s - B0^2 >= 5.7e-4"), (1, fmpq(62, 10000), "kappa3 B0 - 4 c4 >= 6.2e-3")):
        lb = lower_over_box(u1, u2, t1, t2, c4, which, 64)
        gm = grid_min(u1, u2, t1, t2, c4, which)
        corners = {(nu, nt): exact_forms(uu, tt, c4)[which] for nu, uu in (("u1", u1), ("u2", u2)) for nt, tt in (("t1", t1), ("t2", t2))}
        cmin = min(corners, key=lambda k: fq(corners[k]))
        print(f"     appendix box, {label.split('>=')[0].strip()}: exact corner values "
              + ", ".join(f"{k[0]},{k[1]}: {fq(v):.7e}" for k, v in corners.items()))
        check(f"appendix box: {label} (Arb, 64x64 split; exact corner minimum at {cmin})",
              lb >= arb(thr) and corners[cmin] >= thr,
              f"certified lower {float(lb):.6e}, grid min {gm:.6e}, exact value at corner {cmin} = {fq(corners[cmin]):.7e} "
              f"({'>=' if corners[cmin] >= thr else '<'} {fq(thr):.1e})")

    # Section 7.2: min over all boxes of kappa3 B0 - 4 c4 is stated as 1.77e-3 (their certified lower bound).
    lows, gmins = [], []
    for b in boxes:
        u1, u2, t1, t2, c4 = (Q(b[k]) for k in ("u1", "u2", "t1", "t2", "c4"))
        lows.append(float(lower_over_box(u1, u2, t1, t2, c4, 1, 8)))
        gmins.append(grid_min(u1, u2, t1, t2, c4, 1, n=8))
    i = min(range(len(boxes)), key=lambda k: gmins[k])
    b = boxes[i]
    u1, u2, t1, t2, c4 = (Q(b[k]) for k in ("u1", "u2", "t1", "t2", "c4"))
    corner = min(((uu, tt) for uu in (u1, u2) for tt in (t1, t2)), key=lambda p: fq(exact_forms(p[0], p[1], c4)[1]))
    cval = exact_forms(corner[0], corner[1], c4)[1]
    print(f"     kappa3 B0 - 4 c4: min certified lower (8x8 per box) {min(lows):.6e}; min grid value {min(gmins):.6e} "
          f"at box {i} (u [{b['u1']}, {b['u2']}], t [{b['t1']}, {b['t2']}], c4 = {b['c4']}); "
          f"exact value at its corner ({corner[0]}, {corner[1]}) = {fq(cval):.7e}")
    check("all 641 boxes: kappa3 B0 - 4 c4 > 0 certified (8x8 split)", min(lows) > 0)
    check("7.2: stated minimum certified lower bound 1.77e-3 is <= the exact value at the minimising corner",
          cval >= fmpq(177, 100000), f"{fq(cval):.7e}")
    check("7.2: and is within 1e-5 of it", cval - fmpq(177, 100000) < fmpq(1, 100000), f"gap {fq(cval - fmpq(177, 100000)):.3e}")

    # Section 8 (ii): "sup{E|X| : EX^k = EZ^k, k <= 6} ~ 0.8881 ... below 2 tau exactly when q > 0.27015
    # (the value 0.8880738 equals 2 tau at q = 0.2701496)". G = E|X| for the 4-point Gauss-Hermite law.
    s6 = arb(6).sqrt()
    G = arb(0)
    for sgn in (1, -1):
        x = (3 + sgn * s6).sqrt()
        G += 2 * x * arb(24) / (16 * (x ** 3 - 3 * x) ** 2)
    qstar = (1 - (1 - G * G).sqrt()) / 2
    Gf, qf = Fraction(G.mid().str(40, radius=False)), Fraction(qstar.mid().str(40, radius=False))
    check("G = E|X| (4-point Gauss-Hermite) rounds to 0.8880738 and to 0.8881", rounds_to(Gf, "0.8880738") and rounds_to(Gf, "0.8881"),
          G.str(16))
    check("q* with 2 tau(q*) = G rounds to 0.2701496 and to 0.27015", rounds_to(qf, "0.2701496") and rounds_to(qf, "0.27015"),
          qstar.str(16))

    print("A6E_ALL_CLAIMS_CONFIRMED" if not FAILS else f"A6E_CLAIMS_NOT_CONFIRMED {FAILS}")


if __name__ == "__main__":
    main()
