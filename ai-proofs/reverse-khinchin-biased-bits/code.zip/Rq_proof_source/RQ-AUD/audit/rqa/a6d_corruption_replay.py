"""Replay RQ-A's break_tests corruption set (first 40 cells of r1d, 4 corruptions each) through
the RQ-AUD verifier a6_lemmaS_verify.check_cell, and report which corruptions survive."""
import json, os
from fractions import Fraction as Fr
from a6_lemmaS_verify import check_cell

HERE = os.path.dirname(os.path.abspath(__file__))
d = json.load(open(os.path.join(HERE, 'rqa_data', 'cover', 'r1d.json')))
kinds = [(0, Fr(-1, 10**4), 'c0 decrease 1e-4 rel'), (0, Fr(1, 10), 'c0 increase 10% rel'),
         (2, Fr(-1, 100), 'c2 decrease 1% rel'), (6, Fr(-1, 10**3), 'c6 decrease 0.1% rel')]
tally = {name: [0, 0] for _, _, name in kinds}
for cell in d['cells'][:40]:
    u1, u2, a1, a2 = (Fr(cell[k]) for k in ('u1', 'u2', 'a1', 'a2'))
    for k, delta, name in kinds:
        c = [Fr(x) for x in cell['c']]
        c[k] += delta * max(abs(c[k]), Fr(1, 100))
        ok, _ = check_cell(u1, u2, a1, a2, c)
        tally[name][0] += (not ok); tally[name][1] += 1
tot = sum(v[0] for v in tally.values())
for name, (rej, n) in tally.items():
    print('%-24s rejected %d/%d' % (name, rej, n))
print('total rejected %d/160' % tot)
