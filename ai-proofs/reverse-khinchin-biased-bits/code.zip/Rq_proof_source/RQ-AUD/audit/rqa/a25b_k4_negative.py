"""RQ-AUD negative tests for the MAIN-5 verifier `a25_k4_verify.py`: corrupted copies of RQ-A's records must be
rejected by my check functions (seed 25). Each line reports rejected/total; a corruption that is still accepted is
listed with its reason, and counts as a failure of the test only where the corrupted record is certainly invalid."""
import copy
import json
import os
import random
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import a25_k4_verify as W  # noqa: E402
import a18_k3b_verify as K3B  # noqa: E402
import a11_main2_verify as V  # noqa: E402

RES = []


def report(name, rejected, total, must=True, verb='rejected'):
    ok = rejected == total if must else True
    RES.append(ok)
    print(f"{'PASS' if ok else 'FAIL'} {name}: {verb} {rejected}/{total}" + ("" if must else " (informative)"),
          flush=True)


def jobs_ok(bx):
    jobs, bad = W.vertex_jobs4(bx)
    if bad:
        return False
    return all(W.vjob_check4(j)[0] for j in jobs)


def lpv_job_ok(bx):
    jobs, bad = W.vertex_jobs4(bx)
    return not bad and all(W.vjob_check4(j)[0] for j in jobs)


def shrink(rec, f):
    Vs = [[Fr(x) for x in v] for v in rec['V']]
    cen = [sum(v[i] for v in Vs) / len(Vs) for i in range(len(Vs[0]))]
    rec['V'] = [[str(c + f * (x - c)) for x, c in zip(v, cen)] for v in Vs]


def nested_sets(bx):
    """(path, record, X-dimension) of the vertex sets inside an ms5 box"""
    out = [(('c1',), bx['c1'], 2)]
    for side in ('plus', 'minus'):
        for i, pc in enumerate(bx[side]):
            if pc['type'] in ('TC', 'SG'):
                out.append(((side, i), pc, 3 if pc['type'] == 'TC' else 2))
            elif pc['type'] == 'TCS':
                out += [((side, i, 'c1'), pc['c1'], 3), ((side, i, 'c2'), pc['c2'], 3)]
            elif pc['type'] == 'TCN':
                out.append(((side, i, 'c1'), pc['c1'], 3))
                for s2 in ('plus', 'minus'):
                    for j, ip in enumerate(pc[s2]):
                        if ip['type'] == 'TC4':
                            out.append(((side, i, s2, j), ip, 4))
                        elif ip['type'] == 'SG3':
                            out.append(((side, i, s2, j), ip, 3))
                        elif ip['type'] == 'TC4S':
                            out += [((side, i, s2, j, 'c1'), ip['c1'], 4), ((side, i, s2, j, 'c2'), ip['c2'], 4)]
    return out


def main():
    t0 = time.time()
    rnd = random.Random(25)
    man, cells, boxes = W.load()
    lpv = [bx for bx in boxes if bx['kind'] == 'lpv']
    ms5 = [bx for bx in boxes if bx['kind'] == 'ms5']
    pool = Pool(8)

    # 1. lpv vertex certificates
    sample = rnd.sample(lpv, 40)
    variants = {'constant term -1/20 (domination)': [], 'constant term +1 (objective bound)': [],
                'polytope shrunk 10% about its centre (cone)': [], 'one vertex moved by 1e-6 (hyperplane)': []}
    for bx in sample:
        for name in variants:
            b = copy.deepcopy(bx)
            if name.startswith('constant term -'):
                j = rnd.randrange(len(b['C']))
                b['C'][j][0] = str(Fr(b['C'][j][0]) - Fr(1, 20))
            elif name.startswith('constant term +'):
                j = rnd.randrange(len(b['C']))
                b['C'][j][0] = str(Fr(b['C'][j][0]) + 1)
            elif name.startswith('polytope'):
                shrink(b, Fr(9, 10))
            else:
                j = rnd.randrange(len(b['V']))
                b['V'][j][0] = str(Fr(b['V'][j][0]) + Fr(1, 10**6))
            variants[name].append(b)
    for name, bs in variants.items():
        res = pool.map(lpv_job_ok, bs)
        report('lpv: ' + name, sum(1 for r in res if not r), len(bs))
    res = pool.map(lpv_job_ok, sample)
    report('lpv: the 40 uncorrupted boxes (control)', sum(1 for r in res if r), len(sample), verb='accepted')

    # 2. ms5 structure
    sm = rnd.sample(ms5, 25)
    for name in ('remove one plus piece', 'remove one minus piece', 'lower the top of every piece by 1/100'):
        bad = 0
        for bx in sm:
            b = copy.deepcopy(bx)
            if name == 'remove one plus piece':
                if len(b['plus']) == 1:
                    b['plus'] = []
                else:
                    b['plus'].pop(rnd.randrange(len(b['plus'])))
            elif name == 'remove one minus piece':
                b['minus'].pop(rnd.randrange(len(b['minus'])))
            else:
                for side in ('plus', 'minus'):
                    top = max(Fr(p['m'][1]) for p in b[side])
                    for pc in b[side]:
                        if Fr(pc['m'][1]) == top:
                            pc['m'][1] = str(top - Fr(1, 100))
            bad += not W.ms5_structure4((b,))[0]
        report('ms5: ' + name + ' (coverage)', bad, len(sm))
    caps = [(bx, side, i) for bx in ms5 for side in ('plus', 'minus') for i, pc in enumerate(bx[side])
            if pc['type'] in ('TC', 'TCS', 'TCN') and Fr(pc['m'][1]) < 1]
    pick = rnd.sample(caps, min(100, len(caps)))
    bad = 0
    for bx, side, i in pick:
        b = copy.deepcopy(bx)
        b[side][i]['cap'] = b[side][i]['m'][1]
        bad += bool(W.vertex_jobs4(b)[1])
    report('ms5: TC/TCS/TCN cap replaced by m2 (cap check)', bad, len(pick))
    sgs = [(bx, i) for bx in ms5 for i, pc in enumerate(bx['minus']) if pc['type'] == 'SG']
    pick = rnd.sample(sgs, 25)
    bad = 0
    for bx, i in pick:
        b = copy.deepcopy(bx)
        m1 = Fr(b['minus'][i]['m'][0])
        phi_lo = K3B.sqrt_lo((1 - m1 * m1)**3) - m1**3
        b['minus'][i]['pst'] = str(phi_lo - Fr(1, 100))
        bad += bool(W.vertex_jobs4(b)[1])
    report('ms5: SG value p* lowered to phi(m1) - 1/100 (phi check)', bad, len(pick))
    a4s = [(bx, i, k) for bx in ms5 for i, pc in enumerate(bx['plus']) if pc['type'] == 'TCS'
           for k in range(len(pc['sub']))]
    pick = rnd.sample(a4s, 25)
    bad = 0
    for bx, i, k in pick:
        pc = bx['plus'][i]
        n1, n2 = Fr(pc['sub'][k][0]), Fr(pc['sub'][k][1])
        box = tuple(Fr(x) for x in bx['box'])
        m1, m2 = Fr(pc['m'][0]), Fr(pc['m'][1])
        bad += W.near_n(box, bx['s'], [(m1, m2), (n1 / 2, n2)]) is None
    report('ms5: TCS (A4) sub-piece widened from [n1, n2] to [n1/2, n2] (near-sphere test)', bad, len(pick))
    tcs = [(bx, i) for bx in ms5 for i, pc in enumerate(bx['plus']) if pc['type'] in ('TC', 'TCS')]
    pick = rnd.sample(tcs, 20)
    bs = []
    for bx, i in pick:
        b = copy.deepcopy(bx)
        rec = b['plus'][i] if b['plus'][i]['type'] == 'TC' else b['plus'][i]['c2']
        j = rnd.randrange(len(rec['C']))
        rec['C'][j][0] = str(Fr(rec['C'][j][0]) - Fr(1, 20))
        bs.append(b)
    res = pool.map(jobs_ok, bs)
    report('ms5: constant term of one TC / TCS vertex polynomial lowered by 1/20', sum(1 for r in res if not r), len(bs))

    # 3. TCN pieces
    tcn = [(bx, i) for bx in ms5 for i, pc in enumerate(bx['plus']) if pc['type'] == 'TCN']
    pick = rnd.sample(tcn, 25)
    for name in ('remove one inner plus piece', 'remove one inner minus piece', "lower the inner cut m_c' by 1/50"):
        bad = 0
        for bx, i in pick:
            b = copy.deepcopy(bx)
            pc = b['plus'][i]
            if name == 'remove one inner plus piece':
                pc['plus'].pop(rnd.randrange(len(pc['plus'])))
            elif name == 'remove one inner minus piece':
                pc['minus'].pop(rnd.randrange(len(pc['minus'])))
            else:
                pc['mc'] = str(Fr(pc['mc']) - Fr(1, 50))
            bad += not W.ms5_structure4((b,))[0]
        report('TCN: ' + name + ' (coverage)', bad, len(pick))
    inner = [(bx, i, s2, j) for bx in ms5 for i, pc in enumerate(bx['plus']) if pc['type'] == 'TCN'
             for s2 in ('plus', 'minus') for j, ip in enumerate(pc[s2]) if ip['type'] in ('TC4', 'TC4S')
             and Fr(ip['m'][1]) < 1]
    pick = rnd.sample(inner, min(50, len(inner)))
    bad = 0
    for bx, i, s2, j in pick:
        b = copy.deepcopy(bx)
        b['plus'][i][s2][j]['cap'] = b['plus'][i][s2][j]['m'][1]
        bad += bool(W.vertex_jobs4(b)[1])
    report('TCN: TC4 / TC4S cap replaced by n2 (cap check)', bad, len(pick))
    sg3 = [(bx, i, j) for bx in ms5 for i, pc in enumerate(bx['plus']) if pc['type'] == 'TCN'
           for j, ip in enumerate(pc['minus']) if ip['type'] == 'SG3']
    pick = rnd.sample(sg3, 25)
    bad = 0
    for bx, i, j in pick:
        b = copy.deepcopy(bx)
        n1 = Fr(b['plus'][i]['minus'][j]['m'][0])
        b['plus'][i]['minus'][j]['pst'] = str(K3B.sqrt_lo((1 - n1 * n1)**3) - n1**3 - Fr(1, 100))
        bad += bool(W.vertex_jobs4(b)[1])
    report('TCN: SG3 value lowered to phi(n1) - 1/100 (phi check)', bad, len(pick))
    a5s = [(bx, i, j, k) for bx in ms5 for i, pc in enumerate(bx['plus']) if pc['type'] == 'TCN'
           for j, ip in enumerate(pc['plus']) if ip['type'] == 'TC4S' for k in range(len(ip['sub']))]
    pick = rnd.sample(a5s, 25)
    bad = bad_sign = 0
    for bx, i, j, k in pick:
        pc = bx['plus'][i]
        ip = pc['plus'][j]
        box = tuple(Fr(x) for x in bx['box'])
        lv = [(Fr(pc['m'][0]), Fr(pc['m'][1])), (Fr(ip['m'][0]), Fr(ip['m'][1]))]
        o1, o2 = Fr(ip['sub'][k][0]), Fr(ip['sub'][k][1])
        bad += W.near_n(box, bx['s'], lv + [(o1 / 4, o2)]) is None
        bad_sign += W.near_n(box, -1, lv + [(o1, o2)]) != 'A5'
    report('TC4S: (A5) sub-piece widened from [o1, o2] to [o1/4, o2] (near-sphere test)', bad, len(pick))
    report('TC4S: (A5) sub-piece re-checked with s = -1 does not pass (A5)', bad_sign, len(pick))
    a4n = [(bx, i, j) for bx in ms5 for i, pc in enumerate(bx['plus']) if pc['type'] == 'TCN'
           for j, ip in enumerate(pc['plus']) if ip['type'] == 'A4']
    pick = rnd.sample(a4n, 25)
    bad = 0
    for bx, i, j in pick:
        pc = bx['plus'][i]
        ip = pc['plus'][j]
        box = tuple(Fr(x) for x in bx['box'])
        bad += W.near_n(box, bx['s'], [(Fr(pc['m'][0]), Fr(pc['m'][1])), (Fr(ip['m'][0]) / 2, Fr(ip['m'][1]))]) is None
    report('TCN: (A4) inner piece widened from [n1, n2] to [n1/2, n2] (near-sphere test)', bad, len(pick))
    pick = rnd.sample(tcn, 25)
    bs = []
    for bx, i in pick:
        b = copy.deepcopy(bx)
        pc = b['plus'][i]
        recs = [pc['c1']] + [ip for ip in pc['plus'] + pc['minus'] if ip['type'] == 'TC4'] + \
               [ip[c] for ip in pc['plus'] if ip['type'] == 'TC4S' for c in ('c1', 'c2')]
        rec = rnd.choice(recs)
        jj = rnd.randrange(len(rec['C']))
        rec['C'][jj][0] = str(Fr(rec['C'][jj][0]) - Fr(1, 20))
        bs.append(b)
    res = pool.map(jobs_ok, bs)
    report("TCN: constant term of one nested vertex polynomial (C', TC4 or TC4S) lowered by 1/20",
           sum(1 for r in res if not r), len(bs))

    # 4. nested polytopes with 3 or 4 patch parameters, shrunk by 1/2
    nest = [(bx, path) for bx in ms5 for path, rec, d in nested_sets(bx) if d >= 3]
    pick = rnd.sample(nest, 40)
    bs = []
    dims = {}
    for bx, path in pick:
        b = copy.deepcopy(bx)
        for p, rec, d in nested_sets(b):
            if p == path:
                shrink(rec, Fr(1, 2))
                dims[d] = dims.get(d, 0) + 1
        bs.append(b)
    res = pool.map(jobs_ok, bs)
    report(f'nested vertex sets with 3 or 4 patch parameters ({dims}) shrunk by 1/2 (cone)',
           sum(1 for r in res if not r), len(bs))

    # 5. tiling and one-coordinate cells
    reg3 = (W.U_LO, W.U_HI, Fr(0), W.T8, W.A_S, Fr(1))
    for s in (1, -1):
        bs = [tuple(Fr(x) for x in bx['box']) for bx in boxes if bx['s'] == s]
        bs.pop(rnd.randrange(len(bs)))
        ins, voleq, nov = V.tiling3(reg3, bs)
        report(f'tiling s={s:+d} with one box removed', int(not (ins and voleq and nov == 0)), 1)
    cs = rnd.sample(cells, 30)
    bad = 0
    for u1, u2, a1, a2, c in cs:
        c2 = list(c)
        c2[0] += 1
        bad += not W.cell_once4(u1, u2, a1, a2, c2)[0]
    report('one-coordinate cells: constant term +1 (objective bound)', bad, len(cs))
    bad = 0
    for u1, u2, a1, a2, c in cs:
        bad += not W.cell_once4(u1, u2, max(Fr(0), a1 - (a2 - a1)), a2, c)[0]
    report('one-coordinate cells: a-interval extended downwards by its width (informative)', bad, len(cs), must=False)
    bad = 0
    for u1, u2, a1, a2, c in cs:
        bad += not W.cell_once4(u1, u2, a1, a2 + (a2 - a1), c)[0]
    report('one-coordinate cells: a-interval extended upwards by its width (informative)', bad, len(cs), must=False)
    pool.close()
    print(f"RESULT: {'ALL NEGATIVE TESTS PASSED' if all(RES) else 'SOME CORRUPTION ACCEPTED'} ({time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
