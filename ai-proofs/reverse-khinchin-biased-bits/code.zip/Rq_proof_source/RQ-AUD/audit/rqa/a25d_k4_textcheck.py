"""RQ-AUD text checks for RQ-A's MAIN-5 (MAIN_RESULT_K4, 15:49 version): every statistic quoted in the text,
recomputed from the data files with my own code, and the elementary claims of Lemmas 4-5, Theorem 5(c) and
Corollary 2, checked exactly or in floating point at many points."""
import json
import math
import os
import random
from collections import Counter
from fractions import Fraction as Fr

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'k4_data')
OK = []


def chk(name, cond, detail=''):
    OK.append(bool(cond))
    print(f"{'PASS' if cond else 'FAIL'} {name}" + (f"  [{detail}]" if detail else ''))


def main():
    man = json.load(open(os.path.join(DATA, 'k4_manifest.json')))
    ncell, degs, uw, aw = [], Counter(), [], []
    for fn in man['one_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        ncell.append(len(d['cells']))
        for c in d['cells']:
            degs[len(c['c']) - 1] += 1
            uw.append(float(Fr(c['u2']) - Fr(c['u1'])))
            aw.append(float(Fr(c['a2']) - Fr(c['a1'])))
    chk('cells per file 256, 257, 300, 455; all of degree ten', ncell == [256, 257, 300, 455] and degs == {10: 1268},
        f'{ncell} {dict(degs)}')
    boxes = []
    slabs = Counter()
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        for bx in d['boxes']:
            boxes.append(bx)
            slabs[(d['s'], d['region'][0])] += 1
    kinds = Counter((bx['s'], bx['kind']) for bx in boxes)
    chk('Table 1: s=+1 lpv 3 327, ms5 2 718; s=-1 lpv 1 216, ms5 0; total 7 261',
        kinds == {(1, 'lpv'): 3327, (1, 'ms5'): 2718, (-1, 'lpv'): 1216} and len(boxes) == 7261, str(dict(kinds)))
    W = np.array([[float(Fr(bx['box'][2 * i + 1]) - Fr(bx['box'][2 * i])) for i in range(3)] for bx in boxes])
    lo, hi = W.min(0), W.max(0)
    chk('box widths: u 7e-4..0.01, t 3.2e-3..0.104, r 5.2e-3..0.084 (rounded)',
        abs(lo[0] - 7e-4) < 5e-5 and abs(hi[0] - 0.01) < 5e-4 and abs(lo[1] - 3.2e-3) < 5e-5 and abs(hi[1] - 0.104) < 5e-4
        and abs(lo[2] - 5.2e-3) < 5e-5 and abs(hi[2] - 0.084) < 5e-4, f'min {lo}, max {hi}')
    ms = [bx for bx in boxes if bx['kind'] == 'ms5']
    mc = Counter(bx['mc'] for bx in ms)
    chk('ms5 m_c: 1/2 (2 194), 9/20 (240), 3/4 (104), 4/5 (64), 3/5 (62), 17/20 (25), 9/10 (18), 2/5 (11)',
        mc == {'1/2': 2194, '9/20': 240, '3/4': 104, '4/5': 64, '3/5': 62, '17/20': 25, '9/10': 18, '2/5': 11}, str(dict(mc)))
    nmin = Counter(len(bx['minus']) for bx in ms)
    mint = Counter(pc['type'] for bx in ms for pc in bx['minus'])
    nplus = [len(bx['plus']) for bx in ms]
    plt = Counter(pc['type'] for bx in ms for pc in bx['plus'])
    chk('exactly one minus piece per ms5 box (211 SG, 2 507 TC)', nmin == {1: 2718} and mint == {'SG': 211, 'TC': 2507},
        f'{dict(nmin)} {dict(mint)}')
    chk('1 to 8 plus pieces, 5 467 in total: 101 (A3), 2 681 TC, 1 438 TCS, 1 247 TCN',
        min(nplus) == 1 and max(nplus) == 8 and sum(nplus) == 5467
        and plt == {'A3': 101, 'TC': 2681, 'TCS': 1438, 'TCN': 1247}, f'{min(nplus)}..{max(nplus)}, {sum(nplus)}, {dict(plt)}')
    tcs = [pc for bx in ms for pc in bx['plus'] if pc['type'] == 'TCS']
    tcsm = Counter(pc['mc'] for pc in tcs)
    tcssub = Counter(x[2] for pc in tcs for x in pc['sub'])
    chk("TCS: m_c' = 17/20 (1 223) or 4/5 (215); 1 999 sub-pieces, all (A4)",
        tcsm == {'17/20': 1223, '4/5': 215} and tcssub == {'A4': 1999}, f'{dict(tcsm)} {dict(tcssub)}')
    tcn = [pc for bx in ms for pc in bx['plus'] if pc['type'] == 'TCN']
    tcnm = Counter(pc['mc'] for pc in tcn)
    caps = [Fr(pc['cap']) for pc in tcn]
    c1 = sum(1 for c in caps if c == 1)
    cl = [float(c) for c in caps if c < 1]
    chk("TCN: m_c' = 13/20 (1 193), 3/5 (38), 11/20 (16); cap 1 (364) or in [0.681, 0.999] (883)",
        tcnm == {'13/20': 1193, '3/5': 38, '11/20': 16} and c1 == 364 and len(cl) == 883
        and 0.681 <= min(cl) and max(cl) <= 0.9995, f'{dict(tcnm)}, cap=1: {c1}, others {len(cl)} in [{min(cl):.4f}, {max(cl):.4f}]')
    ip = Counter(x['type'] for pc in tcn for x in pc['plus'])
    im = Counter(x['type'] for pc in tcn for x in pc['minus'])
    t4s = [x for pc in tcn for x in pc['plus'] if x['type'] == 'TC4S']
    t4sm = Counter(x['mc'] for x in t4s)
    t4sub = Counter(y[2] for x in t4s for y in x['sub'])
    chk("TCN inner plus: 534 (A4), 2 479 TC4, 216 TC4S (all m_c'' = 17/20; 383 sub-pieces, all (A5)); inner minus:"
        " 1 247 TC4, 73 SG3",
        ip == {'A4': 534, 'TC4': 2479, 'TC4S': 216} and t4sm == {'17/20': 216} and t4sub == {'A5': 383}
        and im == {'TC4': 1247, 'SG3': 73}, f'{dict(ip)} {dict(t4sm)} {dict(t4sub)} {dict(im)}')

    sets = []

    def add(rec, k):
        sets.append((k, rec))
    for bx in boxes:
        if bx['kind'] == 'lpv':
            add(bx, 2)
            continue
        add(bx['c1'], 2)
        for pc in bx['plus'] + bx['minus']:
            if pc['type'] == 'SG':
                add(pc, 2)
            elif pc['type'] == 'TC':
                add(pc, 3)
            elif pc['type'] == 'TCS':
                add(pc['c1'], 3)
                add(pc['c2'], 3)
            elif pc['type'] == 'TCN':
                add(pc['c1'], 3)
                for x in pc['plus'] + pc['minus']:
                    if x['type'] == 'TC4':
                        add(x, 4)
                    elif x['type'] == 'SG3':
                        add(x, 3)
                    elif x['type'] == 'TC4S':
                        add(x['c1'], 4)
                        add(x['c2'], 4)
    nv = sum(len(r['V']) for _, r in sets)
    byk = Counter(k for k, _ in sets)
    dg = Counter(len(c) - 1 for _, r in sets for c in r['C'])
    chk('21 014 vertex certificates with 171 488 vertices; 7 472 / 9 384 / 4 158 with 2 / 3 / 4 patch parameters',
        len(sets) == 21014 and nv == 171488 and byk == {2: 7472, 3: 9384, 4: 4158}, f'{len(sets)} {nv} {dict(byk)}')
    chk('vertex polynomials: 1 894 of degree 10, all others degree 6', dg == {10: 1894, 6: 171488 - 1894}, str(dict(dg)))
    chk('vertex counts are 2^k (4, 8, 16)', all(len(r['V']) == 2**k for k, r in sets))

    def urange(pred):
        us = [(float(Fr(bx['box'][0])), float(Fr(bx['box'][1]))) for bx in ms if pred(bx)]
        return len(us), (min(a for a, _ in us), max(b for _, b in us)) if us else None
    n1, r1 = urange(lambda bx: any(pc['type'] == 'TCS' for pc in bx['plus']))
    n2, r2 = urange(lambda bx: any(pc['type'] == 'TCN' for pc in bx['plus']))
    n3, r3 = urange(lambda bx: any(x['type'] == 'TC4S' for pc in bx['plus'] if pc['type'] == 'TCN' for x in pc['plus']))
    chk('Remark 3: TCS in 684 boxes with u <= 2.76; TCN in 1 124 boxes with u >= 2.75; TC4S in 96 boxes with u >= 2.83',
        n1 == 684 and r1[1] <= 2.76 + 1e-12 and n2 == 1124 and r2[0] >= 2.75 - 1e-12 and n3 == 96 and r3[0] >= 2.83 - 1e-12,
        f'TCS {n1} {r1}, TCN {n2} {r2}, TC4S {n3} {r3}')
    five = sum(v for (s, u1), v in slabs.items() if s == 1 and 2.86 - 1e-9 <= float(Fr(u1)) < 2.91 - 1e-9)
    chk('the five plus slabs in [2.86, 2.91] contain 2 766 of the 7 261 boxes', five == 2766, str(five))
    chk('ms5 boxes only for s = +1 (none for s = -1)', all(bx['s'] == 1 for bx in ms))

    rnd = random.Random(5)
    worst = 0.0
    for _ in range(20000):
        q = rnd.uniform(0.01, 0.5)
        u = math.sqrt((1 - q) / q)
        v = 1 / u
        tau = math.sqrt(q * (1 - q))
        c, d = rnd.random(), rnd.random()
        for s in (1, -1):
            E = (q * q * abs(c * u + s * d * u) + q * (1 - q) * (abs(c * u - s * d * v) + abs(-c * v + s * d * u))
                 + (1 - q)**2 * abs(-c * v - s * d * v))
            F = 2 * tau * max(c, d, (1 - q) * (c + d) if s == 1 else 0)
            worst = max(worst, abs(E - F))
    chk('Lemma 5: E|c chi1 + s d chi2| = 2 tau max{c, d, [s=1](1-q)(c+d)} (20 000 random (q, c, d), both s)',
        worst < 1e-12, f'max error {worst:.2e}')

    def Tk(k, q):
        return 2 * math.sqrt(k) * (1 - q)**(k - 1) * math.sqrt(q * (1 - q))

    def EOR(k, q):
        u = math.sqrt((1 - q) / q)
        tot = 0.0
        for j in range(k + 1):
            tot += math.comb(k, j) * q**j * (1 - q)**(k - j) * abs(j * u - (k - j) / u)
        return tot / math.sqrt(k)
    q4, q5 = 1 - math.sqrt(3) / 2, 1 - 2 / math.sqrt(5)
    e4 = max(abs(EOR(k, q) - Tk(k, q)) for k in (3, 4, 5) for q in np.linspace(0.02, 1 / k - 1e-3, 300))
    chk('Lemma 4: (e1+..+ek)/sqrt k attains T_k for q < 1/k (k = 3, 4, 5)', e4 < 1e-12, f'max error {e4:.2e}')
    qs = np.linspace(1e-4, 0.5, 20001)
    c1 = all(Tk(5, q) > Tk(4, q) for q in qs if q < q5 - 1e-12)
    c2 = all(Tk(3, q) > Tk(4, q) for q in qs if q4 + 1e-12 < q < 1 / 3)
    c3 = all(2 * math.sqrt(q * (1 - q)) > Tk(4, q) for q in qs if 1 / 3 <= q <= 0.5)
    c4 = all(Tk(4, q) >= max(Tk(k, q) for k in (1, 2, 3, 5, 6, 7, 8, 9, 10)) - 1e-15 for q in qs if q5 <= q <= q4)
    chk('Theorem 5(c): T5 > T4 on (0, q5), T3 > T4 on (q4, 1/3), 2 tau > T4 on [1/3, 1/2] (20 001-point grid)',
        c1 and c2 and c3)
    chk('Corollary 2: T4 = max_k T_k on [q5, q4] (k <= 10, grid; k >= 5 by the decreasing sequence (k/4)(4/5)^(k-4))',
        c4 and all(Fr(k, 4) * Fr(4, 5)**(k - 4) <= 1 for k in range(5, 200)))
    chk('ties: T_3(q4) = T_4(q4) and T_5(q5) = T_4(q5) (since (1-q4)^2 = 3/4 and (1-q5)^2 = 4/5)',
        abs(Tk(3, q4) - Tk(4, q4)) < 1e-15 and abs(Tk(5, q5) - Tk(4, q5)) < 1e-15)
    print(f"RESULT: {'ALL PASS' if all(OK) else 'FAILURES'} ({sum(OK)}/{len(OK)})")


if __name__ == '__main__':
    main()
