"""Second exact method on the whole 08:27 MAIN-2 cover: sympy Sturm counts replace the Arb root isolation of
a11_main2_verify_v2.py for every LP box, every one-coordinate cell and every m-split box (c1 and c2 domination,
moment bounds with and without p*; the pieces involve no polynomial root isolation)."""
import json
import os
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
import a11_main2_verify_v2 as W  # noqa: E402
import a11b_main2_negative as N  # noqa: E402
import a9_c11_verify as C9  # noqa: E402

V = W.V


def patch():
    V.positive_on = N.sturm_positive_on
    W.positive_on = N.sturm_positive_on
    C9.positive_on = N.sturm_positive_on


def lp_job(args):
    patch()
    return V.lp_once(*args)[0]


def cell_job(args):
    patch()
    return C9.check_cell_T(*args)[0]


def ms_job(args):
    patch()
    return W.ms_check(args)[0]


if __name__ == '__main__':
    t0 = time.time()
    man = json.load(open(os.path.join(W.D_NEW, 'k2_manifest.json')))
    lps, mss, cells = [], [], []
    for fn in man['two_files']:
        d = json.load(open(W.path_of(fn)))
        for bx in d['boxes']:
            box = tuple(Fr(x) for x in bx['box'])
            if bx['kind'] == 'lp':
                lps.append((box, d['s'], [Fr(x) for x in bx['c']], V.R2_MINE))
            elif bx['kind'] == 'ms':
                mss.append((box, d['s'], bx))
    for fn in man['one_files']:
        for cl in json.load(open(W.path_of(fn)))['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']], V.R2_MINE))
    with Pool(8) as pool:
        r1 = pool.map(lp_job, lps, chunksize=32)
        r2 = pool.map(cell_job, cells, chunksize=4)
        r3 = pool.map(ms_job, mss, chunksize=8)
    print(f"Sturm (sympy count_roots) re-check of the 08:27 cover, depth 0: LP boxes {sum(1 for r in r1 if not r)} failures"
          f" / {len(r1)}; one-coordinate cells {sum(1 for r in r2 if not r)} failures / {len(r2)}; m-split boxes"
          f" {sum(1 for r in r3 if not r)} failures / {len(r3)} ({time.time() - t0:.0f}s)")
