"""RQ-AUD independent verifier for RQ-A's k3b cover (u in [12/5, 127123/50000], the k = 3 gap [q4, 25/169]):
    E|sum alpha_i chi_i| <= T = 2 sqrt3 (1-q)^2 tau  for every unit alpha and every q in [q4, 25/169],
which with MAIN-3 (A.14) would give R(q) = T(q) on the whole k = 3 regime [q4, q3].

RQ-A code is not used. The k-independent helpers are my own (A.6, A.11, A.14: tilings, positivity, the 1-coordinate
cell envelope, the near-circle test, the three-coordinate near-sphere test). New here, each derived from the
hypotheses and written for this audit:
 - ten-moment objective bound: E P(M) = sum_mu L_mu(c) prod kappa_j * prod p_j (moment polynomials and cumulants
   from audit/common/moments10.py, each derived twice), with rho = sqrt(p4) in [0, cap]:
   |p3| <= rho (Cauchy-Schwarz), p4 = rho^2, |p_j| <= cap^(j-4) rho^2 (j >= 5), p_j >= rho^(j-2) (j even, log-
   convexity of l^p norms with p2 = 1); termwise sup; optional p3 <= p* < 0 for the linear p3 term;
 - vertex certificates: V_j . n0 = |n0|^2 >= 1, V a parallelepiped, patch inside the cone (dual functionals of the
   parallelepiped, exact interval bisection), and for every vertex: P_j > envelope over u of F(V_j; .) on R and
   sup_M E P_j(M) < T^-(u1, u2) (caps derived here, not read from the record where avoidable);
 - four-coordinate near-sphere pieces (A4 / B4) in exact rational interval arithmetic;
 - four-bit lemma 12(1-q)^4 - sum_i Delta_i(f)^2 >= 0 on [q4, 25/169] for all 2^16 f, with the irrational endpoint
   q4 = 1 - sqrt3/2 handled exactly (division by its minimal polynomial 4q^2 - 8q + 1);
 - three-bit lemma on [1/(1+U_HI^2), 25/169].
Parts: M md5s, A elementary facts, B tilings, C one-coordinate cells, D vertex certificates, E near-circle boxes,
F m-split structure and near-sphere pieces, G three- and four-bit lemmas.
"""
import hashlib
import json
import os
import sys
import time
from fractions import Fraction as Fr
from itertools import product
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import a11_main2_verify as V  # noqa: E402
import a14_main3_verify as K3  # noqa: E402
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo, tiles  # noqa: E402
from moments10 import KAP, MOM, leval  # noqa: E402

DATA = os.environ.get('K3B_DATA', os.path.join(HERE, 'k3b_data'))
U_LO, U_HI, T8, A_S = Fr(12, 5), Fr(127123, 50000), Fr(41422, 100000), Fr(7, 20)
S3 = K3.S3_MINE
K27 = Fr(27, 128)
NJ = 10
ZERO = (0,) * (len(next(iter(MOM[3]))))


def T_lo(u1, u2):
    return K3.T3_lo(u1, u2, S3)


def iadd(a, b):
    return (a[0] + b[0], a[1] + b[1])


def imulI(a, b):
    xs = (a[0] * b[0], a[0] * b[1], a[1] * b[0], a[1] * b[1])
    return (min(xs), max(xs))


def iscale(a, c):
    x, y = a[0] * c, a[1] * c
    return (min(x, y), max(x, y))


def iabs_lo(a):
    if a[0] > 0:
        return a[0]
    if a[1] < 0:
        return -a[1]
    return Fr(0)


def kap_iv(j, u1, u2):
    """kappa_j on [u1, u2]; kappa_j is monotone on [U_LO, U_HI] (part A), so the endpoint values bound it"""
    a, b = leval(KAP[j], u1), leval(KAP[j], u2)
    return (min(a, b), max(a, b))


# ---------------------------------------------------------------- ten-moment objective bound
def objective_ok(c, u1, u2, cap, T, p3max=None):
    """T - sup E P(M) > 0 over residuals M with max|beta_i| <= cap (and p3 <= p3max < 0 if given), u in [u1, u2]"""
    if not (0 < cap <= 1):
        return False, "cap"
    const, B = objective_poly(c, u1, u2, cap, p3max)
    top = max(B) if B else 0
    coeffs = [T - const] + [-B.get(k, Fr(0)) for k in range(1, top + 1)]
    if coeffs[0] <= 0:
        return False, "T <= Gaussian part"
    ok, why = positive_on(coeffs, lo=Fr(0), hi=cap)
    return ok, ("" if ok else "objective: " + why)


def objective_poly(c, u1, u2, cap, p3max=None):
    """(const, {k: B_k}) with E P(M) <= const + sum_k B_k rho^k for every admissible M, rho = sqrt(p4)"""
    D = len(c) - 1
    assert D <= NJ
    poly = {}
    for n, cn in enumerate(c):
        if cn == 0:
            continue
        for e, co in MOM[n].items():
            poly[e] = poly.get(e, Fr(0)) + cn * co
    kI = {j: kap_iv(j, u1, u2) for j in range(3, D + 1)}
    const = poly.pop(ZERO, Fr(0))
    B = {}
    for e, L in poly.items():
        if L == 0:
            continue
        A = (L, L)
        deg_hi, deg_lo, cabs, has_odd, even = 0, 0, Fr(1), False, True
        for j, ej in enumerate(e, start=3):
            if ej == 0:
                continue
            for _ in range(ej):
                A = imulI(A, kI[j])
            deg_hi += ej * (1 if j == 3 else 2)
            deg_lo += ej * (j - 2)
            if j >= 5:
                cabs *= cap**((j - 4) * ej)
            if j % 2 == 1:
                has_odd = True
                if ej % 2 == 1:
                    even = False
        if p3max is not None and e == (1,) + ZERO[1:] and A[0] >= 0:
            const += A[0] * p3max
            continue
        if even:
            if A[1] >= 0:
                B[deg_hi] = B.get(deg_hi, Fr(0)) + A[1] * cabs
            elif not has_odd:
                B[deg_lo] = B.get(deg_lo, Fr(0)) + A[1]
        else:
            B[deg_hi] = B.get(deg_hi, Fr(0)) + max(abs(A[0]), abs(A[1])) * cabs
    return const, B


# ---------------------------------------------------------------- C: one-coordinate cells, degree <= 10
def cell_once(u1, u2, a1, a2, c):
    bh = sqrt_hi(1 - a1 * a1)
    s1 = u2 * u2 / (1 + u2 * u2)
    s2 = 1 / (1 + u1 * u1)
    P = list(c)
    ok, why = positive_on(P)
    if not ok:
        return False, "P > 0: " + why
    ok, why = positive_on([P[0] + s1 * a1 / u2, P[1] - s1 * bh] + P[2:], lo=(a1 / u2) / bh)
    if not ok:
        return False, "P > l1: " + why
    ok, why = positive_on([P[0] + s2 * a1 * u1, P[1] + s2 * bh] + P[2:], hi=-(a1 * u1) / bh)
    if not ok:
        return False, "P > l2: " + why
    b2 = sqrt_lo(1 - a2 * a2)
    mh = min(Fr(1), a2 / b2)
    T = K3.theta1(u1, u2, a2, S3)
    if T <= 0:
        return False, "Theta1 <= 0"
    return objective_ok(c, u1, u2, mh, T)


def cell_job(args):
    return cell_once(*args)


# ---------------------------------------------------------------- D: vertex certificates
def dot(a, b):
    return sum(x * y for x, y in zip(a, b))


def mat_inv(G):
    n = len(G)
    A = [list(G[i]) + [Fr(int(i == j)) for j in range(n)] for i in range(n)]
    for col in range(n):
        piv = next((r for r in range(col, n) if A[r][col] != 0), None)
        if piv is None:
            return None
        A[col], A[piv] = A[piv], A[col]
        pv = A[col][col]
        A[col] = [x / pv for x in A[col]]
        for r in range(n):
            if r != col and A[r][col] != 0:
                f = A[r][col]
                A[r] = [x - f * y for x, y in zip(A[r], A[col])]
    return [row[n:] for row in A]


def cone_functionals(n0, Vs):
    """h with: p.h >= 0 for all h (and p.n0 > 0)  =>  p = sum nu_j V_j, nu_j >= 0, sum nu_j = p.n0/|n0|^2"""
    d = len(n0)
    k = d - 1
    nn = dot(n0, n0)
    if nn < 1:
        return None, "|n0| < 1"
    if any(dot(v, n0) != nn for v in Vs):
        return None, "V.n0 != |n0|^2"
    bits = list(product((0, 1), repeat=k))
    if len(Vs) != len(bits) or any(len(v) != d for v in Vs):
        return None, "vertex count"
    E = []
    for i in range(k):
        idx = bits.index(tuple(int(l == i) for l in range(k)))
        E.append([x - y for x, y in zip(Vs[idx], Vs[0])])
    for idx, bt in enumerate(bits):
        exp = [Vs[0][x] + sum(bt[i] * E[i][x] for i in range(k)) for x in range(d)]
        if exp != list(Vs[idx]):
            return None, "not a parallelepiped"
    Gi = mat_inv([[dot(E[i], E[l]) for l in range(k)] for i in range(k)])
    if Gi is None:
        return None, "degenerate"
    H = []
    for i in range(k):
        g = [sum(Gi[i][l] * E[l][x] for l in range(k)) for x in range(d)]
        gv = dot(g, Vs[0])
        h1 = [g[x] - gv * n0[x] / nn for x in range(d)]
        h2 = [n0[x] / nn - h1[x] for x in range(d)]
        H += [h1, h2]
    return H, ""


def patch_iv(X):
    (t1, t2), (r1, r2) = X[0], X[1]
    c = (V.cfun(t2), V.cfun(t1))
    dd = (V.dfun(t1), V.dfun(t2))
    b = (sqrt_lo(1 - r2 * r2) if r2 < 1 else Fr(0), sqrt_hi(1 - r1 * r1))
    out = [(r1 * c[0], r2 * c[1]), (r1 * dd[0], r2 * dd[1])]
    if len(X) == 2:
        return out + [b]
    m1, m2 = X[2]
    sm = (sqrt_lo(1 - m2 * m2) if m2 < 1 else Fr(0), sqrt_hi(1 - m1 * m1))
    return out + [(b[0] * m1, b[1] * m2), (b[0] * sm[0], b[1] * sm[1])]


def lin_lo(h, P):
    return sum(hx * (p[0] if hx >= 0 else p[1]) for hx, p in zip(h, P))


def sin_min_t(h0, h1, t1, t2):
    """lower bound of g(t) = h0 c(t) + h1 d(t) on [t1, t2] in [0, 1] (g = A cos(theta - phi), t = tan(theta/2));
    g'(t) = -2 Q(t)/(1+t^2)^2 with Q = h1 t^2 + 2 h0 t - h1, an interior minimum iff Q changes sign from + to -"""
    g = lambda t: h0 * V.cfun(t) + h1 * V.dfun(t)
    lo = min(g(t1), g(t2))
    Q = lambda t: h1 * t * t + 2 * h0 * t - h1
    if Q(t1) > 0 > Q(t2):
        lo = min(lo, -sqrt_hi(h0 * h0 + h1 * h1))
    return lo


def sin_min_m(h2, h3, m1, m2):
    """lower bound of k(m) = h2 m + h3 sqrt(1-m^2) on [m1, m2] in [0, 1]; k is concave if h3 >= 0, convex if h3 < 0,
    with interior critical point m*^2 = h2^2/(h2^2+h3^2) (needs h2 < 0 when h3 < 0), value -sqrt(h2^2+h3^2)"""
    def k_lo(m):
        s2 = 1 - m * m
        s = (sqrt_lo(s2) if h3 >= 0 else sqrt_hi(s2)) if s2 > 0 else Fr(0)
        return h2 * m + h3 * s
    lo = min(k_lo(m1), k_lo(m2))
    if h3 < 0 and h2 < 0:
        ms2 = h2 * h2 / (h2 * h2 + h3 * h3)
        if m1 * m1 <= ms2 <= m2 * m2:
            lo = min(lo, -sqrt_hi(h2 * h2 + h3 * h3))
    return lo


def patch_dot_lo(h, box):
    """exact-up-to-rounding lower bound of h . p over the patch box: h.p = r g(t) + b k(m) with r, b >= 0, so the
    minimum separates: g_min over t, k_min over m, then f(r) = r g_min + k_min sqrt(1-r^2) over [r1, r2]
    (concave if k_min >= 0; convex if k_min < 0, interior minimum -sqrt(g^2+k^2) at r*^2 = g^2/(g^2+k^2) if g < 0)"""
    (t1, t2), (r1, r2) = box[0], box[1]
    g = sin_min_t(h[0], h[1], t1, t2)
    k = h[2] if len(box) == 2 else sin_min_m(h[2], h[3], box[2][0], box[2][1])

    def f_lo(r):
        s2 = 1 - r * r
        s = (sqrt_lo(s2) if k >= 0 else sqrt_hi(s2)) if s2 > 0 else Fr(0)
        return g * r + k * s
    lo = min(f_lo(r1), f_lo(r2))
    if k < 0 and g < 0:
        rs2 = g * g / (g * g + k * k)
        if r1 * r1 <= rs2 <= r2 * r2:
            lo = min(lo, -sqrt_hi(g * g + k * k))
    return lo


def cone_contains(X, H, n0, max_boxes=64):
    assert 0 <= X[0][0] <= X[0][1] <= 1 and 0 <= X[1][0] <= X[1][1] <= 1
    stack, used = [tuple(X)], 0
    while stack:
        box = stack.pop()
        used += 1
        if used > max_boxes:
            return False, used
        if patch_dot_lo(n0, box) > 0 and all(patch_dot_lo(h, box) >= 0 for h in H):
            continue
        w = [b - a for a, b in box]
        i = max(range(len(box)), key=lambda k: w[k])
        if w[i] == 0:
            return False, used
        mid = (box[i][0] + box[i][1]) / 2
        for half in ((box[i][0], mid), (mid, box[i][1])):
            nb = list(box)
            nb[i] = half
            stack.append(tuple(nb))
    return True, used


def vatoms(u1, u2, coefs):
    """for sum_i coefs_i chi_i, u in [u1, u2]: intervals of p_j y_j and of p_j over the 2^k atoms"""
    q = (1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    qb = (1 - q[1], 1 - q[0])
    tau = (u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))
    k = len(coefs)
    X, Pj = [], []
    for e in product((1, 0), repeat=k):
        w = [q if ei else qb for ei in e]
        p = (Fr(1), Fr(1))
        for x in w:
            p = (p[0] * x[0], p[1] * x[1])
        xs = (Fr(0), Fr(0))
        for i in range(k):
            oth = (Fr(1), Fr(1))
            for l in range(k):
                if l != i:
                    oth = (oth[0] * w[l][0], oth[1] * w[l][1])
            t = (oth[0] * tau[0], oth[1] * tau[1])
            xs = iadd(xs, iscale(t, coefs[i] if e[i] else -coefs[i]))
        X.append(xs)
        Pj.append(p)
    return X, Pj


def env_pieces(X, B):
    n = len(X)
    z = [(-X[j][0] - X[j][1]) / (B[j][0] + B[j][1]) for j in range(n)]
    pts = sorted(set(z + [Fr(0)]))
    ivs = [(None, pts[0])] + [(pts[i], pts[i + 1]) for i in range(len(pts) - 1)] + [(pts[-1], None)]
    out = []
    for lo, hi in ivs:
        y = hi - 1 if lo is None else (lo + 1 if hi is None else (lo + hi) / 2)
        right = y > 0
        icpt = slope = Fr(0)
        for j in range(n):
            if y > z[j]:
                icpt += X[j][1]
                slope += B[j][1] if right else B[j][0]
            else:
                icpt -= X[j][0]
                slope -= B[j][0] if right else B[j][1]
        out.append((lo, hi, icpt, slope))
    return out


def vertex_ok(c, v, s, s3, u1, u2, cap, T, p3max):
    coefs = [v[0], v[1] if s == 1 else -v[1]] + ([v[2] if s3 == 1 else -v[2]] if len(v) == 4 else [])
    last = v[-1]
    X, Pj = vatoms(u1, u2, coefs)
    if last == 0:
        K = sum(max(abs(x[0]), abs(x[1])) for x in X)
        ok, why = positive_on([c[0] - K] + list(c[1:]))
        if not ok:
            return False, "dom (b = 0): " + why
    else:
        # F(V; y) = sum_j |X_j + p_j last y|; for last < 0 work in y' = -y, where P becomes sum c_n (-1)^n y'^n
        al = abs(last)
        B = [(p[0] * al, p[1] * al) for p in Pj]
        cc = list(c) if last > 0 else [cn if n % 2 == 0 else -cn for n, cn in enumerate(c)]
        for lo, hi, icpt, slope in env_pieces(X, B):
            ok, why = positive_on([cc[0] - icpt, cc[1] - slope] + cc[2:], lo=lo, hi=hi)
            if not ok:
                return False, "dom: " + why
    return objective_ok(c, u1, u2, cap, T, p3max)


def cap_after(m2, cap):
    """cap is a valid bound for the normalised remainder after removing a coefficient of relative size <= m2"""
    return cap >= 1 or (cap > 0 and cap * cap * (1 - m2 * m2) >= m2 * m2)


def phi_ok(pst, m):
    """pst < 0 and pst >= phi(m) = (1-m^2)^(3/2) - m^3, valid bound p3 <= phi(m') for m' >= m >= 1/sqrt2"""
    if not (0 < m <= 1 and 2 * m * m > 1 and pst < 0):
        return False
    rhs = pst + m**3
    return rhs >= 0 and rhs * rhs >= (1 - m * m)**3


def vertex_jobs(bx):
    box = tuple(Fr(x) for x in bx['box'])
    s = bx['s']
    u1, u2, t1, t2, r1, r2 = box
    blo, _ = V.b_range(r1, r2)
    mb = V.mbar_of(t2, r2, blo)
    X2 = ((t1, t2), (r1, r2))
    jobs, bad = [], []
    if bx['kind'] == 'lpv':
        return [('lpv', bx, X2, s, 1, box, mb, None)], bad
    mc = Fr(bx['mc'])
    jobs.append(('c1', bx['c1'], X2, s, 1, box, min(mc, mb), None))
    for side, s3 in (('plus', 1), ('minus', -1)):
        for pc in bx[side]:
            m1, m2 = Fr(pc['m'][0]), Fr(pc['m'][1])
            X3 = X2 + ((m1, m2),)
            tp = pc['type']
            if tp == 'SG':
                if side != 'minus' or not phi_ok(Fr(pc['pst']), m1):
                    bad.append('SG phi')
                jobs.append(('SG', pc, X2, s, 1, box, min(m2, mb), Fr(pc['pst'])))
            elif tp == 'TC':
                cap = Fr(pc['cap'])
                if not cap_after(m2, cap):
                    bad.append('TC cap')
                jobs.append(('TC', pc, X3, s, s3, box, min(cap, Fr(1)), None))
            elif tp == 'TCS':
                cap, mc2, pst = Fr(pc['cap']), Fr(pc['mc']), Fr(pc['pst'])
                if side != 'plus' or not cap_after(m2, cap) or not phi_ok(pst, mc2):
                    bad.append('TCS cap/phi')
                jobs.append(('TCS1', pc['c1'], X3, s, s3, box, min(mc2, Fr(1)), None))
                jobs.append(('TCS2', pc['c2'], X3, s, s3, box, min(cap, Fr(1)), pst))
    return jobs, bad


def vjob_check(job):
    name, rec, X, s, s3, box, cap, p3max = job
    u1, u2 = box[0], box[1]
    n0 = [Fr(x) for x in rec['n0']]
    Vs = [[Fr(x) for x in v] for v in rec['V']]
    Cs = [[Fr(x) for x in cc] for cc in rec['C']]
    if len(Vs[0]) != len(X) + 1 or len(Cs) != len(Vs):
        return False, name + " shape", 0
    H, why = cone_functionals(n0, Vs)
    if H is None:
        return False, name + " " + why, 0
    ok, used = cone_contains(X, H, n0)
    if not ok:
        return False, f"{name} cone ({used} sub-boxes)", used
    T = T_lo(u1, u2)
    for v, c in zip(Vs, Cs):
        ok, why = vertex_ok(c, v, s, s3, u1, u2, cap, T, p3max)
        if not ok:
            return False, f"{name} {why}", used
    return True, name, used


# ---------------------------------------------------------------- F: m-split structure, A4 / B4 pieces
def near4(box, s, m1, m2, n1, n2):
    """four coordinates: alpha_3 = b m (m in [m1, m2], sign +), alpha_4 = + b' n (n in [n1, n2]), L = Y4 + b'' M''"""
    u1, u2, t1, t2, r1, r2 = box
    T = T_lo(u1, u2)
    blo, bhi = V.b_range(r1, r2)
    if blo <= 0:
        return None
    a1 = (r1 * V.cfun(t2), r2 * V.cfun(t1))
    a2 = (r1 * V.dfun(t1), r2 * V.dfun(t2))
    a3 = (blo * m1, bhi * m2)
    bp2 = (blo * blo * (1 - m2 * m2), bhi * bhi * (1 - m1 * m1))
    bp = (sqrt_lo(bp2[0]), sqrt_hi(bp2[1]))
    a4 = (bp[0] * n1, bp[1] * n2)
    bq2 = (bp2[0] * (1 - n2 * n2), bp2[1] * (1 - n1 * n1))
    bq = sqrt_hi(bq2[1])
    rq = min(Fr(1), sqrt_hi(1 - bq2[0]))
    E4 = 3 + max(Fr(0), u2 * u2 + 1 / (u2 * u2) - 4)
    coefs = [a1, a2 if s == 1 else (-a2[1], -a2[0]), a3, a4]
    U, Vn = (u1, u2), (-1 / u1, -1 / u2)
    q = (1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    qb = (1 - q[1], 1 - q[0])
    tau = (u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))
    atoms = []
    for e in product((1, 0), repeat=4):
        w = [q if ei else qb for ei in e]
        p = Fr(1)
        for x in w:
            p *= x[1]
        y = (Fr(0), Fr(0))
        py = (Fr(0), Fr(0))
        for i in range(4):
            y = iadd(y, imulI(coefs[i], U if e[i] else Vn))
            oth = (Fr(1), Fr(1))
            for l in range(4):
                if l != i:
                    oth = (oth[0] * w[l][0], oth[1] * w[l][1])
            t = (oth[0] * tau[0], oth[1] * tau[1]) if e[i] else (-oth[1] * tau[1], -oth[0] * tau[0])
            py = iadd(py, imulI(coefs[i], t))
        atoms.append((p, iabs_lo(y), max(abs(py[0]), abs(py[1]))))
    if all(yl > 0 for _, yl, _ in atoms):
        S = sum(p / yl**3 for p, yl, _ in atoms)
        if K27 * E4 * bq2[1] * (1 + rq) * S < T:
            return "A4"
    tot = Fr(0)
    for p, yl, apy in atoms:
        e = bq if yl == 0 else min(bq, K27 * bq2[1] * bq2[1] * E4 / yl**3)
        tot += apy + p * e
    return "B4" if tot < T else None


def covers(pieces, lo, hi):
    cur = lo
    for a, b in sorted(pieces):
        if not (0 < a < b <= 1) or a > cur:
            return False
        cur = max(cur, b)
    return cur >= hi


def ms5_structure(args):
    bx, = args
    box = tuple(Fr(x) for x in bx['box'])
    s = bx['s']
    u1, u2, t1, t2, r1, r2 = box
    if not u1 * u1 > 2:
        return False, "u1^2 <= 2", {}
    blo, _ = V.b_range(r1, r2)
    if blo <= 0:
        return False, "b- = 0", {}
    mb = V.mbar_of(t2, r2, blo)
    mc = Fr(bx['mc'])
    top = min(Fr(1), mb)
    if not (0 < mc < top):
        return False, "m_c", {}
    kinds = {}
    for side in ('plus', 'minus'):
        if not covers([(Fr(p['m'][0]), Fr(p['m'][1])) for p in bx[side]], mc, top):
            return False, "cover " + side, {}
    for pc in bx['plus']:
        m1, m2 = Fr(pc['m'][0]), Fr(pc['m'][1])
        tp = pc['type']
        if tp in ('A3', 'B3'):
            k = K3.piece_test(box, s, m1, m2, S3)
            if k is None:
                return False, f"near-sphere 3 [{float(m1)},{float(m2)}]", {}
            kinds[k] = kinds.get(k, 0) + 1
        elif tp == 'TCS':
            cap, mc2 = Fr(pc['cap']), Fr(pc['mc'])
            need = min(cap, Fr(1))
            sub = [(Fr(a), Fr(b)) for a, b, _ in pc['sub']]
            if not covers(sub, mc2, need):
                return False, "TCS sub cover", {}
            for a, b in sub:
                k = near4(box, s, m1, m2, a, b)
                if k is None:
                    return False, f"near-sphere 4 m[{float(m1)},{float(m2)}] n[{float(a)},{float(b)}]", {}
                kinds[k] = kinds.get(k, 0) + 1
        elif tp != 'TC':
            return False, "plus type " + tp, {}
    for pc in bx['minus']:
        if pc['type'] not in ('SG', 'TC'):
            return False, "minus type " + pc['type'], {}
    return True, "", kinds


# ---------------------------------------------------------------- G: bit lemmas
def bit_polys(nbits):
    """distinct H_f = 12(1-q)^4 - sum_i Delta_i(f)^2 (sympy Poly in q) over all f: {0,1}^nbits -> {-1,1}"""
    import sympy as sp
    q = sp.Symbol('q')
    pts = list(product((0, 1), repeat=nbits))
    basis = [sp.Poly(q**k * (1 - q)**(nbits - 1 - k), q) for k in range(nbits)]
    base = sp.Poly(12 * (1 - q)**4, q)
    cache, seen = {}, {}
    for vals in product((-1, 1), repeat=len(pts)):
        f = dict(zip(pts, vals))
        key = []
        for i in range(nbits):
            cnt = [0] * nbits
            for x in pts:
                if x[i]:
                    x0 = x[:i] + (0,) + x[i + 1:]
                    cnt[sum(x) - 1] += f[x] - f[x0]
            key.append(tuple(cnt))
        key = tuple(sorted(key))
        seen.setdefault(key, []).append(vals)
    for key in seen:
        tot = base
        for cnt in key:
            d = sum((basis[k] * cnt[k] for k in range(nbits)), sp.Poly(0, q))
            tot = tot - d * d
        cache[key] = tot
    return cache, seen, pts, q


def nonneg_on(P, q, mu_lo, b, q_lo_rat):
    """P >= 0 on [a, b], a a root of the integer polynomial mu_lo (a = q_lo_rat if mu_lo is None), b rational.
    Returns (ok, zero_at_a, zero_at_b)."""
    import sympy as sp
    R = lambda x: sp.Rational(x.numerator, x.denominator)
    if P.is_zero:
        return True, True, True
    lin_b = sp.Poly(b.denominator * q - b.numerator, q)
    mu = mu_lo if mu_lo is not None else sp.Poly(q_lo_rat.denominator * q - q_lo_rat.numerator, q)
    a_mult, c_mult, Q = 0, 0, P
    while True:
        qq, rr = sp.div(Q, mu)
        if rr.is_zero:
            Q, a_mult = qq, a_mult + 1
        else:
            break
    while True:
        qq, rr = sp.div(Q, lin_b)
        if rr.is_zero:
            Q, c_mult = qq, c_mult + 1
        else:
            break
    if Q.degree() > 0 and Q.count_roots(R(q_lo_rat), R(b)) != 0:
        return False, a_mult > 0, c_mult > 0
    sgn_mu = int(sp.sign(mu.eval(R((q_lo_rat + b) / 2))))
    sgn_lin = int(sp.sign(lin_b.eval(R((q_lo_rat + b) / 2))))
    sgn = int(sp.sign(Q.eval(R(b)))) * sgn_mu**a_mult * sgn_lin**c_mult
    return sgn > 0, a_mult > 0, c_mult > 0


def or_fn(pts, idx, sign=1):
    return tuple(sign * (1 if any(x[i] for i in idx) else -1) for x in pts)


def part_G():
    import sympy as sp
    ok = True
    qL, qH = Fr(25, 169), 1 / (1 + U_HI * U_HI)
    cache, seen, pts, q = bit_polys(3)
    bad, zero, at_lo = 0, [], []
    for key, P in cache.items():
        good, za, zb = nonneg_on(P, q, None, qL, qH)
        bad += not good
        if P.is_zero:
            zero += seen[key]
    or3 = {or_fn(pts, (0, 1, 2), sg) for sg in (1, -1)}
    ok3 = bad == 0 and set(zero) == or3
    print(f"G  three-bit lemma: 256 f, {len(cache)} distinct H_f; H_f >= 0 on [1/(1+U_HI^2), 25/169] fails for {bad};"
          f" H_f == 0 exactly for {len(zero)} f (= +-OR_3: {set(zero) == or3})", flush=True)
    ok &= ok3
    t0 = time.time()
    cache, seen, pts, q = bit_polys(4)
    mu4 = sp.Poly(4 * q**2 - 8 * q + 1, q)
    q4lo = 1 - sqrt_hi(Fr(3, 4))
    q4hi = 1 - sqrt_lo(Fr(3, 4))
    assert mu4.eval(sp.Rational(q4lo.numerator, q4lo.denominator)) > 0 > mu4.eval(sp.Rational(q4hi.numerator, q4hi.denominator))
    bad, zero, at4, at_b = 0, [], [], []
    for key, P in cache.items():
        good, za, zb = nonneg_on(P, q, mu4, qL, q4lo)
        bad += not good
        if P.is_zero:
            zero += seen[key]
        elif za:
            at4 += seen[key]
        if zb and not P.is_zero:
            at_b += seen[key]
    or3_4 = {or_fn(pts, idx, sg) for idx in ((0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)) for sg in (1, -1)}
    or4 = {or_fn(pts, (0, 1, 2, 3), sg) for sg in (1, -1)}
    ok4 = bad == 0 and set(zero) == or3_4 and set(at4) == or4 and not at_b
    print(f"G  four-bit lemma: 65536 f, {len(cache)} distinct H_f; H_f >= 0 on [q4, 25/169] fails for {bad};"
          f" H_f == 0 for {len(zero)} f (= +-OR_3 on 3 of 4 bits: {set(zero) == or3_4}); H_f(q4) = 0 otherwise for"
          f" {len(at4)} f (= +-OR_4: {set(at4) == or4}); H_f(25/169) = 0 for {len(at_b)} f; {time.time() - t0:.0f}s",
          flush=True)
    ok &= ok4
    return ok


# ---------------------------------------------------------------- A: elementary facts
def part_A():
    import sympy as sp
    u = sp.Symbol('u', positive=True)
    ok = True
    okU = U_LO * U_LO > 5 and U_HI * U_HI > 3 and (U_HI * U_HI - 3)**2 >= 12
    gap = float(U_HI) - float(sp.sqrt(3 + 2 * sp.sqrt(3)).evalf(30))
    okT8 = (T8 + 1)**2 >= 2 and T8 < 1
    print(f"A  U_LO^2 > 5 (T decreasing on the range), U_HI >= u4 = sqrt(3+2sqrt3): {okU} (U_HI - u4 = {gap:.3e});"
          f" tan(pi/8) <= T8 < 1: {okT8}")
    ok &= okU and okT8
    mono = True
    for j in range(3, NJ + 1):
        expr = sum(sp.Rational(c.numerator, c.denominator) * u**e for e, c in KAP[j].items())
        num = sp.numer(sp.together(sp.diff(expr, u)))
        P = sp.Poly(num, u)
        n = P.count_roots(sp.Rational(U_LO.numerator, U_LO.denominator), sp.Rational(U_HI.numerator, U_HI.denominator))
        mono &= n == 0
    print(f"A  kappa_3..kappa_{NJ} monotone on [U_LO, U_HI] (no root of kappa_j' there): {mono}")
    ok &= mono
    import moments10
    okm = moments10.self_test()
    ok &= okm
    return ok


def load():
    man = json.load(open(os.path.join(DATA, 'k3b_manifest.json')))
    assert Fr(man['U_LO']) == U_LO and Fr(man['U_HI']) == U_HI and Fr(man['T8']) == T8 and Fr(man['A_S']) == A_S
    cells = []
    for fn in man['one_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['target'] == 'k3' and not d['failed'] and d['D'] <= NJ
        for cl in d['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]))
    boxes = []
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['s'] in (1, -1) and not d['failed'] and d['K'] == 3 and Fr(d['A_S']) == A_S
        for bx in d['boxes']:
            assert bx['s'] == d['s']
            boxes.append(bx)
    return man, cells, boxes


def main():
    t0 = time.time()
    parts = sys.argv[1] if len(sys.argv) > 1 else 'MABCDEFG'
    allok = True
    man, cells, boxes = load()
    files = man['one_files'] + man['two_files']
    kinds = {}
    for bx in boxes:
        kinds[(bx['s'], bx['kind'])] = kinds.get((bx['s'], bx['kind']), 0) + 1
    print(f"k3b verifier (RQ-AUD), data {DATA}: {len(cells)} cells, {len(boxes)} boxes, kinds {dict(sorted(kinds.items()))}",
          flush=True)
    if 'M' in parts:
        pub = {}
        for line in open(os.path.join(DATA, 'k3b_MD5SUMS.txt')):
            h, fn = line.split()
            pub[fn.replace('outputs/', '')] = h
        mism = [fn for fn in files + ['k3b_manifest.json']
                if hashlib.md5(open(os.path.join(DATA, fn), 'rb').read()).hexdigest() != pub.get(fn)]
        print(f"M  md5 of the {len(files) + 1} manifest files vs k3b_MD5SUMS.txt: {len(mism)} mismatches", flush=True)
        allok &= not mism
    if 'A' in parts:
        allok &= part_A()
    if 'B' in parts:
        reg1 = (U_LO, U_HI, Fr(0), A_S)
        tok, gap = tiles(reg1, [cl[:4] for cl in cells])
        inside = all(reg1[0] <= cl[0] < cl[1] <= reg1[1] and reg1[2] <= cl[2] < cl[3] <= reg1[3] for cl in cells)
        area = sum((cl[1] - cl[0]) * (cl[3] - cl[2]) for cl in cells) == (reg1[1] - reg1[0]) * (reg1[3] - reg1[2])
        print(f"B  {len(cells)} one-coordinate cells tile [U_LO,U_HI] x [0,A_S]: {'OK' if tok else 'GAP ' + str(gap)};"
              f" inside {inside}; area {area}", flush=True)
        allok &= tok and inside and area
        reg3 = (U_LO, U_HI, Fr(0), T8, A_S, Fr(1))
        for s in (1, -1):
            bs = [tuple(Fr(x) for x in bx['box']) for bx in boxes if bx['s'] == s]
            ins, voleq, nov = V.tiling3(reg3, bs)
            print(f"B  s={s:+d}: {len(bs)} boxes inside {ins}; volume sum == region volume {voleq}; overlapping pairs {nov}"
                  f" => {'TILING OK' if ins and voleq and nov == 0 else 'TILING FAIL'}", flush=True)
            allok &= ins and voleq and nov == 0
        unknown = {bx['kind'] for bx in boxes} - {'lpv', 'ms5', 'ncA'}
        print(f"B  box kinds outside {{lpv, ms5, ncA}}: {sorted(unknown)}")
        allok &= not unknown
    if 'C' in parts:
        with Pool(8) as pool:
            res = pool.map(cell_job, [(cl[0], cl[1], cl[2], cl[3], cl[4]) for cl in cells], chunksize=2)
        nf = 0
        for cl, r in zip(cells, res):
            if not r[0]:
                nf += 1
                print(f"   FAIL cell u[{float(cl[0]):.6f},{float(cl[1]):.6f}] a[{float(cl[2]):.4f},{float(cl[3]):.4f}]: {r[1]}")
        print(f"C  one-coordinate cells (degree <= 10, own ten-moment bound): failures {nf}/{len(cells)},"
              f" {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    if 'D' in parts:
        jobs, bad = [], []
        for bx in boxes:
            if bx['kind'] in ('lpv', 'ms5'):
                j, b = vertex_jobs(bx)
                jobs += j
                bad += b
        nv = sum(len(j[1]['V']) for j in jobs)
        print(f"D  {len(jobs)} vertex-certificate sets ({nv} vertices); record-side cap/phi problems: {len(bad)} {bad[:3]}",
              flush=True)
        allok &= not bad
        with Pool(8) as pool:
            res = pool.map(vjob_check, jobs, chunksize=4)
        nf = 0
        byname = {}
        for jb, r in zip(jobs, res):
            byname[jb[0]] = byname.get(jb[0], 0) + 1
            if not r[0]:
                nf += 1
                bx = jb[5]
                if nf <= 30:
                    print(f"   FAIL {r[1]} s={jb[3]:+d} s3={jb[4]:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}]"
                          f" t[{float(bx[2]):.5f},{float(bx[3]):.5f}] r[{float(bx[4]):.5f},{float(bx[5]):.5f}] X={[(float(a), float(b)) for a, b in jb[2]]}")
        print(f"D  vertex certificates: failures {nf}/{len(jobs)}; sets by role {byname}; cone sub-boxes max"
              f" {max(r[2] for r in res)}, total {sum(r[2] for r in res)}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    if 'E' in parts:
        ncs = [(tuple(Fr(x) for x in bx['box']), bx['s']) for bx in boxes if bx['kind'] == 'ncA']
        with Pool(8) as pool:
            res = pool.map(K3.nc_rec, [(bx, s, S3) for bx, s in ncs], chunksize=1)
        nf = sum(1 for r in res if not r[0])
        how = {}
        for r in res:
            if r[0]:
                how[r[3]] = how.get(r[3], 0) + 1
        print(f"E  near-circle boxes: failures {nf}/{len(ncs)}; passed by test {how}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    if 'F' in parts:
        mss = [bx for bx in boxes if bx['kind'] == 'ms5']
        with Pool(8) as pool:
            res = pool.map(ms5_structure, [(bx,) for bx in mss], chunksize=2)
        nf = 0
        kk = {}
        for bx, r in zip(mss, res):
            if not r[0]:
                nf += 1
                b = [float(Fr(x)) for x in bx['box']]
                print(f"   FAIL ms5 s={bx['s']:+d} box {b}: {r[1]}")
            for k, v in r[2].items():
                kk[k] = kk.get(k, 0) + v
        mcs = sorted({bx['mc'] for bx in mss}, key=Fr)
        print(f"F  m-split boxes: failures {nf}/{len(mss)}; near-sphere pieces by test {kk}; m_c values {mcs};"
              f" {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    if 'G' in parts:
        allok &= part_G()
    print(f"RESULT: {'ALL CHECKS PASSED' if allok else 'FAILURES'} (parts {parts}, {time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
