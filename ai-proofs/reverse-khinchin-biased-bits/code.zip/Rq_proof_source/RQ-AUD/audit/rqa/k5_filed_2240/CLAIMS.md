# CLAIMS (RQ-A: central range, k = 2 regime, k = 3 regime, k = 4 regime)

Tags: PROVED / CONDITIONAL / NUMERICAL / CONJECTURE / FAILED.
Notation: q in (0,1/2], u = sqrt((1-q)/q), v = 1/u, tau = sqrt(q(1-q)), theta = 1-2q,
L = sum alpha_i chi_i, |alpha|_2 = 1, a = max|alpha_i| (WLOG alpha_1 = a > 0), b = sqrt(1-a^2),
M = b^{-1} sum_{i>=2} alpha_i chi_i, R_a(y) = (1-q)(y-av)_+ + q(-y-au)_+.
Rational parametrisation: q = 1/(1+u^2); then v = 1/u, tau = u/(1+u^2), 1-q = u^2/(1+u^2).
q0 = 1-1/sqrt2 corresponds to u0 = sqrt(1+sqrt2); q3 = 1-sqrt(2/3) to u3 = sqrt(2+sqrt6);
q4 = 1-sqrt3/2 to u4 = sqrt(3+2 sqrt3); 25/169 to u = 12/5.

## MAIN. R(q) = 2 sqrt(q(1-q)) exactly on [1-1/sqrt2, 1/sqrt2], and this range is sharp

- MAIN PROVED (computer-assisted, rigorous). RQ-AUD: VALID (A.6, 06:52 UTC); independent referee
  pending. For every q in
  [1-1/sqrt2, 1/sqrt2], every n and every unit alpha: E|sum alpha_i chi_i| <= 2 sqrt(q(1-q)).
  Hence R(q) = 2 sqrt(q(1-q)) there (attained by alpha = e_1; at q = 1-1/sqrt2 and q = 1/sqrt2
  also by (1,1)/sqrt2). For q outside this interval R(q) >= sqrt2 max(q,1-q) 2 sqrt(q(1-q)) >
  2 sqrt(q(1-q)) (C0.4). Full proof: MAIN_RESULT.md / MAIN_RESULT.pdf.
  Structure: Lemma 9.4 reduction + three certificates on the (u,a) rectangle [1,u0] x (0,1):
  * Lemma S (six-moment certificates, PROVED) + exact cover of 379 cells (PROVED, exact rationals,
    Sturm sequences): all (u,a) outside the two pieces below.
  * Lemma Q (quartic two-extremiser certificate, PROVED) + 641 boxes in (u,t), a = 2t/(1+t^2),
    verified in rational interval arithmetic (mean-value form) (PROVED): u in [611/400, u0],
    a in [16/25, 77/100]; this is where the extremisers e_1 and (1,1)/sqrt2 compete.
  * Lemma D (near-dictator, PROVED, analytic): a in [9/10, 1).
  Independent re-verification: scripts/verify_all.py (shares no code with the generators):
  symbolic identities, coverage, own Sturm code, mpmath intervals (20969 sub-boxes); all pass
  (outputs/verify_all_*.txt). Negative tests: scripts/break_tests.py.

## MAIN-2. k = 2 regime: R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) exactly on [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2], sharp

- MAIN-2 PROVED (computer-assisted, rigorous, independently re-verified). RQ-AUD: VALID (A.11,
  08:52 UTC); independent referee pending. After the audit (text only, data unchanged): the two
  cosmetic points of A.11 are applied (Lemma 20 states the convention for y = 0; Definition 23
  notes that 2 m_c^2 > 1 follows from phi(m_c) <= p* < 0), and the verifier's phi check now also
  requires 0 < m_c <= 1 and p* < 0 (all 1,189 ms boxes pass; new negative test).
  Full proof: MAIN_RESULT_K2.pdf (LaTeX source MAIN_RESULT_K2.tex; same text in MAIN_RESULT_K2.md).
  For every q in [q3, q0] = [0.183503, 0.292893] (and, by symmetry, [1-q0, 1-q3]), every n and
  every unit alpha: E|sum alpha_i chi_i| <= 2 sqrt2 (1-q) tau. Equality iff
  alpha = ±(e_i + e_j)/sqrt2, or q = q0 and alpha = ±e_i, or q = q3 and
  alpha = ±(e_i + e_j + e_k)/sqrt3. The interval is sharp: for q < q3, (1,1,1)/sqrt3 gives
  2 sqrt3 (1-q)^2 tau > T; for q > q0, e_1 gives 2 tau > T.
  Corollary (with MAIN): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 (1-q), sqrt2 q} for all q in
  [q3, 1-q3] = [0.18350, 0.81650].
  This confirms the RQ-B/Stone conjecture R(q) = max_k 2 sqrt(kq)(1-q)^{k-1/2} on [q3, q0], and
  extends RQ-C's C11 ([256/985, q0], audited VALID as A.9) to the largest possible interval.
  Mechanism (new): split off the TWO largest coefficients, so that the extremiser (1,1)/sqrt2
  sits at the boundary b = 0 and no tangency certificate is needed:
  L = a1 chi_1 + s a2 chi_2 + b M, |beta_i| <= min(1, a2/b), E|L| = E F(M) with
  F(y) = E|a1 chi_1 + s a2 chi_2 + b y| (4 atoms).  Coordinates a1 = r(1-t^2)/(1+t^2),
  a2 = 2rt/(1+t^2), b = sqrt(1-r^2).
  * Lemma 2C (two-coordinate value, PROVED, elementary): for c,d >= 0, q <= 1/2,
    E|c chi_1 + s d chi_2| = 2 tau max(c, d, [s=+1](1-q)(c+d)) <= 2 sqrt2 (1-q) tau sqrt(c^2+d^2)
    when q <= q0.
  * Lemma E (cell envelope, PROVED): with interval bounds for p_j x_j = r tau g_j and p_j b on a
    box, a convex piecewise-linear F_box >= F (<= 6 pieces).
  * Lemma 2S (two-coordinate six-moment certificate, PROVED): P >= F_box on R (exact Sturm on
    each piece) + the Lemma 9 moment bound < T_lo  ==>  E|L| < T.
  * Lemma NC (near-circle, PROVED, analytic): E|L| <= rG + sum_j p_j min(b, (27/128) b^4 E M^4 /(r|y_j|)^3),
    G = E|c chi_1 + s d chi_2| <= T; slack T(1-r) = T b^2/(1+r) beats the O(b^4) error.
  * a1 <= 9/20: one-coordinate six-moment cells with target tau(sqrt2(1-q) - a) (784 cells).
  * Three-bit lemma (PROVED, exact): for q in [q3, q0] and all c in R^3,
    E|c1 chi1 + c2 chi2 + c3 chi3| <= T |c|; equality only at ±(e_i+e_j), ±(1,1,1) (q = q3),
    ±e_i (q = q0). Proof: E[f chi_i] = tau Delta_i(f), and sum_i Delta_i(f)^2 <= 8 (1-q)^2 for
    all 256 Boolean f (exact Sturm). Same as the n = 3 case of RQ-C C6 (A.5), checked independently.
  * m-split near the triple point (q3, (1,1,1)/sqrt3) (PROVED): with m = max|beta_i| and a cut
    m_c in (1/sqrt2, 1]: (i) m <= m_c: certificate with the cap m_c; (ii) m >= m_c and the
    largest remaining coefficient is -m: then p3 <= -m_c^3 + (1-m_c^2)^{3/2} < 0 (sign lemma),
    used in the objective bound; (iii) it is +m: split off a third coordinate a3 = b m and apply
    the three-coordinate tail bound with the three-bit lemma (slack T b'^2/(1+r') against an
    O(b'^4) error), b' = b sqrt(1-m^2).
  Cover (u in [1553773/10^6, 1054691/500000] ⊃ [u0, u3], t in [0, 20711/50000], r in [9/20, 1],
  s = ±1): 55,515 boxes (48,810 exact LP certificates, 4,835 near-circle boxes, 1,189 m-split
  boxes with 1,669 near-sphere pieces, 681 boxes with a1 <= 9/20), 0 failures.
  Independent verifier scripts/verify_k2.py (no shared code with the generators): symbolic
  identities, exact 3-D tiling, strict re-check of all cells/boxes (envelope rebuilt as a max of
  16 sign patterns on each half-line), near-circle boxes and near-sphere pieces in mpmath
  intervals, the three-bit lemma by exact Sturm sequences: ALL PASS
  (outputs/verify_k2_ABCDEFG.txt). Negative tests (scripts/break_tests_k2.py,
  outputs/break_tests_k2.txt): corrupted certificates, cuts, pieces and widened boxes are rejected.
- Beyond q3: see MAIN-3 (k = 3 regime on [25/169, q3]).

## MAIN-3. k = 3 regime: R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) exactly on [25/169, q3] = [0.147929, 0.183503]

- MAIN-3 PROVED (computer-assisted, rigorous, independently re-verified). RQ-AUD: VALID, NEW
  (A.14, 10:37 UTC, no fix needed); independent referee pending.
  Full proof: MAIN_RESULT_K3.pdf (LaTeX source MAIN_RESULT_K3.tex; same text in MAIN_RESULT_K3.md).
  For every q in [q_L, q3] with q_L = 25/169 = 1/(1+(12/5)^2) (and, by symmetry, [1-q3, 144/169]),
  every n and every unit alpha: E|sum alpha_i chi_i| <= T3 := 2 sqrt3 (1-q)^2 tau.
  Equality iff alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q3 and alpha = ±(e_i+e_j)/sqrt2.
  First exact values of R(q) in the regime where three equal coefficients are optimal.
  Upper end sharp (for q > q3, (1,1)/sqrt2 gives T2 > T3). Lower end: for q < q4 = 1-sqrt3/2
  = 0.133975, (1,1,1,1)/2 gives 4(1-q)^3 tau > T3, so {q <= 1/2: R = T3} is between [25/169, q3]
  and [q4, q3]; the gap [q4, 25/169) is closed by MAIN-4 below.
  Corollary (with MAIN and MAIN-2): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2},
  qh = max(q, 1-q), for all q in [25/169, 144/169] = [0.14793, 0.85207].
  Mechanism: exactly the machinery of MAIN-2 with target T3 (lower bound S3 min T~(u1), T~(u2),
  T~(u) = 2u^5/(1+u^2)^3, unimodal with maximum at sqrt5), A_S = 2/5, one-coordinate target
  tau(u2)(S3 (u1^2/(1+u1^2))^2 - a2), near-circle test (A) using T2 <= T3 for q <= q3, and the
  m-split now used throughout (the extremiser (1,1,1)/sqrt3 is the interior point m = 1, p3 = 1).
  * Three-bit lemma, k = 3 (PROVED, exact): for q in [25/169, q3] and all c in R^3,
    E|c . chi| <= T3 |c|; equality only at ±(1,1,1) and, at q = q3, ±(e_i+e_j). Proof:
    sum_i Delta_i(f)^2 <= 12 (1-q)^4 for all 256 Boolean f (exact Sturm; P_f = 4(1-q)^2 mu3 for
    OR_2, P_f = 0 for OR_3).
  Cover (u in [2109381/10^6, 12/5] ⊃ [u3, 12/5], t in [0, 20711/50000], r in [2/5, 1], s = ±1):
  81,975 boxes (57,333 exact LP certificates, 2,534 near-circle boxes, 21,232 m-split boxes with
  32,932 near-sphere pieces, 876 boxes with a1 <= 2/5) and 2,704 one-coordinate cells; 0 failures.
  Data in outputs/k3/ (listed in outputs/k3_manifest.json; md5s in outputs/k3_MD5SUMS.txt); generation: scripts/run_k3.sh with
  outputs/k3/jobs.txt (RQ_K=3 RQ_AS=2/5 cover2c.py ...; cover_k3.py).
  Independent verifier: RQ_K=3 python3 verify_k2.py (parts A-G as for MAIN-2, with the k = 3
  target, coverage of [U-, 12/5] x [0, T8] x [2/5, 1], and the k = 3 three-bit claim):
  outputs/verify_k3_ABCDEFG.txt. Negative tests: RQ_K=3 python3 break_tests_k2.py
  (outputs/break_tests_k3.txt).
- Why it stops at 25/169 (NUMERICAL, outputs/k3/scan_one.txt, scan_two.txt): the one-coordinate
  six-moment bound tends to the six-moment Gaussian value 0.888074 as a1 -> 0 (ratio to T3:
  0.9937 at q = 0.15, 0.9990 at q = 0.14, 1.0027 at q = 0.135), and the two-coordinate route
  near a1 = a2 = 0.55 fails for every tried m_c at q = 0.14. Gaussian 2k-moment values of
  sup E|X| (float LP): 6: 0.888074, 8: 0.886410, 10: 0.856068, 12: 0.855086, against
  T3(q4) = 0.884970 and sqrt(2/e) = 0.857764. So reaching q4 by this route needs ten moments,
  plus a split for the four-way tie (1,1,1,1)/2 at q4. This is what MAIN-4 does.

## MAIN-4. k = 3 regime closed: R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) exactly on [q4, 25/169]; with MAIN-3 on [q4, q3], and this is the exact set

- MAIN-4 PROVED (computer-assisted, rigorous, independently re-verified). RQ-AUD: VALID, NEW
  (A.18, 12:41 UTC; no fix needed; auditor's own verifier re-checked all 2,845 vertex sets, 288 cells,
  the tilings and both bit lemmas). Waiting for an independent referee.
  Full proof: MAIN_RESULT_K3B.pdf (19 pages; LaTeX source MAIN_RESULT_K3B.tex; same text in
  MAIN_RESULT_K3B.md). Theorem 4 there:
  (a) for every q in [q4, 25/169] = [1-sqrt3/2, 25/169] = [0.133975, 0.147929] (and, by symmetry,
  [144/169, sqrt3/2]), every n and every unit alpha: E|sum alpha_i chi_i| <= T3 = 2 sqrt3 (1-q)^2 tau;
  (b) equality iff alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q4 and alpha = ±(e_i+e_j+e_k+e_l)/2;
  (c) for q < q4, R(q) >= 4(1-q)^3 tau > T3 (so the lower end is sharp).
  Corollary 1 (with MAIN-3, A.14): R(q) = T3 exactly on [q4, q3] = [0.133975, 0.183503], and
  {q in (0, 1/2] : R(q) = T3(q)} = [q4, q3]. Extremisers on [q4, q3]: ±(e_i+e_j+e_k)/sqrt3, plus
  ±(e_i+e_j)/sqrt2 at q3 and ±(e_i+e_j+e_k+e_l)/2 at q4.
  Corollary 2 (with MAIN, A.6, and MAIN-2, A.11): for all q in [q4, 1-q4] = [0.13397, 0.86603],
    R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2} = 2 sqrt(q(1-q)) max_{k>=1} sqrt(k) qh^(k-1),
  qh = max(q, 1-q) (terms k >= 4 never exceed k = 3 there: (k/3)(3/4)^(k-3) <= 1 for k >= 4).
  This confirms the conjecture R(q) = max_k 2 sqrt(kq) (1-q)^(k-1/2) (BF3, Stone; RQ-B C0, RQ-C
  Conjecture S) on [q4, 1-q4], i.e. on the first three regimes k = 1, 2, 3.
  Mechanism (same frame as MAIN-3, u in [12/5, U+], U+ = 127123/50000 >= u4 = sqrt(3+2 sqrt3)):
  * Degree-10 polynomial certificates with a ten-moment expectation bound (cumulants kappa_j of chi
    for j <= 10, moment recursion, power-sum bounds |p3| <= rho, |p_j| <= m^(j-4) rho^2, p_j >= rho^(j-2)
    for even j). Needed: six (eight) moments give the Gaussian value 0.888074 (0.886410) > T3(q4) =
    0.884970; ten give 0.856068. One-coordinate route for a1 <= A_S = 7/20: 288 degree-10 cells.
  * Vertex certificates (new): x -> F_x(y) = E|x1 chi1 + s x2 chi2 + x3 y| is convex and
    1-homogeneous, so a certificate at each vertex of a polytope whose cone contains the parameter
    patch {(r c, r d, b)} gives a certificate on the whole patch (no interval envelope over a box,
    whose first-order loss is too large near q4). Exact checks: parallelepiped structure,
    V.n0 = |n0|^2 >= 1, cone enclosure of the patch by exact interval bisection, domination on R
    (envelope over the u-interval only), strict objective bound.
  * m-split near (1,1,1)/sqrt3 with vertex certificates in three split coordinates, a second m-split
    inside the plus side (cap m'_c = 17/20), and a four-coordinate near-sphere bound (A4)/(B4)
    based on an exact four-bit lemma.
  * Three-bit lemma on [q_U, 25/169], q_U = 1/(1+U+^2): sum_i Delta_i(f)^2 <= 12 (1-q)^4 for all 256
    Boolean f (exact Sturm); equality identically only for ±OR_3.
  * Four-bit lemma on [q4, 25/169]: sum_i Delta_i(f)^2 <= 12 (1-q)^4 for all 65,536 Boolean f on four
    bits (exact Sturm, 1,630 distinct polynomials); equality identically only for ±OR_S, |S| = 3; at
    q4 also ±OR_4 (H_OR4 = -4(1-q)^4 g4, g4 = 4q^2-8q+1, root q4). It fails for q < q4, which is why
    the boxes with u > u4 are used only for u <= u4.
  Cover: 288 one-coordinate cells; 1,421 two-coordinate boxes (s = +1: 626 lpv, 13 near-circle, 302
  m-split with 1,350 pieces; s = -1: 480 lpv); 2,845 vertex-certificate sets (16,544 vertices,
  degree 6); 301 four-coordinate near-sphere pieces; 0 failures. Data: outputs/k3b/ (listed in
  outputs/k3b_manifest.json; md5s outputs/k3b_MD5SUMS.txt); generation scripts/run_k3b.sh
  (job list outputs/k3b/jobs.txt).
  Independent verifier scripts/verify_k3b.py (no shared code with the generators except the
  Sturm/isqrt/tiling helpers of verify_all.py): parts A-G ALL PASS (outputs/verify_k3b_ABCDEFG.txt,
  93 s on 8 cores). Negative tests scripts/break_tests_k3b.py: all corruptions rejected
  (outputs/break_tests_k3b.txt).
- Next regime (k = 4 on [q5, q4], q5 from 2 sqrt5 (1-q)^4 = 4(1-q)^3): MAIN-5 below.

## MAIN-5. k = 4 regime: R(q) = 4 (1-q)^3 sqrt(q(1-q)) exactly on [q5, q4] = [1-2/sqrt5, 1-sqrt3/2]

- MAIN-5 PROVED (computer-assisted; every computer step exact or certified interval arithmetic, re-done
  by an independent program). **RQ-AUD verdict VALID, NEW (A.25, 16:53 UTC), no fix to the mathematics.**
  Text remarks r1-r2 of A.25 applied at 17:46 UTC (status of Theorem 4 in Corollary 2; Remark 4). Text
  corrections c1-c2 at 20:51 UTC, logged in AUDIT_REQUEST.md: N = 10^15 in the Conventions, and the part B item
  states the kind check done by `scripts/k4_kinds_check.py`. The mathematics and the data are unchanged. Awaiting an
  independent referee. Proof:
  MAIN_RESULT_K4.pdf (source .tex; same text in MAIN_RESULT_K4.md).
  Statement (Theorem 5): (a) for every q in [q5, q4] = [0.105573, 0.133975] (and the mirror), every n
  and every unit alpha, E|sum alpha_i chi_i| <= T4 = 4 (1-q)^3 tau; (b) equality iff
  alpha = ±(e_i+e_j+e_k+e_l)/2, or q = q4 and alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q5 and
  alpha = ±(e_i1+...+e_i5)/sqrt5; (c) R > T4 for q in (0, q5) and (q4, 1/2]. So
  {q <= 1/2 : R(q) = T4(q)} = [q5, q4], and with MAIN-1..4: R(q) = 2 tau max_k sqrt(k) qh^(k-1) on
  [q5, 1-q5].
  Mechanism (as MAIN-4, u in [U-, U+] = [1589/625, 29107/10000], which contains [u4, u5]):
  * k = 4 three- and four-bit lemmas on [q5, q4] (sum_i Delta_i(f)^2 <= 16 (1-q)^6 for all 256 / 65,536
    f; equality: 3 bits only ±OR_3 at q4; 4 bits ±OR_4 identically, ±OR_S (|S| = 3) at q4 only;
    outputs/bitlemma_k4.txt, verify_k4.py part G).
  * OR-region identity (elementary): if c_i > 0 and c_i > q sum_j c_j for all i, then
    E|c . chi| = 2 tau (1-q)^(n-1) sum_i c_i; for n = 5 this is <= T5 |c| <= T4 |c| when q >= q5.
  * One more level of the m-split (TCN, for u >= 2.75) ending in a five-coordinate near-sphere bound
    (A5)/(B5) around (1,...,1)/sqrt5; vertex certificates with two, three or four patch parameters;
    exact cone test by chains of one-variable minima (Lemma 21, no subdivision).
  Cover: 1,268 one-coordinate cells (degree 10); 7,261 two-coordinate boxes (s = +1: 3,327 lpv and
  2,718 m-split; s = -1: 1,216 lpv); 21,014 vertex-certificate sets with 171,488 vertices; 2,533
  four-coordinate and 383 five-coordinate near-sphere pieces; 0 failures. Data: outputs/k4/ (listed in
  outputs/k4_manifest.json, md5s outputs/k4_MD5SUMS.txt); generation scripts/run_k4.sh (job list
  outputs/k4/jobs_all.txt, 8.5 job-hours); statistics outputs/k4_stats.txt (scripts/cover_stats5.py).
  Independent verifier scripts/verify_k4.py (no code shared with the generators; reuses the audited
  helpers of verify_k3b.py and verify_all.py): parts A-G ALL PASS (outputs/verify_k4_ABCDEFG.txt, 367 s
  on 8 cores). Negative tests scripts/break_tests_k4.py: all 23 corruption types rejected in every
  sampled case, both sanity checks hold (outputs/break_tests_k4.txt).

## MAIN-6. k = 5 regime: R(q) = 2 sqrt5 (1-q)^4 sqrt(q(1-q)) exactly on [q6, q5] = [1-sqrt(5/6), 1-2/sqrt5]

- MAIN-6 PROVED (computer-assisted; every computer step exact or certified interval arithmetic, re-done
  by an independent program). Filed for audit 2026-10-22 22:37 UTC (AUDIT_REQUEST.md, MAIN-6); not yet audited. Proof:
  MAIN_RESULT_K5.pdf (source .tex; same text in MAIN_RESULT_K5.md).
  Statement (Theorem 6): (a) for every q in [q6, q5] = [0.087129, 0.105573] (and the mirror), every n and
  every unit alpha, E|sum alpha_i chi_i| <= T5 = 2 sqrt5 (1-q)^4 tau; (b) equality iff
  alpha = ±(e_i1+...+e_i5)/sqrt5, or q = q5 and alpha = ±(e_i+e_j+e_k+e_l)/2, or q = q6 and
  alpha = ±(e_i1+...+e_i6)/sqrt6; (c) R > T5 for q in (0, q6) and (q5, 1/2]. So
  {q <= 1/2 : R(q) = T5(q)} = [q6, q5], and with MAIN-1..5: R(q) = 2 tau max_k sqrt(k) qh^(k-1) on
  [q6, 1-q6].
  Mechanism (as MAIN-5, u in [U-, U+] = [29106/10000, 3236855/1000000], which contains [u5, u6]):
  * k = 5 three- and four-bit lemmas on [q6, q5] (sum_i Delta_i(f)^2 <= 20 (1-q)^8 for all 256 / 65,536
    f; equality: none for 3 bits, ±OR_4 at q5 only for 4 bits; outputs/bitlemma_k5.txt, verify_k5.py part G;
    audited in A.22).
  * OR-region identity (MAIN-5, A.20): carries (e_1+...+e_5)/sqrt5 on the whole regime and, with T6 <= T5 for
    q >= q6, (e_1+...+e_6)/sqrt6 at q6.
  * The m-split as a tree of recursive split nodes of level <= 2 (the child of a TCS piece at level 2 has
    level 3), peeling up to four coordinates and ending in near-sphere bounds with up to six coordinates;
    vertex certificates with two to five patch parameters; exact cone test (Lemma 21).
  Cover: 861 one-coordinate cells (degree 10); 9166 two-coordinate boxes (s = +1: 3804 lpv and 4303 m-split;
  s = -1: 1059 lpv); 52,292 vertex-certificate sets with 784,616 vertices; split nodes 4303 / 4873 / 3958 at
  levels 0 / 1 / 2; 4029 near-sphere pieces (four coordinates 185, five 3200, six 644); 0 failures. Data:
  outputs/k5/ (105 files listed in outputs/k5_manifest.json, md5s outputs/k5_MD5SUMS.txt; 54 of them computed by
  RQ-C, md5s checked); generation scripts/run_k5.sh (job list outputs/k5/jobs_all.txt, about 66 job-hours);
  statistics outputs/k5_stats.txt (scripts/cover_stats6.py).
  Independent verifier scripts/verify_k5.py (no code shared with the generators; reuses the audited helpers
  of verify_k4.py, verify_k3b.py and verify_all.py): parts A-G ALL PASS (outputs/verify_k5_ABCDEFG.txt,
  4449 s on 8 cores, 9.8 CPU-hours). Negative tests scripts/break_tests_k5.py: 21 corruption tests (20 types; tiling once per sign), all
  799 corrupted records rejected; 4 sanity checks hold (outputs/break_tests_k5.txt).
  For the all-q plan (U.3): with MAIN-6, ID*(C) is needed only with C = C(q6) = 0.8559844891... (any decimal
  <= 0.8559844), and RQ-C's support bound becomes A'(q6) = 1.5146.

## U. Uniform in k: reduction of Conjecture S on (0, q_K] to one q-free statement about ID laws

Notation: q <= 1/2, s = ln(1/(1-q)), M(q) = 2 tau max_k sqrt(k) (1-q)^(k-1), g(l) = 2 sqrt(l) e^(-l),
C(q) = M(q) sqrt((1-q) s / q) = max_{k>=1} g(ks) <= g(1/2) = sqrt(2/e). For a Kolmogorov probability
measure K on R (Z_K centred ID with E Z_K^2 = 1, Levy measure x^(-2) K(dx)) and theta > 0:
lambda+_theta(K) = int_[theta,oo) x^(-2) dK, lambda-_theta(K) = int_(-oo,-theta] x^(-2) dK.
ID*(C): every finitely supported K has some theta > 0 (allowed to depend on K) with
E|Z_K| <= max(g(lambda+_theta(K)), g(lambda-_theta(K)), C).

- U.1 PROVED (reduction; first posted in NOTES_FOR_TEAM.md, 15:20 UTC). If ID*(C) holds, then
  R(q) = M(q) for every q <= 1/2 with C(q) >= C.
  Written up by RQ-B as C19 = RQ-B MAIN_RESULT Theorem 3.4 (audit requested by RQ-B), with one theta for all K
  ("(ID-theta, C)"). The proof below is per configuration, so theta may depend on K (ID*); this matters because
  a fixed theta above theta_max(eta) makes the statement false (RQ-C C16: theta = 1.0 fails for C = C(q4)).
  RQ-A does not file U.1 separately.
  Proof. Fix n and a maximiser alpha of E|L|, L = sum alpha_i chi_i, on the unit sphere of R^n; R_n = E|L|.
  Let f = 1{L > 0}, Delta_i = Delta_i(f), D = sum Delta_i^2. Level-one form (RQ-B Lemma 2.1, audited):
  R_n = 2 tau sum alpha_i Delta_i <= 2 tau sqrt(D), and with beta = Delta/sqrt(D),
  2 tau sqrt(D) <= E|sum beta_i chi_i| <= R_n; so R_n = 2 tau sqrt(D) (and beta = alpha).
  Poissonisation (the proof of RQ-B Theorem 3, audited A.7): N_i i.i.d. Poisson(s), x_i = 1{N_i >= 1}
  (Bernoulli(q)), F = f(x(N)) in [0,1], I = sum Delta_i (N_i - s); Stein-Chen gives
  s (1-q) D = E[F I] <= E I_+ = E|I|/2. Here I/sqrt(sD) = Z_K with K = sum_i beta_i^2 delta_{beta_i/sqrt(s)}
  (finitely supported, mass 1). Hence R_n = 2 tau sqrt(D) <= sqrt(q/((1-q)s)) E|Z_K|.
  For every theta, lambda+_theta(K) = s #{i : beta_i >= theta sqrt(s)} and lambda-_theta(K) =
  s #{i : beta_i <= -theta sqrt(s)} are integer multiples of s, so g(lambda±_theta(K)) <=
  max(0, max_k g(ks)) = C(q). By ID*(C) and C <= C(q): E|Z_K| <= C(q), so R_n <= sqrt(q/((1-q)s)) C(q) =
  M(q). Taking sup over n, R(q) <= M(q); R(q) >= M(q) by equal coefficients. []
- U.2 PROVED (elementary). min over q in (0, q_K] of C(q) is C(q_K) = g((K-1) s_K), s_K = (1/2) ln(K/(K-1))
  (the dips of C are at the q_k, where g((k-1)s_k) = g(k s_k), and (k-1) s_k = (1/2)(k-1) ln(1+1/(k-1))
  increases to 1/2, where g is increasing). Values (mpmath, 30 digits, truncated): C(q_4) = 0.8533435684...,
  C(q_5) = 0.8551004554..., C(q_6) = 0.8559844891..., i.e. eta_K = sqrt(2/e) - C(q_K) = 0.0044203164...,
  0.0026634294..., 0.0017793957... for K = 4, 5, 6 (eta_K ~ sqrt(2/e)/(16 K^2) as K -> oo); a margin
  eta used in place of eta_K must be >= eta_K (e.g. 0.00443, 0.00267, 0.00178). Audited VALID as part of A.26.
- U.3 CONDITIONAL corollaries. With MAIN-1..4 (audited): ID*(C(q_4)) implies Conjecture S for all q; any
  decimal C <= 0.8533435 may be used in place of C(q_4) (C must not exceed C(q_4); the earlier text used
  0.853344, which is C(q_4) rounded up and leaves q in (0.13397376, q_4) uncovered: audit A.26, fix f1).
  With MAIN-5: ID*(C(q_5)) suffices (e.g. C = 0.855100). With MAIN-6: ID*(C(q_6)) suffices (e.g. C = 0.855984).
  Remarks: C5 (E|Z_K| <= sqrt(2/e) for all K) is necessary for Conjecture S (RQ-B Theorem 4) and is implied
  by ID*(C) for any C <= sqrt(2/e). ID* is tight on the Dirac curve (K = delta_x, x >= 1: E|Z_K| = g(1/x^2)),
  so a proof must treat a band around it separately ("band lemma", RQ-D's T1) from the rest ("far region",
  C5 with margin eta_K, RQ-B's certificates).
- U.4 NUMERICAL (numerics/band_scan.py, numerics/band_scan_results.txt; local optimisation over K with up
  to 6 atoms, not exhaustive). With theta = 0.7 or 0.8 and residual mass rho^2 = K(-theta, theta): far
  region rho^2 >= 0.05 has sup E|Z_K| <= sqrt(2/e) - 0.0116; band rho^2 in [0.01, 0.3] has
  E|Z_K| - max(g(lambda+), g(lambda-), sqrt(2/e) - 0.0018) <= -0.0017.
- U.5 FAILED (as a proof route, so far). A band lemma from the exact OR-region identity (RQ-D's D2) with
  Cauchy-Schwarz for the main term and Cantelli/exponential bounds for the residual terms
  (numerics/band_bound.py): at first order in the residual mass the bounds lose (rates 0.18 + 0.25 + 0.07
  against the available 0.43 per unit mass at delta_sqrt2), because the flip term is bounded too crudely
  when the largest residual jump is close to the compensator J. A jump-aware bound is needed.
- U.6 PROVED (elementary; one-signed K only; audited VALID, RQ-AUD A.31, 17:23 UTC, remark r1 applied: (a) KNOWN
  within the project, (b)-(c) NEW as stated). Let K be a finitely supported probability measure on (0, oo),
  m = m(K) = int x^(-1) dK, theta >= m, Lambda = lambda+_theta(K), rho^2 = K((0, theta)), S_R the sum of the jumps
  below theta (Levy measure x^(-2) K restricted to (0, theta)), m_R = E S_R, m_S = m - m_R. Then
  (a) E|Z_K| = 2 e^(-Lambda) E(m - S_R)_+ = 2 e^(-Lambda) [m_S + E(S_R - m)_+];
  (b) E|Z_K| <= B(Lambda, rho^2) := e^(-Lambda) [sqrt(Lambda (1 - rho^2)) + sqrt(rho^2 + Lambda (1 - rho^2))];
  (c) if lambda+_m(K) >= 1/2, then E|Z_K| <= g(lambda+_m(K)), with equality iff K is a single atom. So ID*(C)
      holds for such K with theta = m(K), for every C. The same holds for K carried by (-oo, 0) (reflect).
  Proof. (a) Let S >= 0 be the sum of all jumps, so Z_K = S - m. On {N_S >= 1} (some jump >= theta >= m) S >= m.
  As E Z_K = 0, E|Z_K| = 2 E(m - S)_+ = 2 P(N_S = 0) E(m - S_R)_+ = 2 e^(-Lambda) E(m - S_R)_+ (S_R is independent
  of the jumps >= theta), and E(m - S_R)_+ = (m - m_R) + E(S_R - m)_+. [(a) is RQ-D's D2 (audit A.30) in the case
  where the flip term vanishes.] (b) W = S_R - m_R has E W = 0, E W^2 = rho^2, and
  E(W - t)_+ = (E|W - t| - t)/2 <= (sqrt(rho^2 + t^2) - t)/2. With S_R - m = W - m_S this gives
  E|Z_K| <= e^(-Lambda) [m_S + sqrt(rho^2 + m_S^2)], which increases with m_S, and m_S = int_[theta,oo) x^(-1) dK
  <= sqrt(Lambda (1 - rho^2)) by Cauchy-Schwarz. (c) Take theta = m. For h(t) = sqrt(Lambda (1 - t)) +
  sqrt(t + Lambda (1 - t)), 2 h'(t) = (1 - Lambda)/sqrt(t + Lambda (1 - t)) - Lambda/sqrt(Lambda (1 - t)) <= 0 on
  [0, 1) when Lambda >= 1/2 (1 - Lambda <= Lambda, t + Lambda (1 - t) >= Lambda (1 - t)). So B = e^(-Lambda) h(rho^2)
  <= e^(-Lambda) h(0) = g(Lambda). Equality forces rho^2 = 0 (h strictly decreasing for Lambda > 1/2; for
  Lambda = 1/2, h(t) < h(0) for t > 0 directly) and equality in Cauchy-Schwarz (one atom). []
  Scope and limits. (i) theta = m(K) is not a valid choice in general: a residual with many small jumps makes m(K)
  large and lambda+_m(K) = 0 while E|Z_K| stays near g(1/2). (ii) For Lambda < 1/2, (b) does not settle ID*
  (B > max(g(Lambda), C(q_5)) on a grid): e.g. for rho^2 in [0.001, 0.078] at Lambda = 0.49, [0.001, 0.359] at
  Lambda = 0.45, [0.21, 0.86] at Lambda = 0.3, [0.67, 1] at Lambda = 0.005 (outputs/sp_scarf_region.txt,
  numerics/sp_scarf_region.py). Closed form (RQ-AUD, A.31): for 1/4 < Lambda < 1/2 with g(Lambda) > C,
  {B > g(Lambda)} = (0, 8 Lambda (1 - 2 Lambda)) (0.0784 at Lambda = 0.49, 0.36 at Lambda = 0.45). (iii) Two-signed K are not covered, and cannot be reduced to
  one-signed K by reflection (RQ-B F13). NUMERICAL companions (local optimisation, not proofs):
  numerics/sp_idstar_scan.py (one big atom + 2 residual atoms >= 0.02 m; theta = m): over rho^2 >= 0.01 the
  sup of E|Z_K| - max(g(lambda+_m), C) is about -0.004 for C(q_5) and -0.002 for C(q_6), and 0 on the Dirac curve
  (outputs/sp_idstar_scan_J2.txt); numerics/sp_half_check.py checks (c) against direct Poisson enumeration on 400
  random K (max of E|Z_K| - g = -1.0e-6, outputs/sp_half_check.txt).
- U.7 CONJECTURE (sign lemma), with NUMERICAL evidence. For q < 1/2 every maximiser of E|sum alpha_i chi_i| on the
  unit sphere of R^n is one-signed up to the global sign (this implies that the q-biased level-one weight
  sum_i Delta_i(f)^2 of Boolean f is maximised by a monotone f; the converse gives only that some maximiser is
  one-signed, which is all the consequence below uses).
  Consequence (PROVED, given the conjecture; audited VALID as an implication, RQ-AUD A.33, 18:17 UTC, remark r1
  applied: "equivalently" replaced by "this implies"): in U.1 the maximiser can be taken with alpha >= 0, so beta = alpha >= 0
  and K_f is carried by (0, oo). Hence ID*(C) is needed for one-signed K only, and the two-signed directions (the
  cheapest ones at delta_sqrt2 per RQ-C, a small atom near -a; RQ-B F13) drop out of the all-q plan.
  Known cases: n <= 7 and every q < 1/2 (RQ-C's C6, audited A.5/A.5b: the only maximisers are +-1_S/sqrt(k*), and at
  q = q_k* also with k* - 1 coordinates; noted in A.33), so U.7 is open only for n >= 8.
  Evidence: (i) n = 2 is exact and elementary: E|cos(psi) chi_1 - sin(psi) chi_2| = 2 tau max(cos psi, sin psi)
  <= 2 tau. (ii) numerics/sign_test.py (outputs/sign_test.txt): for 12 values of q in [0.02, 0.45] and n <= 7
  (exact enumeration, multistart), the best alpha with a coefficient <= -0.05 and one >= 0.05 equals
  sqrt(1 - 0.05^2) times the best one-signed value on n - 1 coordinates: the negative coefficient sits at the
  constraint and only costs the normalisation. (iii) numerics/sign_test_struct.py (outputs/sign_test_struct.txt):
  alpha = (a 1_k, -b 1_j), k <= 40, j <= 12, exact binomial sums, 14 values of q in [0.01, 0.45]: with a, b >= 0.05
  the sup of E|L|/M(q) is sqrt(1 - 0.05^2) = 0.998749, attained at b = 0.05, j = 1, k = k*(q).
  Without the restriction a >= 0.05 the sup is approached as a -> 0, which is the sign-flipped one-signed vector.
  FAILED (numerical, exact enumeration): the pointwise "opposite-skew mixing" form, i.e.
  E|cos(t) X + sin(t) Y| <= max(E|X|, E|Y|) for normalised one-signed X and sign-flipped one-signed Y. At q = 0.15,
  X = 6 equal bits (E|X| = 0.776) and Y = -(1, 0.024, 0.03)/norm (E|Y| = 0.714): the mixture reaches 0.038 above both
  (numerics/mixing_test.py, outputs/mixing_test.txt). A proof of U.7 must use maximality; mixing helps when neither
  part is near-optimal.
- U.8 NUMERICAL (for the far region of ID*, RQ-B's part; numerics/atomsplit_feas.py, outputs/atomsplit_feas_D12.txt,
  _D14.txt, _D16.txt; float LPs over measures on a grid, HiGHS). Let V_D(K) = sup{E|Y| : E Y^j = E Z_K^j, j <= D}.
  Any certificate of the form E|Z_K| <= E phi(Z_K) with a polynomial phi >= |z| of degree D gives at best V_D(K).
  (a) Gaussian corner (K = delta_0, Z_K = G; outputs/atomsplit_gauss_corner.txt, 8001-point grid): V_D = 0.888067,
      0.888071, 0.856067, 0.856067, 0.840835, 0.840835, 0.831925, 0.831925 for D = 6, 8, ..., 20. So V_{4j+4} = V_{4j+2}:
      the optimal law for D = 4j+2 already meets the extra constraints up to a vanishing mass far out (the LP uses
      E Y^D <= instead of =, which has the same sup over measures on R; with "=" on a bounded grid the D = 12 value
      rises to 0.856067 as the grid widens: 0.853764, 0.855085, 0.855521, 0.855717 for half-widths 8, 12, 16, 20
      standard deviations). So degree-12 majorants cannot certify E|Z_K| <= C(q5) = 0.855100 (nor C(q4)) near the
      Gaussian corner, whatever the cells; degree 14 leaves a margin of 0.0143 there. (D = 6 and 10 agree with
      RQ-C's 0.888074 and 0.856068.)
  (b) Splitting off one atom exactly: with K = w1 delta_x1 + K_W, condition on N1 ~ Poisson(w1/x1^2) and bound
      E|c_n + W| by V_D of W at each shift c_n = x1 (n - lam1). On 16 test laws in the far region (K([0.85, oo)) < 0.8,
      K((-oo, -0.85]) < 0.8; one-signed and two-signed, with and without Gaussian part) the whole-law V_14 is
      0.80-0.846 (true E|Z_K| 0.59-0.809), the split bound is <= 0.826 (D = 12, 14) and <= 0.817 (D = 16) wherever the
      LPs solved, i.e. the loss falls from 0.03-0.22 to 0.003-0.04. Largest split bound: 0.3 delta_1.4 + 0.3 delta_0.7
      + 0.4 G (true 0.785; split 0.826 / 0.824 / 0.816 for D = 12 / 14 / 16).
  (c) Degree 14 does not suffice on the far region (numerics/far_vD_sup.py, outputs/far_vD_sup_D14.txt; search over
      up to three atoms plus a Gaussian part in F = {K on [-1.54, 1.54] : K([0.85, 1.54]) <= 0.8, K([-1.54, -0.85])
      <= 0.8}). K = 0.9448 delta_0.8499 + 0.0552 delta_-1.54 is in F (true E|Z_K| = 0.79658) and has
      V_14(K) = 0.857474 > C(q6) = 0.855984 (the same to 1e-6 for 2,001-16,001 grid points and for the mirror law);
      V_12, V_16, V_18, V_20 = 0.85833, 0.84487, 0.84297, 0.83615. So no degree-14 polynomial majorant certifies
      ID*(C(q5)) or ID*(C(q6)) at this K, whatever the cells; (a)'s statement "degree 14 leaves 0.0143" holds at the
      Gaussian corner only. One atom plus Gaussian part: V_14(0.0992 delta_-1.54 + 0.9008 G) = 0.84882. Dirac laws:
      V_14(delta_x) <= 0.837 for x in [0.5, 0.85). Splitting off the atom at -1.54 exactly (as in (b)) gives 0.80753 and
      0.83141 at these two laws (D = 14); splitting off the heavier atom does not help.
  (d) The opposite atom need not sit at the edge (numerics/far_edge_position.py, outputs/far_edge_position_D14.txt,
      _D16.txt; K = (1 - w) delta_x + w delta_-y, x in {0.80, 0.8499}): V_14 > C(q5) once y >= 1.30 (x = 0.8499) or
      y >= 1.40 (x = 0.80) for w around 0.055-0.07, and V_14 is still 0.848-0.853 for y in [1.0, 1.2] and
      w in [0.055, 0.10] (true E|Z_K| about 0.80). So treating only the jumps near the support edge exactly does
      not rescue degree 14. At D = 16 the maximum over this family is 0.8460 (x = 0.8499, y = 1.54, w = 0.10);
      RQ-B's three-atom laws (V_18 = 0.8489, RQ-B numerics/far14/optV18_*.out) bound sup_F V_16 from below, so
      the whole-law margin at D = 16 is at most 0.0062.
  (e) Conditioning on all big jumps (numerics/far_split2.py, outputs/far_split2.txt): condition on the Poisson
      counts of every atom with |x| >= 0.85 and bound E|c_n + W| for the residual W by its first D moments. At the
      three published numerical maximisers of F (RQ-C 0.8 delta_1.288 + 0.1 delta_-1.105 + 0.1 delta_0.85-,
      RQ-D's and RQ-B's variants; true 0.8255-0.8267) the bound exceeds the true value by <= 0.0008 at D = 8 and
      <= 0.0001 at D = 10, 12. With more residual mass the loss grows (residual 0.2: 0.0013 at D = 10; residual
      0.15 delta_0.85- + 0.15 G: 0.015 at D = 12), but those laws have smaller true values and the bounds stay
      <= 0.817. So in a general-jump split certificate the residual moment bound is not the bottleneck at the top
      of F; the cost lies in the unknown window laws and residual moments of a cell. (Some LPs at D = 14, 16 fail
      numerically for lattice residuals; values are grid-restricted, i.e. slightly below the true V_D.)
- U.9 PROVED (elementary; Stein's method with the zero-bias coupling, a standard tool (Goldstein 2010); the
  constant 1/2 comes from the Stein solution of |w|; filed for audit, AUDIT_REQUEST.md, 19:27 UTC; **audited VALID,
  RQ-AUD A.35, 20:37 UTC, no fix**: KNOWN within the project (BF3 Lemmas 9.5-9.6; one-sided form = RQ-B Prop. 6(b)),
  the two-sided form and the C(q5) threshold NEW as stated; awaiting an independent referee; LaTeX write-up
  `MAIN_RESULT_U9.pdf`, whose Lemma 5 proves the zero-bias identity for general K by truncating the jumps at eps,
  the approximation of A.35 remark r1). For every Kolmogorov probability measure K on R,
  |E|Z_K| - sqrt(2/pi)| <= (1/2) int |x| dK(x). Hence E|Z_K| <= C(q5) whenever int |x| dK <= 2 (C(q5) - sqrt(2/pi))
  = 0.114431... (truncated), and ID*(C(q5)) holds for these K with every theta.
  Proof. Let c = sqrt(2/pi), h(w) = |w| - c (E h(G) = 0) and f(w) = e^(w^2/2) int_{-oo}^w h(t) e^(-t^2/2) dt, so
  f' - w f = h. As h is even and E h(G) = 0, f is odd. Let M(w) = e^(w^2/2) int_w^oo e^(-t^2/2) dt (Mills ratio),
  M' = w M - 1, M(0) = sqrt(pi/2), M(w) = 1/w - 1/w^3 + O(w^-5) as w -> oo. For w > 0,
  int_{-oo}^w h e^(-t^2/2) dt = -int_w^oo (t - c) e^(-t^2/2) dt = -e^(-w^2/2) + c e^(-w^2/2) M(w), so f = c M - 1,
  f' = c (w M - 1), f'' = c ((1 + w^2) M - w) and (f''/c)' = w M (w^2 + 3) - (w^2 + 2). This is < 0 because
  M < B := (w^2 + 2)/(w^3 + 3w) on (0, oo): B' - w B + 1 = -6/(w^2 (w^2 + 3)^2) < 0, so r = B - M satisfies
  (r e^(-w^2/2))' = (B' - w B + 1) e^(-w^2/2) < 0, and r e^(-w^2/2) -> 0 as w -> oo; hence r > 0. So f'' is
  strictly decreasing on (0, oo), with limit 0 at oo (by the expansion of M) and limit c M(0) = 1 at 0+; thus
  0 < f'' <= 1 on (0, oo) and, f'' being odd, -1 <= f'' < 0 on (-oo, 0). Since f' = h + w f is continuous, f' is
  1-Lipschitz on R; also |f| <= 1 and f' is bounded.
  Zero bias: for Z = Z_K and every C^1 function g with g, g' bounded, E[Z g(Z)] = K({0}) E g'(Z) +
  int_{x != 0} E[g(Z + x) - g(Z)]/x dK(x) (Gaussian integration by parts and the Mecke formula for the Poisson part)
  = E g'(Z + U X), with X ~ K, U ~ U(0, 1) and Z independent. With g = f:
  E|Z| - c = E h(Z) = E[f'(Z) - Z f(Z)] = E[f'(Z) - f'(Z + U X)], and |f'(Z) - f'(Z + U X)| <= U |X|, so
  |E|Z| - c| <= E U E|X| = (1/2) int |x| dK. []
  Remarks. (i) The general bound ||f''|| <= 2 ||h'|| gives int |x| dK; the 1/2 uses ||f''|| = 1 for this h.
  (ii) NUMERICAL (numerics/stein_corner.py, outputs/stein_corner.txt): 0 < f'' <= 1, f'' decreasing and M < B at
  2580 points of (0, 60] (mpmath, 40 digits); over 3000 random K (1-3 atoms, optional Gaussian part, exact Poisson
  enumeration) the ratio (E|Z_K| - c)/((1/2) int |x| dK) lies in [-0.293, 0.087]. The bound is of first order in
  the atom size, while E|Z_K| - c is of second order in it: for K = (1 - eps) delta_0 + eps delta_x the bound is
  eps |x|/2 and the first variation of E|Z_K| at delta_0 in the direction delta_x - delta_0 is
  phi(0) (-x^2/12 + O(x^4)) < 0 (wording sharpened 22:22 UTC after A.35 addendum r3).
  (iii) Use in the far region: RQ-B's near-Gaussian maximisers of the split relaxation T_14 (RQ-B numerics/far14,
  optT14 and gcT14 runs: T_14 = 0.8398-0.8443 at Gaussian part 0.89-0.997) have int |x| dK = 0.015-0.112, so they
  lie in this corner.

## C0. Elementary facts
- C0.1 PROVED. E|aχ + bM| = 2τa + 2E R_a(bM) for M independent of χ with EM=0 (BF3 Lemma 9.4;
  re-derived: E|aχ+y| = q|au+y| + (1-q)|y-av| = 2τa + (2q-1)y + 2R_a(y); symbolic check in
  verify_all.py part A1).
- C0.2 PROVED. Cumulants of χ: κ3 = u-v, κ4 = u^2+v^2-4, κ5 = (u-v)(u^2+v^2-10),
  κ6 = w^2-26w+64 with w = u^2+v^2. Moments of M = Σβ_iχ_i (|β|=1), p_j = Σβ_i^j:
  EM^3 = κ3 p3, EM^4 = 3+κ4 p4, EM^5 = κ5 p5 + 10κ3 p3,
  EM^6 = 15 + 15κ4 p4 + 10κ3^2 p3^2 + κ6 p6.  (Additivity of cumulants; symbolic check of the
  cumulants and exact-enumeration check of the moment formulas in verify_all.py part A2.)
- C0.3 PROVED. If max|β_i| <= m <= 1: p3^2 <= p4 <= m^2, p4^2 <= p6 <= m^2 p4, |p5| <= m p4.
  (Cauchy-Schwarz and |β_i| <= m.)
- C0.4 PROVED. Two equal coefficients: E|χ1+χ2|/sqrt2 = sqrt2(1-q)·2τ; more generally for
  a,b>0 with q/(1-q) <= b/a <= (1-q)/q: E|aχ1+bχ2| = 2τ(1-q)(a+b).
- C0.5 PROVED. Level-one form ⇔ L1 form (BF3 end of 9.4; standard duality).

## K. Re-verification of BF3 Theorem K on [3/8,5/8] (now superseded by MAIN)
- K.1 PROVED (independent re-derivation). The logic of BF3's proof (Lemmas 9.4–9.7, Cases
  A/B/C, inequality (12) via zero discriminants, reduction of ψ<=1 to the cubic (13)) was
  re-derived line by line; no gap found. Mills-ratio derivatives A'(w), B'(w) and k'(w) verified
  symbolically (scripts/check_mills.py).
- K.2 PROVED (exact arithmetic, scripts/verify_thmK_bf3.py, outputs/verify_thmK_bf3.txt).
  Independent script, written from the statement only: Case A thresholds on the 64 intervals,
  Case B hypotheses, Case C via the box bound with bisection (2784 boxes with 4-way bisection,
  depth <= 6), and the hand tables for q = 3/8, 2/5, 5/12. All pass.

## N. New mechanism: six-moment relaxation of the remainder (no induction)
- N.1 PROVED (as Lemma S + cover; see MAIN). Originally NUMERICAL: the LP
  "max E R_a(bM) over laws of M subject to EM=0, EM^2=1 and the moment identities of C0.2 with
  power sums in the region of C0.3 (m = min(1,a/b))" has value <= τ(1-a) for all q in [q0,1/2],
  a in (0,1); margin 0 only at (q0, 1/sqrt2) and as a -> 1 (scripts/scan_lp6.py).
  As a -> 0 the LP tends to sup{E|X| : EX^k = EZ^k, k<=6} = 0.8881, < 2τ iff q > 0.27015 (corrected from 0.2744, audit A.6 fix f1).
  Near (q0,1/sqrt2) the LP margin is ≈ sqrt2 (q-q0), i.e. the LP is asymptotically exact there.
- N.2 PROVED (as Lemma Q + box cover; see MAIN). Quartic certificate
  P(y) = (y+v)^2(c4 y^2+By+G), tangent to R_a(b·) at y = u and y = -v. Closed forms:
  B0 = tau^4(2a-b(u^2-1)), s = tau^3(b u^2-a), B = B0-2c4 u, G = s-B0 u+c4 u^2;
  P >= 0 and P >= l1 iff c4 > B0^2/(4s); E P(M) <= E P(χ) iff c4 <= κ3 B0/4 (uses κ3^2-κ4 = 2);
  P >= l2 via an explicit sufficient condition on the Taylor coefficients at y = -au/b.
  Gives E R_a(bM) <= E R_a(bχ), hence E|L| <= E|aχ1+bχ2| = 2τ(1-q)(a+b) <= 2τ for q >= q0.
- N.3 PROVED (Lemma D). For a >= 9/10 and u in [1,u0]: E R_a(bM) <= 0.9402 τ(1-a), from
  (x-t)_+ <= 27x^4/(256t^3), EM^4 <= 3 (κ4 <= 0) and u^4+v^4 <= 6.

## Dead ends (reasoning, recorded for the other agents)
- FAILED: 1-D Bellman function V(x) (adaptive game value >= 2τ sqrt(1+θ^2) > 2τ).
- FAILED: gradient-recursion Bellman B(p) (strict concavity fails for all q < 1/2).
- FAILED: moment LP with only {EM, EM^2, E|M|} (fake two-point law at q0, P(top) = 0.2295).
- BF3 method (Stein/zero-bias + cubic) stops near q ≈ 0.37.
