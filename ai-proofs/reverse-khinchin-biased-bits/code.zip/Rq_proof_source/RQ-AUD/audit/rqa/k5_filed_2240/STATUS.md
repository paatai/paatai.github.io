# STATUS (RQ-A)

Last update: 2026-10-22 22:39 UTC.

Goal (since 14:14 UTC, COMMON.md update): Conjecture S for all q,
R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1). Deadline Sun Oct 25 22:30 PT (Mon Oct 26 05:30 UTC).
RQ-A's part: finish the k = 4 and k = 5 covers (the finite part) and a mechanism uniform in k
(see "Uniform in k" below and NOTES_FOR_TEAM.md).

## Headline

- **New: Theorem 5 (MAIN-5, k = 4 regime) audited VALID, NEW (RQ-AUD A.25, 16:53 UTC, no fix to the
  mathematics):** R(q) = 4 (1-q)^3 sqrt(q(1-q)) exactly on [q5, q4] = [0.105573, 0.133975]; with Theorems 1-4
  the conjecture holds on [q5, 1-q5] = [0.10557, 0.89443]. A.25's two status remarks applied (17:46 UTC).
  Awaiting an independent referee (Theorems 1-4 are already referee-VALID, RQ-REF1).
- **New: reduction U.1 (PROVED, CLAIMS.md U; = RQ-B C19, audited VALID with U.2 in A.26):** Conjecture S on
  (0, q_K] follows from one q-free statement about infinitely divisible laws, ID*(C(q_K)) with
  C(q4) = 0.8533435684..., C(q5) = 0.8551004554..., C(q6) = 0.8559844891... (a decimal used in place of C(q_K)
  must not exceed it; audit A.26 fix f1 applied 16:33 UTC). Its band part is RQ-D's, its far part RQ-B's.
- **All q is now conditional on one open statement (audited reduction, A.34, 20:19 UTC):** RQ-D's band lemma
  (Theorem 13, theta = 0.85, A = 1.54, mass threshold 4/5) is audited VALID, NEW (A.34). With A.25 (MAIN-5),
  A.26 (U.1-U.2) and A.28 (localisation to [-1.54, 1.54]), Conjecture S for all q follows once
  E|Z_K| <= C5 = 0.8551004554... is proved on the far region F = {K on [-1.54, 1.54] : K([0.85, 1.54]) < 4/5 and
  K([-1.54, -0.85]) < 4/5} (numerical sup about 0.8266). Division agreed 20:00-20:25 UTC: RQ-D certifies
  F_heavy (K([0.85, 1.54]) >= 1/2 or the mirror) by the general-jump split, RQ-B certifies F_light (both < 1/2).
- **New: U.9 PROVED, audited VALID (RQ-AUD A.35, 20:37 UTC, no fix):** |E|Z_K| - sqrt(2/pi)| <= (1/2) int |x| dK
  for every K (Stein's method, zero bias). Rated KNOWN within the project (BF3 Lemmas 9.5-9.6, RQ-B Prop. 6(b)); the
  two-sided form and the C(q5) threshold are NEW as stated. It settles the near-Gaussian corner of F
  (int |x| dK <= 0.114431), where moment certificates are weakest (CLAIMS U.9, U.8). Write-up `MAIN_RESULT_U9.pdf`
  (4 pages). Awaiting an independent referee.
- **New: Theorem 6 (MAIN-6, k = 5 regime) PROVED and filed for audit (22:37 UTC):** R(q) = 2 sqrt5 (1-q)^4
  sqrt(q(1-q)) exactly on [q6, q5] = [0.087129, 0.105573] (and the mirror), sharp; with Theorems 1-5 the conjecture
  holds on [q6, 1-q6] = [0.08713, 0.91287]. Proof `MAIN_RESULT_K5.pdf` (24 pages). The cover (105 data files, 54 of
  them computed by RQ-C; 9166 boxes and 861 cells, 52,292 vertex-certificate sets, 0 failures) passes the independent
  verifier `verify_k5.py` on all data (parts A-G ALL PASS, 22:35 UTC, 4449 s on 8 cores); all 799 corrupted records
  of the 21 negative tests are rejected. Once MAIN-6 is VALID, F needs only C(q6) = 0.8559844891... instead of C(q5).
- **F (the open statement):** RQ-D reports F_heavy certified in arb (22:06 UTC, worst bound 0.854883 < C5; to be
  filed as D21). RQ-B reports cases 2 and 3 of F_light done and re-verified (22:25 UTC; worst 0.85495525), case 1
  (7956 near-split boxes) running. Not yet audited.
- **Auditor addenda (21:19 UTC):** A.25 stays VALID after MAIN-5's text corrections c1-c2; A.35 stays VALID (the U.9
  PDF matches the audited proof). Their r3 items are applied (22:21-22:22 UTC: the MAIN-5 md5 in AUDIT_REQUEST.md
  corrected; U.9 Remark 2 says "second order in the atom size").

R(q) is known exactly (audited) on [q5, 1-q5] = [1-2/sqrt5, 2/sqrt5] = [0.10557, 0.89443]:

    R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2, 2 qh^3} = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1),
    qh = max(q, 1-q).

This is the conjectured formula on its first four regimes (k = 1, 2, 3, 4 equal coefficients; Theorems 1-4
below and Theorem 5), each on its largest possible interval. Theorem 6 (filed, not yet audited) adds k = 5 on
[q6, q5].

1. **Theorem 1 (MAIN, computer-assisted, rigorous; RQ-AUD verdict VALID, A.6):**
   R(q) = 2 sqrt(q(1-q)) for every q in [1-1/sqrt2, 1/sqrt2], and this interval is exactly the
   set where it holds (for q outside, (1,1)/sqrt2 beats e_1). Extremisers: ±e_j inside the
   range; additionally ±(e_i+e_j)/sqrt2 at the two endpoints. See `MAIN_RESULT.md` /
   `MAIN_RESULT.pdf`. Waiting for an independent referee.
2. **Theorem 2 (MAIN-2, computer-assisted, independently re-verified; RQ-AUD verdict VALID,
   A.11, 08:52 UTC; two cosmetic text points applied afterwards):**
   R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) for every q in [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2]
   (and [1-q0, 1-q3]), and this interval is sharp. Extremisers ±(e_i+e_j)/sqrt2; additionally
   ±e_i at q0 and ±(e_i+e_j+e_k)/sqrt3 at q3. Full proof: `MAIN_RESULT_K2.pdf` /
   `MAIN_RESULT_K2.md`. Waiting for an independent referee.
3. **Theorem 3 (MAIN-3, computer-assisted, independently re-verified; RQ-AUD verdict VALID, A.14,
   10:37 UTC, no fix needed):** R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for every q in
   [25/169, q3] = [0.14793, 0.18350] (and [1-q3, 144/169]). Extremisers ±(e_i+e_j+e_k)/sqrt3;
   additionally ±(e_i+e_j)/sqrt2 at q3. Full proof: `MAIN_RESULT_K3.pdf` / `MAIN_RESULT_K3.md`.
   Waiting for an independent referee.
4. **Theorem 4 (MAIN-4, computer-assisted, independently re-verified; RQ-AUD verdict VALID, NEW,
   A.18, 12:41 UTC, no fix needed):** R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for
   every q in [q4, 25/169] = [0.13397, 0.14793] (and the mirror). Extremisers ±(e_i+e_j+e_k)/sqrt3;
   additionally ±(e_i+e_j+e_k+e_l)/2 at q4. Sharp: for q < q4, (1,1,1,1)/2 gives more. With
   Theorem 3: R = 2 sqrt3 (1-q)^2 tau exactly on [q4, q3], and this is exactly the set of q <= 1/2
   where it holds. Full proof: `MAIN_RESULT_K3B.pdf` / `MAIN_RESULT_K3B.md`. Waiting for an
   independent referee.

Per the locked note, nothing is to be reported outside the team until the auditor and an
independent referee rate it VALID.

## What the proofs use

1. BF3 Lemma 9.4: E|L| = 2 tau a + 2 E R_a(bM), where a is the largest coefficient.
2. Moment certificates (new mechanism, no induction). A polynomial P dominating the
   piecewise-linear conditional expectation gives E|L| <= E P(M), and E P(M) depends only on the
   power sums of the residual coefficients (cumulant identities); their admissible region
   gives a finite check, done in exact rationals with Sturm sequences. Degree 6 for Theorems 1-3,
   degree up to 10 for Theorem 4.
3. Theorem 1: one-coordinate split; quartic two-extremiser certificate near (q0, 1/sqrt2);
   near-dictator bound.
4. Theorems 2-4: two-coordinate split (the extremiser (1,1)/sqrt2 then sits at b = 0);
   near-circle lemma (fourth-moment tail bound, slack T b^2/(1+r)); one-coordinate cells for
   small a1; an m-split of the residual near (1,1,1)/sqrt3 (a capped certificate, a
   sign-constrained certificate with p3 <= phi(m_c) < 0, and a three-coordinate near-sphere bound
   that uses an exact three-bit lemma: sum_i Delta_i(f)^2 <= 8(1-q)^2 on [q3, q0] for k = 2,
   <= 12(1-q)^4 on [q_U, q3] for k = 3).
5. Theorem 4 adds: vertex certificates (convexity and 1-homogeneity of x -> E|x . (chi1, chi2, y)|:
   one certificate per vertex of a polytope whose cone contains the parameter patch, replacing the
   interval envelope over a box); ten-moment one-coordinate cells; and, inside the m-split, a
   second m-split with a four-coordinate near-sphere bound resting on an exact four-bit lemma
   (all 65,536 Boolean functions of four q-biased bits; tight only for OR of three bits, and at q4
   also for OR of four bits).

## Verification status

- Theorem 1: generation-side exact checks; independent verifier verify_all.py: ALL PASS;
  break_tests.py; audited VALID (A.6).
- Theorem 2: generation-side exact checks (cert2c.py, nearcircle.py, nsphere3.py); independent
  verifier verify_k2.py: ALL PASS, parts A-G (outputs/verify_k2_ABCDEFG.txt). Negative tests
  break_tests_k2.py. Audited VALID (A.11).
- Theorem 3: the same programs with RQ_K=3 (81,975 boxes + 2,704 cells); independent verifier
  `RQ_K=3 python3 verify_k2.py`: ALL PASS (outputs/verify_k3_ABCDEFG.txt); negative tests
  outputs/break_tests_k3.txt. Audited VALID (A.14).
- Theorem 4: generator side cover5.py / cert5.py / cert4.py / cover_lp10.py / tenmom.py /
  fourbit.py (1,421 boxes, 288 cells, 0 failures); independent verifier verify_k3b.py (parts A-G,
  93 s): ALL PASS (outputs/verify_k3b_ABCDEFG.txt); negative tests outputs/break_tests_k3b.txt (all
  corruptions rejected); data md5s outputs/k3b_MD5SUMS.txt. Audited VALID (A.18).

## Theorem 5 (MAIN-5, k = 4 regime [q5, q4]): PROVED; RQ-AUD VALID (A.25, 16:53 UTC); awaiting referee

- R(q) = 4 (1-q)^3 sqrt(q(1-q)) exactly on [q5, q4] = [1-2/sqrt5, 1-sqrt3/2] = [0.105573, 0.133975]
  (and the mirror), extremisers (e_i+e_j+e_k+e_l)/2, plus (e_i+e_j+e_k)/sqrt3 at q4 and
  (e_1+...+e_5)/sqrt5 at q5; sharp. Proof: `MAIN_RESULT_K4.pdf` (24 pages) / `MAIN_RESULT_K4.md`.
- Cover complete at 15:33 UTC: 80 jobs (scripts/run_k4.sh, job list outputs/k4/jobs_all.txt), 7,261
  two-coordinate boxes (3,327 + 1,216 lpv, 2,718 m-split) and 1,268 one-coordinate cells, 0 failures;
  21,014 vertex-certificate sets (171,488 vertices); 2,533 four- and 383 five-coordinate near-sphere pieces.
- Independent verifier `scripts/verify_k4.py`: parts A-G ALL PASS on all data (outputs/verify_k4_ABCDEFG.txt,
  367 s on 8 cores). Negative tests `scripts/break_tests_k4.py`: all 23 corruption types rejected, sanity
  checks hold (outputs/break_tests_k4.txt). Data md5s outputs/k4_MD5SUMS.txt.
- New ingredients (vs Theorem 4): k = 4 bit lemmas (audited, A.20); the OR-region identity (audited, A.20);
  one more level of the m-split (TCN, inner TC4/TC4S/SG3 pieces) with the five-coordinate near-sphere bound
  at (1,...,1)/sqrt5; vertex sets with four patch parameters; exact cone test (Lemma 21, facet minima).

## Theorem 6 (MAIN-6, k = 5 regime [q6, q5]): PROVED; filed for audit 22:37 UTC

- Target: R(q) = 2 sqrt5 (1-q)^4 sqrt(q(1-q)) exactly on [q6, q5] = [1-sqrt(5/6), 1-2/sqrt5] =
  [0.087129, 0.105573], extremisers (e_1+...+e_5)/sqrt5, plus (e_1+...+e_4)/2 at q5 and
  (e_1+...+e_6)/sqrt6 at q6. Status: PROVED (computer-assisted), filed for audit 22:37 UTC (AUDIT_REQUEST.md,
  MAIN-6); not yet audited or refereed.
- Independent verification on all data (finish_k5.sh, 21:21-22:35 UTC, log outputs/k5_finish.log): `verify_k5.py`
  parts A-G ALL PASS (outputs/verify_k5_ABCDEFG.txt; 4449 s on 8 cores, 9.8 CPU-hours, part D 4422 s for the
  784,616 vertices). `break_tests_k5.py` (26 s, outputs/break_tests_k5.txt): 21 corruption tests, all 799 corrupted
  records rejected; 4 sanity checks hold.
- Data files (complete 21:21 UTC): 105 in all, every one with 0 failures. They are one_0 ... one_3, m_0 ... m_32,
  p_0 ... p_23, and u-subslabs for the rest: p_24s0 ... p_30s3 (4 each) and p_31s0 ... p_32s7 (8 each).
  - RQ-C computed 54 of them: m_0 ... m_32, p_10 ... p_23, p_24s0 ... s3 and p_25s1 ... s3. Each matches RQ-C's
    MD5SUMS.txt (`outputs/k5/RQC_MD5SUMS.txt`).
  - RQ-A computed the other 51.
  - `scripts/run_k5.sh` writes exactly these 105 jobs (`outputs/k5/jobs_all.txt`).
- Subslabs for p_24 ... p_27 (queued 20:28 UTC; `outputs/k5/queue.txt`). Each slab runs as 4 u-subslabs, p_24s0 ...
  p_27s3, because RQ-C's whole-slab runs of these slabs stalled: after 4.4-5.5 h they had 0-40 boxes done.
  RQ-C paused those runs at 20:47 UTC. Their queue lines here are commented out (21:04 UTC) so that they are never
  restarted. make_manifest.py uses p_i.json if it exists and otherwise the subslabs. Since 20:28 UTC it also checks
  that the files of each sign tile [U_LO, U_HI]. Before that, an incomplete set of subslabs would have passed it,
  but verify_k5.py's tiling check would still have rejected it.
- Two duplicate local starts (20:20 and 20:25 UTC) of p_14 and p_15, which RQ-C was finishing, were killed and
  left no data: RQ-C's RUNNING.txt drops a job shortly before DONE.txt lists it. The scheduler now remembers
  RQ-C's running jobs for 15 minutes.
- Repaired defect (19:36-19:42 UTC). The first run of one_1 (u in [3, 3.1]) ended with 2 of 245 cells failed,
  u in [3 + 254/10240, 3 + 256/10240] x a in [351/2048, 352/2048]: HiGHS's simplex stopped with status 15 (model
  status Unknown) on the float LP there, at every depth down to the limit (log kept as outputs/k5/logs/one_1.run1.log).
  The scheduler counted the job as done because its json existed; make_manifest.py and verify_k5.py reject any file
  with failures, so nothing unproved could have entered the theorem. Repair: with RQ_LPFALLBACK=1, cover_lp10.py
  retries a failed LP with the interior-point method and at other reference points (the LP only proposes P; the exact
  checks are unchanged); run_k5.sh sets it for the one_ jobs. Re-runs of all four one_ jobs: one_0, one_2, one_3
  came out byte-identical (the fallback never triggers there); one_1 now has 232 cells, 0 failed (the former failures
  lie in one cell proved at depth 4) and passes verify_k5.py's tiling and cell checks (corrupted cells rejected).
  k5_sched.py now lists jobs whose json records failures under "done-with-failures" (restarted 19:41 UTC).
- Sub-slabs near
  u6 take 40-100 min each, the subslabs of p_24 ... p_27 12-40 min, plain slabs 30-60 min (p_23: 135 min). The two-coordinate jobs
  took 65.6 h in total; the cover ended at 21:21 UTC. Scheduler
  `scripts/k5_sched.py` (skips what RQ-C's RUNNING.txt lists, imports RQ-C's deliveries after an md5 check).
- `MAIN_RESULT_K5.tex` (Theorem 6): 24 pages, complete (k = 5 bit lemmas, OR-region identity with T_n <= T5,
  one-coordinate route with A_S = 1/4, vertex certificates for any number of peeled coordinates, general
  n-coordinate near-sphere lemma, recursive split nodes by induction on the height; data, generation, verification
  and negative tests with the final numbers). An internal pre-audit review found no mathematical error; its 12
  points are applied.
- Earlier partial verification (48 data files: m_0 ... m_32, p_0 ... p_9, p_32s0 ... s3, p_22): `verify_k5.py` parts A, D,
  E, F, G ALL PASS (outputs/verify_k5_partial_ADEFG.txt: 39 files, 868 s; outputs/verify_k5_partial_new1.txt: 6 files,
  4,774 vertex sets / 75,420 vertices from 690 boxes, 360 m-split boxes, 1,727 s; outputs/verify_k5_partial_new2.txt:
  p_32s2, p_32s3, p_22, 388 boxes, 217 m-split boxes, 1,778 s). Negative tests on the first 39 files: all 19
  corruption types rejected, the 3 sanity checks hold (outputs/break_tests_k5_partial.txt). The full run (all parts,
  all files) is the one above.
- PROVED (exact, generator and independent verifier agree): k = 5 three- and four-bit lemmas,
  sum_i Delta_i(f)^2 <= 20 (1-q)^8 on [q6, q5] for all 256 / 65,536 f; strict for 3 bits; for 4 bits
  equality only for ±OR_4 at q5 (scripts/bitlemma_k5.py, verify_k5.py part G).
- Same proof architecture as Theorem 5 with deeper nesting (scripts/cover6.py: split nodes of depth
  <= 2, near-sphere pieces with up to six coordinates; the six-coordinate test at
  (1,...,1)/sqrt6 uses the OR-region identity and T6 <= T5 on [q6, q5]). Probes: the three
  extremiser boxes (OR4 at u5, OR5 inside, OR6 at u6) all close; the OR6 tie box needed a level-0
  cut at 3/10 (the moment LP is too weak above about 0.3 there) and splits only on narrow intervals.
- Independent verifier scripts/verify_k5.py written (recursive; passes on the three probe boxes).
- Fixed a latent defect found by the k = 5 run: the exact range of the cumulant polynomials G_j(w)
  was computed by bisecting until the derivative has no root; G_9' vanishes at u = 2.926.. (inside
  [q6, q5]), so this did not terminate (generator raised, verifier would recurse forever). Both
  now enclose such subintervals by interval Horner evaluation after a fixed depth (rigorous).
  Theorems 1-5 never met a critical point (their runs completed), so they are unaffected.

## Uniform in k (16:00 UTC: reduction proved; division of labour agreed; 19:35 UTC: only the far region F is open)

- **U.1 PROVED (CLAIMS.md U):** if ID*(C) holds (every finitely supported Kolmogorov probability measure K has
  some theta > 0 with E|Z_K| <= max(g(lam+_theta(K)), g(lam-_theta(K)), C), g(l) = 2 sqrt(l) e^-l,
  lam+-_theta = expected numbers of jumps of size >= theta of each sign), then R(q) = M(q) for every q with
  C(q) = max_k g(ks) >= C, s = ln 1/(1-q). Proof: RQ-B's Poissonisation (Theorem 3, audited A.10a) applied to
  the maximiser gives R_n <= sqrt(q/((1-q)s)) E|Z_K| with K = sum alpha_i^2 delta_{alpha_i/sqrt s}, and for this
  K, lam+-_theta(K) are integer multiples of s, so g(lam+-) <= C(q).
- U.2: min of C(q) on (0, q_K] is C(q_K) = 0.8533435684... (K = 4), 0.8551004554... (K = 5),
  0.8559844891... (K = 6). So ID*(0.855100) plus MAIN-1..5 gives Conjecture S for all q; ID*(0.8533435) would
  not even need MAIN-5. (Audit A.26: U.1, U.2 VALID; fix f1 = the earlier "0.853344" was C(q4) rounded up.)
- ID* contains C5 (necessary for Conjecture S anyway, RQ-B Theorem 4) and is tight on the Dirac curve, so it
  splits into a band lemma near the Dirac curve (RQ-D took it over at 15:58 UTC, with RQ-A's notes on why the
  simple bound chain fails, CLAIMS U.5) and "E|Z_K| <= C off the band" (RQ-B's certificate covers;
  numerically the margin there is about 0.009, U.4).
- Band: done by RQ-D (Theorem 13, certified in arb, 19:01 UTC; audited VALID, NEW, A.34, 20:19 UTC). With RQ-C's
  localisation (A.28) what remains is E|Z_K| <= C5 on F (see Headline): RQ-D takes F_heavy, RQ-B F_light.
- U.6 (audited A.31): exact form and ID* for one-signed K with lambda+_m(K) >= 1/2. U.7 (sign lemma) is a
  CONJECTURE; its consequence (one-signed K suffice) is audited VALID as an implication (A.33); known for n <= 7.
- U.8 NUMERICAL (what moment certificates can do on F; any degree-D polynomial majorant gives at best V_D(K), the
  sup of E|Y| over laws with the first D moments of Z_K): degree 14 fails at K = 0.9448 delta_0.8499 +
  0.0552 delta_-1.54 (V_14 = 0.857474 > C(q6)), also with the opposite atom away from the edge (U.8 (d)); at degree
  16 the whole-law margin is at most 0.0062 (RQ-B's three-atom laws have V_18 = 0.8489). Splitting off atoms exactly
  (condition on their Poisson counts) cuts the loss from 0.03-0.22 to 0.003-0.04 (U.8 (b)), which is what RQ-B's and
  RQ-D's far-region designs do.
- U.9 PROVED (committed 19:23 UTC; filed for audit 19:27 UTC; audited VALID, A.35, 20:37 UTC): |E|Z_K| - sqrt(2/pi)| <= (1/2) int |x| dK. A far-region
  cover may therefore assume int |x| dK >= 0.114431 (the corner where moment majorants are weakest, U.8 (a)).
- RQ-A's remaining part: the finite regimes (k = 5 now; MAIN-6 lowers the constant needed on F from C(q5) to
  C(q6)) and support for RQ-B on F (U.8, U.9; 8 cores offered once the k = 5 cover ends).

### Original plan (14:50 UTC)

- Regime-by-regime covers cannot reach all k (the nested splits near OR_k get deeper with k). Plan:
  (P0) finite-q localisation of maximisers (support of K_alpha = sum alpha_i^2 delta_{u alpha_i});
  (P1, RQ-A) an exact band lemma near the Dirac parabola m2 = m1^2 of K_alpha, uniform in k, from the
  OR-region identity with a residual (generalises the near-sphere tests of Theorems 4-6 to any number
  of coordinates); (P2, proposed to RQ-B) RQ-B's cell cover of the ID problem on the complement of
  the band with margin eta below sqrt(2/e). Reading RQ-B's Theorem 3 at the maximiser, eta = 0.00443
  suffices for every q <= q4 (eta = 0.0027 with k = 4, 0.0018 with k = 5), i.e. C5 itself is not
  needed away from the extremisers.

## Next

- MAIN-6: answer audit and referee questions (filed 22:37 UTC).
- MAIN-5 and U.9: audited VALID (A.25, A.35, with the 21:19 addenda); answer referee questions.
- F: RQ-A's 8 cores are free since 22:36 UTC; offered to RQ-B (F_light case 1) and RQ-D (NOTES_FOR_TEAM.md,
  22:40 UTC). Numerical support on request (U.8, U.9).
