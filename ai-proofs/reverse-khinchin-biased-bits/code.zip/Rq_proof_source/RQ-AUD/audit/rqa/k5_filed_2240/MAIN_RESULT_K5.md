# MAIN RESULT 6 (RQ-A): $R(q)=2\sqrt5\,(1-q)^4\sqrt{q(1-q)}$ for every $q\in[1-\sqrt{5/6},\,1-\frac2{\sqrt5}]$, the whole $k=5$ regime

**Status:** PROVED (computer-assisted; every computer step is exact rational arithmetic or certified
interval arithmetic, and was re-done by an independent program). **Not yet audited** (filed for audit as MAIN-6,
2026-10-22 22:37 UTC). Do not report outside the team before the auditor and an independent referee rate it VALID.

PDF version (same content, LaTeX): `MAIN_RESULT_K5.pdf` (source `MAIN_RESULT_K5.tex`).
This file was generated from the LaTeX source with pandoc, so the two contain the same proof.

**One-command check:** `cd scripts && python3 verify_k5.py` (4449 s, i.e. 74 minutes, on 8 cores; 9.8 CPU-hours). It prints
`ALL REQUESTED PARTS PASS (A B C D E F G)`. The output is in `outputs/verify_k5_ABCDEFG.txt`.
Negative tests: `python3 break_tests_k5.py` (26 s; output `outputs/break_tests_k5.txt`: all 799 corrupted records of 21 tests rejected, 4 sanity checks hold). Data: the 105 files listed
in `outputs/k5_manifest.json` (md5 sums in `outputs/k5_MD5SUMS.txt`).

This determines $R$ exactly on the whole regime where five equal coefficients are optimal:
$R(q)=2\sqrt5\,(1-q)^4\sqrt{q(1-q)}$ for $q\in[q_6,q_5]=[1-\sqrt{5/6},1-\frac2{\sqrt5}]=[0.087129,0.105573]$, and
this is exactly the set of $q\le\frac12$ where the formula holds. Extremisers: $(e_{i_1}+\dots+e_{i_5})/\sqrt5$;
also $(e_i+e_j+e_k+e_l)/2$ at $q_5$ and $(e_{i_1}+\dots+e_{i_6})/\sqrt6$ at $q_6$. With Theorems 1–5 (audited VALID
as A.6, A.11, A.14, A.18 and A.25): $R(q)=2\sqrt{q(1-q)}\max_{k\ge1}\sqrt k\,\hat q^{k-1}$, $\hat q=\max(q,1-q)$, for
all $q\in[1-\sqrt{5/6},\sqrt{5/6}]$.

## Map of the proof

| piece | region | lemma | verification |
|---|---|---|---|
| one-coordinate cells (degree 10) | $a_1\le 1/4$ (861 cells) | Lemmas 10–16 | `outputs/k5/one_*.json`, exact (Sturm) |
| vertex certificates (`lpv`) | 4863 boxes (3804 with $s=+1$, 1059 with $s=-1$) | Lemmas 17–26 | `outputs/k5/{p,m}_*.json`, exact (Sturm, Gaussian elimination, exact facet minima) |
| $m$-split boxes (`ms`) | 4303 boxes ($s=+1$) near $(e_1+\dots+e_4)/2$, $(e_1+\dots+e_5)/\sqrt5$ and $(e_1+\dots+e_6)/\sqrt6$ | Lemmas 18, 29–33 | exact + interval arithmetic |
| OR-region identity, three- and four-bit lemmas | all $c\in\mathbb R^n$; all $c\in\mathbb R^3$, $c\in\mathbb R^4$ | Lemmas 6–8 | exact Sturm, 256 and 65,536 Boolean functions |

The proof also provides near-circle boxes (kinds `ncA`/`ncB`, Lemmas 27–28) and `small` boxes. Neither occurs in
the final data: every two-coordinate box is `lpv` or `ms` (Table 1 of the PDF). The cover uses 52,292
vertex-certificate sets with 784,616 vertices (4863 sets in `lpv` boxes, 47,429 in split nodes). In the split trees
it uses near-sphere bounds with four, five and six coordinates.

---

# Statement

Fix $q\in(0,1)$ and put $$u=\sqrt{\tfrac{1-q}{q}},\qquad v=\frac1u,\qquad \tau=\sqrt{q(1-q)} .$$ Let $\chi,\chi_1,\chi_2,\dots$ be i.i.d. with $\Pr[\chi=u]=q$ and $\Pr[\chi=-v]=1-q$, so that $\mathbb{E}\chi=0$, $\mathbb{E}\chi^2=1$ and $\mathbb{E}|\chi|=2\tau$. Let $$R(q)=\sup_{n\ge1}\ \sup_{\alpha\in\mathbb{R}^n\setminus\{0\}}\frac{\mathbb{E}|\sum_{i=1}^n\alpha_i\chi_i|}{|\alpha|_2}.$$ Put $$q_5=1-\tfrac{2}{\sqrt5}\approx0.105573,\qquad q_6=1-\sqrt{\tfrac56}\approx0.087129,$$ and, for $k\ge1$, $T_k=2\sqrt k\,(1-q)^{k-1}\tau$; thus $$T_2=2\sqrt2\,(1-q)\,\tau,\quad T_4=4(1-q)^3\,\tau,\quad T_5=2\sqrt5\,(1-q)^4\,\tau,\quad
T_6=2\sqrt6\,(1-q)^5\,\tau .$$

**Theorem 6**.

1.  *For every $q\in[q_6,q_5]$, every $n\ge1$ and every $\alpha\in\mathbb{R}^n$ with $|\alpha|_2=1$, $$\mathbb{E}\Big|\sum_{i=1}^n\alpha_i\chi_i\Big|\le 2\sqrt5\,(1-q)^4\sqrt{q(1-q)} .$$ For $q\in[1-q_5,1-q_6]$ the same holds with $1-q$ replaced by $q$. Consequently $R(q)=2\sqrt5\max(q,1-q)^4\sqrt{q(1-q)}$ for $q\in[q_6,q_5]\cup[1-q_5,1-q_6]$.*

2.  *(Extremisers.) Let $q\in[q_6,q_5]\cup[1-q_5,1-q_6]$. Equality in (a) holds if and only if $\alpha=\pm\frac1{\sqrt5}(e_{i_1}+\dots+e_{i_5})$ with $i_1,\dots,i_5$ distinct, or $q\in\{q_5,1-q_5\}$ and $\alpha=\pm\frac12(e_i+e_j+e_k+e_l)$ with $i,j,k,l$ distinct, or $q\in\{q_6,1-q_6\}$ and $\alpha=\pm\frac1{\sqrt6}(e_{i_1}+\dots+e_{i_6})$ with $i_1,\dots,i_6$ distinct.*

3.  *(Sharpness.) $R(q)>T_5(q)$ for $q\in(0,q_6)\cup(q_5,\frac12]$. More precisely, $R(q)\ge T_6(q)>T_5(q)$ for $q<q_6$, $R(q)\ge T_4(q)>T_5(q)$ for $q_5<q<\frac14$, and $R(q)\ge2\tau>T_5(q)$ for $\frac14\le q\le\frac12$.*

**Corollary 1** (the whole $k=5$ regime). *$\{q\in(0,\tfrac12]:\ R(q)=T_5(q)\}=[q_6,q_5]$, and $\{q\in[\frac12,1):\ R(q)=2\sqrt5\,q^4\tau\}=[1-q_5,1-q_6]$.*

*Proof.* Theorem 6(a) and (c), and Lemma 3 for the mirror statement. ◻

**Corollary 2**. *With Theorem 5 of `MAIN_RESULT_K4` ($R=T_4$ on $[q_5,q_4]$, $q_4=1-\frac{\sqrt3}2$; MAIN-5, audited VALID as A.25) and Theorems 1–4 (`MAIN_RESULT`, `MAIN_RESULT_K2`, `MAIN_RESULT_K3`, `MAIN_RESULT_K3B`; audited VALID as A.6, A.11, A.14, A.18 and refereed VALID), $$R(q)=2\sqrt{q(1-q)}\,\max_{k\ge1}\sqrt k\,\hat q^{\,k-1},\qquad \hat q=\max(q,1-q),$$ for all $q\in[q_6,1-q_6]=[1-\sqrt{5/6},\sqrt{5/6}]$.*

*Proof.* By Lemma 3 let $q\le\frac12$, so $\hat q=1-q$. On $[q_5,\frac12]$ this is Corollary 2 of `MAIN_RESULT_K4` (which combines Theorems 1–5). On $[q_6,q_5]$, Theorem 6 gives $R(q)=2\tau\sqrt5(1-q)^4$, and $\sqrt5(1-q)^4=\max_k\sqrt k(1-q)^{k-1}$ there. Indeed, for $k\le4$, $\sqrt k(1-q)^{k-1}\le\sqrt5(1-q)^4$ iff $(1-q)^{2(5-k)}\ge\frac k5$, and $(1-q)^2\ge\frac45$ (as $q\le q_5$) gives $(1-q)^{2(5-k)}\ge(\frac45)^{5-k}\ge\frac k5$, since $5(\frac45)^{5-k}$ equals $2.048$, $2.56$, $3.2$, $4$ for $k=1,2,3,4$. For $k\ge6$, $\sqrt k(1-q)^{k-1}\le\sqrt5(1-q)^4$ iff $(1-q)^{2(k-5)}\le\frac5k$, and $(1-q)^2\le\frac56$ (as $q\ge q_6$) gives $(1-q)^{2(k-5)}\le(\frac56)^{k-5}\le\frac5k$, because the sequence $\frac k5(\frac56)^{k-5}$ equals $1$ at $k=6$ and decreases for $k\ge6$ ($\frac{k+1}k\cdot\frac56\le\frac76\cdot\frac56<1$). ◻

Part (c) and the lower bound $R\ge T_5$ in (a) are elementary (Lemma 4). The content is the upper bound in (a), and (b).

#### Relation to Theorem 5.

The proof follows `MAIN_RESULT_K4` (Theorem 5) step by step. The changes are:

1.  the target $T_5$, the range $u\in[u_5,u_6]$ (Section 2) and the threshold $A_S=\frac14$ of the one-coordinate route;

2.  $k=5$ versions of the three- and four-bit lemmas ($\sum_i\Delta_i(f)^2\le20(1-q)^8$ on $[q_6,q_5]$; Lemmas 7 and 8);

3.  the OR-region identity (Lemma 6) now carries the main extremiser $(e_1+\dots+e_5)/\sqrt5$, which is extremal on the whole regime, and with six coordinates the tie $(e_1+\dots+e_6)/\sqrt6$ at $q_6$;

4.  the $m$-split is a tree of recursive *split nodes* (Section 8, Definition 30 and Lemma 31): children of $\mathsf{TCN}$ pieces have level at most two, and the child of a $\mathsf{TCS}$ piece in a node of level two has level three (it has only near-sphere and $\mathsf{SG}$ pieces); the proof allows near-sphere bounds with three to six coordinates, and the data use four, five and six (Table 1); the pieces <span class="sans-serif">TC4</span>, <span class="sans-serif">TC4S</span> and <span class="sans-serif">SG3</span> of Theorem 5 are the plus and minus pieces of a split node of level one; vertex certificates are used for patches with up to five parameters.

The lemmas that are unchanged from Theorem 5 are proved again here, so that the document can be read on its own.

#### Conventions.

$x_+=\max(x,0)$. All polynomials in the computer-assisted parts have rational coefficients. “Verified” means verified in exact rational arithmetic or in outward-rounded interval arithmetic, as specified in Section 9. For a rational $x\ge0$ and an integer $N\ge1$, *rational lower and upper bounds of $\sqrt x$* are $\lfloor N\sqrt x\rfloor/N$ and $(\lfloor N\sqrt x\rfloor+1)/N$ computed with integer square roots (the verifier uses $N=10^{15}$).

# Reductions

## Symmetry and parametrisation

**Lemma 3**. *The law of $-\chi^{(q)}$ is the law of $\chi^{(1-q)}$. Hence $\mathbb{E}|\sum\alpha_i\chi^{(q)}_i|=\mathbb{E}|\sum\alpha_i\chi^{(1-q)}_i|$, $R(q)=R(1-q)$, and the extremisers for $q$ and $1-q$ coincide.*

*Proof.* $-\chi^{(q)}$ takes the value $-u_q$ with probability $q$ and $v_q$ with probability $1-q$; since $u_{1-q}=v_q$ and $v_{1-q}=u_q$, this is the law of $\chi^{(1-q)}$. Finally $|\sum\alpha_i(-\chi_i)|=|\sum\alpha_i\chi_i|$. ◻

From now on $q\le\frac12$, i.e. $u\ge1$, and $$\tag{1}
q=\frac{1}{1+u^2},\quad 1-q=\frac{u^2}{1+u^2},\quad v=\frac1u,\quad \tau=\frac{u}{1+u^2},\quad
qu=(1-q)v=\tau .$$ On $u\ge1$, $\tau$ and $q$ are decreasing and $1-q$ is increasing in $u$. The target is $$T_5=2\sqrt5\,(1-q)^4\tau=\frac{2\sqrt5\,u^9}{(1+u^2)^5},\qquad
\frac{d}{du}\frac{u^9}{(1+u^2)^5}=\frac{u^8(9-u^2)}{(1+u^2)^6},$$ so $T_5$ is increasing on $[1,3]$ and decreasing on $[3,\infty)$. Hence, for $1\le u_1<u_2$ and $u\in[u_1,u_2]$, $$\tag{2}
T_5(u)\ \ge\ \min\{T_5(u_1),T_5(u_2)\}\ \ge\ T^-(u_1,u_2):=\sqrt5^{\,-}\min\Big\{\frac{2u_1^9}{(1+u_1^2)^5},\frac{2u_2^9}{(1+u_2^2)^5}\Big\}:$$ if $u\le3$ then $T_5$ is increasing on $[u_1,u]$, and if $u\ge3$ it is decreasing on $[u,u_2]$; here $\sqrt5^{\,-}$ is a fixed rational lower bound of $\sqrt5$ (the verifier uses $N=10^{15}$). For rational $u_1,u_2$ the number $T^-(u_1,u_2)$ is rational. The range $q\in[q_6,q_5]$ corresponds to $u\in[u_5,u_6]$ with $$u_5=\sqrt{4+2\sqrt5}\approx2.9106934,\qquad u_6=\sqrt{5+\sqrt{30}}\approx3.2368543,$$ because $(1-q_5)/q_5=\frac{2}{\sqrt5-2}=2(\sqrt5+2)=4+2\sqrt5$ and $(1-q_6)/q_6=\frac{\sqrt5}{\sqrt6-\sqrt5}=\sqrt5(\sqrt6+\sqrt5)=5+\sqrt{30}$. We fix the rationals $$U_-=\frac{29106}{10000}=2.9106\ \le u_5,\qquad U_+=\frac{3236855}{1000000}=3.236855\ \ge u_6 .$$ Indeed $U_-^2>4$ and $(U_-^2-4)^2\le20$, so $U_-^2\le4+2\sqrt5$; and $U_+^2>5$ and $(U_+^2-5)^2\ge30$, so $U_+^2\ge5+\sqrt{30}$. The computations cover $u\in[U_-,U_+]$; the theorem uses only $u\in[u_5,u_6]$. We also record that $w_-=U_-^2/(1+U_-^2)$ (the value of $1-q$ at $u=U_-$) satisfies $$\tag{3}
5w_-^8>1,\qquad 5w_-^6>2$$ (exact check; $w_-\approx0.894421$, $5w_-^8\approx2.05$, $5w_-^6\approx2.56$). Since $1-q$ increases with $u$, $5(1-q)^8>1$ and $5(1-q)^6>2$ for all $u\ge U_-$.

## Values of a few vectors

**Lemma 4**. *Let $k\ge1$ and $q<1/k$. Then $\mathbb{E}|\chi_1+\dots+\chi_k|/\sqrt k=2\sqrt k\,(1-q)^{k-1}\tau=T_k$. In particular $\mathbb{E}|\chi_1|=2\tau$. Moreover, for all $q\in(0,1)$:*

1.  *$T_4\le T_5$ iff $q\le q_5$, with equality iff $q=q_5$;*

2.  *$T_6\le T_5$ iff $q\ge q_6$, with equality iff $q=q_6$; and $T_{k+1}\le T_k$ for every $k\ge6$ and $q\ge q_6$;*

3.  *for $u\ge U_-$ (in particular for $q\in[q_6,q_5]$): $2\tau<T_5$ and $T_2<T_5$.*

*Proof.* Let $S=\chi_1+\dots+\chi_k$ and let $x_i=\mathbf 1\{\chi_i=u\}$. If some $x_i=1$ then $S\ge u-(k-1)v>0$, because $u^2>k-1$ is equivalent to $q<1/k$. If all $x_i=0$ then $S=-kv<0$. So $|S|=fS$ with $f=1-2\cdot\mathbf 1\{\text{all }x_i=0\}$. Since $\mathbb{E}\chi_i=0$, $\mathbb{E}[f\chi_i]=-2\mathbb{E}[\chi_i\mathbf 1\{\text{all }x=0\}]=-2(1-q)^k(-v)=2(1-q)^{k-1}(1-q)v=2(1-q)^{k-1}\tau$. Summing over $i$ gives $\mathbb{E}|S|=2k(1-q)^{k-1}\tau$. The comparisons: (i) $4(1-q)^3\le2\sqrt5(1-q)^4$ iff $1-q\ge\frac2{\sqrt5}$; (ii) $T_{k+1}\le T_k$ iff $\sqrt{k+1}(1-q)\le\sqrt k$ iff $1-q\le\sqrt{k/(k+1)}$, which for $k=5$ is $q\ge q_6$, and for $k\ge6$ follows from $1-q\le\sqrt{5/6}\le\sqrt{k/(k+1)}$; (iii) $2\tau<2\sqrt5(1-q)^4\tau$ iff $5(1-q)^8>1$, and $2\sqrt2(1-q)\tau<2\sqrt5(1-q)^4\tau$ iff $5(1-q)^6>2$; both hold for $u\ge U_-$ by (3). ◻

## Splitting off the two largest coefficients

Let $|\alpha|_2=1$ and $L=\sum\alpha_i\chi_i$. Changing the sign of $\alpha$ and permuting coordinates does not change $\mathbb{E}|L|$. So we may assume $$a_1:=\alpha_1=\max_i|\alpha_i|>0,\qquad a_2:=|\alpha_2|=\max_{i\ge2}|\alpha_i|,\qquad
|\alpha_3|\ge|\alpha_4|\ge\cdots,$$ and we put $s=\operatorname{sgn}\alpha_2\in\{1,-1\}$ ($s=1$ if $\alpha_2=0$), $$r=\sqrt{a_1^2+a_2^2}\in(0,1],\qquad b=\sqrt{1-r^2}.$$ If $r<1$, let $\beta_i=\alpha_i/b$ for $i\ge3$ and $M=\sum_{i\ge3}\beta_i\chi_i$. Then $$L=a_1\chi_1+s\,a_2\chi_2+bM,\qquad \sum_{i\ge3}\beta_i^2=1,\qquad
m:=\max_{i\ge3}|\beta_i|=\frac{|\alpha_3|}{b}\le\min\Big(1,\frac{a_2}{b}\Big),$$ and $M$ is independent of $(\chi_1,\chi_2)$. We use half-angle coordinates for $(a_1,a_2)$: $$a_1=r\,c(t),\quad a_2=r\,d(t),\qquad c(t)=\frac{1-t^2}{1+t^2},\quad d(t)=\frac{2t}{1+t^2},\qquad
t=\frac{a_2}{r+a_1}.$$ Since $0\le a_2\le a_1$, the angle $\theta$ with $\tan\theta=a_2/a_1$ is in $[0,\pi/4]$ and $t=\tan(\theta/2)\in[0,\sqrt2-1]$. We fix $T_8=\frac{20711}{50000}=0.41422\ge\sqrt2-1$ (indeed $(T_8+1)^2\ge2$). On $[0,1]$, $c$ is decreasing and $d$ is increasing in $t$, both are $\ge0$, and $c^2+d^2=1$. Thus every unit $\alpha$ gives a point $$(u,t,r,s)\in[U_-,U_+]\times[0,T_8]\times(0,1]\times\{1,-1\}\qquad(u\in[u_5,u_6]).$$ We put $A_S=\frac14$. If $a_1\le A_S$ we use the one-coordinate route of Section 5; otherwise $r\ge a_1>A_S$ and we use the two-coordinate route of Sections 6–8.

# Exact evaluations

## Two coordinates

**Lemma 5** (two-coordinate value). *Let $q\le\frac12$, $c,d\ge0$, $s\in\{1,-1\}$, and $X=c\chi_1+s\,d\chi_2$. List the atoms of $X$ as $(\chi_1,\chi_2)=(u,u),(u,-v),(-v,u),(-v,-v)$, with probabilities $p=(q^2,\,q(1-q),\,q(1-q),\,(1-q)^2)$ and values $x_j$. Then $p_jx_j=\tau g_j$ with $$\tag{4}
g=\big(q(c+sd),\ (1-q)c-s\,q\,d,\ -q\,c+s(1-q)d,\ -(1-q)(c+sd)\big),$$ and $$\mathbb{E}|X|=2\tau\max\{c,\ d,\ [s=1]\,(1-q)(c+d)\}$$ (the last entry is present only for $s=1$). Consequently $\mathbb{E}|X|\le\max(2\tau,T_2)\sqrt{c^2+d^2}$, and if $u\ge U_-$ and $(c,d)\ne0$, then $\mathbb{E}|X|<T_5\sqrt{c^2+d^2}$.*

*Proof.* The identities $p_jx_j=\tau g_j$ follow from (1); for example $q(1-q)(cu-sdv)=(1-q)\tau c-q\tau sd$. Since $\mathbb{E}X=0$, $\mathbb{E}|X|=2\mathbb{E}X_+=2\tau\sum_j(g_j)_+$. For $s=1$: $g_1\ge0\ge g_4$, so $\mathbb{E}X_+/\tau=q(c+d)+((1-q)c-qd)_++((1-q)d-qc)_+$. If both middle terms are nonnegative this equals $(1-q)(c+d)$, and then $(1-q)(c+d)-c=(1-q)d-qc\ge0$ and similarly $\ge d$. If only the first is nonnegative it equals $q(c+d)+(1-q)c-qd=c$, and $(1-q)(c+d)-c=(1-q)d-qc<0$, while $c\ge d$ (otherwise $(1-q)d-qc\ge (1-2q)c\ge 0$). The case where only the second is nonnegative is symmetric. Both negative would give $(1-q)(c+d)<q(c+d)$, impossible for $q\le\frac12$ unless $c=d=0$. In all cases $\mathbb{E}X_+/\tau=\max\{c,d,(1-q)(c+d)\}$. For $s=-1$: $g_2\ge0\ge g_3$. If $c\ge d$ then $g_1\ge0\ge g_4$ and $\mathbb{E}X_+/\tau=q(c-d)+(1-q)c+qd=c$. If $c<d$ then $g_1<0<g_4$ and $\mathbb{E}X_+/\tau=(1-q)c+qd+(1-q)(d-c)=d$. So $\mathbb{E}X_+/\tau=\max(c,d)$.

For the bound let $\rho=\sqrt{c^2+d^2}$. Then $\max(c,d)\le\rho$ and $(1-q)(c+d)\le\sqrt2(1-q)\rho$, so $\mathbb{E}|X|\le\max(2\tau\rho,2\sqrt2(1-q)\tau\rho)=\max(2\tau,T_2)\rho$. For $u\ge U_-$ and $\rho>0$ this is $<T_5\rho$ by Lemma 4(iii). ◻

## Bits, OR functions and the OR region

For $n\ge1$, $f:\{0,1\}^n\to[-1,1]$ and $x_i=\mathbf 1\{\chi_i=u\}$ put $\Delta_i(f)=\mathbb{E}[f\mid x_i=1]-\mathbb{E}[f\mid x_i=0]$, a polynomial in $q$. Then, by (1), $$\tag{5}
\mathbb{E}[f\chi_i]=qu\,\mathbb{E}[f\mid x_i=1]-(1-q)v\,\mathbb{E}[f\mid x_i=0]=\tau\,\Delta_i(f).$$ For $c\in\mathbb{R}^n$ write $G_n(c)=\mathbb{E}|c_1\chi_1+\dots+c_n\chi_n|$. For a set $S\subseteq\{1,\dots,n\}$ let $\mathrm{OR}_S=2\cdot\mathbf 1\{\exists i\in S:x_i=1\}-1$. By the computation in the proof of Lemma 4, $$\tag{6}
\Delta_i(\mathrm{OR}_S)=2(1-q)^{|S|-1}\ (i\in S),\qquad \Delta_i(\mathrm{OR}_S)=0\ (i\notin S).$$ (For $i\in S$: $\mathbb{E}[\mathrm{OR}_S\mid x_i=1]=1$ and $\mathbb{E}[\mathrm{OR}_S\mid x_i=0]=1-2(1-q)^{|S|-1}$; for $i\notin S$, $\mathrm{OR}_S$ does not depend on $x_i$.)

**Lemma 6** (OR-region identity). *Let $n\ge1$, $q\in(0,1)$ and $c\in\mathbb{R}^n$ with $c_i>0$ and $c_i>q\sum_{l=1}^nc_l$ for every $i$. Then $$G_n(c)=2\tau(1-q)^{n-1}\sum_{i=1}^nc_i\ \le\ 2\sqrt n\,(1-q)^{n-1}\tau\,|c| .$$ In particular $G_5(c)\le T_5|c|$, with equality if and only if $c_1=\dots=c_5$; and for $q\ge q_6$, $G_6(c)\le T_6|c|\le T_5|c|$, where $G_6(c)=T_5|c|$ holds if and only if $q=q_6$ and $c_1=\dots=c_6$.*

*Proof.* Let $S=\sum_lc_l\chi_l$. If all $x_l=0$ then $S=-v\sum_lc_l<0$. Otherwise pick $i$ with $x_i=1$. Every $l$ with $x_l=1$ contributes $c_lu$ instead of $-c_lv$, a gain of $c_l(u+v)>0$, so $S\ge c_iu-v\sum_{l\ne i}c_l=c_i(u+v)-v\sum_lc_l$. By (1), $u+v=(1+u^2)/u=v/q$, so $S\ge\frac vq\big(c_i-q\sum_lc_l\big)>0$. Hence $|S|=\mathrm{OR}_{\{1,\dots,n\}}\cdot S$, and by (5) and (6), $G_n(c)=\sum_ic_i\mathbb{E}[\mathrm{OR}\,\chi_i]=\tau\sum_ic_i\cdot2(1-q)^{n-1}$. The inequality is Cauchy–Schwarz, $\sum_ic_i\le\sqrt n|c|$, with equality iff all $c_i$ are equal. For $n=5$ the bound is $T_5|c|$. For $n=6$ it is $T_6|c|$, and $T_6\le T_5$ for $q\ge q_6$ with equality iff $q=q_6$ (Lemma 4(ii)). So $G_6(c)=T_5|c|$ forces equality in both steps, i.e. $c_1=\dots=c_6$ and $q=q_6$; conversely these give equality. ◻

## Three and four bits for $k=5$

**Lemma 7** (three-bit lemma for $k=5$). *Let $q\in[q_6,q_5]$ and $c\in\mathbb{R}^3$, $c\ne0$. Then $G_3(c)<T_5\,|c|$.*

**Lemma 8** (four-bit lemma for $k=5$). *Let $q\in[q_6,q_5]$ and $c\in\mathbb{R}^4$. Then $G_4(c)\le T_5\,|c|$. For $c\ne0$ equality holds if and only if $q=q_5$ and $c$ is a positive multiple of $\pm(e_1+e_2+e_3+e_4)$.*

*Proof of Lemmas 7 and 8.* Let $n\in\{3,4\}$, $X=c\cdot\chi$ and $f^*=\operatorname{sgn}X$ (with $\operatorname{sgn}0=1$), a function of $(x_1,\dots,x_n)$ with values $\pm1$. By (5) and Cauchy–Schwarz, $$G_n(c)=\mathbb{E}[f^*X]=\tau\sum_ic_i\Delta_i(f^*)\le\tau|c|\,|\Delta(f^*)| .$$ For $f:\{0,1\}^n\to\{-1,1\}$ put $H_f(q)=20(1-q)^8-\sum_{i=1}^n\Delta_i(f)^2$, a polynomial with integer coefficients. *Claims* (finite exact computations, Section 9, part G):

1.  ($n=3$, all $2^8$ functions) $H_f>0$ on $[q_6,q_5]$.

2.  ($n=4$, all $2^{16}$ functions) $H_f\ge0$ on $[q_6,q_5]$; no $H_f$ vanishes identically; $H_f(q_5)=0$ exactly for $f=\pm\mathrm{OR}_{\{1,2,3,4\}}$, and these two $H_f$ are $>0$ on $[q_6,q_5)$; every other $H_f$ is $>0$ on $[q_6,q_5]$.

Given the claims, $|\Delta(f)|\le2\sqrt5(1-q)^4$ for all $f$, so $G_n(c)\le\tau|c|\cdot2\sqrt5(1-q)^4=T_5|c|$ on $[q_6,q_5]$. If equality holds with $c\ne0$, then both inequalities are equalities: $H_{f^*}(q)=0$, and $c$ is a positive multiple of $\Delta(f^*)\ne0$ (equality in Cauchy–Schwarz with $\sum_ic_i\Delta_i(f^*)>0$). By the claims, $n=4$, $q=q_5$ and $f^*=\pm\mathrm{OR}_{\{1,2,3,4\}}$, so $\Delta(f^*)=\pm2(1-q)^3(1,1,1,1)$ by (6). In particular equality never holds for $n=3$. Conversely, at $q_5$ the vector $c=\pm(1,1,1,1)$ gives $G_4(c)=T_4|c|=T_5|c|$ by Lemma 4 ($q_5<\frac14$).

*How the claims are checked.* For each $f$, $\Delta_i(f)=\sum_{x:x_i=1}(f(x)-f(x-e_i))
\prod_{l\ne i}q^{x_l}(1-q)^{1-x_l}$ is computed as an integer polynomial, and the distinct polynomials $H_f$ are tested (39 for $n=3$, 1 630 for $n=4$). Let $g_5(q)=5q^2-10q+1$ and $g_6(q)=6q^2-12q+1$, with roots $q_5$ and $q_6$ in $(0,1)$ ($5(1-q)^2=4$, resp. $6(1-q)^2=5$); both are decreasing on $[0,1]$, and $g_5$ is irreducible over $\mathbb Q$ (its discriminant $80$ is not a square). Take rationals $q_6^-<q_6$ and $q_5^+>q_5$ from rational bounds of $\sqrt{5/6}$ and $\sqrt{4/5}$, with $g_6(q_6^-)>0$ and $g_5(q_5^+)<0$ (and $q_6^+<q_5^-$ for the companion bounds). For $H_f\not\equiv0$: either $g_5\mid H_f$, $H_f=g_5Q$, where $Q$ has no root in $[q_6^-,q_5^+]$ (Sturm) and $Q(q_6^-)>0$; then $Q>0$ on $[q_6,q_5]$, and $H_f=g_5Q\ge0$ there with equality only at $q_5$, since $g_5>0$ on $[0,q_5)$. Or $g_5\nmid H_f$, and $H_f$ has no root in $[q_6^-,q_5^+]$ and $H_f(q_6^-)>0$, so $H_f>0$ on $[q_6,q_5]$. Since $g_5$ is irreducible, $H_f(q_5)=0$ iff $g_5\mid H_f$. The verifier checks that no $H_f$ vanishes identically, that no $H_f$ with $n=3$ is divisible by $g_5$, and that the functions with $n=4$ and $g_5\mid H_f$ are exactly the two truth tables of $\pm\mathrm{OR}_{\{1,2,3,4\}}$. As a check of (6): $H_{\mathrm{OR}_{\{1,2,3\}}}=20(1-q)^8-12(1-q)^4=4(1-q)^4\big(5(1-q)^4-3\big)>0$ (as $(1-q)^2\ge\frac45$ for $q\le q_5$), and $H_{\mathrm{OR}_{\{1,2,3,4\}}}=20(1-q)^8-16(1-q)^6=4(1-q)^6g_5(q)$. ◻

*Remark 9*. Lemmas 7 and 8 also follow from RQ-C’s result C6 ($R_n(q)=2\tau\sqrt{\max_{k\le n}k(1-q)^{2k-2}}$ for $q\le\frac12$ and $n\le7$, audited VALID as A.5, A.5b), since $T_k<T_5$ for $k\le3$ and $T_4\le T_5$ on $[q_6,q_5]$. Our check is independent of it. The four-bit lemma is false for $q>q_5$, where $(e_1+e_2+e_3+e_4)/2$ gives $T_4>T_5$, and the bound $G_6\le T_5|c|$ of Lemma 6 is false for $q<q_6$, where $(e_1+\dots+e_6)/\sqrt6$ gives $T_6>T_5$. The ends of $[q_6,q_5]$ enter the proof through the four-bit lemma ($q\le q_5$) and through $G_n\le T_n|c|\le T_5|c|$ for $n\ge6$ in the OR region ($q\ge q_6$, Lemmas 6 and 4(ii)), both used in the near-sphere bounds of Section 8; the box computations cover the slightly larger range $u\in[U_-,U_+]$, and their conclusions are used only for $u\in[u_5,u_6]$.

# Moments of the remainder

**Lemma 10** (cumulants). *Let $w=u^2+v^2$ and $d=u-v$. The cumulants of $\chi$ are $\kappa_1=0$, $\kappa_2=1$ and $\kappa_j=d^{[j\text{ odd}]}G_j(w)$ for $3\le j\le10$, where $$\begin{aligned}
G_3&=1, & G_4&=w-4,\\
G_5&=w-10, & G_6&=w^2-26w+64,\\
G_7&=w^2-56w+244, & G_8&=w^3-120w^2+1188w-2176,\\
G_9&=w^3-246w^2+4044w-11080, & G_{10}&=w^4-502w^3+14604w^2-86728w+126976.
\end{aligned}$$*

*Proof.* By (1), $m_k=\mathbb{E}\chi^k=qu^k+(1-q)(-v)^k=(u^k+(-1)^ku^{2-k})/(1+u^2)$. The cumulants are determined by the recursion $\kappa_n=m_n-\sum_{k=1}^{n-1}\binom{n-1}{k-1}\kappa_km_{n-k}$. For example $m_3=u-v$, $m_4=w-1$, so $\kappa_3=d$ and $\kappa_4=m_4-3=w-4$. The identities for $j\le10$ are verified symbolically (sympy, part A1 of the verifier: the difference of the two sides simplifies to $0$ as a rational function of $u$). ◻

**Lemma 11** (moments from cumulants). *Let $M=\sum\beta_i\chi_i$ (finite sum) with $\sum\beta_i^2=1$ and power sums $p_j=\sum_i\beta_i^j$. Then $M$ has cumulants $K_1=0$, $K_2=1$, $K_j=\kappa_jp_j$, and $\mathbb{E}M^n=\mu_n(K_3,\dots,K_n)$ for $n\le10$, where $\mu_0=1$ and $$\mu_n=\sum_{k=2}^{n}\binom{n-1}{k-1}K_k\,\mu_{n-k}\qquad(K_2=1).$$ Each $\mu_n$ is a polynomial in $K_3,\dots,K_{10}$ with nonnegative integer coefficients; we write $\mu_n=\sum_eN_n(e)\prod_{j=3}^{10}K_j^{e_j}$ over exponent vectors $e=(e_3,\dots,e_{10})$. The term with $e=0$ is the Gaussian moment: $N_n(0)=(n-1)!!$ for even $n$ and $0$ for odd $n$.*

*Proof.* Cumulants of independent sums add and $K_j(\beta\chi)=\beta^j\kappa_j$, so $K_j(M)=\kappa_jp_j$, with $K_1=0$ and $K_2=\sum\beta_i^2=1$. The recursion is the moment–cumulant relation $m_n=\sum_{k=1}^{n}\binom{n-1}{k-1}K_km_{n-k}$ with $K_1=0$. The value at $K_3=\dots=K_{10}=0$ is the $n$-th moment of a standard Gaussian. (Part A2 of the verifier checks the recursion against the Gaussian moments and against $\mathbb{E}\chi^n$ at $u=\frac52$ for $n\le10$.) ◻

**Lemma 12** (power sums). *Let $\sum\beta_i^2=1$, $\max|\beta_i|\le m\le1$ and $\rho=\sqrt{p_4}$. Then $0\le\rho\le m$, $|p_3|\le\rho$, $|p_j|\le m^{j-4}\rho^2$ for $5\le j\le10$, and $p_j\ge\rho^{j-2}$ for even $j\ge4$.*

*Proof.* $p_4\le m^2\sum\beta_i^2=m^2$. Cauchy–Schwarz gives $p_3^2=(\sum\beta_i\beta_i^2)^2\le p_2p_4=p_4$. For $j\ge5$, $|p_j|\le\sum|\beta_i|^{j-4}\beta_i^4\le m^{j-4}p_4$. For even $j\ge4$, Jensen’s inequality for the probability weights $\beta_i^2$ and the convex function $x\mapsto x^{(j-2)/2}$ gives $p_j=\sum\beta_i^2(\beta_i^2)^{(j-2)/2}\ge(\sum\beta_i^2\beta_i^2)^{(j-2)/2}=\rho^{j-2}$. ◻

**Lemma 13** (sign information). *Let $\sum\beta_i^2=1$, $m=\max|\beta_i|$, and suppose $\beta_{i_0}=-m$ for some $i_0$. If $m\ge m_c\in(0,1]$, then $p_3\le\varphi(m_c):=-m_c^3+(1-m_c^2)^{3/2}$. Moreover $\varphi(m)<0$ iff $2m^2>1$.*

*Proof.* For $i\ne i_0$, $|\beta_i|\le(\sum_{i\ne i_0}\beta_i^2)^{1/2}=\sqrt{1-m^2}$. Hence $p_3=-m^3+\sum_{i\ne i_0}\beta_i^3\le-m^3+\sqrt{1-m^2}\sum_{i\ne i_0}\beta_i^2=\varphi(m)$, and $\varphi'(m)=-3m^2-3m\sqrt{1-m^2}\le0$, so $\varphi(m)\le\varphi(m_c)$. Finally $\varphi(m)<0$ iff $(1-m^2)^{3/2}<m^3$ iff $1-m^2<m^2$. ◻

#### Cumulant enclosures.

For $1\le u_1\le u\le u_2$: $d=u-1/u$ and $w=u^2+u^{-2}$ are increasing and $d\ge0$, so $d\in[d^-,d^+]=[u_1-\frac1{u_1},u_2-\frac1{u_2}]$ and $w\in[w^-,w^+]=[u_1^2+u_1^{-2},u_2^2+u_2^{-2}]$. Let $[G_j^-,G_j^+]\supseteq G_j([w^-,w^+])$ be the following enclosure: bisect $[w^-,w^+]$; on a subinterval where $G_j'$ has no root (exact Sturm count) the range of $G_j$ is spanned by its two end values; a subinterval that still contains a root of $G_j'$ after a fixed number of bisections (24 in the generator, 30 in the verifier) is enclosed by interval Horner evaluation; $[G_j^-,G_j^+]$ is the hull of these pieces. (This matters: $G_9'$ vanishes at a point with $u\approx2.926$, inside the range.) Then $\kappa_j\in[\kappa_j^-,\kappa_j^+]$, where this is $[G_j^-,G_j^+]$ for even $j$ and the interval product $[d^-,d^+]\cdot[G_j^-,G_j^+]$ for odd $j$.

**Definition 14** (objective bound). Let $D\le10$, $c=(c_0,\dots,c_D)\in\mathbb Q^{D+1}$, $1<u_1<u_2$ rationals, $m^*\in(0,1]$, $p^*<0$ optional, and $\Theta$ a target. Put $L_e=\sum_nc_nN_n(e)$ and $A=L_0=\sum_{n\text{ even}}c_n(n-1)!!$. For every $e\ne0$ with $L_e\ne0$ let $[C_e^-,C_e^+]$ be the interval product $L_e\prod_j[\kappa_j^-,\kappa_j^+]^{e_j}$, and put $$u_e=e_3+2\sum_{j\ge4}e_j,\qquad U_e=\prod_{j\ge5}(m^*)^{(j-4)e_j}.$$ Call $e$ *even* if $e_j$ is even for every odd $j$. For even $e$ let $(\ell_e,l_e)=(0,0)$ if $e_j>0$ for some odd $j$, and $(\ell_e,l_e)=(1,\sum_{j\text{ even}}(j-2)e_j)$ otherwise. Define the term bounds

1.  if $p^*$ is given, $e=(1,0,\dots,0)$ (i.e. the monomial $p_3$) and $C_e^-\ge0$: replace $A$ by $A+C_e^-p^*$, and $b_e=0$;

2.  otherwise, if $e$ is not even: $b_e(\rho)=\max(|C_e^-|,|C_e^+|)\,U_e\,\rho^{u_e}$;

3.  if $e$ is even and $C_e^+\le0$: $b_e(\rho)=C_e^+\,\ell_e\,\rho^{l_e}$;

4.  if $e$ is even and $C_e^+>0$: $b_e(\rho)=C_e^+\,U_e\,\rho^{u_e}$.

We say that *$c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$* if $h(\rho)=\Theta-A-\sum_eb_e(\rho)>0$ for all $\rho\in[0,m^*]$.

**Lemma 15** (expectation bound). *Suppose $c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$ and let $P(y)=\sum_nc_ny^n$. Then $\mathbb{E}P(M)<\Theta$ for every $u\in[u_1,u_2]$ and every $M=\sum\beta_i\chi_i$ with $\sum\beta_i^2=1$, $\max|\beta_i|\le m^*$ and, if $p^*$ is given, $p_3\le p^*$.*

*Proof.* By Lemma 11, $\mathbb{E}P(M)=\sum_nc_n\mu_n=L_0+\sum_{e\ne0}C_ep^e$ with $C_e=L_e\prod_j\kappa_j^{e_j}\in[C_e^-,C_e^+]$ and $p^e=\prod_jp_j^{e_j}$. Let $\rho=\sqrt{p_4}\in[0,m^*]$. By Lemma 12, $|p^e|\le\rho^{e_3}(\rho^2)^{e_4}\prod_{j\ge5}(m^{*\,j-4}\rho^2)^{e_j}=U_e\rho^{u_e}$; if $e$ is even then $p^e\ge0$ (odd power sums appear to even powers, and $p_j\ge0$ for even $j$); and if moreover $e_j=0$ for all odd $j$, then $p^e\ge\prod_{j\text{ even}}\rho^{(j-2)e_j}=\rho^{l_e}$. Hence: in case (T0), $p_3\le p^*<0$ and $C_e\ge C_e^-\ge0$ give $C_ep_3\le C_ep^*\le C_e^-p^*$; in case (T1), $C_ep^e\le|C_e||p^e|\le b_e(\rho)$; in case (T2), $C_e\le C_e^+\le0$ and $p^e\ge\ell_e\rho^{l_e}\ge0$ give $C_ep^e\le C_e^+p^e\le C_e^+\ell_e\rho^{l_e}$; in case (T3), $p^e\ge0$ gives $C_ep^e\le C_e^+p^e\le C_e^+U_e\rho^{u_e}$. Summing, $\mathbb{E}P(M)\le\Theta-h(\rho)<\Theta$. ◻

# The one-coordinate route ($a_1\le\frac14$)

Here we split off only $a=a_1$: $L=a\chi_1+b_1M_1$ with $b_1=\sqrt{1-a^2}$ and $M_1=\sum_{i\ge2}(\alpha_i/b_1)\chi_i$, whose coefficients are at most $\min(1,a/b_1)$ in absolute value. For $y\in\mathbb{R}$, $$\mathbb{E}|a\chi+y|=2\tau a+2R_a(y)-(1-2q)y,\qquad R_a(y)=\max\{0,\ (1-q)(y-av),\ q(-y-au)\}$$ (BF3, Lemma 9.4; Lemma 3 of `MAIN_RESULT`, audited VALID). Indeed $\mathbb{E}|a\chi+y|=q|au+y|+(1-q)|y-av|$ equals $2\tau a-(1-2q)y$ for $-au\le y\le av$ (using $qau=(1-q)av=\tau a$), $y$ for $y>av$, and $-y$ for $y<-au$, and so does the right-hand side. Conditioning on $M_1$ and using $\mathbb{E}M_1=0$, $$\mathbb{E}|L|=2\tau a+2\mathbb{E}R_a(b_1M_1),\qquad\text{so}\qquad \mathbb{E}|L|<T_5\iff\mathbb{E}R_a(b_1M_1)<\tau\big(\sqrt5(1-q)^4-a\big).$$

A *cell* is $[u_1,u_2]\times[\underline a,\overline a]$ with rationals $1<u_1<u_2$ and $0\le\underline a<\overline a\le A_S$. Let $\bar b$ be a rational upper bound of $\sqrt{1-\underline a^2}$, $\bar m=\min\{1,\overline a/\beta\}$ with $\beta$ a rational lower bound of $\sqrt{1-\overline a^2}$, and $$\bar\ell_1(y)=\frac{u_2^2}{1+u_2^2}\Big(\bar by-\frac{\underline a}{u_2}\Big),\quad
\bar\ell_2(y)=\frac{1}{1+u_1^2}\big(-\bar by-\underline au_1\big),\quad
\Theta_1=\tau(u_2)\Big(\sqrt5^{\,-}\Big(\frac{u_1^2}{1+u_1^2}\Big)^4-\overline a\Big).$$ A *cell certificate* is $c\in\mathbb Q^{D+1}$, $D\le10$, with $P(y)=\sum c_ny^n$ such that (V1) $P>0$, (V2) $P>\bar\ell_1$, (V3) $P>\bar\ell_2$ on $\mathbb{R}$, and (V4) $c$ satisfies the objective bound for $(u_1,u_2,\bar m,-,\Theta_1)$.

**Lemma 16**. *If a cell with $u_1\ge U_-$ has a certificate, then $\mathbb{E}|L|<T_5$ for every $u\in[u_1,u_2]$ and every unit $\alpha$ with $\underline a\le\max_i|\alpha_i|\le\overline a$.*

*Proof.* For $u\in[u_1,u_2]$, $a\in[\underline a,\overline a]$ and $b_1=\sqrt{1-a^2}$ we have $R_a(b_1y)=\max\{0,\ell_1,\ell_2\}$ with $\ell_1=\frac{u^2}{1+u^2}(b_1y-\frac au)$ and $\ell_2=\frac1{1+u^2}(-b_1y-au)$. If $\ell_1(y)>0$ then $y>0$ and $0<b_1y-\frac au\le\bar by-\frac{\underline a}{u_2}$, and $\frac{u^2}{1+u^2}\le\frac{u_2^2}{1+u_2^2}$, so $\ell_1(y)\le\bar\ell_1(y)$. If $\ell_2(y)>0$ then $y<0$ and $0<-b_1y-au\le-\bar by-\underline au_1$, and $\frac1{1+u^2}\le\frac1{1+u_1^2}$, so $\ell_2(y)\le\bar\ell_2(y)$. So by (V1)–(V3), $R_a(b_1y)<P(y)$ for all $y$, and $\mathbb{E}R_a(b_1M_1)\le\mathbb{E}P(M_1)$. Since $a/\sqrt{1-a^2}$ is increasing, the coefficients of $M_1$ are at most $\bar m$ in absolute value. By Lemma 15, $\mathbb{E}P(M_1)<\Theta_1$. Finally $\Theta_1\le\tau(u)(\sqrt5(1-q)^4-a)$, because $\tau(u)\ge\tau(u_2)$, $(1-q)^4\ge(\frac{u_1^2}{1+u_1^2})^4$, $\sqrt5^{\,-}\le\sqrt5$, $a\le\overline a$, and the bracket is positive: $w_-^4\ge5^{-1/2}>\frac25$ by (3) and $\sqrt5^{\,-}\ge2$, so $\sqrt5^{\,-}(\frac{u_1^2}{1+u_1^2})^4\ge\sqrt5^{\,-}w_-^4>\frac45>\frac14\ge\overline a$ (the verifier also asserts $\Theta_1>0$ for every cell). ◻

# The two-coordinate route: vertex certificates

## The functions $F_x$, nested patches and peeling

Let $k\ge2$ and a sign vector $\sigma\in\{1,-1\}^k$ with $\sigma_1=1$. For $x\in\mathbb{R}^{k+1}$ and $y\in\mathbb{R}$ put $$F_x(y)=\mathbb{E}\Big|\sum_{i=1}^k\sigma_ix_i\chi_i+x_{k+1}\,y\Big| ,$$ where $\chi_1,\dots,\chi_k$ are i.i.d. normalised $q$-biased bits. We use $\sigma=(1,s,\varsigma_1,\dots,\varsigma_{k-2})$, where $\varsigma_i$ are the signs of peeled coefficients (Lemma 18); the data use $k\le5$.

**Lemma 17**. *For fixed $q$ and $y$, the map $x\mapsto F_x(y)$ is convex and positively homogeneous of degree one. Consequently, if $x=\sum_l\nu_lV_l$ with $\nu_l\ge0$, then $F_x(y)\le\sum_l\nu_lF_{V_l}(y)$.*

*Proof.* $F_x(y)$ is the expectation of the absolute value of a linear function of $x$, i.e. a seminorm of $x$. A seminorm $N$ satisfies $N(\sum\nu_lV_l)\le\sum\nu_lN(V_l)$ for $\nu_l\ge0$. ◻

The *patches* are the maps, for $j\ge0$ and $k=2+j$, $$p_k(t,r,\mu_1,\dots,\mu_j)=\big(rc(t),\,rd(t),\,b_0\mu_1,\,\dots,\,b_{j-1}\mu_j,\,b_j\big),\qquad
b_0=\sqrt{1-r^2},\quad b_i=b_{i-1}\sqrt{1-\mu_i^2},$$ for $t\in[0,1]$ and $r,\mu_1,\dots,\mu_j\in[0,1]$. Thus $$p_2(t,r)=(rc,rd,b_0),\quad p_3(t,r,\mu_1)=(rc,rd,b_0\mu_1,b_1),\quad
p_4(t,r,\mu_1,\mu_2)=(rc,rd,b_0\mu_1,b_1\mu_2,b_2),$$ and so on. Their values are unit vectors with nonnegative entries: $b_{i-1}^2\mu_i^2+b_i^2=b_{i-1}^2$, so $|p_k|^2=r^2c^2+r^2d^2+b_0^2=1$.

#### Peeling.

Let $N=\sum_{i\in I}\gamma_i\chi_i$ be a finite sum with $\sum\gamma_i^2=1$, and $\mu(N)=\max_i|\gamma_i|$. If $\mu=\mu(N)<1$ and $\gamma_{i^*}=\varsigma\mu$ with $\varsigma\in\{1,-1\}$, the *peeled remainder* is $N^\flat=\sum_{i\in I\setminus\{i^*\}}(\gamma_i/\sqrt{1-\mu^2})\chi_i$. Then $$\tag{7}
N=\varsigma\mu\chi_{i^*}+\sqrt{1-\mu^2}\,N^\flat,\qquad \sum_{i\ne i^*}\frac{\gamma_i^2}{1-\mu^2}=1,\qquad
\mu(N^\flat)\le\min\Big(1,\frac{\mu}{\sqrt{1-\mu^2}}\Big),$$ and $N^\flat$ is independent of $\chi_{i^*}$: indeed $\sum_{i\ne i^*}\gamma_i^2=1-\mu^2$, and each $|\gamma_i|$ is at most $\mu$ and at most $\sqrt{1-\mu^2}$. If $\mu(N)=1$, then $N=\varsigma\chi_{i^*}$ (all other coefficients vanish).

**Lemma 18** (conditional expectation). *Consider a point with $r<1$ and remainder $M$, and let $j\ge0$. Put $M^{(0)}=M$ and, for $i=1,\dots,j$, let $\mu_i=\mu(M^{(i-1)})$, attained by the coefficient $\varsigma_i\mu_i$ of $\chi_{l_i}$, and $M^{(i)}=(M^{(i-1)})^\flat$ if $\mu_i<1$.*

1.  *If $\mu_1,\dots,\mu_j<1$, then $\mathbb{E}|L|=\mathbb{E}F_{p_{2+j}(t,r,\mu_1,\dots,\mu_j)}(M^{(j)})$ with $\sigma=(1,s,\varsigma_1,\dots,\varsigma_j)$, the bits being $\chi_1,\chi_2,\chi_{l_1},\dots,\chi_{l_j}$; here $M^{(j)}$ is independent of these bits, $\sum$(coefficients of $M^{(j)}$)$^2=1$, and $\mu(M^{(j)})\le\min(1,\mu_j/\sqrt{1-\mu_j^2})$ if $j\ge1$.*

2.  *If $j\ge1$, $\mu_1,\dots,\mu_{j-1}<1$ and $\mu_j=1$, then $L=a_1\chi_1+sa_2\chi_2+\sum_{i<j}\varsigma_ib_{i-1}\mu_i\chi_{l_i}+\varsigma_jb_{j-1}\chi_{l_j}$, and $F_{p_{2+j}(t,r,\mu_1,\dots,\mu_j)}(y)=\mathbb{E}|L|$ for every $y\in\mathbb{R}$ (with the same $\sigma$).*

*Proof.* $L=a_1\chi_1+sa_2\chi_2+b_0M^{(0)}$ with $(a_1,a_2)=(rc(t),rd(t))$, and by (7), if $\mu_i<1$, $b_{i-1}M^{(i-1)}=\varsigma_ib_{i-1}\mu_i\chi_{l_i}+b_iM^{(i)}$. By induction $L=a_1\chi_1+sa_2\chi_2+\sum_{i\le j}\varsigma_ib_{i-1}\mu_i\chi_{l_i}+b_jM^{(j)}$, where the bits are distinct and independent of $M^{(j)}$; conditioning on $M^{(j)}$ gives (i), and the bound on $\mu(M^{(j)})$ is (7). In (ii), $M^{(j-1)}=\varsigma_j\chi_{l_j}$, which gives the formula for $L$; the last entry of $p_{2+j}$ is $b_j=b_{j-1}\sqrt{1-1}=0$, so $F_{p_{2+j}}(y)$ does not depend on $y$ and equals $\mathbb{E}|L|$. ◻

## Vertex sets and the cone lemma

**Definition 19** (vertex set). Let $X=\prod_{i=1}^k[\xi_i^-,\xi_i^+]$ be a box of patch parameters $(t,r,\mu_1,\dots,\mu_j)$, $k=2+j$, and $p=p_k$. A *vertex set for $X$* is a vector $n_0\in\mathbb Q^{k+1}$ and $2^k$ vectors $V_\epsilon\in\mathbb Q^{k+1}$, indexed by $\epsilon\in\{0,1\}^k$, such that:

1.  $|n_0|^2\ge1$ and $V_\epsilon\cdot n_0=|n_0|^2$ for all $\epsilon$;

2.  (parallelepiped) $V_\epsilon=V_0+\sum_i\epsilon_iE_i$ with $E_i=V_{e_i}-V_0$;

3.  (facets) for each $i$ and $\delta\in\{0,1\}$ the $2^{k-1}$ vertices with $\epsilon_i=\delta$ span a linear subspace of dimension $k$; let $h_{i,\delta}$ be a normal vector of it, oriented so that $h_{i,\delta}\cdot\bar c>0$ for the centre $\bar c=V_0+\frac12\sum_iE_i$ (and $h_{i,\delta}\cdot\bar c\ne0$ is required);

4.  (enclosure) $h_{i,\delta}\cdot p(\xi)\ge0$ for all $i,\delta$ and all $\xi\in X$.

**Lemma 20** (cone lemma). *Let $(n_0,(V_\epsilon))$ be a vertex set for $X$. Then for every $\xi\in X$ there are $\nu_\epsilon\ge0$ with $p(\xi)=\sum_\epsilon\nu_\epsilon V_\epsilon$ and $\sum_\epsilon\nu_\epsilon\le1/|n_0|\le1$.*

*Proof.* First, $V_0,E_1,\dots,E_k$ is a basis of $\mathbb{R}^{k+1}$. Indeed $E_i\cdot n_0=0$ by (P1) and $V_0\cdot n_0=|n_0|^2\ne0$, so $V_0\notin\operatorname{span}\{E_i\}$. By (P2) the face $\{\epsilon_i=0\}$ spans $S_i=\operatorname{span}(V_0,\{E_j\}_{j\ne i})$, which has dimension $k$ by (P3); hence the $k$ vectors $V_0,\{E_j\}_{j\ne i}$ are linearly independent. Moreover $\bar c-V_0-\frac12\sum_{j\ne i}E_j=\frac12E_i$ and $h_{i,0}\cdot\bar c\ne0$ with $h_{i,0}\perp S_i$, so $E_i\notin S_i$. Thus the $k+1$ vectors are independent.

Let $z\in\mathbb{R}^{k+1}$ with $h_{i,\delta}\cdot z\ge0$ for all $i,\delta$, and write $z=\lambda V_0+\sum_i\mu_iE_i$. Since $h_{i,0}\perp S_i$, $h_{i,0}\cdot z=\mu_i\,h_{i,0}\cdot E_i$, and $h_{i,0}\cdot\bar c=\frac12h_{i,0}\cdot E_i>0$; so $\mu_i\ge0$. The face $\{\epsilon_i=1\}$ spans $\operatorname{span}(V_0+E_i,\{E_j\}_{j\ne i})$, so $h_{i,1}\cdot E_j=0$ ($j\ne i$) and $h_{i,1}\cdot V_0=-h_{i,1}\cdot E_i$; then $h_{i,1}\cdot\bar c=-\frac12h_{i,1}\cdot E_i>0$, so $h_{i,1}\cdot V_0>0$, and $h_{i,1}\cdot z=(\lambda-\mu_i)\,h_{i,1}\cdot V_0$; so $\mu_i\le\lambda$. If $\lambda=0$ then $z=0$. Otherwise $z/\lambda=V_0+\sum_i\theta_iE_i$ with $\theta_i=\mu_i/\lambda\in[0,1]$, which is a point of the parallelepiped $\operatorname{conv}\{V_\epsilon\}$, i.e. a convex combination $\sum\omega_\epsilon V_\epsilon$ (take $\omega_\epsilon=\prod_i\theta_i^{\epsilon_i}(1-\theta_i)^{1-\epsilon_i}$). So $z=\sum\nu_\epsilon V_\epsilon$ with $\nu=\lambda\omega\ge0$ and $\sum\nu_\epsilon=\lambda$. Finally $z\cdot n_0=\lambda|n_0|^2$, so $\lambda=z\cdot n_0/|n_0|^2\le|z|/|n_0|$.

By (P4), $z=p(\xi)$ satisfies the hypothesis, and $|p(\xi)|=1$. ◻

Condition (P4) is checked without subdivision: the minimum of a linear functional over a parameter box of a patch is the end of a short chain of one-variable minimisations.

**Lemma 21** (facet minima). *For $\alpha,\beta\in\mathbb{R}$ and $-1\le x^-<x^+\le1$ let $g(x)=\alpha x+\beta\sqrt{1-x^2}$ and $\mathfrak m(\alpha,\beta;x^-,x^+)=\min_{x\in[x^-,x^+]}g(x)$.*

1.  *If $\beta\ge0$, then $\mathfrak m(\alpha,\beta;x^-,x^+)=\min(g(x^-),g(x^+))$.*

2.  *If $\beta<0$, put $R=\sqrt{\alpha^2+\beta^2}$ and $x^*=-\alpha/R$. Then $\mathfrak m(\alpha,\beta;x^-,x^+)=-R$ if $x^-\le x^*\le x^+$, and $\mathfrak m(\alpha,\beta;x^-,x^+)=\min(g(x^-),g(x^+))$ otherwise.*

3.  *$\mathfrak m(\alpha,\beta;x^-,x^+)$ is nondecreasing in $\beta$, and also in $\alpha$ if $x^-\ge0$.*

*Let $k=2+j$ with $j\ge0$, let $X=[t^-,t^+]\times[r^-,r^+]\times\prod_{i=1}^j[\mu_i^-,\mu_i^+]$ with $0\le t^-<t^+\le1$, $0\le r^-<r^+\le1$ and $0\le\mu_i^-<\mu_i^+\le1$, and let $h\in\mathbb{R}^{k+1}$. Put $W_j=h_{k+1}$, $W_{i-1}=\mathfrak m(h_{i+2},W_i;\mu_i^-,\mu_i^+)$ for $i=j,j-1,\dots,1$, $A=\mathfrak m(h_1,h_2;c(t^+),c(t^-))$ and $G=\mathfrak m(A,W_0;r^-,r^+)$. Then $$\min_{\xi\in X}h\cdot p_k(\xi)=G.$$ If in this recursion each value of $\mathfrak m$ is replaced by a lower bound of it (and the later steps are applied to these lower bounds), the result is a lower bound of $G$.*

*Proof.* (i) The function $x\mapsto\sqrt{1-x^2}$ is concave on $[-1,1]$, so for $\beta\ge0$ the function $g$ is concave, and the minimum of a concave function over an interval is attained at an endpoint.

\(ii\) For $\beta<0$ the function $g$ is convex. By the Cauchy–Schwarz inequality, $g(x)\ge-R\,|(x,\sqrt{1-x^2})|=-R$ for all $x\in[-1,1]$. Moreover $R>0$, $|x^*|\le1$ and $\sqrt{1-x^{*2}}=|\beta|/R=-\beta/R$, so $g(x^*)=-\alpha^2/R-\beta^2/R=-R$. Thus $x^*$ is a minimum point of $g$ on $[-1,1]$. If $x^*\in[x^-,x^+]$, the minimum over $[x^-,x^+]$ is $-R$. Otherwise $[x^-,x^+]$ lies in $[-1,x^*]$ or in $[x^*,1]$, where the convex function $g$ is nonincreasing, respectively nondecreasing, so the minimum is attained at an endpoint.

\(iii\) For every $x\in[-1,1]$, $g(x)$ is nondecreasing in $\beta$ because $\sqrt{1-x^2}\ge0$, and nondecreasing in $\alpha$ if $x\ge0$. Minima over $x$ of pointwise nondecreasing families are nondecreasing.

Now the patch. Put $w_j=h_{k+1}$ and $w_{i-1}(\mu_i,\dots,\mu_j)=h_{i+2}\mu_i+\sqrt{1-\mu_i^2}\;w_i(\mu_{i+1},\dots,\mu_j)$ for $i=j,\dots,1$. Since $b_i=b_{i-1}\sqrt{1-\mu_i^2}$, we have $b_{i-1}w_{i-1}=h_{i+2}\,b_{i-1}\mu_i+b_iw_i$, and therefore $$h\cdot p_k(t,r,\mu_1,\dots,\mu_j)=r\,\big(h_1c(t)+h_2d(t)\big)+b_0\,w_0(\mu_1,\dots,\mu_j),\qquad b_0=\sqrt{1-r^2}.$$ First, $\min w_{i-1}=W_{i-1}$, the minimum being over $\mu_l\in[\mu_l^-,\mu_l^+]$ for $l\ge i$. This holds for $i-1=j$, since $w_j=h_{k+1}=W_j$. If it holds for $i$, then for fixed $\mu_i$ the minimum of $w_{i-1}$ over $\mu_{i+1},\dots,\mu_j$ is $h_{i+2}\mu_i+\sqrt{1-\mu_i^2}\,W_i$, because the weight $\sqrt{1-\mu_i^2}$ is nonnegative and $w_i$ does not depend on $\mu_i$. Minimising over $\mu_i\in[\mu_i^-,\mu_i^+]$ gives $\mathfrak m(h_{i+2},W_i;\mu_i^-,\mu_i^+)=W_{i-1}$.

Second, $c$ is a decreasing bijection of $[t^-,t^+]$ onto $[c(t^+),c(t^-)]$, and $d(t)=\sqrt{1-c(t)^2}$ for $t\in[0,1]$ (because $c^2+d^2=1$ and $d\ge0$). Hence $\min_{t\in[t^-,t^+]}(h_1c(t)+h_2d(t))=
\mathfrak m(h_1,h_2;c(t^+),c(t^-))=A$.

Third, for fixed $r$ the two brackets depend on disjoint sets of parameters and have the nonnegative weights $r$ and $b_0$, so the minimum over $t$ and $\mu$ is $rA+\sqrt{1-r^2}\,W_0$. Minimising over $r\in[r^-,r^+]$ gives $G$.

The last statement follows from (iii) by induction along the recursion: in the steps for $W_{i-1}$ the replaced value enters as $\beta$, and in the step for $G$ the values $A$ and $W_0$ enter as $\alpha$ and $\beta$, with $x=r\ge r^-\ge0$. ◻

#### Checking (P4).

(P4) holds if and only if $G(h_{i,\delta})\ge0$ for all $2k$ facet normals. A rational lower bound of $G$ is computed by the recursion of Lemma 21 in exact rational arithmetic: an endpoint value $g(x^\pm)$ is bounded below using a rational lower bound of $\sqrt{1-(x^\pm)^2}$ if $\beta\ge0$ and a rational upper bound if $\beta<0$; the value $-R$ is bounded below by $-R^+$ with $R^+\ge R$ rational; and the condition $x^-\le x^*\le x^+$ is decided exactly. For rationals $p,q$ the sign of $p-qR$ is: $\ge0$ if $p\ge0\ge q$; $<0$ if $p\le0\le q$ and $(p,q)\ne(0,0)$; the sign of $p^2-q^2R^2$ if $p,q>0$; and the sign of $q^2R^2-p^2$ if $p,q<0$. Then $x^-\le x^*$ if and only if $p-qR\ge0$ for $(p,q)=(-\alpha,x^-)$, and $x^*\le x^+$ if and only if $p-qR\le0$ for $(p,q)=(-\alpha,x^+)$. (P4) is accepted if the lower bound is $\ge0$ for every facet normal.

## Vertex envelopes and vertex certificates

Fix a $u$-interval $[u_1,u_2]$ with $u_1>1$. For a vertex $V\in\mathbb Q^{k+1}$ let $\gamma=(\sigma_1V_1,\dots,\sigma_kV_k)$ and $b_V=V_{k+1}$. The atoms of $\sum_i\gamma_i\chi_i$ are indexed by $\omega\in\{u,-v\}^k$, with probability $\pi_\omega=\prod_iq^{[\omega_i=u]}(1-q)^{[\omega_i=-v]}$ and value $y_\omega=\sum_i\gamma_i\omega_i$, and by (1) $$\pi_\omega y_\omega=\tau\sum_i\gamma_i\,(\pm1)_i\prod_{l\ne i}q^{[\omega_l=u]}(1-q)^{[\omega_l=-v]},
\qquad(\pm1)_i=+1\text{ if }\omega_i=u,\ -1\text{ otherwise}.$$ Using $q\in[\frac1{1+u_2^2},\frac1{1+u_1^2}]$, $1-q\in[\frac{u_1^2}{1+u_1^2},\frac{u_2^2}{1+u_2^2}]$ and $\tau\in[\tau(u_2),\tau(u_1)]$, interval arithmetic gives rational enclosures $\pi_\omega y_\omega\in[\eta_\omega^-,\eta_\omega^+]$ and $\pi_\omega\in[\pi_\omega^-,\pi_\omega^+]$, valid for all $u\in[u_1,u_2]$. Put $[\beta_\omega^-,\beta_\omega^+]=[\min(\pi_\omega^-b_V,\pi_\omega^+b_V),\max(\pi_\omega^-b_V,\pi_\omega^+b_V)]$.

**Definition 22** (vertex envelope). $\Phi_V(y)=\sum_\omega\max(\eta_\omega^++\beta_\omega^+y,\ -\eta_\omega^--\beta_\omega^-y)$ for $y\ge0$, and $\Phi_V(y)=\sum_\omega\max(\eta_\omega^++\beta_\omega^-y,\ -\eta_\omega^--\beta_\omega^+y)$ for $y<0$.

**Lemma 23** (envelope). *$F_V(y)\le\Phi_V(y)$ for all $y\in\mathbb{R}$ and all $u\in[u_1,u_2]$. On each closed half-line, $\Phi_V$ is continuous and piecewise linear, with breakpoints among the points where the two lines of one summand cross.*

*Proof.* $F_V(y)=\sum_\omega\pi_\omega|y_\omega+b_Vy|=\sum_\omega|\pi_\omega y_\omega+\pi_\omega b_V\,y|$ and $|z|=\max(z,-z)$. For $y\ge0$: $\pi_\omega y_\omega+\pi_\omega b_Vy\le\eta_\omega^++\beta_\omega^+y$ and $-\pi_\omega y_\omega-\pi_\omega b_Vy\le-\eta_\omega^--\beta_\omega^-y$, since $\pi_\omega b_V\in[\beta_\omega^-,\beta_\omega^+]$ (whatever the sign of $b_V$). For $y<0$ the roles of $\beta^\pm$ are exchanged. ◻

**Definition 24** (vertex certificate). Let $X$ be a parameter box, $\sigma$ a sign vector, $[u_1,u_2]$ a $u$-interval, $m^*\in(0,1]$ a cap, and $p^*<0$ optional. A *vertex certificate for $(X,\sigma,[u_1,u_2],m^*,p^*)$* is a vertex set $(n_0,(V_\epsilon))$ for $X$ and coefficient vectors $c^{(\epsilon)}\in\mathbb Q^{D+1}$, $D\le10$, with $P_\epsilon(y)=\sum_nc^{(\epsilon)}_ny^n$, such that for every $\epsilon$: (W1) $P_\epsilon(y)>\Phi_{V_\epsilon}(y)$ for all $y\in\mathbb{R}$; and (W2) $c^{(\epsilon)}$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,T^-(u_1,u_2))$.

(W1) is checked as follows: on each half-line, $\Phi_V$ coincides on each interval between consecutive breakpoints with one line $\lambda_0+\lambda_1y$ (one choice of line per summand); for every such line, $P_\epsilon-\lambda_0-\lambda_1y$ is shown to be positive on all of $\mathbb{R}$ by Sturm sequences.

**Lemma 25** (vertex certificate lemma). *Let a vertex certificate for $(X,\sigma,[u_1,u_2],m^*,p^*)$ be given. Let $\mathcal Z$ be the class of random variables $Z=\sum\beta_i\chi_i'$ (finite sums of i.i.d. copies of $\chi$, independent of $\chi_1,\dots,\chi_k$) with $\sum\beta_i^2=1$, $\max|\beta_i|\le m^*$ and, if $p^*$ is given, $p_3\le p^*$. Then for every $u\in[u_1,u_2]$, every $\xi\in X$ and every $Z\in\mathcal Z$, $$\mathbb{E}F_{p(\xi)}(Z)<T^-(u_1,u_2)\le T_5(u).$$*

*Proof.* By Lemma 20, $p(\xi)=\sum\nu_\epsilon V_\epsilon$ with $\nu\ge0$ and $\sum\nu_\epsilon\le1$. By Lemmas 17 and 23 and (W1), for every $y$, $F_{p(\xi)}(y)\le\sum_\epsilon\nu_\epsilon F_{V_\epsilon}(y)\le\sum_\epsilon\nu_\epsilon P_\epsilon(y)$. Taking expectations over $Z$, $\mathbb{E}F_{p(\xi)}(Z)\le\sum_\epsilon\nu_\epsilon\mathbb{E}P_\epsilon(Z)$. By (W1) and Lemma 23, $\mathbb{E}P_\epsilon(Z)>\mathbb{E}F_{V_\epsilon}(Z)\ge0$, and by (W2) and Lemma 15, $\mathbb{E}P_\epsilon(Z)<T^-$. Since $\sum\nu_\epsilon\le1$ and $\max_\epsilon\mathbb{E}P_\epsilon(Z)\ge0$, $\sum_\epsilon\nu_\epsilon\mathbb{E}P_\epsilon(Z)\le\max_\epsilon\mathbb{E}P_\epsilon(Z)<T^-$. Finally $T^-\le T_5(u)$ by (2). ◻

Two members of $\mathcal Z$ are used repeatedly: $Z=N^{-1/2}(\chi_1'+\dots+\chi_N')$ with $N^{-1/2}\le m^*$ (no $p^*$), and, if $m^*=1$, $Z=\chi_1'$ (no $p^*$).

## Boxes

A *box* is $B=[u_1,u_2]\times[t_1,t_2]\times[r_1,r_2]$ with rationals $1<u_1<u_2$, $0\le t_1<t_2\le1$, $0\le r_1<r_2\le1$, together with a sign $s$. Let $b^-$ be a rational lower bound of $\sqrt{1-r_2^2}$ ($b^-=0$ if $r_2=1$), and define $\bar m(B)=1$ if $b^-=0$ or $r_2d(t_2)\ge b^-$, and $\bar m(B)=r_2d(t_2)/b^-$ otherwise. Then $\bar m(B)\in(0,1]$ and $m\le\min(1,a_2/b)\le\bar m(B)$ at every point of $B$ with $r<1$, because $a_2=rd(t)\le r_2d(t_2)$ and $b\ge b^-$. A box of kind <span class="sans-serif">lpv</span> carries a vertex certificate for $([t_1,t_2]\times[r_1,r_2],(1,s),[u_1,u_2],\bar m(B),-)$. A box of kind <span class="sans-serif">small</span> satisfies $r_2c(t_1)\le A_S$, so $a_1=rc(t)\le A_S$ on it.

**Lemma 26**. *At every point of an <span class="sans-serif">lpv</span> box with $r<1$, $\mathbb{E}|L|<T_5$.*

*Proof.* By Lemma 18 ($j=0$), $\mathbb{E}|L|=\mathbb{E}F_{p_2(t,r)}(M)$, and $M\in\mathcal Z$ since $m\le\bar m(B)$. Apply Lemma 25. ◻

# Near $(e_1+e_2)/\sqrt2$: the near-circle lemma

**Lemma 27** (tail bound). *Let $y\in\mathbb{R}$, $b\ge0$ and let $Z$ be a random variable with $\mathbb{E}Z=0$ and $\mathbb{E}Z^4<\infty$. Then $$\mathbb{E}|y+bZ|\le|y|+\min\Big(b\,\mathbb{E}|Z|,\ \frac{27}{128}\,\frac{b^4\mathbb{E}Z^4}{|y|^3}\Big),$$ where for $y=0$ the minimum is read as its first entry. The same convention is used below whenever this bound is applied at a point where $y=0$.*

*Proof.* The first bound is the triangle inequality. For the second ($y\ne0$), $|y+z|-|y|-\operatorname{sgn}(y)z=2(-\operatorname{sgn}(y)z-|y|)_+\le2(|z|-|y|)_+$, and $\mathbb{E}[\operatorname{sgn}(y)bZ]=0$. For $x\ge0$ and $\eta>0$, $(x-\eta)_+\le\frac{27}{256}x^4/\eta^3$: the maximum of $(x-\eta)/x^4$ over $x>\eta$ is at $x=\frac43\eta$ and equals $\frac{27}{256}\eta^{-3}$. Hence $\mathbb{E}|y+bZ|-|y|\le2\cdot\frac{27}{256}\,b^4\mathbb{E}Z^4/|y|^3$. ◻

**Lemma 28** (near-circle tests). *Let $B$ be a box with $r_1>0$ and $u_1\ge U_-$. Let $y_j$ ($j=1,\dots,4$) be the atoms of $c\chi_1+sd\chi_2$, so that the atoms of $a_1\chi_1+sa_2\chi_2$ are $ry_j$. Let $\eta_j\ge0$ be a lower bound of $|y_j|$ on $B$, $p_j^+$ an upper bound of $p_j$, $b^+$ an upper bound of $\sqrt{1-r_1^2}$, and $E_4=3+\max(0,w^+-4)\,\bar m(B)^2$. Let $T^-=T^-(u_1,u_2)$.*

1.  *If all $\eta_j>0$ and $\frac{27}{128}E_4(b^+)^2\frac{1+r_2}{r_1^3}\sum_jp_j^+\eta_j^{-3}<T^-$, then $\mathbb{E}|L|<T_5$ at every point of $B$ with $r<1$.*

2.  *Let $G^+$ be an upper bound of $\mathbb{E}|c\chi_1+sd\chi_2|=\tau\sum_j|g_j|$ on $B$ with $G^+\le T^-$, and $e_j^+=\min\big(b^+,\frac{27}{128}(b^+)^4E_4/(r_1^3\eta_j^3)\big)$ ($e_j^+=b^+$ if $\eta_j=0$). If $\sum_jp_j^+e_j^+<T^-(1-r_2)+r_1(T^--G^+)$, then $\mathbb{E}|L|<T_5$ at every point of $B$ with $r<1$.*

*Proof.* At a point of $B$ with $r<1$, condition on $(\chi_1,\chi_2)$ and apply Lemma 27 with $Z=M$. Here $\mathbb{E}M^4=3+\kappa_4p_4\le E_4$ by Lemma 11, since $p_4\le m^2\le\bar m(B)^2$ and $\kappa_4=w-4\le w^+-4$; also $\mathbb{E}|M|\le1$. This gives $\mathbb{E}|L|\le rG+\sum_jp_je_j$, where $G=\mathbb{E}|c\chi_1+sd\chi_2|$ and $e_j=\min(b,\frac{27}{128}b^4E_4/(r^3|y_j|^3))$. (A) By Lemma 5 ($u\ge U_-$, $c^2+d^2=1$), $G<T_5$. Since $1-r=b^2/(1+r)$ and $b>0$, $\sum_jp_je_j\le\frac{27}{128}\frac{b^4E_4}{r^3}\sum_j\frac{p_j}{|y_j|^3}
\le b^2\cdot\frac{27}{128}E_4(b^+)^2\frac{1}{r_1^3}\sum_j\frac{p_j^+}{\eta_j^3}
<\frac{b^2T^-}{1+r_2}\le T_5(1-r)$. So $\mathbb{E}|L|<rT_5+T_5(1-r)=T_5$. (B) $\mathbb{E}|L|\le rG^++\sum_jp_j^+e_j^+<rG^++T^-(1-r_2)+r_1(T^--G^+)\le rG^++T^-(1-r)+r(T^--G^+)=T^-\le T_5$, using $r_1\le r\le r_2$ and $T^--G^+\ge0$. ◻

Boxes of kind <span class="sans-serif">ncA</span> pass test (A) or test (B); boxes of kind <span class="sans-serif">ncB</span> pass test (B).

# Near the extremisers: the $m$-split

In our coordinates the extremisers are the following points (all with $s=1$ and $t=\sqrt2-1$, since $a_1=a_2$; $\mu_1,\mu_2,\dots$ are the successive maxima of Lemma 18):

- $(e_1+\dots+e_5)/\sqrt5$, for every $q\in[q_6,q_5]$: $a_1=a_2=\frac1{\sqrt5}$, $b=\sqrt{3/5}$, $M=(\chi_3+\chi_4+\chi_5)/\sqrt3$, $\mu_1=\frac1{\sqrt3}$, $\mu_2=\frac1{\sqrt2}$, $\mu_3=1$;

- $(e_1+e_2+e_3+e_4)/2$, at $q_5$: $a_1=a_2=\frac12$, $b=\frac1{\sqrt2}$, $M=(\chi_3+\chi_4)/\sqrt2$, $\mu_1=\frac1{\sqrt2}$, $\mu_2=1$;

- $(e_1+\dots+e_6)/\sqrt6$, at $q_6$: $a_1=a_2=\frac1{\sqrt6}$, $b=\sqrt{2/3}$, $M=(\chi_3+\dots+\chi_6)/2$, $\mu_1=\frac12$, $\mu_2=\frac1{\sqrt3}$, $\mu_3=\frac1{\sqrt2}$, $\mu_4=1$.

Equality holds at these points, so no certificate with a strict bound can contain them. We split according to $m=\mu_1$ and the sign of a largest coefficient of $M$; inside some pieces we peel off that coefficient and split the next remainder in the same way. This gives a finite tree of *split nodes* (Definition 30). The points above are reached at the leaves, where the remainder is used up ($b_j=0$) and the near-sphere bound (Lemma 29) is exact.

#### Positive peeling.

At a point with $r<1$ we use the peeling of Lemma 18, with $M^{(0)}=M$ and $\mu_i=\mu(M^{(i-1)})$, and we put $$a_{i+2}=b_{i-1}\mu_i,\qquad b_i=b_{i-1}\sqrt{1-\mu_i^2}\qquad(b_0=b),$$ so that $(a_1,a_2,a_3,\dots,a_{j+2},b_j)=p_{2+j}(t,r,\mu_1,\dots,\mu_j)$. Let $j\ge1$ and let $I_1,\dots,I_j\subset(0,1]$ be intervals. The point is *positively peeled through $I_1,\dots,I_j$* if $\mu_1,\dots,\mu_{j-1}<1$ and, for $i=1,\dots,j$, $\mu_i\in I_i$ and $M^{(i-1)}$ has the coefficient $+\mu_i$ at some $\chi_{l_i}$, which is the coefficient peeled off ($\varsigma_i=+1$). Then, by Lemma 18, the indices $l_1,\dots,l_j\ge3$ are distinct (each peeling removes the peeled coordinate), and $$L=a_1\chi_1+sa_2\chi_2+\sum_{i=1}^ja_{i+2}\chi_{l_i}+b_jM^{(j)},$$ where the last term is absent if $\mu_j=1$ (then $b_j=0$). For $j=0$ every point with $r<1$ counts as positively peeled (through the empty list). Throughout, $E_4'=3+\max(0,\kappa_4)$; for any remainder $N=\sum\gamma_i\chi_i$ with $\sum\gamma_i^2=1$, $\mathbb{E}N^4=3+\kappa_4\sum\gamma_i^4\le E_4'$ by Lemma 11 (as $0\le\sum\gamma_i^4\le1$), and $\mathbb{E}|N|\le1$.

## Near-sphere bounds

**Lemma 29** (near-sphere bound). *Let $j\ge1$, $n=j+2$, and consider a point that is positively peeled through $I_1,\dots,I_j$. Let $Y_n=a_1\chi_1+sa_2\chi_2+\sum_{i=1}^ja_{i+2}\chi_{l_i}$, with atoms $y_l$ and probabilities $p_l$ ($l=1,\dots,2^n$), and $r_n=|(a_1,\dots,a_n)|=\sqrt{1-b_j^2}$. Then $$\tag{8}
\mathbb{E}|L|\le\mathbb{E}|Y_n|+\sum_lp_l\min\Big(b_j,\ \frac{27}{128}\frac{b_j^4E_4'}{|y_l|^3}\Big).$$ Suppose moreover that $q\in[q_6,q_5]$, that all $y_l\ne0$, that $\frac{27}{128}E_4'\,b_j^2(1+r_n)\sum_lp_l|y_l|^{-3}<T_5$, and, if $n\ge5$, that $s=1$ and $a_i>q\sum_{i'=1}^na_{i'}$ for $i=1,\dots,n$. Then $\mathbb{E}|L|<T_5$ if $b_j>0$. If $b_j=0$, then $\mathbb{E}|L|=\mathbb{E}|Y_n|\le T_5$, and equality holds only if $s=1$, $a_1=\dots=a_n=n^{-1/2}$, and either $n=5$, or $n=4$ and $q=q_5$, or $n=6$ and $q=q_6$.*

*Proof.* If $\mu_j=1$ then $b_j=0$ and $L=Y_n$. Otherwise $L=Y_n+b_jM^{(j)}$ with $M^{(j)}$ independent of the $n$ bits of $Y_n$; conditioning on these bits and applying Lemma 27 with $Z=M^{(j)}$ gives (8).

Now assume the extra hypotheses and let $c=(a_1,sa_2,a_3,\dots,a_n)$, so that $\mathbb{E}|Y_n|=G_n(c)$ and $|c|=r_n$. All $a_i$ are positive: $a_1>0$; $a_{i+2}=b_{i-1}\mu_i>0$, because $b_0=b>0$, $b_i>0$ for $i<j$ (as $\mu_i<1$) and $\mu_i>0$; and $a_2\ge|\alpha_{l_1}|=a_3$. We show $G_n(c)\le T_5r_n$, with equality only if $s=1$, all $a_i$ are equal, and $(n,q)$ is as in the statement. For $n=3$ this is Lemma 7, with strict inequality. For $n=4$ it is Lemma 8: equality forces $q=q_5$ and $c$ to be a positive multiple of $\pm(1,1,1,1)$; as $c_1=a_1>0$ the sign is $+$, so $s=1$ and all $a_i$ are equal. For $n\ge5$ we have $s=1$, and $c=(a_1,\dots,a_n)$ satisfies the hypothesis of Lemma 6, so $G_n(c)=2\tau(1-q)^{n-1}\sum_ia_i\le
T_nr_n$, with equality iff all $a_i$ are equal; and $T_n\le T_5$ for $q\ge q_6$ by Lemma 4(ii), with equality iff $n=5$, or $n=6$ and $q=q_6$ (for $n\ge7$, $T_n\le T_7<T_6\le T_5$, since $T_7<T_6$ iff $1-q<\sqrt{6/7}$, and $1-q\le\sqrt{5/6}$).

If $b_j>0$, the hypothesis and $1-r_n=b_j^2/(1+r_n)$ give $\sum_lp_l\frac{27}{128}\frac{b_j^4E_4'}{|y_l|^3}<T_5\frac{b_j^2}{1+r_n}=T_5(1-r_n)$, hence $\mathbb{E}|L|<T_5r_n+T_5(1-r_n)=T_5$ by (8). If $b_j=0$, then $r_n=1$ and $\mathbb{E}|L|=\mathbb{E}|Y_n|=G_n(c)\le T_5$, with equality only as stated. ◻

#### Piece tests $(\mathrm A_n)$, $(\mathrm B_n)$.

Let $B$ be a box with sign $s$ and $b^->0$, let $j\ge1$, $n=j+2$, and $I_i=[\mu_i^-,\mu_i^+]\subset(0,1]$ for $i=1,\dots,j$. On $B\times I_1\times\dots\times I_j$ we enclose $a_1=rc(t)\in[r_1c(t_2),r_2c(t_1)]$, $a_2=rd(t)\in[r_1d(t_1),r_2d(t_2)]$, $b_0^2\in[(b^-)^2,(b^+)^2]$ with $b^+$ a rational upper bound of $\sqrt{1-r_1^2}$, and recursively $$b_i^2\in\big[(b_{i-1}^2)^-(1-(\mu_i^+)^2),\ (b_{i-1}^2)^+(1-(\mu_i^-)^2)\big],\qquad
a_{i+2}=b_{i-1}\mu_i\in\big[b_{i-1}^-\mu_i^-,\ b_{i-1}^+\mu_i^+\big],$$ where $b_{i-1}^\pm$ are the square roots of the bounds of $b_{i-1}^2$; and $r_n\le r_n^+:=\min(1,\sqrt{1-(b_j^2)^-})$. The $2^n$ atoms $y_l$, the probabilities $p_l$ and the products $p_ly_l=\tau\sum_i(\pm c_i)\prod_{i'\ne i}\Pr[\cdot]$ (by $qu=(1-q)v=\tau$, as in Lemma 5; $c=(a_1,sa_2,a_3,\dots,a_n)$) are enclosed in interval arithmetic over $u\in[u_1,u_2]$. Let $\eta_l$ be a lower bound of $|y_l|$, $p_l^+$ an upper bound of $p_l$, $|p_ly_l|^+$ an upper bound of $|p_ly_l|$, $b_j^+$ an upper bound of $\sqrt{(b_j^2)^+}$, $a_i^\pm$ the bounds of $a_i$, $q^+=\frac1{1+u_1^2}$, $E_4'^+=3+\max(0,w^+-4)$ and $T^-=T^-(u_1,u_2)$. The piece $(B;I_1,\dots,I_j)$ passes

- test $(\mathrm A_n)$ if all $\eta_l>0$; if $n\ge5$, also $s=1$ and $a_i^->q^+\sum_{i'=1}^na_{i'}^+$ for $i=1,\dots,n$; and $\frac{27}{128}E_4'^+(b_j^2)^+(1+r_n^+)\sum_lp_l^+\eta_l^{-3}<T^-$;

- test $(\mathrm B_n)$ if $\sum_l\big(|p_ly_l|^++p_l^+\min\big(b_j^+,\frac{27}{128}((b_j^2)^+)^2E_4'^+/\eta_l^3\big)\big)<T^-$, where the second entry of the minimum is omitted if $\eta_l=0$.

Consider a point of $B$ that is positively peeled through $I_1,\dots,I_j$. All quantities above lie in their enclosures, $E_4'\le E_4'^+$ (as $\kappa_4=w-4$ and $w\le w^+$), and $T^-\le T_5(u)$ by (2). In $(\mathrm A_n)$ with $n\ge5$, $\sum_{i'}a_{i'}^+>0$, so $a_i\ge a_i^->q^+\sum_{i'}a_{i'}^+\ge q\sum_{i'}a_{i'}$. Hence: if the piece passes $(\mathrm A_n)$ and $q\in[q_6,q_5]$, the hypotheses of Lemma 29 hold, so $\mathbb{E}|L|<T_5$ if $b_j>0$, and $\mathbb{E}|L|\le T_5$ with equality only as in Lemma 29 if $b_j=0$. If the piece passes $(\mathrm B_n)$, then $\mathbb{E}|L|<T_5$ by (8) alone, since $\mathbb{E}|Y_n|=\sum_l|p_ly_l|$ (this holds for every $u\in[u_1,u_2]$ and either sign $s$).

## Split nodes

For a box $B$ with sign $s$ and intervals $I_1,\dots,I_l\subset(0,1]$ ($l\ge0$) put $X_l=[t_1,t_2]\times[r_1,r_2]\times I_1\times\dots\times I_l$ (parameters of the patch $p_{2+l}$) and $\sigma_l=(1,s,1,\dots,1)\in\{1,-1\}^{2+l}$. For $\mu\in(0,1]$ let $\kappa(\mu)=\min(1,\mu/\sqrt{1-\mu^2})$, with $\kappa(1)=1$. It is nondecreasing, and by (7), $\mu(M^{(i)})\le\kappa(\mu_i)$ whenever $\mu_i<1$. A rational $\kappa'\ge0$ satisfies $\kappa'\ge\kappa(\mu)$ iff $\kappa'\ge1$, or $\mu<1$ and $\kappa'^2(1-\mu^2)\ge\mu^2$.

**Definition 30** (split node). Let $B$ be a box with sign $s$ and $r_2<1$ (so $b^->0$), let $l\ge0$, $I_1,\dots,I_l\subset(0,1]$, and $\hat\kappa\in(0,1]$. A *split node of level $l$ on $(B;I_1,\dots,I_l)$ with range $\hat\kappa$* consists of a rational *cut* $m_c\in(0,1]$, a vertex certificate $\mathcal C$ for $(X_l,\sigma_l,[u_1,u_2],m_c,-)$, and two finite families of intervals $[n_1,n_2]\subset(0,1]$, the *plus pieces* and the *minus pieces*, each family covering $[m_c,\hat\kappa]$. Each plus piece is of one of the following types:

- $(\mathrm A_{l+3})$ or $(\mathrm B_{l+3})$: the piece $(B;I_1,\dots,I_l,[n_1,n_2])$ passes this test;

- $\mathsf{TC}^+$: a rational cap $\kappa'\in(0,1]$ with $\kappa'\ge\kappa(n_2)$, and a vertex certificate for $(X_l\times[n_1,n_2],\,(\sigma_l,1),$ $[u_1,u_2],\,\kappa',\,-)$;

- $\mathsf{TCN}$: a rational $\kappa'\in(0,1]$ with $\kappa'\ge\kappa(n_2)$, and a split node of level $l+1$ on $(B;I_1,\dots,I_l,[n_1,n_2])$ with range $\kappa'$ (its *child*);

- $\mathsf{TCS}$: a $\mathsf{TCN}$ piece whose child, with cut $m_c'$ and range $\kappa'$, has exactly one minus piece, $[m_c',\kappa']$, of type $\mathsf{SG}$ with cap $\kappa'$, and only plus pieces of type $(\mathrm A_{l+4})$ or $(\mathrm B_{l+4})$.

Each minus piece is of one of the following types:

- $\mathsf{SG}$: a rational $p^*$ with $2n_1^2>1$ and $\varphi(n_1)\le p^*<0$, a rational cap $\kappa'\in(0,1]$ with $\kappa'\ge\min(n_2,\hat\kappa)$, and a vertex certificate for $(X_l,\sigma_l,[u_1,u_2],\kappa',p^*)$;

- $\mathsf{TC}^-$: a rational cap $\kappa'\in(0,1]$ with $\kappa'\ge\kappa(n_2)$, and a vertex certificate for $(X_l\times[n_1,n_2],\,(\sigma_l,-1),$ $[u_1,u_2],\,\kappa',\,-)$.

The *height* of a node is $0$ if it has no $\mathsf{TCN}$ piece (including $\mathsf{TCS}$), and otherwise one more than the largest height of its children.

A $\mathsf{TCS}$ piece is stored compactly: its cap $\kappa'$, the cut $m_c'$, the value $p'^*$, the two vertex certificates (cap $m_c'$; cap $\kappa'$ with $p'^*$) and the sub-pieces. In the notation of Theorem 5, <span class="sans-serif">TC4</span>, <span class="sans-serif">TC4S</span> and <span class="sans-serif">SG3</span> are the pieces $\mathsf{TC}^\pm$, $\mathsf{TCS}$ and $\mathsf{SG}$ of a node of level one.

**Lemma 31** (split node lemma). *Let $\mathcal N$ be a split node of level $l$ on $(B;I_1,\dots,I_l)$ with range $\hat\kappa$. Consider a point of $B$ with $q\in[q_6,q_5]$ that is positively peeled through $I_1,\dots,I_l$, with $\mu_l<1$ if $l\ge1$, and with $\mu_{l+1}=\mu(M^{(l)})\le\hat\kappa$. Then $\mathbb{E}|L|\le T_5$. Equality forces $s=1$ and $\alpha=n^{-1/2}(e_1+e_2+e_{l_1}+\dots+e_{l_{n-2}})$ for distinct $l_1,\dots,l_{n-2}\ge3$, where $n=5$, or $n=4$ and $q=q_5$, or $n=6$ and $q=q_6$.*

*Proof.* Induction on the height of $\mathcal N$. By Lemma 18(i) with $j=l$ (for $l=0$: $L=a_1\chi_1+sa_2\chi_2+bM$), $\mathbb{E}|L|=\mathbb{E}F_{p_{2+l}(\xi)}(M^{(l)})$ with $\xi=(t,r,\mu_1,\dots,\mu_l)\in X_l$ and the sign vector $\sigma_l$. Write $\mu=\mu_{l+1}$.

*Case $\mu\le m_c$.* $M^{(l)}$ belongs to the class $\mathcal Z$ of $\mathcal C$ (cap $m_c$), and Lemma 25 gives $\mathbb{E}|L|<T_5$.

*Case $\mu\ge m_c$, and $M^{(l)}$ has the coefficient $+\mu$ at some $\chi_{l_{l+1}}$.* We peel it ($\varsigma_{l+1}=+1$). As $\mu\in[m_c,\hat\kappa]$, $\mu$ lies in a plus piece $[n_1,n_2]$, and the point is positively peeled through $I_1,\dots,I_l,[n_1,n_2]$.

- $(\mathrm A_{l+3})$ or $(\mathrm B_{l+3})$: by Lemma 29 and the consequences of the piece tests (with $j=l+1$, $n=l+3$), $\mathbb{E}|L|<T_5$, except for $(\mathrm A_{l+3})$ with $b_{l+1}=0$, where $\mathbb{E}|L|\le T_5$. In that case $L=Y_n$, i.e. $\alpha=a_1e_1+sa_2e_2+\sum_{i=1}^{l+1}a_{i+2}e_{l_i}$, and equality forces $s=1$, all $a_i=n^{-1/2}$, and $(n,q)$ as in the statement.

- $\mathsf{TC}^+$: if $\mu<1$, Lemma 18(i) with $j=l+1$ gives $\mathbb{E}|L|=\mathbb{E}F_{p_{3+l}(\xi,\mu)}(M^{(l+1)})$ with the sign vector $(\sigma_l,1)$, where $(\xi,\mu)\in
  X_l\times[n_1,n_2]$ and $\mu(M^{(l+1)})\le\kappa(\mu)\le\kappa(n_2)\le\kappa'$; so $M^{(l+1)}$ is in the class of the certificate, and Lemma 25 gives $\mathbb{E}|L|<T_5$. If $\mu=1$, then $n_2=1$ and $\kappa'=1$, and $F_{p_{3+l}(\xi,1)}(y)=\mathbb{E}|L|$ for every $y$ (Lemma 18(ii)); with $Z=\chi'$ (in the class, cap $1$), $\mathbb{E}|L|=\mathbb{E}F_{p_{3+l}(\xi,1)}(Z)<T_5$.

- $\mathsf{TCN}$ (in particular $\mathsf{TCS}$), with child $\mathcal N'$ of cut $m_c'$ and range $\kappa'$: if $\mu=1$, then $F_{p_{3+l}(\xi,1)}(y)=\mathbb{E}|L|$ for every $y$, with the sign vector $\sigma_{l+1}$, and $Z=N^{-1/2}(\chi_1'+\dots+\chi_N')$ with $N^{-1/2}\le m_c'$ is in the class of the certificate of $\mathcal N'$ (patch parameters $X_{l+1}$, sign vector $\sigma_{l+1}$, cap $m_c'$); so $\mathbb{E}|L|=\mathbb{E}F_{p_{3+l}(\xi,1)}(Z)<T_5$. If $\mu<1$, the point is positively peeled through $I_1,\dots,I_l,[n_1,n_2]$ with $\mu_{l+1}<1$, and $\mu_{l+2}\le\kappa(\mu)\le\kappa(n_2)\le\kappa'$; the induction hypothesis for $\mathcal N'$ (whose height is smaller) gives $\mathbb{E}|L|\le T_5$, with equality only as stated.

*Case $\mu\ge m_c$, and $M^{(l)}$ has no coefficient $+\mu$.* Then it has the coefficient $-\mu$ at some $\chi_{l_{l+1}}$, and $\mu\in[m_c,\hat\kappa]$ lies in a minus piece $[n_1,n_2]$.

- $\mathsf{SG}$: by Lemma 13 (applied to $M^{(l)}$ with $n_1\le\mu$ in place of $m_c$), $p_3(M^{(l)})\le\varphi(n_1)\le p^*$; and $\mu\le\min(n_2,\hat\kappa)\le\kappa'$. So $M^{(l)}$ is in the class of the certificate, and Lemma 25 gives $\mathbb{E}|L|<T_5$.

- $\mathsf{TC}^-$: exactly as for $\mathsf{TC}^+$, peeling the coefficient $-\mu$ ($\varsigma_{l+1}=-1$, sign vector $(\sigma_l,-1)$): $\mathbb{E}|L|<T_5$.

 ◻

## The $m$-split boxes

**Definition 32** ($m$-split box). An $m$-split box (kind <span class="sans-serif">ms</span>) is a box $B$ with sign $s$ and $r_2<1$, together with a split node of level $0$ on $B$ with range $\min(1,\bar m(B))$.

**Lemma 33** ($m$-split lemma). *Let $B$ be an $m$-split box. At every point of $B$ with $r<1$ and $q\in[q_6,q_5]$ we have $\mathbb{E}|L|\le T_5$. Equality forces $s=1$ and $\alpha=n^{-1/2}(e_1+e_2+e_{l_1}+\dots+e_{l_{n-2}})$ for distinct $l_1,\dots,l_{n-2}\ge3$, where $n=5$, or $n=4$ and $q=q_5$, or $n=6$ and $q=q_6$.*

*Proof.* Every point with $r<1$ is positively peeled through the empty list, and $\mu_1=m\le\min(1,a_2/b)\le\min(1,\bar m(B))$ (Section 6). Apply Lemma 31 with $l=0$. ◻

# Computer verification

All scripts and outputs are in the repository (`scripts/`, `outputs/`). Floating point (HiGHS linear programming via scipy, numpy) is used only to *find* certificates. Every *verification* is exact or uses outward-rounded interval arithmetic.

## Data

The list of data files is `outputs/k5_manifest.json` ($U_-=\frac{29106}{10000}$, $U_+=\frac{3236855}{1000000}$, $T_8=\frac{20711}{50000}$, $A_S=\frac14$); md5 sums are in `outputs/k5_MD5SUMS.txt`.

- One-coordinate cells: `outputs/k5/one_0.json`, …, `one_3.json` ($u\in[U_-,3]$, $[3,\frac{31}{10}]$, $[\frac{31}{10},\frac{16}5]$, $[\frac{16}5,U_+]$; $234$, $232$, $245$ and $150$ cells, $861$ in all, all with degree-ten certificates), covering $u\in[U_-,U_+]$ and $a\in[0,\frac14]$.

- Two-coordinate boxes: `outputs/k5/m_i.json` ($s=-1$, $i=0,\dots,32$) and `outputs/k5/p_i.json` ($s=+1$, $i=0,\dots,23$), on the $u$-slabs $[U_-,\frac{292}{100}]$, $[\frac{292}{100},\frac{293}{100}]$, …, $[\frac{322}{100},\frac{323}{100}]$, $[\frac{323}{100},U_+]$ (slab $i$ is the $(i+1)$-st). For $s=+1$ the slabs $i=24,\dots,32$, next to $u_6$, are split into equal $u$-subslabs, with files `outputs/k5/p_is0.json`, `p_is1.json`, …: four subslabs for $i=24,\dots,30$ and eight for $i=31,32$; there is no file `p_i.json` for these $i$. For each sign the boxes cover $[U_-,U_+]\times[0,T_8]\times[\frac14,1]$. Each file records $K=5$, $A_S=\frac14$ and the maximal level $2$ of $\mathsf{TCN}$ nodes. Each box record has its kind and data: <span class="sans-serif">small</span>, <span class="sans-serif">lpv</span> ($n_0$, the vertices and one coefficient vector per vertex), <span class="sans-serif">ncA</span>/<span class="sans-serif">ncB</span>, and <span class="sans-serif">ms</span> (the split node: $m_c$, a cap, $\mathcal C$ and the pieces; each piece records its interval and type and, according to the type, its cap, $p^*$ value, vertex certificates, sub-pieces, or child node). Only the kinds <span class="sans-serif">lpv</span> and <span class="sans-serif">ms</span> occur in the data (Table 1).

| sign   | <span class="sans-serif">lpv</span> | <span class="sans-serif">ncA</span>/<span class="sans-serif">ncB</span> | <span class="sans-serif">ms</span> | <span class="sans-serif">small</span> | total |
|:-------|------------------------------------:|------------------------------------------------------------------------:|-----------------------------------:|--------------------------------------:|------:|
| $s=+1$ |                                3804 |                                                                       0 |                               4303 |                                     0 |  8107 |
| $s=-1$ |                                1059 |                                                                       0 |                                  0 |                                     0 |  1059 |

Two-coordinate boxes for Theorem 6. Widths range from $0.00086$ to $0.01$ in $u$, from $0.013$ to $0.1$ in $t$ and from $0.023$ to $0.094$ in $r$. The <span class="sans-serif">ms</span> boxes carry split nodes of height $0$ (2029 boxes), $1$ (1030) and $2$ (1244): 4303 nodes of level $0$, 4873 of level $1$ and 3958 of level $2$. Cuts: level $0$ $\frac{2}{5}$ (1335), $\frac{7}{20}$ (1330), $\frac{9}{20}$ (1034), $\frac{1}{2}$ (592), $\frac{3}{10}$ (10), $\frac{3}{4}$ (2); level $1$ $\frac{1}{2}$ (1281), $\frac{11}{20}$ (1094), $\frac{13}{20}$ (902), $\frac{9}{20}$ (825), $\frac{3}{5}$ (771); level $2$ $\frac{13}{20}$ (3913), $\frac{3}{5}$ (45). Pieces: level 0: minus 2 <span class="sans-serif">SG</span>, 4301 <span class="sans-serif">TC</span>; plus 5445 <span class="sans-serif">TC</span>, 4873 <span class="sans-serif">TCN</span>, 58 <span class="sans-serif">TCS</span>; level 1: minus 4873 <span class="sans-serif">TC</span>; plus 127 (A4), 5768 <span class="sans-serif">TC</span>, 3958 <span class="sans-serif">TCN</span>, 1400 <span class="sans-serif">TCS</span>; level 2: minus 3958 <span class="sans-serif">TC</span>; plus 1431 (A5), 6240 <span class="sans-serif">TC</span>, 396 <span class="sans-serif">TCS</span>. Every <span class="sans-serif">TCS</span> piece has $m_c'=\frac{17}{20}$; the sub-pieces are 58 (A4) at level 0, 1769 (A5) at level 1, 644 (A6) at level 2. There are 52 292 vertex-certificate sets (4863 in <span class="sans-serif">lpv</span> boxes, 47 429 in split nodes) with 784 616 vertices; 9168 of them have two patch parameters, 14 735 three, 17 399 four and 10 990 five. The polynomials of 24 326 vertices have degree $10$, all others degree $6$.

## Generation

`scripts/run_k5.sh` writes the 105 jobs ($101$ two-coordinate jobs: the plus slabs $i=0,\dots,23$, the $44$ plus $u$-subslabs and the $33$ minus slabs; and $4$ one-coordinate jobs) to `outputs/k5/jobs_all.txt`. A two-coordinate job is `python3 cover6.py u1 u2 s out.json `$\nu$` 4 8 16` with the environment `RQ_K=5 RQ_AS=1/4 RQ_MSD=5 RQ_MAXLEV=2 RQ_WTCN=1/16` and the lists of cuts `RQ_MCS0` $=\frac9{10},\frac{17}{20},\frac45,\frac34,\frac12,\frac9{20},\frac25,\frac35,\frac7{20},\frac3{10}$ (root nodes), `RQ_MCSN` $=\frac{13}{20},\frac35,\frac{11}{20},\frac12,\frac9{20},\frac25$ (children of $\mathsf{TCN}$ pieces) and `RQ_MCST` $=\frac{17}{20},\frac45,\frac34$ ($\mathsf{TCS}$ pieces). It bisects $[u_1,u_2]\times[0,T_8]\times[\frac14,1]$ adaptively ($\nu$ initial $u$-intervals, 4 initial $t$-intervals, 8 $r$-intervals, depth $\le16$) and on each box tries, in order: <span class="sans-serif">small</span>; the near-circle tests (`nearcircle.py`); a vertex certificate (`cert5.py`); from depth 5 on, a split node of level $0$ (`cover6.try_ms`). In a node of level $l$ with range $\hat\kappa$ the cut $m_c$ is the first value $m_c<\hat\kappa$ of the list for which $\mathcal C$ exists and both sides can be covered; each side is covered by bisecting $[m_c,\hat\kappa]$ (depth at most $4$ at level $0$ and $3$ below, at most $10$ pieces). A plus piece is tried as $(\mathrm A_{l+3})/(\mathrm B_{l+3})$ (generator-side tests `nsphere3.py`, `cert4.py` and `cover6.check_piece_n` for $n=3$, $4$, $\ge5$), then $\mathsf{TC}^+$ with $\kappa'=\kappa(n_2)$ (rounded up), then $\mathsf{TCS}$ (cuts from `RQ_MCST`, sub-pieces by bisection, depth at most $6$, at most $24$), and, if $l+1\le2$ and the piece has width at most $\frac1{16}$, $\mathsf{TCN}$ with range $\kappa(n_2)$ (rounded up); a minus piece as $\mathsf{SG}$ (if $2n_1^2>1$, with cap $\min(n_2,\hat\kappa)$) and then $\mathsf{TC}^-$. Vertex sets with two or three patch parameters come from `cert5.py` and those with four or five from `cert6.py` ($n_0$ a rational approximation of the patch point at the centre with $|n_0|\ge1$; the polytope is a box in an exactly orthogonal rational basis of $n_0^\perp$ containing the gnomonic projection of a grid of the patch with a relative margin; its corners are the vertices). The cone check is the exact test of Lemma 21 (`sphmin.py`). The coefficient vectors come from a discretised moment linear program (degree $6$, or $10$ if degree $6$ fails), rounded to rationals and repaired; (W1), (W2) and (P1)–(P4) are checked exactly before a record is accepted. One-coordinate cells come from `cover_lp10.py` (degree-ten certificates), run with `RQ_LPFALLBACK=1`: if the HiGHS simplex method stops without a solution, the linear program is solved again by the interior-point method and with other reference points $u$ of the cell. This changes only where a candidate comes from. Without it, the job for $u\in[3,\frac{31}{10}]$ left two cells unproved ($u\in[3+\frac{254}{10240},3+\frac{256}{10240}]$, $a\in[\frac{351}{2048},\frac{352}{2048}]$; the simplex method failed there at every depth); the other three one-coordinate files are byte-identical with and without it. No box or cell of the final data failed.

The slabs were started with $\nu=1$. The plus slabs in $[\frac{315}{100},U_+]$, next to $u_6$, progressed too slowly and were replaced by the $u$-subslabs listed above (each again with $\nu=1$); the whole-slab runs were stopped before they ended and left no data. Two runs started on RQ-A’s machine while RQ-C was finishing the same jobs (the plus slabs $i=14,15$) were killed within minutes and left no data either; RQ-C’s files are used. Jobs were run by `scripts/k5_sched.py` (queue `outputs/k5/queue.txt`) on RQ-A’s machine and, for $54$ of the $105$ files (the $s=-1$ slabs, the plus slabs $i=10,\dots,23$ and the subslabs `p_24s0`, …, `p_24s3`, `p_25s1`, `p_25s2`, `p_25s3`), by RQ-C with an unmodified copy of `scripts/` (md5 sums of the copied scripts in `outputs/k5/RQC_SCRIPTS_MD5SUMS.txt`; delivered files and their md5 sums in `outputs/k5/RQC_MD5SUMS.txt`, logs in `outputs/k5/logs/*.rqc.log`). The copy differs from the final `scripts/` in six files, none of which a two-coordinate job runs: `run_k5.sh` (the job list, in which $p_{24},\dots,p_{32}$ were whole slabs, and `RQ_LPFALLBACK` for the one-coordinate jobs), `cover_lp10.py` (the fallback), the verifier `verify_k5.py` and its negative tests `break_tests_k5.py`, `build_main_md.py` and `mirror.sh`. The generators of the two-coordinate jobs (`cover6`, `cert4`, `cert5`, `cert6`, `sphmin`, `nearcircle`, `nsphere3` and their imports) are identical. Generation is not part of the proof: all files are checked in the same way by the verifier. The $101$ two-coordinate jobs took $65.6$ hours in total ($40.1$ hours for the $44$ subslabs; the longest job, $p_{23}$, took $135$ minutes), and the four one-coordinate jobs took $2$ to $3.5$ minutes each.

## Independent verification

`python3 verify_k5.py` re-checks everything from the data files, and all parts pass (output `outputs/verify_k5_ABCDEFG.txt`; 4449 seconds on 8 cores, 9.8 hours of CPU time, almost all of it in part D). It shares no code with the generators (`cert2c`, `cert4`, `cert5`, `cert6`, `sphmin`, `cover6`, `cover_lp10`, `tenmom`, `nsphere3`, `nearcircle`, `exactcert`, `fourbit`, `bitlemma_k4`, `bitlemma_k5`). It reuses the exact helpers of `verify_k4.py` (the verifier of Theorem 5: exact facet minima of nested patches, vertex-certificate domination, interval helpers), of `verify_k3b.py` (the verifier of Theorem 4: moment polynomials, objective bound, facet normals, atom enclosures, envelopes, cap and $\varphi$ checks, interval coverage, symbolic part A) and the Sturm-sequence, integer-square-root and tiling helpers of `verify_all.py` (the verifier of Theorem 1, audited in A.6). It replaces the range enclosure of the polynomials $G_j$ of `verify_k3b.py`, whose bisection does not terminate when $G_j'$ has a root inside the range (for $k=5$, $G_9'$ vanishes at $w\approx8.68$, i.e. $u\approx2.926$), by its own: exact endpoint values on subintervals without a root of $G_j'$ (Sturm), and interval Horner evaluation on subintervals of length $2^{-30}$ times the range that still contain one. Its parts:

1.  Symbolic identities (sympy). Lemma 10: the cumulants of $\chi$, computed from its moments, are $d^{[j\text{ odd}]}G_j(w)$ for $j=3,\dots,10$. Lemma 11: the recursion reproduces the Gaussian moments, and also the moments of $\chi$ at $u=\frac52$, up to order ten.

2.  Coverage (exact). $U_-\le u_5$ (checked as $U_-^2\le4$ or $(U_-^2-4)^2\le20$); $U_+\ge u_6$ (checked as $U_+^2\ge5$ and $(U_+^2-5)^2\ge30$); (3); and $T_8\ge\sqrt2-1$. The cells tile $[U_-,U_+]\times[0,\frac14]$. For each sign the boxes tile $[U_-,U_+]\times[0,T_8]\times[\frac14,1]$: they lie in the region, have pairwise disjoint interiors and total volume equal to the volume of the region (a closed subset of full measure is dense, so it is the whole region). Every box has the sign of its file and one of the kinds <span class="sans-serif">small</span>, <span class="sans-serif">lpv</span>, <span class="sans-serif">ncA</span>, <span class="sans-serif">ncB</span>, <span class="sans-serif">ms</span>, so that one of the parts B, D, E, F checks it. Every <span class="sans-serif">small</span> box satisfies $r_2c(t_1)\le A_S$. Every file has $K=5$ and $A_S=\frac14$, and no file lists a failed box or cell.

3.  One-coordinate cells: (V1)–(V3) by Sturm sequences; $\Theta_1>0$; (V4) strictly (Definition 14 re-implemented: the polynomials $\mu_n$ from the recursion, the monomial bounds, and a Sturm count of the roots of $h$ on $[0,\bar m]$ together with $h(0)>0$).

4.  Vertex certificates of every node of every split tree: all <span class="sans-serif">lpv</span> records; in every node $\mathcal C$; in every $\mathsf{TC}^\pm$, $\mathsf{SG}$ and $\mathsf{TCS}$ piece its certificates. (P1) and (P2) exactly; (P3) by exact Gaussian elimination (rank $k$ of each facet, normal vector, orientation by the centre); (P4) by the recursion of Lemma 21 as described after it, in an implementation of its own (exact sign decisions, integer square-root bounds, no rounding of intermediate values); (W1) on every linear piece of every vertex envelope (Definition 22, recomputed from the atom enclosures over $[u_1,u_2]$); (W2) strictly with the target $T^-(u_1,u_2)$. The patch parameters, sign vector, cap and $p^*$ value of each certificate are taken from the structure: $X_l$ (or $X_l\times[n_1,n_2]$) and $\sigma_l$ (or $(\sigma_l,\pm1)$) from the position in the tree; $\bar m(B)$ (recomputed exactly) for <span class="sans-serif">lpv</span>; the cut $m_c$ of the node for $\mathcal C$; for $\mathsf{TCS}$ the recorded $m_c'$, and the recorded cap $\kappa'$ with the recorded $p'^*$; and the recorded cap $\kappa'\in(0,1]$ (and $p^*<0$ for $\mathsf{SG}$) for the others.

5.  Near-circle boxes: mpmath interval arithmetic (120 bits), tests (A)/(B) strictly, with the target $T^-(u_1,u_2)$ of Lemma 28, enclosed in interval arithmetic.

6.  Split trees: for every <span class="sans-serif">ms</span> box $r_2<1$ and a recorded root cap $\ge\min(1,\bar m(B))$; recursively, for every node: $0<m_c<\kappa\le1$ for its recorded cap $\kappa$ (the range at the root is $\min(1,\bar m(B))$, below a $\mathsf{TCN}$ piece $[n_1,n_2]$ it is $\kappa$, and $\kappa\ge\kappa(n_2)$ is checked as $\kappa\ge1$ or $\kappa^2(1-n_2^2)\ge n_2^2$); the plus pieces and the minus pieces each cover $[m_c,\hat\kappa]$; every near-sphere piece of a node of level $l$ is of type $(\mathrm A_{l+3})/(\mathrm B_{l+3})$ and passes one of the two tests (mpmath, strict; $(\mathrm A_n)$ with $n\ge5$ includes $s=1$ and the OR-region condition); the cap condition $\kappa'\ge\kappa(n_2)$ of $\mathsf{TC}^\pm$ and $\mathsf{TCS}$; for $\mathsf{TCS}$, $m_c'<\kappa'$, the $\varphi$ condition of $(m_c',p'^*)$, the cover of $[m_c',\kappa']$ by the sub-pieces, and the sub-pieces of type $(\mathrm A_{l+4})/(\mathrm B_{l+4})$ passing their tests; for $\mathsf{SG}$, the $\varphi$ condition of $(n_1,p^*)$ ($0<n_1\le1$, $2n_1^2>1$, $p^*<0$, and $p^*\ge\varphi(n_1)$, checked as $p^*+n_1^3\ge0$ and $(p^*+n_1^3)^2\ge(1-n_1^2)^3$) and $\kappa'\ge\min(n_2,\hat\kappa)$.

7.  The claims (C1) and (C2) of Lemmas 7 and 8, for all $2^8$ and all $2^{16}$ functions, exactly as described there, including the list of equality cases ($\pm$OR of four bits at $q_5$ only; none for three bits).

The generator side has its own exact check of the bit lemmas (`scripts/bitlemma_k5.py`, output `outputs/bitlemma_k5.txt`, same result).

#### Negative tests.

`python3 break_tests_k5.py` corrupts random samples of records (seed 13) and runs the check functions of `verify_k5.py` on them (26 seconds; output `outputs/break_tests_k5.txt`). Every corruption below is rejected in every case. On 40 <span class="sans-serif">lpv</span> boxes: lowering the constant term of one vertex polynomial by $\frac1{20}$ (domination fails), raising it by $1$ (the objective bound fails), shrinking the polytope by $10\%$ about its centre (the cone check fails) and moving one vertex by $10^{-6}$ (the hyperplane/parallelepiped check fails). On 40 split nodes of any level: removing one plus piece or one minus piece (coverage fails). On 25 <span class="sans-serif">ms</span> boxes: lowering the root cap below $\min(1,\bar m(B))$, with the pieces clipped to the new cap (the top check fails). At 60 split nodes: replacing the cap of a $\mathsf{TC}$, $\mathsf{TCS}$ or $\mathsf{TCN}$ piece $[n_1,n_2]$ with $n_2<1$ by $n_2$ (112 cases; the cap check $\kappa'\ge\kappa(n_2)$ fails). For both $\mathsf{SG}$ pieces of the data: lowering $p^*$ to $\varphi(n_1)-\frac1{100}$ (the $\varphi$ check fails) and lowering the cap below $\min(n_2,\hat\kappa)$ (the cap check fails). On 25 $\mathsf{TCS}$ pieces: widening the lowest near-sphere sub-piece from $[o_1,o_2]$ to $[\frac{o_1}4,o_2]$ (the near-sphere test fails). On 25 near-sphere pieces: changing the number of coordinates in the label (the type check fails). On 25 $(\mathrm A_5)$ and $(\mathrm A_6)$ pieces of boxes with $s=1$: re-checking them with $s=-1$ (test $(\mathrm A_n)$, $n\ge5$, must not pass, since the OR-region identity needs $s=1$). On 25 nested split nodes: lowering the cut $m_c$ by $\frac1{50}$ without adding pieces (coverage fails), and, for the 21 of them where the $\mathsf{TCN}$ piece $[n_1,n_2]$ of the node has $2n_2^2<1$ and there is room above $m_c$, lowering the cap of the node to a rational number between $m_c$ and $\kappa(n_2)-10^{-4}$, with the pieces clipped (the cap check fails). On 25 <span class="sans-serif">ms</span> boxes: lowering the constant term of one vertex polynomial, in a vertex set of any level, by $\frac1{20}$ (domination fails). On 40 nested polytopes with three to five patch parameters: shrinking by $\frac12$ about the centre (the cone check fails). Removing one box from the tiling, for each sign. On 30 one-coordinate cells: raising the constant term of the certificate by $1$ (the objective bound fails). On 40 boxes: relabelling the kind as `LPV`, as the kind followed by a space, as `nc`, as the empty string and as `msplit` (200 cases; part B rejects them). Four sanity checks (not corruptions) hold: on the same 40 <span class="sans-serif">lpv</span> boxes the recomputed cap $\bar m(B)$ is at least $\min(1,a_2/b)$ on the box; the 40 unmodified box records pass the per-box check of part B; and for 20 nested vertex sets the exact facet minima of the cone check are at most the minima of $h\cdot p$ over a sample of the patch ($11^k$ points for $k\le4$ patch parameters, $6^5$ for $k=5$; up to $10^{-12}|h|_\infty$ for the rounding of the sample), and, for the 13 sets with $k\le4$, within $10^{-3}|h|_\infty$ of them.

## Reproducing

    pip install numpy scipy sympy mpmath
    cd scripts
    python3 verify_k5.py          # parts A-G, about 75 minutes on 8 cores
    python3 break_tests_k5.py     # negative tests, about 30 seconds
    python3 bitlemma_k5.py        # bit lemmas (generator-side check)
    bash run_k5.sh                # regenerate all data (66 job-hours)

# Proof of Theorem 6

*(a)* By Lemma 3 let $q\in[q_6,q_5]$, i.e. $u\in[u_5,u_6]\subseteq[U_-,U_+]$. Reduce $\alpha$ as in Section 2.3.

1.  $a_1=1$: $\alpha=e_1$ and $\mathbb{E}|L|=2\tau<T_5$ (Lemma 4(iii)).

2.  $a_1\le\frac14$: $(u,a_1)$ lies in a cell, and Lemma 16 gives $\mathbb{E}|L|<T_5$.

3.  $a_1>\frac14$ and $r=1$: $L=a_1\chi_1+sa_2\chi_2$, and Lemma 5 gives $\mathbb{E}|L|<T_5$.

4.  $a_1>\frac14$ and $r<1$: $(u,t,r)$ lies in a box of the cover for the sign $s$ (part B), since $t\in[0,\sqrt2-1]\subseteq[0,T_8]$ and $r\ge a_1>\frac14$. It is not a <span class="sans-serif">small</span> box, since $a_1>A_S$. If it is <span class="sans-serif">lpv</span>, Lemma 26 gives $\mathbb{E}|L|<T_5$. If it is <span class="sans-serif">ncA</span> or <span class="sans-serif">ncB</span>, Lemma 28 gives $\mathbb{E}|L|<T_5$. If it is <span class="sans-serif">ms</span>, Lemma 33 gives $\mathbb{E}|L|\le T_5$.

So $\mathbb{E}|L|\le T_5$ always, and $(e_1+\dots+e_5)/\sqrt5$ attains $T_5$ (Lemma 4, $q<\frac15$). Hence $R(q)=T_5(q)$. For $q\in[1-q_5,1-q_6]$ use Lemma 3: $R(q)=R(1-q)=2\sqrt5\,q^4\tau$.

*(b)* Equality can occur only in the <span class="sans-serif">ms</span> case of (4). By Lemma 33, after the reduction, $\alpha=n^{-1/2}(e_1+e_2+e_{l_1}+\dots+e_{l_{n-2}})$ with distinct $l_i\ge3$, where $n=5$, or $n=4$ and $q=q_5$, or $n=6$ and $q=q_6$. Undoing the reduction (global sign and permutation) gives the list in (b). Conversely, each listed vector attains $T_5$ at the stated $q$ (Lemma 4): $(e_{i_1}+\dots+e_{i_5})/\sqrt5$ gives $T_5$ for $q<\frac15$; $(e_i+e_j+e_k+e_l)/2$ gives $T_4=T_5$ at $q_5$ ($q_5<\frac14$); and $(e_{i_1}+\dots+e_{i_6})/\sqrt6$ gives $T_6=T_5$ at $q_6$ ($q_6<\frac16$). For $q\ge\frac12$ use Lemma 3.

*(c)* For $q<q_6<\frac16$, $R(q)\ge\mathbb{E}|\chi_1+\dots+\chi_6|/\sqrt6=T_6(q)>T_5(q)$ by Lemma 4 and (ii). For $q_5<q<\frac14$, $R(q)\ge T_4(q)>T_5(q)$ by Lemma 4 and (i). For $\frac14\le q\le\frac12$, $R(q)\ge\mathbb{E}|\chi_1|=2\tau$, and $2\tau>2\sqrt5(1-q)^4\tau$ because $5(1-q)^8\le5(\frac34)^8<1$.$\square$

# Remarks

1.  **The $k=5$ regime is closed.** $R(q)=2\sqrt5\,(1-q)^4\sqrt{q(1-q)}$ holds exactly on $[q_6,q_5]$, which is the largest possible interval (Corollary 1). Both ends are ties: at $q_5$ with $(e_1+e_2+e_3+e_4)/2$, at $q_6$ with $(e_1+\dots+e_6)/\sqrt6$. Given Theorem 5, Corollary 2 confirms the conjecture $R(q)=2\tau\max_k\sqrt k\,\hat q^{\,k-1}$ (BF3, Stone; RQ-C’s Conjecture S) on $[q_6,1-q_6]$. The next regime, $k=6$ on $[q_7,q_6]$ with $q_7=1-\sqrt{6/7}$, is not treated here.

2.  **Range of the computations.** The boxes and cells cover $u\in[U_-,U_+]$, slightly more than $[u_5,u_6]$. Outside $[u_5,u_6]$ the four-bit lemma (for $q>q_5$) or the bound $T_6\le T_5$ (for $q<q_6$) fails, so the tests $(\mathrm A_4)$ and $(\mathrm A_6)$ would claim too much there, and the bit lemmas behind $(\mathrm A_3)$ and $(\mathrm A_4)$ are verified only on $[q_6,q_5]$ ($(\mathrm A_5)$ holds for every $q$, by the OR-region identity and Cauchy–Schwarz); this is why Lemmas 29, 31 and 33 and the proof of Theorem 6 use the data only for $q\in[q_6,q_5]$.

3.  **From $k=4$ to $k=5$.** The structure of the proof does not depend on $k$: the one- and two-coordinate routes, the vertex certificates and the split nodes are the same, with the target $T_k$. What depends on $k$ is the input at the leaves of the split trees: the near-sphere bound with $n$ coordinates needs $G_n(c)\le T_k|c|$, which for $n<k$ is a bit lemma ($\sum_i\Delta_i(f)^2\le4k(1-q)^{2k-2}$ for all $f$ on $n$ bits, checked here by enumeration for $n\le4$; RQ-C’s C6 covers $n\le7$), and for $n\ge k$ in the OR region is Lemma 6 with $T_n\le T_k$.

4.  **Where the method is tight.** Split nodes are used in $4303$ of the $8107$ boxes with $s=+1$ and in none with $s=-1$. They are nested (height at least one) in $2274$ boxes and reach height two in $1244$. The near-sphere pieces follow the three extremisers. Four-coordinate pieces occur only for $u\le3.09$ ($123$ boxes; $(e_1+\dots+e_4)/2$ ties at $u_5$). Six-coordinate pieces occur only for $u\ge3.13$ ($129$ boxes; $(e_1+\dots+e_6)/\sqrt6$ ties at $u_6$). Five-coordinate pieces occur on the whole range ($930$ boxes), as $(e_1+\dots+e_5)/\sqrt5$ is extremal for every $q$ of the regime (Table 1).

5.  **Status.** Filed for audit (RQ-A AUDIT_REQUEST.md, MAIN-6, 2026-10-22 22:37 UTC); not yet audited or refereed. The computer steps have been run twice (generator and independent verifier), and the verifier rejects corrupted data (negative tests above).
