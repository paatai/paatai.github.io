"""RQ-AUD independent verifier for RQ-A Lemma S (six-moment certificates), written from the
mathematics only (RQ-A verification code not consulted).  Exact rationals + Arb-certified roots.

Setting: u in [1, u0], q = 1/(1+u^2), v = 1/u, tau = u/(1+u^2), a in [0,1), b = sqrt(1-a^2),
M = sum beta_i chi_i, sum beta_i^2 = 1, |beta_i| <= m = min(1, a/b).
A cell [u1,u2] x [a1,a2] with polynomial P(y) = sum_{k<=6} c_k y^k is VALID if
 (i)  P(y) >= R_a(b y) = max(0, (1-q)(b y - a v), q(-b y - a u)) for all y and all (u,a) in the cell;
 (ii) E P(M) <= tau (1 - a) for all (u,a) in the cell and all admissible M.
Then E R_a(bM) <= tau(1-a), i.e. E|a chi + bM| <= 2 tau.

(i) is implied by P >= 0 on R, P >= l1 on [y1, oo), P >= l2 on (-oo, y2] with the cell majorants
    l1(y) = (u2^2/(1+u2^2)) (bh y - a1/u2),  l2(y) = (1/(1+u1^2)) (-bh y - a1 u1),
    bh >= sqrt(1-a1^2) rational, y1, y2 the zeros of l1, l2 (for y >= y1 > 0: (1-q) <= u2^2/(1+u2^2),
    b y <= bh y, a v >= a1/u2; for y <= y2 < 0 similarly; elsewhere the lines are negative).
(ii) E P(M) = A + B p3 + C p4 + D p5 + E p6 + F p3^2 with A = c0+c2+3c4+15c6, B = k3(c3+10c5),
    C = k4(c4+15c6), D = k5 c5, E = k6 c6, F = 10 k3^2 c6, and (C0.3) |p3| <= r, p4 = r^2,
    r in [0, m], |p5| <= m r^2, r^4 <= p6 <= m^2 r^2.  With interval enclosures of k3..k6 over
    [u1,u2] (k3 = u - v increasing, w = u^2+v^2 increasing, k4 = w-4, k5 = k3(w-10), k6 = w^2-26w+64
    decreasing in w on [2,13]) one gets E P(M) <= A + h(r), h(r) = |B| r + G r^2 + Eneg r^4, and
    we certify T - A - h(r) > 0 on [0, mh], T = tau(u2)(1-a2) (tau decreasing for u >= 1),
    mh >= min(1, a2/b2) rational.
Cells failing with these (cruder) bounds are bisected (same P) up to a fixed depth.
"""
import os as _os
_ROOT = _os.path.abspath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "..", ".."))  # archive root
import json
import glob
import sys
import time
from fractions import Fraction as Fr
from math import isqrt

from flint import fmpz_poly

ROOT = sys.argv[1] if len(sys.argv) > 1 else _os.path.join(_ROOT, 'RQ-A/outputs/cover')
D = 10**30


def sqrt_hi(x):
    n = isqrt(x.numerator * D * D // x.denominator)
    r = Fr(n + 1, D)
    assert r * r >= x
    return r


def sqrt_lo(x):
    n = isqrt(x.numerator * D * D // x.denominator)
    r = Fr(n, D)
    assert r * r <= x
    return r


def to_int_poly(coeffs):
    """rational coefficient list (low -> high) -> fmpz_poly with the same roots, positive multiple"""
    den = 1
    for c in coeffs:
        den = den * c.denominator // __import__('math').gcd(den, c.denominator)
    return fmpz_poly([int(c * den) for c in coeffs])


def ball_q(x):
    m_, e_ = x.mid().man_exp()
    r_, f_ = x.rad().man_exp()
    mid = Fr(int(m_)) * Fr(2)**int(e_)
    rad = 2 * Fr(int(r_)) * Fr(2)**int(f_) + Fr(1, 10**40)
    return mid - rad, mid + rad


def real_roots_q(coeffs):
    """certified rational enclosures [lo, hi] of all real roots"""
    p = to_int_poly(coeffs)
    if p.degree() <= 0:
        return []
    out = []
    for c, mult in p.complex_roots():
        if c.imag != 0:
            continue
        out.append(ball_q(c.real))
    return out


def lead_positive_even(coeffs):
    cs = list(coeffs)
    while cs and cs[-1] == 0:
        cs.pop()
    return len(cs) - 1, cs[-1] > 0 if cs else False


def positive_on(coeffs, lo=None, hi=None):
    """certify coeffs-polynomial > 0 on [lo, hi] (None = infinite end). Returns (ok, reason)."""
    deg, lp = lead_positive_even(coeffs)
    for rlo, rhi in real_roots_q(coeffs):
        if (hi is not None and rlo > hi) or (lo is not None and rhi < lo):
            continue
        return False, f"root in [{float(rlo):.6g},{float(rhi):.6g}]"
    # no root in the interval: sign is constant; evaluate at an interior point or use infinity
    if lo is not None and hi is not None:
        x = (lo + hi) / 2
    elif lo is not None:
        x = lo + 1
    elif hi is not None:
        x = hi - 1
    else:
        x = Fr(0)
    val = sum(c * x**k for k, c in enumerate(coeffs))
    return (val > 0), ("" if val > 0 else "negative")


def kappa_ranges(u1, u2):
    k3 = (u1 - 1 / u1, u2 - 1 / u2)
    w = (u1 * u1 + 1 / (u1 * u1), u2 * u2 + 1 / (u2 * u2))
    assert u1 >= 1 and w[1] < 13
    k4 = (w[0] - 4, w[1] - 4)
    k5 = (-(k3[1] * (10 - w[0])), -(k3[0] * (10 - w[1])))
    k6 = (w[1]**2 - 26 * w[1] + 64, w[0]**2 - 26 * w[0] + 64)
    k3sq = (k3[0]**2, k3[1]**2)
    return k3, k4, k5, k6, k3sq


def imul(I, c):
    a, b = I[0] * c, I[1] * c
    return (min(a, b), max(a, b))


def check_cell(u1, u2, a1, a2, c):
    assert len(c) == 7
    # (i)
    bh = sqrt_hi(1 - a1 * a1)
    s1 = u2 * u2 / (1 + u2 * u2)
    l1 = [-s1 * a1 / u2, s1 * bh]
    s2 = 1 / (1 + u1 * u1)
    l2 = [-s2 * a1 * u1, -s2 * bh]
    P = list(c)
    ok, why = positive_on(P)
    if not ok:
        return False, "P>=0: " + why
    y1 = (a1 / u2) / bh
    y2 = -(a1 * u1) / bh
    Pm1 = [P[0] - l1[0], P[1] - l1[1]] + P[2:]
    ok, why = positive_on(Pm1, lo=y1)
    if not ok:
        return False, "P>=l1: " + why
    Pm2 = [P[0] - l2[0], P[1] - l2[1]] + P[2:]
    ok, why = positive_on(Pm2, hi=y2)
    if not ok:
        return False, "P>=l2: " + why
    # (ii)
    k3, k4, k5, k6, k3sq = kappa_ranges(u1, u2)
    c0, c1, c2, c3, c4, c5, c6 = c
    A = c0 + c2 + 3 * c4 + 15 * c6
    Babs = max(abs(x) for x in imul(k3, c3 + 10 * c5))
    Chi = imul(k4, c4 + 15 * c6)[1]
    Dabs = max(abs(x) for x in imul(k5, c5))
    Ehi = imul(k6, c6)[1]
    Fhi = max(imul(k3sq, 10 * c6)[1], 0)
    b2 = sqrt_lo(1 - a2 * a2)
    mh = min(Fr(1), a2 / b2) if b2 > 0 else Fr(1)
    G = Chi + Dabs * mh + Fhi + (Ehi * mh * mh if Ehi > 0 else 0)
    Eneg = Ehi if Ehi < 0 else Fr(0)
    T = u2 / (1 + u2 * u2) * (1 - a2)
    # T - A - (Babs r + G r^2 + Eneg r^4) > 0 on [0, mh]
    H = [T - A, -Babs, -G, Fr(0), -Eneg]
    if T - A <= 0:
        return False, "T <= A"
    ok, why = positive_on(H, lo=Fr(0), hi=mh)
    if not ok:
        return False, "moment bound: " + why
    return True, ""


def check_cell_rec(u1, u2, a1, a2, c, depth=0, maxdepth=6, stats=None):
    ok, why = check_cell(u1, u2, a1, a2, c)
    if ok:
        stats['leaves'] += 1
        stats['maxdepth'] = max(stats['maxdepth'], depth)
        return True, ""
    if depth >= maxdepth:
        return False, why
    um, am = (u1 + u2) / 2, (a1 + a2) / 2
    for (x1, x2) in ((u1, um), (um, u2)):
        for (b1, b2) in ((a1, am), (am, a2)):
            ok, why2 = check_cell_rec(x1, x2, b1, b2, c, depth + 1, maxdepth, stats)
            if not ok:
                return False, why2
    return True, ""


def tiles(region, cells):
    """exact check that the cells (closed rectangles) cover the region rectangle"""
    U1, U2, A1, A2 = region
    us = sorted({U1, U2} | {x for c in cells for x in (c[0], c[1]) if U1 <= x <= U2})
    as_ = sorted({A1, A2} | {x for c in cells for x in (c[2], c[3]) if A1 <= x <= A2})
    for i in range(len(us) - 1):
        um = (us[i] + us[i + 1]) / 2
        for j in range(len(as_) - 1):
            am = (as_[j] + as_[j + 1]) / 2
            if not any(c[0] <= um <= c[1] and c[2] <= am <= c[3] for c in cells):
                return False, (float(um), float(am))
    return True, None


def main():
    t0 = time.time()
    total = fails = 0
    allstats = {'leaves': 0, 'maxdepth': 0}
    regions = []
    for f in sorted(glob.glob(ROOT + '/*.json')):
        d = json.load(open(f))
        region = [Fr(x) for x in d['region']]
        regions.append(region)
        cells = []
        nf = 0
        for cl in d['cells']:
            u1, u2, a1, a2 = (Fr(cl[k]) for k in ('u1', 'u2', 'a1', 'a2'))
            c = [Fr(x) for x in cl['c']]
            cells.append((u1, u2, a1, a2))
            st = {'leaves': 0, 'maxdepth': 0}
            ok, why = check_cell_rec(u1, u2, a1, a2, c, stats=st)
            allstats['leaves'] += st['leaves']
            allstats['maxdepth'] = max(allstats['maxdepth'], st['maxdepth'])
            total += 1
            if not ok:
                nf += 1
                print(f"  FAIL {f.split('/')[-1]} cell u[{float(u1):.6f},{float(u2):.6f}] a[{float(a1):.5f},{float(a2):.5f}]: {why}")
        tok, where = tiles(region, cells)
        fails += nf
        print(f"{f.split('/')[-1]}: region u[{float(region[0])},{float(region[1])}] a[{float(region[2])},{float(region[3])}],"
              f" {len(cells)} cells, failures {nf}, tiling {'OK' if tok else 'GAP at ' + str(where)}", flush=True)
    print(f"total cells {total}, failures {fails}, sub-cells used {allstats['leaves']}, max subdivision depth {allstats['maxdepth']}, {time.time() - t0:.1f}s")


if __name__ == '__main__':
    main()
