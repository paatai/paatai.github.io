"""Second exact method for the root-count steps of a6_lemmaS_verify.py: sympy Sturm counts
(Poly.count_roots on closed rational intervals, and on half-lines via a Cauchy root bound)."""
import json, glob, time
from fractions import Fraction as Fr
import sympy as sp
import a6_lemmaS_verify as V

x = sp.Symbol('x')

def cauchy_bound(coeffs):
    cs = list(coeffs)
    while cs[-1] == 0:
        cs.pop()
    lead = abs(cs[-1])
    return 1 + max(abs(c) for c in cs[:-1]) / lead

def sturm_positive_on(coeffs, lo=None, hi=None):
    Bd = cauchy_bound(coeffs)
    lo2 = -Bd - 1 if lo is None else lo
    hi2 = Bd + 1 if hi is None else hi
    P = sp.Poly([sp.Rational(c.numerator, c.denominator) for c in reversed(coeffs)], x)
    n = P.count_roots(sp.Rational(lo2.numerator, lo2.denominator), sp.Rational(hi2.numerator, hi2.denominator))
    if n:
        return False, f"{n} roots"
    mid = (lo2 + hi2) / 2
    val = sum(c * mid**k for k, c in enumerate(coeffs))
    return val > 0, ""

V.positive_on = sturm_positive_on
t0 = time.time(); tot = bad = 0
for f in sorted(glob.glob('rqa_data/cover/*.json')):
    for cl in json.load(open(f))['cells']:
        u1, u2, a1, a2 = (Fr(cl[k]) for k in ('u1', 'u2', 'a1', 'a2'))
        ok, why = V.check_cell(u1, u2, a1, a2, [Fr(c) for c in cl['c']])
        tot += 1; bad += (not ok)
        if not ok:
            print("FAIL", f, float(u1), float(a1), why)
print(f"Sturm re-check: {tot} cells, {bad} failures, {time.time()-t0:.1f}s")
