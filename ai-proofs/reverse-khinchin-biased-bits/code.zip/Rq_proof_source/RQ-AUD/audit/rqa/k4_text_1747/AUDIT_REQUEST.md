# Audit requests from RQ-A

## MAIN-5 (new, 2026-10-22 16:00 UTC): Theorem 5 = CLAIMS.md MAIN-5

**Audited: VALID, NEW (RQ-AUD A.25, 16:53 UTC), no fix to the mathematics.** A.25's text remarks applied at
17:46 UTC, nothing else changed: r1, Corollary 2 now cites Theorem 4 as audited (A.18) instead of "filed as
MAIN-4, not yet audited"; r2, Remark 4 ("Status") updated. Diff: two passages of `MAIN_RESULT_K4.tex` (and the
regenerated `.md`/`.pdf`, plus the status paragraph of `notes/main_k4_md_header.md`). Ready for a referee.

Claim for audit: **R(q) = 4 (1-q)^3 sqrt(q(1-q)) for all q in [q5, q4] = [1-2/sqrt5, 1-sqrt3/2] =
[0.105573, 0.133975] (and R(q) = 4 q^3 sqrt(q(1-q)) on the mirror [1-q4, 1-q5]); equality holds iff
alpha = ±(e_i+e_j+e_k+e_l)/2, or q = q4 and alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q5 and
alpha = ±(e_i1+...+e_i5)/sqrt5; R > T4 on (0, q5) and (q4, 1/2].** So {q <= 1/2 : R(q) = T4(q)} = [q5, q4]
(Corollary 1), and with Theorems 1-4 (A.6, A.11, A.14, A.18): R(q) = 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1),
qh = max(q, 1-q), on [q5, 1-q5] = [0.10557, 0.89443] (Corollary 2). Its lemmas lem:or, lem:three and lem:four
were audited in A.20 (unchanged since). RQ-C's C13 (A.21) covers [0.127155, q4] of the same regime by a
different cover; Theorem 5 does not use it.

- Proof: `MAIN_RESULT_K4.pdf` (24 pages; LaTeX source `MAIN_RESULT_K4.tex`, md5 9c7a75e9…; same text in
  `MAIN_RESULT_K4.md`). Lemma numbers below are those of the PDF. It follows `MAIN_RESULT_K3B` (A.18); the
  paragraph "Relation to Theorem 4" in Section 1 lists the changes: the k = 4 target and bit lemmas (A.20),
  the OR-region identity (Lemma 6), one more level of the m-split (TCN, Definitions 36-37 and Lemma 38)
  ending in the five-coordinate near-sphere bound (Lemma 35, tests (A5)/(B5)) around (e_1+...+e_5)/sqrt5,
  and the exact cone test (P4) by chains of one-variable minima (Lemma 21, "facet minima"), which replaces
  the interval bisection of A.18. Vertex sets now have two, three or four patch parameters.
- Data: all 80 files are listed in `outputs/k4_manifest.json` (md5 e7ecde05…): 1,268 one-coordinate cells
  (`outputs/k4/one_0.json` ... `one_3.json`) and 7,261 two-coordinate boxes in 76 files (`outputs/k4/p_i.json`,
  s = +1, and `m_i.json`, s = -1, i = 0..37). Kinds: s = +1: 3,327 lpv, 2,718 ms5; s = -1: 1,216 lpv (no ncA,
  no small). 21,014 vertex-certificate sets (171,488 vertices), 2,533 four-coordinate and 383 five-coordinate
  near-sphere pieces; full statistics in Table 1 and `outputs/k4_stats.txt`. 87 MB. md5s:
  `outputs/k4_MD5SUMS.txt` (md5 3a8fd366…). Logs `outputs/k4/logs/`, job list `outputs/k4/jobs_all.txt`.
- Independent verifier: `cd scripts && python3 verify_k4.py` (parts A-G, 367 s on 8 cores; `RQ_NPROC`
  sets the number of processes, `RQ_MANIFEST4` another manifest). Output: `outputs/verify_k4_ABCDEFG.txt`
  (ALL REQUESTED PARTS PASS). It shares no code with the generators (cert2c, cert4, cert5, cert6, sphmin,
  cover5, cover_lp10, tenmom, nsphere3, nearcircle, exactcert, fourbit, bitlemma_k4); it reuses the helpers of
  `verify_k3b.py` (A.18) and `verify_all.py` (A.6).
- Negative tests: `python3 break_tests_k4.py` (9 s), output `outputs/break_tests_k4.txt`: 23 corruption types,
  every sampled case rejected; 2 sanity checks hold.
- Generator-side check of the bit lemmas: `python3 bitlemma_k4.py`. Regeneration of all data:
  `bash run_k4.sh` (8.5 job-hours; `--dry-run` prints the job list).

Suggested audit points (where an error would most likely hide):
1. Lemma 38 (TCN) and Definitions 36-37: the inner split at m'_c (cases (1)-(3) of the proof), the cap
   conditions kappa >= min(1, m_2/sqrt(1-m_2^2)) (883 of the 1,247 TCN caps are < 1) and kappa_4 >=
   min(1, n_2/sqrt(1-n_2^2)), the SG3 conditions (p'* >= phi(n_1), kappa_3 >= n_2 or the cap condition with m_2),
   coverage of [m'_c, kappa] by inner plus and minus pieces and of [m''_c, kappa_4] by the A5/B5 sub-pieces, and
   the claim that i_0, i_1, i_2 are distinct.
2. Lemma 35 and tests (A5)/(B5): the tail term (27/128) b'''^4 E_4'/|y|^3 (Lemma 27), the enclosures of
   a_1..a_5, b'''^2 and r''', and (A5)'s use of the OR-region identity: it needs s = 1 and a_i > q sum a_l, and
   G_5 <= T5 r''' <= T4 r''' holds only for q >= q5. Break test 19 checks that an A5 piece is never accepted
   with s = -1.
3. Lemma 21 (facet minima): the exact chain of one-variable minima of al x + be sqrt(1-x^2) over the nested
   patch, and its sign rules, replacing the sub-box bisection of A.18 in (P4). Verifier: part D, own
   implementation; break test 21 (nested polytopes shrunk by 1/2 must fail) and sanity check 22 (the exact
   minima agree with sampled minima to 1e-3 |h|).
4. Range: U- = 1589/625 <= u4 and U+ = 29107/10000 >= u5 (part B0); the bit lemmas and T5 <= T4 hold only on
   [q5, q4], and the boxes reaching beyond [u4, u5] are used only at points with q in [q5, q4] (Section 11,
   item 2 of the remarks). As in
   A.18, the data cannot show this; it is a statement about the theorem's range.
5. The equality analysis (Theorem 5(b)): equality only where no strict certificate is used: b' = 0 in (A3),
   b'' = 0 in (A4) (inside TCS or as an inner TCN piece), b''' = 0 in (A5) at q5.
6. Lemma 16 (one-coordinate cells, a_1 <= 33/100, degree 10) and coverage (part B): [U-, U+] x [0, 33/100] by
   1,268 cells; [U-, U+] x [0, T8] x [33/100, 1] for each sign by the boxes.

## MAIN-4 (2026-10-22 11:56 UTC): Theorem 4 = CLAIMS.md MAIN-4 — rated VALID by RQ-AUD (A.18, 12:41 UTC, no fix needed)

Claim for audit: **R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for all q in [q4, 25/169] = [1-sqrt3/2, 25/169]
(and R(q) = 2 sqrt3 q^2 sqrt(q(1-q)) on the mirror [144/169, sqrt3/2]); equality holds iff
alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q4 and alpha = ±(e_i+e_j+e_k+e_l)/2; for q < q4, R(q) >= 4(1-q)^3 tau > T.**
With Theorem 3 (A.14): R = T exactly on [q4, q3], and {q <= 1/2 : R(q) = T(q)} = [q4, q3]
(Corollary 1). With Theorems 1 and 2 (A.6, A.11): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2}
= 2 sqrt(q(1-q)) max_k sqrt(k) qh^(k-1), qh = max(q, 1-q), on [q4, 1-q4] = [0.13397, 0.86603]
(Corollary 2). This closes the k = 3 gap [q4, 25/169] that A.14 left open (A.16 reduced it to
max|alpha_i| >= 0.2934; Theorem 4 does not use A.16).

- Proof: `MAIN_RESULT_K3B.pdf` (19 pages; LaTeX source `MAIN_RESULT_K3B.tex`; same text in
  `MAIN_RESULT_K3B.md`, whose numbering is used below). It follows `MAIN_RESULT_K3` (A.14); the
  paragraph "Relation to Theorem 3" lists the four new ingredients: the range u in [12/5, u4] with
  A_S = 7/20, degree-10 certificates with a ten-moment bound, vertex certificates, and the
  four-coordinate near-sphere bound with the four-bit lemma.
- Data: all files are listed in `outputs/k3b_manifest.json`: 288 one-coordinate cells
  (`outputs/k3b/one_0.json` ... `one_2.json`) and 1,421 two-coordinate boxes in 33 files
  (`outputs/k3b/b5_<i>_<s>.json`, i = 0..14, s = ±1, except b5_13_1, which is split into
  `sub13_a_1.json` ... `sub13_d_1.json`). Kinds: s = +1: 626 lpv, 13 ncA, 302 ms5 (1,350 pieces:
  A3 123, TC 871, SG 146, TCS 210; 301 four-coordinate sub-pieces A4); s = -1: 480 lpv. In total
  2,845 vertex-certificate sets (16,544 vertices). 7.8 MB. md5s: `outputs/k3b_MD5SUMS.txt`
  (md5 2074adcc…). `outputs/k3b/discarded/` holds superseded runs and is not used.
- Independent verifier: `cd scripts && python3 verify_k3b.py` (parts A-G, 93 s on 8 cores).
  Output: `outputs/verify_k3b_ABCDEFG.txt` (ALL REQUESTED PARTS PASS). It shares no code with the
  generators (cert2c, cert4, cert5, cover5, cover_lp10, tenmom, nsphere3, nearcircle, exactcert,
  fourbit) and reuses only the Sturm, integer-square-root and tiling helpers of `verify_all.py` (A.6).
- Negative tests: `python3 break_tests_k3b.py` (seconds), output `outputs/break_tests_k3b.txt`: all
  corruptions rejected; one separate sanity check (the verifier's own lpv cap) holds 40/40.
- Generator-side check of the four-bit lemma: `python3 fourbit.py`. Regeneration of all data:
  `bash run_k3b.sh` (about 40 minutes with 8 jobs; `--dry-run` prints the job list).

Suggested audit points (where an error would most likely hide):
1. Vertex certificates. Lemma 16 (F_x(y) = E|sum_i sigma_i x_i chi_i + x_{k+1} y| is convex and
   1-homogeneous in x), Definition 18 (vertex set: (P1) V_eps . n0 = |n0|^2 >= 1; (P2) the V_eps form
   a parallelepiped; (P3) each facet has rank k and is oriented by the centre; (P4) every facet
   functional is >= 0 on the patch), Lemma 19 (cone lemma: every patch point is sum nu_eps V_eps
   with nu >= 0 and sum nu <= 1/|n0| <= 1) and Lemma 23 (then E F_{p(xi)}(Z) <= sum nu_eps E P_eps(Z)
   < T^-, using P_eps > Phi_{V_eps} >= F_{V_eps} >= 0). In the verifier: part D, `cone_normals`,
   `cone_contains_patch` (exact interval bisection, at most 20,000 sub-boxes), `check_vset`.
2. Lemma 21 (vertex envelope): the envelope is taken over the u-interval only (the vertex is a fixed
   rational vector), using p_omega y_omega = tau(...) with q u = (1-q) v = tau. The enclosures
   eta_omega^±, beta_omega^± over [u1, u2].
3. Definition 13 / Lemma 14 (ten-moment objective bound): the cumulant table of Lemma 9 for
   j <= 10, the moment recursion of Lemma 10, the power-sum bounds of Lemma 11 (|p_j| <= m^(j-4) rho^2
   for j >= 5, p_j >= rho^(j-2) for even j), the classification of exponent vectors ("even" e and
   (ell_e, l_e)), the optional p* (p3 <= p* < 0), and the final positivity check on [0, m*].
4. Lemma 7 (four-bit lemma) and its range: sum_i Delta_i(f)^2 <= 12(1-q)^4 for all 65,536 Boolean f
   of four bits on [q4, 25/169]; equality identically only for ±OR_S with |S| = 3, and at q4 also for
   ±OR_4 (sum Delta_i^2 - 12(1-q)^4 = -4(1-q)^4 g4 with g4 = 4q^2-8q+1 for OR_4). It is false for
   q < q4, so Lemmas 31, 33 and 35 are stated for q >= q4, and the boxes of the last u-slab, which
   reach U+ = 127123/50000 > u4, are used only at points with u <= u4. As in A.11/A.14, parts E/F
   cannot detect a box used outside the claimed range; this is a statement about the theorem's
   range, not something the data can show.
5. Lemma 17 and the case m = 1 (then L = a1 chi1 + s a2 chi2 + s3 b chi_{i0} and F does not depend
   on y, so any admissible Z may be used), and the caps: kappa >= min(1, m2/sqrt(1-m2^2)) for TC/TCS;
   for SG, p* >= phi(m1) and kappa >= min(m2, mbar(B)).
6. Lemma 35 (m-split) and Lemma 33 (TCS): the case split m <= m_c / beta_{i0} = -m / beta_{i0} = +m,
   the inner split at m'_c = 17/20 inside TCS pieces, coverage of [m_c, min(1, mbar(B))] on both
   sides and of [m'_c, kappa] by the A4/B4 sub-pieces, and the equality analysis in part (b) of the
   theorem (equality only where a strict certificate is not used: b' = 0 in A3, b'' = 0 in A4).
7. Lemma 15 (one-coordinate cells, a1 <= 7/20, degree 10) and coverage (part B):
   [12/5, U+] x [0, 7/20] by 288 cells; [12/5, U+] x [0, T8] x [7/20, 1] for each sign by the boxes
   (T8 = 20711/50000 >= sqrt2 - 1); the range checks sqrt5 < U- = 12/5 and U+ >= u4 (target lower bound
   T^- = S3 min(T~(u1), T~(u2)) needs T~ monotone on the range, T~ decreasing for u > sqrt5).

## A.14 (Theorem 3) — rated VALID by RQ-AUD at 10:37 UTC (no fix needed)

### Original MAIN-3 request (2026-10-22 09:46 UTC)

Claim for audit: **R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for all q in [q_L, q3] = [25/169, 1-sqrt(2/3)]
(and R(q) = 2 sqrt3 q^2 sqrt(q(1-q)) on the mirror [1-q3, 144/169]); equality holds iff
alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q3 and alpha = ±(e_i+e_j)/sqrt2; and
[25/169, q3] ⊆ {q <= 1/2 : R(q) = T3(q)} ⊆ [q4, q3] with q4 = 1-sqrt3/2.** With Theorem 1 (A.6) and
Theorem 2 (A.11): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2}, qh = max(q, 1-q), on
[25/169, 144/169] = [0.14793, 0.85207].

- Proof: `MAIN_RESULT_K3.pdf` (14 pages; LaTeX source `MAIN_RESULT_K3.tex`; same text in
  `MAIN_RESULT_K3.md`). It follows `MAIN_RESULT_K2` step by step and is self-contained in the same
  sense. The paragraph "Relation to Theorem 2" lists what changed.
- Data: all files are listed in `outputs/k3_manifest.json`: 2,704 one-coordinate cells
  (`outputs/k3/one/o00.json` ... `o09.json`) and 81,975 two-coordinate boxes in 87 files
  (`outputs/k3/cover2c/p00.json` ... `p57.json`, `m00.json` ... `m28.json`; p = sign +1,
  m = sign -1). Kinds: 57,333 lp, 2,534 nc, 21,232 ms (32,932 pieces), 876 small. md5s:
  `outputs/k3_MD5SUMS.txt`.
- Independent verifier: `cd scripts && RQ_K=3 python3 verify_k2.py` (parts A-G, about 8 minutes on
  8 cores). Output: `outputs/verify_k3_ABCDEFG.txt`. This is the A.11 verifier with the parameter
  K = 3: target 2 sqrt3 (1-q)^2 tau with the rational lower bound S3 <= sqrt3, A_S = 2/5, the
  endpoint check U- < u3 and U+ = 12/5 < u4 (part B0), and the k = 3 three-bit claim in part G.
  Without RQ_K it
  reproduces the A.11 run (`outputs/verify_k2_ABCDEFG.txt`).
- Negative tests: `RQ_K=3 python3 break_tests_k2.py` (seconds), output `outputs/break_tests_k3.txt`.

Suggested audit points (where an error would most likely hide):
1. The target and its lower bound (eq. (2)): T = sqrt3 T~(u) with T~(u) = 2u^5/(1+u^2)^3; T~ is
   unimodal with its maximum at u = sqrt5 = 2.236, which lies inside [u3, 12/5], so on a box the
   minimum is at an endpoint and T^-(u1,u2) = S3 min(T~(u1), T~(u2)) is a valid lower bound.
2. Lemma 5 (three-bit lemma, k = 3): P_f = 12(1-q)^4 - sum_i Delta_i(f)^2 >= 0 for all 256 Boolean f
   on [25/169, q3]. P_f vanishes identically only for ±OR_3, and at q3 also for ±OR_2. There is no
   lower end coming from three bits.
3. Lemma 4 and Lemma 20(A): the two-coordinate value is at most T2 r, and T2 <= T needs q <= q3,
   i.e. u >= u3. The cover starts at U- = 2109381/10^6, slightly below u3 = 2.10938137..., and the
   theorem uses the boxes only at points with u >= u3.
4. Lemma 13 (one-coordinate cells, a1 <= 2/5): the target
   Theta_1 = tau(u2) (S3 (u1^2/(1+u1^2))^2 - a2), a lower bound for tau(u) (sqrt3 (1-q)^2 - a) on the
   cell, and the condition 2 tau a + 2 E P(M) <= T.
5. Lemma 23 (m-split) is now used throughout [u3, 12/5] (21,232 of the 69,871 sign +1 boxes),
   with the pieces (A3)/(B3) of Lemma 21, whose main term rests on Lemma 5.
6. Coverage (part B): [U-, 12/5] x [0, T8] x [2/5, 1] for each sign; the small boxes
   (r2 c(t1) <= 2/5); the cells on [U-, 12/5] x [0, 2/5].
7. That the theorem is claimed only for u in [u3, 12/5]. As in A.11, the negative tests show that
   parts E/F alone do not detect a box moved outside this range (here: below u3), as expected.

## A.11 (Theorem 2) — rated VALID by RQ-AUD at 08:52 UTC; text fixes applied

Both cosmetic points of the A.11 report are applied in `MAIN_RESULT_K2.tex/.md/.pdf` (and in the same
places of `MAIN_RESULT_K3`):
- Lemma 20 (tail bound) is now stated for all real y, with the convention that for y = 0 the
  minimum is read as its first entry.
- Definition 23 now asks for m_c in (0, 1] and phi(m_c) <= p* < 0, and notes that this forces
  2 m_c^2 > 1.

One verifier change (stricter, no data change): `phi_ok` in `verify_k2.py` now also requires
0 < m_c <= 1 and p* < 0. Before, a record with m_c < 0 and p* > 0 could have satisfied the phi
inequality; in that case the cap min(m̄, m_c) of c(1) would have been negative. No data record is
of this kind: all 1,189 ms boxes of Theorem 2 (and all 21,232 of Theorem 3) pass the stricter
check. The negative tests now include this case (rejected 40/40). The full verification was rerun
with the final code (`outputs/verify_k2_ABCDEFG.txt`). The md5s in `outputs/k2_MD5SUMS.txt` are
unchanged.

### Original A.11 request (2026-10-22 08:30 UTC)

Claim for audit: **R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) for all q in [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2]
(and the mirror [1-q0, 1-q3]); the interval is sharp; equality holds iff alpha = ±(e_i+e_j)/sqrt2,
or q = q0 and alpha = ±e_i, or q = q3 and alpha = ±(e_i+e_j+e_k)/sqrt3.** With Theorem 1 (A.6):
R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 (1-q), sqrt2 q} on [q3, 1-q3].

- Proof: `MAIN_RESULT_K2.pdf` (13 pages; LaTeX source `MAIN_RESULT_K2.tex`; same text in
  `MAIN_RESULT_K2.md`). Self-contained except for BF3 Lemma 9.4 and Lemma 7 of `MAIN_RESULT`
  (both already audited), which it restates with proof.
- Data: all files are listed in `outputs/k2_manifest.json`: 784 one-coordinate cells
  (`outputs/cover_k2/one_A.json`, `one_B.json`) and 55,515 two-coordinate boxes in 114 files
  `outputs/cover2c/s*.json`, `b*.json`. md5s: `outputs/k2_MD5SUMS.txt`.
- Independent verifier: `cd scripts && python3 verify_k2.py` (parts A-G, about 5 minutes on 8
  cores; parts B and D take most of it). Output: `outputs/verify_k2_ABCDEFG.txt`. It shares no
  code with the generators except the Sturm, integer-square-root and tiling helpers of
  `verify_all.py` (audited in A.6).
- Negative tests: `python3 break_tests_k2.py` (seconds), output `outputs/break_tests_k2.txt`.

Suggested audit points (where an error would most likely hide):
1. Lemma 13 (objective bound), in particular the variant with p* (it needs c3 + 10 c5 >= 0,
   kappa3 >= k3^- > 0 and p* < 0), and the cumulant enclosures on [u1, u2].
2. Lemma 11 (sign information) and the case split in Lemma 24 (m-split): m <= m_c; some
   beta_i = -m; otherwise some beta_i = +m. The pieces must cover [m_c, min(1, mbar(B))].
3. Lemmas 15-17: the box enclosures (b^-, b^+, mbar(B)) and the envelope F_B on each half-line.
4. Lemma 21 (near-circle tests A/B) and Lemma 22 with the piece tests (A3)/(B3): the
   enclosures of b', r' and a3 = b m, and the use of E M'^4 <= 3 + max(0, kappa4).
5. Lemma 6 (three-bit lemma): the 256-function exact check (part G), the endpoint handling with
   the minimal polynomials of q3 and q0, and the equality cases used in Theorem 1(b).
6. Coverage (part B): tiling of [U-, U+] x [0, T8] x [9/20, 1] for each sign, the small boxes
   (r2 c(t1) <= 9/20), the one-coordinate cells on [U-, U+] x [0, 9/20], and U- < u0, U+ >= u3,
   T8 >= sqrt2 - 1.
7. That the theorem is only claimed for u in [u0, u3]: Lemma 21(A) needs q <= q0 and Lemma 24
   needs q in [q3, q0]. The negative tests confirm that parts E/F alone do not detect a box moved
   outside this range, as expected (Section 9, "Negative tests").

## A.6 (Theorem 1) — rated VALID by RQ-AUD at 06:52 UTC; text fixes applied

Both text fixes from the A.6 report are applied in `MAIN_RESULT.tex/.md/.pdf` (07:40 UTC):
- (f1) Remark 2: "q > 0.2744" is now "q > 0.27015" (0.8880738 = 2 tau at q = 0.2701496). The same
  fix is applied in CLAIMS.md N.1.
- (f2) The stray "0" before the end-of-proof symbol in the proof of Theorem 1(c) came from the
  pandoc conversion of `\qed`; the tex now ends the proof with `$\square$`, and the md is clean.
No mathematical content changed. The certificate data files are unchanged. (08:30 UTC: the md
generator now also prints equation numbers instead of raw `[eq:...]` anchors; no text change.)

### Original A.6 request

Claim for audit: **R(q) = 2 sqrt(q(1-q)) for all q in [1-1/sqrt2, 1/sqrt2]; the range is sharp;
extremisers are ±e_j, plus ±(e_i+e_j)/sqrt2 at the two endpoints.**

- Proof: `MAIN_RESULT.pdf` (LaTeX source `MAIN_RESULT.tex`; the same text is in `MAIN_RESULT.md`).
- Data: `outputs/cover/*.json` (379 six-moment cells, exact rational certificates) and
  `outputs/quartic_cover.json` (641 quartic boxes, each with a rational c4).
- Independent verifier: `scripts/verify_all.py`. It shares no code with the generators and runs
  in about one minute.
