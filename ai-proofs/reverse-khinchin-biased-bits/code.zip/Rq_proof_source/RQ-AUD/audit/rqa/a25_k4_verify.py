"""RQ-AUD independent verifier for RQ-A's MAIN-5 (Theorem 5 of MAIN_RESULT_K4, u in [1589/625, 29107/10000]):
    E|sum alpha_i chi_i| <= T4 = 4 (1-q)^3 tau  for every unit alpha and every q in [q5, q4].

RQ-A code is not used. The k-independent parts are my own helpers from A.6, A.11, A.14 and A.18 (exact tilings,
positivity by certified root isolation, the ten-moment objective bound, the dual-functional cone test with exact
patch minima, atom enclosures, vertex envelopes, cap and phi checks). New here:
 - target T4(u) = 4 u^7/(1+u^2)^4; d/du log T4 = (7-u^2)/(u(1+u^2)), so T4 is unimodal and its minimum over
   [u1, u2] is the smaller end value;
 - one-coordinate threshold Theta_1 = tau(u2) (2 (u1^2/(1+u1^2))^3 - a_hi);
 - four-parameter patches p4(t, r, m, m') = (rc, rd, b0 m, b1 m', b1 sqrt(1-m'^2)), b1 = b0 sqrt(1-m^2):
   h.p = r g(t) + b0 [h3 m + sqrt(1-m^2) (h4 m' + sqrt(1-m'^2) h5)]; the weights r, b0, sqrt(1-m^2) are >= 0, so the
   minimum over the box is taken innermost first, and a lower bound of an inner minimum is a valid input outside;
 - near-sphere tests with 3, 4 or 5 split coordinates in one function; (A5) also requires s = 1 and
   a_i^- > q^+ sum_l a_l^+ (the OR-region condition);
 - the TCN / TC4 / TC4S / SG3 structure, with every cap, phi and cover condition checked exactly.
Parts: M md5s, A elementary facts, B tilings, C one-coordinate cells, D vertex certificates, F m-split structure
and near-sphere pieces. The bit lemmas (Lemmas 6-8) are A.20 (`a20_k4_bits.py`).
"""
import hashlib
import json
import os
import sys
import time
from fractions import Fraction as Fr
from itertools import product
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
sys.path.insert(0, os.path.join(HERE, '..', 'common'))
import a11_main2_verify as V  # noqa: E402
import a18_k3b_verify as K3B  # noqa: E402
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo, tiles  # noqa: E402
from moments10 import KAP  # noqa: E402

DATA = os.environ.get('K4_DATA', os.path.join(HERE, 'k4_data'))
U_LO, U_HI, T8, A_S = Fr(1589, 625), Fr(29107, 10000), Fr(20711, 50000), Fr(33, 100)
K27 = Fr(27, 128)
NJ = 10
MAX_CONE_BOXES = int(os.environ.get('K4_CONE_BOXES', '256'))


def T4(u):
    return 4 * u**7 / (1 + u * u)**4


def T4_lo(u1, u2):
    return min(T4(u1), T4(u2))


def theta1_4(u1, u2, a_hi):
    om1 = u1 * u1 / (1 + u1 * u1)
    return u2 / (1 + u2 * u2) * (2 * om1**3 - a_hi)


# ---------------------------------------------------------------- C: one-coordinate cells
def cell_once4(u1, u2, a1, a2, c):
    if len(c) - 1 > NJ:
        return False, "degree"
    bh = sqrt_hi(1 - a1 * a1)
    s1 = u2 * u2 / (1 + u2 * u2)
    s2 = 1 / (1 + u1 * u1)
    P = list(c)
    ok, why = positive_on(P)
    if not ok:
        return False, "P > 0: " + why
    ok, why = positive_on([P[0] + s1 * a1 / u2, P[1] - s1 * bh] + P[2:], lo=(a1 / u2) / bh)
    if not ok:
        return False, "P > l1: " + why
    ok, why = positive_on([P[0] + s2 * a1 * u1, P[1] + s2 * bh] + P[2:], hi=-(a1 * u1) / bh)
    if not ok:
        return False, "P > l2: " + why
    b2 = sqrt_lo(1 - a2 * a2)
    mh = min(Fr(1), a2 / b2)
    T = theta1_4(u1, u2, a2)
    if T <= 0:
        return False, "Theta1 <= 0"
    return K3B.objective_ok(c, u1, u2, mh, T)


def cell_job(args):
    return cell_once4(*args)


# ---------------------------------------------------------------- D: vertex certificates
def patch_dot_lo4(h, box):
    """lower bound of h . p_k over a parameter box ((t), (r)[, (m)[, (m')]])"""
    (t1, t2), (r1, r2) = box[0], box[1]
    g = K3B.sin_min_t(h[0], h[1], t1, t2)
    if len(box) == 2:
        k = h[2]
    elif len(box) == 3:
        k = K3B.sin_min_m(h[2], h[3], box[2][0], box[2][1])
    else:
        w1 = K3B.sin_min_m(h[3], h[4], box[3][0], box[3][1])
        k = K3B.sin_min_m(h[2], w1, box[2][0], box[2][1])

    def f_lo(r):
        s2 = 1 - r * r
        s = (sqrt_lo(s2) if k >= 0 else sqrt_hi(s2)) if s2 > 0 else Fr(0)
        return g * r + k * s
    lo = min(f_lo(r1), f_lo(r2))
    if k < 0 and g < 0:
        rs2 = g * g / (g * g + k * k)
        if r1 * r1 <= rs2 <= r2 * r2:
            lo = min(lo, -sqrt_hi(g * g + k * k))
    return lo


def cone_contains4(X, H, n0, max_boxes=MAX_CONE_BOXES):
    assert all(0 <= a <= b <= 1 for a, b in X)
    stack, used = [tuple(X)], 0
    while stack:
        box = stack.pop()
        used += 1
        if used > max_boxes:
            return False, used
        if patch_dot_lo4(n0, box) > 0 and all(patch_dot_lo4(h, box) >= 0 for h in H):
            continue
        w = [b - a for a, b in box]
        i = max(range(len(box)), key=lambda j: w[j])
        if w[i] == 0:
            return False, used
        mid = (box[i][0] + box[i][1]) / 2
        for half in ((box[i][0], mid), (mid, box[i][1])):
            nb = list(box)
            nb[i] = half
            stack.append(tuple(nb))
    return True, used


def vertex_ok4(c, v, sig, u1, u2, cap, T, p3max):
    k = len(sig)
    if len(v) != k + 1 or len(c) - 1 > NJ:
        return False, "shape"
    coefs = [sg * x for sg, x in zip(sig, v[:k])]
    last = v[k]
    X, Pj = K3B.vatoms(u1, u2, coefs)
    if last == 0:
        K = sum(max(abs(x[0]), abs(x[1])) for x in X)
        ok, why = positive_on([c[0] - K] + list(c[1:]))
        if not ok:
            return False, "dom (b = 0): " + why
    else:
        al = abs(last)
        B = [(p[0] * al, p[1] * al) for p in Pj]
        cc = list(c) if last > 0 else [cn if n % 2 == 0 else -cn for n, cn in enumerate(c)]
        for lo, hi, icpt, slope in K3B.env_pieces(X, B):
            ok, why = positive_on([cc[0] - icpt, cc[1] - slope] + cc[2:], lo=lo, hi=hi)
            if not ok:
                return False, "dom: " + why
    return K3B.objective_ok(c, u1, u2, cap, T, p3max)


def vjob_check4(job):
    name, rec, X, sig, box, cap, p3max = job
    u1, u2 = box[0], box[1]
    n0 = [Fr(x) for x in rec['n0']]
    Vs = [[Fr(x) for x in v] for v in rec['V']]
    Cs = [[Fr(x) for x in cc] for cc in rec['C']]
    if len(sig) != len(X) or len(n0) != len(X) + 1 or any(len(v) != len(X) + 1 for v in Vs) or len(Cs) != len(Vs):
        return False, name + " shape", 0
    H, why = K3B.cone_functionals(n0, Vs)
    if H is None:
        return False, name + " " + why, 0
    ok, used = cone_contains4(X, H, n0)
    if not ok:
        return False, f"{name} cone ({used} sub-boxes)", used
    T = T4_lo(u1, u2)
    for v, c in zip(Vs, Cs):
        ok, why = vertex_ok4(c, v, sig, u1, u2, cap, T, p3max)
        if not ok:
            return False, f"{name} {why}", used
    return True, name, used


def vertex_jobs4(bx):
    """all vertex-certificate sets of a box, with the parameter box, sign vector, cap and p* derived here"""
    box = tuple(Fr(x) for x in bx['box'])
    s = bx['s']
    u1, u2, t1, t2, r1, r2 = box
    blo, _ = V.b_range(r1, r2)
    mb = V.mbar_of(t2, r2, blo)
    X2 = ((t1, t2), (r1, r2))
    one = Fr(1)
    jobs, bad = [], []
    if bx['kind'] == 'lpv':
        return [('lpv', bx, X2, (1, s), box, mb, None)], bad
    if bx['kind'] != 'ms5':
        return [], ['kind ' + str(bx['kind'])]
    mc = Fr(bx['mc'])
    jobs.append(('c1', bx['c1'], X2, (1, s), box, min(mc, mb), None))
    for side, s3 in (('plus', 1), ('minus', -1)):
        for pc in bx[side]:
            m1, m2 = Fr(pc['m'][0]), Fr(pc['m'][1])
            X3 = X2 + ((m1, m2),)
            tp = pc['type']
            if tp == 'A3':
                if side != 'plus':
                    bad.append('A3 on the minus side')
            elif tp == 'SG':
                if side != 'minus' or not K3B.phi_ok(Fr(pc['pst']), m1):
                    bad.append('SG phi')
                jobs.append(('SG', pc, X2, (1, s), box, min(m2, mb), Fr(pc['pst'])))
            elif tp == 'TC':
                cap = Fr(pc['cap'])
                if not K3B.cap_after(m2, cap):
                    bad.append('TC cap')
                jobs.append(('TC', pc, X3, (1, s, s3), box, min(cap, one), None))
            elif tp == 'TCS':
                cap, mc2, pst = Fr(pc['cap']), Fr(pc['mc']), Fr(pc['pst'])
                if side != 'plus' or not K3B.cap_after(m2, cap) or not K3B.phi_ok(pst, mc2):
                    bad.append('TCS cap/phi')
                jobs.append(('TCS1', pc['c1'], X3, (1, s, 1), box, min(mc2, one), None))
                jobs.append(('TCS2', pc['c2'], X3, (1, s, 1), box, min(cap, one), pst))
            elif tp == 'TCN':
                cap, mc2 = Fr(pc['cap']), Fr(pc['mc'])
                if side != 'plus' or not K3B.cap_after(m2, cap) or not (0 < mc2 < cap <= 1):
                    bad.append('TCN cap/cut')
                jobs.append(('TCN1', pc['c1'], X3, (1, s, 1), box, mc2, None))
                for ip in pc['plus']:
                    n1, n2 = Fr(ip['m'][0]), Fr(ip['m'][1])
                    X4 = X3 + ((n1, n2),)
                    it = ip['type']
                    if it == 'A4':
                        continue
                    if it == 'TC4':
                        k4 = Fr(ip['cap'])
                        if ip['s4'] != 1 or not K3B.cap_after(n2, k4):
                            bad.append('TC4+ sign/cap')
                        jobs.append(('TC4+', ip, X4, (1, s, 1, 1), box, min(k4, one), None))
                    elif it == 'TC4S':
                        k4, mc3, pst = Fr(ip['cap']), Fr(ip['mc']), Fr(ip['pst'])
                        if not K3B.cap_after(n2, k4) or not K3B.phi_ok(pst, mc3) or not (0 < mc3 < k4 <= 1):
                            bad.append('TC4S cap/phi/cut')
                        jobs.append(('TC4S1', ip['c1'], X4, (1, s, 1, 1), box, mc3, None))
                        jobs.append(('TC4S2', ip['c2'], X4, (1, s, 1, 1), box, min(k4, one), pst))
                    else:
                        bad.append('TCN plus type ' + it)
                for ip in pc['minus']:
                    n1, n2 = Fr(ip['m'][0]), Fr(ip['m'][1])
                    X4 = X3 + ((n1, n2),)
                    it = ip['type']
                    if it == 'SG3':
                        k3, pst = Fr(ip['cap']), Fr(ip['pst'])
                        if not K3B.phi_ok(pst, n1) or not (0 < k3 <= 1 and (k3 >= n2 or K3B.cap_after(m2, k3))):
                            bad.append('SG3 phi/cap')
                        jobs.append(('SG3', ip, X3, (1, s, 1), box, k3, pst))
                    elif it == 'TC4':
                        k4 = Fr(ip['cap'])
                        if ip['s4'] != -1 or not K3B.cap_after(n2, k4):
                            bad.append('TC4- sign/cap')
                        jobs.append(('TC4-', ip, X4, (1, s, 1, -1), box, min(k4, one), None))
                    else:
                        bad.append('TCN minus type ' + it)
            else:
                bad.append(f'{side} type {tp}')
    return jobs, bad


# ---------------------------------------------------------------- F: near-sphere tests, m-split structure
def near_n(box, s, levels):
    """split coordinates a3 = b m, a4 = b' m', a5 = b'' m'' with positive signs (m in levels[0], m' in levels[1],
    m'' in levels[2]); L = Y + b^(L) N with N a normalised remainder independent of the 2 + L bits of Y.
    Returns 'A<n>' / 'B<n>' (n = 2 + L) if the test passes, else None."""
    u1, u2, t1, t2, r1, r2 = box
    n = 2 + len(levels)
    T = T4_lo(u1, u2)
    blo, bhi = V.b_range(r1, r2)
    if blo <= 0:
        return None
    a2 = (r1 * V.dfun(t1), r2 * V.dfun(t2))
    coefs = [(r1 * V.cfun(t2), r2 * V.cfun(t1)), a2 if s == 1 else (-a2[1], -a2[0])]
    b2 = (blo * blo, bhi * bhi)
    bb = (blo, bhi)
    for x1, x2 in levels:
        if not (0 < x1 < x2 <= 1):
            return None
        coefs.append((bb[0] * x1, bb[1] * x2))
        b2 = (b2[0] * (1 - x2 * x2), b2[1] * (1 - x1 * x1))
        bb = (sqrt_lo(b2[0]) if b2[0] > 0 else Fr(0), sqrt_hi(b2[1]) if b2[1] > 0 else Fr(0))
    rq = min(Fr(1), sqrt_hi(1 - b2[0]))
    E4 = 3 + max(Fr(0), u2 * u2 + 1 / (u2 * u2) - 4)
    U, Vn = (u1, u2), (-1 / u1, -1 / u2)
    q = (1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    qb = (1 - q[1], 1 - q[0])
    tau = (u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))
    atoms = []
    for e in product((1, 0), repeat=n):
        w = [q if ei else qb for ei in e]
        p = Fr(1)
        for x in w:
            p *= x[1]
        y = (Fr(0), Fr(0))
        py = (Fr(0), Fr(0))
        for i in range(n):
            y = K3B.iadd(y, K3B.imulI(coefs[i], U if e[i] else Vn))
            oth = (Fr(1), Fr(1))
            for l in range(n):
                if l != i:
                    oth = (oth[0] * w[l][0], oth[1] * w[l][1])
            t = (oth[0] * tau[0], oth[1] * tau[1]) if e[i] else (-oth[1] * tau[1], -oth[0] * tau[0])
            py = K3B.iadd(py, K3B.imulI(coefs[i], t))
        atoms.append((p, K3B.iabs_lo(y), max(abs(py[0]), abs(py[1]))))
    a_ok = True
    if n == 5:
        tot_hi = sum(c[1] for c in coefs)
        a_ok = s == 1 and all(c[0] > q[1] * tot_hi for c in coefs)
    if a_ok and all(yl > 0 for _, yl, _ in atoms):
        S = sum(p / yl**3 for p, yl, _ in atoms)
        if K27 * E4 * b2[1] * (1 + rq) * S < T:
            return f"A{n}"
    tot = Fr(0)
    for p, yl, apy in atoms:
        e = bb[1] if yl == 0 else min(bb[1], K27 * b2[1] * b2[1] * E4 / yl**3)
        tot += apy + p * e
    return f"B{n}" if tot < T else None


def ms5_structure4(args):
    bx, = args
    box = tuple(Fr(x) for x in bx['box'])
    s = bx['s']
    u1, u2, t1, t2, r1, r2 = box
    if not (r2 < 1 and u1 >= 2):
        return False, "r2 < 1, u1 >= 2", {}
    blo, _ = V.b_range(r1, r2)
    if blo <= 0:
        return False, "b- = 0", {}
    mb = V.mbar_of(t2, r2, blo)
    top = min(Fr(1), mb)
    mc = Fr(bx['mc'])
    if not (0 < mc < top):
        return False, "m_c", {}
    kinds = {}

    def note(k):
        kinds[k] = kinds.get(k, 0) + 1

    for side in ('plus', 'minus'):
        if not K3B.covers([(Fr(p['m'][0]), Fr(p['m'][1])) for p in bx[side]], mc, top):
            return False, "cover " + side, {}
    for pc in bx['minus']:
        if pc['type'] not in ('SG', 'TC'):
            return False, "minus type " + pc['type'], {}
        note('minus ' + pc['type'])
    for pc in bx['plus']:
        m1, m2 = Fr(pc['m'][0]), Fr(pc['m'][1])
        tp = pc['type']
        note('plus ' + tp)
        if tp == 'A3':
            k = near_n(box, s, [(m1, m2)])
            if k is None:
                return False, f"near-sphere 3 [{float(m1)},{float(m2)}]", {}
            note(k)
        elif tp == 'TCS':
            cap, mc2 = Fr(pc['cap']), Fr(pc['mc'])
            sub = [(Fr(a), Fr(b), typ) for a, b, typ in pc['sub']]
            if not K3B.covers([(a, b) for a, b, _ in sub], mc2, min(cap, Fr(1))):
                return False, "TCS sub cover", {}
            for a, b, typ in sub:
                k = near_n(box, s, [(m1, m2), (a, b)])
                if k is None or typ not in ('A4', 'B4'):
                    return False, f"TCS near-sphere 4 m[{float(m1)},{float(m2)}] n[{float(a)},{float(b)}] {typ}", {}
                note('TCS/' + k)
        elif tp == 'TCN':
            cap, mc2 = Fr(pc['cap']), Fr(pc['mc'])
            for side in ('plus', 'minus'):
                if not K3B.covers([(Fr(p['m'][0]), Fr(p['m'][1])) for p in pc[side]], mc2, cap):
                    return False, "TCN inner cover " + side, {}
            for ip in pc['minus']:
                if ip['type'] not in ('SG3', 'TC4'):
                    return False, "TCN minus type " + ip['type'], {}
                note('TCN minus ' + ip['type'])
            for ip in pc['plus']:
                n1, n2 = Fr(ip['m'][0]), Fr(ip['m'][1])
                it = ip['type']
                note('TCN plus ' + it)
                if it == 'A4':
                    k = near_n(box, s, [(m1, m2), (n1, n2)])
                    if k is None:
                        return False, f"TCN near-sphere 4 m[{float(m1)},{float(m2)}] n[{float(n1)},{float(n2)}]", {}
                    note('TCN/' + k)
                elif it == 'TC4S':
                    k4, mc3 = Fr(ip['cap']), Fr(ip['mc'])
                    sub = [(Fr(a), Fr(b), typ) for a, b, typ in ip['sub']]
                    if not K3B.covers([(a, b) for a, b, _ in sub], mc3, k4):
                        return False, "TC4S sub cover", {}
                    for a, b, typ in sub:
                        k = near_n(box, s, [(m1, m2), (n1, n2), (a, b)])
                        if k is None or typ not in ('A5', 'B5'):
                            return False, (f"TC4S near-sphere 5 m[{float(m1)},{float(m2)}] n[{float(n1)},{float(n2)}]"
                                           f" o[{float(a)},{float(b)}] {typ}"), {}
                        note('TC4S/' + k)
                elif it != 'TC4':
                    return False, "TCN plus type " + it, {}
        elif tp != 'TC':
            return False, "plus type " + tp, {}
    return True, "", kinds


# ---------------------------------------------------------------- A: elementary facts
def part_A():
    import sympy as sp
    u = sp.Symbol('u', positive=True)
    ok = True
    s3 = sp.sqrt(3)
    s5 = sp.sqrt(5)
    u4 = sp.sqrt(3 + 2 * s3)
    u5 = sp.sqrt(4 + 2 * s5)
    q = 1 / (1 + u**2)
    okq = (sp.simplify(q.subs(u, u4) - (1 - s3 / 2)) == 0 and sp.simplify(q.subs(u, u5) - (1 - 2 / s5)) == 0)
    okU = (U_LO > 2 and U_LO**2 >= 3 and (U_LO**2 - 3)**2 <= 12 and U_HI**2 >= 4 and (U_HI**2 - 4)**2 >= 20)
    okT8 = (T8 + 1)**2 >= 2 and T8 < 1
    wm = U_LO**2 / (1 + U_LO**2)
    ok3 = wm**4 >= Fr(1, 2) and 2 * wm**3 >= 1
    print(f"A  u4 = sqrt(3+2sqrt3), u5 = sqrt(4+2sqrt5) give q4 = 1-sqrt3/2, q5 = 1-2/sqrt5: {okq};"
          f" 2 < U_LO <= u4 and U_HI >= u5: {okU} (u4 - U_LO = {float(u4 - sp.Rational(1589, 625)):.3e},"
          f" U_HI - u5 = {float(sp.Rational(29107, 10000) - u5):.3e}); tan(pi/8) <= T8 < 1: {okT8};"
          f" (3) w-^4 >= 1/2, 2 w-^3 >= 1: {ok3}")
    ok &= okq and okU and okT8 and ok3
    T4s = 4 * u**7 / (1 + u**2)**4
    dT = sp.factor(sp.diff(T4s, u))
    okT = sp.simplify(dT - (-4 * u**6 * (u**2 - 7) / (u**2 + 1)**5)) == 0
    okT4 = sp.simplify(T4s - 4 * (1 - q)**3 * u * q) == 0
    print(f"A  T4(u) = 4(1-q)^3 tau = 4u^7/(1+u^2)^4: {okT4}; T4' = -4u^6(u^2-7)/(u^2+1)^5 (unimodal): {okT}")
    ok &= okT and okT4
    mono = True
    for j in range(3, NJ + 1):
        expr = sum(sp.Rational(c.numerator, c.denominator) * u**e for e, c in KAP[j].items())
        num = sp.numer(sp.together(sp.diff(expr, u)))
        P = sp.Poly(num, u)
        n = P.count_roots(sp.Rational(U_LO.numerator, U_LO.denominator), sp.Rational(U_HI.numerator, U_HI.denominator))
        mono &= n == 0
    print(f"A  kappa_3..kappa_{NJ} monotone on [U_LO, U_HI] (no root of kappa_j' there): {mono}")
    ok &= mono
    import moments10
    ok &= moments10.self_test()
    return ok


def load():
    man = json.load(open(os.path.join(DATA, 'k4_manifest.json')))
    assert Fr(man['U_LO']) == U_LO and Fr(man['U_HI']) == U_HI and Fr(man['T8']) == T8 and Fr(man['A_S']) == A_S
    cells = []
    for fn in man['one_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['target'] == 'k4' and d['K'] == 4 and not d['failed'] and d['D'] <= NJ
        for cl in d['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]))
    boxes = []
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['s'] in (1, -1) and not d['failed'] and d['K'] == 4 and Fr(d['A_S']) == A_S
        for bx in d['boxes']:
            assert bx['s'] == d['s']
            boxes.append(bx)
    return man, cells, boxes


def main():
    t0 = time.time()
    parts = sys.argv[1] if len(sys.argv) > 1 else 'MABCDF'
    allok = True
    man, cells, boxes = load()
    files = man['one_files'] + man['two_files']
    kinds = {}
    for bx in boxes:
        kinds[(bx['s'], bx['kind'])] = kinds.get((bx['s'], bx['kind']), 0) + 1
    print(f"k4 verifier (RQ-AUD), data {DATA}: {len(cells)} cells, {len(boxes)} boxes, kinds {dict(sorted(kinds.items()))}",
          flush=True)
    if 'M' in parts:
        pub = {}
        for line in open(os.path.join(DATA, 'k4_MD5SUMS.txt')):
            h, fn = line.split()
            pub[fn.replace('outputs/', '')] = h
        mism = [fn for fn in files + ['k4_manifest.json']
                if hashlib.md5(open(os.path.join(DATA, fn), 'rb').read()).hexdigest() != pub.get(fn)]
        print(f"M  md5 of the {len(files) + 1} manifest files vs k4_MD5SUMS.txt: {len(mism)} mismatches", flush=True)
        allok &= not mism
    if 'A' in parts:
        allok &= part_A()
    if 'B' in parts:
        reg1 = (U_LO, U_HI, Fr(0), A_S)
        tok, gap = tiles(reg1, [cl[:4] for cl in cells])
        inside = all(reg1[0] <= cl[0] < cl[1] <= reg1[1] and reg1[2] <= cl[2] < cl[3] <= reg1[3] for cl in cells)
        area = sum((cl[1] - cl[0]) * (cl[3] - cl[2]) for cl in cells) == (reg1[1] - reg1[0]) * (reg1[3] - reg1[2])
        print(f"B  {len(cells)} one-coordinate cells tile [U_LO,U_HI] x [0,A_S]: {'OK' if tok else 'GAP ' + str(gap)};"
              f" inside {inside}; area {area}", flush=True)
        allok &= tok and inside and area
        reg3 = (U_LO, U_HI, Fr(0), T8, A_S, Fr(1))
        for s in (1, -1):
            bs = [tuple(Fr(x) for x in bx['box']) for bx in boxes if bx['s'] == s]
            ins, voleq, nov = V.tiling3(reg3, bs)
            print(f"B  s={s:+d}: {len(bs)} boxes inside {ins}; volume sum == region volume {voleq}; overlapping pairs {nov}"
                  f" => {'TILING OK' if ins and voleq and nov == 0 else 'TILING FAIL'}", flush=True)
            allok &= ins and voleq and nov == 0
        unknown = {bx['kind'] for bx in boxes} - {'lpv', 'ms5'}
        print(f"B  box kinds outside {{lpv, ms5}}: {sorted(unknown)}")
        allok &= not unknown
    if 'C' in parts:
        with Pool(8) as pool:
            res = pool.map(cell_job, [(cl[0], cl[1], cl[2], cl[3], cl[4]) for cl in cells], chunksize=2)
        nf = 0
        for cl, r in zip(cells, res):
            if not r[0]:
                nf += 1
                print(f"   FAIL cell u[{float(cl[0]):.6f},{float(cl[1]):.6f}] a[{float(cl[2]):.4f},{float(cl[3]):.4f}]: {r[1]}")
        degs = {}
        for cl in cells:
            degs[len(cl[4]) - 1] = degs.get(len(cl[4]) - 1, 0) + 1
        print(f"C  one-coordinate cells (own ten-moment bound, Theta_1 for T4): failures {nf}/{len(cells)}; degrees {degs};"
              f" {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    if 'D' in parts:
        jobs, bad = [], []
        for bx in boxes:
            j, b = vertex_jobs4(bx)
            jobs += j
            bad += b
        nv = sum(len(j[1]['V']) for j in jobs)
        npar = {}
        for j in jobs:
            npar[len(j[2])] = npar.get(len(j[2]), 0) + 1
        print(f"D  {len(jobs)} vertex-certificate sets ({nv} vertices; by number of patch parameters {npar});"
              f" record-side cap/phi/sign problems: {len(bad)} {bad[:3]}", flush=True)
        allok &= not bad
        with Pool(8) as pool:
            res = pool.map(vjob_check4, jobs, chunksize=4)
        nf = 0
        byname = {}
        for jb, r in zip(jobs, res):
            byname[jb[0]] = byname.get(jb[0], 0) + 1
            if not r[0]:
                nf += 1
                bx = jb[4]
                if nf <= 30:
                    print(f"   FAIL {r[1]} sig={jb[3]} u[{float(bx[0]):.6f},{float(bx[1]):.6f}]"
                          f" t[{float(bx[2]):.5f},{float(bx[3]):.5f}] r[{float(bx[4]):.5f},{float(bx[5]):.5f}]"
                          f" X={[(float(a), float(b)) for a, b in jb[2]]}")
        used = [r[2] for r in res]
        print(f"D  vertex certificates: failures {nf}/{len(jobs)}; sets by role {byname}; cone sub-boxes max {max(used)},"
              f" total {sum(used)}, sets needing a split {sum(1 for x in used if x > 1)}; {time.time() - t0:.0f}s",
              flush=True)
        allok &= nf == 0
    if 'F' in parts:
        mss = [bx for bx in boxes if bx['kind'] == 'ms5']
        with Pool(8) as pool:
            res = pool.map(ms5_structure4, [(bx,) for bx in mss], chunksize=2)
        nf = 0
        kk = {}
        for bx, r in zip(mss, res):
            if not r[0]:
                nf += 1
                b = [float(Fr(x)) for x in bx['box']]
                if nf <= 30:
                    print(f"   FAIL ms5 s={bx['s']:+d} box {b}: {r[1]}")
            for k, v in r[2].items():
                kk[k] = kk.get(k, 0) + v
        mcs = sorted({bx['mc'] for bx in mss}, key=Fr)
        print(f"F  m-split boxes: failures {nf}/{len(mss)}; pieces and near-sphere tests {dict(sorted(kk.items()))};"
              f" m_c values {mcs}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0
    print(f"RESULT: {'ALL CHECKS PASSED' if allok else 'FAILURES'} (parts {parts}, {time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
