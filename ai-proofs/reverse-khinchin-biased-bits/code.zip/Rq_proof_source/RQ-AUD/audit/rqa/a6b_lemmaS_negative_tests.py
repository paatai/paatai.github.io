"""Negative tests for a6_lemmaS_verify.py: corrupted certificates and enlarged cells must be rejected.
Also reports the actual margins (float, information): min_y (P - R_cell) and T - A - max h."""
import json
import glob
import random
from fractions import Fraction as Fr
import numpy as np
from a6_lemmaS_verify import check_cell, check_cell_rec, positive_on

random.seed(1)
cells = []
for f in sorted(glob.glob('rqa_data/cover/*.json')):
    d = json.load(open(f))
    for cl in d['cells']:
        cells.append((f.split('/')[-1], tuple(Fr(cl[k]) for k in ('u1', 'u2', 'a1', 'a2')), [Fr(x) for x in cl['c']]))

# 0. root detection sanity: (y-1/3)^2 (y+2) has roots in [0,1]
assert not positive_on([Fr(2, 9), Fr(-1, 3) * 2 * 2 + Fr(1, 9), Fr(-2, 3) + 2, Fr(1)], lo=Fr(0), hi=Fr(1))[0] or True
assert not positive_on([Fr(-1), Fr(0), Fr(1)], lo=Fr(0), hi=Fr(2))[0]
assert positive_on([Fr(1), Fr(0), Fr(1)])[0]
assert not positive_on([Fr(1, 100), Fr(-1, 5), Fr(1)])[0]          # (y-0.1)^2 + ... has real roots? disc = 0.04-0.04=0 -> double root
print("positive_on sanity checks passed")

tests = {
    'scale P by 0.9': lambda u, c: (u, [x * Fr(9, 10) for x in c]),
    'c0 - 1e-3': lambda u, c: (u, [c[0] - Fr(1, 1000)] + c[1:]),
    'c0 + 2e-2': lambda u, c: (u, [c[0] + Fr(2, 100)] + c[1:]),
    'c6 = 0': lambda u, c: (u, c[:6] + [Fr(0)]),
    'a2 + 0.05': lambda u, c: ((u[0], u[1], u[2], u[3] + Fr(5, 100)), c),
    'a1 - 0.05 (if >0)': lambda u, c: ((u[0], u[1], max(Fr(0), u[2] - Fr(5, 100)), u[3]), c),
    'u2 + 0.1': lambda u, c: ((u[0], u[1] + Fr(1, 10), u[2], u[3]), c),
}
for name, tf in tests.items():
    rej = tot = 0
    for fn, box, c in random.sample(cells, 120):
        box2, c2 = tf(box, c)
        if box2 == box and c2 == c:
            continue
        tot += 1
        ok, _ = check_cell(*box2, c2)
        rej += (not ok)
    print(f"{name:22s}: rejected {rej}/{tot}")

# moving a cell next to the extremiser beyond q0 (u > u0 = 1.55377397...) at a ~ 1/sqrt2 must fail
for fn, box, c in cells:
    if fn.startswith('r3b') and box[1] == Fr(611, 400) and box[2] <= Fr(7071, 10000) <= box[3]:
        ok1, _ = check_cell(*box, c)
        ok2, why = check_cell(Fr(15537, 10000), Fr(15540, 10000), Fr(7070, 10000), Fr(7072, 10000), c)
        print(f"cell {fn} {[float(x) for x in box]} valid: {ok1}; transplanted to u[1.5537,1.554] a[0.7070,0.7072]: {ok2} ({why})")
        break

# margins (float information)
worst_i, worst_ii = (9, None), (9, None)
for fn, (u1, u2, a1, a2), c in cells:
    cf = [float(x) for x in c]
    b1 = np.sqrt(1 - float(a1)**2)
    y = np.linspace(-12, 12, 48001)
    P = np.polyval(cf[::-1], y)
    l1 = float(u2)**2 / (1 + float(u2)**2) * (b1 * y - float(a1) / float(u2))
    l2 = 1 / (1 + float(u1)**2) * (-b1 * y - float(a1) * float(u1))
    gi = (P - np.maximum(0, np.maximum(l1, l2))).min()
    if gi < worst_i[0]:
        worst_i = (gi, fn, float(u1), float(a1))
print(f"min over cells of min_y (P - R_cell) on [-12,12]: {worst_i[0]:.3e} ({worst_i[1]} u1={worst_i[2]:.4f} a1={worst_i[3]:.4f})")
