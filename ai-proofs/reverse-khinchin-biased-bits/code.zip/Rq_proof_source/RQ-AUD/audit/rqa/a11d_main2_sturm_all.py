"""Second exact method on ALL MAIN-2 certificates: sympy Sturm counts replace the Arb root isolation in
a11_main2_verify.py for every LP box (dominance pieces + moment bound) and every one-coordinate cell."""
import os
import sys
import time
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
import a11_main2_verify as V  # noqa: E402
import a11b_main2_negative as N  # noqa: E402
import a9_c11_verify as C9  # noqa: E402


def lp_job(args):
    V.positive_on = N.sturm_positive_on
    return V.lp_once(*args)[0]


def cell_job(args):
    C9.positive_on = N.sturm_positive_on
    return C9.check_cell_T(*args)[0]


if __name__ == '__main__':
    t0 = time.time()
    boxes, cells = N.load()
    lps = [(b[0], b[1], b[3], V.R2_MINE) for b in boxes if b[2] == 'lp']
    with Pool(8) as pool:
        r1 = pool.map(lp_job, lps, chunksize=32)
        r2 = pool.map(cell_job, [(cl[0], cl[1], cl[2], cl[3], cl[4], V.R2_MINE) for cl in cells], chunksize=4)
    print(f"Sturm (sympy count_roots) re-check, depth 0: LP boxes {sum(1 for r in r1 if not r)} failures / {len(r1)};"
          f" one-coordinate cells {sum(1 for r in r2 if not r)} failures / {len(r2)} ({time.time() - t0:.0f}s)")
