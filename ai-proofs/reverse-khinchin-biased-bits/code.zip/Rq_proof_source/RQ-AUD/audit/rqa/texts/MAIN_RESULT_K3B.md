# MAIN RESULT 4 (RQ-A): $R(q)=2\sqrt3\,(1-q)^2\sqrt{q(1-q)}$ for every $q\in[1-\frac{\sqrt3}2,\,\frac{25}{169}]$, hence on the whole $k=3$ regime $[1-\frac{\sqrt3}2,\,1-\sqrt{2/3}]$

**Status:** PROVED (computer-assisted; every computer step is exact rational arithmetic or certified
interval arithmetic, and was re-done by an independent program). **Awaiting RQ-AUD audit.**
Do not report outside the team before the audit and an independent referee rate it VALID.

PDF version (same content, LaTeX): `MAIN_RESULT_K3B.pdf` (source `MAIN_RESULT_K3B.tex`).
This file was generated from the LaTeX source with pandoc, so the two contain the same proof.

**One-command check:** `cd scripts && python3 verify_k3b.py` (about two minutes on 8 cores). It prints
`ALL REQUESTED PARTS PASS (A B C D E F G)`. The output is in `outputs/verify_k3b_ABCDEFG.txt`.
Negative tests: `python3 break_tests_k3b.py` (output `outputs/break_tests_k3b.txt`).

With Theorem 3 of `MAIN_RESULT_K3` (audited VALID as A.14) this determines $R$ exactly on the whole
regime where three equal coefficients are optimal: $R(q)=2\sqrt3(1-q)^2\sqrt{q(1-q)}$ for
$q\in[q_4,q_3]=[1-\frac{\sqrt3}2,1-\sqrt{2/3}]$, and this is exactly the set of $q\le\frac12$ where the
formula holds. Extremisers: $(e_i+e_j+e_k)/\sqrt3$; also $(e_i+e_j+e_k+e_l)/2$ at $q_4$ (and
$(e_i+e_j)/\sqrt2$ at $q_3$). With Theorems 1 and 2 (audited VALID as A.6 and A.11):
$R(q)=2\sqrt{q(1-q)}\max_{k\ge1}\sqrt k\,\hat q^{k-1}$, $\hat q=\max(q,1-q)$, for all
$q\in[1-\frac{\sqrt3}2,\frac{\sqrt3}2]$.

## Map of the proof

| piece | region | lemma | verification |
|---|---|---|---|
| one-coordinate cells (degree 10) | $a_1\le 7/20$ (288 cells) | Lemmas 9–15 | `outputs/k3b/one_*.json`, exact (Sturm) |
| vertex certificates (`lpv`) | 1,106 boxes | Lemmas 9–14, 16–25 | `outputs/k3b/*.json`, exact (Sturm, Gaussian elimination, interval bisection) |
| near-circle boxes (`ncA`) | 13 boxes near $(e_1+e_2)/\sqrt2$ | Lemmas 26–27 | interval arithmetic |
| $m$-split boxes (`ms5`) | 302 boxes near $(e_1+e_2+e_3)/\sqrt3$ and $(e_1+\dots+e_4)/2$ | Lemmas 12, 28–35 | exact + interval arithmetic |
| three-bit and four-bit lemmas | all $c\in\mathbb R^3$, $c\in\mathbb R^4$ | Lemmas 6–7 | exact Sturm, 256 and 65,536 Boolean functions |

---

# Statement

Fix $q\in(0,1)$ and put $$u=\sqrt{\tfrac{1-q}{q}},\qquad v=\frac1u,\qquad \tau=\sqrt{q(1-q)} .$$ Let $\chi,\chi_1,\chi_2,\dots$ be i.i.d. with $\Pr[\chi=u]=q$ and $\Pr[\chi=-v]=1-q$, so that $\mathbb{E}\chi=0$, $\mathbb{E}\chi^2=1$ and $\mathbb{E}|\chi|=2\tau$. Let $$R(q)=\sup_{n\ge1}\ \sup_{\alpha\in\mathbb{R}^n\setminus\{0\}}\frac{\mathbb{E}|\sum_{i=1}^n\alpha_i\chi_i|}{|\alpha|_2}.$$ Put $$q_3=1-\sqrt{2/3}\approx0.183503,\qquad q_4=1-\tfrac{\sqrt3}{2}\approx0.133975,\qquad
q_L=\tfrac{25}{169}\approx0.147929,$$ $$T(q)=2\sqrt3\,(1-q)^2\,\tau,\qquad T_2(q)=2\sqrt2\,(1-q)\,\tau,\qquad T_4(q)=4(1-q)^3\tau .$$

**Theorem 4**.

1.  *For every $q\in[q_4,q_L]$, every $n\ge1$ and every $\alpha\in\mathbb{R}^n$ with $|\alpha|_2=1$, $$\mathbb{E}\Big|\sum_{i=1}^n\alpha_i\chi_i\Big|\le 2\sqrt3\,(1-q)^2\sqrt{q(1-q)} .$$ For $q\in[1-q_L,1-q_4]$ the same holds with $1-q$ replaced by $q$. Consequently $R(q)=2\sqrt3\max(q,1-q)^2\sqrt{q(1-q)}$ for $q\in[q_4,q_L]\cup[1-q_L,1-q_4]$.*

2.  *(Extremisers.) Let $q\in[q_4,q_L]\cup[1-q_L,1-q_4]$. Equality in (a) holds if and only if $\alpha=\pm\frac1{\sqrt3}(e_i+e_j+e_k)$ with $i,j,k$ distinct, or $q\in\{q_4,1-q_4\}$ and $\alpha=\pm\frac12(e_i+e_j+e_k+e_l)$ with $i,j,k,l$ distinct.*

3.  *(Sharpness.) For $q\in(0,q_4)$, $R(q)\ge T_4(q)>T(q)$.*

**Corollary 1** (the whole $k=3$ regime). *With Theorem 3 of `MAIN_RESULT_K3` ($R=T$ on $[q_L,q_3]$, audited VALID by RQ-AUD as A.14): $R(q)=T(q)$ for every $q\in[q_4,q_3]$, and $$\{q\in(0,\tfrac12]:\ R(q)=T(q)\}=[q_4,q_3].$$ For $q\in[q_4,q_3]$ the extremisers are the vectors $\pm(e_i+e_j+e_k)/\sqrt3$, together with $\pm(e_i+e_j)/\sqrt2$ when $q=q_3$ and $\pm(e_i+e_j+e_k+e_l)/2$ when $q=q_4$. The mirror statements hold on $[1-q_3,1-q_4]$.*

*Proof.* On $[q_L,q_3]$ this is Theorem 3(a),(b); on $[q_4,q_L]$ it is Theorem 4(a),(b). For $q\in(q_3,\frac12]$, $R(q)\ge T_2(q)>T(q)$ (Theorem 3(c), or Lemma 4(i) below), and for $q<q_4$, $R(q)\ge T_4(q)>T(q)$ (Theorem 4(c)). ◻

**Corollary 2**. *With Theorem 1 of `MAIN_RESULT` ($R(q)=2\tau$ on $[q_0,1-q_0]$, $q_0=1-1/\sqrt2$; audited VALID as A.6) and Theorem 2 of `MAIN_RESULT_K2` ($R(q)=T_2(q)$ on $[q_3,q_0]$, mirrored on $[1-q_0,1-q_3]$; audited VALID as A.11): $$R(q)=2\sqrt{q(1-q)}\,\max\{1,\ \sqrt2\,\hat q,\ \sqrt3\,\hat q^{\,2}\}
=2\sqrt{q(1-q)}\,\max_{k\ge1}\sqrt k\,\hat q^{\,k-1},\qquad \hat q=\max(q,1-q),$$ for all $q\in[q_4,1-q_4]=[1-\frac{\sqrt3}2,\frac{\sqrt3}2]$.*

*Proof.* By symmetry (Lemma 3) let $q\le\frac12$, so $\hat q=1-q$. The maximum of $\{1,\sqrt2(1-q),\sqrt3(1-q)^2\}$ is $\sqrt3(1-q)^2$ on $[q_4,q_3]$, $\sqrt2(1-q)$ on $[q_3,q_0]$ and $1$ on $[q_0,\frac12]$: indeed $\sqrt3(1-q)^2\ge\sqrt2(1-q)$ iff $1-q\ge\sqrt{2/3}$, $\sqrt2(1-q)\ge1$ iff $1-q\ge1/\sqrt2$, and $\sqrt3(1-q)^2\ge1$ for $q\le q_3$. So the first formula follows from Corollary 1 and Theorems 1 and 2. For the second, let $k\ge4$ and $1-q\le\frac{\sqrt3}2$ (i.e. $q\ge q_4$). Then $\sqrt k(1-q)^{k-1}\le\sqrt3(1-q)^2$ iff $\sqrt{k/3}\,(1-q)^{k-3}\le1$, and $\sqrt{k/3}\,(1-q)^{k-3}\le(\frac k3(\frac34)^{k-3})^{1/2}$. The sequence $\frac k3(\frac34)^{k-3}$ equals $1$ at $k=4$ and decreases for $k\ge4$, since $\frac{k+1}{k}\cdot\frac34\le\frac54\cdot\frac34<1$. So the terms with $k\ge4$ never exceed the term with $k=3$ on $[q_4,\frac12]$. ◻

Part (c) and the lower bound $R\ge T$ in (a) are elementary (Lemma 4). The content is the upper bound in (a), and (b).

#### Relation to Theorem 3.

The proof follows `MAIN_RESULT_K3` (Theorem 3) step by step. The new ingredients are:

1.  the range $u\in[\frac{12}5,u_4]$ and the threshold $A_S=\frac7{20}$ of the one-coordinate route;

2.  polynomial certificates of degree up to ten, with an expectation bound that uses ten moments of the remainder (Section 4). Six moments cannot reach $q_4$ (Remark 3 of `MAIN_RESULT_K3`); the one-coordinate cells here have degree ten;

3.  *vertex certificates* (Section 6), which replace the box certificates of Theorem 3. They are needed because near $q_4$ the slack of the certificates is small and the first-order loss of the interval envelope over a box is too large;

4.  in the $m$-split near $(e_1+e_2+e_3)/\sqrt3$ (Section 8): vertex certificates for the patch with three split coordinates, a second $m$-split inside them, and a four-coordinate near-sphere bound based on an exact four-bit lemma (Lemma 7). This handles the second extremiser $(e_1+e_2+e_3+e_4)/2$, which ties with $(e_1+e_2+e_3)/\sqrt3$ at $q_4$.

The lemmas that are unchanged from Theorem 3 are proved again here, so that the document can be read on its own.

#### Conventions.

$x_+=\max(x,0)$. All polynomials in the computer-assisted parts have rational coefficients. “Verified” means verified in exact rational arithmetic or in outward-rounded interval arithmetic, as specified in Section 9. For a rational $x\ge0$ and an integer $N\ge1$, *rational lower and upper bounds of $\sqrt x$* are $\lfloor N\sqrt x\rfloor/N$ and $(\lfloor N\sqrt x\rfloor+1)/N$ computed with integer square roots (the verifier uses $N=10^{15}$ for the box parameters and $N=10^{12}$ for the patch enclosures).

# Reductions

## Symmetry and parametrisation

**Lemma 3**. *The law of $-\chi^{(q)}$ is the law of $\chi^{(1-q)}$. Hence $\mathbb{E}|\sum\alpha_i\chi^{(q)}_i|=\mathbb{E}|\sum\alpha_i\chi^{(1-q)}_i|$, $R(q)=R(1-q)$, and the extremisers for $q$ and $1-q$ coincide.*

*Proof.* $-\chi^{(q)}$ takes the value $-u_q$ with probability $q$ and $v_q$ with probability $1-q$; since $u_{1-q}=v_q$ and $v_{1-q}=u_q$, this is the law of $\chi^{(1-q)}$. Finally $|\sum\alpha_i(-\chi_i)|=|\sum\alpha_i\chi_i|$. ◻

From now on $q\le\frac12$, i.e. $u\ge1$, and $$\tag{1}
q=\frac{1}{1+u^2},\quad 1-q=\frac{u^2}{1+u^2},\quad v=\frac1u,\quad \tau=\frac{u}{1+u^2},\quad
qu=(1-q)v=\tau .$$ On $u\ge1$, $\tau$ and $q$ are decreasing and $1-q$ is increasing in $u$. The target is $$T=2\sqrt3(1-q)^2\tau=\sqrt3\,\tilde T(u),\qquad \tilde T(u)=\frac{2u^5}{(1+u^2)^3},\qquad
\frac{d}{du}\frac{u^5}{(1+u^2)^3}=\frac{u^4(5-u^2)}{(1+u^2)^4},$$ so $\tilde T$ is increasing on $[1,\sqrt5]$ and decreasing on $[\sqrt5,\infty)$. In particular, for $1\le u_1<u_2$ and $u\in[u_1,u_2]$, $$\tag{2}
T(u)\ \ge\ T^-(u_1,u_2):=S_3\min\{\tilde T(u_1),\tilde T(u_2)\},$$ where $S_3<\sqrt3$ is a rational lower bound of $\sqrt3$ (the verifier uses a lower bound with $N=10^{15}$ in exact arithmetic, and an outward-rounded interval enclosure of $\sqrt3$ in its interval-arithmetic parts). The range $q\in[q_4,q_L]$ corresponds to $u\in[\frac{12}5,u_4]$ with $$u_4=\sqrt{3+2\sqrt3}\approx2.5424597,$$ because $(1-q_4)/q_4=\frac{\sqrt3/2}{1-\sqrt3/2}=\frac{\sqrt3}{2-\sqrt3}=\sqrt3(2+\sqrt3)=3+2\sqrt3$ and $1/(1+(12/5)^2)=\frac{25}{169}$. We fix the rationals $$U_-=\frac{12}{5},\qquad U_+=\frac{127123}{50000}=2.54246\ \ge u_4$$ (indeed $U_+^2>3$ and $(U_+^2-3)^2\ge12$, so $U_+^2\ge3+2\sqrt3$), and put $q_U=1/(1+U_+^2)\le q_4$. Also $U_-^2=5.76>5$, so $\tilde T$ is decreasing on $[U_-,U_+]$; we do not need this, since (2) takes the minimum over both endpoints. The computations cover $u\in[U_-,U_+]$; the theorem uses only $u\in[U_-,u_4]$. Since $u_3=\sqrt{2+\sqrt6}\approx2.1094<U_-$, every $q$ in the range satisfies $q<q_3$.

## Values of a few vectors

**Lemma 4**. *Let $k\ge1$ and $q<1/k$. Then $\mathbb{E}|\chi_1+\dots+\chi_k|/\sqrt k=2\sqrt k\,(1-q)^{k-1}\tau$. In particular $\mathbb{E}|\chi_1|=2\tau$, $\mathbb{E}|\chi_1+\chi_2|/\sqrt2=T_2$ for $q<\frac12$, $\mathbb{E}|\chi_1+\chi_2+\chi_3|/\sqrt3=T$ for $q<\frac13$, and $\mathbb{E}|\chi_1+\dots+\chi_4|/2=T_4$ for $q<\frac14$. Moreover:*

1.  *for $q\le\frac12$: $T_2\le T$ iff $q\le q_3$, with equality iff $q=q_3$;*

2.  *for $q\le q_3$: $2\tau<T$;*

3.  *for $q<\frac14$: $T_4\ge T$ iff $q\le q_4$, with equality iff $q=q_4$.*

*Proof.* Let $S=\chi_1+\dots+\chi_k$ and let $x_i=\mathbf 1\{\chi_i=u\}$. If some $x_i=1$ then $S\ge u-(k-1)v>0$, because $u^2>k-1$ is equivalent to $q<1/k$. If all $x_i=0$ then $S=-kv<0$. So $|S|=fS$ with $f=1-2\cdot\mathbf 1\{\text{all }x_i=0\}$. Since $\mathbb{E}\chi_i=0$, $\mathbb{E}[f\chi_i]=-2\mathbb{E}[\chi_i\mathbf 1\{\text{all }x=0\}]=-2(1-q)^k(-v)=2(1-q)^{k-1}(1-q)v=2(1-q)^{k-1}\tau$. Summing over $i$ gives $\mathbb{E}|S|=2k(1-q)^{k-1}\tau$. The comparisons: (i) $2\sqrt2(1-q)\tau\le2\sqrt3(1-q)^2\tau$ iff $1-q\ge\sqrt{2/3}$; (ii) for $q\le q_3$, $\sqrt3(1-q)^2\ge\sqrt3\cdot\frac23=\frac2{\sqrt3}>1$; (iii) $4(1-q)^3\ge2\sqrt3(1-q)^2$ iff $1-q\ge\frac{\sqrt3}2$. ◻

## Splitting off the two largest coefficients

Let $|\alpha|_2=1$ and $L=\sum\alpha_i\chi_i$. Changing the sign of $\alpha$ and permuting coordinates does not change $\mathbb{E}|L|$. So we may assume $$a_1:=\alpha_1=\max_i|\alpha_i|>0,\qquad a_2:=|\alpha_2|=\max_{i\ge2}|\alpha_i|,\qquad
|\alpha_3|\ge|\alpha_4|\ge\cdots,$$ and we put $s=\operatorname{sgn}\alpha_2\in\{1,-1\}$ ($s=1$ if $\alpha_2=0$), $$r=\sqrt{a_1^2+a_2^2}\in(0,1],\qquad b=\sqrt{1-r^2}.$$ If $r<1$, let $\beta_i=\alpha_i/b$ for $i\ge3$ and $M=\sum_{i\ge3}\beta_i\chi_i$. Then $$L=a_1\chi_1+s\,a_2\chi_2+bM,\qquad \sum_{i\ge3}\beta_i^2=1,\qquad
m:=\max_{i\ge3}|\beta_i|=\frac{|\alpha_3|}{b}\le\min\Big(1,\frac{a_2}{b}\Big),$$ and $M$ is independent of $(\chi_1,\chi_2)$. We use half-angle coordinates for $(a_1,a_2)$: $$a_1=r\,c(t),\quad a_2=r\,d(t),\qquad c(t)=\frac{1-t^2}{1+t^2},\quad d(t)=\frac{2t}{1+t^2},\qquad
t=\frac{a_2}{r+a_1}.$$ Since $0\le a_2\le a_1$, the angle $\theta$ with $\tan\theta=a_2/a_1$ is in $[0,\pi/4]$ and $t=\tan(\theta/2)\in[0,\sqrt2-1]$. We fix $T_8=\frac{20711}{50000}=0.41422\ge\sqrt2-1$ (indeed $(T_8+1)^2\ge2$). On $[0,1]$, $c$ is decreasing and $d$ is increasing in $t$, both are $\ge0$, and $c^2+d^2=1$. Thus every unit $\alpha$ gives a point $$(u,t,r,s)\in[U_-,U_+]\times[0,T_8]\times(0,1]\times\{1,-1\}\qquad(u\in[U_-,u_4]).$$ We put $A_S=\frac7{20}$. If $a_1\le A_S$ we use the one-coordinate route of Section 5; otherwise $r\ge a_1>A_S$ and we use the two-coordinate route of Sections 6–8.

# Exact evaluations

## Two coordinates

**Lemma 5** (two-coordinate value). *Let $q\le\frac12$, $c,d\ge0$, $s\in\{1,-1\}$, and $X=c\chi_1+s\,d\chi_2$. List the atoms of $X$ as $(\chi_1,\chi_2)=(u,u),(u,-v),(-v,u),(-v,-v)$, with probabilities $p=(q^2,\,q(1-q),\,q(1-q),\,(1-q)^2)$ and values $x_j$. Then $p_jx_j=\tau g_j$ with $$\tag{3}
g=\big(q(c+sd),\ (1-q)c-s\,q\,d,\ -q\,c+s(1-q)d,\ -(1-q)(c+sd)\big),$$ and $$\mathbb{E}|X|=2\tau\max\{c,\ d,\ [s=1]\,(1-q)(c+d)\}$$ (the last entry is present only for $s=1$). If $q\le q_3$, then $\mathbb{E}|X|\le T\sqrt{c^2+d^2}$, and for $(c,d)\ne0$ equality holds if and only if $q=q_3$, $s=1$ and $c=d$. In particular $\mathbb{E}|X|<T\sqrt{c^2+d^2}$ for $q<q_3$ and $(c,d)\ne0$.*

*Proof.* The identities $p_jx_j=\tau g_j$ follow from (1); for example $q(1-q)(cu-sdv)=(1-q)\tau c-q\tau sd$. Since $\mathbb{E}X=0$, $\mathbb{E}|X|=2\mathbb{E}X_+=2\tau\sum_j(g_j)_+$. For $s=1$: $g_1\ge0\ge g_4$, so $\mathbb{E}X_+/\tau=q(c+d)+((1-q)c-qd)_++((1-q)d-qc)_+$. If both middle terms are nonnegative this equals $(1-q)(c+d)$, and then $(1-q)(c+d)-c=(1-q)d-qc\ge0$ and similarly $\ge d$. If only the first is nonnegative it equals $q(c+d)+(1-q)c-qd=c$, and $(1-q)(c+d)-c=(1-q)d-qc<0$, while $c\ge d$ (otherwise $(1-q)d-qc\ge (1-2q)c\ge 0$). The case where only the second is nonnegative is symmetric. Both negative would give $(1-q)(c+d)<q(c+d)$, impossible for $q\le\frac12$ unless $c=d=0$. In all cases $\mathbb{E}X_+/\tau=\max\{c,d,(1-q)(c+d)\}$. For $s=-1$: $g_2\ge0\ge g_3$. If $c\ge d$ then $g_1\ge0\ge g_4$ and $\mathbb{E}X_+/\tau=q(c-d)+(1-q)c+qd=c$. If $c<d$ then $g_1<0<g_4$ and $\mathbb{E}X_+/\tau=(1-q)c+qd+(1-q)(d-c)=d$. So $\mathbb{E}X_+/\tau=\max(c,d)$.

For the bound let $\rho=\sqrt{c^2+d^2}>0$ and $q\le q_3$. Then $2\tau\max(c,d)\le2\tau\rho<T\rho$ by Lemma 4(ii), and, since $(1-q)(c+d)\le\sqrt2(1-q)\rho$ with equality iff $c=d$, $2\tau(1-q)(c+d)\le T_2\rho\le T\rho$ by Lemma 4(i), with equality iff $c=d$ and $q=q_3$. Since the third entry is present only for $s=1$, this gives the claim. ◻

## Three and four coordinates

For $n\ge1$, $f:\{0,1\}^n\to[-1,1]$ and $x_i=\mathbf 1\{\chi_i=u\}$ put $\Delta_i(f)=\mathbb{E}[f\mid x_i=1]-\mathbb{E}[f\mid x_i=0]$, a polynomial in $q$. Then, by (1), $$\tag{4}
\mathbb{E}[f\chi_i]=qu\,\mathbb{E}[f\mid x_i=1]-(1-q)v\,\mathbb{E}[f\mid x_i=0]=\tau\,\Delta_i(f).$$ For $c\in\mathbb{R}^n$ write $G_n(c)=\mathbb{E}|c_1\chi_1+\dots+c_n\chi_n|$. For a set $S\subseteq\{1,\dots,n\}$ let $\mathrm{OR}_S=2\cdot\mathbf 1\{\exists i\in S:x_i=1\}-1$. By the computation in the proof of Lemma 4, $$\tag{5}
\Delta_i(\mathrm{OR}_S)=2(1-q)^{|S|-1}\ (i\in S),\qquad \Delta_i(\mathrm{OR}_S)=0\ (i\notin S).$$

**Lemma 6** (three-bit lemma). *Let $q\in[q_U,q_L]$ and $c\in\mathbb{R}^3$. Then $G_3(c)\le T\,|c|$. For $c\ne0$ equality holds if and only if $c$ is a positive multiple of $\pm(e_1+e_2+e_3)$.*

**Lemma 7** (four-bit lemma). *Let $q\in[q_4,q_L]$ and $c\in\mathbb{R}^4$. Then $G_4(c)\le T\,|c|$. For $c\ne0$ equality holds if and only if $c$ is a positive multiple of $\pm(e_i+e_j+e_k)$ for distinct $i,j,k$, or $q=q_4$ and $c$ is a positive multiple of $\pm(e_1+e_2+e_3+e_4)$.*

*Proof of Lemmas 6 and 7.* Let $n\in\{3,4\}$, $X=c\cdot\chi$ and $f^*=\operatorname{sgn}X$ (with $\operatorname{sgn}0=1$), a function of $(x_1,\dots,x_n)$ with values $\pm1$. By (4) and Cauchy–Schwarz, $$G_n(c)=\mathbb{E}[f^*X]=\tau\sum_ic_i\Delta_i(f^*)\le\tau|c|\,|\Delta(f^*)| .$$ For $f:\{0,1\}^n\to\{-1,1\}$ put $H_f(q)=12(1-q)^4-\sum_{i=1}^n\Delta_i(f)^2$, a polynomial with integer coefficients. *Claims* (finite exact computations, Section 9, part G):

1.  ($n=3$, all $2^8$ functions) $H_f\ge0$ on $[q_U,q_L]$; $H_f\equiv0$ exactly for $f=\pm\mathrm{OR}_{\{1,2,3\}}$; every other $H_f$ is $>0$ on $[q_U,q_L]$.

2.  ($n=4$, all $2^{16}$ functions) $H_f\ge0$ on $[q_4,q_L]$; $H_f\equiv0$ exactly for the eight functions $f=\pm\mathrm{OR}_S$ with $|S|=3$; $H_f(q_4)=0\not\equiv H_f$ exactly for $f=\pm\mathrm{OR}_{\{1,2,3,4\}}$, and these two $H_f$ are $>0$ on $(q_4,q_L]$; every other $H_f$ is $>0$ on $[q_4,q_L]$.

Given the claims, $G_n(c)\le\tau|c|\sqrt{12}(1-q)^2=T|c|$ on the stated ranges. If equality holds with $c\ne0$, then $\Delta(f^*)\ne0$, $c$ is a positive multiple of $\Delta(f^*)$, and $H_{f^*}(q)=0$. By the claims and (5): for $n=3$, $f^*=\pm\mathrm{OR}_{\{1,2,3\}}$ and $\Delta(f^*)=\pm2(1-q)^2(1,1,1)$; for $n=4$, either $f^*=\pm\mathrm{OR}_S$ with $|S|=3$ and $\Delta(f^*)=\pm2(1-q)^2\sum_{i\in S}e_i$, or $q=q_4$, $f^*=\pm\mathrm{OR}_{\{1,2,3,4\}}$ and $\Delta(f^*)=\pm2(1-q)^3(1,1,1,1)$. Conversely these vectors attain $T|c|$ by Lemma 4 (for $c=e_i+e_j+e_k$ the fourth coordinate does not contribute; at $q_4$, $T_4=T$).

*How the claims are checked.* For each $f$, $\Delta_i(f)=\sum_{x:x_i=1}(f(x)-f(x-e_i))
\prod_{l\ne i}q^{x_l}(1-q)^{1-x_l}$ is computed as an integer polynomial, and the distinct polynomials $H_f$ are tested (39 for $n=3$, 1 630 for $n=4$). For $n=3$: $H_f\equiv0$, or $H_f$ has no real root in $[q_U,q_L]$ (Sturm) and $H_f(q_L)>0$. For $n=4$, let $g_4(q)=4q^2-8q+1$, the minimal polynomial of $q_4$; it is irreducible over $\mathbb Q$ (its discriminant $48$ is not a square), decreasing on $[0,1]$, and its other root $1+\sqrt3/2$ exceeds $1$. Take rationals $q_4^-<q_4<q_4^+$ with $g_4(q_4^-)>0>g_4(q_4^+)$ and $q_U<q_4^-$, $q_4^+<q_L$ (from rational bounds of $\sqrt{3/4}$). Then for $H_f\not\equiv0$: $H_f$ has no root in $[q_4^+,q_L]$ and $H_f(q_L)>0$; and either $g_4\mid H_f$, $H_f=g_4Q$, where $Q$ has no root in $[q_4^-,q_4^+]$ and $Q(q_4^+)<0$ (so $H_f=g_4Q\ge0$ on $[q_4,q_4^+]$ with equality only at $q_4$), or $g_4\nmid H_f$, and $H_f$ has no root in $[q_4^-,q_4^+]$ and $H_f(q_4^-)>0$. Since $g_4$ is irreducible, $H_f(q_4)=0$ iff $g_4\mid H_f$. The lists of functions with $H_f\equiv0$ and with $g_4\mid H_f$ are compared with the truth tables of the OR functions. As a check of (5): $H_{\mathrm{OR}_{\{1,2,3,4\}}}=12(1-q)^4-16(1-q)^6=-4(1-q)^4g_4(q)$. ◻

*Remark 8*. Lemma 6 on $[q_4,q_3]$ and Lemma 7 are the cases $n=3,4$ of RQ-C’s result C6 ($R_n(q)=2\tau\sqrt{\max_{k\le n}k(1-\bar q)^{2k-2}}$ for $n\le7$, audited VALID as A.5, A.5b). Our check is independent of it. Lemma 7 is false for $q<q_4$, where $(e_1+\dots+e_4)/2$ gives $T_4>T$; this is the only place where the lower end $q_4$ of Theorem 4 enters the proof.

# Moments of the remainder

**Lemma 9** (cumulants). *Let $w=u^2+v^2$ and $d=u-v$. The cumulants of $\chi$ are $\kappa_1=0$, $\kappa_2=1$ and $\kappa_j=d^{[j\text{ odd}]}G_j(w)$ for $3\le j\le10$, where $$\begin{aligned}
G_3&=1, & G_4&=w-4,\\
G_5&=w-10, & G_6&=w^2-26w+64,\\
G_7&=w^2-56w+244, & G_8&=w^3-120w^2+1188w-2176,\\
G_9&=w^3-246w^2+4044w-11080, & G_{10}&=w^4-502w^3+14604w^2-86728w+126976.
\end{aligned}$$*

*Proof.* By (1), $m_k=\mathbb{E}\chi^k=qu^k+(1-q)(-v)^k=(u^k+(-1)^ku^{2-k})/(1+u^2)$. The cumulants are determined by the recursion $\kappa_n=m_n-\sum_{k=1}^{n-1}\binom{n-1}{k-1}\kappa_km_{n-k}$. For example $m_3=u-v$, $m_4=w-1$, so $\kappa_3=d$ and $\kappa_4=m_4-3=w-4$. The identities for $j\le10$ are verified symbolically (sympy, part A1 of the verifier: the difference of the two sides simplifies to $0$ as a rational function of $u$). ◻

**Lemma 10** (moments from cumulants). *Let $M=\sum\beta_i\chi_i$ (finite sum) with $\sum\beta_i^2=1$ and power sums $p_j=\sum_i\beta_i^j$. Then $M$ has cumulants $K_1=0$, $K_2=1$, $K_j=\kappa_jp_j$, and $\mathbb{E}M^n=\mu_n(K_3,\dots,K_n)$ for $n\le10$, where $\mu_0=1$ and $$\mu_n=\sum_{k=2}^{n}\binom{n-1}{k-1}K_k\,\mu_{n-k}\qquad(K_2=1).$$ Each $\mu_n$ is a polynomial in $K_3,\dots,K_{10}$ with nonnegative integer coefficients; we write $\mu_n=\sum_eN_n(e)\prod_{j=3}^{10}K_j^{e_j}$ over exponent vectors $e=(e_3,\dots,e_{10})$. The term with $e=0$ is the Gaussian moment: $N_n(0)=(n-1)!!$ for even $n$ and $0$ for odd $n$.*

*Proof.* Cumulants of independent sums add and $K_j(\beta\chi)=\beta^j\kappa_j$, so $K_j(M)=\kappa_jp_j$, with $K_1=0$ and $K_2=\sum\beta_i^2=1$. The recursion is the moment–cumulant relation $m_n=\sum_{k=1}^{n}\binom{n-1}{k-1}K_km_{n-k}$ with $K_1=0$. The value at $K_3=\dots=K_{10}=0$ is the $n$-th moment of a standard Gaussian. (Part A2 of the verifier checks the recursion against the Gaussian moments and against $\mathbb{E}\chi^n$ at $u=\frac52$ for $n\le10$.) ◻

**Lemma 11** (power sums). *Let $\sum\beta_i^2=1$, $\max|\beta_i|\le m\le1$ and $\rho=\sqrt{p_4}$. Then $0\le\rho\le m$, $|p_3|\le\rho$, $|p_j|\le m^{j-4}\rho^2$ for $5\le j\le10$, and $p_j\ge\rho^{j-2}$ for even $j\ge4$.*

*Proof.* $p_4\le m^2\sum\beta_i^2=m^2$. Cauchy–Schwarz gives $p_3^2=(\sum\beta_i\beta_i^2)^2\le p_2p_4=p_4$. For $j\ge5$, $|p_j|\le\sum|\beta_i|^{j-4}\beta_i^4\le m^{j-4}p_4$. For even $j\ge4$, Jensen’s inequality for the probability weights $\beta_i^2$ and the convex function $x\mapsto x^{(j-2)/2}$ gives $p_j=\sum\beta_i^2(\beta_i^2)^{(j-2)/2}\ge(\sum\beta_i^2\beta_i^2)^{(j-2)/2}=\rho^{j-2}$. ◻

**Lemma 12** (sign information). *Let $\sum\beta_i^2=1$, $m=\max|\beta_i|$, and suppose $\beta_{i_0}=-m$ for some $i_0$. If $m\ge m_c\in(0,1]$, then $p_3\le\varphi(m_c):=-m_c^3+(1-m_c^2)^{3/2}$. Moreover $\varphi(m)<0$ iff $2m^2>1$.*

*Proof.* For $i\ne i_0$, $|\beta_i|\le(\sum_{i\ne i_0}\beta_i^2)^{1/2}=\sqrt{1-m^2}$. Hence $p_3=-m^3+\sum_{i\ne i_0}\beta_i^3\le-m^3+\sqrt{1-m^2}\sum_{i\ne i_0}\beta_i^2=\varphi(m)$, and $\varphi'(m)=-3m^2-3m\sqrt{1-m^2}\le0$. Finally $\varphi(m)<0$ iff $(1-m^2)^{3/2}<m^3$ iff $1-m^2<m^2$. ◻

#### Cumulant enclosures.

For $1\le u_1\le u\le u_2$: $d=u-1/u$ and $w=u^2+u^{-2}$ are increasing and $d\ge0$, so $d\in[d^-,d^+]=[u_1-\frac1{u_1},u_2-\frac1{u_2}]$ and $w\in[w^-,w^+]=[u_1^2+u_1^{-2},u_2^2+u_2^{-2}]$. Let $[G_j^-,G_j^+]$ be the exact range of the polynomial $G_j$ on $[w^-,w^+]$ (computed by isolating the real roots of $G_j'$ by Sturm sequences and bisection). Then $\kappa_j\in[\kappa_j^-,\kappa_j^+]$, where this is $[G_j^-,G_j^+]$ for even $j$ and the interval product $[d^-,d^+]\cdot[G_j^-,G_j^+]$ for odd $j$.

**Definition 13** (objective bound). Let $D\le10$, $c=(c_0,\dots,c_D)\in\mathbb Q^{D+1}$, $1<u_1<u_2$ rationals, $m^*\in(0,1]$, $p^*<0$ optional, and $\Theta$ a target. Put $L_e=\sum_nc_nN_n(e)$ and $A=L_0=\sum_{n\text{ even}}c_n(n-1)!!$. For every $e\ne0$ with $L_e\ne0$ let $[C_e^-,C_e^+]$ be the interval product $L_e\prod_j[\kappa_j^-,\kappa_j^+]^{e_j}$, and put $$u_e=e_3+2\sum_{j\ge4}e_j,\qquad U_e=\prod_{j\ge5}(m^*)^{(j-4)e_j}.$$ Call $e$ *even* if $e_j$ is even for every odd $j$. For even $e$ let $(\ell_e,l_e)=(0,0)$ if $e_j>0$ for some odd $j$, and $(\ell_e,l_e)=(1,\sum_{j\text{ even}}(j-2)e_j)$ otherwise. Define the term bounds

1.  if $p^*$ is given, $e=(1,0,\dots,0)$ (i.e. the monomial $p_3$) and $C_e^-\ge0$: replace $A$ by $A+C_e^-p^*$, and $b_e=0$;

2.  otherwise, if $e$ is not even: $b_e(\rho)=\max(|C_e^-|,|C_e^+|)\,U_e\,\rho^{u_e}$;

3.  if $e$ is even and $C_e^+\le0$: $b_e(\rho)=C_e^+\,\ell_e\,\rho^{l_e}$;

4.  if $e$ is even and $C_e^+>0$: $b_e(\rho)=C_e^+\,U_e\,\rho^{u_e}$.

We say that *$c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$* if $h(\rho)=\Theta-A-\sum_eb_e(\rho)>0$ for all $\rho\in[0,m^*]$.

**Lemma 14** (expectation bound). *Suppose $c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$ and let $P(y)=\sum_nc_ny^n$. Then $\mathbb{E}P(M)<\Theta$ for every $u\in[u_1,u_2]$ and every $M=\sum\beta_i\chi_i$ with $\sum\beta_i^2=1$, $\max|\beta_i|\le m^*$ and, if $p^*$ is given, $p_3\le p^*$.*

*Proof.* By Lemma 10, $\mathbb{E}P(M)=\sum_nc_n\mu_n=L_0+\sum_{e\ne0}C_ep^e$ with $C_e=L_e\prod_j\kappa_j^{e_j}\in[C_e^-,C_e^+]$ and $p^e=\prod_jp_j^{e_j}$. Let $\rho=\sqrt{p_4}\in[0,m^*]$. By Lemma 11, $|p^e|\le\rho^{e_3}(\rho^2)^{e_4}\prod_{j\ge5}(m^{*\,j-4}\rho^2)^{e_j}=U_e\rho^{u_e}$; if $e$ is even then $p^e\ge0$ (odd power sums appear to even powers, and $p_j\ge0$ for even $j$); and if moreover $e_j=0$ for all odd $j$, then $p^e\ge\prod_{j\text{ even}}\rho^{(j-2)e_j}=\rho^{l_e}$. Hence: in case (T0), $p_3\le p^*<0$ and $C_e\ge C_e^-\ge0$ give $C_ep_3\le C_ep^*\le C_e^-p^*$; in case (T1), $C_ep^e\le|C_e||p^e|\le b_e(\rho)$; in case (T2), $C_e\le C_e^+\le0$ and $p^e\ge\ell_e\rho^{l_e}\ge0$ give $C_ep^e\le C_e^+p^e\le C_e^+\ell_e\rho^{l_e}$; in case (T3), $p^e\ge0$ gives $C_ep^e\le C_e^+p^e\le C_e^+U_e\rho^{u_e}$. Summing, $\mathbb{E}P(M)\le\Theta-h(\rho)<\Theta$. ◻

# The one-coordinate route ($a_1\le\frac7{20}$)

Here we split off only $a=a_1$: $L=a\chi_1+b_1M_1$ with $b_1=\sqrt{1-a^2}$ and $M_1=\sum_{i\ge2}(\alpha_i/b_1)\chi_i$, whose coefficients are at most $\min(1,a/b_1)$ in absolute value. For $y\in\mathbb{R}$, $$\mathbb{E}|a\chi+y|=2\tau a+2R_a(y)-(1-2q)y,\qquad R_a(y)=\max\{0,\ (1-q)(y-av),\ q(-y-au)\}$$ (BF3, Lemma 9.4; Lemma 3 of `MAIN_RESULT`, audited VALID). Indeed $\mathbb{E}|a\chi+y|=q|au+y|+(1-q)|y-av|$ equals $2\tau a-(1-2q)y$ for $-au\le y\le av$ (using $qau=(1-q)av=\tau a$), $y$ for $y>av$, and $-y$ for $y<-au$, and so does the right-hand side. Conditioning on $M_1$ and using $\mathbb{E}M_1=0$, $$\mathbb{E}|L|=2\tau a+2\mathbb{E}R_a(b_1M_1),\qquad\text{so}\qquad \mathbb{E}|L|<T\iff\mathbb{E}R_a(b_1M_1)<\tau\big(\sqrt3(1-q)^2-a\big).$$

A *cell* is $[u_1,u_2]\times[\underline a,\overline a]$ with rationals $1<u_1<u_2$ and $0\le\underline a<\overline a\le A_S$. Let $\bar b$ be a rational upper bound of $\sqrt{1-\underline a^2}$, $\bar m=\min\{1,\overline a/\beta\}$ with $\beta$ a rational lower bound of $\sqrt{1-\overline a^2}$, and $$\bar\ell_1(y)=\frac{u_2^2}{1+u_2^2}\Big(\bar by-\frac{\underline a}{u_2}\Big),\quad
\bar\ell_2(y)=\frac{1}{1+u_1^2}\big(-\bar by-\underline au_1\big),\quad
\Theta_1=\tau(u_2)\Big(S_3\Big(\frac{u_1^2}{1+u_1^2}\Big)^2-\overline a\Big).$$ A *cell certificate* is $c\in\mathbb Q^{D+1}$, $D\le10$, with $P(y)=\sum c_ny^n$ such that (V1) $P>0$, (V2) $P>\bar\ell_1$, (V3) $P>\bar\ell_2$ on $\mathbb{R}$, and (V4) $c$ satisfies the objective bound for $(u_1,u_2,\bar m,-,\Theta_1)$.

**Lemma 15**. *If a cell with $u_1\ge U_-$ has a certificate, then $\mathbb{E}|L|<T$ for every $u\in[u_1,u_2]$ and every unit $\alpha$ with $\underline a\le\max_i|\alpha_i|\le\overline a$.*

*Proof.* For $u\in[u_1,u_2]$, $a\in[\underline a,\overline a]$ and $b_1=\sqrt{1-a^2}$ we have $R_a(b_1y)=\max\{0,\ell_1,\ell_2\}$ with $\ell_1=\frac{u^2}{1+u^2}(b_1y-\frac au)$ and $\ell_2=\frac1{1+u^2}(-b_1y-au)$. If $\ell_1(y)>0$ then $y>0$ and $0<b_1y-\frac au\le\bar by-\frac{\underline a}{u_2}$, and $\frac{u^2}{1+u^2}\le\frac{u_2^2}{1+u_2^2}$, so $\ell_1(y)\le\bar\ell_1(y)$. If $\ell_2(y)>0$ then $y<0$ and $0<-b_1y-au\le-\bar by-\underline au_1$, and $\frac1{1+u^2}\le\frac1{1+u_1^2}$, so $\ell_2(y)\le\bar\ell_2(y)$. So by (V1)–(V3), $R_a(b_1y)<P(y)$ for all $y$, and $\mathbb{E}R_a(b_1M_1)\le\mathbb{E}P(M_1)$. Since $a/\sqrt{1-a^2}$ is increasing, the coefficients of $M_1$ are at most $\bar m$ in absolute value. By Lemma 14, $\mathbb{E}P(M_1)<\Theta_1$. Finally $\Theta_1\le\tau(u)(\sqrt3(1-q)^2-a)$, because $\tau(u)\ge\tau(u_2)$, $(1-q)^2\ge(\frac{u_1^2}{1+u_1^2})^2$, $S_3<\sqrt3$, $a\le\overline a$, and the bracket is positive: $S_3(\frac{u_1^2}{1+u_1^2})^2\ge S_3(\frac{144}{169})^2>1.25>\frac7{20}\ge\overline a$ (the verifier also asserts $\Theta_1>0$ for every cell). ◻

# The two-coordinate route: vertex certificates

## The functions $F_x$ and the patches

Let $k\in\{2,3\}$ and a sign vector $\sigma\in\{1,-1\}^k$ with $\sigma_1=1$. For $x\in\mathbb{R}^{k+1}$ and $y\in\mathbb{R}$ put $$F_x(y)=\mathbb{E}\Big|\sum_{i=1}^k\sigma_ix_i\chi_i+x_{k+1}\,y\Big| ,$$ where $\chi_1,\dots,\chi_k$ are i.i.d. normalised $q$-biased bits. We use $\sigma=(1,s)$ for $k=2$ and $\sigma=(1,s,s_3)$ for $k=3$.

**Lemma 16**. *For fixed $q$ and $y$, the map $x\mapsto F_x(y)$ is convex and positively homogeneous of degree one. Consequently, if $x=\sum_l\nu_lV_l$ with $\nu_l\ge0$, then $F_x(y)\le\sum_l\nu_lF_{V_l}(y)$.*

*Proof.* $F_x(y)$ is the expectation of the absolute value of a linear function of $x$, i.e. a seminorm of $x$. A seminorm $N$ satisfies $N(\sum\nu_lV_l)\le\sum\nu_lN(V_l)$ for $\nu_l\ge0$. ◻

The *patches* are the maps $$p_2(t,r)=\big(rc(t),\,rd(t),\,\sqrt{1-r^2}\big),\qquad
p_3(t,r,m)=\big(rc(t),\,rd(t),\,\sqrt{1-r^2}\,m,\,\sqrt{1-r^2}\sqrt{1-m^2}\big),$$ for $t\in[0,1]$, $r,m\in[0,1]$. Their values are unit vectors with nonnegative entries.

**Lemma 17** (conditional expectation). *At a point with $r<1$, $\mathbb{E}|L|=\mathbb{E}F_{p_2(t,r)}(M)$ with $\sigma=(1,s)$, where the expectation on the right is over $M$ (independent of $\chi_1,\chi_2$). If moreover $\beta_{i_0}=s_3m$ with $m=\max|\beta_i|<1$ and $s_3\in\{1,-1\}$, let $M'=\sum_{i\ge3,\,i\ne i_0}\beta_i'\chi_i$ with $\beta_i'=\beta_i/\sqrt{1-m^2}$. Then $\sum\beta_i'^2=1$, $\max|\beta_i'|\le\min(1,m/\sqrt{1-m^2})$, $M'$ is independent of $(\chi_1,\chi_2,\chi_{i_0})$ and $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,m)}(M')$ with $\sigma=(1,s,s_3)$ (the third bit being $\chi_{i_0}$). If $m=1$, then $L=a_1\chi_1+sa_2\chi_2+s_3b\chi_{i_0}$, and $F_{p_3(t,r,1)}(y)=\mathbb{E}|L|$ for every $y$.*

*Proof.* $L=a_1\chi_1+sa_2\chi_2+bM$ and $(a_1,a_2,b)=p_2(t,r)$; condition on $M$. In the second case $L=a_1\chi_1+sa_2\chi_2+s_3bm\chi_{i_0}+b\sqrt{1-m^2}M'$ and $(a_1,a_2,bm,b\sqrt{1-m^2})=p_3(t,r,m)$; $\sum_{i\ne i_0}\beta_i^2=1-m^2$ and $|\beta_i|\le m$, and also $|\beta_i'|\le1$. If $m=1$ the last entry of $p_3$ is $0$. ◻

## Vertex sets and the cone lemma

**Definition 18** (vertex set). Let $X=\prod_{i=1}^k[\xi_i^-,\xi_i^+]$ be a box of patch parameters ($(t,r)$ for $k=2$, $(t,r,m)$ for $k=3$) and $p=p_k$. A *vertex set for $X$* is a vector $n_0\in\mathbb Q^{k+1}$ and $2^k$ vectors $V_\epsilon\in\mathbb Q^{k+1}$, indexed by $\epsilon\in\{0,1\}^k$, such that:

1.  $|n_0|^2\ge1$ and $V_\epsilon\cdot n_0=|n_0|^2$ for all $\epsilon$;

2.  (parallelepiped) $V_\epsilon=V_0+\sum_i\epsilon_iE_i$ with $E_i=V_{e_i}-V_0$;

3.  (facets) for each $i$ and $\delta\in\{0,1\}$ the $2^{k-1}$ vertices with $\epsilon_i=\delta$ span a linear subspace of dimension $k$; let $h_{i,\delta}$ be a normal vector of it, oriented so that $h_{i,\delta}\cdot\bar c>0$ for the centre $\bar c=V_0+\frac12\sum_iE_i$ (and $h_{i,\delta}\cdot\bar c\ne0$ is required);

4.  (enclosure) $h_{i,\delta}\cdot p(\xi)\ge0$ for all $i,\delta$ and all $\xi\in X$.

**Lemma 19** (cone lemma). *Let $(n_0,(V_\epsilon))$ be a vertex set for $X$. Then for every $\xi\in X$ there are $\nu_\epsilon\ge0$ with $p(\xi)=\sum_\epsilon\nu_\epsilon V_\epsilon$ and $\sum_\epsilon\nu_\epsilon\le1/|n_0|\le1$.*

*Proof.* First, $V_0,E_1,\dots,E_k$ is a basis of $\mathbb{R}^{k+1}$. Indeed $E_i\cdot n_0=0$ by (P1) and $V_0\cdot n_0=|n_0|^2\ne0$, so $V_0\notin\operatorname{span}\{E_i\}$. By (P2) the face $\{\epsilon_i=0\}$ spans $S_i=\operatorname{span}(V_0,\{E_j\}_{j\ne i})$, which has dimension $k$ by (P3); hence the $k$ vectors $V_0,\{E_j\}_{j\ne i}$ are linearly independent. Moreover $\bar c-V_0-\frac12\sum_{j\ne i}E_j=\frac12E_i$ and $h_{i,0}\cdot\bar c\ne0$ with $h_{i,0}\perp S_i$, so $E_i\notin S_i$. Thus the $k+1$ vectors are independent.

Let $z\in\mathbb{R}^{k+1}$ with $h_{i,\delta}\cdot z\ge0$ for all $i,\delta$, and write $z=\lambda V_0+\sum_i\mu_iE_i$. Since $h_{i,0}\perp S_i$, $h_{i,0}\cdot z=\mu_i\,h_{i,0}\cdot E_i$, and $h_{i,0}\cdot\bar c=\frac12h_{i,0}\cdot E_i>0$; so $\mu_i\ge0$. The face $\{\epsilon_i=1\}$ spans $\operatorname{span}(V_0+E_i,\{E_j\}_{j\ne i})$, so $h_{i,1}\cdot E_j=0$ ($j\ne i$) and $h_{i,1}\cdot V_0=-h_{i,1}\cdot E_i$; then $h_{i,1}\cdot\bar c=-\frac12h_{i,1}\cdot E_i>0$, so $h_{i,1}\cdot V_0>0$, and $h_{i,1}\cdot z=(\lambda-\mu_i)\,h_{i,1}\cdot V_0$; so $\mu_i\le\lambda$. If $\lambda=0$ then $z=0$. Otherwise $z/\lambda=V_0+\sum_i\theta_iE_i$ with $\theta_i=\mu_i/\lambda\in[0,1]$, which is a point of the parallelepiped $\operatorname{conv}\{V_\epsilon\}$, i.e. a convex combination $\sum\omega_\epsilon V_\epsilon$ (take $\omega_\epsilon=\prod_i\theta_i^{\epsilon_i}(1-\theta_i)^{1-\epsilon_i}$). So $z=\sum\nu_\epsilon V_\epsilon$ with $\nu=\lambda\omega\ge0$ and $\sum\nu_\epsilon=\lambda$. Finally $z\cdot n_0=\lambda|n_0|^2$, so $\lambda=z\cdot n_0/|n_0|^2\le|z|/|n_0|$.

By (P4), $z=p(\xi)$ satisfies the hypothesis, and $|p(\xi)|=1$. ◻

## Vertex envelopes and vertex certificates

Fix a $u$-interval $[u_1,u_2]$ with $u_1>1$. For a vertex $V\in\mathbb Q^{k+1}$ let $\gamma=(\sigma_1V_1,\dots,\sigma_kV_k)$ and $b_V=V_{k+1}$. The atoms of $\sum_i\gamma_i\chi_i$ are indexed by $\omega\in\{u,-v\}^k$, with probability $\pi_\omega=\prod_iq^{[\omega_i=u]}(1-q)^{[\omega_i=-v]}$ and value $y_\omega=\sum_i\gamma_i\omega_i$, and by (1) $$\pi_\omega y_\omega=\tau\sum_i\gamma_i\,(\pm1)_i\prod_{l\ne i}q^{[\omega_l=u]}(1-q)^{[\omega_l=-v]},
\qquad(\pm1)_i=+1\text{ if }\omega_i=u,\ -1\text{ otherwise}.$$ Using $q\in[\frac1{1+u_2^2},\frac1{1+u_1^2}]$, $1-q\in[\frac{u_1^2}{1+u_1^2},\frac{u_2^2}{1+u_2^2}]$ and $\tau\in[\tau(u_2),\tau(u_1)]$, interval arithmetic gives rational enclosures $\pi_\omega y_\omega\in[\eta_\omega^-,\eta_\omega^+]$ and $\pi_\omega\in[\pi_\omega^-,\pi_\omega^+]$, valid for all $u\in[u_1,u_2]$. Put $[\beta_\omega^-,\beta_\omega^+]=[\min(\pi_\omega^-b_V,\pi_\omega^+b_V),\max(\pi_\omega^-b_V,\pi_\omega^+b_V)]$.

**Definition 20** (vertex envelope). $\Phi_V(y)=\sum_\omega\max(\eta_\omega^++\beta_\omega^+y,\ -\eta_\omega^--\beta_\omega^-y)$ for $y\ge0$, and $\Phi_V(y)=\sum_\omega\max(\eta_\omega^++\beta_\omega^-y,\ -\eta_\omega^--\beta_\omega^+y)$ for $y<0$.

**Lemma 21** (envelope). *$F_V(y)\le\Phi_V(y)$ for all $y\in\mathbb{R}$ and all $u\in[u_1,u_2]$. On each closed half-line, $\Phi_V$ is continuous and piecewise linear, with breakpoints among the points where the two lines of one summand cross.*

*Proof.* $F_V(y)=\sum_\omega\pi_\omega|y_\omega+b_Vy|=\sum_\omega|\pi_\omega y_\omega+\pi_\omega b_V\,y|$ and $|z|=\max(z,-z)$. For $y\ge0$: $\pi_\omega y_\omega+\pi_\omega b_Vy\le\eta_\omega^++\beta_\omega^+y$ and $-\pi_\omega y_\omega-\pi_\omega b_Vy\le-\eta_\omega^--\beta_\omega^-y$, since $\pi_\omega b_V\in[\beta_\omega^-,\beta_\omega^+]$ (whatever the sign of $b_V$). For $y<0$ the roles of $\beta^\pm$ are exchanged. ◻

**Definition 22** (vertex certificate). Let $X$ be a parameter box, $\sigma$ a sign vector, $[u_1,u_2]$ a $u$-interval, $m^*\in(0,1]$ a cap, and $p^*<0$ optional. A *vertex certificate for $(X,\sigma,[u_1,u_2],m^*,p^*)$* is a vertex set $(n_0,(V_\epsilon))$ for $X$ and coefficient vectors $c^{(\epsilon)}\in\mathbb Q^{D+1}$, $D\le10$, with $P_\epsilon(y)=\sum_nc^{(\epsilon)}_ny^n$, such that for every $\epsilon$: (W1) $P_\epsilon(y)>\Phi_{V_\epsilon}(y)$ for all $y\in\mathbb{R}$; and (W2) $c^{(\epsilon)}$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,T^-(u_1,u_2))$.

(W1) is checked as follows: on each half-line, $\Phi_V$ coincides on each interval between consecutive breakpoints with one line $\lambda_0+\lambda_1y$ (one choice of line per summand); for every such line, $P_\epsilon-\lambda_0-\lambda_1y$ is shown to be positive on all of $\mathbb{R}$ by Sturm sequences.

**Lemma 23** (vertex certificate lemma). *Let a vertex certificate for $(X,\sigma,[u_1,u_2],m^*,p^*)$ be given. Let $\mathcal Z$ be the class of random variables $Z=\sum\beta_i\chi_i'$ (finite sums of i.i.d. copies of $\chi$, independent of $\chi_1,\dots,\chi_k$) with $\sum\beta_i^2=1$, $\max|\beta_i|\le m^*$ and, if $p^*$ is given, $p_3\le p^*$. Then for every $u\in[u_1,u_2]$, every $\xi\in X$ and every $Z\in\mathcal Z$, $$\mathbb{E}F_{p(\xi)}(Z)<T^-(u_1,u_2)\le T(u).$$*

*Proof.* By Lemma 19, $p(\xi)=\sum\nu_\epsilon V_\epsilon$ with $\nu\ge0$ and $\sum\nu_\epsilon\le1$. By Lemmas 16 and 21 and (W1), for every $y$, $F_{p(\xi)}(y)\le\sum_\epsilon\nu_\epsilon F_{V_\epsilon}(y)\le\sum_\epsilon\nu_\epsilon P_\epsilon(y)$. Taking expectations over $Z$, $\mathbb{E}F_{p(\xi)}(Z)\le\sum_\epsilon\nu_\epsilon\mathbb{E}P_\epsilon(Z)$. By (W1) and Lemma 21, $\mathbb{E}P_\epsilon(Z)>\mathbb{E}F_{V_\epsilon}(Z)\ge0$, and by (W2) and Lemma 14, $\mathbb{E}P_\epsilon(Z)<T^-$. Since $\sum\nu_\epsilon\le1$ and $\max_\epsilon\mathbb{E}P_\epsilon(Z)\ge0$, $\sum_\epsilon\nu_\epsilon\mathbb{E}P_\epsilon(Z)\le\max_\epsilon\mathbb{E}P_\epsilon(Z)<T^-$. Finally $T^-\le T(u)$ by (2). ◻

*Remark 24*. Compared with the box certificates of Theorem 3, the envelope here is taken only over $u$ (the vertices are fixed vectors), and the parameters $(t,r)$ enter only through the cone condition (P4). So the loss of the certificate is the variation of $F$ over a polytope that hugs the patch, rather than a first-order interval overestimate in $(t,r)$; in our runs this allowed boxes about eight times larger in $t$ and $r$ near $q_4$.

## Boxes

A *box* is $B=[u_1,u_2]\times[t_1,t_2]\times[r_1,r_2]$ with rationals $1<u_1<u_2$, $0\le t_1<t_2\le1$, $0\le r_1<r_2\le1$, together with a sign $s$. Let $b^-$ be a rational lower bound of $\sqrt{1-r_2^2}$ ($b^-=0$ if $r_2=1$), and define $\bar m(B)=1$ if $b^-=0$ or $r_2d(t_2)\ge b^-$, and $\bar m(B)=r_2d(t_2)/b^-$ otherwise. Then $\bar m(B)\in(0,1]$ and $m\le\min(1,a_2/b)\le\bar m(B)$ at every point of $B$ with $r<1$, because $a_2=rd(t)\le r_2d(t_2)$ and $b\ge b^-$. A box of kind <span class="sans-serif">lpv</span> carries a vertex certificate for $([t_1,t_2]\times[r_1,r_2],(1,s),[u_1,u_2],\bar m(B),-)$.

**Lemma 25**. *At every point of an <span class="sans-serif">lpv</span> box with $r<1$, $\mathbb{E}|L|<T$.*

*Proof.* By Lemma 17, $\mathbb{E}|L|=\mathbb{E}F_{p_2(t,r)}(M)$, and $M\in\mathcal Z$ since $m\le\bar m(B)$. Apply Lemma 23. ◻

# Near $(e_1+e_2)/\sqrt2$: the near-circle lemma

**Lemma 26** (tail bound). *Let $y\in\mathbb{R}$, $b\ge0$ and let $Z$ be a random variable with $\mathbb{E}Z=0$ and $\mathbb{E}Z^4<\infty$. Then $$\mathbb{E}|y+bZ|\le|y|+\min\Big(b\,\mathbb{E}|Z|,\ \frac{27}{128}\,\frac{b^4\mathbb{E}Z^4}{|y|^3}\Big),$$ where for $y=0$ the minimum is read as its first entry. The same convention is used below whenever this bound is applied at a point where $y=0$.*

*Proof.* The first bound is the triangle inequality. For the second ($y\ne0$), $|y+z|-|y|-\operatorname{sgn}(y)z=2(-\operatorname{sgn}(y)z-|y|)_+\le2(|z|-|y|)_+$, and $\mathbb{E}[\operatorname{sgn}(y)bZ]=0$. For $x\ge0$ and $\eta>0$, $(x-\eta)_+\le\frac{27}{256}x^4/\eta^3$: the maximum of $(x-\eta)/x^4$ over $x>\eta$ is at $x=\frac43\eta$ and equals $\frac{27}{256}\eta^{-3}$. Hence $\mathbb{E}|y+bZ|-|y|\le2\cdot\frac{27}{256}\,b^4\mathbb{E}Z^4/|y|^3$. ◻

**Lemma 27** (near-circle tests). *Let $B$ be a box with $r_1>0$. Let $y_j$ ($j=1,\dots,4$) be the atoms of $c\chi_1+sd\chi_2$, so that the atoms of $a_1\chi_1+sa_2\chi_2$ are $ry_j$. Let $\eta_j\ge0$ be a lower bound of $|y_j|$ on $B$, $p_j^+$ an upper bound of $p_j$, $b^+$ an upper bound of $\sqrt{1-r_1^2}$, and $E_4=3+\max(0,w^+-4)\,\bar m(B)^2$. Let $T^-=T^-(u_1,u_2)$.*

1.  *If all $\eta_j>0$ and $\frac{27}{128}E_4(b^+)^2\frac{1+r_2}{r_1^3}\sum_jp_j^+\eta_j^{-3}<T^-$, then $\mathbb{E}|L|<T$ at every point of $B$ with $r<1$ and $q\le q_3$.*

2.  *Let $G^+$ be an upper bound of $\mathbb{E}|c\chi_1+sd\chi_2|=\tau\sum_j|g_j|$ on $B$ with $G^+\le T^-$, and $e_j^+=\min\big(b^+,\frac{27}{128}(b^+)^4E_4/(r_1^3\eta_j^3)\big)$ ($e_j^+=b^+$ if $\eta_j=0$). If $\sum_jp_j^+e_j^+<T^-(1-r_2)+r_1(T^--G^+)$, then $\mathbb{E}|L|<T$ at every point of $B$ with $r<1$.*

*Proof.* At a point of $B$ with $r<1$, condition on $(\chi_1,\chi_2)$ and apply Lemma 26 with $Z=M$. Here $\mathbb{E}M^4=3+\kappa_4p_4\le E_4$ by Lemma 10, since $p_4\le m^2\le\bar m(B)^2$ and $\kappa_4=w-4\le w^+-4$; also $\mathbb{E}|M|\le1$. This gives $\mathbb{E}|L|\le rG+\sum_jp_je_j$, where $G=\mathbb{E}|c\chi_1+sd\chi_2|$ and $e_j=\min(b,\frac{27}{128}b^4E_4/(r^3|y_j|^3))$. (A) By Lemma 5 ($q\le q_3$), $G\le T$. Since $1-r=b^2/(1+r)$ and $b>0$, $\sum_jp_je_j\le\frac{27}{128}\frac{b^4E_4}{r^3}\sum_j\frac{p_j}{|y_j|^3}
\le b^2\cdot\frac{27}{128}E_4(b^+)^2\frac{1}{r_1^3}\sum_j\frac{p_j^+}{\eta_j^3}
<\frac{b^2T^-}{1+r_2}\le T(1-r)$. So $\mathbb{E}|L|<rT+T(1-r)=T$. (B) $\mathbb{E}|L|\le rG^++\sum_jp_j^+e_j^+<rG^++T^-(1-r_2)+r_1(T^--G^+)\le rG^++T^-(1-r)+r(T^--G^+)=T^-\le T$, using $r_1\le r\le r_2$ and $T^--G^+\ge0$. ◻

Boxes of kind <span class="sans-serif">ncA</span> pass test (A) or test (B). In our range $q<q_3$, so (A) applies.

# Near the extremisers: the $m$-split

The extremiser $(e_1+e_2+e_3)/\sqrt3$ is, in our coordinates, the point $a_1=a_2=b=1/\sqrt3$ with $M=\chi_3$, so $m=1$; at $q_4$ the second extremiser $(e_1+e_2+e_3+e_4)/2$ is the point $a_1=a_2=\frac12$, $b=\frac1{\sqrt2}$ with $M=(\chi_3+\chi_4)/\sqrt2$, so $m=\frac1{\sqrt2}$. In both cases equality holds, so no certificate with a strict bound can contain these points. As in Theorem 3 we split according to $m=\max_{i\ge3}|\beta_i|$ and the sign of a largest remaining coefficient; in addition, after removing a coefficient $+m$, we split the new remainder once more.

## Three split coordinates

**Lemma 28** (three-coordinate near-sphere bound). *Consider a point with $r<1$ and suppose $\beta_{i_0}=+m$ for some $i_0\ge3$. Put $a_3=bm$, $b'=b\sqrt{1-m^2}$, $Y=a_1\chi_1+sa_2\chi_2+a_3\chi_{i_0}$ with atoms $y_j$ and probabilities $p_j$ ($j=1,\dots,8$), $r'=\sqrt{a_1^2+a_2^2+a_3^2}=\sqrt{1-b'^2}$ and $E_4'=3+\max(0,\kappa_4)$. Then $$\mathbb{E}|L|\le\mathbb{E}|Y|+\sum_jp_j\min\Big(b',\ \frac{27}{128}\frac{b'^4E_4'}{|y_j|^3}\Big).$$ If moreover $q\in[q_U,q_L]$, all $y_j\ne0$ and $\frac{27}{128}E_4'\,b'^2(1+r')\sum_jp_j|y_j|^{-3}<T$, then $\mathbb{E}|L|<T$ if $b'>0$, and if $b'=0$ then $\mathbb{E}|L|=G_3(a_1,sa_2,a_3)\le T$.*

*Proof.* If $m=1$ then $b'=0$ and $L=Y$. Otherwise $L=Y+b'M'$ with $M'$ as in Lemma 17. Then $M'$ is independent of $Y$, $\sum\beta_i'^2=1$ and $\sum\beta_i'^4\le1$, so $\mathbb{E}M'^4=3+\kappa_4\sum\beta_i'^4\le E_4'$ by Lemma 10. Conditioning on $(\chi_1,\chi_2,\chi_{i_0})$ and applying Lemma 26 with $Z=M'$ (and $\mathbb{E}|M'|\le1$) gives the first bound. By Lemma 6, $\mathbb{E}|Y|=G_3(a_1,sa_2,a_3)\le Tr'$. If $b'>0$, the hypothesis and $1-r'=b'^2/(1+r')$ give $\sum_jp_j\frac{27}{128}\frac{b'^4E_4'}{|y_j|^3}<T\frac{b'^2}{1+r'}=T(1-r')$, hence $\mathbb{E}|L|<Tr'+T(1-r')=T$. ◻

#### Piece tests (A3), (B3).

Let $B$ be a box with $b^->0$ and $[m_1,m_2]\subset(0,1]$. On $B\times[m_1,m_2]$ we enclose $a_1=rc(t)$, $a_2=rd(t)$, $a_3=bm\in[b^-m_1,b^+m_2]$, $b'^2\le(b'^2)^+:=(b^+)^2(1-m_1^2)$, and $r'\le r'^+:=\min\big(1,\sqrt{1-(b^-)^2(1-m_2^2)}\big)$ (recall $r'^2=1-b^2(1-m^2)$). The atoms $y_j=a_1x_{j1}+sa_2x_{j2}+a_3x_{j3}$ ($x\in\{u,-v\}^3$) and the products $p_jy_j=\tau\sum_i(\pm a_i)\prod_{l\ne i}\Pr[x_{jl}]$ (by $qu=(1-q)v=\tau$) are enclosed in interval arithmetic. Let $\eta_j$ be a lower bound of $|y_j|$, $p_j^+$ an upper bound of $p_j$, and $E_4'^+=3+\max(0,w^+-4)$. The piece passes

- test (A3) if all $\eta_j>0$ and $\frac{27}{128}E_4'^+(b'^2)^+(1+r'^+)\sum_jp_j^+\eta_j^{-3}<T^-(u_1,u_2)$;

- test (B3) if $\sum_j\big(|p_jy_j|^++p_j^+\min\big(b'^+,\frac{27}{128}((b'^2)^+)^2E_4'^+/\eta_j^3\big)\big)<T^-(u_1,u_2)$, where $|p_jy_j|^+$ is an upper bound of $|p_jy_j|$, $b'^+$ an upper bound of $\sqrt{(b'^2)^+}$, and the second entry of the minimum is omitted if $\eta_j=0$.

By Lemma 28, if a piece passes (A3), then at every point of $B$ with $q\in[q_U,q_L]$ and every remainder with $\beta_{i_0}=+m$, $m\in[m_1,m_2]$, we have $\mathbb{E}|L|<T$ if $b'>0$, and $\mathbb{E}|L|=G_3(a_1,sa_2,bm)\le T$ if $b'=0$. If it passes (B3), then $\mathbb{E}|L|<T$ by the first bound of Lemma 28 alone ($\mathbb{E}|Y|=\sum_j|p_jy_j|$).

**Definition 29** (pieces of type <span class="sans-serif">TC</span> and <span class="sans-serif">SG</span>). Let $B$ be a box with $b^->0$, sign $s$, and $[m_1,m_2]\subset(0,1]$.

- A <span class="sans-serif">TC</span> piece with sign $s_3\in\{1,-1\}$ is a rational cap $\kappa\in(0,1]$ with $\kappa\ge\min(1,m_2/\sqrt{1-m_2^2})$ (that is, $\kappa=1$, or $m_2<1$ and $\kappa^2(1-m_2^2)\ge m_2^2$), and a vertex certificate for $([t_1,t_2]\times[r_1,r_2]\times[m_1,m_2],(1,s,s_3),[u_1,u_2],\kappa,-)$.

- An <span class="sans-serif">SG</span> piece (for $s_3=-1$) is a rational $p^*$ with $2m_1^2>1$ and $\varphi(m_1)\le p^*<0$, a rational cap $\kappa\in(0,1]$ with $\kappa\ge\min(m_2,\bar m(B))$, and a vertex certificate for $([t_1,t_2]\times[r_1,r_2],(1,s),[u_1,u_2],\kappa,p^*)$.

**Lemma 30**. *Let $B$ be a box with $b^->0$ and consider a point of $B$ with $r<1$ whose remainder has $m=\max_{i\ge3}|\beta_i|\in[m_1,m_2]$ and $\beta_{i_0}=s_3m$.*

1.  *If $[m_1,m_2]$ carries a <span class="sans-serif">TC</span> piece with sign $s_3$, then $\mathbb{E}|L|<T$.*

2.  *If $s_3=-1$ and $[m_1,m_2]$ carries an <span class="sans-serif">SG</span> piece, then $\mathbb{E}|L|<T$.*

*Proof.* (i) If $m<1$, Lemma 17 gives $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,m)}(M')$ with $\max|\beta_i'|\le\min(1,m/\sqrt{1-m^2})\le\min(1,m_2/\sqrt{1-m_2^2})\le\kappa$, so $M'\in\mathcal Z$ and Lemma 23 applies. If $m=1$, then $m_2=1$ and $\kappa=1$, and $\mathbb{E}|L|=F_{p_3(t,r,1)}(y)$ for every $y$; taking $Z=\chi'$ (one bit, an element of $\mathcal Z$), $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,1)}(Z)<T$ by Lemma 23. (ii) By Lemma 12 with $m_c=m_1$, $p_3\le\varphi(m_1)\le p^*$. Also $m\le m_2$ and $m\le\bar m(B)$, so $m\le\kappa$. Thus $M\in\mathcal Z$, and Lemmas 17 and 23 give $\mathbb{E}|L|<T$. ◻

## Four split coordinates

**Lemma 31** (four-coordinate near-sphere bound). *Consider a point with $r<1$, $\beta_{i_0}=+m$ with $m<1$, and let $M'$ be as in Lemma 17. Suppose $\beta'_{i_1}=+m'$ for some $i_1$, where $m'=\max|\beta_i'|$. Put $a_3=bm$, $b'=b\sqrt{1-m^2}$, $a_4=b'm'$, $b''=b'\sqrt{1-m'^2}$, $Y_4=a_1\chi_1+sa_2\chi_2+a_3\chi_{i_0}+a_4\chi_{i_1}$ with atoms $y_j$ and probabilities $p_j$ ($j=1,\dots,16$), $r''=\sqrt{a_1^2+a_2^2+a_3^2+a_4^2}=\sqrt{1-b''^2}$ and $E_4'=3+\max(0,\kappa_4)$. Then $$\mathbb{E}|L|\le\mathbb{E}|Y_4|+\sum_jp_j\min\Big(b'',\ \frac{27}{128}\frac{b''^4E_4'}{|y_j|^3}\Big).$$ If moreover $q\in[q_4,q_L]$, all $y_j\ne0$ and $\frac{27}{128}E_4'\,b''^2(1+r'')\sum_jp_j|y_j|^{-3}<T$, then $\mathbb{E}|L|<T$ if $b''>0$, and if $b''=0$ then $\mathbb{E}|L|=G_4(a_1,sa_2,a_3,a_4)\le T$.*

*Proof.* If $m'=1$ then $b''=0$ and $L=Y_4$. Otherwise $L=Y_4+b''M''$ with $M''=\sum_{i\ne i_0,i_1}\beta_i''\chi_i$, $\beta_i''=\beta_i'/\sqrt{1-m'^2}$, which is independent of $Y_4$ and has $\sum\beta_i''^2=1$, so $\mathbb{E}M''^4\le E_4'$ and $\mathbb{E}|M''|\le1$. Conditioning on the four bits of $Y_4$ and applying Lemma 26 gives the first bound. By Lemma 7, $\mathbb{E}|Y_4|=G_4(a_1,sa_2,a_3,a_4)\le Tr''$. If $b''>0$, the hypothesis and $1-r''=b''^2/(1+r'')$ give $\mathbb{E}|L|<Tr''+T(1-r'')=T$. ◻

#### Piece tests (A4), (B4).

Let $B$ be a box with $b^->0$, $[m_1,m_2]\subset(0,1]$ and $[n_1,n_2]\subset(0,1]$. On $B\times[m_1,m_2]\times[n_1,n_2]$ (with $m\in[m_1,m_2]$, $m<1$, and $m'\in[n_1,n_2]$) we enclose $a_1,a_2,a_3$ as in (A3), $b'^2\in[(b^-)^2(1-m_2^2),(b^+)^2(1-m_1^2)]$, $b'$ by the square roots of these bounds, $a_4=b'm'\in[b'^-n_1,b'^+n_2]$, $b''^2\le(b''^2)^+:=(b'^2)^+(1-n_1^2)$, and $r''\le r''^+:=\min\big(1,\sqrt{1-(b'^2)^-(1-n_2^2)}\big)$. The 16 atoms and the products $p_jy_j$ are enclosed as in (A3). The piece passes

- test (A4) if all $\eta_j>0$ and $\frac{27}{128}E_4'^+(b''^2)^+(1+r''^+)\sum_jp_j^+\eta_j^{-3}<T^-(u_1,u_2)$;

- test (B4) if $\sum_j\big(|p_jy_j|^++p_j^+\min\big(b''^+,\frac{27}{128}((b''^2)^+)^2E_4'^+/\eta_j^3\big)\big)<T^-(u_1,u_2)$.

**Definition 32** (pieces of type <span class="sans-serif">TCS</span>). Let $B$ be a box with $b^->0$, sign $s$, and $[m_1,m_2]\subset(0,1]$. A <span class="sans-serif">TCS</span> piece is: a rational cap $\kappa\in(0,1]$ with $\kappa\ge\min(1,m_2/\sqrt{1-m_2^2})$; a rational $m_c'\in(0,1]$ and a rational $p'^*$ with $2m_c'^2>1$ and $\varphi(m_c')\le p'^*<0$; a vertex certificate $\mathcal C'$ for $(X_3,(1,s,1),[u_1,u_2],m_c',-)$ and a vertex certificate $\mathcal C''$ for $(X_3,(1,s,1),[u_1,u_2],\kappa,p'^*)$, where $X_3=[t_1,t_2]\times[r_1,r_2]\times[m_1,m_2]$; and sub-pieces $[n_1,n_2]\subset(0,1]$, each passing (A4) or (B4) (on $B\times[m_1,m_2]\times[n_1,n_2]$), whose union contains $[m_c',\kappa]$.

**Lemma 33**. *Let $[m_1,m_2]$ carry a <span class="sans-serif">TCS</span> piece for $B$. At every point of $B$ with $r<1$ and $q\in[q_4,q_L]$ whose remainder has $\beta_{i_0}=+m$, $m=\max|\beta_i|\in[m_1,m_2]$, we have $\mathbb{E}|L|\le T$. Equality forces $q=q_4$, $s=1$ and $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$ for some $i_1\notin\{1,2,i_0\}$.*

*Proof.* If $m=1$: $\mathbb{E}|L|=F_{p_3(t,r,1)}(y)$ for every $y$; take $Z=N^{-1/2}(\chi_1'+\dots+\chi_N')$ with $N^{-1/2}\le m_c'$, which belongs to the class of $\mathcal C'$. Lemma 23 gives $\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,1)}(Z)<T$.

Now let $m<1$ and $m'=\max|\beta_i'|$. By Lemma 17, $$\mathbb{E}|L|=\mathbb{E}F_{p_3(t,r,m)}(M'),\qquad m'\le\min\big(1,m/\sqrt{1-m^2}\big)\le\kappa .$$

- If $m'\le m_c'$: $M'$ is in the class of $\mathcal C'$, and Lemma 23 gives $\mathbb{E}|L|<T$.

- If $m'\ge m_c'$ and $\beta'_{i_1}=-m'$ for some $i_1$: by Lemma 12, $p_3(M')\le\varphi(m_c')\le p'^*$, and $m'\le\kappa$, so $M'$ is in the class of $\mathcal C''$, and $\mathbb{E}|L|<T$.

- Otherwise $\beta'_{i_1}=+m'$ for some $i_1$, with $m'\in[m_c',\kappa]$, so $m'$ lies in a sub-piece $[n_1,n_2]$, and $m\in[m_1,m_2]$. If the sub-piece passes (B4), Lemma 31 (first bound) gives $\mathbb{E}|L|<T$. If it passes (A4), Lemma 31 gives $\mathbb{E}|L|<T$ when $b''>0$, and $\mathbb{E}|L|=G_4(c)\le T$ with $c=(a_1,sa_2,a_3,a_4)$, $|c|=1$, when $b''=0$.

In the last case with $b''=0$ (so $m'=1$ and $a_4=b'>0$, as $m<1$), equality means $G_4(c)=T|c|$. All entries of $c$ are nonzero ($a_1>0$, $a_2\ge|\alpha_{i_0}|=a_3=bm>0$, $a_4>0$), so by Lemma 7, $q=q_4$ and $c$ is a positive multiple of $\pm(1,1,1,1)$; since $a_1,a_3,a_4>0$, $s=1$ and $a_1=a_2=a_3=a_4=\frac12$. ◻

## The $m$-split boxes

**Definition 34** ($m$-split box). An $m$-split box (kind <span class="sans-serif">ms5</span>) is a box $B$ with sign $s$, $r_2<1$ (so $b^->0$) and $u_1\ge2$, together with: a rational $m_c$ with $0<m_c<\min(1,\bar m(B))$; a vertex certificate $\mathcal C^{(1)}$ for $([t_1,t_2]\times[r_1,r_2],(1,s),[u_1,u_2],m_c,-)$; *plus pieces* $[m_1,m_2]$, each of type (A3), (B3), <span class="sans-serif">TC</span> with $s_3=1$, or <span class="sans-serif">TCS</span>, whose union contains $[m_c,\min(1,\bar m(B))]$; and *minus pieces* $[m_1,m_2]$, each of type <span class="sans-serif">SG</span> or <span class="sans-serif">TC</span> with $s_3=-1$, whose union contains $[m_c,\min(1,\bar m(B))]$.

**Lemma 35** ($m$-split lemma). *Let $B$ be an $m$-split box. At every point of $B$ with $r<1$ and $q\in[q_4,q_L]$ we have $\mathbb{E}|L|\le T$. Equality forces $s=1$ and either $\alpha=\frac1{\sqrt3}(e_1+e_2+e_{i_0})$, or $q=q_4$ and $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$.*

*Proof.* Recall $m\le\min(1,\bar m(B))$. If $m\le m_c$, use $\mathcal C^{(1)}$: by Lemmas 17 and 23, $\mathbb{E}|L|<T$. Let $m\ge m_c$. If $\beta_{i_0}=+m$ for some $i_0$, then $m$ lies in a plus piece. A piece (B3) or <span class="sans-serif">TC</span> gives $\mathbb{E}|L|<T$ (Lemma 30(i) for <span class="sans-serif">TC</span>). A piece (A3) gives $\mathbb{E}|L|<T$ if $b'>0$, and $\mathbb{E}|L|=G_3(a_1,sa_2,b)\le T$ if $b'=0$ (i.e. $m=1$); in the latter case equality forces, by Lemma 6 ($q\in[q_4,q_L]\subset[q_U,q_L]$), $(a_1,sa_2,b)$ to be a positive multiple of $\pm(1,1,1)$, so $s=1$, $a_1=a_2=b=\frac1{\sqrt3}$ and $\beta=e_{i_0}$. A piece <span class="sans-serif">TCS</span> gives $\mathbb{E}|L|\le T$ with equality only as in Lemma 33. Otherwise the maximum $m$ is attained only by negative coefficients, $\beta_{i_0}=-m$, and $m$ lies in a minus piece; Lemma 30 gives $\mathbb{E}|L|<T$. ◻

# Computer verification

All scripts and outputs are in the repository (`scripts/`, `outputs/`). Floating point (HiGHS linear programming via scipy, numpy) is used only to *find* certificates. Every *verification* is exact or uses outward-rounded interval arithmetic.

## Data

The list of data files is `outputs/k3b_manifest.json` ($U_-=\frac{12}5$, $U_+=\frac{127123}{50000}$, $T_8=\frac{41422}{100000}$, $A_S=\frac7{20}$); md5 sums are in `outputs/k3b_MD5SUMS.txt`.

- One-coordinate cells: `outputs/k3b/one_0.json`, `one_1.json`, `one_2.json` ($u\in[\frac{12}5,\frac{247}{100}]$, $[\frac{247}{100},\frac{127}{50}]$, $[\frac{127}{50},U_+]$; 98, 126 and 64 cells, all of degree $10$), covering $u\in[U_-,U_+]$ and $a\in[0,\frac7{20}]$. Widths: $6.2\cdot10^{-4}$ to $0.0175$ in $u$, $0.022$ to $0.044$ in $a$.

- Two-coordinate boxes: `outputs/k3b/b5_i_s.json` for $i=0,\dots,14$ and $s=\pm1$ ($u$-slabs $[\frac{12}5,\frac{241}{100}]$, $[\frac{241}{100},\frac{121}{50}]$, …, $[\frac{253}{100},\frac{127}{50}]$, $[\frac{127}{50},U_+]$), except that the slab $[\frac{253}{100},\frac{127}{50}]$ with $s=+1$ is split into four files `outputs/k3b/sub13_a_1.json`, …, `sub13_d_1.json` of width $\frac1{400}$. For each sign the boxes cover $[U_-,U_+]\times[0,T_8]\times[\frac7{20},1]$. Each file records $K=3$ and $A_S=\frac7{20}$. Each box record has its kind and data: <span class="sans-serif">lpv</span> ($n_0$, the vertices and one coefficient vector per vertex), <span class="sans-serif">ncA</span>, and <span class="sans-serif">ms5</span> ($m_c$, $\mathcal C^{(1)}$ and the pieces, with their vertex certificates, caps, $p^*$ values and sub-pieces).

| sign   | <span class="sans-serif">lpv</span> | <span class="sans-serif">ncA</span> | <span class="sans-serif">ms5</span> | <span class="sans-serif">small</span> | total |
|:-------|------------------------------------:|------------------------------------:|------------------------------------:|--------------------------------------:|------:|
| $s=+1$ |                                 626 |                                  13 |                                 302 |                                     0 |   941 |
| $s=-1$ |                                 480 |                                   0 |                                   0 |                                     0 |   480 |

Two-coordinate boxes for Theorem 4. Widths range from $2.46\cdot10^{-3}$ to $0.01$ in $u$, from $3.2\cdot10^{-3}$ to $0.104$ in $t$ and from $5.1\cdot10^{-3}$ to $0.081$ in $r$. The <span class="sans-serif">ms5</span> boxes use $m_c\in\{\frac25,\frac9{20},\frac12,\frac35,\frac34,\frac45,\frac{17}{20},\frac9{10}\}$ and carry 1 350 pieces: plus pieces 123 (A3), 689 <span class="sans-serif">TC</span>, 210 <span class="sans-serif">TCS</span> (all with $m_c'=\frac{17}{20}$, with 301 sub-pieces, all of type (A4)); minus pieces 146 <span class="sans-serif">SG</span>, 182 <span class="sans-serif">TC</span>. In total there are 2 845 vertex certificates (1 106 <span class="sans-serif">lpv</span>, 302 $\mathcal C^{(1)}$, 871 <span class="sans-serif">TC</span>, 146 <span class="sans-serif">SG</span>, $2\times210$ in <span class="sans-serif">TCS</span>) with 16 544 vertices; all their polynomials have degree $6$.

## Generation

`scripts/run_k3b.sh` runs the 36 jobs of `outputs/k3b/jobs.txt` (about 40 minutes with 8 parallel jobs). A two-coordinate job is `RQ_K=3 RQ_AS=7/20 python3 cover5.py u1 u2 s out.json 1 4 8 16`: it bisects $[u_1,u_2]\times[0,T_8]\times[\frac7{20},1]$ adaptively (4 initial $t$-intervals, 8 $r$-intervals, depth $\le16$) and on each box tries, in order: <span class="sans-serif">small</span>; the near-circle tests (`nearcircle.py`); a vertex certificate (`cert5.py`); from depth 2 on, the $m$-split (`cover5.try_ms5`, with `nsphere3.py` and `cert4.py` for the near-sphere pieces). A vertex set is built from the centre of the parameter box: $n_0$ is a rational approximation of the patch point at the centre with $|n_0|\ge1$, the polytope is a box in an exactly orthogonal rational basis of $n_0^\perp$ that contains the gnomonic projection of a $7^k$ grid of the patch with a relative margin (4%, enlarged to 10% and 25% if the cone check fails), and its corners are the vertices. The coefficient vectors come from a discretised moment linear program (as in Theorem 3, with the objective of Definition 13), rounded to rationals and repaired; (W1), (W2) and (P1)–(P4) are checked exactly before a record is accepted. One-coordinate cells come from `cover_lp10.py` (degree-ten certificates, `tenmom.py`). No box or cell failed.

## Independent verification

`python3 verify_k3b.py` re-checks everything from the data files (93 seconds on 8 cores; output `outputs/verify_k3b_ABCDEFG.txt`, all parts pass). It shares no code with the generators (`cert2c`, `cert4`, `cert5`, `cover5`, `cover_lp10`, `tenmom`, `nsphere3`, `nearcircle`, `exactcert`, `fourbit`); it reuses only the Sturm-sequence, integer-square-root and tiling helpers of `verify_all.py` (the verifier of Theorem 1, audited in A.6). Its parts:

1.  Symbolic identities (sympy). Lemma 9: the cumulants of $\chi$, computed from its moments, are $d^{[j\text{ odd}]}G_j(w)$ for $j=3,\dots,10$. Lemma 10: the recursion reproduces the Gaussian moments, and also the moments of $\chi$ at $u=\frac52$, up to order ten.

2.  Coverage (exact). $\sqrt5<U_-\le\frac{12}5$; $U_+\ge u_4$, checked as $U_+^2>3$ and $(U_+^2-3)^2\ge12$; and $T_8\ge\sqrt2-1$. The 288 cells tile $[U_-,U_+]\times[0,\frac7{20}]$. For each sign the boxes tile $[U_-,U_+]\times[0,T_8]\times[\frac7{20},1]$: they lie in the region, have pairwise disjoint interiors and total volume equal to the volume of the region (a closed subset of full measure is dense, so it is the whole region). Every file has $K=3$ and $A_S=\frac7{20}$.

3.  One-coordinate cells: (V1)–(V3) by Sturm sequences; $\Theta_1>0$; (V4) strictly (Definition 13 re-implemented: the polynomials $\mu_n$ from the recursion, the monomial bounds, and a Sturm count of the roots of $h$ on $[0,\bar m]$ together with $h(0)>0$).

4.  Vertex certificates (all <span class="sans-serif">lpv</span> records and all certificates inside <span class="sans-serif">ms5</span> records: $\mathcal C^{(1)}$, <span class="sans-serif">TC</span>, <span class="sans-serif">SG</span>, and $\mathcal C'$, $\mathcal C''$ of <span class="sans-serif">TCS</span>): (P1) and (P2) exactly; (P3) by exact Gaussian elimination (rank $k$ of each facet, normal vector, orientation by the centre); (P4) by interval bisection of the parameter box against the $2k$ facet normals, with componentwise rational enclosures of the patch (monotonicity of $c,d$ and outward square-root bounds), failing if any sub-box has a facet value with negative upper bound or if more than $20\,000$ sub-boxes are needed; (W1) on every linear piece of every vertex envelope (Definition 20, recomputed from the atom enclosures over $[u_1,u_2]$); (W2) strictly with the target $T^-(u_1,u_2)$. The caps are taken from the structure: $\bar m(B)$ (recomputed exactly) for <span class="sans-serif">lpv</span>, $m_c$ for $\mathcal C^{(1)}$, the recorded cap $\kappa\in(0,1]$ for <span class="sans-serif">TC</span>, <span class="sans-serif">SG</span> and $\mathcal C''$, and $m_c'$ for $\mathcal C'$; the $p^*$ values are those of the records.

5.  Near-circle boxes: mpmath interval arithmetic (120 bits), tests (A)/(B) strictly, with $T^-$ computed from an interval enclosure of $\sqrt3$.

6.  $m$-split structure: $r_2<1$, $u_1\ge2$, $0<m_c<\min(1,\bar m(B))$; the plus pieces and the minus pieces each cover $[m_c,\min(1,\bar m(B))]$; each (A3)/(B3) piece passes its test (mpmath, 120 bits, strict); <span class="sans-serif">TC</span> caps satisfy $\kappa=1$ or $\kappa^2(1-m_2^2)\ge m_2^2$; <span class="sans-serif">SG</span>: $0<m_1\le1$, $2m_1^2>1$, $p^*<0$, $p^*\ge\varphi(m_1)$ (checked as $p^*+m_1^3\ge0$ and $(p^*+m_1^3)^2\ge(1-m_1^2)^3$) and $\kappa\ge\min(m_2,\bar m(B))$; <span class="sans-serif">TCS</span>: the cap condition, the same $\varphi$ check for $(m_c',p'^*)$, the sub-pieces cover $[m_c',\kappa]$, and each sub-piece passes (A4) or (B4) (mpmath, strict).

7.  The claims (C1) and (C2) of Lemmas 6 and 7, for all $2^8$ and all $2^{16}$ functions, exactly as described there, on $[q_U,q_L]$ and $[q_4,q_L]$ with $q_L=1/(1+U_-^2)$, including the lists of equality cases ($\pm$OR of three bits identically; $\pm$OR of four bits at $q_4$ only).

The generator side has its own exact check of the four-bit lemma (`scripts/fourbit.py`, same result).

#### Negative tests.

`python3 break_tests_k3b.py` corrupts random samples of records and runs the check functions of `verify_k3b.py` on them (output `outputs/break_tests_k3b.txt`). Every corruption below is rejected in every case: on 40 <span class="sans-serif">lpv</span> boxes, lowering the constant term of one vertex polynomial by $\frac1{20}$ (domination fails), raising it by $1$ (the objective bound fails), shrinking the polytope by $10\%$ about its centre (the cone check fails) and moving one vertex by $10^{-6}$ (the hyperplane/parallelepiped check fails); on 25 <span class="sans-serif">ms5</span> boxes, removing one plus piece or one minus piece, and lowering the top of the pieces by $\frac1{100}$ (coverage fails); replacing a <span class="sans-serif">TC</span>/<span class="sans-serif">TCS</span> cap by $m_2$ (43 cases; the cap check fails); lowering an <span class="sans-serif">SG</span> value $p^*$ by $\frac1{100}$ below $\varphi(m_1)$ (25 cases); widening an (A4) sub-piece from $[n_1,n_2]$ to $[n_1/2,n_2]$ (25 cases; the near-sphere test fails); lowering the constant term of a <span class="sans-serif">TC</span> vertex polynomial by $\frac1{20}$ (20 cases); removing one box from the tiling, for each sign. A separate sanity check (not a corruption) confirms on the same 40 boxes that the recomputed cap $\bar m(B)$ is at least $\min(1,a_2/b)$ on the box.

## Reproducing

    pip install numpy scipy sympy mpmath
    cd scripts
    python3 verify_k3b.py          # parts A-G, about 2 minutes on 8 cores
    python3 break_tests_k3b.py     # negative tests
    python3 fourbit.py             # four-bit lemma (generator-side check)
    bash run_k3b.sh                # regenerate all data (about 40 minutes, 8 jobs)

# Proof of Theorem 4

*(a)* By Lemma 3 let $q\in[q_4,q_L]$, i.e. $u\in[U_-,u_4]\subseteq[U_-,U_+]$; then $q<q_3$ and $q\in[q_U,q_L]$. Reduce $\alpha$ as in Section 2.3.

1.  $a_1=1$: $\alpha=e_1$ and $\mathbb{E}|L|=2\tau<T$ (Lemma 4(ii)).

2.  $a_1\le\frac7{20}$: $(u,a_1)$ lies in a cell, and Lemma 15 gives $\mathbb{E}|L|<T$.

3.  $a_1>\frac7{20}$ and $r=1$: $L=a_1\chi_1+sa_2\chi_2$, and Lemma 5 ($q<q_3$) gives $\mathbb{E}|L|<T$.

4.  $a_1>\frac7{20}$ and $r<1$: $(u,t,r)$ lies in a box of the cover for the sign $s$ (part B), since $t\in[0,\sqrt2-1]\subseteq[0,T_8]$ and $r\ge a_1>\frac7{20}$. If it is <span class="sans-serif">lpv</span>, Lemma 25 gives $\mathbb{E}|L|<T$. If it is <span class="sans-serif">ncA</span>, Lemma 27 gives $\mathbb{E}|L|<T$ ($q<q_3$). If it is <span class="sans-serif">ms5</span>, Lemma 35 gives $\mathbb{E}|L|\le T$. (There are no <span class="sans-serif">small</span> boxes.)

So $\mathbb{E}|L|\le T$ always, and $(e_1+e_2+e_3)/\sqrt3$ attains $T$ (Lemma 4, $q<\frac13$). Hence $R(q)=T(q)$. For $q\in[1-q_L,1-q_4]$ use Lemma 3: $R(q)=R(1-q)=2\sqrt3\,q^2\tau$.

*(b)* Equality can occur only in the <span class="sans-serif">ms5</span> case of (4). By Lemma 35, after the reduction, $\alpha=\frac1{\sqrt3}(e_1+e_2+e_{i_0})$, or $q=q_4$ and $\alpha=\frac12(e_1+e_2+e_{i_0}+e_{i_1})$. Undoing the reduction (global sign and permutation) gives the list in (b). Conversely, each listed vector attains $T$ at the stated $q$: $(e_i+e_j+e_k)/\sqrt3$ gives $T$ for $q<\frac13$, and $(e_i+e_j+e_k+e_l)/2$ gives $T_4=T$ at $q_4$ (Lemma 4). For $q\ge\frac12$ use Lemma 3.

*(c)* For $q<q_4<\frac14$, $R(q)\ge\mathbb{E}|\chi_1+\dots+\chi_4|/2=T_4(q)>T(q)$ by Lemma 4 and (iii).$\square$

# Remarks

1.  **The $k=3$ regime is closed.** With Theorem 3, $R(q)=2\sqrt3(1-q)^2\sqrt{q(1-q)}$ holds exactly on $[q_4,q_3]$, which is the largest possible interval (Corollary 1). Both ends are ties: at $q_3$ with $(e_1+e_2)/\sqrt2$, at $q_4$ with $(e_1+\dots+e_4)/2$. Corollary 2 confirms the conjecture $R(q)=2\tau\max_k\sqrt k\,\hat q^{\,k-1}$ (BF3, Stone; RQ-C’s Conjecture S) on $[q_4,1-q_4]$. Its next regime, $k=4$ on $[q_5,q_4]$ with $q_5$ defined by $2\sqrt5(1-q)^4=4(1-q)^3$, is not treated here.

2.  **Where the method is tight.** The $m$-split is used in 302 of the 941 boxes with $s=+1$. <span class="sans-serif">TCS</span> pieces, the only place where the four-bit lemma is used, occur in 93 boxes, all with $u_1\ge2.48$; the slabs between $2.52$ and $2.54$ are the most expensive part of the cover. For $u>u_4$ the four-bit lemma fails, and test (A4) would claim too much; this is why the boxes with $u>u_4$ (up to $U_+$) are used only for $u\le u_4$, and why Lemma 33 and Lemma 35 are stated for $q\ge q_4$.

3.  **Ten moments.** The one-coordinate cells need degree ten: as $a_1\to0$ the remainder becomes Gaussian, and the six-moment Gaussian value $0.888074$ (resp. eight-moment value $0.886410$) exceeds $T(q_4)\approx0.884970$, while the ten-moment value is $0.856068$ (floating-point linear programs over polynomial majorants of $|y|$; numerical, used only to choose the degree). The vertex certificates of the two-coordinate route all have degree $6$; the expectation bound of Definition 13 is used for them as well.

4.  **Status.** Not yet audited. The computer steps have been run twice (generator and independent verifier), and the verifier rejects corrupted data (negative tests above).
