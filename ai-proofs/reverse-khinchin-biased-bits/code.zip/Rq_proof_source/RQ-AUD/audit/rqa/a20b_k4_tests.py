"""RQ-AUD A.20, second script: cross-checks, semantic, adversarial and negative tests for the PROVED parts of RQ-A
MAIN-5 (lem:or, lem:three, lem:four of MAIN_RESULT_K4.tex).  Own code only.

 X  Delta_i(f) from the definition E[f | x_i = 1] - E[f | x_i = 0] (exact Fractions, direct enumeration) against
    the integer polynomials of a20_k4_bits.delta_coeffs, at three rational q in [q5, q4]: all 256 f (n = 3) and
    4,000 f (n = 4, including the OR functions).
 D  level-one duality at rational u: G_n(c) = tau max_f c . Delta(f), exactly (n = 3: all f; n = 4: all 65,536 f).
 S  the lemmas' conclusion, exactly: at rational u in [u4, u5] (then q, tau, T4 = 4u^7/(1+u^2)^4 are rational),
    G_n(c)^2 <= T4^2 |c|^2 for random rational c and for c near the extremisers, n = 3, 4; equality at (1,1,1,1).
 A  adversarial float search: max over unit c of G_n(c)/(T4 |c|), n = 3, 4, 5, at q5, mid, q4 (Nelder-Mead).
 E  endpoint sharpness: lem:three fails just above q4 at (1,1,1); the n = 5 bound of lem:or fails just below q5.
 N  negative tests of the a20 checker: H_f itself on [q5, q4 + 1/1000]; 16 -> 16 - 1e-6; the k = 3 target
    12 (1-q)^4; and (informational) H_f >= 0 on [0, q5].
"""
import os
import sys
import time
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import minimize

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqb'))
from a20_k4_bits import delta_coeffs, H_coeffs, or_table  # noqa: E402
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo  # noqa: E402
from a19_c17_verify import sturm_positive  # noqa: E402

Q5 = 1 - 2 / np.sqrt(5)
Q4 = 1 - np.sqrt(3) / 2


def peval(coeffs, x):
    return sum((Fr(int(c)) * x**k for k, c in enumerate(coeffs)), Fr(0))


def delta_direct(table, n, i, q):
    """E[f | x_i = 1] - E[f | x_i = 0] by enumeration; table[x] = f(x), x = sum_l x_l 2^l"""
    e1 = e0 = Fr(0)
    for x in range(1 << n):
        p = Fr(1)
        for l in range(n):
            if l != i:
                p *= q if (x >> l) & 1 else 1 - q
        if (x >> i) & 1:
            e1 += p * table[x]
        else:
            e0 += p * table[x]
    return e1 - e0


def part_X(rng):
    ok = True
    count = 0
    for n in (3, 4):
        F, deltas = delta_coeffs(n)
        nf = F.shape[0]
        if n == 3:
            sample = list(range(nf))
        else:
            ors = set()
            for S in [(0, 1, 2, 3), (0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)]:
                for sg in (1, -1):
                    t = or_table(n, S, sg)
                    ors.add(int(sum((1 << x) for x in range(16) if t[x] == 1)))
            sample = sorted(ors | set(int(v) for v in rng.integers(0, nf, 4000 - len(ors))))
        for q in (Fr(1, 8), Fr(3, 25), Fr(2, 15)):
            for fi in sample:
                table = [int(v) for v in F[fi]]
                for i in range(n):
                    count += 1
                    if delta_direct(table, n, i, q) != peval(deltas[i][fi], q):
                        ok = False
    print(f"X  Delta_i(f) by direct conditional expectation = polynomial table at q in {{1/8, 3/25, 2/15}}: "
          f"{count} comparisons, {'all equal' if ok else 'MISMATCH'}", flush=True)
    return ok


def atoms(n, u):
    q = 1 / (1 + u * u)
    v = 1 / u
    out = []
    for x in range(1 << n):
        k = bin(x).count('1')
        out.append((q**k * (1 - q)**(n - k), [u if (x >> l) & 1 else -v for l in range(n)]))
    return out


def G_exact(c, at):
    return sum((p * abs(sum((ci * xi for ci, xi in zip(c, xs)), Fr(0))) for p, xs in at), Fr(0))


def part_D(rng):
    ok = True
    tested = 0
    for n, trials in ((3, 60), (4, 12)):
        F, deltas = delta_coeffs(n)
        for t in range(trials):
            u = Fr(int(rng.integers(254, 292)), 100)
            q = 1 / (1 + u * u)
            tau = u / (1 + u * u)
            c = [Fr(int(rng.integers(-300, 301)), 100) for _ in range(n)]
            dq = [[peval(deltas[i][fi], q) for fi in range(F.shape[0])] for i in range(n)]
            best = max(sum((c[i] * dq[i][fi] for i in range(n)), Fr(0)) for fi in range(F.shape[0]))
            G = G_exact(c, atoms(n, u))
            tested += 1
            ok &= G == tau * best
    print(f"D  G_n(c) = tau max_f c . Delta(f) exactly: {tested} random (u, c), n = 3, 4: "
          f"{'all equal' if ok else 'MISMATCH'}", flush=True)
    return ok


def part_S(rng):
    ok = True
    worst = Fr(0)
    tested = 0
    us = [Fr(2543, 1000), Fr(26, 10), Fr(27, 10), Fr(28, 10), Fr(2910, 1000)]
    # u4 = 2.54246 < 2.543 and 2.910 < u5 = 2.91069, so every u here is inside [u4, u5]
    assert all(u * u > 3 + 2 * sqrt_hi(Fr(3)) and u * u < 4 + 2 * sqrt_lo(Fr(5)) for u in us)
    eq_hits = 0
    for u in us:
        T4 = 4 * u**7 / (1 + u * u)**4
        for n in (3, 4):
            at = atoms(n, u)
            cands = [[Fr(int(rng.integers(-400, 401)), 100) for _ in range(n)] for _ in range(150)]
            base = [1] * n
            for _ in range(60):
                cands.append([Fr(b) + Fr(int(rng.integers(-30, 31)), 1000) for b in base])
            if n == 4:
                for _ in range(60):
                    cands.append([Fr(1) + Fr(int(rng.integers(-30, 31)), 1000) for _ in range(3)]
                                 + [Fr(int(rng.integers(-30, 31)), 1000)])
                cands.append([Fr(1)] * 4)
            for c in cands:
                if not any(c):
                    continue
                G = G_exact(c, at)
                lhs, rhs = G * G, T4 * T4 * sum(ci * ci for ci in c)
                tested += 1
                if lhs > rhs:
                    ok = False
                if lhs == rhs:
                    eq_hits += 1
                    ok &= n == 4 and len(set(c)) == 1
                worst = max(worst, lhs / rhs)
    print(f"S  G_n(c)^2 <= T4^2 |c|^2 exactly at u in {{2.543, 2.6, 2.7, 2.8, 2.910}}: {tested} vectors, "
          f"{'no violation' if ok else 'VIOLATION'}; equality in {eq_hits} cases (all c = (1,1,1,1)); largest "
          f"ratio of squares {float(worst):.12f}", flush=True)
    return ok and eq_hits >= len(us)


def float_atoms(n, q):
    u = np.sqrt((1 - q) / q)
    X = np.array([[u if (x >> l) & 1 else -1 / u for l in range(n)] for x in range(1 << n)])
    k = (X > 0).sum(axis=1)
    return X, q**k * (1 - q)**(n - k)


def part_A(rng):
    lines = []
    ok = True
    for q in (Q5, (Q5 + Q4) / 2, Q4):
        T4 = 4 * (1 - q)**3 * np.sqrt(q * (1 - q))
        for n in (3, 4, 5):
            X, p = float_atoms(n, q)
            best, arg = -1.0, None
            for s in range(150):
                x0 = rng.normal(size=n) if s >= 3 else np.ones(n) + 0.05 * rng.normal(size=n)
                r = minimize(lambda c: -float(p @ np.abs(X @ c)) / (np.linalg.norm(c) * T4), x0,
                             method='Nelder-Mead', options={'xatol': 1e-10, 'fatol': 1e-13, 'maxiter': 4000})
                if -r.fun > best:
                    best, arg = -r.fun, r.x / np.linalg.norm(r.x)
            arg = arg * np.sign(arg[np.argmax(np.abs(arg))])
            lines.append(f"q = {q:.6f}, n = {n}: max ratio {best:.10f} at {np.round(np.sort(arg)[::-1], 4)}")
            ok &= best <= 1 + 1e-9
    for s in lines:
        print("A  " + s, flush=True)
    return ok


def part_E():
    import mpmath as mp
    mp.mp.dps = 40
    ok = True
    out = []
    for dq in (mp.mpf('1e-4'), mp.mpf('1e-7')):
        q = 1 - mp.sqrt(3) / 2 + dq
        u = mp.sqrt((1 - q) / q)
        v = 1 / u
        tau = mp.sqrt(q * (1 - q))
        G3 = sum(q**k * (1 - q)**(3 - k) * mp.binomial(3, k) * abs(k * u - (3 - k) * v) for k in range(4))
        r = G3 / mp.sqrt(3) / (4 * (1 - q)**3 * tau)
        out.append(f"q4 + {mp.nstr(dq, 2)}: G_3(1,1,1)/(T4 sqrt3) = {mp.nstr(r, 12)}")
        ok &= r > 1
        q = 1 - 2 / mp.sqrt(5) - dq
        u = mp.sqrt((1 - q) / q)
        v = 1 / u
        tau = mp.sqrt(q * (1 - q))
        G5 = sum(q**k * (1 - q)**(5 - k) * mp.binomial(5, k) * abs(k * u - (5 - k) * v) for k in range(6))
        r = G5 / mp.sqrt(5) / (4 * (1 - q)**3 * tau)
        out.append(f"q5 - {mp.nstr(dq, 2)}: G_5(1,...,1)/(T4 sqrt5) = {mp.nstr(r, 12)}")
        ok &= r > 1
    print("E  " + "; ".join(out), flush=True)
    return ok


def part_N():
    ok = True
    q5lo = 1 - sqrt_hi(Fr(4, 5))
    q5hi = 1 - sqrt_lo(Fr(4, 5))
    q4hi = 1 - sqrt_lo(Fr(3, 4))
    msgs = []
    for n in (3, 4):
        F, deltas, H = H_coeffs(n)
        uniq, inv = np.unique(H, axis=0, return_inverse=True)
        inv = np.ravel(inv)
        counts = np.bincount(inv, minlength=len(uniq))
        H16 = [[Fr(int(c)) for c in row] for row in uniq]
        fail_wide = fail_eps = fail_12 = 0
        below_bad = 0
        eps = Fr(1, 10**6)
        for u_i, row in enumerate(H16):
            m = int(counts[u_i])
            if not any(row):
                fail_eps += m
                fail_12 += m
                continue
            fail_wide += m * (not positive_on(row, q5lo, q4hi + Fr(1, 1000))[0])
            shift = [Fr(0)] * 7
            for j in range(7):
                shift[j] = -eps * __import__('math').comb(6, j) * (-1) ** j
            fail_eps += m * (not positive_on([a + b for a, b in zip(row, shift)], q5lo, q4hi)[0])
            to12 = list(row)
            # replace 16 (1-q)^6 by 12 (1-q)^4
            for j in range(7):
                to12[j] -= 16 * __import__('math').comb(6, j) * (-1) ** j
            for j in range(5):
                to12[j] += 12 * __import__('math').comb(4, j) * (-1) ** j
            fail_12 += m * (not any(to12) or not positive_on(to12, q5lo, q4hi)[0])
            P = list(row)
            while P and P[0] == 0:
                P = P[1:]
            below_bad += m * (not sturm_positive(P, Fr(0), q5hi))
        msgs.append(f"n = {n}: H_f > 0 on [q5, q4 + 1/1000] fails for {fail_wide} f; with 16 - 1e-6 on [q5, q4] "
                    f"fails for {fail_eps} f; with the k = 3 target 12 (1-q)^4 fails for {fail_12} f; "
                    f"H_f/q^j > 0 on [0, q5] fails for {below_bad} f (informational)")
        if n == 3:
            ok &= fail_wide >= 2 and fail_eps >= 2 and fail_12 >= 2
        else:
            ok &= fail_wide >= 8 and fail_eps >= 10 and fail_12 >= 2
    for s in msgs:
        print("N  " + s, flush=True)
    return ok


def main():
    t0 = time.time()
    rng = np.random.default_rng(2026102213)
    ok = part_X(rng)
    ok &= part_D(rng)
    ok &= part_S(rng)
    ok &= part_A(rng)
    ok &= part_E()
    ok &= part_N()
    print(f"RESULT: {'ALL TESTS AS EXPECTED' if ok else 'UNEXPECTED'} ({time.time() - t0:.0f}s)", flush=True)


if __name__ == '__main__':
    main()
