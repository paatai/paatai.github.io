"""RQ-AUD independent verifier for RQ-A MAIN-2, release of 08:27 UTC (MAIN_RESULT_K2): the k = 2 bound
E|sum alpha_i chi_i| <= T = 2 sqrt2 (1-q) tau on the full range q in [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2].

Re-uses RQ-AUD's own checks from a11_main2_verify.py (tilings, one-coordinate cells, LP boxes with my envelope,
near-circle boxes, small boxes) and adds, written from MAIN_RESULT_K2 Lemmas 6, 11, 22-24 (RQ-A code not used):
 G  m-split boxes: b- > 0; 2 m_c^2 > 1 >= m_c; p* < 0 and p* >= phi(m_c) = -m_c^3 + (1-m_c^2)^{3/2} (exact);
    c1 = box certificate with cap min(m_c, mbar) (my envelope + my moment bound);
    c2 = box certificate with cap min(1, mbar) and p3 <= p* (if c3+10c5 >= 0: kappa3 (c3+10c5) p3 <= k3- (c3+10c5) p*);
    pieces (s3 = +1) cover [m_c, min(1, mbar)] and each passes my (A3) or (B3) test (exact rationals, 8 atoms).
 H  three-bit lemma: for all 256 f: {0,1}^3 -> {-1,1}, P_f(q) = 8(1-q)^2 - sum_i Delta_i(f)^2 >= 0 on [q3, q0]
    (factor out mu3 = 3q^2-6q+1 and mu0 = 2q^2-4q+1, Sturm counts for the cofactor), with the equality lists.
Data: s*-files and one_A from k2_data/ (08:19 copy, byte-identical to 08:27), b*-files and one_B from k2_data_v2/;
all md5s are compared with RQ-A's published outputs/k2_MD5SUMS.txt.
"""
import hashlib
import json
import os
import sys
import time
from fractions import Fraction as Fr
from itertools import product
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
import a11_main2_verify as V  # noqa: E402
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo, kappa_ranges, imul, tiles  # noqa: E402

D_OLD = os.path.join(HERE, 'k2_data')
D_NEW = os.path.join(HERE, 'k2_data_v2')
U_LO, T8, A_S = V.U_LO, V.T8, V.A_S
U_HI = Fr(1054691, 500000)


def path_of(fn):
    p = os.path.join(D_NEW, fn)
    return p if os.path.exists(p) else os.path.join(D_OLD, fn)


# ---------------------------------------------------------------- G: m-split boxes
def phi_ok(pstar, mc):
    x = pstar + mc**3
    return pstar < 0 and x >= 0 and x * x >= (1 - mc * mc)**3


def moment_ok_p(c, u1, u2, mstar, T, pstar=None):
    k3, k4, k5, k6, k3sq = kappa_ranges(u1, u2)
    c0, c1, c2, c3, c4, c5, c6 = c
    A = c0 + c2 + 3 * c4 + 15 * c6
    X = c3 + 10 * c5
    if pstar is not None and X >= 0:
        A += k3[0] * X * pstar
        Babs = Fr(0)
    else:
        Babs = max(abs(x) for x in imul(k3, X))
    Chi = imul(k4, c4 + 15 * c6)[1]
    Dabs = max(abs(x) for x in imul(k5, c5))
    Ehi = imul(k6, c6)[1]
    Fhi = max(imul(k3sq, 10 * c6)[1], 0)
    G = Chi + Dabs * mstar + Fhi + (Ehi * mstar * mstar if Ehi > 0 else 0)
    Eneg = Ehi if Ehi < 0 else Fr(0)
    if T - A <= 0:
        return False, "T <= A"
    ok, why = positive_on([T - A, -Babs, -G, Fr(0), -Eneg], lo=Fr(0), hi=mstar)
    return ok, ("" if ok else "moment: " + why)


def dominance_ok(box, s, c):
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = V.b_range(r1, r2)
    X = V.atoms_X(u1, u2, t1, t2, r1, r2, s)
    B = [(p[0] * blo, p[1] * bhi) for p in V.r_probs(u1, u2)]
    for lo, hi, icpt, slope in V.envelope_pieces(X, B):
        ok, why = positive_on([c[0] - icpt, c[1] - slope] + list(c[2:]), lo=lo, hi=hi)
        if not ok:
            return False, "dom: " + why
    return True, ""


def p3_probs(u1, u2):
    """ranges of q^k (1-q)^(3-k), k = number of coordinates equal to u (monotone in u on [1.5, 2.2])"""
    q1, q2 = 1 / (1 + u1 * u1), 1 / (1 + u2 * u2)
    f = lambda q, k: q**k * (1 - q)**(3 - k)
    out = {}
    for k in range(4):
        a, b = f(q1, k), f(q2, k)
        out[k] = (min(a, b), max(a, b))
    return out


def piece_test(box, s, m1, m2, r2v=V.R2_MINE):
    u1, u2, t1, t2, r1, r2 = box
    T = V.T_lo(u1, u2, r2v)
    blo, bhi = V.b_range(r1, r2)
    if blo <= 0:
        return None
    a1 = (r1 * V.cfun(t2), r2 * V.cfun(t1))
    a2 = (r1 * V.dfun(t1), r2 * V.dfun(t2))
    a3 = (blo * m1, bhi * m2)
    bp2 = bhi * bhi * (1 - m1 * m1)
    bp = sqrt_hi(bp2) if bp2 > 0 else Fr(0)
    rp = min(Fr(1), sqrt_hi(1 - blo * blo * (1 - m2 * m2)))
    E4 = 3 + max(Fr(0), u2 * u2 + 1 / (u2 * u2) - 4)
    U, Vn = (u1, u2), (-1 / u1, -1 / u2)
    Vn = (min(Vn), max(Vn))
    pr = p3_probs(u1, u2)
    tau = (u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))
    qq = (1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    om = (u1 * u1 / (1 + u1 * u1), u2 * u2 / (1 + u2 * u2))
    coefs = (a1, a2 if s == 1 else V.ineg(a2), a3)
    atoms = []
    for xs in product((1, 0), repeat=3):
        k = sum(xs)
        y = (Fr(0), Fr(0))
        py = (Fr(0), Fr(0))
        for i in range(3):
            y = V.iadd(y, V.imm(coefs[i], U if xs[i] else Vn))
            other = (Fr(1), Fr(1))
            for j in range(3):
                if j != i:
                    other = V.imm(other, qq if xs[j] else om)
            sgn = (Fr(1), Fr(1)) if xs[i] else (Fr(-1), Fr(-1))
            py = V.iadd(py, V.imm(V.imm(coefs[i], other), V.imm(tau, sgn)))
        atoms.append((pr[k][1], y, py))
    ys = [V.iabs_lo(y) for _, y, _ in atoms]
    if all(y > 0 for y in ys):
        S = sum(p / y**3 for (p, _, _), y in zip(atoms, ys))
        if V.K27 * E4 * bp2 * (1 + rp) * S < T:
            return "A3"
    tot = Fr(0)
    for (p, y, py), yl in zip(atoms, ys):
        e = bp if yl == 0 else min(bp, V.K27 * bp2 * bp2 * E4 / yl**3)
        tot += max(abs(py[0]), abs(py[1])) + p * e
    return "B3" if tot < T else None


def ms_check(args):
    box, s, rec = args
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = V.b_range(r1, r2)
    if blo <= 0:
        return False, "b- = 0", None
    mc, pstar, mtop = Fr(rec['mcut']), Fr(rec['p3max']), Fr(rec['mtop'])
    if not (2 * mc * mc > 1 and mc <= 1):
        return False, "m_c", None
    if not phi_ok(pstar, mc):
        return False, "p* < phi(m_c) or p* >= 0", None
    mbar = V.mbar_of(t2, r2, blo)
    c1 = [Fr(x) for x in rec['c']]
    c2 = [Fr(x) for x in rec['c2']]
    T = V.T_lo(u1, u2, V.R2_MINE)
    ok, why = dominance_ok(box, s, c1)
    if not ok:
        return False, "c1 " + why, None
    ok, why = moment_ok_p(c1, u1, u2, min(mc, mbar), T)
    if not ok:
        return False, "c1 " + why, None
    ok, why = dominance_ok(box, s, c2)
    if not ok:
        return False, "c2 " + why, None
    ok, why = moment_ok_p(c2, u1, u2, min(Fr(1), mbar), T, pstar)
    if not ok:
        return False, "c2 " + why, None
    top = min(Fr(1), mbar)
    pcs = sorted((Fr(p[0]), Fr(p[1])) for p in rec['pieces'] if p[2] == 1)
    reach = mc
    for m1, m2 in pcs:
        if m1 > reach:
            break
        reach = max(reach, m2)
    if mc < top and reach < top:
        return False, f"pieces reach {float(reach)} < {float(top)}", None
    kinds = []
    for m1, m2 in pcs:
        k = piece_test(box, s, m1, m2)
        if k is None:
            return False, f"piece [{float(m1)},{float(m2)}] fails", None
        kinds.append(k)
    return True, "", kinds


# ---------------------------------------------------------------- H: three-bit lemma
def three_bit():
    import sympy as sp
    q = sp.Symbol('q')
    mu3 = sp.Poly(3 * q**2 - 6 * q + 1, q)
    mu0 = sp.Poly(2 * q**2 - 4 * q + 1, q)
    q3lo, q3hi = 1 - sqrt_hi(Fr(2, 3)), 1 - sqrt_lo(Fr(2, 3))
    q0lo, q0hi = 1 - sqrt_hi(Fr(1, 2)), 1 - sqrt_lo(Fr(1, 2))
    R = lambda x: sp.Rational(x.numerator, x.denominator)
    assert mu3.eval(R(q3lo)) > 0 > mu3.eval(R(q3hi)) and mu0.eval(R(q0lo)) > 0 > mu0.eval(R(q0hi))
    pts = list(product((0, 1), repeat=3))
    bad, zero, at3, at0 = 0, [], [], []
    for vals in product((-1, 1), repeat=8):
        f = dict(zip(pts, vals))
        D = []
        for i in range(3):
            e1 = e0 = 0
            for x in pts:
                w = sp.Integer(1)
                for j in range(3):
                    if j != i:
                        w *= q if x[j] else (1 - q)
                if x[i]:
                    e1 += f[x] * w
                else:
                    e0 += f[x] * w
            D.append(sp.expand(e1 - e0))
        P = sp.Poly(sp.expand(8 * (1 - q)**2 - sum(d * d for d in D)), q)
        if P.is_zero:
            zero.append(vals)
            continue
        a = b = 0
        Q = P
        while True:
            qq, rr = sp.div(Q, mu3)
            if rr.is_zero:
                Q, a = qq, a + 1
            else:
                break
        while True:
            qq, rr = sp.div(Q, mu0)
            if rr.is_zero:
                Q, b = qq, b + 1
            else:
                break
        lo, hi = q3lo, q0hi
        n = Q.count_roots(R(lo), R(hi)) if Q.degree() > 0 else 0
        sgn = Q.eval(sp.Rational(1, 4)) * (-1)**a
        if n != 0 or sgn <= 0:
            bad += 1
        if a:
            at3.append(vals)
        if b:
            at0.append(vals)
    return bad, zero, at3, at0, pts


def or_fn(pts, idx):
    return tuple(1 if any(x[i] for i in idx) else -1 for x in pts)


def main():
    t0 = time.time()
    parts = sys.argv[1] if len(sys.argv) > 1 else 'MBFCDEGH'
    allok = True
    man = json.load(open(os.path.join(D_NEW, 'k2_manifest.json')))
    assert Fr(man['U_LO']) == U_LO and Fr(man['U_HI']) == U_HI and Fr(man['T8']) == T8 and Fr(man['A_S']) == A_S
    files = man['one_files'] + man['two_files']
    if 'M' in parts:
        pub = {}
        for line in open(os.path.join(D_NEW, 'k2_MD5SUMS.txt')):
            h, fn = line.split()
            pub[fn.replace('outputs/', '')] = h
        mism = [fn for fn in files + ['k2_manifest.json'] if hashlib.md5(open(path_of(fn), 'rb').read()).hexdigest() != pub.get(fn)]
        print(f"M  md5 of the {len(files) + 1} manifest files vs RQ-A k2_MD5SUMS.txt: {len(mism)} mismatches {mism[:3]}")
        allok &= not mism
    cells = []
    for fn in man['one_files']:
        for cl in json.load(open(path_of(fn)))['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]))
    boxes = {1: [], -1: []}
    for fn in man['two_files']:
        d = json.load(open(path_of(fn)))
        assert d['s'] in (1, -1) and not d['failed']
        for bx in d['boxes']:
            assert bx['s'] == d['s']
            boxes[d['s']].append((tuple(Fr(x) for x in bx['box']), bx['kind'], bx))
    kinds = {}
    for s in (1, -1):
        for _, k, _ in boxes[s]:
            kinds[(s, k)] = kinds.get((s, k), 0) + 1
    print(f"data: {len(cells)} cells; boxes s=+1: {len(boxes[1])}, s=-1: {len(boxes[-1])}; kinds {dict(sorted(kinds.items()))}", flush=True)

    if 'B' in parts:
        ok1 = (U_LO * U_LO - 1)**2 < 2 and U_HI**2 > 2 and (U_HI**2 - 2)**2 > 6
        print(f"B  U_LO < u0, U_HI > u3 = sqrt(2+sqrt6): {ok1}")
        reg1 = (U_LO, U_HI, Fr(0), A_S)
        tok, gap = tiles(reg1, [cl[:4] for cl in cells])
        inside = all(reg1[0] <= cl[0] < cl[1] <= reg1[1] and reg1[2] <= cl[2] < cl[3] <= reg1[3] for cl in cells)
        area = sum((cl[1] - cl[0]) * (cl[3] - cl[2]) for cl in cells) == (reg1[1] - reg1[0]) * (reg1[3] - reg1[2])
        print(f"B  {len(cells)} one-coordinate cells tile {[str(x) for x in reg1]}: {'OK' if tok else 'GAP ' + str(gap)}; inside {inside}; area {area}", flush=True)
        allok &= ok1 and tok and inside and area
        reg3 = (U_LO, U_HI, Fr(0), T8, A_S, Fr(1))
        for s in (1, -1):
            ins, voleq, nov = V.tiling3(reg3, [b[0] for b in boxes[s]])
            print(f"B  s={s:+d}: {len(boxes[s])} boxes inside {ins}; volume sum == region volume {voleq}; overlapping pairs {nov}"
                  f" => {'TILING OK' if ins and voleq and nov == 0 else 'TILING FAIL'}", flush=True)
            allok &= ins and voleq and nov == 0

    if 'F' in parts:
        smalls = [b[0] for s in (1, -1) for b in boxes[s] if b[1] == 'small']
        badsm = [bx for bx in smalls if not (bx[5] * V.cfun(bx[2]) <= A_S)]
        print(f"F  small boxes: {len(smalls)}, violating r2 c(t1) <= 9/20: {len(badsm)}")
        allok &= not badsm

    if 'C' in parts:
        from a9_c11_verify import check_cell_rec as cell1
        with Pool(8) as pool:
            res = pool.map(cell1, [(cl[0], cl[1], cl[2], cl[3], cl[4], V.R2_MINE) for cl in cells], chunksize=4)
        nf = sum(1 for r in res if not r[0])
        print(f"C  one-coordinate cells: failures {nf}/{len(cells)}, max depth {max(r[2] for r in res)}, {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0

    if 'D' in parts:
        lps = [(b[0], s, [Fr(x) for x in b[2]['c']], V.R2_MINE) for s in (1, -1) for b in boxes[s] if b[1] == 'lp']
        with Pool(8) as pool:
            res = pool.map(V.lp_rec, lps, chunksize=16)
        nf = sum(1 for r in res if not r[0])
        depths = {}
        for r in res:
            if r[0]:
                depths[r[2]] = depths.get(r[2], 0) + 1
        for (bx, s, c, _), r in zip(lps, res):
            if not r[0]:
                print(f"   FAIL s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.5f},{float(bx[3]):.5f}] r[{float(bx[4]):.5f},{float(bx[5]):.5f}]: {r[3]}")
        print(f"D  LP boxes: failures {nf}/{len(lps)}; certified at depth {dict(sorted(depths.items()))}, {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0

    if 'E' in parts:
        ncs = [(b[0], s, V.R2_MINE) for s in (1, -1) for b in boxes[s] if b[1].startswith('nc')]
        with Pool(8) as pool:
            res = pool.map(V.nc_rec, ncs, chunksize=16)
        nf = sum(1 for r in res if not r[0])
        how = {}
        for r in res:
            if r[0]:
                how[r[3]] = how.get(r[3], 0) + 1
        print(f"E  near-circle boxes: failures {nf}/{len(ncs)}; passed by test {how}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0

    if 'G' in parts:
        mss = [(b[0], s, b[2]) for s in (1, -1) for b in boxes[s] if b[1] == 'ms']
        with Pool(8) as pool:
            res = pool.map(ms_check, mss, chunksize=8)
        nf = sum(1 for r in res if not r[0])
        npc = sum(len(r[2]) for r in res if r[0])
        kk = {}
        for r in res:
            if r[0]:
                for k in r[2]:
                    kk[k] = kk.get(k, 0) + 1
        for (bx, s, rec), r in zip(mss, res):
            if not r[0]:
                print(f"   FAIL ms s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.5f},{float(bx[3]):.5f}] r[{float(bx[4]):.5f},{float(bx[5]):.5f}]: {r[1]}")
        umin = min(bx[0] for bx, _, _ in mss)
        mcs = sorted({rec['mcut'] for _, _, rec in mss}, key=Fr)
        print(f"G  m-split boxes: failures {nf}/{len(mss)}; pieces {npc} by test {kk}; min u1 = {float(umin):.4f} (>= u0);"
              f" m_c values {mcs}; {time.time() - t0:.0f}s", flush=True)
        allok &= nf == 0 and umin * umin > 1 + V.SQ2_HI

    if 'H' in parts:
        bad, zero, at3, at0, pts = three_bit()
        or2 = {or_fn(pts, ij) for ij in ((0, 1), (0, 2), (1, 2))}
        or2 |= {tuple(-x for x in f) for f in or2}
        or3 = {or_fn(pts, (0, 1, 2)), tuple(-x for x in or_fn(pts, (0, 1, 2)))}
        dic = set()
        for i in range(3):
            f = tuple(1 if x[i] else -1 for x in pts)
            dic |= {f, tuple(-v for v in f)}
        okH = bad == 0 and set(zero) == or2 and set(at3) == or3 and set(at0) == dic
        print(f"H  three-bit lemma: 256 functions, P_f >= 0 on [q3,q0] fails for {bad}; P_f == 0 exactly for {len(zero)} f"
              f" (= +-OR_2: {set(zero) == or2}); P_f(q3) = 0 for {len(at3)} f (= +-OR_3: {set(at3) == or3});"
              f" P_f(q0) = 0 for {len(at0)} f (= +-dictators: {set(at0) == dic})", flush=True)
        allok &= okH

    print(f"RESULT: {'ALL CHECKS PASSED' if allok else 'FAILURES'} (parts {parts}, {time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
