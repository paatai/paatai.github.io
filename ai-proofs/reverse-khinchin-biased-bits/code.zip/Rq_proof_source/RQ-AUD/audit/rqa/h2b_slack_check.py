"""Effect of the sixth-moment slack (mass escaping to infinity) on the six-moment LP of RQ-A N.1.

Without the slack, an LP over measures on [-Y, Y] with EM^6 *equal* to its target can under-estimate
the relaxation (dual leading coefficient lambda_6 < 0).  With the slack, lambda_6 >= 0 is forced.
Reports primal ratio (2 tau a + 2 V)/(2 tau) for both versions and the reduced-cost maximum of the
slack version on the wider window [-60, 60] (a dual upper bound needs it <= 0 off the grid too).
"""
import numpy as np
from h2_moment_lp_colgen import V

q0 = 1 - 1 / np.sqrt(2)
pts = [(q0, 0.73), (q0, 0.85), (q0, 0.9), (q0, 0.7071), (q0, 0.6), (q0, 0.3),
       (0.2935, 0.715), (0.2935, 0.73), (0.2935, 0.9), (0.295, 0.715), (0.295, 0.9),
       (0.30, 0.7071), (0.30, 0.9), (0.32, 0.9), (0.35, 0.85), (0.35, 0.9), (0.375, 0.85),
       (0.42, 0.85), (0.5, 0.6), (0.5, 0.65), (0.5, 0.7), (0.5, 0.75), (0.5, 0.8), (0.5, 0.85)]
for q, a in pts:
    r0 = V(q, a, iters=150)
    r1 = V(q, a, iters=150, slack6=True)
    if r0 is None or r1 is None:
        print(f"q={q:.5f} a={a}: LP failed")
        continue
    flag = 'SLACK RAISES VALUE' if r1['ratio'] > r0['ratio'] + 1e-7 else ''
    viol = 'VIOLATION' if r1['ratio'] > 1 + 1e-9 else ''
    print(f"q={q:.5f} a={a:.4f}: ratio(eq) {r0['ratio']:.9f}  ratio(slack) {r1['ratio']:.9f}"
          f"  maxrc(slack) {r1['maxrc']:.1e}  lead>0 {r1['lead_ok']}  it {r1['it']} {flag} {viol}", flush=True)
