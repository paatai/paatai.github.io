"""End-to-end semantic test of the MAIN-3 certificates (float evidence, exact enumeration of the laws).

Random admissible points are drawn in random boxes/cells, with u restricted to [u3, 12/5] (the claimed range):
u, t, r in the box, s, and a residual M = sum_{i<=m} beta_i chi_i with sum beta_i^2 = 1 and |beta_i| <= mbar = min(1, a2/b)
(m <= 12). E|L| for L = a1 chi_1 + s a2 chi_2 + b M is computed exactly from the 2^(m+2) atoms, T = 2 sqrt3 (1-q)^2 tau, and
  lp box:   E|L| <= E P(M) < T(u);
  nc box:   E|L| <= r G + sum_j p_j min(b, (27/128) b^4 E M^4 / (r |y_j|)^3) <= T(u);
  ms box:   max|beta| <= m_c:            E|L| <= E P_c1(M) < T(u);
            beta_1 = -m, m >= m_c:      p3 <= p*, E|L| <= E P_c2(M) < T(u);
            beta_1 = +m, m >= m_c:      E|L| <= E|Y| + sum_j p_j min(b', (27/128) b'^4 E M'^4/|y_j|^3) <= T(u),
                                        Y = a1 chi_1 + s a2 chi_2 + b m chi_3, b' = b sqrt(1-m^2);
  cell:     L = a chi_1 + sqrt(1-a^2) M, |beta_i| <= min(1, a/b):  E|L| <= 2 a tau + 2 E P(M) < T(u).
The m-split samples include points near the extremiser (a1 = a2 = b = 1/sqrt3, beta = e_1), where the ratio tends to 1.
"""
import json
import os
import sys
from fractions import Fraction as Fr

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
DATA = os.environ.get('K3_DATA', os.path.join(HERE, 'k3_data'))

rg = np.random.default_rng(3141)
U3 = np.sqrt(2 + np.sqrt(6))
UH = 2.4


def law_sum(q, beta):
    u, v = np.sqrt((1 - q) / q), np.sqrt(q / (1 - q))
    xs, ps = np.array([0.0]), np.array([1.0])
    for bi in beta:
        xs = np.concatenate([xs + bi * u, xs - bi * v])
        ps = np.concatenate([ps * q, ps * (1 - q)])
    return xs, ps


def draw_beta(mbar, first=None):
    """unit beta with max |beta_i| <= mbar; if first = +-m is given, beta_1 = first and the rest have |beta_i| <= m"""
    if first is not None:
        m = abs(first)
        rest2 = max(0.0, 1 - m * m)
        if rest2 < 1e-14:
            return np.array([first])
        kmin = max(1, int(np.ceil(rest2 / (m * m) - 1e-12)))
        if kmin > 11:
            return None
        for _ in range(200):
            k = int(rg.integers(kmin, 12))
            rest = np.abs(rg.normal(size=k)) * rg.choice([-1, 1], size=k)
            rest *= np.sqrt(rest2) / np.linalg.norm(rest)
            if np.max(np.abs(rest)) <= m + 1e-12:
                return np.concatenate([[first], rest])
        return None
    mlo = max(1, int(np.ceil(1 / mbar**2 - 1e-12)))
    if mlo > 12:
        return None
    for _ in range(200):
        m = int(rg.integers(mlo, 13))
        beta = np.abs(rg.normal(size=m)) * rg.choice([-1, 1], size=m)
        beta /= np.linalg.norm(beta)
        if np.max(np.abs(beta)) <= mbar + 1e-12:
            return beta
        beta = np.full(m, 1 / np.sqrt(m)) * rg.choice([-1, 1], size=m)
        if 1 / np.sqrt(m) <= mbar + 1e-12:
            return beta
    return None


def poly_exp(c, xm, pm):
    cf = np.array([float(Fr(x)) for x in c])
    return float(pm @ np.polyval(cf[::-1], xm))


def tail_bound(y, p, b, EM4):
    return sum(pj * (min(b, 27 / 128 * b**4 * EM4 / abs(yj)**3) if abs(yj) > 0 else b) for pj, yj in zip(p, y))


def target(u):
    q = 1 / (1 + u * u)
    return 2 * np.sqrt(3) * (1 - q)**2 * np.sqrt(q * (1 - q)), q


def main():
    man = json.load(open(os.path.join(DATA, 'k3_manifest.json')))
    boxes = {'lp': [], 'nc': [], 'ms': []}
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        for bx in d['boxes']:
            k = 'nc' if bx['kind'].startswith('nc') else bx['kind']
            if k in boxes:
                boxes[k].append((tuple(float(Fr(x)) for x in bx['box']), d['s'], bx))
    cells = []
    for fn in man['one_files']:
        for cl in json.load(open(os.path.join(DATA, fn)))['cells']:
            cells.append((float(Fr(cl['u1'])), float(Fr(cl['u2'])), float(Fr(cl['a1'])), float(Fr(cl['a2'])), cl['c']))
    worst, cnt = {}, {}

    def rec(key, val):
        worst[key] = min(worst.get(key, np.inf), val)

    worst_ratio = [0.0, None]
    near = [0, 0.0]
    for kind, nb, reps in (('lp', 3000, 2), ('nc', 2534, 2), ('ms', 21232, 1)):
        pool = boxes[kind]
        idx = rg.choice(len(pool), size=min(nb, len(pool)), replace=False)
        for i in idx:
            (u1, u2, t1, t2, r1, r2), s, bx = pool[i]
            lo_u, hi_u = max(u1, U3), min(u2, UH)
            if lo_u >= hi_u:
                continue
            for _ in range(reps):
                u = lo_u + rg.random() * (hi_u - lo_u)
                t = t1 + rg.random() * (t2 - t1)
                r = r1 + rg.random() * (r2 - r1)
                if r >= 1:
                    continue
                T, q = target(u)
                tau = np.sqrt(q * (1 - q))
                cc, dd = (1 - t * t) / (1 + t * t), 2 * t / (1 + t * t)
                a1, a2, b = r * cc, r * dd, np.sqrt(1 - r * r)
                mbar = min(1.0, a2 / b)
                case = None
                if kind == 'ms':
                    mc = float(Fr(bx['mcut']))
                    if mbar > mc and rg.random() < 3 / 4:
                        m = mc + rg.random() * (mbar - mc)
                        if rg.random() < 0.15:
                            m = mbar
                        case = '+' if rg.random() < 2 / 3 else '-'
                        beta = draw_beta(mbar, first=m if case == '+' else -m)
                    else:
                        case = 'c1'
                        beta = draw_beta(min(mc, mbar))
                else:
                    beta = draw_beta(mbar)
                if beta is None:
                    continue
                xm, pm = law_sum(q, beta)
                x2, p2 = law_sum(q, [a1, s * a2])
                EL = float(p2 @ np.abs(x2[:, None] + b * xm[None, :]) @ pm)
                if EL / T > worst_ratio[0]:
                    worst_ratio[:] = [EL / T, (kind, case, u, a1, s * a2, b, list(np.round(beta, 6)))]
                key = kind + ('' if case is None else ':' + case)
                cnt[key] = cnt.get(key, 0) + 1
                if kind == 'lp' or case in ('c1', '-'):
                    c = bx['c'] if case in (None, 'c1') else bx['c2']
                    if case == '-':
                        rec('ms:- p* - p3', float(Fr(bx['p3max'])) - float(np.sum(beta**3)))
                    EP = poly_exp(c, xm, pm)
                    rec(key + ' E P - E|L|', EP - EL)
                    rec(key + ' T - E P', T - EP)
                elif kind == 'nc':
                    y2, _ = law_sum(q, [cc, s * dd])
                    bound = r * float(p2 @ np.abs(y2)) + tail_bound(r * y2, p2, b, float(pm @ xm**4))
                    rec('nc bound - E|L|', bound - EL)
                    rec('nc T - bound', T - bound)
                else:
                    m = abs(beta[0])
                    bp = b * np.sqrt(max(0.0, 1 - m * m))
                    rest = beta[1:]
                    if len(rest):
                        xr, pr = law_sum(q, rest / np.linalg.norm(rest))
                        EM4 = float(pr @ xr**4)
                    else:
                        EM4 = 0.0
                    y3, p3 = law_sum(q, [a1, s * a2, b * m])
                    bound = float(p3 @ np.abs(y3)) + tail_bound(y3, p3, bp, EM4)
                    rec('ms:+ bound - E|L|', bound - EL)
                    rec('ms:+ T - bound', T - bound)
                    if abs(a1 - 1 / np.sqrt(3)) < 0.02 and abs(a2 - 1 / np.sqrt(3)) < 0.02 and s == 1:
                        near[0] += 1
                        near[1] = max(near[1], EL / T)
    for _ in range(4000):
        u1, u2, A1, A2, c = cells[rg.integers(len(cells))]
        lo_u, hi_u = max(u1, U3), min(u2, UH)
        if lo_u >= hi_u:
            continue
        u = lo_u + rg.random() * (hi_u - lo_u)
        a = A1 + rg.random() * (A2 - A1)
        T, q = target(u)
        tau = np.sqrt(q * (1 - q))
        b = np.sqrt(1 - a * a)
        beta = draw_beta(min(1.0, a / b) if b > 0 else 1.0)
        if beta is None:
            continue
        xm, pm = law_sum(q, beta)
        x1, p1 = law_sum(q, [a])
        EL = float(p1 @ np.abs(x1[:, None] + b * xm[None, :]) @ pm)
        bound = 2 * a * tau + 2 * poly_exp(c, xm, pm)
        if EL / T > worst_ratio[0]:
            worst_ratio[:] = [EL / T, ('cell', None, u, a, list(np.round(beta, 6)))]
        cnt['cell'] = cnt.get('cell', 0) + 1
        rec('cell bound - E|L|', bound - EL)
        rec('cell T - bound', T - bound)
    print(f"sampled admissible points (u in [u3, 12/5]): {dict(sorted(cnt.items()))}")
    for k in sorted(worst):
        print(f"  min({k}) = {worst[k]:+.3e}  ({'OK' if worst[k] >= -1e-12 else 'VIOLATION'})")
    print(f"max E|L|/T over all sampled points: {worst_ratio[0]:.12f} at {worst_ratio[1]}")
    print(f"m-split samples within 0.02 of (1,1,1)/sqrt3 in (a1, a2): {near[0]}, max E|L|/T among them {near[1]:.12f}")
    bad = [k for k in worst if worst[k] < -1e-12]
    print(f"RESULT: {'no violation' if not bad else 'VIOLATIONS ' + str(bad)}")


if __name__ == '__main__':
    main()
