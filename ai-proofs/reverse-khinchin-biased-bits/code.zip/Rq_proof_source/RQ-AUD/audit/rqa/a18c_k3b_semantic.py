"""A.18 semantic end-to-end test of RQ-A's k3b cover (Theorem 4): real unit vectors against the recorded certificates.

For sampled boxes and cells, draw an actual reduced unit vector alpha whose parameters lie in the record's region,
compute E|L| by exact enumeration of the atoms (mpmath, 40 digits), and follow the chain of the lemma that the
record is used with:
  cell (Lemma 15):        E|L| = 2 tau a + 2 E R_a(b1 M1),  E R_a(b1 M1) <= E P(M1) < Theta_1,  E|L| < T
  vertex sets (Lemma 23): E|L| = E F_p(Z) <= sum_e nu_e E F_{V_e}(Z) <= sum_e nu_e E P_e(Z) <= max_e E P_e(Z) < T^-
                          with nu from the parallelepiped coordinates (0 <= mu_i <= lambda <= 1/|n0|)
  A3 / A4 pieces (Lemmas 28, 31): E|L| <= near-sphere bound, and the bound < T when the record's test is A
The roles: lpv (M, cap mbar), c1 (M, m <= m_c), TC plus / minus (M', beta_i0 = +-m), SG (M, beta_i0 = -m, p3 <= p*),
TCS C' (M', m' <= m_c'), TCS C'' (M', beta'_i1 = -m'), A3 (beta_i0 = +m), A4 (beta_i0 = +m, beta'_i1 = +m').
Every sample must satisfy every inequality of its chain; any violation is printed. Floating point (mpmath) is used:
this is a test of the semantics of the data, not a proof.
"""
import json
import os
import random
import sys
from fractions import Fraction as Fr
from itertools import product

import mpmath as mp

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import a18_k3b_verify as A  # noqa: E402

mp.mp.dps = 40
rng = random.Random(20261022)
S3 = mp.sqrt(3)


def mq(x):
    return mp.mpf(x.numerator) / x.denominator if isinstance(x, Fr) else mp.mpf(x)


def dist_of(coefs, u):
    """atoms (prob, value) of sum coefs_i chi_i; equal coefficients are grouped (binomial counts)"""
    groups = {}
    for c in coefs:
        groups[c] = groups.get(c, 0) + 1
    q = 1 / (1 + u * u)
    v = 1 / u
    out = [(mp.mpf(1), mp.mpf(0))]
    for c, k in groups.items():
        law = [(mp.binomial(k, j) * q**j * (1 - q)**(k - j), c * (j * u - (k - j) * v)) for j in range(k + 1)]
        out = [(p * pb, x + xb) for p, x in out for pb, xb in law]
    return out


def e_abs(coefs, u):
    return sum(p * abs(x) for p, x in dist_of(coefs, u))


def e_poly(c, dist):
    return sum(p * sum(mq(cn) * x**n for n, cn in enumerate(c)) for p, x in dist)


def T_of(u):
    return 2 * S3 * (u * u / (1 + u * u))**2 * u / (1 + u * u)


def T_minus(u1, u2):
    return mq(A.T_lo(u1, u2))


def rand_in(lo, hi):
    return lo + (hi - lo) * Fr(rng.randrange(1, 10**6), 10**6)


def remainder(cap, n_max=6, sign_top=None, top=None):
    """random unit beta with max |beta| <= cap (mpf list). If top is given, beta_0 = sign_top * top is the largest
    entry in absolute value (ties allowed) and the rest has max <= top."""
    for _ in range(400):
        n = rng.randint(1, n_max)
        if top is None:
            raw = [mp.mpf(rng.uniform(-1, 1)) for _ in range(n)]
            nrm = mp.sqrt(sum(x * x for x in raw))
            if nrm == 0:
                continue
            beta = [x / nrm for x in raw]
            if max(abs(x) for x in beta) <= cap:
                return beta
        else:
            rest2 = 1 - top * top
            if rest2 < 0:
                return None
            if rest2 == 0:
                return [sign_top * top]
            raw = [mp.mpf(rng.uniform(-1, 1)) for _ in range(n)]
            nrm = mp.sqrt(sum(x * x for x in raw))
            if nrm == 0:
                continue
            rest = [x / nrm * mp.sqrt(rest2) for x in raw]
            if max(abs(x) for x in rest) <= top:
                return [sign_top * top] + rest
    k = int(mp.ceil(1 / (min(cap, 1 if top is None else top))**2)) + 1
    if k > 400:
        return None
    if top is None:
        return [mp.mpf(1) / mp.sqrt(k)] * k
    rest2 = 1 - top * top
    kk = max(1, int(mp.ceil(rest2 / top**2)) + 1)
    return [sign_top * top] + [mp.sqrt(rest2 / kk)] * kk


def p3_of(beta):
    return sum(x**3 for x in beta)


def nu_of(n0, Vs, p):
    k = len(Vs[0]) - 1
    V0 = [mq(x) for x in Vs[0]]
    E = []
    for i in range(k):
        idx = 1 << (k - 1 - i)
        E.append([mq(a) - b for a, b in zip(Vs[idx], V0)])
    Mx = mp.matrix(k + 1, k + 1)
    for row in range(k + 1):
        Mx[row, 0] = V0[row]
        for i in range(k):
            Mx[row, i + 1] = E[i][row]
    sol = mp.lu_solve(Mx, mp.matrix(p))
    lam = sol[0]
    mu = [sol[i + 1] for i in range(k)]
    nrm = mp.sqrt(sum(mq(x)**2 for x in n0))
    ok = lam >= -mp.mpf(10)**-30 and lam <= 1 / nrm + mp.mpf(10)**-30 and \
        all(-mp.mpf(10)**-30 <= m_ <= lam + mp.mpf(10)**-30 for m_ in mu)
    nus = []
    for eps in product((0, 1), repeat=k):
        w = lam
        for i, e in enumerate(eps):
            th = mu[i] / lam
            w *= th if e else (1 - th)
        nus.append(w)
    return ok, nus, lam


def vertex_chain(rec, patch, sigma, Zcoefs, u, u1, u2, EL, tag, fails):
    """E|L| = E F_patch(Z); check the Lemma 23 chain for the record."""
    ok, nus, lam = nu_of(rec['n0'], rec['V'], patch)
    if not ok:
        fails.append((tag, 'cone (nu)'))
        return
    Zd = dist_of(Zcoefs, u)
    FP = sum(pz * e_abs_shift([s * x for s, x in zip(sigma, patch[:-1])], patch[-1] * z, u) for pz, z in Zd)
    if abs(FP - EL) > mp.mpf(10)**-25:
        fails.append((tag, f'E F_p(Z) = {mp.nstr(FP, 12)} != E|L| = {mp.nstr(EL, 12)}'))
    FV, PV = [], []
    for V, c in zip(rec['V'], rec['C']):
        V = [mq(x) for x in V]
        FV.append(sum(pz * e_abs_shift([s * x for s, x in zip(sigma, V[:-1])], V[-1] * z, u) for pz, z in Zd))
        PV.append(e_poly([Fr(x) for x in c], Zd))
    s1 = sum(n * f for n, f in zip(nus, FV))
    s2 = sum(n * p for n, p in zip(nus, PV))
    Tm = T_minus(u1, u2)
    chain = [FP <= s1 + mp.mpf(10)**-25, s1 <= s2 + mp.mpf(10)**-25, all(f <= p for f, p in zip(FV, PV)),
             s2 <= max(PV) + mp.mpf(10)**-25, max(PV) < Tm, Tm <= T_of(u)]
    if not all(chain):
        fails.append((tag, f'chain {chain} FP={mp.nstr(FP, 10)} s1={mp.nstr(s1, 10)} s2={mp.nstr(s2, 10)}'
                           f' maxP={mp.nstr(max(PV), 10)} T-={mp.nstr(Tm, 10)}'))
    return float(Tm - max(PV)), float(Tm - EL)


def e_abs_shift(coefs, shift, u):
    return sum(p * abs(x + shift) for p, x in dist_of(coefs, u))


def cfun(t):
    return (1 - t * t) / (1 + t * t)


def dfun(t):
    return 2 * t / (1 + t * t)


def sample_point(bx):
    b = [Fr(x) for x in bx['box']]
    u = rand_in(b[0], b[1])
    t = rand_in(b[2], min(b[3], Fr(41421356, 10**8)))
    r = rand_in(b[4], b[5])
    return b, u, t, r


def main():
    nlpv = int(sys.argv[1]) if len(sys.argv) > 1 else 150
    man, cells, boxes = A.load()
    fails, stats = [], {}

    def note(tag, res):
        if res:
            st = stats.setdefault(tag, [0, 1e9, 1e9])
            st[0] += 1
            st[1] = min(st[1], res[0])
            st[2] = min(st[2], res[1])

    # cells
    for (u1, u2, alo, ahi, c) in rng.sample(cells, 60):
        u = rand_in(u1, u2)
        a = rand_in(alo, ahi)
        um, am = mq(u), mq(a)
        b1 = mp.sqrt(1 - am * am)
        beta = remainder(min(mp.mpf(1), am / b1))
        if beta is None:
            continue
        alpha = [am] + [b1 * x for x in beta]
        EL = e_abs(alpha, um)
        tau = um / (1 + um * um)
        M1 = dist_of(beta, um)
        q = 1 / (1 + um * um)
        ER = sum(p * max(0, (1 - q) * (b1 * x - am / um), q * (-b1 * x - am * um)) for p, x in M1)
        EP = e_poly(c, M1)
        th1 = mq(u2 / (1 + u2 * u2) * (A.S3 * (u1 * u1 / (1 + u1 * u1))**2 - ahi))
        ok = [abs(EL - (2 * tau * am + 2 * ER)) < mp.mpf(10)**-25, ER <= EP, EP < th1, EL < T_of(um)]
        if not all(ok):
            fails.append(('cell', f'{ok}'))
        note('cell', (float(th1 - EP), float(T_of(um) - EL)))

    lpvs = [bx for bx in boxes if bx['kind'] == 'lpv']
    for bx in rng.sample(lpvs, min(nlpv, len(lpvs))):
        b, u, t, r = sample_point(bx)
        if r >= 1:
            continue
        um, tm, rmm = mq(u), mq(t), mq(r)
        a1, a2, bb = rmm * cfun(tm), rmm * dfun(tm), mp.sqrt(1 - rmm * rmm)
        blo, _ = A.V.b_range(b[4], b[5])
        mb = mq(A.V.mbar_of(b[3], b[5], blo))
        beta = remainder(min(mp.mpf(1), a2 / bb, mb))
        if beta is None:
            continue
        s = bx['s']
        alpha = [a1, s * a2] + [bb * x for x in beta]
        EL = e_abs(alpha, um)
        note('lpv', vertex_chain(bx, [a1, a2, bb], [1, s], beta, um, b[0], b[1], EL, 'lpv', fails))

    ms5 = [bx for bx in boxes if bx['kind'] == 'ms5']
    for bx in ms5:
        b, u, t, r = sample_point(bx)
        um, tm, rmm = mq(u), mq(t), mq(r)
        a1, a2, bb = rmm * cfun(tm), rmm * dfun(tm), mp.sqrt(1 - rmm * rmm)
        s = bx['s']
        mc = mq(Fr(bx['mc']))
        top = min(mp.mpf(1), a2 / bb)
        # c1: m <= m_c
        beta = remainder(min(mc, top))
        if beta is None:
            continue
        EL = e_abs([a1, s * a2] + [bb * x for x in beta], um)
        note('c1', vertex_chain(bx['c1'], [a1, a2, bb], [1, s], beta, um, b[0], b[1], EL, 'c1', fails))
        for side, s3 in (('plus', 1), ('minus', -1)):
            for pc in bx[side]:
                m1, m2 = Fr(pc['m'][0]), Fr(pc['m'][1])
                m = mq(rand_in(m1, m2))
                if m > top or m < mc:
                    continue
                tp = pc['type']
                if tp in ('TC', 'SG') or tp == 'TCS':
                    if m >= 1:
                        continue
                    capp = min(mp.mpf(1), m / mp.sqrt(1 - m * m))
                    if tp == 'TCS':
                        mc2 = mq(Fr(pc['mc']))
                        # C': m' <= m_c'
                        bp = remainder(min(capp, mc2))
                        if bp is None:
                            continue
                        beta = [s3 * m] + [mp.sqrt(1 - m * m) * x for x in bp]
                        if max(abs(x) for x in beta) > m + mp.mpf(10)**-30:
                            continue
                        EL = e_abs([a1, s * a2] + [bb * x for x in beta], um)
                        patch = [a1, a2, bb * m, bb * mp.sqrt(1 - m * m)]
                        note('TCS1', vertex_chain(pc['c1'], patch, [1, s, s3], bp, um, b[0], b[1], EL, 'TCS1', fails))
                        # C'': beta'_i1 = -m', m' >= m_c'
                        if capp >= mc2:
                            mpp = mc2 + (capp - mc2) * mp.mpf(rng.random())
                            bp = remainder(capp, sign_top=-1, top=mpp)
                            if bp is not None and max(abs(x) for x in bp) <= mpp + mp.mpf(10)**-30:
                                beta = [s3 * m] + [mp.sqrt(1 - m * m) * x for x in bp]
                                if p3_of(bp) > mq(Fr(pc['pst'])):
                                    fails.append(('TCS2', 'p3 > p* for a vector of the class'))
                                EL = e_abs([a1, s * a2] + [bb * x for x in beta], um)
                                note('TCS2', vertex_chain(pc['c2'], patch, [1, s, s3], bp, um, b[0], b[1], EL, 'TCS2',
                                                          fails))
                            # A4 sub-pieces: beta'_i1 = +m'
                            for n1, n2, kind in pc['sub']:
                                n1, n2 = Fr(n1), Fr(n2)
                                mpp = mq(rand_in(n1, n2))
                                if mpp > capp or mpp < mc2:
                                    continue
                                bp = remainder(capp, sign_top=1, top=mpp)
                                if bp is None:
                                    continue
                                beta = [m] + [mp.sqrt(1 - m * m) * x for x in bp]
                                alpha = [a1, s * a2] + [bb * x for x in beta]
                                EL = e_abs(alpha, um)
                                bq = bb * mp.sqrt(1 - m * m) * mp.sqrt(1 - mpp * mpp)
                                Y4 = alpha[:4]
                                k4 = (um * um + 1 / (um * um) - 4)
                                E4 = 3 + max(0, k4)
                                bound = mp.mpf(0)
                                for p, y in dist_of(Y4, um):
                                    bound += p * abs(y) + p * (bq if y == 0 else min(bq, mp.mpf(27) / 128 * bq**4 * E4 / abs(y)**3))
                                Tu = T_of(um)
                                okk = EL <= bound + mp.mpf(10)**-25 and (bound < Tu or bq == 0)
                                if kind == 'A4' and float(um) > float(mp.sqrt(3 + 2 * mp.sqrt(3))):
                                    okk = EL <= bound + mp.mpf(10)**-25
                                if not okk:
                                    fails.append(('A4', f'EL={mp.nstr(EL, 12)} bound={mp.nstr(bound, 12)} T={mp.nstr(Tu, 12)}'
                                                        f' u={float(um)}'))
                                note('A4', (float(Tu - bound), float(Tu - EL)))
                        continue
                    if tp == 'TC':
                        cap = mq(Fr(pc['cap']))
                        bp = remainder(min(capp, cap))
                        if bp is None:
                            continue
                        beta = [s3 * m] + [mp.sqrt(1 - m * m) * x for x in bp]
                        if max(abs(x) for x in beta) > m + mp.mpf(10)**-30:
                            continue
                        EL = e_abs([a1, s * a2] + [bb * x for x in beta], um)
                        patch = [a1, a2, bb * m, bb * mp.sqrt(1 - m * m)]
                        note('TC' + side, vertex_chain(pc, patch, [1, s, s3], bp, um, b[0], b[1], EL, 'TC' + side,
                                                       fails))
                    else:
                        beta = remainder(1, sign_top=-1, top=m)
                        if beta is None or max(abs(x) for x in beta) > m + mp.mpf(10)**-30:
                            continue
                        if p3_of(beta) > mq(Fr(pc['pst'])):
                            fails.append(('SG', 'p3 > p* for a vector of the class'))
                        EL = e_abs([a1, s * a2] + [bb * x for x in beta], um)
                        note('SG', vertex_chain(pc, [a1, a2, bb], [1, s], beta, um, b[0], b[1], EL, 'SG', fails))
                elif tp in ('A3', 'B3'):
                    beta = remainder(1, sign_top=1, top=m)
                    if beta is None:
                        continue
                    alpha = [a1, s * a2] + [bb * x for x in beta]
                    EL = e_abs(alpha, um)
                    bp = bb * mp.sqrt(1 - m * m)
                    E4 = 3 + max(0, um * um + 1 / (um * um) - 4)
                    bound = mp.mpf(0)
                    for p, y in dist_of(alpha[:3], um):
                        bound += p * abs(y) + p * (bp if y == 0 else min(bp, mp.mpf(27) / 128 * bp**4 * E4 / abs(y)**3))
                    Tu = T_of(um)
                    if not (EL <= bound + mp.mpf(10)**-25 and (bound < Tu or bp == 0)):
                        fails.append(('A3', f'EL={mp.nstr(EL, 12)} bound={mp.nstr(bound, 12)} T={mp.nstr(Tu, 12)}'))
                    note('A3', (float(Tu - bound), float(Tu - EL)))

    for tag, st in sorted(stats.items()):
        print(f"{tag:8s} samples {st[0]:5d}   min (T^- - max_e E P_e) or (T - bound) {st[1]:.3e}   min (T - E|L|) {st[2]:.3e}")
    print(f"violations: {len(fails)}")
    for f in fails[:30]:
        print("   ", f)
    print("RESULT:", "no violation" if not fails else "VIOLATIONS FOUND")


if __name__ == '__main__':
    main()
