"""sup E|X| over laws with the first six moments of N(0,1) (limit a -> 0 of the N.1 LP), plus the
4-point Gauss-Hermite value and the q at which it equals 2 sqrt(q(1-q))."""
import numpy as np
from scipy.optimize import linprog
from mpmath import mp, sqrt, mpf, findroot
mp.dps = 30
mom = [1, 0, 1, 0, 3, 0, 15]
best = None
for Y in (8.0, 12.0, 20.0):
    y = np.linspace(-Y, Y, 40001)
    A = np.array([y**k for k in range(7)])
    A6 = A.copy()
    # slack for the sixth moment (mass at infinity)
    Aeq = np.hstack([A6, np.eye(7)[:, 6:7]])
    c = -np.concatenate([np.abs(y), [0.0]])
    sc = np.array([1.0 / max(1.0, Y**k) for k in range(7)])
    res = linprog(c, A_eq=Aeq * sc[:, None], b_eq=np.array(mom) * sc, bounds=[(0, None)] * (len(y) + 1), method='highs')
    w = res.x[:-1]
    supp = [(round(float(y[i]), 4), round(float(w[i]), 5)) for i in range(len(y)) if w[i] > 1e-7]
    print(f"Y={Y}: LP sup E|X| = {-res.fun:.8f}, slack6 = {res.x[-1]:.2e}, support {supp}")
s6 = sqrt(6)
gh = 2 * ((3 + s6) / 12 * sqrt(3 - s6) + (3 - s6) / 12 * sqrt(3 + s6))
print("4-point Gauss-Hermite E|X| =", gh)
qstar = findroot(lambda q: 2 * sqrt(q * (1 - q)) - gh, 0.27)
print("q with 2 sqrt(q(1-q)) = that value:", qstar)
print("2 tau at q = 0.2744:", 2 * sqrt(mpf('0.2744') * (1 - mpf('0.2744'))))
