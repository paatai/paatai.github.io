"""A.6 f3 follow-up: RQ-A's corrected MAIN_RESULT (tex 38b69350, pdf 5c0ac2ef, md bb6da13b; 03:08 UTC).
(1) tex: undoing the one substitution 6.1 -> 6.2 must give the refereed tex 6816732f byte for byte.
(2) md: removing the new header paragraph and undoing the same substitution must give my copy 6cdb60b2.
(3) pdf: the a6f method (every number and long word of the tex body in the PDF text), and the new figure in it.
(4) the corrected figure and the md header's "certified lower bound 6.158e-3" read as bounds on the appendix box,
    and Section 7.2's "1.77e-3" read as a bound on all 641 boxes, with my own enclosures (a6e functions, refined).
(5) K2 line 411, which RQ-A's 03:04 sweep cites: S_2 u1^2/(1+u1^2) >= 1.414 * 0.707 > 9/20.
Run from /workspace.  Own code only."""
import os as _os
_ROOT = _os.path.abspath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "..", ".."))  # archive root
import hashlib
import json
import os
import re
import subprocess
import sys

from flint import arb, fmpq

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__))))
import a6e_text_recheck as e  # noqa: E402

STORE = _os.path.join(_ROOT, "RQ-A")
OLD_MD = "audit/snapshots/s0144/RQ-A_MAIN_RESULT.md"
ok = True


def check(name, cond, info=""):
    global ok
    ok &= bool(cond)
    print(("PASS " if cond else "FAIL ") + name + (f": {info}" if info else ""))


def md5b(b):
    return hashlib.md5(b).hexdigest()


def main():
    tex = open(f"{STORE}/MAIN_RESULT.tex", "rb").read()
    md = open(f"{STORE}/MAIN_RESULT.md", "rb").read()
    pdfb = open(f"{STORE}/MAIN_RESULT.pdf", "rb").read()
    check("md5s tex 38b69350, md bb6da13b, pdf 5c0ac2ef",
          md5b(tex).startswith("38b69350") and md5b(md).startswith("bb6da13b") and md5b(pdfb).startswith("5c0ac2ef"))

    new, old = b"\\ge6.1\\cdot10^{-3}", b"\\ge6.2\\cdot10^{-3}"
    check("tex: the new string occurs once, the old one not at all", tex.count(new) == 1 and tex.count(old) == 0)
    line = tex.split(b"\n").index(next(l for l in tex.split(b"\n") if new in l)) + 1
    rev = tex.replace(new, old)
    check(f"tex: undoing the substitution (line {line}) gives the refereed tex 6816732f byte for byte",
          md5b(rev) == "6816732f3c313392f6b5ec547e1747f0", md5b(rev))

    oldmd = open(OLD_MD, "rb").read()
    check("old md copy is 6cdb60b2", md5b(oldmd).startswith("6cdb60b2"))
    L = md.split(b"\n")
    i = next(k for k, l in enumerate(L) if l.startswith(b"After the referee's report one number in the appendix"))
    j = next(k for k in range(i, len(L)) if L[k].rstrip().endswith(b"$\\kappa_3B_0-4c_4>0$."))
    hdr = b"\n".join(L[i:j + 1]).decode()
    print("     md header paragraph (lines %d-%d): %s" % (i + 1, j + 1, " ".join(hdr.split())))
    md_rev = b"\n".join(L[:i] + L[j + 1:]).replace(b"\\ge6.1\\cdot10^{-3}", b"\\ge6.2\\cdot10^{-3}")
    check("md: without that paragraph and with the substitution undone it equals 6cdb60b2 byte for byte",
          md5b(md_rev) == md5b(oldmd), md5b(md_rev)[:8])

    pdf = subprocess.run(["pdftotext", "-enc", "UTF-8", f"{STORE}/MAIN_RESULT.pdf", "-"], capture_output=True,
                         text=True, check=True).stdout
    info = subprocess.run(["pdfinfo", f"{STORE}/MAIN_RESULT.pdf"], capture_output=True, text=True).stdout
    pages = re.search(r"Pages:\s+(\d+)", info)
    pdf_join = re.sub(r"-\n", "", pdf)
    pdf_flat = re.sub(r"\s+", "", pdf_join)
    t = tex.decode("utf-8")
    body = t[t.index("\\begin{document}"):]
    body_nocmd = re.sub(r"\\(label|ref|eqref|cite|begin|end|usepackage|texttt|label)\{[^}]*\}", " ", body)
    nums = sorted(set(re.findall(r"\d+(?:\.\d+)?", body_nocmd)) - {str(k) for k in range(10)})
    miss_n = [n for n in nums if n not in pdf_flat]
    words = sorted({w for w in re.findall(r"(?<![\\A-Za-z])[A-Za-z]{6,}", body_nocmd)})
    pdf_words = set(re.findall(r"[A-Za-z]+", pdf_join))
    miss_w = [w for w in words if w not in pdf_words and w.lower() not in pdf_join.lower()]
    check(f"pdf ({pages.group(1) if pages else '?'} pages): all {len(nums)} numbers and {len(words)} long words of the "
          "tex body occur in its text", not miss_n and not miss_w, f"missing {miss_n} {miss_w}")
    n61 = len(re.findall(r"6\.1\s*·\s*10", pdf_join))
    n62 = len(re.findall(r"6\.2\s*·\s*10", pdf_join))
    check("pdf: the appendix reads 6.1·10^-3 (once) and 6.2·10^-3 nowhere", n61 == 1 and n62 == 0, f"{n61}, {n62}")

    d = json.load(open(os.path.join(e.DATA, "quartic_cover.json")))
    boxes = d["boxes"]
    u0 = (1 + arb(2).sqrt()).sqrt()
    t0 = arb(2).sqrt() - 1
    hit = [b for b in boxes if arb(e.Q(b["u1"])) < u0 and u0 < arb(e.Q(b["u2"])) and arb(e.Q(b["t1"])) < t0
           and t0 < arb(e.Q(b["t2"]))]
    b = hit[0]
    u1, u2, t1, t2, c4 = (e.Q(b[k]) for k in ("u1", "u2", "t1", "t2", "c4"))
    lb4 = e.lower_over_box(u1, u2, t1, t2, c4, 1, 64)
    lb1 = e.lower_over_box(u1, u2, t1, t2, c4, 0, 64)
    corner = e.exact_forms(u2, t1, c4)[1]
    check("appendix box: kappa3 B0 - 4c4 >= 6.1e-3 and >= 6.158e-3 (the md header's figure read as a bound); "
          "4c4 s - B0^2 >= 5.7e-4", len(hit) == 1 and lb4 >= arb(fmpq(61, 10000)) and lb4 >= arb(fmpq(6158, 10 ** 6))
          and lb1 >= arb(fmpq(57, 100000)),
          f"certified {float(lb4):.7e} (exact corner value {e.fq(corner):.7e}); Q1 certified {float(lb1):.7e}")

    thr = arb(fmpq(177, 100000))
    lows, refined = [], 0
    for k, bx in enumerate(boxes):
        u1, u2, t1, t2, c4 = (e.Q(bx[x]) for x in ("u1", "u2", "t1", "t2", "c4"))
        for n in (8, 32, 128):
            lb = e.lower_over_box(u1, u2, t1, t2, c4, 1, n)
            if lb >= thr:
                break
            refined += 1
        lows.append((float(lb), k, n))
    worst = min(lows)
    check("Section 7.2: kappa3 B0 - 4c4 >= 1.77e-3 certified on all 641 boxes (8x8, refined to 32x32 or 128x128 where "
          "needed)", all(lo >= 1.77e-3 for lo, _, _ in lows),
          f"{refined} refinements; smallest certified bound {worst[0]:.7e} at box {worst[1]} (split {worst[2]}x{worst[2]})")

    S2 = fmpq(1414213562373095, 10 ** 15)
    Um = fmpq(1553773, 1000000)
    sq2 = arb(2).sqrt()
    check("K2 line 411: S_2 = floor(sqrt2)_15 in [1.414, sqrt2); U_-^2 >= 707/293, so u^2/(1+u^2) >= 0.707 for "
          "u >= U_-; 1.414 * 0.707 > 9/20",
          S2 >= fmpq(1414, 1000) and arb(S2) < sq2 and arb(S2 + fmpq(1, 10 ** 15)) > sq2 and Um * Um >= fmpq(707, 293)
          and fmpq(707, 293) / (1 + fmpq(707, 293)) == fmpq(707, 1000) and fmpq(1414, 1000) * fmpq(707, 1000) > fmpq(9, 20),
          f"U_-^2 = {float(Um * Um):.7f}, 707/293 = {707 / 293:.7f}, 1.414 * 0.707 = {1.414 * 0.707:.6f}")
    print("A6G_PASS" if ok else "A6G_FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
