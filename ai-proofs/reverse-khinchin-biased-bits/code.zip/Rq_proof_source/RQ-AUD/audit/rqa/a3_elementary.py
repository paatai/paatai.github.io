"""RQ-AUD audit of RQ-A elementary PROVED claims C0.2 (cumulants/moments), C0.3 (power sums),
C0.4 (two coefficients).  Exact sympy / exact rational enumeration."""
import sympy as sp
from fractions import Fraction as F
import itertools
import random

ok = True


def check(name, cond):
    global ok
    ok &= bool(cond)
    print(f"[{'OK' if cond else 'FAIL'}] {name}")


# C0.2: cumulants of chi via the cumulant generating function; rational parametrisation u > 0.
u, t = sp.symbols('u t', positive=True)
v = 1 / u
q = 1 / (1 + u**2)
mgf = q * sp.exp(t * u) + (1 - q) * sp.exp(-t * v)
K = sp.series(sp.log(mgf), t, 0, 7).removeO()
kap = [sp.simplify(sp.factorial(j) * K.coeff(t, j)) for j in range(7)]
w = u**2 + v**2
check("kappa_1 = 0, kappa_2 = 1", sp.simplify(kap[1]) == 0 and sp.simplify(kap[2] - 1) == 0)
check("kappa_3 = u - v", sp.simplify(kap[3] - (u - v)) == 0)
check("kappa_4 = u^2 + v^2 - 4", sp.simplify(kap[4] - (w - 4)) == 0)
check("kappa_5 = (u - v)(u^2 + v^2 - 10)", sp.simplify(kap[5] - (u - v) * (w - 10)) == 0)
check("kappa_6 = w^2 - 26 w + 64", sp.simplify(kap[6] - (w**2 - 26 * w + 64)) == 0)
# tau-forms used in RQ-A's LP code (moment_lp3.cumulants)
tau = u / (1 + u**2)
th = 1 - 2 * q
check("LP code: k3 = theta/tau", sp.simplify(kap[3] - th / tau) == 0)
check("LP code: k4 = (1-6tau^2)/tau^2", sp.simplify(kap[4] - (1 - 6 * tau**2) / tau**2) == 0)
check("LP code: k5 = theta(1-12tau^2)/tau^3", sp.simplify(kap[5] - th * (1 - 12 * tau**2) / tau**3) == 0)
check("LP code: k6 = (1-30tau^2+120tau^4)/tau^4", sp.simplify(kap[6] - (1 - 30 * tau**2 + 120 * tau**4) / tau**4) == 0)

# moments of M = sum beta_i chi_i (|beta| = 1) from cumulants K_j = kappa_j p_j: exact check by
# enumeration for random rational beta (not normalised: use general formula with p2).
def moments_formula(k, p):
    k3, k4, k5, k6 = k
    p2, p3, p4, p5, p6 = p
    m3 = k3 * p3
    m4 = k4 * p4 + 3 * p2**2
    m5 = k5 * p5 + 10 * k3 * p3 * p2
    m6 = k6 * p6 + 15 * k4 * p4 * p2 + 10 * k3**2 * p3**2 + 15 * p2**3
    return m3, m4, m5, m6


random.seed(3)
allgood = True
for trial in range(30):
    uu = F(random.randint(5, 30), random.randint(5, 30))
    vv = 1 / uu
    qq = 1 / (1 + uu**2)
    n = random.randint(1, 6)
    beta = [F(random.randint(-9, 9), random.randint(1, 9)) for _ in range(n)]
    ww = uu**2 + vv**2
    k = (uu - vv, ww - 4, (uu - vv) * (ww - 10), ww**2 - 26 * ww + 64)
    p = tuple(sum(b**j for b in beta) for j in (2, 3, 4, 5, 6))
    mom = [F(0)] * 7
    for xs in itertools.product([0, 1], repeat=n):
        pr = F(1)
        val = F(0)
        for b, x in zip(beta, xs):
            pr *= qq if x else 1 - qq
            val += b * (uu if x else -vv)
        for j in range(7):
            mom[j] += pr * val**j
    allgood &= (mom[1] == 0 and mom[2] == p[0] and tuple(mom[3:7]) == moments_formula(k, p))
check("C0.2 moments EM^3..EM^6 (general p2; |beta|=1 gives RQ-A's formulas), 30 exact random cases", allgood)

# C0.3 power-sum inequalities: random exact tests (the proofs are Cauchy-Schwarz; see AUDIT.md)
good = True
for trial in range(2000):
    n = random.randint(1, 8)
    beta = [F(random.randint(-20, 20), 7) for _ in range(n)]
    s2 = sum(b * b for b in beta)
    if s2 == 0:
        continue
    # normalise exactly by scaling the power sums: p_j(beta/|beta|) = p_j(beta)/s2^{j/2};
    # compare in homogeneous form
    m = max(abs(b) for b in beta)  # m^2/s2 is the normalised max^2
    p3, p4, p5, p6 = (sum(b**j for b in beta) for j in (3, 4, 5, 6))
    good &= p3**2 <= p4 * s2  # p3^2 <= p4
    good &= p4 <= m * m * s2  # p4 <= m^2   (homogeneous: p4/s2^2 <= m^2/s2)
    good &= p4**2 <= p6 * s2  # p4^2 <= p6
    good &= p6 <= m * m * p4  # p6 <= m^2 p4
    good &= abs(p5) <= m * p4  # |p5| <= m p4
check("C0.3 power-sum inequalities on 2000 exact random vectors", good)

# C0.4 two coefficients: E|a chi1 + b chi2| = 2 tau (1-q)(a+b) for q/(1-q) <= b/a <= (1-q)/q (q<1/2)
a_, b_ = sp.symbols('a b', positive=True)
uq = u  # q = 1/(1+u^2) < 1/2  <=> u > 1
vals = [((a_ + b_) * uq, q**2), (a_ * uq - b_ * v, q * (1 - q)), (b_ * uq - a_ * v, q * (1 - q)), (-(a_ + b_) * v, (1 - q)**2)]
# in the stated range a u - b v >= 0 and b u - a v >= 0, so |.| is the identity on the middle atoms
E = sum(pr * (x if i < 3 else -x) for i, (x, pr) in enumerate(vals))
check("C0.4 E|a chi1 + b chi2| = 2 tau (1-q)(a+b) when both middle atoms are >= 0",
      sp.simplify(E - 2 * tau * (1 - q) * (a_ + b_)) == 0)
check("C0.4 middle atoms >= 0 <=> v/u <= b/a <= u/v, i.e. q/(1-q) <= b/a <= (1-q)/q",
      sp.simplify(v / u - q / (1 - q)) == 0 and sp.simplify(u / v - (1 - q) / q) == 0)
print("\nALL OK" if ok else "\nSOME FAILED")
