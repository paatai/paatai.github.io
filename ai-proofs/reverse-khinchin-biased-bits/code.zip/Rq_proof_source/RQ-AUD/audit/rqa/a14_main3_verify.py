"""RQ-AUD independent verifier for RQ-A MAIN-3 (Theorem 3 of MAIN_RESULT_K3, 09:46 UTC):
    E|sum alpha_i chi_i| <= T = 2 sqrt3 (1-q)^2 tau  for every unit alpha and every q in [25/169, q3], q3 = 1-sqrt(2/3).

RQ-A code is not used. The target-independent helpers are my own from A.6, A.9 and A.11 (a6_lemmaS_verify,
a11_main2_verify, a11_main2_verify_v2: tilings, my box envelope, my six-moment bound with optional p*, the 8-atom
piece arithmetic). Everything that depends on k is re-implemented here from the text of MAIN_RESULT_K3:
 - target T = sqrt3 Tt(u), Tt(u) = 2u^5/(1+u^2)^3, unimodal with maximum at sqrt5; lower bound on [u1,u2]:
   T-(u1,u2) = S3 min(Tt(u1), Tt(u2)), S3 = floor(10^30 sqrt3)/10^30 (also RQ-A's S3 = 1732050807568877/10^15);
 - one-coordinate cells (a1 <= 2/5): A.9 cell check with target Theta1 = tau(u2) (S3 (u1^2/(1+u1^2))^2 - a2);
 - near-circle boxes: E|L| <= r G + sum_j p_j min(b, (27/128) b^4 E4/(r |y_j|)^3) with G = E|c chi1 + s d chi2|
   <= T for q <= q3 (Lemma 4); tests (pointwise ratio, monotone, mixed) with the k = 3 margin
   T - G >= 2 tau- (S3 (1-q)-^2 - max(c, d, [s=1](1-q)(c+d))+), all strict;
 - m-split boxes: c1 (cap min(m_c, mbar)), c2 (cap min(1, mbar), p3 <= p*), 0 < m_c <= 1, 2 m_c^2 > 1,
   phi(m_c) <= p* < 0, pieces with s3 = +1 covering [m_c, min(1, mbar)], each passing (A3) or (B3) with the k = 3
   target (main term by the k = 3 three-bit lemma), u1^2 > 2 (monotonicity of q^k (1-q)^(3-k));
 - three-bit lemma, k = 3: P_f = 12(1-q)^4 - sum_i Delta_i(f)^2 >= 0 on [25/169, q3] for all 256 f, with the
   equality lists (P_f == 0 iff +-OR_3; P_f(q3) = 0 iff +-OR_2).
Parts: M md5s, A elementary facts, B tilings, F small boxes, C cells, D lp boxes (and both certificates of each
ms box), E near-circle boxes, G m-split boxes, H three-bit lemma.
"""
import hashlib
import json
import os
import random
import sys
import time
from fractions import Fraction as Fr
from itertools import product
from math import comb, isqrt
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqc'))
import a11_main2_verify as V  # noqa: E402
import a11_main2_verify_v2 as V2  # noqa: E402
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo, kappa_ranges, imul, tiles  # noqa: E402

DATA = os.environ.get('K3_DATA', os.path.join(HERE, 'k3_data'))
U_LO, U_HI, T8, A_S = Fr(2109381, 10**6), Fr(12, 5), Fr(20711, 50000), Fr(2, 5)
D30 = 10**30
S3_MINE = Fr(isqrt(3 * D30 * D30), D30)
S3_RQA = Fr(1732050807568877, 10**15)
assert S3_MINE**2 < 3 and S3_RQA**2 < 3 and S3_RQA < S3_MINE
K27 = Fr(27, 128)


def Tt(u):
    return 2 * u**5 / (1 + u * u)**3


def T3_lo(u1, u2, s3=S3_MINE):
    return s3 * min(Tt(u1), Tt(u2))


# ---------------------------------------------------------------- C: one-coordinate cells (k = 3 target)
def theta1(u1, u2, a2, s3):
    om1 = u1 * u1 / (1 + u1 * u1)
    return u2 / (1 + u2 * u2) * (s3 * om1 * om1 - a2)


def cell_once(u1, u2, a1, a2, c, s3):
    bh = sqrt_hi(1 - a1 * a1)
    s1 = u2 * u2 / (1 + u2 * u2)
    s2 = 1 / (1 + u1 * u1)
    P = list(c)
    ok, why = positive_on(P)
    if not ok:
        return False, "P > 0: " + why
    ok, why = positive_on([P[0] + s1 * a1 / u2, P[1] - s1 * bh] + P[2:], lo=(a1 / u2) / bh)
    if not ok:
        return False, "P > l1: " + why
    ok, why = positive_on([P[0] + s2 * a1 * u1, P[1] + s2 * bh] + P[2:], hi=-(a1 * u1) / bh)
    if not ok:
        return False, "P > l2: " + why
    b2 = sqrt_lo(1 - a2 * a2)
    mh = min(Fr(1), a2 / b2) if b2 > 0 else Fr(1)
    T = theta1(u1, u2, a2, s3)
    if T <= 0:
        return False, "Theta1 <= 0"
    return V2.moment_ok_p(c, u1, u2, mh, T)


def cell_rec(args, depth=0, maxdepth=6):
    u1, u2, a1, a2, c, s3 = args
    ok, why = cell_once(u1, u2, a1, a2, c, s3)
    if ok:
        return True, 1, depth, ""
    if depth >= maxdepth:
        return False, 0, depth, why
    um, am = (u1 + u2) / 2, (a1 + a2) / 2
    leaves, md = 0, depth
    for x1, x2 in ((u1, um), (um, u2)):
        for b1, b2 in ((a1, am), (am, a2)):
            ok, lv, d2, why2 = cell_rec((x1, x2, b1, b2, c, s3), depth + 1, maxdepth)
            if not ok:
                return False, 0, d2, why2
            leaves += lv
            md = max(md, d2)
    return True, leaves, md, ""


# ---------------------------------------------------------------- D: box certificates
def box_cert_ok(box, s, c, mstar, pstar, s3):
    ok, why = V2.dominance_ok(box, s, c)
    if not ok:
        return False, why
    return V2.moment_ok_p(c, box[0], box[1], mstar, T3_lo(box[0], box[1], s3), pstar)


def lp_rec(args, depth=0, maxdepth=3):
    box, s, c, s3 = args
    blo, _ = V.b_range(box[4], box[5])
    ok, why = box_cert_ok(box, s, c, V.mbar_of(box[3], box[5], blo), None, s3)
    if ok:
        return True, 1, depth, ""
    if depth >= maxdepth:
        return False, 0, depth, why
    leaves, md = 0, depth
    for sb in V.split8(box):
        ok, lv, d2, why2 = lp_rec((sb, s, c, s3), depth + 1, maxdepth)
        if not ok:
            return False, 0, d2, why2
        leaves += lv
        md = max(md, d2)
    return True, leaves, md, ""


# ---------------------------------------------------------------- E: near-circle boxes (k = 3 margin)
def nc_once(box, s, s3):
    u1, u2, t1, t2, r1, r2 = box
    if r1 <= 0:
        return False, "r1 = 0"
    T = T3_lo(u1, u2, s3)
    blo, bhi = V.b_range(r1, r2)
    mbar = V.mbar_of(t2, r2, blo)
    w_hi = u2 * u2 + 1 / (u2 * u2)
    E4 = 3 + max(Fr(0), w_hi - 4) * mbar * mbar
    ys = [V.iabs_lo(y) for y in V.atoms_y(u1, u2, t1, t2, s)]
    ph = [p[1] for p in V.r_probs(u1, u2)]
    tau_lo = u2 / (1 + u2 * u2)
    om_lo, om_hi = u1 * u1 / (1 + u1 * u1), u2 * u2 / (1 + u2 * u2)
    C, Dd = V.r_c(t1, t2), V.r_d(t1, t2)
    mx = max(C[1], Dd[1], om_hi * V.r_cpd(t1, t2)[1] if s == 1 else Fr(0))
    Dlo = max(Fr(0), 2 * tau_lo * (s3 * om_lo * om_lo - mx))
    if all(y > 0 for y in ys):
        S = sum(p / y**3 for p, y in zip(ph, ys))
        if K27 * E4 * bhi * bhi * (1 + r2) / r1**3 * S < T:
            return True, "1"
    lhs = Fr(0)
    for p, y in zip(ph, ys):
        e = bhi if y == 0 else min(bhi, K27 * bhi**4 * E4 / (r1 * y)**3)
        lhs += p * e
    if lhs < T * (1 - r2) + r1 * Dlo:
        return True, "2"
    Cz = sum(p for p, y in zip(ph, ys) if y == 0)
    Cnz = sum(p * K27 * E4 * bhi * bhi / (r1 * y)**3 for p, y in zip(ph, ys) if y > 0)
    coef = Cnz - T / (1 + r2)
    bw = bhi if coef > 0 else blo
    if bw * bw * coef + bhi * Cz < r1 * Dlo:
        return True, "3"
    return False, "nc tests fail"


def nc_rec(args, depth=0, maxdepth=4):
    box, s, s3 = args
    ok, why = nc_once(box, s, s3)
    if ok:
        return True, 1, depth, why
    if depth >= maxdepth:
        return False, 0, depth, why
    leaves, md = 0, depth
    for sb in V.split8(box):
        ok, lv, d2, why2 = nc_rec((sb, s, s3), depth + 1, maxdepth)
        if not ok:
            return False, 0, d2, why2
        leaves += lv
        md = max(md, d2)
    return True, leaves, md, "bisected"


# ---------------------------------------------------------------- G: m-split boxes (k = 3 target)
def piece_test(box, s, m1, m2, s3):
    u1, u2, t1, t2, r1, r2 = box
    assert u1 * u1 > 2
    T = T3_lo(u1, u2, s3)
    blo, bhi = V.b_range(r1, r2)
    if blo <= 0:
        return None
    a1 = (r1 * V.cfun(t2), r2 * V.cfun(t1))
    a2 = (r1 * V.dfun(t1), r2 * V.dfun(t2))
    a3 = (blo * m1, bhi * m2)
    bp2 = bhi * bhi * (1 - m1 * m1)
    bp = sqrt_hi(bp2) if bp2 > 0 else Fr(0)
    rp = min(Fr(1), sqrt_hi(1 - blo * blo * (1 - m2 * m2)))
    E4 = 3 + max(Fr(0), u2 * u2 + 1 / (u2 * u2) - 4)
    U, Vn = (u1, u2), (-1 / u1, -1 / u2)
    Vn = (min(Vn), max(Vn))
    pr = V2.p3_probs(u1, u2)
    tau = (u2 / (1 + u2 * u2), u1 / (1 + u1 * u1))
    qq = (1 / (1 + u2 * u2), 1 / (1 + u1 * u1))
    om = (u1 * u1 / (1 + u1 * u1), u2 * u2 / (1 + u2 * u2))
    coefs = (a1, a2 if s == 1 else V.ineg(a2), a3)
    atoms = []
    for xs in product((1, 0), repeat=3):
        y = (Fr(0), Fr(0))
        py = (Fr(0), Fr(0))
        for i in range(3):
            y = V.iadd(y, V.imm(coefs[i], U if xs[i] else Vn))
            other = (Fr(1), Fr(1))
            for j in range(3):
                if j != i:
                    other = V.imm(other, qq if xs[j] else om)
            sgn = (Fr(1), Fr(1)) if xs[i] else (Fr(-1), Fr(-1))
            py = V.iadd(py, V.imm(V.imm(coefs[i], other), V.imm(tau, sgn)))
        atoms.append((pr[sum(xs)][1], y, py))
    ys = [V.iabs_lo(y) for _, y, _ in atoms]
    if all(y > 0 for y in ys):
        S = sum(p / y**3 for (p, _, _), y in zip(atoms, ys))
        if K27 * E4 * bp2 * (1 + rp) * S < T:
            return "A3"
    tot = Fr(0)
    for (p, y, py), yl in zip(atoms, ys):
        e = bp if yl == 0 else min(bp, K27 * bp2 * bp2 * E4 / yl**3)
        tot += max(abs(py[0]), abs(py[1])) + p * e
    return "B3" if tot < T else None


def ms_check(args):
    box, s, rec, s3 = args
    u1, u2, t1, t2, r1, r2 = box
    blo, bhi = V.b_range(r1, r2)
    if blo <= 0:
        return False, "b- = 0", None
    mc, pstar = Fr(rec['mcut']), Fr(rec['p3max'])
    if not (0 < mc <= 1 and 2 * mc * mc > 1):
        return False, "m_c", None
    if not V2.phi_ok(pstar, mc):
        return False, "p* < phi(m_c) or p* >= 0", None
    mbar = V.mbar_of(t2, r2, blo)
    top = min(Fr(1), mbar)
    ok, why = box_cert_ok(box, s, [Fr(x) for x in rec['c']], min(mc, mbar), None, s3)
    if not ok:
        return False, "c1 " + why, None
    ok, why = box_cert_ok(box, s, [Fr(x) for x in rec['c2']], top, pstar, s3)
    if not ok:
        return False, "c2 " + why, None
    pcs = sorted((Fr(p[0]), Fr(p[1])) for p in rec['pieces'] if p[2] == 1)
    reach = mc
    for m1, m2 in pcs:
        if m1 > reach:
            break
        reach = max(reach, m2)
    if mc < top and reach < top:
        return False, f"pieces reach {float(reach)} < {float(top)}", None
    kinds = []
    for m1, m2 in pcs:
        if not (0 < m1 < m2 <= 1):
            return False, "piece range", None
        k = piece_test(box, s, m1, m2, s3)
        if k is None:
            return False, f"piece [{float(m1)},{float(m2)}] fails", None
        kinds.append(k)
    return True, "", kinds


# ---------------------------------------------------------------- H: three-bit lemma, k = 3
def three_bit_k3():
    import sympy as sp
    q = sp.Symbol('q')
    mu3 = sp.Poly(3 * q**2 - 6 * q + 1, q)
    q3lo, q3hi = 1 - sqrt_hi(Fr(2, 3)), 1 - sqrt_lo(Fr(2, 3))
    qL = 1 / (1 + U_HI * U_HI)
    R = lambda x: sp.Rational(x.numerator, x.denominator)
    assert mu3.eval(R(q3lo)) > 0 > mu3.eval(R(q3hi)) and qL < q3lo and qL == Fr(25, 169)
    pts = list(product((0, 1), repeat=3))
    bad, zero, at3 = 0, [], []
    for vals in product((-1, 1), repeat=8):
        f = dict(zip(pts, vals))
        D = []
        for i in range(3):
            e1 = e0 = 0
            for x in pts:
                w = sp.Integer(1)
                for j in range(3):
                    if j != i:
                        w *= q if x[j] else (1 - q)
                if x[i]:
                    e1 += f[x] * w
                else:
                    e0 += f[x] * w
            D.append(sp.expand(e1 - e0))
        P = sp.Poly(sp.expand(12 * (1 - q)**4 - sum(d * d for d in D)), q)
        if P.is_zero:
            zero.append(vals)
            continue
        a, Q = 0, P
        while True:
            qq, rr = sp.div(Q, mu3)
            if rr.is_zero:
                Q, a = qq, a + 1
            else:
                break
        nQ = Q.count_roots(R(qL), R(q3hi)) if Q.degree() > 0 else 0
        nP = P.count_roots(R(qL), R(q3lo))
        if nQ != 0 or nP != 0 or Q.eval(R(qL)) <= 0 or P.eval(R(qL)) <= 0:
            bad += 1
        if a:
            at3.append(vals)
    return bad, zero, at3, pts


def or_fn(pts, idx):
    return tuple(1 if any(x[i] for i in idx) else -1 for x in pts)


# ---------------------------------------------------------------- A: elementary facts
def exact_sum_value(u, k):
    """E|chi_1 + ... + chi_k| for rational u, by enumeration"""
    q = 1 / (1 + u * u)
    tot = Fr(0)
    for j in range(k + 1):
        tot += comb(k, j) * q**j * (1 - q)**(k - j) * abs(j * u - (k - j) / u)
    return tot


def part_A():
    import sympy as sp
    ok = True
    u3sq_lo = U_LO * U_LO
    okU = u3sq_lo > 2 and (u3sq_lo - 2)**2 < 6 and U_HI**2 > 3 and (U_HI**2 - 3)**2 < 12 and 1 / (1 + U_HI**2) == Fr(25, 169)
    okT8 = (T8 + 1)**2 >= 2 and T8 < 1
    okW = U_HI**2 + 1 / U_HI**2 < 10 and U_LO > 1
    om = U_LO**2 / (1 + U_LO**2)
    okTh = S3_RQA * om * om > Fr(115, 100) > A_S
    print(f"A  U_LO < u3 = sqrt(2+sqrt6), U_HI = 12/5 < u4 = sqrt(3+2sqrt3), q(12/5) = 25/169: {okU}; sqrt2-1 <= T8 < 1: {okT8};"
          f" S3 (U_LO^2/(1+U_LO^2))^2 > 1.15 > 2/5: {okTh}")
    print(f"A  w = u^2 + u^-2 < 10 on the range (needed by the kappa_5 enclosure): {okW}")
    ok &= okU and okT8 and okTh and okW
    bad = V.lemma2c_exact()
    print(f"A  Lemma 4 value 2 tau max(c, d, [s=+1](1-q)(c+d)) at 8000 random rational points: {bad} mismatches")
    ok &= bad == 0
    rnd = random.Random(5)
    bad4 = 0
    for _ in range(3000):
        u = Fr(rnd.randint(2110, 4000), 1000)
        if not (u * u > 2 and (u * u - 2)**2 >= 6):
            continue
        q = 1 / (1 + u * u)
        tau = u / (1 + u * u)
        c, d = Fr(rnd.randint(0, 999), 1000), Fr(rnd.randint(1, 999), 1000)
        for s in (1, -1):
            G = 2 * tau * max(c, d, (1 - q) * (c + d) if s == 1 else Fr(0))
            bad4 += not (G * G < 12 * (1 - q)**4 * tau * tau * (c * c + d * d))
    print(f"A  Lemma 4, k = 3 bound E|X|^2 < T^2 (c^2+d^2) at random rational u > u3: {bad4} violations")
    ok &= bad4 == 0
    bad3 = 0
    for num in range(2110, 2600, 7):
        u = Fr(num, 1000)
        q = 1 / (1 + u * u)
        tau = u / (1 + u * u)
        bad3 += exact_sum_value(u, 3) != 6 * (1 - q)**2 * tau
        bad3 += exact_sum_value(u, 4) != 8 * (1 - q)**3 * tau
        bad3 += exact_sum_value(u, 2) != 4 * (1 - q) * tau
        bad3 += exact_sum_value(u, 1) != 2 * tau
    print(f"A  Lemma 3: E|chi_1+...+chi_k| = 2k(1-q)^(k-1) tau for k = 1..4 at 70 rational u in [2.11, 2.6): {bad3} mismatches")
    ok &= bad3 == 0
    u = sp.symbols('u', positive=True)
    qs = 1 / (1 + u**2)
    taus = u / (1 + u**2)
    e1 = sp.simplify(2 * (1 - qs)**2 * taus - 2 * u**5 / (1 + u**2)**3)
    der = sp.factor(sp.diff(u**5 / (1 + u**2)**3, u))
    e2 = sp.simplify(der - u**4 * (5 - u**2) / (1 + u**2)**4)
    qq = sp.symbols('q', positive=True)
    s1 = sp.factor(12 * (1 - qq)**4 - 8 * (1 - qq)**2)
    s2 = sp.factor(16 * (1 - qq)**6 - 12 * (1 - qq)**4)
    okS = e1 == 0 and e2 == 0
    print(f"A  T = sqrt3 * 2u^5/(1+u^2)^3 and d/du u^5/(1+u^2)^3 = u^4(5-u^2)/(1+u^2)^4: {okS};"
          f" T^2 - T2^2 ~ {s1} (zero at q3); (4(1-q)^3)^2 - (2 sqrt3 (1-q)^2)^2 ~ {s2} (zero at q4)")
    ok &= okS
    return ok


def main():
    t0 = time.time()
    parts = sys.argv[1] if len(sys.argv) > 1 else 'MABFCDEGH'
    allok = True
    man = json.load(open(os.path.join(DATA, 'k3_manifest.json')))
    assert Fr(man['U_LO']) == U_LO and Fr(man['U_HI']) == U_HI and Fr(man['T8']) == T8 and Fr(man['A_S']) == A_S
    files = man['one_files'] + man['two_files']
    print(f"MAIN-3 verifier (RQ-AUD), data {DATA}; {len(files)} data files", flush=True)
    if 'M' in parts:
        pub = {}
        for line in open(os.path.join(DATA, 'k3_MD5SUMS.txt')):
            h, fn = line.split()
            pub[fn.replace('outputs/', '')] = h
        mism = [fn for fn in files + ['k3_manifest.json'] if hashlib.md5(open(os.path.join(DATA, fn), 'rb').read()).hexdigest() != pub.get(fn)]
        print(f"M  md5 of the {len(files) + 1} manifest files vs RQ-A k3_MD5SUMS.txt: {len(mism)} mismatches {mism[:3]}", flush=True)
        allok &= not mism
    cells = []
    for fn in man['one_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['target'] == 'k3' and not d['failed'] and Fr(d['S3']) == S3_RQA
        for cl in d['cells']:
            cells.append((Fr(cl['u1']), Fr(cl['u2']), Fr(cl['a1']), Fr(cl['a2']), [Fr(x) for x in cl['c']]))
    boxes = {1: [], -1: []}
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        assert d['s'] in (1, -1) and not d['failed'] and d['K'] == 3 and Fr(d['A_S']) == A_S
        for bx in d['boxes']:
            assert bx['s'] == d['s']
            boxes[d['s']].append((tuple(Fr(x) for x in bx['box']), bx['kind'], bx))
    kinds = {}
    for s in (1, -1):
        for _, k, _ in boxes[s]:
            kinds[(s, k)] = kinds.get((s, k), 0) + 1
    print(f"data: {len(cells)} cells; boxes s=+1: {len(boxes[1])}, s=-1: {len(boxes[-1])}; kinds {dict(sorted(kinds.items()))}", flush=True)

    if 'A' in parts:
        allok &= part_A()

    if 'B' in parts:
        reg1 = (U_LO, U_HI, Fr(0), A_S)
        tok, gap = tiles(reg1, [cl[:4] for cl in cells])
        inside = all(reg1[0] <= cl[0] < cl[1] <= reg1[1] and reg1[2] <= cl[2] < cl[3] <= reg1[3] for cl in cells)
        area = sum((cl[1] - cl[0]) * (cl[3] - cl[2]) for cl in cells) == (reg1[1] - reg1[0]) * (reg1[3] - reg1[2])
        print(f"B  {len(cells)} one-coordinate cells tile {[str(x) for x in reg1]}: {'OK' if tok else 'GAP ' + str(gap)};"
              f" inside {inside}; area {area}", flush=True)
        allok &= tok and inside and area
        reg3 = (U_LO, U_HI, Fr(0), T8, A_S, Fr(1))
        for s in (1, -1):
            ins, voleq, nov = V.tiling3(reg3, [b[0] for b in boxes[s]])
            print(f"B  s={s:+d}: {len(boxes[s])} boxes inside {ins}; volume sum == region volume {voleq}; overlapping pairs {nov}"
                  f" => {'TILING OK' if ins and voleq and nov == 0 else 'TILING FAIL'}", flush=True)
            allok &= ins and voleq and nov == 0

    if 'F' in parts:
        smalls = [b[0] for s in (1, -1) for b in boxes[s] if b[1] == 'small']
        badsm = [bx for bx in smalls if not (bx[5] * V.cfun(bx[2]) <= A_S)]
        print(f"F  small boxes: {len(smalls)}, violating r2 c(t1) <= 2/5: {len(badsm)}")
        allok &= not badsm
        unknown = [k for k in kinds if k[1] not in ('lp', 'ncA', 'ncB', 'ms', 'small')]
        allok &= not unknown

    s3list = [('MINE', S3_MINE)] + ([('RQA', S3_RQA)] if 'R' in parts else [])
    if 'C' in parts:
        for name, s3 in s3list:
            with Pool(8) as pool:
                res = pool.map(cell_rec, [(cl[0], cl[1], cl[2], cl[3], cl[4], s3) for cl in cells], chunksize=4)
            nf = sum(1 for r in res if not r[0])
            for cl, r in zip(cells, res):
                if not r[0]:
                    print(f"   FAIL cell u[{float(cl[0]):.6f},{float(cl[1]):.6f}] a[{float(cl[2]):.4f},{float(cl[3]):.4f}]: {r[3]}")
            print(f"C  one-coordinate cells (Theta1, S3={name}): failures {nf}/{len(cells)}, sub-cells {sum(r[1] for r in res)},"
                  f" max depth {max(r[2] for r in res)}, {time.time() - t0:.0f}s", flush=True)
            allok &= nf == 0

    if 'D' in parts:
        lps = [(b[0], s, [Fr(x) for x in b[2]['c']]) for s in (1, -1) for b in boxes[s] if b[1] == 'lp']
        for name, s3 in s3list:
            with Pool(8) as pool:
                res = pool.map(lp_rec, [(bx, s, c, s3) for bx, s, c in lps], chunksize=16)
            nf = sum(1 for r in res if not r[0])
            depths = {}
            for r in res:
                if r[0]:
                    depths[r[2]] = depths.get(r[2], 0) + 1
            for (bx, s, c), r in zip(lps, res):
                if not r[0]:
                    print(f"   FAIL s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.5f},{float(bx[3]):.5f}]"
                          f" r[{float(bx[4]):.5f},{float(bx[5]):.5f}]: {r[3]}")
            print(f"D  lp boxes (S3={name}): failures {nf}/{len(lps)}; certified at depth {dict(sorted(depths.items()))},"
                  f" {time.time() - t0:.0f}s", flush=True)
            allok &= nf == 0

    if 'E' in parts:
        ncs = [(b[0], s) for s in (1, -1) for b in boxes[s] if b[1].startswith('nc')]
        for name, s3 in s3list:
            with Pool(8) as pool:
                res = pool.map(nc_rec, [(bx, s, s3) for bx, s in ncs], chunksize=16)
            nf = sum(1 for r in res if not r[0])
            how = {}
            for r in res:
                if r[0]:
                    how[r[3]] = how.get(r[3], 0) + 1
            for (bx, s), r in zip(ncs, res):
                if not r[0]:
                    print(f"   FAIL nc s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.5f},{float(bx[3]):.5f}]"
                          f" r[{float(bx[4]):.5f},{float(bx[5]):.5f}]: {r[3]}")
            sliver = sum(1 for bx, _ in ncs if (bx[0] * bx[0] - 2)**2 < 6)
            print(f"E  near-circle boxes (S3={name}): failures {nf}/{len(ncs)}; passed by test {how};"
                  f" boxes touching [U_LO, u3) (argument used only at u >= u3): {sliver}; {time.time() - t0:.0f}s", flush=True)
            allok &= nf == 0

    if 'G' in parts:
        mss = [(b[0], s, b[2]) for s in (1, -1) for b in boxes[s] if b[1] == 'ms']
        for name, s3 in s3list:
            with Pool(8) as pool:
                res = pool.map(ms_check, [(bx, s, rec, s3) for bx, s, rec in mss], chunksize=8)
            nf = sum(1 for r in res if not r[0])
            kk = {}
            for r in res:
                if r[0]:
                    for k in r[2]:
                        kk[k] = kk.get(k, 0) + 1
            for (bx, s, rec), r in zip(mss, res):
                if not r[0]:
                    print(f"   FAIL ms s={s:+d} u[{float(bx[0]):.6f},{float(bx[1]):.6f}] t[{float(bx[2]):.5f},{float(bx[3]):.5f}]"
                          f" r[{float(bx[4]):.5f},{float(bx[5]):.5f}]: {r[1]}")
            umin = min(bx[0] for bx, _, _ in mss)
            mcs = sorted({rec['mcut'] for _, _, rec in mss}, key=Fr)
            print(f"G  m-split boxes (S3={name}): failures {nf}/{len(mss)}; pieces {sum(kk.values())} by test {kk};"
                  f" min u1 = {float(umin):.6f}; m_c values {mcs}; {time.time() - t0:.0f}s", flush=True)
            allok &= nf == 0

    if 'H' in parts:
        bad, zero, at3, pts = three_bit_k3()
        or3 = {or_fn(pts, (0, 1, 2)), tuple(-x for x in or_fn(pts, (0, 1, 2)))}
        or2 = {or_fn(pts, ij) for ij in ((0, 1), (0, 2), (1, 2))}
        or2 |= {tuple(-x for x in f) for f in or2}
        okH = bad == 0 and set(zero) == or3 and set(at3) == or2
        print(f"H  three-bit lemma k = 3: 256 functions, P_f >= 0 on [25/169, q3] fails for {bad}; P_f == 0 exactly for"
              f" {len(zero)} f (= +-OR_3: {set(zero) == or3}); P_f(q3) = 0 for {len(at3)} f (= +-OR_2: {set(at3) == or2})", flush=True)
        allok &= okH

    print(f"RESULT: {'ALL CHECKS PASSED' if allok else 'FAILURES'} (parts {parts}, {time.time() - t0:.0f}s)")


if __name__ == '__main__':
    main()
