"""Negative tests for a7_lemmaQ_verify.py: wrong c4, boxes moved beyond q0 or outside the a-window."""
import json
from fractions import Fraction as Fr
from a7_lemmaQ_verify import check_box
d = json.load(open('rqa_data/quartic_cover.json'))
boxes = [(Fr(bx['u1']), Fr(bx['u2']), Fr(bx['t1']), Fr(bx['t2']), Fr(bx['c4'])) for bx in d['boxes']]
def run(name, mod, maxdepth=5):
    rej = 0
    sample = boxes[::8]
    for bx in sample:
        st = {'leaves': 0, 'maxdepth': 0}
        ok, _ = check_box(*mod(bx), maxdepth=maxdepth, stats=st)
        rej += (not ok)
    print(f"{name:36s}: rejected {rej}/{len(sample)}", flush=True)
run('c4 * 3', lambda b: b[:4] + (b[4] * 3,))
run('c4 / 3', lambda b: b[:4] + (b[4] / 3,))
run('c4 * 1.5', lambda b: b[:4] + (b[4] * Fr(3, 2),))
run('c4 / 1.5', lambda b: b[:4] + (b[4] / Fr(3, 2),))
run('u shifted +0.05 (beyond q0 region)', lambda b: (b[0] + Fr(5, 100), b[1] + Fr(5, 100)) + b[2:])
run('t shifted +0.15 (a ~ 0.88)', lambda b: b[:2] + (b[2] + Fr(15, 100), b[3] + Fr(15, 100), b[4]))
run('t shifted -0.25 (a ~ 0.2)', lambda b: b[:2] + (b[2] - Fr(25, 100), b[3] - Fr(25, 100), b[4]))
print("original boxes (control):")
run('unchanged', lambda b: b)
