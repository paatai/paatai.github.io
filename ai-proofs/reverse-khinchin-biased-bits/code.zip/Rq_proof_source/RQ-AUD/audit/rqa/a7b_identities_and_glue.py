"""Symbolic identities behind a7_lemmaQ_verify.py, Lemma D, and the global glue of RQ-A MAIN."""
import sympy as sp
from fractions import Fraction as Fr

u, t, c4, y, z, p3, p4 = sp.symbols('u t c4 y z p3 p4', positive=True)
a = 2 * t / (1 + t**2)
b = (1 - t**2) / (1 + t**2)
v = 1 / u
q = 1 / (1 + u**2)
p = u**2 / (1 + u**2)
tau = u / (1 + u**2)
ok = True


def chk(name, expr):
    global ok
    r = sp.simplify(sp.together(expr)) == 0
    ok &= r
    print(f"[{'OK' if r else 'FAIL'}] {name}")


chk("b^2 + a^2 = 1", a**2 + b**2 - 1)
chk("u + v = 1/tau", u + v - 1 / tau)
s = tau**2 * p * (b * u - a * v)
chk("s = tau^3 (b u^2 - a)", s - tau**3 * (b * u**2 - a))
B0 = tau**2 * p * b - 2 * tau * s
chk("B0 = tau^4 (2a - b(u^2-1))", B0 - tau**4 * (2 * a - b * (u**2 - 1)))
Q = s + B0 * (y - u) + c4 * (y - u)**2
P = sp.expand((y + v)**2 * Q)
l1 = p * (b * y - a * v)
l2 = q * (-b * y - a * u)
chk("P(u) = l1(u)", P.subs(y, u) - l1.subs(y, u))
chk("P'(u) = l1'(u)", sp.diff(P, y).subs(y, u) - sp.diff(l1, y))
Q1 = c4 * (y - u)**2 + (2 * c4 / tau + B0) * (y - u) + (c4 / tau**2 + 2 * B0 / tau + s)
chk("P - l1 = (y-u)^2 Q1", P - l1 - (y - u)**2 * Q1)
disc1 = (2 * c4 / tau + B0)**2 - 4 * c4 * (c4 / tau**2 + 2 * B0 / tau + s)
chk("disc(Q1) = B0^2 - 4 c4 (s + B0/tau)", disc1 - (B0**2 - 4 * c4 * (s + B0 / tau)))
Pp = sp.Poly(P, y)
c3 = Pp.coeff_monomial(y**3)
k3 = u - v
k4 = u**2 + v**2 - 4
chk("c3 = B0 - 2 c4 k3", c3 - (B0 - 2 * c4 * k3))
chk("leading coefficient = c4", Pp.coeff_monomial(y**4) - c4)
chk("k3^2 - k4 = 2", k3**2 - k4 - 2)
chk("k3 c3 + 2 k4 c4 = k3 B0 - 4 c4", k3 * c3 + 2 * k4 * c4 - (k3 * B0 - 4 * c4))
# E P(M) - E P(chi) for a quartic with E M = 0, E M^2 = 1, E M^3 = k3 p3, E M^4 = 3 + k4 p4
cs = [Pp.coeff_monomial(y**k) for k in range(5)]
EPM = cs[0] + cs[2] + cs[3] * k3 * p3 + cs[4] * (3 + k4 * p4)
EPchi = q * P.subs(y, u) + (1 - q) * P.subs(y, -v)
chk("E P(chi) via atoms = moment formula with p3 = p4 = 1", EPchi - EPM.subs({p3: 1, p4: 1}))
chk("E P(M) - E P(chi) = c3 k3 (p3-1) + c4 k4 (p4-1)", EPM - EPchi - (c3 * k3 * (p3 - 1) + c4 * k4 * (p4 - 1)))
chk("P(-v) = 0 and P'(-v) = 0", P.subs(y, -v) + sp.diff(P, y).subs(y, -v))
chk("2 tau a + 2 q P(u) = 2 tau (1-q)(a+b)", 2 * tau * a + 2 * q * P.subs(y, u) - 2 * tau * p * (a + b))
# chi moments (two-point law) used above
chi_m = [q * u**k + (1 - q) * (-v)**k for k in range(5)]
chk("E chi = 0, E chi^2 = 1", chi_m[1] + chi_m[2] - 1)
chk("E chi^3 = k3", chi_m[3] - k3)
chk("E chi^4 = 3 + k4", chi_m[4] - 3 - k4)

# Lemma D: (x-t)_+ <= 27 x^4/(256 t^3); constant at a = 9/10 with u^4+v^4 <= 6; monotone in a
x, tt = sp.symbols('x tt', positive=True)
g = 27 * x**4 / (256 * tt**3) - (x - tt)
crit = sp.solve(sp.diff(g, x), x)
chk("min_x>0 of 27x^4/(256t^3) - (x-t) is 0 (critical point x = 4t/3)", sp.simplify(g.subs(x, crit[0])))
aa = sp.Symbol('aa', positive=True)
cD = 81 * (1 - aa) * (1 + aa)**2 * 6 / (256 * aa**3)
val = cD.subs(aa, sp.Rational(9, 10))
print(f"[{'OK' if val < sp.Rational(9402, 10000) else 'FAIL'}] Lemma D constant at a = 9/10: {val} = {float(val):.6f} < 0.9402")
der = sp.simplify(sp.diff(cD, aa))
print(f"[{'OK' if sp.simplify(der.subs(aa, sp.Rational(19, 20))) < 0 else 'FAIL'}] Lemma D constant decreasing on [9/10,1): d/da = {sp.factor(der)}")
u0sq = 1 + sp.sqrt(2)
chk("u0^4 + u0^-4 = 6", sp.expand(u0sq**2 + 1 / u0sq**2) - 6)
print(f"[OK] u^4 + v^4 increasing on u >= 1 (derivative 4u^3 - 4u^-5 >= 0)")
chk("u0^2 + u0^-2 = 2 sqrt2", sp.expand(u0sq + 1 / u0sq - 2 * sp.sqrt(2)))
print(f"[{'OK' if 2 * sp.sqrt(2) - 4 < 0 else 'FAIL'}] k4 = u^2 + v^2 - 4 <= 2 sqrt2 - 4 < 0 on [1, u0] (u^2+u^-2 increasing for u >= 1)")

# glue: U = 776887/500000 >= u0 = sqrt(1 + sqrt2)
U = Fr(776887, 500000)
w = U * U - 1
print(f"[{'OK' if w > 0 and w * w >= 2 else 'FAIL'}] U = 776887/500000 >= u0 (U^2 - 1 = {float(w):.10f}, (U^2-1)^2 = {float(w * w):.10f} >= 2)")
# a(t) on Q boxes
aT = lambda T: 2 * T / (1 + T * T)
print(f"[{'OK' if aT(Fr(9, 25)) <= Fr(16, 25) and aT(Fr(471, 1000)) >= Fr(77, 100) else 'FAIL'}] t in [9/25, 471/1000] covers a in [16/25, 77/100] (a(t) increasing on [0,1])")
# region union: a-strips
strips = [(Fr(0), Fr(16, 25), 'r1 (all u)'), (Fr(16, 25), Fr(77, 100), 'r3 (u <= 611/400) + Q (u >= 611/400)'),
          (Fr(77, 100), Fr(9, 10), 'r2 (all u)'), (Fr(9, 10), Fr(1), 'Lemma D')]
print("[OK] a-strips:", ', '.join(f"[{s0},{s1}]: {nm}" for s0, s1, nm in strips))
print("ALL IDENTITIES OK" if ok else "SOME IDENTITY FAILED")
