"""RQ-AUD A.22: the parts of RQ-A MAIN-6 marked PROVED (CLAIMS.md 14:11 snapshot 2a36088d, STATUS.md 13:58):
k = 5 three- and four-bit lemmas on [q6, q5] = [1 - sqrt(5/6), 1 - 2/sqrt5], and the n-coordinate near-sphere bound
at (1,...,1)/sqrt(n), n = 5, 6, from the OR-region identity.  Own code only (the Delta tables come from my A.20
script, cross-checked there and again here by direct enumeration).

 B  for k in (4, 5) (k = 4 is the A.20 regression): H_f = 4k (1-q)^(2k-2) - sum_i Delta_i(f)^2 on
    [q_{k+1}, q_k], q_k = 1 - sqrt((k-1)/k), g_k = k q^2 - 2k q + 1 (root q_k), for all f on n = 3, 4 bits:
    divide out g_k and g_{k+1} as often as they divide H_f, prove the cofactor > 0 on [q_{k+1}-, q_k+] twice
    (Arb root isolation and own Sturm); report the zero set and the g-divisible classes.
 X  Delta_i(f) by direct conditional expectation (exact) = the polynomial table, at q in {9/100, 1/10, 21/200}.
 D  G_n(c) = tau max_f c . Delta(f) exactly at rational u in [u5, u6], n = 3, 4.
 S  the conclusion exactly: G_n(c)^2 <= T5^2 |c|^2 = 20 (1-q)^8 tau^2 |c|^2 at rational u in [u5, u6], n = 3, 4.
 O  T4 <= T5 iff q <= q5, T6 <= T5 iff q >= q6; (1,...,1)/sqrt(n) lies in the OR region c_i > q sum c iff q < 1/n;
    the OR-region identity exactly at rational u in [u5, u6] for n = 5, 6.
 E  endpoint sharpness: the 4-bit bound fails just above q5 at (1,1,1,1); T5 is beaten by (1,...,1)/sqrt6 just
    below q6.
 N  negative tests of part B: interval widened to q5 + 1/1000; 20 -> 20 - 1e-6; the k = 6 target 24 (1-q)^10;
    for n = 3 the target 12 (1-q)^4 - 1e-6.
 A  hostile float search for MAIN-6 itself (not claimed PROVED): max over unit c in R^n of G_n(c)/T5, n = 3..7,
    at q6, mid, q5.
"""
import itertools
import os
import sys
import time
from fractions import Fraction as Fr
from math import comb

import numpy as np
from flint import fmpq_poly
from scipy.optimize import minimize

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, os.path.join(HERE, '..', 'rqb'))
from a20_k4_bits import delta_coeffs, or_table  # noqa: E402
from a20b_k4_tests import G_exact, atoms, delta_direct, peval  # noqa: E402
from a6_lemmaS_verify import positive_on, sqrt_hi, sqrt_lo  # noqa: E402
from a19_c17_verify import sturm_positive  # noqa: E402


def qk_bounds(k):
    """rational enclosure of q_k = 1 - sqrt((k-1)/k)"""
    return 1 - sqrt_hi(Fr(k - 1, k)), 1 - sqrt_lo(Fr(k - 1, k))


def g_poly(k):
    return fmpq_poly([1, -2 * k, k])


def target(k, const=None):
    """coefficients (low -> high) of const (1-q)^(2k-2), const = 4k by default"""
    c = 4 * k if const is None else const
    m = 2 * k - 2
    return [c * comb(m, j) * (-1) ** j for j in range(m + 1)]


def H_table(n, k):
    F, deltas = delta_coeffs(n)
    tw = target(k)
    L = max(len(tw), 2 * n - 1)
    H = np.zeros((F.shape[0], L), dtype=object)
    for j, c in enumerate(tw):
        H[:, j] += c
    for d in deltas:
        for a in range(n):
            for b in range(n):
                H[:, a + b] -= d[:, a].astype(object) * d[:, b].astype(object)
    return F, deltas, H


def divide_out(P, g):
    m = 0
    while P.degree() >= g.degree():
        qq, rr = divmod(P, g)
        if rr == 0:
            P, m = qq, m + 1
        else:
            break
    return P, m


def part_B(k):
    t0 = time.time()
    lo, _ = qk_bounds(k + 1)
    _, hi = qk_bounds(k)
    gk, gk1 = g_poly(k), g_poly(k + 1)
    assert len(gk.factor()[1]) == 1 and len(gk1.factor()[1]) == 1
    qkl, qkh = qk_bounds(k)
    q1l, q1h = qk_bounds(k + 1)
    # g_k > 0 on [0, q_k) and g_k(q_k) = 0; g_{k+1} vanishes at q_{k+1} and is < 0 on (q_{k+1}, 1]
    def gval(kk, x):
        return kk * x * x - 2 * kk * x + 1
    assert gval(k, qkl) > 0 > gval(k, qkh) and gval(k + 1, q1l) > 0 > gval(k + 1, q1h)
    assert q1h < qkl
    ok = True
    summary = {}
    for n in (3, 4):
        F, deltas, H = H_table(n, k)
        keys = [tuple(int(x) for x in row) for row in H]
        classes = {}
        for fi, key in enumerate(keys):
            classes.setdefault(key, []).append(fi)
        tables = [tuple(int(v) for v in row) for row in F]
        zero_f, gk_f, gk1_f = [], [], []
        bad_arb = bad_sturm = 0
        mult = {}
        min_float = float('inf')
        qs = np.linspace(float(q1l), float(qkh), 3001)
        for key, members in classes.items():
            if not any(key):
                zero_f += [tables[m] for m in members]
                continue
            P = fmpq_poly(list(key))
            P, mk = divide_out(P, gk)
            P, mk1 = divide_out(P, gk1)
            Q = [Fr(int(c.p), int(c.q)) for c in P.coeffs()]
            # H = g_k^mk g_{k+1}^mk1 Q; g_k >= 0 on [q_{k+1}, q_k]; g_{k+1} <= 0 there, so mk1 must be even or 0
            a_ok = positive_on(Q, lo, hi)[0]
            s_ok = sturm_positive(Q, lo, hi)
            sign_ok = mk1 % 2 == 0
            bad_arb += not (a_ok and sign_ok)
            bad_sturm += not (s_ok and sign_ok)
            if mk:
                gk_f += [tables[m] for m in members]
            if mk1:
                gk1_f += [tables[m] for m in members]
            mult[(mk, mk1)] = mult.get((mk, mk1), 0) + len(members)
            vals = np.polynomial.polynomial.polyval(qs, [float(c) for c in key])
            min_float = min(min_float, float(vals.min()))
        sets_km1 = list(itertools.combinations(range(n), k - 1)) if k - 1 <= n else []
        or_km1 = {or_table(n, S, sg) for S in sets_km1 for sg in (1, -1)}
        or_k = ({or_table(n, tuple(range(n)), sg) for sg in (1, -1)} if n == k else set())
        # H_{OR_S} = 4k (1-q)^(2k-2) - 4|S| (1-q)^(2|S|-2): identically 0 iff |S| = k, divisible by g_k iff |S| = k-1
        okn = (bad_arb == 0 and bad_sturm == 0 and set(zero_f) == or_k and set(gk_f) == or_km1 and not gk1_f)
        okOR = True
        for r in range(1, n + 1):
            for S in itertools.combinations(range(n), r):
                fidx = tables.index(or_table(n, S, 1))
                for i in range(n):
                    want = [0] * n
                    if i in S:
                        for j in range(r):
                            want[j] = 2 * comb(r - 1, j) * (-1) ** j
                    okOR &= [int(v) for v in deltas[i][fidx]] == want
        print(f"B  k = {k}, n = {n}: {F.shape[0]} f, {len(classes)} distinct H_f; cofactor > 0 on "
              f"[q{k + 1}-, q{k}+] fails for {bad_arb} (Arb) / {bad_sturm} (Sturm); H == 0 identically for "
              f"{len(zero_f)} f (expected the 2 ORs of {k} bits if n = k: {set(zero_f) == or_k}); g{k} | H for "
              f"{len(gk_f)} f (expected the {len(or_km1)} +-OR_S, |S| = {k - 1}: {set(gk_f) == or_km1}); "
              f"g{k + 1} | H for {len(gk1_f)} f; (mult g{k}, mult g{k + 1}) -> #f {dict(sorted(mult.items()))}; "
              f"Delta(OR_S) formula for all S: {okOR}; float min of H_f over nonzero classes {min_float:.3e} "
              f"({time.time() - t0:.1f}s)", flush=True)
        summary[n] = len(classes)
        ok &= okn and okOR
    return ok, summary


def part_X(rng):
    ok = True
    count = 0
    for n in (3, 4):
        F, deltas = delta_coeffs(n)
        nf = F.shape[0]
        if n == 3:
            sample = list(range(nf))
        else:
            ors = set()
            for r in (3, 4):
                for S in itertools.combinations(range(4), r):
                    for sg in (1, -1):
                        t = or_table(n, S, sg)
                        ors.add(int(sum((1 << x) for x in range(16) if t[x] == 1)))
            sample = sorted(ors | set(int(v) for v in rng.integers(0, nf, 3000)))
        for q in (Fr(9, 100), Fr(1, 10), Fr(21, 200)):
            for fi in sample:
                table = [int(v) for v in F[fi]]
                for i in range(n):
                    count += 1
                    ok &= delta_direct(table, n, i, q) == peval(deltas[i][fi], q)
    print(f"X  Delta_i(f) by direct conditional expectation = polynomial table at q in {{9/100, 1/10, 21/200}}: "
          f"{count} comparisons, {'all equal' if ok else 'MISMATCH'}", flush=True)
    return ok


def in_u5_u6(u):
    return u * u > 4 + 2 * sqrt_hi(Fr(5)) and u * u < 5 + sqrt_lo(Fr(30))


def part_D(rng):
    ok = True
    tested = 0
    for n, trials in ((3, 40), (4, 8)):
        F, deltas = delta_coeffs(n)
        for t in range(trials):
            u = Fr(int(rng.integers(2912, 3236)), 1000)
            assert in_u5_u6(u)
            q = 1 / (1 + u * u)
            tau = u / (1 + u * u)
            c = [Fr(int(rng.integers(-300, 301)), 100) for _ in range(n)]
            dq = [[peval(deltas[i][fi], q) for fi in range(F.shape[0])] for i in range(n)]
            best = max(sum((c[i] * dq[i][fi] for i in range(n)), Fr(0)) for fi in range(F.shape[0]))
            tested += 1
            ok &= G_exact(c, atoms(n, u)) == tau * best
    print(f"D  G_n(c) = tau max_f c . Delta(f) exactly, {tested} random (u, c) with u in [u5, u6], n = 3, 4: "
          f"{'all equal' if ok else 'MISMATCH'}", flush=True)
    return ok


def part_S(rng):
    ok = True
    worst = Fr(0)
    tested = 0
    us = [Fr(2911, 1000), Fr(29107, 10000), Fr(3), Fr(31, 10), Fr(32, 10), Fr(3236, 1000)]
    assert all(in_u5_u6(u) for u in us)
    for u in us:
        q = 1 / (1 + u * u)
        tau = u / (1 + u * u)
        T5sq = 20 * (1 - q)**8 * tau * tau
        for n in (3, 4):
            at = atoms(n, u)
            cands = [[Fr(int(rng.integers(-400, 401)), 100) for _ in range(n)] for _ in range(120)]
            for _ in range(60):
                cands.append([Fr(1) + Fr(int(rng.integers(-30, 31)), 1000) for _ in range(n)])
            if n == 4:
                for _ in range(40):
                    cands.append([Fr(1) + Fr(int(rng.integers(-30, 31)), 1000) for _ in range(3)]
                                 + [Fr(int(rng.integers(-30, 31)), 1000)])
            cands.append([Fr(1)] * n)
            for c in cands:
                if not any(c):
                    continue
                G = G_exact(c, at)
                lhs, rhs = G * G, T5sq * sum(ci * ci for ci in c)
                tested += 1
                ok &= lhs < rhs
                worst = max(worst, lhs / rhs)
    print(f"S  G_n(c)^2 < T5^2 |c|^2 exactly (strict, as q < q5) at u in {{2.911, 2.9107, 3, 3.1, 3.2, 3.236}}: "
          f"{tested} vectors, {'no violation' if ok else 'VIOLATION'}; largest ratio of squares "
          f"{float(worst):.12f} (at u = 2.9107 near u5, c = (1,1,1,1))", flush=True)
    return ok


def part_O(rng):
    import sympy as sp
    q = sp.Symbol('q', positive=True)
    T = {n: 2 * sp.sqrt(n) * (1 - q)**(n - 1) for n in range(4, 7)}
    r4 = sp.simplify(T[4] / T[5])
    r6 = sp.simplify(T[6] / T[5])
    s4 = sp.solve(sp.Eq(r4, 1), q)
    s6 = sp.solve(sp.Eq(r6, 1), q)
    ok = (len(s4) == 1 and sp.simplify(s4[0] - (1 - 2 / sp.sqrt(5))) == 0 and len(s6) == 1
          and sp.simplify(s6[0] - (1 - sp.sqrt(sp.Rational(5, 6)))) == 0)
    ok &= sp.diff(r4, q).subs(q, sp.Rational(1, 10)) > 0 and sp.diff(r6, q).subs(q, sp.Rational(1, 10)) < 0
    print(f"O  T4/T5 = {r4} (increasing, = 1 only at q5), T6/T5 = {r6} (decreasing, = 1 only at q6): {ok}",
          flush=True)
    q5hi = qk_bounds(5)[1]
    okr = all(q5hi < Fr(1, n) for n in (5, 6))
    print(f"O  (1,...,1)/sqrt(n) in the OR region (c_i > q sum c iff q < 1/n) for n = 5, 6 on [q6, q5]: {okr}",
          flush=True)
    okI = True
    tested = 0
    for trial in range(60):
        n = 5 + trial % 2
        u = Fr(int(rng.integers(2912, 3236)), 1000)
        qq = 1 / (1 + u * u)
        tau = u / (1 + u * u)
        c = [Fr(1) + Fr(int(rng.integers(-150, 151)), 1000) for _ in range(n)]
        if not all(ci > qq * sum(c) for ci in c):
            continue
        tested += 1
        okI &= G_exact(c, atoms(n, u)) == 2 * tau * (1 - qq)**(n - 1) * sum(c)
    print(f"O  OR-region identity exactly at {tested} random (u, c), u in [u5, u6], n = 5, 6, c near (1,...,1): "
          f"{okI}", flush=True)
    return ok and okr and okI and tested >= 50


def part_E():
    import mpmath as mp
    mp.mp.dps = 40
    ok = True
    out = []

    def G_ones(n, q):
        u = mp.sqrt((1 - q) / q)
        v = 1 / u
        return sum(q**j * (1 - q)**(n - j) * mp.binomial(n, j) * abs(j * u - (n - j) * v) for j in range(n + 1))

    for dq in (mp.mpf('1e-4'), mp.mpf('1e-7')):
        q = 1 - 2 / mp.sqrt(5) + dq
        T5 = 2 * mp.sqrt(5) * (1 - q)**4 * mp.sqrt(q * (1 - q))
        r = G_ones(4, q) / 2 / T5
        out.append(f"q5 + {mp.nstr(dq, 2)}: G_4(1,1,1,1)/(2 T5) = {mp.nstr(r, 12)}")
        ok &= r > 1
        q = 1 - mp.sqrt(mp.mpf(5) / 6) - dq
        T5 = 2 * mp.sqrt(5) * (1 - q)**4 * mp.sqrt(q * (1 - q))
        r = G_ones(6, q) / mp.sqrt(6) / T5
        out.append(f"q6 - {mp.nstr(dq, 2)}: G_6(1,...,1)/(sqrt6 T5) = {mp.nstr(r, 12)}")
        ok &= r > 1
    print("E  " + "; ".join(out), flush=True)
    return ok


def part_N():
    ok = True
    lo, _ = qk_bounds(6)
    _, hi = qk_bounds(5)
    msgs = []
    for n in (3, 4):
        F, deltas, H = H_table(n, 5)
        keys = {}
        for row in H:
            key = tuple(int(x) for x in row)
            keys[key] = keys.get(key, 0) + 1
        tw20 = target(5)
        eps_shift = [-Fr(1, 10**6) * comb(8, j) * (-1) ** j for j in range(9)]
        tw24 = target(6)
        tw12 = target(3, const=12)
        f_wide = f_eps = f_24 = f_12 = 0
        for key, m in keys.items():
            row = [Fr(x) for x in key]
            f_wide += m * (not positive_on(row, lo, hi + Fr(1, 1000))[0]) if any(row) else 0
            f_eps += m * (not positive_on([a + b for a, b in zip(row, eps_shift)], lo, hi)[0])
            to24 = [Fr(0)] * 11
            for j, c in enumerate(row):
                to24[j] += c
            for j, c in enumerate(tw20):
                to24[j] -= c
            for j, c in enumerate(tw24):
                to24[j] += c
            f_24 += m * (not positive_on(to24, lo, hi)[0])
            if n == 3:
                to12 = list(row)
                for j, c in enumerate(tw20):
                    to12[j] -= c
                for j, c in enumerate(tw12):
                    to12[j] += c
                to12[0] -= Fr(1, 10**6)
                f_12 += m * (not positive_on(to12, lo, hi)[0])
        # informational: the stronger k = 4 target 16 (1-q)^6 on [q6, q5] (H4 == 0 only for +-OR_4)
        tw16 = target(4)
        f_16 = 0
        for key, m in keys.items():
            to16 = [Fr(x) for x in key]
            for j, c in enumerate(tw20):
                to16[j] -= c
            for j, c in enumerate(tw16):
                to16[j] += c
            if any(to16):
                f_16 += m * (not (positive_on(to16, lo, hi)[0] and sturm_positive(to16, lo, hi)))
        msg = (f"n = {n}: on [q6, q5 + 1/1000] fails for {f_wide} f; 20 -> 20 - 1e-6 fails for {f_eps} f; "
               f"k = 6 target 24 (1-q)^10 fails for {f_24} f")
        if n == 3:
            # for n = 3 the binding f are +-OR_3 (12 (1-q)^4), strict on [q6, q5 + 1/1000] since 20 (1-q)^8 >
            # 12 (1-q)^4 iff q < 1 - (3/5)^(1/4) = 0.1199, and 24 (1-q)^10 >= 12 (1-q)^4 iff q <= 1 - 2^(-1/6) =
            # 0.1091 > q5: so only the 12 (1-q)^4 - 1e-6 corruption must fail
            msg += (f"; target 12 (1-q)^4 - 1e-6 fails for {f_12} f (the first three are expected to pass: "
                    f"20 (1-q)^8 > 12 (1-q)^4 for q < 0.1199, 24 (1-q)^10 >= 12 (1-q)^4 for q <= 0.1091)")
            ok &= f_12 >= 2 and f_wide == 0 and f_24 == 0
        else:
            ok &= f_wide == 2 and f_eps >= 2 and f_24 >= 2
        msg += (f"; informational: the stronger k = 4 bound 16 (1-q)^6 - sum Delta^2 > 0 on [q6-, q5+] fails for "
                f"{f_16} f besides the 2 with H4 == 0 (n = 4 only)")
        msgs.append(msg)
    for s in msgs:
        print("N  " + s, flush=True)
    return ok


def float_atoms(n, q):
    u = np.sqrt((1 - q) / q)
    X = np.array([[u if (x >> l) & 1 else -1 / u for l in range(n)] for x in range(1 << n)])
    k = (X > 0).sum(axis=1)
    return X, q**k * (1 - q)**(n - k)


def part_A(rng):
    q5 = 1 - 2 / np.sqrt(5)
    q6 = 1 - np.sqrt(5 / 6)
    lines = []
    ok = True
    for q in (q6, (q5 + q6) / 2, q5):
        T5 = 2 * np.sqrt(5) * (1 - q)**4 * np.sqrt(q * (1 - q))
        for n in (3, 4, 5, 6, 7):
            X, p = float_atoms(n, q)
            best, arg = -1.0, None
            starts = 120 if n <= 5 else 60
            for s in range(starts):
                if s < 4:
                    x0 = np.r_[np.ones(min(n, 4 + s)), np.zeros(n - min(n, 4 + s))] + 0.03 * rng.normal(size=n)
                else:
                    x0 = rng.normal(size=n)
                r = minimize(lambda c: -float(p @ np.abs(X @ c)) / (np.linalg.norm(c) * T5), x0,
                             method='Nelder-Mead', options={'xatol': 1e-10, 'fatol': 1e-13, 'maxiter': 6000})
                if -r.fun > best:
                    best, arg = -r.fun, r.x / np.linalg.norm(r.x)
            arg = arg * np.sign(arg[np.argmax(np.abs(arg))])
            lines.append(f"q = {q:.6f}, n = {n}: max G_n/T5 found {best:.10f} at {np.round(np.sort(arg)[::-1], 4)}")
            ok &= best <= 1 + 1e-9
    for s in lines:
        print("A  " + s, flush=True)
    return ok


def main():
    t0 = time.time()
    rng = np.random.default_rng(2026102214)
    parts = sys.argv[1] if len(sys.argv) > 1 else 'BXDSOENA'
    res = {}
    if 'B' in parts:
        ok4, s4 = part_B(4)
        res['B4 (A.20 regression: 39 / 1630 classes)'] = ok4 and s4 == {3: 39, 4: 1630}
        ok5, s5 = part_B(5)
        res['B5'] = ok5
    if 'X' in parts:
        res['X'] = part_X(rng)
    if 'D' in parts:
        res['D'] = part_D(rng)
    if 'S' in parts:
        res['S'] = part_S(rng)
    if 'O' in parts:
        res['O'] = part_O(rng)
    if 'E' in parts:
        res['E'] = part_E()
    if 'N' in parts:
        res['N'] = part_N()
    if 'A' in parts:
        res['A (informational: MAIN-6 not claimed)'] = part_A(rng)
    print(f"summary {res}")
    print(f"RESULT: {'ALL CHECKS PASSED' if all(res.values()) else 'FAILURES'} ({time.time() - t0:.0f}s)", flush=True)


if __name__ == '__main__':
    main()
