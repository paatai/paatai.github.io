"""A.31: own check of RQ-A U.6 (one-signed K). 256-bit arb; atoms, weights, m, theta and all partial sums are exact
Fractions, so every sign and every split x >= theta is decided exactly.

K = sum_j w_j delta_{x_j}, x_j > 0, sum w_j = 1; Z_K = sum_j x_j (N_j - lam_j), N_j ~ Poisson(lam_j = w_j/x_j^2).
m = sum w_j/x_j. For theta >= m: big atoms x_j >= theta, Lambda = sum_big lam_j, rho^2 = residual mass,
S_R = sum_res x_j N_j, m_S = sum_big w_j/x_j.

Evaluators (own code, independent of RQ-A's):
  E1 (sign-free, no use of E Z = 0): sum over the outer counts (n_j <= NMAX_j) of p(n) E|c(n) + x_J N_J| with
     E|c + x N| = c + x lam + 2 sum_{n : c + x n < 0} p(n) (-c - x n) (pointwise |y| = y + 2 y_-, finite sum);
     omitted outer counts cost at most sqrt(E (Z - shift)^2) sqrt(sum_j P(N_j > NMAX_j)) (Cauchy-Schwarz).
  E2 (finite): E|Z| = 2 E(Z)_- = 2 sum_{n : S(n) < m} p(n) (m - S(n)), S = sum_j x_j N_j >= 0.
Checks: E1 = E2; (a) both forms against E1; (b) E|Z_K| <= B(Lambda, rho^2) for random theta >= m; (c) E|Z_K| <=
g(lambda+_m) when lambda+_m >= 1/2, equality at single atoms; negative tests; a hostile float search with certified
re-evaluation at rationalised points; the scope (ii) intervals via concavity of B in rho^2.
Usage: python3 a31_u6_check.py [N_bc] [restarts]
"""
import math
import random
import sys
import time
from fractions import Fraction as F

import numpy as np
from scipy.optimize import minimize
from flint import arb, ctx

ctx.prec = 256
TAILBITS = 200
FAILS = []


def say(*a):
    print(*a)
    sys.stdout.flush()


def check(ok, msg):
    say(('PASS ' if ok else 'FAIL ') + msg)
    if not ok:
        FAILS.append(msg)


def ar(fr):
    fr = F(fr)
    return arb(fr.numerator) / fr.denominator


def g(l):
    return 2 * l.sqrt() * (-l).exp()


def s3(v, d=3):
    return v.str(d, radius=False)


def pmf(lam, n):
    out, p = [], (-lam).exp()
    for k in range(n + 1):
        out.append(p)
        p = p * lam / (k + 1)
    return out


def tail_bound(lam, n):
    """P(N > n) <= lam^(n+1)/(n+1)! / (1 - lam/(n+2)), used only with n + 2 > 2 lam."""
    assert n + 2 > 2 * float(lam.mid())
    t = arb(1)
    for k in range(1, n + 2):
        t = t * lam / k
    return t / (1 - lam / (n + 2))


def nmax_for(lam):
    n = max(4, int(2 * float(lam.mid())) + 2)
    while not bool(tail_bound(lam, n) < arb(2) ** -TAILBITS):
        n += 4
    return n


def lam_of(x, w):
    return ar(w) / ar(x) ** 2


def mean_m(atoms):
    return sum((w / x for (x, w) in atoms), F(0))


def inner_abs(c, x, lam, p):
    """E|c + x N| for N ~ Poisson(lam); c, x exact; p is the pmf list (extended in place)."""
    s = ar(c) + ar(x) * lam
    n = 0
    while c + x * n < 0:
        if n >= len(p):
            p.extend(pmf(lam, n + 50)[len(p):])
        s += 2 * p[n] * ar(-(c + x * n))
        n += 1
    return s


def E1(atoms, shift=None, plus=False):
    """Sign-free E|sum x_j N_j - shift| (or E(...)_+ if plus) with an explicit tail; returns (value, tail)."""
    if shift is None:
        shift = mean_m(atoms)
    ls = [lam_of(x, w) for (x, w) in atoms]
    order = sorted(range(len(atoms)), key=lambda j: float(ls[j].mid()))
    inner, outer = order[-1], order[:-1]
    xi, li = atoms[inner][0], ls[inner]
    pin = pmf(li, 60)
    nm = [nmax_for(ls[j]) for j in outer]
    ps = [pmf(ls[j], nm[k]) for k, j in enumerate(outer)]
    tot = [arb(0)]

    def rec(k, c, pr):
        if k == len(outer):
            v = inner_abs(c, xi, li, pin)
            if plus:
                v = (v + ar(c) + ar(xi) * li) / 2
            tot[0] += pr * v
            return
        x = atoms[outer[k]][0]
        for n in range(nm[k] + 1):
            rec(k + 1, c + x * n, pr * ps[k][n])

    rec(0, -shift, arb(1))
    pt = sum((tail_bound(ls[j], nm[k]) for k, j in enumerate(outer)), arb(0))
    second = ar(sum((w for (_, w) in atoms), F(0)) + (mean_m(atoms) - shift) ** 2)
    return tot[0], (second * pt).sqrt()


def Eneg(atoms, level):
    """E(level - S)_+ for S = sum x_j N_j: a finite sum over {S < level}."""
    ls = [lam_of(x, w) for (x, w) in atoms]
    pm = [(-l).exp() for l in ls]
    tot = [arb(0)]

    def rec(k, s, pr):
        if k == len(atoms):
            tot[0] += pr * ar(level - s)
            return
        x, l = atoms[k][0], ls[k]
        n, p = 0, pm[k]
        while s + x * n < level:
            rec(k + 1, s + x * n, pr * p)
            n += 1
            p = p * l / n

    rec(0, F(0), arb(1))
    return tot[0]


def E2(atoms):
    return 2 * Eneg(atoms, mean_m(atoms))


def split(atoms, theta):
    big = [(x, w) for (x, w) in atoms if x >= theta]
    res = [(x, w) for (x, w) in atoms if x < theta]
    Lam = sum((lam_of(x, w) for (x, w) in big), arb(0))
    rho2 = sum((w for (_, w) in res), F(0))
    mS = sum((w / x for (x, w) in big), F(0))
    return big, res, Lam, rho2, mS


def Bfun(Lam, rho2):
    r = ar(rho2) if isinstance(rho2, F) else rho2
    return (-Lam).exp() * ((Lam * (1 - r)).sqrt() + (r + Lam * (1 - r)).sqrt())


def rand_atoms(rng, nbig, nres, rho2_max, xres_min=40):
    """Atoms multiples of 1/1000 (big in [1, 1.6], residual in [xres_min/1000, 1.3]), weights multiples of 1/10000."""
    xs = [rng.randint(1000, 1600) for _ in range(nbig)] + [rng.randint(xres_min, 1300) for _ in range(nres)]
    r = rng.randint(nres, max(nres, int(rho2_max * 10000))) if nres else 0
    cr = sorted(rng.sample(range(1, r), nres - 1)) if nres > 1 else []
    wr = [b - a for a, b in zip([0] + cr, cr + [r])] if nres else []
    rb = 10000 - r
    cb = sorted(rng.sample(range(1, rb), nbig - 1)) if nbig > 1 else []
    wb = [b - a for a, b in zip([0] + cb, cb + [rb])]
    return [(F(x, 1000), F(w, 10000)) for x, w in zip(xs, wb + wr) if w > 0]


def fmt(atoms):
    return ' + '.join(f'{float(w):.4g} d{float(x):.4g}' for (x, w) in atoms)


def part_eq():
    say('== part e: equality in (c) at single atoms K = delta_x, 1 <= x <= sqrt 2')
    for x in (F(1), F(11, 10), F(6, 5), F(13, 10), F(14142, 10000), F(141421356, 10 ** 8)):
        atoms = [(x, F(1))]
        v, (v1, t1) = E2(atoms), E1(atoms)
        lam = 1 / ar(x) ** 2
        ok = bool(abs(v - g(lam)) < arb(2) ** -200) and bool(abs(v1 - v) < t1 + arb(2) ** -150)
        check(ok, f'E|Z_delta_x| = g(1/x^2) at x = {float(x):.9g} (|diff| < 2^-200; E1 agrees within its tail)')
    r2 = arb(2).sqrt()
    assert bool(r2 * 1 > 1 / r2)
    v = 2 * (-arb(1) / 2).exp() * (1 / r2)
    check(bool(abs(v - g(arb(1) / 2)) < arb(2) ** -200),
          'x = sqrt 2: only N = 0 has S < m = 1/sqrt 2, E|Z| = 2 e^(-1/2)/sqrt 2 = g(1/2) = sqrt(2/e)')
    big, res, Lam, rho2, mS = split([(F(9, 10), F(1))], F(10, 9))
    check(bool(Lam == 0), 'delta_0.9: m = 1/0.9 > 0.9, so lambda+_m = 0 and (c) does not apply (x < 1)')


def part_neg():
    say('== part n: negative tests')
    atoms = [(F(13, 10), F(8, 10)), (F(6, 10), F(2, 10))]
    m, theta = mean_m(atoms), F(1, 2)
    big, res, Lam, rho2, mS = split(atoms, theta)
    lhs = E2(atoms)
    r1 = 2 * (-Lam).exp() * (Eneg(res, m) if res else ar(m))
    check(theta < m and bool(abs(lhs - r1) > ar(F(1, 1000))),
          f'theta = 0.5 < m = {float(m):.5f} (atom 0.6 in [theta, m)): (a) fails, E|Z| = {s3(lhs, 6)} vs '
          f'{s3(r1, 6)}, so theta >= m is needed')
    atoms = [(F(14, 10), F(95, 100)), (F(5, 100), F(5, 100))]
    m = mean_m(atoms)
    big, res, Lam, rho2, mS = split(atoms, m)
    v = E2(atoms)
    check(bool(Lam == 0) and bool(v > ar(F(8, 10))),
          f'scope (i): K = {fmt(atoms)}: m = {float(m):.5f} > 1.4, lambda+_m = 0, E|Z_K| = {s3(v, 6)} > g(0) = 0')
    atoms = [(F(149, 100), F(99, 100)), (F(68, 100), F(1, 100))]
    m = mean_m(atoms)
    big, res, Lam, rho2, mS = split(atoms, m)
    v = E2(atoms)
    say(f'INFO RQ-A J2 maximiser (rounded): K = {fmt(atoms)}: Lambda = {s3(Lam, 5)} < 1/2, E|Z_K| = {s3(v, 7)}, '
        f'B = {s3(Bfun(Lam, rho2), 7)}, g(Lambda) = {s3(g(Lam), 7)} (outside (c))')


def part_cross(rng, n):
    say('== part x: cross-validation E1 (sign-free, tail) = E2 (finite sum)')
    for _ in range(n):
        atoms = rand_atoms(rng, rng.choice([1, 2]), rng.choice([0, 1]), 0.4, xres_min=250)
        v1, t1 = E1(atoms)
        v2 = E2(atoms)
        if not bool(abs(v1 - v2) < t1 + arb(2) ** -150):
            check(False, f'E1 != E2 for {fmt(atoms)}: {v1} vs {v2}')
            return
    check(True, f'E1 = E2 on {n} random K with <= 3 atoms (agreement within the E1 tail, < 2^-99)')


def part_a(rng, n):
    say('== part a: identity (a), both forms, against the sign-free E1, for random theta >= m')
    shapes = [(1, 1), (1, 2), (2, 1)]
    for _ in range(n):
        nb, nr = rng.choice(shapes)
        atoms = rand_atoms(rng, nb, nr, 0.5, xres_min=250)
        m = mean_m(atoms)
        cands = [m] + [x for (x, _) in atoms if x > m] + [m + F(rng.randint(1, 500), 1000)]
        theta = rng.choice(cands)
        big, res, Lam, rho2, mS = split(atoms, theta)
        lhs, tl = E1(atoms)
        if res:
            r1 = 2 * (-Lam).exp() * Eneg(res, m)
            ep, tp = E1(res, shift=m, plus=True)
            r2 = 2 * (-Lam).exp() * (ar(mS) + ep)
        else:
            r1 = 2 * (-Lam).exp() * ar(m)
            r2, tp = 2 * (-Lam).exp() * ar(mS), arb(0)
        ok1 = bool(abs(lhs - r1) < tl + arb(2) ** -150)
        ok2 = bool(abs(lhs - r2) < tl + 2 * tp + arb(2) ** -150)
        if not (ok1 and ok2):
            check(False, f'(a) fails at {fmt(atoms)}, theta {theta}: {lhs} {r1} {r2}')
            return
    check(True, f'(a) both forms equal E|Z_K| on {n} random (K, theta), theta in {{m, an atom above m, '
                f'm + U(0, 0.5)}}')


def one_point(atoms):
    return len(set(x for (x, _) in atoms)) == 1


def part_b_c(rng, N):
    say(f'== part b/c: (b) at theta = m and a random theta >= m, (c) at theta = m when lambda+_m >= 1/2 ({N} K, E2); '
        'equality is required exactly when K is one point mass with rho^2 = 0, strict inequality otherwise')
    nb = nb_eq = nc = nc_eq = 0
    minb, at_minb, minc, at_minc = None, None, None, None
    tiny = arb(2) ** -200
    for _ in range(N):
        atoms = rand_atoms(rng, rng.choice([1, 1, 2]), rng.choice([0, 1, 2, 3]),
                           rng.choice([0.02, 0.1, 0.5, 0.9]), xres_min=rng.choice([40, 150, 400]))
        m = mean_m(atoms)
        val = E2(atoms)
        for theta in (m, m + F(rng.randint(0, 800), 1000)):
            big, res, Lam, rho2, mS = split(atoms, theta)
            s = Bfun(Lam, rho2) - val
            nb += 1
            if rho2 == 0 and one_point(atoms):
                nb_eq += 1
                if not bool(abs(s) < tiny):
                    check(False, f'(b) equality fails at {fmt(atoms)}, theta {theta}: B - E = {s}')
                continue
            if not bool(s > 0):
                check(False, f'(b) fails at {fmt(atoms)}, theta {theta}: B - E = {s}')
            if minb is None or bool(s < minb):
                minb, at_minb = s, (fmt(atoms), float(theta - m), Lam, rho2)
        big, res, Lam, rho2, mS = split(atoms, m)
        if bool(Lam >= arb(1) / 2):
            s = g(Lam) - val
            nc += 1
            if one_point(atoms):
                nc_eq += 1
                if not bool(abs(s) < tiny):
                    check(False, f'(c) equality fails at {fmt(atoms)}: {s}')
                continue
            if not bool(s > 0):
                check(False, f'(c) fails at {fmt(atoms)}: g - E = {s}')
            if minc is None or bool(s < minc):
                minc, at_minc = s, (fmt(atoms), Lam, rho2)
    check(True, f'(b): {nb} (K, theta) pairs: equality to 2^-200 in the {nb_eq} one-point cases, B - E|Z_K| > 0 in '
                f'the other {nb - nb_eq}; smallest {s3(minb)} at {at_minb[0]}, theta - m = {at_minb[1]:.4g} '
                f'(Lambda {s3(at_minb[2], 4)}, rho^2 {float(at_minb[3]):.4g})')
    check(True, f'(c): {nc} K with lambda+_m >= 1/2: equality to 2^-200 in the {nc_eq} one-point cases, '
                f'g(lambda+_m) - E|Z_K| > 0 in the other {nc - nc_eq}; smallest {s3(minc)} at {at_minc[0]} '
                f'(Lambda {s3(at_minc[1], 4)}, rho^2 {float(at_minc[2]):.4g})')


def part_scope():
    say('== part s: scope (ii): B(Lambda, rho^2) > max(g(Lambda), C(q5)); B is concave in rho^2 (sum of square roots '
        'of affine functions), so the two endpoints decide each stated interval')
    C5 = g(2 * (arb(5) / 4).log())
    say(f'INFO C(q5) = g(2 ln(5/4)) = {s3(C5, 15)}')
    for Lam, lo, hi in ((F(49, 100), F(1, 1000), F(78, 1000)), (F(45, 100), F(1, 1000), F(36, 100)),
                        (F(3, 10), F(21, 100), F(86, 100)), (F(5, 1000), F(67, 100), F(1))):
        L = ar(Lam)
        c = C5 if bool(C5 > g(L)) else g(L)
        oklo, okhi = bool(Bfun(L, lo) > c), bool(Bfun(L, hi) > c)
        inside = [F(i, 1000) for i in range(0, 1001) if bool(Bfun(L, F(i, 1000)) > c)]
        tl, th = inside[0], inside[-1]

        def edge(a, b):
            for _ in range(70):
                mid = (a + b) / 2
                if bool(Bfun(L, mid) > c):
                    a = mid
                else:
                    b = mid
            return float((a + b) / 2)
        e_lo = edge(tl, tl - F(1, 1000)) if tl > 0 else 0.0
        e_hi = edge(th, th + F(1, 1000)) if th < 1 else 1.0
        msg = (f'Lambda = {float(Lam)}: claimed [{float(lo)}, {float(hi)}]; B > max at the left end: {oklo}, at the '
               f'right end: {okhi}; exact set {{B > max}} = ({e_lo:.6f}, {e_hi:.6f}); grid points (step 0.001) '
               f'{float(tl)} .. {float(th)}')
        if oklo and okhi:
            check(True, msg)
        else:
            say('REMARK ' + msg + ' -- the stated interval is rounded outward')
        if F(1, 4) < Lam < F(1, 2) and bool(g(L) > C5):
            # h(t) = h(0) with s = sqrt(1 - t): s^2 - 4 Lam s + 4 Lam - 1 = 0, so s = 1 or s = 4 Lam - 1
            t_star = 8 * Lam * (1 - 2 * Lam)
            eq = bool(abs(Bfun(L, t_star) - g(L)) < arb(2) ** -200)
            inside = bool(Bfun(L, t_star - F(1, 10 ** 6)) > g(L)) and not bool(Bfun(L, t_star + F(1, 10 ** 6)) > g(L))
            check(eq and inside, f'Lambda = {float(Lam)}: max = g(Lambda) and {{B > g(Lambda)}} = (0, 8 Lambda (1 - 2 '
                                 f'Lambda)) = (0, {float(t_star)}); B = g(Lambda) exactly at the right end (to 2^-200)')


def f_eabs(xs, ws):
    """float E|Z| via E2 (finite sum over S < m); returns (E|Z|, m, lam)."""
    lam = ws / xs ** 2
    m = float(np.sum(ws / xs))
    order = np.argsort(-xs)
    xo, lo = xs[order], lam[order]
    tot = [0.0]

    def rec(k, s, lp):
        if k == len(xo):
            tot[0] += math.exp(lp) * (m - s)
            return
        n = 0
        while s + xo[k] * n < m:
            rec(k + 1, s + xo[k] * n, lp - lo[k] + n * math.log(lo[k]) - math.lgamma(n + 1))
            n += 1

    rec(0, 0.0, 0.0)
    return 2 * tot[0], m, lam


def unpack(z, J):
    xs = 0.03 + 2.5 / (1 + np.exp(-np.clip(z[:J], -40, 40)))
    e = np.exp(z[J:2 * J] - np.max(z[J:2 * J]))
    return xs, e / e.sum()


def rationalise_keep(xs, ws, flags):
    """Atoms to 1e-6, weights to 1e-8 (renormalised exactly); zero weights dropped together with their flags."""
    wi = [int(round(w * 10 ** 8)) for w in ws]
    wi[int(np.argmax(ws))] += 10 ** 8 - sum(wi)
    keep = [i for i in range(len(xs)) if wi[i] > 0]
    return ([(F(int(round(xs[i] * 10 ** 6)), 10 ** 6), F(wi[i], 10 ** 8)) for i in keep], [flags[i] for i in keep])


def hostile(rng, restarts):
    """Maximise E|Z_K| - g(lambda+_m) (case c) or E|Z_K| - B(Lambda, rho^2) (case b) over non-degenerate K:
    'r' = residual mass >= 0.01; 's' = no residual, two support points >= 0.05 apart, each of mass >= 0.05."""
    say(f'== part h: hostile float search (Nelder-Mead from {restarts} feasible starts per case), certified '
        're-evaluation at the rationalised maximiser')

    def feasible(xs, ws, m, theta, mode):
        bigm = xs >= theta
        r2 = float(np.sum(ws[~bigm]))
        if mode == 'r':
            return r2 >= 0.01
        return r2 == 0 and abs(xs[0] - xs[1]) >= 0.05 and min(ws) >= 0.05

    def obj(z, kind, J, mode):
        xs, ws = unpack(z, J)
        v, m, lam = f_eabs(xs, ws)
        theta = m if kind == 'c' else m + 1.5 / (1 + math.exp(-max(-40, min(40, z[-1]))))
        bigm = xs >= theta
        L, r2 = float(np.sum(lam[bigm])), float(np.sum(ws[~bigm]))
        if not feasible(xs, ws, m, theta, mode):
            return 2.0
        if kind == 'c':
            if L < 0.5:
                return 2.0
            return -(v - 2 * math.sqrt(L) * math.exp(-L))
        return -(v - math.exp(-L) * (math.sqrt(L * (1 - r2)) + math.sqrt(r2 + L * (1 - r2))))

    cases = [('c', 2, 'r'), ('c', 3, 'r'), ('c', 2, 's'), ('b', 2, 'r'), ('b', 3, 'r'), ('b', 2, 's')]
    for kind, J, mode in cases:
        bv, bz, nstart = -9.0, None, 0
        for _ in range(restarts * 200):
            if nstart == restarts:
                break
            z0 = np.array([rng.gauss(0, 1.5) for _ in range(2 * J + (kind == 'b'))])
            if obj(z0, kind, J, mode) >= 1:
                continue
            nstart += 1
            res = minimize(obj, z0, args=(kind, J, mode), method='Nelder-Mead',
                           options={'maxiter': 1500, 'xatol': 1e-10, 'fatol': 1e-13})
            if res.fun < 1 and -res.fun > bv:
                bv, bz = -res.fun, res.x
        label = f'hostile ({kind}) J={J} ' + ('rho^2 >= 0.01' if mode == 'r' else 'rho^2 = 0, two separated atoms')
        if bz is None:
            say(f'INFO {label}: no feasible start found')
            continue
        xs, ws = unpack(bz, J)
        fm = float(np.sum(ws / xs))
        ftheta = fm if kind == 'c' else fm + 1.5 / (1 + math.exp(-max(-40, min(40, bz[-1]))))
        atoms, fbig = rationalise_keep(xs, ws, [bool(x >= ftheta) for x in xs])
        step, ok_cls = F(1, 10 ** 6), False
        for _ in range(5000):
            m = mean_m(atoms)
            if kind == 'c':
                theta = m
            else:
                theta = max(m, F(int(round(ftheta * 10 ** 6)), 10 ** 6))
                lo = [x for (x, _), b in zip(atoms, fbig) if not b]
                hi = [x for (x, _), b in zip(atoms, fbig) if b]
                if lo and theta <= max(lo):
                    theta = max(lo) + F(1, 10 ** 9)
                if hi and theta > min(hi):
                    theta = min(hi)
            cls = [x >= theta for (x, _) in atoms]
            big, res_, Lam, rho2, mS = split(atoms, theta)
            if cls == fbig and (kind == 'b' or bool(Lam >= arb(1) / 2)):
                ok_cls = True
                break
            if kind == 'b':
                break
            new = []
            for (x, w), b, c in zip(atoms, fbig, cls):
                if b and not c:
                    x += step
                elif c and not b:
                    x -= step
                elif b and not bool(Lam >= arb(1) / 2):
                    x -= step
                new.append((x, w))
            atoms = new
        if not ok_cls:
            say(f'INFO {label}: could not rationalise the maximiser without changing its big/residual split '
                f'(float sup {bv:.3e}); not certified')
            continue
        val = E2(atoms)
        s = (g(Lam) if kind == 'c' else Bfun(Lam, rho2)) - val
        check(bool(s > 0), f'{label} ({nstart} starts): float sup of E|Z| - bound = {bv:.3e}; certified bound - '
                           f'E|Z| = {s3(s)} at {fmt(atoms)}' + (f', theta - m = {float(theta - m):.4g}' if kind == 'b'
                                                               else '') +
                           f' (Lambda {s3(Lam, 5)}, rho^2 {float(rho2):.4g})')


def main():
    t0 = time.time()
    rng = random.Random(31)
    nbc = int(sys.argv[1]) if len(sys.argv) > 1 else 3000
    rst = int(sys.argv[2]) if len(sys.argv) > 2 else 40
    part_eq()
    part_neg()
    part_cross(rng, 200)
    part_a(rng, 300)
    part_b_c(rng, nbc)
    part_scope()
    hostile(rng, rst)
    say(f'time {time.time() - t0:.0f} s')
    say('ALL CHECKS PASSED' if not FAILS else f'{len(FAILS)} FAILURES')


if __name__ == '__main__':
    main()
