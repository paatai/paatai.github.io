"""RQ-AUD hostile test of RQ-A claim N.1 (six-moment relaxation), floating point, independent code.

For fixed (q, a), b = sqrt(1-a^2), m = min(1, a/b), the relaxation is
  V(q,a) = max E R_a(bM)  over laws of M and power sums (p3,p4,p5,p6) and P33, subject to
  EM = 0, EM^2 = 1, EM^3 = k3 p3, EM^4 = 3 + k4 p4, EM^5 = k5 p5 + 10 k3 p3,
  EM^6 = 15 + 15 k4 p4 + 10 k3^2 P33 + k6 p6,
  p3^2 <= P33 <= p4 <= m^2,  p4^2 <= p6 <= m^2 p4,  |p5| <= m p4.
N.1 claims V(q,a) <= tau (1-a) for all q in [1-1/sqrt2, 1/2], a in (0,1).

Unlike a fixed-grid LP (which under-estimates V), this code does column generation on the
whole line: after each LP solve, it maximises the reduced cost R(y) - lambda.(1,y,..,y^6) over
y in [-Y, Y] (fine grid + golden refinement) and adds the violators; convex constraints are
handled by adaptive tangent cuts at the current point.  Output: primal value (a feasible
point of the relaxation, up to LP tolerances) and the dual bound when the dual polynomial is
verified to dominate R on a fine grid of [-Y, Y] with positive leading coefficient.
"""
import numpy as np
from scipy.optimize import linprog
import sys


def cumulants(q):
    tau2 = q * (1 - q)
    tau = np.sqrt(tau2)
    th = 1 - 2 * q
    return th / tau, (1 - 6 * tau2) / tau2, th * (1 - 12 * tau2) / tau**3, (1 - 30 * tau2 + 120 * tau2**2) / tau2**2


def V(q, a, Y=14.0, iters=60, tol=1e-10, exactP33=False, verbose=False, slack6=False):
    u, v, tau = np.sqrt((1 - q) / q), np.sqrt(q / (1 - q)), np.sqrt(q * (1 - q))
    b = np.sqrt(1 - a * a)
    m = min(1.0, a / b)
    k3, k4, k5, k6 = cumulants(q)
    R = lambda y: (1 - q) * np.maximum(b * y - a * v, 0) + q * np.maximum(-b * y - a * u, 0)
    pts = list(np.linspace(-Y, Y, 801)) + [a * v / b, -a * u / b]
    cuts33 = list(np.linspace(-m, m, 9))
    cuts64 = list(np.linspace(0, m * m, 9))
    fine = np.linspace(-Y, Y, 400001)
    hist = []
    for it in range(iters):
        y = np.array(sorted(set(np.round(pts, 12))))
        nY = len(y)
        I3, I4, I5, I6, I33, IS6 = nY, nY + 1, nY + 2, nY + 3, nY + 4, nY + 5
        nv = nY + 6
        Aeq = np.zeros((7, nv))
        beq = np.zeros(7)
        for k in range(7):
            Aeq[k, :nY] = y**k
        beq[0], beq[2] = 1, 1
        Aeq[3, I3] = -k3
        Aeq[4, I4] = -k4; beq[4] = 3
        Aeq[5, I5] = -k5; Aeq[5, I3] = -10 * k3
        Aeq[6, I4] = -15 * k4; Aeq[6, I33] = -10 * k3 * k3; Aeq[6, I6] = -k6; beq[6] = 15
        # sixth moment carried by mass escaping to infinity (contributes nothing to E R in the limit)
        Aeq[6, IS6] = 1.0
        Aub, bub = [], []

        def row():
            return np.zeros(nv)
        for c in cuts33:  # P33 >= p3^2 : 2c p3 - c^2 <= P33
            r = row(); r[I3] = 2 * c; r[I33] = -1; Aub.append(r); bub.append(c * c)
        if exactP33:
            pass
        r = row(); r[I33] = 1; r[I4] = -1; Aub.append(r); bub.append(0)       # P33 <= p4
        for c in cuts64:  # p6 >= p4^2
            r = row(); r[I4] = 2 * c; r[I6] = -1; Aub.append(r); bub.append(c * c)
        r = row(); r[I6] = 1; r[I4] = -m * m; Aub.append(r); bub.append(0)    # p6 <= m^2 p4
        r = row(); r[I5] = 1; r[I4] = -m; Aub.append(r); bub.append(0)        # p5 <= m p4
        r = row(); r[I5] = -1; r[I4] = -m; Aub.append(r); bub.append(0)       # -p5 <= m p4
        bounds = [(0, None)] * nY + [(-m, m), (0, m * m), (-m**3, m**3), (0, m**4), (0, m * m),
                                     (0, None) if slack6 else (0, 0)]
        cobj = np.zeros(nv); cobj[:nY] = -R(y)
        # row scaling for conditioning
        sc = np.array([1.0 / max(1.0, Y**k) for k in range(7)])
        res = linprog(cobj, A_ub=np.array(Aub), b_ub=np.array(bub), A_eq=Aeq * sc[:, None], b_eq=beq * sc,
                      bounds=bounds, method="highs")
        if res.status != 0:
            return None
        lam = -res.eqlin.marginals * sc  # dual multipliers of the unscaled equality rows
        x = res.x
        val = -res.fun
        p3, p4, p6, P33 = x[I3], x[I4], x[I6], x[I33]
        # column generation: reduced cost on the fine grid
        poly = np.polyval(lam[::-1], fine)
        rc = R(fine) - poly
        j = np.argsort(rc)[-12:]
        newpts = [fine[i] for i in j if rc[i] > tol]
        # local maxima of rc (between grid points) via parabola refinement
        added = 0
        for yy in newpts:
            pts.append(yy); added += 1
        # tangent cuts
        cut_added = 0
        if P33 < p3 * p3 - 1e-12:
            cuts33.append(p3); cut_added += 1
        if p6 < p4 * p4 - 1e-12:
            cuts64.append(p4); cut_added += 1
        dualobj = lam[0] + lam[2] + 3 * lam[4] + 15 * lam[6]  # value of moment part at p=0 (info)
        hist.append((val, rc.max()))
        if verbose:
            print(f"  it {it}: val {val:.12f}, max reduced cost {rc.max():.3e}, cuts {cut_added}, support {np.sum(x[:nY] > 1e-9)}")
        if added == 0 and cut_added == 0:
            w = x[:nY]
            supp = [(float(y[i]), float(w[i])) for i in range(nY) if w[i] > 1e-9]
            lead_ok = lam[6] > 0
            return dict(val=val, target=tau * (1 - a), ratio=(2 * tau * a + 2 * val) / (2 * tau),
                        maxrc=float(rc.max()), lead_ok=lead_ok, supp=supp,
                        p=(float(p3), float(p4), float(x[I5]), float(p6), float(P33)), it=it)
    return dict(val=val, target=tau * (1 - a), ratio=(2 * tau * a + 2 * val) / (2 * tau), maxrc=float(rc.max()),
                lead_ok=lam[6] > 0, supp=None, p=None, it=iters)


if __name__ == '__main__':
    q0 = 1 - 1 / np.sqrt(2)
    qs = [q0, 0.2935, 0.295, 0.30, 0.32, 0.35, 0.375, 0.42, 0.5]
    As = [0.01, 0.03, 0.05, 0.08, 0.1, 0.13, 0.16, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65,
          0.68, 0.7, 0.7071, 0.715, 0.73, 0.76, 0.8, 0.85, 0.9, 0.95, 0.98]
    if len(sys.argv) > 1:
        qs = [float(sys.argv[1])]
    for q in qs:
        worst = None
        for a in As:
            r = V(q, a)
            if r is None:
                print(f"q={q:.5f} a={a}: LP failed")
                continue
            ub = (2 * np.sqrt(q * (1 - q)) * a + 2 * (r['val'] + max(r['maxrc'], 0))) / (2 * np.sqrt(q * (1 - q)))
            marg = 1 - ub
            if worst is None or marg < worst[0]:
                worst = (marg, a, r)
            flag = 'VIOLATION (primal)' if r['ratio'] > 1 + 1e-9 else ('possible violation (dual)' if marg < 0 else '')
            print(f"q={q:.5f} a={a:.4f}: primal ratio {r['ratio']:.9f}, upper {ub:.9f}, margin {marg:.3e}"
                  f"  (maxrc {r['maxrc']:.1e}, lead>0 {r['lead_ok']}, it {r['it']}) {flag}")
            sys.stdout.flush()
        print(f"== q={q:.5f}: min margin {worst[0]:.3e} at a={worst[1]}")
