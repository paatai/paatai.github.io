"""A.35 addendum: checks of RQ-A's U.9 write-up (MAIN_RESULT_U9.tex 12949c06, .md 342bc6b2, .pdf bff8f38a, 20:58 UTC)
beyond those of a35_u9_check.py. Own code.

  T  arb (256 bits): every decimal of the write-up (Corollary 2, its proof, Remark 3). A quoted "d..." is a
     truncation of x iff d <= x < d + 10^-n; a plain quoted decimal is a rounding iff |x - d| < 10^-n / 2.
  S  sympy, exact: the lower Mills bound identity beta' - w beta + 1 = 2/(1+w^2)^2 for beta = w/(1+w^2); B' and w B
     as printed; (1+w^2) B - w = 2/(w(w^2+3)); (f''/c)' = w M (w^2+3) - (w^2+2) from M' = w M - 1 alone; the
     comparison identity (r e^{-w^2/2})' = (beta' - w beta + 1) e^{-w^2/2} for r = beta - M; f(0) = 0, f'(0) = -c.
  R  Remark 2: E|G+x| = c (1 + x^2/2 - x^4/24 + ...) and
     d/d eps E|Z_{K_eps}| at 0 = -c/2 + (E|G+x| - c)/x^2 = phi(0) (-x^2/12 + O(x^4)), K_eps = (1-eps) delta_0 + eps delta_x;
     the series exactly (sympy), and the derivative against E|Z_{K_eps}| summed exactly in mpmath (60 digits) at
     eps = 10^-25 with Richardson extrapolation.

Usage: python3 a35b_u9_writeup_check.py
"""
import sys
import time
from fractions import Fraction

from flint import arb, ctx

FAIL = []


def chk(name, ok):
    print(('PASS ' if ok else 'FAIL ') + name, flush=True)
    if not ok:
        FAIL.append(name)


def part_T():
    ctx.prec = 256

    def g(x):
        return 2 * x.sqrt() * (-x).exp()

    def C_of(q):
        s = -(1 - q).log()
        best = None
        for k in range(1, 60):
            v = g(k * s)
            best = v if best is None else best.max(v)
        return best

    def to_arb(fr):
        return arb(fr.numerator) / fr.denominator

    def dec(text):
        return Fraction(text), len(text.split('.')[1])

    def truncated(x, text):
        d, n = dec(text)
        return bool(x > to_arb(d)) and bool(x < to_arb(d + Fraction(1, 10 ** n)))

    def rounded(x, text):
        d, n = dec(text)
        return bool(abs(x - to_arb(d)) < to_arb(Fraction(1, 2 * 10 ** n)))

    c = (arb(2) / arb.pi()).sqrt()
    q5 = 1 - 2 / arb(5).sqrt()
    q6 = 1 - (arb(5) / 6).sqrt()
    C5, C6 = C_of(q5), C_of(q6)
    chk('T C(q5) = g(2 ln 5/4) (|diff| < 1e-70)', bool(abs(C5 - g(2 * (arb(5) / 4).log())) < arb(10) ** -70))
    chk('T C(q6) = g(5 s(q6)) = g(6 s(q6)) (|diff| < 1e-70)',
        bool(abs(C6 - g(5 * (-(1 - q6).log()))) < arb(10) ** -70)
        and bool(abs(C6 - g(6 * (-(1 - q6).log()))) < arb(10) ** -70))
    print('   c =', c.str(20), ' C(q5) =', C5.str(20), ' C(q6) =', C6.str(20))
    for name, x, text in [('c', c, '0.7978845608'), ('C(q5)', C5, '0.8551004554'), ('C(q6)', C6, '0.8559844891'),
                          ('C(q5) - c', C5 - c, '0.0572158946'), ('C(q6) - c', C6 - c, '0.0580999283'),
                          ('2(C(q5) - c)', 2 * (C5 - c), '0.1144317'), ('2(C(q6) - c)', 2 * (C6 - c), '0.1161998')]:
        chk(f'T truncation {name} = {text}...', truncated(x, text))
    chk('T 0.114431 < 2(C(q5) - c) (Corollary 2, abstract)', bool(to_arb(Fraction('0.114431')) < 2 * (C5 - c)))
    chk('T Remark 3: c = 0.797885 (rounded)', rounded(c, '0.797885'))


def part_S():
    import sympy as sp
    w = sp.symbols('w', positive=True)
    beta = w / (1 + w ** 2)
    chk('S lower Mills: beta\' - w beta + 1 = 2/(1+w^2)^2',
        sp.simplify(sp.diff(beta, w) - w * beta + 1 - 2 / (1 + w ** 2) ** 2) == 0)
    chk('S beta\' = (1-w^2)/(1+w^2)^2', sp.simplify(sp.diff(beta, w) - (1 - w ** 2) / (1 + w ** 2) ** 2) == 0)
    B = (w ** 2 + 2) / (w ** 3 + 3 * w)
    chk('S B\' = -(w^4+3w^2+6)/(w^2(w^2+3)^2)',
        sp.simplify(sp.diff(B, w) + (w ** 4 + 3 * w ** 2 + 6) / (w ** 2 * (w ** 2 + 3) ** 2)) == 0)
    chk('S w B = (w^2+2)/(w^2+3)', sp.simplify(w * B - (w ** 2 + 2) / (w ** 2 + 3)) == 0)
    chk('S B\' - w B + 1 = -6/(w^2(w^2+3)^2)',
        sp.simplify(sp.diff(B, w) - w * B + 1 + 6 / (w ** 2 * (w ** 2 + 3) ** 2)) == 0)
    chk('S (1+w^2) B - w = 2/(w(w^2+3))', sp.simplify((1 + w ** 2) * B - w - 2 / (w * (w ** 2 + 3))) == 0)
    chk('S w B < 1 (so 0 < w M < 1): 1 - w B = 1/(w^2+3)', sp.simplify(1 - w * B - 1 / (w ** 2 + 3)) == 0)
    chk('S w beta > 0 and (1+w^2) beta - w = 0', sp.simplify((1 + w ** 2) * beta - w) == 0)
    Mf = sp.Function('M')
    M = Mf(w)
    sub = {sp.Derivative(M, w): w * M - 1}
    c = sp.sqrt(2 / sp.pi)
    fpp_over_c = (1 + w ** 2) * M - w
    d = sp.diff(fpp_over_c, w).subs(sub)
    chk('S (f\'\'/c)\' = w M (w^2+3) - (w^2+2) using M\' = w M - 1 only',
        sp.simplify(sp.expand(d - (w * M * (w ** 2 + 3) - (w ** 2 + 2)))) == 0)
    fp = c * (w * M - 1)
    chk('S f\' = c M\' and f\'\' = c (M + w M\') = c((1+w^2) M - w)',
        sp.simplify(sp.expand(sp.diff(c * M - 1, w).subs(sub) - fp)) == 0
        and sp.simplify(sp.expand(sp.diff(fp, w).subs(sub) - c * fpp_over_c)) == 0)
    rr = sp.Function('beta')(w) - M
    lhs = sp.diff(rr * sp.exp(-w ** 2 / 2), w).subs(sub)
    rhs = (sp.diff(sp.Function('beta')(w), w) - w * sp.Function('beta')(w) + 1) * sp.exp(-w ** 2 / 2)
    chk('S comparison: (r e^{-w^2/2})\' = (beta\' - w beta + 1) e^{-w^2/2} for r = beta - M',
        sp.simplify(sp.expand(lhs - rhs)) == 0)
    t = sp.symbols('t', real=True)
    f0 = sp.integrate((-t - c) * sp.exp(-t ** 2 / 2), (t, -sp.oo, 0))
    chk('S f(0) = int_{-oo}^0 (|t| - c) e^{-t^2/2} dt = 0', sp.simplify(f0) == 0)
    chk('S f\'(0) = h(0) + 0 f(0) = -c, and c M(0) = 1',
        sp.simplify(c * sp.sqrt(sp.pi / 2) - 1) == 0)


def part_R():
    import sympy as sp
    import mpmath as mp
    x = sp.symbols('x', real=True)
    c = sp.sqrt(2 / sp.pi)
    phi0 = 1 / sp.sqrt(2 * sp.pi)
    Phi = (1 + sp.erf(x / sp.sqrt(2))) / 2
    EG = 2 * phi0 * sp.exp(-x ** 2 / 2) + x * (2 * Phi - 1)
    t = sp.symbols('t', real=True)
    a = sp.Rational(7, 10)
    direct = sp.integrate((t + a) * sp.exp(-t ** 2 / 2), (t, -a, sp.oo)) / sp.sqrt(2 * sp.pi) \
        - sp.integrate((t + a) * sp.exp(-t ** 2 / 2), (t, -sp.oo, -a)) / sp.sqrt(2 * sp.pi)
    chk('R E|G+a| = 2 phi(a) + a (2 Phi(a) - 1) at a = 7/10 (exact integrals)',
        abs(sp.N(direct - EG.subs(x, a), 50)) < 1e-45)
    ser = sp.series(EG, x, 0, 9).removeO()
    print('   E|G+x| series:', sp.simplify(sp.expand(ser / c)))
    chk('R E|G+x| = c (1 + x^2/2 - x^4/24 + O(x^6))',
        sp.simplify(sp.expand(sp.series(EG - c * (1 + x ** 2 / 2 - x ** 4 / 24), x, 0, 6).removeO())) == 0)
    D = -c / 2 + (EG - c) / x ** 2
    serD = sp.series(D, x, 0, 6).removeO()
    print('   D(x) series / phi(0):', sp.simplify(sp.expand(serD / phi0)))
    chk('R D(x) = phi(0) (-x^2/12 + O(x^4))',
        sp.simplify(sp.expand(sp.series(D / phi0 + x ** 2 / 12, x, 0, 4).removeO())) == 0)

    mp.mp.dps = 60

    def EabsZ(xv, eps):
        lam = eps / xv ** 2
        sig = mp.sqrt(1 - eps)
        tot = mp.mpf(0)
        n = 0
        pn = mp.exp(-lam)
        while True:
            m = xv * (n - lam)
            val = 2 * sig * mp.npdf(m / sig) + m * (1 - 2 * mp.ncdf(-m / sig))
            tot += pn * val
            n += 1
            pn = pn * lam / n
            if n > 3 and pn < mp.mpf(10) ** -80:
                break
        return tot

    cm = mp.sqrt(2 / mp.pi)
    worst = 0
    for xv in [mp.mpf('0.05'), mp.mpf('0.2'), mp.mpf('0.5'), mp.mpf(1), mp.mpf('1.54'), mp.mpf(-1), mp.mpf(3)]:
        e1 = mp.mpf(10) ** -25
        F1 = (EabsZ(xv, e1) - cm) / e1
        F2 = (EabsZ(xv, 2 * e1) - cm) / (2 * e1)
        Dnum = 2 * F1 - F2
        Dform = -cm / 2 + (2 * mp.npdf(xv) + xv * (2 * mp.ncdf(xv) - 1) - cm) / xv ** 2
        lead = mp.npdf(0) * (-xv ** 2 / 12)
        rel = abs(Dnum - Dform) / abs(Dform)
        worst = max(worst, rel)
        print(f'   x = {mp.nstr(xv, 4):>5}: derivative (Richardson) {mp.nstr(Dnum, 15)}  formula {mp.nstr(Dform, 15)}'
              f'  phi(0)(-x^2/12) {mp.nstr(lead, 8)}  rel diff {mp.nstr(rel, 3)}', flush=True)
    chk('R derivative of E|Z_{K_eps}| at eps = 0 equals -c/2 + (E|G+x| - c)/x^2 (rel diff < 1e-15 at 7 points)',
        worst < 1e-15)


if __name__ == '__main__':
    t0 = time.time()
    print('A.35 addendum: RQ-A MAIN_RESULT_U9 write-up checks (RQ-AUD own code)')
    part_T()
    part_S()
    part_R()
    print(f'{"ALL CHECKS PASSED" if not FAIL else "FAILURES: " + str(FAIL)}  ({time.time() - t0:.1f} s)')
    sys.exit(1 if FAIL else 0)
