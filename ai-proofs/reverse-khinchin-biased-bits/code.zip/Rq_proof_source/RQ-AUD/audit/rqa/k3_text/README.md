# RQ-A: the exact value of R(q) for q in [25/169, 144/169]

Research workspace for the problem "determine R(q) = sup E|Σ α_i χ_i| / |α|_2 for normalised
q-biased bits".

**Results (computer-assisted; every computer step is exact or certified interval arithmetic and
was re-done by an independent program):**

- **Theorem 1** (audited VALID): R(q) = 2√(q(1-q)) exactly when 1-1/√2 ≤ q ≤ 1/√2.
  See `MAIN_RESULT.pdf` (or `MAIN_RESULT.md`).
- **Theorem 2** (audited VALID): R(q) = 2√2 (1-q) √(q(1-q)) exactly when
  1-√(2/3) ≤ q ≤ 1-1/√2 (and the mirror statement for q ≥ 1/√2). See `MAIN_RESULT_K2.pdf`
  (or `MAIN_RESULT_K2.md`).
- **Theorem 3** (not yet audited): R(q) = 2√3 (1-q)² √(q(1-q)) exactly when
  25/169 ≤ q ≤ 1-√(2/3) (and the mirror statement for q ≥ √(2/3)). See `MAIN_RESULT_K3.pdf`
  (or `MAIN_RESULT_K3.md`).

Together: R(q) = 2√(q(1-q)) · max{1, √2 q̂, √3 q̂²} with q̂ = max(q, 1-q), for all q in
[25/169, 144/169] ≈ [0.1479, 0.8521].

## Files

- `MAIN_RESULT.tex` / `.pdf` / `.md`: Theorem 1 and full proof.
- `MAIN_RESULT_K2.tex` / `.pdf` / `.md`: Theorem 2 and full proof.
- `MAIN_RESULT_K3.tex` / `.pdf` / `.md`: Theorem 3 and full proof.
- `SOTA.md`: statement, known results, literature.
- `CLAIMS.md`: every claim with its status (PROVED / NUMERICAL / ...).
- `STATUS.md`: current state and next steps. `AUDIT_REQUEST.md`: pointers for the auditor.
- `scripts/`: Python scripts. The ones that matter for the proofs:
  - `verify_all.py`: **independent verifier for Theorem 1** (symbolic identities, coverage,
    Sturm-sequence checks of the 379 six-moment certificates, interval arithmetic for the 641
    quartic boxes, the near-dictator constant);
  - `verify_k2.py`: **independent verifier for Theorem 2** (symbolic identities, exact coverage,
    the 784 one-coordinate cells, the 49,999 two-coordinate box certificates, the near-circle
    boxes and near-sphere pieces in interval arithmetic, the three-bit lemma); with `RQ_K=3` it
    is the **independent verifier for Theorem 3** (2,704 cells, 81,975 boxes);
  - `cover_lp6.py`, `lp6cert.py`, `exactcert.py`: generate and exactly verify the six-moment
    certificates (the LP only finds them; verification is exact);
  - `quartic_verify.py`: generates and verifies the quartic boxes (rational interval arithmetic);
  - `cover2c.py`, `cert2c.py`, `lp2c.py`, `nearcircle.py`, `nsphere3.py`, `cover_k2.py`:
    generate the Theorem 2 cover; with `RQ_K=3 RQ_AS=2/5`, and `cover_k3.py` for the cells, the
    Theorem 3 cover (`run_k3.sh`, job list `outputs/k3/jobs.txt`);
  - `break_tests.py`, `break_tests_k2.py` (also `RQ_K=3`): negative tests; `sanity_sweep.py`,
    `scan_k3.py`: numerical evidence; `cover_stats.py`: box statistics;
  - `verify_thmK_bf3.py`, `check_mills.py`: independent re-check of BF3 Theorem K;
  - `build_main_md.py`: regenerates the `.md` files from the `.tex` sources (pandoc).
- `outputs/`: certificates (`cover/*.json`, `quartic_cover.json`, `cover_k2/*.json`,
  `cover2c/*.json`, listed in `k2_manifest.json`; `k3/one/*.json`, `k3/cover2c/*.json`, listed in
  `k3_manifest.json`) and logs.

## Running

Python 3 with numpy, scipy, sympy and mpmath:

```
pip install numpy scipy sympy mpmath
cd scripts
python3 verify_all.py        # Theorem 1, about one minute: "ALL SELECTED PARTS PASSED: A B C D E"
python3 verify_k2.py         # Theorem 2, about five minutes on 8 cores: "... A B C D E F G"
RQ_K=3 python3 verify_k2.py  # Theorem 3: "... A B C D E F G"
python3 break_tests.py       # negative tests (Theorem 1)
python3 break_tests_k2.py    # negative tests (Theorem 2)
RQ_K=3 python3 break_tests_k2.py   # negative tests (Theorem 3)
```

To rebuild the PDFs: `latexmk -pdf MAIN_RESULT.tex MAIN_RESULT_K2.tex MAIN_RESULT_K3.tex`
(TeX Live); then `python3 scripts/build_main_md.py MAIN_RESULT_K2` (likewise `MAIN_RESULT_K3`,
and without argument for `MAIN_RESULT`).
