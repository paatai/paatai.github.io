# CLAIMS (RQ-A: central range, k = 2 regime, k = 3 regime)

Tags: PROVED / CONDITIONAL / NUMERICAL / CONJECTURE / FAILED.
Notation: q in (0,1/2], u = sqrt((1-q)/q), v = 1/u, tau = sqrt(q(1-q)), theta = 1-2q,
L = sum alpha_i chi_i, |alpha|_2 = 1, a = max|alpha_i| (WLOG alpha_1 = a > 0), b = sqrt(1-a^2),
M = b^{-1} sum_{i>=2} alpha_i chi_i, R_a(y) = (1-q)(y-av)_+ + q(-y-au)_+.
Rational parametrisation: q = 1/(1+u^2); then v = 1/u, tau = u/(1+u^2), 1-q = u^2/(1+u^2).
q0 = 1-1/sqrt2 corresponds to u0 = sqrt(1+sqrt2); q3 = 1-sqrt(2/3) to u3 = sqrt(2+sqrt6);
q4 = 1-sqrt3/2 to u4 = sqrt(3+2 sqrt3); 25/169 to u = 12/5.

## MAIN. R(q) = 2 sqrt(q(1-q)) exactly on [1-1/sqrt2, 1/sqrt2], and this range is sharp

- MAIN PROVED (computer-assisted, rigorous). RQ-AUD: VALID (A.6, 06:52 UTC); independent referee
  pending. For every q in
  [1-1/sqrt2, 1/sqrt2], every n and every unit alpha: E|sum alpha_i chi_i| <= 2 sqrt(q(1-q)).
  Hence R(q) = 2 sqrt(q(1-q)) there (attained by alpha = e_1; at q = 1-1/sqrt2 and q = 1/sqrt2
  also by (1,1)/sqrt2). For q outside this interval R(q) >= sqrt2 max(q,1-q) 2 sqrt(q(1-q)) >
  2 sqrt(q(1-q)) (C0.4). Full proof: MAIN_RESULT.md / MAIN_RESULT.pdf.
  Structure: Lemma 9.4 reduction + three certificates on the (u,a) rectangle [1,u0] x (0,1):
  * Lemma S (six-moment certificates, PROVED) + exact cover of 379 cells (PROVED, exact rationals,
    Sturm sequences): all (u,a) outside the two pieces below.
  * Lemma Q (quartic two-extremiser certificate, PROVED) + 641 boxes in (u,t), a = 2t/(1+t^2),
    verified in rational interval arithmetic (mean-value form) (PROVED): u in [611/400, u0],
    a in [16/25, 77/100]; this is where the extremisers e_1 and (1,1)/sqrt2 compete.
  * Lemma D (near-dictator, PROVED, analytic): a in [9/10, 1).
  Independent re-verification: scripts/verify_all.py (shares no code with the generators):
  symbolic identities, coverage, own Sturm code, mpmath intervals (20969 sub-boxes); all pass
  (outputs/verify_all_*.txt). Negative tests: scripts/break_tests.py.

## MAIN-2. k = 2 regime: R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) exactly on [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2], sharp

- MAIN-2 PROVED (computer-assisted, rigorous, independently re-verified). RQ-AUD: VALID (A.11,
  08:52 UTC); independent referee pending. After the audit (text only, data unchanged): the two
  cosmetic points of A.11 are applied (Lemma 20 states the convention for y = 0; Definition 23
  notes that 2 m_c^2 > 1 follows from phi(m_c) <= p* < 0), and the verifier's phi check now also
  requires 0 < m_c <= 1 and p* < 0 (all 1,189 ms boxes pass; new negative test).
  Full proof: MAIN_RESULT_K2.pdf (LaTeX source MAIN_RESULT_K2.tex; same text in MAIN_RESULT_K2.md).
  For every q in [q3, q0] = [0.183503, 0.292893] (and, by symmetry, [1-q0, 1-q3]), every n and
  every unit alpha: E|sum alpha_i chi_i| <= 2 sqrt2 (1-q) tau. Equality iff
  alpha = ±(e_i + e_j)/sqrt2, or q = q0 and alpha = ±e_i, or q = q3 and
  alpha = ±(e_i + e_j + e_k)/sqrt3. The interval is sharp: for q < q3, (1,1,1)/sqrt3 gives
  2 sqrt3 (1-q)^2 tau > T; for q > q0, e_1 gives 2 tau > T.
  Corollary (with MAIN): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 (1-q), sqrt2 q} for all q in
  [q3, 1-q3] = [0.18350, 0.81650].
  This confirms the RQ-B/Stone conjecture R(q) = max_k 2 sqrt(kq)(1-q)^{k-1/2} on [q3, q0], and
  extends RQ-C's C11 ([256/985, q0], audited VALID as A.9) to the largest possible interval.
  Mechanism (new): split off the TWO largest coefficients, so that the extremiser (1,1)/sqrt2
  sits at the boundary b = 0 and no tangency certificate is needed:
  L = a1 chi_1 + s a2 chi_2 + b M, |beta_i| <= min(1, a2/b), E|L| = E F(M) with
  F(y) = E|a1 chi_1 + s a2 chi_2 + b y| (4 atoms).  Coordinates a1 = r(1-t^2)/(1+t^2),
  a2 = 2rt/(1+t^2), b = sqrt(1-r^2).
  * Lemma 2C (two-coordinate value, PROVED, elementary): for c,d >= 0, q <= 1/2,
    E|c chi_1 + s d chi_2| = 2 tau max(c, d, [s=+1](1-q)(c+d)) <= 2 sqrt2 (1-q) tau sqrt(c^2+d^2)
    when q <= q0.
  * Lemma E (cell envelope, PROVED): with interval bounds for p_j x_j = r tau g_j and p_j b on a
    box, a convex piecewise-linear F_box >= F (<= 6 pieces).
  * Lemma 2S (two-coordinate six-moment certificate, PROVED): P >= F_box on R (exact Sturm on
    each piece) + the Lemma 9 moment bound < T_lo  ==>  E|L| < T.
  * Lemma NC (near-circle, PROVED, analytic): E|L| <= rG + sum_j p_j min(b, (27/128) b^4 E M^4 /(r|y_j|)^3),
    G = E|c chi_1 + s d chi_2| <= T; slack T(1-r) = T b^2/(1+r) beats the O(b^4) error.
  * a1 <= 9/20: one-coordinate six-moment cells with target tau(sqrt2(1-q) - a) (784 cells).
  * Three-bit lemma (PROVED, exact): for q in [q3, q0] and all c in R^3,
    E|c1 chi1 + c2 chi2 + c3 chi3| <= T |c|; equality only at ±(e_i+e_j), ±(1,1,1) (q = q3),
    ±e_i (q = q0). Proof: E[f chi_i] = tau Delta_i(f), and sum_i Delta_i(f)^2 <= 8 (1-q)^2 for
    all 256 Boolean f (exact Sturm). Same as the n = 3 case of RQ-C C6 (A.5), checked independently.
  * m-split near the triple point (q3, (1,1,1)/sqrt3) (PROVED): with m = max|beta_i| and a cut
    m_c in (1/sqrt2, 1]: (i) m <= m_c: certificate with the cap m_c; (ii) m >= m_c and the
    largest remaining coefficient is -m: then p3 <= -m_c^3 + (1-m_c^2)^{3/2} < 0 (sign lemma),
    used in the objective bound; (iii) it is +m: split off a third coordinate a3 = b m and apply
    the three-coordinate tail bound with the three-bit lemma (slack T b'^2/(1+r') against an
    O(b'^4) error), b' = b sqrt(1-m^2).
  Cover (u in [1553773/10^6, 1054691/500000] ⊃ [u0, u3], t in [0, 20711/50000], r in [9/20, 1],
  s = ±1): 55,515 boxes (48,810 exact LP certificates, 4,835 near-circle boxes, 1,189 m-split
  boxes with 1,669 near-sphere pieces, 681 boxes with a1 <= 9/20), 0 failures.
  Independent verifier scripts/verify_k2.py (no shared code with the generators): symbolic
  identities, exact 3-D tiling, strict re-check of all cells/boxes (envelope rebuilt as a max of
  16 sign patterns on each half-line), near-circle boxes and near-sphere pieces in mpmath
  intervals, the three-bit lemma by exact Sturm sequences: ALL PASS
  (outputs/verify_k2_ABCDEFG.txt). Negative tests (scripts/break_tests_k2.py,
  outputs/break_tests_k2.txt): corrupted certificates, cuts, pieces and widened boxes are rejected.
- Beyond q3: see MAIN-3 (k = 3 regime on [25/169, q3]).

## MAIN-3. k = 3 regime: R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) exactly on [25/169, q3] = [0.147929, 0.183503]

- MAIN-3 PROVED (computer-assisted, rigorous, independently re-verified). Audit requested
  (AUDIT_REQUEST.md, section MAIN-3); not yet audited.
  Full proof: MAIN_RESULT_K3.pdf (LaTeX source MAIN_RESULT_K3.tex; same text in MAIN_RESULT_K3.md).
  For every q in [q_L, q3] with q_L = 25/169 = 1/(1+(12/5)^2) (and, by symmetry, [1-q3, 144/169]),
  every n and every unit alpha: E|sum alpha_i chi_i| <= T3 := 2 sqrt3 (1-q)^2 tau.
  Equality iff alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q3 and alpha = ±(e_i+e_j)/sqrt2.
  First exact values of R(q) in the regime where three equal coefficients are optimal.
  Upper end sharp (for q > q3, (1,1)/sqrt2 gives T2 > T3). Lower end: for q < q4 = 1-sqrt3/2
  = 0.133975, (1,1,1,1)/2 gives 4(1-q)^3 tau > T3, so {q <= 1/2: R = T3} is between [25/169, q3]
  and [q4, q3]; the gap [q4, 25/169) is open (CONJECTURE: R = T3 there).
  Corollary (with MAIN and MAIN-2): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2},
  qh = max(q, 1-q), for all q in [25/169, 144/169] = [0.14793, 0.85207].
  Mechanism: exactly the machinery of MAIN-2 with target T3 (lower bound S3 min T~(u1), T~(u2),
  T~(u) = 2u^5/(1+u^2)^3, unimodal with maximum at sqrt5), A_S = 2/5, one-coordinate target
  tau(u2)(S3 (u1^2/(1+u1^2))^2 - a2), near-circle test (A) using T2 <= T3 for q <= q3, and the
  m-split now used throughout (the extremiser (1,1,1)/sqrt3 is the interior point m = 1, p3 = 1).
  * Three-bit lemma, k = 3 (PROVED, exact): for q in [25/169, q3] and all c in R^3,
    E|c . chi| <= T3 |c|; equality only at ±(1,1,1) and, at q = q3, ±(e_i+e_j). Proof:
    sum_i Delta_i(f)^2 <= 12 (1-q)^4 for all 256 Boolean f (exact Sturm; P_f = 4(1-q)^2 mu3 for
    OR_2, P_f = 0 for OR_3).
  Cover (u in [2109381/10^6, 12/5] ⊃ [u3, 12/5], t in [0, 20711/50000], r in [2/5, 1], s = ±1):
  81,975 boxes (57,333 exact LP certificates, 2,534 near-circle boxes, 21,232 m-split boxes with
  32,932 near-sphere pieces, 876 boxes with a1 <= 2/5) and 2,704 one-coordinate cells; 0 failures.
  Data in outputs/k3/ (listed in outputs/k3_manifest.json; md5s in outputs/k3_MD5SUMS.txt); generation: scripts/run_k3.sh with
  outputs/k3/jobs.txt (RQ_K=3 RQ_AS=2/5 cover2c.py ...; cover_k3.py).
  Independent verifier: RQ_K=3 python3 verify_k2.py (parts A-G as for MAIN-2, with the k = 3
  target, coverage of [U-, 12/5] x [0, T8] x [2/5, 1], and the k = 3 three-bit claim):
  outputs/verify_k3_ABCDEFG.txt. Negative tests: RQ_K=3 python3 break_tests_k2.py
  (outputs/break_tests_k3.txt).
- Why it stops at 25/169 (NUMERICAL, outputs/k3/scan_one.txt, scan_two.txt): the one-coordinate
  six-moment bound tends to the six-moment Gaussian value 0.888074 as a1 -> 0 (ratio to T3:
  0.9937 at q = 0.15, 0.9990 at q = 0.14, 1.0027 at q = 0.135), and the two-coordinate route
  near a1 = a2 = 0.55 fails for every tried m_c at q = 0.14. Gaussian 2k-moment values of
  sup E|X| (float LP): 6: 0.888074, 8: 0.886410, 10: 0.856068, 12: 0.855086, against
  T3(q4) = 0.884970 and sqrt(2/e) = 0.857764. So reaching q4 by this route needs ten moments,
  plus a split for the four-way tie (1,1,1,1)/2 at q4.

## C0. Elementary facts
- C0.1 PROVED. E|aχ + bM| = 2τa + 2E R_a(bM) for M independent of χ with EM=0 (BF3 Lemma 9.4;
  re-derived: E|aχ+y| = q|au+y| + (1-q)|y-av| = 2τa + (2q-1)y + 2R_a(y); symbolic check in
  verify_all.py part A1).
- C0.2 PROVED. Cumulants of χ: κ3 = u-v, κ4 = u^2+v^2-4, κ5 = (u-v)(u^2+v^2-10),
  κ6 = w^2-26w+64 with w = u^2+v^2. Moments of M = Σβ_iχ_i (|β|=1), p_j = Σβ_i^j:
  EM^3 = κ3 p3, EM^4 = 3+κ4 p4, EM^5 = κ5 p5 + 10κ3 p3,
  EM^6 = 15 + 15κ4 p4 + 10κ3^2 p3^2 + κ6 p6.  (Additivity of cumulants; symbolic check of the
  cumulants and exact-enumeration check of the moment formulas in verify_all.py part A2.)
- C0.3 PROVED. If max|β_i| <= m <= 1: p3^2 <= p4 <= m^2, p4^2 <= p6 <= m^2 p4, |p5| <= m p4.
  (Cauchy-Schwarz and |β_i| <= m.)
- C0.4 PROVED. Two equal coefficients: E|χ1+χ2|/sqrt2 = sqrt2(1-q)·2τ; more generally for
  a,b>0 with q/(1-q) <= b/a <= (1-q)/q: E|aχ1+bχ2| = 2τ(1-q)(a+b).
- C0.5 PROVED. Level-one form ⇔ L1 form (BF3 end of 9.4; standard duality).

## K. Re-verification of BF3 Theorem K on [3/8,5/8] (now superseded by MAIN)
- K.1 PROVED (independent re-derivation). The logic of BF3's proof (Lemmas 9.4–9.7, Cases
  A/B/C, inequality (12) via zero discriminants, reduction of ψ<=1 to the cubic (13)) was
  re-derived line by line; no gap found. Mills-ratio derivatives A'(w), B'(w) and k'(w) verified
  symbolically (scripts/check_mills.py).
- K.2 PROVED (exact arithmetic, scripts/verify_thmK_bf3.py, outputs/verify_thmK_bf3.txt).
  Independent script, written from the statement only: Case A thresholds on the 64 intervals,
  Case B hypotheses, Case C via the box bound with bisection (2784 boxes with 4-way bisection,
  depth <= 6), and the hand tables for q = 3/8, 2/5, 5/12. All pass.

## N. New mechanism: six-moment relaxation of the remainder (no induction)
- N.1 PROVED (as Lemma S + cover; see MAIN). Originally NUMERICAL: the LP
  "max E R_a(bM) over laws of M subject to EM=0, EM^2=1 and the moment identities of C0.2 with
  power sums in the region of C0.3 (m = min(1,a/b))" has value <= τ(1-a) for all q in [q0,1/2],
  a in (0,1); margin 0 only at (q0, 1/sqrt2) and as a -> 1 (scripts/scan_lp6.py).
  As a -> 0 the LP tends to sup{E|X| : EX^k = EZ^k, k<=6} = 0.8881, < 2τ iff q > 0.27015 (corrected from 0.2744, audit A.6 fix f1).
  Near (q0,1/sqrt2) the LP margin is ≈ sqrt2 (q-q0), i.e. the LP is asymptotically exact there.
- N.2 PROVED (as Lemma Q + box cover; see MAIN). Quartic certificate
  P(y) = (y+v)^2(c4 y^2+By+G), tangent to R_a(b·) at y = u and y = -v. Closed forms:
  B0 = tau^4(2a-b(u^2-1)), s = tau^3(b u^2-a), B = B0-2c4 u, G = s-B0 u+c4 u^2;
  P >= 0 and P >= l1 iff c4 > B0^2/(4s); E P(M) <= E P(χ) iff c4 <= κ3 B0/4 (uses κ3^2-κ4 = 2);
  P >= l2 via an explicit sufficient condition on the Taylor coefficients at y = -au/b.
  Gives E R_a(bM) <= E R_a(bχ), hence E|L| <= E|aχ1+bχ2| = 2τ(1-q)(a+b) <= 2τ for q >= q0.
- N.3 PROVED (Lemma D). For a >= 9/10 and u in [1,u0]: E R_a(bM) <= 0.9402 τ(1-a), from
  (x-t)_+ <= 27x^4/(256t^3), EM^4 <= 3 (κ4 <= 0) and u^4+v^4 <= 6.

## Dead ends (reasoning, recorded for the other agents)
- FAILED: 1-D Bellman function V(x) (adaptive game value >= 2τ sqrt(1+θ^2) > 2τ).
- FAILED: gradient-recursion Bellman B(p) (strict concavity fails for all q < 1/2).
- FAILED: moment LP with only {EM, EM^2, E|M|} (fake two-point law at q0, P(top) = 0.2295).
- BF3 method (Stein/zero-bias + cubic) stops near q ≈ 0.37.
