# Audit requests from RQ-A

## MAIN-3 (new, 2026-10-22 09:46 UTC): Theorem 3 = CLAIMS.md MAIN-3

(The ledger ids A.12 and A.13 are already used for RQ-C C12 and RQ-B C11-C12, so this request has
no id yet; please give it the next free one.)

Claim for audit: **R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for all q in [q_L, q3] = [25/169, 1-sqrt(2/3)]
(and R(q) = 2 sqrt3 q^2 sqrt(q(1-q)) on the mirror [1-q3, 144/169]); equality holds iff
alpha = ±(e_i+e_j+e_k)/sqrt3, or q = q3 and alpha = ±(e_i+e_j)/sqrt2; and
[25/169, q3] ⊆ {q <= 1/2 : R(q) = T3(q)} ⊆ [q4, q3] with q4 = 1-sqrt3/2.** With Theorem 1 (A.6) and
Theorem 2 (A.11): R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2}, qh = max(q, 1-q), on
[25/169, 144/169] = [0.14793, 0.85207].

- Proof: `MAIN_RESULT_K3.pdf` (14 pages; LaTeX source `MAIN_RESULT_K3.tex`; same text in
  `MAIN_RESULT_K3.md`). It follows `MAIN_RESULT_K2` step by step and is self-contained in the same
  sense. The paragraph "Relation to Theorem 2" lists what changed.
- Data: all files are listed in `outputs/k3_manifest.json`: 2,704 one-coordinate cells
  (`outputs/k3/one/o00.json` ... `o09.json`) and 81,975 two-coordinate boxes in 87 files
  (`outputs/k3/cover2c/p00.json` ... `p57.json`, `m00.json` ... `m28.json`; p = sign +1,
  m = sign -1). Kinds: 57,333 lp, 2,534 nc, 21,232 ms (32,932 pieces), 876 small. md5s:
  `outputs/k3_MD5SUMS.txt`.
- Independent verifier: `cd scripts && RQ_K=3 python3 verify_k2.py` (parts A-G, about 8 minutes on
  8 cores). Output: `outputs/verify_k3_ABCDEFG.txt`. This is the A.11 verifier with the parameter
  K = 3: target 2 sqrt3 (1-q)^2 tau with the rational lower bound S3 <= sqrt3, A_S = 2/5, the
  endpoint check U- < u3 and U+ = 12/5 < u4 (part B0), and the k = 3 three-bit claim in part G.
  Without RQ_K it
  reproduces the A.11 run (`outputs/verify_k2_ABCDEFG.txt`).
- Negative tests: `RQ_K=3 python3 break_tests_k2.py` (seconds), output `outputs/break_tests_k3.txt`.

Suggested audit points (where an error would most likely hide):
1. The target and its lower bound (eq. (2)): T = sqrt3 T~(u) with T~(u) = 2u^5/(1+u^2)^3; T~ is
   unimodal with its maximum at u = sqrt5 = 2.236, which lies inside [u3, 12/5], so on a box the
   minimum is at an endpoint and T^-(u1,u2) = S3 min(T~(u1), T~(u2)) is a valid lower bound.
2. Lemma 5 (three-bit lemma, k = 3): P_f = 12(1-q)^4 - sum_i Delta_i(f)^2 >= 0 for all 256 Boolean f
   on [25/169, q3]. P_f vanishes identically only for ±OR_3, and at q3 also for ±OR_2. There is no
   lower end coming from three bits.
3. Lemma 4 and Lemma 20(A): the two-coordinate value is at most T2 r, and T2 <= T needs q <= q3,
   i.e. u >= u3. The cover starts at U- = 2109381/10^6, slightly below u3 = 2.10938137..., and the
   theorem uses the boxes only at points with u >= u3.
4. Lemma 13 (one-coordinate cells, a1 <= 2/5): the target
   Theta_1 = tau(u2) (S3 (u1^2/(1+u1^2))^2 - a2), a lower bound for tau(u) (sqrt3 (1-q)^2 - a) on the
   cell, and the condition 2 tau a + 2 E P(M) <= T.
5. Lemma 23 (m-split) is now used throughout [u3, 12/5] (21,232 of the 69,871 sign +1 boxes),
   with the pieces (A3)/(B3) of Lemma 21, whose main term rests on Lemma 5.
6. Coverage (part B): [U-, 12/5] x [0, T8] x [2/5, 1] for each sign; the small boxes
   (r2 c(t1) <= 2/5); the cells on [U-, 12/5] x [0, 2/5].
7. That the theorem is claimed only for u in [u3, 12/5]. As in A.11, the negative tests show that
   parts E/F alone do not detect a box moved outside this range (here: below u3), as expected.

## A.11 (Theorem 2) — rated VALID by RQ-AUD at 08:52 UTC; text fixes applied

Both cosmetic points of the A.11 report are applied in `MAIN_RESULT_K2.tex/.md/.pdf` (and in the same
places of `MAIN_RESULT_K3`):
- Lemma 20 (tail bound) is now stated for all real y, with the convention that for y = 0 the
  minimum is read as its first entry.
- Definition 23 now asks for m_c in (0, 1] and phi(m_c) <= p* < 0, and notes that this forces
  2 m_c^2 > 1.

One verifier change (stricter, no data change): `phi_ok` in `verify_k2.py` now also requires
0 < m_c <= 1 and p* < 0. Before, a record with m_c < 0 and p* > 0 could have satisfied the phi
inequality; in that case the cap min(m̄, m_c) of c(1) would have been negative. No data record is
of this kind: all 1,189 ms boxes of Theorem 2 (and all 21,232 of Theorem 3) pass the stricter
check. The negative tests now include this case (rejected 40/40). The full verification was rerun
with the final code (`outputs/verify_k2_ABCDEFG.txt`). The md5s in `outputs/k2_MD5SUMS.txt` are
unchanged.

### Original A.11 request (2026-10-22 08:30 UTC)

Claim for audit: **R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) for all q in [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2]
(and the mirror [1-q0, 1-q3]); the interval is sharp; equality holds iff alpha = ±(e_i+e_j)/sqrt2,
or q = q0 and alpha = ±e_i, or q = q3 and alpha = ±(e_i+e_j+e_k)/sqrt3.** With Theorem 1 (A.6):
R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 (1-q), sqrt2 q} on [q3, 1-q3].

- Proof: `MAIN_RESULT_K2.pdf` (13 pages; LaTeX source `MAIN_RESULT_K2.tex`; same text in
  `MAIN_RESULT_K2.md`). Self-contained except for BF3 Lemma 9.4 and Lemma 7 of `MAIN_RESULT`
  (both already audited), which it restates with proof.
- Data: all files are listed in `outputs/k2_manifest.json`: 784 one-coordinate cells
  (`outputs/cover_k2/one_A.json`, `one_B.json`) and 55,515 two-coordinate boxes in 114 files
  `outputs/cover2c/s*.json`, `b*.json`. md5s: `outputs/k2_MD5SUMS.txt`.
- Independent verifier: `cd scripts && python3 verify_k2.py` (parts A-G, about 5 minutes on 8
  cores; parts B and D take most of it). Output: `outputs/verify_k2_ABCDEFG.txt`. It shares no
  code with the generators except the Sturm, integer-square-root and tiling helpers of
  `verify_all.py` (audited in A.6).
- Negative tests: `python3 break_tests_k2.py` (seconds), output `outputs/break_tests_k2.txt`.

Suggested audit points (where an error would most likely hide):
1. Lemma 13 (objective bound), in particular the variant with p* (it needs c3 + 10 c5 >= 0,
   kappa3 >= k3^- > 0 and p* < 0), and the cumulant enclosures on [u1, u2].
2. Lemma 11 (sign information) and the case split in Lemma 24 (m-split): m <= m_c; some
   beta_i = -m; otherwise some beta_i = +m. The pieces must cover [m_c, min(1, mbar(B))].
3. Lemmas 15-17: the box enclosures (b^-, b^+, mbar(B)) and the envelope F_B on each half-line.
4. Lemma 21 (near-circle tests A/B) and Lemma 22 with the piece tests (A3)/(B3): the
   enclosures of b', r' and a3 = b m, and the use of E M'^4 <= 3 + max(0, kappa4).
5. Lemma 6 (three-bit lemma): the 256-function exact check (part G), the endpoint handling with
   the minimal polynomials of q3 and q0, and the equality cases used in Theorem 1(b).
6. Coverage (part B): tiling of [U-, U+] x [0, T8] x [9/20, 1] for each sign, the small boxes
   (r2 c(t1) <= 9/20), the one-coordinate cells on [U-, U+] x [0, 9/20], and U- < u0, U+ >= u3,
   T8 >= sqrt2 - 1.
7. That the theorem is only claimed for u in [u0, u3]: Lemma 21(A) needs q <= q0 and Lemma 24
   needs q in [q3, q0]. The negative tests confirm that parts E/F alone do not detect a box moved
   outside this range, as expected (Section 9, "Negative tests").

## A.6 (Theorem 1) — rated VALID by RQ-AUD at 06:52 UTC; text fixes applied

Both text fixes from the A.6 report are applied in `MAIN_RESULT.tex/.md/.pdf` (07:40 UTC):
- (f1) Remark 2: "q > 0.2744" is now "q > 0.27015" (0.8880738 = 2 tau at q = 0.2701496). The same
  fix is applied in CLAIMS.md N.1.
- (f2) The stray "0" before the end-of-proof symbol in the proof of Theorem 1(c) came from the
  pandoc conversion of `\qed`; the tex now ends the proof with `$\square$`, and the md is clean.
No mathematical content changed. The certificate data files are unchanged. (08:30 UTC: the md
generator now also prints equation numbers instead of raw `[eq:...]` anchors; no text change.)

### Original A.6 request

Claim for audit: **R(q) = 2 sqrt(q(1-q)) for all q in [1-1/sqrt2, 1/sqrt2]; the range is sharp;
extremisers are ±e_j, plus ±(e_i+e_j)/sqrt2 at the two endpoints.**

- Proof: `MAIN_RESULT.pdf` (LaTeX source `MAIN_RESULT.tex`; the same text is in `MAIN_RESULT.md`).
- Data: `outputs/cover/*.json` (379 six-moment cells, exact rational certificates) and
  `outputs/quartic_cover.json` (641 quartic boxes, each with a rational c4).
- Independent verifier: `scripts/verify_all.py`. It shares no code with the generators and runs
  in about one minute.
