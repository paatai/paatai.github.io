# STATUS (RQ-A)

Last update: 2026-10-22 09:46 UTC.

## Headline

R(q) is now known exactly on [25/169, 144/169] = [0.14793, 0.85207]:

    R(q) = 2 sqrt(q(1-q)) max{1, sqrt2 qh, sqrt3 qh^2},   qh = max(q, 1-q).

1. **Theorem 1 (MAIN, computer-assisted, rigorous; RQ-AUD verdict VALID, A.6):**
   R(q) = 2 sqrt(q(1-q)) for every q in [1-1/sqrt2, 1/sqrt2], and this interval is exactly the
   set where it holds (for q outside, (1,1)/sqrt2 beats e_1). Extremisers: ±e_j inside the
   range; additionally ±(e_i+e_j)/sqrt2 at the two endpoints. See `MAIN_RESULT.md` /
   `MAIN_RESULT.pdf`. Waiting for an independent referee.
2. **Theorem 2 (MAIN-2, computer-assisted, independently re-verified; RQ-AUD verdict VALID,
   A.11, 08:52 UTC; two cosmetic text points applied afterwards):**
   R(q) = 2 sqrt2 (1-q) sqrt(q(1-q)) for every q in [q3, q0] = [1-sqrt(2/3), 1-1/sqrt2]
   (and [1-q0, 1-q3]), and this interval is sharp. Extremisers ±(e_i+e_j)/sqrt2; additionally
   ±e_i at q0 and ±(e_i+e_j+e_k)/sqrt3 at q3. Full proof: `MAIN_RESULT_K2.pdf` /
   `MAIN_RESULT_K2.md`. Waiting for an independent referee.
3. **Theorem 3 (MAIN-3, new, computer-assisted, independently re-verified; audit requested in
   AUDIT_REQUEST.md, section MAIN-3; not yet audited):** R(q) = 2 sqrt3 (1-q)^2 sqrt(q(1-q)) for every q in [25/169, q3] = [0.14793, 0.18350]
   (and [1-q3, 144/169]). Extremisers ±(e_i+e_j+e_k)/sqrt3; additionally ±(e_i+e_j)/sqrt2 at q3.
   The upper end q3 is sharp; the lower end of the k = 3 regime is conjecturally
   q4 = 1-sqrt3/2 = 0.13397 (the gap [q4, 25/169) is open). Full proof: `MAIN_RESULT_K3.pdf` /
   `MAIN_RESULT_K3.md`. These are the first exact values of R(q) in the regime where three equal
   coefficients are optimal.

Per the locked note, nothing is to be reported outside the team until the auditor and an
independent referee rate it VALID.

## What the proofs use

1. BF3 Lemma 9.4: E|L| = 2 tau a + 2 E R_a(bM), where a is the largest coefficient.
2. Six-moment certificates (new mechanism, no induction). A degree-6 polynomial P dominating the
   piecewise-linear conditional expectation gives E|L| <= E P(M), and E P(M) depends only on the
   power sums p3..p6 of the residual coefficients (cumulant identities); their admissible region
   gives a finite check, done in exact rationals with Sturm sequences.
3. Theorem 1: one-coordinate split; quartic two-extremiser certificate near (q0, 1/sqrt2);
   near-dictator bound.
4. Theorems 2 and 3: two-coordinate split (the extremiser (1,1)/sqrt2 then sits at b = 0);
   near-circle lemma (fourth-moment tail bound, slack T b^2/(1+r)); one-coordinate cells for
   small a1; an m-split of the residual near (1,1,1)/sqrt3 (a capped certificate, a
   sign-constrained certificate with p3 <= phi(m_c) < 0, and a three-coordinate near-sphere bound
   that uses an exact three-bit lemma: sum_i Delta_i(f)^2 <= 8(1-q)^2 on [q3, q0] for k = 2,
   <= 12(1-q)^4 on [25/169, q3] for k = 3).

## Verification status

- Theorem 1: generation-side exact checks; independent verifier verify_all.py: ALL PASS;
  break_tests.py; audited VALID (A.6).
- Theorem 2: generation-side exact checks (cert2c.py, nearcircle.py, nsphere3.py); independent
  verifier verify_k2.py (no shared code with the generators; envelope rebuilt differently;
  mpmath intervals for the near-circle boxes and near-sphere pieces; exact Sturm for the
  three-bit lemma): ALL PASS, parts A-G (outputs/verify_k2_ABCDEFG.txt). Negative tests
  break_tests_k2.py (outputs/break_tests_k2.txt). Data md5s: outputs/k2_MD5SUMS.txt. Audited
  VALID (A.11). After the audit the verifier's phi check was made stricter (0 < m_c <= 1 and
  p* < 0 are now checked too); all data still pass and the full run was repeated.
- Theorem 3: the same programs with RQ_K=3: generation 81,975 boxes + 2,704 cells, 0 failures;
  independent verifier `RQ_K=3 python3 verify_k2.py`: outputs/verify_k3_ABCDEFG.txt; negative
  tests outputs/break_tests_k3.txt; data md5s outputs/k3_MD5SUMS.txt.

## Next

- Respond to audit findings on Theorem 3.
- The gap [q4, 25/169): six moments cannot reach q4 (Gaussian six-moment value 0.888074 >
  T3(q4) = 0.884970; eight moments 0.886410; ten moments 0.856068). Options: push the lower end
  with six moments towards q = 0.14, or a ten-moment version of the one- and two-coordinate
  routes plus a split for the four-way tie (1,1,1,1)/2 at q4.
