# MAIN RESULT 3 (RQ-A): $R(q)=2\sqrt3\,(1-q)^2\sqrt{q(1-q)}$ for every $q\in[\frac{25}{169},\,1-\sqrt{2/3}]$

**Status:** PROVED (computer-assisted; every computer step is exact rational arithmetic or certified
interval arithmetic, and was re-done by an independent program). **Awaiting RQ-AUD audit.**
Do not report outside the team before the audit and an independent referee rate it VALID.

PDF version (same content, LaTeX): `MAIN_RESULT_K3.pdf` (source `MAIN_RESULT_K3.tex`).
This file was generated from the LaTeX source with pandoc, so the two contain the same proof.

**One-command check:** `cd scripts && RQ_K=3 python3 verify_k2.py` (about eight minutes on 8 cores). It prints
`ALL SELECTED PARTS PASSED: A B C D E F G`. The output is in `outputs/verify_k3_ABCDEFG.txt`.
Negative tests: `RQ_K=3 python3 break_tests_k2.py` (output `outputs/break_tests_k3.txt`).

These are the first exact values of $R(q)$ in the regime where three equal coefficients are optimal.
With Theorem 1 of `MAIN_RESULT` (audited VALID as A.6) and Theorem 2 of `MAIN_RESULT_K2` (audited
VALID as A.11), this gives $R(q)=2\sqrt{q(1-q)}\max\{1,\sqrt2\hat q,\sqrt3\hat q^2\}$ with
$\hat q=\max(q,1-q)$ for all $q\in[\frac{25}{169},\frac{144}{169}]$. The upper end $q_3=1-\sqrt{2/3}$ of the
$k=3$ formula is sharp; the conjectured lower end is $q_4=1-\sqrt3/2\approx0.1340$ (the interval
$[q_4,\frac{25}{169})$ remains open).

## Map of the proof

| piece | region | lemma | verification |
|---|---|---|---|
| one-coordinate cells | $a_1\le 2/5$ (2,704 cells) | Lemma 13 | `outputs/k3/one/o*.json`, exact (Sturm) |
| two-coordinate box certificates (`lp`) | 57,333 boxes | Lemmas 12, 14–18 | `outputs/k3/cover2c/*.json`, exact (Sturm) |
| near-circle boxes (`ncA`, `ncB`) | 2,534 boxes near $(e_1+e_2)/\sqrt2$ | Lemmas 19–20 | interval arithmetic |
| $m$-split boxes (`ms`) | 21,232 boxes near $(e_1+e_2+e_3)/\sqrt3$ | Lemmas 10, 21–23 | exact + interval arithmetic |
| three-bit lemma ($k=3$) | all $c\in\mathbb R^3$ | Lemma 5 | exact Sturm, 256 Boolean functions |

---

# Statement

Fix $q\in(0,1)$ and put $$u=\sqrt{\tfrac{1-q}{q}},\qquad v=\frac1u,\qquad \tau=\sqrt{q(1-q)} .$$ Let $\chi,\chi_1,\chi_2,\dots$ be i.i.d. with $\Pr[\chi=u]=q$ and $\Pr[\chi=-v]=1-q$, so that $\mathbb{E}\chi=0$, $\mathbb{E}\chi^2=1$ and $\mathbb{E}|\chi|=2\tau$. Let $$R(q)=\sup_{n\ge1}\ \sup_{\alpha\in\mathbb{R}^n\setminus\{0\}}\frac{\mathbb{E}|\sum_{i=1}^n\alpha_i\chi_i|}{|\alpha|_2}.$$ Put $$q_3=1-\sqrt{2/3}\approx0.183503,\qquad q_4=1-\tfrac{\sqrt3}{2}\approx0.133975,\qquad
q_L=\tfrac{25}{169}\approx0.147929,$$ $$T(q)=2\sqrt3\,(1-q)^2\,\tau,\qquad T_2(q)=2\sqrt2\,(1-q)\,\tau .$$

**Theorem 3**.

1.  *For every $q\in[q_L,q_3]$, every $n\ge1$ and every $\alpha\in\mathbb{R}^n$ with $|\alpha|_2=1$, $$\mathbb{E}\Big|\sum_{i=1}^n\alpha_i\chi_i\Big|\le 2\sqrt3\,(1-q)^2\sqrt{q(1-q)} .$$ For $q\in[1-q_3,1-q_L]$ the same holds with $1-q$ replaced by $q$. Consequently $R(q)=2\sqrt3\max(q,1-q)^2\sqrt{q(1-q)}$ for $q\in[q_L,q_3]\cup[1-q_3,1-q_L]$.*

2.  *(Extremisers.) Let $q\in[q_L,q_3]\cup[1-q_3,1-q_L]$. Equality in (a) holds if and only if $\alpha=\pm\frac1{\sqrt3}(e_i+e_j+e_k)$ with $i,j,k$ distinct, or $q\in\{q_3,1-q_3\}$ and $\alpha=\pm\frac1{\sqrt2}(e_i+e_j)$ with $i\ne j$.*

3.  *(Sharpness.) For $q\in(q_3,\frac12]$, $R(q)\ge T_2(q)>T(q)$. For $q\in(0,q_4)$, $R(q)\ge4(1-q)^3\tau>T(q)$. Hence $[q_L,q_3]\subseteq\{q\in(0,\frac12]:R(q)=T(q)\}\subseteq[q_4,q_3]$.*

**Corollary 1**. *With Theorem 1 of `MAIN_RESULT` ($R(q)=2\tau$ on $[q_0,1-q_0]$, $q_0=1-1/\sqrt2$) and Theorem 2 (the main theorem of `MAIN_RESULT_K2`: $R(q)=T_2(q)$ on $[q_3,q_0]$, mirrored on $[1-q_0,1-q_3]$): $$R(q)=2\sqrt{q(1-q)}\,\max\{1,\ \sqrt2\,\hat q,\ \sqrt3\,\hat q^{\,2}\},\qquad \hat q=\max(q,1-q),
\qquad\text{for all }q\in[\tfrac{25}{169},\tfrac{144}{169}].$$*

*Proof.* For $q\le\frac12$, $\hat q=1-q$, and $\max\{1,\sqrt2(1-q),\sqrt3(1-q)^2\}$ equals $\sqrt3(1-q)^2$ on $[q_L,q_3]$, $\sqrt2(1-q)$ on $[q_3,q_0]$ and $1$ on $[q_0,\frac12]$: indeed $\sqrt3(1-q)^2\ge\sqrt2(1-q)$ iff $1-q\ge\sqrt{2/3}$, $\sqrt2(1-q)\ge1$ iff $1-q\ge1/\sqrt2$, and $\sqrt3(1-q)^2\ge1$ for $q\le q_3$. For $q\ge\frac12$ use Lemma 2. ◻

Part (c) and the lower bound $R\ge T$ in (a) are elementary (Lemma 3). The content is the upper bound in (a), and (b).

#### Relation to Theorem 2.

Theorem 2 is the main theorem of `MAIN_RESULT_K2` (labelled Theorem 1 there). The proof of Theorem 3 follows `MAIN_RESULT_K2` step by step. Sections 4, 6 and the generic parts of Sections 7–8 are unchanged. The changes are: the target $T$ and its lower bound (2); the range $u\in[u_3,\frac{12}5]$; the threshold $A_S=\frac25$; the target $\Theta_1$ of the one-coordinate route; the $k=3$ three-bit lemma (Lemma 5), used in the $m$-split; and the main-term bounds in Lemmas 4 and 20(A), which now use $T_2\le T$ for $q\le q_3$. We give the full proof so that the document can be read on its own.

#### Conventions.

$x_+=\max(x,0)$. All polynomials in the computer-assisted parts have rational coefficients. “Verified” means verified in exact rational arithmetic or in outward-rounded interval arithmetic, as specified in Section 9. For a rational $x\ge0$ we write $\lfloor\sqrt x\rfloor_{15}=\lfloor10^{15}\sqrt x\rfloor/10^{15}$ and $\lceil\sqrt x\rceil_{15}=(\lfloor10^{15}\sqrt x\rfloor+1)/10^{15}$ (integer square roots).

# Reductions

## Symmetry and parametrisation

**Lemma 2**. *The law of $-\chi^{(q)}$ is the law of $\chi^{(1-q)}$. Hence $\mathbb{E}|\sum\alpha_i\chi^{(q)}_i|=\mathbb{E}|\sum\alpha_i\chi^{(1-q)}_i|$, $R(q)=R(1-q)$, and the extremisers for $q$ and $1-q$ coincide.*

*Proof.* $-\chi^{(q)}$ takes the value $-u_q$ with probability $q$ and $v_q$ with probability $1-q$; since $u_{1-q}=v_q$ and $v_{1-q}=u_q$, this is the law of $\chi^{(1-q)}$. Finally $|\sum\alpha_i(-\chi_i)|=|\sum\alpha_i\chi_i|$. ◻

From now on $q\le\frac12$, i.e. $u\ge1$, and $$\tag{1}
q=\frac{1}{1+u^2},\quad 1-q=\frac{u^2}{1+u^2},\quad v=\frac1u,\quad \tau=\frac{u}{1+u^2},\quad
qu=(1-q)v=\tau .$$ On $u\ge1$, $\tau$ and $q$ are decreasing and $1-q$ is increasing in $u$. The target is $$T=2\sqrt3(1-q)^2\tau=\sqrt3\,\tilde T(u),\qquad \tilde T(u)=\frac{2u^5}{(1+u^2)^3},\qquad
\frac{d}{du}\frac{u^5}{(1+u^2)^3}=\frac{u^4(5-u^2)}{(1+u^2)^4},$$ so $\tilde T$ is increasing on $[1,\sqrt5]$ and decreasing on $[\sqrt5,\infty)$. In particular, for $1\le u_1<u_2$ and $u\in[u_1,u_2]$, $$\tag{2}
T(u)\ \ge\ T^-(u_1,u_2):=S_3\min\{\tilde T(u_1),\tilde T(u_2)\},\qquad S_3=\lfloor\sqrt3\rfloor_{15}<\sqrt3 .$$ The range $q\in[q_L,q_3]$ corresponds to $u\in[u_3,\frac{12}5]$ with $$u_3=\sqrt{2+\sqrt6}\approx2.1093814,$$ because $(1-q_3)/q_3=\sqrt2/(\sqrt3-\sqrt2)=2+\sqrt6$ and $1/(1+(12/5)^2)=\frac{25}{169}$. We fix the rationals $$U_-=\frac{2109381}{1000000}<u_3,\qquad U_+=\frac{12}{5}<u_4:=\sqrt{3+2\sqrt3}\approx2.5425,$$ (indeed $U_-^2>2$ with $(U_-^2-2)^2<6$, and $U_+^2=5.76<3+2\sqrt3$; $u_4$ corresponds to $q_4$). The computations cover $u\in[U_-,U_+]$; the theorem uses only $u\in[u_3,U_+]$.

## Values of a few vectors

**Lemma 3**. *Let $k\ge1$ and $q<1/k$. Then $\mathbb{E}|\chi_1+\dots+\chi_k|/\sqrt k=2\sqrt k\,(1-q)^{k-1}\tau$. In particular $\mathbb{E}|\chi_1|=2\tau$, $\mathbb{E}|\chi_1+\chi_2|/\sqrt2=T_2$ (for $q<\frac12$; also at $q=\frac12$ by continuity), $\mathbb{E}|\chi_1+\chi_2+\chi_3|/\sqrt3=T$ for $q<\frac13$, and $\mathbb{E}|\chi_1+\dots+\chi_4|/2=4(1-q)^3\tau$ for $q<\frac14$. Moreover:*

1.  *for $q\le\frac12$: $T_2\le T$ iff $q\le q_3$, with equality iff $q=q_3$;*

2.  *for $q\le q_3$: $2\tau<T$;*

3.  *for $q<\frac14$: $4(1-q)^3\tau>T$ iff $q<q_4$.*

*Proof.* Let $S=\chi_1+\dots+\chi_k$ and let $x_i=\mathbf 1\{\chi_i=u\}$. If some $x_i=1$ then $S\ge u-(k-1)v>0$, because $u^2>k-1$ is equivalent to $q<1/k$. If all $x_i=0$ then $S=-kv<0$. So $|S|=fS$ with $f=2\cdot\mathbf 1\{\exists i:x_i=1\}-1=1-2\cdot\mathbf 1\{\text{all }x_i=0\}$. Since $\mathbb{E}\chi_i=0$, $\mathbb{E}[f\chi_i]=-2\mathbb{E}[\chi_i\mathbf 1\{\text{all }x=0\}]=-2(1-q)^k(-v)=2(1-q)^{k-1}(1-q)v=2(1-q)^{k-1}\tau$. Summing over $i$ gives $\mathbb{E}|S|=2k(1-q)^{k-1}\tau$. The comparisons: (i) $2\sqrt2(1-q)\tau\le2\sqrt3(1-q)^2\tau$ iff $1-q\ge\sqrt{2/3}$; (ii) for $q\le q_3$, $\sqrt3(1-q)^2\ge\sqrt3\cdot\frac23=\frac2{\sqrt3}>1$; (iii) $4(1-q)^3>2\sqrt3(1-q)^2$ iff $1-q>\frac{\sqrt3}2$. ◻

## Splitting off the two largest coefficients

Let $|\alpha|_2=1$ and $L=\sum\alpha_i\chi_i$. Changing the sign of $\alpha$ and permuting coordinates does not change $\mathbb{E}|L|$. So we may assume $$a_1:=\alpha_1=\max_i|\alpha_i|>0,\qquad a_2:=|\alpha_2|=\max_{i\ge2}|\alpha_i|,\qquad
|\alpha_3|\ge|\alpha_4|\ge\cdots,$$ and we put $s=\operatorname{sgn}\alpha_2\in\{1,-1\}$ ($s=1$ if $\alpha_2=0$), $$r=\sqrt{a_1^2+a_2^2}\in(0,1],\qquad b=\sqrt{1-r^2}.$$ If $r<1$, let $\beta_i=\alpha_i/b$ for $i\ge3$ and $M=\sum_{i\ge3}\beta_i\chi_i$. Then $$L=a_1\chi_1+s\,a_2\chi_2+bM,\qquad \sum_{i\ge3}\beta_i^2=1,\qquad
m:=\max_{i\ge3}|\beta_i|=\frac{|\alpha_3|}{b}\le\min\Big(1,\frac{a_2}{b}\Big),$$ and $M$ is independent of $(\chi_1,\chi_2)$. We use half-angle coordinates for $(a_1,a_2)$: $$a_1=r\,c(t),\quad a_2=r\,d(t),\qquad c(t)=\frac{1-t^2}{1+t^2},\quad d(t)=\frac{2t}{1+t^2},\qquad
t=\frac{a_2}{r+a_1}.$$ Since $0\le a_2\le a_1$, the angle $\theta$ with $\tan\theta=a_2/a_1$ is in $[0,\pi/4]$ and $t=\tan(\theta/2)\in[0,\sqrt2-1]$. We fix $T_8=\frac{20711}{50000}=0.41422\ge\sqrt2-1$ (indeed $(T_8+1)^2\ge2$). On $[0,1]$, $c$ is decreasing and $d$ is increasing in $t$, and $c^2+d^2=1$. Thus every unit $\alpha$ gives a point $$(u,t,r,s)\in[U_-,U_+]\times[0,T_8]\times(0,1]\times\{1,-1\}\qquad(u\in[u_3,U_+]).$$ We put $A_S=\frac25$. If $a_1\le A_S$ we use the one-coordinate route of Section 5; otherwise $r\ge a_1>A_S$ and we use the two-coordinate route of Sections 6–8.

# Exact evaluations

## Two coordinates

**Lemma 4** (two-coordinate value). *Let $q\le\frac12$, $c,d\ge0$, $s\in\{1,-1\}$, and $X=c\chi_1+s\,d\chi_2$. List the atoms of $X$ as $(\chi_1,\chi_2)=(u,u),(u,-v),(-v,u),(-v,-v)$, with probabilities $p=(q^2,\,q(1-q),\,q(1-q),\,(1-q)^2)$ and values $x_j$. Then $p_jx_j=\tau g_j$ with $$\tag{3}
g=\big(q(c+sd),\ (1-q)c-s\,q\,d,\ -q\,c+s(1-q)d,\ -(1-q)(c+sd)\big),$$ and $$\mathbb{E}|X|=2\tau\max\{c,\ d,\ [s=1]\,(1-q)(c+d)\}$$ (the last entry is present only for $s=1$). If $q\le q_0=1-1/\sqrt2$, then $\mathbb{E}|X|\le T_2\sqrt{c^2+d^2}$. If $q\le q_3$, then $\mathbb{E}|X|\le T\sqrt{c^2+d^2}$, and for $(c,d)\ne0$ equality holds if and only if $q=q_3$, $s=1$ and $c=d$.*

*Proof.* The identities $p_jx_j=\tau g_j$ follow from (1); for example $q(1-q)(cu-sdv)=(1-q)\tau c-q\tau sd$. Since $\mathbb{E}X=0$, $\mathbb{E}|X|=2\mathbb{E}X_+=2\tau\sum_j(g_j)_+$. For $s=1$: $g_1\ge0\ge g_4$, so $\mathbb{E}X_+/\tau=q(c+d)+((1-q)c-qd)_++((1-q)d-qc)_+$. If both middle terms are nonnegative this equals $(1-q)(c+d)$, and then $(1-q)(c+d)-c=(1-q)d-qc\ge0$ and similarly $\ge d$. If only the first is nonnegative it equals $q(c+d)+(1-q)c-qd=c$, and $(1-q)(c+d)-c=(1-q)d-qc<0$, while $c\ge d$ (otherwise $(1-q)d-qc\ge (1-2q)c\ge 0$). The case where only the second is nonnegative is symmetric. Both negative would give $(1-q)(c+d)<q(c+d)$, impossible for $q\le\frac12$ unless $c=d=0$. In all cases $\mathbb{E}X_+/\tau=\max\{c,d,(1-q)(c+d)\}$. For $s=-1$: $g_2\ge0\ge g_3$. If $c\ge d$ then $g_1\ge0\ge g_4$ and $\mathbb{E}X_+/\tau=q(c-d)+(1-q)c+qd=c$. If $c<d$ then $g_1<0<g_4$ and $\mathbb{E}X_+/\tau=(1-q)c+qd+(1-q)(d-c)=d$. So $\mathbb{E}X_+/\tau=\max(c,d)$.

For the bounds let $\rho=\sqrt{c^2+d^2}>0$. Then $\max(c,d)\le\rho$, and $2\tau\rho\le T_2\rho$ iff $\sqrt2(1-q)\ge1$ iff $q\le q_0$. Also $(1-q)(c+d)\le\sqrt2(1-q)\rho$ with equality iff $c=d$. This gives $\mathbb{E}|X|\le T_2\rho$ for $q\le q_0$. Now let $q\le q_3$ ($<q_0$). Then $2\tau\max(c,d)\le2\tau\rho<T\rho$ by Lemma 3(ii), and $2\tau(1-q)(c+d)\le T_2\rho\le T\rho$ by Lemma 3(i), with equality iff $c=d$ and $q=q_3$. Since the third entry is present only for $s=1$, this gives the claim. ◻

## Three coordinates

For $f:\{0,1\}^3\to[-1,1]$ and $x_i=\mathbf 1\{\chi_i=u\}$ put $\Delta_i(f)=\mathbb{E}[f\mid x_i=1]-\mathbb{E}[f\mid x_i=0]$, a polynomial in $q$. Then, by (1), $$\tag{4}
\mathbb{E}[f\chi_i]=qu\,\mathbb{E}[f\mid x_i=1]-(1-q)v\,\mathbb{E}[f\mid x_i=0]=\tau\,\Delta_i(f).$$

**Lemma 5** (three-bit lemma, $k=3$). *Let $q\in[q_L,q_3]$ and $c\in\mathbb{R}^3$. Then $$G_3(c):=\mathbb{E}|c_1\chi_1+c_2\chi_2+c_3\chi_3|\le T\,|c| .$$ For $c\ne0$ equality holds if and only if $c$ is a positive multiple of $\pm(e_1+e_2+e_3)$, or $q=q_3$ and $c$ is a positive multiple of $\pm(e_i+e_j)$ for some $i\ne j$.*

*Proof.* Let $X=c\cdot\chi$ and $f^*=\operatorname{sgn}X$ (with $\operatorname{sgn}0=1$), a function of $(x_1,x_2,x_3)$ with values $\pm1$. By (4) and Cauchy–Schwarz, $$G_3(c)=\mathbb{E}[f^*X]=\tau\sum_ic_i\Delta_i(f^*)\le\tau|c|\,|\Delta(f^*)| .$$ *Claim:* for each of the $2^8=256$ functions $f:\{0,1\}^3\to\{-1,1\}$, the polynomial $P_f(q)=12(1-q)^4-\sum_{i=1}^3\Delta_i(f)^2$ is $\ge0$ on $[q_L,q_3]$. Moreover $P_f\equiv0$ exactly for $f=\pm(2\cdot\mathbf 1\{x_1\vee x_2\vee x_3\}-1)$ (two functions); $P_f(q_3)=0\ne P_f$ exactly for $f=\pm(2\cdot\mathbf 1\{x_i\vee x_j\}-1)$ (six functions); and no $P_f\not\equiv0$ has a zero in $[q_L,q_3)$. Given the claim, $G_3(c)\le\tau|c|\sqrt{12}(1-q)^2=T|c|$.

The claim is a finite exact computation (Section 9, part G). For each $f$, $P_f$ is computed symbolically as a polynomial with rational coefficients (degree $\le4$). Let $\mu_3(q)=3q^2-6q+1$, the minimal polynomial of $q_3$ (irreducible over $\mathbb Q$, since $24$ is not a square). Its other root $1+\sqrt{2/3}$ lies above $1$, so $\mu_3>0$ on $[0,q_3)$. Take a rational enclosure $q_3\in[q_3^-,q_3^+]$ of width $10^{-15}$; the signs $\mu_3(q_3^-)>0>\mu_3(q_3^+)$ and $q_L<q_3^-$ are asserted. Then: (i) by Sturm sequences, $P_f$ has no root in $[q_L,q_3^-]$, and $P_f(q_L)>0$; (ii) near $q_3$: if $\mu_3\mid P_f$, write $P_f=\mu_3Q$; then $Q$ has no root in $[q_3^-,q_3^+]$ and $Q(q_3^-)>0$, so $P_f>0$ on $[q_3^-,q_3)$ and $P_f(q_3)=0$; otherwise $P_f$ has no root in $[q_3^-,q_3^+]$ and $P_f(q_3^-)>0$. Since $\mu_3$ is irreducible, $P_f(q_3)=0$ iff $\mu_3\mid P_f$. The two functions with $P_f\equiv0$ are $\pm$OR$_3$, by the computation in Lemma 3 ($\Delta(\mathrm{OR}_3)=2(1-q)^2(e_1+e_2+e_3)$); and $\Delta(\mathrm{OR}_{ij})=2(1-q)(e_i+e_j)$ gives $P=12(1-q)^4-8(1-q)^2=4(1-q)^2\mu_3(q)$ for the OR of two bits.

Equality. Suppose $G_3(c)=T|c|$ with $c\ne0$. Then $|\Delta(f^*)|^2=12(1-q)^4$, so $P_{f^*}(q)=0$, and $c$ is a positive multiple of $\Delta(f^*)$. By the claim, $f^*=\pm$OR$_3$, with $\Delta=\pm2(1-q)^2(1,1,1)$; or $q=q_3$ and $f^*$ is $\pm$ the OR of two bits, with $\Delta=\pm2(1-q)(e_i+e_j)$. Conversely, these $c$ attain $T|c|$ by Lemmas 3 and 4 (at $q=q_3$, $T_2=T$). ◻

*Remark 6*. Lemma 5 is contained in the case $n=3$ of RQ-C’s result C6: for $n\le7$ and all $q\in(0,1)$, $R_n(q)=2\tau\sqrt{\max_{k\le n}k(1-\bar q)^{2k-2}}$ with $\bar q=\min(q,1-q)$, with only OR$_k$ extremal. RQ-AUD audited C6 VALID (A.5 for $n\le6$, A.5b for $n=7$). Our check is independent of it. Unlike the $k=2$ lemma of Theorem 2, the $k=3$ claim has no lower end of validity coming from three bits (the OR of four bits needs a fourth coordinate). The range of Theorem 3 is limited by the rest of the argument, not by Lemma 5.

# Moments of the remainder

**Lemma 7**. *The cumulants of $\chi$ are $\kappa_1=0$, $\kappa_2=1$, and, with $w=u^2+v^2$, $\kappa_3=u-v$, $\kappa_4=w-4$, $\kappa_5=(u-v)(w-10)$, $\kappa_6=w^2-26w+64$.*

*Proof.* By (1), $m_k=\mathbb{E}\chi^k=(u^k+(-1)^ku^{2-k})/(1+u^2)$, which gives $m_3=u-v$, $m_4=w-1$, $m_5=(u-v)w$ and $m_6=w^2-w-1$. (Use $u^4-1=(u^2+1)(u^2-1)$, $u^6+1=(u^2+1)(u^4-u^2+1)$, $u^8-1=(u^2+1)(u^2-1)(u^4+1)$ and $u^{10}+1=(u^2+1)(u^8-u^6+u^4-u^2+1)$.) For a centred variable with unit variance, $\kappa_3=m_3$, $\kappa_4=m_4-3$, $\kappa_5=m_5-10m_3$ and $\kappa_6=m_6-15m_4-10m_3^2+30$. Using $(u-v)^2=w-2$ gives the formulas. (Verified symbolically in `verify_all.py`, part A1.) ◻

**Lemma 8**. *Let $M=\sum\beta_i\chi_i$ (finite sum) with $\sum\beta_i^2=1$ and power sums $p_j=\sum_i\beta_i^j$. Then $\mathbb{E}M=0$, $\mathbb{E}M^2=1$, and $$\mathbb{E}M^3=\kappa_3p_3,\quad \mathbb{E}M^4=3+\kappa_4p_4,\quad \mathbb{E}M^5=\kappa_5p_5+10\kappa_3p_3,\quad
\mathbb{E}M^6=15+15\kappa_4p_4+10\kappa_3^2p_3^2+\kappa_6p_6 .$$*

*Proof.* Cumulants of independent sums add and are homogeneous, so $M$ has cumulants $K_1=0$, $K_2=1$ and $K_j=\kappa_jp_j$. For a centred variable, $m_3=K_3$, $m_4=K_4+3K_2^2$, $m_5=K_5+10K_3K_2$ and $m_6=K_6+15K_4K_2+10K_3^2+15K_2^3$. ◻

**Lemma 9**. *If $\sum\beta_i^2=1$ and $\max|\beta_i|\le m\le1$, then $p_3^2\le p_4\le m^2$, $p_4^2\le p_6\le m^2p_4$, $|p_5|\le mp_4$ and $0\le p_4\le1$.*

*Proof.* Cauchy–Schwarz gives $p_3^2=(\sum\beta_i\beta_i^2)^2\le\sum\beta_i^2\sum\beta_i^4=p_4$ and $p_4^2=(\sum\beta_i\beta_i^3)^2\le p_2p_6=p_6$. Also $p_4\le m^2\sum\beta_i^2=m^2$, $p_6\le m^2p_4$ and $|p_5|\le\sum|\beta_i|\beta_i^4\le mp_4$. ◻

**Lemma 10** (sign information). *Let $\sum\beta_i^2=1$, $m=\max|\beta_i|$, and suppose $\beta_{i_0}=-m$ for some $i_0$. If $m\ge m_c\in(0,1]$, then $p_3\le\varphi(m_c):=-m_c^3+(1-m_c^2)^{3/2}$.*

*Proof.* For $i\ne i_0$, $|\beta_i|\le(\sum_{i\ne i_0}\beta_i^2)^{1/2}=\sqrt{1-m^2}$. Hence $p_3=-m^3+\sum_{i\ne i_0}\beta_i^3\le-m^3+\sqrt{1-m^2}\sum_{i\ne i_0}\beta_i^2=-m^3+(1-m^2)^{3/2}$. Finally $\frac{d}{dm}\big(-m^3+(1-m^2)^{3/2}\big)=-3m^2-3m\sqrt{1-m^2}\le0$. ◻

#### Cumulant enclosures.

For $1\le u_1\le u\le u_2$: $\kappa_3=u-1/u$ and $w=u^2+u^{-2}$ are increasing, so $\kappa_3\in[k_3^-,k_3^+]=[u_1-\frac1{u_1},u_2-\frac1{u_2}]$ and $w\in[w^-,w^+]$. We require $w^+<13$ (here $w^+<6$). Then $\kappa_4\in[w^--4,w^+-4]$, $\kappa_6\in[f_6(w^+),f_6(w^-)]$ with $f_6(x)=x^2-26x+64$ (decreasing for $x<13$), and $|\kappa_5|\le k_5^+:=k_3^+\max(|w^--10|,|w^+-10|)$.

**Definition 11** (objective bound). For $c=(c_0,\dots,c_6)$, an interval $[u_1,u_2]$ with $u_1>1$, a number $m^*\in(0,1]$, an optional number $p^*<0$, and a target $\Theta$, put $$\begin{aligned}
A&=c_0+c_2+3c_4+15c_6, & \bar B&=k_3^+|c_3+10c_5|,\\
C^+&=\max_{\kappa_4\in[w^--4,w^+-4]}\kappa_4(c_4+15c_6), & \bar D&=k_5^+|c_5|,\\
E^+&=\max\{f_6(w^-)c_6,f_6(w^+)c_6\}, & F^+&=\max\{0,10(k_3^-)^2c_6,10(k_3^+)^2c_6\},
\end{aligned}$$ $\Gamma=C^++\bar Dm^*+F^++\max(E^+,0)m^{*2}$ and $\varepsilon=\min(E^+,0)$. If $p^*$ is given and $c_3+10c_5\ge0$, replace $A$ by $A+k_3^-(c_3+10c_5)p^*$ and $\bar B$ by $0$. We say that *$c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$* if $h(\rho)=\Theta-A-\bar B\rho-\Gamma\rho^2-\varepsilon\rho^4>0$ for all $\rho\in[0,m^*]$.

**Lemma 12** (expectation bound). *Suppose $c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,\Theta)$, and let $P(y)=\sum_kc_ky^k$. Then $\mathbb{E}P(M)<\Theta$ for every $u\in[u_1,u_2]$ and every $M=\sum\beta_i\chi_i$ with $\sum\beta_i^2=1$ and $\max|\beta_i|\le m^*$, and, if $p^*$ is given, $p_3\le p^*$.*

*Proof.* By Lemma 8, $\mathbb{E}P(M)=A+\kappa_3(c_3+10c_5)p_3+\kappa_4(c_4+15c_6)p_4+\kappa_5c_5p_5+\kappa_6c_6p_6+10\kappa_3^2c_6p_3^2$, with $A$ the unmodified value. Put $\rho=\sqrt{p_4}\in[0,m^*]$ (Lemma 9). Then $\kappa_3(c_3+10c_5)p_3\le\bar B\rho$ since $|p_3|\le\rho$. If $p^*$ is given and $c_3+10c_5\ge0$, then instead $\kappa_3(c_3+10c_5)p_3\le\kappa_3(c_3+10c_5)p^*\le k_3^-(c_3+10c_5)p^*$, using $\kappa_3\ge k_3^->0$ and $p^*<0$. Next, $\kappa_4(c_4+15c_6)p_4\le C^+\rho^2$ (linear in $\kappa_4$, $p_4\ge0$); $\kappa_5c_5p_5\le\bar Dm^*\rho^2$; $10\kappa_3^2c_6p_3^2\le F^+\rho^2$; and $\kappa_6c_6p_6\le E^+p_6$, which is $\le E^+m^{*2}\rho^2$ if $E^+\ge0$ and $\le E^+\rho^4$ if $E^+<0$ (Lemma 9). Summing, $\mathbb{E}P(M)\le\Theta-h(\rho)<\Theta$. ◻

# The one-coordinate route ($a_1\le\frac25$)

Here we split off only $a=a_1$: $L=a\chi_1+b_1M_1$ with $b_1=\sqrt{1-a^2}$, $M_1=\sum_{i\ge2}(\alpha_i/b_1)\chi_i$, whose coefficients are at most $\min(1,a/b_1)$ in absolute value. By BF3, Lemma 9.4 (Lemma 3 of `MAIN_RESULT`; audited VALID in A.0 and A.3), $$\mathbb{E}|L|=2\tau a+2\mathbb{E}R_a(b_1M_1),\qquad R_a(y)=\max\{0,(1-q)(y-av),\,q(-y-au)\},$$ so $\mathbb{E}|L|<T$ iff $\mathbb{E}R_a(b_1M_1)<\tau(\sqrt3(1-q)^2-a)$.

A *cell* is $[u_1,u_2]\times[a_1,a_2]$ with rationals $1<u_1<u_2$, $0\le a_1<a_2\le\frac25$. Put $\bar b=\lceil\sqrt{1-a_1^2}\rceil_{15}$, $\bar m=\min\{1,a_2/\lfloor\sqrt{1-a_2^2}\rfloor_{15}\}$, and $$\bar\ell_1(y)=\frac{u_2^2}{1+u_2^2}\Big(\bar by-\frac{a_1}{u_2}\Big),\quad
\bar\ell_2(y)=\frac{1}{1+u_1^2}\big(-\bar by-a_1u_1\big),\quad
\Theta_1=\tau(u_2)\Big(S_3\Big(\frac{u_1^2}{1+u_1^2}\Big)^2-a_2\Big).$$ A *cell certificate* is $c\in\mathbb Q^7$ with $P(y)=\sum c_ky^k$ such that (V1) $P>0$, (V2) $P>\bar\ell_1$, (V3) $P>\bar\ell_2$ on $\mathbb{R}$, and (V4) $c$ satisfies the objective bound for $(u_1,u_2,\bar m,-,\Theta_1)$.

**Lemma 13**. *If a cell with $u_1\ge U_-$ has a certificate, then $\mathbb{E}|L|<T$ for every $u\in[u_1,u_2]$ and every unit $\alpha$ with $a_1\le\max|\alpha_i|\le a_2$.*

*Proof.* For $u\in[u_1,u_2]$, $a\in[a_1,a_2]$, $b_1=\sqrt{1-a^2}$, we have $R_a(b_1y)\le\max\{0,\bar\ell_1,\bar\ell_2\}(y)$. This is Lemma 7 of `MAIN_RESULT`, audited VALID in A.6. We recall the proof: $R_a(b_1y)=\max\{0,\ell_1,\ell_2\}$ with $\ell_1=\frac{u^2}{1+u^2}(b_1y-\frac au)$ and $\ell_2=\frac1{1+u^2}(-b_1y-au)$. If $\ell_1(y)>0$ then $y>0$ and $0<b_1y-\frac au\le\bar by-\frac{a_1}{u_2}$, and $\frac{u^2}{1+u^2}\le\frac{u_2^2}{1+u_2^2}$. If $\ell_2(y)>0$ then $y<0$ and $0<-b_1y-au\le-\bar by-a_1u_1$, and $\frac1{1+u^2}\le\frac1{1+u_1^2}$. So by (V1)–(V3), $\mathbb{E}R_a(b_1M_1)\le\mathbb{E}P(M_1)$. Since $a/\sqrt{1-a^2}$ is increasing, the coefficients of $M_1$ are at most $\bar m$. By Lemma 12, $\mathbb{E}P(M_1)<\Theta_1$. Finally $\Theta_1\le\tau(u)(\sqrt3(1-q)^2-a)$, because $\tau(u)\ge\tau(u_2)$, $(1-q)^2\ge(\frac{u_1^2}{1+u_1^2})^2$, $S_3<\sqrt3$, $a\le a_2$, and the bracket is positive: $S_3(\frac{u_1^2}{1+u_1^2})^2\ge S_3(\frac{U_-^2}{1+U_-^2})^2>1.15>\frac25\ge a_2$ (the verifier also asserts $\Theta_1>0$ for every cell). ◻

# The two-coordinate route: box certificates

A *box* is $B=[u_1,u_2]\times[t_1,t_2]\times[r_1,r_2]$ with rationals $1<u_1<u_2$, $0\le t_1<t_2\le1$, $0\le r_1<r_2\le1$, together with a sign $s$. For a point of $B$, $a_1=rc(t)$, $a_2=rd(t)$ and $b=\sqrt{1-r^2}$, as in Section 2.3.

**Lemma 14** (conditional expectation). *For a point of $B$ with $r<1$, $\mathbb{E}|L|=\mathbb{E}F(M)$, where $$F(y)=\sum_{j=1}^4p_j|x_j+by|=\sum_{j=1}^4\big|p_jx_j+p_jb\,y\big|,$$ $x_j$ and $p_j$ are the atoms and probabilities of $a_1\chi_1+sa_2\chi_2$, and $p_jx_j=r\tau g_j$ with $g$ as in (3) (with $c=c(t)$, $d=d(t)$).*

*Proof.* Condition on $(\chi_1,\chi_2)$ (independent of $M$), and use Lemma 4 for $(a_1,a_2)=r(c,d)$. ◻

#### Box enclosures.

On $B$: $q\in[\frac1{1+u_2^2},\frac1{1+u_1^2}]$, $1-q\in[\frac{u_1^2}{1+u_1^2},\frac{u_2^2}{1+u_2^2}]$, $\tau\in[\tau(u_2),\tau(u_1)]$, $c\in[c(t_2),c(t_1)]$, $d\in[d(t_1),d(t_2)]$, $r\in[r_1,r_2]$ and $b\in[b^-,b^+]$ with $b^-=\lfloor\sqrt{1-r_2^2}\rfloor_{15}$ ($b^-=0$ if $r_2=1$) and $b^+=\lceil\sqrt{1-r_1^2}\rceil_{15}$. Interval arithmetic then gives rational enclosures $p_jx_j\in[\pi_j^-,\pi_j^+]$ and $p_jb\in[\beta_j^-,\beta_j^+]$ with $\beta_j^-\ge0$. We define $\bar m(B)=1$ if $b^-=0$ or $r_2d(t_2)\ge b^-$, and otherwise $\bar m(B)$ is a rational with $\bar m(B)\ge r_2d(t_2)/b^-$. Then $m\le\min(1,a_2/b)\le\min(1,\bar m(B))$ at every point of $B$ with $r<1$.

**Definition 15** (box envelope). $F_B(y)=\sum_j\max(\pi_j^++\beta_j^+y,\ -\pi_j^--\beta_j^-y)$ for $y\ge0$, and $F_B(y)=\sum_j\max(\pi_j^++\beta_j^-y,\ -\pi_j^--\beta_j^+y)$ for $y<0$.

**Lemma 16** (envelope). *$F(y)\le F_B(y)$ for all $y\in\mathbb{R}$ and all points of $B$ with $r<1$. On each half-line, $F_B$ is the maximum of the $2^4$ affine functions obtained by choosing one of the two lines in each summand.*

*Proof.* $|p_jx_j+p_jby|=\max(p_jx_j+p_jby,\,-p_jx_j-p_jby)$. For $y\ge0$: $p_jx_j+p_jby\le\pi_j^++\beta_j^+y$ and $-p_jx_j-p_jby\le-\pi_j^--\beta_j^-y$. For $y<0$: $p_jby\le\beta_j^-y$ and $-p_jby\le-\beta_j^+y$. A sum of maxima is the maximum over all choices. ◻

**Definition 17** (box certificate). Let $m^*\in(0,\min(1,\bar m(B))]$ and let $p^*<0$ be optional. A *box certificate for $(B,s,m^*,p^*)$* is $c\in\mathbb Q^7$ with $P(y)=\sum c_ky^k$ such that (W1) $P(y)>F_B(y)$ for all $y\in\mathbb{R}$, and (W2) $c$ satisfies the objective bound for $(u_1,u_2,m^*,p^*,T^-(u_1,u_2))$, with $T^-$ as in (2).

**Lemma 18** (box certificate lemma). *If $c$ is a box certificate for $(B,s,m^*,p^*)$, then $\mathbb{E}|L|<T(u)$ at every point of $B$ with $r<1$ and every remainder $M$ with $m\le m^*$ and, if $p^*$ is given, $p_3\le p^*$.*

*Proof.* By Lemmas 14 and 16 and (W1), $\mathbb{E}|L|=\mathbb{E}F(M)\le\mathbb{E}P(M)$. By Lemma 12 and (W2), $\mathbb{E}P(M)<T^-(u_1,u_2)\le T(u)$, using (2). ◻

With $m^*=\min(1,\bar m(B))$ and no $p^*$, Lemma 18 covers every remainder. These are the boxes of kind <span class="sans-serif">lp</span>.

# Near $(e_1+e_2)/\sqrt2$: the near-circle lemma

**Lemma 19** (tail bound). *Let $y\in\mathbb{R}$, $b\ge0$ and let $Z$ be a random variable with $\mathbb{E}Z=0$ and $\mathbb{E}Z^4<\infty$. Then $$\mathbb{E}|y+bZ|\le|y|+\min\Big(b\,\mathbb{E}|Z|,\ \frac{27}{128}\,\frac{b^4\mathbb{E}Z^4}{|y|^3}\Big),$$ where for $y=0$ the minimum is read as its first entry. The same convention is used below whenever this bound is applied at a point where $y=0$.*

*Proof.* The first bound is the triangle inequality. For the second (only needed for $y\ne0$), $|y+z|-|y|-\operatorname{sgn}(y)z=2(-\operatorname{sgn}(y)z-|y|)_+\le2(|z|-|y|)_+$, and $\mathbb{E}[\operatorname{sgn}(y)bZ]=0$. For $x\ge0$ and $\eta>0$, $(x-\eta)_+\le\frac{27}{256}x^4/\eta^3$: the maximum of $(x-\eta)/x^4$ over $x>\eta$ is at $x=\frac43\eta$ and equals $\frac{27}{256}\eta^{-3}$. Hence $\mathbb{E}|y+bZ|-|y|\le2\cdot\frac{27}{256}\,b^4\mathbb{E}Z^4/|y|^3$. ◻

**Lemma 20** (near-circle tests). *Let $B$ be a box with $r_1>0$. Let $y_j$ ($j=1,\dots,4$) be the atoms of $c\chi_1+sd\chi_2$, so that the atoms of $a_1\chi_1+sa_2\chi_2$ are $ry_j$. Let $\eta_j\ge0$ be a lower bound of $|y_j|$ on $B$, $p_j^+$ an upper bound of $p_j$, and $E_4=3+\max(0,w^+-4)\,\min(1,\bar m(B))^2$. Let $T^-=T^-(u_1,u_2)$.*

1.  *If all $\eta_j>0$ and $\frac{27}{128}E_4(b^+)^2\frac{1+r_2}{r_1^3}\sum_jp_j^+\eta_j^{-3}<T^-$, then at every point of $B$ with $u\ge u_3$: $\mathbb{E}|L|<T$ if $r<1$, and $\mathbb{E}|L|\le T$ if $r=1$, with equality only in the case of Lemma 4 ($q=q_3$, $s=1$, $a_1=a_2$).*

2.  *Let $G^+$ be an upper bound of $\mathbb{E}|c\chi_1+sd\chi_2|=\tau\sum_j|g_j|$ on $B$ with $G^+\le T^-$, and $e_j^+=\min\big(b^+,\frac{27}{128}(b^+)^4E_4/(r_1^3\eta_j^3)\big)$ ($e_j^+=b^+$ if $\eta_j=0$). If $\sum_jp_j^+e_j^+<T^-(1-r_2)+r_1(T^--G^+)$, then $\mathbb{E}|L|<T$ at every point of $B$.*

*Proof.* At a point of $B$ with $r<1$, condition on $(\chi_1,\chi_2)$ and apply Lemma 19 with $Z=M$. Here $\mathbb{E}M^4=3+\kappa_4p_4\le E_4$, by Lemma 8, since $p_4\le m^2\le\min(1,\bar m)^2$. This gives $\mathbb{E}|L|\le rG+\sum_jp_je_j$, where $G=\mathbb{E}|c\chi_1+sd\chi_2|$ and $e_j=\min(b,\frac{27}{128}b^4E_4/(r^3|y_j|^3))$; also $\mathbb{E}|M|\le1$. If $r=1$ then $\mathbb{E}|L|=G$. (A) By Lemma 4 ($q\le q_3$, since $u\ge u_3$), $G\le T$. Since $1-r=b^2/(1+r)$, $\sum_jp_je_j\le\frac{27}{128}\frac{b^4E_4}{r^3}\sum_j\frac{p_j}{|y_j|^3}
\le b^2\cdot\frac{27}{128}E_4(b^+)^2\frac{1}{r_1^3}\sum_j\frac{p_j^+}{\eta_j^3}
<\frac{b^2T^-}{1+r_2}\le T(1-r)$ when $b>0$. So $\mathbb{E}|L|<rT+T(1-r)=T$. For $r=1$ use Lemma 4. (B) $\mathbb{E}|L|\le rG^++\sum_jp_j^+e_j^+<rG^++T^-(1-r_2)+r_1(T^--G^+)\le rG^++T^-(1-r)+r(T^--G^+)=T^-\le T$, using $r_1\le r\le r_2$ and $T^--G^+\ge0$. ◻

These are the boxes of kind <span class="sans-serif">ncA</span> and <span class="sans-serif">ncB</span>.

# Near the extremiser $(e_1+e_2+e_3)/\sqrt3$: the $m$-split

The extremiser $(e_1+e_2+e_3)/\sqrt3$ is, in our coordinates, the point $a_1=a_2=b=1/\sqrt3$ with $M=\chi_3$, so $m=1$ and $p_3=1$. It is an interior point of the parameter region, and there the six-moment relaxation is exact, so no box certificate can work near it. In Theorem 2 this happened only at the endpoint $u_3$; here it happens for every $u$ in the range. As in Theorem 2, we split according to $m=\max_{i\ge3}|\beta_i|$ and the sign of a largest remaining coefficient.

**Lemma 21** (three-coordinate near-sphere bound). *Consider a point with $r<1$ and suppose $\beta_{i_0}=+m$ for some $i_0\ge3$. Put $a_3=bm$, $b'=b\sqrt{1-m^2}$, $Y=a_1\chi_1+sa_2\chi_2+a_3\chi_{i_0}$ with atoms $y_j$ and probabilities $p_j$ ($j=1,\dots,8$), $r'=\sqrt{a_1^2+a_2^2+a_3^2}=\sqrt{1-b'^2}$ and $E_4'=3+\max(0,\kappa_4)$. Then $$\mathbb{E}|L|\le\mathbb{E}|Y|+\sum_jp_j\min\Big(b',\ \frac{27}{128}\frac{b'^4E_4'}{|y_j|^3}\Big).$$ If moreover $q\in[q_L,q_3]$, all $y_j\ne0$ and $\frac{27}{128}E_4'\,b'^2(1+r')\sum_jp_j|y_j|^{-3}<T$, then $\mathbb{E}|L|<T$ if $b'>0$, and if $b'=0$ then $\mathbb{E}|L|=G_3(a_1,sa_2,a_3)\le T$.*

*Proof.* If $m=1$ then $b'=0$ and $L=Y$. Otherwise $L=Y+b'M'$, where $M'=\sum_{i\ge3,\,i\ne i_0}\beta_i'\chi_i$ with $\beta_i'=\beta_i/\sqrt{1-m^2}$. Then $M'$ is independent of $Y$, $\sum\beta_i'^2=1$ and $\sum\beta_i'^4\le1$, so $\mathbb{E}M'^4=3+\kappa_4\sum\beta_i'^4\le E_4'$ by Lemma 8. Conditioning on $(\chi_1,\chi_2,\chi_{i_0})$ and applying Lemma 19 with $Z=M'$ (and $\mathbb{E}|M'|\le1$) gives the first bound. By Lemma 5, $\mathbb{E}|Y|=G_3(a_1,sa_2,a_3)\le Tr'$. If $b'>0$, the hypothesis and $1-r'=b'^2/(1+r')$ give $\sum_jp_j\frac{27}{128}\frac{b'^4E_4'}{|y_j|^3}<T\frac{b'^2}{1+r'}=T(1-r')$, hence $\mathbb{E}|L|<Tr'+T(1-r')=T$. ◻

#### Piece tests.

Let $B$ be a box with $b^->0$, and $[m_1,m_2]\subset(0,1]$. On $B\times[m_1,m_2]$ we enclose $a_3\in[b^-m_1,b^+m_2]$, $b'^2\le(b'^2)^+:=(b^+)^2(1-m_1^2)$, $b'\le b'^+$ with $b'^+$ an upper bound of $\sqrt{(b'^2)^+}$, and $r'\le r'^+$ with $r'^+$ an upper bound of $\min\big(1,\sqrt{1-(b^-)^2(1-m_2^2)}\big)$ (recall $r'^2=1-b^2(1-m^2)$). The atoms $y_j=a_1x_{j1}+sa_2x_{j2}+a_3x_{j3}$ ($x\in\{u,-v\}^3$) and the products $p_jy_j=\tau\sum_i(\pm a_i)\prod_{k\ne i}\Pr[x_{jk}]$ (by $qu=(1-q)v=\tau$) are enclosed in interval arithmetic. Let $\eta_j$ be a lower bound of $|y_j|$, $p_j^+$ an upper bound of $p_j$, and $E_4'=3+\max(0,w^+-4)$. The piece passes

- test (A3) if all $\eta_j>0$ and $\frac{27}{128}E_4'(b'^2)^+(1+r'^+)\sum_jp_j^+\eta_j^{-3}<T^-(u_1,u_2)$;

- test (B3) if $\sum_j\big(|p_jy_j|^++p_j^+\min\big(b'^+,\frac{27}{128}((b'^2)^+)^2E_4'/\eta_j^3\big)\big)<T^-(u_1,u_2)$, where $|p_jy_j|^+$ is an upper bound of $|p_jy_j|$ (the second entry of the minimum is omitted if $\eta_j=0$).

By Lemma 21, if a piece passes (A3), then at every point of $B$ with $u\in[u_3,U_+]$ and every remainder with $\beta_{i_0}=+m$, $m\in[m_1,m_2]$, we have $\mathbb{E}|L|<T$ if $b'>0$ and $\mathbb{E}|L|\le T$ if $b'=0$. If it passes (B3), then $\mathbb{E}|L|<T$ by the first bound of Lemma 21 alone.

**Definition 22** ($m$-split box). An $m$-split box is a box $B$ with sign $s$ and $b^->0$, together with: a rational $m_c\in(0,1]$ and a rational $p^*$ with $\varphi(m_c)\le p^*<0$ (this forces $2m_c^2>1$, because $\varphi(m)<0$ iff $(1-m^2)^{3/2}<m^3$ iff $2m^2>1$; the verifier also checks $2m_c^2>1$ directly); a box certificate $c^{(1)}$ for $(B,s,\min(m_c,\bar m(B)),-)$; a box certificate $c^{(2)}$ for $(B,s,\min(1,\bar m(B)),p^*)$; and pieces $[m_1,m_2]$, each passing (A3) or (B3), whose union contains $[m_c,\min(1,\bar m(B))]$.

**Lemma 23** ($m$-split lemma). *Let $B$ be an $m$-split box. At every point of $B$ with $r<1$ and $u\in[u_3,U_+]$ we have $\mathbb{E}|L|\le T$. Equality forces $m=1$, $\beta_{i_0}=+1$ for some $i_0$ (that is, $\alpha=a_1e_1+sa_2e_2+be_{i_0}$), and $G_3(a_1,sa_2,b)=T$.*

*Proof.* Recall $m\le\min(1,\bar m(B))$. If $m\le m_c$, use $c^{(1)}$ and Lemma 18: $\mathbb{E}|L|<T$. If $m\ge m_c$ and $\beta_{i_0}=-m$ for some $i_0$, then $p_3\le\varphi(m_c)\le p^*$ by Lemma 10; use $c^{(2)}$ and Lemma 18: $\mathbb{E}|L|<T$. Otherwise $\beta_{i_0}=+m$ for some $i_0$, and $m\in[m_c,\min(1,\bar m(B))]$ lies in a piece. The piece tests give $\mathbb{E}|L|<T$ unless $b'=0$, i.e. $m=1$, and then $\mathbb{E}|L|=G_3(a_1,sa_2,b)\le T$. ◻

# Computer verification

All scripts and outputs are in the repository (`scripts/`, `outputs/`). Floating point (HiGHS linear programming via scipy) is used only to *find* certificates. Every *verification* is exact or uses outward-rounded interval arithmetic. The programs are those of Theorem 2, run with the environment variable `RQ_K=3`, which selects the target $T$ (in the generators `cert2c.py`, `nearcircle.py`, `nsphere3.py` and in the verifier `verify_k2.py`) and, in the verifier, the data list `outputs/k3_manifest.json`, the target $\Theta_1$ and the $k=3$ three-bit claim.

## Data

- One-coordinate cells: 10 files `outputs/k3/one/o00.json`, …, `o09.json` (2 704 cells), covering $u\in[U_-,U_+]$ and $a\in[0,\frac25]$.

- Two-coordinate boxes: 58 files `outputs/k3/cover2c/p00.json`, …, `p57.json` ($s=+1$, $u$-slabs of width $0.005$, the first one $[U_-,\frac{423}{200}]$) and 29 files `m00.json`, …, `m28.json` ($s=-1$, width $0.01$, the first one $[U_-,\frac{53}{25}]$). For each sign they cover $[U_-,U_+]\times[0,T_8]\times[\frac25,1]$. Each file records $K=3$ and $A_S=\frac25$. Each box record has its kind and data: <span class="sans-serif">lp</span> (certificate $c$), <span class="sans-serif">ncA</span>/<span class="sans-serif">ncB</span>, <span class="sans-serif">small</span> (boxes with $r_2c(t_1)\le\frac25$, i.e. $a_1\le\frac25$ on the whole box, which are left to the one-coordinate route), and <span class="sans-serif">ms</span> ($m_c$, $p^*$, $c^{(1)}$, $c^{(2)}$ and the pieces).

| sign   | <span class="sans-serif">lp</span> | <span class="sans-serif">ncA</span> | <span class="sans-serif">ncB</span> | <span class="sans-serif">ms</span> | <span class="sans-serif">small</span> |  total |
|:-------|-----------------------------------:|------------------------------------:|------------------------------------:|-----------------------------------:|--------------------------------------:|-------:|
| $s=+1$ |                             45 720 |                               1 097 |                               1 205 |                             21 232 |                                   617 | 69 871 |
| $s=-1$ |                             11 613 |                                   0 |                                 232 |                                  0 |                                   259 | 12 104 |

Two-coordinate boxes for Theorem 3. Widths range from $2.5\cdot10^{-3}$ to $0.0106$ in $u$, from $1.6\cdot10^{-3}$ to $0.052$ in $t$ and from $3.1\cdot10^{-3}$ to $0.05$ in $r$. The <span class="sans-serif">ms</span> boxes carry 32 932 pieces (32 386 of type (A3), 546 of type (B3)), with $m_c\in\{\frac34,\frac{31}{40},\frac45,\frac{33}{40},\frac{17}{20},\frac78,\frac9{10}\}$.

## Generation

`scripts/run_k3.sh` runs the 97 jobs of `outputs/k3/jobs.txt`. A two-coordinate job is `RQ_K=3 RQ_AS=2/5 python3 cover2c.py u1 u2 s out.json 1 8 12 18 ms`: it bisects $[u_1,u_2]\times[0,T_8]\times[\frac25,1]$ adaptively (8 initial $t$-intervals, 12 $r$-intervals, depth $\le18$) and on each box tries, in order: <span class="sans-serif">small</span>; the near-circle tests (`nearcircle.py`, exact rationals); a box certificate (`cert2c.py`); the $m$-split (`cover2c.try_msplit`, `nsphere3.py`). The certificates come from a discretised six-moment linear program (dual multipliers of the moment rows), rounded to rationals and repaired; (W1) is checked exactly on every linear piece of $F_B$ by real-root counting, and (W2) exactly by bisection. One-coordinate cells come from `cover_k3.py` (the pipeline of `MAIN_RESULT` with target $\Theta_1$). No box or cell failed.

## Independent verification

`RQ_K=3 python3 verify_k2.py` re-checks everything. The verifier shares no code with the generators; it reuses only the Sturm-sequence, integer-square-root and tiling helpers of `verify_all.py` (the verifier of Theorem 1, audited in A.6). Its parts:

1.  Symbolic identities (sympy): $p_jx_j=r\tau g_j$ for both signs, $\sum p_j=1$, mean $0$, the two-coordinate values, the half-angle formulas, the constant $27/256$, the identity $T=\sqrt3\,\tilde T(u)$ and the derivative of $u^5/(1+u^2)^3$.

2.  Coverage (exact). The one-coordinate cells tile $[U_-,U_+]\times[0,\frac25]$. For each sign the boxes tile $[U_-,U_+]\times[0,T_8]\times[\frac25,1]$: they lie in the region, have pairwise disjoint interiors and total volume equal to the volume of the region. A closed subset of full measure is dense, so it is the whole region. Also $U_-<u_3$, $U_+<u_4$, $T_8\ge\sqrt2-1$, every file has $K=3$ and $A_S=\frac25$, and every <span class="sans-serif">small</span> box has $r_2c(t_1)\le\frac25$.

3.  One-coordinate cells: (V1)–(V3) by Sturm sequences; $\Theta_1>0$; (V4) strictly by Sturm on $[0,\bar m]$.

4.  Box certificates (<span class="sans-serif">lp</span>, and both certificates of each <span class="sans-serif">ms</span> box): (W1) by writing $F_B$ on each half-line as the maximum of the $16$ sign-pattern lines and checking by Sturm counting that $P$ minus each line is positive on that half-line; (W2) strictly, with the target $T^-(u_1,u_2)$ of (2); for <span class="sans-serif">ms</span> boxes also $0<m_c\le1$, $2m_c^2>1$, $p^*<0$, $p^*\ge\varphi(m_c)$ (as $(p^*+m_c^3)^2\ge(1-m_c^2)^3$ with $p^*+m_c^3\ge0$), and $m^*=\min(m_c,\bar m)$ for $c^{(1)}$. The verifier recomputes $\bar m$ as the exact quotient $r_2d(t_2)/b^-$.

5.  Near-circle boxes: mpmath interval arithmetic (120 bits), tests (A)/(B) strictly, with $T^-$ computed from an interval enclosure of $\sqrt3$.

6.  $m$-split pieces: the pieces with $s_3=+1$ cover $[m_c,\min(1,\bar m)]$; each passes (A3) or (B3) in mpmath interval arithmetic (120 bits); the box has $u_1\ge2$.

7.  The three-bit claim of Lemma 5, for all 256 functions, by exact Sturm sequences as described there, on $[q_L,q_3]$ with $q_L=1/(1+U_+^2)$, including the list of equality cases.

The output is `outputs/verify_k3_ABCDEFG.txt` (all parts pass).

#### Negative tests.

`RQ_K=3 python3 break_tests_k2.py` corrupts random samples of records and runs the check functions of `verify_k2.py` on them (output `outputs/break_tests_k3.txt`). A corruption is counted only if it changes the record. On 40 <span class="sans-serif">ms</span> boxes, each of the following is rejected 40 times out of 40: lowering $m_c$ by $\frac1{10}$ (the pieces no longer reach $m_c$); removing or halving the top piece; lowering $p^*$ by $\frac1{100}$ (below $\varphi(m_c)$); lowering the constant term of $c^{(2)}$ by $10^{-3}$; multiplying the constant term of $c^{(1)}$ by $\frac{99}{100}$; widening the $r$- or the $t$-interval downwards by $\frac1{20}$. Raising $m_c$ by $\frac1{10}$ is rejected $37/40$ times; in the other three cases $c^{(1)}$ still satisfies the objective bound with the larger cap, the pieces still cover $[m_c,1]$ and $\varphi$ is decreasing, so the modified record is still a valid proof. The pair $(-m_c,\,1+m_c^3)$ satisfies the $\varphi$ inequality $(p^*+m^3)^2\ge(1-m^2)^3$, $p^*+m^3\ge0$ for $m=-m_c$; the check rejects it in $40/40$ cases because it also requires $0<m_c\le1$ and $p^*<0$. On 60 <span class="sans-serif">lp</span> boxes, lowering $c_0$ by $10^{-3}|c_0|$ or $c_6$ by $10^{-1}|c_6|$ is rejected $60/60$ times, and widening the $r$-interval downwards by $\frac1{10}$ (but not below $\frac25$) is rejected in all $58$ cases where it changes the box (two of the sampled boxes already start at $r=\frac25$). On 60 near-circle boxes, widening the $r$-interval by $\frac1{10}$ is rejected $60/60$ times; on 40 one-coordinate cells, lowering $c_0$ by $10^{-3}|c_0|$ is rejected $40/40$ times. The claim of Lemma 5 fails at $q_3+10^{-3}$ (for the OR of two bits).

Two corruptions are *not* always detected, as expected. Shifting an <span class="sans-serif">ms</span> box by $-\frac1{20}$ in $u$ (below $u_3$) passes part F in $17/40$ cases (it is rejected by part D in $40/40$ cases), and moving a near-circle box to $u\le2<u_3$ passes part E in $43/60$ cases. The piece test (A3) and the near-circle test (A) only bound the error term. The main term is bounded by Lemma 5 and by Lemma 4 with $T_2\le T$, and both hold only for $q\le q_3$. This is why Lemma 20(A) and Lemma 23 are stated only for $u\ge u_3$, and why the theorem stops at $u_3$.

## Reproducing

    pip install numpy scipy sympy mpmath
    cd scripts
    RQ_K=3 python3 verify_k2.py        # parts A-G
    RQ_K=3 python3 break_tests_k2.py   # negative tests
    # regeneration of one slab, e.g. the first one (s = +1, next to u3):
    RQ_K=3 RQ_AS=2/5 python3 cover2c.py 2109381/1000000 423/200 1 \
            ../outputs/k3/cover2c/p00.json 1 8 12 18 ms

# Proof of Theorem 3

*(a)* By Lemma 2 let $q\in[q_L,q_3]$, i.e. $u\in[u_3,U_+]\subset[U_-,U_+]$. Reduce $\alpha$ as in Section 2.3.

1.  $a_1=1$: $\alpha=e_1$ and $\mathbb{E}|L|=2\tau<T$ (Lemma 3(ii)).

2.  $a_1\le\frac25$: $(u,a_1)$ lies in a cell, and Lemma 13 gives $\mathbb{E}|L|<T$.

3.  $a_1>\frac25$ and $r=1$: $L=a_1\chi_1+sa_2\chi_2$, and Lemma 4 ($q\le q_3$) gives $\mathbb{E}|L|\le T$, with equality iff $q=q_3$, $s=1$ and $a_1=a_2$.

4.  $a_1>\frac25$ and $r<1$: $(u,t,r)$ lies in a box of the cover for the sign $s$ (part B), and the box is not <span class="sans-serif">small</span>, because $a_1>\frac25$. If it is <span class="sans-serif">lp</span>, Lemma 18 with $m^*=\min(1,\bar m(B))\ge m$ gives $\mathbb{E}|L|<T$. If it is <span class="sans-serif">ncA</span> or <span class="sans-serif">ncB</span>, Lemma 20 gives $\mathbb{E}|L|<T$ (here $u\ge u_3$). If it is <span class="sans-serif">ms</span>, Lemma 23 gives $\mathbb{E}|L|\le T$ (here $u\in[u_3,U_+]$).

So $\mathbb{E}|L|\le T$ always, and $(e_1+e_2+e_3)/\sqrt3$ attains $T$ (Lemma 3, $q<\frac13$). Hence $R(q)=T(q)$. For $q\in[1-q_3,1-q_L]$ use Lemma 2: $R(q)=R(1-q)=2\sqrt3\,q^2\tau$.

*(b)* Equality can occur only in case (3) and in the <span class="sans-serif">ms</span> case of (4). Case (3) gives $q=q_3$ and $\alpha=\pm(e_i+e_j)/\sqrt2$. In the <span class="sans-serif">ms</span> case, Lemma 23 gives $\alpha=a_1e_1+sa_2e_2+be_{i_0}$ (after the reduction) with $G_3(a_1,sa_2,b)=T$ and $a_1,b>0$, $a_2\ge|\alpha_{i_0}|=b>0$. By Lemma 5, $(a_1,sa_2,b)$ is a positive multiple of $\pm(1,1,1)$, or $q=q_3$ and it is a positive multiple of $\pm(e_i+e_j)$. The second is impossible because all three entries are nonzero. So $s=1$ and $a_1=a_2=b$, i.e. $\alpha=(e_1+e_2+e_{i_0})/\sqrt3$. Undoing the reduction (global sign and permutation) gives the list in (b). Conversely, each listed vector attains $T$ at the stated $q$ (Lemma 3; at $q_3$, $T_2=T$). For $q\ge\frac12$ use Lemma 2.

*(c)* For $q\in(q_3,\frac12]$, $R(q)\ge T_2(q)>T(q)$ by Lemma 3 and (i). For $q<q_4<\frac14$, $R(q)\ge\mathbb{E}|\chi_1+\dots+\chi_4|/2=4(1-q)^3\tau>T(q)$ by Lemma 3 and (iii). Together with (a) this gives $[q_L,q_3]\subseteq\{q\le\frac12:R(q)=T(q)\}\subseteq[q_4,q_3]$.$\square$

# Remarks

1.  **What changed from Theorem 2.** Only the target, the range, $A_S$, $\Theta_1$ and the three-bit lemma. The near-circle lemma now treats a point that is *not* an extremiser for $q<q_3$: at $(e_1+e_2)/\sqrt2$ we have $\mathbb{E}|L|=T_2<T$. The $m$-split, which in Theorem 2 was needed only for $u\ge2.09$, is now needed throughout $[u_3,U_+]$ (it is used in 21 232 of the 69 871 of the $s=+1$ boxes).

2.  **Why the range stops at $\frac{25}{169}$.** Two parts of the method lose their margin below $q\approx0.14$ (`outputs/k3/scan_one.txt`, `scan_two.txt`; floating point, evidence only). (i) The one-coordinate route: as $a_1\to0$ the remainder becomes Gaussian, and the best six-moment bound tends to the six-moment Gaussian value $\sup\{\mathbb{E}|X|:\mathbb{E}X^j=\mathbb{E}G^j,\ j\le6\}\approx0.888074$. The scanned ratio of the six-moment bound to $T$ is $0.9937$ at $q=0.15$, $0.9990$ at $q=0.14$ and $1.0027$ at $q=0.135$, for small $a$. (ii) The two-coordinate route near $a_1=a_2\approx0.57$: the plain certificate already fails at $q=0.145$ (margin $-5\cdot10^{-4}$, so the $m$-split is needed there), and at $q=0.14$ the scan has points where every tried $m_c$ fails (the capped certificate or the piece test (A3)).

3.  **The gap $[q_4,\frac{25}{169})$.** We conjecture $R=T$ on $[q_4,q_3]$; this is the case $k=3$ of the conjecture $R(q)=\max_k2\sqrt k(1-q)^{k-1}\tau$ for $q\le\frac12$ (BF3, Stone; RQ-C’s Conjecture S). Six moments cannot reach $q_4$: $0.888074>T(q_4)\approx0.884970$. Eight moments do not help either, since the eight-moment Gaussian value is $\approx0.886410$. Ten moments give $\approx0.856068$, below $\sqrt{2/e}\approx0.857764=\lim_{q\to0}R(q)$ (these values come from a floating-point linear program over polynomial majorants of $|y|$; numerical). At $q_4$ the vector $(e_1+\dots+e_4)/2$ also attains $T$. In our coordinates it has $M=(\chi_3+\chi_4)/\sqrt2$ with two equal largest coefficients, which the $m$-split does not handle.

4.  **Status.** Not yet audited. The computer steps have been run twice (generator and independent verifier), and the verifier rejects corrupted data (negative tests above).
