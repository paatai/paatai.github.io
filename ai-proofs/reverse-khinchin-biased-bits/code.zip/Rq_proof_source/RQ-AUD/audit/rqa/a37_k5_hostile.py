"""A.37 (RQ-AUD): hostile search for a counterexample to MAIN-6 (E|sum alpha_i chi_i| <= T5 = 2 sqrt5 (1-q)^4 tau
for unit alpha, q in [q6, q5]) with n = 5 ... 14 coordinates. Evidence, not proof. Own code.

E|alpha . chi| is computed exactly in float64 over all 2^n atoms. The ascent alpha <- E[sign(alpha . chi) chi] / norm
never decreases f(alpha) = E|alpha . chi| (f is convex and 1-homogeneous, so f(new) >= <grad f(alpha), new> =
|grad f(alpha)| >= f(alpha)); runs stop at a fixed point."""
import sys, time
import numpy as np

rng = np.random.default_rng(20261022)
q5 = 1 - 2 / np.sqrt(5)
q6 = 1 - np.sqrt(5 / 6)


def T5(q):
    return 2 * np.sqrt(5) * (1 - q) ** 4 * np.sqrt(q * (1 - q))


def atoms(n, q):
    u = np.sqrt((1 - q) / q)
    codes = np.arange(2 ** n)
    bits = ((codes[:, None] >> np.arange(n)[None, :]) & 1).astype(float)
    X = np.where(bits == 1, u, -1 / u)
    k = bits.sum(1)
    P = q ** k * (1 - q) ** (n - k)
    return X, P


def ascend(a, X, P, iters=400):
    a = a / np.linalg.norm(a)
    f = P @ np.abs(X @ a)
    for _ in range(iters):
        s = np.sign(X @ a)
        g = (P * s) @ X
        b = g / np.linalg.norm(g)
        fb = P @ np.abs(X @ b)
        if fb <= f * (1 + 1e-15):
            break
        a, f = b, fb
    return f, a


def main():
    t0 = time.time()
    nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    qs = [q6, q6 + 0.25 * (q5 - q6), 0.5 * (q5 + q6), q6 + 0.75 * (q5 - q6), q5]
    worst = (-1, None)
    print('A.37 hostile search for MAIN-6 (RQ-AUD); ratio = E|alpha . chi| / T5(q)')
    for n in range(5, nmax + 1):
        nrand = 300 if n <= 10 else 120
        for q in qs:
            X, P = atoms(n, q)
            T = T5(q)
            best = (-1, None, '')
            starts = []
            for _ in range(nrand):
                starts.append((rng.standard_normal(n), 'gauss'))
                starts.append((np.abs(rng.standard_normal(n)), 'positive'))
            for k in (4, 5, 6):
                if k <= n:
                    base = np.zeros(n); base[:k] = 1
                    for eps in (1e-3, 1e-2, 5e-2, 0.15):
                        for _ in range(20):
                            starts.append((base + eps * rng.standard_normal(n), f'ext{k}+{eps}'))
            for a0, tag in starts:
                f, a = ascend(a0, X, P)
                if f / T > best[0]:
                    best = (f / T, a, tag)
            r, a, tag = best
            aa = np.sort(np.abs(a))[::-1]
            supp = int((aa > 1e-6).sum())
            print(f'n = {n:2d}, q = {q:.6f}: max ratio {r:.12f} (start {tag}); support {supp}, '
                  f'top |alpha| {np.round(aa[:7], 6).tolist()}')
            if r > worst[0]:
                worst = (r, (n, q, tag))
        sys.stdout.flush()
    print(f'overall max ratio {worst[0]:.12f} at n, q, start = {worst[1]}; exceeds 1 + 1e-12: {worst[0] > 1 + 1e-12}')
    print(f'time {time.time() - t0:.0f} s')


if __name__ == '__main__':
    main()
