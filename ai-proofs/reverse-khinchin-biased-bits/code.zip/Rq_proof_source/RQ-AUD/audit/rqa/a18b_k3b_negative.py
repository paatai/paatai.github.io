"""RQ-AUD negative, calibrated and semantic tests for a18_k3b_verify.py (RQ-A k3b cover).

N1 cells: c0 -= 1/20; cap := 1; calibrated objective (T - 2 slack must fail, T - slack/2 must pass, slack = min over
   rho in [0, cap] of T - bound, computed in floating point and then decided exactly).
N2 semantic: E P(M) exact (rational u, rational beta, moments by enumeration, normalisation in mpmath) never exceeds
   my ten-moment bound const + sum_k B_k rho^k at rho = sqrt(p4), for cell and vertex certificates.
N3 vertex sets: c0 -= 1/20 at one vertex; one vertex moved by 1e-6; polytope shrunk by 10% about its centre;
   target lowered by 1%.
N4 m-split: an A4 piece widened to [n1/2, n2]; an A3 piece widened to [m1/2, m2]; minus-side cover with one piece
   removed; SG p* lowered below phi(m1).
N5 bit lemmas: four-bit lemma on [q4 - 10^-6, 25/169] must fail (OR_4); 12 -> 12 - 10^-6 must fail (OR_3).
N6 tilings: one cell removed; one box removed.
"""
import copy
import os
import random
import sys
from fractions import Fraction as Fr
from itertools import product
from multiprocessing import Pool

import mpmath as mp
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import a18_k3b_verify as W  # noqa: E402
from a6_lemmaS_verify import tiles  # noqa: E402

rng = random.Random(20261022)
mp.mp.dps = 50


def mq(x):
    x = Fr(x)
    return mp.mpf(x.numerator) / mp.mpf(x.denominator)


def slack_float(c, u1, u2, cap, T, p3max=None):
    const, B = W.objective_poly(c, u1, u2, cap, p3max)
    xs = np.linspace(0, float(cap), 20001)
    val = float(T - const) - sum(float(b) * xs**k for k, b in B.items())
    return float(val.min())


def n1_cell(cl):
    u1, u2, a1, a2, c = cl
    out = {}
    out['c0'] = not W.cell_once(u1, u2, a1, a2, [c[0] - Fr(1, 20)] + c[1:])[0]
    b2 = W.sqrt_lo(1 - a2 * a2)
    mh = min(Fr(1), a2 / b2)
    T = W.K3.theta1(u1, u2, a2, W.S3)
    sl = slack_float(c, u1, u2, mh, T)
    out['slack'] = sl
    d = Fr(sl).limit_denominator(10**12)
    out['cal_fail'] = not W.objective_ok(c, u1, u2, mh, T - 2 * d)[0]
    out['cal_pass'] = W.objective_ok(c, u1, u2, mh, T - d / 2)[0]
    out['cap1'] = not W.objective_ok(c, u1, u2, Fr(1), T)[0] if mh < 1 else None
    return out


def exact_moments(beta, u, D):
    q = 1 / (1 + u * u)
    mom = [Fr(0)] * (D + 1)
    for bits in product((0, 1), repeat=len(beta)):
        w, x = Fr(1), Fr(0)
        for b, bit in zip(beta, bits):
            w *= q if bit else 1 - q
            x += b * (u if bit else -1 / u)
        p = Fr(1)
        for m in range(D + 1):
            mom[m] += w * p
            p *= x
    return mom


def n2_semantic(args):
    c, u1, u2, cap, p3max, seed = args
    r = random.Random(seed)
    D = len(c) - 1
    const, B = W.objective_poly(c, u1, u2, cap, p3max)
    worst = mp.mpf('inf')
    tried = 0
    for _ in range(40):
        u = u1 + (u2 - u1) * Fr(r.randint(0, 1000), 1000)
        n = r.randint(2, 7)
        beta = [Fr(r.randint(-60, 60), 60) for _ in range(n)]
        if all(b == 0 for b in beta):
            continue
        S = sum(b * b for b in beta)
        mx = max(abs(b) for b in beta)
        if mx * mx > cap * cap * S:
            beta = [b if abs(b) * abs(b) <= cap * cap * S / 4 else b / 4 for b in beta]
            S = sum(b * b for b in beta)
            mx = max(abs(b) for b in beta)
            if mx * mx > cap * cap * S:
                continue
        p3 = mq(sum(b**3 for b in beta)) / mq(S)**mp.mpf(1.5)
        if p3max is not None and not p3 <= mq(p3max):
            beta = [-b for b in beta]
            p3 = -p3
            if not p3 <= mq(p3max):
                continue
        mom = exact_moments(beta, u, D)
        EP = sum(mq(cn) * mq(mom[nn]) / mq(S)**(mp.mpf(nn) / 2) for nn, cn in enumerate(c))
        rho = mp.sqrt(mq(sum(b**4 for b in beta)) / mq(S)**2)
        bound = mq(const) + sum(mq(b) * rho**k for k, b in B.items())
        worst = min(worst, bound - EP)
        tried += 1
    return float(worst), tried


def n3_vset(job):
    name, rec, X, s, s3, box, cap, p3max = job
    out = {}
    r = copy.deepcopy(rec)
    j = rng.randrange(len(r['C']))
    r['C'][j][0] = str(Fr(r['C'][j][0]) - Fr(1, 20))
    out['c0'] = not W.vjob_check((name, r, X, s, s3, box, cap, p3max))[0]
    r = copy.deepcopy(rec)
    v = [Fr(x) for x in r['V'][0]]
    v[0] += Fr(1, 10**6)
    r['V'][0] = [str(x) for x in v]
    out['move'] = not W.vjob_check((name, r, X, s, s3, box, cap, p3max))[0]
    r = copy.deepcopy(rec)
    Vs = [[Fr(x) for x in vv] for vv in r['V']]
    cen = [sum(vv[i] for vv in Vs) / len(Vs) for i in range(len(Vs[0]))]
    r['V'] = [[str(cen[i] + Fr(9, 10) * (vv[i] - cen[i])) for i in range(len(vv))] for vv in Vs]
    out['shrink'] = not W.vjob_check((name, r, X, s, s3, box, cap, p3max))[0]
    n0 = [Fr(x) for x in rec['n0']]
    H, _ = W.cone_functionals(n0, [[Fr(x) for x in vv] for vv in rec['V']])
    T = W.T_lo(box[0], box[1])
    bad = False
    for vv, cc in zip(rec['V'], rec['C']):
        ok, _ = W.vertex_ok([Fr(x) for x in cc], [Fr(x) for x in vv], s, s3, box[0], box[1], cap, T * Fr(99, 100), p3max)
        bad |= not ok
    out['T99'] = bad
    return out


def main():
    tests = sys.argv[1] if len(sys.argv) > 1 else '123456'
    man, cells, boxes = W.load()
    print(f"data: {len(cells)} cells, {len(boxes)} boxes; tests {tests}", flush=True)
    if '1' in tests:
        with Pool(8) as pool:
            res = pool.map(n1_cell, cells, chunksize=2)
        c0 = sum(r['c0'] for r in res)
        cf = sum(r['cal_fail'] for r in res)
        cp = sum(r['cal_pass'] for r in res)
        c1 = [r['cap1'] for r in res if r['cap1'] is not None]
        sl = sorted(r['slack'] for r in res)
        print(f"N1 cells: c0 -= 1/20 rejected {c0}/{len(cells)}; calibrated objective T - 2 slack rejected {cf}/{len(cells)},"
              f" T - slack/2 accepted {cp}/{len(cells)}; cap := 1 rejected {sum(c1)}/{len(c1)};"
              f" objective slack min {sl[0]:.3e}, median {sl[len(sl) // 2]:.3e}", flush=True)

    jobs = []
    for bx in boxes:
        if bx['kind'] in ('lpv', 'ms5'):
            jobs += W.vertex_jobs(bx)[0]
    sem = []
    for cl in rng.sample(cells, 40):
        u1, u2, a1, a2, c = cl
        b2 = W.sqrt_lo(1 - a2 * a2)
        sem.append((c, u1, u2, min(Fr(1), a2 / b2), None, rng.randrange(10**9)))
    for jb in rng.sample(jobs, 80):
        name, rec, X, s, s3, box, cap, p3max = jb
        for cc in rec['C'][:2]:
            sem.append(([Fr(x) for x in cc], box[0], box[1], cap, p3max, rng.randrange(10**9)))
    if '2' in tests:
        with Pool(8) as pool:
            res2 = pool.map(n2_semantic, sem, chunksize=2)
        tried = sum(t for _, t in res2)
        worst = min(w for w, t in res2 if t)
        print(f"N2 semantic: {tried} (certificate, u, beta) triples from {len(sem)} certificates; min (bound - exact E P(M))"
              f" = {worst:.3e} (must be >= 0)", flush=True)

    by_role = {}
    for jb in jobs:
        by_role.setdefault(jb[0], []).append(jb)
    sample = []
    for role, lst in sorted(by_role.items()):
        sample += rng.sample(lst, min(12, len(lst)))
    if '3' in tests:
        with Pool(8) as pool:
            res3 = pool.map(n3_vset, sample, chunksize=1)
        for key, label in (('c0', 'c0 -= 1/20 at one vertex'), ('move', 'one vertex moved by 1e-6'),
                           ('shrink', 'polytope shrunk by 10% about its centre'), ('T99', 'target lowered by 1%')):
            print(f"N3 vertex sets ({len(sample)} sampled over roles {sorted(by_role)}): {label}: rejected"
                  f" {sum(r[key] for r in res3)}/{len(sample)}", flush=True)

    mss = [bx for bx in boxes if bx['kind'] == 'ms5']
    a4 = [(bx, pc, sub) for bx in mss for pc in bx['plus'] if pc['type'] == 'TCS' for sub in pc['sub']]
    rej = 0
    for bx, pc, sub in rng.sample(a4, min(25, len(a4))):
        box = tuple(Fr(x) for x in bx['box'])
        m1, m2 = Fr(pc['m'][0]), Fr(pc['m'][1])
        rej += W.near4(box, bx['s'], m1, m2, Fr(sub[0]) / 2, Fr(sub[1])) is None
    a3 = [(bx, pc) for bx in mss for pc in bx['plus'] if pc['type'] in ('A3', 'B3')]
    rej3 = 0
    for bx, pc in rng.sample(a3, min(25, len(a3))):
        box = tuple(Fr(x) for x in bx['box'])
        rej3 += W.K3.piece_test(box, bx['s'], Fr(pc['m'][0]) / 2, Fr(pc['m'][1]), W.S3) is None
    rejc = 0
    for bx in rng.sample(mss, 25):
        b2 = copy.deepcopy(bx)
        b2['minus'] = sorted(b2['minus'], key=lambda p: Fr(p['m'][0]))[1:] if len(b2['minus']) > 1 else []
        rejc += not W.ms5_structure((b2,))[0]
    sgs = [pc for bx in mss for pc in bx['minus'] if pc['type'] == 'SG']
    phi_rej = 0
    for pc in rng.sample(sgs, min(25, len(sgs))):
        m1 = Fr(pc['m'][0])
        phi_lo = Fr(mp.nstr((1 - mq(m1)**2)**1.5 - mq(m1)**3, 30)) - Fr(1, 10**12)
        phi_rej += not W.phi_ok(phi_lo, m1)
    print(f"N4 m-split: A4 widened to [n1/2, n2] rejected {rej}/{min(25, len(a4))}; A3 widened to [m1/2, m2] rejected"
          f" {rej3}/{min(25, len(a3))}; one minus piece removed rejected {rejc}/25; SG p* = phi(m1) - 1e-12 rejected"
          f" {phi_rej}/{min(25, len(sgs))}", flush=True)

    import sympy as sp
    cache, seen, pts, q = W.bit_polys(4)
    mu4 = sp.Poly(4 * q**2 - 8 * q + 1, q)
    q4lo = 1 - W.sqrt_hi(Fr(3, 4))
    lo2 = q4lo - Fr(1, 10**6)
    bad_lo = [k for k, P in cache.items() if not W.nonneg_on(P, q, None, Fr(25, 169), lo2)[0]]
    f_bad = sum(len(seen[k]) for k in bad_lo)
    or4 = {W.or_fn(pts, (0, 1, 2, 3), sg) for sg in (1, -1)}
    hit4 = any(set(seen[k]) & or4 for k in bad_lo)
    eps = Fr(1, 10**6)
    bad_e = []
    for k, P in cache.items():
        P2 = P - sp.Poly(sp.Rational(eps.numerator, eps.denominator) * (1 - q)**4, q)
        if not W.nonneg_on(P2, q, mu4, Fr(25, 169), q4lo)[0]:
            bad_e.append(k)
    print(f"N5 four-bit lemma on [q4 - 1e-6, 25/169]: fails for {f_bad} f (includes +-OR_4: {hit4});"
          f" with 12 - 1e-6 on [q4, 25/169]: fails for {sum(len(seen[k]) for k in bad_e)} f", flush=True)

    reg1 = (W.U_LO, W.U_HI, Fr(0), W.A_S)
    cl2 = [cl[:4] for cl in cells]
    drop = cl2[:17] + cl2[18:]
    t1 = not tiles(reg1, drop)[0]
    reg3 = (W.U_LO, W.U_HI, Fr(0), W.T8, W.A_S, Fr(1))
    bs = [tuple(Fr(x) for x in bx['box']) for bx in boxes if bx['s'] == -1]
    ins, voleq, nov = W.V.tiling3(reg3, bs[:100] + bs[101:])
    t2 = not (ins and voleq and nov == 0)
    print(f"N6 tilings: one cell removed rejected {t1}; one s=-1 box removed rejected {t2}", flush=True)


if __name__ == '__main__':
    main()
