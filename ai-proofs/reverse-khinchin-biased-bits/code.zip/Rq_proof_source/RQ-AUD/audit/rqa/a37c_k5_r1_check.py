"""A.37 addendum (RQ-AUD): check the sentences that RQ-A added to Remark 4 of MAIN_RESULT_K5.tex when applying
A.37's r1 (23:04 UTC). Per box of kind ms, compute the height of the split tree (a TCS piece counts as a TCN piece,
Definition 30) and the set of near-sphere piece sizes, then check: heights 2017 / 809 / 1348 / 129 with 2286 of
height >= 1; the height-3 trees are exactly the boxes with a TCS piece at level 2; and these are exactly the boxes
with six-coordinate pieces. Own code; reads only the JSON data in k5_data/."""
import json, os, time
from collections import Counter

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, 'k5_data')


def main():
    t0 = time.time()
    man = json.load(open(os.path.join(DATA, 'k5_manifest.json')))
    heights = Counter()
    h3, tcs2, six = set(), set(), set()
    tcs2_nosub = 0
    for fn in man['two_files']:
        d = json.load(open(os.path.join(DATA, fn)))
        for ib, bx in enumerate(d['boxes']):
            if bx['kind'] != 'ms':
                continue
            key = (fn, ib)
            sizes = set()
            has_tcs2 = False

            def node(nd, lev):
                nonlocal has_tcs2, tcs2_nosub
                h = 0
                for pc in nd['plus']:
                    tp = pc['type']
                    if tp[0] in 'AB':
                        sizes.add(int(tp[1:]))
                    elif tp == 'TCN':
                        h = max(h, 1 + node(pc, lev + 1))
                    elif tp == 'TCS':
                        h = max(h, 1)
                        if lev == 2:
                            has_tcs2 = True
                            if not pc['sub']:
                                tcs2_nosub += 1
                        for _, _, typ in pc['sub']:
                            sizes.add(int(typ[1:]))
                return h

            h = node(bx, 0)
            heights[h] += 1
            if h == 3:
                h3.add(key)
            if has_tcs2:
                tcs2.add(key)
            if 6 in sizes:
                six.add(key)
    ok = (dict(heights) == {0: 2017, 1: 809, 2: 1348, 3: 129} and sum(heights[k] for k in (1, 2, 3)) == 2286
          and h3 == tcs2 == six and len(six) == 129 and tcs2_nosub == 0)
    print('heights of ms trees', dict(sorted(heights.items())), '; height >= 1:', sum(heights[k] for k in (1, 2, 3)))
    print('height-3 boxes', len(h3), '; boxes with a TCS piece at level 2', len(tcs2),
          '; boxes with six-coordinate pieces', len(six), '; level-2 TCS pieces without sub-pieces', tcs2_nosub)
    print('height 3 == TCS at level 2 == six-coordinate pieces:', h3 == tcs2 == six)
    print('R1_CHECK_PASS' if ok else 'R1_CHECK_FAIL', f'({time.time() - t0:.1f} s)')


if __name__ == '__main__':
    main()
