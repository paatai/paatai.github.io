#!/usr/bin/env python3
"""A.34c (RQ-AUD): negative and positive controls for a34_bandstar_verify.py (not part of the proof).

  origin squares [0, 1/256]^2 and [0, 1/128]^2, no refinement: certified at shift 0; NOT certified at shifts 1e-30,
    1e-9, 1/2000 (a positive shift also disables T1; on the Dirac curve F = g(L) at rho^2 = 0), nor without the
    slope check;
  the squares of the last level (side 1/1024) of the certificate run, no refinement: certified at shift 0; count at
    shifts 1/10000 and 1/1000.
"""
import json
import sys
from fractions import Fraction as F
from multiprocessing import Pool

import a34_bandstar_verify as V


class NoSlope(V.Square):
    def __init__(self, *a, **k):
        super().__init__(*a, **k)
        self.slope_ok = False


def job(args):
    cls, sq, shift = args
    r = cls(*sq, shift=shift).run()
    return dict(ok=r['ok'], fail=r.get('fail'), boxes=r['boxes'])


def main():
    out, bad = [], 0
    with Pool(8) as pool:
        tasks, names = [], []
        for side in (256, 128):
            sq = (F(0), F(1, side), F(0), F(1, side))
            for shift, expect in ((F(0), True), (F(1, 10 ** 30), False), (F(1, 10 ** 9), False), (F(1, 2000), False)):
                tasks.append((V.Square, sq, shift))
                names.append((f'origin [0,1/{side}]^2 shift {shift}', expect))
            tasks.append((NoSlope, sq, F(0)))
            names.append((f'origin [0,1/{side}]^2 without slope check', False))
        for (name, expect), r in zip(names, pool.map(job, tasks, chunksize=1)):
            rec = dict(control=name, certified=r['ok'], expected=expect, boxes=r['boxes'], first_fail=r['fail'])
            out.append(rec)
            bad += r['ok'] != expect
            print(json.dumps(rec))
            sys.stdout.flush()
        last = [json.loads(l) for l in open('outputs/a34_squares_shift0.jsonl')]
        top = max(r['side'] for r in last)
        sqs = [tuple(F(x) for x in r['sq']) for r in last if r['side'] == top]
        for shift in (F(0), F(1, 10000), F(1, 1000)):
            res = pool.map(job, [(V.Square, sq, shift) for sq in sqs], chunksize=1)
            nfail = sum(not r['ok'] for r in res)
            rec = dict(control=f'{len(sqs)} last-level squares (side 1/{top}) shift {shift}', not_certified=nfail)
            if shift == 0:
                rec['expected_not_certified'] = 0
                bad += nfail != 0
            out.append(rec)
            print(json.dumps(rec))
            sys.stdout.flush()
    print('CONTROLS AS EXPECTED' if bad == 0 else f'{bad} CONTROLS NOT AS EXPECTED')


if __name__ == '__main__':
    main()
