#!/usr/bin/env python3
"""A.34e (RQ-AUD): exact check, from outputs/a34_squares_shift0.jsonl alone, that the certified squares cover
T = {a, b >= 0, a + b <= 1/5}: level 0 is every square of side 1/128 meeting T; each later level is exactly the set
of children meeting T of the squares not certified before; the last level has none uncertified; and the certified
squares' areas inside T add up to area(T) = 1/50 (exact rationals)."""
import json
from fractions import Fraction as F

RM = F(1, 5)
rows = [json.loads(l) for l in open('outputs/a34_squares_shift0.jsonl')]
levels = sorted({r['side'] for r in rows})
by = {s: {tuple(F(x) for x in r['sq']): r['ok'] for r in rows if r['side'] == s} for s in levels}
n = levels[0]
expect = {(F(i, n), F(i + 1, n), F(j, n), F(j + 1, n)) for i in range(n) for j in range(n) if F(i + j, n) <= RM}
ok = True
for k, s in enumerate(levels):
    got = set(by[s])
    if got != expect:
        ok = False
        print('level', s, 'mismatch', len(got ^ expect))
    bad = [q for q, v in by[s].items() if not v]
    expect = set()
    for (a1, a2, b1, b2) in bad:
        am, bm = (a1 + a2) / 2, (b1 + b2) / 2
        for (x1, x2) in ((a1, am), (am, a2)):
            for (y1, y2) in ((b1, bm), (bm, b2)):
                if x1 + y1 <= RM:
                    expect.add((x1, x2, y1, y2))
if expect:
    ok = False
    print('uncertified squares at the last level:', len(expect))


def area_in_T(a1, a2, b1, b2):
    """Exact area of the square intersected with a + b <= 1/5 (the square is axis-parallel, side s)."""
    s = a2 - a1
    lo, hi = a1 + b1, a2 + b2
    if hi <= RM:
        return s * s
    if lo >= RM:
        return F(0)
    t = RM - lo                                   # 0 < t < 2s
    return t * t / 2 if t <= s else s * s - (2 * s - t) ** 2 / 2


area = sum(area_in_T(*q) for s in levels for q, v in by[s].items() if v)
print(dict(levels=[(f'1/{s}', len(by[s]), sum(not v for v in by[s].values())) for s in levels],
           certified=sum(v for s in levels for v in by[s].values()), area_certified_in_T=str(area),
           area_T=str(RM * RM / 2)))
print('COVER OK' if ok and area == RM * RM / 2 else 'COVER FAILED')
