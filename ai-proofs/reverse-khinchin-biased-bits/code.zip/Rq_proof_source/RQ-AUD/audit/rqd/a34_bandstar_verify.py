#!/usr/bin/env python3
"""A.34 (RQ-AUD): own certified check of RQ-D Theorem 13 (ID* band lemma, theta = 17/20, A = 77/50);
RQ-D MAIN_RESULT.tex md5 bba5c599.

Written from the statements of Lemmas 2, 3, 6 (stop-loss bounds), 7 (one jump, with (c)), 8 (F1-F5), Proposition 9,
options (O1)-(O5), Lemma 12 and Section 6.1 of the tex only; RQ-D's scripts are neither used nor read. Primitives re-typed from my own A.32 verifier (a32_band_verify.py),
generalised to theta, A. All decisions are made in arb (128 bits); floats only choose h, options and subdivisions.

Claim certified. For all (a, b, L, m) with a, b >= 0, a + b <= 1/5, V = 1 - a - b and (L, m) satisfying F1-F5:
    F = 2 m e^{-L} + e^{-L} c_B + L e^{-L} O' + P2(L) c_C <= max(g(L), C5),   g(L) = 2 sqrt(L) e^{-L},
with P2(L) = 1 - e^{-L}(1 + L), C5 = g(2 ln 5/4), c_B >= 2E(W - m)_+, c_C >= 2E(-W - (2 theta - m))_+ and
O' >= E phi(J - m), phi(y) = 2E(-W - y)_+, J in [theta, A] with mean mu1 = m/L and variance (L V - m^2)/L^2.

Bounds used (each re-derived in AUDIT.md A.34):
  phi(y) <= chi^C_h(y), phi(y) <= CS(y) = sqrt(y^2 + r^2) - y (r^2 >= rho^2), phi(y) <= -2y + chi^B_h(-y);
  2E(W - t)_+ <= chi^B_h(t), CS(t);  chi^B, chi^C nonincreasing in t, nondecreasing in a and b (Lemma 6);
  W_B = theta (N_{a/theta^2} - a/theta^2) + sqrt(b) G,  W_C = A (N_{b/A^2} - b/A^2) + sqrt(a) G;
  O1 chord (mu1 -> mu_lo after the max replacement), O2 Lemma 7(b), O3/O4 Lemma 7(c) box form, O5 + Lemma 12.

Squares [a1, a2] x [b1, b2] (side 1/128, children down to 1/8192); costs at the corner (abar, bbar), CS terms with
r^2 = min(abar + bbar, 1/5); (L, m) boxes from a 1/64 grid, bisected down to m-width 1/4096, L-width 1/16384.
Direct check: M + e^{-L1} c_B(m1) + TE O' + P2(L2) c_C(2 theta - m2) < T = max(min(g(L1), g(L2)), C5).
Slope check (a2 + b2 <= 1/50, m2 < theta): rho^2-pieces [r1, r2] (bisected up to 6 times), linear bounds valid
for a + b <= r (r >= r2 on the grid 1/8192), F <= sqrt(V) g(L) + rho^2 Mx; tests T1, T2, T3 of Section 6.1.

Usage:
  python3 a34_bandstar_verify.py run [workers] [shift] [side0] [maxside] [norefine]   (shift > 0: controls only)
  python3 a34_bandstar_verify.py square a1 a2 b1 b2 [shift]                            (one square, verbose)
"""
import json
import math
import sys
import time
from fractions import Fraction as F
from multiprocessing import Pool

import numpy as np
from flint import arb, ctx
from scipy.special import ndtr

ctx.prec = 128

TH, AA = F(17, 20), F(77, 50)
RS, RM = F(1, 50), F(1, 5)
GM, GL, GR = 4096, 16384, 8192        # m / y grid, finest L width, grid for r
G0 = 64                               # initial (L, m) grid
NT = 12                               # lattice terms in chi
NS = 11                               # series terms in the linear bounds


def say(*a):
    print(*a)
    sys.stdout.flush()


def ar(x):
    x = F(x)
    return arb(x.numerator) / x.denominator


THa, AAa = ar(TH), ar(AA)
SQ2 = arb(2).sqrt()
INV_SQ2PI = 1 / (2 * arb.pi()).sqrt()
C5 = ar(F(32, 25)) * (2 * ar(F(5, 4)).log()).sqrt()
THf, AAf = 0.85, 1.54
C5f = float(C5.mid())
ISQ2PIf = 1 / math.sqrt(2 * math.pi)
HG = [float(x) for x in 0.004 * 1.12 ** np.arange(60)]
HGa = np.array(HG)
HGF = [F(h) for h in HG]
U_GRID = [0.03, 0.06, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85,
          0.9, 0.95]
H5 = [float(0.04 * 1.07 ** k) for k in range(52)]
LAMS = [k / 20 for k in range(21)]


def up(x):
    return x.upper()


def umax(x, y):
    """An exact number >= both balls (upper endpoints)."""
    ux, uy = x.upper(), y.upper()
    return ux if bool(ux >= uy) else uy


def lower_of(x, y):
    """Of two valid upper bounds, the one with the smaller upper endpoint."""
    return x if bool(x.upper() < y.upper()) else y


# ---------------------------------------------------------------- arb special functions
def Phi(x):
    return (-x / SQ2).erfc() / 2


def Phibar(x):
    return (x / SQ2).erfc() / 2


def phi(x):
    return (-(x * x) / 2).exp() * INV_SQ2PI


def tau(x):
    """E(G - x)_+^2."""
    return (1 + x * x) * Phibar(x) - x * phi(x)


def Q(d, s):
    """E(d + sG)_+^2, s > 0."""
    z = d / s
    return (d * d + s * s) * Phi(z) + d * s * phi(z)


def chi_arb(J, lam, s, t, h):
    """Upper ball for (2h)^-1 E(J (N_lam - lam) + s G - t + h)_+^2 (J, lam, s, t, h arb; lam >= 0, s > 0, h > 0)."""
    c = t - h
    p = (-lam).exp()
    tot = arb(0)
    for n in range(NT + 1):
        tot += p * Q(J * (n - lam) - c, s)
        p = p * lam / (n + 1)
    # tail n >= n1: Q(d, s) <= d^2 + s^2, |d_n| <= J n + C, term ratio <= lam (n + 1)/n^2 <= q
    n1 = NT + 1
    x = J * n1 + J * lam + abs(c)
    u = p * (x * x + s * s)
    q = lam * (n1 + 1) / (n1 * n1)
    assert bool(q < 1)
    return (tot + u / (1 - q)) / (2 * h)


def CS(t, r2):
    return (t * t + r2).sqrt() - t


def g_arb(L):
    L = ar(L)
    return 2 * L.sqrt() * (-L).exp()


def lin_arb(kind, y, h, r):
    """(alpha, beta) with chi^kind_h(y) <= alpha a + beta b for all a, b >= 0, a + b <= r.
    Needs c = y - h > 0 and r <= 2 J (J - c), J = theta (kind B) or A (kind C); checked exactly here."""
    J = TH if kind == 'B' else AA
    c = y - h
    assert c > 0 and r <= 2 * J * (J - c)
    Ja, ca, ra = ar(J), ar(c), ar(r)
    rr = ra / (Ja * Ja)
    S, fact, rp = arb(0), arb(1), arb(1)
    for n in range(1, NS + 1):
        fact = fact * n
        e = Ja * n - ca
        S += rp * (e * e + ra) / fact
        rp = rp * rr
    n1 = NS + 1
    # tail n >= n1: (J n - c)^2 <= J^2 n^2 as 0 < c < J; term ratio <= rr (n + 1)/n^2 <= q
    u = rp * (Ja * Ja * n1 * n1 + ra) / (fact * n1)
    q = rr * (n1 + 1) / (n1 * n1)
    assert bool(q < 1)
    S = (S + u / (1 - q)) / (Ja * Ja)
    tv = tau(ca / ra.sqrt())
    h2 = 2 * ar(h)
    return (S / h2, tv / h2) if kind == 'B' else (tv / h2, S / h2)


# ---------------------------------------------------------------- float mirrors (choices only)
def tau_f(x):
    return (1 + x * x) * 0.5 * math.erfc(x / math.sqrt(2)) - x * math.exp(-0.5 * x * x) * ISQ2PIf


def chi_vec(J, lam, s, y):
    """Float (2h)^-1 E(J (N_lam - lam) + s G - y + h)_+^2 over the grid HG."""
    c = y - HGa
    tot = np.zeros_like(HGa)
    p = math.exp(-lam)
    for n in range(NT + 1):
        d = J * (n - lam) - c
        z = d / s
        tot += p * ((d * d + s * s) * ndtr(z) + d * s * np.exp(-0.5 * z * z) * ISQ2PIf)
        p *= lam / (n + 1)
    return tot / (2 * HGa)


def lin_f(kind, y, h, r):
    J = THf if kind == 'B' else AAf
    c = y - h
    rr = r / (J * J)
    S, fact, rp = 0.0, 1.0, 1.0
    for n in range(1, 8):
        fact *= n
        S += rp * ((J * n - c) ** 2 + r) / fact
        rp *= rr
    S /= J * J
    tv = tau_f(c / math.sqrt(r))
    return (S / (2 * h), tv / (2 * h)) if kind == 'B' else (tv / (2 * h), S / (2 * h))


def g_f(L):
    return 2 * math.sqrt(L) * math.exp(-L)


# ---------------------------------------------------------------- exact box tools
def infeasible(L1, L2, m1, m2, Vlo, Vhi):
    """True only if one of F1-F5 fails at every point of the box, for every V in [Vlo, Vhi] (exact)."""
    if L2 * AA * AA < Vlo or L1 * TH * TH > Vhi:                 # F1  V/A^2 <= L <= V/theta^2
        return True
    if m2 * AA < Vlo or m1 * TH > Vhi:                           # F2  V/A <= m <= V/theta
        return True
    if TH * L1 > m2 or m1 > AA * L2:                             # F3  theta L <= m <= A L
        return True
    if m1 * m1 > L2 * Vhi:                                       # F4  m^2 <= L V
        return True
    if L1 > (1 / AA + 1 / TH) * m2 - Vlo / (AA * TH):            # F5  L <= (1/A + 1/theta) m - V/(A theta)
        return True
    return False


def Mbox(L1, L2, m2, Vhi):
    """max over L in [L1, L2] of 2 e^{-L} min(m2, sqrt(L Vhi)) (increasing up to min(m2^2/Vhi, 1/2), then decreasing)."""
    Lp = min(m2 * m2 / Vhi, F(1, 2))
    Ls = min(max(Lp, L1), L2)
    if Ls * Vhi >= m2 * m2:
        return 2 * ar(m2) * (-ar(Ls)).exp()
    return 2 * (ar(Ls) * ar(Vhi)).sqrt() * (-ar(Ls)).exp()


def Mbox_f(L1, L2, m2, Vhi):
    Lp = min(m2 * m2 / Vhi, 0.5)
    Ls = min(max(Lp, L1), L2)
    if Ls * Vhi >= m2 * m2:
        return 2 * m2 * math.exp(-Ls)
    return 2 * math.sqrt(Ls * Vhi) * math.exp(-Ls)


def floor_grid(x):
    return F(math.floor(x * GM), GM)


def floor_grid_sqrt(x0, s2):
    """Largest k/GM <= x0 + 2 sqrt(s2) (exact; s2 >= 0 rational)."""
    k = math.floor((float(x0) + 2 * math.sqrt(float(s2))) * GM) + 2

    def ok(k):
        z = F(k, GM) - x0
        return z <= 0 or z * z <= 4 * s2
    while not ok(k):
        k -= 1
    while ok(k + 1):
        k += 1
    return F(k, GM)


class Geo:
    """Box quantities of Section 6.1 (exact rationals): mu range, d range, s^2 >= sigma_J^2, w', far points."""
    __slots__ = ('mulo', 'muhi', 'dlo', 'dhi', 's2', 'wp', 'j0p', 'far', 'far5', 'w1')

    def __init__(self, L1, L2, m1, m2, Vhi):
        self.mulo = max(TH, m1 / L2)
        self.muhi = min(AA, m2 / L1)
        self.dlo = self.mulo - TH
        self.dhi = self.muhi - TH
        self.s2 = max(F(0), min((L2 * Vhi - m1 * m1) / (L1 * L1), self.dhi * (AA - self.mulo)))
        self.j0p = TH - m2
        self.w1 = self.dlo / (AA - TH)
        if self.dlo > 0:
            d2 = self.dlo * self.dlo
            self.wp = d2 / (d2 + self.s2)
            if self.s2 <= d2:
                self.far = floor_grid(self.j0p + self.dlo + self.s2 / self.dlo)
            elif self.s2 >= self.dhi * self.dhi:
                self.far = floor_grid(self.j0p + self.dhi + self.s2 / self.dhi)
            else:
                self.far = floor_grid_sqrt(self.j0p, self.s2)
            self.far5 = floor_grid(self.j0p + self.dlo)
        else:
            self.wp = F(0)
            self.far = None
            self.far5 = None


# ---------------------------------------------------------------- one (a, b) square
class Square:
    def __init__(self, a1, a2, b1, b2, shift=F(0)):
        self.a1, self.a2, self.b1, self.b2 = a1, a2, b1, b2
        if a2 + b2 <= RM:
            ab, bb = a2, b2
        else:
            ab, bb = min(a2, RM - b1), min(b2, RM - a1)
        assert ab > 0 and bb > 0
        self.ab, self.bb = ab, bb
        self.r2cs = min(ab + bb, RM)
        self.RC = ar(self.r2cs)
        self.Vlo, self.Vhi = 1 - min(a2 + b2, RM), 1 - (a1 + b1)
        self.slope_ok = a2 + b2 <= RS
        self.shift = F(shift)
        self.shiftf = float(shift)
        A_, B_ = ar(ab), ar(bb)
        self.lamB, self.sB = A_ / (THa * THa), B_.sqrt()
        self.lamC, self.sC = B_ / (AAa * AAa), A_.sqrt()
        abf, bbf = float(ab), float(bb)
        self.lamBf, self.sBf = abf / 0.7225, math.sqrt(bbf)
        self.lamCf, self.sCf = bbf / (1.54 * 1.54), math.sqrt(abf)
        self.rcf = float(self.r2cs)
        self.tabB, self.tabC, self.arbB, self.arbC, self.csA = {}, {}, {}, {}, {}
        self.cache_cost = {}
        self.cache_L = {}
        self.lin_cache, self.linf_cache = {}, {}
        self.stats = dict(boxes=0, infeasible=0, O1=0, O2=0, O3=0, O4=0, slope=0, slope_empty=0, pieces=0)
        self.worst = None

    # ---- chi tables (float over HG) and arb values
    def tB(self, t):
        v = self.tabB.get(t)
        if v is None:
            v = self.tabB[t] = chi_vec(THf, self.lamBf, self.sBf, float(t))
        return v

    def tC(self, y):
        v = self.tabC.get(y)
        if v is None:
            v = self.tabC[y] = chi_vec(AAf, self.lamCf, self.sCf, float(y))
        return v

    def aB(self, t, k):
        key = (t, k)
        v = self.arbB.get(key)
        if v is None:
            v = self.arbB[key] = chi_arb(THa, self.lamB, self.sB, ar(t), ar(HGF[k]))
        return v

    def aC(self, y, k):
        key = (y, k)
        v = self.arbC.get(key)
        if v is None:
            v = self.arbC[key] = chi_arb(AAa, self.lamC, self.sC, ar(y), ar(HGF[k]))
        return v

    def cs(self, y):
        v = self.csA.get(y)
        if v is None:
            v = self.csA[y] = CS(ar(y), self.RC)
        return v

    def csf(self, y):
        y = float(y)
        return math.sqrt(y * y + self.rcf) - y

    # ---- costs of the direct check: (arb, float)
    def cost(self, kind, m):
        key = (kind, m)
        v = self.cache_cost.get(key)
        if v is not None:
            return v
        if kind == 'cB':                 # 2E(W - m)_+ <= min(chi^B_h(m), CS(m))
            t = m
            tb = self.tB(t)
            k = int(np.argmin(tb))
            cands = [(tb[k], lambda: self.aB(t, k)), (self.csf(t), lambda: self.cs(t))]
        elif kind == 'cC':               # 2E(-W - (2 theta - m))_+ <= min(chi^C_h, CS) at y = 2 theta - m
            y = 2 * TH - m
            tc = self.tC(y)
            k = int(np.argmin(tc))
            cands = [(tc[k], lambda: self.aC(y, k)), (self.csf(y), lambda: self.cs(y))]
        elif kind == 'p1':               # phi(theta - m) <= min(chi^C_h(y), CS(y), -2y + chi^B_h(-y))
            y = TH - m
            tc, tb = self.tC(y), self.tB(-y)
            kc, kb = int(np.argmin(tc)), int(np.argmin(tb))
            cands = [(tc[kc], lambda: self.aC(y, kc)), (self.csf(y), lambda: self.cs(y)),
                     (-2 * float(y) + tb[kb], lambda: -2 * ar(y) + self.aB(-y, kb))]
        else:                            # 'p2': phi(A - m) <= min(chi^C_h(y), CS(y))
            y = AA - m
            tc = self.tC(y)
            k = int(np.argmin(tc))
            cands = [(tc[k], lambda: self.aC(y, k)), (self.csf(y), lambda: self.cs(y))]
        cands.sort(key=lambda z: z[0])
        best = None
        for _, fn in cands[:2]:
            x = fn()
            best = x if best is None else lower_of(best, x)
        v = self.cache_cost[key] = (best, float(best.upper()))
        return v

    def Lq(self, L1, L2):
        key = (L1, L2)
        v = self.cache_L.get(key)
        if v is not None:
            return v
        e1 = (-ar(L1)).exp()
        e2 = (-ar(L2)).exp()
        if L2 <= 1:
            TE = ar(L2) * e2
        elif L1 >= 1:
            TE = ar(L1) * e1
        else:
            TE = (-arb(1)).exp()
        P2 = 1 - e2 * (1 + ar(L2))
        g1, g2 = g_arb(L1), g_arb(L2)
        gmin = g1 if bool(g1.lower() <= g2.lower()) else g2
        T = gmin if bool(gmin.lower() >= C5.lower()) else C5
        T = T - ar(self.shift)
        Lc = min(max(F(1, 2), L1), L2)
        ghat = g_arb(Lc)
        f1, f2 = float(L1), float(L2)
        TEf = f2 * math.exp(-f2) if f2 <= 1 else (f1 * math.exp(-f1) if f1 >= 1 else math.exp(-1))
        Tf = max(min(g_f(f1), g_f(f2)), C5f) - self.shiftf
        v = self.cache_L[key] = dict(e1=e1, TE=TE, P2=P2, T=T, gmin=gmin, ghat=ghat, e1f=math.exp(-f1), TEf=TEf,
                                     P2f=1 - math.exp(-f2) * (1 + f2), Tf=Tf, gminf=min(g_f(f1), g_f(f2)),
                                     ghatf=g_f(float(Lc)))
        return v

    # ---- direct check (parts=True: return every arb ingredient instead, for the semantic test)
    def direct(self, L1, L2, m1, m2, parts=False):
        Lq = self.Lq(L1, L2)
        cB, cBf = self.cost('cB', m1)
        cC, cCf = self.cost('cC', m2)
        Mf = Mbox_f(float(L1), float(L2), float(m2), float(self.Vhi))
        base_f = Mf + Lq['e1f'] * cBf + Lq['P2f'] * cCf
        budget = (Lq['Tf'] - base_f) / Lq['TEf']
        if budget <= 0 and not parts:
            return None
        geo = Geo(L1, L2, m1, m2, self.Vhi)
        opts = []
        # (O1) chord with phibar1 -> max(phibar1, phibar2), mu1 -> mu_lo
        p1, p1f = self.cost('p1', m2)
        p2, p2f = self.cost('p2', m2)
        w1 = geo.w1
        w1f = float(w1)
        opts.append(((1 - w1f) * max(p1f, p2f) + w1f * p2f, 'O1',
                     lambda: (1 - ar(w1)) * umax(p1, p2) + ar(w1) * up(p2)))
        wp, wpf = geo.wp, float(geo.wp)
        j0p = geo.j0p
        # (O3) Lemma 7(c) box form with psi = chi^C_h (common h)
        t0 = self.tC(j0p)
        if geo.far is not None and wp > 0:
            t1 = self.tC(geo.far)
            vals = (1 - wpf) * t0 + wpf * t1
            k3 = int(np.argmin(vals))
            far = geo.far
            opts.append((vals[k3], 'O3', lambda: (1 - ar(wp)) * self.aC(j0p, k3) + ar(wp) * self.aC(far, k3)))
        else:
            k3 = int(np.argmin(t0))
            opts.append((t0[k3], 'O3', lambda: self.aC(j0p, k3)))
        # (O4) if theta - m2 >= 0: psi = sqrt(y^2 + r^2) - y
        if j0p >= 0:
            if geo.far is not None and wp > 0:
                far = geo.far
                opts.append(((1 - wpf) * self.csf(j0p) + wpf * self.csf(far), 'O4',
                             lambda: (1 - ar(wp)) * self.cs(j0p) + ar(wp) * self.cs(far)))
            else:
                opts.append((self.csf(j0p), 'O4', lambda: self.cs(j0p)))
        # (O2) Lemma 7(b): -2(mu_lo - m2) + chi^B_h(t) + s^2/(2h), t <= m1 - mu_hi on the grid
        tO2 = floor_grid(m1 - geo.muhi)
        s2, s2f = geo.s2, float(geo.s2)
        vals = self.tB(tO2) + s2f / (2 * HGa)
        k2 = int(np.argmin(vals))
        c2 = -2 * (geo.mulo - m2)
        opts.append((float(c2) + vals[k2], 'O2',
                     lambda: ar(c2) + self.aB(tO2, k2) + ar(s2) / (2 * ar(HGF[k2]))))
        opts.sort(key=lambda z: z[0])
        if parts:
            return dict(M=Mbox(L1, L2, m2, self.Vhi), cB=cB, cC=cC, e1=Lq['e1'], TE=Lq['TE'], P2=Lq['P2'],
                        T=Lq['T'], opts={lab: fn() for _, lab, fn in opts})
        if opts[0][0] >= budget * (1 - 1e-12):
            return None
        M = Mbox(L1, L2, m2, self.Vhi)
        base = M + Lq['e1'] * cB + Lq['P2'] * cC
        T = Lq['T']
        for val, lab, fn in opts:
            if val >= budget:
                break
            tot = base + Lq['TE'] * fn()
            if bool(tot < T):
                return lab, float((T - tot).lower())
        return None

    # ---- linear coefficient candidates (slope check)
    def lin(self, kind, y, h, r):
        key = (kind, y, h, r)
        v = self.lin_cache.get(key)
        if v is None:
            v = self.lin_cache[key] = lin_arb(kind, y, F(h), r)
        return v

    def lin_candidates(self, kind, y, r, hs):
        """Float (alpha, beta, key) of valid linear bounds for chi^kind at y (and CS when y > 0)."""
        key = (kind, y, r)
        v = self.linf_cache.get(key)
        if v is not None:
            return v
        out = []
        if y > 0:
            c = 1 / (2 * float(y))
            out.append((c, c, ('CS', y)))
        J = TH if kind == 'B' else AA
        for h in hs:
            hF = F(h)
            c = y - hF
            if c > 0 and r <= 2 * J * (J - c):
                al, be = lin_f(kind, float(y), h, float(r))
                out.append((al, be, (kind, y, h, r)))
        self.linf_cache[key] = out
        return out

    def lin_value(self, key):
        if key[0] == 'CS':
            c = 1 / (2 * ar(key[1]))
            return c, c
        return self.lin(*key)

    def piece(self, L1, L2, m1, m2, r1, r2, parts=False):
        Vlo, Vhi = 1 - r2, 1 - r1
        if infeasible(L1, L2, m1, m2, Vlo, Vhi):
            return 'empty'
        r = min(F(max(math.ceil(r2 * GR), 1), GR), RS)
        assert r >= r2 and r > 0
        geo = Geo(L1, L2, m1, m2, Vhi)
        Lq = self.Lq(L1, L2)
        mults = (Lq['e1f'], Lq['TEf'], Lq['P2f'])
        j0p = geo.j0p
        y_cC = 2 * TH - m2
        cB_c = self.lin_candidates('B', m1, r, [float(m1) * u for u in U_GRID])
        cC_c = self.lin_candidates('C', y_cC, r, [float(y_cC) * u for u in U_GRID])
        wp, wpf = geo.wp, float(geo.wp)
        oc = []                                           # (alpha, beta, recipe)
        e1c = self.lin_candidates('C', j0p, r, [float(j0p) * u for u in U_GRID])
        e2y = AA - m2
        e2c = self.lin_candidates('C', e2y, r, [float(e2y) * u for u in U_GRID])
        w1f = float(geo.w1)
        seen = set()
        for lam in LAMS:
            i1 = min(range(len(e1c)), key=lambda i: lam * e1c[i][0] + (1 - lam) * e1c[i][1])
            i2 = min(range(len(e2c)), key=lambda i: lam * e2c[i][0] + (1 - lam) * e2c[i][1])
            if (i1, i2) in seen:
                continue
            seen.add((i1, i2))
            u1, u2 = e1c[i1], e2c[i2]
            al = (1 - w1f) * max(u1[0], u2[0]) + w1f * u2[0]
            be = (1 - w1f) * max(u1[1], u2[1]) + w1f * u2[1]
            oc.append((al, be, ('O1', u1[2], u2[2])))
        if geo.far is not None and geo.far > 0:
            far = geo.far
            fc = {c[2][2]: c for c in self.lin_candidates('C', far, r, [float(j0p) * u for u in U_GRID])
                  if c[2][0] == 'C'}
            for c0 in e1c:
                if c0[2][0] != 'C' or c0[2][2] not in fc:
                    continue
                c1 = fc[c0[2][2]]
                oc.append(((1 - wpf) * c0[0] + wpf * c1[0], (1 - wpf) * c0[1] + wpf * c1[1],
                           ('O3', c0[2], c1[2])))
            v = (1 - wpf) / (2 * float(j0p)) + wpf / (2 * float(far))
            oc.append((v, v, ('O4', j0p, far)))
            if geo.far5 is not None and geo.far5 > 0:
                f5 = geo.far5
                bound = geo.dlo ** 4 * L1
                for c1 in self.lin_candidates('C', f5, r, H5):
                    if c1[2][0] != 'C':
                        continue
                    hF = F(c1[2][2])
                    e = hF - j0p
                    kap = e * e / (2 * hF) if e > 0 else F(0)
                    if kap * kap * (1 - r1) > bound:
                        continue
                    extra = (1 - wpf) / (2 * c1[2][2])
                    oc.append((c1[0] + extra, c1[1] + extra, ('O5', c1[2], kap)))
        best = None
        for lam in LAMS:
            picks = []
            for cl in (cB_c, oc, cC_c):
                picks.append(min(cl, key=lambda z: lam * z[0] + (1 - lam) * z[1]))
            Af = sum(mults[j] * picks[j][0] for j in range(3))
            Bf = sum(mults[j] * picks[j][1] for j in range(3))
            wv = max(Af, Bf)
            if best is None or wv < best[0]:
                best = (wv, picks)
        picks = best[1]
        # arb coefficients of the chosen combination
        aB_, bB_ = self.lin_value(picks[0][2])
        aC_, bC_ = self.lin_value(picks[2][2])
        rec = picks[1][2]
        kap = None
        if rec[0] == 'O1':
            u1, u2 = self.lin_value(rec[1]), self.lin_value(rec[2])
            w1 = ar(geo.w1)
            aO = (1 - w1) * umax(u1[0], u2[0]) + w1 * up(u2[0])
            bO = (1 - w1) * umax(u1[1], u2[1]) + w1 * up(u2[1])
        elif rec[0] == 'O3':
            u1, u2 = self.lin_value(rec[1]), self.lin_value(rec[2])
            W = ar(wp)
            aO = (1 - W) * u1[0] + W * u2[0]
            bO = (1 - W) * u1[1] + W * u2[1]
        elif rec[0] == 'O4':
            aO = bO = (1 - ar(wp)) / (2 * ar(rec[1])) + ar(wp) / (2 * ar(rec[2]))
        else:
            u1 = self.lin_value(rec[1])
            kap = rec[2]
            extra = (1 - ar(wp)) / (2 * ar(F(rec[1][2])))
            aO, bO = u1[0] + extra, u1[1] + extra
        Aco = Lq['e1'] * aB_ + Lq['TE'] * aO + Lq['P2'] * aC_
        Bco = Lq['e1'] * bB_ + Lq['TE'] * bO + Lq['P2'] * bC_
        Mx = umax(Aco, Bco)
        T = Lq['T']
        if parts:
            return dict(terms=((aB_, bB_), (aO, bO), (aC_, bC_)), Aco=Aco, Bco=Bco, Mx=Mx, rec=rec[0], kap=kap,
                        h5=float(rec[1][2]) if rec[0] == 'O5' else None, gmin=Lq['gmin'], ghat=Lq['ghat'], T=T)
        if self.shift == 0 and bool(Mx < Lq['gmin'] / 2):
            return 'T1'
        X = Mx - Lq['ghat'] / 2
        if bool(Lq['ghat'] + ar(r1) * X < T) and bool(Lq['ghat'] + ar(r2) * X < T):
            return 'T2'
        if kap is None:
            M0 = Mbox(L1, L2, m2, Vhi)
        else:
            M = Mbox(L1, L2, m2, Vhi)
            alt = (-ar(L1)).exp() * (2 * ar(m2) + ar(kap * max(F(0), L2 * Vhi - m2 * m2) / (L1 * geo.dlo ** 2)))
            M0 = M if bool(M.lower() >= alt.upper()) else umax(M, alt)
        if bool(M0 + ar(r2) * Mx < T):
            return 'T3'
        return None

    def slope(self, L1, L2, m1, m2):
        r0 = self.a1 + self.b1
        rB = min(self.a2 + self.b2, 1 - m1 * m1 / L2)
        if rB < r0:
            return 'empty'
        stack = [(r0, rB, 0)]
        while stack:
            r1, r2, d = stack.pop()
            self.stats['pieces'] += 1
            if self.piece(L1, L2, m1, m2, r1, r2) is not None:
                continue
            if d >= 6:
                return None
            rm = (r1 + r2) / 2
            stack += [(r1, rm, d + 1), (rm, r2, d + 1)]
        return 'slope'

    # ---- all (L, m) boxes of the square
    def run(self, maxboxes=10 ** 8):
        t0 = time.time()
        Vlo, Vhi = self.Vlo, self.Vhi
        Lb = F(math.floor(Vlo / (AA * AA) * G0), G0)
        Lt = F(math.ceil(Vhi / (TH * TH) * G0), G0)
        mb = F(math.floor(Vlo / AA * G0), G0)
        mt = F(math.ceil(Vhi / TH * G0), G0)
        stack = []
        Lk = Lb
        while Lk < Lt:
            mk = mb
            while mk < mt:
                stack.append((Lk, Lk + F(1, G0), mk, mk + F(1, G0), 0))
                mk += F(1, G0)
            Lk += F(1, G0)
        st = self.stats
        while stack:
            L1, L2, m1, m2, d = stack.pop()
            st['boxes'] += 1
            if st['boxes'] > maxboxes:
                return self.result(False, t0, fail=('maxboxes',))
            if infeasible(L1, L2, m1, m2, Vlo, Vhi):
                st['infeasible'] += 1
                continue
            res = self.direct(L1, L2, m1, m2)
            if res is not None:
                st[res[0]] += 1
                if self.worst is None or res[1] < self.worst[0]:
                    self.worst = (res[1], str(L1), str(L2), str(m1), str(m2))
                continue
            if self.slope_ok and m2 < TH and (m2 - m1) * 256 <= 1:
                sres = self.slope(L1, L2, m1, m2)
                if sres is not None:
                    st['slope' if sres == 'slope' else 'slope_empty'] += 1
                    continue
            wm, wl = m2 - m1, L2 - L1
            if wm * GM > 1 and (d % 2 == 0 or wl * GL <= 1):
                mm = (m1 + m2) / 2
                stack += [(L1, L2, m1, mm, d + 1), (L1, L2, mm, m2, d + 1)]
            elif wl * GL > 1:
                Lm = (L1 + L2) / 2
                stack += [(L1, Lm, m1, m2, d + 1), (Lm, L2, m1, m2, d + 1)]
            else:
                return self.result(False, t0, fail=(float(L1), float(L2), float(m1), float(m2)))
        return self.result(True, t0)

    def result(self, ok, t0, fail=None):
        out = dict(sq=[str(self.a1), str(self.a2), str(self.b1), str(self.b2)], ok=ok, **self.stats,
                   worst=self.worst, seconds=round(time.time() - t0, 2))
        if fail is not None:
            out['fail'] = fail
        return out


def square_job(args):
    a1, a2, b1, b2, shift = args
    return Square(a1, a2, b1, b2, shift).run()


def meets(x1, y1):
    return x1 + y1 <= RM


def run_all(workers=8, shift=F(0), side0=128, maxside=8192, refine=True, outpath=None):
    t0 = time.time()
    n = side0
    sq = [(F(i, n), F(i + 1, n), F(j, n), F(j + 1, n)) for i in range(n) for j in range(n)
          if meets(F(i, n), F(j, n))]
    levels, total, uncert = [], dict(), []
    fo = open(outpath, 'w') if outpath else None
    worst = None
    with Pool(workers) as pool:
        side = side0
        while sq:
            res = pool.map(square_job, [(a1, a2, b1, b2, shift) for (a1, a2, b1, b2) in sq], chunksize=1)
            bad = [r for r in res if not r['ok']]
            for r in res:
                if fo:
                    fo.write(json.dumps(dict(side=side, **r)) + '\n')
                if r['ok']:
                    for k in ('boxes', 'infeasible', 'O1', 'O2', 'O3', 'O4', 'slope', 'slope_empty', 'pieces'):
                        total[k] = total.get(k, 0) + r[k]
                    if r['worst'] is not None and (worst is None or r['worst'][0] < worst[0]):
                        worst = tuple(r['worst']) + tuple(r['sq'])
            if fo:
                fo.flush()
            lv = dict(side=f'1/{side}', squares=len(res), not_certified=len(bad),
                      boxes=sum(r['boxes'] for r in res), cpu_s=round(sum(r['seconds'] for r in res), 1),
                      wall_s=round(time.time() - t0, 1))
            if bad:
                lv['bad_example'] = dict(sq=bad[0]['sq'], fail=bad[0].get('fail'))
            levels.append(lv)
            say(json.dumps(lv))
            if not bad or not refine or side * 2 > maxside:
                uncert = [r['sq'] for r in bad]
                break
            side *= 2
            nsq = []
            for r in bad:
                a1, a2, b1, b2 = (F(x) for x in r['sq'])
                am, bm = (a1 + a2) / 2, (b1 + b2) / 2
                for (x1, x2) in ((a1, am), (am, a2)):
                    for (y1, y2) in ((b1, bm), (bm, b2)):
                        if meets(x1, y1):
                            nsq.append((x1, x2, y1, y2))
            sq = nsq
    if fo:
        fo.close()
    return dict(shift=str(shift), levels=levels, certified_leaf_totals=total,
                certified_squares=sum(lv['squares'] - lv['not_certified'] for lv in levels),
                uncertified=uncert, worst_direct_margin=worst, seconds=round(time.time() - t0, 1))


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'run'
    if mode == 'run':
        workers = int(sys.argv[2]) if len(sys.argv) > 2 else 8
        shift = F(sys.argv[3]) if len(sys.argv) > 3 else F(0)
        side0 = int(sys.argv[4]) if len(sys.argv) > 4 else 128
        maxside = int(sys.argv[5]) if len(sys.argv) > 5 else 8192
        refine = not (len(sys.argv) > 6 and sys.argv[6] == 'norefine')
        outpath = f'outputs/a34_squares_shift{str(shift).replace("/", "_")}.jsonl'
        say(json.dumps(dict(start=time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime()), workers=workers,
                            shift=str(shift), side0=side0, maxside=maxside, refine=refine, prec=ctx.prec)))
        say(json.dumps(run_all(workers, shift, side0, maxside, refine, outpath)))
    elif mode == 'square':
        a1, a2, b1, b2 = (F(x) for x in sys.argv[2:6])
        shift = F(sys.argv[6]) if len(sys.argv) > 6 else F(0)
        say(json.dumps(Square(a1, a2, b1, b2, shift).run()))


if __name__ == '__main__':
    main()
