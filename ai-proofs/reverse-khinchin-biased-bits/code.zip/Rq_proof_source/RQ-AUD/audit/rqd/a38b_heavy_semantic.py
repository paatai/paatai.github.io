#!/usr/bin/env python3
"""A.38b (RQ-AUD): end-to-end semantic test of Theorem 16's chain on random heavy K (evidence, not proof).

For random probability K on [-A, A] with 1/2 <= K([tau, A]) < 4/5 (atoms, optional Gaussian part):
  1. exact E|Z_K| (Poisson enumeration, a34b_semantic.law / E_abs);
  2. chord rates (a+, b+) (Lemma 18), the leaf box B of the data containing them; B must not be recorded empty;
  3. W = W1 + Gaussian padding (Lemma 20): padding >= 0, W({A}) <= cap_B, (kappa3, kappa4)(W) in R_B, its cell C; the
     certificate of C must not be an emptiness certificate;
  4. Lemma 18(ii)/20: E|Z_K| <= E h_B(Z_W) = E|Z_{K+# + W0} + sigma G| (exact);
  5. ranges: L_j <= kappa_j(W) <= U_j (j = 3..16), with my verifier's proved ranges for C;
  6. E phi(Z_W) = sum c_k P_k(kappa(W)) (exact rationals) <= beta (my verifier's bound for C);
  7. E h_B(Z_W) <= E phi(Z_W) + eps, and E|Z_K| <= beta + eps < C5.
Modes: random (V+ in [1/2, 4/5), band atoms anywhere), edge (V+ in [1/2, 0.62], band atoms in [1.38, 1.54]: the
region of the tightest certified bounds), kstar (perturbations of the far-region maximiser K*, V+ just below 4/5).
Usage: python3 a38b_heavy_semantic.py N SEED [NPROC] [MODE]
"""
import glob
import json
import math
import os
import sys
from multiprocessing import Pool

import numpy as np
from flint import arb, fmpq

import a38_heavy_verify as V
import a34b_semantic as S

TAUf, Af = 0.85, 1.54
DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'heavy_2230', 'plus_cert')
RECS = {}


def load():
    for f in sorted(glob.glob(os.path.join(DATA, 'certs_v1_r*.jsonl'))):
        for l in open(f):
            r = json.loads(l)
            RECS[tuple(r['box'])] = r


def find_box(a, b):
    for (ea, ia, eb, ib), r in RECS.items():
        a1, a2, b1, b2 = V.box_of([ea, ia, eb, ib])
        if a1 <= a <= a2 and b1 <= b <= b2:
            return r, (a1, a2, b1, b2)
    return None, None


MODE = 'random'


def random_K(rng):
    if MODE == 'kstar':
        Vp = 0.8 * (1 - rng.uniform(1e-6, 0.02))
        x1 = 1.29781 + rng.normal(0, 0.03)
        x2 = -1.10077 + rng.normal(0, 0.03)
        x3 = 0.85 - abs(rng.normal(0, 0.02)) - 1e-9
        w2 = (1 - Vp) * rng.uniform(0.4, 0.5)
        return [(float(min(max(x1, TAUf), Af)), float(Vp))], [(float(max(x2, -Af)), float(w2)),
                                                                  (float(x3), float(1 - Vp - w2))], 0.0
    Vp = rng.uniform(0.5, 0.8) if MODE == 'random' else rng.uniform(0.5, 0.62)
    n1 = rng.integers(1, 3)
    xp = rng.uniform(TAUf, Af, n1) if MODE == 'random' else rng.uniform(1.38, Af, n1)
    wp = rng.dirichlet(np.ones(n1)) * Vp
    rest = 1 - Vp
    n2 = rng.integers(1, 4)
    g = rest * rng.uniform(0, 0.5) if rng.random() < 0.4 else 0.0
    xr = np.where(rng.random(n2) < 0.5, rng.uniform(-Af, -0.4, n2), rng.uniform(0.4, TAUf - 1e-6, n2))
    wr = rng.dirichlet(np.ones(n2)) * (rest - g)
    return [(float(x), float(w)) for x, w in zip(xp, wp)], [(float(x), float(w)) for x, w in zip(xr, wr)], g


def one(args):
    seed, k = args
    rng = np.random.default_rng(seed * 1000003 + k)
    plus, rest, g = random_K(rng)
    out = {'k': k}
    vals, probs = S.law(plus + rest)
    EK = S.E_abs(vals, probs, math.sqrt(g))
    nu = [(x, w / (x * x)) for x, w in plus]
    ap = sum(r * (Af - x) / (Af - TAUf) for x, r in nu)
    bp = sum(r * (x - TAUf) / (Af - TAUf) for x, r in nu)
    rec, box = find_box(V.fq(ap), V.fq(bp))
    if rec is None:
        return out | {'fail': 'no box'}
    if rec['status'] == 'empty':
        return out | {'fail': 'box recorded empty', 'box': rec['box']}
    a1, a2, b1, b2 = box
    mu, cap, R3, R4 = V.box_params(a1, a2, b1, b2)
    a1f, b1f, muf, capf = float(a1), float(b1), float(mu), float(cap)
    W1 = rest + [(TAUf, (ap - a1f) * TAUf ** 2), (Af, (bp - b1f) * Af ** 2)]
    W1mass = sum(w for _, w in W1) + g
    pad = muf - W1mass
    if pad < -1e-12:
        return out | {'fail': 'padding < 0', 'pad': pad}
    if (bp - b1f) * Af ** 2 > capf + 1e-12:
        return out | {'fail': 'W({A}) > cap'}
    k3 = sum(x * w for x, w in W1)
    k4 = sum(x * x * w for x, w in W1)
    cell = None
    for ct in rec['certs']:
        c3, c4 = V.cell_of(ct['cell'], R3, R4)
        if float(c3[0]) <= k3 <= float(c3[1]) and float(c4[0]) <= k4 <= float(c4[1]):
            cell = ct
            break
    if cell is None:
        return out | {'fail': 'no cell', 'k34': (k3, k4)}
    if cell['status'] != 'ok':
        return out | {'fail': 'cell certified empty but W is in it', 'cell': cell['cell']}
    # 4. E h_B(Z_W) = E|Z_{K+# + W0} + sigma G|, sigma^2 = pad + g
    sharp = [(TAUf, ap * TAUf ** 2), (Af, bp * Af ** 2)]
    v2, p2 = S.law([a for a in sharp if a[1] > 0] + rest)
    EhB = S.E_abs(v2, p2, math.sqrt(max(pad, 0.0) + g))
    st = {'sup': 0, 'pieces': 0}
    c3, c4 = V.cell_of(cell['cell'], R3, R4)
    rg = V.ranges(cell['rmult'], mu, cap, c3, c4, st)
    beta = V.lagrangian_beta(cell, mu, cap, c3, c4, rg, st)
    eps, why = V.majorant_eps(cell, a1, b1, st)
    # 5./6. exact cumulants of W (W1 + Gaussian at 0 of mass pad + g), E phi(Z_W)
    Wq = [(V.fq(x), V.fq(w)) for x, w in W1 if w > 0]
    kap = {j: sum((w * x ** (j - 2) for x, w in Wq), fmpq(0)) for j in range(3, 17)}
    rng_ok = all(rg[j][0] <= kap[j] <= rg[j][1] for j in range(3, 17))
    c = [V.fq(x) for x in cell['coef']]
    E = V.expand_Ephi(c, mu)
    Ephi = fmpq(0)
    for al, v in E.items():
        t = v
        for i in al:
            t *= kap[i]
        Ephi += t
    res = {'EK': EK, 'EhB': EhB, 'Ephi': float(Ephi), 'beta': float(beta), 'eps': float(eps) if eps else None,
           'V+': sum(w for _, w in plus), 'box': rec['box'], 'cell': cell['cell'], 'mu_exact': True}
    fails = []
    if not EK <= EhB + 1e-12:
        fails.append('E|Z_K| > E h_B(Z_W)')
    if not rng_ok:
        fails.append('kappa out of range')
    if not Ephi <= beta:
        fails.append('E phi > beta')
    if eps is None or not EhB <= float(Ephi + eps) + 1e-12:
        fails.append('E h_B > E phi + eps')
    if not (EK <= float(beta + eps) and arb(beta + eps) < V.C5):
        fails.append('final')
    return out | res | ({'fail': '; '.join(fails)} if fails else {})


def init(mode):
    global MODE
    MODE = mode
    load()


def main():
    n, seed = int(sys.argv[1]), int(sys.argv[2])
    nproc = int(sys.argv[3]) if len(sys.argv) > 3 else 8
    mode = sys.argv[4] if len(sys.argv) > 4 else 'random'
    with Pool(nproc, initializer=init, initargs=(mode,)) as pool:
        res = pool.map(one, [(seed, k) for k in range(n)], chunksize=1)
    bad = [r for r in res if 'fail' in r]
    good = [r for r in res if 'fail' not in r]
    print(f'a38b (RQ-AUD): {n} heavy K, mode {mode} (seed {seed}); {len(good)} pass all links, {len(bad)} fail')
    for r in bad[:10]:
        print('FAIL', r)
    if good:
        g1 = min(r['EhB'] - r['EK'] for r in good)
        g2 = min(r['beta'] - r['Ephi'] for r in good)
        g3 = min(r['Ephi'] + r['eps'] - r['EhB'] for r in good)
        g4 = min(r['beta'] + r['eps'] - r['EK'] for r in good)
        print(f'smallest gaps: E h_B - E|Z_K| = {g1:.3e}; beta - E phi = {g2:.3e}; E phi + eps - E h_B = {g3:.3e}; '
              f'(beta + eps) - E|Z_K| = {g4:.4f}')
        mx = max(good, key=lambda r: r['EK'])
        print(f"largest E|Z_K| sampled: {mx['EK']:.6f} (V+ {mx['V+']:.3f}, box {mx['box']}, cell {mx['cell']}, "
              f"beta + eps {mx['beta'] + mx['eps']:.6f})")
    print('ALL PASS' if not bad else 'FAILURES')


if __name__ == '__main__':
    main()
