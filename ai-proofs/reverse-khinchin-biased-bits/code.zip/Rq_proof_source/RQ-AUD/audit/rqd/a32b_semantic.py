#!/usr/bin/env python3
"""A.32 semantic and lemma-breaking tests for RQ-D Theorem 10 (own code; float64 lattice computations, evidence only).

K = sum_j w_j delta_{x_j} with atoms on the lattice (1/D) Z (D = 400), x = 0 allowed (Gaussian part). Laws of the
compound Poisson parts are computed on the lattice by FFT-free direct convolution of truncated Poisson pmfs (tail mass
< 1e-15), Gaussian parts in closed form. Tests:
  T1  E|Z_K| <= sqrt(2/e) for random band K (K([1, sqrt2]) >= 9/10, K carried by [-sqrt2, sqrt2]);
  T2  the decomposition E|Z_K| = sum_n P(N_S = n) E l(S_n - m) (Lemma 2 + Lemma 3), and the identity of Lemma 3;
  T3  each cost bound at the exact (a, b): c_B >= 2E(W - m)_+, chord >= 2E(-W - (J - m))_+, c_C >= 2E(-W - (2 - m))_+,
      Lemma 6 (i) for random h, Lemma 6 (ii), and F >= E|Z_K|, F < sqrt(2/e);
  T4  Lemma 4 (comparison) for random K, T(x) >= x and psi in {psi_{t,h}, exp(k w)}; and the reverse direction for
      psi = (t - w)_+^2 (psi'' nonincreasing), which must fail somewhere (control);
  T5  hostile search: maximise E|Z_K| over band K (Nelder-Mead, restarts) and maximise E|Z_K| - F.
Usage: PYTHONPATH=. python3 a32b_semantic.py [n_random] [restarts]
"""
import math
import random
import sys

import numpy as np
from scipy.optimize import minimize
from scipy.special import expit, ndtr

import a32_band_verify as V

D = 400
TF = math.sqrt(2 / math.e)
SQ2 = math.sqrt(2)
FAILS = []


def say(*a):
    print(*a)
    sys.stdout.flush()


def check(ok, msg):
    if not ok:
        FAILS.append(msg)
        say('FAIL ' + msg)
    return ok


def pois_f(lam, k):
    return math.exp(-lam) * lam ** k / math.factorial(k)


def pois(lam, tol=1e-16):
    n = max(10, int(lam + 12 * math.sqrt(lam + 1) + 20))
    p = np.empty(n + 1)
    p[0] = math.exp(-lam)
    for k in range(1, n + 1):
        p[k] = p[k - 1] * lam / k
    return p


class Lat:
    """Law of sum_j x_j N_j on the lattice Z/D: (offset, pmf array)."""

    def __init__(self):
        self.off, self.p = 0, np.array([1.0])

    def add(self, x, lam):
        k = int(round(x * D))
        assert abs(k - x * D) < 1e-9, 'atoms must lie on the lattice'
        if k == 0 or lam == 0:
            return
        q = pois(lam)
        nq, n, kk = len(q), len(self.p), abs(k)
        out = np.zeros(n + kk * (nq - 1))
        for j in range(nq):
            s0 = j * kk if k > 0 else (nq - 1 - j) * kk
            out[s0:s0 + n] += q[j] * self.p
        if k < 0:
            self.off -= kk * (nq - 1)
        keep = out > 1e-300
        i0, i1 = int(np.argmax(keep)), len(keep) - int(np.argmax(keep[::-1]))
        self.off += i0
        self.p = out[i0:i1]

    def values(self):
        return (self.off + np.arange(len(self.p))) / D


def law(atoms):
    """atoms [(x, w)]; returns (values of sum x_j N_j, pmf, compensator, sigma)."""
    L = Lat()
    comp, sig2 = 0.0, 0.0
    for x, w in atoms:
        if abs(x) < 1e-12:
            sig2 += w
            continue
        lam = w / (x * x)
        L.add(x, lam)
        comp += x * lam
    return L.values(), L.p, comp, math.sqrt(sig2)


def e_abs(c, s):
    """E|c + sG| elementwise."""
    if s == 0:
        return np.abs(c)
    z = c / s
    return c * (2 * ndtr(z) - 1) + 2 * s * np.exp(-0.5 * z * z) / math.sqrt(2 * math.pi)


def e_plus(c, s):
    """E(c + sG)_+ elementwise."""
    if s == 0:
        return np.maximum(c, 0)
    z = c / s
    return c * ndtr(z) + s * np.exp(-0.5 * z * z) / math.sqrt(2 * math.pi)


def e_plus2(c, s):
    if s == 0:
        return np.maximum(c, 0) ** 2
    z = c / s
    return (c * c + s * s) * ndtr(z) + c * s * np.exp(-0.5 * z * z) / math.sqrt(2 * math.pi)


def EabsZ(atoms):
    v, p, comp, s = law(atoms)
    return float(np.dot(p, e_abs(v - comp, s)))


def rand_band(rng, rho2_max=0.1, nbig=None, nres=None, rho2=None):
    nbig = nbig or rng.randint(1, 3)
    nres = nres if nres is not None else rng.randint(1, 3)
    rho2 = rho2 if rho2 is not None else rng.uniform(0.0005, rho2_max)
    xb = [rng.randint(D, int(SQ2 * D)) / D for _ in range(nbig)]
    wb = np.random.default_rng(rng.randint(0, 10 ** 9)).dirichlet(np.ones(nbig)) * (1 - rho2)
    xr = []
    for _ in range(nres):
        u = rng.random()
        if u < 0.2:
            xr.append(0.0)
        elif u < 0.6:
            xr.append(rng.randint(int(0.25 * D), D - 1) / D)
        else:
            xr.append(-rng.randint(int(0.25 * D), int(SQ2 * D)) / D)
    wr = np.random.default_rng(rng.randint(0, 10 ** 9)).dirichlet(np.ones(nres)) * rho2
    return [(x, float(w)) for x, w in zip(xb, wb)], [(x, float(w)) for x, w in zip(xr, wr)]


def pieces(big, res):
    Lam = sum(w / x ** 2 for x, w in big)
    m = sum(w / x for x, w in big)
    Vv = sum(w for _, w in big)
    a = sum(w for x, w in res if x > 0)
    b = sum(w for x, w in res if x <= 0)
    return Lam, m, Vv, a, b


def costs_exact(big, res):
    """2E(W - m)_+, 2E[(-W - (J - m))_+] with J ~ nu_S/Lam, 2E(-W - (2 - m))_+ and the endpoint values phi(1 - m),
    phi(sqrt2 - m) of phi(y) = 2E(-W - y)_+."""
    Lam, m, Vv, a, b = pieces(big, res)
    v, p, comp, s = law(res)
    Wv = v - comp
    cb = 2 * float(np.dot(p, e_plus(Wv - m, s)))
    phi = lambda y: 2 * float(np.dot(p, e_plus(-Wv - y, s)))
    oj = sum((w / x ** 2) / Lam * phi(x - m) for x, w in big)
    return cb, oj, phi(2 - m), phi(1 - m), phi(SQ2 - m), (Wv, p, s)


def chi_s(J, lam, s, t, h):
    """(2h)^-1 E(J (N_lam - lam) + s G - t + h)_+^2 in floats, s >= 0 (s = 0: pure Poisson)."""
    c = t - h
    tot, p = 0.0, math.exp(-lam)
    for n in range(40):
        d = J * (n - lam) - c
        tot += p * (V.Q_f(d, s) if s > 0 else max(d, 0.0) ** 2)
        p *= lam / (n + 1)
    return tot / (2 * h)


def best_h_s(J, lam, s, t, lo=1e-3, hi=3.0, it=40):
    a, b = math.log(lo), math.log(hi)
    gr = (math.sqrt(5) - 1) / 2
    f = lambda x: chi_s(J, lam, s, t, math.exp(x))
    x1, x2 = b - gr * (b - a), a + gr * (b - a)
    f1, f2 = f(x1), f(x2)
    for _ in range(it):
        if f1 < f2:
            b, x2, f2 = x2, x1, f1
            x1 = b - gr * (b - a)
            f1 = f(x1)
        else:
            a, x1, f1 = x1, x2, f2
            x2 = a + gr * (b - a)
            f2 = f(x2)
    return math.exp((a + b) / 2)


def F_and_parts(big, res):
    Lam, m, Vv, a, b = pieces(big, res)
    rho2 = a + b
    cs = lambda t: math.sqrt(t * t + rho2) - t
    sb, sa = math.sqrt(b), math.sqrt(a)
    cB = min(chi_s(1.0, a, sb, m, best_h_s(1.0, a, sb, m)), cs(m))

    def cC(t):
        return min(chi_s(SQ2, b / 2, sa, t, best_h_s(SQ2, b / 2, sa, t)), cs(t))
    mu = m / Lam
    w1 = (mu - 1) / (SQ2 - 1)
    U0, U1, c2 = cC(1 - m), cC(SQ2 - m), cC(2 - m)
    chord = (1 - w1) * U0 + w1 * U1
    P2 = 1 - math.exp(-Lam) * (1 + Lam)
    Fv = 2 * m * math.exp(-Lam) + math.exp(-Lam) * cB + Lam * math.exp(-Lam) * chord + P2 * c2
    return Fv, dict(cB=cB, U0=U0, U1=U1, cC=c2, chord=chord, Lam=Lam, m=m, mu=mu, a=a, b=b)


def decomposition(big, res):
    """sum_n P(N_S = n) E l(S_n - m), l(y) = E|y + W|, by direct lattice convolution of Y and W separately."""
    vY, pY, compY, _ = law(big)
    vW, pW, compW, s = law(res)
    tot = 0.0
    for y, py in zip(vY - compY, pY):
        if py < 1e-18:
            continue
        tot += py * float(np.dot(pW, e_abs(y + vW - compW, s)))
    return tot


def T1_T3(rng, n):
    worstT, worstF, worst_gap = 1.0, 1.0, 1.0
    for it in range(n):
        big, res = rand_band(rng, nres=rng.randint(1, 3))
        K = big + res
        Lam, m, Vv, a, b = pieces(big, res)
        E = EabsZ(K)
        worstT = min(worstT, TF - E)
        check(E <= TF, f'T1 E|Z_K| = {E} > T for {K}')
        Fv, parts = F_and_parts(big, res)
        cb, oj, c2, ph0, ph1, (Wv, p, s) = costs_exact(big, res)
        tol = 1e-11
        check(parts['cB'] >= cb - tol, f'T3 c_B {parts["cB"]} < 2E(W-m)+ {cb} for {K}')
        check(parts['chord'] >= oj - tol, f'T3 chord {parts["chord"]} < 2E(-W-(J-m))+ {oj} for {K}')
        check(parts['cC'] >= c2 - tol, f'T3 c_C {parts["cC"]} < {c2} for {K}')
        check(parts['U0'] >= ph0 - tol and parts['U1'] >= ph1 - tol, f'T3 endpoint values for {K}')
        check(Fv >= E - tol, f'T3 F = {Fv} < E|Z_K| = {E} for {K}')
        check(Fv < TF, f'T3 F = {Fv} >= T for {K}')
        worstF = min(worstF, TF - Fv)
        worst_gap = min(worst_gap, Fv - E)
        # Lemma 6 (i) at random h and t; (ii)
        for _ in range(3):
            t, h = rng.uniform(-0.5, 2.0), rng.uniform(0.01, 1.5)
            lhsB = 2 * float(np.dot(p, e_plus(Wv - t, s)))
            lhsC = 2 * float(np.dot(p, e_plus(-Wv - t, s)))
            rB = chi_s(1.0, a, math.sqrt(b), t, h)
            rC = chi_s(SQ2, b / 2, math.sqrt(a), t, h)
            check(lhsB <= rB + tol, f'T3 Lemma 6(i) B t={t} h={h}: {lhsB} > {rB} for {res}')
            check(lhsC <= rC + tol, f'T3 Lemma 6(i) C t={t} h={h}: {lhsC} > {rC} for {res}')
            cs = math.sqrt(t * t + a + b) - t
            check(lhsB <= cs + tol and lhsC <= cs + tol, f'T3 Lemma 6(ii) t={t} for {res}')
        if it < 60:
            dec = decomposition(big, res)
            check(abs(dec - E) < 1e-11, f'T2 decomposition {dec} vs {E}')
            # Lemma 3 identity: E|Z| = 2 m e^-L + 2 e^-L E(W - m)_+ + 2 E[(-W - Y)_+; N_S >= 1]
            vY, pY, compY, _ = law(big)
            Y = vY - compY
            flip = 0.0
            assert abs(vY[0]) < 1e-12 and abs(Y[0] + m) < 1e-12
            for sv, y, py in zip(vY, Y, pY):       # N_S >= 1 <=> S >= 1 (lattice points in (0, 1) have mass 0)
                if sv > 0.5:
                    flip += py * float(np.dot(p, e_plus(-Wv - y, s)))
                else:
                    check(sv < 1e-12 or py == 0.0, 'T2 lattice mass inside (0, 1)')
            rhs = 2 * m * math.exp(-Lam) + math.exp(-Lam) * cb + 2 * flip
            check(abs(rhs - E) < 1e-11, f'T2 Lemma 3 identity {rhs} vs {E}')
    say(f'T1-T3: {n} random band K: min(T - E|Z_K|) = {worstT:.3e}, min(T - F) = {worstF:.3e}, '
        f'min(F - E|Z_K|) = {worst_gap:.3e}')


def Epsi(atoms, kind, t=0.0, h=1.0, k=1.0):
    v, p, comp, s = law(atoms)
    c = v - comp
    if kind == 'psi':
        return float(np.dot(p, e_plus2(c - t + h, s))) / (4 * h)
    if kind == 'rev':
        return float(np.dot(p, e_plus2(t - c, s)))
    if kind == 'exp':
        return math.exp(sum((math.exp(k * x) - 1 - k * x) / x ** 2 * w if abs(x) > 1e-12 else k * k * w / 2
                            for x, w in atoms))


def T4(rng, n):
    worst = 1.0
    rev_fail = 0
    for it in range(n):
        na = rng.randint(1, 3)
        atoms = []
        for _ in range(na):
            u = rng.random()
            x = 0.0 if u < 0.2 else rng.randint(-int(1.4 * D), int(1.4 * D)) / D
            if abs(x) < 0.2 and x != 0.0:
                x = 0.2 if x > 0 else -0.2
            atoms.append((x, rng.uniform(0.05, 0.5)))
        moved = []
        for x, w in atoms:
            x2 = x + rng.randint(0, int(0.8 * D)) / D
            if 0 < abs(x2) < 0.2:
                x2 = 0.2 if x2 > 0 else (0.0 if x2 > -0.1 else -0.2)
            if x2 < x:
                x2 = x
            moved.append((x2, w))
        t, h = rng.uniform(-1.5, 1.5), rng.uniform(0.02, 1.0)
        kk = rng.uniform(0.1, 1.5)
        for kind in ('psi', 'exp'):
            e0, e1 = Epsi(atoms, kind, t, h, kk), Epsi(moved, kind, t, h, kk)
            check(e0 <= e1 + 1e-12 * max(1.0, abs(e1)), f'T4 Lemma 4 {kind}: {e0} > {e1} for {atoms} -> {moved}')
            if kind == 'psi':
                worst = min(worst, e1 - e0)
        r0, r1 = Epsi(atoms, 'rev', t), Epsi(moved, 'rev', t)
        if r0 > r1 + 1e-9:
            rev_fail += 1
    say(f'T4: {n} random (K, T): Lemma 4 held for psi_(t,h) and exp(k w) (min gap {worst:.3e}); control psi = '
        f'(t - w)_+^2 (psi\'\' nonincreasing): the inequality failed in {rev_fail} of {n} cases')
    check(rev_fail > 0, 'T4 control: the reverse-curvature test function never violated the inequality')
    # Remark 5 counterexample, exact: E(Z_K)_+ for K = delta_sqrt2 vs delta_2
    a1 = 0.5 * sum(pois_f(0.5, n) * abs(SQ2 * (n - 0.5)) for n in range(60))
    a2 = 0.5 * math.exp(-0.25)
    say(f'T4: Remark 5: E(Z_d_sqrt2)_+ = {a1:.12f} (T/2 = {TF / 2:.12f}), E(Z_d_2)_+ = {a2:.12f} = e^(-1/4)/2; '
        f'the stop-loss decreases, as stated')
    check(abs(a1 - TF / 2) < 1e-12 and a2 < a1, 'T4 Remark 5 counterexample')


def T5(rng, restarts):
    """Hostile search over band K: two big atoms, one positive residual atom in (0, 1), one negative atom, Gaussian."""

    def unpack(z, force_res=False):
        s = expit(np.asarray(z[:6], dtype=float))
        x1 = 1 + (SQ2 - 1) * s[0]
        x2 = 1 + (SQ2 - 1) * s[1]
        f = s[2]
        rho2 = 0.1 * s[3] if not force_res else 0.001 + 0.099 * s[3]
        xr = 0.25 + 0.74 * s[4]
        xn = -(0.25 + (SQ2 - 0.25) * s[5])
        e = np.exp(z[6:9] - np.max(z[6:9]))
        pr = e / e.sum()
        kmax = math.floor(SQ2 * D)
        q = lambda x: math.copysign(min(round(abs(x) * D), kmax), x) / D
        big = [(q(x1), (1 - rho2) * f), (q(x2), (1 - rho2) * (1 - f))]
        res = [(q(xr), rho2 * pr[0]), (q(xn), rho2 * pr[1]), (0.0, rho2 * pr[2])]
        assert all(D <= round(x * D) <= kmax for x, _ in big) and all(abs(x) <= kmax / D for x, _ in res)
        return [u for u in big if u[1] > 1e-9], [u for u in res if u[1] > 1e-9]

    bestE, bestG = (-1, None), (-1, None)
    for r in range(restarts):
        z0 = np.array([rng.gauss(0, 2) for _ in range(9)])

        def fE(z):
            big, res = unpack(z)
            return -EabsZ(big + res)

        def fG(z):
            big, res = unpack(z, True)
            if not res:
                return 0.0
            return -(EabsZ(big + res) - F_and_parts(big, res)[0])
        for f, tag in ((fE, 'E'), (fG, 'G')):
            o = minimize(f, z0, method='Nelder-Mead', options=dict(maxiter=600, xatol=1e-7, fatol=1e-13))
            big, res = unpack(o.x, tag == 'G')
            val = -o.fun
            if tag == 'E' and val > bestE[0]:
                bestE = (val, big, res)
            if tag == 'G' and val > bestG[0]:
                bestG = (val, big, res)
    say(f'T5: hostile max E|Z_K| over band K = {bestE[0]:.12f} (T = {TF:.12f}, T - max = {TF - bestE[0]:.3e}) at '
        f'big {bestE[1]} res {bestE[2]}')
    check(bestE[0] <= TF, 'T5 hostile search found E|Z_K| > T')
    say(f'T5: hostile max (E|Z_K| - F) = {bestG[0]:.3e} at big {bestG[1]} res {bestG[2]}')
    check(bestG[0] <= 1e-11, 'T5 hostile search found E|Z_K| > F')


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 400
    restarts = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    rng = random.Random(20261022)
    T1_T3(rng, n)
    T4(rng, n)
    T5(rng, restarts)
    say(f'TOTAL FAILS: {len(FAILS)}')


if __name__ == '__main__':
    main()
