#!/usr/bin/env python3
"""A.38c (RQ-AUD): negative controls for my verifier a38_heavy_verify.py (each corruption must be rejected).

c1 drop one box record (box tiling); c2 move one box index out of its grid; c3 drop one cell of a box with >= 2 cells;
c4 make the top coefficient c_16 of one majorant negative; c5 Farkas multipliers (0, 0); c6 mark a certified,
non-empty box as empty; c7 L below tau a1 + A b1; c8 threshold lowered to just below a box's own bound (the
verifier is tight: it must fail at C5' = mine - 1e-9 and pass at mine + 1e-9); neutral control n1: phi - 1e-3
(beta drops and eps rises by the same 1e-3, so beta + eps is unchanged to 1e-9).
Usage: python3 a38c_heavy_negative.py
"""
import copy
import glob
import json
import os

from flint import arb, fmpq

import a38_heavy_verify as V

DATA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'heavy_2230', 'plus_cert')


def tiling_ok(recs):
    per = {}
    for r in recs:
        ea, ia, eb, ib = r['box']
        d = ea - 4
        if not (ea == eb and 0 <= d <= 4 and 0 <= ia < 2 ** ea and 0 <= ib < 2 ** eb):
            return False
        s = 2 ** d
        per.setdefault((ia // s, ib // s), []).append((d, ia % s, ib % s))
    return len(per) == 256 and all(V.tiles(v, 4) for v in per.values())


def main():
    recs = []
    for f in sorted(glob.glob(os.path.join(DATA, 'certs_v1_r*.jsonl'))):
        recs += [json.loads(l) for l in open(f)]
    out = []
    out.append(('baseline tiling', tiling_ok(recs), True))
    out.append(('c1 drop box record 0', tiling_ok(recs[1:]), False))
    r2 = copy.deepcopy(recs)
    r2[5]['box'][1] += 2 ** r2[5]['box'][0]
    out.append(('c2 box index out of grid', tiling_ok(r2), False))
    multi = next(r for r in recs if r['status'] == 'ok' and len(r['certs']) >= 2)
    m2 = copy.deepcopy(multi)
    m2['certs'] = m2['certs'][1:]
    out.append((f'c3 drop one cell of box {multi["box"]}', V.verify_box(m2)['ok'], False))
    one = next(r for r in recs if r['status'] == 'ok' and len(r['certs']) == 1)
    base = V.verify_box(one)
    out.append((f'baseline box {one["box"]}', base['ok'], True))
    m4 = copy.deepcopy(one)
    m4['certs'][0]['coef'][16] = -abs(m4['certs'][0]['coef'][16]) - 1e-6
    out.append(('c4 c_16 negative', V.verify_box(m4)['ok'], False))
    fk = next(r for r in recs if r['status'] == 'ok' and any(c['status'] == 'empty_farkas' for c in r['certs']))
    out.append((f'baseline Farkas box {fk["box"]}', V.verify_box(fk)['ok'], True))
    m5 = copy.deepcopy(fk)
    for c in m5['certs']:
        if c['status'] == 'empty_farkas':
            c['farkas'] = [0.0, 0.0]
    out.append(('c5 Farkas multipliers (0, 0)', V.verify_box(m5)['ok'], False))
    m6 = copy.deepcopy(one)
    m6['status'] = 'empty'
    out.append(('c6 certified box marked empty', V.verify_box(m6)['ok'], False))
    m7 = copy.deepcopy(one)
    a1, a2, b1, b2 = V.box_of(one['box'])
    m7['certs'][0]['Lt'] = float(V.TAU * a1 + V.AA * b1) * 0.5
    out.append(('c7 L < tau a1 + A b1', V.verify_box(m7)['ok'], False))
    mine = fmpq(0)
    c5 = V.C5
    w = base['worst']['mine']
    V.C5 = arb(w) - arb('1e-9')
    out.append(('c8 threshold mine - 1e-9', V.verify_box(one)['ok'], False))
    V.C5 = arb(w) + arb('1e-9')
    out.append(('c8 threshold mine + 1e-9', V.verify_box(one)['ok'], True))
    V.C5 = c5
    del mine
    ct = one['certs'][0]
    mu, cap, R3, R4 = V.box_params(a1, a2, b1, b2)
    k3, k4 = V.cell_of(ct['cell'], R3, R4)
    st = {'sup': 0, 'pieces': 0}
    rg = V.ranges(ct['rmult'], mu, cap, k3, k4, st)
    b_old = V.lagrangian_beta(ct, mu, cap, k3, k4, rg, st)
    n1 = copy.deepcopy(ct)
    n1['coef'][0] -= 1e-3
    b_new = V.lagrangian_beta(n1, mu, cap, k3, k4, rg, st)
    exact = (b_new - b_old) == (V.fq(n1['coef'][0]) - V.fq(ct['coef'][0]))
    out.append(('n1 c_0 - 1e-3 moves beta by exactly the change of c_0', exact, True))
    allok = True
    for name, got, want in out:
        flag = 'ok' if got == want else 'UNEXPECTED'
        allok &= got == want
        print(f'{name}: verified = {got} (expected {want}) {flag}')
    print('ALL CONTROLS BEHAVE AS EXPECTED' if allok else 'CONTROL FAILURE')


if __name__ == '__main__':
    main()
