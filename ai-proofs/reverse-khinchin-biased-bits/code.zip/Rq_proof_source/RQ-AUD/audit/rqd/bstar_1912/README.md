# RQ-D: a non-moment mechanism for Conjecture S

Code and certificates for Part IV of the R(q) proof.

**Problem.** For q in (0,1) let chi_i be i.i.d. with chi = sqrt((1-q)/q) w.p. q and chi = -sqrt(q/(1-q)) w.p. 1-q.
R(q) = sup E|sum alpha_i chi_i| / ||alpha||_2. Conjecture S: R(q) = 2 sqrt(q(1-q)) max_{k>=1} sqrt(k) qh^(k-1),
qh = max(q, 1-q), with equal coefficients on k coordinates (OR_k) as extremisers. Proved and audited by the team on
[1 - sqrt3/2, sqrt3/2].

**RQ-D's mechanism.** No moment-polynomial certificates. The tools are

1. the exact *flip formula* E|Y + W| = E|Y| + 2E[(-sgn(Y) W - |Y|)_+] for independent Y, W with E W = 0;
2. the *OR-region identity*: if the large part Y of the sum has every jump above its compensator, then E|Y| is an
   explicit OR-type value, so all the error sits in tail ("stop-loss") terms of the residual W;
3. explicit, non-moment bounds for those stop-loss terms (single-jump expansion plus Poisson/Bernoulli tail
   comparison).

4. a *comparison lemma*: pushing jumps to the right increases E psi(Z_K) whenever psi'' is nondecreasing, which bounds
   the stop-loss terms by two-point laws.

**Results** (details and audit status in `CLAIMS.md`; proofs in `MAIN_RESULT.pdf`):

- **Theorem 10 (band lemma for C5; audit A.32 VALID).** E|Z_K| <= sqrt(2/e) for every probability K on
  [-sqrt2, sqrt2] with K([1, sqrt2]) >= 9/10 or K([-sqrt2, -1]) >= 9/10. **Corollary 11:** C5 reduces to the far
  region.
- **Theorem 13 (ID* band lemma at theta = 0.85, A = 1.54; audit requested).** E|Z_K| <= max(g(lambda+_0.85(K)), C_5)
  for every finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, and the mirror
  statement. **Corollary 14:** with the team's audited reductions, Conjecture S for all q then needs only
  E|Z_K| <= C_5 on the far region {K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5}.

Both theorems are computer-assisted. Every inequality the proofs need is checked in ball arithmetic.

## Layout

| Path | Content |
|---|---|
| `CLAIMS.md` | every claim, tagged PROVED / CONDITIONAL / NUMERICAL / FAILED |
| `STATUS.md` | what is established, the exact failure point, the next lemma |
| `MAIN_RESULT.tex` / `.pdf` | write-up of the claimed results (full proofs) |
| `AUDIT_REQUEST.md` | claims submitted to RQ-AUD |
| `NOTES_FOR_TEAM.md` | coordination notes for RQ-A / RQ-B / RQ-C |
| `scripts/` | exploration (float, evidence only) and certified checks (exact / interval) |
| `outputs/` | outputs of the scripts |

## Running

Python 3 with `numpy`, `scipy`, `mpmath` and `python-flint` (arb, for the certified checks). Certified checks
(versions in `outputs/verify_band_env.txt` and `outputs/verify_bandstar_env.txt`):

```bash
python3 scripts/verify_band.py S       # Theorem 10, part S (seconds)
python3 scripts/verify_band.py B       # Theorem 10, part B (8 processes, about 2 min)
python3 scripts/verify_bandstar.py all 0.0078125 8 outputs/verify_bandstar_squares.jsonl   # Theorem 13 (about 13 min)
PYTHONPATH=scripts python3 scripts/verify_bandstar_controls.py 8                         # controls for Theorem 13
```

Exploration and float tests (evidence only):

```bash
cd scripts && python3 bandstar_soundness2.py 0.2 400   # float soundness test of every ingredient of Theorem 13
cd ..
python3 scripts/explore_pairs2.py      # pair endpoint tests (float)
python3 scripts/explore_blocks.py      # level/block moves (float)
python3 scripts/pair_bellman.py 0.3 80 21 40   # two-copy Bellman relaxation (float)
```

Build the PDF with `latexmk -pdf MAIN_RESULT.tex`.
