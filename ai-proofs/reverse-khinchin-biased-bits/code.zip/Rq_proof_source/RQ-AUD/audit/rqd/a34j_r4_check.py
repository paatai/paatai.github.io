"""A.34 addendum: RQ-D's text-only update of 2026-10-23 07:40 UTC (A.34 r4: the lower end of the D13 Dirac range).

Inputs: my snapshots of RQ-D's texts (audit/snapshots/s0645/ = before, audit/snapshots/s0742/ = after) and the live
store for hashing. RQ-D's scripts and data files are hashed, not read.

Checks: (1) the CLAIMS diff is the date and the two D13 lines; (2) 1.3388681 is the leading-digit form of 1/sqrt(L2)
in Arb; (3) the AUDIT_REQUEST diff is the new 07:40 note plus the r3 note with the figure corrected and a marker;
(4) every remaining "1.3388682…" in the four texts is a quoted old figure; (5) my own sweep of every decimal written
with an ellipsis in CLAIMS, STATUS, README, AUDIT_REQUEST, NOTES and MAIN_RESULT.tex, each checked in Arb against
the exact value it denotes; (6) md5s of the tex, PDF, README and the 21 files of a34i.
"""
import os
import re
import sys

from flint import arb, fmpq

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
from a34i_text_fix_check import UNCHANGED, changed_lines, g, md5, prefix  # noqa: E402

SNAP = os.path.join(HERE, "..", "snapshots")
OLD = os.path.join(SNAP, "s0645")
NEW = os.path.join(SNAP, "s0742")
RQD = "/cursor/stores/bot/rq/RQ-D"
TEX_MD5 = "ac0ecf4ff81feba53f6b8d8567a35a3b"
PDF_MD5 = "f0fc9c23eef76a9921644261ca7ae757"
CLAIMS_MD5 = "77201a7b56b54b33869e47b19cbdd456"
OLD_FIG, NEW_FIG = "1.3388682…", "1.3388681…"
ELL = r"(?:…|\.\.\.|\\ldots|\\dots|\\cdots)"
RES = []


def check(name, cond, detail=""):
    RES.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f": {detail}" if detail else ""))


def lines(path):
    return open(path, encoding="utf-8").read().split("\n")


def norm(ls):
    return " ".join(" ".join(ls).split())


def leading(v, fig):
    d = len(fig.split(".")[1])
    a = arb(fmpq(int(fig.replace(".", "")), 10 ** d))
    return bool(v - a > 0) and bool(a + arb(fmpq(1, 10 ** d)) - v > 0)


def main():
    old = {n: lines(os.path.join(OLD, f"RQ-D_{n}.md")) for n in ("CLAIMS", "AUDIT_REQUEST", "STATUS", "NOTES_FOR_TEAM")}
    new = {n: lines(os.path.join(NEW, f"{n}.md")) for n in old}
    check("(0) s0742 CLAIMS has the md5 that RQ-D states (77201a7b…)",
          md5(os.path.join(NEW, "CLAIMS.md")) == CLAIMS_MD5)

    o, n = old["CLAIMS"], new["CLAIMS"]
    ops = changed_lines(o, n)
    rows = sorted(i1 + 1 for _, i1, _, _, _ in ops)
    ok = (len(o) == len(n) and all(t == "replace" and i1 == j1 and i2 - i1 == j2 - j1 for t, i1, i2, j1, j2 in ops)
          and sorted(set(i for _, i1, i2, _, _ in ops for i in range(i1 + 1, i2 + 1))) == [3, 84, 85]
          and n[2] == o[2].replace("05:35 UTC", "07:40 UTC") and o[83].count(OLD_FIG) == 1
          and n[83] == o[83].replace(OLD_FIG, NEW_FIG) and n[84] == o[84].replace("A.34 r3)", "A.34 r3, r4)"))
    check("(1) CLAIMS e62b2ae6 -> 77201a7b: only the date (line 3) and D13 lines 84-85 change: 1.3388682… -> "
          "1.3388681… and 'A.34 r3' -> 'A.34 r3, r4'", ok, f"changed blocks start at lines {rows}; {len(o)} lines")

    L5 = 2 * arb(fmpq(5, 4)).log()
    C5 = g(L5)
    lo, hi = arb(fmpq(1, 2)), arb(1)
    for _ in range(120):
        mid = (lo + hi) / 2
        if g(mid) > C5:
            lo = mid
        else:
            hi = mid
    L2 = (lo + hi) / 2
    xa, xb = 1 / L2.sqrt(), 1 / L5.sqrt()
    check("(2) the lower end 1/sqrt(L2) has leading digits 1.3388681, not 1.3388682 (Arb, 200 bits)",
          prefix(xa, "1.3388681") and not prefix(xa, "1.3388682") and leading(xa, "1.3388681"),
          f"1/sqrt(L2) = {xa.mid().str(15, radius=False)}")

    o, n = old["AUDIT_REQUEST"], new["AUDIT_REQUEST"]
    ops = changed_lines(o, n)
    ins = [(i1, j1, j2) for t, i1, i2, j1, j2 in ops if t == "insert"]
    rep = [(i1, i2, j1, j2) for t, i1, i2, j1, j2 in ops if t == "replace"]
    note = None
    ok = len(ops) == 2 and len(ins) == 1 and len(rep) == 1
    if ok:
        i1, j1, j2 = ins[0]
        block = n[j1:j2]
        while block and not block[0].strip():
            block, j1 = block[1:], j1 + 1
        while block and not block[-1].strip():
            block, j2 = block[:-1], j2 - 1
        note = (j1, j2)
        ok = (block[0].startswith("**Note, 2026-10-23 07:40 UTC: A.34 r4 applied (CLAIMS D13 only).")
              and CLAIMS_MD5 in norm(block) and "ac0ecf4f" in norm(block) and "f0fc9c23" in norm(block))
        a1, a2, b1, b2 = rep[0]
        before = norm(o[a1:a2]).replace(OLD_FIG, NEW_FIG)
        after = norm(n[b1:b2])
        tail = after[len(before):]
        ok = (ok and after.startswith(before) and tail.startswith(" (Lower end corrected at 07:40 UTC, A.34 r4:")
              and f'"{OLD_FIG}"' in tail and o[a1].startswith("- **A.34 r3 (CLAIMS D13, NUMERICAL).**"))
        print(f"     inserted note: new lines {j1 + 1}-{j2} after old line {i1}; r3 note: old {a1 + 1}-{a2} -> "
              f"new {b1 + 1}-{b2}; appended marker: {tail.strip()}")
    check("(3) AUDIT_REQUEST: the only changes are the new 07:40 note at the top (naming CLAIMS 77201a7b…, tex "
          "ac0ecf4f…, PDF f0fc9c23…) and the r3 note with 1.3388681… and a correction marker", ok)

    bad = []
    for name in new:
        for k, s in enumerate(new[name], 1):
            for m in re.finditer(re.escape(OLD_FIG), s):
                if not (s[m.start() - 1:m.start()] == '"' and s[m.end():m.end() + 1] == '"'):
                    bad.append(f"{name}:{k}")
        for t, i1, i2, j1, j2 in changed_lines(old[name], new[name]):
            if name in ("STATUS", "NOTES_FOR_TEAM"):
                for s in new[name][j1:j2]:
                    print(f"     {name} + {s}")
    check("(4) in the new CLAIMS, AUDIT_REQUEST, STATUS and NOTES every '1.3388682…' is a quoted old figure",
          not bad, f"unquoted at {bad}" if bad else "")

    q5 = 1 - arb(fmpq(4, 5)).sqrt()
    s5 = -(1 - q5).log()
    figures = {
        "0.337": (arb(fmpq(4, 5)) / arb(fmpq(77, 50)) ** 2, "0.8/A^2, A = 1.54 (tex: b_+ < 0.8/A^2)"),
        "1.107": (arb(fmpq(4, 5)) / arb(fmpq(17, 20)) ** 2, "0.8/tau^2, tau = 0.85 (tex: a_+ < 0.8/tau^2)"),
        "0.4462871": (L5, "2 ln(5/4)"),
        "0.5578588": (L2, "L2, the upper root of g = C_5"),
        "0.5578588782": (L2, "L2 (quoted from RQ-AUD's A.34 addendum)"),
        "1.33886819": (xa, "1/sqrt(L2) (quoted from RQ-AUD's A.34 addendum)"),
        "0.85510045547": (C5, "C_5 = g(2 ln 5/4)"),
        "0.8551004": (C5, "C_5 = g(2 ln 5/4)"),
        "1.3388681": (xa, "1/sqrt(L2)"),
        "1.4969001": (xb, "1/sqrt(2 ln 5/4)"),
        "1.538": ((2 * q5 / s5).sqrt() / (1 - q5), "A'(q5) = sqrt(2q/s)/(1-q)"),
    }
    files = {"CLAIMS": os.path.join(NEW, "CLAIMS.md"), "STATUS": os.path.join(NEW, "STATUS.md"),
             "AUDIT_REQUEST": os.path.join(NEW, "AUDIT_REQUEST.md"), "NOTES": os.path.join(NEW, "NOTES_FOR_TEAM.md"),
             "README": os.path.join(RQD, "README.md"), "MAIN_RESULT.tex": os.path.join(RQD, "MAIN_RESULT.tex")}
    rqd9 = {"0.337", "1.107", "0.4462871", "0.5578588", "0.85510045547", "0.8551004", "1.3388681", "1.4969001", "1.538"}
    seen, outside, quoted, unknown, wrong = {}, set(), [], [], []
    for name, p in files.items():
        for k, s in enumerate(lines(p), 1):
            in_note = name == "AUDIT_REQUEST" and note is not None and note[0] < k <= note[1]
            for m in re.finditer(r"(?<![\d.])(\d+\.\d+)" + ELL, s):
                fig = m.group(1)
                if s[m.start() - 1:m.start()] == '"':
                    quoted.append(f"{fig} ({name}:{k})")
                    continue
                seen.setdefault(fig, []).append(f"{name}:{k}")
                if not in_note:
                    outside.add(fig)
                if fig not in figures:
                    unknown.append(f"{fig} ({name}:{k})")
    for fig in sorted(seen):
        if fig in figures:
            v, what = figures[fig]
            ok = leading(v, fig)
            if not ok:
                wrong.append(fig)
            print(f"     {'PASS' if ok else 'FAIL'} {fig}… = {what} = {v.mid().str(18, radius=False)} "
                  f"x{len(seen[fig])} ({', '.join(sorted(set(x.split(':')[0] for x in seen[fig])))})")
    print(f"     quoted old figures (not checked as values): {quoted}")
    print(f"     outside RQ-D's 07:40 note: {sorted(outside)}; only in the note: {sorted(set(seen) - outside)}")
    check(f"(5) own sweep: {len(seen)} distinct unquoted ellipsis figures in RQ-D's six texts, each the leading "
          f"digits of its exact value; outside RQ-D's 07:40 note they are exactly the 9 that RQ-D lists",
          not unknown and not wrong and outside == rqd9,
          f"unidentified {unknown}; wrong {wrong}" if unknown or wrong else ", ".join(sorted(seen)))

    live = {"MAIN_RESULT.tex": TEX_MD5, "MAIN_RESULT.pdf": PDF_MD5,
            "README.md": md5(os.path.join(OLD, "RQ-D_README.md")),
            "CLAIMS.md": md5(os.path.join(NEW, "CLAIMS.md")), "AUDIT_REQUEST.md": md5(os.path.join(NEW, "AUDIT_REQUEST.md")),
            "STATUS.md": md5(os.path.join(NEW, "STATUS.md")), "NOTES_FOR_TEAM.md": md5(os.path.join(NEW, "NOTES_FOR_TEAM.md"))}
    live.update(UNCHANGED)
    bad = [rel for rel, e in live.items() if md5(os.path.join(RQD, rel)) != e]
    check(f"(6) live store: tex ac0ecf4f…, PDF f0fc9c23…, README (as at 06:45), the 21 files of a34i (hashed, not "
          f"read) and the four texts as snapshotted ({len(live)} files)", not bad, f"mismatches {bad}" if bad else "")

    bad = [nm for nm, ok in RES if not ok]
    print("A34J_ALL_CONFIRMED" if not bad else f"A34J_NOT_CONFIRMED {bad}")


if __name__ == "__main__":
    main()
