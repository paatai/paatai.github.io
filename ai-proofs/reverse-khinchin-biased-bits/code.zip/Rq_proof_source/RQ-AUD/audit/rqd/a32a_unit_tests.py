"""A.32 unit tests of a32_band_verify.py primitives (own code): tau, Q against mpmath quadrature; chi_arb against a
120-term mpmath sum; the Part S linear bounds chi <= a alpha + b beta and CS <= rho^2/(2t) at random (a, b, t, h).
Usage: PYTHONPATH=. python3 a32a_unit_tests.py
"""
import math, mpmath as mp, random
from fractions import Fraction as F
import a32_band_verify as V
from flint import arb
mp.mp.dps = 40
fails = 0
def chk(ok, msg):
    global fails
    print(('PASS ' if ok else 'FAIL ') + msg)
    if not ok: fails += 1
# tau and Q against quadrature
for x in [-2.0, -0.3, 0.0, 0.7, 2.5, 5.0, 7.0]:
    q = mp.quad(lambda g: (g - x)**2 * mp.npdf(g), [x, mp.inf])
    v = V.tau(arb(x))
    chk(abs(float(v.mid()) - float(q)) < 1e-15 * max(1, float(q)) + 1e-30 and v.rad() < 1e-30, f'tau({x}) = {float(q):.6e}')
for (d0, s0) in [(-1.0, 0.1), (0.3, 0.2), (-0.05, 0.3), (2.0, 0.05), (-3.0, 0.2)]:
    # reference fully in mpmath (the float inputs are exact binary numbers); integral in the shifted variable
    d, s = mp.mpf(d0), mp.mpf(s0)
    with mp.workdps(60):
        if d < 0:   # integrand (s u)^2 phi(|z| + u) concentrates at u ~ 2/|z|
            q = mp.quad(lambda u: (s * u) ** 2 * mp.npdf(-d / s + u), [0, 0.05, 0.2, 1, 5, mp.inf])
        else:       # integrand concentrates at g ~ 0
            q = mp.quad(lambda g: (d + s * g) ** 2 * mp.npdf(g), [-d / s] + [x for x in (-10, -5, 0, 5, 10) if x > -d / s] + [mp.inf])
    v = V.Q(arb(d0), arb(s0))
    chk(abs(float(v.mid()) / float(q) - 1) < 1e-12 and float(v.rad()) < 1e-20 * float(q), f'Q({d0},{s0}) = {float(q):.6e}')
# chi against an independent direct sum with mpmath (100 Poisson terms, mp quadrature-free closed form)
def chi_mp(J, lam, s, t, h):
    tot = mp.mpf(0)
    for n in range(120):
        p = mp.e**(-lam) * lam**n / mp.factorial(n)
        d = J * (n - lam) - (t - h)
        z = d / s
        tot += p * ((d*d + s*s) * mp.ncdf(z) + d * s * mp.npdf(z))
    return tot / (2 * h)
rng = random.Random(5)
for _ in range(12):
    J = rng.choice([1.0, math.sqrt(2)]); lam = rng.uniform(0, 0.12); s = rng.uniform(0.01, 0.35)
    t = rng.uniform(-0.2, 2.0); h = rng.uniform(0.01, 1.5)
    va = V.chi_arb(arb(J), arb(lam), arb(s), arb(t), arb(h))
    vm = chi_mp(mp.mpf(J), mp.mpf(lam), mp.mpf(s), mp.mpf(t), mp.mpf(h))
    vf = V.chi_f(J, lam, s, t, h)
    ok = float(va.lower().mid()) <= float(vm) * (1 + 1e-12) + 1e-40 and float(va.upper().mid()) >= float(vm) * (1 - 1e-12)
    chk(ok and abs(vf - float(vm)) <= 1e-12 * float(vm) + 1e-300 and float(va.rad()) < 1e-20, f'chi J={J:.3f} lam={lam:.3f} s={s:.3f} t={t:.3f} h={h:.3f}: {float(vm):.6e}')
# Part S coefficient bounds vs chi at random (a, b) (alpha, beta are upper coefficients)
P = V.PartS(F(1, 50))
for _ in range(400):
    a = rng.uniform(0, 0.02); b = rng.uniform(1e-6, 0.02)
    kind = rng.choice('BC'); t = rng.uniform(0.3, 1.4) if kind == 'C' else rng.uniform(0.6, 1.0)
    cands = P.candidates(kind, ('test', t), arb(t))
    for (al, be, h) in cands:
        if h == 'CS':
            lhs = math.sqrt(t*t + a + b) - t
        elif kind == 'B':
            lhs = V.chi_f(1.0, a, math.sqrt(b), t, h)
        else:
            lhs = V.chi_f(math.sqrt(2), b/2, math.sqrt(max(a,1e-300)), t, h) if a > 0 else None
        if lhs is None: continue
        rhs = a * float(al.mid()) + b * float(be.mid())
        if lhs > rhs * (1 + 1e-9) + 1e-15:
            chk(False, f'linear bound {kind} t={t} h={h} a={a} b={b}: {lhs} > {rhs}')
print('linear-bound spot checks done')
print('FAILS', fails)
