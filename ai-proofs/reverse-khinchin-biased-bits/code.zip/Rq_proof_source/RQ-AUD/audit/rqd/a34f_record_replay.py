#!/usr/bin/env python3
"""A.34 addendum (RQ-AUD): replay of RQ-D's box-level record of the Theorem 13 run (RQ-REF3's remark 2) with my own
A.34 verifier.

Input: RQ-D's record, data only (outputs/bandstar_cert/: bandstar_leaves.npz, bandstar_slope.json,
record_squares.jsonl) and RQ-D's published per-square log outputs/verify_bandstar_squares.jsonl. RQ-D's scripts
(bandstar_record.py, bandstar_replay.py, verify_bandstar.py) are neither read nor run; the layout of the record is
read off the data. Units: (a, b) in 1/8192, Lambda in 1/16384, m in 1/4096.

Checks, all with my code (a34_bandstar_verify.py, whose decisions are made in arb):
 (1) the certified squares are interior-disjoint, cover the triangle T = {a, b >= 0, a + b <= 1/5}, and are exactly
     the ok squares of the published log; the record's per-square log equals the published one (box, ok, nbox);
 (2) per square, the leaves are interior-disjoint and their union contains
     R0 = [Vlo/A^2, Vhi/theta^2] x [Vlo/A, Vhi/theta], which holds every (Lambda, m) allowed by F1-F2;
 (3) every leaf is decided by my own procedures: infeasible (F1-F5, exact), direct (options O1-O4, my h grid), slope
     (my rho^2 pieces and tests T1-T3); a leaf none of them decides whole is bisected by my rule and each part decided;
 (4) RQ-D's labels: an infeasible leaf's inequality number against my eight one-sided tests; for each slope
     certificate, that its bisection paths are complete and prefix-free, that r_eff = jr/4096 >= r2 for every piece,
     that (T3) never comes with (O5) and (T3K) only with (O5), and that my piece check passes on RQ-D's pieces;
     counts per method against RQ-D's.

Usage: a34f_record_replay.py [workers] [record_dir]
"""
import os as _os
_ROOT = _os.path.abspath(_os.path.join(_os.path.dirname(_os.path.abspath(__file__)), "..", "..", ".."))  # archive root
import hashlib
import json
import math
import os
import sys
import time
from collections import Counter
from fractions import Fraction as F
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from a34_bandstar_verify import AA, GL, GM, RM, RS, TH, Square, infeasible  # noqa: E402

AB_UNIT, L_UNIT, M_UNIT = 8192, 16384, 4096
R_UNIT = 4096          # r_eff = jr/4096: the reading that fits the data (jr = 64 on the whole rho^2 range [0, 1/64])
STORE = _os.path.join(_ROOT, "RQ-D/outputs")
EXPECTED_MD5 = {"bandstar_leaves.npz": "170d0ba8c98c8fbed9575f3c1525a452",
                "bandstar_slope.json": "353cfe2ad87153637ca05129df7ee4e8",
                "record_squares.jsonl": "8d4d2db30e96cba715bf9f1605c5f94e"}
MAXDEPTH = 14


def md5(path):
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def eight_tests(L1, L2, m1, m2, Vlo, Vhi):
    """My one-sided tests of F1-F5 on a box, in the order of infeasible(): each True means that inequality fails on the
    whole box for every V in [Vlo, Vhi]."""
    return (L2 * AA * AA < Vlo, L1 * TH * TH > Vhi, m2 * AA < Vlo, m1 * TH > Vhi, TH * L1 > m2, m1 > AA * L2,
            m1 * m1 > L2 * Vhi, L1 > (1 / AA + 1 / TH) * m2 - Vlo / (AA * TH))


def cover_cells(boxes, xs=None, ys=None):
    """Coverage counts on the grid cut out by all box edges (boxes: int array n x 4, [x1, x2, y1, y2])."""
    if xs is None:
        xs = np.unique(np.concatenate([boxes[:, 0], boxes[:, 1]]))
        ys = np.unique(np.concatenate([boxes[:, 2], boxes[:, 3]]))
    D = np.zeros((len(xs) + 1, len(ys) + 1), dtype=np.int64)
    i1, i2 = np.searchsorted(xs, boxes[:, 0]), np.searchsorted(xs, boxes[:, 1])
    j1, j2 = np.searchsorted(ys, boxes[:, 2]), np.searchsorted(ys, boxes[:, 3])
    np.add.at(D, (i1, j1), 1)
    np.add.at(D, (i2, j1), -1)
    np.add.at(D, (i1, j2), -1)
    np.add.at(D, (i2, j2), 1)
    C = D.cumsum(0).cumsum(1)[:len(xs) - 1, :len(ys) - 1]
    return xs, ys, C


def decide(sq, L1, L2, m1, m2, depth, tally, maxdepth=MAXDEPTH):
    """True if my procedures certify the box [L1, L2] x [m1, m2] of square sq (bisecting by my rule if needed)."""
    if infeasible(L1, L2, m1, m2, sq.Vlo, sq.Vhi):
        tally["infeasible"] += 1
        return True
    res = sq.direct(L1, L2, m1, m2)
    if res is not None:
        tally[res[0]] += 1
        return True
    if sq.slope_ok and m2 < TH:
        s = sq.slope(L1, L2, m1, m2)
        if s is not None:
            tally["slope" if s == "slope" else "slope_empty"] += 1
            return True
    if depth >= maxdepth:
        return False
    tally["split"] += 1
    wm, wl = m2 - m1, L2 - L1
    if wm * GM > 1 and (depth % 2 == 0 or wl * GL <= 1):
        mm = (m1 + m2) / 2
        return (decide(sq, L1, L2, m1, mm, depth + 1, tally, maxdepth)
                and decide(sq, L1, L2, mm, m2, depth + 1, tally, maxdepth))
    if wl * GL > 1:
        Lm = (L1 + L2) / 2
        return (decide(sq, L1, Lm, m1, m2, depth + 1, tally, maxdepth)
                and decide(sq, Lm, L2, m1, m2, depth + 1, tally, maxdepth))
    return False


def piece_interval(r0, rB, path):
    lo, hi = r0, rB
    for c in path:
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if c == "0" else (mid, hi)
    return lo, hi


def slope_record_check(sq, L1, L2, m1, m2, cert):
    """RQ-D's slope certificate of one leaf: structure, r_eff, test/option pairing, my piece check on its pieces."""
    out = Counter()
    paths = [p["path"] for p in cert["pieces"]]
    kraft = sum(F(1, 2 ** len(p)) for p in paths)
    prefix_free = all(not (p != q and q.startswith(p)) for p in paths for q in paths)
    out["complete_prefix_free"] += int(kraft == 1 and prefix_free and len(set(paths)) == len(paths))
    r0 = sq.a1 + sq.b1
    rB = min(sq.a2 + sq.b2, 1 - m1 * m1 / L2)
    for p in cert["pieces"]:
        r1, r2 = piece_interval(r0, rB, p["path"])
        out["pieces"] += 1
        out["reff_ok"] += int(F(p["jr"], R_UNIT) >= r2)
        out["reff_le_rs"] += int(F(p["jr"], R_UNIT) <= RS)
        o5 = p["O"][0] == "O5"
        out["T3_with_O5"] += int(p["test"] == "T3" and o5)
        out["T3K_without_O5"] += int(p["test"] == "T3K" and not o5)
        out["test_" + p["test"]] += 1
        out["opt_" + p["O"][0]] += 1
        out["mine_whole"] += int(sq.piece(L1, L2, m1, m2, r1, r2) is not None)
    return out


def square_job(args):
    """args = (s, box, leaves, slope_certs[, shift, maxdepth]); shift > 0 lowers the target (controls only)."""
    s, box, leaves, slope_certs = args[:4]
    shift = args[4] if len(args) > 4 else F(0)
    maxdepth = args[5] if len(args) > 5 else MAXDEPTH
    t0 = time.time()
    a1, a2, b1, b2 = (F(int(x), AB_UNIT) for x in box)
    sq = Square(a1, a2, b1, b2, shift)
    res = dict(s=s, sq=[str(a1), str(a2), str(b1), str(b2)], leaves=len(leaves))
    # (2) tiling of R0 by the leaves
    bx = leaves[:, :4].astype(np.int64)
    xs, ys, C = cover_cells(bx)
    Llo, Lhi = sq.Vlo / (AA * AA) * L_UNIT, sq.Vhi / (TH * TH) * L_UNIT
    mlo, mhi = sq.Vlo / AA * M_UNIT, sq.Vhi / TH * M_UNIT
    inside_x = np.array([F(int(xs[i])) < Lhi and F(int(xs[i + 1])) > Llo for i in range(len(xs) - 1)])
    inside_y = np.array([F(int(ys[j])) < mhi and F(int(ys[j + 1])) > mlo for j in range(len(ys) - 1)])
    contains = F(int(xs[0])) <= Llo and F(int(xs[-1])) >= Lhi and F(int(ys[0])) <= mlo and F(int(ys[-1])) >= mhi
    need = np.outer(inside_x, inside_y)
    res["R0_covered"] = bool(contains and (C[need] >= 1).all())
    res["disjoint"] = bool(C.max() <= 1)
    res["union_is_rectangle"] = bool((C == 1).all())
    # (3), (4) leaf by leaf
    tally, by_rqd, label = Counter(), Counter(), Counter()
    slope_out = Counter()
    fails = []
    for row in leaves:
        l1, l2, k1, k2, meth, opt, aux = (int(x) for x in row)
        L1, L2, m1, m2 = F(l1, L_UNIT), F(l2, L_UNIT), F(k1, M_UNIT), F(k2, M_UNIT)
        by_rqd[meth] += 1
        if meth == 0:
            tests = eight_tests(L1, L2, m1, m2, sq.Vlo, sq.Vhi)
            label[(opt, tuple(i + 1 for i, t in enumerate(tests) if t))] += 1
        if meth == 5:
            slope_out.update(slope_record_check(sq, L1, L2, m1, m2, slope_certs[aux]))
        if not decide(sq, L1, L2, m1, m2, 0, tally, maxdepth):
            fails.append([l1, l2, k1, k2, meth])
    res.update(mine=dict(tally), by_rqd={str(k): v for k, v in by_rqd.items()},
               labels=[[o, list(t), n] for (o, t), n in label.items()], slope=dict(slope_out),
               fails=fails[:5], n_fail=len(fails), sec=round(time.time() - t0, 2))
    return res


def main():
    workers = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    rdir = sys.argv[2] if len(sys.argv) > 2 else os.path.join(STORE, "bandstar_cert")
    t0 = time.time()
    print(f"a34f: replay of RQ-D's box-level record, start {time.strftime('%Y-%m-%d %H:%M:%S', time.gmtime())} UTC")
    for name, want in EXPECTED_MD5.items():
        got = md5(os.path.join(rdir, name))
        print(f"md5 {name}: {got} ({'as filed' if got == want else 'DIFFERS from ' + want})")
    pub = os.path.join(rdir, "..", "verify_bandstar_squares.jsonl")
    print(f"md5 verify_bandstar_squares.jsonl (published log): {md5(pub)}")
    z = np.load(os.path.join(rdir, "bandstar_leaves.npz"), allow_pickle=False)
    certs = json.load(open(os.path.join(rdir, "bandstar_slope.json")))
    sq_box, off = z["sq_box"], z["sq_off"]
    leaves = np.stack([z["leaf_L1"], z["leaf_L2"], z["leaf_k1"], z["leaf_k2"], z["leaf_meth"], z["leaf_opt"],
                       z["leaf_aux"]], axis=1).astype(np.int32)
    methods = [str(x) for x in z["methods"]]
    print(f"record: {len(sq_box)} squares, {len(leaves)} leaves, {len(certs)} slope certificates; methods {methods}")
    ok = True

    # (1) squares
    rec = [json.loads(line) for line in open(os.path.join(rdir, "record_squares.jsonl"))]
    pubrec = [json.loads(line) for line in open(pub)]
    key = lambda r: (tuple(r["box"]), r["ok"], r["nbox"])  # noqa: E731
    same_log = sorted(map(key, rec)) == sorted(map(key, pubrec))
    okbox = sorted(tuple(int(round(x * AB_UNIT)) for x in r["box"]) for r in pubrec if r["ok"])
    exact_units = all(abs(x * AB_UNIT - round(x * AB_UNIT)) == 0 for r in pubrec for x in r["box"])
    recbox = sorted(tuple(int(v) for v in b) for b in sq_box)
    print(f"(1) record log = published log (box, ok, nbox) on {len(rec)} / {len(pubrec)} squares: {same_log}; "
          f"ok squares of the published log = certified squares of the record ({len(okbox)}): "
          f"{okbox == recbox and exact_units}")
    ok &= same_log and okbox == recbox and exact_units
    sb = sq_box.astype(np.int64)
    xs, ys, C = cover_cells(sb)
    lim = F(1, 5) * AB_UNIT
    meet = np.array([[F(int(xs[i])) + F(int(ys[j])) < lim for j in range(len(ys) - 1)] for i in range(len(xs) - 1)])
    cov_T = bool(xs[0] <= 0 and ys[0] <= 0 and (C[meet] >= 1).all())
    disj = bool(C.max() <= 1)
    sides = Counter(int(b[1] - b[0]) for b in sb)
    square_ok = all(b[1] - b[0] == b[3] - b[2] and b[0] % (b[1] - b[0]) == 0 and b[2] % (b[3] - b[2]) == 0
                    and F(int(b[0] + b[2]), AB_UNIT) <= F(1, 5) for b in sb)
    print(f"(1) squares interior-disjoint: {disj}; cover T: {cov_T}; dyadic squares meeting T: {square_ok}; "
          f"sides (units 1/8192): {dict(sorted(sides.items()))}")
    ok &= disj and cov_T and square_ok

    # (2)-(4) per square
    by_sq = {}
    for c in certs:
        by_sq.setdefault(c["sq"], {})[c["leaf"]] = c
    jobs = []
    for s in range(len(sq_box)):
        lv = leaves[off[s]:off[s + 1]]
        loc = {}
        for i in np.where(lv[:, 4] == 5)[0]:
            aux = int(lv[i, 6])
            c = certs[aux]
            assert c["sq"] == s and c["leaf"] == int(off[s] + i) and c["box"] == [int(v) for v in lv[i, :4]], (s, i)
            loc[aux] = c
        jobs.append((s, sq_box[s], lv, loc))
    print(f"slope certificates indexed: {sum(len(j[3]) for j in jobs)} (each matches its leaf's square, global leaf "
          f"index and box)")
    with Pool(workers) as pool:
        out = pool.map(square_job, jobs, chunksize=4)
    tot_mine, tot_rqd, labels, slope_tot = Counter(), Counter(), Counter(), Counter()
    n_fail, tiling_bad, union_rect, worst_sec = 0, [], 0, 0.0
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs", "a34f_squares.jsonl"), "w") as fo:
        for r in out:
            fo.write(json.dumps(r) + "\n")
            tot_mine.update(r["mine"])
            tot_rqd.update({methods[int(k)]: v for k, v in r["by_rqd"].items()})
            for o, t, n in r["labels"]:
                labels[(o, tuple(t))] += n
            slope_tot.update(r["slope"])
            n_fail += r["n_fail"]
            if not (r["R0_covered"] and r["disjoint"]):
                tiling_bad.append(r["sq"])
            union_rect += r["union_is_rectangle"]
            worst_sec = max(worst_sec, r["sec"])
    print(f"(2) squares whose leaves are interior-disjoint and cover R0: {len(out) - len(tiling_bad)} / {len(out)}; "
          f"union equal to the leaves' bounding rectangle: {union_rect}; first bad: {tiling_bad[:3]}")
    print(f"(3) leaves: {sum(tot_rqd.values())}; RQ-D's counts by method: {dict(tot_rqd)}")
    print(f"(3) my decisions (parts after my bisection included): {dict(sorted(tot_mine.items()))}")
    print(f"(3) leaves my procedures do not certify: {n_fail}")
    lab = {}
    for (o, t), n in sorted(labels.items()):
        lab.setdefault(o, Counter())[t] += n
    for o in sorted(lab):
        common = set(range(1, 9))
        for t in lab[o]:
            common &= set(t)
        print(f"(4) RQ-D infeasible label {o}: {sum(lab[o].values())} leaves; my tests failing on all of them: "
              f"{sorted(common)}; leaves where none of my 8 tests fails: {lab[o].get((), 0)}")
    no_test = sum(n for (o, t), n in labels.items() if not t)
    print(f"(4) slope certificates: {dict(sorted(slope_tot.items()))}")
    sl_ok = (slope_tot["complete_prefix_free"] == len(certs) and slope_tot["reff_ok"] == slope_tot["pieces"]
             and slope_tot["T3_with_O5"] == 0 and slope_tot["T3K_without_O5"] == 0)
    want = {"infeasible": 3114781, "chord": 551105, "twopoint_C": 2876016, "twopoint_CS": 128597, "taylor_B": 1203286,
            "slope": 426}
    print(f"(4) RQ-D's counts by method equal its published counts: {dict(tot_rqd) == want}")
    ok &= not tiling_bad and n_fail == 0 and sl_ok and dict(tot_rqd) == want
    print(f"labels without any failing test of mine (decided by my direct/slope checks instead): {no_test}")
    print(f"slowest square {worst_sec:.1f} s; total {time.time() - t0:.0f} s")
    print("A34F_PASS: the record is a valid certificate of Theorem 13 (checked with my own verifier)" if ok
          else "A34F_FAIL")


if __name__ == "__main__":
    main()
