#!/usr/bin/env python3
"""A.38 (RQ-AUD): independent verifier for RQ-D's Theorem 16 (heavy far region), MAIN_RESULT.pdf Section 7.

No RQ-D code is used or read; only the PDF (Lemmas 18-24, Section 7.4) and the certificate data
outputs/plus_cert/certs_v1_r*.jsonl. Every inequality is decided in exact rational arithmetic (python-flint fmpq),
except the Poisson probabilities, which are arb balls; polynomial positivity on an interval is proved by an exact
Sturm count (my own; RQ-D uses Taylor bounds with bisection), after a floating-point guess of the bound.

Checks (tau = 17/20, A = 77/50, C5 = 1.28 sqrt(2 ln 1.25)):
  T  box tiling of [0, 28/25] x [0, 17/50] (fine-grid marking, indices in their grids); empty boxes exact
     (Q(a1, b1) >= 4/5 or M(a2, b2) < 1/2); cell tiling of R_B for every other box.
  R  ranges (a) for j = 3..16 with the certificate's (s3, s4), Lemma 22 with S from a proved sup on [-A, tau].
  F  Farkas emptiness (b).
  L  Lagrangian bound (c): my own expansion E phi(Z_W) = sum c_k P_k (P_n = sum_i C(n-1, i-1) kappa_i P_{n-i},
     kappa_2 = mu_B), my own tuple set P (prefix-closed), McCormick and Hoelder rows, cell rows; multipliers clipped
     at 0; beta = c'' + mu_B S_R + cap_B (R(A) - S_R)_+ + sum max(e'_a k_a-, e'_a k_a+), S_R proved on [-A, 0], [0, tau].
  M  majorant (Lemma 23) with my own truncation (n_a, n_b, T, e): phi + eps >= H on [-L, L] piece by piece (Sturm),
     the two Taylor tail tests at +-L (exact), L >= tau a1 + A b1; then beta + eps < C5.
Usage: python3 a38_heavy_verify.py DATADIR [NPROC] [limit]
"""
import glob
import hashlib
import json
import math
import os
import sys
import time
from functools import lru_cache
from math import comb
from multiprocessing import Pool

import numpy as np
from flint import arb, ctx, fmpq, fmpq_poly

ctx.prec = 200
TAU, AA = fmpq(17, 20), fmpq(77, 50)
RA, RB_ = fmpq(28, 25), fmpq(17, 50)
C5 = arb('1.28') * (2 * arb(fmpq(5, 4)).log()).sqrt()
DEG = 16
X = fmpq_poly([0, 1])


def Q(a, b):
    return fmpq(0) if a + b == 0 else (a * TAU + b * AA) ** 2 / (a + b)


def M(a, b):
    return a * TAU ** 2 + b * AA ** 2


def fq(x):
    """exact rational value of a double"""
    m, e = math.frexp(float(x))
    n = int(m * 2 ** 53)
    return fmpq(n, 1) * fmpq(2) ** (e - 53) if e >= 53 else fmpq(n, 2 ** (53 - e))


def _ub(x):
    """an exact rational >= every point of the ball x"""
    m, e = x.upper().man_exp()
    v = fmpq(int(m)) * (fmpq(2) ** int(e) if e >= 0 else fmpq(1, 2 ** (-int(e))))
    assert arb(v) >= x
    return v


# ------------------------------------------------------------------ exact polynomial bounds (Sturm)

def sturm_seq(p):
    seq = [p, p.derivative()]
    while seq[-1].degree() > 0:
        r = -(seq[-2] % seq[-1])
        if r == 0:
            break
        seq.append(r)
    return seq


def sign_changes(seq, x):
    vals = [q(x) for q in seq]
    vals = [v for v in vals if v != 0]
    return sum(1 for a, b in zip(vals, vals[1:]) if (a > 0) != (b > 0))


def positive_on(p, u, v):
    """True only if p > 0 on [u, v] (exact)."""
    if p.degree() <= 0:
        return p(u) > 0
    if not (p(u) > 0 and p(v) > 0):
        return False
    seq = sturm_seq(p)
    return sign_changes(seq, u) == sign_changes(seq, v)


def float_sup(p, u, v):
    c = [float(x) for x in p.coeffs()]
    if len(c) <= 1:
        return c[0] if c else 0.0
    pts = list(np.linspace(float(u), float(v), 65))
    d = np.polynomial.polynomial.Polynomial(c).deriv()
    for z in d.roots():
        if abs(z.imag) < 1e-9 and float(u) <= z.real <= float(v):
            pts.append(z.real)
    P = np.polynomial.polynomial.Polynomial(c)
    return float(max(P(np.array(pts))))


def proved_sup(p, u, v, stats=None):
    """an exact rational S with p < S on [u, v], proved by Sturm"""
    s = float_sup(p, u, v)
    for eta in (1e-12, 1e-10, 1e-8, 1e-6, 1e-4):
        S = fq(s) + fq(eta * (1 + abs(s)))
        if positive_on(S - p, u, v):
            if stats is not None:
                stats['sup'] += 1
            return S
    raise RuntimeError('proved_sup failed')


# ------------------------------------------------------------------ moment polynomials and the tuple set

@lru_cache(maxsize=None)
def moment_template():
    """P_n as dict {(power of kappa_2, sorted tuple of indices >= 3): integer coefficient}, n <= 16"""
    P = [{(0, ()): 1}, {}]
    for n in range(2, DEG + 1):
        acc = {}
        for i in range(2, n + 1):
            cf = comb(n - 1, i - 1)
            for (e2, al), c in P[n - i].items():
                key = (e2 + 1, al) if i == 2 else (e2, tuple(sorted(al + (i,))))
                acc[key] = acc.get(key, 0) + cf * c
        P.append(acc)
    return P


@lru_cache(maxsize=None)
def tuple_set():
    S = set()
    for Pn in moment_template():
        for (_, al) in Pn:
            if len(al) >= 2:
                for t in range(2, len(al) + 1):
                    S.add(al[:t])
    return sorted(S, key=lambda a: (len(a), a))


def expand_Ephi(c, mu):
    """E phi(Z_W) = sum c_k P_k as a linear form in monomials of kappa_3.. (kappa_2 = mu)"""
    out = {}
    mup = [fmpq(1)]
    for _ in range(DEG):
        mup.append(mup[-1] * mu)
    for k, ck in enumerate(c):
        if ck == 0:
            continue
        for (e2, al), m in moment_template()[k].items():
            out[al] = out.get(al, fmpq(0)) + ck * m * mup[e2]
    return out


# ------------------------------------------------------------------ geometry

def box_of(rec):
    ea, ia, eb, ib = rec
    assert ea == eb and 4 <= ea <= 8 and 0 <= ia < 2 ** ea and 0 <= ib < 2 ** eb, rec
    ha, hb = RA / 2 ** ea, RB_ / 2 ** eb
    return ia * ha, (ia + 1) * ha, ib * hb, (ib + 1) * hb


def box_params(a1, a2, b1, b2):
    mu = 1 - max(Q(a2, b2), fmpq(1, 2)) + M(a2, b2) - M(a1, b1)
    cap = (b2 - b1) * AA ** 2
    R3 = (-AA * mu, TAU * mu + (AA - TAU) * cap)
    R4 = (fmpq(0), AA ** 2 * mu)
    return mu, cap, R3, R4


def cell_of(cl, R3, R4):
    lev, i3, i4 = cl
    assert 0 <= lev <= 6 and 0 <= i3 < 2 ** lev and 0 <= i4 < 2 ** lev, cl
    w3, w4 = (R3[1] - R3[0]) / 2 ** lev, (R4[1] - R4[0]) / 2 ** lev
    return (R3[0] + i3 * w3, R3[0] + (i3 + 1) * w3), (R4[0] + i4 * w4, R4[0] + (i4 + 1) * w4)


def tiles(squares, top):
    """squares = [(level, i, j)] dyadic sub-squares of the unit square at depth `level` (<= top): exact tiling"""
    n = 2 ** top
    grid = np.zeros((n, n), dtype=np.int32)
    for lev, i, j in squares:
        if not (0 <= lev <= top and 0 <= i < 2 ** lev and 0 <= j < 2 ** lev):
            return False
        s = 2 ** (top - lev)
        grid[i * s:(i + 1) * s, j * s:(j + 1) * s] += 1
    return bool((grid == 1).all())


# ------------------------------------------------------------------ ranges (a), Farkas (b)

def pmax(s, lo, hi):
    return max(s * lo, s * hi)


def pmin(s, lo, hi):
    return min(s * lo, s * hi)


def lemma22_upper(g, mu, cap, stats):
    S = proved_sup(g, -AA, TAU, stats)
    return mu * S + cap * max(g(AA) - S, fmpq(0))


def ranges(rm, mu, cap, k3, k4, stats):
    """[L_j, U_j], j = 3..16; rm[j] = [t3, t4, s3, s4]: lower and upper multipliers, kappa_j = int g + s3 k3 + s4 k4"""
    out = {}
    for j in range(3, DEG + 1):
        t3, t4, s3, s4 = [fq(x) for x in rm[str(j)]]
        base = X ** (j - 2)
        gU = base - s3 * X - s4 * X ** 2
        U = lemma22_upper(gU, mu, cap, stats) + pmax(s3, *k3) + pmax(s4, *k4)
        gL = -(base - t3 * X - t4 * X ** 2)
        L = -(lemma22_upper(gL, mu, cap, stats) + pmax(-t3, *k3) + pmax(-t4, *k4))
        if j == 3:
            L, U = max(L, k3[0]), min(U, k3[1])
        if j == 4:
            L, U = max(L, k4[0]), min(U, k4[1])
        out[j] = (L, U)
    return out


def iprod(ivs):
    lo, hi = fmpq(1), fmpq(1)
    for a, b in ivs:
        cands = [lo * a, lo * b, hi * a, hi * b]
        lo, hi = min(cands), max(cands)
    return lo, hi


# ------------------------------------------------------------------ Lagrangian bound (c)

def lagrangian_beta(cert, mu, cap, k3, k4, rg, stats):
    c = [fq(x) for x in cert['coef']]
    E = expand_Ephi(c, mu)
    PT = tuple_set()
    lin = {}

    def add(key, v):
        if v != 0:
            lin[key] = lin.get(key, fmpq(0)) + v

    for al, v in E.items():
        if len(al) == 0:
            add('1', v)
        elif len(al) == 1:
            add(('k', al[0]), v)
        else:
            assert al in PT
            add(('w', al), v)
    mult = cert['mult']
    cm = [max(fq(x), fmpq(0)) for x in mult['cell']]
    # cell rows: k3+ - kappa3, kappa3 - k3-, k4+ - kappa4, kappa4 - k4-
    add('1', cm[0] * k3[1] - cm[1] * k3[0] + cm[2] * k4[1] - cm[3] * k4[0])
    add(('k', 3), -cm[0] + cm[1])
    add(('k', 4), -cm[2] + cm[3])
    rng = {}
    for al in PT:
        rng[al] = iprod([rg[i] for i in al])
    for key, lam in mult['mcc'].items():
        al = tuple(int(x) for x in key.split(','))
        assert al in PT, al
        lam = [max(fq(x), fmpq(0)) for x in lam]
        Xk = ('k', al[0]) if len(al) == 2 else ('w', al[:-1])
        Xm, Xp = rg[al[0]] if len(al) == 2 else rng[al[:-1]]
        Ym, Yp = rg[al[-1]]
        Yk, Wk = ('k', al[-1]), ('w', al)
        # (X - X-)(Y - Y-), (X+ - X)(Y+ - Y), (X+ - X)(Y - Y-), (X - X-)(Y+ - Y), each with w = XY
        rows = [(1, -Xm, -Ym, Xm * Ym), (1, -Xp, -Yp, Xp * Yp), (-1, Xp, Ym, -Xp * Ym), (-1, Xm, Yp, -Xm * Yp)]
        for l, (cw, cy, cx, c0) in zip(lam, rows):
            if l == 0:
                continue
            add(Wk, l * cw)
            add(Yk, l * cy)
            add(Xk, l * cx)
            add('1', l * c0)
    for key, lam in mult['cheb'].items():
        al = tuple(int(x) for x in key.split(','))
        assert al in PT, al
        lam = [max(fq(x), fmpq(0)) for x in lam]
        s = sum(i - 2 for i in al)
        f = mu ** (len(al) - 1)
        add(('abs', s), (lam[0] + lam[1]) * f)
        add(('w', al), -lam[0] + lam[1])
    # collect R(x) on [-A, 0] and [0, tau], R(A)
    Rneg, Rpos = fmpq_poly([0]), fmpq_poly([0])
    RAv = fmpq(0)
    beta = lin.get('1', fmpq(0))
    for key, v in lin.items():
        if key == '1':
            continue
        if key[0] == 'k':
            mono = X ** (key[1] - 2)
            Rneg += v * mono
            Rpos += v * mono
            RAv += v * AA ** (key[1] - 2)
        elif key[0] == 'abs':
            s = key[1]
            Rneg += v * (-X) ** s
            Rpos += v * X ** s
            RAv += v * AA ** s
        else:
            lo, hi = rng[key[1]]
            beta += max(v * lo, v * hi)
    SR = max(proved_sup(Rneg, -AA, fmpq(0), stats), proved_sup(Rpos, fmpq(0), TAU, stats))
    beta += mu * SR + cap * max(RAv - SR, fmpq(0))
    return beta


# ------------------------------------------------------------------ majorant (Lemma 23)

def pois_balls(lam, n):
    lam_a = arb(lam)
    p = [(-lam_a).exp()]
    for k in range(1, n + 1):
        p.append(p[-1] * lam_a / k)
    tail = 1 - sum(p[1:], p[0])
    return p, tail


def majorant_eps(cert, a1, b1, stats):
    c = [fq(x) for x in cert['coef']]
    phi = fmpq_poly(c)
    L = fq(cert['Lt'])
    if not (L >= TAU * a1 + AA * b1):
        return None, 'L < tau a1 + A b1'
    na = int(float(a1) + 14 * math.sqrt(float(a1)) + 30)
    nb = int(float(b1) + 14 * math.sqrt(float(b1)) + 30)
    pa, ta = pois_balls(a1, na)
    pb, tb = pois_balls(b1, nb)
    T = max(_ub(ta) + _ub(tb), fmpq(0))
    var = TAU ** 2 * a1 + AA ** 2 * b1
    e = _ub((arb(T) * arb(var)).sqrt()) if T > 0 else fmpq(0)
    big, small_w, small_c = [], fmpq(0), fmpq(0)
    delta = arb(0)
    for n in range(na + 1):
        for m in range(nb + 1):
            pi = pa[n] * pb[m]
            cnm = TAU * (n - a1) + AA * (m - b1)
            if cnm > L:
                delta += pi * arb(cnm - L)
            if pi.upper() < arb('1e-25'):
                w = _ub(pi)
                small_w += w
                small_c += w * abs(cnm)
            else:
                big.append((cnm, pi))
    delta = 2 * delta + 2 * arb(e)
    Tm = T + small_w
    e2 = e + small_c
    # tails
    sh = phi(X + L) - L - X
    if not all(q >= 0 for q in sh.coeffs()):
        return None, 'right tail'
    shl = phi(-X - L) - L - X - _ub(delta)
    if not all(q >= 0 for q in shl.coeffs()):
        return None, 'left tail'
    # pieces on [-L, L]
    kinks = sorted(set([fmpq(0)] + [-cn for cn, _ in big if -L < -cn < L]))
    pts = [-L] + kinks + [L]
    pieces = []
    for u, v in zip(pts, pts[1:]):
        if u == v:
            continue
        mid = (u + v) / 2
        s_ball, c_ball = arb(0), arb(e2)
        for cn, pi in big:
            if cn + mid >= 0:
                s_ball += pi
                c_ball += pi * arb(cn)
            else:
                s_ball -= pi
                c_ball -= pi * arb(cn)
        sg = 1 if mid > 0 else -1
        s_ball += sg * arb(Tm)
        sm, cmid = fq(float(s_ball.mid())), fq(float(c_ball.mid()))
        # rigorous upper bound of the affine piece on [u, v]
        ds = _ub(abs(s_ball - arb(sm)))
        dc = _ub(abs(c_ball - arb(cmid)))
        cup = cmid + dc + ds * max(abs(u), abs(v))
        pieces.append((u, v, sm, cup))
    ef = max(float_sup(sm * X + cup - phi, u, v) for u, v, sm, cup in pieces)
    for eta in (1e-12, 1e-10, 1e-9, 1e-8, 1e-7):
        eps = max(fq(ef), fmpq(0)) + fq(eta)
        if all(positive_on(phi + eps - (sm * X + cup), u, v) for u, v, sm, cup in pieces):
            stats['pieces'] += len(pieces)
            return eps, None
    return None, 'majorant'


# ------------------------------------------------------------------ one box

def verify_box(rec):
    stats = {'sup': 0, 'pieces': 0}
    a1, a2, b1, b2 = box_of(rec['box'])
    empty = Q(a1, b1) >= fmpq(4, 5) or M(a2, b2) < fmpq(1, 2)
    if rec['status'] == 'empty':
        return {'box': rec['box'], 'ok': bool(empty), 'why': None if empty else 'not empty', 'worst': None,
                'ncert': 0, 'stats': stats}
    if empty:
        pass  # a certified box may be empty; its certificates are still checked
    mu, cap, R3, R4 = box_params(a1, a2, b1, b2)
    cells = [tuple(ct['cell']) for ct in rec['certs']]
    if not tiles(cells, 6):
        return {'box': rec['box'], 'ok': False, 'why': 'cells do not tile', 'worst': None, 'ncert': len(cells),
                'stats': stats}
    worst, kinds = None, {}
    for ct in rec['certs']:
        k3, k4 = cell_of(ct['cell'], R3, R4)
        if ct['status'] == 'empty_farkas':
            if 'farkas' not in ct:
                return {'box': rec['box'], 'ok': False, 'why': 'farkas data missing', 'worst': None,
                        'ncert': len(cells), 'stats': stats, 'keys': list(ct.keys())}
            s3, s4 = [fq(x) for x in ct['farkas']]
            g = -s3 * X - s4 * X ** 2
            Phi = lemma22_upper(g, mu, cap, stats) + pmax(s3, *k3) + pmax(s4, *k4)
            if not Phi < 0:
                return {'box': rec['box'], 'ok': False, 'why': 'farkas', 'worst': None, 'ncert': len(cells),
                        'stats': stats}
            kinds['empty_farkas'] = kinds.get('empty_farkas', 0) + 1
            continue
        rg = ranges(ct['rmult'], mu, cap, k3, k4, stats)
        if any(L > U for L, U in rg.values()):
            kinds['empty_a'] = kinds.get('empty_a', 0) + 1
            continue
        if ct['status'] != 'ok' or len(ct['coef']) != DEG + 1:
            return {'box': rec['box'], 'ok': False, 'why': 'status/degree', 'worst': None, 'ncert': len(cells),
                    'stats': stats}
        beta = lagrangian_beta(ct, mu, cap, k3, k4, rg, stats)
        eps, why = majorant_eps(ct, a1, b1, stats)
        if eps is None:
            return {'box': rec['box'], 'ok': False, 'why': why, 'cell': ct['cell'], 'worst': None,
                    'ncert': len(cells), 'stats': stats}
        tot = beta + eps
        if not arb(tot) < C5:
            return {'box': rec['box'], 'ok': False, 'why': 'beta + eps >= C5', 'cell': ct['cell'],
                    'val': float(tot), 'stored': ct.get('bound'), 'worst': None, 'ncert': len(cells), 'stats': stats}
        kinds['ok'] = kinds.get('ok', 0) + 1
        d = {'cell': ct['cell'], 'mine': float(tot), 'stored': ct.get('bound'), 'beta': float(beta),
             'eps': float(eps)}
        if worst is None or d['mine'] > worst['mine']:
            worst = d
    return {'box': rec['box'], 'ok': True, 'why': None, 'worst': worst, 'ncert': len(cells), 'kinds': kinds,
            'stats': stats}


def main():
    ddir = sys.argv[1]
    nproc = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    limit = int(sys.argv[3]) if len(sys.argv) > 3 else None
    t0 = time.time()
    files = sorted(glob.glob(os.path.join(ddir, 'certs_v1_r*.jsonl')))
    recs = []
    for f in files:
        print('md5', hashlib.md5(open(f, 'rb').read()).hexdigest(), os.path.basename(f))
        recs += [json.loads(l) for l in open(f)]
    print(f'{len(recs)} box records; tuple set P has {len(tuple_set())} tuples (max length '
          f'{max(len(a) for a in tuple_set())})')
    # T: box tiling
    sq = []
    for r in recs:
        ea, ia, eb, ib = r['box']
        assert ea == eb
        sq.append((ea - 4, ia, ib))
    per_initial = {}
    ok_t = True
    for d, i, j in sq:
        if not (0 <= d <= 4 and 0 <= i < 2 ** (4 + d) and 0 <= j < 2 ** (4 + d)):
            ok_t = False
            continue
        s = 2 ** d
        per_initial.setdefault((i // s, j // s), []).append((d, i % s, j % s))
    ok_t = ok_t and len(per_initial) == 256 and all(tiles(v, 4) for v in per_initial.values())
    print(f'T: box tiling of [0, 28/25] x [0, 17/50] by {len(recs)} leaves (256 initial boxes): {ok_t}')
    if limit:
        recs = recs[:limit]
    with Pool(nproc) as pool:
        res = pool.map(verify_box, recs, chunksize=1)
    bad = [r for r in res if not r['ok']]
    nemp = sum(1 for r, x in zip(recs, res) if r['status'] == 'empty')
    ncert = sum(r['ncert'] for r in res)
    kinds = {}
    for r in res:
        for k, v in r.get('kinds', {}).items():
            kinds[k] = kinds.get(k, 0) + v
    worst = [r['worst'] | {'box': r['box']} for r in res if r.get('worst')]
    worst.sort(key=lambda d: -d['mine'])
    st = {'sup': sum(r['stats']['sup'] for r in res), 'pieces': sum(r['stats']['pieces'] for r in res)}
    print(f'{len(res) - nemp} certified boxes with {ncert} cell certificates ({kinds}), {nemp} empty boxes; '
          f'{len(bad)} failures; {st["sup"]} proved sups, {st["pieces"]} majorant pieces; {time.time() - t0:.0f} s')
    for b in bad[:20]:
        print('FAIL', b)
    if worst:
        print(f'worst beta + eps = {worst[0]["mine"]:.7f} < C5 = {float(C5.mid()):.10f} (box {worst[0]["box"]}, cell '
              f'{worst[0]["cell"]}, stored {worst[0]["stored"]})')
        dif = [d['mine'] - d['stored'] for d in worst if d['stored'] is not None]
        print(f'max over boxes of (mine - stored) for the worst cell per box: {max(dif):+.3e}, min {min(dif):+.3e}')
        for d in worst[:8]:
            print(f"  {d['mine']:.7f} (beta {d['beta']:.7f}, eps {d['eps']:.2e}; stored {d['stored']:.7f}) box "
                  f"{d['box']} cell {d['cell']}")
    print('ALL PASS' if (ok_t and not bad) else 'FAILURES')


if __name__ == '__main__':
    main()
