#!/usr/bin/env python3
"""A.34d (RQ-AUD): hostile search against the statement of RQ-D Theorem 13 (evidence only).

Maximises E|Z_K| - max(g(lambda+_0.85(K)), C5) over K = K_S + K_R with K_S = w1 d_x1 + w2 d_x2 (x_i in [0.85, 1.54],
K_S(R) >= 4/5), K_R = a d_y (y in (0, 0.85)) + (b - s2) d_-z (z in (0, 1.54]) + s2 d_0, by Nelder-Mead from random
starts; E|Z_K| by exact Poisson enumeration (a34b_semantic.law). rho^2 = 1 - K_S(R) is kept in [rho2_min, 1/5].
Usage: python3 a34d_hostile.py [starts] [seed] [rho2_min]
"""
import json
import math
import sys

import numpy as np
from scipy.optimize import minimize

from a34b_semantic import E_abs, law

TH, AA = 0.85, 1.54
C5 = 1.28 * math.sqrt(2 * math.log(1.25))


RHO_MIN = 0.0


def sig(t):
    return 1 / (1 + math.exp(-max(-60.0, min(60.0, t))))


def build(p):
    x1 = TH + (AA - TH) * sig(p[0])
    x2 = TH + (AA - TH) * sig(p[1])
    f = sig(p[2])
    rho2 = RHO_MIN + (0.2 - RHO_MIN) * sig(p[3])
    fa = sig(p[4])
    y = 0.05 + (TH - 0.05 - 1e-9) * sig(p[5])
    z = 0.05 + (AA - 0.05) * sig(p[6])
    fs = sig(p[7])
    V_ = 1 - rho2
    a = rho2 * fa
    b = rho2 - a
    S = [(x1, V_ * f), (x2, V_ * (1 - f))]
    R = [(y, a), (-z, b * (1 - fs))]
    return S, R, b * fs, a, b


def objective(p):
    S, R, s2, a, b = build(p)
    S = [(x, w) for x, w in S if w > 1e-14]
    R = [(x, w) for x, w in R if w > 1e-14]
    vS, pS = law(S)
    vR, pR = law(R)
    vals = (vS[:, None] + vR[None, :]).ravel()
    probs = (pS[:, None] * pR[None, :]).ravel()
    EZ = E_abs(vals, probs, math.sqrt(max(s2, 0)))
    L = sum(w / x ** 2 for x, w in S)
    tgt = max(2 * math.sqrt(L) * math.exp(-L), C5)
    return EZ - tgt, dict(EZ=EZ, L=L, target=tgt, rho2=a + b, a=a, b=b, s2=s2, S=S, R=R)


def main():
    global RHO_MIN
    starts = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 7
    RHO_MIN = float(sys.argv[3]) if len(sys.argv) > 3 else 0.0
    rng = np.random.default_rng(seed)
    best = None
    for k in range(starts):
        p0 = rng.normal(0, 2, 8)
        res = minimize(lambda p: -objective(p)[0], p0, method='Nelder-Mead',
                       options=dict(maxiter=1500, xatol=1e-7, fatol=1e-12))
        val, info = objective(res.x)
        if best is None or val > best[0]:
            best = (val, info)
        if k % 10 == 9:
            print(json.dumps(dict(start=k + 1, best_excess=best[0], rho2=best[1]['rho2'], L=best[1]['L'])))
            sys.stdout.flush()
    v, info = best
    print(json.dumps(dict(starts=starts, seed=seed, rho2_min=RHO_MIN, max_excess=v, **{k: info[k] for k in
                                                                    ('EZ', 'L', 'target', 'rho2', 'a', 'b', 's2')},
                          S=[[float(x), float(w)] for x, w in info['S']], R=[[float(x), float(w)] for x, w in info['R']])))
    print('NO COUNTEREXAMPLE FOUND' if v <= 1e-12 else 'COUNTEREXAMPLE CANDIDATE')


if __name__ == '__main__':
    main()
