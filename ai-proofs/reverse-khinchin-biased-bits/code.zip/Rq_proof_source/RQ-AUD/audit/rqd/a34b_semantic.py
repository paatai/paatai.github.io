#!/usr/bin/env python3
"""A.34b (RQ-AUD): semantic test of my verifier a34_bandstar_verify.py against exact values (evidence, not proof).

For random finitely supported probability Kolmogorov measures K on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, the
law of Z_K = Y + W is enumerated exactly (Poisson counts, Gaussian part in closed form; float64, tail mass < 1e-16).
The verifier's own code is then run on the smallest grid square / box containing (a, b, L, m) and every arb ingredient
it would use is compared with its exact value:
  c_B >= 2E(W - m)_+,  c_C >= 2E(-W - (2 theta - m))_+,  each direct option O1-O4 >= E phi(J - m),
  M + e^{-L1} c_B + TE O' + P2(L2) c_C >= E|Z_K| for every option,
  slope pieces: each linear term >= the quantity it bounds (O5: minus (1 - w) kappa), Lemma 12, and
  sqrt(V) g(L) + a A + b B >= E|Z_K|;
and the conclusion E|Z_K| <= max(g(L), C5) of Theorem 13 is checked.
Usage: python3 a34b_semantic.py [n] [seed] [mode]   (mode: band | dirac | edge)
"""
import json
import math
import sys
from fractions import Fraction as F

import numpy as np
from scipy.special import erf, ndtr

import a34_bandstar_verify as V

TH, AA = 0.85, 1.54
C5 = V.C5f
ISQ2PI = 1 / math.sqrt(2 * math.pi)


def pois(lam, eps=1e-17):
    n = [0]
    p = [math.exp(-lam)]
    while True:
        k = n[-1] + 1
        p.append(p[-1] * lam / k)
        n.append(k)
        if k > lam and p[-1] < eps:
            break
    return np.array(n, float), np.array(p)


def law(atoms):
    """Exact law of sum x (N_x - lam_x) over atoms [(x, w)], as (values, probs)."""
    vals, probs = np.zeros(1), np.ones(1)
    for x, w in atoms:
        lam = w / (x * x)
        n, p = pois(lam)
        vals = (vals[:, None] + x * (n[None, :] - lam)).ravel()
        probs = (probs[:, None] * p[None, :]).ravel()
        keep = probs > 1e-22
        vals, probs = vals[keep], probs[keep]
    return vals, probs


def E_abs(vals, probs, s):
    if s == 0:
        return float(np.sum(probs * np.abs(vals)))
    return float(np.sum(probs * (vals * erf(vals / (s * math.sqrt(2))) + 2 * s * ISQ2PI * np.exp(-vals ** 2 / (2 * s * s)))))


def E_plus(vals, probs, s, t):
    """E(v + sG - t)_+."""
    c = vals - t
    if s == 0:
        return float(np.sum(probs * np.maximum(c, 0)))
    return float(np.sum(probs * (c * ndtr(c / s) + s * ISQ2PI * np.exp(-c * c / (2 * s * s)))))


def E_plus2(vals, probs, s, t):
    """E(v + sG - t)_+^2."""
    c = vals - t
    if s == 0:
        return float(np.sum(probs * np.maximum(c, 0) ** 2))
    return float(np.sum(probs * ((c * c + s * s) * ndtr(c / s) + c * s * ISQ2PI * np.exp(-c * c / (2 * s * s)))))


def random_K(rng, mode):
    if mode == 'dirac':
        rho2 = rng.uniform(0, 0.02) * rng.choice([1, 0.3, 0.05])
        x = rng.uniform(1.25, 1.54)
        S = [(x, 1 - rho2)] if rng.random() < 0.5 else [(x, (1 - rho2) * 0.97), (min(1.54, x + rng.uniform(0, 0.05)),
                                                                                (1 - rho2) * 0.03)]
    else:
        rho2 = rng.uniform(0, 0.2) if mode == 'band' else 0.2 - rng.uniform(0, 0.01)
        V_ = 1 - rho2
        k = rng.integers(1, 3)
        xs = rng.uniform(TH, AA, k)
        if rng.random() < 0.2:
            xs[0] = TH
        ws = rng.dirichlet(np.ones(k)) * V_
        S = list(zip(xs, ws))
    fa = rng.random()
    a = rho2 * fa
    b = rho2 - a
    R = []
    if a > 0:
        R.append((rng.uniform(0.3, TH - 1e-9), a))
    sig2 = 0.0
    if b > 0:
        if rng.random() < 0.4:
            sig2 = b * rng.random()
        if b - sig2 > 0:
            R.append((-rng.uniform(0.3, AA), b - sig2))
    return S, R, sig2, a, b


def grid_lo_hi(x, G):
    lo = F(math.floor(x * G), G)
    return lo, lo + F(1, G)


def check_one(S, R, sig2, a, b, out, mode):
    V_ = sum(w for _, w in S)
    L = sum(w / x ** 2 for x, w in S)
    m = sum(w / x for x, w in S)
    rho2 = a + b
    s = math.sqrt(sig2)
    vS, pS = law(S)
    vR, pR = law(R)
    vals = (vS[:, None] + vR[None, :]).ravel()
    probs = (pS[:, None] * pR[None, :]).ravel()
    EZ = E_abs(vals, probs, s)
    cB_ex = 2 * E_plus(vR, pR, s, m)
    cC_ex = 2 * E_plus(-vR, pR, s, 2 * TH - m)
    phi = lambda y: 2 * E_plus(-vR, pR, s, y)
    Ophi = sum((w / x ** 2) / L * phi(x - m) for x, w in S)
    mu1 = m / L
    sigJ2 = max(0.0, (L * V_ - m * m) / (L * L))
    tgt = max(V.g_f(L), C5)
    rec = dict(mode=mode, a=a, b=b, L=L, m=m, V=V_, EZ=EZ, target=tgt, slack=tgt - EZ)
    viol = []
    if EZ > tgt + 1e-12:
        viol.append(('theorem', EZ - tgt))
    # Proposition 9 with the exact ingredients
    Fpt = 2 * m * math.exp(-L) + math.exp(-L) * cB_ex + L * math.exp(-L) * Ophi + (1 - math.exp(-L) * (1 + L)) * cC_ex
    if Fpt < EZ - 1e-12:
        viol.append(('prop9', Fpt - EZ))
    # the verifier on the smallest grid square / box containing the point
    a1, a2 = grid_lo_hi(a, 2 ** 13)
    b1, b2 = grid_lo_hi(b, 2 ** 13)
    L1, L2 = grid_lo_hi(L, V.GL)
    m1, m2 = grid_lo_hi(m, V.GM)
    if a2 + b2 > V.RM and a1 + b1 >= V.RM:
        return None
    sq = V.Square(a1, a2, b1, b2)
    if V.infeasible(L1, L2, m1, m2, sq.Vlo, sq.Vhi):
        viol.append(('feasible point declared infeasible', 0))
    P = sq.direct(L1, L2, m1, m2, parts=True)
    up = lambda x: float(x.upper())
    for nm, val, ex in (('cB', P['cB'], cB_ex), ('cC', P['cC'], cC_ex)):
        if up(val) < ex - 1e-13:
            viol.append((nm, up(val) - ex))
    gaps = {}
    for lab, O in P['opts'].items():
        gaps[lab] = up(O) - Ophi
        if up(O) < Ophi - 1e-13:
            viol.append((lab, up(O) - Ophi))
        Fb = P['M'] + P['e1'] * P['cB'] + P['TE'] * O + P['P2'] * P['cC']
        if up(Fb) < EZ - 1e-13:
            viol.append(('Fbox_' + lab, up(Fb) - EZ))
    rec['opt_gaps'] = gaps
    rec['Fbox_best_minus_EZ'] = min(up(P['M'] + P['e1'] * P['cB'] + P['TE'] * O + P['P2'] * P['cC']) for O in
                                    P['opts'].values()) - EZ
    # slope pieces
    if a2 + b2 <= V.RS and m2 < V.TH:
        r1 = a1 + b1
        r2 = min(a2 + b2, 1 - m1 * m1 / L2)
        if r2 >= r1:
            Q = sq.piece(L1, L2, m1, m2, r1, r2, parts=True)
            if Q == 'empty':
                viol.append(('feasible piece declared empty', 0))
            elif Q is not None:
                (aB_, bB_), (aO, bO), (aC_, bC_) = Q['terms']
                lB = up(aB_) * a + up(bB_) * b
                lC = up(aC_) * a + up(bC_) * b
                lO = up(aO) * a + up(bO) * b
                if lB < cB_ex - 1e-13:
                    viol.append(('lin_cB', lB - cB_ex))
                if lC < cC_ex - 1e-13:
                    viol.append(('lin_cC', lC - cC_ex))
                kap = Q['kap']
                d = mu1 - TH
                w = d * d / (d * d + sigJ2) if d > 0 else 0.0
                extra = (1 - w) * float(kap) if kap is not None else 0.0
                if lO + extra < Ophi - 1e-13:
                    viol.append(('lin_O_' + Q['rec'], lO + extra - Ophi))
                main = 2 * m * math.exp(-L) + L * math.exp(-L) * extra
                if main > math.sqrt(V_) * V.g_f(L) + 1e-13:
                    viol.append(('lemma12' if kap is not None else 'F4', main - math.sqrt(V_) * V.g_f(L)))
                Fs = math.sqrt(V_) * V.g_f(L) + up(Q['Aco']) * a + up(Q['Bco']) * b
                if Fs < EZ - 1e-13:
                    viol.append(('Fslope', Fs - EZ))
                rec['slope'] = dict(rec=Q['rec'], Mx=float(Q['Mx']), half_gmin=float(Q['gmin'].lower()) / 2,
                                    Fs_minus_EZ=Fs - EZ)
                if kap is not None:
                    h = Q['h5']
                    j0 = TH - m
                    ex = E_plus2(-vR, pR, s, j0 - h) / (2 * h)
                    kk = max(0.0, h - j0) ** 2 / (2 * h)
                    if ex > kk + rho2 / (2 * h) + 1e-13:
                        viol.append(('chiC(j0) <= kappa + rho2/(2h)', ex - kk - rho2 / (2 * h)))
    rec['viol'] = viol
    out.append(rec)
    return rec


def main():
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    seed = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    mode = sys.argv[3] if len(sys.argv) > 3 else 'band'
    rng = np.random.default_rng(seed)
    out = []
    while len(out) < n:
        S, R, sig2, a, b = random_K(rng, mode)
        check_one(S, R, sig2, a, b, out, mode)
    bad = [r for r in out if r['viol']]
    summ = dict(mode=mode, seed=seed, n=len(out), with_violations=len(bad),
                min_theorem_slack=min(r['slack'] for r in out),
                min_Fbox_minus_EZ=min(r['Fbox_best_minus_EZ'] for r in out),
                min_opt_gap={lab: min(r['opt_gaps'][lab] for r in out if lab in r['opt_gaps'])
                             for lab in ('O1', 'O2', 'O3', 'O4') if any(lab in r['opt_gaps'] for r in out)},
                slope_tested=sum(1 for r in out if 'slope' in r),
                min_Fslope_minus_EZ=min([r['slope']['Fs_minus_EZ'] for r in out if 'slope' in r], default=None),
                slope_recipes=sorted({r['slope']['rec'] for r in out if 'slope' in r}))
    print(json.dumps(summ))
    for r in bad[:10]:
        print('VIOLATION', json.dumps(r))
    print('ALL CHECKS PASSED' if not bad else 'FAILURES FOUND')


if __name__ == '__main__':
    main()
