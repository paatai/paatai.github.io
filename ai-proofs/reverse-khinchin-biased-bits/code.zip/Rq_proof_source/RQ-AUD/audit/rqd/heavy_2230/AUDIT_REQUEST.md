# RQ-D audit requests (for RQ-AUD)

Store copy: `/cursor/stores/bot/rq/RQ-D/`. Second request first; the first request (17:18 UTC, rated VALID in A.32
at 18:17 UTC) is kept below unchanged.

# Second request (filed 2026-10-22 19:01 UTC): Theorem 13, the ID* band lemma at theta = 0.85, A = 1.54

Addendum 19:07 UTC: Corollary 15 has been added, as item 7 (D20). It was suggested by RQ-C at 19:00 UTC. Because
of it, the md5s of MAIN_RESULT.tex, MAIN_RESULT.pdf and CLAIMS.md in the table below are updated. Nothing else in
Section 6, the code or the outputs has changed.

## What is to be audited

Section 6 of `MAIN_RESULT.pdf` ("The band lemma in the form needed at finite q") and the two additions to Section 4
that it uses. CLAIMS.md ids in brackets.

| # | Statement (MAIN_RESULT.pdf) | CLAIMS | Kind |
|---|---|---|---|
| 1 | Lemma 7(c): two-point mean-variance bound, and the box version (the bound is nondecreasing in sigma^2 for convex nonincreasing psi) | D16 | elementary |
| 2 | The list (O1)-(O4) of admissible O' after Proposition 9 | D10, D16 | elementary |
| 3 | (O5) (Section 6, before Lemma 12) and Lemma 12 (absorption) | D17 | elementary |
| 4 | Theorem 13: if K is a finitely supported probability on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5, then E\|Z_K\| <= max(g(lambda+_0.85(K)), C_5); mirror for K([-1.54, -0.85]) >= 4/5 | D18 | computer-assisted (arb) |
| 5 | Section 6.1: the certified computation (squares, boxes, direct check, slope check with the linear coefficients and tests (T1)-(T3), result) against the code | D18 | code |
| 6 | Corollary 14: given E\|Z_K\| <= C_5 on the far region {K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5}, ID*(C_5) holds for every finitely supported probability on [-1.54, 1.54] | D19 | trivial |
| 7 | Corollary 15 (added 19:07 UTC): (a) Theorem 13 for all probability K on [-1.54, 1.54], by approximation; (b) C5 reduces to the far region of Theorem 13 on [-sqrt2, sqrt2], via A.13a as in Corollary 11; and the hypothesis of Corollary 14 implies C5 | D20 | uses A.13a |

How it is used: with A.26 (C19), A.28 (C15) and A.25 (MAIN-5), Corollary 14 leaves only the far-region inequality
(RQ-B's part, open) for Conjecture S at all q. RQ-B accepted this split (theta = 0.85, rho0^2 = 1/5, A = 1.54, mass
form) at 18:15 UTC.

**Changes to the text audited in A.32** (diff against `audit/snapshots/RQ-D_MAIN_RESULT_1722.tex`). There are no
changes to Lemmas 1-6 and 8, Remark 5, Proposition 9 and its proof, Theorem 10, Corollary 11 or Section 5.1. The
changes are:
- the abstract;
- Lemma 7 gains part (c) and its proof (insertions after old lines 213 and 218);
- the list (O1)-(O4) is inserted after Proposition 9 (after old line 268);
- the old "Outlook" section (old lines 371-384) is replaced by Section 6.

Numbering is unchanged up to Corollary 11.

## Files (md5)

| File | md5 |
|---|---|
| MAIN_RESULT.tex | bba5c599262882085752622923179a03 |
| MAIN_RESULT.pdf | 3137370e468b5b4ad85889c49b1f1780 |
| CLAIMS.md | aa4587a5ab6cb94ecc50ecac06d103b3 |
| scripts/verify_bandstar.py (the certificate) | b5b55ceec828f01debc6c1a422e7270f |
| outputs/verify_bandstar.txt (recorded run, 18:39:45-18:52:59 UTC) | c36c17e52bb29948ebd55119097e2732 |
| outputs/verify_bandstar_squares.jsonl (one line per square) | 73a8da42b2c739cc01713566199d7250 |
| outputs/verify_bandstar_env.txt (versions, md5, start/end) | 2d40d19e7d642ef687367b1c8dd9b8fa |
| outputs/verify_bandstar_run2.txt (earlier run, same counts) | e05b2c0c0c2dd3ad7f9ce4e38d782ef5 |
| scripts/verify_bandstar_controls.py (controls, not proof) | 7427d4c4be4ccd5d30e804360336f06f |
| outputs/verify_bandstar_controls.txt | 5b51fc49a9678954a7da23742863aacb |
| scripts/bandstar_soundness2.py (float test, evidence only) | 88c63664e70fa8378cf795f1006f499f |
| scripts/idlib.py (exact laws for the float test) | b388f50f6777523824788911843f53d7 |
| outputs/bandstar_soundness2.txt (400 band K, rho^2 <= 1/5) | e7df91de74c93163241975767732f72e |
| outputs/bandstar_soundness2_dirac.txt (400 near-Dirac K, rho^2 <= 1/50) | 4d4e5cd11695cecc8201c09afa7aad3a |

The earlier run (18:25-18:38 UTC) used a copy of the script with md5 c3fe3289db0d505d20483e1046c3b751. It differs
from the recorded file in these places only:
- the docstring;
- an unused constant `RLINF` and an unused argument `lin` of `Tables`;
- one `flog.flush()`;
- the control shift `TGT_SHIFT`. This is 0 by default; with 0, `target_lo` and test (T1) are unchanged.

## How to reproduce

Requirements: python 3.12, python-flint 0.9.0 (arb), numpy, scipy (versions in `outputs/verify_bandstar_env.txt`).

```
python3 scripts/verify_bandstar.py all 0.0078125 8 outputs/verify_bandstar_squares.jsonl   # 8 processes, about 13 min
python3 scripts/verify_bandstar.py one 0,0.0078125,0,0.0078125 full                         # one square, prints its JSON
PYTHONPATH=scripts python3 scripts/verify_bandstar_controls.py 8                          # controls, about 1 min
cd scripts && python3 bandstar_soundness2.py 0.2 400 && python3 bandstar_soundness2.py 0.02 400 dirac
```

Expected result: the final JSON line of the first command has levels with `not_certified` 215, 102, 20, 0 (sides
1/128 to 1/1024), `"certified": 1339`, `"lam_m_boxes": 14894034` and no key `"uncertified"`.

## Map from the proof to the code (`scripts/verify_bandstar.py`)

- **Target and C_5.** `target_lo` is max(min(g(L1), g(L2)), C_5) minus the control shift (0 by default). `C5` is
  the ball 2 sqrt(2 ln(5/4)) * 16/25, with theta = 85/100 and A = 154/100 exact, at 80 bits.
- **Covering.**
  - `ab_boxes` and `run_all`: the squares and their refinement; children with a1 + b1 >= 1/5 are dropped.
  - `verify_ab_box`: the V range, the clipped corner (a-bar, b-bar) and r^2, and whether the slope check applies.
  - `run_boxes`: the (Lambda, m) boxes and their bisection.
- **Parameter domain.** `feasible` tests (F1)-(F5). `jump_geometry` gives mu_lo, mu_hi, d_lo, s^2 (the exact
  formula and Bhatia-Davis), w' and u'.
- **Corner costs** (class `Tables`):
  - `cB`: c_B at m1;
  - `cC2`: c_C at 2 theta - m2;
  - `phi1`, `phi2`: phi at theta - m2 (with the option -2y + chi^B_h(-y)) and at A - m2;
  - `chiC_y`: chi^C on the grid y = theta - k/4096, for (O3);
  - `chiB_t`: chi^B on the grid t = j/4096, for (O2).
- **Direct check.** `check_direct`, with the options in the order (O1), (O3), (O4), (O2).
- **Linear coefficients.**
  - `lin_B`, `lin_C`: the two displayed bounds of Section 6.1, with the validity tests on c.
  - `r_eff`: r = min(ceil(4096 r2)/4096, 1/50).
  - `lin_options_point`: adds the Cauchy-Schwarz coefficient 1/(2t).
  - `best_pair`: Pareto reduction in floats; the values stay arb.
- **Slope check** (`check_slope`):
  - `options`: (O1) is the chord with the coefficientwise max-fix. Then come (O3), (O4), and (O5) with the condition
    kappa <= d_lo^2 sqrt(L1/(1 - r1)).
  - `combine`: chooses the combination in floats and recomputes Mx in arb.
  - `ok`: tests (T1)-(T3). (T1) is skipped when the control shift is nonzero, and (T3) has an (O5) form.
  - `rec`: bisects rho^2 at most 6 times and skips pieces with m1^2 > L2 (1 - r1).

## Points I would check first (my own list of risks)

1. **(O5) uses two versions of Lemma 7(c).** Lemma 12 needs the exact weight w. The code bounds (1 - w) rho^2/(2h)
   by (1 - w') rho^2/(2h), using w >= w' (s^2 >= sigma_J^2 and d >= d_lo). It bounds the far term by
   chi^C_h(theta - m2 + d_lo) >= chi^C_h(mu1 - m), rounded down to the grid. It does not use u', which belongs to the
   box version with s^2. An earlier draft did use u' there. I found this mix in review and fixed it before the
   recorded run.
2. **The kappa condition of Lemma 12.** kappa <= d_lo^2 sqrt(L1/(1 - r1)) implies kappa <= D^2 sqrt(Lambda/V), with
   D = d_lo <= d, Lambda >= L1 and V <= 1 - r1. (O5) is offered only if d_lo > 0.
3. **(T3) for (O5).** If m2 <= sqrt(Lambda V):
   e^{-Lambda} q(m) <= e^{-L1}(2 m2 + kappa max(0, L2(1 - r1) - m2^2)/(L1 d_lo^2)), since q is nondecreasing up to
   its vertex >= sqrt(Lambda V). Otherwise e^{-Lambda} q(m) <= sqrt(V) g(Lambda) <= M.
4. **The linear bounds.**
   - Validity conditions: c = t - h > 0 and r/theta <= 2(theta - c) on the B side, r/A <= 2(A - c) on the C side.
   - The n = 0 term, and the tail bounded by twice the n = 12 term with c = 0.
   - r_eff >= rho^2 on the piece. This holds because r2 <= a2 + b2 < 1/50 whenever the slope check is used.
5. **Nonnegativity.** All coefficients and O'-bounds are >= 0. This is needed to replace e^{-Lambda},
   Lambda e^{-Lambda} and P_2(Lambda) by their box maxima.
6. **(T2).** F <= g-hat + rho^2 (Mx - g-hat/2) uses 1 - rho^2/2 > 0 and g(Lambda) <= g-hat.
7. **Squares crossing a + b = 1/5.** Here the code uses the clipped corner (a-bar, b-bar), r^2 = min(a-bar + b-bar, 1/5)
   and V >= 4/5.
8. **The direct check's (O2).** It uses Gamma'' <= 1/h (since chi^B_h'' = P/h), the t-grid point rounded down
   (t <= -(mu_hi - m1)) and s^2 >= sigma_J^2.
9. **NaN in python-flint.** `x**2` returns NaN for a ball with midpoint exactly 0. Every comparison with NaN is
   False, which can only make a check fail; in `feasible`, False means "keep the box". `lin_B` and `lin_C` use
   `**2` on theta n - c and A n - c. In `check_slope`, kappa is computed as e*e, and only when e > 0.
10. **Floats choose, arb decides.** h, the option order, `best_pair` and `combine` are float choices. Every
    inequality that certifies something is an arb comparison.

## Controls and float evidence (not proof; MAIN_RESULT Section 6.1)

- **Controls** (target lowered by a shift, no refinement, (T1) disabled):
  - The origin squares [0, 1/256]^2 and [0, 1/128]^2 are certified at shift 0 and fail at shift 0.0005. The first
    failure is on the Dirac curve at Lambda = 0.5632, m = 3074/4096, where C_5 - g(Lambda) is in
    [0.000496, 0.000502] and F = g at rho^2 = 0.
  - The 80 squares of side 1/1024 all lie along a + b = 1/5. At shift 0.001, 63 of them fail.
- **Float soundness of every ingredient.**
  - No bound is below its exact value by more than 1e-15. The two equality cases are at -8.9e-16 and -2.2e-16.
  - min(F - E\|Z_K\|) = 2.1e-4 and min(target - F) = 5.8e-4 on 400 band K.
  - The same two quantities are 1.5e-7 and 7.3e-7 on 400 near-Dirac K.

# First request (filed 2026-10-22 17:18 UTC; rated VALID in A.32, 18:17 UTC)

Erratum 17:35 UTC (A.32 text nit): the md5 printed for `scripts/band_soundness.py` was garbled (it was the md5
of `outputs/verify_band_S.txt` with "OUND" appended). The correct value, now in the table, is
5aad81599fde76b2e01ef699237a50f0. Nothing else in this file changed.

## What is to be audited

Theorem 10 (band lemma for C5) and Corollary 11 of `MAIN_RESULT.pdf`, with the lemmas they use. CLAIMS.md ids in
brackets.

| # | Statement (MAIN_RESULT.pdf) | CLAIMS | Kind |
|---|---|---|---|
| 1 | Lemma 3: OR-region identity with residual, **fix f1 of A.30 applied** (K_S != 0 in the hypothesis; used for P(Y = 0) = 0 and in the equality clause) | D2 | re-check of a fix |
| 2 | Lemma 2: conditional form l(y) = E\|y + W\| (convex, 1-Lipschitz, two exact identities, \|y\| <= l <= sqrt(y^2 + rho^2)) | D6 | elementary |
| 3 | Lemma 4: comparison lemma, E psi(Z_K) <= E psi(Z_{T#K}) for T(x) >= x and psi'' nondecreasing, bounded | D7 | new, analytic |
| 4 | Remark 5: counterexample for psi = (w - t)_+, and minimality of psi_{t,h} (stated "not used") | D7 | optional |
| 5 | Lemma 6: stop-loss bounds (i)-(iv) through the comparison laws W_B, W_C | D8 | analytic |
| 6 | Lemmas 7, 8: one-jump bounds (chord, variance) and feasibility F1-F5 | D9 | elementary |
| 7 | Proposition 9: band bound (F) and its second form | D10 | analytic |
| 8 | Theorem 10: K probability on [-sqrt2, sqrt2], K([1, sqrt2]) >= 9/10 (or mirror) => E\|Z_K\| <= sqrt(2/e); finitely supported equality only at delta_{+-sqrt2} | D11 | computer-assisted (arb) |
| 9 | Corollary 11: C5 <= the far region {K([1, sqrt2]) < 9/10 and K([-sqrt2, -1]) < 9/10} on [-sqrt2, sqrt2] | D12 | uses A.13a |

Not for audit (labelled NUMERICAL / in progress): Section 6 (ID* band at theta = 0.85, D13), D14, D15.

## Files (md5)

| File | md5 |
|---|---|
| MAIN_RESULT.tex | 4df86775aaa4b0e44d1ef733cefaeb16 |
| MAIN_RESULT.pdf | f69703ee53c78ad68fa2195961f4afca |
| CLAIMS.md | 5802cb5d470efa1b2548a5ab5b037a56 |
| scripts/verify_band.py | b8164113fd41949dbb3c3fe9a7b5d119 |
| outputs/verify_band_S.txt | 00d374efd595e521d5a41e2a3d23e6cf |
| outputs/verify_band_B.txt | 4b010e6bcfdad07098eb15938146123b |
| outputs/verify_band_env.txt | c1f8fd2706ac0f1221ead53f253c2235 |
| scripts/band_soundness.py (float test, evidence only) | 5aad81599fde76b2e01ef699237a50f0 |

## How to reproduce the certificate

Requirements: python 3.12, python-flint 0.9.0 (arb), numpy, scipy (versions in `outputs/verify_band_env.txt`).

```
python3 scripts/verify_band.py S     # Part S, 0 < rho^2 <= 1/50: about 3 s, prints one JSON line
python3 scripts/verify_band.py B     # Part B, 1/50 <= rho^2 <= 1/10: 8 processes, about 95 s
```

Expected: Part S `"nfail": 0`; Part B a final JSON line whose last level has `"nbad": 0` and no key
`"uncertified"`. Recorded results: Part S 1098 boxes, 0 failures (2.3 s); Part B side 0.00390625: 341 squares, 85 not certified; side 0.001953125: 333 squares, 3 not certified; side 0.0009765625: 12 squares, 0 not certified; 598 squares certified, 1,339,228 (Lambda, m) boxes, 95 s.

## Map from the proof to the code

- F of Theorem 10: `check_box` (Part B) and `check_S` (Part S); target `T = sqrt(2/e)` in arb.
- chi^B_h, chi^C_h (Lemma 6 (i)): `chiB`, `chiC` via `lattice_sum` (14 Poisson terms, exact Gaussian stop-loss `Q`,
  geometric tail bound with ratio lam (N+2)/(N+1)^2), h chosen in floats (`make_tables`), then evaluated in arb.
- Cauchy-Schwarz costs (Lemma 6 (ii)): `cs`.
- 2 m e^{-Lambda} on a box with m^2 <= Lambda V (Lemma 3, F4): `main_max` (unimodality of g).
- Chord for O' (Lemma 7 (a), Prop. 9 second form): `chord`, which replaces the upper value at y = 1 - m by
  max(g1, g2) so that the bounding chord is nonincreasing in mu1 (change of 17:11 UTC; the certificate was re-run
  after it).
- Infeasible boxes (Lemma 8, F1-F5 with theta = 1, A = sqrt2): first two `if` blocks of `check_box` / `check_S`.
- Monotonicity in (a, b) used to evaluate all costs at the corner (a2, b2) of an (a, b) square: Lemma 6 (iv).
- Part S linear bounds chi <= a alpha + b beta: `lin_coeffs_B`, `lin_coeffs_C` (derivation in Section 5.1, Part S).

## Points I would check first (my own list of risks)

1. Lemma 4, Step 1: the right derivative of s -> E psi(X + Z_{sL}) (no-jump, one-jump and two-jump events) and the
   joint continuity used for Psi'(t). Step 2: the mollification limit.
2. Lemma 6 (i): T(x) = theta on (0, theta), 0 on [-A, 0] (resp. A on [0, A], 0 on (-theta, 0) after reflection);
   the atom at 0 (Gaussian part) is in b and T(0) = 0 (resp. A).
3. Proposition 9: the n >= 2 sum equals m Lambda e^{-Lambda} (uses E Y = 0 and Lambda mu1 = m); no sign condition on
   theta - m or 2 theta - m is needed.
4. Section 5.1, Part S: the n = 0 term bound b tau(c/sqrt r), and (n - a - c)^2 <= (n - c)^2 for 0 <= a <= 2(n - c)
   (c = m - h < 0.95 because h >= 0.05); the C-side analogue needs sqrt2 n - c > 0 (c <= 1.35).
5. Part B: monotonicity directions (e^{-L1}, L2 e^{-L2}, P2(L2) on Lambda <= 1; c_B at m1; c_C and the chord endpoint
   values at m2).
6. Theorem 10, general K: approximation by finitely supported K_n with K_n([1, sqrt2]) >= 9/10 (cells inside
   [1, sqrt2] and inside [-sqrt2, 1)), and E|Z_{K_n}| -> E|Z_K| (A.8 / A.26(e) continuity step).
7. Corollary 11: x <= 2(1-u)/R and 1 - u <= R/sqrt2 (A.13a) give x <= sqrt2; mirrored for x < 0.

## Controls (recorded in MAIN_RESULT Section 5.1)

r = 0.06 in Part S: 426,627 failing boxes; target sqrt(2/e) - 0.002 in Part S: 5,750 failures; Part B at target
sqrt(2/e) - 0.001: 110 of 1281 squares fail at side 1/512. Float soundness of F on 400 random K
(`scripts/band_soundness.py`): F - E|Z_K| >= 1.5e-5 and sqrt(2/e) - F >= 3.2e-5.
