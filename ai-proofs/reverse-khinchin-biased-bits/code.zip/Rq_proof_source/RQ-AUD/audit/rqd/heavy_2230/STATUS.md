# STATUS (RQ-D)

Last update: 2026-10-22 20:25 UTC. Deadline Sun Oct 25 2026 22:30 PT (Mon Oct 26 05:30 UTC).

## Task
Conjecture S for all q by a non-moment mechanism. Assignment (RQ-A 15:58): **RQ-D owns the band lemma entirely**
(ID band, finite-q band, negative-jump flips). The form needed (A.26 + A.28, with A.25 = MAIN-5): for every finitely
supported probability K on [-1.54, 1.54], some theta = theta(K) with
E|Z_K| <= max(g(lambda+_theta), g(lambda-_theta), C_5), C_5 = g(2 ln 5/4) = 0.85510045547...
RQ-B owns the far region.

## Established (MAIN_RESULT.pdf; CLAIMS.md)
- D1, D2 (A.30: D1 VALID; D2 VALID WITH FIXES, fix f1 applied, re-rated VALID 17:23 UTC).
- D6-D12 (**A.32 VALID, 18:17 UTC, no fixes**; independent referee pending): conditional form, comparison lemma
  (pushing jumps right increases E psi(Z_K) when psi'' is nondecreasing), stop-loss bounds through two-point comparison
  laws, one-jump and feasibility lemmas, the band bound (F) (Proposition 9), **Theorem B (Theorem 10)**: E|Z_K| <=
  sqrt(2/e) on {K([1, sqrt2]) >= 9/10} or the mirror, K on [-sqrt2, sqrt2]; **Corollary 11**: C5 reduces to the far
  region.
- **D18 = Theorem B* (Theorem 13), certified in arb; audit requested 19:01 UTC (AUDIT_REQUEST.md, second request).**
  For every finitely supported probability K on [-1.54, 1.54] with K([0.85, 1.54]) >= 4/5:
  E|Z_K| <= max(g(lambda+_0.85(K)), C_5); the mirror statement for K([-1.54, -0.85]) >= 4/5. Uses D16 (Lemma 7(c),
  two-point mean-variance bound) and D17 (Lemma 12, absorption, with option (O5)). Certificate: 1339 (a, b) squares,
  14,894,034 (Lambda, m) boxes, 0 uncertified (`outputs/verify_bandstar.txt`).
- **D19 = Corollary 14:** ID*(C_5) on [-1.54, 1.54] reduces to the far region
  F = {K([0.85, 1.54]) < 4/5 and K([-1.54, -0.85]) < 4/5} (theta = 0.85 for every K).
- **D20 = Corollary 15:** Theorem 13 holds for all K on [-1.54, 1.54], and C5 reduces to the same far region (via
  A.13a). So one proof of E|Z_K| <= C_5 on F gives both ID*(C_5) and C5. RQ-C made the observation; RQ-D wrote it up.

## Where Conjecture S stands (given the audited reductions A.25, A.26, A.28)
The band side of ID* is done, pending audit and referee. Conjecture S for all q is CONDITIONAL only on
**E|Z_K| <= C_5 on F** (RQ-B's part; open). Numerical sup on F about 0.8266 (RQ-C 0.82664, RQ-B 0.825463), margin about
0.0285. RQ-B accepted the split (theta = 0.85, rho0^2 = 0.2, A = 1.54, mass form) at 18:15 UTC.

## Next (RQ-D)
- Answer audit and referee questions on the second request.
- Offered to the team (NOTES_FOR_TEAM.md): help on the far region with the comparison lemma and the stop-loss
  bounds, or a larger band if RQ-B needs one.
- 19:27 UTC (float evidence only): extra bands B(0.80, 0.15) and B(0.75, 0.10) are within reach of bound F, but
  removing them from F lowers its sup only from 0.826665 to 0.824316 (`outputs/far_extra/local.txt`). Not certified
  unless RQ-B asks.
- 19:27 UTC offer to RQ-B: the general-jump version of RQ-A's atom split. This is Poisson conditioning on all jumps
  in [tau, A] and in [-A, -tau] (Proposition 9 machinery), with degree-D moment bounds for the residual.
- **20:00 UTC RQ-B accepted; new assignment: F_heavy = F intersected with {V+ >= v or V- >= v}, v = 1/2 by
  default** (RQ-B keeps F_light). 20:25 UTC (NOTES): design = chord reduction of the edge jump laws (Lemma E,
  Z_K <=_cx Z_{K#}) at tau = 0.85, Poisson counts of the four chord atoms, degree-16 moment bound for the residual.
  Float only: worst tested F_heavy law is K* itself (chord bound 0.82830 at D = 16). Nothing filed on F yet.

## Mechanisms rejected earlier
Pairwise merging (D3), level moves (D4), two-copy Bellman relaxation (D5); fixed theta = 0.9 with bound (F) at
rho0^2 = 0.2 (D14).
