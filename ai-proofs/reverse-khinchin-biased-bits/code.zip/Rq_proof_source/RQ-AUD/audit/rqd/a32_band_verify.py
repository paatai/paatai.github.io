#!/usr/bin/env python3
"""A.32 (RQ-AUD): own certified check of RQ-D Theorem 10 (band lemma for C5); RQ-D MAIN_RESULT.tex md5 4df86775.

Written from the statements of Lemmas 2-8, Proposition 9 and Section 5.1 of the tex only; RQ-D's scripts are neither
used nor read. All decisions are made in arb (128 bits); floats only choose the parameters h and the subdivision.

Claim certified. For every (a, b, L, m) with a, b >= 0, 0 < rho^2 = a + b <= 1/10, V = 1 - rho^2 and (L, m)
satisfying F1-F5 (theta = 1, A = sqrt2):
    F = 2 m e^{-L} + e^{-L} c_B + L e^{-L} O' + P2(L) c_C < T = sqrt(2/e),        P2(L) = 1 - e^{-L}(1 + L),
with the admissible choices of Lemma 6 / Lemma 7(a):
    c_B  >= 2E(W - m)_+          : chi^B_h(m) or CS(m),        CS(t) = sqrt(t^2 + rho^2) - t,
    c_C  >= 2E(-W - (2 - m))_+   : chi^C_h(2 - m) or CS(2 - m),
    O'   >= 2E(-W - (J - m))_+   : chord of y -> 2E(-W - y)_+ on [1 - m, sqrt2 - m] (weights from mu1 = m/L), with
                                   endpoint bounds chi^C_h(y) or CS(y),
    W_B = (N_a - a) + sqrt(b) G,  W_C = sqrt2 (N_{b/2} - b/2) + sqrt(a) G,  chi_h(t) = (2h)^{-1} E(W_. - t + h)_+^2.

Part S (0 < rho^2 <= r = 1/50), per (L, m) box, one of
  S1  chi, CS <= a alpha + b beta (own derivation, below), so F <= 2 m e^{-L} + a A + b B and, as 2 m e^{-L} <=
      sqrt(V) g(L) <= (1 - rho^2/2) T, F < T once max(A, B) < T/2;
  S2  M0 + r_B max(A, B) < T, M0 = box max of 2 m e^{-L} under m^2 <= L, r_B = min(r, 1 - m1^2/L2) (F4);
  S3  M0 + (all costs by CS at rho^2 = r_B) < T.
  Linear coefficients (c = t - h): B side, valid for 0 <= c <= 1 - r/2:
      alpha_B = (2h)^-1 sum_{n>=1} r^{n-1} ((n - c)^2 + r)/n!,  beta_B = tau(c/sqrt r)/(2h),  tau(x) = E(G - x)_+^2;
  C side, valid for 0 <= c <= sqrt2 - r/(2 sqrt2):
      alpha_C = tau(c/sqrt r)/(2h),  beta_C = (2h)^-1 sum_{n>=1} r^{n-1} ((sqrt2 n - c)^2 + r)/(2^n n!);
  CS: sqrt(t^2 + rho^2) - t <= rho^2/(2t) (t > 0).
Part B (1/50 <= rho^2 <= 1/10): (a, b) squares (side 1/256, refined to 1/512, ...); costs at the corner (a2, b2)
  (Lemma 6 (iv)), CS at rho2_hi; V in [1 - rho2_hi, 1 - rho2_lo]; (L, m) boxes: discarded when one of F1-F5 fails on
  the whole box, else certified when
      M + e^{-L1} c_B(m1) + L2 e^{-L2} max_{mu} chord(mu; U0(m2), U1(m2)) + P2(L2) c_C(m2) < T,
  M = box max of 2 m e^{-L} under m^2 <= L V_hi (unimodal: peak at min(m2^2/V_hi, 1/2)), mu in
  [max(1, m1/L2), min(sqrt2, m2/L1)] as one ball; else bisected.
Usage:
  python3 a32_band_verify.py S [r] [shift]                 (shift > 0 lowers the target, controls only)
  python3 a32_band_verify.py B [shift] [side0] [maxside] [workers] [norefine]
  python3 a32_band_verify.py profile                        (float margin profile, evidence only)
"""
import json
import math
import sys
import time
from fractions import Fraction as F
from multiprocessing import Pool

from flint import arb, ctx

ctx.prec = 128

SQ2 = arb(2).sqrt()
INV_SQ2PI = 1 / (2 * arb.pi()).sqrt()
T = (arb(2) / arb(1).exp()).sqrt()
NT = 12
SQ2F = math.sqrt(2.0)
TF = math.sqrt(2.0 / math.e)


def say(*a):
    print(*a)
    sys.stdout.flush()


def ar(x):
    x = F(x)
    return arb(x.numerator) / x.denominator


# ---------------------------------------------------------------- arb special functions
def Phi(x):
    return (-x / SQ2).erfc() / 2


def Phibar(x):
    return (x / SQ2).erfc() / 2


def phi(x):
    return (-(x * x) / 2).exp() * INV_SQ2PI


def tau(x):
    """E(G - x)_+^2."""
    return (1 + x * x) * Phibar(x) - x * phi(x)


def Q(d, s):
    """E(d + sG)_+^2, s > 0."""
    z = d / s
    return (d * d + s * s) * Phi(z) + d * s * phi(z)


def chi_arb(J, lam, s, t, h):
    """Upper ball for (2h)^-1 E(J (N_lam - lam) + s G - t + h)_+^2 (lam >= 0, s > 0, h > 0)."""
    c = t - h
    p = (-lam).exp()
    tot = arb(0)
    for n in range(NT + 1):
        tot += p * Q(J * (n - lam) - c, s)
        p = p * lam / (n + 1)
    # tail n > NT: p_n <= lam^n/n!, Q(d, s) <= d^2 + s^2, |d_n| <= J n + C; term ratio <= lam (n1 + 1)/n1^2
    n1 = NT + 1
    C = J * lam + abs(c)
    u = p * lam.exp() * ((J * n1 + C) ** 2 + s * s)
    q = lam * (n1 + 1) / (n1 * n1)
    assert bool(q < 1)
    return (tot + u / (1 - q)) / (2 * h)


def CS(t, rho2):
    return (t * t + rho2).sqrt() - t


# ---------------------------------------------------------------- float mirrors (parameter choice only)
def Phi_f(x):
    return 0.5 * math.erfc(-x / SQ2F)


def phi_f(x):
    return math.exp(-0.5 * x * x) / math.sqrt(2 * math.pi)


def Q_f(d, s):
    z = d / s
    return (d * d + s * s) * Phi_f(z) + d * s * phi_f(z)


def chi_f(J, lam, s, t, h):
    c = t - h
    p = math.exp(-lam)
    tot = 0.0
    for n in range(NT + 1):
        tot += p * Q_f(J * (n - lam) - c, s)
        p *= lam / (n + 1)
    return tot / (2 * h)


def best_h(J, lam, s, t, lo=1e-3, hi=3.0, it=26):
    """Golden section in log h; h -> chi_h(t) is convex (each (x + h)_+^2/(2h) is), so unimodal."""
    a, b = math.log(lo), math.log(hi)
    gr = (math.sqrt(5) - 1) / 2
    x1, x2 = b - gr * (b - a), a + gr * (b - a)
    f1, f2 = chi_f(J, lam, s, t, math.exp(x1)), chi_f(J, lam, s, t, math.exp(x2))
    for _ in range(it):
        if f1 < f2:
            b, x2, f2 = x2, x1, f1
            x1 = b - gr * (b - a)
            f1 = chi_f(J, lam, s, t, math.exp(x1))
        else:
            a, x1, f1 = x1, x2, f2
            x2 = a + gr * (b - a)
            f2 = chi_f(J, lam, s, t, math.exp(x2))
    return math.exp((a + b) / 2)


def lower_of(x, y):
    """The ball with the smaller upper endpoint (both are upper bounds of the same quantity)."""
    return x if bool(x.upper() < y.upper()) else y


# ---------------------------------------------------------------- common box tools
def infeasible(L1, L2, m1, m2, Vlo, Vhi):
    """True only if one of F1-F5 fails at every point of the box for every V in [Vlo, Vhi] (exact / certain)."""
    if L2 < Vlo / 2 or L1 > Vhi:                       # F1
        return True
    if 2 * m2 * m2 < Vlo * Vlo or m1 > Vhi:            # F2: m2 < Vlo/sqrt2, m1 > Vhi
        return True
    if L1 > m2 or m1 * m1 > 2 * L2 * L2:               # F3: L <= m <= sqrt2 L
        return True
    if m1 * m1 > L2 * Vhi:                             # F4: m^2 <= L V
        return True
    if bool(ar(L1) - (1 + 1 / SQ2) * ar(m2) + ar(Vlo) / SQ2 > 0):   # F5
        return True
    return False


def Mbox(L1, L2, m2, Vhi):
    """max over L in [L1, L2] of 2 e^{-L} min(m2, sqrt(L Vhi)) (unimodal in L)."""
    Lp = min(m2 * m2 / Vhi, F(1, 2))
    Ls = min(max(Lp, L1), L2)
    if Ls * Vhi >= m2 * m2:
        return 2 * ar(m2) * (-ar(Ls)).exp()
    return 2 * (ar(Ls) * ar(Vhi)).sqrt() * (-ar(Ls)).exp()


def mu_ball(L1, L2, m1, m2):
    lo = max(F(1), m1 / L2)
    r = m2 / L1
    hi = SQ2 if r * r >= 2 else ar(r)
    return ar(lo).union(hi)


def multipliers(L1, L2):
    eL1 = (-ar(L1)).exp()
    LL2 = ar(L2)
    eL2 = (-LL2).exp()
    return eL1, LL2 * eL2, 1 - eL2 * (1 + LL2)


# ---------------------------------------------------------------- Part S
U_GRID = [0.01, 0.02, 0.03, 0.05, 0.07, 0.1, 0.13, 0.16, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6,
          0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.99, 1 - 1e-9]


class PartS:
    def __init__(self, r):
        self.r = F(r)
        self.R = ar(self.r)
        self.sqR = self.R.sqrt()
        self.cmaxB = 1 - self.R / 2
        self.cmaxC = SQ2 - self.R / (2 * SQ2)
        self.cache = {}

    def series_B(self, c):
        R, Nn = self.R, 10
        s, fact, rp = arb(0), arb(1), arb(1)
        for n in range(1, Nn + 1):
            fact = fact * n
            s += rp * ((n - c) ** 2 + R) / fact
            rp = rp * R
        n1 = Nn + 1                                       # tail: (n - c)^2 <= n^2 (0 <= c <= 1), ratio <= r
        u = rp * (n1 * n1 + R) / (fact * n1)
        return s + u / (1 - R)

    def series_C(self, c):
        R, Nn = self.R, 10
        s, fact, rp, two = arb(0), arb(1), arb(1), arb(1)
        for n in range(1, Nn + 1):
            fact = fact * n
            two = two * 2
            s += rp * ((SQ2 * n - c) ** 2 + R) / (two * fact)
            rp = rp * R
        n1 = Nn + 1                                       # tail: (sqrt2 n - c)^2 <= 2 n^2, ratio <= r/2
        u = rp * (2 * n1 * n1 + R) / (two * 2 * fact * n1)
        return s + u / (1 - R / 2)

    def candidates(self, kind, key, t):
        """Valid (alpha, beta) balls for a term of type kind at t (cached by key)."""
        ck = (kind, key)
        if ck in self.cache:
            return self.cache[ck]
        out = []
        if bool(t > 0):
            cs = 1 / (2 * t)
            out.append((cs, cs, 'CS'))
        tf = float(t.mid())
        for u in U_GRID:
            h = tf * u
            if h <= 0:
                continue
            hh = arb(h)
            c = t - hh
            cmax = self.cmaxB if kind == 'B' else self.cmaxC
            if not (bool(c >= 0) and bool(c <= cmax)):
                continue
            tt = tau(c / self.sqR) / (2 * hh)
            if kind == 'B':
                al, be = self.series_B(c) / (2 * hh), tt
            else:
                al, be = tt, self.series_C(c) / (2 * hh)
            out.append((al, be, h))
        self.cache[ck] = out
        return out

    def coeffs(self, L1, L2, m1, m2):
        """Balls (A, B) bounding the a- and b-coefficients of all costs on the box, or None."""
        terms = [self.candidates('B', ('m', m1), ar(m1)),
                 self.candidates('C', ('1-m', m2), ar(1 - m2)),
                 self.candidates('C', ('s2-m', m2), SQ2 - ar(m2)),
                 self.candidates('C', ('2-m', m2), ar(2 - m2))]
        if any(len(tm) == 0 for tm in terms):
            return None
        eL1, L2e, P2 = multipliers(L1, L2)
        mu = mu_ball(L1, L2, m1, m2)
        w1 = (mu - 1) / (SQ2 - 1)
        wlo, whi = float(w1.lower().mid()), float(w1.upper().mid())
        mf = [float(eL1.mid()), float(L2e.mid()), float(P2.mid())]
        tf = [[(float(al.mid()), float(be.mid())) for (al, be, _) in tm] for tm in terms]
        best = None
        for k in range(21):
            lam = k / 20
            pick = [min(range(len(tm)), key=lambda i, tm=tm: lam * tm[i][0] + (1 - lam) * tm[i][1]) for tm in tf]
            worst = 0.0
            for w in (wlo, whi):
                ws = [mf[0], mf[1] * (1 - w), mf[1] * w, mf[2]]
                Af = sum(ws[j] * tf[j][pick[j]][0] for j in range(4))
                Bf = sum(ws[j] * tf[j][pick[j]][1] for j in range(4))
                worst = max(worst, Af, Bf)
            if best is None or worst < best[0]:
                best = (worst, pick)
        pick = best[1]
        c = [terms[j][pick[j]] for j in range(4)]
        A = eL1 * c[0][0] + L2e * (c[1][0] + w1 * (c[2][0] - c[1][0])) + P2 * c[3][0]
        B = eL1 * c[0][1] + L2e * (c[1][1] + w1 * (c[2][1] - c[1][1])) + P2 * c[3][1]
        return A, B, [c[j][2] for j in range(4)]


def run_S(r=F(1, 50), shift=F(0), maxdepth=14, g=64):
    t0 = time.time()
    P = PartS(r)
    r = F(r)
    Vlo, Vhi = 1 - r, F(1)
    target = T - ar(shift)
    Lb, Lt = F(math.floor(float(Vlo / 2) * g), g), F(1)
    mb, mt = F(math.floor(float(Vlo) / SQ2F * g) - 1, g), F(1)
    stack = []
    Lk = Lb
    while Lk < Lt:
        mk = mb
        while mk < mt:
            stack.append((Lk, Lk + F(1, g), mk, mk + F(1, g), 0))
            mk += F(1, g)
        Lk += F(1, g)
    stats = dict(boxes=0, infeasible=0, S1=0, S2=0, S3=0, fail=0, maxdepth_used=0)
    worst = {'S1': None, 'S2': None, 'S3': None}
    fails = []
    while stack:
        L1, L2, m1, m2, d = stack.pop()
        stats['boxes'] += 1
        stats['maxdepth_used'] = max(stats['maxdepth_used'], d)
        if infeasible(L1, L2, m1, m2, Vlo, Vhi):
            stats['infeasible'] += 1
            continue
        co = P.coeffs(L1, L2, m1, m2)
        M0 = Mbox(L1, L2, m2, F(1))
        rB = min(r, 1 - m1 * m1 / L2)
        done = None
        if co is not None:
            A, B, _ = co
            mAB = A if bool(A.upper() > B.upper()) else B
            if shift == 0 and bool(A < T / 2) and bool(B < T / 2):
                done, marg = 'S1', T / 2 - mAB
            else:
                v = M0 + ar(rB) * mAB
                if bool(v < target):
                    done, marg = 'S2', target - v
        if done is None:
            eL1, L2e, P2 = multipliers(L1, L2)
            RB = ar(rB)
            mu = mu_ball(L1, L2, m1, m2)
            w1 = (mu - 1) / (SQ2 - 1)
            u0, u1 = CS(ar(1 - m2), RB), CS(SQ2 - ar(m2), RB)
            v = M0 + eL1 * CS(ar(m1), RB) + L2e * (u0 + w1 * (u1 - u0)) + P2 * CS(ar(2 - m2), RB)
            if bool(v < target):
                done, marg = 'S3', target - v
        if done is not None:
            stats[done] += 1
            mf = float(marg.lower().mid())
            if worst[done] is None or mf < worst[done][0]:
                worst[done] = (mf, float(L1), float(L2), float(m1), float(m2))
            continue
        if d >= maxdepth:
            stats['fail'] += 1
            if len(fails) < 5:
                fails.append((float(L1), float(L2), float(m1), float(m2)))
            continue
        if d % 2 == 0:
            mm = (m1 + m2) / 2
            stack += [(L1, L2, m1, mm, d + 1), (L1, L2, mm, m2, d + 1)]
        else:
            Lm = (L1 + L2) / 2
            stack += [(L1, Lm, m1, m2, d + 1), (Lm, L2, m1, m2, d + 1)]
    stats.update(part='S', r=str(r), shift=str(shift), worst=worst, fails=fails, seconds=round(time.time() - t0, 1))
    return stats


# ---------------------------------------------------------------- Part B
def square_job(args):
    a1, a2, b1, b2, shift, maxdepth, g = args
    t0 = time.time()
    rlo, rhi = max(a1 + b1, F(1, 50)), min(a2 + b2, F(1, 10))
    Vlo, Vhi = 1 - rhi, 1 - rlo
    target = T - ar(shift)
    A2, B2, RH = ar(a2), ar(b2), ar(rhi)
    lamB, sB = A2, B2.sqrt()
    lamC, sC = B2 / 2, A2.sqrt()
    a2f, b2f = float(a2), float(b2)
    sBf, sCf = math.sqrt(b2f), math.sqrt(a2f)
    one = arb(1)
    cacheB, cacheC = {}, {}

    def cost_C(t, tf):
        h = best_h(SQ2F, b2f / 2, sCf, tf)
        return lower_of(chi_arb(SQ2, lamC, sC, t, arb(h)), CS(t, RH))

    def costB(m):
        if m not in cacheB:
            mm = ar(m)
            h = best_h(1.0, a2f, sBf, float(m))
            cacheB[m] = lower_of(chi_arb(one, lamB, sB, mm, arb(h)), CS(mm, RH))
        return cacheB[m]

    def costC(m):
        if m not in cacheC:
            mf = float(m)
            cacheC[m] = (cost_C(ar(1 - m), 1 - mf), cost_C(SQ2 - ar(m), SQ2F - mf), cost_C(ar(2 - m), 2 - mf))
        return cacheC[m]

    Lb, Lt = F(math.floor(float(Vlo / 2) * g), g), F(math.ceil(float(Vhi) * g), g)
    mb, mt = F(math.floor(float(Vlo) / SQ2F * g) - 1, g), F(math.ceil(float(Vhi) * g), g)
    stack = []
    Lk = Lb
    while Lk < Lt:
        mk = mb
        while mk < mt:
            stack.append((Lk, Lk + F(1, g), mk, mk + F(1, g), 0))
            mk += F(1, g)
        Lk += F(1, g)
    nbox = ninf = ncert = 0
    worst = None
    while stack:
        L1, L2, m1, m2, d = stack.pop()
        nbox += 1
        if infeasible(L1, L2, m1, m2, Vlo, Vhi):
            ninf += 1
            continue
        eL1, L2e, P2 = multipliers(L1, L2)
        U0, U1, cC = costC(m2)
        w1 = (mu_ball(L1, L2, m1, m2) - 1) / (SQ2 - 1)
        Fb = Mbox(L1, L2, m2, Vhi) + eL1 * costB(m1) + L2e * (U0 + w1 * (U1 - U0)) + P2 * cC
        if bool(Fb < target):
            ncert += 1
            mg = float((target - Fb).lower().mid())
            if worst is None or mg < worst[0]:
                worst = (mg, float(L1), float(L2), float(m1), float(m2))
            continue
        if d >= maxdepth:
            return dict(sq=[str(a1), str(a2), str(b1), str(b2)], ok=False, nbox=nbox,
                        fail=(float(L1), float(L2), float(m1), float(m2), float(Fb.upper().mid())),
                        seconds=round(time.time() - t0, 2))
        if d % 2 == 0:
            mm = (m1 + m2) / 2
            stack += [(L1, L2, m1, mm, d + 1), (L1, L2, mm, m2, d + 1)]
        else:
            Lm = (L1 + L2) / 2
            stack += [(L1, Lm, m1, m2, d + 1), (Lm, L2, m1, m2, d + 1)]
    return dict(sq=[str(a1), str(a2), str(b1), str(b2)], ok=True, nbox=nbox, ninf=ninf, ncert=ncert,
                worst=worst, ncost=len(cacheB) + 3 * len(cacheC), seconds=round(time.time() - t0, 2))


def in_band(a1, a2, b1, b2):
    return max(a1 + b1, F(1, 50)) <= min(a2 + b2, F(1, 10))


def run_B(shift=F(0), side0=256, maxside=4096, workers=8, refine=True, maxdepth=16, g=64):
    t0 = time.time()
    sq = []
    n = side0
    for i in range(n):
        for j in range(n):
            a1, a2, b1, b2 = F(i, n), F(i + 1, n), F(j, n), F(j + 1, n)
            if a1 + b1 > F(1, 10):
                continue
            if in_band(a1, a2, b1, b2):
                sq.append((a1, a2, b1, b2))
    levels = []
    total_boxes = 0
    worst = None
    uncert = []
    with Pool(workers) as pool:
        side = side0
        while sq:
            res = pool.map(square_job, [(a1, a2, b1, b2, shift, maxdepth, g) for (a1, a2, b1, b2) in sq],
                           chunksize=1)
            bad = [r for r in res if not r['ok']]
            total_boxes += sum(r['nbox'] for r in res)
            for r in res:
                if r['ok'] and r['worst'] is not None and (worst is None or r['worst'][0] < worst[0]):
                    worst = r['worst'] + tuple(r['sq'])
            lv = dict(side=f'1/{side}', squares=len(res), bad=len(bad),
                      boxes=sum(r['nbox'] for r in res), cpu_s=round(sum(r['seconds'] for r in res), 1))
            if bad:
                lv['bad_example'] = bad[0]['sq'] + [bad[0]['fail']]
            levels.append(lv)
            say(json.dumps(lv))
            if not refine or not bad:
                if bad:
                    uncert = [r['sq'] for r in bad]
                break
            if side * 2 > maxside:
                uncert = [r['sq'] for r in bad]
                break
            side *= 2
            nsq = []
            for r in bad:
                a1, a2, b1, b2 = (F(x) for x in r['sq'])
                am, bm = (a1 + a2) / 2, (b1 + b2) / 2
                for (x1, x2) in ((a1, am), (am, a2)):
                    for (y1, y2) in ((b1, bm), (bm, b2)):
                        if x1 + y1 <= F(1, 10) and in_band(x1, x2, y1, y2):
                            nsq.append((x1, x2, y1, y2))
            sq = nsq
    out = dict(part='B', shift=str(shift), levels=levels, total_boxes=total_boxes,
               certified_squares=sum(lv['squares'] - lv['bad'] for lv in levels), uncertified=uncert,
               worst_margin=worst, seconds=round(time.time() - t0, 1))
    return out


# ---------------------------------------------------------------- float profile (evidence only)
def F_point_f(a, b, L, m):
    rho2 = a + b
    V = 1 - rho2
    mu = m / L
    cs = lambda t: math.sqrt(t * t + rho2) - t
    hB = best_h(1.0, a, math.sqrt(b), m) if b > 0 else None
    cB = min(chi_f(1.0, a, math.sqrt(b), m, hB), cs(m)) if b > 0 else cs(m)

    def cC(t):
        if a <= 0:
            return cs(t)
        h = best_h(SQ2F, b / 2, math.sqrt(a), t)
        return min(chi_f(SQ2F, b / 2, math.sqrt(a), t, h), cs(t))
    w1 = (mu - 1) / (SQ2F - 1)
    chord = (1 - w1) * cC(1 - m) + w1 * cC(SQ2F - m)
    P2 = 1 - math.exp(-L) * (1 + L)
    return 2 * m * math.exp(-L) + math.exp(-L) * cB + L * math.exp(-L) * chord + P2 * cC(2 - m), V


def profile():
    say('float margin T - F on the Dirac curve K_S = V delta_x (evidence only)')
    for rho2 in (0.001, 0.005, 0.01, 0.02, 0.03, 0.05, 0.07, 0.1):
        for frac_a in (1.0, 0.5, 0.0):
            a, b = rho2 * frac_a, rho2 * (1 - frac_a)
            a, b = max(a, 1e-12), max(b, 1e-12)
            V = 1 - rho2
            best = None
            for k in range(0, 401):
                x = 1 + (SQ2F - 1) * k / 400
                Fv, _ = F_point_f(a, b, V / x ** 2, V / x)
                if best is None or TF - Fv < best[0]:
                    best = (TF - Fv, x)
            say(f'rho2={rho2:<6} a/rho2={frac_a:<4} min margin {best[0]:.6f} at x={best[1]:.4f}'
                f'  (margin/rho2 = {best[0] / rho2:.4f})')


def main():
    mode = sys.argv[1] if len(sys.argv) > 1 else 'S'
    if mode == 'S':
        r = F(sys.argv[2]) if len(sys.argv) > 2 else F(1, 50)
        shift = F(sys.argv[3]) if len(sys.argv) > 3 else F(0)
        say(json.dumps(run_S(r, shift)))
    elif mode == 'B':
        shift = F(sys.argv[2]) if len(sys.argv) > 2 else F(0)
        side0 = int(sys.argv[3]) if len(sys.argv) > 3 else 256
        maxside = int(sys.argv[4]) if len(sys.argv) > 4 else 4096
        workers = int(sys.argv[5]) if len(sys.argv) > 5 else 8
        refine = not (len(sys.argv) > 6 and sys.argv[6] == 'norefine')
        say(json.dumps(run_B(shift, side0, maxside, workers, refine)))
    elif mode == 'profile':
        profile()


if __name__ == '__main__':
    main()
