#!/usr/bin/env python3
"""A.34 addendum (RQ-AUD): the recorded parameters of RQ-D's box-level record of Theorem 13 against MAIN_RESULT
Section 6.1 (data only; RQ-D's scripts are neither read nor run).

  (O3) leaf (method twopoint_C, aux = kx): kx is the far point in the m variable, y_far = theta - kx/4096 (the
       reading that fits RQ-D's note "kx/4096 >= m_2 - u'"); it must satisfy y_far <= j0' + u', i.e.
       kx/4096 >= m2 - u', with j0' = theta - m2 and u' = min over d in [dlo, dhi] of d + s^2/d (chi^C_h is
       nonincreasing, so a nearer far point is safe); decided exactly, also when u' = 2s is irrational;
  (O2) leaf (method taylor_B, aux = jt): jt/4096 <= -(mu_hi - m1);
  square: the recorded corner (units 2^-24) is >= the exact corner (min(a2, 1/5 - b1), min(b2, 1/5 - a1)).
Exact rationals throughout, with Geo and Square of a34_bandstar_verify (my code). Counts equal / below / above the
largest admissible grid point; any 'above' is a violation.

Usage: a34g_record_params.py [workers] [record_dir]
"""
import os
import sys
import time
from collections import Counter
from fractions import Fraction as F
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from a34_bandstar_verify import Geo, Square, floor_grid  # noqa: E402

STORE = "/cursor/stores/bot/rq/RQ-D/outputs/bandstar_cert"
AB_UNIT, L_UNIT, M_UNIT, C_UNIT = 8192, 16384, 4096, 2 ** 24


def far_ok(k, m2, geo):
    """Exact test of k/4096 >= m2 - u'."""
    z = m2 - F(k, M_UNIT)
    if z <= 0:
        return True
    d2, s2 = geo.dlo * geo.dlo, geo.s2
    if s2 <= d2:
        return z <= geo.dlo + s2 / geo.dlo
    if s2 >= geo.dhi * geo.dhi:
        return z <= geo.dhi + s2 / geo.dhi
    return z * z <= 4 * s2


def far_min(m2, geo):
    """Smallest integer k with k/4096 >= m2 - u'."""
    d2, s2 = float(geo.dlo) ** 2, float(geo.s2)
    if s2 <= d2:
        u = float(geo.dlo) + s2 / float(geo.dlo)
    elif s2 >= float(geo.dhi) ** 2:
        u = float(geo.dhi) + s2 / float(geo.dhi)
    else:
        u = 2 * s2 ** 0.5
    k = int(np.ceil((float(m2) - u) * M_UNIT)) + 2
    while far_ok(k - 1, m2, geo):
        k -= 1
    while not far_ok(k, m2, geo):
        k += 1
    return k


def job(args):
    s, box, corner, lv = args
    a1, a2, b1, b2 = (F(int(x), AB_UNIT) for x in box)
    sq = Square(a1, a2, b1, b2)
    out = Counter()
    ca, cb = F(int(corner[0]), C_UNIT), F(int(corner[1]), C_UNIT)
    out["corner_ok"] += int(ca >= sq.ab and cb >= sq.bb)
    out["corner_exact"] += int(ca == sq.ab and cb == sq.bb)
    for l1, l2, k1, k2, meth, aux in lv:
        L1, L2, m1, m2 = F(int(l1), L_UNIT), F(int(l2), L_UNIT), F(int(k1), M_UNIT), F(int(k2), M_UNIT)
        if meth == 2:
            geo = Geo(L1, L2, m1, m2, sq.Vhi)
            if geo.far is None or geo.wp == 0:
                out["O3_no_far_point"] += 1
                continue
            kmin = far_min(m2, geo)
            out["O3_" + ("equal" if aux == kmin else "above" if aux > kmin else "BELOW")] += 1
        elif meth == 4:
            geo = Geo(L1, L2, m1, m2, sq.Vhi)
            top = int(floor_grid(m1 - geo.muhi) * M_UNIT)
            out["O2_" + ("equal" if aux == top else "below" if aux < top else "ABOVE")] += 1
    return out


def main():
    workers = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    rdir = sys.argv[2] if len(sys.argv) > 2 else STORE
    t0 = time.time()
    z = np.load(os.path.join(rdir, "bandstar_leaves.npz"), allow_pickle=False)
    off = z["sq_off"]
    lv = np.stack([z["leaf_L1"], z["leaf_L2"], z["leaf_k1"], z["leaf_k2"], z["leaf_meth"], z["leaf_aux"]],
                  axis=1).astype(np.int32)
    keep = (lv[:, 4] == 2) | (lv[:, 4] == 4)
    jobs = []
    for s in range(len(z["sq_box"])):
        part = lv[off[s]:off[s + 1]]
        jobs.append((s, z["sq_box"][s], z["sq_corner"][s], part[keep[off[s]:off[s + 1]]]))
    with Pool(workers) as pool:
        res = pool.map(job, jobs, chunksize=8)
    tot = Counter()
    for r in res:
        tot.update(r)
    print(f"a34g: {len(jobs)} squares, {int(keep.sum())} (O3) and (O2) leaves")
    print(f"corners: {tot['corner_ok']} >= exact corner, {tot['corner_exact']} equal to it")
    print(f"(O3) far point kx against the smallest admissible k (k/4096 >= m2 - u'): equal {tot['O3_equal']}, above "
          f"(nearer far point, valid) {tot['O3_above']}, below (violation) {tot['O3_BELOW']}; leaves without a far "
          f"point (d_lo = 0 or w' = 0): {tot['O3_no_far_point']}")
    print(f"(O2) t point jt/4096 against floor_grid(m1 - mu_hi): equal {tot['O2_equal']}, below {tot['O2_below']}, "
          f"above {tot['O2_ABOVE']}")
    ok = tot["corner_ok"] == len(jobs) and tot["O3_BELOW"] == 0 and tot["O2_ABOVE"] == 0
    print(f"{time.time() - t0:.0f} s")
    print("A34G_PASS" if ok else "A34G_FAIL")


if __name__ == "__main__":
    main()
