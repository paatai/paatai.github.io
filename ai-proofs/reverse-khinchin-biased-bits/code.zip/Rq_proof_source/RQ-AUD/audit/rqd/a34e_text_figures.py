"""A.34 / A.38 addendum: the stated figures of RQ-D's MAIN_RESULT.tex (212c6f23) in Sections 5-7 that can be checked
from g(lambda) = 2 sqrt(lambda) e^{-lambda} (tex line 68) and the box grid of Section 7, in Arb (200 bits).
"""
from fractions import Fraction

from flint import arb, ctx, fmpq

ctx.prec = 200
RES = []


def check(name, cond, detail=""):
    RES.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f": {detail}" if detail else ""))


def near(x, stated):
    dec = len(stated.split(".")[1])
    return abs(Fraction(x.mid().str(40, radius=False)) - Fraction(stated)) <= Fraction(1, 2 * 10 ** dec)


def prefix(x, stated):
    """A figure written with an ellipsis ('0.8551004...'): its digits are the leading digits of x."""
    return x.mid().str(40, radius=False).startswith(stated) and x.rad() < arb(fmpq(1, 10 ** 30))


def g(L):
    return 2 * L.sqrt() * (-L).exp()


def main():
    L5 = 2 * arb(fmpq(5, 4)).log()
    C5 = g(L5)
    check("line 429: C5 = g(2 ln 5/4) = 1.28 sqrt(2 ln 1.25) = 0.8551004...",
          abs(C5 - arb(fmpq(128, 100)) * L5.sqrt()) < arb(fmpq(1, 10 ** 50)) and prefix(C5, "0.8551004"), C5.str(15))
    lo, hi = arb(fmpq(1, 2)), arb(1)
    for _ in range(120):
        mid = (lo + hi) / 2
        if g(mid) > C5:
            lo = mid
        else:
            hi = mid
    root = (lo + hi) / 2
    check("g > C5 exactly on (2 ln 5/4, root): g(1/2) = sqrt(2/e) > C5 and g is unimodal with max at 1/2",
          g(arb(fmpq(1, 2))) > C5 and abs(g(arb(fmpq(1, 2))) - (2 / arb(1).exp()).sqrt()) < arb(fmpq(1, 10 ** 50)))
    print(f"     lower root 2 ln 5/4 = {L5.str(12)}; upper root = {root.str(12)} (bisection bracket width {float(hi - lo):.1e})")
    check("line 617: lower end 0.4463", near(L5, "0.4463"))
    check("line 617: upper end 0.5599", near(root, "0.5599"),
          f"the upper root is {root.str(10)}; g(0.5599) - C5 = {(g(arb('0.5599')) - C5).str(6)}; it rounds to 0.5579")
    for L, s in (("0.56323", "0.000496"), ("0.56329", "0.000502")):
        v = C5 - g(arb(L))
        check(f"line 648: C5 - g({L}) ~ {s}", near(v, s), v.str(10))
    v = C5 - g(arb("0.56329")) - arb(fmpq(5, 10000))
    check("line 649: with shift 0.0005 the target C5 - 0.0005 is <= g + 2e-6 on the box", v < arb(fmpq(2, 10 ** 6)), v.str(6))
    m1, m2 = fmpq(3074, 4096) ** 2, fmpq(3075, 4096) ** 2
    check("line 647: m in [3074, 3075]/4096 meets the Dirac curve m^2 = Lambda for Lambda in [0.56323, 0.56329]",
          m1 <= fmpq(56329, 100000) and m2 >= fmpq(56323, 100000), f"m^2 in [{float(m1.p) / float(m1.q):.7f}, {float(m2.p) / float(m2.q):.7f}]")
    xa, xb = 1 / root.sqrt(), 1 / L5.sqrt()
    check("RQ-D CLAIMS D13 (NUMERICAL): Dirac range x in [1.335, 1.4985] where g(1/x^2) >= C5",
          near(xa, "1.335") and near(xb, "1.4985"), f"exact range [{xa.str(8)}, {xb.str(8)}]")
    t1, t2 = arb(fmpq(8, 10)) / arb(fmpq(85, 100)) ** 2, arb(fmpq(8, 10)) / arb(fmpq(154, 100)) ** 2
    check("line 769: 0.8/0.85^2 = 1.107... < 28/25 and 0.8/1.54^2 = 0.337... < 17/50",
          prefix(t1, "1.107") and t1 < arb(fmpq(28, 25)) and prefix(t2, "0.337") and t2 < arb(fmpq(17, 50)), f"{t1.str(8)}, {t2.str(8)}")
    ha, hb = fmpq(28, 25) / 64, fmpq(17, 50) / 64
    box = (3 * ha, 4 * ha, 39 * hb, 40 * hb)
    fl = [float(x.p) / float(x.q) for x in box]
    check("line 965: box (6, 3, 6, 39) of A.38 (worst bound 0.8548832) is [0.0525, 0.0700] x [0.2072, 0.2125]",
          [round(x, 4) for x in fl] == [0.0525, 0.07, 0.2072, 0.2125], f"exact {[str(x) for x in box]}")
    check("line 965: 0.854883 is the rounding of A.38's worst bound 0.8548832169680262 and is < C5",
          round(0.8548832169680262, 6) == 0.854883 and arb("0.8548832169680262") < C5)
    bad = [n for n, ok in RES if not ok]
    print("A34E_ALL_CONFIRMED" if not bad else f"A34E_NOT_CONFIRMED {bad}")


if __name__ == "__main__":
    main()
