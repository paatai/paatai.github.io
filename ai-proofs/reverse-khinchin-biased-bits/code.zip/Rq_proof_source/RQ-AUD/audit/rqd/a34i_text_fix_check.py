"""A.34 addendum: RQ-D's text-only update of 2026-10-23 05:35 UTC (A.34 f1, A.34 r3, the line-652 range).

Inputs: my snapshots of RQ-D's texts (audit/snapshots/s0005/RQ-D/ = the refereed MAIN_RESULT.tex 212c6f23 and .pdf
fed00af2; audit/snapshots/s0645/ = the new tex ac0ecf4f, pdf f0fc9c23 and CLAIMS e62b2ae6) and RQ-D's record data
(outputs/bandstar_cert/bandstar_leaves.npz and bandstar_slope.json in the store), data only. RQ-D's scripts are
hashed, not read.

Checks: (1) the tex diff is exactly the two figures; (2) the PDF text diff is the two figures and the date;
(3) the new figures in Arb (200 bits); (4) CLAIMS D13; (5) the hypotenuse ranges of tex line 652 from `sq_box`;
(6) r_eff = min(jr/4096, 1/50) (README) equals jr/4096 on every slope piece; (7) md5s of the files RQ-D lists
as unchanged.
"""
import difflib
import hashlib
import json
import os
import subprocess
import sys
from fractions import Fraction as F

import numpy as np
from flint import arb, ctx, fmpq

ctx.prec = 200
HERE = os.path.dirname(os.path.abspath(__file__))
SNAP = os.path.join(HERE, "..", "snapshots")
OLD_TEX = os.path.join(SNAP, "s0005", "RQ-D", "MAIN_RESULT.tex")
NEW_TEX = os.path.join(SNAP, "s0645", "RQ-D_MAIN_RESULT_ac0ecf4f.tex")
OLD_PDF = os.path.join(SNAP, "s0005", "RQ-D", "MAIN_RESULT.pdf")
NEW_PDF = os.path.join(SNAP, "s0645", "RQ-D_MAIN_RESULT_f0fc9c23.pdf")
NEW_CLAIMS = os.path.join(SNAP, "s0645", "RQ-D_CLAIMS.md")
RQD = "/cursor/stores/bot/rq/RQ-D"
AB_UNIT = 8192
JR_UNIT = 4096

UNCHANGED = {
    "scripts/verify_bandstar.py": "b5b55ceec828f01debc6c1a422e7270f",
    "scripts/bandstar_record.py": "6fcfd2e81fafcfad3c27ca7da0422359",
    "scripts/bandstar_replay.py": "e38a1a9e187cba0fda225ca415c91a14",
    "outputs/bandstar_cert/bandstar_leaves.npz": "170d0ba8c98c8fbed9575f3c1525a452",
    "outputs/bandstar_cert/bandstar_slope.json": "353cfe2ad87153637ca05129df7ee4e8",
    "outputs/bandstar_cert/record.txt": "d3ae2b0731a98170c99e7780efbd7444",
    "outputs/bandstar_cert/record_env.txt": "11c9c8fd26e75b87cf0986970299833b",
    "outputs/bandstar_cert/record_squares.jsonl": "8d4d2db30e96cba715bf9f1605c5f94e",
    "outputs/bandstar_cert/record_summary.json": "2f94be6809c772ca014aa5a3a93c9aad",
    "outputs/bandstar_cert/replay.txt": "13c696a1b3f76c9a6da35e9f159cb1fa",
    "outputs/bandstar_cert/replay_selftest.txt": "bcffaef62cef7da92868ad0d433d0c2f",
    "outputs/verify_bandstar.txt": "c36c17e52bb29948ebd55119097e2732",
    "outputs/verify_bandstar_squares.jsonl": "73a8da42b2c739cc01713566199d7250",
    "scripts/verify_plus.py": "c754a7305654c6635025f7e405dd98bb",
    "scripts/plus_verify_lib.py": "a7db98d4dac237f52493f6d085b97d15",
    "outputs/plus_cert/certs_v1_r0.jsonl": "e23d52dd72764e98fb579ae6dba2b85c",
    "outputs/plus_cert/certs_v1_r1.jsonl": "ee9307ee5d40850c0e6199df6478b610",
    "outputs/plus_cert/certs_v1_r2.jsonl": "f5fe9a23f7ddd05ff70b7217731aa1af",
    "outputs/plus_cert/certs_v1_r3.jsonl": "6d495261e3af634ebc32ef8c7ef18c63",
    "outputs/plus_cert/certs_v1_r4.jsonl": "3033710b0d34ca792aaa15feae577299",
    "outputs/plus_cert/verify_v1.txt": "4b52e38e2b67422a54da43ad752ad550",
}
SNAP_MD5 = {OLD_TEX: "212c6f230b7bd8b8ef0c377b21f7c937", NEW_TEX: "ac0ecf4ff81feba53f6b8d8567a35a3b",
            OLD_PDF: "fed00af29c12800e45b2fb6cade857c6", NEW_PDF: "f0fc9c23eef76a9921644261ca7ae757",
            NEW_CLAIMS: "e62b2ae620d5fa0110b083d5537684e0"}
RES = []
REMARKS = []


def check(name, cond, detail=""):
    RES.append((name, bool(cond)))
    print(("PASS " if cond else "FAIL ") + name + (f": {detail}" if detail else ""))


def md5(path):
    with open(path, "rb") as f:
        return hashlib.md5(f.read()).hexdigest()


def near(x, stated):
    dec = len(stated.split(".")[1])
    return abs(F(x.mid().str(40, radius=False)) - F(stated)) <= F(1, 2 * 10 ** dec)


def prefix(x, stated):
    return x.mid().str(40, radius=False).startswith(stated) and x.rad() < arb(fmpq(1, 10 ** 30))


def g(L):
    return 2 * L.sqrt() * (-L).exp()


def changed_lines(a, b):
    out = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if tag != "equal":
            out.append((tag, i1, i2, j1, j2))
    return out


def main():
    for p, e in SNAP_MD5.items():
        check(f"snapshot md5 {os.path.relpath(p, SNAP)} = {e[:8]}", md5(p) == e)

    old = open(OLD_TEX, encoding="utf-8").read().split("\n")
    new = open(NEW_TEX, encoding="utf-8").read().split("\n")
    ops = changed_lines(old, new)
    want = {617: ("0.5599", "0.5579"), 652: ("0.1973", "0.1972")}
    ok = len(old) == len(new) and all(t == "replace" and i2 - i1 == 1 and j2 - j1 == 1 and i1 == j1
                                      for t, i1, i2, j1, j2 in ops)
    lines = sorted(i1 + 1 for _, i1, _, _, _ in ops)
    ok = ok and lines == sorted(want)
    for ln, (a, b) in want.items():
        ok = ok and old[ln - 1].count(a) == 1 and new[ln - 1] == old[ln - 1].replace(a, b)
    check("(1) tex 212c6f23 -> ac0ecf4f: only lines 617 (0.5599 -> 0.5579) and 652 (0.1973 -> 0.1972) change, "
          "and nothing else on those lines", ok, f"changed lines {lines}; {len(old)} lines in both")

    txt = []
    for p in (OLD_PDF, NEW_PDF):
        r = subprocess.run(["pdftotext", "-layout", p, "-"], capture_output=True, text=True, check=True)
        txt.append(r.stdout.split("\n"))
    pops = changed_lines(*txt)
    diffs = [(txt[0][i1:i2], txt[1][j1:j2]) for _, i1, i2, j1, j2 in pops]
    ok = len(diffs) == 3
    if ok:
        (d0, d1), (e0, e1), (f0, f1) = diffs
        ok = (d0 == [l.replace("October 23", "October 22") for l in d1] and "October 23, 2026" in d1[0]
              and len(e0) == 1 and e0 == [l.replace("0.5579", "0.5599") for l in e1] and "0.5579" in e1[0]
              and len(f0) == 1 and f1 == [f0[0].replace("0.1973", "0.1972")] and "0.1972" in f1[0])
    pages = []
    for p in (OLD_PDF, NEW_PDF):
        info = subprocess.run(["pdfinfo", p], capture_output=True, text=True, check=True).stdout
        pages.append([l.split()[-1] for l in info.split("\n") if l.startswith("Pages:")][0])
    check("(2) PDF text fed00af2 -> f0fc9c23 (pdftotext -layout): only the date, 0.5599 -> 0.5579 and "
          "0.1973 -> 0.1972", ok and pages == ["19", "19"], f"{len(diffs)} changed blocks; pages {pages}")

    L5 = 2 * arb(fmpq(5, 4)).log()
    C5 = g(L5)
    lo, hi = arb(fmpq(1, 2)), arb(1)
    for _ in range(120):
        mid = (lo + hi) / 2
        if g(mid) > C5:
            lo = mid
        else:
            hi = mid
    L2 = (lo + hi) / 2
    print(f"     g > C5 exactly on (2 ln 5/4, L2) = ({L5.str(12)}, {L2.str(12)})")
    check("(3) tex line 617: 0.5579 is the upper end L2 rounded to four digits, and the old 0.5599 lies outside",
          near(L2, "0.5579") and g(arb("0.5599")) < C5 and near(L5, "0.4463"),
          f"L2 = {L2.str(10)}; g(0.5599) - C5 = {(g(arb('0.5599')) - C5).str(6)}")
    xa, xb = 1 / L2.sqrt(), 1 / L5.sqrt()
    xlo, xhi = arb(1), arb(fmpq(3, 2))
    for _ in range(120):
        mid = (xlo + xhi) / 2
        if 2 / mid * (-1 / (mid * mid)).exp() > C5:
            xhi = mid
        else:
            xlo = mid
    xd = (xlo + xhi) / 2
    claims = open(NEW_CLAIMS, encoding="utf-8").read()
    d13 = "Dirac curve x in [1.3388682…, 1.4969001…] (where g(1/x^2) >= C_5;"
    ends = "the ends are 1/sqrt(0.5578588…) and 1/sqrt(2 ln(5/4)); A.34 r3)"
    check("(4a) CLAIMS D13 reads x in [1.3388682…, 1.4969001…], with ends 1/sqrt(0.5578588…) and 1/sqrt(2 ln(5/4))",
          d13 in claims and ends in claims)
    check("(4b) 0.5578588… and 1.4969001… are leading digits of L2 and 1/sqrt(2 ln 5/4)",
          prefix(L2, "0.5578588") and prefix(xb, "1.4969001"), f"{L2.str(12)}, {xb.str(12)}")
    check("(4c) the lower end 1/sqrt(L2), found again by bisection in x on (2/x) e^(-1/x^2) = C5, rounds to "
          "1.3388682 at seven decimals",
          abs(xd - xa) < arb(fmpq(1, 10 ** 30)) and near(xa, "1.3388682"), f"{xa.str(12)}")
    if prefix(xa, "1.3388682"):
        print("     the lower end has leading digits 1.3388682")
    else:
        REMARKS.append("4d")
        print(f"REMARK (4d) the lower end is {xa.mid().str(12, radius=False)}: its leading digits are "
              f"1.3388681, so '1.3388682…' is a rounding written with an ellipsis (cosmetic; the figure is the one of "
              f"RQ-AUD's own A.34 r3 note, where a34e printed arb str(8), a rounding)")

    for rel in ("outputs/bandstar_cert/bandstar_leaves.npz", "outputs/bandstar_cert/bandstar_slope.json"):
        if md5(os.path.join(RQD, rel)) != UNCHANGED[rel]:
            check(f"record file {rel} has the filed md5", False)
            sys.exit(1)
    z = np.load(os.path.join(RQD, "outputs/bandstar_cert/bandstar_leaves.npz"), allow_pickle=False)
    sb = [tuple(int(v) for v in row) for row in z["sq_box"]]
    small = [s for s in sb if s[1] - s[0] == 8 and s[3] - s[2] == 8]
    side_counts = {}
    for s in sb:
        side_counts[F(s[1] - s[0], AB_UNIT)] = side_counts.get(F(s[1] - s[0], AB_UNIT), 0) + 1
    ab_lo = min(F(a1 + b1, AB_UNIT) for a1, a2, b1, b2 in small)
    ab_hi = max(min(F(a2 + b2, AB_UNIT), F(1, 5)) for a1, a2, b1, b2 in small)
    a_lo = min(F(a1, AB_UNIT) for a1, a2, b1, b2 in small)
    a_hi = max(F(a2, AB_UNIT) for a1, a2, b1, b2 in small)
    print(f"     squares by side: {dict(sorted((str(k), v) for k, v in side_counts.items()))}")
    check("(5) tex line 652: the 80 squares of side 1/1024 have a + b in [101/512, 1/5] and a in [29/512, 49/512], "
          "enclosed by [0.1972, 0.2] and [0.0566, 0.0958]",
          len(small) == 80 and ab_lo == F(101, 512) and ab_hi == F(1, 5) and a_lo == F(29, 512)
          and a_hi == F(49, 512) and F("0.1972") <= ab_lo and F("0.0566") <= a_lo and a_hi <= F("0.0958")
          and not F("0.1973") <= ab_lo,
          f"a + b in [{ab_lo}, {ab_hi}], a in [{a_lo}, {a_hi}]")

    certs = json.load(open(os.path.join(RQD, "outputs/bandstar_cert/bandstar_slope.json")))
    jrs = [int(p["jr"]) for c in certs for p in c["pieces"]]
    check("(6) README r_eff = min(jr/4096, 1/50) equals jr/4096 on all slope pieces (max jr <= 81 < 4096/50)",
          len(certs) == 426 and len(jrs) == 579 and max(jrs) * 50 <= JR_UNIT and min(jrs) > 0,
          f"{len(certs)} slope leaves, {len(jrs)} pieces, jr in [{min(jrs)}, {max(jrs)}]")

    bad = [rel for rel, e in UNCHANGED.items() if md5(os.path.join(RQD, rel)) != e]
    check(f"(7) the {len(UNCHANGED)} files RQ-D lists as unchanged have the refereed md5s (hashed, not read)",
          not bad, f"mismatches {bad}" if bad else "")

    bad = [n for n, ok in RES if not ok]
    rem = f" (cosmetic remarks: {', '.join(REMARKS)})" if REMARKS else ""
    print(("A34I_ALL_CONFIRMED" if not bad else f"A34I_NOT_CONFIRMED {bad}") + rem)


if __name__ == "__main__":
    main()
