#!/usr/bin/env python3
"""A.34 addendum (RQ-AUD): the squares of RQ-D's record in which a34f's replay left leaves undecided, replayed again
with a finer h grid in my own verifier.

Lemma 6 gives phi <= chi_h and 2E(W - t)_+ <= chi_h for every h > 0, so the h grid of a34_bandstar_verify is only a
choice; here HG = 0.002 * 1.02^k, k < 400 (my A.34 grid: 0.004 * 1.12^k, k < 60; RQ-D's: 80 values of ratio 1.084).
Everything else is a34f's square_job unchanged: tiling of R0, then every leaf by my infeasible / direct / slope checks
in arb, bisected by my rule if needed.

Control mode (not part of the check): the 80 squares of side 1/1024 (tex line 652: they lie along the hypotenuse,
a + b in [0.1973, 0.2], a in [0.0566, 0.0958]); every recorded leaf is taken whole (no bisection), at the true target
and with the target lowered by 1/1000 (test T1 off), as in RQ-D's tampered-record test. Leaves that pass at the true
target and fail at the lowered one show that the replay is not vacuous there.

Usage: a34h_fine_grid.py [workers] [control]
"""
import json
import os
import sys
import time
from collections import Counter
from fractions import Fraction as F
from multiprocessing import Pool

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import a34_bandstar_verify as V  # noqa: E402

V.HG = [float(x) for x in 0.002 * 1.02 ** np.arange(400)]
V.HGa = np.array(V.HG)
V.HGF = [F(h) for h in V.HG]

import a34f_record_replay as R  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))


def load():
    rdir = os.path.join(R.STORE, "bandstar_cert")
    z = np.load(os.path.join(rdir, "bandstar_leaves.npz"), allow_pickle=False)
    certs = json.load(open(os.path.join(rdir, "bandstar_slope.json")))
    return z, certs


def square_args(z, certs, s, *extra):
    off = z["sq_off"]
    lv = np.stack([z[k][off[s]:off[s + 1]] for k in ("leaf_L1", "leaf_L2", "leaf_k1", "leaf_k2", "leaf_meth",
                                                     "leaf_opt", "leaf_aux")], axis=1).astype(np.int32)
    loc = {int(lv[i, 6]): certs[int(lv[i, 6])] for i in np.where(lv[:, 4] == 5)[0]}
    return (s, z["sq_box"][s], lv, loc) + extra


def control(workers):
    t0 = time.time()
    z, certs = load()
    sb = z["sq_box"]
    small = [s for s in range(len(sb)) if sb[s][1] - sb[s][0] == 8]
    a1s = [F(int(sb[s][0]), R.AB_UNIT) for s in small]
    a2s = [F(int(sb[s][1]), R.AB_UNIT) for s in small]
    lo = min(F(int(sb[s][0] + sb[s][2]), R.AB_UNIT) for s in small)
    hi = max(min(F(int(sb[s][1] + sb[s][3]), R.AB_UNIT), F(1, 5)) for s in small)
    print(f"a34h control: {len(small)} squares of side 1/1024; a + b in [{float(lo):.5f}, {float(hi):.5f}], "
          f"a in [{float(min(a1s)):.5f}, {float(max(a2s)):.5f}] (tex line 652: [0.1973, 0.2] and [0.0566, 0.0958])")
    for shift in (F(0), F(1, 1000)):
        with Pool(workers) as pool:
            out = pool.map(R.square_job, [square_args(z, certs, s, shift, 0) for s in small], chunksize=1)
        nl = sum(r["leaves"] for r in out)
        nf = sum(r["n_fail"] for r in out)
        nsq = sum(r["n_fail"] > 0 for r in out)
        print(f"shift {shift}: leaves taken whole {nl}; not certified {nf}; squares with such leaves {nsq} of "
              f"{len(out)}; {time.time() - t0:.0f} s")


def main():
    workers = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    if len(sys.argv) > 2 and sys.argv[2] == "control":
        control(workers)
        return
    t0 = time.time()
    rows = [json.loads(line) for line in open(os.path.join(HERE, "outputs", "a34f_squares.jsonl"))]
    todo = [r["s"] for r in rows if r["n_fail"] > 0]
    print(f"a34h: {len(todo)} squares with undecided leaves in a34f ({sum(r['n_fail'] for r in rows)} leaves): {todo}; "
          f"h grid {len(V.HG)} values {V.HG[0]:.4f} ... {V.HG[-1]:.3f}")
    z, certs = load()
    jobs = [square_args(z, certs, s) for s in todo]
    with Pool(min(workers, len(jobs))) as pool:
        out = pool.map(R.square_job, jobs, chunksize=1)
    tot, n_fail = Counter(), 0
    for r in out:
        tot.update(r["mine"])
        n_fail += r["n_fail"]
        print(f"square {r['s']} {r['sq']}: {r['leaves']} leaves, R0 covered {r['R0_covered']}, disjoint "
              f"{r['disjoint']}; my decisions {dict(sorted(r['mine'].items()))}; undecided {r['n_fail']} "
              f"{r['fails'][:3]}; {r['sec']} s")
    print(f"total: {dict(sorted(tot.items()))}; undecided {n_fail}; {time.time() - t0:.0f} s")
    print("A34H_PASS" if n_fail == 0 and all(r["R0_covered"] and r["disjoint"] for r in out) else "A34H_FAIL")


if __name__ == "__main__":
    main()
