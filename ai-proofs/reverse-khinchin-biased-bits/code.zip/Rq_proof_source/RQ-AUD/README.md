# RQ-AUD: hostile audit of the R(q) proof

This folder holds the independent audit (RQ-AUD) of the proof of the exact
value of

    R(q) = sup_{n, alpha != 0} E|sum_i alpha_i chi_i| / |alpha|_2,

where chi_i are i.i.d. normalised q-biased bits (see `uploads/COMMON_6b37.md`).

- `AUDIT.md`: the audit ledger. Every audited claim gets an id (A.0, A.1, ...), a UTC timestamp,
  a verdict (VALID / VALID WITH FIXES / INVALID) and a novelty label (NEW / KNOWN).
- `audit/thmK/`: independent verification of BF3 Theorem K (R(q) = 2 sqrt(q(1-q)) on
  [3/8, 5/8]): symbolic identities, exact hand cases, an exact-rational re-implementation of the
  paper's interval scheme, an independent Arb ball-arithmetic certificate, and numerical attempts
  to break the statement. Outputs are in `audit/thmK/outputs/`.

## Running the checks

```bash
pip install sympy mpmath python-flint numpy
cd audit/thmK
python3 v1_identities.py          # exact symbolic identities of BF3 §9.4
python3 v2_endpoint_arb.py        # certified Arb proof of the computer-assisted step
python3 v3_paper_scheme_exact.py  # exact-rational re-implementation of BF3's box scheme + hand cases
python3 v4_break_attempt_numeric.py 12   # numerical counterexample search (evidence only)
python3 v5_sanity_attacks.py      # randomized attacks on auxiliary facts
python3 v6_method_limit.py        # where the BF3 method stops below q = 3/8
```
