#!/usr/bin/env bash
# Mirror the audit working folder to the shared store (no .git, no rendered page images, no large scratch files).
# The store does not keep modification times, so changes are detected by content: .mirror_manifest (local only,
# not mirrored or committed) holds the md5 of every file as last copied, and only new or changed files are copied.
# Files listed in the old manifest but no longer present here are removed from the store.
set -u
export LC_ALL=C
DEST=/cursor/stores/bot/rq/RQ-AUD
MAN=/workspace/.mirror_manifest
cd /workspace
mkdir -p "$DEST"
find . -type f \
  -not -path './.git/*' -not -path './agent-tools/*' -not -path './terminals/*' -not -path '*/__pycache__/*' \
  -not -path './work/pg*.png' -not -path './audit/rqc/work7/*_P.bin' -not -path './audit/rqc/work7/*_rep.txt' \
  -not -path './audit/rqa/k3_data/k3/*' -not -path './audit/rqa/k4_data/k4/*' -not -path './audit/rqa/k5_data/k5/*' -not -name '.mirror_manifest*' -print0 \
  | xargs -0 md5sum | sort > "$MAN.new"
touch "$MAN"
fail=0
n=0
while IFS= read -r line; do
  path="${line#*  }"
  if mkdir -p "$DEST/$(dirname "$path")" && cp "$path" "$DEST/$path"; then
    n=$((n + 1))
  else
    fail=1
  fi
done < <(comm -23 "$MAN.new" <(sort "$MAN"))
d=0
while IFS= read -r path; do
  [ -n "$path" ] && rm -f "$DEST/$path" && d=$((d + 1))
done < <(comm -13 <(cut -d' ' -f3- "$MAN.new" | sort) <(cut -d' ' -f3- "$MAN" | sort))
if [ "$fail" -eq 0 ]; then
  mv "$MAN.new" "$MAN"
else
  echo "some copies failed; manifest not updated, the next run retries them" >&2
fi
date -u +"%Y-%m-%d %H:%M:%S UTC" > "$DEST/LAST_MIRROR.txt"
echo "mirrored $n changed files, removed $d deleted ones, at $(cat "$DEST/LAST_MIRROR.txt")"
