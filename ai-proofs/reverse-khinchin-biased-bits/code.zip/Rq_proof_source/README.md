# Source files for "The exact L1–L2 constant of biased bits for every q ∈ (0,1): a complete proof of Conjecture S"

This archive holds the programs, certificates, papers, audit and referee reports behind the
192-page proof `Rq_full_proof.pdf`, included here as `RQ-A/FULL_PROOF.pdf` (md5 `9a6be20aa646ea13d716faa72f0c3607`,
recompiled for the public release; see "Changes for the public release" below).

The data that the verifiers read are in the companion archive `certificates.zip`. Unzip it over this tree
(both archives have the root folder `Rq_proof_source/`).

## The theorem

For q ∈ (0,1), let χ1, χ2, … be independent, each equal to √((1−q)/q) with probability q and to
−√(q/(1−q)) with probability 1−q. Let R(q) be the best constant in E|Σ αᵢχᵢ| ≤ R(q)‖α‖₂.

**Conjecture S (proved for all q):**  R(q) = 2√(q(1−q)) · max_{k≥1} √k · q̂^{k−1}, where q̂ = max(q, 1−q).
The supremum is attained by equal coefficients on k coordinates.

| Part | Range | Chapters | Folder |
|---|---|---|---|
| I | middle range [q6, 1−q6] = [1−√(5/6), √(5/6)], k = 1..5 | 1–6 (Theorems 1–6) | `RQ-A/` (54 of the 105 Theorem 6 data files were computed by RQ-C) |
| II | reduces (0, q5] to the q-free inequality ID*(C5) by Poissonisation | 7 | `RQ-B/rq/`, plus RQ-A's U.1–U.3 (`RQ-A/MAIN_RESULT_U9.*`) |
| III | localisation: only measures on [−1.54, 1.54] are needed (claim C15) | 8 | `RQ-C/` |
| IV | band lemma (Thm 9.13) and heavy far region (Thm 9.16) | 9 | `RQ-D/` |
| V | light far region, E|Z_K| ≤ 171/200 < C5 (Thm 10.1) | 10 | `RQ-B/numerics/` |

The mirror q ↦ 1−q covers [1−q5, 1). Chapters 7 and 8 have no computer-assisted step.

## Layout

The folders keep the layout of the working folders, so the `scripts/…` and `outputs/…` paths cited in the PDF resolve.
RQ-A's paths in the PDF are relative to `RQ-A/`. The paths for the other folders are relative to this root.

```
RQ-A/            Part I: papers MAIN_RESULT*.tex/md/pdf, FULL_PROOF.tex/pdf, scripts/, outputs/,
                 full_proof/ (hand-written parts and pinned sources/ of the assembled PDF), far_jobs/
RQ-B/            Part II paper (rq/MAIN_RESULT.tex/md) and Part V code + certificates (numerics/)
RQ-C/            Part III (claim C15), literature, numerics, k=4/k=5 cross-checks
RQ-D/            Part IV: scripts/, outputs/ (bandstar_cert, plus_cert), MAIN_RESULT.tex
RQ-AUD/          hostile auditor: AUDIT.md (ledger A.1–A.41) and audit/ (its own re-verification code)
RQ-REF1..3/      independent referees: REFEREE.md, ref/ (their own code), logs/
tools/           pdf_md5_register.txt, check_pdf_md5.sh, check_data_md5.sh (added for this release)
```

## Software

These versions come from the PDF's register and the run logs. Earlier or later versions will probably work too.

* Python 3.12.3
* numpy 2.5.4, scipy 1.18.1 (scipy's HiGHS is used only by the untrusted LP generators), sympy 1.14.0, mpmath 1.3.0
* python-flint 0.9.0 (arb balls and fmpq): needed for RQ-D (Part IV), RQ-B's far_verify, RQ-REF1 and RQ-AUD
* gmpy2 2.3.2: needed only for RQ-REF2 and RQ-REF3 (see their `requirements.txt`)
* highspy: needed only for some RQ-C exploratory scripts. matplotlib: needed only for RQ-C figures.
* The standard library is used everywhere else (fractions, multiprocessing, lzma, json, hashlib, …).

```
pip install numpy scipy sympy mpmath python-flint gmpy2
```

All the verifiers decide inequalities in exact rationals (Sturm sequences, Fraction) or in outward-rounded
interval/ball arithmetic (mpmath intervals, arb). Floating point is used only by the generators.

## Re-running the proof (commands exactly as in the PDF)

### Part I — Chapters 1–6 (run in `RQ-A/scripts`)

```
pip install numpy scipy sympy mpmath
cd RQ-A/scripts
python3 verify_all.py          # Theorem 1 (Ch.1), parts A-E, about one minute
python3 break_tests.py         # negative tests
python3 verify_k2.py           # Theorem 2 (Ch.2), parts A-G, about 5 minutes on 8 cores
python3 break_tests_k2.py      # about 15 s
RQ_K=3 python3 verify_k2.py    # Theorem 3 (Ch.3), parts A-G (certificates 317 s)
RQ_K=3 python3 break_tests_k2.py
python3 verify_k3b.py          # Theorem 4 (Ch.4), about 2 minutes on 8 cores (recorded 93 s)
python3 break_tests_k3b.py
python3 fourbit.py             # four-bit lemma (generator-side check)
python3 verify_k4.py           # Theorem 5 (Ch.5), about 6 minutes on 8 cores (recorded 367 s)   [needs outputs archive]
python3 break_tests_k4.py      # about 10 s
python3 bitlemma_k4.py
python3 verify_k5.py           # Theorem 6 (Ch.6), about 75 minutes on 8 cores (recorded 4449 s, 9.8 CPU-h)  [needs outputs archive]
python3 break_tests_k5.py      # about 30 s
python3 bitlemma_k5.py
```

Optional data regeneration uses the generators. These are untrusted: their output is re-checked by the verifiers above.

```
python3 cover_lp6.py 1 776887/500000 0 4/25 ../outputs/cover/r1a.json          # Ch.1, one rectangle (run_cover.sh)
python3 quartic_verify.py 611/400 1553774/1000000 9/25 471/1000 ../outputs/quartic_cover.json
python3 cover2c.py 421/200 1054691/500000 1 ../outputs/cover2c/b10b_p.json 1 8 11 18 ms                       # Ch.2, one slab
RQ_K=3 RQ_AS=2/5 python3 cover2c.py 2109381/1000000 423/200 1 ../outputs/k3/cover2c/p00.json 1 8 12 18 ms    # Ch.3, one slab
bash run_k3b.sh                # Ch.4, all data, about 40 minutes with 8 jobs
bash run_k4.sh                 # Ch.5, all data, 8.5 job-hours
bash run_k5.sh                 # Ch.6, all data, 66 job-hours
```

The large k=4 and k=5 certificate data (`RQ-A/outputs/k4/`: 28 files, 79.6 MB; `RQ-A/outputs/k5/`: 68 files, 500.6 MB)
are **not released** (too large for this site; together with the other large files below they form a 147.6 MB `.tar.xz`).
Regenerate them with `run_k4.sh` / `run_k5.sh`; `bash tools/check_data_md5.sh` then checks them against the shipped md5 lists.

### Part IV — Chapter 9 (RQ-D; from `RQ-D/`, as in `RQ-D/README.md`)

```
python3 scripts/verify_bandstar.py all 0.0078125 8 outputs/verify_bandstar_squares.jsonl   # Theorem 9.13 band (recorded 793 s, 8 processes, 80-bit arb)
PYTHONPATH=scripts python3 scripts/verify_bandstar_controls.py 8                         # controls (about 60 s)
python3 -B scripts/bandstar_record.py all 8 outputs/bandstar_cert         # band again, recording all 7,874,211 leaf boxes (about 13 min)
python3 -B scripts/bandstar_replay.py outputs/bandstar_cert 8             # replay of the record (about 30 s)
python3 -B scripts/bandstar_replay.py outputs/bandstar_cert 8 selftest    # tampered records must be rejected
cd scripts
python3 verify_plus.py ../outputs/plus_cert/certs_v1_r[0-4].jsonl --nproc 8       # Theorem 9.16 heavy far region (recorded 25 s)
python3 verify_plus_controls.py ../outputs/plus_cert/certs_v1_r[0-4].jsonl        # controls
python3 test_plus_verify.py ../outputs/plus_cert/certs_v1_r0.jsonl                # float self-tests
```
`plus_cert.py` (HiGHS LP) and `plus_driver.py` are generators. They are not trusted.
`bandstar_record.py` and `bandstar_replay.py` were added after the referee's report (REF3 remark 2). Their outputs are pinned in the PDF, but they were not audited as programs.

### Part V — Chapter 10 (RQ-B; from `RQ-B/numerics/`, per `RQ-B/rq/MAIN_RESULT.md` §13.6)

```
bash reproduce_flight.sh 8                                             # all three cases + md5 check, about 15 min on 8 cores
# or one case at a time:
python3 cover_check.py nsplit cover_final/nsplit_D14.jsonl.xz 8         # case 1: 8481 certs, about 8 min on 8 cores
python3 cover_check.py chord  cover_final/chord_D14.jsonl.xz  2         # case 2: 1212 certs, about 5 min on 2 cores
python3 cover_check.py light  cover_final/light_vl025_D18.jsonl.xz 8    # case 3: 1273 certs
python3 cover_controls.py cover_final/chord_D14.jsonl.xz 40 1           # controls (usage: CERTFILE NSAMPLE SEED)
```
The verifier is `cover_check.py` together with `cover_common.py` and `far_verify.py`. `far_cert.py` is the certificate generator and is not trusted, except for one function: `cert_from_json` (hex doubles → exact rationals) is imported from it. `cover_driver.py` is a driver and is not trusted. `cover_semantic.py` is evidence only.
The recorded results are in `cover_final/reproduce_flight.out`: 10,966 certificates accepted, 0 rejected, max U = 0.854996980551545 < 171/200.
Windows 30–35 of the nsplit case were run on RQ-A's machine with `RQ-A/outputs/far_jobs/nsplit_k30_35/rqa_nsplit_k30_35.sh`.

### Independent re-verifications

None of these are needed for the proof, but they repeat it with separate code.

* `RQ-REF1/README.md`: Theorems 1–4, with its own code (`pip install sympy numpy mpmath python-flint`). Each theorem takes about 2 minutes or less on 8 processes.
* `RQ-REF2/README.md`: Theorems 5–6 (gmpy2). Run from `ref/` with `DATA=../../RQ-A/outputs`. This needs the outputs archive.
* `RQ-REF3/README.md`: Parts II–V: `constants.py`, `heavy_verify.py`, `light_verify.py`, and `band_verify.py` (about 9 minutes).
  `ref/heavy_verify.py` and `ref/light_verify.py` find the certificate files relative to this archive root.
* `RQ-AUD/AUDIT.md` and `RQ-AUD/audit/`: the auditor's ledger and its own verifiers. The verifiers cited in the PDF are `audit/rqd/a34_bandstar_verify.py`,
  `audit/rqd/a38_heavy_verify.py`, `audit/rqb/a39_lib.py`, `audit/rqb/a39_light_verify.py` and `audit/chain/a40_chain_seams.py`.

### Rebuilding the PDF

From `RQ-A/`, run `python3 scripts/build_full_proof.py`, then `python3 scripts/check_full_proof.py`. The hand-written parts are in
`full_proof/`, and the pinned copies of each source are in `full_proof/sources/`. You need a LaTeX installation (pdflatex). The build script reads its inputs relative to this archive root. The `.tex` sources compile on their own.

## Which scripts the proof uses

**Used by the proof:** every program listed in `tools/pdf_md5_register.txt` (the md5-pinned files of the PDF's Appendix A), plus the
modules they import:
* RQ-A: `verify_all.py`, `verify_k2.py`, `verify_k3b.py`, `verify_k4.py`, `verify_k5.py`, `exactcert.py`, `quartic_verify.py`,
  `cover_lp6.py`, `fourbit.py`, `bitlemma_k4.py`, `bitlemma_k5.py`, `break_tests*.py`, `k4_kinds_check.py`, `quartic_appendix_bounds.py`, `far_job_crosscheck.py`, `run_k3b.sh`, `run_k4.sh`, `run_k5.sh`.
* RQ-B/numerics: `cover_check.py`, `cover_common.py`, `far_verify.py`, `cover_controls.py`. Generators: `far_cert.py`, `cover_driver.py`.
* RQ-D/scripts: `verify_bandstar.py`, `verify_bandstar_controls.py`, `verify_plus.py`, `plus_verify_lib.py`, `verify_plus_controls.py`, `bandstar_record.py`, `bandstar_replay.py`.

**Generators:** these produce the certificates and are not trusted. They are `cover_lp6.py`, `cover_lp10.py`, `cover5.py`, `cover6.py`, `cover2c.py`, `cert*.py`, `lp2c.py`, `nearcircle.py`, `nsphere3.py` in RQ-A, `far_cert.py` in RQ-B, and `plus_cert.py` and `plus_driver.py` in RQ-D.

**Exploratory, not part of the proof:** everything else. Examples are RQ-A's `scan_*`, `moment_lp*`, `msplit_explore*`, `*_probe*` and `verify_thmK_bf3.py`;
most of RQ-B/numerics (`*_test.py`, `*_probe.py`, `*_sup.py`, `rid*`, `c5_*`, `k2_*`, …); RQ-C's `hunt_*`, `far_split_*`, `k4_comp*` and the other cross-checks;
RQ-D's `explore_*`, `pair_bellman.py`, `heavy_scan.py`, `bandstar_soundness2.py` and `verify_band.py` (Theorem 9.10, which the Main Theorem does not use). They are kept for the record.

## md5 check against the PDF

The PDF pins the md5 sums of 121 files: sources, programs, outputs and certificates (Appendices A–C, collected in
`tools/pdf_md5_register.txt`). Unzip `code.zip` and `certificates.zip` into the same folder, then run
`bash tools/check_pdf_md5.sh` from the root `Rq_proof_source/`.

Result for this release (28 Oct 2026): **121 OK, 0 MISMATCH, 0 MISSING.**

Eleven of these files were edited for the public release (wording, or absolute paths made relative; see below).
The register and the recompiled `RQ-A/FULL_PROOF.pdf` give the md5 sums of the released copies. Logs and reports
written during the work (for example the RQ-REF3 report and the auditor's outputs) still record the sums of the
working copies.

The data manifests shipped with the proof: k2, k3, k3b (RQ-A) and RQ-B `cover_final/MD5SUMS.txt` pass with
`certificates.zip` unpacked. Run `bash tools/check_data_md5.sh` from this root. The k2/k3 lists are relative to `RQ-A/`,
and the k3b/k4/k5 lists are relative to `RQ-A/outputs/`. The k4 and k5 lists report their large data files as
missing unless you regenerate them (see Part I above).

With both archives unpacked, `verify_all.py` passes (parts A–E), as do RQ-A `break_tests.py` and `verify_k3b.py`,
RQ-D `verify_plus.py` and `bandstar_replay.py`, and RQ-B `cover_check.py chord`.

## What was left out, and why

* `.git/` directories, `__pycache__/` and `*.pyc` files: version-control and cache files.
* `RQ-C/rqa_k5/` (127 MB): a duplicate of RQ-A's k=5 run data. The 54 data files RQ-C computed for Theorem 6 are in `RQ-A/outputs/k5/`
  (not released; see above) and are listed in `RQ-A/outputs/k5_MD5SUMS.txt`.
* `RQ-AUD/uploads`, `RQ-B/uploads`, `RQ-C/uploads`: identical copies of an unrelated reference PDF and the task brief.
* Not released (too large): 124 files over 1 MB, 696 MB raw. These are under `RQ-A/outputs/k4/` and `RQ-A/outputs/k5/` (the Theorem 5–6 certificate data),
  `RQ-C/numerics/out/` (RQ-C's k=4 cross-check data), `RQ-AUD/audit/rqc/` (the auditor's copy of that data) and `RQ-AUD/audit/snapshots/` (earlier copies of the full-proof PDF).
  The small files in those folders (logs, job lists, md5 lists) stay in this zip.
* Also not released: 376 data files (49 MB raw) under `RQ-AUD/audit/` that are byte-identical copies
  of author data still in this zip (for example `audit/rqa/k2_data`, `k3b_data`, `audit/rqb/*_data`, `audit/rqd/heavy_2230`). The auditor
  took these copies as snapshots before re-verifying. The auditor's own code, logs and reports stay in this zip. Some auditor scripts read these
  snapshot folders, so they cannot be re-run from this release.

## Caveats

* The recorded runs, logs and times are the ones cited in the PDF. For this release, the verifiers listed above were re-run from a fresh unzip of both archives; the k=4 and k=5 verifiers need the unreleased data.
* The PDF's md5 sums for RQ-A were computed in RQ-A's working repository. This archive comes from the shared working folders, and all pinned RQ-A files match.
* Run times are the recorded wall-clock times on an 8-core Xeon. They will differ on other machines.

## Changes for the public release (Oct 28, 2026)

To publish this archive, internal working material was removed and machine-specific paths were made relative.
No program logic, certificate or data file was changed.

* Removed: the coordination files (the coordination log, the conventions file, and every `NOTES_FOR_TEAM.md`, `STATUS.md`,
  `AUDIT_REQUEST.md`, `NOTE_FOR_*.md`, `SOTA.md`, `FINDINGS.md`), `RQ-A/notes/`, the `mirror.sh` scripts, job-status
  files, `RQ-AUD/audit/snapshots/` and `RQ-AUD/audit/store_manifests/` (time-stamped copies of the working folders),
  the auditor's copies of those coordination files under `RQ-AUD/audit/*/`, and the "Store access log" section of
  `RQ-AUD/AUDIT.md`. The claim ledgers `RQ-A/CLAIMS.md` and `RQ-C/CLAIMS.md` are kept, since the PDF pins them.
* Absolute paths of the original machines were replaced by paths relative to this archive root, in scripts
  (`_ROOT` in Python, `$(dirname "$0")` in shell) and in recorded logs.
* Wording: references to internal coordination files and descriptions of the working setup were replaced by neutral
  wording (for example "the reporting rule", "the coordination log (not part of the public release)") in
  `RQ-AUD/AUDIT.md`, the RQ-REF1 and RQ-REF2 reports, both `CLAIMS.md` files, `RQ-B/rq/MAIN_RESULT.md`, and
  `RQ-A/FULL_PROOF.tex` with `RQ-A/full_proof/`. No mathematical statement, proof step, number or program was changed.
* `RQ-A/FULL_PROOF.tex` and `full_proof/*.tex` now quote the md5 sums of the released copies of the edited pinned files,
  with a note in the ledger appendix; `RQ-A/FULL_PROOF.pdf` was recompiled and `tools/pdf_md5_register.txt` regenerated.
* The certificate data were moved to the companion archive `certificates.zip`.
* Auditor scripts that compare the texts of earlier snapshots (`RQ-AUD/audit/fullproof/a41*`, `audit/chain/a40*` text checks)
  read files that are no longer included; they are not part of the proof.
