"""Make a (U) certificate self-describing (requirement from independent review): add the zone-A Hoelder partition
nodes a_c = e_0 < e_1 < ... < e_K = beta to every block record, so a verifier need not re-derive them from
the theta enclosure and the rounding rule.

The nodes are produced by exactly the construction the re-checker uses (prawitz_U_fast.two_S_upper_fast):
    a_c = float_below(theta_lo * beta / pi)      # largest double <= theta*beta/pi, so a_c <= theta*beta/pi
    es  = _edges(a_c, beta, K)                    # e_j = beta - (beta-a_c)((K-j)/K)^2, e_0=a_c, e_K=beta
Only the fields 'a_c' and 'es' are added; every load-bearing field (alpha,beta,K,xsA,xsB,TsB,x_end) is
copied unchanged, so the cell re-check and both independent from-scratch verifications of the base file
carry over verbatim (asserted here, and independently re-checked by verify_nodes_U.py).

usage: python3 add_nodes_U.py in_cert.jsonl.gz out_cert.jsonl.gz [prec]
"""
import os
import sys, gzip, json
from flint import arb, ctx
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))
import prawitz_U as pu
from prawitz_arb import float_below, THETA_LO
from prawitz_U import _edges

LOAD_BEARING = ("alpha", "beta", "K", "xsA", "xsB", "TsB", "x_end")


def main():
    inp, outp = sys.argv[1], sys.argv[2]
    prec = int(sys.argv[3]) if len(sys.argv) > 3 else 96
    ctx.prec = prec
    pu.PI = arb.pi()
    recs = [json.loads(l) for l in gzip.open(inp, "rt")]
    with gzip.open(outp, "wt") as f:
        for r in recs:
            beta, K = r["beta"], r["K"]
            a_c = float_below(arb(THETA_LO) * arb(beta) / pu.PI)
            es = _edges(a_c, beta, K)
            assert es[0] == a_c and es[-1] == beta, f"endpoint mismatch at beta={beta}"
            assert all(es[j] < es[j + 1] for j in range(K)), f"nodes not increasing at beta={beta}"
            out = dict(r)               # keep every existing field unchanged
            out["a_c"], out["es"] = a_c, es
            f.write(json.dumps(out) + "\n")
    # prove the load-bearing fields are unchanged (value-identical => identically serialized for these types),
    # so every verification of the base file transfers to the companion.
    new = [json.loads(l) for l in gzip.open(outp, "rt")]
    assert len(new) == len(recs)
    for a, b in zip(recs, new):
        for key in LOAD_BEARING:
            assert a[key] == b[key], f"load-bearing field {key} changed at beta={a.get('beta')}"
    print(f"wrote {outp}: {len(recs)} records; added a_c + es (K+1 nodes) per record at prec={prec}; "
          f"all load-bearing fields ({','.join(LOAD_BEARING)}) value-identical to {inp}")


if __name__ == "__main__":
    main()
