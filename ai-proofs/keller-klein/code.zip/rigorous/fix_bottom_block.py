#!/usr/bin/env python3
"""
fix_bottom_block.py  <cert_in>  <cert_out>  [xcal_frac] [maxA]

Re-certify the lowest-alpha block of a (U) certificate with its alpha lowered by
one ulp, so the block genuinely covers the intended real bottom endpoint B.

Why this is needed.  Production starts the first block at alpha = fl(B), the
double nearest B.  For some decimals fl(B) > B (e.g. fl(0.08)-0.08 = +1.7e-18,
fl(0.10)-0.10 = +5.6e-18), so the certificate covers [fl(B),1] and leaves the
sliver [B, fl(B)) of real a_1 uncovered.  The Keller-Klein claim is about real
a_1 >= B, so we lower the first block's alpha to the double just below fl(B),
which is < B, making coverage of [B,1] exact.  (When fl(B) <= B the certificate
already covers [B,1] and this script is unnecessary.)

Lowering alpha by one ulp (~1e-17) changes the target H(alpha) of (U-A)/(U-B)
and the requirement 1-H(alpha) of (U-C) by < 1e-17, negligible against the zone
margins (~1e-5); the block re-certifies with an essentially unchanged margin.
All other blocks are copied verbatim.
"""
import sys, gzip, json, math
from verify_block_U import verify_block_U


def main():
    if len(sys.argv) < 3:
        print(__doc__)
        sys.exit(2)
    cin, cout = sys.argv[1], sys.argv[2]
    xcf = float(sys.argv[3]) if len(sys.argv) > 3 else 1e-5
    mxa = int(sys.argv[4]) if len(sys.argv) > 4 else 2500

    recs = [json.loads(l) for l in gzip.open(cin, "rt")]
    recs.sort(key=lambda r: r["alpha"])
    b0 = recs[0]
    a_old, beta, K = b0["alpha"], b0["beta"], b0["K"]
    a_new = math.nextafter(a_old, -math.inf)
    print(f"first block [{a_old!r}, {beta!r}] K={K}")
    print(f"lowering alpha by 1 ulp: {a_old!r} -> {a_new!r}  (delta = {a_new - a_old:.3e})")

    r = verify_block_U(a_new, beta, K=K, xcal_frac=xcf, maxA=mxa)
    if not r.get("ok"):
        print("FAILED to re-certify bottom block:",
              {k: v for k, v in r.items() if k not in ("xsA", "xsB", "TsB")})
        sys.exit(1)
    print(f"re-certified: nA={r['nA']} nB={r['nB']} "
          f"marginA={r['marginA']:+.3e} marginB={r['marginB']:+.3e}")

    recs[0] = {k: r[k] for k in ("alpha", "beta", "K", "x_end", "xsA", "xsB", "TsB")}
    with gzip.open(cout, "wt") as f:
        for rr in recs:
            f.write(json.dumps(rr) + "\n")
    print(f"wrote {cout} ({len(recs)} blocks); new bottom alpha = {recs[0]['alpha']!r}")


if __name__ == "__main__":
    main()
