"""Rigorous (ball arithmetic, python-flint/arb) upper bound for the Prawitz integral

    J(x; a, T) = int_0^1 max(k(u,x,T) L_a(Tu), k(u,x,T) U_a(Tu)) du

with the envelopes of CLAIMS.md C3 (valid for every Rademacher sum with max a_i <= a):
  region 1  a v <= pi/2         L = cos(a v)^(1/a^2),                 U = exp(-v^2/2)
  region 2  pi/2 < a v <= theta L = -|cos(a v)| exp(-(1-a^2) v^2/2),  U = exp(-v^2/2)
  region 3  theta < a v <= pi   L = -|cos(a v)|^(1/a^2) = -U
  region 4  a v > pi            L = -1, U = 1
and k(u,x,T) = (1-u) sin(pi u - T u x)/sin(pi u) - sin(T u x)/pi.

All inputs a, T, x are exact binary floats (Python floats are exact dyadic rationals).
The region boundaries u = pi/(2aT), theta/(aT), pi/(aT) are enclosed in balls; the thin
slivers between the lower and upper ends of these balls are bounded crudely by
sup|k| * width (there |phi_X| <= 1, so max(kL,kU) <= |k|).
"""
import math
from flint import arb, acb, ctx

ctx.prec = 64

PI = arb.pi()


def _f_theta(y):
    return (-(y * y) / 2).exp() + y.cos()


def theta_bounds():
    """Exact floats lo < hi with f(lo) > 0 > f(hi), f(y) = exp(-y^2/2) + cos y.

    f > 0 on [0, pi/2] and f' = -y exp(-y^2/2) - sin y < 0 on [pi/2, pi], so the root theta
    in [0, pi] is unique and lies in (lo, hi)."""
    lo, hi = 1.7, 1.8
    assert _f_theta(arb(lo)) > 0 and _f_theta(arb(hi)) < 0
    for _ in range(200):
        mid = (lo + hi) / 2
        if mid == lo or mid == hi:
            break
        v = _f_theta(arb(mid))
        if v > 0:
            lo = mid
        elif v < 0:
            hi = mid
        else:
            break
    return lo, hi


THETA_LO, THETA_HI = theta_bounds()


def _kA(u, x, T):
    """k for u in [0, 1/2] (analytic at u = 0)."""
    w = PI - T * x
    return (1 - u) * (w / PI) * (w * u).sinc() / u.sinc_pi() - (T * u * x).sin() / PI


def _kB(u, x, T):
    """k for u in [1/2, 1] (analytic at u = 1)."""
    w = PI - T * x
    return (w * u).sin() / (PI * (1 - u).sinc_pi()) - (T * u * x).sin() / PI


def kernel(u, x, T):
    """k on an arb/acb ball u inside [0,1]; chooses the analytic form."""
    if isinstance(u, arb):
        if u.upper() <= 0.5:
            return _kA(u, x, T)
        if u.lower() >= 0.5:
            return _kB(u, x, T)
        # straddles 1/2: both forms are valid there
        return _kA(u, x, T)
    return _kA(u, x, T) if u.real.mid() <= 0.5 else _kB(u, x, T)


def make_integrand(region, half, a, T, x):
    a = arb(a); T = arb(T); x = arb(x)
    p = 1 / (a * a)
    om = 1 - a * a
    kf = _kA if half == 0 else _kB

    if region == 1:
        def f(u, analytic):
            k = kf(u, x, T)
            ak = k.real_abs(analytic=analytic)
            v = T * u
            U = (-(v * v) / 2).exp()
            cv = (a * v).cos()
            if analytic or cv.real.lower() > 0:
                L = (cv.log(analytic=analytic) * p).exp()
            elif not u.imag.is_zero():
                return acb("nan")
            else:
                # crude enclosure near a v = pi/2 on a real segment: 0 <= L <= min(1,|cos|)^p
                ub = cv.abs_upper()
                if ub > 1:
                    ub = arb(1)
                L = acb(arb(0).union((ub.log() * p).exp() if ub > 0 else arb(0)))
            return ((U + L) * k + (U - L) * ak) / 2
    elif region == 2:
        def f(u, analytic):
            k = kf(u, x, T)
            ak = k.real_abs(analytic=analytic)
            v = T * u
            U = (-(v * v) / 2).exp()
            L = (a * v).cos() * (-(om * v * v) / 2).exp()
            return ((U + L) * k + (U - L) * ak) / 2
    elif region == 3:
        def f(u, analytic):
            k = kf(u, x, T)
            ak = k.real_abs(analytic=analytic)
            v = T * u
            U = ((-(a * v).cos()).log(analytic=analytic) * p).exp()
            return ak * U
    else:
        def f(u, analytic):
            k = kf(u, x, T)
            return k.real_abs(analytic=analytic)
    return f


def float_below(b):
    """A float l with l <= every point of the ball b (verified exactly)."""
    lo = b.lower()
    l = float(lo)
    while arb(l) > lo:
        l = math.nextafter(l, -math.inf)
    return l


def float_above(b):
    """A float h with h >= every point of the ball b (verified exactly)."""
    hi = b.upper()
    h = float(hi)
    while arb(h) < hi:
        h = math.nextafter(h, math.inf)
    return h


def _ball_bounds(b):
    return float_below(b), float_above(b)


def breakpoints(a, T):
    """Exact float enclosures [lo, hi] of pi/(2aT), theta/(aT), pi/(aT)."""
    aT = arb(a) * arb(T)
    b1 = _ball_bounds(PI / (2 * aT))
    b2 = (float_below(arb(THETA_LO) / aT), float_above(arb(THETA_HI) / aT))
    b3 = _ball_bounds(PI / aT)
    return b1, b2, b3


def J_upper(x, a, T, abs_tol=1e-14, rel_tol=1e-12, verbose=False, stats=None):
    """Rigorous upper bound (an arb ball whose upper end bounds J) for J(x; a, T)."""
    (l1, h1), (l2, h2), (l3, h3) = breakpoints(a, T)
    # regions as (lo, hi, region id) between the slivers
    pieces = [(0.0, l1, 1), (h1, l2, 2), (h2, l3, 3), (h3, 1.0, 4)]
    slivers = [(l1, h1), (l2, h2), (l3, h3)]
    total = arb(0)
    xa, Ta = arb(x), arb(T)
    for lo, hi, r in pieces:
        lo, hi = max(lo, 0.0), min(hi, 1.0)
        if hi <= lo:
            continue
        for half, (s, e) in enumerate([(lo, min(hi, 0.5)), (max(lo, 0.5), hi)]):
            if e <= s:
                continue
            f = make_integrand(r, half, a, T, x)
            val = acb.integral(f, s, e, abs_tol=abs_tol, rel_tol=rel_tol,
                               eval_limit=10 ** 7, deg_limit=200)
            if not val.real.is_finite():
                raise RuntimeError(f"non-finite integral on [{s},{e}] region {r}")
            total += val.real
            if stats is not None:
                stats.append((r, s, e, float(val.real.rad())))
    for lo, hi in slivers:
        lo, hi = max(lo, 0.0), min(hi, 1.0)
        if hi <= lo:
            continue
        uu = arb(lo).union(arb(hi))
        kb = kernel(uu, xa, Ta)
        total += arb(0).union(kb.abs_upper() * (arb(hi) - arb(lo)))
    return total


def Phi(x):
    x = arb(x)
    return (1 + (x / arb(2).sqrt()).erf()) / 2


def c_of(a):
    return Phi(a) - arb(0.5)


def B_upper(x, a, T, **kw):
    return Phi(x) - arb(0.5) + J_upper(x, a, T, **kw)


if __name__ == "__main__":
    import time, math, sys
    sys.path.insert(0, "/workspace/numerics")
    from prawitz_fast import B as Bfloat
    for (a, xi) in [(0.1, 2.0), (0.1, 1.5), (0.22, 2.0), (0.05, 2.0), (0.5, 1.3)]:
        T = math.pi / a
        x = xi * a
        t0 = time.time()
        b = B_upper(x, a, T)
        t1 = time.time()
        print(f"a={a} x={x} T={T:.4f}: rigorous B in {b}  ({t1-t0:.2f}s); float B={Bfloat(x, a, T, nsub=3000):.12f}; c={c_of(a)}")
