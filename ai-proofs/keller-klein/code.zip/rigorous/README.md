# Rigorous verification (ball arithmetic)

Ball-arithmetic (Arb / python-flint 0.9.0) verification for the two parts of the paper (`keller-klein.pdf`).

**Part 1 — computer-assisted, $a_1\in[0.05,1]$ (Proposition 6.1):** finite certificates for inequality (L) on blocks
$[\alpha,\beta]$ of values of $a_1$.

**Part 2 — analytic, $a_1\in(0,0.1]$ (Section 7):** a human proof reduces $F(x)\le0$ to a fixed list of elementary
numerical inequalities; `small_a_check.py` certifies that list. No per-$a_1$ certificate is needed — the inequalities
hold for every $a_1\le0.1$ by the analytic argument, the script only bounds the finitely many constants/polynomials.

| file | role |
|---|---|
| `prawitz_arb.py` | certified upper bound `J_upper(x, a, T)` for $J(x;a,T)=\int_0^1\max(kL_a,kU_a)\,du$, certified $\theta$, $\Phi$, $c$ |
| `verify_block.py` | builds and certifies the grids (C-part, P-part, $x_e$) for one block |
| `run_range.py` | splits a range of $a_1$ into blocks, runs them in parallel, writes summary and certificate |
| `check_cert.py` | independent re-check of a stored certificate (no floating-point optimisation, any precision) |
| `small_a_check.py` | certifies the numerical facts (K1–K3, P0–P2, Q, H, X1, X2) of the analytic $a_1\le0.1$ proof |
| `results/` | `L_005_1_summary.txt`, `L_005_1_cert.jsonl.gz`, `L_005_1_check96.txt` for $a_1\in[0.05,1]$ |

```bash
pip install python-flint==0.9.0 numpy scipy
python3 run_range.py 0.05 1.0 0.6 0.02 8 L_005_1                 # ~5 min on 8 cores
python3 check_cert.py results/L_005_1_cert.jsonl.gz 0.05 1.0 96 8  # independent re-check at 96 bits
python3 small_a_check.py                                         # analytic part: "ALL CHECKS PASSED"
```

`run_range.py A0 A1 [kappa] [wmax] [workers] [tag]`: blocks $\alpha_{k+1}=\alpha_k+\min(w_{\max},\kappa\alpha_k^3)$;
failed blocks are bisected (depth $\le8$). Each certificate line stores `alpha, beta, ys, Ss, xs, Ts, x_end`.
