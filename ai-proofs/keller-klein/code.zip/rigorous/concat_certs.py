"""Concatenate (U) certificate files into one gzipped jsonl, sorted by alpha.

The blocks from several runs over abutting a1-ranges tile the union, so the combined
file is re-checkable as a single certificate by check_cert_U.py over [A0,A1].

usage: python3 concat_certs.py OUT.jsonl.gz IN1.jsonl.gz IN2.jsonl.gz ...
"""
import os
import sys, gzip, json

out = sys.argv[1]
recs = []
for path in sys.argv[2:]:
    for line in gzip.open(path, "rt"):
        line = line.strip()
        if line:
            recs.append(json.loads(line))
recs.sort(key=lambda r: r["alpha"])
with gzip.open(out, "wt") as f:
    for r in recs:
        f.write(json.dumps(r) + "\n")
los = [r["alpha"] for r in recs]
his = [r["beta"] for r in recs]
print(f"wrote {out}: {len(recs)} blocks, alpha in [{min(los):.5f},{max(his):.5f}]")
# tiling sanity as EXACT rationals (requirement from independent review): endpoints are stored doubles, so abutment is
# exact; no 1e-12 tolerance.  (The authoritative cover check is exact_coverage_U.py / check_cert_U.py.)
from fractions import Fraction
cur = min(Fraction(x) for x in los)
gaps = []
for r in recs:
    al, be = Fraction(r["alpha"]), Fraction(r["beta"])
    if al > cur:
        gaps.append((float(cur), float(al)))
    cur = max(cur, be)
print("tiling:", "CONTIGUOUS" if not gaps else f"GAPS {gaps}")
