#!/usr/bin/env bash
# Downstream pipeline for the [0.07,1] extension of the (U) certificate.
# Run AFTER results/U_007_008_cert.jsonl.gz is produced (so CPU is free).
#
#   concat RAW pieces (exact abut at the stored doubles 0.08, 0.10)
#   -> fix_bottom_block (0.07 rounds UP: fl-real=+6.7e-18, so lower alpha 1 ulp)
#   -> check_cert_U @prec96 over the full [0.07,1]
#   -> indep_verify.py (referee's from-scratch verifier) over the full [0.07,1]
#   -> safe_cross_check_U.py sample
#
# Each step aborts the pipeline on failure (set -e) so a bad result never
# silently flows into the docs.
set -euo pipefail
cd /workspace/rigorous
R=results
NEW=$R/U_007_008_cert.jsonl.gz
RAW=$R/U_007_1_raw_cert.jsonl.gz
CERT=$R/U_007_1_cert.jsonl.gz

[ -s "$NEW" ] || { echo "ABORT: $NEW missing/empty"; exit 2; }

echo "=== [1/5] concat RAW pieces -> $RAW ==="
python3 concat_certs.py "$RAW" "$NEW" $R/U_008_010_cert.jsonl.gz $R/U_010_1_cert.jsonl.gz

echo "=== [2/5] fix bottom block (lower alpha(0.07) 1 ulp) -> $CERT ==="
python3 fix_bottom_block.py "$RAW" "$CERT" 1e-5 2500

echo "=== [3/5] author recheck @prec96 over [0.07,1] ==="
python3 check_cert_U.py "$CERT" 0.07 1.0 96 8 | tee $R/U_007_1_check96_fast.txt

echo "=== [4/5] independent from-scratch verification over [0.07,1] ==="
python3 /workspace/referee_U/indep_verify.py "$CERT" --blocks all --cells all --workers 8 \
    --out /workspace/referee_U/results_007_1_all.jsonl | tee /workspace/referee_U/log_007_1_all.txt
# explicit [0.07,1] coverage confirmation (referee code prints its hardcoded 0.15 "ends" check)
python3 - "$CERT" <<'PY'
import sys, gzip, json
sys.path.insert(0, "/workspace/referee_U")
from indep_verify import coverage, load_cert
recs = load_cert(sys.argv[1])
print("explicit coverage [0.07,1.0]:", coverage(recs, 0.07, 1.0))
print("bottom alpha =", repr(recs[0]["alpha"]), " top beta =", repr(recs[-1]["beta"]))
PY

echo "=== [5/5] safe cell cross-check (200 zone-A cells) ==="
python3 safe_cross_check_U.py "$CERT" 0.07 1.0 200 96 8 | tee $R/U_007_1_safe.txt

echo "=== PIPELINE DONE: $CERT ready ==="
