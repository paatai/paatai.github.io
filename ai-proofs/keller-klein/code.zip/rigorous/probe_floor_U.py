"""Probe how low in alpha the (U) block certificate stays feasible.

For each alpha, pick beta = choose_beta(alpha, 1.0, bf) and run verify_block_U at
several K.  Report the A-width margin, overall ok/where, #cells, and time, so we can
pick a safe target range for an extended production run.
"""
import sys, time
sys.path.insert(0, "/workspace/rigorous")
from run_range_U import choose_beta, Ipi, H_f
from verify_block_U import verify_block_U

alphas = [float(a) for a in sys.argv[1].split(",")] if len(sys.argv) > 1 else [0.12, 0.11, 0.10, 0.09, 0.08]
Ks = [int(k) for k in sys.argv[2].split(",")] if len(sys.argv) > 2 else [16, 24, 32]
bf = float(sys.argv[3]) if len(sys.argv) > 3 else 0.5

for alpha in alphas:
    beta = choose_beta(alpha, 1.0, bf)
    c11 = H_f(alpha) - Ipi(alpha)
    print(f"\nalpha={alpha:.5f} beta={beta:.6f} (w={beta-alpha:.2e}) "
          f"C11margin={c11:.3e} bf*C11={bf*c11:.3e}")
    for K in Ks:
        t0 = time.time()
        r = verify_block_U(alpha, beta, K=K)
        dt = time.time() - t0
        tag = "OK " if r.get("ok") else f"FAIL@{r.get('where')}"
        mA = r.get("marginA", r.get("margin"))
        extra = ""
        if r.get("ok"):
            extra = f"nA={r.get('nA')} nB={r.get('nB')} mA={r.get('marginA'):+.2e} mB={r.get('marginB'):+.2e}"
        else:
            extra = f"margin={r.get('margin'):+.2e}" if r.get("margin") is not None else ""
        print(f"   K={K:3d}: {tag:14s} {extra}  ({dt:.1f}s)")
