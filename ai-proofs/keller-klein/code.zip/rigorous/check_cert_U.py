"""Independent re-check of a (U) certificate produced by run_range_U.py.

usage: python3 check_cert_U.py results/<tag>_cert.jsonl.gz A0 A1 [prec] [workers]

For every block [alpha,beta] the stored grids are re-verified from scratch in ball arithmetic at
working precision `prec` (no floating-point optimisation, higher precision than production):
  (A) 2 S(x_{i+1}; beta, pi/beta, K) <= H(x_i) + H(alpha),  x_0=0 ... x_{nA}=alpha/2   (zone A)
  (B) 2 J(-x_{i+1}; beta, T_i)       <= H(x_i) + H(alpha),  x_0=alpha/2 ... x_{nB}=x_end (zone B)
  (C) H(x_end) >= 1 - H(alpha)                                                           (zone C)
and the zone grids must abut (xsA[-1]==alpha/2==xsB[0], xsB+[x_end] increasing).  Finally the blocks
must tile [A0,A1].  H(x)=2Phi(x)-1; a1 in [alpha,beta] gives H(x)+H(a1) >= H(x_i)+H(alpha) and
Pr[|X|<=x] <= value at the right endpoint, so each cell inequality implies (U) on that cell.
"""
import sys, gzip, json, math
from multiprocessing import Pool

sys.path.insert(0, "/workspace/rigorous")


def check_block(args):
    rec, prec, mode = args
    from flint import arb, ctx
    import prawitz_arb as pa
    import prawitz_U as pu
    import prawitz_U_fast as puf
    ctx.prec = prec
    pa.PI = arb.pi()
    pu.PI = pa.PI                       # keep the two namespaces' pi in sync at this precision
    puf.pu.PI = pa.PI
    # mode selects the zone-A bound: "fast" (default) or "safe" (obviously-correct real_abs everywhere).
    two_S = puf.two_S_upper_fast if mode == "fast" else pu.two_S_upper
    # tolerances: ball accuracy far tighter than the certificate margins (~3e-4 zone A, ~2e-6 zone B),
    # yet loose enough to be fast at high precision.
    tS = dict(abs_tol=1e-10, rel_tol=1e-9, deg_limit=180)
    tJ = dict(abs_tol=1e-10, rel_tol=1e-9)
    al, be, K, xe = rec["alpha"], rec["beta"], rec["K"], rec["x_end"]
    xsA, xsB, TsB = rec["xsA"], rec["xsB"], rec["TsB"]
    # mA, mB track rigorous LOWER bounds on the per-cell slacks H(x_i)+H(alpha)-{2S,2J} (ball .lower()).
    mA, mB = math.inf, math.inf
    if not (al < be):
        return (al, be, False, "bad block", mA, mB)
    HA = 2 * pu.Phi(arb(al)) - 1
    Tb = pa.PI / arb(be)
    xA = al / 2
    # ----- zone C
    if not (2 * pu.Phi(arb(xe)) - 1 >= 1 - HA):
        return (al, be, False, "C: H(x_end) < 1-H(alpha)", mA, mB)
    # ----- zone A
    if not xsA or xsA[0] != 0.0 or xsA[-1] != xA:
        return (al, be, False, "A-grid endpoints", mA, mB)
    for i in range(len(xsA) - 1):
        xl, xr = xsA[i], xsA[i + 1]
        if not (xr > xl):
            return (al, be, False, f"A-grid order {i}", mA, mB)
        S2 = two_S(xr, be, Tb, K=K, **tS)
        rhs = (2 * pu.Phi(arb(xl)) - 1) + HA
        if not (S2 <= rhs):
            return (al, be, False, f"(A) fails at i={i} x=({xl},{xr})", mA, mB)
        mA = min(mA, float((rhs - S2).lower()))
    # ----- zone B  (empty when x_end<=xA: zone A covers [0,xA] >= [0,x_end] and zone C covers [x_end,inf))
    if not xsB:
        if xe <= xA:
            return (al, be, True, f"ok nA={len(xsA)-1} nB=0 (B empty, x_end<=xA)", mA, mB)
        return (al, be, False, "B-grid empty but x_end>xA", mA, mB)
    if xsB[0] != xA:
        return (al, be, False, "B-grid start", mA, mB)
    if len(TsB) != len(xsB):
        return (al, be, False, "B-grid shape", mA, mB)
    grid = xsB + [xe]
    for i in range(len(xsB)):
        xl, xr = grid[i], grid[i + 1]
        if not (xr > xl):
            return (al, be, False, f"B-grid order {i}", mA, mB)
        J2 = pu.two_J_upper(xr, be, TsB[i], **tJ)
        rhs = (2 * pu.Phi(arb(xl)) - 1) + HA
        if not (J2 <= rhs):
            return (al, be, False, f"(B) fails at i={i} x=({xl},{xr})", mA, mB)
        mB = min(mB, float((rhs - J2).lower()))
    return (al, be, True, f"ok nA={len(xsA)-1} nB={len(xsB)}", mA, mB)


def main():
    import random
    path = sys.argv[1]; A0 = float(sys.argv[2]); A1 = float(sys.argv[3])
    prec = int(sys.argv[4]) if len(sys.argv) > 4 else 96
    nw = int(sys.argv[5]) if len(sys.argv) > 5 else 8
    mode = sys.argv[6] if len(sys.argv) > 6 else "fast"           # "fast" (default) or "safe"
    frac = float(sys.argv[7]) if len(sys.argv) > 7 else 1.0       # sample this fraction of blocks (safe cross-check)
    recs = [json.loads(l) for l in gzip.open(path, "rt")]
    recs.sort(key=lambda r: r["alpha"])
    coverage_recs = recs
    if frac < 1.0:
        random.seed(12345)
        recs = sorted(random.sample(recs, max(1, int(len(recs) * frac))), key=lambda r: r["alpha"])
        print(f"SAMPLE cross-check ({mode}): {len(recs)} of {len(coverage_recs)} blocks")
    bad, blocks = [], []
    gmA, gmB = math.inf, math.inf      # global min rigorous slack in zone A / zone B over all cells
    with Pool(nw) as pool:
        for al, be, ok, msg, mA, mB in pool.imap_unordered(check_block, [(r, prec, mode) for r in recs], chunksize=1):
            if ok:
                blocks.append((al, be))
                gmA, gmB = min(gmA, mA), min(gmB, mB)
            else:
                bad.append((al, be, msg))
                print("FAIL", al, be, msg, flush=True)
    # coverage is judged over ALL blocks in the cert (tiling), independent of any sampling.
    # Referee BF2-REF3 E1 / BF2-REF4 F4: compare the range endpoints and the stored block endpoints as EXACT
    # rationals (decimal string -> Fraction; stored double -> its exact dyadic value Fraction(float)), with no
    # tolerance -- so the real claim [A0,A1] (e.g. [7/100,1], not [fl(0.07),1]) is what is verified.  See
    # exact_coverage_U.py for the companion audit that also records a_1=1/10 and every stage join.
    from fractions import Fraction
    A0r, A1r = Fraction(sys.argv[2]), Fraction(sys.argv[3])
    cov = sorted((Fraction(r["alpha"]), Fraction(r["beta"])) for r in coverage_recs)
    cur, gaps = A0r, []
    for al, be in cov:
        if al > cur:
            gaps.append((float(cur), float(al)))
        cur = max(cur, be)
    if cur < A1r:
        gaps.append((float(cur), float(A1r)))
    tag = f"{mode}" + (f" sample={len(recs)}/{len(coverage_recs)}" if frac < 1.0 else "")
    print(f"checked {len(recs)} blocks at prec={prec} ({tag}): {len(bad)} failures; "
          f"coverage of [{A0},{A1}] over {len(coverage_recs)} blocks: {'COMPLETE' if not gaps else gaps}")
    if not bad:
        print(f"min rigorous slack: zone A {gmA:+.3e}, zone B {gmB:+.3e}")


if __name__ == "__main__":
    main()
