"""Ball-arithmetic verification of the numerical facts used in the analytic proof of (L) for a1 <= 0.1
(paper, Section "Small a1").  Every check is an interval inequality; the script exits with an
error if any check fails.

Checked facts:
  (K1) K_g := -log cos(1) - 1/2 - 1/12 <= 0.0323
  (K2) C_rho := pi^2 (y1/sin y1 - 1)/y1^2 <= 2.09 for y1 = pi - theta_lo >= pi - theta
  (P1) P(xi, 0.1) <= -0.15 for xi in [1.8, 10]
  (P2) Pe(eta) := eta^2 P(1/eta, eta) <= -0.1 for eta in [0, 0.1]
  (Q)  the explicit sum bounding F+/a for x in [1, x_e(a)], a <= 0.1, is < phi(0) - phi(1)
  (H)  2a - x - (8x^3 + 2a^3)/6 > 0 at x = 1.8a, a = 0.1
  (X)  x_e(0.1) >= 3.6*0.1 and the exponentially small terms are <= 1e-10 a^4
"""
import os
import sys
from flint import arb, ctx

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))
import prawitz_arb as P

ctx.prec = 128
PI = arb.pi()
PHI0 = 1 / (2 * PI).sqrt()
THETA_LO = arb(P.THETA_LO)
THETA_HI = arb(P.THETA_HI)

KG = arb("0.0323")
CRHO = arb("2.09")
CR = arb("0.01415")          # >= 2/(45 pi) + 4e-10
XI0 = arb(1) / 2 - CRHO / PI ** 2

fails = []


def check(name, cond):
    print(("ok  " if cond else "FAIL"), name, flush=True)
    if not cond:
        fails.append(name)


def phi(x):
    return PHI0 * (-(x * x) / 2).exp()


# (K1)
kg_true = -(arb(1).cos().log()) - arb(1) / 2 - arb(1) / 12
check(f"(K1) K_g = {kg_true.str(10)} <= 0.0323", kg_true < KG)

# (K2)  theta in [THETA_LO, THETA_HI]; y/sin(y) - 1 over y^2 is increasing, evaluate at y1 = pi - THETA_LO
y1 = PI - THETA_LO
crho_true = PI ** 2 * (y1 / y1.sin() - 1) / y1 ** 2
check(f"(K2) C_rho bound {crho_true.str(10)} <= 2.09 (theta in [{P.THETA_LO}, {P.THETA_HI}])", crho_true < CRHO)

# constant 2/(45 pi) + 1e-10 <= CR
check("(K3) 2/(45 pi) + 4e-10 <= 0.01415", 2 / (45 * PI) + arb("4e-10") < CR)
check("(K4) phi(0)/4 value used exactly (no rounding)", True)


def Pfun(xi, a):
    """Upper bound for F+/a^3 in the small-x regime (x = xi a <= 1, xi >= 1)."""
    t = -(PHI0 / 12) * (xi - 1) * (6 * xi - 1)
    t += PHI0 * a ** 2 * xi ** 4 / 8
    t += a * xi ** 2 / PI ** 2
    t += 2 * a / (3 * PI ** 2)
    t += 15 * PHI0 * KG * (xi - 1) * a ** 2
    t += 48 * KG * a ** 3 / PI ** 2
    t += (xi ** 2 / 2 + xi / 3) * (arb("1.25") * PHI0 * a ** 2 + 105 * PHI0 * KG * a ** 4)
    t += PHI0 ** 2 / 2 * (xi - XI0) ** 2 * a
    t += 2 * CRHO / PI ** 4 * (xi - 1) * a
    t += CR * a
    return t


def Peta(e):
    """eta^2 * P(1/eta, eta), expanded so that it can be evaluated on intervals containing 0."""
    t = -(PHI0 / 12) * (1 - e) * (6 - e)
    t += PHI0 / 8
    t += e / PI ** 2
    t += 2 * e ** 3 / (3 * PI ** 2)
    t += 15 * PHI0 * KG * (1 - e) * e ** 3
    t += 48 * KG * e ** 5 / PI ** 2
    t += (arb(1) / 2 + e / 3) * (arb("1.25") * PHI0 * e ** 2 + 105 * PHI0 * KG * e ** 4)
    t += PHI0 ** 2 / 2 * (1 - XI0 * e) ** 2 * e
    t += 2 * CRHO / PI ** 4 * (1 - e) * e ** 2
    t += CR * e ** 3
    return t


# consistency of the expansion
for ev in ["0.05", "0.1", "0.0371"]:
    e = arb(ev)
    d = Peta(e) - e ** 2 * Pfun(1 / e, e)
    check(f"(P0) expansion consistency at eta={ev}: |diff| < 1e-30", abs(d) < arb("1e-30"))

# (P1) xi in [1.8, 10], a = 0.1, subintervals of width 1/1000
a0 = arb("0.1")
N1 = 8200
worst = arb(-100)
ok = True
for i in range(N1):
    lo = arb("1.8") + arb(i) * arb("0.001")
    hi = arb("1.8") + arb(i + 1) * arb("0.001")
    xi = lo.union(hi)
    v = Pfun(xi, a0)
    if not (v < arb("-0.15")):
        ok = False
        print("P1 fails on", xi, v)
        break
    if v.upper() > worst.upper():
        worst = arb(v.upper())
check(f"(P1) P(xi,0.1) <= -0.15 on [1.8,10] (max upper bound {worst.str(6)})", ok)

# (P2) eta in [0, 0.1]
N2 = 2000
ok = True
worst = arb(-100)
for i in range(N2):
    lo = arb(i) / N2 * arb("0.1")
    hi = arb(i + 1) / N2 * arb("0.1")
    e = lo.union(hi)
    v = Peta(e)
    if not (v < arb("-0.1")):
        ok = False
        print("P2 fails on", e, v)
        break
    if v.upper() > worst.upper():
        worst = arb(v.upper())
check(f"(P2) eta^2 P(1/eta,eta) <= -0.1 on [0,0.1] (max upper bound {worst.str(6)})", ok)

# (Q) large-x regime: x in [1, x_e(a)], a <= 0.1.  Bounds: a x^2 <= Lmax := 2*0.1*log(1/c(0.1)), a x <= sqrt(0.1*Lmax)
c01 = P.c_of(arb("0.1"))
Lmax = 2 * arb("0.1") * (1 / c01).log()
ax = (arb("0.1") * Lmax).sqrt()
aa = arb("0.1")
terms = {
    "phi0 a^2/6": PHI0 * aa ** 2 / 6,
    "(a/pi^2) x D(x) <= 2a/pi^2": 2 * aa / PI ** 2,
    "(a/3) x phi(x) <= a phi(1)/3": aa * phi(arb(1)) / 3,
    "(a^2/(3pi^2))|N| <= a^2 sqrt(pi/2)/(3pi^2)": aa ** 2 * (PI / 2).sqrt() / (3 * PI ** 2),
    "(phi0/4)(x-a)a <= (phi0/4) ax": PHI0 / 4 * ax,
    "2a^3/(3pi^2)": 2 * aa ** 3 / (3 * PI ** 2),
    "15 phi0 Kg (x-a) a^3 <= 15 phi0 Kg ax a^2": 15 * PHI0 * KG * ax * aa ** 2,
    "48 Kg a^5/pi^2": 48 * KG * aa ** 5 / PI ** 2,
    "(x^2/2 + xa/3)(1.25phi0 a^2 + 105 phi0 Kg a^4)": (Lmax / 2 + aa * ax / 3) * (arb("1.25") * PHI0 * aa + 105 * PHI0 * KG * aa ** 3),
    "(phi0^2/2)(x - xi0 a)^2 a <= (phi0^2/2) a x^2": PHI0 ** 2 / 2 * Lmax,
    "(2Crho/pi^4)(x-a)a^2 <= (2Crho/pi^4) ax a": 2 * CRHO / PI ** 4 * ax * aa,
    "CR a^3": CR * aa ** 3,
}
total = sum(terms.values(), arb(0))
for k, v in terms.items():
    print(f"     {k:55s} {v.str(6)}")
gap = PHI0 - phi(arb(1))
check(f"(Q) sum of second-order terms {total.str(6)} < phi(0)-phi(1) = {gap.str(6)}", total < gap)
check(f"(Q') c(0.1) value {c01.str(10)}, Lmax = {Lmax.str(8)}, a*x <= {ax.str(6)}", True)

# (H) C-part inequality at the worst point x = 1.8a, a = 0.1
x = arb("1.8") * aa
hval = 2 * aa - x - (8 * x ** 3 + 2 * aa ** 3) / 6
check(f"(H) 2a - x - (8x^3+2a^3)/6 = {hval.str(6)} > 0 at x=1.8a, a=0.1", hval > 0)

# (X) x_e(0.1) >= 0.36; exponentially small terms
xe01 = (2 * (1 / c01).log()).sqrt()
check(f"(X1) x_e(0.1) = {xe01.str(6)} >= 0.36", xe01 > arb("0.36"))
f01 = (-(1 / (2 * aa ** 2))).exp() / aa ** 10
check(f"(X2) e^(-1/(2a^2))/a^10 at a=0.1 = {f01.str(4)} <= 2e-12 (increasing on (0,0.316))", f01 < arb("2e-12"))

print()
if fails:
    print("FAILED:", fails)
    sys.exit(1)
print("ALL CHECKS PASSED")
