"""Rigorous verification of the UPPER half (U) for all a1 in a block [alpha,beta].

(U):  Pr[|X| <= x] <= H(x) + H(a1)  for all x >= 0,  H(x)=2Phi(x)-1,  a1=max a_i in [alpha,beta].

Every bound uses a = beta (Holder sup over a<=beta, and C3 envelopes with parameter beta, both valid
for max weight a1 <= beta) and the target H(x)+H(a1) >= H(x)+H(alpha).  Pr[|X|<=x] is nondecreasing
in x and H(x)+H(alpha) is nondecreasing, so on a cell [x_i, x_{i+1}] it suffices to bound the value
at the right endpoint by the target at the left endpoint:

* ZONE A (Holder/covering), x in [0, xA], xA = alpha/2 (so x <= a1/2 and k(u,-x,T)>=0, T=pi/beta):
      grid 0=x_0<...<x_{nA}=xA with   2 S(x_{i+1}; beta, pi/beta)  <=  H(x_i) + H(alpha),      (A)
  S = sup_{a<=beta} G(a) bounded rigorously by prawitz_U.two_S_upper.
* ZONE B (envelope), x in [xA, x_end]:
      grid xA=x_0<...<x_{nB}=x_end with   2 J(-x_{i+1}; beta, T_i)  <=  H(x_i) + H(alpha).      (B)
* ZONE C, x >= x_end with H(x_end) >= 1 - H(alpha):  Pr[|X|<=x] <= 1 <= H(x)+H(a1).             (C)

All of (A),(B),(C) are checked in ball arithmetic; floats only choose grids and T.  The grids
(xsA, xsB, TsB, x_end) are returned so an independent checker can re-verify (A),(B),(C) from scratch.
"""
import math, time, sys
import numpy as np
from scipy.special import erfinv
from flint import arb, ctx

sys.path.insert(0, "/workspace/rigorous")
sys.path.insert(0, "/workspace/numerics")
from prawitz_U import two_J_upper, H, Phi, float_above, float_below, THETA_LO
from prawitz_U_fast import two_S_upper_fast as two_S_upper   # validated == safe two_S_upper, ~20x faster
import prawitz_upper as pup   # float envelope J(-x) for choosing T

ctx.prec = 64

# ---- fast float covering proxy 2 sup_a G(a;x) for predicting the zone-A march ----
_GLx, _GLw = np.polynomial.legendre.leggauss(16)
def _ugrid(nsub=500):
    e = np.linspace(0.0, 1.0, nsub + 1)
    a, b = e[:-1, None], e[1:, None]
    u = ((a + b) / 2 + (b - a) / 2 * _GLx[None, :]).ravel()
    w = ((b - a) / 2 * _GLw[None, :]).ravel()
    return u, w
_UU, _WW = _ugrid(500)
def _kfloat(u, x, T):
    rho = (1 - u) / np.tan(np.pi * u) + 1 / np.pi
    return (1 - u) * np.cos(T * u * x) + rho * np.sin(T * u * x)
def twoS_float(x, beta, T, K=10):
    k = _kfloat(_UU, x, T)
    Gg = float(np.sum(_WW * k * np.exp(-(T * _UU) ** 2 / 2)))
    ac = float_below(arb(THETA_LO) * arb(beta) / arb(math.pi))
    best = Gg
    edges = np.array([beta - (beta - ac) * ((K - j) / K) ** 2 for j in range(K + 1)])
    for j in range(K):
        hj = np.abs(np.cos(edges[j] * T * _UU)) ** (1.0 / edges[j] ** 2)
        hj1 = np.abs(np.cos(edges[j + 1] * T * _UU)) ** (1.0 / edges[j + 1] ** 2)
        pb = float(np.sum(_WW * k * np.maximum(hj, hj1)))
        best = max(best, pb)
    return 2 * best


def _down(x, k=1):
    for _ in range(k):
        x = math.nextafter(x, -math.inf)
    return x


def _bestT_env(x, beta, taus):
    """choose tau minimising the float envelope 2J(-x; beta, tau/beta).  2J is unimodal in T,
    so scan the coarse grid, then refine locally (two coarse spacings wide) around the best."""
    best = (math.inf, taus[0])
    for tau in taus:
        v = pup.BU_many_x(np.array([x]), beta, tau / beta, nsub=400)[0]
        if v < best[0]:
            best = (v, tau)
    span = taus[1] - taus[0]
    for tau in np.linspace(max(1e-6, best[1] - span), best[1] + span, 24):
        v = pup.BU_many_x(np.array([x]), beta, tau / beta, nsub=400)[0]
        if v < best[0]:
            best = (v, tau)
    return best[1] / beta, best[1]


def verify_block_U(alpha, beta, K=14, tolA=1e-10, degA=180, xcal_frac=1e-3, maxA=600):
    t0 = time.time()
    A = arb(alpha)
    HA = 2 * Phi(A) - 1
    Tb = math.pi / beta
    rec = {"alpha": alpha, "beta": beta, "K": K}

    # x_end: H(x_end) >= 1 - H(alpha)
    ha = float(HA.lower())
    xe = math.sqrt(2) * erfinv(1 - ha) * (1 + 1e-9) + 1e-12
    if not (2 * Phi(arb(xe)) - 1 >= 1 - HA):
        xe = math.sqrt(2) * erfinv(1 - ha) * (1 + 1e-7) + 1e-10
        if not (2 * Phi(arb(xe)) - 1 >= 1 - HA):
            rec.update(ok=False, where="x_end", secs=time.time() - t0)
            return rec
    xA = alpha / 2

    # ---------- ZONE A ----------  (adaptive march: predict x_next by float covering, verify in arb)
    # upfront width check near x=0: 2S(x~0) must sit below H(alpha), else the block is too wide.
    xcal = xA * xcal_frac
    S0 = two_S_upper(xcal, beta, Tb, K=K, abs_tol=tolA, rel_tol=tolA * 10, deg_limit=degA)
    if not (S0 <= HA):
        rec.update(ok=False, where="A-width", margin=float(HA.lower()) - float_above(S0),
                   secs=time.time() - t0)
        return rec
    # calibrate the float-vs-arb gap (arb is a touch larger; the float proxy misreads the cusps),
    # so the predictor's buffer can stay just above it and avoid per-cell backoffs.
    gap = max(0.0, float_above(S0) - twoS_float(xcal, beta, Tb, K=K))
    # Adaptive zone-A march buffer: a fixed 8e-5 is comfortable for large alpha but exceeds the whole
    # C11 margin (~phi(0)alpha^3/6) once alpha<~0.15, so scale it to the margin available at x~0.
    avail = float(HA.lower()) - float_above(S0)                 # rigorous margin available at x~0
    buf = min(8e-5, max(1.4 * gap + 1e-5, 0.45 * avail))
    buf = min(buf, 0.85 * avail)                                # keep the A-buffer check (buf<avail) with room
    # if the buffer already exceeds the margin at x=0, the block is too hard at this K: split it.
    if not (float_above(S0) + buf <= float(HA.lower())):
        rec.update(ok=False, where="A-buffer", margin=float(HA.lower()) - float_above(S0) - buf,
                   secs=time.time() - t0)
        return rec
    xsA = [0.0]
    marginA = math.inf
    x = 0.0
    while x < xA - 1e-13:
        rhs = (2 * Phi(arb(x)) - 1) + HA         # H(x_i) + H(alpha), target fixed at left point
        target = float(rhs.lower())
        if twoS_float(xA, beta, Tb, K=K) <= target - buf:
            xnext = xA
        else:
            lo, hi = x, xA
            for _ in range(48):
                mid = 0.5 * (lo + hi)
                if twoS_float(mid, beta, Tb, K=K) <= target - buf:
                    lo = mid
                else:
                    hi = mid
            xnext = lo
        if xnext <= x + 1e-12:
            xnext = min(xA, x + 2e-5)
        # rigorous check, with geometric backoff
        S = two_S_upper(xnext, beta, Tb, K=K, abs_tol=tolA, rel_tol=tolA * 10, deg_limit=degA)
        tries = 0
        while not (S <= rhs):
            xnext = x + 0.5 * (xnext - x)
            if xnext <= x + 1e-12:
                rec.update(ok=False, where="A", xi=x, margin=float(rhs.lower()) - float_above(S),
                           secs=time.time() - t0)
                return rec
            S = two_S_upper(xnext, beta, Tb, K=K, abs_tol=tolA, rel_tol=tolA * 10, deg_limit=degA)
            tries += 1
            if tries > 40:
                rec.update(ok=False, where="A-stall", xi=x, secs=time.time() - t0)
                return rec
        marginA = min(marginA, float(rhs.lower()) - float_above(S))
        x = xnext
        xsA.append(x)
        if len(xsA) > maxA:
            rec.update(ok=False, where="A-maxsteps", xi=x, secs=time.time() - t0)
            return rec
    xsA[-1] = xA

    # ---------- ZONE B ----------  (envelope march)
    taus = list(np.pi * np.linspace(0.3, 8.0, 45))
    x = xA
    xsB, TsB = [], []
    marginB = math.inf
    while x < xe - 1e-15:
        T, tau = _bestT_env(x, beta, taus)
        rhs = (2 * Phi(arb(x)) - 1) + HA
        target = float(rhs.lower())
        # binary search on x_next in (x, xe] using float envelope as proxy
        if pup.BU_many_x(np.array([xe]), beta, T, nsub=400)[0] <= target:
            xnext = xe
        else:
            lo, hi = x, xe
            for _ in range(44):
                mid = 0.5 * (lo + hi)
                if pup.BU_many_x(np.array([mid]), beta, T, nsub=400)[0] <= target - 1.2e-5:
                    lo = mid
                else:
                    hi = mid
            xnext = _down(lo, 2)
        if xnext <= x + 1e-13:
            xnext = min(xe, x + 1e-4)
        Jb = two_J_upper(xnext, beta, T)
        tries = 0
        while not (Jb <= rhs):
            xnext = x + 0.5 * (xnext - x)
            if xnext <= x + 1e-13:
                rec.update(ok=False, where="B", x=x, margin=float(rhs.lower()) - float_above(Jb),
                           secs=time.time() - t0)
                return rec
            Jb = two_J_upper(xnext, beta, T)
            tries += 1
            if tries > 40:
                rec.update(ok=False, where="B-stall", x=x, secs=time.time() - t0)
                return rec
        marginB = min(marginB, float(rhs.lower()) - float_above(Jb))
        xsB.append(x); TsB.append(T)
        x = xnext
        if len(xsB) > 6000:
            rec.update(ok=False, where="B-maxsteps", x=x, secs=time.time() - t0)
            return rec

    rec.update(ok=True, nA=len(xsA) - 1, nB=len(xsB), x_end=xe,
               marginA=marginA, marginB=marginB, secs=time.time() - t0,
               xsA=xsA, xsB=xsB, TsB=TsB)
    return rec


if __name__ == "__main__":
    al = float(sys.argv[1]); be = float(sys.argv[2])
    K = int(sys.argv[3]) if len(sys.argv) > 3 else 14
    xcf = float(sys.argv[4]) if len(sys.argv) > 4 else 1e-3
    mxa = int(sys.argv[5]) if len(sys.argv) > 5 else 600
    r = verify_block_U(al, be, K=K, xcal_frac=xcf, maxA=mxa)
    print({k: v for k, v in r.items() if k not in ("xsA", "xsB", "TsB")})
