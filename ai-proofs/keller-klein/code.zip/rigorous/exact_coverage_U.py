"""Exact-rational coverage audit of a (U) certificate.

Requirement from independent review:
the coverage test must compare the range endpoints and the stage joins with the stored block endpoints as
*exact rationals*, never through floating point, so that the extremal equal-weight point a_1 = 1/10 (100 equal
weights -- the tightest case on the whole range) and every decimal stage join are provably inside a certified block.

Each block [alpha, beta] is certified at its stiffer LEFT endpoint alpha and, via H(a_1) >= H(alpha), proves (U)
for every a_1 in [alpha, beta]. So a_1 = r is covered iff some block has alpha <= r <= beta; we then record that
block and that it is applied at alpha <= r. Endpoints are read as Fraction(double), i.e. the exact dyadic value of
the stored IEEE double; range endpoints and joins are read as exact decimal rationals (Fraction("0.07") = 7/100).

usage: python3 exact_coverage_U.py results/<tag>_cert.jsonl.gz [A0] [A1]
"""
import os
import sys, gzip, json
from fractions import Fraction


def main():
    path = sys.argv[1]
    A0 = Fraction(sys.argv[2]) if len(sys.argv) > 2 else Fraction(7, 100)
    A1 = Fraction(sys.argv[3]) if len(sys.argv) > 3 else Fraction(1)
    recs = [json.loads(l) for l in gzip.open(path, "rt")]
    # exact dyadic value of each stored double; no tolerance anywhere below.
    blocks = sorted((Fraction(r["alpha"]), Fraction(r["beta"])) for r in recs)
    n = len(blocks)
    print(f"certificate: {path}")
    print(f"blocks: {n}")
    print(f"claimed range as exact rationals: [A0, A1] = [{A0} = {float(A0):.17g}, {A1} = {float(A1):.17g}]")

    # (1) tiling as exact rationals: interior abutments, gaps, overlaps, and the two ends.
    gaps = overlaps = 0
    for i in range(1, n):
        prev_be, cur_al = blocks[i - 1][1], blocks[i][0]
        if cur_al > prev_be:
            gaps += 1
            print(f"  GAP between block {i-1} and {i}: ({float(prev_be):.17g}, {float(cur_al):.17g})")
        elif cur_al < prev_be:
            overlaps += 1
            print(f"  OVERLAP between block {i-1} and {i}: ({float(cur_al):.17g}, {float(prev_be):.17g})")
    a0, aN = blocks[0][0], blocks[-1][1]
    bottom_ok, top_ok = (a0 <= A0), (aN >= A1)
    print(f"interior abutments exact: {n - 1 - gaps - overlaps}/{n - 1}  (gaps={gaps}, overlaps={overlaps})")
    print(f"bottom: first alpha = {float(a0):.17g}  (alpha - A0 = {float(a0 - A0):+.3e});  alpha <= A0 ? {bottom_ok}")
    print(f"top:    last  beta  = {float(aN):.17g}  (beta  - A1 = {float(aN - A1):+.3e});  beta  >= A1 ? {top_ok}")
    tiling_ok = (gaps == 0 and overlaps == 0 and bottom_ok and top_ok)
    print(f"EXACT TILING of [{A0}, {A1}]: {'COMPLETE' if tiling_ok else 'INCOMPLETE'}")

    # (2) key exact rationals: the rational equal-weight extremals a_1 = 1/m (m^2 equal weights) with 1/m in
    #     [A0, A1], and the decimal stage joins. Each must lie in a certified block, applied at alpha <= r.
    def covered(label, r):
        hit = [(al, be) for (al, be) in blocks if al <= r <= be]
        if not hit:
            print(f"  {label}: r = {r} = {float(r):.17g}  --  NOT COVERED by any block")
            return False
        al, be = hit[0]
        print(f"  {label}: r = {r} = {float(r):.17g}  in block [{float(al):.17g}, {float(be):.17g}]; "
              f"certified at left endpoint alpha = {float(al):.17g} <= r  (so H(a_1) >= H(alpha))")
        return True

    print("rational equal-weight extremals a_1 = 1/m with 1/m in range (m^2 equal weights):")
    ew_ok = True
    for m in range(1, 1000):
        r = Fraction(1, m)
        if r < A0:
            break
        if r <= A1:
            note = "  <-- 100 equal weights, tightest case on the whole range" if m == 10 else ""
            ew_ok &= covered(f"n={m*m}, a_1=1/{m}{note}", r)
    print("decimal stage joins:")
    joins = [("0.07 (bottom)", Fraction(7, 100)), ("0.08", Fraction(8, 100)),
             ("0.10", Fraction(10, 100)), ("0.11", Fraction(11, 100)),
             ("0.15", Fraction(15, 100)), ("1", Fraction(1))]
    join_ok = all(covered(lbl, r) for lbl, r in joins if A0 <= r <= A1)

    ok = tiling_ok and ew_ok and join_ok
    print(f"RESULT: {'PASS -- exact-rational cover of [%s,%s] complete; a_1=1/10 and all stage joins covered' % (A0, A1) if ok else 'FAIL'}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
