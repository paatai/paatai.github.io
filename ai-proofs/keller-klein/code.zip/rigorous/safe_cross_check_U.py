"""Cell-level SAFE cross-check of a (U) certificate's zone-A inequalities.

The certificate and the check_cert_U recheck bound 2 sup_a G(a) with the fast covering bound
two_S_upper_fast (region decomposition: a single smooth factor outside the narrow pi/2-straddling band,
real_abs only on the band).  This script re-verifies a random sample of INDIVIDUAL zone-A cells

    2 S(x_{i+1}; beta, pi/beta, K) <= H(x_i) + H(alpha)

with the obviously-correct real_abs covering bound two_S_upper (safe: real_abs on the whole domain),
at high precision, and records that safe >= fast on every sampled cell -- so the fast bound being a
valid upper bound follows from the (manifestly valid) safe one.  Sampling cells rather than whole
blocks makes the real_abs method (about 1000x slower per cell) tractable while still spanning the
range.  Zone B uses the same J_upper in both fast and safe, so it needs no fast-vs-safe cross-check.

usage: python3 safe_cross_check_U.py <cert.jsonl.gz> <A0> <A1> <ncells> [prec] [workers]
"""
import sys, gzip, json, random
from multiprocessing import Pool

sys.path.insert(0, "/workspace/rigorous")


def _check_cell(args):
    al, be, K, xl, xr, prec = args
    from flint import arb, ctx
    import prawitz_arb as pa
    import prawitz_U as pu
    import prawitz_U_fast as puf
    ctx.prec = prec
    pa.PI = arb.pi()
    pu.PI = pa.PI
    puf.pu.PI = pa.PI
    tS = dict(abs_tol=1e-10, rel_tol=1e-9, deg_limit=180)
    Tb = pa.PI / arb(be)
    HA = 2 * pu.Phi(arb(al)) - 1
    rhs = (2 * pu.Phi(arb(xl)) - 1) + HA
    Sfast = puf.two_S_upper_fast(xr, be, Tb, K=K, **tS)
    Ssafe = pu.two_S_upper(xr, be, Tb, K=K, **tS)
    ok_safe = bool(Ssafe <= rhs)                                 # the obviously-correct method certifies the cell
    fast_le_safe = pu.float_above(Sfast) <= pu.float_above(Ssafe) + 1e-12   # fast no looser than safe
    return (al, be, xl, xr, ok_safe, fast_le_safe,
            pu.float_above(Ssafe), pu.float_above(Sfast), float(rhs.lower()))


def main():
    path = sys.argv[1]; A0 = float(sys.argv[2]); A1 = float(sys.argv[3]); ncells = int(sys.argv[4])
    prec = int(sys.argv[5]) if len(sys.argv) > 5 else 96
    nw = int(sys.argv[6]) if len(sys.argv) > 6 else 8
    recs = [json.loads(l) for l in gzip.open(path, "rt")]
    # Restrict to blocks overlapping [A0, A1] (beta > A0 and alpha < A1). For the full-range
    # call A0=0.07, A1=1.0 this keeps every block, so the whole-cert behaviour is unchanged;
    # passing a sub-range (e.g. 0.07 0.08) genuinely focuses the sample on that stage.
    cells = []
    nblk = 0
    for r in recs:
        if not (r["beta"] > A0 and r["alpha"] < A1):
            continue
        nblk += 1
        xsA = r["xsA"]
        for i in range(len(xsA) - 1):
            cells.append((r["alpha"], r["beta"], r["K"], xsA[i], xsA[i + 1]))
    random.seed(2026)
    samp = random.sample(cells, min(ncells, len(cells)))
    samp.sort()
    print(f"blocks overlapping [{A0},{A1}]: {nblk} of {len(recs)}", flush=True)
    print(f"safe cell cross-check of {path}: {len(samp)} of {len(cells)} zone-A cells at prec={prec} on {nw} workers")
    nbad = nfls = 0
    worst_margin = float("inf")
    done = 0
    with Pool(nw) as pool:
        for al, be, xl, xr, ok_safe, fle, ssafe, sfast, rhslo in \
                pool.imap_unordered(_check_cell, [(*c, prec) for c in samp], chunksize=1):
            done += 1
            if not ok_safe:
                nbad += 1
                print(f"  SAFE FAIL [{al:.4f},{be:.4f}] cell ({xl:.5f},{xr:.5f}): safe 2S={ssafe:.8f} > rhs={rhslo:.8f}", flush=True)
            if not fle:
                nfls += 1
                print(f"  FAST>SAFE [{al:.4f},{be:.4f}] cell ({xl:.5f},{xr:.5f}): fast={sfast:.8f} safe={ssafe:.8f}", flush=True)
            worst_margin = min(worst_margin, rhslo - ssafe)
            if done % 20 == 0:
                print(f"    [{done}/{len(samp)}] min safe margin so far {worst_margin:+.2e}", flush=True)
    print(f"done: {len(samp)} cells, {nbad} safe failures, {nfls} cells with fast>safe; "
          f"min safe-method margin = {worst_margin:+.2e}  (coverage of [{A0},{A1}] established by check_cert_U)")


if __name__ == "__main__":
    main()
