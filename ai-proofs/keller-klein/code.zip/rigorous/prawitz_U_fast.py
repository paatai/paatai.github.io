"""Faster zone-A piece bound: same integrand as prawitz_U._piece_upper, but the non-analytic
max(h(alo,u),h(ahi,u)) is evaluated with acb_real_abs ONLY on the narrow band [zb,za] where
cos(alo Tu) and cos(ahi Tu) straddle pi/2.  Outside that band the sup over a in [alo,ahi] is a
single smooth factor, by the proven monotonicity of a |-> h(a,u)=|cos(aTu)|^{1/a^2}
(C3(i): psi(s)=log|cos s|/s^2 decreasing on (0,pi/2), increasing on (pi/2,pi)):

  * u < zb = pi/(2 ahi T):   a Tu < pi/2 for all a in [alo,ahi]  => h decreasing in a => max = h(alo,u)
  * zb < u < za = pi/(2 alo T): alo Tu < pi/2 < ahi Tu          => max = max(h(alo,u),h(ahi,u))  (band)
  * u > za:                  a Tu > pi/2 for all a in [alo,ahi]  => h increasing in a => max = h(ahi,u)

This removes the spurious subdivision the integrator does near u=0 and near za/zb (where the two
smooth factors coincide so the real_abs argument straddles 0), making the integral converge far
faster.  Validated against prawitz_U._piece_upper (gold, high prec) in the __main__ block.
"""
import os
import sys, math
from flint import arb, acb, ctx
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))
import prawitz_U as pu
from prawitz_U import _logcos_pow, _zero_u, Ggauss_upper, _edges, _box_upper
from prawitz_arb import _kA, _kB, kernel, float_above, float_below, THETA_LO


def _piece_upper_fast(alo, ahi, x, T, abs_tol=1e-10, rel_tol=1e-9, deg_limit=180):
    """int_0^1 k(u,-x,T) max(h(alo,u),h(ahi,u)) du, h(a,u)=|cos(aTu)|^{1/a^2}, alo<=ahi in (0,beta]."""
    xa, Ta = arb(-x), arb(T)
    plo = 1 / arb(alo) ** 2            # exact-ball Hoelder exponents 1/a^2 (no float rounding)
    phi = 1 / arb(ahi) ** 2
    za_lo, za_hi = _zero_u(alo, T)     # zero of cos(alo Tu) : u=za   (larger)
    zb_lo, zb_hi = _zero_u(ahi, T)     # zero of cos(ahi Tu) : u=zb   (smaller, zb<=za)
    balls = [(zb_lo, zb_hi), (za_lo, za_hi)]
    cuts = sorted(c for c in {0.0, 0.5, 1.0, za_lo, za_hi, zb_lo, zb_hi} if 0.0 <= c <= 1.0)
    total = arb(0)
    for s, e in zip(cuts[:-1], cuts[1:]):
        if e <= s:
            continue
        mid = 0.5 * (s + e)
        if any(blo <= s and e <= bhi for blo, bhi in balls):   # inside a zero-ball: sliver, max h <= 1
            uu = arb(s).union(arb(e))
            kb = kernel(uu, xa, Ta)
            total += arb(0).union(kb.abs_upper() * (arb(e) - arb(s)))
            continue
        kf = _kA if mid < 0.5 else _kB
        if e <= zb_lo:                 # region A: u<zb => max = h(alo), cos(alo Tu)>0
            def f(u, analytic, kf=kf):
                h = _logcos_pow(alo * (Ta * u), 1, plo, analytic)
                return kf(u, xa, Ta) * h
        elif s >= za_hi:               # region C: u>za => max = h(ahi), cos(ahi Tu)<0
            def f(u, analytic, kf=kf):
                h = _logcos_pow(ahi * (Ta * u), -1, phi, analytic)
                return kf(u, xa, Ta) * h
        else:                          # band zb<u<za: max(h(alo)[cos>0], h(ahi)[cos<0]) via real_abs
            def f(u, analytic, kf=kf):
                v = Ta * u
                hlo = _logcos_pow(alo * v, 1, plo, analytic)
                hhi = _logcos_pow(ahi * v, -1, phi, analytic)
                d = hhi - hlo
                mx = (hlo + hhi + d.real_abs(analytic=analytic)) / 2
                return kf(u, xa, Ta) * mx
        val = acb.integral(f, s, e, abs_tol=abs_tol, rel_tol=rel_tol, eval_limit=10 ** 7, deg_limit=deg_limit)
        total += val.real if val.real.is_finite() else _box_upper(alo, ahi, s, e, xa, Ta, plo, phi)
    return total


def two_S_upper_fast(x, a1, T, K=12, **kw):
    """arb upper bound for 2 sup_{a in (0,a1]} G(a;x), using the fast piece bound.  Needs x<=a1/2."""
    a_c = float_below(arb(THETA_LO) * arb(a1) / pu.PI)   # a<=a_c => aTu<=theta (Gaussian sub-bound valid)
    S = Ggauss_upper(x, a1, T, **kw)
    if not S.is_finite():
        raise RuntimeError("Ggauss non-finite")
    edges = _edges(a_c, a1, K)
    for j in range(K):
        pb = _piece_upper_fast(edges[j], edges[j + 1], x, T, **kw)
        if not pb.is_finite():
            raise RuntimeError(f"piece [{edges[j]},{edges[j+1]}] non-finite")
        if float_above(pb) > float_above(S):
            S = pb
    return 2 * S


if __name__ == "__main__":
    import time
    import numpy as np
    from prawitz_U import _piece_upper
    print("Validate _piece_upper_fast = int k(u,-x,T) max(h(alo,u),h(ahi,u)) du against an INDEPENDENT")
    print("high-resolution float quadrature (true value q), covering small beta where both ball piece")
    print("functions fall back on stiff bands.  Rigor: fast.upper >= q (valid upper bound).  Quality:")
    print("fast.upper is no looser than the obviously-correct real_abs _piece_upper (safe).")
    _glx, _glw = np.polynomial.legendre.leggauss(64)

    def _kcov(u, x, T):                       # float k(u,-x,T) = (1-u)cos(Tux)+rho(u)sin(Tux)
        rho = (1 - u) / np.tan(np.pi * u) + 1 / np.pi
        return (1 - u) * np.cos(T * u * x) + rho * np.sin(T * u * x)

    def _piece_float(alo, ahi, x, T, nsub=4000):
        e = np.linspace(1e-12, 1 - 1e-12, nsub + 1)
        a, b = e[:-1, None], e[1:, None]
        u = ((a + b) / 2 + (b - a) / 2 * _glx[None, :]).ravel()
        w = ((b - a) / 2 * _glw[None, :]).ravel()
        k = _kcov(u, x, T)
        h1 = np.abs(np.cos(alo * T * u)) ** (1.0 / alo ** 2)
        h2 = np.abs(np.cos(ahi * T * u)) ** (1.0 / ahi ** 2)
        return float(np.sum(w * k * np.maximum(h1, h2)))

    cases = []
    for be in [0.07, 0.08, 0.10, 0.11, 0.15, 0.16, 0.2, 0.31, 0.5, 0.9]:
        T = math.pi / be
        a_c = float_below(arb(THETA_LO) * arb(be) / arb(math.pi))
        edges = _edges(a_c, be, 10)
        for xr in [0.0, 0.25, 0.5]:
            x = xr * (be / 2)
            for j in [0, 5, 9]:
                cases.append((edges[j], edges[j + 1], x, T, be))
    worst_slack = math.inf     # min (fast.upper - true); must stay >= 0 for rigor
    worst_loose = 0.0          # max (safe.upper - fast.upper); fast should be the tighter bound
    nbad = 0
    for alo, ahi, x, T, be in cases:
        q = _piece_float(alo, ahi, x, T)
        t0 = time.time(); fast = _piece_upper_fast(alo, ahi, x, T); tf = time.time() - t0
        t0 = time.time(); safe = _piece_upper(alo, ahi, x, T, abs_tol=1e-10, rel_tol=1e-9, deg_limit=180); ts = time.time() - t0
        fu, su = float_above(fast), float_above(safe)
        slack, loose = fu - q, su - fu
        worst_slack = min(worst_slack, slack)
        worst_loose = max(worst_loose, loose)
        if not fast.is_finite() or slack < -1e-9:
            nbad += 1
            print(f"  BAD b={be} [{alo:.4f},{ahi:.4f}] x={x:.3f}: fast.up={fu:.9f} < true={q:.9f} (slack={slack:.2e})")
        elif (alo, ahi, x, T, be) in cases[:6] or loose > 1e-6:
            print(f"  ok b={be} [{alo:.4f},{ahi:.4f}] x={x:.4f}: fast={fu:.9f}({tf:.1f}s) safe={su:.9f}({ts:.1f}s) "
                  f"true={q:.9f}  fast-true={slack:+.1e} safe-fast={loose:+.1e}")
    print(f"done: {len(cases)} cases, {nbad} invalid; min(fast.upper-true)={worst_slack:.2e} (>=0 required for rigor); "
          f"max(safe.upper-fast.upper)={worst_loose:.2e} (fast is the tighter, independently-confirmed bound)")
