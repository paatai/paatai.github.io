"""Independently audit the self-describing nodes of a (U) certificate (requirement from independent review).

Given a base certificate and its node-augmented companion, verify:
  (1) every load-bearing field (alpha,beta,K,xsA,xsB,TsB,x_end) is value-identical between the two files, so
      every verification of the base file (96-bit cell re-check, both independent from-scratch verifiers)
      transfers to the companion;
  (2) each companion record's nodes es = [e_0,...,e_K] satisfy the hypotheses Lemma supG needs:
      e_0 = a_c and e_K = beta exactly, strictly increasing, and -- rigorously, in ball arithmetic --
      a_c <= theta*beta/pi (so the Gaussian sub-bound covers (0,a_c]); and that they equal the re-checker's
      own construction float_below(theta_lo*beta/pi), _edges(a_c,beta,K).

usage: python3 verify_nodes_U.py base_cert.jsonl.gz nodes_cert.jsonl.gz [prec]
"""
import os
import sys, gzip, json
from flint import arb, ctx
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))
import prawitz_U as pu
from prawitz_arb import float_below, THETA_LO
from prawitz_U import _edges

LOAD_BEARING = ("alpha", "beta", "K", "xsA", "xsB", "TsB", "x_end")


def main():
    base, nodes = sys.argv[1], sys.argv[2]
    prec = int(sys.argv[3]) if len(sys.argv) > 3 else 96
    ctx.prec = prec
    pu.PI = arb.pi()
    rb = [json.loads(l) for l in gzip.open(base, "rt")]
    rn = [json.loads(l) for l in gzip.open(nodes, "rt")]
    assert len(rb) == len(rn), f"record count differs: {len(rb)} vs {len(rn)}"
    bad_field = bad_node = bad_ac = 0
    for a, b in zip(rb, rn):
        for key in LOAD_BEARING:
            if a[key] != b[key]:
                bad_field += 1
                print(f"  FIELD {key} differs at beta={a.get('beta')}")
        beta, K = b["beta"], b["K"]
        es, a_c = b["es"], b["a_c"]
        ac2 = float_below(arb(THETA_LO) * arb(beta) / pu.PI)
        es2 = _edges(ac2, beta, K)
        if not (len(es) == K + 1 and es[0] == a_c == ac2 and es[-1] == beta
                and all(es[j] < es[j + 1] for j in range(K)) and es == es2):
            bad_node += 1
            print(f"  NODES invalid at beta={beta}")
        # rigorous: a_c <= theta*beta/pi (use theta_lo <= theta, so a_c <= theta_lo*beta/pi => a_c <= theta*beta/pi)
        if not bool(arb(a_c) <= arb(THETA_LO) * arb(beta) / pu.PI):
            bad_ac += 1
            print(f"  a_c > theta*beta/pi at beta={beta}  (a_c={a_c!r})")
    ok = (bad_field == 0 and bad_node == 0 and bad_ac == 0)
    print(f"checked {len(rn)} records at prec={prec}: "
          f"load-bearing mismatches={bad_field}, invalid node lists={bad_node}, a_c>theta*beta/pi={bad_ac}")
    print(f"RESULT: {'PASS -- companion is the base cert plus valid, self-consistent partition nodes' if ok else 'FAIL'}")
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
