"""Cover [amin, amax] (values of a1) by blocks and verify the UPPER half (U) on each in parallel.

Block choice: largest beta with (1/pi) I(1/beta^2) <= H(alpha) - buffer (buffer = part of the C11
margin, kept for covering overshoot and zone-A x-growth).  Blocks tile [amin,amax]
(alpha_{i+1}=beta_i).  Blocks are verified concurrently (process pool); a block that fails is split
in half and its two halves re-queued, which preserves the tiling.  The certificate stores, per block,
the grids (xsA, xsB, TsB, x_end) so check_cert_U.py can re-verify (A),(B),(C) from scratch.
"""
import os
import sys, math, time, json, gzip
from multiprocessing import Pool
import numpy as np
from scipy.special import gamma, erf

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))


def Phi_f(x): return 0.5 * (1 + erf(x / math.sqrt(2)))
def H_f(x): return 2 * Phi_f(x) - 1
def Ipi(a):
    p = 1.0 / a ** 2
    return 2 * (0.5 * gamma((p + 1) / 2) / (math.sqrt(math.pi) * gamma(p / 2 + 1)))


def choose_beta(alpha, amax, buffer_frac=0.35):
    """Largest beta<=amax with Ipi(beta) <= Ipi(alpha)+(1-buffer_frac)*(H(alpha)-Ipi(alpha))."""
    Ha = H_f(alpha)
    tgt = Ipi(alpha) + (1 - buffer_frac) * (Ha - Ipi(alpha))
    if Ipi(amax) <= tgt:
        return amax
    lo, hi = alpha, amax
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if Ipi(mid) <= tgt:
            lo = mid
        else:
            hi = mid
    return lo


def partition(amin, amax, buffer_frac=0.35):
    blocks = []
    alpha = amin
    while alpha < amax - 1e-12:
        beta = min(choose_beta(alpha, amax, buffer_frac), amax)
        if beta <= alpha + 1e-12:
            beta = min(alpha + 1e-6, amax)
        blocks.append((alpha, beta))
        alpha = beta
    return blocks


def _verify(args):
    alpha, beta, K, xcal_frac, maxA = args
    from verify_block_U import verify_block_U
    r = verify_block_U(alpha, beta, K=K, xcal_frac=xcal_frac, maxA=maxA)
    return r


def run(amin, amax, out=None, K=13, nw=8, buffer_frac=0.35, xcal_frac=1e-3, maxA=600):
    t0 = time.time()
    todo = partition(amin, amax, buffer_frac)
    print(f"[{amin},{amax}] initial partition: {len(todo)} blocks; verifying on {nw} workers, "
          f"K={K} bf={buffer_frac} xcal_frac={xcal_frac} maxA={maxA}")
    done = []
    rounds = 0
    with Pool(nw) as pool:
        while todo:
            rounds += 1
            args = [(a, b, K, xcal_frac, maxA) for (a, b) in todo]
            nextf = []
            ndone_round = 0
            for r in pool.imap_unordered(_verify, args, chunksize=1):
                a, b = r["alpha"], r["beta"]
                if r.get("ok"):
                    done.append(r)
                    ndone_round += 1
                    if ndone_round % 5 == 0 or len(done) <= 8:
                        print(f"    [{a:.4f},{b:.4f}] ok nA={r.get('nA')} nB={r.get('nB')} "
                              f"mA={r.get('marginA'):+.1e} mB={r.get('marginB'):+.1e} "
                              f"({r.get('secs'):.0f}s)  [{len(done)} done, {time.time()-t0:.0f}s]", flush=True)
                else:
                    mid = 0.5 * (a + b)
                    if mid <= a + 1e-9 or (b - a) < 1e-7:
                        print(f"  UNSPLITTABLE FAIL [{a:.6f},{b:.6f}]: {({k:v for k,v in r.items() if k in ('where','xi','x','margin')})}")
                        return None
                    print(f"  split [{a:.6f},{b:.6f}] ({r.get('where')}) -> halves", flush=True)
                    nextf += [(a, mid), (mid, b)]
            todo = nextf
            print(f"  round {rounds} done: {len(done)} ok total, {len(todo)} to retry  ({time.time()-t0:.0f}s)", flush=True)
    done.sort(key=lambda r: r["alpha"])
    # coverage sanity (float)
    cur = amin
    ok_cov = True
    for r in done:
        if r["alpha"] > cur + 1e-9:
            ok_cov = False
            print(f"  GAP ({cur}, {r['alpha']})")
        cur = max(cur, r["beta"])
    if cur < amax - 1e-9:
        ok_cov = False
        print(f"  GAP ({cur}, {amax})")
    nA = sum(r["nA"] for r in done); nB = sum(r["nB"] for r in done)
    mA = min(r["marginA"] for r in done); mB = min(r["marginB"] for r in done)
    secs = time.time() - t0
    print(f"COVERED [{amin},{amax}] with {len(done)} blocks (cov {'OK' if ok_cov else 'INCOMPLETE'}); "
          f"total cells nA={nA} nB={nB}; min marginA={mA:+.2e} marginB={mB:+.2e}; {secs:.0f}s")
    if out:
        with gzip.open(out, "wt") as f:
            for r in done:
                f.write(json.dumps({k: r[k] for k in ("alpha", "beta", "K", "x_end",
                                                       "xsA", "xsB", "TsB")}) + "\n")
        print(f"wrote {out}  ({len(done)} blocks)")
    return done


if __name__ == "__main__":
    amin = float(sys.argv[1]); amax = float(sys.argv[2])
    out = sys.argv[3] if len(sys.argv) > 3 else None
    K = int(sys.argv[4]) if len(sys.argv) > 4 else 13
    nw = int(sys.argv[5]) if len(sys.argv) > 5 else 8
    bf = float(sys.argv[6]) if len(sys.argv) > 6 else 0.35
    xcf = float(sys.argv[7]) if len(sys.argv) > 7 else 1e-3
    mxa = int(sys.argv[8]) if len(sys.argv) > 8 else 600
    run(amin, amax, out, K=K, nw=nw, buffer_frac=bf, xcal_frac=xcf, maxA=mxa)
