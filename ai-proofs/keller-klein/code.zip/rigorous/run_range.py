"""Verify (L) for all a1 in [A0, A1] by covering the range with blocks [alpha, beta].

usage: python3 run_range.py A0 A1 [kappa] [wmax] [workers] [tag]

Blocks: alpha_{k+1} = alpha_k + min(wmax, kappa * alpha_k^3) (exact floats); a failed block is split in
two and retried (up to 8 times).  Writes
  results/<tag>_summary.txt      one line per verified block
  results/<tag>_cert.jsonl.gz    full parameter certificate (grids and T values) per block
and finally checks that the verified blocks cover [A0, A1] without gaps.
"""
import sys, os, json, gzip, time, subprocess
from multiprocessing import Pool

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))
from verify_block import verify_block


def work(block):
    al, be, depth = block
    try:
        r = verify_block(al, be)
    except Exception as e:  # noqa: BLE001
        r = {"alpha": al, "beta": be, "ok": False, "where": f"exception {e!r}"}
    r["depth"] = depth
    return r


def main():
    A0 = float(sys.argv[1]); A1 = float(sys.argv[2])
    kappa = float(sys.argv[3]) if len(sys.argv) > 3 else 0.6
    wmax = float(sys.argv[4]) if len(sys.argv) > 4 else 0.02
    nw = int(sys.argv[5]) if len(sys.argv) > 5 else 8
    tag = sys.argv[6] if len(sys.argv) > 6 else f"L_{A0}_{A1}"
    os.makedirs(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous", "results"), exist_ok=True)
    commit = subprocess.run(["git", "-C", os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rev-parse", "HEAD"], capture_output=True,
                            text=True).stdout.strip()
    blocks = []
    a = A0
    while a < A1:
        b = min(A1, a + min(wmax, kappa * a ** 3))
        blocks.append((a, b, 0))
        a = b
    summ = open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous", "results", f"{tag}_summary.txt"), "w")
    cert = gzip.open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous", "results", f"{tag}_cert.jsonl.gz"), "wt")
    summ.write(f"# (L) verification on [{A0},{A1}], kappa={kappa}, wmax={wmax}, code commit {commit}\n")
    summ.write("# alpha beta ok nC x1/alpha nP n_int slack_min secs depth\n")
    t0 = time.time()
    verified = []
    pending = blocks
    total_int = 0
    while pending:
        failed = []
        with Pool(nw) as pool:
            for r in pool.imap_unordered(work, pending, chunksize=1):
                if r.get("ok"):
                    verified.append((r["alpha"], r["beta"]))
                    total_int += r["n_int"]
                    summ.write(f"{r['alpha']!r} {r['beta']!r} 1 {r['nC']} {r['x1_over_alpha']:.4f} {r['nP']} "
                               f"{r['n_int']} {r['slack_min']:.3e} {r['secs']:.1f} {r['depth']}\n")
                    summ.flush()
                    cert.write(json.dumps({k: r[k] for k in ("alpha", "beta", "ys", "Ss", "xs", "Ts", "x_end")}) + "\n")
                else:
                    summ.write(f"# FAILED {r['alpha']!r} {r['beta']!r} {r.get('where')} {r.get('xi')} depth {r['depth']}\n")
                    summ.flush()
                    if r["depth"] >= 8:
                        print("giving up on", r["alpha"], r["beta"], flush=True)
                        continue
                    mid = (r["alpha"] + r["beta"]) / 2
                    failed += [(r["alpha"], mid, r["depth"] + 1), (mid, r["beta"], r["depth"] + 1)]
        pending = failed
    cert.close()
    verified.sort()
    gaps = []
    cur = A0
    for al, be in verified:
        if al > cur:
            gaps.append((cur, al))
        cur = max(cur, be)
    if cur < A1:
        gaps.append((cur, A1))
    msg = (f"# DONE blocks={len(verified)} integrals={total_int} wall={time.time()-t0:.0f}s "
           f"coverage {'COMPLETE' if not gaps else 'GAPS ' + repr(gaps)}\n")
    summ.write(msg)
    summ.close()
    print(msg, flush=True)


if __name__ == "__main__":
    main()
