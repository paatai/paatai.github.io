"""Diagnose the zone A/B transition for small alpha: is the envelope 2J(-x;beta,T) adequate
at x=xA=alpha/2 (where zone A hands off)?  Uses the float envelope proxy (fast).

For each alpha we print, at a grid of x from xA upward, the best-T float envelope 2*BU and the
target H(x_prev)+H(alpha), and the smallest x at which the envelope first fits the target at xA.
"""
import os
import sys, math
import numpy as np
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "numerics"))
from run_range_U import choose_beta, Ipi, H_f
import prawitz_upper as pup

def Phi_f(x): return 0.5 * (1 + math.erf(x / math.sqrt(2)))
def H(x): return 2 * Phi_f(x) - 1

taus = list(np.pi * np.concatenate([np.linspace(0.5, 2.0, 24), np.linspace(2.2, 6.0, 20)]))

def env2(x, beta):
    best = math.inf
    for tau in taus:
        T = tau / beta
        v = pup.BU_many_x(np.array([x]), beta, T, nsub=400)[0]
        best = min(best, v)
    return 2 * best

for alpha in [float(a) for a in (sys.argv[1].split(",") if len(sys.argv) > 1 else ["0.10","0.09","0.085","0.08"])]:
    bf = 0.55
    beta = choose_beta(alpha, 1.0, bf)
    xA = alpha / 2
    HA = H(alpha)
    print(f"\nalpha={alpha:.4f} beta={beta:.5f} xA={xA:.4f} H(alpha)={HA:.5f}")
    # target at the first zone-B cell is H(xA)+H(alpha); envelope must be <= that at x>xA (limit x->xA)
    for xr in [1.0, 1.1, 1.25, 1.5, 2.0, 3.0]:
        x = xA * xr
        e2 = env2(x, beta)
        tgt = H(xA) + HA        # target held at left endpoint = xA for the first cell
        print(f"   x={x:.4f} (={xr:.2f}xA): 2J={e2:.5f}  H(xA)+H(a)={tgt:.5f}  slack={tgt-e2:+.2e}")
