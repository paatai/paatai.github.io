"""Diagnose one failing (A) cell: compute 2*two_S_upper under several (prec,tol,deg) settings,
print midpoint/radius/sup and the target, to see whether the inequality truly holds and whether
the production (prec=64) enclosure actually contained the true value."""
import sys, math
sys.path.insert(0, "/workspace/rigorous")
from flint import arb, ctx
import prawitz_arb as pa
import prawitz_U as pu

# failing cell from block [0.4934927647269965, 0.5010077657285242], i=15
alpha = 0.4934927647269965
beta = 0.5010077657285242
xl = 0.14115730285214412
xr = 0.1848599082650151
K = 10

settings = [
    ("prod   64", 64, dict(abs_tol=1e-9, rel_tol=1e-7, deg_limit=60)),
    ("check  96", 96, dict(abs_tol=1e-8, rel_tol=1e-7, deg_limit=90)),
    ("tight  96", 96, dict(abs_tol=1e-11, rel_tol=1e-10, deg_limit=160)),
    ("gold  192", 192, dict(abs_tol=1e-13, rel_tol=1e-12, deg_limit=220)),
]

for name, prec, kw in settings:
    ctx.prec = prec
    pa.PI = arb.pi()
    pu.PI = pa.PI
    HA = 2 * pu.Phi(arb(alpha)) - 1
    target = (2 * pu.Phi(arb(xl)) - 1) + HA
    Tb = pa.PI / arb(beta)
    S2 = pu.two_S_upper(xr, beta, Tb, K=K, **kw)
    mid = float(arb(S2).mid()); rad = float(arb(S2).rad())
    sup = pu.float_above(S2)
    tlo = float(target.lower())
    print(f"{name}: 2S mid={mid:.10f} rad={rad:.2e} sup={sup:.10f} "
          f"target.lower={tlo:.10f} margin={tlo - sup:+.3e} "
          f"{'PASS' if S2 <= target else 'FAIL'}")
