"""Rigorous verification of inequality (L) for all a1 in a block [alpha, beta].

(L):  Pr[|X| < x] >= H(x) - H(a1)  for all x > a1,   H(x) = 2 Phi(x) - 1.

For a block [alpha, beta] every bound below uses the envelopes with parameter a = beta (valid since
a1 <= beta, CLAIMS C3/C4) and the target H(alpha) <= H(a1).  Three x-ranges:

* C-part, x in (a1, x1]:  grid alpha = y_0 < ... < y_M = x1 with
      H(y_{j+1}) <= H(alpha) - (2/3) J(2 y_j; beta, S_j)                         (*)
  Proof: for x in (max(a1,y_j), y_{j+1}], b = max(a1, y_j) satisfies a1 <= b < x, so by KK Lemma
  seg-compare2, Pr[|X|<x] >= Pr<-b,b> >= Pr<-2b,2b>/3 >= Pr[|X|<2y_j]/3, and by Prawitz (C4)
  Pr[|X|<z] = 2Pr[X<z]-1 >= H(z) - 2B(z) = -2 J(z).
* P-part, x in [x1, x_end]: grid x1 = x_0 < ... < x_N >= x_end with
      Phi(x_{i+1}) <= Phi(alpha) - J(x_i; beta, T_i)                                (**)
  Proof: for x in [x_i, x_{i+1}], Phi(x) - Pr[X<x] <= Phi(x_{i+1}) - Pr[X<x_i] <= Phi(x_{i+1}) - 1/2
  + J(x_i) <= c(alpha) <= c(a1).
* x >= x_end with exp(-x_end^2/2) <= c(alpha): Hoeffding (C7).

All inequalities (*), (**) and the x_end condition are checked in ball arithmetic.  Floating point
is only used to choose the parameters (grid points, T, S).
"""
import math, time, sys
import numpy as np
from scipy.special import ndtri, erf
from flint import arb, ctx

sys.path.insert(0, "/workspace/rigorous")
from prawitz_arb import J_upper, Phi as PhiB, THETA_LO

ctx.prec = 64

THETA_F = THETA_LO
_GL_X, _GL_W = np.polynomial.legendre.leggauss(10)


# ---------------------------------------------------------------- float helper (parameter choice only)
def _nodes(a, T, nsub):
    bps = {0.0, 1.0, 0.5}
    for b in (math.pi / 2, THETA_F, math.pi):
        ub = b / (a * T)
        if 0 < ub < 1:
            bps.add(ub)
    bps = sorted(bps)
    us, ws = [], []
    for lo, hi in zip(bps[:-1], bps[1:]):
        m = max(2, int(nsub * (hi - lo)) + 1)
        e = np.linspace(lo, hi, m + 1)
        A, Bq = e[:-1, None], e[1:, None]
        us.append(((A + Bq) / 2 + (Bq - A) / 2 * _GL_X[None, :]).ravel())
        ws.append(((Bq - A) / 2 * _GL_W[None, :]).ravel())
    return np.concatenate(us), np.concatenate(ws)


def J_float(x, a, T, nsub=300):
    u, w = _nodes(a, T, nsub)
    v = T * u
    av = a * v
    p = 1 / (a * a)
    ca = np.cos(av)
    g = np.exp(-v * v / 2)
    L = np.where(av <= math.pi / 2, np.power(np.clip(ca, 0, None), p),
        np.where(av <= THETA_F, -np.abs(ca) * np.exp(-(1 - a * a) * v * v / 2),
        np.where(av <= math.pi, -np.power(np.abs(ca), p), -1.0)))
    U = np.where(av <= THETA_F, g, np.where(av <= math.pi, np.power(np.abs(ca), p), 1.0))
    k = (1 - u) * np.cos(T * u * x) - ((1 - u) / np.tan(np.pi * u) + 1 / np.pi) * np.sin(T * u * x)
    return float(np.sum(w * np.maximum(k * L, k * U)))


def best_T(x, a, tau_prev=None, lo=0.80, hi=1.20):
    """Approximately minimise J(x; a, tau/a) over tau (floats)."""
    taus = list(np.linspace(lo, hi, 9) * math.pi)
    if tau_prev is not None:
        taus += [tau_prev * f for f in (0.995, 1.0, 1.005)]
    vals = [J_float(x, a, t / a) for t in taus]
    i = int(np.argmin(vals))
    t0 = taus[i]
    step = 0.025 * math.pi
    best = (vals[i], t0)
    for _ in range(10):
        cand = [best[1] - step, best[1] + step]
        for t in cand:
            if t > 0:
                v = J_float(x, a, t / a)
                if v < best[0]:
                    best = (v, t)
        step /= 2
    return best[1] / a, best[1]


def Phi_f(x):
    return 0.5 * (1 + erf(x / math.sqrt(2)))


def _down(x, k=1):
    for _ in range(k):
        x = math.nextafter(x, -math.inf)
    return x


# ---------------------------------------------------------------- the block check
def verify_block(alpha, beta, xi_C=1.75, max_steps=200000, log=None):
    """Return dict with ok flag and statistics.  alpha, beta are exact floats."""
    t0 = time.time()
    a = beta
    A = arb(alpha)
    PhiA = PhiB(A)
    HA = 2 * PhiA - 1
    cA = PhiA - arb(0.5)
    n_int = 0
    rec = {"alpha": alpha, "beta": beta}

    # x_end: exp(-x_end^2/2) <= c(alpha)
    xe = math.sqrt(2 * math.log(1 / float(cA.mid()))) * (1 + 1e-9) + 1e-12
    assert (-(arb(xe) ** 2) / 2).exp() < cA, "x_end check failed"

    # ---- C-part
    y = alpha
    ys, Ss = [y], []
    tau = math.pi
    while y < xi_C * alpha and y < xe:
        S, tau = best_T(2 * y, a, tau)
        Jz = J_upper(2 * y, a, S)
        n_int += 1
        rhs = HA - 2 * Jz / 3              # need H(y_next) <= rhs
        r = float(rhs.lower())
        if r >= 1:
            ynext = xe
        else:
            ynext = _down(float(ndtri((1 + r) / 2)) * (1 - 1e-12), 2) if r > -1 else -1.0
        if ynext >= xe:
            ynext = xe
        # rigorous check of (*)
        if not (2 * PhiB(arb(ynext)) - 1 <= rhs):
            ynext = _down(ynext * (1 - 1e-9), 2)
            if not (2 * PhiB(arb(ynext)) - 1 <= rhs):
                rec.update(ok=False, where="C-check", y=y)
                return rec
        if ynext <= y * (1 + 1e-6):
            break
        Ss.append(S)
        y = ynext
        ys.append(y)
        if len(ys) > 60:
            break
    x1 = y
    rec["x1_over_alpha"] = x1 / alpha
    rec["nC"] = len(Ss)

    # ---- P-part
    x = x1
    xs, Ts, slack_min = [], [], math.inf
    tau = math.pi
    steps = 0
    while x < xe:
        T, tau = best_T(x, a, tau)
        Jx = J_upper(x, a, T)
        n_int += 1
        rhs = PhiA - Jx                     # need Phi(x_next) <= rhs
        r = float(rhs.lower())
        slack = float((cA - (PhiB(arb(x)) - arb(0.5) + Jx)).lower())  # c(alpha) - B(x_i)
        slack_min = min(slack_min, slack)
        if r >= 1:
            xnext = xe
        else:
            xnext = _down(float(ndtri(r)) * (1 - 1e-12), 2)
        if xnext >= xe:
            xnext = xe
        if not (PhiB(arb(xnext)) <= rhs):
            xnext = _down(xnext * (1 - 1e-9), 2)
            if not (PhiB(arb(xnext)) <= rhs):
                rec.update(ok=False, where="P-check", x=x)
                return rec
        if xnext <= x:
            rec.update(ok=False, where="P-stall", x=x, xi=x / alpha, slack=slack, n_int=n_int)
            return rec
        xs.append(x); Ts.append(T)
        x = xnext
        steps += 1
        if steps > max_steps:
            rec.update(ok=False, where="P-maxsteps", x=x)
            return rec
    rec.update(ok=True, nP=len(xs), n_int=n_int, slack_min=slack_min, secs=time.time() - t0,
               ys=ys, Ss=Ss, xs=xs, Ts=Ts, x_end=xe)
    return rec


if __name__ == "__main__":
    al = float(sys.argv[1]); be = float(sys.argv[2])
    r = verify_block(al, be)
    print({k: v for k, v in r.items() if k not in ("ys", "Ss", "xs", "Ts")})
