"""Rigorous (ball arithmetic) upper bounds for the UPPER half (U) of Keller-Klein.

(U):  Pr[|X| <= x] <= H(x) + H(a1),   H(x) = 2 Phi(x) - 1,   a1 = max_i a_i.

Foundation (CLAIMS C2, symmetry).  For symmetric X and any T>0, x>=0,
    Pr[|X| <= x]  <=  2 int_0^1 k(u,-x,T) phi_X(Tu) du,                       (U-Praw)
    k(u,-x,T) = (1-u) cos(Tux) + rho(u) sin(Tux),   rho(u)=(1-u)cot(pi u)+1/pi >= 0.
If Tx <= pi/2 then k(u,-x,T) >= 0 on (0,1).

Two rigorous upper bounds for the RHS of (U-Praw):

(A) HOLDER / covering bound  (for x <= a1/2, so k>=0).  With p_i=1/a_i^2 (sum=1),
    phi_X <= prod|cos(a_i Tu)|  and generalized Holder over the measure k du give
        2 int k phi_X du  <=  2 prod_i G(a_i)^{a_i^2}  <=  2 sup_{a in (0,a1]} G(a),
    G(a) = int_0^1 k(u,-x,T) |cos(a T u)|^{1/a^2} du.
    We bound the sup rigorously:
      * a <= a_c := THETA*a1/pi  =>  aTu<=theta for all u, so |cos(aTu)|^{1/a^2}<=exp(-(Tu)^2/2):
            sup_{a<=a_c} G(a) <= Ggauss := int_0^1 k(u,-x,T) exp(-(Tu)^2/2) du.
      * a in [a_c, a1]: cover by pieces [a_j,a_{j+1}].  h(a,u)=|cos(aTu)|^{1/a^2} is, as a function
        of a (u fixed), decreasing for aTu<pi/2 and increasing for aTu>pi/2 (one interior minimum),
        so sup_{a in [a_j,a_{j+1}]} h(a,u) = max(h(a_j,u), h(a_{j+1},u)); hence
            sup_{a in [a_j,a_{j+1}]} G(a) <= int_0^1 k(u,-x,T) max(h(a_j,u),h(a_{j+1},u)) du.
    two_S_upper returns an arb whose upper end bounds 2*sup_a G(a).

(B) ENVELOPE bound (any x; needs no sign restriction).  phi_X in [L_a, U_a] (C3) with a=a1 gives
        2 int k phi_X du <= 2 int_0^1 max(k L_{a1}(Tu), k U_{a1}(Tu)) du = 2 J(-x; a1, T),
    computed by prawitz_arb.J_upper with x -> -x.  two_J_upper wraps it.

Monotonicity of h in a (used in (A)).  d/da log h = (1/a^3) G3(aTu), G3(s)=-2 log|cos s| - s tan s.
G3(0)=0 and G3'(s)=(sin s cos s - s)/cos^2 s < 0 on (0,pi/2), so G3<0 there (h decreasing in a);
on (pi/2,pi) both -2log|cos s|>0 and -s tan s>0, so G3>0 (h increasing in a).  One sign change =>
one interior minimum => sup over an a-interval is attained at an endpoint.  (All verified below.)
"""
import math, sys
from flint import arb, acb, ctx

sys.path.insert(0, "/workspace/rigorous")
from prawitz_arb import (_kA, _kB, kernel, Phi, PI, THETA_LO, THETA_HI,
                         float_below, float_above, J_upper)

ctx.prec = 64


def _logcos_pow(av, sgn, p, analytic):
    """|cos(av)|^p on a sub-interval where sgn*cos(av) > 0 (sgn in {+1,-1})."""
    c = av.cos()
    base = c if sgn > 0 else -c
    return (base.log(analytic=analytic) * p).exp()


def _hmax_upper(alo, ahi, uu, Ta, plo, phi):
    """Rigorous upper bound of max(h(alo,u), h(ahi,u)) over the real ball uu, h(a,u)=|cos(aTu)|^{1/a^2}.
    cu = float >= |cos(aTu)| on uu (capped to [0,1]); then |cos|^p <= cu^p."""
    def _h(a, p):
        cu = float_above((arb(a) * Ta * uu).cos().abs_upper())
        if cu <= 0.0:
            return arb(0)
        if cu >= 1.0:
            return arb(1)
        return (arb(cu).log() * arb(p)).exp()
    return _h(alo, plo).union(_h(ahi, phi)).abs_upper()


def _box_upper(alo, ahi, s, e, xa, Ta, plo, phi):
    """Conservative rigorous value of int_s^e k(u,-x,T) max(h(alo,u),h(ahi,u)) du when acb.integral is
    non-finite (the integrand is too stiff near a cos-zero at small beta).  Valid because in zone A
    k>=0 and 0<=max(h)<=1, so the integral lies in [0, sup|k| * sup max(h) * (e-s)].  Tight exactly
    where it is needed: there the band straddles pi/2, so max(h) ~ (cos near pi/2)^{1/a^2} ~ 1e-70."""
    uu = arb(s).union(arb(e))
    kb = kernel(uu, xa, Ta)
    mh = _hmax_upper(alo, ahi, uu, Ta, plo, phi)
    return arb(0).union(kb.abs_upper() * mh * (arb(e) - arb(s)))


def _kf_of(half):
    return _kA if half == 0 else _kB


def _zero_u(a, T):
    """Ball enclosure [lo,hi] of u where a T u = pi/2 (the zero of cos(aTu))."""
    z = PI / (2 * arb(a) * arb(T))
    return float_below(z), float_above(z)


def Ggauss_upper(x, a1, T, abs_tol=1e-12, rel_tol=1e-10, deg_limit=120):
    """int_0^1 k(u,-x,T) exp(-(Tu)^2/2) du  (an arb upper bound)."""
    xa, Ta = arb(-x), arb(T)
    total = arb(0)
    for half, (s, e) in enumerate([(0.0, 0.5), (0.5, 1.0)]):
        kf = _kf_of(half)
        def f(u, analytic, kf=kf):
            v = Ta * u
            return kf(u, xa, Ta) * (-(v * v) / 2).exp()
        val = acb.integral(f, s, e, abs_tol=abs_tol, rel_tol=rel_tol,
                           eval_limit=10 ** 7, deg_limit=deg_limit)
        total += val.real
    return total


def _piece_upper(alo, ahi, x, T, abs_tol=1e-12, rel_tol=1e-10, deg_limit=120):
    """int_0^1 k(u,-x,T) max(h(alo,u), h(ahi,u)) du,  h(a,u)=|cos(aTu)|^{1/a^2}.
    Upper-bounds sup_{a in [alo,ahi]} G(a).  Requires alo<=ahi, both in (0,a1], T=pi/a1 or pi/beta.

    cos(alo Tu) changes sign at z_alo=pi/(2 alo T), cos(ahi Tu) at z_ahi (z_ahi<=z_alo, both >=1/2).
    We cut [0,1] at 1/2 (kernel form) and at ball enclosures of the two zeros; every resulting
    smooth segment has constant sign for both cosines, and the zero-balls are bounded as slivers."""
    xa, Ta = arb(-x), arb(T)
    plo = 1 / arb(alo) ** 2            # exact-ball Hoelder exponents 1/a^2 (no float rounding; referee R1)
    phi = 1 / arb(ahi) ** 2
    za_lo, za_hi = _zero_u(alo, T)     # zero of cos(alo Tu)  (larger u)
    zb_lo, zb_hi = _zero_u(ahi, T)     # zero of cos(ahi Tu)  (smaller u)
    balls = [(zb_lo, zb_hi), (za_lo, za_hi)]
    cuts = sorted(c for c in {0.0, 0.5, 1.0, za_lo, za_hi, zb_lo, zb_hi} if 0.0 <= c <= 1.0)
    total = arb(0)
    for s, e in zip(cuts[:-1], cuts[1:]):
        if e <= s:
            continue
        mid = 0.5 * (s + e)
        if any(blo <= s and e <= bhi for blo, bhi in balls):   # inside a zero-ball: sliver
            uu = arb(s).union(arb(e))
            kb = kernel(uu, xa, Ta)
            total += arb(0).union(kb.abs_upper() * (arb(e) - arb(s)))   # max(h,.) <= 1
            continue
        kf = _kA if mid < 0.5 else _kB
        slo = 1 if mid < za_lo else -1     # sign of cos(alo Tu) on this segment
        shi = 1 if mid < zb_lo else -1     # sign of cos(ahi Tu)
        def f(u, analytic, kf=kf, slo=slo, shi=shi):
            v = Ta * u
            hlo = _logcos_pow(alo * v, slo, plo, analytic)
            hhi = _logcos_pow(ahi * v, shi, phi, analytic)
            d = hhi - hlo
            ad = d.real_abs(analytic=analytic)
            mx = (hlo + hhi + ad) / 2
            return kf(u, xa, Ta) * mx
        val = acb.integral(f, s, e, abs_tol=abs_tol, rel_tol=rel_tol,
                           eval_limit=10 ** 7, deg_limit=deg_limit)
        total += val.real if val.real.is_finite() else _box_upper(alo, ahi, s, e, xa, Ta, plo, phi)
    return total


def _edges(a_c, a1, K):
    """K+1 edges from a_c to a1 concentrated near a1 (quadratic): the sup of G(a;x) over a sits at
    a=a1 for small x, so fine pieces there cut the piece-cover overshoot ~10x for the same K.
    Endpoints are forced exactly (e_0=a_c, e_K=a1): the Gaussian sub-bound covers (0,a_c] and the
    pieces cover [a_c,a1], so the whole a-range (0,a1] is covered with no float-rounding gap at a_c."""
    e = [a1 - (a1 - a_c) * ((K - j) / K) ** 2 for j in range(K + 1)]
    e[0], e[-1] = a_c, a1
    return e


def two_S_upper(x, a1, T, K=12, **kw):
    """arb upper bound for 2 * sup_{a in (0,a1]} G(a;x).  Needs x <= a1/2 (so k>=0)."""
    a_c = float_below(arb(THETA_LO) * arb(a1) / PI)   # a<=a_c => aTu<=theta for u in[0,1]
    S = Ggauss_upper(x, a1, T, **kw)
    if not S.is_finite():
        raise RuntimeError("Ggauss non-finite")
    # pieces over [a_c, a1]
    edges = _edges(a_c, a1, K)
    for j in range(K):
        pb = _piece_upper(edges[j], edges[j + 1], x, T, **kw)
        if not pb.is_finite():
            raise RuntimeError(f"piece [{edges[j]},{edges[j+1]}] non-finite")
        if float_above(pb) > float_above(S):
            S = pb
    return 2 * S


def two_J_upper(x, a1, T, **kw):
    """arb upper bound for 2 J(-x; a1, T) >= Pr[|X|<=x] (envelope bound (B))."""
    return 2 * J_upper(-x, a1, T, **kw)


def H(x):
    return 2 * Phi(x) - 1


if __name__ == "__main__":
    import time
    sys.path.insert(0, "/workspace/numerics")
    import prawitz_holder as ph
    import prawitz_fast as pf
    import numpy as np
    print("Validate Ggauss_upper, two_S_upper (A) and two_J_upper (B) vs float.")
    for a1 in [1.0, 0.5, 0.3, 0.2]:
        T = math.pi / a1
        for xr in [0.0, 0.2, 0.4]:
            x = xr * a1
            t0 = time.time()
            S = two_S_upper(x, a1, T, K=12)
            t1 = time.time()
            # float reference: 2 sup_a G(a)
            Mf, _ = ph.M(x, a1, T, na=400)
            tgt = H(x) + H(a1)
            print(f"a1={a1:.2f} x/a1={xr:.2f}: 2S_arb<= {float_above(S):.8f} "
                  f"(float 2supG={Mf:.8f}) tgt={float(tgt.mid()):.8f} "
                  f"margin={float(tgt.lower())-float_above(S):+.3e} ({t1-t0:.1f}s)")
