"""Independent re-check of a certificate produced by run_range.py.

usage: python3 check_cert.py results/<tag>_cert.jsonl.gz A0 A1 [prec] [workers]

For every block [alpha, beta] the stored parameters (C-part grid ys with S values, P-part grid xs with
T values, x_end) are re-verified from scratch in ball arithmetic at working precision `prec`:
  (*)  2 Phi(y_{j+1}) - 1 <= 2 Phi(alpha) - 1 - (2/3) J(2 y_j; beta, S_j)
  (**) Phi(x_{i+1}) <= Phi(alpha) - J(x_i; beta, T_i)      (x_{N} := x_end)
  (E)  exp(-x_end^2/2) <= Phi(alpha) - 1/2, and the P-grid starts at the last C-grid point.
Finally the blocks must cover [A0, A1].  No floating-point optimisation is involved.
"""
import sys, gzip, json
from multiprocessing import Pool

sys.path.insert(0, "/workspace/rigorous")


def check_block(args):
    rec, prec = args
    from flint import arb, ctx
    import prawitz_arb as P  # sets ctx.prec = 64 on first import
    ctx.prec = prec
    P.PI = arb.pi()
    al, be = rec["alpha"], rec["beta"]
    A = arb(al)
    PhiA = P.Phi(A)
    HA = 2 * PhiA - 1
    cA = PhiA - arb(0.5)
    ys, Ss, xs, Ts, xe = rec["ys"], rec["Ss"], rec["xs"], rec["Ts"], rec["x_end"]
    if not (al < be):
        return (al, be, False, "bad block")
    if not ((-(arb(xe) ** 2) / 2).exp() < cA):
        return (al, be, False, "x_end")
    if ys[0] != al or len(Ss) != len(ys) - 1:
        return (al, be, False, "C-grid shape")
    for j, S in enumerate(Ss):
        y, yn = ys[j], ys[j + 1]
        if not (yn > y):
            return (al, be, False, f"C-grid order {j}")
        J = P.J_upper(2 * y, be, S)
        if not (2 * P.Phi(arb(yn)) - 1 <= HA - 2 * J / 3):
            return (al, be, False, f"(*) fails at j={j}")
    x1 = ys[-1]
    if x1 >= xe:
        return (al, be, True, "C-part reaches x_end")
    if not xs or xs[0] != x1 or len(Ts) != len(xs):
        return (al, be, False, "P-grid start")
    grid = xs + [xe]
    for i, T in enumerate(Ts):
        x, xn = grid[i], grid[i + 1]
        if not (xn > x):
            return (al, be, False, f"P-grid order {i}")
        J = P.J_upper(x, be, T)
        if not (P.Phi(arb(xn)) <= PhiA - J):
            return (al, be, False, f"(**) fails at i={i}")
    return (al, be, True, f"ok nC={len(Ss)} nP={len(Ts)}")


def main():
    path = sys.argv[1]; A0 = float(sys.argv[2]); A1 = float(sys.argv[3])
    prec = int(sys.argv[4]) if len(sys.argv) > 4 else 96
    nw = int(sys.argv[5]) if len(sys.argv) > 5 else 8
    recs = [json.loads(l) for l in gzip.open(path, "rt")]
    bad = []
    blocks = []
    with Pool(nw) as pool:
        for al, be, ok, msg in pool.imap_unordered(check_block, [(r, prec) for r in recs], chunksize=1):
            if ok:
                blocks.append((al, be))
            else:
                bad.append((al, be, msg))
                print("FAIL", al, be, msg, flush=True)
    blocks.sort()
    cur, gaps = A0, []
    for al, be in blocks:
        if al > cur:
            gaps.append((cur, al))
        cur = max(cur, be)
    if cur < A1:
        gaps.append((cur, A1))
    print(f"checked {len(recs)} blocks at prec={prec}: {len(bad)} failures; coverage of [{A0},{A1}]: "
          f"{'COMPLETE' if not gaps else gaps}")


if __name__ == "__main__":
    main()
