"""Two-valued weights: m copies of 1, k copies of t (0<t<=1), normalized."""
import numpy as np
from kk_exact import deviations

res = []
for m in range(1, 13):
    for k in range(1, 13):
        if m + k > 16:
            continue
        for t in np.linspace(0.05, 1.0, 96):
            a = np.concatenate([np.ones(m), np.full(k, t)])
            d = deviations(a)
            res.append((d['rLnt'], d['rU'], m, k, t, d['a1'], d['xLnt'], d['xU']))
res = np.array(res, dtype=object)
idx = np.argsort([-r[0] for r in res])[:15]
print("top rLnt (nontrivial L ratio)")
for i in idx:
    r = res[i]
    print("rLnt=%.5f rU=%.5f m=%d k=%d t=%.3f a1=%.4f xL=%.4f" % (r[0], r[1], r[2], r[3], r[4], r[5], r[6] or -1))
idx = np.argsort([-r[1] for r in res])[:15]
print("top rU")
for i in idx:
    r = res[i]
    print("rLnt=%.5f rU=%.5f m=%d k=%d t=%.3f a1=%.4f xU=%.4f" % (r[0], r[1], r[2], r[3], r[4], r[5], r[7]))
