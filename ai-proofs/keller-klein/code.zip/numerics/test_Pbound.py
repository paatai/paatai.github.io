"""Test the clean zone-A bound:  2 S(x) <= 2 S(0) + 2 P(x),  P(x)=int_0^1 [k(u,-x,T)-(1-u)]_+ du.
If 2 P(x) <= H(x) for x in [0, alpha/2] (T=pi/beta), zone A needs only 2S(0)<=H(alpha) per block.
Also compares P(x) (a-free) to the true sup_a D(a,x) to see how loose the h<=1 step is."""
import math
import numpy as np
from scipy.special import erf, gamma

def H(x): return erf(x / math.sqrt(2))

# fine u-grid
_x, _w = np.polynomial.legendre.leggauss(24)
e = np.linspace(0, 1, 2000 + 1)
a_, b_ = e[:-1, None], e[1:, None]
U = ((a_ + b_) / 2 + (b_ - a_) / 2 * _x[None, :]).ravel()
W = ((b_ - a_) / 2 * _w[None, :]).ravel()

def rho(u): return (1 - u) / np.tan(np.pi * u) + 1 / np.pi
def kfun(u, x, T): return (1 - u) * np.cos(T * u * x) + rho(u) * np.sin(T * u * x)

def Px(x, T):
    B = kfun(U, x, T) - (1 - U)      # = (1-u)(cos-1) + rho sin
    return float(np.sum(W * np.maximum(B, 0.0)))

def supD(x, T, beta, na=400):
    B = kfun(U, x, T) - (1 - U)
    best = -1e9
    for a in np.linspace(1e-3, beta, na):
        h = np.abs(np.cos(a * T * U)) ** (1.0 / a ** 2)
        best = max(best, float(np.sum(W * B * h)))
    return best

print("For each (alpha,beta): worst over x in [0,alpha/2] of  2P(x)-H(x)  and  2supD(x)-H(x).")
for alpha, beta in [(0.2, 0.2004), (0.3, 0.3015), (0.5, 0.5078), (0.7, 0.7239),
                    (0.9, 0.956), (1.0, 1.0), (0.15, 0.1502), (0.1, 0.1001), (0.05,0.0500)]:
    T = math.pi / beta
    xs = np.linspace(0, alpha / 2, 40)
    wP = max(2 * Px(x, T) - H(x) for x in xs)
    wD = max(2 * supD(x, T, beta) - H(x) for x in xs)
    # also the max ratio 2P/H away from 0
    xs2 = xs[xs > 1e-4]
    rP = max(2 * Px(x, T) / H(x) for x in xs2)
    print(f"alpha={alpha:.3f} beta={beta:.4f}: max(2P-H)={wP:+.3e}  max(2supD-H)={wD:+.3e}  max 2P/H={rP:.3f}")
