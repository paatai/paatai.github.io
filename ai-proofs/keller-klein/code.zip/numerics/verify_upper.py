"""Verify the Prawitz UPPER bound  Pr[|X|<=x] <= 2 J(-x; a1, T)  against exact probabilities.

Two layers:
 (1) raw Prawitz:  Pr[|X|<=x] <= P_raw(x) := 2 * int_0^1 k(u,-x,T) phi_X(Tu) du   (true phi_X)
 (2) enveloped:    P_raw(x)   <= 2 J(-x; a1, T)                                     (pointwise envelope)
A violation of (1) would refute the derivation; a violation of (2) would refute the envelope use.
"""
import math, random
import numpy as np
import prawitz_fast as pf
from prawitz_upper import BU_many_x
from kk_exact import abs_atoms

rng = random.Random(7)
_GLx, _GLw = np.polynomial.legendre.leggauss(64)


def phiX(v, a):
    v = np.asarray(v)
    out = np.ones_like(v, dtype=float)
    for ai in a:
        out = out * np.cos(ai * v)
    return out


def P_raw(x, a, T, nsub=2000):
    # 2 * int_0^1 k(u,-x,T) phi_X(T u) du, careful near u=0,1 (k is regular there)
    edges = np.linspace(1e-9, 1 - 1e-9, nsub + 1)
    lo, hi = edges[:-1, None], edges[1:, None]
    u = (lo + hi) / 2 + (hi - lo) / 2 * _GLx[None, :]
    w = (hi - lo) / 2 * _GLw[None, :]
    u = u.ravel(); w = w.ravel()
    k = pf.kfun(u, -x, T)
    return 2.0 * float(np.sum(w * k * phiX(T * u, a)))


def Pr_abs_le(atoms, masses, x):
    return float(np.sum(masses[atoms <= x + 1e-12]))


def main(trials=300):
    worst_raw = -1e9; worst_env = -1e9; wr_info = er_info = None
    for t in range(trials):
        n = rng.randint(2, 15)
        if rng.random() < 0.3:
            w = np.ones(n)  # equal weights (extremal for U)
        else:
            w = np.array(sorted([rng.random() ** rng.choice([0.3, 1, 3]) for _ in range(n)], reverse=True))
        w = w / np.linalg.norm(w)
        a1 = float(w[0])
        atoms, masses, a = abs_atoms(w)
        for _ in range(20):
            x = rng.random() * 2.5 * a1 if rng.random() < 0.7 else rng.random() * 3
            T = (0.5 + 1.2 * rng.random()) * math.pi / a1
            true = Pr_abs_le(atoms, masses, x)
            praw = P_raw(x, a, T)
            penv = float(BU_many_x([x], a1, T, nsub=1200)[0])
            if true - praw > worst_raw:
                worst_raw = true - praw; wr_info = (n, a1, x, T, true, praw)
            if praw - penv > worst_env:
                worst_env = praw - penv; er_info = (n, a1, x, T, praw, penv)
    print(f"max [true - P_raw]  = {worst_raw:.3e}  (must be <= 0; raw Prawitz upper bound)")
    print(f"   at {wr_info}")
    print(f"max [P_raw - 2J_env]= {worst_env:.3e}  (must be <= 0; envelope step)")
    print(f"   at {er_info}")


if __name__ == "__main__":
    main()
