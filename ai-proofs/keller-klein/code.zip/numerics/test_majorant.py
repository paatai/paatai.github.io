"""Test candidate a-monotone majorants for G(a;x), T=pi/a1, that would give mono for free.
 (1) x=0:  is  G(a;0) <= (1/(2pi)) I(1/a^2)  ?   [then mono via I decreasing]
 (2) x>0:  is  G(a;x) <= (1/(2pi)) I(1/a^2) + (x-correction indep of a, or increasing in a)?
     Candidate: Gtil(a;x) := int_0^1 [k_xi(u)] |cos(a T u)|^{1/a^2} du  but bound k by its sup?
     Simpler diagnostic: compare G(a;x) to G(a1;x) directly and to (1/2pi)I + delta.
"""
import numpy as np, math
from scipy.special import gamma
import prawitz_fast as pf
import prawitz_holder as ph
Phi = pf.Phi
def H(x): return 2*Phi(x)-1
U, Wt = ph._grid(4000)

def kf(u, x, T):
    rho = (1-u)/np.tan(np.pi*u) + 1/np.pi
    return (1-u)*np.cos(T*u*x) + rho*np.sin(T*u*x)

def G(a, x, a1):
    T = math.pi/a1
    k = kf(U, x, T)
    return float(np.sum(Wt*k*np.abs(np.cos(a*T*U))**(1.0/a**2)))

def halfI(a):  # (1/2pi) I(1/a^2) = (1/2) * Gamma((p+1)/2)/(sqrt(pi)Gamma(p/2+1)), p=1/a^2
    p = 1.0/a**2
    return 0.5*gamma((p+1)/2)/(math.sqrt(math.pi)*gamma(p/2+1))

if __name__ == "__main__":
    print("=== (1) x=0: G(a;0) vs (1/2pi)I(1/a^2)  (want G <= halfI, i.e. diff<=0) ===")
    for a1 in [1.0, 0.5, 0.2, 0.1, 0.055]:
        worst = -1e9; wa = None
        for a in np.linspace(a1/200, a1, 200):
            d = G(a, 0.0, a1) - halfI(a)
            if d > worst: worst = d; wa = a/a1
        print(f"  a1={a1:.3f}: max [G(a;0)-halfI(a)] = {worst:+.3e} at a/a1={wa:.3f}")

    print("\n=== (2) x>0: is G(a;x) <= halfI(a) + [G(a1;x)-halfI(a1)] for a<=a1? ===")
    print("     (RHS is monotone-in-a majorant iff G(a1;x)-halfI(a1)>=0 acts as const shift)")
    for a1 in [1.0, 0.5, 0.2, 0.1]:
        for xr in [0.1, 0.25, 0.4]:
            x = xr*a1
            shift = G(a1, x, a1) - halfI(a1)
            worst = -1e9; wa=None
            for a in np.linspace(a1/200, a1, 200):
                d = G(a, x, a1) - (halfI(a) + shift)
                if d > worst: worst = d; wa=a/a1
            print(f"  a1={a1:.2f} x/a1={xr:.2f}: shift={shift:+.2e}, max[G-(halfI+shift)]={worst:+.3e} at a/a1={wa:.3f}")
