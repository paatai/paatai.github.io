import numpy as np, math, sys
from prawitz_fast import best_over_T, c, B

variant = sys.argv[1] if len(sys.argv) > 1 else 'improved'
a1s = [0.05, 0.08, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65, 0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 1.0]
taus = np.pi * np.linspace(0.6, 1.3, 71)
for a1 in a1s:
    xs = np.concatenate([a1 * (1 + np.geomspace(1e-4, 1, 60)), np.linspace(2 * a1, max(4.0, 3 * a1), 400)])
    xs = np.unique(xs)
    best, arg = best_over_T(xs, a1, taus, variant, nsub=300 if a1 > 0.07 else 600)
    marg = best - c(a1)
    bad = xs[marg > 0]
    i = int(np.argmax(marg[xs > a1 * 1.001]))
    xm = xs[xs > a1 * 1.001][i]
    print("a1=%.3f c=%.5f  max margin(x>1.001a1)=%+.2e at x=%.4f (xi=%.3f)  #bad=%d  bad range=[%s]" % (
        a1, c(a1), marg[xs > a1 * 1.001].max(), xm, xm / a1, len(bad),
        ("%.4f..%.4f" % (bad.min(), bad.max())) if len(bad) else ""))
    sys.stdout.flush()
