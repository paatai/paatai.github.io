"""Non-rigorous exploration of the Prawitz-type bound (Keller-Klein Prop. 4.3,
pointwise-optimal variant) for the (L) half:  P(Z<x) - P(X<x) <= B(x; a1, T).

B = Phi(x) - 1/2 + int_0^1 max(k L(Tu), k U(Tu)) du, with L <= phi_X <= U.
"""
import numpy as np, math, sys
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import erf

THETA = brentq(lambda y: math.exp(-y * y / 2) + math.cos(y), 1.5, 2.5)


def Phi(x):
    return 0.5 * (1 + erf(x / math.sqrt(2)))


def c(a1):
    return Phi(a1) - 0.5


def kfun(u, x, T):
    return (1 - u) * math.sin(math.pi * u - T * u * x) / math.sin(math.pi * u) - math.sin(T * u * x) / math.pi


def LU(v, a1):
    av = a1 * v
    g = math.exp(-v * v / 2)
    if av <= math.pi / 2:
        return math.cos(av) ** (1 / a1 ** 2), g
    if av <= THETA:
        return -g, g
    if av <= math.pi:
        e = abs(math.cos(av)) ** (1 / a1 ** 2)
        return -e, e
    return -1.0, 1.0


def integrand(u, x, T, a1):
    k = kfun(u, x, T)
    L, U = LU(T * u, a1)
    return max(k * L, k * U)


def B(x, a1, T):
    pts = sorted(set([p for p in [math.pi / 2 / (a1 * T), THETA / (a1 * T), math.pi / (a1 * T)] if 0 < p < 1]))
    val, err = quad(integrand, 1e-12, 1 - 1e-12, args=(x, T, a1), points=pts or None, limit=400)
    return Phi(x) - 0.5 + val


def best_T(x, a1, Ts):
    vals = [B(x, a1, T) for T in Ts]
    i = int(np.argmin(vals))
    return vals[i], Ts[i]


if __name__ == "__main__":
    for a1 in [0.3, 0.22, 0.15, 0.1]:
        Ts = np.linspace(0.5 * math.pi / a1, 1.15 * math.pi / a1, 27)
        print("a1=%.3f c=%.5f" % (a1, c(a1)))
        for x in np.concatenate([np.linspace(a1, 3 * a1, 9), np.linspace(3 * a1, 3.5, 12)]):
            v, T = best_T(x, a1, Ts)
            print("  x=%.3f  B=%.5f  B-c=%+.5f  T*a1/pi=%.3f" % (x, v, v - c(a1), T * a1 / math.pi))
        sys.stdout.flush()
