"""Float test of the honest-sup covering bound for sup_{a<=a1} G(a;x), for the (U) Holder zone.
Region analysis:
  * For a <= a_c := theta*a1/pi (~0.566 a1): a*T*u <= theta for all u in [0,1], so
    |cos(aTu)|^{1/a^2} = cos(aTu)^{1/a^2} <= exp(-(Tu)^2/2).  Hence
        sup_{a<=a_c} G(a) <= Ggauss := int_0^1 k(u,-x,T) exp(-(Tu)^2/2) du.      (one integral)
  * For a in (a_c, a1]: cover by pieces [a_j,a_{j+1}].  h(a,u)=|cos(aTu)|^{1/a^2} is
    (as a function of a, u fixed) decreasing then increasing -> max at an endpoint, so
        sup_{a in [a_j,a_{j+1}]} G(a) <= int_0^1 k(u) * max(h(a_j,u), h(a_{j+1},u)) du.
Certify  2*S <= H(x)+H(a1),  S = max(Ggauss, max_j piecebound_j).
Report the smallest margin and the K needed.
"""
import numpy as np, math, sys
import prawitz_fast as pf
import prawitz_holder as ph
Phi = pf.Phi
def H(x): return 2*Phi(x)-1
THETA = pf.THETA
U, Wt = ph._grid(4000)

def kf(u, x, T):
    rho = (1-u)/np.tan(np.pi*u) + 1/np.pi
    return (1-u)*np.cos(T*u*x) + rho*np.sin(T*u*x)

def h(a, T):
    return np.abs(np.cos(a*T*U))**(1.0/a**2)

def Scover(x, a1, K):
    T = math.pi/a1
    k = kf(U, x, T)
    Ggauss = float(np.sum(Wt*k*np.exp(-(T*U)**2/2)))
    a_c = THETA*a1/math.pi
    edges = np.linspace(a_c, a1, K+1)
    best = Ggauss
    for j in range(K):
        hj = h(edges[j], T); hj1 = h(edges[j+1], T)
        pb = float(np.sum(Wt*k*np.maximum(hj, hj1)))
        if pb > best: best = pb
    return best, Ggauss

if __name__ == "__main__":
    print("Certify 2*Scover <= H(x)+H(a1) on zone A: x in [0, 0.4 a1]")
    for a1 in [1.0, 0.5, 0.3, 0.2, 0.1, 0.07, 0.055]:
        for K in [10, 40, 160]:
            worst = math.inf; wx = None
            for xr in np.linspace(0.0, 0.4, 17):
                x = xr*a1
                S, Gg = Scover(x, a1, K)
                m = H(x)+H(a1) - 2*S
                if m < worst: worst = m; wx = xr
            flag = "OK " if worst > 0 else "XX "
            print(f"  a1={a1:.3f} K={K:3d}: worst 2S-margin={worst:+.3e} at x/a1={wx:.2f} {flag}")
        print()
