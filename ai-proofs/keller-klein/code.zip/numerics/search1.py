import numpy as np, math, sys
from kk_exact import deviations
from scipy.optimize import minimize

rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 0)

def neg(key):
    def f(z):
        a = np.abs(z) + 1e-9
        return -deviations(a)[key]
    return f

best = {'rLnt': (0, None), 'rU': (0, None), 'rL': (0, None)}
for trial in range(400):
    n = int(rng.integers(2, 15))
    kind = rng.integers(0, 4)
    if kind == 0:
        a = rng.random(n)
    elif kind == 1:
        a = 1 + 0.1 * rng.standard_normal(n)
    elif kind == 2:
        k = int(rng.integers(1, n + 1))
        a = np.concatenate([np.ones(k), rng.random(n - k) * rng.random()])
    else:
        k = int(rng.integers(1, n + 1))
        a = np.concatenate([np.ones(k), np.full(n - k, rng.random())])
    a = np.abs(a) + 1e-6
    d = deviations(a)
    for key in best:
        if d[key] > best[key][0]:
            best[key] = (d[key], np.sort(a / np.linalg.norm(a))[::-1], d)
for key in best:
    v, a, d = best[key]
    print(key, v, 'a1=%.4f' % d['a1'], np.round(a, 4))

# local search from best for rLnt and rU
for key in ['rLnt', 'rU']:
    v, a, d = best[key]
    res = minimize(neg(key), a, method='Nelder-Mead', options=dict(maxiter=3000, xatol=1e-9, fatol=1e-12))
    a2 = np.abs(res.x); a2 /= np.linalg.norm(a2)
    print('local', key, -res.fun, np.round(np.sort(a2)[::-1], 5))
