"""Exact (floating, atom-merged) distribution of Rademacher sums and the
Keller-Klein deviations.

For X = sum a_i x_i (sum a_i^2 = 1), H(x) = P(|Z| <= x) = 2 Phi(x) - 1:
  (L)  sup_{x>0} [H(x) - P(|X| <  x)]  <= H(a_1)
  (U)  sup_{x>=0} [P(|X| <= x) - H(x)] <= H(a_1)
Both are equivalent to the two halves of the conjecture (factor 2 dropped).
"""
import itertools
import math
import numpy as np
from scipy.special import erf


def H(x):
    return erf(np.asarray(x, dtype=float) / math.sqrt(2.0))


def abs_atoms(a, tol=1e-11):
    """Return sorted distinct atoms t_k >= 0 of |X| and their masses."""
    a = np.asarray(a, dtype=float)
    a = a / math.sqrt(float(np.sum(a * a)))
    vals = np.zeros(1)
    for ai in a:
        vals = np.concatenate([vals + ai, vals - ai])
    vals = np.abs(vals)
    vals.sort()
    # merge
    atoms = []
    masses = []
    p = 1.0 / len(vals)
    cur = vals[0]
    m = p
    for v in vals[1:]:
        if v - cur <= tol:
            m += p
        else:
            atoms.append(cur)
            masses.append(m)
            cur = v
            m = p
    atoms.append(cur)
    masses.append(m)
    return np.array(atoms), np.array(masses), a


def deviations(a):
    atoms, masses, a = abs_atoms(a)
    a1 = float(np.max(a))
    Ha1 = float(H(a1))
    cdf_lt = np.concatenate([[0.0], np.cumsum(masses)[:-1]])  # P(|X| < t_k)
    cdf_le = np.cumsum(masses)  # P(|X| <= t_k)
    Ht = H(atoms)
    L_all = Ht - cdf_lt
    L_all[atoms <= 0] = -1
    L = float(np.max(L_all))
    sel = atoms > a1 + 1e-12
    Lnt = float(np.max(L_all[sel])) if np.any(sel) else 0.0
    U_all = cdf_le - Ht
    U = float(np.max(U_all))
    return dict(a1=a1, Ha1=Ha1, L=L, Lnt=Lnt, U=U,
                rL=L / Ha1, rLnt=Lnt / Ha1, rU=U / Ha1,
                xL=float(atoms[int(np.argmax(L_all))]),
                xLnt=float(atoms[sel][int(np.argmax(L_all[sel]))]) if np.any(sel) else None,
                xU=float(atoms[int(np.argmax(U_all))]))


if __name__ == "__main__":
    print("equal weights")
    for n in range(1, 21):
        d = deviations(np.ones(n))
        print(n, "a1=%.4f rL=%.5f rLnt=%.5f (x=%.3f) rU=%.5f (x=%.3f)" % (
            d['a1'], d['rL'], d['rLnt'], d['xLnt'] or -1, d['rU'], d['xU']))
