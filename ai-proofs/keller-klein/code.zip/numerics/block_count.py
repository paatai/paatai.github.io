"""Estimate the (U) zone-A block count: blocks [alpha,beta] need 2S(0;beta)+ (growth to x=alpha/2)
<= H(alpha).  Binding at x=0: (1/pi)I(1/beta^2) + overshoot(beta,K) <= H(alpha).
We march alpha->beta greedily (largest beta s.t. the x=0 condition holds with margin) and count.
"""
import numpy as np, math
from scipy.special import gamma
import prawitz_fast as pf
import prawitz_holder as ph
import test_cover as tc
Phi = pf.Phi
def H(x): return 2*Phi(x)-1
def halfI(a):
    p=1.0/a**2
    return 0.5*gamma((p+1)/2)/(math.sqrt(math.pi)*gamma(p/2+1))
def Ipi(a): return 2*halfI(a)  # (1/pi) I(1/a^2)

def twoS0(beta, K=14):
    # float covering 2S at x=0 for a1=beta
    S, _ = tc.Scover(0.0, beta, K)
    return 2*S

def count_blocks(amin, amax, K=14, safety=0.90):
    a = amin; n = 0; widths=[]
    while a < amax - 1e-12:
        Ha = H(a)
        # find largest beta<=amax with 2S(0;beta) <= Ha (with safety margin)
        lo, hi = a, min(amax, a*1.6)
        # ensure feasibility at lo
        if twoS0(lo+1e-9) > Ha:
            return None, f"infeasible at a={a}"  # overshoot already exceeds
        # expand hi if still feasible
        while hi < amax and twoS0(hi) <= Ha - safety*0 and twoS0(hi) <= Ha:
            hi = min(amax, hi*1.3)
        # binary search largest beta with twoS0(beta) <= Ha
        for _ in range(40):
            mid = 0.5*(lo+hi)
            if twoS0(mid) <= Ha:
                lo = mid
            else:
                hi = mid
        beta = lo
        # apply safety: shrink width by 10% to leave room for overshoot growth over x in [0,alpha/2]
        beta = a + safety*(beta-a)
        widths.append(beta-a)
        a = beta; n += 1
        if n > 5000: break
    return n, widths

if __name__ == "__main__":
    for (lo,hi) in [(0.5,1.0),(0.3,1.0),(0.2,1.0),(0.15,1.0),(0.1,1.0),(0.2,0.5),(0.1,0.2)]:
        n,w = count_blocks(lo,hi)
        if n is None:
            print(f"[{lo},{hi}]: {w}")
        else:
            print(f"[{lo},{hi}]: {n} blocks  (width min={min(w):.4f} max={max(w):.4f})")
