"""Go/no-go: does (U) hold for EVERY x>=0 and a1 in (0,1] via at least one method?

Methods (each an UPPER bound B on Pr[|X|<=x], valid for ALL weight vectors):
  (H) Holder  :  x in (0, a1/2],  B_H(x) = 2 sup_{a<=a1} G(a;x,a1,pi/a1),  k>=0 there.
  (E) envelope:  B_E(x) = 2 min_T J(-x; a1, T)   (pointwise envelopes).
  (T) trivial :  B_triv = 1.
(U) at x is certified if min(applicable B's) <= H(x)+H(a1).
We scan a fine (a1,x) grid and report any (a1,x) where NO method certifies (U).
"""
import numpy as np, math
import prawitz_fast as pf
import prawitz_upper as pu
import prawitz_holder as ph

Phi = pf.Phi
def H(x): return 2*Phi(x)-1

ph._U, ph._Wt = ph._grid(600)
def BH(x, a1, na=60):
    T = math.pi/a1
    agrid = np.linspace(a1/na, a1, na)
    return 2*max(ph.G(a, x, a1, T) for a in agrid)

# envelope: best over a wide tau grid
TAUS = np.pi*np.concatenate([np.linspace(0.3,2.0,80), np.linspace(2.0,8.0,60)])

if __name__ == "__main__":
    import sys
    a1lo = float(sys.argv[1]) if len(sys.argv)>1 else 0.05
    a1s = np.linspace(a1lo, 1.0, 96)
    worst_margin = np.inf; worst_at = None
    n_fail = 0
    for a1 in a1s:
        # x grid: dense near 0, out to where trivial kicks in (H(x)>=1-H(a1))
        x_triv = float(pf.Phi(0)*0)  # placeholder
        # find x where H(x) = 1-H(a1):  x = Phi^{-1}((2-H(a1))/2)... just scan to 3.5
        xs = np.unique(np.concatenate([
            np.linspace(1e-4, a1, 60),
            np.linspace(a1, 3.5, 200)]))
        # envelope bound for all xs at once (best over T)
        BE, _ = pu.best_BU_over_T(xs, a1, TAUS, nsub=400)
        for i, x in enumerate(xs):
            tgt = H(x) + H(a1)
            cands = [1.0, BE[i]]           # trivial, envelope
            if x <= a1/2 + 1e-12:
                cands.append(BH(x, a1))    # Holder (only where k>=0)
            B = min(cands)
            margin = tgt - B
            if margin < worst_margin:
                worst_margin = margin; worst_at = (a1, x, x/a1, B, tgt)
            if margin < -1e-9:
                n_fail += 1
                if n_fail <= 8:
                    print(f"  FAIL a1={a1:.3f} x={x:.4f} (x/a1={x/a1:.3f}): B={B:.5f} tgt={tgt:.5f} margin={margin:+.2e}")
    a1,x,xr,B,tgt = worst_at
    print(f"\nWORST margin over all (a1,x): {worst_margin:+.3e}")
    print(f"   at a1={a1:.3f}, x={x:.4f} (x/a1={xr:.3f}), B={B:.5f}, target={tgt:.5f}")
    print(f"Total grid failures (margin<-1e-9): {n_fail}")
    print("PASS: (U) certified at every sampled (a1,x)" if n_fail==0 else "SOME FAILURES")
