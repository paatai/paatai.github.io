"""Definitive single-T=pi/a1 hybrid (U) check.
 A) monotonicity: G(a) <= G(a1) for a in (0,a1]  (=> max_i G(a_i)=G(a1), dropping the sup)
    G(a) = int_0^1 k_+(u) |cos(a pi u/a1)|^{1/a^2} du,  k_+ = max(k(u,-x,pi/a1),0).
 B) full scan: B_hyb = 2(G(a1) + E),  E = int k_-(u) L_{a1}(pi u/a1) du,  vs H(x)+H(a1).
"""
import numpy as np, math, sys
from scipy.special import erfinv
import prawitz_fast as pf
import prawitz_holder as ph
Phi=pf.Phi
def H(x): return 2*Phi(x)-1
U,Wt=ph._grid(2500)

def kf(u,x,T):
    rho=(1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def Gfun(a,x,a1,T,kp=None):
    if kp is None:
        kp=np.maximum(kf(U,x,T),0.0)
    return float(np.sum(Wt*kp*np.abs(np.cos(a*T*U))**(1.0/a**2)))

def bhyb_mono(x,a1,T):
    """returns (B_hyb using G(a1), mono_violation = max_{a<a1} G(a)-G(a1))."""
    k=kf(U,x,T); kp=np.maximum(k,0); kn=np.minimum(k,0)
    L,_=pf.envelopes(T*U,a1)
    Ga1=Gfun(a1,x,a1,T,kp)
    # monotonicity: sample a in (0,a1]
    mv=-1e9
    for a in np.linspace(a1/40,a1*0.999,40):
        g=Gfun(a,x,a1,T,kp)
        if g-Ga1>mv: mv=g-Ga1
    E=float(np.sum(Wt*kn*L))
    return 2*(Ga1+E), mv

if __name__=="__main__":
    a1lo=float(sys.argv[1]) if len(sys.argv)>1 else 0.01
    a1s=np.linspace(a1lo,1.0,50)
    worst_m=np.inf; worst_at=None
    worst_mono=-1e9; mono_at=None
    nfail=0
    for a1 in a1s:
        T=math.pi/a1
        xtriv=math.sqrt(2)*erfinv(1-H(a1))
        xs=np.linspace(0.005*a1, min(xtriv,3.5), 70)
        for x in xs:
            B,mv=bhyb_mono(x,a1,T)
            m=H(x)+H(a1)-B
            if m<worst_m: worst_m=m; worst_at=(a1,x/a1,B)
            if mv>worst_mono: worst_mono=mv; mono_at=(a1,x/a1)
            if m<-1e-9:
                nfail+=1
                if nfail<=10: print(f"  FAIL a1={a1:.3f} x/a1={x/a1:.3f}: m={m:+.2e}")
    print(f"\n[A] worst monotonicity G(a)-G(a1) = {worst_mono:+.2e} at a1={mono_at[0]:.3f},x/a1={mono_at[1]:.2f} (<=0 means G max at a1)")
    print(f"[B] worst (U) margin = {worst_m:+.3e} at a1={worst_at[0]:.3f}, x/a1={worst_at[1]:.3f}, B={worst_at[2]:.5f}")
    print(f"    total failures: {nfail}")
    print("    PASS" if nfail==0 and worst_mono<=1e-9 else "    CHECK")
