"""Check B_hyb = 2 int_0^1 max(k U_H, k L) du  with  U_H(u)=|cos(pi u)|^{1/a1^2}, L=L_{a1}(pi u/a1),
equals the directly-computed hybrid bound 2(G(a1)+E), AND is >= Pr[|X|<=x] for exact vectors.
(valid only if monotonicity sup_a G(a)=G(a1) holds, which final_U_scan verifies.)
"""
import numpy as np, math
import prawitz_fast as pf
import prawitz_holder as ph
import kk_exact as kx
Phi=pf.Phi
def H(x): return 2*Phi(x)-1
U,Wt=ph._grid(2500)

def kf(u,x,T):
    rho=(1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def bhyb_direct(x,a1,T):
    k=kf(U,x,T); kp=np.maximum(k,0); kn=np.minimum(k,0)
    L,_=pf.envelopes(T*U,a1)
    Ga1=float(np.sum(Wt*kp*np.abs(np.cos(a1*T*U))**(1.0/a1**2)))
    E=float(np.sum(Wt*kn*L))
    return 2*(Ga1+E)

def bhyb_maxform(x,a1,T):
    k=kf(U,x,T)
    UH=np.abs(np.cos(a1*T*U))**(1.0/a1**2)   # = |cos(pi u)|^{1/a1^2}
    L,_=pf.envelopes(T*U,a1)
    return 2*float(np.sum(Wt*np.maximum(k*UH,k*L)))

def normalize(v):
    v=np.array(v,float); return v/math.sqrt(np.sum(v*v))

if __name__=="__main__":
    print("=== max-form vs direct hybrid ===")
    md=0
    for a1 in [0.03,0.1,0.3,0.7,1.0]:
        T=math.pi/a1
        for xr in [0.1,0.5,0.9,1.5,2.5]:
            x=xr*a1
            d=bhyb_direct(x,a1,T); mx=bhyb_maxform(x,a1,T)
            md=max(md,abs(d-mx))
    print(f"  max |direct - maxform| = {md:.2e}  (should be ~0)")

    print("\n=== max-form bound >= exact Pr, and <= target? ===")
    worst_valid=-1e9; worst_tgt=-1e9
    rng=np.random.default_rng(3)
    vrs=[normalize(np.ones(n)) for n in [2,3,4,5,8,12,20]]
    vrs+=[normalize([2.0,1,1]),normalize([3.0,1,1,1])]
    vrs+=[normalize(rng.uniform(0.3,1,rng.integers(2,9))) for _ in range(20)]
    for a in vrs:
        a=np.sort(a)[::-1]; a1=min(float(a[0]),1.0); T=math.pi/a1
        for xr in [0.1,0.4,0.7,1.0,1.4,2.0]:
            x=xr*a1
            atoms,masses,_=kx.abs_atoms(a)
            exact=float(np.sum(masses[atoms<=x+1e-13]))
            B=bhyb_maxform(x,a1,T)
            worst_valid=max(worst_valid, exact-B)     # need <=0
            worst_tgt=max(worst_tgt, B-(H(x)+H(a1)))   # need <=0
    print(f"  worst (exact - Bmaxform) = {worst_valid:+.2e}  (<=0 => valid upper bound)")
    print(f"  worst (Bmaxform - target)= {worst_tgt:+.2e}  (<=0 => proves (U))")
