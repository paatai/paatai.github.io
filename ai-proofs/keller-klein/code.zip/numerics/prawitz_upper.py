"""Pointwise-envelope Prawitz UPPER bound for the (U) half of Keller-Klein.

For symmetric X and any y, Prawitz gives  Pr[X<y] >= 1/2 - int_0^1 k(u,y,T) phi_X(Tu) du.
Put y=-x (x>=0) and use Pr[X<=x] = 1 - Pr[X<-x] (symmetry):
    Pr[X<=x] <= 1/2 + int_0^1 k(u,-x,T) phi_X(Tu) du,
    Pr[|X|<=x] = 2 Pr[X<=x] - 1 <= 2 int_0^1 k(u,-x,T) phi_X(Tu) du
               <= 2 J(-x; a, T),   J(-x;a,T) = int_0^1 max(k(u,-x,T) L_a, k(u,-x,T) U_a) du.
So (U)  Pr[|X|<=x] <= H(x)+H(a1)  is implied (pointwise envelopes) by
    BU(x;a,T) := 2 J(-x; a, T)  <=  H(x) + H(a1).
This file scans the slack  s(x) = H(x)+H(a1) - min_T BU(x;a,T).  s>=0 means Prawitz proves (U) at x.
"""
import numpy as np, math
import prawitz_fast as pf

Phi = pf.Phi


def H(x):
    return 2 * Phi(x) - 1


def BU_many_x(xs, a1, T, variant='improved', nsub=400):
    """2 J(-x; a1, T) for an array of x>=0."""
    u, w = pf.nodes(T, a1, nsub)
    L, U = pf.envelopes(T * u, a1, variant)
    xs = np.asarray(xs)[:, None]
    k = pf.kfun(u[None, :], -xs, T)          # kernel at -x
    J = np.sum(w[None, :] * np.maximum(k * L[None, :], k * U[None, :]), axis=1)
    return 2.0 * J


def best_BU_over_T(xs, a1, taus, variant='improved', nsub=400):
    best = np.full(len(xs), np.inf)
    arg = np.zeros(len(xs))
    for tau in taus:
        b = BU_many_x(xs, a1, tau / a1, variant, nsub)
        m = b < best
        best[m] = b[m]
        arg[m] = tau
    return best, arg


if __name__ == "__main__":
    taus = np.pi * np.linspace(0.3, 2.0, 60)
    for a1 in [0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0]:
        # scan x from 0 up to where (U) becomes trivial (H(x) >= 1 - H(a1))
        xU = 3.5
        xs = np.linspace(0.0, xU, 700)
        BU, arg = best_BU_over_T(xs, a1, taus)
        target = H(xs) + H(a1)
        slack = target - BU
        # find worst (most negative) slack and where
        imin = int(np.argmin(slack))
        # also report slack at x=0 and the largest x with slack<0
        neg = np.where(slack < 0)[0]
        if len(neg):
            x_lo, x_hi = xs[neg[0]], xs[neg[-1]]
        else:
            x_lo = x_hi = float('nan')
        print(f"a1={a1:.2f}: min slack={slack[imin]:+.5f} at x={xs[imin]:.4f} (x/a1={xs[imin]/a1:.3f}, tau/pi={arg[imin]/math.pi:.3f}); "
              f"slack(0)={slack[0]:+.5f}; neg range x in [{x_lo:.4f},{x_hi:.4f}]")
