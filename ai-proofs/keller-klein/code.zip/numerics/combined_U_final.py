"""Definitive go/no-go for (U) over all x>=0 and a1 in (0,1], using:
   x in (0, a1]  : hybrid Holder/envelope bound (T=pi/a1)
   x in [a1, .]  : pointwise-envelope bound 2 min_T J(-x; a1, T)
   any x         : trivial bound 1
(U) certified at (a1,x) if min(applicable bounds) <= H(x)+H(a1).
"""
import numpy as np, math, sys
import prawitz_fast as pf
import prawitz_upper as pu
import prawitz_holder as ph
import hybrid_holder as hy

Phi=pf.Phi
def H(x): return 2*Phi(x)-1
TAUS=np.pi*np.concatenate([np.linspace(0.3,2.0,80),np.linspace(2.0,8.0,60)])

if __name__=="__main__":
    a1lo=float(sys.argv[1]) if len(sys.argv)>1 else 0.01
    a1s=np.linspace(a1lo,1.0,60)
    worst=np.inf; worst_at=None; nfail=0
    for a1 in a1s:
        T=math.pi/a1
        # hybrid region x in (0, a1]
        xs_h=np.linspace(0.02*a1,a1,22)
        for x in xs_h:
            B=hy.hybrid_bound(x,a1,T,na=50)
            m=H(x)+H(a1)-B
            if m<worst: worst=m; worst_at=(a1,x,x/a1,'hyb',B)
            if m<-1e-9:
                nfail+=1
                if nfail<=12: print(f"  FAIL(hyb) a1={a1:.3f} x/a1={x/a1:.3f}: B={B:.6f} tgt={H(x)+H(a1):.6f} m={m:+.2e}")
        # envelope/trivial region x in [a1, 3.5]
        xs_e=np.linspace(a1,3.5,180)
        BE,_=pu.best_BU_over_T(xs_e,a1,TAUS,nsub=500)
        for i,x in enumerate(xs_e):
            B=min(1.0,BE[i])
            m=H(x)+H(a1)-B
            if m<worst: worst=m; worst_at=(a1,x,x/a1,'env',B)
            if m<-1e-9:
                nfail+=1
                if nfail<=12: print(f"  FAIL(env) a1={a1:.3f} x/a1={x/a1:.3f}: B={B:.6f} tgt={H(x)+H(a1):.6f} m={m:+.2e}")
    a1,x,xr,meth,B=worst_at
    print(f"\nWORST margin over all (a1,x): {worst:+.3e} at a1={a1:.3f} x/a1={xr:.3f} ({meth}) B={B:.5f}")
    print(f"Total failures: {nfail}")
    print("PASS: (U) certified at every sampled (a1,x)" if nfail==0 else "SOME FAILURES")
