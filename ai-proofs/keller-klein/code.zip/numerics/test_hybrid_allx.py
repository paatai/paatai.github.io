"""Does the hybrid bound (pointwise k-masking) work for ALL x, incl. large x and small a1?
B_hyb(x,a1,T) = 2[ sup_{a<=a1} int_{k>=0} k|cos(aTu)|^{1/a^2} du + int_{k<0} k L_{a1}(Tu) du ].
We minimize over T in a grid and scan x from 0 to the trivial threshold.
"""
import numpy as np, math, sys
import prawitz_fast as pf
import prawitz_holder as ph
Phi=pf.Phi
def H(x): return 2*Phi(x)-1
U,Wt=ph._grid(2000)

def kf(u,x,T):
    rho=(1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def bhyb(x,a1,T,na=50):
    k=kf(U,x,T); kp=np.maximum(k,0); kn=np.minimum(k,0)
    L,_=pf.envelopes(T*U,a1)
    agrid=np.linspace(a1/na,a1,na)
    supG=max(float(np.sum(Wt*kp*np.abs(np.cos(av*T*U))**(1.0/av**2))) for av in agrid)
    return 2*(supG+float(np.sum(Wt*kn*L)))

def bhyb_optT(x,a1,taus):
    return min(bhyb(x,a1,tau/a1) for tau in taus)

if __name__=="__main__":
    taus=np.pi*np.array([0.5,0.7,0.85,1.0,1.15,1.3])
    for a1 in [0.01,0.03,0.05,0.1,0.3,1.0]:
        # x up to trivial threshold: H(x)>=1-H(a1)
        from scipy.special import erfinv
        xtriv=math.sqrt(2)*erfinv(1-H(a1))
        xs=np.linspace(0.02*a1, min(xtriv*1.02, 3.5), 40)
        worst=math.inf; wx=None
        for x in xs:
            B=bhyb_optT(x,a1,taus)
            m=H(x)+H(a1)-B
            if m<worst: worst=m; wx=x
        print(f"a1={a1:.2f}: xtriv={xtriv:.3f}, worst hybrid margin={worst:+.3e} at x={wx:.4f} (x/a1={wx/a1:.2f})")
