"""(1) Verify 2G(a1;x=0) = (1/pi) I(1/a1^2) exactly (symmetry identity).
   (2) Does a SINGLE T=pi/a1 make the hybrid bound work for all x, all a1?  (vs needing T-opt)
"""
import numpy as np, math
from scipy.special import gamma
import prawitz_fast as pf
import prawitz_holder as ph
Phi=pf.Phi
def H(x): return 2*Phi(x)-1
U,Wt=ph._grid(3000)

def kf(u,x,T):
    rho=(1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def bhyb(x,a1,T,na=60):
    k=kf(U,x,T); kp=np.maximum(k,0); kn=np.minimum(k,0)
    L,_=pf.envelopes(T*U,a1)
    agrid=np.linspace(a1/na,a1,na)
    supG=max(float(np.sum(Wt*kp*np.abs(np.cos(av*T*U))**(1.0/av**2))) for av in agrid)
    return 2*(supG+float(np.sum(Wt*kn*L)))

def Ip_over_pi(p):
    # (1/pi) int_0^pi |cos s|^p ds = Gamma((p+1)/2)/(sqrt(pi) Gamma(p/2+1))
    return gamma((p+1)/2)/(math.sqrt(math.pi)*gamma(p/2+1))

if __name__=="__main__":
    print("=== (1) 2G(a1;0) vs (1/pi)I(1/a1^2) ===")
    for a1 in [0.05,0.1,0.3,0.6,1.0]:
        p=1.0/a1**2
        twoG=2*float(np.sum(Wt*(1-U)*np.abs(np.cos(np.pi*U))**p))
        iip=Ip_over_pi(p)
        print(f"  a1={a1:.2f}: 2G={twoG:.10f}  (1/pi)I={iip:.10f}  diff={twoG-iip:+.2e}  H(a1)-2G={H(a1)-twoG:+.3e}")

    print("\n=== (2) single T=pi/a1 hybrid: worst margin over x in (0,xtriv] ===")
    from scipy.special import erfinv
    for a1 in [0.01,0.02,0.03,0.05,0.1,0.2,0.4,0.7,1.0]:
        T=math.pi/a1
        xtriv=math.sqrt(2)*erfinv(1-H(a1))
        xs=np.linspace(0.01*a1,min(xtriv,3.5),60)
        worst=math.inf; wx=None
        for x in xs:
            m=H(x)+H(a1)-bhyb(x,a1,T)
            if m<worst: worst=m; wx=x
        flag="  <-- NEG" if worst<-1e-9 else ""
        print(f"  a1={a1:.2f}: worst single-T margin={worst:+.3e} at x/a1={wx/a1:.2f}{flag}")
