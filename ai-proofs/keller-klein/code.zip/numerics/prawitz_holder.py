"""Hoelder bound on the Prawitz UPPER integral, for the (U) half near x=0.

Prawitz (lower) at y=-x and symmetry give, for every T>0 and x>=0,
    Pr[|X|<=x] <= 2 int_0^1 k(u,-x,T) phi_X(Tu) du,                        (*)
with phi_X(Tu)=prod_i cos(a_i T u).  Write
    k(u,-x,T) = (1-u)cos(Tux) + rho(u) sin(Tux),   rho(u)=(1-u)cot(pi u)+1/pi.
Fact: rho(u)>=0 on (0,1)  (pi(1-u)cos(pi u)+sin(pi u) is decreasing from pi to 0).
So if Tx<=pi/2 then cos(Tux)>=0 and sin(Tux)>=0 for all u in (0,1), hence k>=0.

With k>=0, phi_X<=prod|cos(a_i Tu)|, and generalized Hoelder with p_i=1/a_i^2
(sum 1/p_i = sum a_i^2 = 1) over the positive measure k(u,-x,T)du gives
    int k prod|cos(a_i Tu)| du <= prod_i ( int k |cos(a_i Tu)|^{1/a_i^2} du )^{a_i^2}
                              <= max_i G(a_i) <= sup_{a in (0,a1]} G(a),
    G(a) := int_0^1 k(u,-x,T) |cos(a T u)|^{1/a^2} du.
Therefore
    Pr[|X|<=x]  <=  2 sup_{a in (0,a1]} G(a)  =: M(x,a1,T).                 (**)
Hoelder is EQUALITY for equal weights (a_i=a1), the extremal case for (U) at x=0,
so (**) does not suffer the third-order envelope overshoot.

This file (1) checks k>=0, (2) checks whether sup_a G(a)=G(a1), and
(3) scans the slack  H(x)+H(a1) - M(x,a1,T)  for x near 0.
"""
import numpy as np, math
import prawitz_fast as pf

Phi = pf.Phi
def H(x): return 2*Phi(x)-1

# high-order Gauss-Legendre on [0,1], many subintervals (k and |cos|^p are smooth on (0,1))
_X, _W = np.polynomial.legendre.leggauss(24)
def _grid(nsub=2000):
    edges = np.linspace(0.0, 1.0, nsub+1)
    a, b = edges[:-1, None], edges[1:, None]
    u = (a+b)/2 + (b-a)/2*_X[None, :]
    w = (b-a)/2*_W[None, :]
    return u.ravel(), w.ravel()

_U, _Wt = _grid()

def kpos(u, x, T):
    """k(u,-x,T) = (1-u)cos(Tux) + rho(u) sin(Tux)."""
    rho = (1-u)/np.tan(np.pi*u) + 1/np.pi
    return (1-u)*np.cos(T*u*x) + rho*np.sin(T*u*x)

def G(a, x, a1, T):
    """int_0^1 k(u,-x,T) |cos(a T u)|^{1/a^2} du."""
    k = kpos(_U, x, T)
    val = np.abs(np.cos(a*T*_U))**(1.0/a**2)
    return float(np.sum(_Wt*k*val))

def M(x, a1, T, na=200):
    """2 sup_{a in (0,a1]} G(a); returns (M, argmax a)."""
    agrid = np.linspace(a1/na, a1, na)
    gs = np.array([G(a, x, a1, T) for a in agrid])
    i = int(np.argmax(gs))
    return 2*gs[i], agrid[i]

if __name__ == "__main__":
    print("=== (1) check k(u,-x,T)>=0 on (0,1) for T=pi/a1, x<=a1/2 ===")
    worst = np.inf
    for a1 in [0.05,0.1,0.2,0.3,0.5,0.7,1.0]:
        T = math.pi/a1
        for xr in np.linspace(0.0, 0.5, 26):  # x = xr*a1, up to a1/2
            x = xr*a1
            k = kpos(_U, x, T)
            worst = min(worst, k.min())
    print(f"  min k over all sampled (a1,x<=a1/2,u) = {worst:+.6e}  (should be >=0)")

    print("\n=== (2) is sup_a G(a) attained at a=a1? ===")
    for a1 in [0.05,0.1,0.3,0.5,1.0]:
        T = math.pi/a1
        x = 0.1*a1
        agrid = np.linspace(a1/60, a1, 60)
        gs = np.array([G(a,x,a1,T) for a in agrid])
        i = int(np.argmax(gs))
        print(f"  a1={a1:.2f}, x={x:.4f}: argmax a={agrid[i]:.4f} (a/a1={agrid[i]/a1:.3f}), "
              f"G(a1)={gs[-1]:.6f}, maxG={gs[i]:.6f}")

    print("\n=== (3) slack H(x)+H(a1) - M(x,a1,pi/a1) for x in (0, a1/2] ===")
    for a1 in [0.05,0.1,0.2,0.3,0.5,0.7,1.0]:
        T = math.pi/a1
        xs = np.linspace(1e-4*a1, 0.5*a1, 40)
        slacks = []
        for x in xs:
            m,_ = M(x,a1,T)
            slacks.append(H(x)+H(a1)-m)
        slacks = np.array(slacks)
        imin = int(np.argmin(slacks))
        print(f"  a1={a1:.2f}: min slack={slacks[imin]:+.6e} at x/a1={xs[imin]/a1:.3f}; "
              f"slack at x->0 = {slacks[0]:+.6e}")
