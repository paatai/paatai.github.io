"""CRITICAL sanity check of the Hoelder (U)-near-0 chain against EXACT probabilities.

Chain:  Pr[|X|<=x]  <=  2 int k(u,-x,T) phi_X(Tu) du         (I: Prawitz upper)
                    <=  2 int k(u,-x,T) prod|cos(a_i Tu)| du (II: k>=0, phi<=|phi|)
                    <=  2 prod_i G(a_i)^{a_i^2}               (III: Hoelder)
                    <=  2 max_i G(a_i)                        (IV: weighted geo-mean<=max)
                    <=  2 sup_{a<=a1} G(a) = M               (V)
                    <=  H(x)+H(a1)                            (VI: the target)
Each inequality must hold for every test vector.  We check I..V exactly (numerics vs
exact atoms) and report the worst violation of each link.
"""
import numpy as np, math, itertools
import prawitz_fast as pf
import prawitz_holder as ph
import kk_exact as kx

Phi = pf.Phi
def H(x): return 2*Phi(x)-1

# faster integration grid for the sanity check (accuracy ~1e-6 is plenty vs margins >1e-5)
ph._U, ph._Wt = ph._grid(400)
def M_fast(x, a1, T, na=40):
    agrid = np.linspace(a1/na, a1, na)
    gs = [ph.G(a, x, a1, T) for a in agrid]
    return 2*max(gs)

def exact_abs_cdf(a, x):
    """Pr[|X|<=x] exactly from atoms of |X|."""
    atoms, masses, _ = kx.abs_atoms(a)
    return float(np.sum(masses[atoms <= x + 1e-13]))

def intI(a, x, T):   # 2 int k(u,-x,T) phi_X(Tu) du
    k = ph.kpos(ph._U, x, T)
    phiX = np.prod([np.cos(ai*T*ph._U) for ai in a], axis=0)
    return 2*float(np.sum(ph._Wt*k*phiX))

def intII(a, x, T):  # 2 int k prod|cos| du
    k = ph.kpos(ph._U, x, T)
    absphi = np.prod([np.abs(np.cos(ai*T*ph._U)) for ai in a], axis=0)
    return 2*float(np.sum(ph._Wt*k*absphi))

def intIII(a, x, T): # 2 prod G(a_i)^{a_i^2}
    a1 = max(a)
    logs = sum(ai**2 * math.log(ph.G(ai, x, a1, T)) for ai in a)
    return 2*math.exp(logs)

def normalize(v):
    v = np.array(v, float); return v/math.sqrt(np.sum(v*v))

def test_vectors():
    V = []
    # equal weights (the tight case), even and odd n
    for n in [2,3,4,5,6,8,10,16,25]:
        V.append(normalize(np.ones(n)))
    # two-point weights
    for n in [3,4,6,10]:
        for r in [1.5,2.0,3.0]:
            w = np.ones(n); w[0]=r; V.append(normalize(w))
    # tiny-atom example a=(2t+eps,t,t)
    for eps in [0.0,0.05,0.2]:
        V.append(normalize([2+eps,1,1]))
    # random
    rng = np.random.default_rng(0)
    for _ in range(25):
        n = rng.integers(2,10)
        V.append(normalize(rng.uniform(0.3,1.0,n)))
    return V

if __name__ == "__main__":
    worst = {k: (-1e9, None) for k in ['I-exact','II-I','III-II','IV-III','V-IV','VI-V(target)']}
    for a in test_vectors():
        a = np.sort(a)[::-1]
        a1 = float(a[0])
        if a1 > 1: a1 = 1.0
        T = math.pi/a1
        # test x in (0, a1/2]
        for xr in [0.001,0.05,0.1,0.2,0.3,0.4,0.49]:
            x = xr*a1
            exact = exact_abs_cdf(a, x)
            I  = intI(a,x,T); II = intII(a,x,T); III= intIII(a,x,T)
            IV = 2*max(ph.G(ai,x,a1,T) for ai in a)
            Vv = M_fast(x,a1,T)
            tgt = H(x)+H(a1)
            # each link should be <=0 (lower <= upper); record max (worst) violation
            checks = {
                'I-exact':   exact - I,     # Pr <= I
                'II-I':      I - II,        # I <= II
                'III-II':    II - III,      # II <= III
                'IV-III':    III - IV,      # III <= IV
                'V-IV':      IV - Vv,       # IV <= V
                'VI-V(target)': Vv - tgt,   # V <= target  (this is the actual (U) claim)
            }
            for key,val in checks.items():
                if val > worst[key][0]:
                    worst[key] = (val, f"n={len(a)},a1={a1:.3f},x/a1={xr}")
    print("Worst (most positive = violation) of each link over all test vectors, x in (0,a1/2]:")
    for key,(val,where) in worst.items():
        flag = "  <-- VIOLATION" if val > 1e-7 else ""
        print(f"  {key:16s}: {val:+.3e}  [{where}]{flag}")
    print("\n(All links <= ~0 means the chain Pr[|X|<=x] <= 2 sup_a G(a) <= H(x)+H(a1) holds.)")
