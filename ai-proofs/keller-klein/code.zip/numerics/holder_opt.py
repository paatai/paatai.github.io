"""Optimized-T Holder bound: how far past a1/2 does Holder reach with positive slack?

For any T>0 with Tx<=pi/2 the kernel k(u,-x,T)>=0, so
    Pr[|X|<=x] <= 2 sup_{a<=a1} G(a;x,a1,T),   G(a)=int_0^1 k(u,-x,T)|cos(aTu)|^{1/a^2}du.
We minimize the bound over T in (0, pi/(2x)] and scan x up to ~1.5 a1.
"""
import numpy as np, math
import prawitz_fast as pf
import prawitz_holder as ph

Phi = pf.Phi
def H(x): return 2*Phi(x)-1
ph._U, ph._Wt = ph._grid(800)

def bound_opt(x, a1, na=60, nT=30):
    Tmax = math.pi/(2*x)
    Ts = np.linspace(Tmax/nT, Tmax, nT)   # T in (0, pi/(2x)], so Tx<=pi/2 => k>=0
    agrid = np.linspace(a1/na, a1, na)
    best = math.inf; bestT = None
    for T in Ts:
        g = max(ph.G(a, x, a1, T) for a in agrid)
        if 2*g < best:
            best = 2*g; bestT = T
    return best, bestT

if __name__ == "__main__":
    for a1 in [0.02, 0.05, 0.1, 0.3, 0.6, 1.0]:
        print(f"a1={a1}:")
        xs = np.linspace(0.3*a1, 1.5*a1, 16)
        for x in xs:
            B, T = bound_opt(x, a1)
            tgt = H(x)+H(a1)
            m = tgt - B
            flag = " <-- FAIL" if m < -1e-9 else ""
            print(f"   x/a1={x/a1:.3f}: B={B:.6f} tgt={tgt:.6f} margin={m:+.3e} (Tx/pi={T*x/math.pi:.3f}){flag}")
