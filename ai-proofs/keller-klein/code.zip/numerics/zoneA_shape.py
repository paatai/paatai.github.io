"""Characterize the covering bound 2S(x)=2 sup_{a<=beta} G(a;x,pi/beta) across zone A x in [0, alpha/2].
Decide whether a single evaluation at x=alpha/2 suffices (2S(alpha/2)<=H(alpha)) or a march is needed."""
import math, sys
import numpy as np
from scipy.special import gamma, erf

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "numerics"))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "rigorous"))
from verify_block_U import twoS_float
from run_range_U import choose_beta, Ipi

def Hf(x): return erf(x / math.sqrt(2))   # H(x)=2Phi(x)-1 = erf(x/sqrt2)

for alpha in [0.2, 0.3, 0.4, 0.5, 0.7, 0.9]:
    beta = choose_beta(alpha, 1.0)
    T = math.pi / beta
    Ha = Hf(alpha)
    xA = alpha / 2
    xs = np.linspace(0, xA, 11)
    vals = [twoS_float(x, beta, T, K=12) for x in xs]
    s0 = vals[0]
    sA = vals[-1]
    smax = max(vals)
    print(f"alpha={alpha:.3f} beta={beta:.4f} (b/a={beta/alpha:.4f})  H(a)={Ha:.6f}  Ipi(b)={Ipi(beta):.6f}")
    print(f"   2S(0)={s0:.6f}  2S(xA)={sA:.6f}  max 2S={smax:.6f}   "
          f"margin@0={Ha-s0:+.2e} margin@xA={Ha-sA:+.2e} min margin={Ha-smax:+.2e}")
    # where is the max?
    im = int(np.argmax(vals))
    print(f"   argmax at x/xA={xs[im]/xA:.2f};  2S profile: " +
          " ".join(f"{v-s0:+.1e}" for v in vals))
