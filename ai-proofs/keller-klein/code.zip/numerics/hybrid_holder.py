"""Hybrid Holder/envelope bound to extend the (U) proof past x=a1/2.

With T=pi/a1 and x in (a1/2, a1), k(u,-x,T) is >=0 on [0,u0] and <0 on [u0,1] (u0 near 1).
    Pr[|X|<=x] <= 2 int_0^1 k phi_X du = 2( int_0^{u0} k phi_X + int_{u0}^1 k phi_X ).
On [0,u0] (k>=0): phi_X<=prod|cos|, Holder -> <= sup_{a<=a1} int_0^{u0} k |cos(aTu)|^{1/a^2} du.
On [u0,1] (k<=0): phi_X>=L_{a1}(Tu) (lower envelope, C3) -> k phi_X <= k L_{a1}(Tu).
So  Pr[|X|<=x] <= 2[ sup_a Gseg(a) + int_{u0}^1 k(u,-x,T) L_{a1}(Tu) du ].
"""
import numpy as np, math
from scipy.optimize import brentq
import prawitz_fast as pf
import prawitz_holder as ph

Phi = pf.Phi
def H(x): return 2*Phi(x)-1
ph._U, ph._Wt = ph._grid(1200)

def kpos(u,x,T):
    rho = (1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def u0_of(x,T):
    """sign-change: largest u in (0,1) where k=0 (k>0 below, <0 above). None if k>=0 on (0,1)."""
    f = lambda u: kpos(np.array([u]),x,T)[0]
    # k(1^-)=0^+; scan from near 1 downward for a sign change
    us = np.linspace(0.5,0.999,400)
    ks = kpos(us,x,T)
    idx = np.where(ks<0)[0]
    if len(idx)==0: return None
    # first u (smallest) where k<0 -> bracket with previous
    i = idx[0]
    if i==0: return us[0]
    return brentq(f, us[i-1], us[i])

def Lenv(v,a1):
    L,_ = pf.envelopes(np.atleast_1d(v), a1)
    return L

def seg_grid(u0):
    # Gauss-Legendre on [0,u0] and [u0,1]
    X,W = np.polynomial.legendre.leggauss(64)
    def seg(a,b,n):
        e = np.linspace(a,b,n+1); lo,hi=e[:-1,None],e[1:,None]
        u=(lo+hi)/2+(hi-lo)/2*X[None,:]; w=(hi-lo)/2*W[None,:]
        return u.ravel(),w.ravel()
    return seg(1e-9,u0,800), seg(u0,1-1e-9,400)

def hybrid_bound(x,a1,T,na=80):
    u0 = u0_of(x,T)
    if u0 is None:  # k>=0 everywhere: pure Holder
        agrid=np.linspace(a1/na,a1,na)
        return 2*max(ph.G(a,x,a1,T) for a in agrid)
    (uA,wA),(uB,wB) = seg_grid(u0)
    kA = kpos(uA,x,T); kB = kpos(uB,x,T)
    # Holder on [0,u0]
    agrid=np.linspace(a1/na,a1,na)
    Gseg = max(float(np.sum(wA*kA*np.abs(np.cos(a*T*uA))**(1.0/a**2))) for a in agrid)
    # envelope on [u0,1]
    LB = Lenv(T*uB,a1)
    seg2 = float(np.sum(wB*kB*LB))
    return 2*(Gseg+seg2)

if __name__ == "__main__":
    import kk_exact as kx
    print("=== hybrid bound vs target, and vs exact (equal weights) ===")
    for a1 in [0.02,0.05,0.1,0.2]:
        T=math.pi/a1
        print(f"a1={a1}:")
        for xr in [0.5,0.6,0.7,0.8,0.9,1.0,1.1,1.2]:
            x=xr*a1
            B=hybrid_bound(x,a1,T)
            tgt=H(x)+H(a1)
            m=tgt-B
            flag=" <-- FAIL" if m<-1e-9 else ""
            print(f"   x/a1={xr:.2f}: Bhyb={B:.6f} tgt={tgt:.6f} margin={m:+.3e}{flag}")
