"""Verify the HYBRID (U) bound against EXACT probabilities.

Unified bound (T=pi/a1), valid for ALL x>=0 and all weight vectors:
  Pr[|X|<=x] <= 2 int_0^1 k(u,-x,T) phi_X(Tu) du                                  (I)
            = 2[ int_{k>=0} k phi_X + int_{k<0} k phi_X ]
           <= 2[ int_{k>=0} k prod|cos(a_i Tu)| + int_{k<0} k phi_X ]             (II: phi<=|phi| where k>=0)
           <= 2[ prod_i(int_{k>=0} k|cos(a_i Tu)|^{1/a_i^2})^{a_i^2} + int_{k<0} k phi_X ]  (III: Holder on k>=0)
           <= 2[ prod_i(...)^{a_i^2} + int_{k<0} k L_{a1}(Tu) ]                    (IV: phi_X>=L on k<0, k<0)
           <= 2[ sup_{a<=a1} int_{k>=0} k|cos(aTu)|^{1/a^2} + int_{k<0} k L_{a1} ] = Bhyb   (V)
           <= H(x)+H(a1)                                                          (VI: target)
We check every link against exact atoms, over x in (a1/2, 1.3 a1) (where k has a sign change).
"""
import numpy as np, math
import prawitz_fast as pf
import prawitz_holder as ph
import kk_exact as kx

Phi = pf.Phi
def H(x): return 2*Phi(x)-1
U, Wt = ph._grid(1500)

def kpos(u,x,T):
    rho=(1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def exact_abs_cdf(a,x):
    atoms,masses,_=kx.abs_atoms(a)
    return float(np.sum(masses[atoms<=x+1e-13]))

def normalize(v):
    v=np.array(v,float); return v/math.sqrt(np.sum(v*v))

def links(a,x,T):
    a=np.sort(a)[::-1]; a1=float(a[0])
    k=kpos(U,x,T)
    kp=np.maximum(k,0.0); kn=np.minimum(k,0.0)   # k>=0 and k<0 parts
    phiX=np.prod([np.cos(ai*T*U) for ai in a],axis=0)
    absphi=np.prod([np.abs(np.cos(ai*T*U)) for ai in a],axis=0)
    L,_=pf.envelopes(T*U,a1)
    I   = 2*float(np.sum(Wt*k*phiX))
    II  = 2*float(np.sum(Wt*(kp*absphi + kn*phiX)))
    # Holder on k>=0 part
    logs=sum(ai**2*math.log(max(np.sum(Wt*kp*np.abs(np.cos(ai*T*U))**(1.0/ai**2)),1e-300)) for ai in a)
    III = 2*(math.exp(logs) + float(np.sum(Wt*kn*phiX)))
    IV  = 2*(math.exp(logs) + float(np.sum(Wt*kn*L)))
    # Bhyb: sup over a of the k>=0 Holder integral
    agrid=np.linspace(a1/60,a1,60)
    supG=max(float(np.sum(Wt*kp*np.abs(np.cos(av*T*U))**(1.0/av**2))) for av in agrid)
    V   = 2*(supG + float(np.sum(Wt*kn*L)))
    return I,II,III,IV,V

def test_vectors():
    V=[]
    for n in [2,3,4,5,6,8,10,16,25]: V.append(normalize(np.ones(n)))
    for n in [3,4,6,10]:
        for r in [1.5,2.0,3.0]:
            w=np.ones(n); w[0]=r; V.append(normalize(w))
    for eps in [0.0,0.05,0.2]: V.append(normalize([2+eps,1,1]))
    rng=np.random.default_rng(1)
    for _ in range(30):
        n=rng.integers(2,10); V.append(normalize(rng.uniform(0.3,1.0,n)))
    return V

if __name__=="__main__":
    worst={k:(-1e9,None) for k in ['I-exact','II-I','III-II','IV-III','V-IV','VI-V(target)']}
    for a in test_vectors():
        a=np.sort(a)[::-1]; a1=float(a[0])
        if a1>1: a1=1.0
        T=math.pi/a1
        for xr in [0.55,0.65,0.75,0.85,0.95,1.05,1.2,1.3]:
            x=xr*a1
            exact=exact_abs_cdf(a,x)
            I,II,III,IV,Vv=links(a,x,T)
            tgt=H(x)+H(a1)
            checks={'I-exact':exact-I,'II-I':I-II,'III-II':II-III,'IV-III':III-IV,
                    'V-IV':IV-Vv,'VI-V(target)':Vv-tgt}
            for key,val in checks.items():
                if val>worst[key][0]: worst[key]=(val,f"n={len(a)},a1={a1:.3f},x/a1={xr}")
    print("Worst (most positive=violation) of each HYBRID link, x in (a1/2,1.3a1]:")
    for key,(val,where) in worst.items():
        flag="  <-- VIOLATION" if val>1e-6 else ""
        print(f"  {key:16s}: {val:+.3e}  [{where}]{flag}")
