"""Margin profile m(x) = c(a1) - min_tau B(x; a1, tau/a1) (floating point, non-rigorous).

Reports the smallest margin beyond the C6 strip and the margins near integer xi = x/a1.
"""
import sys, math
import numpy as np
from prawitz_fast import best_over_T, c, Phi

def eta(a):
    return max(3.0 ** -k * (1 - 4.0 ** -k / a ** 2) for k in range(1, 40))

def phi(x):
    return math.exp(-x * x / 2) / math.sqrt(2 * math.pi)

def profile(a1, nsub=800, ntau=121):
    ca = float(c(a1))
    xstart = a1 + eta(a1) / (2 * phi(a1))
    xend = math.sqrt(-2 * math.log(ca))
    xs = np.concatenate([np.linspace(xstart, min(xend, 12 * a1), 1500),
                         np.linspace(min(xend, 12 * a1), xend, 300)])
    taus = math.pi * np.linspace(0.80, 1.10, ntau)
    b, arg = best_over_T(xs, a1, taus, nsub=nsub)
    m = ca - b
    i = int(np.argmin(m))
    print(f"a1={a1}: c={ca:.6g} xstart={xstart:.5f} (xi={xstart/a1:.4f}) xend={xend:.3f}")
    print(f"   min margin {m[i]:.3e} at x={xs[i]:.5f} xi={xs[i]/a1:.3f} tau/pi={arg[i]/math.pi:.4f}; rel {m[i]/ca:.2e}")
    for j in range(1, 13):
        sel = np.abs(xs / a1 - j) < 0.5
        if sel.any():
            k = np.argmin(np.where(sel, m, np.inf))
            print(f"   xi in [{j-0.5},{j+0.5}]: min margin {m[k]:.3e} at xi={xs[k]/a1:.3f}, tau/pi={arg[k]/math.pi:.4f}, m/a^3={m[k]/a1**3:.4f}")
    return xs, m, arg

if __name__ == "__main__":
    for a in [float(s) for s in sys.argv[1:]] or [0.1, 0.2, 0.3]:
        profile(a)
