"""Rigorous-style (U) combo, NO sup over a:
   x in (0, xH], xH<0.46 a1 (mono-clean): Holder bound 2G(a1)=2 int k(u,-x,pi/a1)|cos(pi u)|^{1/a1^2}du
   x in [xH, xtriv]: envelope bound 2 min_T J(-x; a1, T)
   x >= xtriv: trivial 1
Find min a1 where all margins>0, and verify mono holds for x<=xH.
"""
import numpy as np, math, sys
from scipy.special import erfinv
import prawitz_fast as pf
import prawitz_upper as pu
import prawitz_holder as ph
Phi=pf.Phi
def H(x): return 2*Phi(x)-1
U,Wt=ph._grid(2500)
TAUS=np.pi*np.concatenate([np.linspace(0.3,2.0,80),np.linspace(2.0,8.0,60)])

def kf(u,x,T):
    rho=(1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def BH(x,a1):
    T=math.pi/a1
    k=kf(U,x,T)
    return 2*float(np.sum(Wt*k*np.abs(np.cos(np.pi*U))**(1.0/a1**2)))   # =2G(a1); k>=0 for x<=a1/2

def mono_ok(x,a1,na=50):
    T=math.pi/a1
    kp=np.maximum(kf(U,x,T),0.0)
    Ga1=float(np.sum(Wt*kp*np.abs(np.cos(a1*T*U))**(1.0/a1**2)))
    for a in np.linspace(a1/na,a1,na):
        g=float(np.sum(Wt*kp*np.abs(np.cos(a*T*U))**(1.0/a**2)))
        if g-Ga1>1e-9: return False
    return True

if __name__=="__main__":
    xHfrac=float(sys.argv[1]) if len(sys.argv)>1 else 0.4
    print(f"xH = {xHfrac} a1")
    for a1 in [0.04,0.045,0.05,0.055,0.06,0.07,0.08,0.1,0.15,0.3,0.6,1.0]:
        xH=xHfrac*a1
        xtriv=math.sqrt(2)*erfinv(1-H(a1))
        # Holder region
        wH=math.inf; mono_bad=False
        for x in np.linspace(0.01*a1,xH,30):
            m=H(x)+H(a1)-BH(x,a1)
            if m<wH: wH=m
            if not mono_ok(x,a1): mono_bad=True
        # envelope region
        xs=np.linspace(xH,min(xtriv,3.5),200)
        BE,_=pu.best_BU_over_T(xs,a1,TAUS,nsub=500)
        wE=min(H(xs[i])+H(a1)-min(1.0,BE[i]) for i in range(len(xs)))
        ok = wH>0 and wE>0 and not mono_bad
        print(f"  a1={a1:.3f}: Holder worst m={wH:+.2e}, envelope worst m={wE:+.2e}, mono_clean(x<=xH)={not mono_bad}  {'OK' if ok else 'XX'}")
