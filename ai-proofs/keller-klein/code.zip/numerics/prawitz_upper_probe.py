"""Probe the near-0 gap of the Prawitz (U) upper bound: can a wider T close it?
Also measure the gap width x_*(a1): the largest x where min_T BU(x) > H(x)+H(a1)."""
import numpy as np, math
import prawitz_fast as pf
from prawitz_upper import BU_many_x, H

def min_BU(x, a1, taus, nsub=800):
    xs = np.array([x])
    best = np.inf; argt = 0
    for tau in taus:
        b = BU_many_x(xs, a1, tau / a1, nsub=nsub)[0]
        if b < best:
            best = b; argt = tau
    return best, argt

# Wide tau grid including large T (more Fourier info)
taus = np.pi * np.concatenate([np.linspace(0.3, 2.0, 50), np.linspace(2.1, 8.0, 60)])

print("== x=0 overshoot vs T range ==")
for a1 in [0.05, 0.1, 0.3, 0.5, 0.7, 1.0]:
    b0, t0 = min_BU(0.0, a1, taus)
    ha = H(a1)
    print(f"a1={a1:.2f}: min_T BU(0)={b0:.6f}, H(a1)={ha:.6f}, overshoot={b0-ha:+.6f}, best tau/pi={t0/math.pi:.3f}")

print("\n== gap width x_*(a1): largest x with min_T BU(x) > H(x)+H(a1) ==")
for a1 in [0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0]:
    xs = np.linspace(0, 0.4 * max(a1, 0.3), 400)[1:]  # skip x=0 (handled by C11)
    worst_x = 0.0
    for x in xs:
        b, _ = min_BU(x, a1, taus)
        if b > H(x) + H(a1) + 1e-12:
            worst_x = x
    print(f"a1={a1:.2f}: x_* ~ {worst_x:.5f} (x_*/a1={worst_x/a1:.4f})")
