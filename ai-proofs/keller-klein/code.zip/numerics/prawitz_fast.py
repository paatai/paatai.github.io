"""Fast (non-rigorous) vectorized evaluation of the pointwise-optimal Prawitz bound

  P(Z<x) - P(X<x) <= B(x;a1,T) = Phi(x) - 1/2 + int_0^1 max(k L(Tu), k U(Tu)) du

L <= phi_X <= U are pointwise envelopes depending only on a1 = max a_i:
  a1 v <= pi/2        : L = cos(a1 v)^(1/a1^2),     U = exp(-v^2/2)
  pi/2 < a1 v <= theta: L = -|cos(a1 v)| exp(-(1-a1^2) v^2/2), U = exp(-v^2/2)
  theta < a1 v <= pi  : L = -|cos(a1 v)|^(1/a1^2),   U = +|cos(a1 v)|^(1/a1^2)
  a1 v > pi           : L = -1, U = 1
(option 'kk' uses L=-exp(-v^2/2) on the second range, as in Keller-Klein.)
"""
import numpy as np, math
from scipy.special import erf
from scipy.optimize import brentq

THETA = brentq(lambda y: math.exp(-y * y / 2) + math.cos(y), 1.5, 2.5)
_GL_X, _GL_W = np.polynomial.legendre.leggauss(12)


def Phi(x):
    return 0.5 * (1 + erf(np.asarray(x) / math.sqrt(2)))


def c(a1):
    return Phi(a1) - 0.5


def envelopes(v, a1, variant='improved'):
    av = a1 * v
    g = np.exp(-v * v / 2)
    p = 1.0 / a1 ** 2
    ca = np.cos(av)
    L = np.empty_like(v)
    U = np.empty_like(v)
    r1 = av <= math.pi / 2
    r2 = (av > math.pi / 2) & (av <= THETA)
    r3 = (av > THETA) & (av <= math.pi)
    r4 = av > math.pi
    L[r1] = np.power(np.maximum(ca[r1], 0), p)
    U[r1] = g[r1]
    if variant == 'kk':
        L[r2] = -g[r2]
    else:
        L[r2] = -np.abs(ca[r2]) * np.exp(-(1 - a1 * a1) * v[r2] ** 2 / 2)
    U[r2] = g[r2]
    e3 = np.power(np.abs(ca[r3]), p)
    L[r3] = -e3
    U[r3] = e3
    L[r4] = -1.0
    U[r4] = 1.0
    return L, U


def nodes(T, a1, nsub=400):
    """Gauss-Legendre nodes on [0,1], subdivided, with breakpoints."""
    bps = [0.0, 1.0]
    for b in [math.pi / 2, THETA, math.pi]:
        ub = b / (a1 * T)
        if 0 < ub < 1:
            bps.append(ub)
    bps = sorted(bps)
    us, ws = [], []
    for lo, hi in zip(bps[:-1], bps[1:]):
        m = max(2, int(nsub * (hi - lo)))
        edges = np.linspace(lo, hi, m + 1)
        a, b = edges[:-1, None], edges[1:, None]
        u = (a + b) / 2 + (b - a) / 2 * _GL_X[None, :]
        w = (b - a) / 2 * _GL_W[None, :]
        us.append(u.ravel())
        ws.append(w.ravel())
    return np.concatenate(us), np.concatenate(ws)


def kfun(u, x, T):
    return (1 - u) * np.cos(T * u * x) - ((1 - u) / np.tan(np.pi * u) + 1 / np.pi) * np.sin(T * u * x)


def B(x, a1, T, variant='improved', nsub=400):
    u, w = nodes(T, a1, nsub)
    L, U = envelopes(T * u, a1, variant)
    k = kfun(u, x, T)
    return float(Phi(x) - 0.5 + np.sum(w * np.maximum(k * L, k * U)))


def B_many_x(xs, a1, T, variant='improved', nsub=400):
    u, w = nodes(T, a1, nsub)
    L, U = envelopes(T * u, a1, variant)
    xs = np.asarray(xs)[:, None]
    k = kfun(u[None, :], xs, T)
    return Phi(xs[:, 0]) - 0.5 + np.sum(w[None, :] * np.maximum(k * L[None, :], k * U[None, :]), axis=1)


def best_over_T(xs, a1, taus, variant='improved', nsub=400):
    """min over T = tau/a1 of B(x); returns (minB, argmin tau) arrays."""
    best = np.full(len(xs), np.inf)
    arg = np.zeros(len(xs))
    for tau in taus:
        b = B_many_x(xs, a1, tau / a1, variant, nsub)
        m = b < best
        best[m] = b[m]
        arg[m] = tau
    return best, arg
