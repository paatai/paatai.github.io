"""Floating-point sanity check of the explicit small-a1 bound for the Prawitz bound at T = pi/a.

F(x,a) := B(x; a, pi/a) - c(a) (envelopes at a = a1).  Claimed upper bound (notes/small_a.md):
  F <= aphi(x) - c(a) + (a^2/pi^2) x D(x) + (a^2/3) x phi(x) - (a^3/(3 pi^2)) N(x)
       + D1bound(xi,a) + 0.079577 (xi-0.28823)^2 a^4 + 0.042912 (xi-1) a^4 + 0.014147 a^4
with xi = x/a, D(x) = int_0^inf sin(sx) e^{-s^2/2} ds, M = 1 - xD, N = D + xM, and
  D1bound = 0.099736(xi-1)a^3 + 0.067547a^4 + 0.19325(xi-1)a^5 + 0.15705a^6
            + (xi^2/2 + 0.406 xi)(0.49868 a^5 + 1.35273 a^7).
Also prints the individual pieces (Gaussian part, envelope loss D1, aliasing A1) against their bounds.
"""
import math, sys
import numpy as np
from scipy.special import dawsn, erf
from scipy.integrate import quad

sys.path.insert(0, "/workspace/numerics")
from prawitz_fast import envelopes, kfun, THETA

PHI0 = 1 / math.sqrt(2 * math.pi)


def phi(x):
    return math.exp(-x * x / 2) * PHI0


def Phi(x):
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))


def c(a):
    return Phi(a) - 0.5


def Dfun(x):
    return math.sqrt(2) * dawsn(x / math.sqrt(2))


def Mfun(x):
    return 1 - x * Dfun(x)


def Nfun(x):
    return Dfun(x) + x * Mfun(x)


_GX, _GW = np.polynomial.legendre.leggauss(20)


def integrate(f, lo, hi, n):
    e = np.linspace(lo, hi, n + 1)
    a, b = e[:-1, None], e[1:, None]
    u = ((a + b) / 2 + (b - a) / 2 * _GX[None, :]).ravel()
    w = ((b - a) / 2 * _GW[None, :]).ravel()
    return float(np.sum(w * f(u)))


def pieces(x, a, n=4000):
    T = math.pi / a
    p = 1 / a ** 2
    k = lambda u: kfun(u, x, T)
    # Gaussian part over [0,1]
    E = integrate(lambda u: k(u) * np.exp(-(T * u) ** 2 / 2), 1e-12, 1.0, n)
    # region 1 envelope loss
    def d1(u):
        kk = k(u)
        W = np.exp(-(T * u) ** 2 / 2) - np.power(np.maximum(np.cos(math.pi * u), 0), p)
        return np.maximum(-kk, 0) * W
    D1 = integrate(d1, 1e-12, 0.5, n)
    def d2(u):
        kk = k(u)
        v = T * u
        W = np.exp(-v * v / 2) + np.abs(np.cos(math.pi * u)) * np.exp(-(1 - a * a) * v * v / 2)
        return np.maximum(-kk, 0) * W
    D2 = integrate(d2, 0.5, THETA / math.pi, max(50, n // 10))
    def a1(u):
        return np.abs(k(u)) * np.power(np.abs(np.cos(math.pi * u)), p) - k(u) * np.exp(-(T * u) ** 2 / 2)
    A1 = integrate(a1, THETA / math.pi, 1.0 - 1e-12, n)
    return E, D1, D2, A1


def F_true(x, a, n=4000):
    E, D1, D2, A1 = pieces(x, a, n)
    return Phi(x) - 0.5 + E + D1 + D2 + A1 - c(a)


def gauss_formula(x, a):
    return a * phi(x) - (a * a / math.pi ** 2) * Mfun(x) + (a * a / 3) * x * phi(x) - (a ** 3 / (3 * math.pi ** 2)) * Nfun(x)


PHI0_ = 1 / math.sqrt(2 * math.pi)
KG = 0.0323
CRHO = 2.09
XI0 = 0.5 - CRHO / math.pi ** 2


def D1bound(xi, a):
    return (PHI0_ / 4 * (xi - 1) * a ** 3 + 2 / (3 * math.pi ** 2) * a ** 4 + 15 * PHI0_ * KG * (xi - 1) * a ** 5
            + 48 * KG / math.pi ** 2 * a ** 6 + (xi * xi / 2 + xi / 3) * (1.25 * PHI0_ * a ** 5 + 105 * PHI0_ * KG * a ** 7))


def A1bound(xi, a):
    return (a * a / math.pi ** 2) * abs(math.cos(math.pi * xi)) + 0.126987 * (xi - 0.28823) * abs(math.sin(math.pi * xi)) * a ** 3 \
        + 0.042912 * (xi - 1) * a ** 4


def F_bound(x, a):
    xi = x / a
    return (a * phi(x) - c(a) + (a * a / math.pi ** 2) * x * Dfun(x) + (a * a / 3) * x * phi(x)
            - (a ** 3 / (3 * math.pi ** 2)) * Nfun(x) + D1bound(xi, a) + PHI0_ ** 2 / 2 * (xi - XI0) ** 2 * a ** 4
            + 2 * CRHO / math.pi ** 4 * (xi - 1) * a ** 4 + 0.01415 * a ** 4)


if __name__ == "__main__":
    # check D formula
    for x in [0.3, 1.0, 2.5]:
        v, _ = quad(lambda s: math.sin(s * x) * math.exp(-s * s / 2), 0, 40, limit=400)
        print("D check", x, v, Dfun(x))
    for a in [0.05, 0.03, 0.02]:
        print(f"\n=== a = {a}")
        worst_ratio = -1e9
        for xi in [1.2, 1.5, 1.8, 2.0, 2.2, 2.5, 3.0, 3.5, 4.0, 5.0, 7.0, 10.0, 15.0, 20.0, 30.0, 0.5 / a, 1.0 / a, 2.0 / a]:
            x = xi * a
            E, D1, D2, A1 = pieces(x, a)
            Ft = Phi(x) - 0.5 + E + D1 + D2 + A1 - c(a)
            Fb = F_bound(x, a)
            g_num = Phi(x) - 0.5 + E
            g_for = gauss_formula(x, a)
            print(f"xi={xi:7.3f} F={Ft: .4e} Fbound={Fb: .4e} ok={Ft<=Fb} | gauss num-formula={g_num-g_for: .2e} "
                  f"(<= {0.014147*a**4:.1e}) | D1={D1:.4e} <= {D1bound(xi,a):.4e} | A1={A1:.4e} <= {A1bound(xi,a):.4e} | D2={D2:.1e}"
                  f" | F/a^3={Ft/a**3: .4f} Fb/a^3={Fb/a**3: .4f}")
