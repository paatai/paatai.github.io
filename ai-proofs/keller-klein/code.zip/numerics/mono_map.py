"""Map where monotonicity  G(a) <= G(a1) for a in (0,a1]  holds vs fails, over (a1, x/a1).
G(a)=int_0^1 k_+(u,-x,pi/a1)|cos(a pi u/a1)|^{1/a^2}du.  Also report, where it fails,
whether x<=a1/2 (pure-Holder region) or x>a1/2.
"""
import numpy as np, math
import prawitz_fast as pf
import prawitz_holder as ph
Phi=pf.Phi
def H(x): return 2*Phi(x)-1
U,Wt=ph._grid(2000)

def kf(u,x,T):
    rho=(1-u)/np.tan(np.pi*u)+1/np.pi
    return (1-u)*np.cos(T*u*x)+rho*np.sin(T*u*x)

def mono_viol(x,a1,T,na=60):
    kp=np.maximum(kf(U,x,T),0.0)
    Ga1=float(np.sum(Wt*kp*np.abs(np.cos(a1*T*U))**(1.0/a1**2)))
    mv=-1e9; amax=a1
    for a in np.linspace(a1/na,a1,na):
        g=float(np.sum(Wt*kp*np.abs(np.cos(a*T*U))**(1.0/a**2)))
        if g-Ga1>mv: mv=g-Ga1; amax=a
    return mv, amax/a1

if __name__=="__main__":
    print("a1 : (x/a1 where mono fails, with viol>1e-7) ; worst viol overall; also note x<=0.5 region")
    for a1 in [0.05,0.1,0.2,0.3,0.4,0.5,0.6,0.7,0.8,0.9,1.0]:
        T=math.pi/a1
        fails=[]; worst=-1e9; worst_xr=None; worst_amax=None
        fail_below_half=False
        for xr in np.linspace(0.02,1.2,60):
            x=xr*a1
            mv,ar=mono_viol(x,a1,T)
            if mv>worst: worst=mv; worst_xr=xr; worst_amax=ar
            if mv>1e-7:
                fails.append(xr)
                if xr<=0.5: fail_below_half=True
        if fails:
            rng=f"x/a1 in [{min(fails):.2f},{max(fails):.2f}]"
        else:
            rng="none"
        print(f"a1={a1:.2f}: fails {rng}; worst viol={worst:+.2e} at x/a1={worst_xr:.2f},a*/a1={worst_amax:.2f}; "
              f"fail with x<=a1/2? {fail_below_half}")
