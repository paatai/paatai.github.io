"""Dense floating-point check that F(x,a) <= F_bound(x,a) (small_a_bound.py) and that F_bound <= 0 on
[1.8a, x_e(a)], for several a.  Not rigorous; the rigorous statement is proved analytically."""
import math, sys
import numpy as np
from multiprocessing import Pool

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "numerics"))
from small_a_bound import F_true, F_bound, c


def job(args):
    a, x = args
    return a, x, F_true(x, a, n=3000), F_bound(x, a)


if __name__ == "__main__":
    tasks = []
    for a in [0.1, 0.07, 0.05, 0.03, 0.02, 0.01]:
        xe = math.sqrt(2 * math.log(1 / c(a)))
        xis = list(np.arange(1.0, 12.0, 0.01)) + list(np.linspace(12.0, xe / a, 300))
        tasks += [(a, xi * a) for xi in xis]
    worst = {}
    viol = 0
    with Pool(8) as p:
        for a, x, ft, fb in p.imap_unordered(job, tasks, chunksize=20):
            if ft > fb:
                viol += 1
                print("VIOLATION F>Fbound", a, x / a, ft, fb, flush=True)
            if x >= 1.8 * a:
                w = worst.get(a, (-1e9, None))
                if fb / a ** 3 > w[0]:
                    worst[a] = (fb / a ** 3, x / a)
    print("violations:", viol, "of", len(tasks))
    for a in sorted(worst):
        print(f"a={a}: max Fbound/a^3 on [1.8a, x_e] = {worst[a][0]:.4f} at xi={worst[a][1]:.3f}")
