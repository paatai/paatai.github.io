"""Explore sup_{a<=a1} G(a;x) to gauge rigorous-covering feasibility for the (U) Holder zone.
G(a;x) = int_0^1 k(u,-x,pi/a1) |cos(a pi u/a1)|^{1/a^2} du,  k>=0 for x<=a1/2.
We report:
  - shape of G(a)/G(a1) across a in (0,a1]
  - S=sup_a G(a), argmax, S-G(a1)
  - margin of (*) using honest sup:  H(x)+H(a1) - 2 G(a1)^{a1^2} S^{1-a1^2}
  - margin using 2S:                  H(x)+H(a1) - 2 S
  - margin using 2 G(a1):             H(x)+H(a1) - 2 G(a1)
"""
import numpy as np, math
import prawitz_fast as pf
import prawitz_holder as ph
Phi = pf.Phi
def H(x): return 2*Phi(x)-1
U, Wt = ph._grid(3000)

def kf(u, x, T):
    rho = (1-u)/np.tan(np.pi*u) + 1/np.pi
    return (1-u)*np.cos(T*u*x) + rho*np.sin(T*u*x)

def G(a, x, a1):
    T = math.pi/a1
    k = kf(U, x, T)
    return float(np.sum(Wt*k*np.abs(np.cos(a*T*U))**(1.0/a**2)))

if __name__ == "__main__":
    for a1 in [1.0, 0.7, 0.5, 0.3, 0.2, 0.1, 0.055]:
        print(f"\n===== a1={a1:.3f}  (margin at x=0 ~ H(a1)-2G(a1;0)) =====")
        for xr in [0.0, 0.1, 0.25, 0.4, 0.5]:
            x = xr*a1
            na = 400
            agrid = np.linspace(a1/na, a1, na)
            gs = np.array([G(a, x, a1) for a in agrid])
            Ga1 = gs[-1]
            i = int(np.argmax(gs))
            S = gs[i]; amax = agrid[i]
            tgt = H(x) + H(a1)
            m_hon = tgt - 2*Ga1**(a1**2)*S**(1-a1**2)
            m_2S = tgt - 2*S
            m_2G = tgt - 2*Ga1
            # how far below a1 does G stay within, say, 0.1% of Ga1?
            near = agrid[gs >= Ga1*0.999]
            frac_near = near.min()/a1 if len(near) else 1.0
            print(f"  x/a1={xr:.2f}: argmax a/a1={amax/a1:.3f}  S/G(a1)={S/Ga1:.5f}  "
                  f"S-G(a1)={S-Ga1:+.2e}")
            print(f"          margin: honest={m_hon:+.3e}  2S={m_2S:+.3e}  2G(a1)={m_2G:+.3e}  "
                  f"(G within .1% for a/a1>={frac_near:.3f})")
