"""Try to break the pointwise Prawitz bound and the C-part inequality.

For random weight vectors (various a1), compare the exact Phi(x) - P(X<x) with B(x; a, T) for
a = a1 and random T, x; and the exact P(|X|<x) with the C-part lower bound -(2/3) J(2b; a, S),
b in [a1, x).  Any violation would indicate an error in C2-C4 or in the C-part argument.
"""
import math, random
import numpy as np
from scipy.special import erf
from kk_exact import abs_atoms  # exact distribution of |X|
from prawitz_fast import B as Bf, Phi

rng = random.Random(1)


def P_abs_less(vals, probs, x):
    return float(np.sum(probs[vals < x - 1e-12]))


def main(trials=400):
    worst_P, worst_C = -1e9, -1e9
    for t in range(trials):
        n = rng.randint(2, 16)
        w = np.array(sorted([rng.random() ** rng.choice([0.3, 1, 3]) for _ in range(n)], reverse=True))
        w /= np.linalg.norm(w)
        a1 = float(w[0])
        vals, probs, _ = abs_atoms(w)
        for _ in range(30):
            x = a1 * (1 + 4 * rng.random()) if rng.random() < 0.7 else rng.random() * 3
            T = (0.5 + 1.0 * rng.random()) * math.pi / a1
            dev = float(Phi(x)) - (0.5 + 0.5 * P_abs_less(vals, probs, x))
            b = Bf(x, a1, T, nsub=600)
            worst_P = max(worst_P, dev - b)
            # C-part: for b0 in [a1, x): P(|X|<x) >= -(2/3) J(2 b0)
            if x > a1:
                b0 = a1 + (x - a1) * rng.random()
                S = (0.7 + 0.5 * rng.random()) * math.pi / a1
                J = Bf(2 * b0, a1, S, nsub=600) - (float(Phi(2 * b0)) - 0.5)
                lhs = P_abs_less(vals, probs, x)
                worst_C = max(worst_C, -(2 / 3) * J - lhs)
    print(f"max over trials of [true deviation - B]   = {worst_P:.3e}  (must be <= 0)")
    print(f"max over trials of [C-part bound - P(|X|<x)] = {worst_C:.3e}  (must be <= 0)")


if __name__ == "__main__":
    main()
