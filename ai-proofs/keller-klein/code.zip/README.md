# Code for the Keller–Klein paper (`keller-klein.pdf`)

Two directories; run every command from the directory named in its heading.

* `rigorous/`: the computer-assisted part of the proof. Ball arithmetic (Arb via `python-flint` 0.9.0);
  each certificate is a list of blocks of values of a_1, re-checked by an independent checker.
  See `rigorous/README.md` for the lower half (L).
* `numerics/`: floating-point exploration and sanity checks. Not part of any proof.

Requirements: Python 3, `pip install python-flint==0.9.0 numpy scipy`.

## rigorous/: lower half (L)

| script | what it verifies |
| --- | --- |
| `prawitz_arb.py` | certified upper bound for the Prawitz integral J(x; a, T) and the constants theta, Phi, c |
| `verify_block.py` | inequality (L) for every a_1 in one block [alpha, beta] |
| `run_range.py` | covers a range of a_1 by blocks and writes `results/<tag>_summary.txt` and `results/<tag>_cert.jsonl.gz` |
| `check_cert.py` | independent re-check of a stored (L) certificate, at any precision |
| `small_a_check.py` | the numerical facts used in the analytic proof of (L) for a_1 <= 0.1; prints `ALL CHECKS PASSED` |

## rigorous/: upper half (U)

| script | what it verifies |
| --- | --- |
| `prawitz_U.py`, `prawitz_U_fast.py` | certified upper bounds for the Prawitz UPPER integral (zone A Hoelder pieces, zone B envelope) |
| `verify_block_U.py` | inequality (U) for every a_1 in one block [alpha, beta] |
| `run_range_U.py` | covers a range of a_1 by (U) blocks in parallel and writes a certificate |
| `concat_certs.py`, `fix_bottom_block.py` | join stage certificates; move the bottom block one ulp below the stored double 0.07 |
| `check_cert_U.py` | independent re-check of a (U) certificate, with exact-rational coverage of [A0, A1] |
| `exact_coverage_U.py` | exact-rational coverage of a (U) certificate, including a_1 = 1/10 and every stage join |
| `add_nodes_U.py`, `verify_nodes_U.py` | add the zone-A Hoelder partition nodes to each block record, and check them independently |
| `safe_cross_check_U.py` | cell-level cross-check of sampled zone-A inequalities with a looser, simpler bound |
| `run_007_1_pipeline.sh` | the sequence that produced `results/U_007_1_cert.jsonl.gz` from the stage certificates |
| `probe_floor_U.py`, `diag_cell.py`, `diag_zoneB.py` | diagnostics used while choosing parameters (not part of the proof) |

`results/` holds the certificates (`*_cert.jsonl.gz`) and the outputs of the runs and re-checks.

## Quick checks

```bash
cd rigorous
python3 small_a_check.py                                             # analytic part: ALL CHECKS PASSED
python3 check_cert.py results/L_005_1_cert.jsonl.gz 0.05 1.0 96 8    # (L) on [0.05, 1]
python3 exact_coverage_U.py results/U_007_1_cert.jsonl.gz 0.07 1.0   # (U): exact coverage of [0.07, 1]
python3 check_cert_U.py results/U_007_1_cert.jsonl.gz 0.07 1.0 96 8  # (U) re-check of [0.07, 1] (hours on 8 cores)
python3 verify_nodes_U.py results/U_007_1_cert.jsonl.gz results/U_007_1_cert_nodes.jsonl.gz
```

To regenerate the (L) certificate: `python3 run_range.py 0.05 1.0 0.6 0.02 8 L_005_1` (about 5 minutes on 8 cores).
