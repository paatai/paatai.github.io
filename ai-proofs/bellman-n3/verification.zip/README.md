# An explicit Bellman function for disjoint partitions: the sharp logarithmic gain for three families

Research paper by Paata Ivanisvili (Department of Mathematics, University of California, Irvine): `bellman_n3.pdf`, with
source `bellman_n3.tex`, together with the code that verifies it.

For finite families $\mathcal F_1,\mathcal F_2,\mathcal F_3$ of subsets of $[m]$, let $N$ be the number of
partitions $[m]=T_1\sqcup T_2\sqcup T_3$ with $T_j\in\mathcal F_j$. Any $B$ satisfying the *main inequality*

$$B(x_0+x_1,\,y_0+y_1,\,z_0+z_1)\ \ge\ B(x_1,y_0,z_0)+B(x_0,y_1,z_0)+B(x_0,y_0,z_1)\qquad(x_i,y_i,z_i\ge0),$$

with $B=0$ when $\min\{x,y,z\}<1$ and $B(1,1,1)\ge1$, gives $N\le B(|\mathcal F_1|,|\mathcal F_2|,|\mathcal F_3|)$, and hence
$N_3(X)\le B(|X|,|X|,|X|)$. The classical choice is $B=(xyz)^c$ with $3c=c(3)=\ln27/\ln(27/4)$ (Kane–Tao, Ivanisvili).

This project finds and proves the closed form

$$B(x,y,z)=(xyz)^c\Bigl(\frac GM\Bigr)^{\kappa}\Bigl(1+\frac{\ln(xyz)}{2000}\Bigr)^{-\gamma},\qquad
G=(xyz)^{1/3},\quad M=\Bigl(\frac{x^t+y^t+z^t}3\Bigr)^{1/t},\quad t=\frac\alpha{\ln(xyz)},$$

where $\lambda=\ln2$, $\mu=\ln\frac{27}4$, $\gamma=\frac{\ln(27/16)}{2\mu}$,
$\alpha=\frac{3\mu}{2\lambda}\bigl(\frac9\lambda-1-\frac1\gamma\bigr)$ and $\kappa=\frac{9\gamma\mu}{\lambda^2\alpha}$. On the
diagonal this gives

$$B(x,x,x)=\frac{x^{3c}}{(1+\frac3{2000}\ln x)^{\gamma}}\le 2.44\,\frac{x^{3c}}{(1+\ln x)^{\gamma}},$$

which is the sharp bound $N_3(X)\lesssim|X|^{c(3)}(1+\ln|X|)^{-\gamma_3}$. The theorem holds for every shift
$A\in[2000,\infty]$ in place of $2000$. Numerically, the smallest admissible shift is $A_*\approx29.05$.

## Contents

| Path | What it is |
| --- | --- |
| `bellman_n3.pdf`, `bellman_n3.tex` | The paper. Title page and abstract; Section 1: introduction with the main inequality, the classical and the new Bellman function, and the main theorem (constant 2.44); Section 2: the counting lemma, logarithmic coordinates and the choice of the constants, structure of the proof; Section 3: numerical verification; Appendix A: the full proof; Appendix B: the computer-assisted steps; Disclaimer. |
| `verification/` | Scripts for the rigorous computer-assisted steps (C1)–(C4) and the high-precision numerical tests. |
| `verification/results/` | Logs and JSON output of every run quoted in the PDF. |
| `scratch/` | Exploration scripts and working notes (not needed for the proof). |
| `uploads/` | Source material: the companion paper and Ivanisvili's arXiv:1705.08529. |

The rigorous steps are:

- `taylor_symbolic.py` (C1): exact `sympy` expansion of the admissibility gap $Q$ and of $\omega$ at the balanced point.
- `check_Q.py` (C2), `check_omega.py` (C3) and `check_near.py` (C4): interval arithmetic with Arb, through `python-flint`.

## Running

Requirements: Python ≥ 3.10 with `python-flint` (tested with 0.9.0), `mpmath`, `sympy` and `scipy`; for the PDF, TeX Live
with `pgfplots`.

```bash
pip install python-flint mpmath sympy scipy

python3 verification/run_all.py          # all computer-assisted proof steps (C1)-(C4), about 65 s
python3 verification/numerics.py         # integer grids, random samples, worst-case slack (50 digits; about 6.5 min on 8 cores)
python3 verification/numerics.py --quick # reduced version of the same run
python3 verification/threshold.py        # smallest admissible shift A_*(s), about 20 s

latexmk -pdf bellman_n3.tex              # rebuild the PDF
```

`run_all.py` writes one log per step to `verification/results/` and exits with a nonzero status if a check fails.
