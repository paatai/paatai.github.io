"""Parameters of the proof of Theorem 1 that are shared by all computer-assisted checks.

All values are decimal strings; they are converted to Arb balls (which contain the exact decimal).
The "certified" entries are claims verified by the scripts (upper bounds unless stated otherwise).
"""
from flint import arb

A0 = '2000'          # the theorem holds for every A >= A0
C4 = '0.2'           # Prop. A:   Q >= C4 r^4 for r = |q - U| <= RQ
RQ = '0.13605'       # radius of the near disk in q;  C4 * RQ^4 >= gamma / A0
R0_Q = '0.003'       # inner disk used in the proof of Prop. A
SIGMA_V = '0.001'    # vertex regions {1 - max q_j <= SIGMA_V}
C_OMEGA = '4.13'     # Lemma omega:  omega >= -C_OMEGA r^2 for r <= RQ
R0_OMEGA = '0.001'   # inner disk used in the proof of Lemma omega
RX = '0.017'         # radius of the near region in x = l/s  (case F3 for |x - w(q)| >= RX)

# certified constants of the near regime (check_near.py)
RW = '0.0607'        # sup |w(q) - U| over r <= RQ
LAMBDA = '0.1'       # lower bound of lambda_min(pi(x)) over |x - U| <= RW + RX
GX = '1.95'          # sup |P grad_x V(w(q), q, q)|
GU = '2.0'           # sup |grad_u V(w(q), q, q)|


def ball(name):
    return arb(globals()[name])
