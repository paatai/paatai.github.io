"""Exact (symbolic) Taylor expansions at the balanced point U = (1/3, 1/3, 1/3).

ln2 and ln3 are independent symbols L2, L3: all coefficients live in the field Q(L2, L3), so an
expression that is 0 there vanishes identically (in particular for the true values of ln2, ln3).
Truncated series in t have coefficients in Q(L2, L3)[v1, v2], with v = (v1, v2, -v1-v2).

Verified:
  Q(U + t v)     = q4 |v|^4 t^4 + O(t^5)          (orders 0..3 vanish, the quartic term is isotropic)
  omega(U + t v) = omega2 |v|^2 t^2 + O(t^3)      (orders 0, 1 vanish, the quadratic term is isotropic)
and the closed forms of beta = K alpha^2/6, kappa_3 = K alpha^3/6 used in the text.
"""
from sympy import QQ, Rational, factorial, log, N, sympify
from sympy.polys.fields import field
from sympy.polys.rings import ring

F, L2, L3 = field("L2,L3", QQ)
R, v1, v2 = ring("v1,v2", F)
v = [v1, v2, -v1 - v2]
nv2 = v1 ** 2 + v2 ** 2 + (v1 + v2) ** 2

mu = 3 * L3 - 2 * L2
nu = 3 * L3 - 4 * L2
c = L3 / mu
gam = nu / (2 * mu)
NN = (9 - L2) * nu - 2 * L2 * mu
alpha = 3 * mu * NN / (2 * nu * L2 ** 2)
kappa = 3 * nu ** 2 / (mu * NN)
K = kappa / alpha


class Ser:
    """Truncated power series in t with coefficients in R."""
    n = 5

    def __init__(self, cs):
        cs = [R(x) for x in cs][:Ser.n]
        self.c = cs + [R(0)] * (Ser.n - len(cs))

    def __add__(self, o):
        o = o if isinstance(o, Ser) else Ser([o])
        return Ser([a + b for a, b in zip(self.c, o.c)])
    __radd__ = __add__

    def __neg__(self):
        return Ser([-a for a in self.c])

    def __sub__(self, o):
        return self + (-(o if isinstance(o, Ser) else Ser([o])))

    def __rsub__(self, o):
        return (-self) + o

    def __mul__(self, o):
        if not isinstance(o, Ser):
            return Ser([a * o for a in self.c])
        out = [R(0)] * Ser.n
        for i, a in enumerate(self.c):
            if a == 0:
                continue
            for j in range(Ser.n - i):
                out[i + j] += a * o.c[j]
        return Ser(out)
    __rmul__ = __mul__

    def inv(self):
        a0 = self.c[0]
        assert a0.is_ground and a0 != 0
        r = (self - a0) * (1 / a0.LC)
        out, term = Ser([1]), Ser([1])
        for _ in range(Ser.n):
            term = term * (-r)
            out = out + term
        return out * (1 / a0.LC)

    def __truediv__(self, o):
        return self * o.inv() if isinstance(o, Ser) else self * (1 / F(o))


def taylor(derivs, tau):
    """sum_k derivs[k] tau^k / k!,  tau a series with zero constant term."""
    out, power = Ser([0]), Ser([1])
    for k, d in enumerate(derivs):
        out = out + power * (d / int(factorial(k)))
        power = power * tau
    return out


def exp0(z):
    """exp(z) for a series with zero constant term."""
    return taylor([F(1)] * Ser.n, z)


def log1p0(z):
    """log(1 + z) for a series with zero constant term."""
    return taylor([F(0)] + [F((-1) ** (k + 1) * int(factorial(k - 1))) for k in range(1, Ser.n)], z)


tv = [Ser([0, vj]) for vj in v]                      # t v_j
third = F(1) / 3
# derivatives at 1/3:  h(t) = -t ln t - (1-t) ln(1-t),  e(t) = -t ln t
hd = [L3 - 2 * L2 / 3, L2, F(Rational(-9, 2)), F(Rational(27, 4)), F(Rational(-243, 4))]
ed = [L3 / 3, L3 - 1, F(-3), F(9), F(-54)]

hs = [taylor(hd, x) for x in tv]
S = hs[0] + hs[1] + hs[2]
H = taylor(ed, tv[0]) + taylor(ed, tv[1]) + taylor(ed, tv[2])
I = c * S - H
w = [hj / S for hj in hs]
y = [wj - third for wj in w]
L = log1p0((exp0(y[0] * alpha) + exp0(y[1] * alpha) + exp0(y[2] * alpha)) * (F(1) / 3) - 1)
Q = I / S - L * K

print('Q(U + t v), v = (v1, v2, -v1 - v2):')
for k in range(4):
    print(f'  coefficient of t^{k}: {Q.c[k]}')
    assert Q.c[k] == 0
q4 = Q.c[4].coeff(v1 ** 4) / (nv2 ** 2).coeff(v1 ** 4)
assert Q.c[4] == nv2 ** 2 * q4
to_num = lambda e: N(sympify(str(e)).subs({'L2': log(2), 'L3': log(3)}), 15)
print(f'  coefficient of t^4 = q4 |v|^4 with q4 = {to_num(q4)}')

# beta, kappa_3 of the profile K L(U + y) = beta |y|^2 + kappa_3 y1 y2 y3 + O(|y|^4)
beta = K * alpha ** 2 / 6
k3 = K * alpha ** 3 / 6
assert beta == 3 * nu / (4 * L2 ** 2)
assert k3 == 3 * mu ** 2 / L2 ** 3 * (27 * gam / (4 * L2) - 3 * (1 + gam) / 4)
print(f'  beta = 3 nu/(4 L2^2) = {to_num(beta)},  kappa_3 = {to_num(k3)}')

# omega(q) = V(w(q), q, q) - gamma S(q)
Ser.n = 3
tv = [Ser([0, vj]) for vj in v]
hs = [taylor(hd, x) for x in tv]
S = hs[0] + hs[1] + hs[2]
w = [hj / S for hj in hs]
ex = [exp0((wj - third) * alpha) for wj in w]       # e^{alpha (w_j - 1/3)}
Z = ex[0] + ex[1] + ex[2]
pi = [e / Z for e in ex]
lnq = [log1p0(x * 3) - L3 for x in tv]               # ln(1/3 + t v_j)
ln1q = [log1p0(x * F(Rational(-3, 2))) + (L2 - L3) for x in tv]   # ln(2/3 - t v_j)
qs = [Ser([third, vj]) for vj in v]
Vs = Ser([0])
for i in range(3):
    D = [lnq[j] if j == i else ln1q[j] for j in range(3)]
    d = -(D[0] + D[1] + D[2])
    g = [D[j] + d * w[j] for j in range(3)]
    m = pi[0] * g[0] + pi[1] * g[1] + pi[2] * g[2]
    var = sum(((g[j] - m) * (g[j] - m) * pi[j] for j in range(3)), Ser([0]))
    Vs = Vs + qs[i] * var
om = Vs * (K * alpha ** 2 / 2) - S * gam
print('omega(U + t v):')
for k in range(2):
    print(f'  coefficient of t^{k}: {om.c[k]}')
    assert om.c[k] == 0
o2 = om.c[2].coeff(v1 ** 2) / nv2.coeff(v1 ** 2)
assert om.c[2] == nv2 * o2
print(f'  coefficient of t^2 = omega2 |v|^2 with omega2 = {to_num(o2)}')
print('OK')
