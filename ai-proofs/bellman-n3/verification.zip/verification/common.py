"""Shared definitions for the computer-assisted part of the proof (ball arithmetic, python-flint/Arb).

Every function below accepts Arb balls (``arb``) or truncated Taylor series with ball coefficients
(``arb_series``).  Ball arithmetic is inclusion-isotone: if the inputs are balls containing the exact
values, the output contains the exact value.  Series inputs give enclosures of Taylor coefficients.

Notation follows the appendix of ``bellman_n3.tex``.
"""
from flint import arb, arb_series, ctx

ctx.prec = 128

# --------------------------------------------------------------------------------------------
# exact constants (as balls)
# --------------------------------------------------------------------------------------------
LAM = arb(2).log()                      # lambda = ln 2
LN3 = arb(3).log()
MU = 3 * LN3 - 2 * LAM                  # mu = ln(27/4)
NU = 3 * LN3 - 4 * LAM                  # nu = ln(27/16)
C = LN3 / MU                            # c = ln3 / ln(27/4)
GAM = NU / (2 * MU)                     # gamma = nu / (2 mu)
NN = (9 - LAM) * NU - 2 * LAM * MU      # N
ALPHA = 3 * MU * NN / (2 * NU * LAM ** 2)
KAPPA = 3 * NU ** 2 / (MU * NN)
K = KAPPA / ALPHA
BETA = K * ALPHA ** 2 / 6
BMIN = C - 2 * KAPPA / 3                # lower bound for the coordinates of grad F
THIRD = arb(1) / 3
SQ2, SQ3, SQ6 = arb(2).sqrt(), arb(3).sqrt(), arb(6).sqrt()
E1 = [1 / SQ2, -1 / SQ2, arb(0)]        # orthonormal basis of the plane {sum = 0}
E2 = [1 / SQ6, 1 / SQ6, -2 / SQ6]
INV_E = (-arb(1)).exp()                 # 1/e


def hull(a, b):
    """Smallest ball containing the balls a and b."""
    return arb(a).union(arb(b))


def interval(a, b):
    return hull(arb(a), arb(b))


def is_series(t):
    return isinstance(t, arb_series)


# --------------------------------------------------------------------------------------------
# entropy-type functions; ball versions also accept balls touching 0
# --------------------------------------------------------------------------------------------
def xlogx(t):
    """t*ln(t) (0 at t=0).  For a ball whose lower end is <= 0 the exact range over [0, upper] is used."""
    if is_series(t):
        return t * t.log()
    lo = t.lower()
    if lo > 0:
        return t * t.log()
    hi = t.upper()
    if hi <= 0:
        return arb(0)
    # x ln x is decreasing on [0, 1/e] and increasing on [1/e, 1]
    if hi <= INV_E:
        return hull(hi * hi.log(), 0)
    return hull(-INV_E, hull(hi * hi.log(), 0))


def h(t):
    """binary entropy h(t) = -t ln t - (1-t) ln(1-t)."""
    return -xlogx(t) - xlogx(1 - t)


def bkl(q, u):
    """binary Kullback-Leibler divergence d(q||u) for 0<q,u<1."""
    return q * (q / u).log() + (1 - q) * ((1 - q) / (1 - u)).log()


# --------------------------------------------------------------------------------------------
# the admissibility gap Q
# --------------------------------------------------------------------------------------------
def lse_L(w):
    """L(w) = ln( (1/3) sum_j exp(alpha (w_j - 1/3)) )."""
    E = [(ALPHA * (wj - THIRD)).exp() for wj in w]
    return ((E[0] + E[1] + E[2]) / 3).log()


def Q_parts(q):
    hs = [h(qj) for qj in q]
    S = hs[0] + hs[1] + hs[2]
    H = -(xlogx(q[0]) + xlogx(q[1]) + xlogx(q[2]))
    I = C * S - H
    w = [hj / S for hj in hs]
    return S, I, w


def Q(q):
    """Q(q) = I(q)/S(q) - K L(h(q)/S(q))."""
    S, I, w = Q_parts(q)
    return I / S - K * lse_L(w)


def r2(q):
    return (q[0] - THIRD) ** 2 + (q[1] - THIRD) ** 2 + (q[2] - THIRD) ** 2


# --------------------------------------------------------------------------------------------
# the second-order gain V(x,u,q) and omega(q) = V(w(q),q,q) - gamma S(q)
# --------------------------------------------------------------------------------------------
def softmax(x):
    E = [(ALPHA * xk).exp() for xk in x]
    Z = E[0] + E[1] + E[2]
    return [e / Z for e in E]


def Dvec(u, i):
    """D^{(i)}(u): ln u_j for j = i, ln(1-u_j) for j != i."""
    return [u[j].log() if j == i else (1 - u[j]).log() for j in range(3)]


def V(x, u, q):
    """V(x,u,q) = (K alpha^2/2) sum_i q_i Var_{pi(x)}(g_i),  g_i = D^{(i)}(u) + d_i(u) x."""
    p = softmax(x)
    tot = 0
    for i in range(3):
        D = Dvec(u, i)
        d = -(D[0] + D[1] + D[2])
        g = [D[j] + d * x[j] for j in range(3)]
        m = p[0] * g[0] + p[1] * g[1] + p[2] * g[2]
        var = p[0] * (g[0] - m) ** 2 + p[1] * (g[1] - m) ** 2 + p[2] * (g[2] - m) ** 2
        tot = tot + q[i] * var
    return tot * K * ALPHA ** 2 / 2


def omega(q):
    S, I, w = Q_parts(q)
    return V(w, q, q) - GAM * S


def V_grads(x, u, q):
    """Return (grad_x V, grad_u V, d, osc-data) at (x,u,q), all as lists of balls.

    d_x_k V = sum_i q_i (K a^2/2) pi_k [ a((g_ik-m_i)^2 - Var_i) + 2 d_i (g_ik - m_i) ]
    d_u_j V = sum_i q_i  K a^2 eta_ij [ pi_j (g_ij - m_i) - sum_k pi_k (g_ik - m_i) x_k ],
    eta_ij = 1/u_j (i = j), -1/(1-u_j) (i != j).
    """
    p = softmax(x)
    gx = [arb(0)] * 3
    gu = [arb(0)] * 3
    ds, gs = [], []
    for i in range(3):
        D = Dvec(u, i)
        d = -(D[0] + D[1] + D[2])
        g = [D[j] + d * x[j] for j in range(3)]
        ds.append(d)
        gs.append(g)
        m = p[0] * g[0] + p[1] * g[1] + p[2] * g[2]
        c_ = [g[j] - m for j in range(3)]
        var = p[0] * c_[0] ** 2 + p[1] * c_[1] ** 2 + p[2] * c_[2] ** 2
        for k in range(3):
            gx[k] = gx[k] + q[i] * p[k] * (ALPHA * (c_[k] ** 2 - var) + 2 * d * c_[k])
        s_ = p[0] * c_[0] * x[0] + p[1] * c_[1] * x[1] + p[2] * c_[2] * x[2]
        for j in range(3):
            eta = 1 / u[j] if i == j else -1 / (1 - u[j])
            gu[j] = gu[j] + q[i] * eta * (p[j] * c_[j] - s_)
    gx = [g_ * K * ALPHA ** 2 / 2 for g_ in gx]
    gu = [g_ * K * ALPHA ** 2 for g_ in gu]
    return gx, gu, ds, gs, p


# --------------------------------------------------------------------------------------------
# Taylor series helpers
# --------------------------------------------------------------------------------------------
def line_series(base, direction, n):
    """Components of tau -> base + tau*direction as arb_series truncated at order n."""
    ctx.cap = n
    return [arb_series([base[j], direction[j]], prec=n) for j in range(len(base))]


def coeff(sr, k):
    cs = sr.coeffs()
    return cs[k] if len(cs) > k else arb(0)


def polar_point(t, th):
    """U + t (cos th E1 + sin th E2) and the unit direction, for balls t, th."""
    ct, st = th.cos(), th.sin()
    v = [ct * E1[j] + st * E2[j] for j in range(3)]
    return [THIRD + t * v[j] for j in range(3)], v


def fmt(x, digits=8):
    return x.str(digits, radius=False)
