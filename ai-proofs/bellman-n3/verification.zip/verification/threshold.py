"""The smallest admissible shift A, numerically.

For fixed (s, xi, u) the slack delta_A(s, xi, u) = ln LHS - ln RHS is non-decreasing in A (each child has s_i <= s),
so there is a critical shift A_0(s, xi, u) = inf{A >= 0 : delta_A >= 0}, and the main inequality holds for B_A iff
A >= A_*(s) := sup_{xi,u} A_0(s, xi, u) for every s.  This script estimates A_*(s) on a grid of sizes s by maximising
A_0 (dense random seeding + Nelder-Mead, double precision), and re-evaluates delta at the maximisers in 50-digit
arithmetic (mpmath) at A_0 -+ 0.01 to confirm the sign change.  Double precision suffices for s <= 1e4 (for
larger s use the 50-digit worst-case search in numerics.py).

    python threshold.py          (about 20 seconds on 8 cores; writes results/threshold.json next to this script)
"""
import json
import math
import os
import random
import time
from multiprocessing import Pool

import mpmath as mp
from scipy.optimize import brentq, minimize

import numerics as nm

LAM, LN3 = math.log(2), math.log(3)
MU, NU = 3 * LN3 - 2 * LAM, 3 * LN3 - 4 * LAM
C, GAM = LN3 / MU, NU / (2 * MU)
NN = (9 - LAM) * NU - 2 * LAM * MU
ALPHA = 3 * MU * NN / (2 * NU * LAM ** 2)
KAPPA = 3 * NU ** 2 / (MU * NN)
E1 = [1 / math.sqrt(2), -1 / math.sqrt(2), 0.0]
E2 = [1 / math.sqrt(6), 1 / math.sqrt(6), -2 / math.sqrt(6)]
U_LO, U_HI = 0.005, 0.995
A_MAX = 1e4


def F(l):
    s = l[0] + l[1] + l[2]
    if s <= 0:
        return 0.0
    a = [ALPHA * lj / s for lj in l]
    am = max(a)
    lse = am + math.log((math.exp(a[0] - am) + math.exp(a[1] - am) + math.exp(a[2] - am)) / 3)
    return C * s + KAPPA * s / 3 - KAPPA * s / ALPHA * lse


def split(l, u):
    """F and s of the parent and of the active children."""
    kids = []
    for i in range(3):
        child = []
        for j in range(3):
            f = u[j] if j == i else 1 - u[j]
            cj = l[j] + math.log(f) if f > 0 else -1.0
            if cj < 0:
                break
            child.append(cj)
        if len(child) == 3:
            kids.append((F(child), sum(child)))
    return (F(l), sum(l)), kids


def delta(par, kids, A):
    """delta_A with the factor (1 + s/A)^-gamma written as A^gamma (A + s)^-gamma (A^gamma cancels)."""
    p = par[0] - GAM * math.log(A + par[1])
    v = [f - GAM * math.log(A + si) for f, si in kids]
    m = max(v)
    return p - m - math.log(sum(math.exp(x - m) for x in v))


def A0(par, kids):
    if not kids:
        return 0.0
    lo, hi = 1e-9, A_MAX
    if delta(par, kids, lo) >= 0:
        return 0.0
    if delta(par, kids, hi) < 0:
        return A_MAX
    return brentq(lambda A: delta(par, kids, A), lo, hi, xtol=1e-7, rtol=1e-12)


def point(s, p):
    scale = 1 / math.sqrt(s) if s > 1 else 0.3
    xi1, xi2, a1, a2, a3 = p
    x = [1 / 3 + scale * (xi1 * E1[j] + xi2 * E2[j]) for j in range(3)]
    if min(x) <= 0:
        return None
    u = [U_LO + (U_HI - U_LO) * 0.5 * (1 + math.tanh(a / 2)) for a in (a1, a2, a3)]
    return [s * xj for xj in x], u


def neg_A0(p, s):
    pt = point(s, p)
    if pt is None:
        return 1e3
    par, kids = split(*pt)
    return -A0(par, kids)


def logit(u):
    v = (u - U_LO) / (U_HI - U_LO)
    return math.log(v / (1 - v))


def s2delta(p, s, A):
    pt = point(s, p)
    if pt is None:
        return 1e6
    par, kids = split(*pt)
    if not kids:
        return 1e6
    return s * s * delta(par, kids, A)


def worker(args):
    """Stage 1: minimise the smooth function s^2 delta_{A_REF} from many seeds.  Stage 2: maximise A_0 starting
    from the best stage-1 points (A_0 is flat, = 0, wherever delta >= 0 already without the shift)."""
    s, nseed, nstart, seed = args
    A_REF = 29.0
    rng = random.Random(seed)
    seeds = []
    for k in range(nseed):
        if k % 2 == 0:
            p = [rng.gauss(0, 0.8), rng.gauss(0, 0.8)] + [logit(rng.uniform(0.12, 0.65)) for _ in range(3)]
        else:
            p = [rng.gauss(0, 1.2), rng.gauss(0, 1.2)] + [logit(rng.uniform(0.02, 0.98)) for _ in range(3)]
        seeds.append((s2delta(p, s, A_REF), p))
    seeds.sort(key=lambda z: z[0])
    stage1 = []
    for val, p0 in seeds[:nstart]:
        r = minimize(s2delta, p0, args=(s, A_REF), method='Nelder-Mead',
                     options=dict(xatol=1e-8, fatol=1e-11, maxiter=4000, adaptive=True))
        stage1.append((r.fun, list(r.x)))
    stage1.sort(key=lambda z: z[0])
    best = (math.inf, None)
    for val, p0 in stage1[:max(4, nstart // 4)]:
        r = minimize(neg_A0, p0, args=(s,), method='Nelder-Mead',
                     options=dict(xatol=1e-8, fatol=1e-9, maxiter=4000, adaptive=True))
        if r.fun < best[0]:
            best = (r.fun, list(r.x))
    l, u = point(s, best[1])
    a0 = -best[0]
    # confirmation in 50-digit arithmetic
    mp.mp.dps = 50
    lm, um = [mp.mpf(z) for z in l], [mp.mpf(z) for z in u]
    d_lo = nm.delta_split(lm, um, mp.mpf(a0) - mp.mpf('0.01')) if a0 > 0.01 else None
    d_hi = nm.delta_split(lm, um, mp.mpf(a0) + mp.mpf('0.01'))
    return dict(s=s, A0=a0, l=l, u=u, delta_minus=float(d_lo) if d_lo is not None else None,
                delta_plus=float(d_hi))


def main():
    t0 = time.time()
    svals = [1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 6, 7, 8, 9, 10, 12, 14, 17, 20, 25, 30, 35, 36, 38, 40, 42, 45, 50, 55, 60,
             65, 70, 80, 90, 100, 120, 150, 200, 300, 500, 1000, 3000, 1e4]
    jobs = [(s, 20000, 24, 101 + i) for i, s in enumerate(svals)]
    with Pool(8) as pool:
        res = pool.map(worker, jobs)
    best = max(res, key=lambda r: r['A0'])
    for r in res:
        dm, dp = r['delta_minus'], r['delta_plus']
        conf = 'confirmed' if (dm is None or dm < 0) and dp > 0 else 'NOT CONFIRMED'
        dm_s = 'n/a' if dm is None else f'{dm:.3e}'
        print(f"s = {r['s']:>8g}:  A_*(s) >= {r['A0']:9.4f}   u = ({', '.join(f'{z:.4f}' for z in r['u'])})   "
              f"[50 digits: delta(A0-0.01) = {dm_s}, delta(A0+0.01) = {dp:.3e}: {conf}]", flush=True)
    print(f"max over s: A_* ~ {best['A0']:.4f} at s = {best['s']:g}   ({time.time() - t0:.0f}s)")
    out = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'results', 'threshold.json')
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out, 'w') as f:
        json.dump(dict(points=res, A_star=best['A0'], s_star=best['s'], time=time.time() - t0), f, indent=1)


if __name__ == '__main__':
    main()
