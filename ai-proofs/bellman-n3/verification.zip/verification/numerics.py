"""High-precision numerical verification of the main inequality for the new Bellman function (mpmath).

    B(x0+x1, y0+y1, z0+z1) >= B(x1,y0,z0) + B(x0,y1,z0) + B(x0,y0,z1),   B = 0 if min(x,y,z) < 1,
    B(x,y,z) = (xyz)^c (G/M)^kappa (1 + ln(xyz)/A)^(-gamma).

The slack is reported as  delta = ln(LHS) - ln(RHS) >= 0  (relative slack 1 - RHS/LHS = 1 - e^-delta).
Parametrisation: parent sizes X = e^{l1}, Y = e^{l2}, Z = e^{l3} (s = l1+l2+l3, x = l/s) and split fractions
u = (x1/X, y1/Y, z1/Z).  Equality holds exactly at the trivial splits u = e_k.

  python numerics.py --quick        (reduced run, writes results/numerics_quick.json next to this script)
  python numerics.py                (full run, about 6.5 minutes on 8 cores, writes results/numerics.json)
"""
import os
import json
import time
import argparse
import random
import math
from multiprocessing import Pool
import mpmath as mp

DPS = 50
mp.mp.dps = DPS
LAM = mp.log(2)
LN3 = mp.log(3)
MU = 3 * LN3 - 2 * LAM
NU = 3 * LN3 - 4 * LAM
C = LN3 / MU
GAM = NU / (2 * MU)
NN = (9 - LAM) * NU - 2 * LAM * MU
ALPHA = 3 * MU * NN / (2 * NU * LAM ** 2)
KAPPA = 3 * NU ** 2 / (MU * NN)
THIRD = mp.mpf(1) / 3


def lnB(l, A):
    """ln B at sizes e^{l_j} (l_j >= 0), in the numerically stable form
    ln B = c s + kappa s/3 - (kappa s/alpha) ln((1/3) sum_j e^{alpha l_j/s}) - gamma ln(1 + s/A)."""
    s = l[0] + l[1] + l[2]
    if s == 0:
        return mp.mpf(0)
    a = [ALPHA * lj / s for lj in l]
    am = max(a)
    lse = am + mp.log((mp.exp(a[0] - am) + mp.exp(a[1] - am) + mp.exp(a[2] - am)) / 3)
    out = C * s + KAPPA * s / 3 - KAPPA * s / ALPHA * lse
    if A != mp.inf:
        out -= GAM * mp.log1p(s / A)
    return out


def B_literal(x, y, z, A):
    """The closed form of B in the paper (geometric mean G, power mean M), evaluated literally."""
    x, y, z = mp.mpf(x), mp.mpf(y), mp.mpf(z)
    if min(x, y, z) < 1:
        return mp.mpf(0)
    P = x * y * z
    if P == 1:
        return mp.mpf(1)
    t = ALPHA / mp.log(P)
    G = mp.cbrt(P)
    M = ((x ** t + y ** t + z ** t) / 3) ** (1 / t)
    out = P ** C * (G / M) ** KAPPA
    if A != mp.inf:
        out *= (1 + mp.log(P) / A) ** (-GAM)
    return out


def delta_split(l, u, A):
    """ln LHS - ln RHS for parent logs l and split fractions u (inf if every child vanishes)."""
    vals = []
    for i in range(3):
        child = []
        for j in range(3):
            f = u[j] if j == i else 1 - u[j]
            if f <= 0:
                break
            cj = l[j] + mp.log(f)
            if cj < 0:
                break
            child.append(cj)
        if len(child) == 3:
            vals.append(lnB(child, A))
    if not vals:
        return mp.inf
    m = max(vals)
    return lnB(l, A) - (m + mp.log(sum(mp.exp(v - m) for v in vals)))


def parse_A(a):
    return mp.inf if a in ('inf', mp.inf) else mp.mpf(a)


U_LO, U_HI = 0.02, 0.98


def sigmoid(a):
    """Split fraction in [U_LO, U_HI]; the trivial splits (delta = 0) are kept out of the optimisation."""
    return U_LO + (U_HI - U_LO) * 0.5 * (1 + math.tanh(a / 2))


def logit(u):
    v = (u - U_LO) / (U_HI - U_LO)
    return math.log(v / (1 - v))


# ------------------------------------------------------------------------------------------------
# 1. exhaustive integer grid
# ------------------------------------------------------------------------------------------------
def _grid_worker(args):
    X, N, A = args
    mp.mp.dps = 30
    A = parse_A(A)
    Bt = {}

    def Bv(a, b, c):
        if a < 1 or b < 1 or c < 1:
            return mp.mpf(0)
        key = (a, b, c)
        if key not in Bt:
            Bt[key] = mp.exp(lnB([mp.log(a), mp.log(b), mp.log(c)], A))
        return Bt[key]
    n = ntriv = nzero = 0
    best = (mp.inf, None)
    for Y in range(1, N + 1):
        for Z in range(1, N + 1):
            lhs = Bv(X, Y, Z)
            for x1 in range(X + 1):
                for y1 in range(Y + 1):
                    for z1 in range(Z + 1):
                        rhs = Bv(x1, Y - y1, Z - z1) + Bv(X - x1, y1, Z - z1) + Bv(X - x1, Y - y1, z1)
                        n += 1
                        if rhs == 0:
                            nzero += 1
                            continue
                        d = mp.log(lhs / rhs)
                        if (x1, y1, z1) in ((X, 0, 0), (0, Y, 0), (0, 0, Z)):
                            ntriv += 1
                            assert abs(d) < mp.mpf(10) ** (-25)
                            continue
                        if d < best[0]:
                            best = (d, (x1, X - x1, y1, Y - y1, z1, Z - z1))
    return n, ntriv, nzero, float(best[0]), best[1]


def integer_grid(N, A, pool):
    res = pool.map(_grid_worker, [(X, N, str(A)) for X in range(1, N + 1)])
    n = sum(r[0] for r in res)
    ntriv = sum(r[1] for r in res)
    nzero = sum(r[2] for r in res)
    best = min(res, key=lambda r: r[3])
    return dict(N=N, A=str(A), configs=n, trivial=ntriv, rhs_zero=nzero, min_delta=best[3],
                argmin=best[4], min_rel=float(-mp.expm1(-best[3])))


# ------------------------------------------------------------------------------------------------
# 2. random samples
# ------------------------------------------------------------------------------------------------
E1 = [1 / math.sqrt(2), -1 / math.sqrt(2), 0.0]
E2 = [1 / math.sqrt(6), 1 / math.sqrt(6), -2 / math.sqrt(6)]


def sample(cls, rng):
    """Return (l, u) for the sampling class."""
    if cls == 'generic':
        s = 10 ** rng.uniform(-3, 5)
        g = [rng.expovariate(1) for _ in range(3)]
        x = [gi / sum(g) for gi in g]
        u = [rng.random() for _ in range(3)]
    elif cls == 'balanced':
        s = 10 ** rng.uniform(0, 6)
        r = abs(rng.gauss(0, 1.0)) / math.sqrt(s)
        th = rng.uniform(0, 2 * math.pi)
        x = [1 / 3 + min(r, 0.3) * (math.cos(th) * E1[j] + math.sin(th) * E2[j]) for j in range(3)]
        su = 10 ** rng.uniform(-4, -0.7)
        u = [min(max(1 / 3 + rng.gauss(0, su), 1e-12), 1 - 1e-12) for _ in range(3)]
    elif cls == 'faces':
        s = 10 ** rng.uniform(-2, 4)
        k = rng.randrange(3)
        g = [rng.expovariate(1) for _ in range(3)]
        g[k] = 10 ** rng.uniform(-12, -1) * (0 if rng.random() < 0.3 else 1)
        if rng.random() < 0.3:
            g[(k + 1) % 3] = 10 ** rng.uniform(-12, -1)
        x = [gi / sum(g) for gi in g]
        u = [rng.choice([10 ** rng.uniform(-12, -1), 1 - 10 ** rng.uniform(-12, -1), rng.random()])
             for _ in range(3)]
    elif cls == 'near_trivial':
        s = 10 ** rng.uniform(-1, 5)
        g = [rng.expovariate(1) for _ in range(3)]
        x = [gi / sum(g) for gi in g]
        k = rng.randrange(3)
        eps = [10 ** rng.uniform(-10, -0.5) for _ in range(3)]
        u = [1 - eps[j] if j == k else eps[j] for j in range(3)]
    elif cls == 'child_boundary':
        # child i is active and its j-th size is e^eps, just above the threshold 1 where B jumps
        while True:
            s = 10 ** rng.uniform(-1, 4)
            g = [rng.expovariate(1) for _ in range(3)]
            x = [gi / sum(g) for gi in g]
            i, j = rng.randrange(3), rng.randrange(3)
            eps = 10 ** rng.uniform(-12, -1)
            if s * x[j] > 2 * eps:
                break
        f = [math.exp(-s * x[k] + eps) if k == j else rng.uniform(math.exp(-s * x[k]), 1) for k in range(3)]
        u = [f[k] if k == i else 1 - f[k] for k in range(3)]
        l = [mp.mpf(s) * mp.mpf(xk) for xk in x]
        uu = [mp.mpf(uk) for uk in u]
        uu[j] = mp.exp(-l[j] + eps) if j == i else -mp.expm1(-l[j] + eps)
        return l, uu, s
    else:
        raise ValueError(cls)
    l = [mp.mpf(s) * mp.mpf(xj) for xj in x]
    return l, [mp.mpf(uj) for uj in u], s


def _rand_worker(args):
    cls, A, n, seed = args
    mp.mp.dps = DPS
    A = parse_A(A)
    rng = random.Random(seed)
    cnt = inf_cnt = 0
    best = (mp.inf, None)
    best_s2 = (mp.inf, None)
    best_rel = (mp.inf, None)
    for _ in range(n):
        l, u, s = sample(cls, rng)
        d = delta_split(l, u, A)
        if d == mp.inf:
            inf_cnt += 1
            continue
        cnt += 1
        loc = ([float(z) for z in l], [float(z) for z in u])
        if d < best[0]:
            best = (d, loc)
        if s >= 10 and d * s * s < best_s2[0]:
            best_s2 = (d * s * s, loc)
        # slack relative to the L1-distance of u from the nearest trivial split e_k
        dist = min(sum(abs(u[j] - (1 if j == k else 0)) for j in range(3)) for k in range(3))
        if d / dist < best_rel[0]:
            best_rel = (d / dist, loc)
    return cnt, inf_cnt, best, best_s2, best_rel


def random_class(cls, A, n, pool, seed0=1):
    k = 8
    res = pool.map(_rand_worker, [(cls, str(A), n // k, seed0 + 1000 * i) for i in range(k)])
    cnt = sum(r[0] for r in res)
    inf_cnt = sum(r[1] for r in res)
    b = min((r[2] for r in res), key=lambda z: z[0])
    b2 = min((r[3] for r in res), key=lambda z: z[0])
    b3 = min((r[4] for r in res), key=lambda z: z[0])
    return dict(cls=cls, A=str(A), samples=cnt, rhs_zero=inf_cnt, min_delta=float(b[0]), argmin=b[1],
                min_s2delta=(float(b2[0]) if b2[0] != mp.inf else None), argmin_s2=b2[1],
                min_delta_over_dist=float(b3[0]), argmin_dist=b3[1])


# ------------------------------------------------------------------------------------------------
# 3. worst case over the split and the parent direction at fixed s:  min s^2 delta
# ------------------------------------------------------------------------------------------------
def _worst_worker(args):
    from scipy.optimize import minimize
    s, A, nstart, seed = args
    mp.mp.dps = DPS
    Am = parse_A(A)
    sm = mp.mpf(s)
    rng = random.Random(seed)
    scale = 1 / math.sqrt(s) if s > 1 else 0.3

    def obj(p):
        xi1, xi2, a1, a2, a3 = p
        x = [1 / 3 + scale * (xi1 * E1[j] + xi2 * E2[j]) for j in range(3)]
        if min(x) <= 0:
            return 1e6
        u = [sigmoid(a) for a in (a1, a2, a3)]
        l = [sm * mp.mpf(xj) for xj in x]
        d = delta_split(l, [mp.mpf(uj) for uj in u], Am)
        if d == mp.inf:
            return 1e6
        return float(d * sm * sm)
    best = (math.inf, None)
    for k in range(nstart):
        if k % 2 == 0:
            u0 = [rng.uniform(0.25, 0.45) for _ in range(3)]
        else:
            u0 = [rng.uniform(0.1, 0.9) for _ in range(3)]
        p0 = [rng.gauss(0, 1), rng.gauss(0, 1)] + [logit(z) for z in u0]
        r = minimize(obj, p0, method='Nelder-Mead', options=dict(xatol=1e-7, fatol=1e-10, maxiter=4000))
        if r.fun < best[0]:
            best = (r.fun, list(r.x))
    return s, A, best


def worst_case(svals, Avals, nstart, pool):
    jobs = [(s, str(A), nstart, 17 + i) for i, (s, A) in enumerate((s, A) for A in Avals for s in svals)]
    out = []
    for s, A, best in pool.map(_worst_worker, jobs):
        xi1, xi2, a1, a2, a3 = best[1]
        u = [sigmoid(a) for a in (a1, a2, a3)]
        out.append(dict(s=s, A=A, min_s2delta=best[0], xi=[xi1, xi2], u=u))
    return out


# ------------------------------------------------------------------------------------------------
def literal_check(n=200, seed=5):
    """The closed form of B in the paper agrees with the logarithmic form used everywhere else."""
    rng = random.Random(seed)
    worst = mp.mpf(0)
    for _ in range(n):
        xyz = [mp.mpf(1) + mp.mpf(10) ** rng.uniform(-3, 6) for _ in range(3)]
        for A in (mp.mpf(2000), mp.mpf(30), mp.inf):
            a = B_literal(*xyz, A)
            b = mp.exp(lnB([mp.log(z) for z in xyz], A))
            worst = max(worst, abs(a / b - 1))
    return float(worst)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--quick', action='store_true')
    ap.add_argument('--out', default=None)
    args = ap.parse_args()
    t0 = time.time()
    quick = args.quick
    here = os.path.dirname(os.path.abspath(__file__))
    out = args.out or os.path.join(here, 'results', 'numerics_quick.json' if quick else 'numerics.json')
    os.makedirs(os.path.dirname(out) or '.', exist_ok=True)
    res = dict(dps=DPS)

    def save():
        res['time'] = time.time() - t0
        with open(out, 'w') as f:
            json.dump(res, f, indent=1, default=str)

    res['literal_vs_log_form_max_rel_diff'] = literal_check(50 if quick else 300)
    print(f"closed form vs. log form: max relative difference {res['literal_vs_log_form_max_rel_diff']:.2e}",
          flush=True)
    save()
    with Pool(8) as pool:
        res['grid'] = []
        for A in ([2000] if quick else [2000, 30, 'inf']):
            g = integer_grid(8 if quick else 24, A, pool)
            res['grid'].append(g)
            print(f"integer grid N={g['N']}, A={A}: {g['configs']} configurations, {g['trivial']} trivial splits "
                  f"(equality), {g['rhs_zero']} with RHS = 0; min delta over the others = {g['min_delta']:.6e} "
                  f"at (x1,x0,y1,y0,z1,z0) = {g['argmin']}  [{time.time() - t0:.0f}s]", flush=True)
            save()
        res['random'] = []
        n = 4000 if quick else 400000
        for A in ([2000, 30] if quick else [2000, 30, 'inf']):
            for cls in ('generic', 'balanced', 'faces', 'near_trivial', 'child_boundary'):
                r = random_class(cls, A, n, pool)
                res['random'].append(r)
                s2 = f", min s^2 delta (s >= 10) = {r['min_s2delta']:.4f}" if r['min_s2delta'] is not None else ''
                print(f"random '{cls}', A={A}: {r['samples']} samples (+{r['rhs_zero']} with RHS = 0), "
                      f"min delta = {r['min_delta']:.4e}{s2}, min delta/dist(u, trivial) = "
                      f"{r['min_delta_over_dist']:.4f}  [{time.time() - t0:.0f}s]", flush=True)
            save()
        svals = [10, 30, 100, 300, 1e3, 1e4, 1e5, 1e6]
        res['worst'] = worst_case(svals[::2] if quick else svals, [2000, 30, 25, 22], 4 if quick else 16, pool)
        for w in res['worst']:
            print(f"worst case s={w['s']:g}, A={w['A']}: min s^2 delta = {w['min_s2delta']:.5f} "
                  f"(xi = {w['xi'][0]:.3f},{w['xi'][1]:.3f}; u = {', '.join(f'{z:.4f}' for z in w['u'])})", flush=True)
        save()
        if not quick:
            sv = [4, 5, 7, 10, 14, 20, 30, 50, 70, 100, 150, 200, 300, 500, 1000, 3000]
            Av = [25, 26, 26.5, 27, 27.5, 28, 28.5, 29, 30]
            thr = worst_case(sv, Av, 16, pool)
            res['threshold'] = thr
            for A in Av:
                rows = [w for w in thr if w['A'] == str(A)]
                wmin = min(rows, key=lambda w: w['min_s2delta'])
                print(f"threshold scan A={A}: min over s of the worst-case s^2 delta = {wmin['min_s2delta']:.5f} "
                      f"at s = {wmin['s']:g}", flush=True)
            save()
    save()
    print(f"total {res['time']:.0f}s; results in {os.path.relpath(out)}")


if __name__ == '__main__':
    main()
