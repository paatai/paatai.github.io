"""Certified lower bounds of smooth functions of q = U + y1 E1 + y2 E2 on boxes in the (y1, y2)-plane.

Third-order Taylor form: on a box with centre c and half-widths (w1, w2)
    f(c + d) = P(d) + R(d),   P = exact quadratic Taylor polynomial at c,
    |R(d)| <= |T111| w1^3 + |T112| w1^2 w2 + |T122| w1 w2^2 + |T222| w2^3,
where the T's (third derivatives / multinomial factors) are enclosed on the whole box from directional
Taylor series along (1,0), (0,1), (1,1), (1,-1).  P is evaluated at the centre in ball arithmetic (tight),
and minimised over the box: a coordinate whose partial derivative has constant sign on the box is fixed
at the corresponding face, the remaining ones are kept as intervals.
"""
from flint import arb
from common import THIRD, E1, E2, line_series, coeff, interval


def qpoint(y1, y2):
    return [THIRD + y1 * E1[j] + y2 * E2[j] for j in range(3)]


def series_f(fun, y, d, n):
    base = qpoint(*y)
    dq = [d[0] * E1[j] + d[1] * E2[j] for j in range(3)]
    return fun(line_series(base, dq, n))


def taylor_lb(fun, c1, c2, w1, w2):
    yc = (arb(c1), arb(c2))
    s1 = series_f(fun, yc, (1, 0), 3)
    s2 = series_f(fun, yc, (0, 1), 3)
    sd = series_f(fun, yc, (1, 1), 3)
    f0, g1, g2 = coeff(s1, 0), coeff(s1, 1), coeff(s2, 1)
    H11, H22 = 2 * coeff(s1, 2), 2 * coeff(s2, 2)
    H12 = coeff(sd, 2) - (H11 + H22) / 2
    yb = (arb(c1, w1), arb(c2, w2))
    t1 = coeff(series_f(fun, yb, (1, 0), 4), 3)
    t2 = coeff(series_f(fun, yb, (0, 1), 4), 3)
    tp = coeff(series_f(fun, yb, (1, 1), 4), 3)
    tm = coeff(series_f(fun, yb, (1, -1), 4), 3)
    a = (tp - tm - 2 * t2) / 2
    b = (tp + tm - 2 * t1) / 2
    W1, W2 = arb(w1), arb(w2)
    R3 = (t1.abs_upper() * W1 ** 3 + a.abs_upper() * W1 ** 2 * W2 + b.abs_upper() * W1 * W2 ** 2
          + t2.abs_upper() * W2 ** 3)
    d1, d2 = arb(0, w1), arb(0, w2)
    I1 = g1 + H11 * d1 + H12 * d2
    I2 = g2 + H12 * d1 + H22 * d2
    if I1 > 0:
        d1 = -W1
    elif I1 < 0:
        d1 = W1
    if I2 > 0:
        d2 = -W2
    elif I2 < 0:
        d2 = W2
    sq1 = d1 ** 2 if d1.is_exact() else interval(0, W1 ** 2)
    sq2 = d2 ** 2 if d2.is_exact() else interval(0, W2 ** 2)
    P = f0 + g1 * d1 + g2 * d2 + H11 * sq1 / 2 + H12 * d1 * d2 + H22 * sq2 / 2
    return (P - R3).lower()


def box_r2_range(c1, c2, w1, w2):
    """(lower bound of min r^2, upper bound of max r^2) over the box, r^2 = y1^2 + y2^2."""
    dx = 0 if c1 - w1 <= 0 <= c1 + w1 else min(abs(c1 - w1), abs(c1 + w1))
    dy = 0 if c2 - w2 <= 0 <= c2 + w2 else min(abs(c2 - w2), abs(c2 + w2))
    rmin2 = (arb(dx) ** 2 + arb(dy) ** 2).lower()
    ex = max(abs(c1 - w1), abs(c1 + w1))
    ey = max(abs(c2 - w2), abs(c2 + w2))
    rmax2 = (arb(ex) ** 2 + arb(ey) ** 2).upper()
    return rmin2, rmax2
