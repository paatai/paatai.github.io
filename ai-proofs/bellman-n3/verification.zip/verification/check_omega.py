"""Lemma "omega" (computer-assisted part):  omega(q) >= -C_omega |q-U|^2  for |q-U| <= r_q.

omega(q) = V(w(q), q, q) - gamma S(q),  omega(U) = 0,  grad omega(U) = 0 (symmetry).
  * Inner disk r <= r0: omega(U + t v) = w2 t^2 + w3(xi; v) t^3 with w2 = (isotropic) second coefficient at
    U, and the third Taylor coefficient enclosed on polar boxes; so -omega/t^2 <= -w2 + r0 * M3.
  * r0 <= r <= r_q: F(q) = omega(q) + C r^2 >= 0 is certified by third-order Taylor forms on an adaptive
    quadtree covering the disk (no symmetry reduction).
"""
import sys
import time
import argparse
from flint import arb, ctx
from common import omega, r2, line_series, coeff, polar_point, interval, fmt, THIRD, E1, E2
from taylor2d import taylor_lb, box_r2_range
import params

ctx.prec = 128
PI = arb.pi()


def inner(r0, nth=720):
    U = [THIRD] * 3
    s1 = omega(line_series(U, E1, 3))
    s2 = omega(line_series(U, E2, 3))
    w2 = coeff(s1, 2)
    M3 = arb(0)
    for k in range(nth):
        th = interval(2 * PI * k / nth, 2 * PI * (k + 1) / nth)
        q, v = polar_point(interval(0, r0), th)
        c3 = coeff(omega(line_series(q, v, 4)), 3)
        M3 = max(M3, c3.abs_upper(), key=float)
    return dict(w0=coeff(s1, 0), w1=coeff(s1, 1), w2=w2, w2_E2=coeff(s2, 2), M3=M3, C_in=-w2 + arb(r0) * M3)


def quadtree(C, rq, r0, h0=1 / 128, min_w=1e-7):
    C = arb(C)
    fun = lambda q: omega(q) + C * r2(q)
    rq2, r02 = arb(rq) ** 2, arb(r0) ** 2
    n = int(rq / (2 * h0)) + 2
    stack = [((2 * i + 1) * h0, (2 * k + 1) * h0, h0, h0) for i in range(-n, n) for k in range(-n, n)]
    stats = dict(boxes=0, skipped=0, min_margin=None)
    fails = []
    t0 = time.time()
    while stack:
        c1, c2, w1, w2 = stack.pop()
        rmin2, rmax2 = box_r2_range(c1, c2, w1, w2)
        if rmin2 > rq2 or rmax2 < r02:
            stats['skipped'] += 1
            continue
        stats['boxes'] += 1
        lb = taylor_lb(fun, c1, c2, w1, w2)
        if lb >= 0:
            if stats['min_margin'] is None or lb < stats['min_margin']:
                stats['min_margin'] = lb
            continue
        if w1 < min_w:
            fails.append((c1, c2, w1))
            continue
        for s1 in (-0.5, 0.5):
            for s2 in (-0.5, 0.5):
                stack.append((c1 + s1 * w1, c2 + s2 * w2, w1 / 2, w2 / 2))
    stats['time'] = time.time() - t0
    return stats, fails


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--rq', type=float, default=float(arb(params.RQ).upper()))
    ap.add_argument('--C', default=params.C_OMEGA)
    ap.add_argument('--r0', type=float, default=float(params.R0_OMEGA))
    args = ap.parse_args()
    ind = inner(args.r0)
    print(f"omega at U: value {ind['w0'].str(3)}, first coefficient {ind['w1'].str(3)}, second coefficient "
          f"{fmt(ind['w2'], 10)} (along E2: {fmt(ind['w2_E2'], 10)})")
    print(f"inner disk r <= {args.r0}: M3 = {fmt(ind['M3'])}, -omega/r^2 <= {fmt(ind['C_in'])}")
    assert ind['C_in'] < arb(args.C)
    stats, fails = quadtree(args.C, args.rq, args.r0)
    print(f"disk {args.r0} <= r <= {args.rq}: omega + {args.C} r^2 >= 0 certified on {stats['boxes']} boxes "
          f"({stats['time']:.1f}s), min margin {fmt(stats['min_margin']) if stats['min_margin'] is not None else None}, "
          f"failures {len(fails)}")
    if not fails:
        print(f"=> C_omega = {args.C}")
    return 0 if not fails else 1


if __name__ == '__main__':
    sys.exit(main())
