"""Run every computer-assisted step of the proof of Theorem 1 and store the logs in results/.

    python run_all.py            (about 65 seconds)

Steps (see the appendix of bellman_n3.tex):
  taylor_symbolic.py   exact Taylor coefficients of Q and omega at the balanced point (sympy, exact field Q(ln2, ln3))
  check_Q.py           Proposition A: Q >= c4 r^4 near U, Q >= gamma/A0 elsewhere, vertex lemma constants (Arb)
  check_omega.py       Lemma omega: omega >= -C_omega r^2 (Arb)
  check_near.py        constants of the near case and the one-dimensional inequality in s (Arb)
"""
import os
import subprocess
import sys
import time

STEPS = ['taylor_symbolic.py', 'check_Q.py', 'check_omega.py', 'check_near.py']


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    os.makedirs(os.path.join(here, 'results'), exist_ok=True)
    ok = True
    for step in STEPS:
        t0 = time.time()
        p = subprocess.run([sys.executable, step], cwd=here, capture_output=True, text=True)
        log = os.path.join(here, 'results', step.replace('.py', '.txt'))
        with open(log, 'w') as f:
            f.write(p.stdout)
            if p.stderr:
                f.write('\n[stderr]\n' + p.stderr)
        status = 'OK' if p.returncode == 0 else f'FAILED (exit code {p.returncode})'
        print(f'{step:22s} {status:28s} {time.time() - t0:6.1f}s   log: results/{os.path.basename(log)}', flush=True)
        ok &= p.returncode == 0
    print('all checks passed' if ok else 'SOME CHECKS FAILED')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
