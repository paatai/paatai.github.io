"""Proposition A (computer-assisted part): lower bounds for the admissibility gap Q on the simplex.

Claims verified (q = U + y1 E1 + y2 E2, r = |q - U|; by the S_3-symmetry of Q it suffices to treat the
fundamental triangle F = {q1 >= q2 >= q3}, i.e. y1 >= 0, y2 >= y1/sqrt3, q3 >= 0):

  (i)   Q(q) >= c4 r^4           for r <= r_q,
  (ii)  Q(q) >= eps_Q = gamma/A0 for r >= r_q and 1 - max_j q_j >= sigma_V   (c4 r_q^4 >= eps_Q),
  (iii) Q(q) >= eps_V            for 1 - max_j q_j <= sigma_V   (Lemma "vertex", constants checked here).

Method.
  * Inner disk r <= r0: Q(U + t v) = q4 t^4 + Q5(xi; v) t^5 (Lagrange), where the coefficients of order
    <= 3 vanish and the quartic one is q4 |v|^4 (appendix, Lemma "Taylor expansion at U").  The 5th
    Taylor coefficient is enclosed on polar boxes.
  * Elsewhere: adaptive quadtree on F.  On each box either a plain ball evaluation, or a third-order
    Taylor form (exact quadratic Taylor polynomial at the centre, minimised over the box using
    monotonicity, plus a cubic remainder whose coefficients are enclosed on the whole box).
"""
import sys
import time
import argparse
from flint import arb, ctx
from common import (Q, r2, THIRD, E1, E2, SQ3, SQ6, C, K, LAM, lse_L, line_series, coeff, interval,
                    polar_point, fmt, GAM)
import params

ctx.prec = 128
PI = arb.pi()


def qpoint(y1, y2):
    return [THIRD + y1 * E1[j] + y2 * E2[j] for j in range(3)]


class Target:
    """f = Q - c4 r^4 (mode 'quartic') or f = Q - eps (mode 'eps')."""

    def __init__(self, c4, eps):
        self.c4, self.eps = arb(c4), eps

    def f(self, q, mode):
        if mode == 'quartic':
            return Q(q) - self.c4 * r2(q) ** 2
        return Q(q) - self.eps


def series_f(T, mode, y, d, n):
    base = qpoint(*y)
    dq = [d[0] * E1[j] + d[1] * E2[j] for j in range(3)]
    return T.f(line_series(base, dq, n), mode)


def taylor_lb(T, mode, c1, c2, w1, w2):
    """Rigorous lower bound of f on the box [c1-w1,c1+w1] x [c2-w2,c2+w2] (y-coordinates)."""
    yc = (arb(c1), arb(c2))
    s1 = series_f(T, mode, yc, (1, 0), 3)
    s2 = series_f(T, mode, yc, (0, 1), 3)
    sd = series_f(T, mode, yc, (1, 1), 3)
    f0, g1, g2 = coeff(s1, 0), coeff(s1, 1), coeff(s2, 1)
    H11, H22 = 2 * coeff(s1, 2), 2 * coeff(s2, 2)
    H12 = coeff(sd, 2) - (H11 + H22) / 2
    yb = (arb(c1, w1), arb(c2, w2))
    t1 = coeff(series_f(T, mode, yb, (1, 0), 4), 3)
    t2 = coeff(series_f(T, mode, yb, (0, 1), 4), 3)
    tp = coeff(series_f(T, mode, yb, (1, 1), 4), 3)
    tm = coeff(series_f(T, mode, yb, (1, -1), 4), 3)
    a = (tp - tm - 2 * t2) / 2
    b = (tp + tm - 2 * t1) / 2
    W1, W2 = arb(w1), arb(w2)
    R3 = (t1.abs_upper() * W1 ** 3 + a.abs_upper() * W1 ** 2 * W2 + b.abs_upper() * W1 * W2 ** 2
          + t2.abs_upper() * W2 ** 3)
    # minimise the quadratic Taylor polynomial over the box: monotone directions are fixed at a face
    d1, d2 = arb(0, w1), arb(0, w2)
    I1 = g1 + H11 * d1 + H12 * d2
    I2 = g2 + H12 * d1 + H22 * d2
    if I1 > 0:
        d1 = -W1
    elif I1 < 0:
        d1 = W1
    if I2 > 0:
        d2 = -W2
    elif I2 < 0:
        d2 = W2
    sq1 = d1 ** 2 if d1.is_exact() else interval(0, W1 ** 2)
    sq2 = d2 ** 2 if d2.is_exact() else interval(0, W2 ** 2)
    P = f0 + g1 * d1 + g2 * d2 + H11 * sq1 / 2 + H12 * d1 * d2 + H22 * sq2 / 2
    return (P - R3).lower()


def naive_lb(T, mode, q):
    return T.f(q, mode).lower()


def clip(q, sigV):
    """Intersect the coordinate balls with [0, 1 - sigV] (the part of the box that has to be checked)."""
    out = []
    cap = 1 - sigV
    for j in range(3):
        lo = q[j].lower()
        hi = q[j].upper()
        lo = lo if lo > 0 else arb(0)
        hi = hi if hi < cap else cap
        if hi < lo:
            return None
        out.append(interval(lo, hi))
    return out


def run_quadtree(T, rq, r0, sigV, h0=1 / 64, min_w=1e-6, verbose=True, full=False):
    """Cover F (or the whole simplex if full) minus {r < r0} minus the vertex regions by certified boxes."""
    rq, r0, sigV = arb(rq), arb(r0), arb(sigV)
    y1max = float((1 / arb(2).sqrt()).upper()) + 1e-12
    y2max = float((1 / SQ6).upper()) + 1e-12
    y2min = -float((2 / SQ6).upper()) - 1e-12 if full else 0.0
    y1min = -y1max if full else 0.0
    stack = []
    n1 = int((y1max - y1min) / (2 * h0)) + 1
    n2 = int((y2max - y2min) / (2 * h0)) + 1
    for i in range(n1):
        for k in range(n2):
            stack.append((y1min + (2 * i + 1) * h0, y2min + (2 * k + 1) * h0, h0, h0, 0))
    stats = dict(boxes=0, naive=0, taylor=0, skipped_outside=0, skipped_inner=0, skipped_vertex=0,
                 min_margin_quartic=None, min_margin_eps=None, maxdepth=0)
    t0 = time.time()
    failures = []
    while stack:
        c1, c2, w1, w2, depth = stack.pop()
        stats['maxdepth'] = max(stats['maxdepth'], depth)
        Y1 = arb(c1, w1)
        Y2 = arb(c2, w2)
        if full:
            qq = qpoint(Y1, Y2)
            if any(qj.upper() < 0 for qj in qq):
                stats['skipped_outside'] += 1
                continue
        # outside F ?  (q2 >= q3  <=>  y2 >= y1/sqrt3 ;  q3 >= 0  <=>  y2 <= 1/sqrt6)
        elif (Y2.upper() < Y1.lower() / SQ3) or (Y2.lower() > 1 / SQ6) or (Y1.upper() < 0):
            stats['skipped_outside'] += 1
            continue
        # inside the inner disk r < r0 ?
        corners = [(c1 + s1 * w1, c2 + s2 * w2) for s1 in (-1, 1) for s2 in (-1, 1)]
        rmax2 = max([(arb(a) ** 2 + arb(b) ** 2).upper() for a, b in corners], key=float)
        if rmax2 < r0 ** 2:
            stats['skipped_inner'] += 1
            continue
        q = qpoint(Y1, Y2)
        if any(qj.lower() > 1 - sigV for qj in q):
            stats['skipped_vertex'] += 1
            continue
        # distance of the box from the origin
        dx = 0 if c1 - w1 <= 0 <= c1 + w1 else min(abs(c1 - w1), abs(c1 + w1))
        dy = 0 if c2 - w2 <= 0 <= c2 + w2 else min(abs(c2 - w2), abs(c2 + w2))
        rmin2 = (arb(dx) ** 2 + arb(dy) ** 2).lower()
        mode = 'eps' if rmin2 >= rq ** 2 else 'quartic'
        qc = clip(q, sigV)
        if qc is None:
            stats['skipped_outside'] += 1
            continue
        stats['boxes'] += 1
        lb = naive_lb(T, mode, qc)
        ok = lb >= 0
        if ok:
            stats['naive'] += 1
        else:
            interior = all(qj.lower() > 0.002 for qj in q) and all(qj.upper() < 1 - sigV for qj in q)
            if interior:
                lb = taylor_lb(T, mode, c1, c2, w1, w2)
                ok = lb >= 0
                if ok:
                    stats['taylor'] += 1
        if ok:
            key = 'min_margin_' + mode
            if stats[key] is None or lb < stats[key]:
                stats[key] = lb
            continue
        if w1 < min_w:
            failures.append((c1, c2, w1, w2, mode, lb))
            continue
        for s1 in (-0.5, 0.5):
            for s2 in (-0.5, 0.5):
                stack.append((c1 + s1 * w1, c2 + s2 * w2, w1 / 2, w2 / 2, depth + 1))
        if verbose and stats['boxes'] % 2000 == 0:
            print(f"  ... {stats['boxes']} boxes, stack {len(stack)}, {time.time() - t0:.0f}s", flush=True)
    stats['time'] = time.time() - t0
    return stats, failures


def inner_disk(c4, r0, nth=120, full=False):
    """Q(U+tv) >= t^4 (q4 - t M5) for t <= r0 and all directions of the fundamental sector (or all)."""
    U = [THIRD] * 3
    q4 = coeff(Q(line_series(U, E1, 5)), 4)
    q4b = coeff(Q(line_series(U, E2, 5)), 4)
    lower_orders = [coeff(Q(line_series(U, E2, 5)), k) for k in range(4)]
    M5 = arb(0)
    a, b = (arb(0), 2 * PI) if full else (PI / 6, PI / 2)
    if full:
        nth *= 6
    for i in range(nth):
        th = interval(a + (b - a) * i / nth, a + (b - a) * (i + 1) / nth)
        q, v = polar_point(interval(0, r0), th)
        c5 = coeff(Q(line_series(q, v, 6)), 5)
        M5 = max(M5, c5.abs_upper(), key=float)
    bound = q4 - arb(r0) * M5
    return dict(q4=q4, q4_check=q4b, lower_orders=lower_orders, M5=M5, bound=bound, ok=bool(bound > c4))


def vertex_lemma(sigV):
    """Constants of Lemma 'vertex':  Q >= c - 1/2 - ln2/(4 ln(1/s)) - K L(1/2-e, 1/2+e, 0)  for s <= sigV."""
    s = arb(sigV)
    lns = (1 / s).log()
    corr_H = LAM / (4 * lns)
    e = (LAM + s / (4 * (1 - s))) / (4 * lns)
    Lval = lse_L([1 / arb(2) - e, 1 / arb(2) + e, arb(0)])
    epsV = C - 1 / arb(2) - corr_H - K * Lval
    return dict(sigV=s, corr_H=corr_H, e=e, KL=K * Lval, epsV=epsV)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--A0', default=params.A0)
    ap.add_argument('--c4', default=params.C4)
    ap.add_argument('--rq', default=params.RQ)
    ap.add_argument('--r0', type=float, default=float(params.R0_Q))
    ap.add_argument('--sigV', type=float, default=float(params.SIGMA_V))
    ap.add_argument('--h0', type=float, default=1 / 64)
    ap.add_argument('--full', action='store_true', help='cover the whole simplex (no symmetry reduction)')
    args = ap.parse_args()
    c4 = arb(args.c4)
    rq = arb(args.rq)
    epsQ = GAM / arb(args.A0)
    print(f'A0 = {args.A0}: eps_Q = gamma/A0 = {fmt(epsQ)}; c4 = {args.c4}, r_q = {args.rq}, '
          f'c4 r_q^4 = {fmt(c4 * rq ** 4)}')
    assert c4 * rq ** 4 >= epsQ
    vl = vertex_lemma(args.sigV)
    print(f"vertex lemma (sigma <= {args.sigV}): ln2/(4ln(1/s)) = {fmt(vl['corr_H'])}, e = {fmt(vl['e'])}, "
          f"K L = {fmt(vl['KL'])}  =>  Q >= {fmt(vl['epsV'])}")
    assert vl['epsV'] >= epsQ
    ind = inner_disk(c4, args.r0, full=args.full)
    print(f"inner disk r <= {args.r0}: q4 = {fmt(ind['q4'], 12)} (along E2: {fmt(ind['q4_check'], 12)}), "
          f"coefficients of order <= 3 along E2: {[c.str(3) for c in ind['lower_orders']]}")
    print(f"   M5 = {fmt(ind['M5'])},  q4 - r0 M5 = {fmt(ind['bound'])}  >= c4 : {ind['ok']}")
    assert ind['ok']
    T = Target(c4, epsQ)
    stats, failures = run_quadtree(T, rq, args.r0, args.sigV, h0=args.h0, full=args.full)
    print('quadtree:', {k: (fmt(v) if isinstance(v, arb) else v) for k, v in stats.items()})
    print('failures:', len(failures))
    for f in failures[:20]:
        print('   ', f)
    return 0 if not failures else 1


if __name__ == '__main__':
    sys.exit(main())
