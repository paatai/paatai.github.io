"""Case N of the proof of Theorem 1 (computer-assisted part): constants of the near regime and the final
one-dimensional inequality in s.

Notation as in the appendix of bellman_n3.tex:  r = |q - U|,  x = l/s (a point of the plane sum = 1),
w(q) = h(q)/S(q),  pi(x) = softmax(alpha x),  V(x,u,q) = (K alpha^2/2) sum_i q_i Var_{pi(x)}(g_i),
g_i = D^(i)(u) + d_i(u) x.  Near region:  r < RQ,  |u - q| < RU,  |x - w(q)| < RX.
All functions involved are invariant under the simultaneous permutation of coordinates, so suprema over
the q-disk are taken over the sector 30deg <= theta <= 90deg (q1 >= q2 >= q3).

Certified here (balls / Arb):
  (1) RW >= sup_{r <= RQ} |w(q) - U|                                     (Taylor forms on a quadtree)
  (2) LAMBDA <= inf_{|x-U| <= RW+RX} lambda_min(pi(x))   and   (K alpha^2/2) RX^2 LAMBDA >= gamma/A0
  (3) GX >= sup |P grad_x V(w(q),q,q)|,   GU >= sup |grad_u V(w(q),q,q)|  (Taylor forms on a quadtree)
  (4) M_xx >= sup ||P Hess_xx V(x,q,q) P||,  M_xu >= sup ||P Hess_xu V(x,q,q)||,
      C_2 >= sup max_k K alpha^2 (A_k^+/(q_k-RU)^2 + B_k^+/(1-q_k-RU)^2)
      over {r <= RQ} x {|x-U| <= RW+RX}               (interval evaluation of closed formulas on boxes)
  (5) elementary constants S_min, d_lo, d_hi, a, b', c_x
  (6) gamma S_min [m(s) - 1/(A0+s-d_hi)] - Def_om(m) - Def_x(m) - Def_u(m) > 0 for all s >= d_lo,
      m = m(s) = 2 phi(a/s)/s   (interval grid up to S_BIG, monotone tail beyond).
"""
import sys
import time
import argparse
from flint import arb, ctx
from common import (Q_parts, V_grads, THIRD, E1, E2, SQ2, SQ3, SQ6, ALPHA, K, GAM, MU, BMIN, interval, fmt)
from taylor2d import taylor_lb, box_r2_range, qpoint
import params

ctx.prec = 128
KA2 = K * ALPHA ** 2


# ----------------------------------------------------------------------------------------------
# quadtree over the sector {r <= R, 30deg <= theta <= 90deg} of the (y1, y2)-plane
# ----------------------------------------------------------------------------------------------
def sector_boxes(R, h0):
    R = float(arb(R).upper())
    n1 = int(R * 0.8660254 / (2 * h0)) + 1
    n2 = int(R / (2 * h0)) + 1
    return [((2 * i + 1) * h0, (2 * k + 1) * h0, h0, h0) for i in range(n1) for k in range(n2)]


def outside_sector(c1, c2, w1, w2, R2):
    rmin2, _ = box_r2_range(c1, c2, w1, w2)
    if rmin2 > R2:
        return True
    if c1 + w1 < 0:
        return True
    return (arb(c2 + w2) < arb(c1 - w1) / SQ3) is True


def certify_sector(lb_fun, R, h0=1 / 64, min_w=1e-6):
    """Check lb_fun(c1,c2,w1,w2) >= 0 on boxes covering the sector; bisect boxes that fail."""
    R2 = arb(R) ** 2
    stack = sector_boxes(R, h0)
    nbox, fails, minmargin = 0, [], None
    while stack:
        c1, c2, w1, w2 = stack.pop()
        if outside_sector(c1, c2, w1, w2, R2):
            continue
        nbox += 1
        lb = lb_fun(c1, c2, w1, w2)
        if lb >= 0:
            minmargin = lb if minmargin is None or lb < minmargin else minmargin
            continue
        if w1 < min_w:
            fails.append((c1, c2, w1, w2))
            continue
        for s1 in (-0.5, 0.5):
            for s2 in (-0.5, 0.5):
                stack.append((c1 + s1 * w1, c2 + s2 * w2, w1 / 2, w2 / 2))
    return nbox, fails, minmargin


# ----------------------------------------------------------------------------------------------
# (1) R_w,  (3) G_x, G_u
# ----------------------------------------------------------------------------------------------
def w_dev2(q):
    S, I, w = Q_parts(q)
    return (w[0] - THIRD) ** 2 + (w[1] - THIRD) ** 2 + (w[2] - THIRD) ** 2


def grad_sq(q):
    S, I, w = Q_parts(q)
    gx, gu, _, _, _ = V_grads(w, q, q)
    a = gx[0] * E1[0] + gx[1] * E1[1] + gx[2] * E1[2]
    b = gx[0] * E2[0] + gx[1] * E2[1] + gx[2] * E2[2]
    return a * a + b * b, gu[0] ** 2 + gu[1] ** 2 + gu[2] ** 2


def certify_upper(fun, target, R, h0):
    T2 = arb(target) ** 2
    return certify_sector(lambda c1, c2, w1, w2: taylor_lb(lambda q: T2 - fun(q), c1, c2, w1, w2), R, h0)


# ----------------------------------------------------------------------------------------------
# (2) lambda_min(pi(x)) = 6P/(T + sqrt(T^2 - 12P)),  T = 2 e_2(pi),  P = pi1 pi2 pi3
# ----------------------------------------------------------------------------------------------
def x_differences(Y1, Y2):
    """x1-x2, x1-x3, x2-x3 for x = U + Y1 E1 + Y2 E2 (computed without dependency)."""
    t = arb(3).sqrt() / SQ2
    return SQ2 * Y1, Y1 / SQ2 + t * Y2, -Y1 / SQ2 + t * Y2


def softmax_box(Y1, Y2):
    d12, d13, d23 = x_differences(Y1, Y2)
    ex = lambda z: (ALPHA * z).exp()
    p1 = 1 / (1 + ex(-d12) + ex(-d13))
    p2 = 1 / (1 + ex(d12) + ex(-d23))
    p3 = 1 / (1 + ex(d13) + ex(d23))
    return [p1, p2, p3]


def lam_min_lower(Y1, Y2):
    p = softmax_box(Y1, Y2)
    P = p[0] * p[1] * p[2]
    T = 2 * (p[0] * p[1] + p[0] * p[2] + p[1] * p[2])
    disc = (T * T - 12 * P).upper()
    sq = arb(disc).sqrt().upper() if disc > 0 else arb(0)
    return (6 * P).lower() / (T.upper() + sq)


def certify_lambda(LAM, R, h0=1 / 256):
    LAM = arb(LAM)

    def lb(c1, c2, w1, w2):
        return lam_min_lower(arb(c1, w1), arb(c2, w2)) - LAM
    return certify_sector(lb, R, h0)


# ----------------------------------------------------------------------------------------------
# (4) second-order quantities on boxes of the product region
# ----------------------------------------------------------------------------------------------
def sq(z):
    """Enclosure of z^2 (arb's z**2 is NaN for balls centred at 0, z*z ignores the sign)."""
    lo, hi = z.abs_lower(), z.abs_upper()
    return interval(lo * lo, hi * hi)


def up(z):
    """Upper bound of a ball as an exact ball; refuses non-finite input."""
    if not z.is_finite():
        raise ArithmeticError('non-finite enclosure')
    return z.upper()


def second_order_bounds(q, Yx1, Yx2, RU):
    """Upper bounds for ||P Hxx P||, ||P Hxu||, and max_k K a^2 (A_k^+/(q_k-RU)^2 + B_k^+/(1-q_k-RU)^2)
    at u = q, for q in the balls q[j] and x = U + Yx1 E1 + Yx2 E2.  Centred quantities are written as
    sums of differences (sum_k pi_k (f_j - f_k), the term k = j being exactly 0)."""
    p = softmax_box(Yx1, Yx2)
    xd = [Yx1 * E1[j] + Yx2 * E2[j] for j in range(3)]                    # x_j - 1/3
    d12, d13, d23 = x_differences(Yx1, Yx2)
    dif = [[arb(0), d12, d13], [-d12, arb(0), d23], [-d13, -d23, arb(0)]]  # x_j - x_k
    others = [[k for k in range(3) if k != j] for j in range(3)]
    xt = [sum(p[l] * dif[k][l] for l in others[k]) for k in range(3)]     # x_k - E_pi x
    Es = [E1, E2]
    et = [[sum(p[l] * (e[k] - e[l]) for l in others[k]) for k in range(3)] for e in Es]
    covee = [[sum(p[k] * et[a][k] * et[b][k] for k in range(3)) for b in range(2)] for a in range(2)]
    Hxx = [[arb(0), arb(0)], [arb(0), arb(0)]]
    Hxu = [[arb(0)] * 3 for _ in range(2)]
    zeta = []
    for i in range(3):
        D = [q[j].log() if j == i else (1 - q[j]).log() for j in range(3)]
        d = -(D[0] + D[1] + D[2])
        c = [sum(p[k] * (D[j] - D[k] + d * dif[j][k]) for k in others[j]) for j in range(3)]
        c2_ = [sq(cj) for cj in c]
        var = sum(p[j] * c2_[j] for j in range(3))
        coveg = [sum(p[k] * et[a][k] * c[k] for k in range(3)) for a in range(2)]
        for a in range(2):
            for b in range(a, 2):
                t4 = sum(p[k] * et[a][k] * et[b][k] * c2_[k] for k in range(3))
                t3 = sum(p[k] * et[a][k] * et[b][k] * c[k] for k in range(3))
                val = (ALPHA * ALPHA * (t4 - covee[a][b] * var - 2 * coveg[a] * coveg[b])
                       + 4 * ALPHA * d * t3 + 2 * d * d * covee[a][b])
                Hxx[a][b] = Hxx[a][b] + q[i] * val
        for m in range(3):
            eta = 1 / q[m] if i == m else -1 / (1 - q[m])
            gt = [eta * ((1 if k == m else 0) - p[m] - xt[k]) for k in range(3)]
            for a in range(2):
                t1 = sum(p[k] * et[a][k] * c[k] * gt[k] for k in range(3))
                t2 = sum(p[k] * et[a][k] * gt[k] for k in range(3))
                val = 2 * (ALPHA * t1 + d * t2 - eta * coveg[a])
                Hxu[a][m] = Hxu[a][m] + q[i] * val
        zeta.append([p[k] * c[k] - sum(p[l] * c[l] * xd[l] for l in range(3)) for k in range(3)])
    h = KA2 / 2
    a_, b_, c_ = h * Hxx[0][0], h * Hxx[0][1], h * Hxx[1][1]
    # ||[[a, b], [b, c]]|| = |a + c|/2 + sqrt(((a - c)/2)^2 + b^2)
    nxx = up((a_ + c_).abs_upper() / 2 + (sq((a_ - c_) / 2) + sq(b_)).upper().sqrt())
    # ||G||^2 = lambda_max(G G^T) <= (P + T)/2 + sqrt(((P - T)/2)^2 + R^2) with upper bounds of P, T, |R|
    G = [[h * Hxu[a][m] for m in range(3)] for a in range(2)]
    P_ = up(sum(sq(G[0][m]) for m in range(3)))
    T_ = up(sum(sq(G[1][m]) for m in range(3)))
    R_ = up(sum(G[0][m].abs_upper() * G[1][m].abs_upper() for m in range(3)))
    lam = (P_ + T_) / 2 + (sq((P_ - T_) / 2) + R_ * R_).sqrt()
    nxu = up(up(lam).sqrt())
    c2 = arb(0)
    for k in range(3):
        A = q[k] * zeta[k][k]
        B = sum(q[i] * zeta[i][k] for i in range(3) if i != k)
        Ap = max(up(A), arb(0), key=float)
        Bp = max(up(B), arb(0), key=float)
        val = KA2 * (Ap / sq(q[k] - RU) + Bp / sq(1 - q[k] - RU))
        c2 = max(c2, up(val), key=float)
    return nxx, nxu, c2


def product_sups(RQ, RXX, RU, hq, hx):
    RQ2, RXX2 = arb(RQ) ** 2, arb(RXX) ** 2
    qboxes = [b for b in sector_boxes(RQ, hq) if not outside_sector(*b, RQ2)]
    n = int(float(arb(RXX).upper()) / (2 * hx)) + 1
    xboxes = []
    for i in range(-n, n):
        for k in range(-n, n):
            c1, c2 = (2 * i + 1) * hx, (2 * k + 1) * hx
            if box_r2_range(c1, c2, hx, hx)[0] <= RXX2:
                xboxes.append((c1, c2))
    Mxx = Mxu = C2 = arb(0)
    for (c1, c2, w1, w2) in qboxes:
        q = qpoint(arb(c1, w1), arb(c2, w2))
        for (x1, x2) in xboxes:
            nxx, nxu, c2v = second_order_bounds(q, arb(x1, hx), arb(x2, hx), RU)
            Mxx = max(Mxx, nxx, key=float)
            Mxu = max(Mxu, nxu, key=float)
            C2 = max(C2, c2v, key=float)
    return dict(Mxx=Mxx, Mxu=Mxu, C2=C2, nq=len(qboxes), nx=len(xboxes))


# ----------------------------------------------------------------------------------------------
# (6) the one-dimensional inequality
# ----------------------------------------------------------------------------------------------
def phi(t):
    return (t - 1 + (-t).exp()) / t ** 2


def max_lin_quad(mG, Cq, r):
    """Upper bound of max_{0 <= rho <= r} (mG rho - Cq rho^2)."""
    at_r = mG * r - Cq * r ** 2
    if Cq > 0:
        # the vertex value bounds the maximum over [0, inf); if the vertex lies beyond r the maximum is at r
        return at_r if mG > 2 * Cq * r else mG ** 2 / (4 * Cq)
    if Cq <= 0 or mG > 2 * arb(Cq.upper()) * r:
        return at_r
    raise ValueError('ambiguous sign of the quadratic coefficient')


class OneD:
    def __init__(self, k):
        self.k = k

    def m(self, s):
        return 2 * phi(self.k['a'] / s) / s

    def deficits(self, m):
        k = self.k
        z = m * k['Com'] / (2 * k['Smin'] * k['c4'])          # vertex of m C z - S c4 z^2, z = r^2
        if z <= k['RQ'] ** 2:
            dom = (m * k['Com']) ** 2 / (4 * k['Smin'] * k['c4'])
        elif z > k['RQ'] ** 2:
            dom = m * k['Com'] * k['RQ'] ** 2 - k['Smin'] * k['c4'] * k['RQ'] ** 4
        else:
            dom = (m * k['Com']) ** 2 / (4 * k['Smin'] * k['c4'])
        th = k['RU'] / k['RX']
        Cx = k['cx'] - m * (k['Mxx'] + th * k['Mxu']) / 2
        Cu = 2 * k['bp'] - m * (k['C2'] + k['Mxu'] / th) / 2
        dx = max_lin_quad(m * k['Gx'], Cx, k['RX'])
        du = max_lin_quad(m * k['Gu'], Cu, k['RU'])
        return dom, dx, du

    def check_interval(self, s1, s2):
        k = self.k
        gain = GAM * k['Smin'] * (self.m(s2) - 1 / (k['A0'] + s1 - k['dhi']))
        dom, dx, du = self.deficits(self.m(s1))
        return gain, dom + dx + du, (dom, dx, du)

    def tail(self, s_big):
        k = self.k
        mb = self.m(arb(s_big))
        th = k['RU'] / k['RX']
        Cx = k['cx'] - mb * (k['Mxx'] + th * k['Mxu']) / 2
        Cu = 2 * k['bp'] - mb * (k['C2'] + k['Mxu'] / th) / 2
        assert Cx > 0 and Cu > 0
        Rbar = k['Com'] ** 2 / (4 * k['Smin'] * k['c4']) + k['Gx'] ** 2 / (4 * Cx) + k['Gu'] ** 2 / (4 * Cu)
        a, A0, dhi, s = k['a'], k['A0'], k['dhi'], arb(s_big)
        lhs = GAM * k['Smin'] * (s * (A0 - dhi - a / 3) - a / 3 * (A0 - dhi)) / (A0 + s - dhi)
        return lhs, Rbar, GAM * k['Smin'] * (A0 - dhi - a / 3)


def run_1d(k, s_big=2e4, ratio=1.002):
    od = OneD(k)
    s = k['dlo'].lower()
    worst = None
    n = 0
    t0 = time.time()
    while s < s_big:
        s2 = s * ratio
        gain, deff, parts = od.check_interval(arb(s), arb(s2))
        margin = gain - deff
        if not margin > 0:
            return dict(ok=False, s=s, gain=gain, deficit=deff, parts=parts)
        rel = (deff / gain).upper()
        if worst is None or rel > worst[0]:
            worst = (rel, s, gain, deff, parts)
        s = s2
        n += 1
    lhs, Rbar, asym = od.tail(s_big)
    return dict(ok=bool(lhs > Rbar), n=n, worst=worst, tail_lhs=lhs, tail_R=Rbar, asym=asym,
                time=time.time() - t0)


# ----------------------------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--hq', type=float, default=0.005)
    ap.add_argument('--hx', type=float, default=0.0015)
    ap.add_argument('--skip-product', action='store_true')
    args = ap.parse_args()
    t_start = time.time()
    A0, c4, RQ = arb(params.A0), arb(params.C4), arb(params.RQ)
    Com, RX = arb(params.C_OMEGA), arb(params.RX)
    RW, LAMB, GX, GU = arb(params.RW), arb(params.LAMBDA), arb(params.GX), arb(params.GU)
    eps = GAM / A0
    assert c4 * RQ ** 4 >= eps
    RU = (GAM * MU / (2 * A0 * (BMIN - eps))).sqrt()
    print(f"A0 = {params.A0}, c4 = {params.C4}, r_q = {params.RQ}, C_omega = {params.C_OMEGA}, r_x = {params.RX}")
    print(f"r_u = sqrt(gamma mu / (2 A0 (b_min - gamma/A0))) = {fmt(RU)}")

    # (5) elementary constants
    t0 = THIRD - (arb(2) / 3).sqrt() * RQ
    Smin = MU - RQ ** 2 / (2 * t0 * (1 - t0))
    du_ = (arb(2) / 3).sqrt() * RQ + RU
    dhi = -(THIRD - du_).log() - 2 * (2 * THIRD - du_).log()
    dlo = -(THIRD + du_).log() - 2 * (2 * THIRD + du_).log()
    bp = BMIN - GAM / (A0 + dlo - dhi)
    RXX = RW + RX
    a = ALPHA * (((2 * THIRD + du_) / (THIRD - du_)).log() + SQ2 * dhi * RXX)
    print(f"S_min = {fmt(Smin)}, delta_u = {fmt(du_)}, d_lo = {fmt(dlo)}, d_hi = {fmt(dhi)}, "
          f"a = {fmt(a)}, b' = {fmt(bp)}")

    # (1) R_w
    nb, fails, mm = certify_upper(w_dev2, RW, RQ, 1 / 64)
    print(f"(1) sup |w(q)-U| <= {params.RW}: {nb} boxes, failures {len(fails)}")
    assert not fails
    # (2) lambda_min and the radius r_x of case F3
    nb, fails, mm = certify_lambda(LAMB, RXX)
    f3 = KA2 / 2 * RX ** 2 * LAMB
    print(f"(2) lambda_min(pi(x)) >= {params.LAMBDA} on |x-U| <= {fmt(RXX)}: {nb} boxes, failures {len(fails)}; "
          f"(K a^2/2) r_x^2 Lambda = {fmt(f3)} >= gamma/A0 = {fmt(eps)}: {bool(f3 >= eps)}")
    assert not fails and f3 >= eps
    cx = KA2 / 2 * Smin * LAMB
    print(f"    c_x = (K a^2/2) S_min Lambda = {fmt(cx)}")
    # (3) G_x, G_u
    nb, fails, mm = certify_upper(lambda q: grad_sq(q)[0], GX, RQ, 1 / 64)
    print(f"(3) sup |P grad_x V(w,q,q)| <= {params.GX}: {nb} boxes, failures {len(fails)}")
    assert not fails
    nb, fails, mm = certify_upper(lambda q: grad_sq(q)[1], GU, RQ, 1 / 64)
    print(f"    sup |grad_u V(w,q,q)| <= {params.GU}: {nb} boxes, failures {len(fails)}")
    assert not fails
    # (4) second-order quantities
    if args.skip_product:
        so = dict(Mxx=arb(150), Mxu=arb(40), C2=arb(2), nq=0, nx=0)
        print("(4) SKIPPED (placeholder values)")
    else:
        t1 = time.time()
        so = product_sups(RQ, RXX, RU, args.hq, args.hx)
        print(f"(4) {so['nq']} q-boxes x {so['nx']} x-boxes ({time.time() - t1:.0f}s): M_xx <= {fmt(so['Mxx'])}, "
              f"M_xu <= {fmt(so['Mxu'])}, C_2 <= {fmt(so['C2'])}")
    # (6) one-dimensional inequality
    k = dict(A0=A0, c4=c4, RQ=RQ, Com=Com, RX=RX, RU=RU, Smin=Smin, dlo=dlo, dhi=dhi, a=a, bp=bp, cx=cx,
             Gx=GX, Gu=GU, Mxx=so['Mxx'], Mxu=so['Mxu'], C2=so['C2'])
    res = run_1d(k)
    if not res['ok']:
        print("(6) FAILED", res)
        return 1
    rel, s_w, g_w, d_w, parts = res['worst']
    print(f"(6) {res['n']} s-intervals on [d_lo, 2e4] ({res['time']:.1f}s): worst deficit/gain = {float(rel):.4f} "
          f"at s = {float(s_w):.3f} (gain {fmt(g_w, 5)}, deficits omega/x/u = "
          f"{', '.join(fmt(p_, 4) for p_ in parts)})")
    print(f"    tail s >= 2e4: s^2-gain >= {fmt(res['tail_lhs'])} > R = {fmt(res['tail_R'])}; "
          f"asymptotic gain gamma S_min (A0 - d_hi - a/3) = {fmt(res['asym'])}")
    print(f"total time {time.time() - t_start:.0f}s")
    return 0


if __name__ == '__main__':
    sys.exit(main())
