# Lean 4 formalization of the Keller–Klein bound for Rademacher sums

This Lean 4 + Mathlib project proves the Keller–Klein Berry–Esseen conjecture for normalized
Rademacher sums. The proof has no `sorry`, depends only on Lean's standard axioms, and uses
no `native_decide`.

For every `n`, every `a₁, …, aₙ` with `a₁² + ⋯ + aₙ² = 1`, every level `a ≥ maxᵢ |aᵢ|` and
every real `x`,

    |P[X ≤ x] − Φ(x)| ≤ Φ(a) − 1/2   and   |P[X < x] − Φ(x)| ≤ Φ(a) − 1/2,

where `X = a₁ε₁ + ⋯ + aₙεₙ` with independent uniform signs `εᵢ = ±1`. With `a = maxᵢ |aᵢ|`
the right-hand side is `P[Z ∈ (0, a)]` for `Z ~ N(0, 1)`.

## The main theorem

`KellerKlein.keller_klein` in `KellerKlein/Full/Final.lean`:

```lean
theorem keller_klein {n : ℕ} (coeff : Fin n → ℝ) (hvar : ∑ i, coeff i ^ 2 = 1) {a : ℝ}
    (hca : ∀ i, |coeff i| ≤ a) (x : ℝ) :
    |rademacherCDF coeff x - cdf (gaussianReal 0 1) x| ≤ cdf (gaussianReal 0 1) a - 1 / 2 ∧
      |rademacherStrictCDF coeff x - cdf (gaussianReal 0 1) x| ≤
        cdf (gaussianReal 0 1) a - 1 / 2
```

`keller_klein_max` in the same file states the same bound with `a = |coeff i₀|` for an index
`i₀` of maximal modulus.

The objects in the statement are elementary and are printed by `KellerKlein/Full/FinalAudit.lean`:

- `BoolCube n = Fin n → Bool`. `cubeProbability p` is the number of `ω` with `p ω`, divided by `2ⁿ`.
- `rademacherSign b = if b then 1 else -1` and `rademacherSum c ω = ∑ i, c i * rademacherSign (ω i)`.
- `rademacherCDF c x = cubeProbability (fun ω => rademacherSum c ω ≤ x)`; `rademacherStrictCDF` uses `<`.
- `cdf (gaussianReal 0 1)` is Mathlib's distribution function of the standard normal law.

## Building

Requirements:

- [elan](https://github.com/leanprover/elan), the Lean version manager;
- network access for the Mathlib cache;
- about 10 GB of disk;
- several cores and plenty of memory: each certificate module needs up to about 7 GB
  (see the note on resources below).

Lean is pinned to `v4.19.0` in `lean-toolchain`. Mathlib is pinned to commit
`c44e0c8ee63ca166450922a373c7409c5d26b00b` in `lakefile.lean` and `lake-manifest.json`.

```bash
curl https://raw.githubusercontent.com/leanprover/elan/master/elan-init.sh -sSf \
  | sh -s -- -y --default-toolchain none
source ~/.elan/env
cd lean
lake exe cache get   # prebuilt Mathlib
lake build
```

A successful build ends with `Build completed successfully.`. On a machine with 8 cores and
47 GB of memory, `lake exe cache get` took 38 seconds on a fresh clone, and a clean
`lake build` of all 125 modules took 18 minutes of wall-clock time (111 minutes of CPU time).
The new modules (`Full/`, `Num/`) build without warnings. The build prints 70 style-linter
warnings (for example "Used `tac1 <;> tac2` where `(tac1; tac2)` would suffice"), all from
Dev Goyal's modules, which are kept byte-identical to the published files; they do not
affect the proof.

**Resources.** The 32 certificate modules `KellerKlein/Num/Cert/*.lean` account for almost
all of the build time. Each one is checked by kernel evaluation; `KellerKlein/Num/Cert/U00.lean`
alone takes about 3.3 minutes and peaks at 6.9 GB of resident memory. Lake builds as many
modules in parallel as the machine has cores. On a machine with less memory, build the
certificate modules a few at a time by naming them as targets, then run `lake build`:

```bash
lake build KellerKlein.Num.Cert.U00 KellerKlein.Num.Cert.U01   # and so on
```

## Checking the result

1. **Build.** `lake build` succeeds. The build output includes the axiom audit from
   `KellerKlein/Full/FinalAudit.lean`:

   ```
   'KellerKlein.keller_klein' depends on axioms: [propext, Classical.choice, Quot.sound]
   ```

   To re-run the audit alone, use `lake env lean KellerKlein/Full/FinalAudit.lean`.

2. **No escape hatches.** Run the following from `lean/`:

   ```bash
   grep -rnwE "sorry|admit|native_decide|implemented_by|extern" KellerKlein
   grep -rnE "^\s*(axiom|unsafe|@\[extern)" KellerKlein
   ```

   Both commands print nothing. The computer-assisted inequalities are proved with
   `decide +kernel`: the Lean kernel itself evaluates the Boolean checkers. The compiler and
   `Lean.ofReduceBool` are not involved.

3. **Independent kernel replay.** Run [lean4checker](https://github.com/leanprover/lean4checker)
   at the tag matching the toolchain (`v4.19.0`):

   ```bash
   git clone --branch v4.19.0 https://github.com/leanprover/lean4checker ../lean4checker
   (cd ../lean4checker && lake build)
   lake env ../lean4checker/.lake/build/bin/lean4checker --fresh KellerKlein.Full.FinalAudit
   ```

   `--fresh` replays every declaration in the environment of `KellerKlein.Full.FinalAudit`
   (all of Mathlib, the project, and the final theorem) in a new kernel environment, in a
   single thread. `--fresh` accepts exactly one module. `KellerKlein.Full.FinalAudit` imports
   the final theorem, so it is the right one to pass. Passing `KellerKlein` does not work: it
   is treated as a module prefix and rejected. On the machine above, this command finished
   with exit code 0 and no output (no declaration rejected). On the current build it took
   2 h 15 min of wall-clock time and at most 6.85 GB of resident memory. See `../STATUS.md`.

## How the proof is organized

The 61 modules under `KellerKlein/` that are not in `Full/` or `Num/` are Dev Goyal's
formalization of the upper half for `maxᵢ |aᵢ| ≤ 0.07`. They are included unchanged
(byte-identical) from
<https://github.com/dvgyl/math-and-theory/tree/main/papers/mathematics/keller-klein>.
They provide Prawitz's smoothing inequality, the characteristic-function envelopes, the
envelope integral `JUpper`, the Hölder reduction near the origin, and the Gaussian
decomposition. The root file `KellerKlein.lean` imports the three modules that Goyal's root
file imports (`Main`, `Nonvacuity`, `Audit`); his two modules `FarTail` and `ZoneAAudit`,
which no other module imports; and `KellerKlein.Full`, through which all new modules are
imported. So `lake build` compiles every module, 125 in all. The new modules are listed
below.

| module | content |
| --- | --- |
| `Full/Reduction.lean` | both CDF conventions at every real `x` follow from (U) `P[|X| ≤ x] ≤ H(a) + H(x)` and (L) `P[|X| < x] ≥ H(x) − H(a)` (`H = 2Φ − 1`) |
| `Full/LowerPrawitz.lean` | Prawitz at the negative location: `P[|X| < x] ≥ −2 J(a, −x)`, so both halves reduce to `J(a, y) ≤ c(a) + c(y)` |
| `Full/Hoeffding.lean` | `P[|X| ≥ s] ≤ 2 e^{−s²/2}`; rescaling the remainder sum |
| `Full/Peeling.lean` | peeling identities for `X = a ε + Y` |
| `Full/Induction.lean` | the structure `Pieces` (seven explicit inequalities) and the strong induction on `n` |
| `Full/MainConditional.lean` | the conjecture from `Pieces` |
| `Full/Wallis.lean` | `V(N) = ∫₀^{1/2} cos(πu)^N du` satisfies `V(N)² ≤ 1/(2π(N + 1/2))` for real `N ≥ 1/2` |
| `Full/ZoneAPoly.lean` | `π u ρ(u) ≤ 1 − (5/2)u² + u³ + u⁴/2`, the affine kernel majorant, concavity of `c` |
| `Full/ZoneARay.lean` | derivative of the profile integral in `a` (dominated differentiation and integration by parts), monotonicity along the ray |
| `Full/ZoneADiagonal.lean` | the diagonal `a = b` via the Wallis bound |
| `Full/ZoneAGeneral.lean` | (U) for `0 ≤ x ≤ a/2` and every `a < 0.675`, analytically |
| `Full/Master.lean` | the master decomposition `J − c(a) − c(y) ≤ ∫₀¹ g − Θ + tails`, with cancellation-free region formulas |
| `Full/LowerSmall.lean` | (L) for `a ≤ 1/10`, analytically (Dev Goyal's decomposition at `y = −x`) |
| `Full/PeelNearSmall.lean` | the near-diagonal peeling inequality for `a ≤ 0.3`, analytically |
| `Full/PeelPieces.lean` | the peeling fields of `Pieces` |
| `Full/Final.lean` | `pieces : Pieces` and the unconditional theorem `keller_klein` |
| `Full/FinalAudit.lean` | `#print axioms` and the definitions in the statement |
| `Num/Ball.lean` | fixed-point ball arithmetic on natural numbers (scale `2⁶⁴`), with soundness lemmas |
| `Num/Series.lean`, `Num/Elem.lean` | Taylor series on balls; `π`, `cos`, `sin`, `exp`, `log`, `√` and reciprocals on balls |
| `Num/Special.lean` | `D(y) = 1 − y cot y`, `E(y) = −log cos y − y²/2`, and the cotangent remainder |
| `Num/CellDefs.lean`, `Num/CellSound.lean` | the computable box check for the envelope inequalities and its soundness |
| `Num/Cover.lean`, `Num/CoverSound.lean` | groups of boxes, end conditions, gluing in `ξ = x/a` and in `a` |
| `Num/GaussCDF.lean` | certified values of `c(t) = Φ(t) − 1/2` by alternating series |
| `Num/Peel.lean`, `Num/PeelCert.lean` | box checks for the peeling inequalities, their soundness, and the 105 kernel-checked boxes; `c(0.675) ≥ 1/4` |
| `Num/Cert/U00–U15`, `Num/Cert/L00–L15`, `Num/Cert/All.lean` | the kernel-checked covers: (U) on `0.07 ≤ a ≤ 0.5` (67 groups, 790 boxes, 65 736 cell bounds) and (L) on `0.1 ≤ a ≤ 0.55` (58 groups, 913 boxes, 75 584 cell bounds), in 454 `decide +kernel` declarations |
| `Num/Fourier.lean` | the covers restated on the decimal ranges of `Pieces` |

The case analysis in `halves_of_pieces` (`Full/Induction.lean`), with `a` the largest
|coefficient|:

| half | range | proof |
| --- | --- | --- |
| (U) | `a ≥ 0.675` | elementary, from `c(0.675) ≥ 1/4` |
| (U) | `a < 0.675`, `x ≤ a/2` | analytic (`Full/ZoneA*.lean`, `Full/Wallis.lean`) |
| (U) | `a ≤ 0.07` | Dev Goyal's theorem `small_coefficient_upper_concentration` |
| (U) | `0.07 < a ≤ 0.5`, `x ≥ a/2`, `H(x) + H(a) < 1` | `J(a, x) ≤ c(a) + c(x)`: kernel-checked cover |
| (U) | `0.5 < a < 0.675`, `x ≥ a/2`, `H(x) + H(a) < 1` | peeling and induction: kernel-checked cover |
| (U) | `H(x) + H(a) ≥ 1` | trivial |
| (L) | `e^{−x²/2} ≤ c(a)` | Hoeffding |
| (L) | `a ≥ 0.55` | peeling and induction: kernel-checked cover |
| (L) | `a < 0.55`, `a < x ≤ 3a/2` | peeling and induction: analytic for `a ≤ 0.3`, kernel-checked cover above |
| (L) | `a ≤ 0.1`, `x > 3a/2` | analytic (`Full/LowerSmall.lean`) |
| (L) | `0.1 < a < 0.55`, `x > 3a/2` | `J(a, −x) ≤ c(a) − c(x)`: kernel-checked cover |

## The certificates

`certs/` holds the data behind the generated modules.

- `certs/c_<half>_<first group>.txt` lists the (U) covers (half `0`) and the (L) covers (half `1`)
  as groups `(k0, k1, n_lobe, [m0, …, mK])`. The largest coefficient ranges over
  `[k0·2⁻³², k1·2⁻³²]`, and `ξ = x/a` ranges over the boxes `[mᵢ·2⁻¹⁶, mᵢ₊₁·2⁻¹⁶]`. The
  matching `certs/log_*.txt` are the search logs.
- `certs/peel_L_large.txt`, `certs/peel_L_near.txt` and `certs/peel_U.txt` are the peeling covers.
- `certs/gen_lean.py` and `certs/gen_peel.py` generate `KellerKlein/Num/Cert/*.lean` and
  `KellerKlein/Num/PeelCert.lean` from the data (`python3 certs/gen_lean.py`,
  `python3 certs/gen_peel.py`).
- `certs/search/FourierSearch.lean` and `certs/search/PeelSearch.lean` are the search drivers.
  They run the same computable checkers with `#eval`.

The covers are trusted only after the kernel evaluates them during `lake build`; the search
drivers just propose them. The envelope covers were produced from `lean/` with:

```bash
# (U): groups [0,17), [17,34), [34,51), [51,∞)
LOWER=0 KMIN=300647710 KMAX=2147483648 I0=0 I1=17 OUT=certs/c_0_0.txt \
  lake env lean certs/search/FourierSearch.lean
# (L): groups [0,15), [15,30), [30,45), [45,∞)
LOWER=1 KMIN=429496729 KMAX=2362232013 I0=0 I1=15 OUT=certs/c_1_0.txt \
  lake env lean certs/search/FourierSearch.lean
```

These runs use the default grid parameters (`NUM/DEN = 103/100`, `NL = 40`, `WIDTH = 2¹⁸`,
`MINW = 64`). The peeling commands are listed in the header of `certs/search/PeelSearch.lean`.

## Credits and licenses

- The modules outside `Full/` and `Num/` are Dev Goyal's Lean formalization of the
  small-coefficient upper half (Apache-2.0). Its license is in `LICENSE-dvgyl-keller-klein`.
- Three of those modules (`Vendor/`) are ports of files from CausalSmith (Apache-2.0).
  `third_party/causalsmith/` keeps their license, notice, the original files and a
  description of the changes.
- The recurrence-and-limit argument behind Prawitz's majorant (`PrawitzRecurrence.lean`,
  `PrawitzOscillation.lean`, `PrawitzLimit.lean`, `PrawitzMajorant.lean`) comes from the
  public CoolRmal/BerryEsseen project, <https://github.com/CoolRmal/BerryEsseen> (commit
  `bfb2260`). Goyal's Lean proof formalizes it independently; no code was copied
  (`third_party/causalsmith/UPSTREAM.txt`).
- The rest of the project is new. The mathematics is described in `../paper/`.
