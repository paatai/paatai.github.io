import KellerKlein.Num.Cover
open KellerKlein.Num Ball

/-! Search driver for the Fourier (envelope) covers `certs/c_<half>_<start>.txt` (not part of
the proof: the covers are only trusted after kernel evaluation in `KellerKlein/Num/Cert`).
It runs the computable checker `boxOk` of `KellerKlein/Num/Cover.lean` and writes the groups
`(k0, k1, n_lobe, [m0, ..., mK])`.  Parameters are read from the environment (`LOWER`,
`KMIN`, `KMAX`, `NUM`/`DEN` for the geometric `a`-grid, `NL`, `WIDTH`, `MINW`, `I0`/`I1` for a
range of groups, `OUT`); run with `lake env lean certs/search/FourierSearch.lean`. -/

/-- a-endpoints `k_j` (units `2⁻³²`), geometric with ratio `num/den`, ending exactly at `kMax`. -/
partial def aEndpoints (k kMax num den : ℕ) (acc : Array ℕ) : Array ℕ :=
  if k ≥ kMax then acc.push kMax
  else
    let k' := Nat.max (k * num / den) (k + 1)
    if k' ≥ kMax then (acc.push k).push kMax else aEndpoints k' kMax num den (acc.push k)

/-- Smallest `m` (units `2⁻¹⁶`, multiple of `step`) with `endOk`. -/
partial def findEnd (lower : Bool) (pa0 : ℕ) (m step : ℕ) : ℕ :=
  if endOk lower pa0 m then m else findEnd lower pa0 (m + step) step

structure Stats where
  evals : ℕ := 0
  fails : List (ℕ × ℕ) := []

/-- Breakpoints after `m0` covering `[m0, m1]` by passing boxes. -/
partial def coverIv (lower : Bool) (pa0 pa1 : ℕ) (grid : List ℕ) (minW : ℕ) (m0 m1 : ℕ) :
    StateM Stats (List ℕ) := do
  modify fun s => { s with evals := s.evals + 1 }
  if boxOk lower pa0 pa1 (m0 * xiUnit) (m1 * xiUnit) grid then
    return [m1]
  else if m1 - m0 ≤ minW then
    modify fun s => { s with fails := (m0, m1) :: s.fails }
    return [m1]
  else
    let mid := (m0 + m1) / 2
    let l ← coverIv lower pa0 pa1 grid minW m0 mid
    let r ← coverIv lower pa0 pa1 grid minW mid m1
    return l ++ r

def coverGroup (lower : Bool) (k0 k1 nl width minW : ℕ) : List ℕ × Stats :=
  let pa0 := k0 * aUnit
  let pa1 := k1 * aUnit
  let grid := gridGen pa0 nl
  let mS := xi0 lower
  let mE := findEnd lower pa0 mS 1024
  let rec go (m : ℕ) (fuel : ℕ) : StateM Stats (List ℕ) := do
    match fuel with
    | 0 => return []
    | f + 1 =>
      if m ≥ mE then return []
      else
        let m' := Nat.min (m + width) mE
        let l ← coverIv lower pa0 pa1 grid minW m m'
        let r ← go m' f
        return l ++ r
  let (bps, st) := (go mS 100000).run {}
  (mS :: bps, st)

def runSearch (lower : Bool) (kMin kMax num den nl width minW i0 i1 : ℕ) (out : String) : IO Unit := do
  let eps := aEndpoints kMin kMax num den #[]
  let h ← IO.FS.Handle.mk out IO.FS.Mode.write
  let mut totalBoxes := 0
  let mut totalEvals := 0
  let mut totalCells := 0
  for i in [i0:Nat.min i1 (eps.size - 1)] do
    let k0 := eps[i]!
    let k1 := eps[i+1]!
    let t0 ← IO.monoMsNow
    let (bps, st) := coverGroup lower k0 k1 nl width minW
    let t1 ← IO.monoMsNow
    let nb := bps.length - 1
    let nc := (gridGen (k0 * aUnit) nl).length
    totalBoxes := totalBoxes + nb
    totalEvals := totalEvals + st.evals
    totalCells := totalCells + nb * nc
    h.putStrLn s!"  ({k0}, {k1}, {nl}, {bps}),"
    h.flush
    IO.eprintln s!"group {i}: a=[{k0.toFloat / 4294967296.0}, {k1.toFloat / 4294967296.0}] boxes={nb} evals={st.evals} cells/box={nc} fails={st.fails.length} {st.fails} ({t1 - t0} ms)"
  IO.eprintln s!"TOTAL groups={Nat.min i1 (eps.size - 1) - i0} boxes={totalBoxes} evals={totalEvals} leafCells={totalCells}"

def envNat (n : String) (d : ℕ) : IO ℕ := do
  match (← IO.getEnv n) with
  | some s => return s.toNat!
  | none => return d

#eval show IO Unit from do
  let lower := (← envNat "LOWER" 0) == 1
  let kMin ← envNat "KMIN" 300647710
  let kMax ← envNat "KMAX" 2147483648
  let num ← envNat "NUM" 103
  let den ← envNat "DEN" 100
  let nl ← envNat "NL" 40
  let width ← envNat "WIDTH" 262144
  let minW ← envNat "MINW" 64
  let i0 ← envNat "I0" 0
  let i1 ← envNat "I1" 1000
  let out := (← IO.getEnv "OUT").getD "/tmp/cover.txt"
  runSearch lower kMin kMax num den nl width minW i0 i1 out
