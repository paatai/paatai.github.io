import KellerKlein.Num.Peel
open KellerKlein.Num Ball

/-! Search driver for the peeling covers `certs/peel_*.txt` (not part of the proof: the covers
are only trusted after kernel evaluation in `KellerKlein/Num/PeelCert.lean`).  Runs the
computable box checkers of `KellerKlein/Num/Peel.lean` and writes the groups
`(k0, k1, [m0, ..., mK])`.  The committed covers were produced with

* `FAM=0 KMIN=2362232012 KMAX=4294967296 WIDTH=32768 W=171798692 WMAX=687194767`
  (`peel_L_large.txt`);
* `FAM=1 KMIN=1288490188 KMAX=2362232013 WIDTH=4096` (`peel_L_near.txt`);
* `FAM=2 KMIN=2147483648 KMAX=2899102925 WIDTH=4096` (`peel_U.txt`);

and `OUT=<file> lake env lean certs/search/PeelSearch.lean`. -/

def famBox (fam : ℕ) (pa0 pa1 m0 m1 : ℕ) : Bool :=
  if fam == 2 then peelUBox pa0 pa1 (m0 * xiUnit) (m1 * xiUnit)
  else peelLBox pa0 pa1 (m0 * xiUnit) (m1 * xiUnit)

def famStart (fam : ℕ) (pa0 : ℕ) : ℕ :=
  if fam == 2 then pa0 / (2 * xiUnit) else 0

partial def findEndL (pa0 m step : ℕ) : ℕ :=
  if endLLarge pa0 m then m else findEndL pa0 (m + step) step

partial def findEndU (pa0 m step : ℕ) : ℕ :=
  if endU pa0 m then m else findEndU pa0 (m + step) step

def famEnd (fam : ℕ) (pa0 pa1 : ℕ) : ℕ :=
  if fam == 0 then findEndL pa0 256 256
  else if fam == 1 then (pa1 + 2 * xiUnit - 1) / (2 * xiUnit)
  else findEndU pa0 ((pa0 / (2 * xiUnit) / 256 + 1) * 256) 256

/-- Breakpoints after `m0` covering `[m0, m1]`, or `none` on failure. -/
partial def coverIv (fam pa0 pa1 minW m0 m1 : ℕ) : Option (List ℕ) :=
  if famBox fam pa0 pa1 m0 m1 then some [m1]
  else if m1 - m0 ≤ minW then none
  else
    let mid := (m0 + m1) / 2
    match coverIv fam pa0 pa1 minW m0 mid with
    | none => none
    | some l => match coverIv fam pa0 pa1 minW mid m1 with
      | none => none
      | some r => some (l ++ r)

partial def coverChain (fam pa0 pa1 width minW m mE : ℕ) (acc : List ℕ) : Option (List ℕ) :=
  if m ≥ mE then some acc.reverse
  else
    let m' := Nat.min (m + width) mE
    match coverIv fam pa0 pa1 minW m m' with
    | none => none
    | some l => coverChain fam pa0 pa1 width minW m' mE (l.reverse ++ acc)

def coverStrip (fam k0 k1 width minW : ℕ) : Option (List ℕ) :=
  let pa0 := k0 * aUnit
  let pa1 := k1 * aUnit
  let mS := famStart fam pa0
  let mE := famEnd fam pa0 pa1
  (coverChain fam pa0 pa1 width minW mS mE []).map (fun l => mS :: l)

partial def runStrips (fam k kMax w wMax width minW : ℕ) (h : IO.FS.Handle)
    (nb ng : ℕ) : IO (ℕ × ℕ) := do
  if k ≥ kMax then return (nb, ng)
  let k1 := Nat.min (k + w) kMax
  match coverStrip fam k k1 width minW with
  | some bps =>
    h.putStrLn s!"  ({k}, {k1}, {bps}),"
    h.flush
    runStrips fam k1 kMax (Nat.min (2 * w) wMax) wMax width minW h (nb + bps.length - 1) (ng + 1)
  | none =>
    if w ≤ 1024 then
      IO.eprintln s!"FAIL at k={k}"
      return (nb, ng)
    runStrips fam k kMax (w / 2) wMax width minW h nb ng

def envNat (n : String) (d : ℕ) : IO ℕ := do
  match (← IO.getEnv n) with
  | some s => return s.toNat!
  | none => return d

#eval show IO Unit from do
  let fam ← envNat "FAM" 0
  let kMin ← envNat "KMIN" 2362232012
  let kMax ← envNat "KMAX" 4294967296
  let w ← envNat "W" 42949673
  let wMax ← envNat "WMAX" 171798692
  let width ← envNat "WIDTH" 4096
  let minW ← envNat "MINW" 16
  let out := (← IO.getEnv "OUT").getD "/tmp/peel.txt"
  let h ← IO.FS.Handle.mk out IO.FS.Mode.write
  let t0 ← IO.monoMsNow
  let (nb, ng) ← runStrips fam kMin kMax w wMax width minW h 0 0
  let t1 ← IO.monoMsNow
  IO.eprintln s!"fam={fam} groups={ng} boxes={nb} ({t1 - t0} ms)"
