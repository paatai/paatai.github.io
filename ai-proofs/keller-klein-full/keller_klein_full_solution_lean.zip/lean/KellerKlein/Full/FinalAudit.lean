import KellerKlein.Full.Final

/-!
Axiom audit of the final theorem. Expected output: `propext`, `Classical.choice`, `Quot.sound`.
-/

#print axioms KellerKlein.keller_klein
#print axioms KellerKlein.keller_klein_max
#print axioms KellerKlein.pieces

#check @KellerKlein.keller_klein
#print KellerKlein.rademacherCDF
#print KellerKlein.rademacherStrictCDF
#print KellerKlein.rademacherSum
#print KellerKlein.rademacherSign
#print KellerKlein.cubeProbability
