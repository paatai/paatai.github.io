import KellerKlein.Full.Reduction

/-!
# A Wallis bound for real exponents

`V(t) = ∫₀^{1/2} cos(πu)^t du` satisfies `V(N)² ≤ 1/(2π(N + 1/2))` for every real `N ≥ 1/2`.

* `log V` is convex (Hölder's inequality);
* `(t + 2) V(t + 2) = (t + 1) V(t)` (integration by parts), so `g(t) = (t + 1) V(t) V(t + 1)`
  is `1`-periodic, and `g = 1/(2π)` at the integers (`V(0) = 1/2`, `V(1) = 1/π`);
* between consecutive integers `M ≤ M + θ ≤ M + 1`, log-convexity gives
  `g(M + θ) ≤ (M + θ + 1)/(2π(M + 1))`; letting `M → ∞` along the period, `g ≤ 1/(2π)`;
* finally `V(N)² ≤ V(N - 1/2) V(N + 1/2) = g(N - 1/2)/(N + 1/2)`.
-/

namespace KellerKlein

noncomputable section

open MeasureTheory Set Real

/-- `V(t) = ∫₀^{1/2} cos(πu)^t du`. -/
def wallisV (t : ℝ) : ℝ := ∫ u in (0 : ℝ)..(1 / 2), Real.cos (π * u) ^ t

/-- `g(t) = (t + 1) V(t) V(t + 1)`. -/
def wallisG (t : ℝ) : ℝ := (t + 1) * wallisV t * wallisV (t + 1)

lemma cos_pi_mul_nonneg_of_mem {u : ℝ} (hu0 : 0 ≤ u) (hu1 : u ≤ 1 / 2) :
    0 ≤ Real.cos (π * u) := by
  apply Real.cos_nonneg_of_mem_Icc
  constructor <;> nlinarith [Real.pi_pos]

lemma continuous_cos_pi_rpow {t : ℝ} (ht : 0 ≤ t) :
    Continuous (fun u : ℝ => Real.cos (π * u) ^ t) :=
  (Real.continuous_cos.comp (continuous_const.mul continuous_id)).rpow_const
    (fun _ => Or.inr ht)

lemma wallisV_nonneg (t : ℝ) : 0 ≤ wallisV t := by
  unfold wallisV
  apply intervalIntegral.integral_nonneg (by norm_num)
  intro u hu
  exact Real.rpow_nonneg (cos_pi_mul_nonneg_of_mem hu.1 hu.2) t

lemma wallisV_eq_set (t : ℝ) :
    wallisV t = ∫ u in Ioc (0 : ℝ) (1 / 2), Real.cos (π * u) ^ t := by
  unfold wallisV
  rw [intervalIntegral.integral_of_le (by norm_num)]

/-! ### Log-convexity -/

lemma memLp_cos_pi_rpow {s : ℝ} (hs : 0 ≤ s) (p : ENNReal) :
    MemLp (fun u : ℝ => Real.cos (π * u) ^ s) p (volume.restrict (Ioc (0 : ℝ) (1 / 2))) := by
  refine MemLp.of_bound (continuous_cos_pi_rpow hs).aestronglyMeasurable 1 ?_
  filter_upwards [ae_restrict_mem measurableSet_Ioc] with u hu
  have hc := cos_pi_mul_nonneg_of_mem hu.1.le hu.2
  rw [Real.norm_eq_abs, abs_of_nonneg (Real.rpow_nonneg hc _)]
  exact Real.rpow_le_one hc (Real.cos_le_one _) hs

lemma wallisV_holder {x y l : ℝ} (hx : 0 ≤ x) (hy : 0 ≤ y) (hl0 : 0 < l) (hl1 : l < 1) :
    wallisV (l * x + (1 - l) * y) ≤ wallisV x ^ l * wallisV y ^ (1 - l) := by
  have hl1' : 0 < 1 - l := by linarith
  have hpq := Real.holderConjugate_one_div hl0 hl1' (by ring)
  have hpos : ∀ u ∈ Ioc (0 : ℝ) (1 / 2), 0 ≤ Real.cos (π * u) :=
    fun u hu => cos_pi_mul_nonneg_of_mem hu.1.le hu.2
  have hf0 : 0 ≤ᵐ[volume.restrict (Ioc (0 : ℝ) (1 / 2))]
      (fun u : ℝ => Real.cos (π * u) ^ (l * x)) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with u hu
    exact Real.rpow_nonneg (hpos u hu) _
  have hg0 : 0 ≤ᵐ[volume.restrict (Ioc (0 : ℝ) (1 / 2))]
      (fun u : ℝ => Real.cos (π * u) ^ ((1 - l) * y)) := by
    filter_upwards [ae_restrict_mem measurableSet_Ioc] with u hu
    exact Real.rpow_nonneg (hpos u hu) _
  have h := integral_mul_le_Lp_mul_Lq_of_nonneg hpq hf0 hg0
    (memLp_cos_pi_rpow (by positivity) _) (memLp_cos_pi_rpow (by positivity) _)
  have e1 : (∫ u in Ioc (0 : ℝ) (1 / 2),
      Real.cos (π * u) ^ (l * x) * Real.cos (π * u) ^ ((1 - l) * y)) =
      wallisV (l * x + (1 - l) * y) := by
    rw [wallisV_eq_set]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro u hu
    exact (Real.rpow_add_of_nonneg (hpos u hu) (by positivity) (by positivity)).symm
  have e2 : (∫ u in Ioc (0 : ℝ) (1 / 2), (Real.cos (π * u) ^ (l * x)) ^ (1 / l)) =
      wallisV x := by
    rw [wallisV_eq_set]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro u hu
    simp only
    rw [← Real.rpow_mul (hpos u hu)]
    congr 1
    field_simp
  have e3 : (∫ u in Ioc (0 : ℝ) (1 / 2), (Real.cos (π * u) ^ ((1 - l) * y)) ^ (1 / (1 - l))) =
      wallisV y := by
    rw [wallisV_eq_set]
    apply setIntegral_congr_fun measurableSet_Ioc
    intro u hu
    simp only
    rw [← Real.rpow_mul (hpos u hu)]
    congr 1
    field_simp
  rw [e1, e2, e3] at h
  simpa only [one_div_one_div] using h

lemma wallisV_interp (M : ℕ) {θ : ℝ} (h0 : 0 ≤ θ) (h1 : θ ≤ 1) :
    wallisV (M + θ) ≤ wallisV M ^ (1 - θ) * wallisV (M + 1) ^ θ := by
  rcases h0.eq_or_lt with rfl | h0'
  · simp
  rcases h1.eq_or_lt with rfl | h1'
  · simp
  have h := wallisV_holder (x := M) (y := M + 1) (l := 1 - θ) (by positivity) (by positivity)
    (by linarith) (by linarith)
  have e : (1 - θ) * (M : ℝ) + (1 - (1 - θ)) * (M + 1) = M + θ := by ring
  rw [e, show 1 - (1 - θ) = θ by ring] at h
  exact h

/-! ### The recursion -/

lemma wallisV_zero : wallisV 0 = 1 / 2 := by
  unfold wallisV
  simp

lemma wallisV_one : wallisV 1 = 1 / π := by
  unfold wallisV
  simp only [Real.rpow_one]
  have h := intervalIntegral.integral_comp_mul_left (fun u => Real.cos u)
    (a := (0 : ℝ)) (b := 1 / 2) Real.pi_ne_zero
  simp only at h
  rw [h, integral_cos]
  have : π * (1 / 2) = π / 2 := by ring
  rw [this, Real.sin_pi_div_two, mul_zero, Real.sin_zero, smul_eq_mul]
  field_simp

lemma wallisV_add_two {t : ℝ} (ht : 0 ≤ t) :
    (t + 2) * wallisV (t + 2) = (t + 1) * wallisV t := by
  have hlin : ∀ u : ℝ, HasDerivAt (fun u : ℝ => π * u) π u := fun u =>
    ((hasDerivAt_id u).const_mul π).congr_deriv (mul_one π)
  have hU : ∀ u ∈ uIcc (0 : ℝ) (1 / 2), HasDerivAt (fun u => Real.cos (π * u) ^ (t + 1))
      (-Real.sin (π * u) * π * (t + 1) * Real.cos (π * u) ^ t) u := by
    intro u _
    have hc : HasDerivAt (fun u => Real.cos (π * u)) (-Real.sin (π * u) * π) u :=
      (Real.hasDerivAt_cos (π * u)).comp u (hlin u)
    have h := hc.rpow_const (p := t + 1) (Or.inr (by linarith))
    simpa only [add_sub_cancel_right] using h
  have hv : ∀ u ∈ uIcc (0 : ℝ) (1 / 2), HasDerivAt (fun u => Real.sin (π * u) / π)
      (Real.cos (π * u)) u := by
    intro u _
    have := ((Real.hasDerivAt_sin (π * u)).comp u (hlin u)).div_const π
    convert this using 1
    field_simp
  have hcont : Continuous (fun u : ℝ => -Real.sin (π * u) * π * (t + 1) * Real.cos (π * u) ^ t) :=
    (((Real.continuous_sin.comp (continuous_const.mul continuous_id)).neg.mul
      continuous_const).mul continuous_const).mul (continuous_cos_pi_rpow ht)
  have hibp := intervalIntegral.integral_mul_deriv_eq_deriv_mul hU hv
    (hcont.intervalIntegrable _ _)
    ((Real.continuous_cos.comp (continuous_const.mul continuous_id)).intervalIntegrable _ _)
  have hl : (∫ u in (0 : ℝ)..(1 / 2), Real.cos (π * u) ^ (t + 1) * Real.cos (π * u)) =
      wallisV (t + 2) := by
    unfold wallisV
    apply intervalIntegral.integral_congr
    intro u hu
    rw [uIcc_of_le (by norm_num)] at hu
    have hc := cos_pi_mul_nonneg_of_mem hu.1 hu.2
    simp only
    rw [show t + 2 = (t + 1) + 1 by ring,
      Real.rpow_add_of_nonneg hc (show (0 : ℝ) ≤ t + 1 by linarith) zero_le_one, Real.rpow_one]
  have hr : (∫ u in (0 : ℝ)..(1 / 2),
      -Real.sin (π * u) * π * (t + 1) * Real.cos (π * u) ^ t * (Real.sin (π * u) / π)) =
      ∫ u in (0 : ℝ)..(1 / 2), -(t + 1) * (Real.cos (π * u) ^ t - Real.cos (π * u) ^ (t + 2)) := by
    apply intervalIntegral.integral_congr
    intro u hu
    rw [uIcc_of_le (by norm_num)] at hu
    have hc := cos_pi_mul_nonneg_of_mem hu.1 hu.2
    simp only
    rw [Real.rpow_add_of_nonneg hc ht (by norm_num : (0 : ℝ) ≤ 2)]
    have h2 : Real.cos (π * u) ^ (2 : ℝ) = Real.cos (π * u) ^ 2 := by
      rw [show (2 : ℝ) = ((2 : ℕ) : ℝ) by norm_num, Real.rpow_natCast]
    rw [h2]
    have hs : Real.sin (π * u) ^ 2 = 1 - Real.cos (π * u) ^ 2 := by
      linarith [Real.sin_sq_add_cos_sq (π * u)]
    calc -Real.sin (π * u) * π * (t + 1) * Real.cos (π * u) ^ t * (Real.sin (π * u) / π)
        = -(t + 1) * Real.cos (π * u) ^ t * Real.sin (π * u) ^ 2 := by
          field_simp
          ring
      _ = -(t + 1) * (Real.cos (π * u) ^ t - Real.cos (π * u) ^ t * Real.cos (π * u) ^ 2) := by
          rw [hs]
          ring
  have hint : (∫ u in (0 : ℝ)..(1 / 2),
      -(t + 1) * (Real.cos (π * u) ^ t - Real.cos (π * u) ^ (t + 2))) =
      -(t + 1) * (wallisV t - wallisV (t + 2)) := by
    rw [intervalIntegral.integral_const_mul, intervalIntegral.integral_sub
      ((continuous_cos_pi_rpow ht).intervalIntegrable _ _)
      ((continuous_cos_pi_rpow (by linarith)).intervalIntegrable _ _)]
    rfl
  rw [hl, hr, hint] at hibp
  have hb1 : Real.cos (π * (1 / 2)) ^ (t + 1) = 0 := by
    rw [show π * (1 / 2) = π / 2 by ring, Real.cos_pi_div_two]
    exact Real.zero_rpow (by linarith)
  simp only [hb1, zero_mul, mul_zero, Real.sin_zero, zero_div, sub_zero] at hibp
  linarith

lemma wallisG_add_one {t : ℝ} (ht : 0 ≤ t) : wallisG (t + 1) = wallisG t := by
  unfold wallisG
  have h := wallisV_add_two ht
  rw [show t + 1 + 1 = t + 2 by ring]
  calc (t + 2) * wallisV (t + 1) * wallisV (t + 2)
      = wallisV (t + 1) * ((t + 2) * wallisV (t + 2)) := by ring
    _ = wallisV (t + 1) * ((t + 1) * wallisV t) := by rw [h]
    _ = (t + 1) * wallisV t * wallisV (t + 1) := by ring

lemma wallisG_add_nat {t : ℝ} (ht : 0 ≤ t) (n : ℕ) : wallisG (t + n) = wallisG t := by
  induction n with
  | zero => simp
  | succ n ih =>
    rw [Nat.cast_succ, ← add_assoc, wallisG_add_one (by positivity), ih]

lemma wallisG_zero : wallisG 0 = 1 / (2 * π) := by
  unfold wallisG
  rw [zero_add, wallisV_zero, wallisV_one]
  field_simp

lemma wallisG_nat (n : ℕ) : wallisG n = 1 / (2 * π) := by
  have h := wallisG_add_nat (le_refl (0 : ℝ)) n
  rw [zero_add] at h
  rw [h, wallisG_zero]

lemma wallisV_mul_succ (n : ℕ) : wallisV n * wallisV (n + 1) = 1 / (2 * π * (n + 1)) := by
  have h := wallisG_nat n
  unfold wallisG at h
  have hn : (0 : ℝ) < n + 1 := by positivity
  field_simp
  field_simp at h
  linarith

/-! ### The bound -/

lemma wallisG_le_shift (M : ℕ) {θ : ℝ} (h0 : 0 ≤ θ) (h1 : θ ≤ 1) :
    wallisG (M + θ) ≤ (M + 2) / (2 * π * (M + 1)) := by
  have hA := wallisV_interp M h0 h1
  have hB := wallisV_interp (M + 1) h0 h1
  push_cast at hB
  have hP1 := wallisV_mul_succ M
  have hP2 := wallisV_mul_succ (M + 1)
  push_cast at hP2
  have hV0 := wallisV_nonneg M
  have hV1 := wallisV_nonneg (M + 1)
  have hV2 := wallisV_nonneg (M + 1 + 1)
  have hθ1 : 0 ≤ 1 - θ := by linarith
  set x : ℝ := 1 / (2 * π * (M + 1)) with hx
  set y : ℝ := 1 / (2 * π * (M + 1 + 1)) with hy
  have hx0 : 0 < x := by positivity
  have hy0 : 0 ≤ y := by positivity
  have hyx : y ≤ x := by
    apply one_div_le_one_div_of_le (by positivity)
    nlinarith [Real.pi_pos]
  have hprod : wallisV (M + θ) * wallisV (M + 1 + θ) ≤ x := by
    calc wallisV (M + θ) * wallisV (M + 1 + θ)
        ≤ (wallisV M ^ (1 - θ) * wallisV (M + 1) ^ θ) *
          (wallisV (M + 1) ^ (1 - θ) * wallisV (M + 1 + 1) ^ θ) :=
          mul_le_mul hA hB (wallisV_nonneg _) (by positivity)
      _ = (wallisV M * wallisV (M + 1)) ^ (1 - θ) *
          (wallisV (M + 1) * wallisV (M + 1 + 1)) ^ θ := by
          rw [Real.mul_rpow hV0 hV1, Real.mul_rpow hV1 hV2]
          ring
      _ = x ^ (1 - θ) * y ^ θ := by rw [hP1, hP2]
      _ ≤ x ^ (1 - θ) * x ^ θ :=
          mul_le_mul_of_nonneg_left (Real.rpow_le_rpow hy0 hyx h0) (by positivity)
      _ = x := by
          rw [← Real.rpow_add hx0, show 1 - θ + θ = 1 by ring, Real.rpow_one]
  unfold wallisG
  have hM : (M : ℝ) + θ + 1 ≤ M + 2 := by linarith
  calc ((M : ℝ) + θ + 1) * wallisV (M + θ) * wallisV (M + θ + 1)
      = ((M : ℝ) + θ + 1) * (wallisV (M + θ) * wallisV (M + 1 + θ)) := by
        rw [show (M : ℝ) + θ + 1 = M + 1 + θ by ring]
        ring
    _ ≤ ((M : ℝ) + θ + 1) * x := mul_le_mul_of_nonneg_left hprod (by positivity)
    _ ≤ ((M : ℝ) + 2) * x := mul_le_mul_of_nonneg_right hM hx0.le
    _ = (M + 2) / (2 * π * (M + 1)) := by rw [hx]; ring

lemma wallisG_le {t : ℝ} (ht : 0 ≤ t) : wallisG t ≤ 1 / (2 * π) := by
  have key : ∀ n : ℕ, wallisG t ≤ 1 / (2 * π) * (1 + 1 / (n + 1)) := by
    intro n
    have hs : 0 ≤ t + n := by positivity
    set M := ⌊t + n⌋₊ with hM
    have hMle : (M : ℝ) ≤ t + n := Nat.floor_le hs
    have hlt : t + n < M + 1 := Nat.lt_floor_add_one _
    have hnM : n ≤ M := Nat.le_floor (by linarith)
    have hθ := wallisG_le_shift M (θ := t + n - M) (by linarith) (by linarith)
    rw [show (M : ℝ) + (t + n - M) = t + n by ring, wallisG_add_nat ht n] at hθ
    have hnM' : (n : ℝ) ≤ M := by exact_mod_cast hnM
    have h1 : ((M : ℝ) + 2) / (2 * π * (M + 1)) = 1 / (2 * π) * (1 + 1 / (M + 1)) := by
      field_simp
      ring
    have h2 : 1 / ((M : ℝ) + 1) ≤ 1 / (n + 1) :=
      one_div_le_one_div_of_le (by positivity) (by linarith)
    rw [h1] at hθ
    calc wallisG t ≤ 1 / (2 * π) * (1 + 1 / (M + 1)) := hθ
      _ ≤ 1 / (2 * π) * (1 + 1 / (n + 1)) := by
        apply mul_le_mul_of_nonneg_left _ (by positivity)
        linarith
  by_contra hc
  push_neg at hc
  have hε : 0 < (wallisG t - 1 / (2 * π)) * (2 * π) := by
    apply mul_pos (by linarith) (by positivity)
  obtain ⟨n, hn⟩ := exists_nat_one_div_lt hε
  have hk := key n
  have : 1 / (2 * π) * (1 + 1 / (n + 1)) < wallisG t := by
    have hpi : 0 < 2 * π := by positivity
    have e : 1 / (2 * π) * (1 + 1 / ((n : ℝ) + 1)) =
        1 / (2 * π) + (1 / ((n : ℝ) + 1)) / (2 * π) := by
      ring
    rw [e]
    have : (1 / ((n : ℝ) + 1)) / (2 * π) < wallisG t - 1 / (2 * π) := by
      rw [div_lt_iff₀ hpi]
      linarith
    linarith
  linarith

theorem wallisV_sq_le {N : ℝ} (hN : 1 / 2 ≤ N) :
    wallisV N ^ 2 ≤ 1 / (2 * π * (N + 1 / 2)) := by
  have h := wallisV_holder (x := N - 1 / 2) (y := N + 1 / 2) (l := 1 / 2) (by linarith)
    (by linarith) (by norm_num) (by norm_num)
  rw [show 1 / 2 * (N - 1 / 2) + (1 - 1 / 2) * (N + 1 / 2) = N by ring,
    show (1 : ℝ) - 1 / 2 = 1 / 2 by norm_num] at h
  have h0 := wallisV_nonneg (N - 1 / 2)
  have h1 := wallisV_nonneg (N + 1 / 2)
  have hsq : wallisV N ^ 2 ≤ wallisV (N - 1 / 2) * wallisV (N + 1 / 2) := by
    have hr : (wallisV (N - 1 / 2) ^ (1 / 2 : ℝ) * wallisV (N + 1 / 2) ^ (1 / 2 : ℝ)) ^ 2 =
        wallisV (N - 1 / 2) * wallisV (N + 1 / 2) := by
      rw [mul_pow, ← Real.rpow_natCast, ← Real.rpow_natCast (wallisV (N + 1 / 2) ^ (1 / 2 : ℝ)),
        ← Real.rpow_mul h0, ← Real.rpow_mul h1]
      norm_num
    rw [← hr]
    exact pow_le_pow_left₀ (wallisV_nonneg N) h 2
  have hg := wallisG_le (t := N - 1 / 2) (by linarith)
  unfold wallisG at hg
  rw [show N - 1 / 2 + 1 = N + 1 / 2 by ring] at hg
  have hpos : 0 < N + 1 / 2 := by linarith
  have h2 : (N + 1 / 2) * wallisV (N - 1 / 2) * wallisV (N + 1 / 2) * (2 * π) ≤ 1 := by
    have := mul_le_mul_of_nonneg_right hg (by positivity : (0 : ℝ) ≤ 2 * π)
    rwa [one_div_mul_cancel (by positivity)] at this
  have : wallisV (N - 1 / 2) * wallisV (N + 1 / 2) ≤ 1 / (2 * π * (N + 1 / 2)) := by
    rw [le_div_iff₀ (by positivity)]
    calc wallisV (N - 1 / 2) * wallisV (N + 1 / 2) * (2 * π * (N + 1 / 2))
        = (N + 1 / 2) * wallisV (N - 1 / 2) * wallisV (N + 1 / 2) * (2 * π) := by ring
      _ ≤ 1 := h2
  linarith

end

end KellerKlein
