import KellerKlein.Full.Reduction

/-!
# Zone A, pointwise ingredients

* `upperKernel ξ u ≤ (1 - u) + ξ p(u)` on `0 < u < 1`, `0 ≤ ξ ≤ 1/2`, with the quartic
  `p(u) = 1 - 5u²/2 + u³ + u⁴/2`. It follows from `π u ρ(u) ≤ p(u)`, which uses
  `y cot y ≤ 1 - y²/3 - y⁴/45` for `u ≤ 1/2` and the reflected bound
  `1 - y cot y ≤ y²/3 + y⁴/32` for `u ≥ 1/2`.
* Concavity of `c` on `[0, ∞)`: `λ c(x) ≤ c(λ x)` for `0 ≤ λ ≤ 1`.
-/

namespace KellerKlein

noncomputable section

open Set

/-- The quartic majorant of `π u ρ(u)`. -/
def kernelPoly (u : ℝ) : ℝ := 1 - 5 / 2 * u ^ 2 + u ^ 3 + u ^ 4 / 2

lemma kernelPoly_add_reflect (u : ℝ) :
    kernelPoly u + kernelPoly (1 - u) = 1 + u ^ 2 * (1 - u) ^ 2 := by
  unfold kernelPoly; ring

lemma kernelPoly_one : kernelPoly 1 = 0 := by unfold kernelPoly; norm_num

private lemma aux_m_nonneg {x : ℝ} (hx : 0 ≤ x) (hxp : x ≤ Real.pi / 2) :
    0 ≤ (7 + x ^ 2) * Real.sin x - 7 * x * Real.cos x := by
  apply nonneg_of_derivative_nonneg hx
    (f' := fun y => 9 * y * Real.sin y + y ^ 2 * Real.cos y)
  · simp
  · intro y _
    convert (((hasDerivAt_const y (7 : ℝ)).add (hasDerivAt_pow 2 y)).mul
      (Real.hasDerivAt_sin y)).sub (((hasDerivAt_id y).const_mul 7).mul
      (Real.hasDerivAt_cos y)) using 1
    simp only [id_eq]
    ring
  · intro y hy
    have hs : 0 ≤ Real.sin y :=
      Real.sin_nonneg_of_nonneg_of_le_pi hy.1 (by linarith [Real.pi_pos, hy.2])
    have hc : 0 ≤ Real.cos y :=
      Real.cos_nonneg_of_mem_Icc ⟨by linarith [Real.pi_pos, hy.1], hy.2.trans hxp⟩
    have := hy.1
    positivity

private lemma aux_k_nonneg {x : ℝ} (hx : 0 ≤ x) (hxp : x ≤ Real.pi / 2) :
    0 ≤ (1 - 4 * x ^ 2 / 15) * Real.sin x - (x + x ^ 3 / 15) * Real.cos x := by
  apply nonneg_of_derivative_nonneg hx
    (f' := fun y => y / 15 * ((7 + y ^ 2) * Real.sin y - 7 * y * Real.cos y))
  · simp
  · intro y _
    convert (((hasDerivAt_const y (1 : ℝ)).sub
      (((hasDerivAt_pow 2 y).const_mul 4).div_const 15)).mul
      (Real.hasDerivAt_sin y)).sub (((hasDerivAt_id y).add
      ((hasDerivAt_pow 3 y).div_const 15)).mul (Real.hasDerivAt_cos y)) using 1
    simp only [id_eq]
    ring
  · intro y hy
    exact mul_nonneg (div_nonneg hy.1 (by norm_num)) (aux_m_nonneg hy.1 (hy.2.trans hxp))

/-- `y cot y ≤ 1 - y²/3 - y⁴/45` on `[0, π/2]`, in product form. -/
lemma cotangent_upper_quartic {x : ℝ} (hx : 0 ≤ x) (hxp : x ≤ Real.pi / 2) :
    x * Real.cos x ≤ (1 - x ^ 2 / 3 - x ^ 4 / 45) * Real.sin x := by
  have h : 0 ≤ (1 - x ^ 2 / 3 - x ^ 4 / 45) * Real.sin x - x * Real.cos x := by
    apply nonneg_of_derivative_nonneg hx
      (f' := fun y => y / 3 *
        ((1 - 4 * y ^ 2 / 15) * Real.sin y - (y + y ^ 3 / 15) * Real.cos y))
    · simp
    · intro y _
      convert ((((hasDerivAt_const y (1 : ℝ)).sub ((hasDerivAt_pow 2 y).div_const 3)).sub
        ((hasDerivAt_pow 4 y).div_const 45)).mul (Real.hasDerivAt_sin y)).sub
        ((hasDerivAt_id y).mul (Real.hasDerivAt_cos y)) using 1
      simp only [id_eq]
      ring
    · intro y hy
      exact mul_nonneg (div_nonneg hy.1 (by norm_num)) (aux_k_nonneg hy.1 (hy.2.trans hxp))
  linarith

lemma pi_sq_gt : (9869 / 1000 : ℝ) < Real.pi ^ 2 := by
  nlinarith [Real.pi_gt_d4]

lemma pi_sq_lt : Real.pi ^ 2 < (987 / 100 : ℝ) := by
  nlinarith [Real.pi_lt_d4, Real.pi_pos]

private lemma delta_nonneg {u s : ℝ} (hu : 0 ≤ u) (hu1 : u ≤ 1 / 2) (hs : 9869 / 1000 ≤ s) :
    0 ≤ (1 - u) * (s / 3 + s ^ 2 * u ^ 2 / 45) - 5 / 2 + u + u ^ 2 / 2 := by
  have hmono : (1 - u) * ((9869 / 1000 : ℝ) / 3 + (9869 / 1000) ^ 2 * u ^ 2 / 45) ≤
      (1 - u) * (s / 3 + s ^ 2 * u ^ 2 / 45) := by
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    have : (9869 / 1000 : ℝ) ^ 2 ≤ s ^ 2 := pow_le_pow_left₀ (by norm_num) hs 2
    nlinarith [sq_nonneg u]
  have hpoly : 0 ≤ (1 - u) * ((9869 / 1000 : ℝ) / 3 + (9869 / 1000) ^ 2 * u ^ 2 / 45) -
      5 / 2 + u + u ^ 2 / 2 := by
    nlinarith [mul_nonneg hu (by linarith : (0 : ℝ) ≤ 1 / 2 - u),
      mul_nonneg (mul_nonneg hu hu) (by linarith : (0 : ℝ) ≤ 1 / 2 - u),
      mul_nonneg (mul_nonneg hu (by linarith : (0 : ℝ) ≤ 1 / 2 - u))
        (by linarith : (0 : ℝ) ≤ 1 / 2 - u)]
  linarith

private lemma eps_nonneg {t s : ℝ} (ht : 0 ≤ t) (ht1 : t ≤ 1 / 2) (hs0 : 0 ≤ s)
    (hs : s ≤ 987 / 100) :
    0 ≤ 7 / 2 - 3 * t + t ^ 2 / 2 - (1 - t) * (s / 3 + s ^ 2 * t ^ 2 / 32) := by
  have hmono : (1 - t) * (s / 3 + s ^ 2 * t ^ 2 / 32) ≤
      (1 - t) * ((987 / 100 : ℝ) / 3 + (987 / 100) ^ 2 * t ^ 2 / 32) := by
    apply mul_le_mul_of_nonneg_left _ (by linarith)
    have : s ^ 2 ≤ (987 / 100 : ℝ) ^ 2 := pow_le_pow_left₀ hs0 hs 2
    nlinarith [sq_nonneg t]
  have hpoly : 0 ≤ 7 / 2 - 3 * t + t ^ 2 / 2 -
      (1 - t) * ((987 / 100 : ℝ) / 3 + (987 / 100) ^ 2 * t ^ 2 / 32) := by
    nlinarith [mul_nonneg ht (by linarith : (0 : ℝ) ≤ 1 / 2 - t),
      mul_nonneg (mul_nonneg ht ht) (by linarith : (0 : ℝ) ≤ 1 / 2 - t),
      sq_nonneg (t - 1 / 2), mul_nonneg ht (sq_nonneg (t - 1 / 2))]
  linarith

/-- `π u ρ(u) ≤ p(u)` on `(0, 1)`. -/
lemma pi_mul_rho_le_poly {u : ℝ} (hu : 0 < u) (hu1 : u < 1) :
    Real.pi * u * rho u ≤ kernelPoly u := by
  rcases le_total u (1 / 2) with hh | hh
  · set y := Real.pi * u with hy_def
    have hy : 0 < y := mul_pos Real.pi_pos hu
    have hyp : y ≤ Real.pi / 2 := by rw [hy_def]; nlinarith [Real.pi_pos]
    have hs : 0 < Real.sin y := Real.sin_pos_of_pos_of_lt_pi hy (by linarith [Real.pi_pos])
    have hcot : y * (Real.cos y / Real.sin y) ≤ 1 - y ^ 2 / 3 - y ^ 4 / 45 := by
      rw [← mul_div_assoc, div_le_iff₀ hs]
      exact cotangent_upper_quartic hy.le hyp
    have he : Real.pi * u * rho u = (1 - u) * (y * (Real.cos y / Real.sin y)) + u := by
      unfold rho
      rw [← hy_def]
      field_simp [Real.pi_ne_zero]
      ring
    rw [he]
    have hm := mul_le_mul_of_nonneg_left hcot (show 0 ≤ 1 - u by linarith)
    have hδ := delta_nonneg hu.le hh pi_sq_gt.le
    have hy2 : y ^ 2 = Real.pi ^ 2 * u ^ 2 := by rw [hy_def]; ring
    have hy4 : y ^ 4 = (Real.pi ^ 2) ^ 2 * u ^ 4 := by rw [hy_def]; ring
    rw [hy2, hy4] at hm
    unfold kernelPoly
    have hu2 : 0 ≤ u ^ 2 := sq_nonneg u
    nlinarith [mul_nonneg hu2 hδ]
  · set t := 1 - u with ht_def
    have ht : 0 < t := by rw [ht_def]; linarith
    have ht1 : t ≤ 1 / 2 := by rw [ht_def]; linarith
    have hu_eq : u = 1 - t := by rw [ht_def]; ring
    have hy : 0 < Real.pi * t := mul_pos Real.pi_pos ht
    have hyp : Real.pi * t ≤ Real.pi / 2 := by nlinarith [Real.pi_pos]
    have hrem := cotangent_remainder_bound hy hyp
    have hrho := rho_reflect ht (by linarith)
    rw [hu_eq, hrho]
    have he : Real.pi * (1 - t) * ((1 - Real.pi * t * Real.cos (Real.pi * t) /
        Real.sin (Real.pi * t)) / Real.pi) =
        (1 - t) * (1 - Real.pi * t * (Real.cos (Real.pi * t) / Real.sin (Real.pi * t))) := by
      field_simp [Real.pi_ne_zero]
      ring
    rw [he]
    have hm := mul_le_mul_of_nonneg_left hrem (show 0 ≤ 1 - t by linarith)
    have hε := eps_nonneg ht.le ht1 (sq_nonneg Real.pi) pi_sq_lt.le
    have hy2 : (Real.pi * t) ^ 2 = Real.pi ^ 2 * t ^ 2 := by ring
    have hy4 : (Real.pi * t) ^ 4 = (Real.pi ^ 2) ^ 2 * t ^ 4 := by ring
    rw [hy2, hy4] at hm
    have hp : kernelPoly (1 - t) = t ^ 2 * (7 / 2 - 3 * t + t ^ 2 / 2) := by
      unfold kernelPoly; ring
    rw [hp]
    have ht2 : 0 ≤ t ^ 2 := sq_nonneg t
    nlinarith [mul_nonneg ht2 hε]

/-- The kernel majorant, affine in `ξ`. -/
lemma upperKernel_le_affine {ξ u : ℝ} (hξ : 0 ≤ ξ) (hξ1 : ξ ≤ 1 / 2)
    (hu : 0 < u) (hu1 : u < 1) :
    upperKernel ξ u ≤ (1 - u) + ξ * kernelPoly u := by
  have hz : 0 ≤ Real.pi * ξ * u := by positivity
  have hphase : Real.pi * ξ * u ≤ Real.pi := by
    have hm : ξ * u ≤ 1 / 2 := by nlinarith
    nlinarith [Real.pi_pos]
  have hs := Real.sin_nonneg_of_nonneg_of_le_pi hz hphase
  have hρ := rho_nonneg hu hu1
  have h1 := mul_le_mul_of_nonneg_left (Real.cos_le_one (Real.pi * ξ * u))
    (show 0 ≤ 1 - u by linarith)
  have h2 := mul_le_mul_of_nonneg_left (Real.sin_le hz) hρ
  have h3 := mul_le_mul_of_nonneg_left (pi_mul_rho_le_poly hu hu1) hξ
  unfold upperKernel
  have he : rho u * (Real.pi * ξ * u) = ξ * (Real.pi * u * rho u) := by ring
  linarith

lemma phi_le_of_le {s t : ℝ} (hs : 0 ≤ s) (hst : s ≤ t) : phi t ≤ phi s := by
  unfold phi
  exact mul_le_mul_of_nonneg_right
    (gaussian_antitoneOn (mem_Ici.2 hs) (mem_Ici.2 (hs.trans hst)) hst) phi0_pos.le

/-- Concavity of `c` on `[0, ∞)`. -/
lemma mul_c_le_c_mul {l x : ℝ} (hl0 : 0 ≤ l) (hl1 : l ≤ 1) (hx : 0 ≤ x) :
    l * c x ≤ c (l * x) := by
  rcases hl0.eq_or_lt with rfl | hl
  · simp [c_zero]
  have hsub : (∫ s in (0 : ℝ)..x, phi (l * s)) = l⁻¹ * c (l * x) := by
    rw [intervalIntegral.integral_comp_mul_left (fun t => phi t) hl.ne', mul_zero, smul_eq_mul]
    rfl
  have hmono : c x ≤ ∫ s in (0 : ℝ)..x, phi (l * s) := by
    unfold c
    apply intervalIntegral.integral_mono_on hx (continuous_phi.intervalIntegrable 0 x)
      ((continuous_phi.comp (continuous_const.mul continuous_id)).intervalIntegrable 0 x)
    intro s hs
    exact phi_le_of_le (mul_nonneg hl.le hs.1) (by show l * s ≤ s; nlinarith [hs.1])
  rw [hsub] at hmono
  have := mul_le_mul_of_nonneg_left hmono hl.le
  rwa [← mul_assoc, mul_inv_cancel₀ hl.ne', one_mul] at this

end

end KellerKlein
