import KellerKlein.Num.PeelCert
import KellerKlein.Full.PeelNearSmall

/-!
# The peeling inputs of the induction

The kernel-checked peeling covers of `Num/PeelCert.lean`, restated on the decimal ranges of
`Pieces`, and combined with the analytic near-diagonal bound for `a ≤ 0.3`.
-/

namespace KellerKlein

open Num

lemma pt_mul_aUnit (k : ℕ) : pt (Nat.mul k aUnit) = (k : ℝ) / 4294967296 := by
  simp only [pt, aUnit, S, Nat.mul_eq, Nat.cast_mul, Nat.cast_ofNat]
  ring

theorem c675_piece : 1 / 4 ≤ c (675 / 1000) := c675_certified

theorem peelLLarge_piece {a x : ℝ} (ha : 55 / 100 ≤ a) (ha1 : a < 1) (hx : a < x)
    (hexp : c a < Real.exp (-(x ^ 2) / 2)) : PeelL a x := by
  have h0 : pt (Nat.mul 2362232012 aUnit) ≤ a := by rw [pt_mul_aUnit]; linarith
  have h1 : a ≤ pt (Nat.mul 4294967296 aUnit) := by rw [pt_mul_aUnit]; linarith
  exact peelLLarge_cover a h0 h1 ha1 x hx hexp

theorem peelLNear_piece {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 55 / 100) (hx : a < x)
    (hx3 : x ≤ 3 * a / 2) : PeelL a x := by
  rcases le_or_lt a (3 / 10) with h | h
  · exact peelLNear_small ha h hx hx3
  · have h0 : pt (Nat.mul 1288490188 aUnit) ≤ a := by rw [pt_mul_aUnit]; linarith
    have h1 : a ≤ pt (Nat.mul 2362232013 aUnit) := by rw [pt_mul_aUnit]; linarith
    exact peelLNear_cover a h0 h1 (by linarith) x hx hx3

theorem peelU_piece {a x : ℝ} (ha : 1 / 2 ≤ a) (ha1 : a < 675 / 1000) (hx : a / 2 ≤ x)
    (ht : H x + H a < 1) : PeelU a x := by
  have h0 : pt (Nat.mul 2147483648 aUnit) ≤ a := by rw [pt_mul_aUnit]; linarith
  have h1 : a ≤ pt (Nat.mul 2899102925 aUnit) := by rw [pt_mul_aUnit]; linarith
  exact peelU_cover a h0 h1 x hx ht

end KellerKlein
