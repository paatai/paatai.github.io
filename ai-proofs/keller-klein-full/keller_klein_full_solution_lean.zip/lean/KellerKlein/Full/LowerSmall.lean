import KellerKlein.ZoneBTheorem
import KellerKlein.Full.Reduction
import KellerKlein.Num.Special
import KellerKlein.Num.Series

/-!
# The lower half (L) for small coefficients

For `0 < a ≤ 1/10`, `x ≥ 3a/2` and `c(a) < e^{-x²/2}`: `J(a, -x) ≤ c(a) - c(x)`.

The proof is Dev Goyal's zone-B decomposition of the envelope integral (Gaussian closed form,
envelope loss on `u ≤ 1/π`, middle region, compensated alias) taken at the negative location
`y = -x`.  The decomposition and the middle-region bound hold for every real location, and the
alias bound depends on `|ξ|` only.  The envelope loss needs the kernel bound
`(-κ_{-η}(u))₊ ≤ (η - 1) + u + (πηu)²/2`, which replaces Dev Goyal's bound for `ξ ≥ 0`.
-/

open Set MeasureTheory

namespace KellerKlein

noncomputable section

set_option maxHeartbeats 800000

/-! ### The decomposition at every real location -/

theorem JUpper_le_gaussian_primary_alias_real {a y : ℝ} (ha : 0 < a) (ha2 : a ≤ 1 / 2) :
    JUpper a y ≤ scaledGaussianKernelIntegral a y + primaryLoss a (y / a) +
      zoneBAliasIntegral a (y / a) + 6 * gaussian (1 / a) := by
  have hA : (0 : ℝ) ≤ 1 / Real.pi := by positivity
  have hAB : 1 / Real.pi ≤ crossoverRoot / Real.pi := by
    apply div_le_div_of_nonneg_right _ Real.pi_pos.le
    linarith [crossoverRoot_spec.1, Real.pi_gt_d2]
  have hB : crossoverRoot / Real.pi ≤ 1 := (div_le_one Real.pi_pos).2 crossoverRoot_spec.2.1.le
  have hi := intervalIntegrable_envelopeDifference (x := y) ha (by linarith)
  have h01 := intervalIntegrable_sub_unit hi le_rfl hA (hAB.trans hB)
  have h12 := intervalIntegrable_sub_unit hi hA hAB hB
  have h23 := intervalIntegrable_sub_unit hi (hA.trans hAB) hB le_rfl
  have hsplit := intervalIntegral.integral_add_adjacent_intervals (h01.trans h12) h23
  rw [← intervalIntegral.integral_add_adjacent_intervals h01 h12] at hsplit
  have hbase : (∫ u in (0 : ℝ)..1, envelopeDifference a y u) =
      JUpper a y - scaledGaussianKernelIntegral a y := by
    change (∫ u in (0 : ℝ)..1, upperEnvelopeIntegrand a y u - gaussianKernelUnit a y u) = _
    rw [intervalIntegral.integral_sub
      (intervalIntegrable_upperEnvelopeIntegrand ha (by linarith))
      (intervalIntegrable_gaussianKernelUnit a y), integral_gaussianKernelUnit ha]
    rfl
  rw [hbase, integral_envelopeDifference_first ha] at hsplit
  have hmid := integral_envelopeDifference_middle_le (x := y) ha ha2
  have halias := integral_envelopeDifference_alias_le (x := y) ha ha2
  linarith only [hsplit, hmid, halias]

lemma gaussianD_odd (x : ℝ) : gaussianD (-x) = -gaussianD x := by
  unfold gaussianD
  rw [← integral_neg]
  congr 1
  funext s
  rw [mul_neg, Real.sin_neg]
  ring

lemma gaussianN_odd (x : ℝ) : gaussianN (-x) = -gaussianN x := by
  unfold gaussianN
  rw [← integral_neg]
  congr 1
  funext s
  rw [mul_neg, Real.sin_neg]
  ring

lemma zoneBCommon_neg (a x : ℝ) :
    zoneBCommon a (-x) = a * phi x - c a + a ^ 2 * x * phi x / 3 +
      a ^ 2 * x * gaussianD x / Real.pi ^ 2 - a ^ 3 * gaussianN x / (3 * Real.pi ^ 2) := by
  unfold zoneBCommon
  rw [phi_even, gaussianD_odd, gaussianN_odd]
  ring

/-! ### The envelope loss at a negative location -/

lemma pi_mul_rho_le_one {u : ℝ} (hu : 0 < u) (hu1 : u < 1) : Real.pi * u * rho u ≤ 1 := by
  rw [Num.q_eq_left]
  have hD := Num.Dfun_nonneg (y := Real.pi * u) (by positivity)
    (by nlinarith [Real.pi_pos])
  have : 0 ≤ (1 - u) * Num.Dfun (Real.pi * u) := mul_nonneg (by linarith) hD
  linarith

lemma negKernel_negPart_le {η u : ℝ} (hη : 1 ≤ η) (hu : 0 < u) (hu1 : u < 1) :
    max 0 (-upperKernel (-η) u) ≤ (η - 1) + u + (Real.pi * η * u) ^ 2 / 2 := by
  have hη0 : 0 ≤ η := by linarith
  have ht : 0 ≤ Real.pi * η * u := by positivity
  apply max_le
  · have := sq_nonneg (Real.pi * η * u)
    linarith
  have e1 : Real.pi * -η * u = -(Real.pi * η * u) := by ring
  unfold upperKernel
  rw [e1, Real.cos_neg, Real.sin_neg]
  set t := Real.pi * η * u with ht_def
  have hsin := Real.sin_le ht
  have hcos := Real.one_sub_sq_div_two_le_cos (x := t)
  have hρ := rho_nonneg hu hu1
  have hq := pi_mul_rho_le_one hu hu1
  have h1 : rho u * Real.sin t ≤ rho u * t := mul_le_mul_of_nonneg_left hsin hρ
  have h2 : (1 - u) * (1 - t ^ 2 / 2) ≤ (1 - u) * Real.cos t :=
    mul_le_mul_of_nonneg_left hcos (by linarith)
  have h3 : rho u * t = η * (Real.pi * u * rho u) := by rw [ht_def]; ring
  have h4 : η * (Real.pi * u * rho u) ≤ η := by nlinarith
  have h5 : u * t ^ 2 / 2 ≥ 0 := by positivity
  nlinarith

/-- The envelope-loss majorant at the location `-η`. -/
def negLossMajorant (a η s : ℝ) : ℝ :=
  ((η - 1) + a * s / Real.pi + a ^ 2 * η ^ 2 * s ^ 2 / 2) *
    (gaussian s * gaussianProfileLoss a s)

lemma primaryLossIntegrand_le_neg {a η s : ℝ} (ha : 0 < a) (hη : 1 ≤ η)
    (hs : 0 < s) (hsa : s < 1 / a) :
    primaryLossIntegrand a (-η) s ≤ negLossMajorant a η s := by
  have has : a * s < 1 := by
    have h := (lt_div_iff₀ ha).mp hsa
    nlinarith
  have hu : 0 < a * s / Real.pi := div_pos (mul_pos ha hs) Real.pi_pos
  have hu1 : a * s / Real.pi < 1 := by
    apply (div_lt_iff₀ Real.pi_pos).2
    linarith [Real.pi_gt_three]
  have hK := negKernel_negPart_le hη hu hu1
  have he : (Real.pi * η * (a * s / Real.pi)) ^ 2 / 2 = a ^ 2 * η ^ 2 * s ^ 2 / 2 := by
    field_simp
    ring
  rw [he] at hK
  have hW := cosine_profile_loss_bound ha hs.le has.le
  have hW0 := sub_nonneg.mpr (cosine_profile_le_gaussian ha hs.le
    (by linarith [Real.pi_gt_three] : a * s < Real.pi / 2))
  have hc0 : 0 ≤ (η - 1) + a * s / Real.pi + a ^ 2 * η ^ 2 * s ^ 2 / 2 := by
    have : 0 ≤ η - 1 := by linarith
    positivity
  exact mul_le_mul hK hW hW0 hc0

lemma negLossMajorant_eq (a η s : ℝ) :
    negLossMajorant a η s = ((η - 1) * a ^ 2 / 12) * (s ^ 4 * gaussian s) +
      (a ^ 3 / (12 * Real.pi)) * (s ^ 5 * gaussian s) +
      ((η - 1) * a ^ 4 / 20 + a ^ 4 * η ^ 2 / 24) * (s ^ 6 * gaussian s) +
      (a ^ 5 / (20 * Real.pi)) * (s ^ 7 * gaussian s) +
      (a ^ 6 * η ^ 2 / 40) * (s ^ 8 * gaussian s) := by
  unfold negLossMajorant gaussianProfileLoss
  field_simp
  ring

lemma integrable_negLossMajorant (a η : ℝ) : Integrable (negLossMajorant a η) := by
  have he : negLossMajorant a η = fun s =>
      ((η - 1) * a ^ 2 / 12) * (s ^ 4 * gaussian s) +
      (a ^ 3 / (12 * Real.pi)) * (s ^ 5 * gaussian s) +
      ((η - 1) * a ^ 4 / 20 + a ^ 4 * η ^ 2 / 24) * (s ^ 6 * gaussian s) +
      (a ^ 5 / (20 * Real.pi)) * (s ^ 7 * gaussian s) +
      (a ^ 6 * η ^ 2 / 40) * (s ^ 8 * gaussian s) := funext (negLossMajorant_eq a η)
  rw [he]
  exact (((((integrable_pow_gaussian 4).const_mul _).add
    ((integrable_pow_gaussian 5).const_mul _)).add
    ((integrable_pow_gaussian 6).const_mul _)).add
    ((integrable_pow_gaussian 7).const_mul _)).add
    ((integrable_pow_gaussian 8).const_mul _)

lemma integral_negLossMajorant (a η : ℝ) :
    a / Real.pi * (∫ s in Ioi (0 : ℝ), negLossMajorant a η s) =
      (η - 1) * phi0 * (a ^ 3 / 4 + 3 * a ^ 5 / 4) +
        a ^ 4 / Real.pi ^ 2 * (2 / 3 + 12 * a ^ 2 / 5) +
        η ^ 2 * phi0 * (5 * a ^ 5 / 8 + 21 * a ^ 7 / 8) := by
  simp_rw [negLossMajorant_eq]
  have h4 := (integrableOn_pow_gaussian 4).const_mul ((η - 1) * a ^ 2 / 12)
  have h5 := (integrableOn_pow_gaussian 5).const_mul (a ^ 3 / (12 * Real.pi))
  have h6 := (integrableOn_pow_gaussian 6).const_mul ((η - 1) * a ^ 4 / 20 + a ^ 4 * η ^ 2 / 24)
  have h7 := (integrableOn_pow_gaussian 7).const_mul (a ^ 5 / (20 * Real.pi))
  have h8 := (integrableOn_pow_gaussian 8).const_mul (a ^ 6 * η ^ 2 / 40)
  have h45 : IntegrableOn (fun s => (η - 1) * a ^ 2 / 12 * (s ^ 4 * gaussian s) +
      a ^ 3 / (12 * Real.pi) * (s ^ 5 * gaussian s)) (Ioi 0) := h4.add h5
  have h456 : IntegrableOn (fun s => (η - 1) * a ^ 2 / 12 * (s ^ 4 * gaussian s) +
      a ^ 3 / (12 * Real.pi) * (s ^ 5 * gaussian s) +
      ((η - 1) * a ^ 4 / 20 + a ^ 4 * η ^ 2 / 24) * (s ^ 6 * gaussian s)) (Ioi 0) :=
    h45.add h6
  have h4567 : IntegrableOn (fun s => (η - 1) * a ^ 2 / 12 * (s ^ 4 * gaussian s) +
      a ^ 3 / (12 * Real.pi) * (s ^ 5 * gaussian s) +
      ((η - 1) * a ^ 4 / 20 + a ^ 4 * η ^ 2 / 24) * (s ^ 6 * gaussian s) +
      a ^ 5 / (20 * Real.pi) * (s ^ 7 * gaussian s)) (Ioi 0) := h456.add h7
  rw [integral_add h4567 h8, integral_add h456 h7, integral_add h45 h6, integral_add h4 h5,
    integral_const_mul, integral_const_mul, integral_const_mul, integral_const_mul,
    integral_const_mul]
  change a / Real.pi * ((η - 1) * a ^ 2 / 12 * halfMoment 4 +
    a ^ 3 / (12 * Real.pi) * halfMoment 5 +
    ((η - 1) * a ^ 4 / 20 + a ^ 4 * η ^ 2 / 24) * halfMoment 6 +
    a ^ 5 / (20 * Real.pi) * halfMoment 7 + a ^ 6 * η ^ 2 / 40 * halfMoment 8) = _
  rw [halfMoment_four, halfMoment_five, halfMoment_six, halfMoment_seven, halfMoment_eight]
  field_simp
  ring

lemma integrableOn_primaryLossIntegrand_real {a ξ : ℝ} (ha : 0 < a) :
    IntegrableOn (primaryLossIntegrand a ξ) (Ioo (0 : ℝ) (1 / a)) := by
  apply ((integrable_largeLossMajorant a).integrableOn).mono'
    (measurable_primaryLossIntegrand a ξ).aestronglyMeasurable
  filter_upwards [ae_restrict_mem measurableSet_Ioo] with s hs
  rw [Real.norm_eq_abs, abs_of_nonneg (primaryLossIntegrand_nonneg ha hs.1 hs.2)]
  exact primaryLossIntegrand_le_large ha hs.1 hs.2

lemma primaryLoss_le_neg {a η : ℝ} (ha : 0 < a) (hη : 1 ≤ η) :
    primaryLoss a (-η) ≤
      (η - 1) * phi0 * (a ^ 3 / 4 + 3 * a ^ 5 / 4) +
        a ^ 4 / Real.pi ^ 2 * (2 / 3 + 12 * a ^ 2 / 5) +
        η ^ 2 * phi0 * (5 * a ^ 5 / 8 + 21 * a ^ 7 / 8) := by
  rw [← integral_negLossMajorant a η]
  apply mul_le_mul_of_nonneg_left _ (div_nonneg ha.le Real.pi_pos.le)
  calc
    (∫ s in Ioo (0 : ℝ) (1 / a), primaryLossIntegrand a (-η) s) ≤
        ∫ s in Ioo (0 : ℝ) (1 / a), negLossMajorant a η s := by
      apply integral_mono_ae (integrableOn_primaryLossIntegrand_real ha)
        (integrable_negLossMajorant a η).integrableOn
      filter_upwards [ae_restrict_mem measurableSet_Ioo] with s hs
      exact primaryLossIntegrand_le_neg ha hη hs.1 hs.2
    _ ≤ ∫ s in Ioi (0 : ℝ), negLossMajorant a η s := by
      apply setIntegral_mono_set (integrable_negLossMajorant a η).integrableOn
      · filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
        unfold negLossMajorant gaussianProfileLoss
        have hs0 : 0 < s := hs
        have hg := gaussian_nonneg s
        have : 0 ≤ η - 1 := by linarith
        positivity
      · exact Filter.Eventually.of_forall (fun s hs => hs.1)

lemma primaryLoss_le_large_real {a ξ : ℝ} (ha : 0 < a) :
    primaryLoss a ξ ≤
      phi0 * a ^ 3 / 4 + a ^ 2 / (6 * Real.pi) + 3 * phi0 * a ^ 5 / 4 +
        2 * a ^ 4 / (5 * Real.pi) := by
  rw [← integral_largeLossMajorant a]
  apply mul_le_mul_of_nonneg_left _ (div_nonneg ha.le Real.pi_pos.le)
  calc
    (∫ s in Ioo (0 : ℝ) (1 / a), primaryLossIntegrand a ξ s) ≤
        ∫ s in Ioo (0 : ℝ) (1 / a), largeLossMajorant a s := by
      apply integral_mono_ae (integrableOn_primaryLossIntegrand_real ha)
        (integrable_largeLossMajorant a).integrableOn
      filter_upwards [ae_restrict_mem measurableSet_Ioo] with s hs
      exact primaryLossIntegrand_le_large ha hs.1 hs.2
    _ ≤ ∫ s in Ioi (0 : ℝ), largeLossMajorant a s := by
      apply setIntegral_mono_set (integrable_largeLossMajorant a).integrableOn
      · filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
        dsimp [largeLossMajorant]
        have hs0 : 0 < s := hs
        have hg := gaussian_nonneg s
        positivity
      · exact Filter.Eventually.of_forall (fun s hs => hs.1)

/-! ### The alias region at a negative location -/

lemma abs_upperKernel_neg_alias_bound {η t : ℝ} (hη : 0 ≤ η) (ht : 0 < t) (ht1 : t ≤ 1 / 2) :
    |upperKernel (-η) (1 - t)| ≤ zoneBAliasPolynomial η t := by
  have hr0 : 0 ≤ rho (1 - t) := rho_nonneg (by linarith) (by linarith)
  have hr := rho_alias_four_thirds ht ht1
  have hb : 0 ≤ Real.pi * η := mul_nonneg Real.pi_pos.le hη
  have hc := abs_cos_toward_bound hb ht.le
  have hs := abs_sin_toward_bound hb ht.le
  have hm := mul_le_mul hr hs (abs_nonneg _) (by positivity : 0 ≤ (4 / 3 : ℝ) * t ^ 2)
  have hn := mul_le_mul_of_nonneg_left hc ht.le
  have hlast := mul_le_mul_of_nonneg_left (Real.abs_cos_le_one (Real.pi * η))
    (by positivity : 0 ≤ (4 * Real.pi / 3) * η * t ^ 3)
  have e1 : Real.pi * -η * (1 - t) = -(Real.pi * η * (1 - t)) := by ring
  have hk : |upperKernel (-η) (1 - t)| ≤ t * |Real.cos (Real.pi * η * (1 - t))| +
      rho (1 - t) * |Real.sin (Real.pi * η * (1 - t))| := by
    unfold upperKernel
    rw [e1, Real.cos_neg, Real.sin_neg, sub_sub_cancel]
    calc |t * Real.cos (Real.pi * η * (1 - t)) + rho (1 - t) * -Real.sin (Real.pi * η * (1 - t))|
        ≤ |t * Real.cos (Real.pi * η * (1 - t))| +
          |rho (1 - t) * -Real.sin (Real.pi * η * (1 - t))| := abs_add_le _ _
      _ = _ := by rw [abs_mul, abs_mul, abs_neg, abs_of_pos ht, abs_of_nonneg hr0]
  refine hk.trans ?_
  unfold zoneBAliasPolynomial
  nlinarith only [hm, hn, hlast]

lemma zoneBAlias_reflected_bound_neg {a η s : ℝ} (ha : 0 < a) (hη : 0 ≤ η)
    (hs : 0 < s) (hsL : s ≤ (Real.pi - crossoverRoot) / a) :
    zoneBAliasIntegrand a (-η) (Real.pi / a - s) ≤
      zoneBAliasPolynomial η (a * s / Real.pi) * gaussian s := by
  have has : a * s ≤ Real.pi / 2 := by
    have h := (le_div_iff₀ ha).mp hsL
    nlinarith [crossoverRoot_spec.1]
  have ht : 0 < a * s / Real.pi := by positivity
  have ht1 : a * s / Real.pi ≤ 1 / 2 := (div_le_iff₀ Real.pi_pos).mpr (by linarith)
  have hk := abs_upperKernel_neg_alias_bound hη ht ht1
  have hp := ZoneA.cosine_alias_profile_bound ha hs.le has
  have he1 : a * (Real.pi / a - s) / Real.pi = 1 - a * s / Real.pi := by
    field_simp
  have he2 : a * (Real.pi / a - s) = Real.pi - a * s := by field_simp
  unfold zoneBAliasIntegrand cosineProfile
  rw [he1, he2]
  exact mul_le_mul hk hp (Real.rpow_nonneg (abs_nonneg _) _)
    (zoneBAliasPolynomial_nonneg hη ht.le)

theorem zoneBAliasIntegral_le_neg {a η : ℝ} (ha : 0 < a) (hη : 0 ≤ η) :
    zoneBAliasIntegral a (-η) ≤ zoneBAliasValue a η := by
  let L : ℝ := (Real.pi - crossoverRoot) / a
  have hL : 0 ≤ L := div_nonneg (sub_nonneg.mpr crossoverRoot_spec.2.1.le) ha.le
  have hf := intervalIntegrable_zoneBAlias ha (-η)
  have hfr : IntervalIntegrable
      (fun s => zoneBAliasIntegrand a (-η) (Real.pi / a - s)) volume 0 L := by
    have h := (hf.comp_sub_left (Real.pi / a)).symm
    have he : Real.pi / a - crossoverRoot / a = L := by dsimp [L]; ring
    simpa only [sub_self, he] using h
  have hp : Continuous (fun s => zoneBAliasPolynomial η (a * s / Real.pi) * gaussian s) := by
    unfold zoneBAliasPolynomial gaussian
    fun_prop
  have hi : (∫ s in (0 : ℝ)..L, zoneBAliasIntegrand a (-η) (Real.pi / a - s)) ≤
      ∫ s in (0 : ℝ)..L, zoneBAliasPolynomial η (a * s / Real.pi) * gaussian s := by
    apply intervalIntegral.integral_mono_on_of_le_Ioo hL hfr (hp.intervalIntegrable 0 L)
    intro s hs
    exact zoneBAlias_reflected_bound_neg ha hη hs.1 hs.2.le
  have hreflect := intervalIntegral.integral_comp_sub_left (zoneBAliasIntegrand a (-η))
    (a := (0 : ℝ)) (b := L) (Real.pi / a)
  have he : Real.pi / a - L = crossoverRoot / a := by dsimp [L]; ring
  rw [he, sub_zero] at hreflect
  rw [hreflect, intervalIntegral.integral_of_le hL] at hi
  have hm := mul_le_mul_of_nonneg_left hi (by positivity : 0 ≤ a / Real.pi)
  have hext : (∫ s in Ioc (0 : ℝ) L, zoneBAliasPolynomial η (a * s / Real.pi) * gaussian s) ≤
      ∫ s in Ioi (0 : ℝ), zoneBAliasPolynomial η (a * s / Real.pi) * gaussian s := by
    apply setIntegral_mono_set (integrable_zoneBAliasPolynomial a η).integrableOn
    · filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
      exact mul_nonneg (zoneBAliasPolynomial_nonneg hη
        (div_nonneg (mul_nonneg ha.le hs.le) Real.pi_pos.le)) (gaussian_nonneg s)
    · exact Filter.Eventually.of_forall fun s hs => hs.1
  unfold zoneBAliasIntegral
  exact hm.trans ((mul_le_mul_of_nonneg_left hext (by positivity)).trans_eq
    (integral_zoneBAliasPolynomial a η))

/-! ### The exponentially small remainders for `a ≤ 1/10` -/

lemma gaussian_inverse_le_power16 {a : ℝ} (ha : 0 < a) :
    gaussian (1 / a) ≤ 10321920 * a ^ 16 := by
  have hv : 0 < 1 / (2 * a ^ 2) := by positivity
  have h : (1 / (2 * a ^ 2)) ^ 8 / 40320 ≤ Real.exp (1 / (2 * a ^ 2)) := by
    convert Real.pow_div_factorial_le_exp (1 / (2 * a ^ 2)) hv.le 8 using 1
  have hp : 0 < (1 / (2 * a ^ 2)) ^ 8 / 40320 := by positivity
  have hi := one_div_le_one_div_of_le hp h
  have he : -(1 / a) ^ 2 / 2 = -(1 / (2 * a ^ 2)) := by field_simp [ha.ne']; ring
  rw [gaussian, he, Real.exp_neg]
  have hpow : 1 / ((1 / (2 * a ^ 2)) ^ 8 / 40320) = 10321920 * a ^ 16 := by
    field_simp [ha.ne']
    ring
  rw [hpow] at hi
  simpa only [one_div] using hi

lemma gaussian_remainder_budget_tenth {a : ℝ} (ha : 0 < a) (ha1 : a ≤ 1 / 10) :
    a ^ 4 / (15 * Real.pi) + 9 * gaussian (1 / a) ≤ a ^ 4 / 40 := by
  have h12 := pow_le_pow_left₀ ha.le ha1 12
  have hnum : (9 * 10321920 : ℝ) * (1 / 10) ^ 12 ≤ 1 / 1000 := by norm_num
  have hcoeff : (9 * 10321920 : ℝ) * a ^ 12 ≤ 1 / 1000 := by nlinarith
  have hmul := mul_le_mul_of_nonneg_left hcoeff (pow_nonneg ha.le 4)
  have he : a ^ 4 * ((9 * 10321920 : ℝ) * a ^ 12) = 9 * 10321920 * a ^ 16 := by ring
  rw [he] at hmul
  have hg := gaussian_inverse_le_power16 ha
  have htail : 9 * gaussian (1 / a) ≤ a ^ 4 / 1000 := by nlinarith only [hmul, hg]
  have hpi : (1 : ℝ) / (15 * Real.pi) ≤ 1 / 45 := by
    apply (div_le_iff₀ (by positivity : (0 : ℝ) < 15 * Real.pi)).2
    linarith [Real.pi_gt_three]
  have hp := mul_le_mul_of_nonneg_left hpi (pow_nonneg ha.le 4)
  have hp' : a ^ 4 / (15 * Real.pi) ≤ a ^ 4 / 45 := by
    convert hp using 1 <;> ring
  nlinarith only [htail, hp', pow_nonneg ha.le 4]

/-! ### Elementary facts used by the closure -/

lemma sin_ge_sub_cube_div_six {y : ℝ} (hy : 0 ≤ y) : y - y ^ 3 / 6 ≤ Real.sin y := by
  have h := (Num.cos_sin_taylor 1 y hy).2
  simp only [Num.sinPoly, Finset.sum_range_succ, Finset.sum_range_zero] at h
  norm_num [Nat.factorial] at h
  linarith

lemma gaussianD_ge_cubic {x : ℝ} (hx : 0 ≤ x) : x - x ^ 3 / 3 ≤ gaussianD x := by
  have hi := (integrable_pow_sin_gaussian 0 x).integrableOn (s := Ioi (0 : ℝ))
  simp only [pow_zero, one_mul] at hi
  have h1 : IntegrableOn (fun s => x * (s * gaussian s)) (Ioi 0) := by
    simpa using (integrableOn_pow_gaussian 1).const_mul x
  have h3 : IntegrableOn (fun s => x ^ 3 / 6 * (s ^ 3 * gaussian s)) (Ioi 0) :=
    (integrableOn_pow_gaussian 3).const_mul _
  have e1 : (∫ s in Ioi (0 : ℝ), s * gaussian s) = 1 := by
    simpa [halfMoment] using halfMoment_one
  have e3 : (∫ s in Ioi (0 : ℝ), s ^ 3 * gaussian s) = 2 := by
    simpa [halfMoment] using halfMoment_three
  calc
    x - x ^ 3 / 3 =
        ∫ s in Ioi (0 : ℝ), (x * (s * gaussian s) - x ^ 3 / 6 * (s ^ 3 * gaussian s)) := by
      rw [integral_sub h1 h3, integral_const_mul, integral_const_mul, e1, e3]
      ring
    _ ≤ gaussianD x := by
      apply integral_mono_ae (h1.sub h3) hi
      filter_upwards [ae_restrict_mem measurableSet_Ioi] with s hs
      have h := mul_le_mul_of_nonneg_right (sin_ge_sub_cube_div_six (mul_nonneg hs.le hx))
        (gaussian_nonneg s)
      have e : (s * x - (s * x) ^ 3 / 6) * gaussian s =
          x * (s * gaussian s) - x ^ 3 / 6 * (s ^ 3 * gaussian s) := by ring
      rw [e] at h
      exact h

lemma gaussianN_nonneg_of_le_one {x : ℝ} (hx : 0 ≤ x) (hx1 : x ≤ 1) : 0 ≤ gaussianN x := by
  rw [gaussianN_eq, gaussianM_eq]
  have hD := gaussianD_ge_cubic hx
  have hx2 : x ^ 2 ≤ 1 := by nlinarith
  have hx3 : x ^ 3 ≤ x := by nlinarith
  have hD0 : 0 ≤ gaussianD x := by linarith
  have hsq : 0 ≤ 1 - x ^ 2 := by linarith
  nlinarith [mul_nonneg hD0 hsq]

lemma exp_neg_half_le : Real.exp (-(1 / 2 : ℝ)) ≤ 5 / 8 := by
  have he := Real.sum_le_exp_of_nonneg (by norm_num : 0 ≤ (1 / 2 : ℝ)) 4
  norm_num [Finset.sum_range_succ, Nat.factorial] at he
  rw [Real.exp_neg]
  have hh : 1 / Real.exp (1 / 2 : ℝ) ≤ (5 / 8 : ℝ) := by
    apply (div_le_iff₀ (Real.exp_pos _)).mpr
    linarith
  simpa only [one_div] using hh

lemma mul_gaussian_le (x : ℝ) : x * gaussian x ≤ 5 / 8 := by
  have h1 := Real.add_one_le_exp ((x ^ 2 - 1) / 2)
  have h2 : x ≤ Real.exp ((x ^ 2 - 1) / 2) := by nlinarith [sq_nonneg (x - 1)]
  have e : Real.exp ((x ^ 2 - 1) / 2) * gaussian x = Real.exp (-(1 / 2 : ℝ)) := by
    unfold gaussian
    rw [← Real.exp_add]
    congr 1
    ring
  calc
    x * gaussian x ≤ Real.exp ((x ^ 2 - 1) / 2) * gaussian x :=
      mul_le_mul_of_nonneg_right h2 (gaussian_nonneg x)
    _ = Real.exp (-(1 / 2 : ℝ)) := e
    _ ≤ 5 / 8 := exp_neg_half_le

lemma zoneBAliasEta_nonneg : 0 ≤ zoneBAliasEta := ZoneB.eta_nonneg

lemma zoneBAliasEta_le : zoneBAliasEta ≤ 5 / 6 := ZoneB.eta_le

/-- In the lower half the threshold `c(a) < e^{-x²/2}` forces `a x² ≤ 4/5` when `a ≤ 1/10`. -/
lemma mul_sq_le_of_lt_exp {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 1 / 10)
    (h : c a < Real.exp (-(x ^ 2) / 2)) : a * x ^ 2 ≤ 4 / 5 := by
  by_contra hcon
  push_neg at hcon
  set t := 2 / (5 * a) with ht
  have hat : a * t = 2 / 5 := by
    rw [ht]
    field_simp
    ring
  have ht4 : 4 ≤ t := by
    rw [ht, le_div_iff₀ (by positivity)]
    linarith
  have hxt : t ≤ x ^ 2 / 2 := by
    have h5 : 2 / 5 ≤ a * (x ^ 2 / 2) := by linarith
    nlinarith
  have hexp := Real.sum_le_exp_of_nonneg (by linarith : 0 ≤ t) 5
  norm_num [Finset.sum_range_succ, Nat.factorial] at hexp
  have h2 : 4 * t ≤ t ^ 2 := by nlinarith
  have h3 : 16 * t ≤ t ^ 3 := by nlinarith
  have h4 : 64 * t ≤ t ^ 4 := by nlinarith
  have hlow : 25 / 3 * t ≤ Real.exp t := by nlinarith
  have hneg : Real.exp (-t) ≤ 3 * a / 10 := by
    have hpos := Real.exp_pos t
    have hprod : Real.exp (-t) * Real.exp t = 1 := by
      rw [← Real.exp_add]
      simp
    have h1 : 1 ≤ 3 * a / 10 * Real.exp t := by nlinarith
    by_contra hlt
    have hm := mul_lt_mul_of_pos_right (not_le.mp hlt) hpos
    linarith
  have hmono : Real.exp (-(x ^ 2) / 2) ≤ Real.exp (-t) := Real.exp_le_exp.mpr (by linarith)
  have hc := c_lower_cubic ha.le
  have hφ := ZoneA.phi0_lower
  have ha2 : a ^ 2 ≤ 1 / 100 := by nlinarith
  have ha3 : a ^ 3 ≤ a / 100 := by nlinarith [mul_le_mul_of_nonneg_left ha2 ha.le]
  have hcl : 3 * a / 10 ≤ c a := by nlinarith
  linarith

/-! ### Closing the small-`x` case `3a/2 ≤ x ≤ 1` -/

lemma lowerSmallPoly_le {a ξ : ℝ} (ha : 0 ≤ a) (ha1 : a ≤ 1 / 10) (hξ : 3 / 2 ≤ ξ)
    (hax : a * ξ ≤ 1) :
    (1 / 6 - ξ ^ 2 / 2 + a ^ 2 * ξ ^ 4 / 8) + ξ / 3 + a * (100 / 351) * ξ ^ 2 +
      ((ξ - 1) * (1 / 4 + 3 * a ^ 2 / 4) + ξ ^ 2 * (5 * a ^ 2 / 8 + 21 * a ^ 4 / 8)) +
      a * (100 / 351) * (2 / 3 + 12 * a ^ 2 / 5) + a * ((ξ + 5 / 6) ^ 2 / 5) +
      a * (200 / 1053) * (ξ + 1) + a * (5 / 78) ≤ 0 := by
  have hξ0 : 0 ≤ ξ := by linarith
  have ha2 : a ^ 2 ≤ 1 / 100 := by nlinarith
  have ha4 : a ^ 4 ≤ 1 / 10000 := by nlinarith
  have hlin : (ξ - 1) * (1 / 4 + 3 * a ^ 2 / 4) ≤ (ξ - 1) * (1 / 4 + 3 / 400) :=
    mul_le_mul_of_nonneg_left (by linarith) (by linarith)
  have hquad : ξ ^ 2 * (5 * a ^ 2 / 8 + 21 * a ^ 4 / 8) ≤ ξ ^ 2 * (5 / 800 + 21 / 80000) :=
    mul_le_mul_of_nonneg_left (by linarith) (sq_nonneg ξ)
  have hK0 : 0 ≤ (100 / 351) * ξ ^ 2 + (100 / 351) * (2 / 3 + 12 / 500) +
      (ξ + 5 / 6) ^ 2 / 5 + (200 / 1053) * (ξ + 1) + 5 / 78 := by positivity
  have hK1 := mul_le_mul_of_nonneg_right ha1 hK0
  have hK2 : a * (100 / 351) * (12 * a ^ 2 / 5) ≤ a * (100 / 351) * (12 / 500) :=
    mul_le_mul_of_nonneg_left (by linarith) (by positivity)
  have hK : a * (100 / 351) * ξ ^ 2 + a * (100 / 351) * (2 / 3 + 12 * a ^ 2 / 5) +
      a * ((ξ + 5 / 6) ^ 2 / 5) + a * (200 / 1053) * (ξ + 1) + a * (5 / 78) ≤
      1 / 10 * ((100 / 351) * ξ ^ 2 + (100 / 351) * (2 / 3 + 12 / 500) +
        (ξ + 5 / 6) ^ 2 / 5 + (200 / 1053) * (ξ + 1) + 5 / 78) := by
    nlinarith only [hK1, hK2]
  have hsq := mul_nonneg (sub_nonneg.2 hξ) (sub_nonneg.2 hξ)
  rcases le_total ξ 4 with hξ4 | hξ4
  · have hξ2 : ξ ^ 2 ≤ 16 := by nlinarith
    have h4 : a ^ 2 * ξ ^ 4 ≤ 16 / 100 * ξ ^ 2 := by
      have hm := mul_le_mul ha2 (mul_le_mul_of_nonneg_left hξ2 (sq_nonneg ξ))
        (by positivity) (by norm_num)
      nlinarith only [hm]
    nlinarith only [hlin, hquad, hK, h4, hξ, hsq]
  · have hax2 : a ^ 2 * ξ ^ 2 ≤ 1 := by
      have hh := pow_le_pow_left₀ (mul_nonneg ha hξ0) hax 2
      simpa only [mul_pow, one_pow] using hh
    have h4 : a ^ 2 * ξ ^ 4 ≤ ξ ^ 2 := by
      have hh := mul_le_mul_of_nonneg_right hax2 (sq_nonneg ξ)
      nlinarith only [hh]
    nlinarith only [hlin, hquad, hK, h4, hξ, hsq]

lemma lowerSmall_close_small {a ξ : ℝ} (ha : 0 < a) (ha1 : a ≤ 1 / 10) (hξ : 3 / 2 ≤ ξ)
    (hax : a * ξ ≤ 1) :
    (a * phi (a * ξ) - c a + a ^ 2 * (a * ξ) * phi (a * ξ) / 3 +
        a ^ 2 * (a * ξ) * gaussianD (a * ξ) / Real.pi ^ 2 -
        a ^ 3 * gaussianN (a * ξ) / (3 * Real.pi ^ 2)) +
      ((ξ - 1) * phi0 * (a ^ 3 / 4 + 3 * a ^ 5 / 4) +
        a ^ 4 / Real.pi ^ 2 * (2 / 3 + 12 * a ^ 2 / 5) +
        ξ ^ 2 * phi0 * (5 * a ^ 5 / 8 + 21 * a ^ 7 / 8)) +
      (phi0 ^ 2 / 2 * (ξ + zoneBAliasEta) ^ 2 * a ^ 4 + 6 * (ξ + 1) * a ^ 4 / Real.pi ^ 4) +
      a ^ 4 / 40 ≤ 0 := by
  have hξ0 : 0 ≤ ξ := by linarith
  have hx : 0 ≤ a * ξ := mul_nonneg ha.le hξ0
  have hφ0 := phi0_pos
  have hcu := mul_le_mul_of_nonneg_left (ZoneB.phi_upper_quartic (a * ξ)) ha.le
  have hca := c_lower_cubic ha.le
  have hT1 : a * phi (a * ξ) - c a ≤ phi0 * a ^ 3 * (1 / 6 - ξ ^ 2 / 2 + a ^ 2 * ξ ^ 4 / 8) := by
    nlinarith only [hcu, hca]
  have hphi_le : phi (a * ξ) ≤ phi0 := by
    unfold phi
    nlinarith [gaussian_le_one (a * ξ)]
  have hT2 : a ^ 2 * (a * ξ) * phi (a * ξ) / 3 ≤ phi0 * a ^ 3 * (ξ / 3) := by
    have hm := mul_le_mul_of_nonneg_left hphi_le (show 0 ≤ a ^ 2 * (a * ξ) / 3 by positivity)
    nlinarith only [hm]
  have hdg := mul_le_mul_of_nonneg_left (gaussianD_le_self hx) hx
  have hd1 := div_le_div_of_nonneg_right hdg (sq_nonneg Real.pi)
  have hd2 := mul_le_mul_of_nonneg_left hd1 (sq_nonneg a)
  have hd3 := mul_le_mul_of_nonneg_right ZoneB.inv_pi_sq_le_scaled_phi0
    (show 0 ≤ a ^ 4 * ξ ^ 2 by positivity)
  have hT3 : a ^ 2 * (a * ξ) * gaussianD (a * ξ) / Real.pi ^ 2 ≤
      phi0 * a ^ 3 * (a * (100 / 351) * ξ ^ 2) := by
    calc
      _ = a ^ 2 * ((a * ξ) * gaussianD (a * ξ) / Real.pi ^ 2) := by ring
      _ ≤ a ^ 2 * ((a * ξ) ^ 2 / Real.pi ^ 2) := by
        convert hd2 using 1
        ring
      _ = (1 / Real.pi ^ 2) * (a ^ 4 * ξ ^ 2) := by ring
      _ ≤ (100 / 351) * phi0 * (a ^ 4 * ξ ^ 2) := hd3
      _ = _ := by ring
  have hN := gaussianN_nonneg_of_le_one hx hax
  have hT4 : 0 ≤ a ^ 3 * gaussianN (a * ξ) / (3 * Real.pi ^ 2) := by positivity
  have hp5 := mul_le_mul_of_nonneg_right ZoneB.inv_pi_sq_le_scaled_phi0
    (show 0 ≤ a ^ 4 * (2 / 3 + 12 * a ^ 2 / 5) by positivity)
  have hT5 : a ^ 4 / Real.pi ^ 2 * (2 / 3 + 12 * a ^ 2 / 5) ≤
      phi0 * a ^ 3 * (a * (100 / 351) * (2 / 3 + 12 * a ^ 2 / 5)) := by
    calc
      _ = (1 / Real.pi ^ 2) * (a ^ 4 * (2 / 3 + 12 * a ^ 2 / 5)) := by ring
      _ ≤ (100 / 351) * phi0 * (a ^ 4 * (2 / 3 + 12 * a ^ 2 / 5)) := hp5
      _ = _ := by ring
  have hηsq : (ξ + zoneBAliasEta) ^ 2 ≤ (ξ + 5 / 6) ^ 2 :=
    pow_le_pow_left₀ (add_nonneg hξ0 zoneBAliasEta_nonneg)
      (add_le_add_left zoneBAliasEta_le ξ) 2
  have hph : phi0 / 2 ≤ (1 / 5 : ℝ) := by linarith [ZoneA.phi0_upper]
  have hq := mul_le_mul hph hηsq (sq_nonneg _) (by norm_num : 0 ≤ (1 / 5 : ℝ))
  have hqm := mul_le_mul_of_nonneg_left hq (show 0 ≤ phi0 * a ^ 4 by positivity)
  have hT6a : phi0 ^ 2 / 2 * (ξ + zoneBAliasEta) ^ 2 * a ^ 4 ≤
      phi0 * a ^ 3 * (a * ((ξ + 5 / 6) ^ 2 / 5)) := by
    nlinarith only [hqm]
  have hb0 := mul_le_mul_of_nonneg_right ZoneB.six_div_pi_fourth_le_scaled_phi0
    (show 0 ≤ (ξ + 1) * a ^ 4 by positivity)
  have hT6b : 6 * (ξ + 1) * a ^ 4 / Real.pi ^ 4 ≤
      phi0 * a ^ 3 * (a * (200 / 1053) * (ξ + 1)) := by
    calc
      _ = 6 / Real.pi ^ 4 * ((ξ + 1) * a ^ 4) := by ring
      _ ≤ (200 / 1053) * phi0 * ((ξ + 1) * a ^ 4) := hb0
      _ = _ := by ring
  have hr0 : (1 / 40 : ℝ) ≤ (5 / 78) * phi0 := by linarith [ZoneA.phi0_lower]
  have hr1 := mul_le_mul_of_nonneg_right hr0 (pow_nonneg ha.le 4)
  have hT7 : a ^ 4 / 40 ≤ phi0 * a ^ 3 * (a * (5 / 78)) := by
    nlinarith only [hr1]
  have hP := lowerSmallPoly_le ha.le ha1 hξ hax
  have hPm := mul_le_mul_of_nonneg_left hP (show 0 ≤ phi0 * a ^ 3 by positivity)
  nlinarith only [hT1, hT2, hT3, hT4, hT5, hT6a, hT6b, hT7, hPm]

/-! ### Closing the large-`x` case `1 < x`, `a x² ≤ 4/5` -/

lemma lowerSmall_close_large {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 1 / 10) (hx : 1 ≤ x)
    (hax2 : a * x ^ 2 ≤ 4 / 5) :
    (a * phi x - c a + a ^ 2 * x * phi x / 3 + a ^ 2 * x * gaussianD x / Real.pi ^ 2 -
        a ^ 3 * gaussianN x / (3 * Real.pi ^ 2)) +
      (phi0 * a ^ 3 / 4 + a ^ 2 / (6 * Real.pi) + 3 * phi0 * a ^ 5 / 4 +
        2 * a ^ 4 / (5 * Real.pi)) +
      (phi0 ^ 2 / 2 * (x / a + zoneBAliasEta) ^ 2 * a ^ 4 +
        6 * (x / a + 1) * a ^ 4 / Real.pi ^ 4) +
      a ^ 4 / 40 ≤ 0 := by
  have hx0 : 0 ≤ x := by linarith
  have hxx : x ≤ x ^ 2 := by nlinarith
  have hax : a * x ≤ 4 / 5 := (mul_le_mul_of_nonneg_left hxx ha.le).trans hax2
  have haxm := mul_le_mul_of_nonneg_left hax (sq_nonneg a)
  have hφg := mul_le_mul_of_nonneg_left (ZoneB.phi_gap_large hx) ha.le
  have hca := c_lower_cubic ha.le
  have hφ3 := mul_le_mul_of_nonneg_right ZoneA.phi0_upper (pow_nonneg ha.le 3)
  have hnormal : a * phi x - c a ≤ -(117 / 800) * a + a ^ 3 / 15 := by
    nlinarith only [hφg, hca, hφ3]
  have hxphi : x * phi x ≤ 1 / 4 := by
    have hm := mul_le_mul (mul_gaussian_le x) ZoneA.phi0_upper phi0_pos.le
      (by norm_num : (0 : ℝ) ≤ 5 / 8)
    unfold phi
    nlinarith only [hm]
  have hphiterm : a ^ 2 * x * phi x / 3 ≤ a ^ 2 / 12 := by
    have hm := mul_le_mul_of_nonneg_left hxphi (sq_nonneg a)
    nlinarith only [hm]
  have hDcoef : x * gaussianD x / Real.pi ^ 2 ≤ (2 / 9 : ℝ) := by
    apply (div_le_iff₀ (sq_pos_of_pos Real.pi_pos)).mpr
    nlinarith [mul_gaussianD_le_two x, ZoneA.pi_sq_lower]
  have hD0 := mul_le_mul_of_nonneg_left hDcoef (sq_nonneg a)
  have hd : a ^ 2 * x * gaussianD x / Real.pi ^ 2 ≤ 2 * a ^ 2 / 9 := by
    convert hD0 using 1 <;> ring
  have hN0 := mul_le_mul_of_nonneg_left (ZoneB.gaussianN_scaled_large (-x)) (pow_nonneg ha.le 3)
  rw [gaussianN_odd] at hN0
  have hn : -(a ^ 3 * gaussianN x / (3 * Real.pi ^ 2)) ≤ 2 * a ^ 3 / 45 := by
    have e : a ^ 3 * (-gaussianN x / (3 * Real.pi ^ 2)) =
        -(a ^ 3 * gaussianN x / (3 * Real.pi ^ 2)) := by ring
    rw [← e]
    linarith
  have hinv6 : (1 : ℝ) / (6 * Real.pi) ≤ 1 / 18 := by
    apply (div_le_iff₀ (by positivity : 0 < 6 * Real.pi)).mpr
    linarith [Real.pi_gt_three]
  have hinv5 : (2 : ℝ) / (5 * Real.pi) ≤ 2 / 15 := by
    apply (div_le_iff₀ (by positivity : 0 < 5 * Real.pi)).mpr
    linarith [Real.pi_gt_three]
  have hv2 := mul_le_mul_of_nonneg_right hinv6 (sq_nonneg a)
  have hv4 := mul_le_mul_of_nonneg_right hinv5 (pow_nonneg ha.le 4)
  have hv5 := mul_le_mul_of_nonneg_right ZoneA.phi0_upper (pow_nonneg ha.le 5)
  have hv2' : a ^ 2 / (6 * Real.pi) ≤ a ^ 2 / 18 := by
    convert hv2 using 1 <;> ring
  have hv4' : 2 * a ^ 4 / (5 * Real.pi) ≤ 2 * a ^ 4 / 15 := by
    convert hv4 using 1 <;> ring
  have hprimary : phi0 * a ^ 3 / 4 + a ^ 2 / (6 * Real.pi) +
      3 * phi0 * a ^ 5 / 4 + 2 * a ^ 4 / (5 * Real.pi) ≤
      a ^ 3 / 10 + a ^ 2 / 18 + 3 * a ^ 5 / 10 + 2 * a ^ 4 / 15 := by
    nlinarith only [hφ3, hv2', hv4', hv5]
  have hη2 : zoneBAliasEta ^ 2 ≤ (5 / 6 : ℝ) ^ 2 :=
    pow_le_pow_left₀ zoneBAliasEta_nonneg zoneBAliasEta_le 2
  have hfirst := mul_le_mul_of_nonneg_left hax2 ha.le
  have hmiddle := mul_le_mul_of_nonneg_right zoneBAliasEta_le
    (show 0 ≤ 2 * a ^ 3 * x by positivity)
  have hlast := mul_le_mul_of_nonneg_right hη2 (pow_nonneg ha.le 4)
  have hcore : a ^ 2 * x ^ 2 + 2 * zoneBAliasEta * a ^ 3 * x + zoneBAliasEta ^ 2 * a ^ 4 ≤
      4 * a / 5 + 4 * a ^ 2 / 3 + 25 * a ^ 4 / 36 := by
    nlinarith only [hfirst, hmiddle, hlast, haxm]
  have hcore0 : 0 ≤ a ^ 2 * x ^ 2 + 2 * zoneBAliasEta * a ^ 3 * x +
      zoneBAliasEta ^ 2 * a ^ 4 := by
    have := zoneBAliasEta_nonneg
    positivity
  have hφ2 := pow_le_pow_left₀ phi0_pos.le ZoneA.phi0_upper 2
  have hφhalf : phi0 ^ 2 / 2 ≤ (2 / 25 : ℝ) := by nlinarith only [hφ2]
  have hproduct := mul_le_mul hφhalf hcore hcore0 (by norm_num : 0 ≤ (2 / 25 : ℝ))
  have heq : (x / a + zoneBAliasEta) ^ 2 * a ^ 4 =
      a ^ 2 * x ^ 2 + 2 * zoneBAliasEta * a ^ 3 * x + zoneBAliasEta ^ 2 * a ^ 4 := by
    field_simp
    ring
  have halias : phi0 ^ 2 / 2 * (x / a + zoneBAliasEta) ^ 2 * a ^ 4 ≤
      (2 / 25) * (4 * a / 5 + 4 * a ^ 2 / 3 + 25 * a ^ 4 / 36) := by
    calc
      _ = phi0 ^ 2 / 2 * ((x / a + zoneBAliasEta) ^ 2 * a ^ 4) := by ring
      _ = phi0 ^ 2 / 2 * (a ^ 2 * x ^ 2 + 2 * zoneBAliasEta * a ^ 3 * x +
          zoneBAliasEta ^ 2 * a ^ 4) := by rw [heq]
      _ ≤ _ := hproduct
  have hp4 : (81 : ℝ) ≤ Real.pi ^ 4 := by
    nlinarith [ZoneA.pi_sq_lower, sq_nonneg (Real.pi ^ 2 - 9)]
  have hbcoef : (6 : ℝ) / Real.pi ^ 4 ≤ 2 / 27 := by
    apply (div_le_iff₀ (by positivity : 0 < Real.pi ^ 4)).mpr
    nlinarith only [hp4]
  have hbcore : (x / a + 1) * a ^ 4 ≤ 4 * a ^ 2 / 5 + a ^ 4 := by
    have heq' : (x / a + 1) * a ^ 4 = a ^ 3 * x + a ^ 4 := by
      field_simp
      ring
    rw [heq']
    nlinarith only [haxm]
  have hb0 := mul_le_mul hbcoef hbcore
    (show 0 ≤ (x / a + 1) * a ^ 4 by positivity) (by norm_num : 0 ≤ (2 / 27 : ℝ))
  have hb : 6 * (x / a + 1) * a ^ 4 / Real.pi ^ 4 ≤ (2 / 27) * (4 * a ^ 2 / 5 + a ^ 4) := by
    calc
      _ = 6 / Real.pi ^ 4 * ((x / a + 1) * a ^ 4) := by ring
      _ ≤ _ := hb0
  have ha2 : a ^ 2 ≤ 1 / 100 := by nlinarith
  have ha3 : a ^ 3 ≤ 1 / 1000 := by nlinarith
  have ha4 : a ^ 4 ≤ 1 / 10000 := by nlinarith
  have hB : -(117 / 800 : ℝ) + 8 / 125 +
      a * (1 / 12 + 2 / 9 + 1 / 18 + 8 / 75 + 8 / 135) +
      a ^ 2 * (1 / 15 + 2 / 45 + 1 / 10) + a ^ 3 * (2 / 15 + 1 / 18 + 2 / 27 + 1 / 40) +
      a ^ 4 * (3 / 10) ≤ 0 := by
    nlinarith only [ha1, ha2, ha3, ha4]
  have hBm := mul_le_mul_of_nonneg_left hB ha.le
  nlinarith only [hnormal, hphiterm, hd, hn, hprimary, halias, hb, hBm]

/-! ### The lower half for `a ≤ 1/10` -/

theorem lowerFourier_small {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 1 / 10) (hx : 3 * a / 2 ≤ x)
    (hxe : c a < Real.exp (-(x ^ 2) / 2)) : JUpper a (-x) ≤ c a - c x := by
  have ha2 : a ≤ 1 / 2 := by linarith
  have hη : 3 / 2 ≤ x / a := (le_div_iff₀ ha).mpr (by linarith)
  have hη0 : 0 ≤ x / a := by linarith
  have hdec := JUpper_le_gaussian_primary_alias_real (y := -x) ha ha2
  rw [neg_div] at hdec
  have hbase := scaledGaussianKernelIntegral_le (x := -x) ha ha2
  have hcommon := gaussianBaselineValue_eq_common a (-x)
  rw [c_neg, zoneBCommon_neg] at hcommon
  have halias := zoneBAliasIntegral_le_neg ha hη0
  have hcomp := zoneBAliasValue_compensated ha hη0
  have hrem := gaussian_remainder_budget_tenth ha ha1
  have hg0 := gaussian_nonneg (1 / a)
  have hcoef : a ^ 2 / (2 * Real.pi) ≤ 2 := by
    rw [div_le_iff₀ (by positivity)]
    nlinarith [Real.pi_gt_three]
  have hcoefm := mul_le_mul_of_nonneg_right hcoef hg0
  have hkey : JUpper a (-x) - (c a - c x) ≤
      (a * phi x - c a + a ^ 2 * x * phi x / 3 + a ^ 2 * x * gaussianD x / Real.pi ^ 2 -
        a ^ 3 * gaussianN x / (3 * Real.pi ^ 2)) + primaryLoss a (-(x / a)) +
      (phi0 ^ 2 / 2 * (x / a + zoneBAliasEta) ^ 2 * a ^ 4 +
        6 * (x / a + 1) * a ^ 4 / Real.pi ^ 4) + a ^ 4 / 40 := by
    nlinarith only [hdec, hbase, hcommon, halias, hcomp, hrem, hg0, hcoefm]
  have heq : a * (x / a) = x := by field_simp
  rcases le_or_gt x 1 with hx1 | hx1
  · have hP := primaryLoss_le_neg ha (show 1 ≤ x / a by linarith)
    have hc := lowerSmall_close_small ha ha1 hη (by rw [heq]; exact hx1)
    rw [heq] at hc
    linarith
  · have hax2 := mul_sq_le_of_lt_exp ha ha1 hxe
    have hP := primaryLoss_le_large_real (ξ := -(x / a)) ha
    have hc := lowerSmall_close_large ha ha1 hx1.le hax2
    linarith

end

end KellerKlein
