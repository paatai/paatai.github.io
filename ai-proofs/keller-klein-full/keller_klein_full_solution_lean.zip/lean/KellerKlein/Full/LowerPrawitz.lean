import KellerKlein.Full.Reduction

/-!
# Prawitz' minorant for the open concentration event

Dev Goyal's Prawitz identity
`M(T(y - z)) + M(T(y + z)) - 1 = 2 ∫₀¹ K_y(u) cos(Tuz) du` holds for every real `y`.
At `y = -x` it gives a minorant of `1_{(-x, x)}`, hence
`P[|X| < x] ≥ -2 J(a, -x)`, where `J = JUpper` is the same envelope integral that
bounds the closed event from above.  Both halves of the conjecture therefore reduce to
`J(a, y) ≤ c a + c y`.
-/

open MeasureTheory Set
open scoped BigOperators

namespace KellerKlein

noncomputable section

lemma prawitzMajorantValue_nonneg (z : ℝ) : 0 ≤ prawitzMajorantValue z := by
  have h := prawitz_indicator_majorant z
  unfold prawitzMajorantValue
  split_ifs at h <;> linarith

lemma open_interval_indicator_ge_prawitz {x T : ℝ} (hT : 0 < T) (y : ℝ) :
    -(prawitzMajorantValue (T * (-x - y)) + prawitzMajorantValue (T * (-x + y)) - 1) ≤
      (if |y| < x then (1 : ℝ) else 0) := by
  have hm := prawitz_indicator_majorant (T * (-x - y))
  have hp := prawitz_indicator_majorant (T * (-x + y))
  have hm0 := prawitzMajorantValue_nonneg (T * (-x - y))
  have hp0 := prawitzMajorantValue_nonneg (T * (-x + y))
  simp only [mul_nonneg_iff_of_pos_left hT] at hm hp
  change (if 0 ≤ -x - y then (1 : ℝ) else 0) ≤ prawitzMajorantValue (T * (-x - y)) at hm
  change (if 0 ≤ -x + y then (1 : ℝ) else 0) ≤ prawitzMajorantValue (T * (-x + y)) at hp
  by_cases hy : |y| < x
  · rw [if_pos hy]; linarith
  · rw [if_neg hy]
    rcases le_or_lt 0 y with hy0 | hy0
    · have : x ≤ y := by rw [abs_of_nonneg hy0] at hy; linarith
      rw [if_pos (by linarith : (0 : ℝ) ≤ -x + y)] at hp
      linarith
    · have : x ≤ -y := by rw [abs_of_neg hy0] at hy; linarith
      rw [if_pos (by linarith : (0 : ℝ) ≤ -x - y)] at hm
      linarith

-- `hx` is part of the statement but is not needed by the proof.
set_option linter.unusedVariables false in
/-- Prawitz' lower bound for the open concentration event. -/
theorem rademacher_open_concentration_ge_prawitz {n : ℕ} (c : Fin n → ℝ)
    {x T : ℝ} (hx : 0 < x) (hT : 0 < T) :
    -(2 * ∫ u in (0 : ℝ)..1, symmetricPrawitzKernel (-x) T u * cosProduct Finset.univ c (T * u)) ≤
      rademacherOpenConcentration c x := by
  classical
  rw [rademacherOpenConcentration, cubeProbability_eq_expectation]
  calc
    _ = cubeExpectation (fun ω => -(2 * ∫ u in (0 : ℝ)..1,
        symmetricPrawitzKernel (-x) T u * Real.cos ((T * u) * rademacherSum c ω))) := by
      rw [show (fun ω : BoolCube n => -(2 * ∫ u in (0 : ℝ)..1,
          symmetricPrawitzKernel (-x) T u * Real.cos ((T * u) * rademacherSum c ω))) =
          (fun ω => (-2) * ∫ u in (0 : ℝ)..1,
          symmetricPrawitzKernel (-x) T u * Real.cos ((T * u) * rademacherSum c ω)) by
            funext ω; ring]
      rw [cubeExpectation_const_mul,
        cubeExpectation_intervalIntegral _ (fun ω =>
          symmetricPrawitzKernel_mul_cos_intervalIntegrable (-x) _ T)]
      have hfun : (fun u => cubeExpectation (fun ω : BoolCube n =>
          symmetricPrawitzKernel (-x) T u * Real.cos ((T * u) * rademacherSum c ω))) =
          (fun u => symmetricPrawitzKernel (-x) T u * cosProduct Finset.univ c (T * u)) := by
        funext u
        rw [cubeExpectation_const_mul]
        have heq : (fun ω : BoolCube n => Real.cos ((T * u) * rademacherSum c ω)) =
            (fun ω => Real.cos (rademacherSum c ω * (T * u))) := by
          funext ω
          rw [mul_comm (T * u)]
        rw [heq, rademacher_cos_expectation]
      rw [hfun]
      ring
    _ = cubeExpectation (fun ω =>
        -(prawitzMajorantValue (T * (-x - rademacherSum c ω)) +
          prawitzMajorantValue (T * (-x + rademacherSum c ω)) - 1)) := by
      congr 1
      funext ω
      rw [prawitzMajorantPair_eq_integral (-x) _ T]
    _ ≤ _ := cubeExpectation_mono (fun ω => open_interval_indicator_ge_prawitz hT _)

/-- The open concentration event is bounded below by the envelope integral at `-x`. -/
theorem rademacher_open_concentration_ge_JUpper {n : ℕ} (coeff : Fin n → ℝ)
    {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hc : ∀ i, 0 ≤ coeff i)
    (hca : ∀ i, coeff i ≤ a) (hvar : ∑ i, coeff i ^ 2 = 1) (hx : 0 < x) :
    -(2 * JUpper a (-x)) ≤ rademacherOpenConcentration coeff x := by
  have hp := rademacher_open_concentration_ge_prawitz coeff hx
    (show 0 < Real.pi / a by positivity)
  have heq : (fun u : ℝ => symmetricPrawitzKernel (-x) (Real.pi / a) u *
      cosProduct Finset.univ coeff (Real.pi / a * u)) =
      (fun u => upperKernel (-x / a) u * cosProduct Finset.univ coeff (Real.pi * u / a)) := by
    funext u
    rw [symmetricPrawitzKernel_eq_upperKernel ha.ne']
    congr 2
    ring
  rw [heq] at hp
  have hi : IntervalIntegrable
      (fun u => upperKernel (-x / a) u * cosProduct Finset.univ coeff (Real.pi * u / a))
      volume 0 1 := by
    apply (intervalIntegrable_upperKernel (-x / a)).mul_continuousOn
    exact ((continuous_cosProduct Finset.univ coeff).comp
      ((continuous_const.mul continuous_id).div_const a)).continuousOn
  have hb : (∫ u in (0 : ℝ)..1,
      upperKernel (-x / a) u * cosProduct Finset.univ coeff (Real.pi * u / a)) ≤
        JUpper a (-x) := by
    apply intervalIntegral.integral_mono_on (by norm_num) hi
      (intervalIntegrable_upperEnvelopeIntegrand ha ha1)
    intro u hu
    have ht : 0 ≤ Real.pi * u / a := div_nonneg (mul_nonneg Real.pi_pos.le hu.1) ha.le
    have he := actual_characteristic_envelopes Finset.univ coeff ha
      (fun i _ => hc i) (fun i _ => hca i) hvar ht
    exact mul_le_max_envelopes he.1 he.2
  linarith

theorem rademacherOpenConcentration_abs {n : ℕ} (coeff : Fin n → ℝ) (x : ℝ) :
    rademacherOpenConcentration coeff x =
      rademacherOpenConcentration (fun i => |coeff i|) x := by
  classical
  exact rademacher_probability_abs coeff (fun y => |y| < x)

/-- (L) at a location `x` from the envelope inequality `J(a, -x) ≤ c a - c x`. -/
theorem lowerHalf_at_of_JUpper {n : ℕ} (coeff : Fin n → ℝ)
    {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hca : ∀ i, |coeff i| ≤ a)
    (hvar : ∑ i, coeff i ^ 2 = 1) (hx : 0 < x) (hJ : JUpper a (-x) ≤ c a - c x) :
    H x - H a ≤ rademacherOpenConcentration coeff x := by
  rw [rademacherOpenConcentration_abs]
  have hv : ∑ i, |coeff i| ^ 2 = 1 := by simpa only [sq_abs] using hvar
  have h := rademacher_open_concentration_ge_JUpper (fun i => |coeff i|) ha ha1
    (fun i => abs_nonneg _) hca hv hx
  unfold H
  linarith

/-- (U) at a location `x` from the envelope inequality `J(a, x) ≤ c a + c x`. -/
theorem upperHalf_at_of_JUpper {n : ℕ} (coeff : Fin n → ℝ)
    {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) (hca : ∀ i, |coeff i| ≤ a)
    (hvar : ∑ i, coeff i ^ 2 = 1) (hx : 0 ≤ x) (hJ : JUpper a x ≤ c a + c x) :
    rademacherConcentration coeff x ≤ H a + H x := by
  rw [rademacherConcentration_abs]
  have hv : ∑ i, |coeff i| ^ 2 = 1 := by simpa only [sq_abs] using hvar
  have h := rademacher_concentration_le_JUpper (fun i => |coeff i|) ha ha1
    (fun i => abs_nonneg _) hca hv hx
  unfold H
  linarith

end

end KellerKlein
