import KellerKlein.Main

/-!
# Reduction of the two-sided conjecture to the two symmetric halves

For a normalized Rademacher sum `X`, both CDF conventions at every real `x` follow from

* (U) `P[|X| ≤ x] ≤ H a + H x` for `x ≥ 0`, and
* (L) `H x - H a ≤ P[|X| < x]` for `x > a`,

where `H = 2c`, `c t = Φ t - 1/2`.
-/

open MeasureTheory Set
open scoped BigOperators

namespace KellerKlein

noncomputable section

/-- `P[|X| < x]`. -/
def rademacherOpenConcentration {n : ℕ} (c : Fin n → ℝ) (x : ℝ) : ℝ :=
  cubeProbability (fun ω => |rademacherSum c ω| < x)

lemma phi_even (x : ℝ) : phi (-x) = phi x := by
  simp [phi, gaussian_neg]

lemma c_neg (x : ℝ) : c (-x) = -c x := by
  unfold c
  have h := intervalIntegral.integral_comp_neg (a := (0 : ℝ)) (b := x) phi
  simp only [neg_zero] at h
  have h2 : (∫ t in (0 : ℝ)..(-x), phi t) = ∫ t in (0 : ℝ)..(-x), phi (-t) := by
    congr 1; funext t; rw [phi_even]
  rw [h2, intervalIntegral.integral_comp_neg (fun t => phi t)]
  simp only [neg_zero, neg_neg]
  rw [intervalIntegral.integral_symm]

lemma c_sub_c_eq {x y : ℝ} : c y - c x = ∫ t in x..y, phi t := by
  unfold c
  rw [intervalIntegral.integral_interval_sub_left]
  · exact (continuous_phi.intervalIntegrable _ _)
  · exact (continuous_phi.intervalIntegrable _ _)

lemma c_mono {x y : ℝ} (hxy : x ≤ y) : c x ≤ c y := by
  have h := c_sub_c_eq (x := x) (y := y)
  have hn : 0 ≤ ∫ t in x..y, phi t :=
    intervalIntegral.integral_nonneg hxy (fun t _ => (phi_pos t).le)
  linarith

lemma c_zero : c 0 = 0 := by simp [c]

lemma c_nonneg {x : ℝ} (hx : 0 ≤ x) : 0 ≤ c x := by
  simpa [c_zero] using c_mono hx

lemma H_mono {x y : ℝ} (hxy : x ≤ y) : H x ≤ H y := by
  unfold H; linarith [c_mono hxy]

lemma H_zero : H 0 = 0 := by simp [H, c_zero]

lemma H_nonneg {x : ℝ} (hx : 0 ≤ x) : 0 ≤ H x := by
  unfold H; linarith [c_nonneg hx]

lemma c_le_half (x : ℝ) : c x ≤ 1 / 2 := by
  have h := standardNormal_cdf_eq x
  have h1 := ProbabilityTheory.cdf_le_one (ProbabilityTheory.gaussianReal 0 1) x
  linarith

lemma cubeProbability_congr {n : ℕ} {p q : BoolCube n → Prop} (h : ∀ ω, p ω ↔ q ω) :
    cubeProbability p = cubeProbability q := by
  have : p = q := funext fun ω => propext (h ω)
  rw [this]

lemma rademacher_prob_neg_symm {n : ℕ} (c : Fin n → ℝ) (p : ℝ → Prop) :
    cubeProbability (fun ω => p (rademacherSum c ω)) =
      cubeProbability (fun ω => p (-rademacherSum c ω)) := by
  classical
  rw [cubeProbability_eq_expectation, cubeProbability_eq_expectation]
  exact (rademacher_expectation_symmetric c (fun y => if p y then (1 : ℝ) else 0)).symm

/-- For `x ≥ 0`: `P[X ≤ x] = (1 + P[|X| ≤ x]) / 2`. -/
lemma rademacherCDF_eq_half_closed {n : ℕ} (c : Fin n → ℝ) {x : ℝ} (hx : 0 ≤ x) :
    rademacherCDF c x = (1 + rademacherConcentration c x) / 2 := by
  have h1 := rademacherCDF_symmetry c x
  have h2 := rademacherConcentration_eq_one_sub_two_strictCDF c hx
  linarith

lemma cubeProbability_or_disjoint {n : ℕ} (p q : BoolCube n → Prop)
    (hd : ∀ ω, ¬ (p ω ∧ q ω)) :
    cubeProbability (fun ω => p ω ∨ q ω) = cubeProbability p + cubeProbability q := by
  classical
  rw [cubeProbability_eq_expectation, cubeProbability_eq_expectation,
    cubeProbability_eq_expectation, ← cubeExpectation_add]
  congr 1
  funext ω
  by_cases hp : p ω
  · have hq : ¬ q ω := fun hq => hd ω ⟨hp, hq⟩
    simp [hp, hq]
  · by_cases hq : q ω <;> simp [hp, hq]

lemma cubeProbability_compl {n : ℕ} (p : BoolCube n → Prop) :
    cubeProbability (fun ω => ¬ p ω) = 1 - cubeProbability p := by
  classical
  rw [cubeProbability_eq_expectation, cubeProbability_eq_expectation]
  have : (fun ω => if ¬ p ω then (1 : ℝ) else 0) = (fun ω => 1 - (if p ω then (1 : ℝ) else 0)) := by
    funext ω; by_cases h : p ω <;> simp [h]
  rw [this, cubeExpectation_sub, cubeExpectation_const]

/-- For `x > 0`: `P[X < x] = (1 + P[|X| < x]) / 2`. -/
lemma rademacherStrictCDF_eq_half_open {n : ℕ} (c : Fin n → ℝ) {x : ℝ} (hx : 0 < x) :
    rademacherStrictCDF c x = (1 + rademacherOpenConcentration c x) / 2 := by
  -- `X < x` iff `|X| < x` or `X ≤ -x`, disjointly
  have hsplit : rademacherStrictCDF c x =
      rademacherOpenConcentration c x +
        cubeProbability (fun ω => rademacherSum c ω ≤ -x) := by
    unfold rademacherStrictCDF rademacherOpenConcentration
    rw [← cubeProbability_or_disjoint]
    · apply cubeProbability_congr
      intro ω
      constructor
      · intro h
        by_cases h' : rademacherSum c ω ≤ -x
        · exact Or.inr h'
        · exact Or.inl (abs_lt.mpr ⟨by linarith, h⟩)
      · rintro (h | h)
        · exact (abs_lt.mp h).2
        · linarith
    · intro ω ⟨h1, h2⟩
      have := (abs_lt.mp h1).1
      linarith
  -- `P[X ≤ -x] = P[X ≥ x] = 1 - P[X < x]`
  have hsym : cubeProbability (fun ω => rademacherSum c ω ≤ -x) =
      cubeProbability (fun ω => x ≤ rademacherSum c ω) := by
    rw [rademacher_prob_neg_symm c (fun y => y ≤ -x)]
    apply cubeProbability_congr
    intro ω; constructor <;> intro h <;> linarith
  have hcomp : cubeProbability (fun ω => x ≤ rademacherSum c ω) =
      1 - rademacherStrictCDF c x := by
    unfold rademacherStrictCDF
    rw [← cubeProbability_compl]
    apply cubeProbability_congr
    intro ω; constructor <;> intro h
    · exact not_lt.mpr h
    · exact not_lt.mp h
  rw [hsym, hcomp] at hsplit
  linarith

/-- `P[X < 0] = (1 - P[|X| ≤ 0]) / 2`. -/
lemma rademacherStrictCDF_zero {n : ℕ} (c : Fin n → ℝ) :
    rademacherStrictCDF c 0 = (1 - rademacherConcentration c 0) / 2 := by
  have h := rademacherConcentration_eq_one_sub_two_strictCDF c (le_refl (0 : ℝ))
  rw [neg_zero] at h
  linarith

lemma rademacherStrictCDF_le_CDF {n : ℕ} (c : Fin n → ℝ) (x : ℝ) :
    rademacherStrictCDF c x ≤ rademacherCDF c x := by
  classical
  unfold rademacherStrictCDF rademacherCDF
  rw [cubeProbability_eq_expectation, cubeProbability_eq_expectation]
  apply cubeExpectation_mono
  intro ω
  by_cases h : rademacherSum c ω < x
  · simp [h, h.le]
  · simp only [h, if_false]
    split_ifs <;> norm_num

/-- The upper half (U) for a coefficient vector and a level `a`. -/
def UpperHalf {n : ℕ} (c : Fin n → ℝ) (a : ℝ) : Prop :=
  ∀ x : ℝ, 0 ≤ x → rademacherConcentration c x ≤ H a + H x

/-- The lower half (L) for a coefficient vector and a level `a`. -/
def LowerHalf {n : ℕ} (c : Fin n → ℝ) (a : ℝ) : Prop :=
  ∀ x : ℝ, a < x → H x - H a ≤ rademacherOpenConcentration c x

/-- Both halves give the bounds at nonnegative locations. -/
lemma cdf_bounds_nonneg_of_halves {n : ℕ} (c : Fin n → ℝ) {a : ℝ}
    (hU : UpperHalf c a) (hL : LowerHalf c a) {x : ℝ} (hx : 0 ≤ x) :
    rademacherCDF c x ≤ 1 / 2 + KellerKlein.c x + KellerKlein.c a ∧
      1 / 2 + KellerKlein.c x - KellerKlein.c a ≤ rademacherStrictCDF c x := by
  constructor
  · rw [rademacherCDF_eq_half_closed c hx]
    have := hU x hx
    unfold H at this
    linarith
  · rcases eq_or_lt_of_le hx with rfl | hx0
    · rw [rademacherStrictCDF_zero]
      have := hU 0 le_rfl
      rw [H_zero] at this
      unfold H at this
      rw [c_zero]
      linarith
    · rw [rademacherStrictCDF_eq_half_open c hx0]
      by_cases hax : a < x
      · have := hL x hax
        unfold H at this
        linarith
      · have hp : 0 ≤ rademacherOpenConcentration c x := cubeProbability_nonneg _
        have hcx : KellerKlein.c x ≤ KellerKlein.c a := c_mono (le_of_not_gt hax)
        linarith

/-- The two-sided bounds for both CDF conventions at every real location, in terms of `c`. -/
theorem cdf_bounds_of_halves {n : ℕ} (c : Fin n → ℝ) {a : ℝ}
    (hU : UpperHalf c a) (hL : LowerHalf c a) (x : ℝ) :
    |rademacherCDF c x - (1 / 2 + KellerKlein.c x)| ≤ KellerKlein.c a ∧
      |rademacherStrictCDF c x - (1 / 2 + KellerKlein.c x)| ≤ KellerKlein.c a := by
  rcases le_total 0 x with hx | hx
  · obtain ⟨h1, h2⟩ := cdf_bounds_nonneg_of_halves c hU hL hx
    have h3 := rademacherStrictCDF_le_CDF c x
    constructor
    · rw [abs_le]; constructor <;> linarith
    · rw [abs_le]; constructor <;> linarith
  · have hx' : 0 ≤ -x := by linarith
    obtain ⟨h1, h2⟩ := cdf_bounds_nonneg_of_halves c hU hL hx'
    have h3 := rademacherStrictCDF_le_CDF c (-x)
    -- `P[X ≤ x] = 1 - P[X < -x]` and `P[X < x] = 1 - P[X ≤ -x]`
    have hs1 := rademacherCDF_symmetry c x
    have hs2 : rademacherStrictCDF c x = 1 - rademacherCDF c (-x) := by
      have := rademacherCDF_symmetry c (-x)
      rw [neg_neg] at this
      linarith
    have hcn := c_neg x
    constructor
    · rw [abs_le]; constructor <;> linarith
    · rw [abs_le]; constructor <;> linarith

end

end KellerKlein
