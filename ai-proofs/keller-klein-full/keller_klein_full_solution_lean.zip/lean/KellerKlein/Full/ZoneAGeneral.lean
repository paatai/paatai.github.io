import KellerKlein.Full.ZoneADiagonal

/-!
# Zone A for every `a < 0.675`

`holderProfile a b ξ ≤ c(a) + c(ξ a)` for `0 < b ≤ a < 0.675`, `0 ≤ ξ ≤ 1/2`:

* the kernel majorant gives `holderProfile ≤ M₀ + ξ P` with `M₀ = ∫(1-u)W`, `P = ∫ p W`;
* the ray and the diagonal give `M₀ ≤ c(a)` and `M₀ + P/2 ≤ c(a) + c(a/2)`;
* interpolating in `ξ` and using `2ξ c(a/2) ≤ c(ξ a)` (concavity) closes the bound.

The probability statement then follows exactly as for the original small-`a` theorem
(`rademacher_concentration_zoneA`): Prawitz's smoothing inequality and the Hölder reduction to a
single coefficient profile.
-/

namespace KellerKlein

noncomputable section

open MeasureTheory Set

theorem holderProfile_le_general {a b ξ : ℝ} (hb : 0 < b) (hba : b ≤ a)
    (ha1 : a < 675 / 1000) (hξ : 0 ≤ ξ) (hξ1 : ξ ≤ 1 / 2) :
    ZoneA.holderProfile a b ξ ≤ c a + c (ξ * a) := by
  have ha : 0 < a := hb.trans_le hba
  have hb2 : b ^ 2 ≤ 1 / 2 := by nlinarith
  have hW := continuous_profile_comp b a
  have hM0 : (∫ u in (0 : ℝ)..1, (1 - u) * cosineProfile b (Real.pi * u / a)) ≤ c a := by
    have h1 := ray_zero hb hba ha1
    have h2 := diag_zero_le hb hb2
    linarith
  have hMh : (∫ u in (0 : ℝ)..1, kHalf u * cosineProfile b (Real.pi * u / a)) ≤
      c a + c (a / 2) := by
    have h1 := ray_half hb hba ha1
    have h2 := diag_half_le hb hb2
    linarith
  have hlin : Continuous fun u => (1 - u) + ξ * kernelPoly u := by
    unfold kernelPoly; fun_prop
  have hK : ZoneA.holderProfile a b ξ ≤ ∫ u in (0 : ℝ)..1,
      ((1 - u) + ξ * kernelPoly u) * cosineProfile b (Real.pi * u / a) := by
    unfold ZoneA.holderProfile
    apply intervalIntegral.integral_mono_on_of_le_Ioo (by norm_num)
      (intervalIntegrable_upperKernel_cosineProfile a b ξ) ((hlin.mul hW).intervalIntegrable 0 1)
    intro u hu
    exact mul_le_mul_of_nonneg_right (upperKernel_le_affine hξ hξ1 hu.1 hu.2)
      (cosineProfile_nonneg _ _)
  have hsplit : (∫ u in (0 : ℝ)..1,
      ((1 - u) + ξ * kernelPoly u) * cosineProfile b (Real.pi * u / a)) =
      (1 - 2 * ξ) * (∫ u in (0 : ℝ)..1, (1 - u) * cosineProfile b (Real.pi * u / a)) +
        2 * ξ * ∫ u in (0 : ℝ)..1, kHalf u * cosineProfile b (Real.pi * u / a) := by
    rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_const_mul,
      ← intervalIntegral.integral_add]
    · congr 1; funext u; unfold kHalf; ring
    · exact (continuous_const.mul ((by fun_prop : Continuous fun u : ℝ => 1 - u).mul
        hW)).intervalIntegrable 0 1
    · exact (continuous_const.mul (continuous_kHalf.mul hW)).intervalIntegrable 0 1
  have hconc := mul_c_le_c_mul (l := 2 * ξ) (x := a / 2) (by linarith) (by linarith)
    (by linarith)
  have he : 2 * ξ * (a / 2) = ξ * a := by ring
  rw [he] at hconc
  have h1 := mul_le_mul_of_nonneg_left hM0 (by linarith : (0 : ℝ) ≤ 1 - 2 * ξ)
  have h2 := mul_le_mul_of_nonneg_left hMh (by linarith : (0 : ℝ) ≤ 2 * ξ)
  linarith

/-- (U) near the origin: `P[|X| ≤ x] ≤ H(a) + H(x)` for nonnegative coefficients `≤ a < 0.675`
and `0 ≤ x ≤ a/2`. -/
theorem rademacher_concentration_zoneA_general {n : ℕ} (coeff : Fin n → ℝ)
    {a x : ℝ} (ha : 0 < a) (ha1 : a < 675 / 1000) (hc : ∀ i, 0 ≤ coeff i)
    (hca : ∀ i, coeff i ≤ a) (hvar : ∑ i, coeff i ^ 2 = 1)
    (hx : 0 ≤ x) (hxa : x ≤ a / 2) :
    rademacherConcentration coeff x ≤ H a + H x := by
  have hξ : 0 ≤ x / a := div_nonneg hx ha.le
  have hξ1 : x / a ≤ (1 / 2 : ℝ) := (div_le_iff₀ ha).mpr (by linarith)
  have hfreq (u : ℝ) : Real.pi / a * u = Real.pi * u / a := by ring
  have hi : IntervalIntegrable
      (fun u => upperKernel (x / a) u * cosProduct Finset.univ coeff (Real.pi / a * u))
      volume 0 1 := by
    apply (intervalIntegrable_upperKernel (x / a)).mul_continuousOn
    exact ((continuous_cosProduct Finset.univ coeff).comp
      (continuous_const.mul continuous_id)).continuousOn
  have hprofiles : ∀ i ∈ (Finset.univ : Finset (Fin n)), IntervalIntegrable
      (fun u => upperKernel (x / a) u * cosineProfile (coeff i) (Real.pi / a * u))
      volume 0 1 := by
    intro i _
    simpa only [hfreq] using intervalIntegrable_upperKernel_cosineProfile a (coeff i) (x / a)
  have hbounds : ∀ i ∈ (Finset.univ : Finset (Fin n)), coeff i ≠ 0 →
      (∫ u in (0 : ℝ)..1, upperKernel (x / a) u * cosineProfile (coeff i) (Real.pi / a * u)) ≤
        c a + c x := by
    intro i _ hnz
    have hci : 0 < coeff i := lt_of_le_of_ne (hc i) (Ne.symm hnz)
    have h := holderProfile_le_general hci (hca i) ha1 hξ hξ1
    simpa only [ZoneA.holderProfile, hfreq, div_mul_cancel₀ x ha.ne'] using h
  have hb := integral_cosProduct_le_uniform_profile Finset.univ coeff hvar
    (upperKernel (x / a)) (Real.pi / a) (c a + c x)
    (upperKernel_nonneg_closed hξ hξ1) hi hprofiles hbounds
  have hp := rademacher_concentration_le_prawitz coeff hx
    (show 0 < Real.pi / a by positivity)
  have heq : symmetricPrawitzKernel x (Real.pi / a) = upperKernel (x / a) := by
    funext u
    exact symmetricPrawitzKernel_eq_upperKernel ha.ne' x u
  rw [heq] at hp
  unfold H
  linarith

/-- The `zoneA` input of `Pieces`: signed coefficients. -/
theorem zoneA_piece {n : ℕ} (coeff : Fin n → ℝ) {a x : ℝ} (ha : 0 < a)
    (ha1 : a < 675 / 1000) (hca : ∀ i, |coeff i| ≤ a) (hvar : ∑ i, coeff i ^ 2 = 1)
    (hx : 0 ≤ x) (hxa : x ≤ a / 2) :
    rademacherConcentration coeff x ≤ H a + H x := by
  rw [rademacherConcentration_abs]
  apply rademacher_concentration_zoneA_general (fun i => |coeff i|) ha ha1
    (fun i => abs_nonneg _) hca
  · simpa only [sq_abs] using hvar
  · exact hx
  · exact hxa

end

end KellerKlein
