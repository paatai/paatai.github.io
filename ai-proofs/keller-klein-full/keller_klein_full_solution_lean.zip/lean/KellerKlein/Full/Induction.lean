import KellerKlein.Full.Hoeffding

/-!
# The induction on the number of terms

The two halves (U) and (L) are proved for all normalized coefficient vectors by induction on
the number of terms.  The proof is a case analysis on the largest coefficient `a` and the
location `x`.  The analytic and numerical inputs are collected in `Pieces`; each field is a
statement about explicit functions of `(a, x)` (or, for zone A, about a single sum without
induction), proved in separate files.
-/

open MeasureTheory Set Finset
open scoped BigOperators

namespace KellerKlein

noncomputable section

/-- `σ = √(1 - a²)`. -/
def peelSigma (a : ℝ) : ℝ := Real.sqrt (1 - a ^ 2)

/-- The level of the rescaled remainder `Y/σ`: `min (a/σ) 1`. -/
def peelLevel (a : ℝ) : ℝ := min (a / peelSigma a) 1

/-- Lower bound for `P[|Y| < t]` from (L) and Hoeffding for `Y/σ`. -/
def loY (a t : ℝ) : ℝ :=
  max 0 (max (H (t / peelSigma a) - H (peelLevel a))
    (1 - 2 * Real.exp (-((t / peelSigma a) ^ 2) / 2)))

/-- Upper bound for `P[|Y| ≤ t]` from (U) for `Y/σ`. -/
def upY (a t : ℝ) : ℝ := min 1 (H (peelLevel a) + H (t / peelSigma a))

/-- The peeling inequality for (L) at `(a, x)`, `x > a`. -/
def PeelL (a x : ℝ) : Prop := H x - H a ≤ (loY a (x + a) + loY a (x - a)) / 2

/-- The peeling inequality for (U) at `(a, x)`. -/
def PeelU (a x : ℝ) : Prop :=
  (if a ≤ x then (upY a (x + a) + upY a (x - a)) / 2
    else (upY a (a + x) - loY a (a - x)) / 2) ≤ H a + H x

/-- The analytic and numerical inputs of the proof. -/
structure Pieces : Prop where
  /-- `H(0.675) ≥ 1/2`. -/
  c675 : 1 / 4 ≤ c (675 / 1000)
  /-- (U) near the origin, for every `a < 0.675`. -/
  zoneA : ∀ {n : ℕ} (coeff : Fin n → ℝ) {a x : ℝ}, 0 < a → a < 675 / 1000 →
    (∀ i, |coeff i| ≤ a) → ∑ i, coeff i ^ 2 = 1 → 0 ≤ x → x ≤ a / 2 →
    rademacherConcentration coeff x ≤ H a + H x
  /-- The envelope inequality for (U), `0.07 ≤ a ≤ 1/2`. -/
  upperFourier : ∀ {a x : ℝ}, 7 / 100 ≤ a → a ≤ 1 / 2 → a / 2 ≤ x → H x + H a < 1 →
    JUpper a x ≤ c a + c x
  /-- The envelope inequality for (L), `a ≤ 0.55`, `x ≥ 3a/2`. -/
  lowerFourier : ∀ {a x : ℝ}, 0 < a → a ≤ 55 / 100 → 3 * a / 2 ≤ x →
    c a < Real.exp (-(x ^ 2) / 2) → JUpper a (-x) ≤ c a - c x
  /-- Peeling for (L), large coefficients. -/
  peelLLarge : ∀ {a x : ℝ}, 55 / 100 ≤ a → a < 1 → a < x →
    c a < Real.exp (-(x ^ 2) / 2) → PeelL a x
  /-- Peeling for (L), near range. -/
  peelLNear : ∀ {a x : ℝ}, 0 < a → a ≤ 55 / 100 → a < x → x ≤ 3 * a / 2 → PeelL a x
  /-- Peeling for (U), zone B, `1/2 ≤ a < 0.675`. -/
  peelU : ∀ {a x : ℝ}, 1 / 2 ≤ a → a < 675 / 1000 → a / 2 ≤ x → H x + H a < 1 → PeelU a x

lemma H_le_one (x : ℝ) : H x ≤ 1 := by unfold H; linarith [c_le_half x]

lemma upperHalf_mono {n : ℕ} {c : Fin n → ℝ} {a a' : ℝ} (h : UpperHalf c a) (haa : a ≤ a') :
    UpperHalf c a' := by
  intro x hx
  have := h x hx
  have := H_mono haa
  linarith

lemma lowerHalf_mono {n : ℕ} {c : Fin n → ℝ} {a a' : ℝ} (h : LowerHalf c a) (haa : a ≤ a') :
    LowerHalf c a' := by
  intro x hx
  have := h x (lt_of_le_of_lt haa hx)
  have := H_mono haa
  linarith

lemma sum_sq_removeCoeff {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1)) :
    ∑ j, removeCoeff c i j ^ 2 = (∑ j, c j ^ 2) - c i ^ 2 := by
  rw [Fin.sum_univ_succAbove _ i]
  unfold removeCoeff
  ring

lemma peelSigma_pos {a : ℝ} (ha : |a| < 1) : 0 < peelSigma a := by
  unfold peelSigma
  apply Real.sqrt_pos.mpr
  have : a ^ 2 < 1 := by
    have h0 := abs_nonneg a
    nlinarith [sq_abs a]
  linarith

lemma peelSigma_sq {a : ℝ} (ha : |a| ≤ 1) : peelSigma a ^ 2 = 1 - a ^ 2 := by
  unfold peelSigma
  rw [Real.sq_sqrt]
  have h0 := abs_nonneg a
  nlinarith [sq_abs a]

/-- The bounds for the remainder `Y` supplied by the induction hypothesis and Hoeffding. -/
lemma peel_remainder_bounds {n : ℕ} (c : Fin (n + 1) → ℝ) (hvar : ∑ j, c j ^ 2 = 1)
    (i : Fin (n + 1)) (hmax : ∀ j, |c j| ≤ |c i|) (hlt : |c i| < 1)
    (IH : ∀ e : Fin n → ℝ, ∑ j, e j ^ 2 = 1 → ∀ a', (∀ j, |e j| ≤ a') →
      UpperHalf e a' ∧ LowerHalf e a') :
    (∀ t, 0 ≤ t → loY |c i| t ≤ rademacherOpenConcentration (removeCoeff c i) t) ∧
      (∀ t, 0 ≤ t → rademacherConcentration (removeCoeff c i) t ≤ upY |c i| t) := by
  set a := |c i| with ha_def
  have hσ : 0 < peelSigma a := peelSigma_pos (by rw [abs_abs]; exact hlt)
  set σ := peelSigma a
  set d := removeCoeff c i
  set e : Fin n → ℝ := fun j => d j / σ
  have hσsq : σ ^ 2 = 1 - a ^ 2 := peelSigma_sq (by rw [abs_abs]; exact hlt.le)
  have hd : ∑ j, d j ^ 2 = 1 - a ^ 2 := by
    rw [sum_sq_removeCoeff, hvar, ha_def, sq_abs]
  have he : ∑ j, e j ^ 2 = 1 := by
    have : ∑ j, e j ^ 2 = (∑ j, d j ^ 2) / σ ^ 2 := by
      rw [Finset.sum_div]; apply Finset.sum_congr rfl; intro j _; simp only [e, div_pow]
    rw [this, hd, hσsq, div_self]
    have : 0 < σ ^ 2 := by positivity
    linarith
  have hlev : ∀ j, |e j| ≤ peelLevel a := by
    intro j
    unfold peelLevel
    apply le_min
    · simp only [e, abs_div, abs_of_pos hσ]
      apply div_le_div_of_nonneg_right _ hσ.le
      exact hmax (i.succAbove j)
    · have hj : e j ^ 2 ≤ 1 := by
        rw [← he]
        exact Finset.single_le_sum (f := fun j => e j ^ 2) (fun j _ => sq_nonneg _)
          (Finset.mem_univ j)
      have h0 := abs_nonneg (e j)
      nlinarith [sq_abs (e j)]
  obtain ⟨hU, hL⟩ := IH e he (peelLevel a) hlev
  constructor
  · intro t ht
    rw [rademacherOpenConcentration_scale d hσ t]
    have hts : 0 ≤ t / σ := div_nonneg ht hσ.le
    unfold loY
    apply max_le (cubeProbability_nonneg _)
    apply max_le
    · by_cases hb : peelLevel a < t / σ
      · exact hL (t / σ) hb
      · have := H_mono (le_of_not_gt hb)
        have := cubeProbability_nonneg (fun ω => |rademacherSum e ω| < t / σ)
        linarith
    · exact hoeffding_open e he hts
  · intro t ht
    rw [rademacherConcentration_scale d hσ t]
    have hts : 0 ≤ t / σ := div_nonneg ht hσ.le
    unfold upY
    apply le_min (cubeProbability_le_one _)
    exact hU (t / σ) hts

lemma exists_max_coeff {n : ℕ} (c : Fin (n + 1) → ℝ) : ∃ i, ∀ j, |c j| ≤ |c i| := by
  obtain ⟨i, _, hi⟩ := Finset.exists_max_image Finset.univ (fun j => |c j|)
    Finset.univ_nonempty
  exact ⟨i, fun j => hi j (Finset.mem_univ j)⟩

lemma max_coeff_pos {n : ℕ} (c : Fin (n + 1) → ℝ) (hvar : ∑ j, c j ^ 2 = 1)
    (i : Fin (n + 1)) (hmax : ∀ j, |c j| ≤ |c i|) : 0 < |c i| := by
  by_contra h
  have h0 : ∀ j, c j = 0 := by
    intro j
    have := hmax j
    have := abs_nonneg (c j)
    exact abs_eq_zero.mp (by linarith)
  simp [h0] at hvar

lemma max_coeff_le_one {n : ℕ} (c : Fin (n + 1) → ℝ) (hvar : ∑ j, c j ^ 2 = 1)
    (i : Fin (n + 1)) : |c i| ≤ 1 := by
  have hj : c i ^ 2 ≤ 1 := by
    rw [← hvar]
    exact Finset.single_le_sum (f := fun j => c j ^ 2) (fun j _ => sq_nonneg _)
      (Finset.mem_univ i)
  have h0 := abs_nonneg (c i)
  nlinarith [sq_abs (c i)]

/-- If the largest coefficient is `1`, the remainder vanishes. -/
lemma removeCoeff_eq_zero_of_one {n : ℕ} (c : Fin (n + 1) → ℝ) (hvar : ∑ j, c j ^ 2 = 1)
    (i : Fin (n + 1)) (h1 : |c i| = 1) (j : Fin n) : removeCoeff c i j = 0 := by
  have hd := sum_sq_removeCoeff c i
  rw [hvar, ← sq_abs, h1] at hd
  norm_num at hd
  have hj : removeCoeff c i j ^ 2 ≤ 0 := by
    rw [← hd]
    exact Finset.single_le_sum (f := fun j => removeCoeff c i j ^ 2) (fun j _ => sq_nonneg _)
      (Finset.mem_univ j)
  exact pow_eq_zero_iff (n := 2) (by norm_num) |>.mp (le_antisymm hj (sq_nonneg _))

lemma rademacherSum_zero_coeff {n : ℕ} (d : Fin n → ℝ) (hd : ∀ j, d j = 0) (ω : BoolCube n) :
    rademacherSum d ω = 0 := by
  simp [rademacherSum, hd]

theorem halves_of_pieces (P : Pieces) :
    ∀ (n : ℕ) (c : Fin n → ℝ), ∑ i, c i ^ 2 = 1 → ∀ a, (∀ i, |c i| ≤ a) →
      UpperHalf c a ∧ LowerHalf c a := by
  intro n
  induction n with
  | zero =>
    intro c hvar
    simp at hvar
  | succ n IH =>
    intro c hvar a hca
    obtain ⟨i, hmax⟩ := exists_max_coeff c
    set A := |c i| with hA
    have hA0 : 0 < A := max_coeff_pos c hvar i hmax
    have hA1 : A ≤ 1 := max_coeff_le_one c hvar i
    have hAa : A ≤ a := (hca i).trans' le_rfl
    suffices h : UpperHalf c A ∧ LowerHalf c A from
      ⟨upperHalf_mono h.1 hAa, lowerHalf_mono h.2 hAa⟩
    have hH675 : 1 / 2 ≤ H (675 / 1000) := by unfold H; linarith [P.c675]
    rcases eq_or_lt_of_le hA1 with hA1' | hAlt
    · -- the largest coefficient is `1`: `X = ±ε`
      have hd := removeCoeff_eq_zero_of_one c hvar i hA1'
      have hY0 : ∀ ω, rademacherSum (removeCoeff c i) ω = 0 :=
        rademacherSum_zero_coeff _ hd
      have hH1 : 1 / 2 ≤ H A := by
        rw [hA1']; exact hH675.trans (H_mono (by norm_num))
      constructor
      · intro x hx
        rcases lt_or_le x A with hxA | hxA
        · have := peel_closed_lt_le_half c i hx hxA
          have := H_nonneg hx
          linarith
        · have h1 : H A ≤ H x := H_mono hxA
          have := cubeProbability_le_one (fun ω => |rademacherSum c ω| ≤ x)
          unfold rademacherConcentration
          linarith
      · intro x hx
        rw [peel_open_gt c i hx]
        have hp : ∀ t, 0 < t → rademacherOpenConcentration (removeCoeff c i) t = 1 := by
          intro t ht
          unfold rademacherOpenConcentration cubeProbability
          simp only [hY0, abs_zero, ht, Finset.filter_True, Finset.card_univ,
            Fintype.card_fun, Fintype.card_fin, Fintype.card_bool, Nat.cast_pow,
            Nat.cast_ofNat]
          exact div_self (by positivity)
        rw [hp _ (by linarith), hp _ (by linarith)]
        have := H_le_one x
        have := H_nonneg hA0.le
        linarith
    · -- `A < 1`: the remainder is a normalized sum after rescaling
      have hIH : ∀ e : Fin n → ℝ, ∑ j, e j ^ 2 = 1 → ∀ a', (∀ j, |e j| ≤ a') →
          UpperHalf e a' ∧ LowerHalf e a' := fun e he a' hea => IH e he a' hea
      obtain ⟨hloY, hupY⟩ := peel_remainder_bounds c hvar i hmax hAlt hIH
      have hcA : ∀ j, |c j| ≤ A := hmax
      constructor
      · -- the upper half
        intro x hx
        by_cases hbig : 675 / 1000 ≤ A
        · rcases lt_or_le x A with hxA | hxA
          · have := peel_closed_lt_le_half c i hx hxA
            have := H_nonneg hx
            have := hH675.trans (H_mono hbig)
            linarith
          · have h1 : H A ≤ H x := H_mono hxA
            have := hH675.trans (H_mono hbig)
            have := cubeProbability_le_one (fun ω => |rademacherSum c ω| ≤ x)
            unfold rademacherConcentration
            linarith
        · have hsmall : A < 675 / 1000 := lt_of_not_le hbig
          by_cases hzA : x ≤ A / 2
          · exact P.zoneA c hA0 hsmall hcA hvar hx hzA
          · have hzB : A / 2 ≤ x := le_of_lt (lt_of_not_le hzA)
            by_cases htail : 1 ≤ H x + H A
            · have := cubeProbability_le_one (fun ω => |rademacherSum c ω| ≤ x)
              unfold rademacherConcentration
              linarith
            · have htail' : H x + H A < 1 := lt_of_not_le htail
              by_cases h07 : A ≤ 7 / 100
              · exact small_coefficient_upper_concentration c hA0 h07 hcA hvar hx
              · by_cases h05 : A ≤ 1 / 2
                · exact upperHalf_at_of_JUpper c hA0 hA1 hcA hvar hx
                    (P.upperFourier (le_of_lt (lt_of_not_le h07)) h05 hzB htail')
                · have hpeel := P.peelU (le_of_lt (lt_of_not_le h05)) hsmall hzB htail'
                  unfold PeelU at hpeel
                  split_ifs at hpeel with hAx
                  · rw [peel_closed_ge c i hAx]
                    have h1 := hupY (x + A) (by linarith)
                    have h2 := hupY (x - A) (by linarith)
                    linarith
                  · have hxA : x < A := lt_of_not_le hAx
                    rw [peel_closed_lt c i hx hxA]
                    have h1 := hupY (A + x) (by linarith)
                    have h2 := hloY (A - x) (by linarith)
                    linarith
      · -- the lower half
        intro x hx
        have hx0 : 0 < x := lt_trans hA0 hx
        by_cases hhoe : Real.exp (-(x ^ 2) / 2) ≤ KellerKlein.c A
        · exact lowerHalf_at_of_hoeffding c hvar hx0.le hhoe
        · have hhoe' : KellerKlein.c A < Real.exp (-(x ^ 2) / 2) := lt_of_not_le hhoe
          have hpeelL : PeelL A x → H x - H A ≤ rademacherOpenConcentration c x := by
            intro hpeel
            unfold PeelL at hpeel
            rw [peel_open_gt c i hx]
            have h1 := hloY (x + A) (by linarith)
            have h2 := hloY (x - A) (by linarith)
            linarith
          by_cases h55 : 55 / 100 ≤ A
          · exact hpeelL (P.peelLLarge h55 hAlt hx hhoe')
          · have h55' : A ≤ 55 / 100 := le_of_lt (lt_of_not_le h55)
            by_cases hnear : x ≤ 3 * A / 2
            · exact hpeelL (P.peelLNear hA0 h55' hx hnear)
            · exact lowerHalf_at_of_JUpper c hA0 hA1 hcA hvar hx0
                (P.lowerFourier hA0 h55' (le_of_lt (lt_of_not_le hnear)) hhoe')

end

end KellerKlein
