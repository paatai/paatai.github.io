import KellerKlein.Full.Induction

/-!
# Peeling for (L) near the diagonal, small coefficients

For `0 < a ≤ 3/10` and `a < x ≤ 3a/2` the peeling inequality `PeelL a x` follows from the
first branch of `loY a (x + a)` alone.  With `σ = √(1 - a²)` and `v = (x + a)/σ`:

* `H x - H a ≤ 2(x - a) φ(a) ≤ 2(x - a) φ₀`;
* `loY a (x + a) / 2 ≥ c(v) - c(a/σ) ≥ (x/σ) φ(v) ≥ x φ₀ (1 - v²/2)`;

and `4(x - a)(1 - a²) ≤ x (2(1 - a²) - (x + a)²)` closes the gap.
-/

namespace KellerKlein

noncomputable section

open MeasureTheory Set

lemma phi_anti_of_nonneg {s t : ℝ} (hs : 0 ≤ s) (hst : s ≤ t) : phi t ≤ phi s := by
  unfold phi
  apply mul_le_mul_of_nonneg_right _ phi0_pos.le
  unfold gaussian
  apply Real.exp_le_exp.mpr
  nlinarith

lemma c_sub_le_mul_phi {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    c b - c a ≤ (b - a) * phi a := by
  rw [c_sub_c_eq]
  have h : (∫ t in a..b, phi t) ≤ ∫ _ in a..b, phi a := by
    apply intervalIntegral.integral_mono_on hab
    · exact continuous_phi.intervalIntegrable _ _
    · exact intervalIntegrable_const
    · intro t ht
      exact phi_anti_of_nonneg ha ht.1
  simpa [intervalIntegral.integral_const, smul_eq_mul] using h

lemma mul_phi_le_c_sub {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) :
    (b - a) * phi b ≤ c b - c a := by
  rw [c_sub_c_eq]
  have h : (∫ _ in a..b, phi b) ≤ ∫ t in a..b, phi t := by
    apply intervalIntegral.integral_mono_on hab
    · exact intervalIntegrable_const
    · exact continuous_phi.intervalIntegrable _ _
    · intro t ht
      exact phi_anti_of_nonneg (ha.trans ht.1) ht.2
  simpa [intervalIntegral.integral_const, smul_eq_mul] using h

lemma peelLNear_poly {a x : ℝ} (ha : 0 < a) (ha3 : a ≤ 3 / 10) (hx : a < x)
    (hx3 : x ≤ 3 * a / 2) :
    4 * (x - a) * (1 - a ^ 2) ≤ x * (2 * (1 - a ^ 2) - (x + a) ^ 2) := by
  have e : x * (2 * (1 - a ^ 2) - (x + a) ^ 2) - 4 * (x - a) * (1 - a ^ 2) =
      a * (1 - 83 / 8 * a ^ 2) + 2 * (a / 2 - (x - a)) + 6 * a ^ 2 * (a / 2 - (x - a)) +
        5 * a * (a / 2 - (x - a)) * (a / 2 + (x - a)) +
        (a / 2 - (x - a)) * ((a / 2) ^ 2 + a / 2 * (x - a) + (x - a) ^ 2) := by
    ring
  have h1 : 0 ≤ a / 2 - (x - a) := by linarith
  have h2 : 0 ≤ 1 - 83 / 8 * a ^ 2 := by nlinarith
  have t1 : 0 ≤ a * (1 - 83 / 8 * a ^ 2) := mul_nonneg ha.le h2
  have t2 : 0 ≤ 6 * a ^ 2 * (a / 2 - (x - a)) := by positivity
  have t3 : 0 ≤ 5 * a * (a / 2 - (x - a)) * (a / 2 + (x - a)) := by
    have : 0 ≤ a / 2 + (x - a) := by linarith
    positivity
  have t4 : 0 ≤ (a / 2 - (x - a)) * ((a / 2) ^ 2 + a / 2 * (x - a) + (x - a) ^ 2) := by
    have : 0 ≤ (a / 2) ^ 2 + a / 2 * (x - a) + (x - a) ^ 2 := by
      have : 0 ≤ x - a := by linarith
      positivity
    exact mul_nonneg h1 this
  linarith

theorem peelLNear_small {a x : ℝ} (ha : 0 < a) (ha3 : a ≤ 3 / 10) (hx : a < x)
    (hx3 : x ≤ 3 * a / 2) : PeelL a x := by
  have habs : |a| < 1 := by rw [abs_of_pos ha]; linarith
  have hσpos : 0 < peelSigma a := peelSigma_pos habs
  have hσsq : peelSigma a ^ 2 = 1 - a ^ 2 := peelSigma_sq habs.le
  have hσle : peelSigma a ≤ 1 := by nlinarith
  have h1a : 0 < 1 - a ^ 2 := by nlinarith
  have hpoly := peelLNear_poly ha ha3 hx hx3
  have hu0 : 0 ≤ a / peelSigma a := div_nonneg ha.le hσpos.le
  have huv : a / peelSigma a ≤ (x + a) / peelSigma a :=
    div_le_div_of_nonneg_right (by linarith) hσpos.le
  have hvu : (x + a) / peelSigma a - a / peelSigma a = x / peelSigma a := by
    rw [← sub_div]
    ring_nf
  have h1 := c_sub_le_mul_phi ha.le hx.le
  have h2 := mul_phi_le_c_sub hu0 huv
  rw [hvu] at h2
  have h3 : phi a ≤ phi0 := by
    unfold phi
    have := gaussian_le_one a
    nlinarith [phi0_pos]
  have h4 := phi_lower_quadratic ((x + a) / peelSigma a)
  have hv2 : ((x + a) / peelSigma a) ^ 2 = (x + a) ^ 2 / (1 - a ^ 2) := by
    rw [div_pow, hσsq]
  have hq : 2 * (x - a) ≤ x * (1 - ((x + a) / peelSigma a) ^ 2 / 2) := by
    rw [hv2]
    have e : x * (1 - (x + a) ^ 2 / (1 - a ^ 2) / 2) =
        x * (2 * (1 - a ^ 2) - (x + a) ^ 2) / (2 * (1 - a ^ 2)) := by
      field_simp
      ring
    rw [e, le_div_iff₀ (by positivity)]
    nlinarith [hpoly]
  have hx0 : 0 < x := by linarith
  have h1v : 0 ≤ 1 - ((x + a) / peelSigma a) ^ 2 / 2 := by
    by_contra hneg
    push_neg at hneg
    have : x * (1 - ((x + a) / peelSigma a) ^ 2 / 2) < 0 := mul_neg_of_pos_of_neg hx0 hneg
    linarith
  have hxσ : x ≤ x / peelSigma a := by
    rw [le_div_iff₀ hσpos]
    nlinarith
  have hq2 : x * (1 - ((x + a) / peelSigma a) ^ 2 / 2) ≤
      x / peelSigma a * (1 - ((x + a) / peelSigma a) ^ 2 / 2) :=
    mul_le_mul_of_nonneg_right hxσ h1v
  have e1 : c x - c a ≤ (x - a) * phi0 :=
    h1.trans (mul_le_mul_of_nonneg_left h3 (by linarith))
  have e2 : 2 * (x - a) * phi0 ≤ x / peelSigma a * (phi0 * (1 - ((x + a) / peelSigma a) ^ 2 / 2)) := by
    have := mul_le_mul_of_nonneg_right (hq.trans hq2) phi0_pos.le
    linarith
  have e3 : x / peelSigma a * (phi0 * (1 - ((x + a) / peelSigma a) ^ 2 / 2)) ≤
      x / peelSigma a * phi ((x + a) / peelSigma a) :=
    mul_le_mul_of_nonneg_left h4 (div_nonneg hx0.le hσpos.le)
  have hL1 : H ((x + a) / peelSigma a) - H (a / peelSigma a) ≤ loY a (x + a) := by
    unfold loY
    refine le_trans ?_ (le_max_right _ _)
    refine le_trans ?_ (le_max_left _ _)
    have : H (peelLevel a) ≤ H (a / peelSigma a) := H_mono (min_le_left _ _)
    linarith
  have hL2 : 0 ≤ loY a (x - a) := le_max_left _ _
  unfold PeelL
  unfold H at hL1 ⊢
  linarith

end

end KellerKlein
