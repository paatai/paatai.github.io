import KellerKlein.Full.Induction

/-!
# The conjecture from the inputs `Pieces`

For every finite normalized coefficient vector, every level `a ≥ max |aⱼ|`, every real `x`,
and both CDF conventions,
`|P[X ≤ x] - Φ(x)| ≤ Φ(a) - 1/2` and `|P[X < x] - Φ(x)| ≤ Φ(a) - 1/2`.
-/

open MeasureTheory Set ProbabilityTheory
open scoped BigOperators

namespace KellerKlein

noncomputable section

theorem keller_klein_of_pieces (P : Pieces) {n : ℕ} (coeff : Fin n → ℝ)
    (hvar : ∑ i, coeff i ^ 2 = 1) {a : ℝ} (hca : ∀ i, |coeff i| ≤ a) (x : ℝ) :
    |rademacherCDF coeff x - cdf (gaussianReal 0 1) x| ≤ cdf (gaussianReal 0 1) a - 1 / 2 ∧
      |rademacherStrictCDF coeff x - cdf (gaussianReal 0 1) x| ≤
        cdf (gaussianReal 0 1) a - 1 / 2 := by
  obtain ⟨hU, hL⟩ := halves_of_pieces P n coeff hvar a hca
  have h := cdf_bounds_of_halves coeff hU hL x
  rw [standardNormal_cdf_eq, standardNormal_cdf_eq]
  simpa using h

end

end KellerKlein
