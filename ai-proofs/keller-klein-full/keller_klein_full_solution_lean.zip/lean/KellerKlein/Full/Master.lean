import KellerKlein.ZoneBDecomposition
import KellerKlein.Num.Special

/-!
# The master decomposition

For `0 < a ≤ 1` and every real `y`,

`J(a, y) - c(a) - c(y) ≤ ∫₀¹ gU a y - masterTarget a y + tailBound a + aliasTailBound a`,

where the integrand `gU` is the envelope loss plus the cotangent remainder, minus the
Gaussian moment term `a² M(y) / π²` transported to the alias region `θ/π < u < 1`
(`θ = crossoverRoot`).  On each envelope region `gU` has an explicit form without
cancellation (`gU_R1`, `gU_R2`, `gU_R3`); these are the formulas evaluated by the
certified cell check.
-/

open Set MeasureTheory

namespace KellerKlein

noncomputable section

/-- The Gaussian part of `c(a) + c(y) - J(a, y)`, up to the transported `M`-term. -/
def masterTarget (a y : ℝ) : ℝ :=
  c a - a * phi y + a ^ 2 * y * phi y / 3 - a ^ 3 * gaussianN y / (3 * Real.pi ^ 2)

/-- The cotangent remainder in the unit coordinate `u = a s / π`. -/
def cotU (a y u : ℝ) : ℝ := cotangentRemainderIntegrand a y (Real.pi * u / a)

/-- The `M`-moment integrand in the unit coordinate `u = 1 - a s / π`. -/
def mU (a y u : ℝ) : ℝ :=
  (1 - u) * Real.cos (Real.pi * (y / a) * (1 - u)) * gaussian (Real.pi * (1 - u) / a)

/-- The master integrand. -/
def gU (a y u : ℝ) : ℝ :=
  envelopeDifference a y u + cotU a y u -
    (Ioi (crossoverRoot / Real.pi)).indicator (mU a y) u

def tailBound (a : ℝ) : ℝ :=
  a ^ 2 * (2 / Real.pi ^ 2 + 1 / Real.pi ^ 3 + 2 / (3 * Real.pi) + a ^ 2 / (3 * Real.pi ^ 3)) *
    gaussian (Real.pi / a)

def aliasTailBound (a : ℝ) : ℝ :=
  (a / Real.pi) ^ 2 * gaussian ((Real.pi - crossoverRoot) / a)

lemma crossoverRoot_div_pi_pos : 0 < crossoverRoot / Real.pi :=
  div_pos (by linarith [crossoverRoot_spec.1, Real.pi_pos]) Real.pi_pos

lemma crossoverRoot_div_pi_lt_one : crossoverRoot / Real.pi < 1 :=
  (div_lt_one Real.pi_pos).2 crossoverRoot_spec.2.1

lemma continuous_mU (a y : ℝ) : Continuous (mU a y) := by
  unfold mU gaussian
  fun_prop

lemma intervalIntegrable_cotU {a y : ℝ} (ha : 0 < a) :
    IntervalIntegrable (cotU a y) volume 0 1 := by
  have hpa : 0 < Real.pi / a := div_pos Real.pi_pos ha
  have h := (intervalIntegrable_iff_integrableOn_Ioo_of_le hpa.le).2
    (integrableOn_cotangentRemainderIntegrand (x := y) ha)
  have h2 := h.comp_mul_left (Real.pi / a)
  rw [zero_div, div_self hpa.ne'] at h2
  have hfun : (fun x => cotangentRemainderIntegrand a y (Real.pi / a * x)) = cotU a y := by
    funext x
    unfold cotU
    congr 1
    ring
  rw [hfun] at h2
  exact h2

lemma integral_cotU {a y : ℝ} (ha : 0 < a) :
    (∫ u in (0 : ℝ)..1, cotU a y u) = cotangentRemainderIntegral a y := by
  have ha0 : a ≠ 0 := ha.ne'
  rw [integral_rescale_unit _ ha0]
  simp only [mul_zero, zero_div, mul_one]
  have hf : (fun s => cotU a y (a * s / Real.pi)) = cotangentRemainderIntegrand a y := by
    funext s
    unfold cotU
    congr 1
    field_simp
  rw [hf, intervalIntegral.integral_of_le (div_pos Real.pi_pos ha).le,
    integral_Ioc_eq_integral_Ioo]
  rfl

lemma intervalIntegrable_indicator_mU (a y : ℝ) :
    IntervalIntegrable ((Ioi (crossoverRoot / Real.pi)).indicator (mU a y)) volume 0 1 := by
  have h : IntervalIntegrable (mU a y) volume 0 1 := (continuous_mU a y).intervalIntegrable 0 1
  rw [intervalIntegrable_iff] at h ⊢
  exact h.indicator measurableSet_Ioi

lemma integral_indicator_mU (a y : ℝ) :
    (∫ u in (0 : ℝ)..1, (Ioi (crossoverRoot / Real.pi)).indicator (mU a y) u) =
      ∫ u in (crossoverRoot / Real.pi)..1, mU a y u := by
  rw [intervalIntegral.integral_of_le zero_le_one,
    intervalIntegral.integral_of_le crossoverRoot_div_pi_lt_one.le,
    setIntegral_indicator measurableSet_Ioi, Ioc_inter_Ioi,
    sup_eq_right.2 crossoverRoot_div_pi_pos.le]

lemma integral_mU {a y : ℝ} (ha : 0 < a) :
    (∫ u in (crossoverRoot / Real.pi)..1, mU a y u) =
      (a / Real.pi) ^ 2 * ∫ s in Ioo (0 : ℝ) ((Real.pi - crossoverRoot) / a),
        s * Real.cos (s * y) * gaussian s := by
  have ha0 : a ≠ 0 := ha.ne'
  have hR : 0 ≤ (Real.pi - crossoverRoot) / a :=
    div_nonneg (by linarith [crossoverRoot_spec.2.1]) ha.le
  have h1 : (∫ x in (0 : ℝ)..(1 - crossoverRoot / Real.pi), mU a y (1 - x)) =
      ∫ u in (crossoverRoot / Real.pi)..1, mU a y u := by
    rw [intervalIntegral.integral_comp_sub_left (mU a y) 1]
    simp only [sub_sub_cancel, sub_zero]
  have h2 := integral_rescale_unit (fun x => mU a y (1 - x)) ha0 0 (1 - crossoverRoot / Real.pi)
  have hRe : Real.pi * (1 - crossoverRoot / Real.pi) / a = (Real.pi - crossoverRoot) / a := by
    field_simp
  have hfun : (fun s => mU a y (1 - a * s / Real.pi)) =
      fun s => a / Real.pi * (s * Real.cos (s * y) * gaussian s) := by
    funext s
    simp only [mU]
    have e1 : 1 - (1 - a * s / Real.pi) = a * s / Real.pi := by ring
    have e2 : Real.pi * (y / a) * (a * s / Real.pi) = s * y := by field_simp; ring
    have e3 : Real.pi * (a * s / Real.pi) / a = s := by field_simp
    rw [e1, e2, e3]
    ring
  rw [← h1, h2]
  simp only [mul_zero, zero_div, hRe]
  rw [hfun, intervalIntegral.integral_const_mul, intervalIntegral.integral_of_le hR,
    integral_Ioc_eq_integral_Ioo]
  ring

lemma gaussianM_split {a y : ℝ} (ha : 0 < a) :
    a ^ 2 * gaussianM y / Real.pi ^ 2 = (∫ u in (crossoverRoot / Real.pi)..1, mU a y u) +
      (a / Real.pi) ^ 2 * ∫ s in Ioi ((Real.pi - crossoverRoot) / a),
        s * Real.cos (s * y) * gaussian s := by
  rw [integral_mU ha]
  have hR : 0 ≤ (Real.pi - crossoverRoot) / a :=
    div_nonneg (by linarith [crossoverRoot_spec.2.1]) ha.le
  have hi : IntegrableOn (fun s => s * Real.cos (s * y) * gaussian s) (Ioi 0) := by
    have h := integrable_pow_cos_gaussian 1 y
    simp only [pow_one] at h
    exact h.integrableOn
  have hsplit := integral_Ioo_add_Ioi_of_nonneg hR hi
  unfold gaussianM
  rw [← hsplit]
  ring

lemma abs_baselineTail_le {a y : ℝ} (ha : 0 < a) :
    |a / Real.pi * ∫ s in Ioi (Real.pi / a), gaussianBaselineIntegrand a y s| ≤ tailBound a := by
  have hap : 0 < a / Real.pi := div_pos ha Real.pi_pos
  have h1 : |∫ s in Ioi (Real.pi / a), gaussianBaselineIntegrand a y s| ≤
      ∫ s in Ioi (Real.pi / a), gaussianBaselineTailMajorant a s := by
    refine abs_integral_le_integral_abs.trans ?_
    apply setIntegral_mono_on (integrable_gaussianBaselineIntegrand a y).integrableOn.abs
      (integrable_gaussianBaselineTailMajorant a).integrableOn measurableSet_Ioi
    intro s hs
    exact abs_gaussianBaselineIntegrand_tail ha (le_of_lt hs)
  rw [abs_mul, abs_of_pos hap]
  have h2 := integral_gaussianBaselineTailMajorant_le ha
  have h3 := mul_le_mul_of_nonneg_left h1 hap.le
  unfold tailBound
  linarith

lemma abs_aliasTail_le {a y : ℝ} (ha : 0 < a) :
    |(a / Real.pi) ^ 2 * ∫ s in Ioi ((Real.pi - crossoverRoot) / a),
        s * Real.cos (s * y) * gaussian s| ≤ aliasTailBound a := by
  have hR : 0 ≤ (Real.pi - crossoverRoot) / a :=
    div_nonneg (by linarith [crossoverRoot_spec.2.1]) ha.le
  rw [abs_mul, abs_of_nonneg (sq_nonneg _)]
  unfold aliasTailBound
  apply mul_le_mul_of_nonneg_left _ (sq_nonneg _)
  rw [← gaussianTailMoment_one]
  unfold gaussianTailMoment
  refine abs_integral_le_integral_abs.trans ?_
  have hi : Integrable (fun s : ℝ => s * Real.cos (s * y) * gaussian s) := by
    have h := integrable_pow_cos_gaussian 1 y
    simp only [pow_one] at h
    exact h
  apply setIntegral_mono_on hi.integrableOn.abs (integrable_pow_gaussian 1).integrableOn
    measurableSet_Ioi
  intro s hs
  have hs0 : 0 ≤ s := hR.trans (le_of_lt hs)
  rw [abs_mul, abs_mul, abs_of_nonneg hs0, abs_of_nonneg (gaussian_nonneg s), pow_one]
  have h := mul_le_mul_of_nonneg_right
    (mul_le_mul_of_nonneg_left (Real.abs_cos_le_one (s * y)) hs0) (gaussian_nonneg s)
  linarith

theorem master_le {a y : ℝ} (ha : 0 < a) (ha1 : a ≤ 1) :
    JUpper a y - c a - c y ≤
      (∫ u in (0 : ℝ)..1, gU a y u) - masterTarget a y + tailBound a + aliasTailBound a := by
  have hE := intervalIntegrable_envelopeDifference (x := y) ha ha1
  have hC := intervalIntegrable_cotU (y := y) ha
  have hM := intervalIntegrable_indicator_mU a y
  have h1 : (∫ u in (0 : ℝ)..1, gU a y u) =
      (∫ u in (0 : ℝ)..1, (envelopeDifference a y u + cotU a y u)) -
        ∫ u in (0 : ℝ)..1, (Ioi (crossoverRoot / Real.pi)).indicator (mU a y) u :=
    intervalIntegral.integral_sub (hE.add hC) hM
  have h2 : (∫ u in (0 : ℝ)..1, (envelopeDifference a y u + cotU a y u)) =
      (∫ u in (0 : ℝ)..1, envelopeDifference a y u) + ∫ u in (0 : ℝ)..1, cotU a y u :=
    intervalIntegral.integral_add hE hC
  have hbase : (∫ u in (0 : ℝ)..1, envelopeDifference a y u) =
      JUpper a y - scaledGaussianKernelIntegral a y := by
    change (∫ u in (0 : ℝ)..1, upperEnvelopeIntegrand a y u - gaussianKernelUnit a y u) = _
    rw [intervalIntegral.integral_sub (intervalIntegrable_upperEnvelopeIntegrand ha ha1)
      (intervalIntegrable_gaussianKernelUnit a y), integral_gaussianKernelUnit ha]
    rfl
  have hS := scaledGaussianKernelIntegral_eq (x := y) ha
  have hMs := gaussianM_split (y := y) ha
  have hT := abs_baselineTail_le (y := y) ha
  have hA := abs_aliasTail_le (y := y) ha
  have hT' := neg_abs_le
    (a / Real.pi * ∫ s in Ioi (Real.pi / a), gaussianBaselineIntegrand a y s)
  have hA' := neg_abs_le ((a / Real.pi) ^ 2 * ∫ s in Ioi ((Real.pi - crossoverRoot) / a),
    s * Real.cos (s * y) * gaussian s)
  rw [integral_cotU ha] at h2
  rw [integral_indicator_mU] at h1
  unfold masterTarget
  unfold gaussianBaselineValue at hS
  linarith

/-! ### The integrand on the three envelope regions -/

lemma envelopeDifference_R1 {a y u : ℝ} (ha : 0 < a) (hu : 0 < u) (hu2 : u < 1 / 2) :
    envelopeDifference a y u = max 0 (-upperKernel (y / a) u) * gaussian (Real.pi * u / a) *
      (1 - Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * u)))) := by
  have ha0 : a ≠ 0 := ha.ne'
  have hph : a * (Real.pi * u / a) = Real.pi * u := by field_simp
  have hy0 : 0 < Real.pi * u := by positivity
  have hy2 : Real.pi * u < Real.pi / 2 := by nlinarith [Real.pi_pos]
  have hθ : Real.pi * u ≤ crossoverRoot := by linarith [crossoverRoot_spec.1]
  have hcos : 0 < Real.cos (Real.pi * u) := Real.cos_pos_of_mem_Ioo ⟨by linarith, hy2⟩
  have hE := Num.Efun_nonneg hy0.le hy2
  have hl : lowerEnvelope a crossoverRoot (Real.pi * u / a) =
      gaussian (Real.pi * u / a) * Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * u))) := by
    rw [lowerEnvelope, if_pos (by rw [hph]; exact hy2.le), hph, Num.cos_rpow_eq hcos]
    congr 1
    unfold gaussian
    rw [div_pow]
    ring_nf
  have hg : upperEnvelope a crossoverRoot (Real.pi * u / a) = gaussian (Real.pi * u / a) := by
    rw [upperEnvelope, if_pos (by rw [hph]; exact hθ)]
    rfl
  have hexp : Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * u))) ≤ 1 := by
    apply Real.exp_le_one_iff.2
    have : 0 ≤ 1 / a ^ 2 * Num.Efun (Real.pi * u) := mul_nonneg (by positivity) hE
    linarith
  have hlg : gaussian (Real.pi * u / a) * Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * u))) ≤
      gaussian (Real.pi * u / a) := by
    have := gaussian_nonneg (Real.pi * u / a)
    nlinarith
  unfold envelopeDifference upperEnvelopeIntegrand gaussianKernelUnit
  rw [hl, hg, max_kernel_loss _ _ _ hlg]
  ring

lemma envelopeDifference_R2 {a y u : ℝ} (ha : 0 < a) (hu2 : 1 / 2 < u)
    (huθ : u ≤ crossoverRoot / Real.pi) :
    envelopeDifference a y u = max 0 (-upperKernel (y / a) u) * gaussian (Real.pi * u / a) *
      (1 + |Real.cos (Real.pi * u)| * Real.exp ((Real.pi * u) ^ 2 / 2)) := by
  have ha0 : a ≠ 0 := ha.ne'
  have hph : a * (Real.pi * u / a) = Real.pi * u := by field_simp
  have hy2 : Real.pi / 2 < Real.pi * u := by nlinarith [Real.pi_pos]
  have hθ : Real.pi * u ≤ crossoverRoot := by
    have := (le_div_iff₀ Real.pi_pos).1 huθ
    linarith
  have hex : Real.exp (-(1 - a ^ 2) * (Real.pi * u / a) ^ 2 / 2) =
      gaussian (Real.pi * u / a) * Real.exp ((Real.pi * u) ^ 2 / 2) := by
    unfold gaussian
    rw [← Real.exp_add]
    congr 1
    field_simp
    ring
  have hl : lowerEnvelope a crossoverRoot (Real.pi * u / a) =
      -(|Real.cos (Real.pi * u)| *
        (gaussian (Real.pi * u / a) * Real.exp ((Real.pi * u) ^ 2 / 2))) := by
    rw [lowerEnvelope, if_neg (by rw [hph]; exact not_le.2 hy2), if_pos (by rw [hph]; exact hθ),
      hph, hex]
  have hg : upperEnvelope a crossoverRoot (Real.pi * u / a) = gaussian (Real.pi * u / a) := by
    rw [upperEnvelope, if_pos (by rw [hph]; exact hθ)]
    rfl
  have hlg : -(|Real.cos (Real.pi * u)| *
      (gaussian (Real.pi * u / a) * Real.exp ((Real.pi * u) ^ 2 / 2))) ≤
        gaussian (Real.pi * u / a) := by
    have h1 := gaussian_nonneg (Real.pi * u / a)
    have h2 : 0 ≤ |Real.cos (Real.pi * u)| *
        (gaussian (Real.pi * u / a) * Real.exp ((Real.pi * u) ^ 2 / 2)) := by positivity
    linarith
  unfold envelopeDifference upperEnvelopeIntegrand gaussianKernelUnit
  rw [hl, hg, max_kernel_loss _ _ _ hlg]
  ring

lemma envelopeDifference_R3 {a y u : ℝ} (ha : 0 < a) (huθ : crossoverRoot / Real.pi < u)
    (hu1 : u < 1) :
    envelopeDifference a y u = |upperKernel (y / a) u| * (gaussian (Real.pi * (1 - u) / a) *
      Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * (1 - u))))) -
        upperKernel (y / a) u * gaussian (Real.pi * u / a) := by
  have ha0 : a ≠ 0 := ha.ne'
  have hph : a * (Real.pi * u / a) = Real.pi * u := by field_simp
  have hθ : crossoverRoot < Real.pi * u := by
    have := (div_lt_iff₀ Real.pi_pos).1 huθ
    linarith
  have hy2 : Real.pi / 2 < Real.pi * u := by linarith [crossoverRoot_spec.1]
  have hyπ : Real.pi * u < Real.pi := by nlinarith [Real.pi_pos]
  have hcosneg : Real.cos (Real.pi * u) < 0 :=
    Real.cos_neg_of_pi_div_two_lt_of_lt hy2 (by linarith [Real.pi_pos])
  have habs : |Real.cos (Real.pi * u)| = Real.cos (Real.pi * (1 - u)) := by
    rw [abs_of_neg hcosneg, mul_one_sub, Real.cos_pi_sub]
  have hct : 0 < Real.cos (Real.pi * (1 - u)) := by
    rw [← habs]
    exact abs_pos.2 hcosneg.ne
  have hP : |Real.cos (Real.pi * u)| ^ (1 / a ^ 2 : ℝ) =
      gaussian (Real.pi * (1 - u) / a) * Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * (1 - u)))) := by
    rw [habs, Num.cos_rpow_eq hct]
    congr 1
    unfold gaussian
    rw [div_pow]
    ring_nf
  have hl : lowerEnvelope a crossoverRoot (Real.pi * u / a) =
      -(|Real.cos (Real.pi * u)| ^ (1 / a ^ 2 : ℝ)) := by
    rw [lowerEnvelope, if_neg (by rw [hph]; exact not_le.2 hy2),
      if_neg (by rw [hph]; exact not_le.2 hθ), if_pos (by rw [hph]; exact hyπ.le), hph]
  have hg : upperEnvelope a crossoverRoot (Real.pi * u / a) =
      |Real.cos (Real.pi * u)| ^ (1 / a ^ 2 : ℝ) := by
    rw [upperEnvelope, if_neg (by rw [hph]; exact not_le.2 hθ),
      if_pos (by rw [hph]; exact hyπ.le), hph]
  unfold envelopeDifference upperEnvelopeIntegrand gaussianKernelUnit
  rw [hl, hg, max_kernel_symmetric _ _ (Real.rpow_nonneg (abs_nonneg _) _), hP]

lemma cotU_eq {a y u : ℝ} (ha : 0 < a) :
    cotU a y u = (1 - u) * cotangentQ (Real.pi * u) * Real.sin (Real.pi * (y / a) * u) *
      gaussian (Real.pi * u / a) := by
  have ha0 : a ≠ 0 := ha.ne'
  unfold cotU cotangentRemainderIntegrand
  have e1 : a * (Real.pi * u / a) / Real.pi = u := by field_simp
  have e2 : a * (Real.pi * u / a) = Real.pi * u := by field_simp
  have e3 : Real.pi * u / a * y = Real.pi * (y / a) * u := by ring
  rw [e1, e2, e3]

/-- The two branches of `|κ| - (1 - u) cos(π ξ (1 - u))` in product form. -/
def bPlus (ξ u : ℝ) : ℝ :=
  -(2 * (1 - u) * Real.sin (Real.pi * ξ / 2) * Real.sin (Real.pi * ξ * (u - 1 / 2))) +
    rho u * Real.sin (Real.pi * ξ * u)

def bMinus (ξ u : ℝ) : ℝ :=
  -(2 * (1 - u) * Real.cos (Real.pi * ξ / 2) * Real.cos (Real.pi * ξ * (u - 1 / 2))) -
    rho u * Real.sin (Real.pi * ξ * u)

lemma abs_upperKernel_sub (ξ u : ℝ) :
    |upperKernel ξ u| - (1 - u) * Real.cos (Real.pi * ξ * (1 - u)) =
      max (bPlus ξ u) (bMinus ξ u) := by
  have hs := Real.cos_sub_cos (Real.pi * ξ * u) (Real.pi * ξ * (1 - u))
  have hc := Real.cos_add_cos (Real.pi * ξ * u) (Real.pi * ξ * (1 - u))
  have e1 : (Real.pi * ξ * u + Real.pi * ξ * (1 - u)) / 2 = Real.pi * ξ / 2 := by ring
  have e2 : (Real.pi * ξ * u - Real.pi * ξ * (1 - u)) / 2 = Real.pi * ξ * (u - 1 / 2) := by ring
  rw [e1, e2] at hs hc
  rw [abs_eq_max_neg, ← max_sub_sub_right]
  unfold bPlus bMinus upperKernel
  congr 1
  · linear_combination (1 - u) * hs
  · linear_combination -(1 - u) * hc

lemma gU_of_le {a y u : ℝ} (hu : u ≤ crossoverRoot / Real.pi) :
    gU a y u = envelopeDifference a y u + cotU a y u := by
  unfold gU
  rw [indicator_of_not_mem (show u ∉ Ioi (crossoverRoot / Real.pi) from not_lt.2 hu)]
  ring

lemma gU_R1 {a y u : ℝ} (ha : 0 < a) (hu : 0 < u) (hu2 : u < 1 / 2) :
    gU a y u = max 0 (-upperKernel (y / a) u) * gaussian (Real.pi * u / a) *
      (1 - Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * u)))) + cotU a y u := by
  have hθ : u ≤ crossoverRoot / Real.pi := by
    rw [le_div_iff₀ Real.pi_pos]
    nlinarith [crossoverRoot_spec.1, Real.pi_pos]
  rw [gU_of_le hθ, envelopeDifference_R1 ha hu hu2]

lemma gU_R2 {a y u : ℝ} (ha : 0 < a) (hu2 : 1 / 2 < u) (huθ : u ≤ crossoverRoot / Real.pi) :
    gU a y u = max 0 (-upperKernel (y / a) u) * gaussian (Real.pi * u / a) *
      (1 + |Real.cos (Real.pi * u)| * Real.exp ((Real.pi * u) ^ 2 / 2)) + cotU a y u := by
  rw [gU_of_le huθ, envelopeDifference_R2 ha hu2 huθ]

lemma gU_R3 {a y u : ℝ} (ha : 0 < a) (huθ : crossoverRoot / Real.pi < u) (hu1 : u < 1) :
    gU a y u = |upperKernel (y / a) u| * gaussian (Real.pi * (1 - u) / a) *
        (Real.exp (-(1 / a ^ 2 * Num.Efun (Real.pi * (1 - u)))) - 1) +
      max (bPlus (y / a) u) (bMinus (y / a) u) * gaussian (Real.pi * (1 - u) / a) -
      upperKernel (y / a) u * gaussian (Real.pi * u / a) + cotU a y u := by
  have hm := abs_upperKernel_sub (y / a) u
  unfold gU
  rw [indicator_of_mem (show u ∈ Ioi (crossoverRoot / Real.pi) from huθ),
    envelopeDifference_R3 ha huθ hu1]
  unfold mU
  rw [← hm]
  ring

end

end KellerKlein
