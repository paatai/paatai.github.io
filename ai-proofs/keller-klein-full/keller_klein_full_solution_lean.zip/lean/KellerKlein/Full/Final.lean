import KellerKlein.Full.MainConditional
import KellerKlein.Full.ZoneAGeneral
import KellerKlein.Full.PeelPieces
import KellerKlein.Full.LowerSmall
import KellerKlein.Num.Fourier

/-!
# The Keller–Klein Berry–Esseen bound for normalized Rademacher sums

Let `X = ∑ aⱼ εⱼ` with `∑ aⱼ² = 1` and independent uniform signs `εⱼ`, and let
`a ≥ max |aⱼ|`. Then for every real `x`
`|P[X ≤ x] - Φ(x)| ≤ Φ(a) - 1/2 = P[Z ∈ (0, a)]`, and the same for `P[X < x]`.

All seven inputs of `Pieces` are proved here, so the theorem is unconditional.
-/

open MeasureTheory Set ProbabilityTheory
open scoped BigOperators

namespace KellerKlein

noncomputable section

/-- The envelope inequality for (L), all `0 < a ≤ 0.55`. -/
theorem lowerFourier_piece {a x : ℝ} (ha : 0 < a) (ha1 : a ≤ 55 / 100) (hx : 3 * a / 2 ≤ x)
    (ht : c a < Real.exp (-(x ^ 2) / 2)) : JUpper a (-x) ≤ c a - c x := by
  rcases le_total a (1 / 10) with h | h
  · exact lowerFourier_small ha h hx ht
  · exact Num.lowerFourier_certified h ha1 hx ht

theorem pieces : Pieces where
  c675 := c675_piece
  zoneA := zoneA_piece
  upperFourier := Num.upperFourier_certified
  lowerFourier := lowerFourier_piece
  peelLLarge := peelLLarge_piece
  peelLNear := peelLNear_piece
  peelU := peelU_piece

/-- **Keller–Klein.** For a normalized Rademacher sum and any `a ≥ max |aⱼ|`, both CDF
conventions are within `Φ(a) - 1/2` of the standard normal CDF at every real `x`. -/
theorem keller_klein {n : ℕ} (coeff : Fin n → ℝ) (hvar : ∑ i, coeff i ^ 2 = 1) {a : ℝ}
    (hca : ∀ i, |coeff i| ≤ a) (x : ℝ) :
    |rademacherCDF coeff x - cdf (gaussianReal 0 1) x| ≤ cdf (gaussianReal 0 1) a - 1 / 2 ∧
      |rademacherStrictCDF coeff x - cdf (gaussianReal 0 1) x| ≤
        cdf (gaussianReal 0 1) a - 1 / 2 :=
  keller_klein_of_pieces pieces coeff hvar hca x

/-- The statement with `a₁ = max |aⱼ|`, attained at the index `i₀`. -/
theorem keller_klein_max {n : ℕ} (coeff : Fin n → ℝ) (hvar : ∑ i, coeff i ^ 2 = 1)
    (i₀ : Fin n) (hmax : ∀ i, |coeff i| ≤ |coeff i₀|) (x : ℝ) :
    |rademacherCDF coeff x - cdf (gaussianReal 0 1) x| ≤
        cdf (gaussianReal 0 1) |coeff i₀| - 1 / 2 ∧
      |rademacherStrictCDF coeff x - cdf (gaussianReal 0 1) x| ≤
        cdf (gaussianReal 0 1) |coeff i₀| - 1 / 2 :=
  keller_klein coeff hvar hmax x

end

end KellerKlein
