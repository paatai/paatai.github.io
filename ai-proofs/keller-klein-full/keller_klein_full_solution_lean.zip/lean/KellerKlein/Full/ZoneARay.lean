import KellerKlein.Full.ZoneAPoly
import Mathlib.Analysis.Calculus.ParametricIntervalIntegral

/-!
# Zone A, monotonicity along the ray in `a`

Fix `0 < b` with `b² ≤ 1/2` and write `P = cosineProfile b`, so `P(t) = (cos² bt)^(1/(2b²))` is
`C¹` with `|P'| ≤ 1/b`. For a continuous weight `k` with `k(1) = 0` let
`G(α) = ∫₀¹ k(u) P(πu/α) du`. Differentiating under the integral and integrating by parts,
`G'(α) = (1/α) ∫₀¹ j'(u) P(πu/α) du` with `j = u k`.

If `j' ≤ c₁ - 2u` on `[0, 1/2]` and `j' ≤ 0` on `[1/2, 1]`, then for `α ≥ b` the Gaussian majorant
`P(πu/α) ≤ exp(-π²u²/(2α²))` on `[0, 1/2]` gives
`G'(α) ≤ c₁ φ₀ - (2α/π²)(1 - exp(-π²/(8α²)))`.

For `k = 1 - u` (`c₁ = 1`) and `k = 1 - u + p(u)/2` (`c₁ = 3/2`) this is at most `φ(α)`,
resp. `φ(α) + φ(α/2)/2`, for `α < 0.675`. Hence `c(α) - G(α)` and `c(α) + c(α/2) - G(α)` are
nondecreasing on `[b, 0.675)`.
-/

namespace KellerKlein

noncomputable section

open MeasureTheory Set

lemma c_hasDerivAt (t : ℝ) : HasDerivAt c (phi t) t :=
  (continuous_phi.integral_hasStrictDerivAt 0 t).hasDerivAt

lemma le_of_hasDerivAt_nonneg {f f' : ℝ → ℝ} {x y : ℝ} (hxy : x ≤ y)
    (hd : ∀ t ∈ Icc x y, HasDerivAt f (f' t) t) (hn : ∀ t ∈ Icc x y, 0 ≤ f' t) :
    f x ≤ f y := by
  have hm := monotoneOn_of_hasDerivWithinAt_nonneg (convex_Icc x y)
    (fun t ht => (hd t ht).continuousAt.continuousWithinAt)
    (fun t ht => (hd t (interior_subset ht)).hasDerivWithinAt)
    (fun t ht => hn t (interior_subset ht))
  exact hm ⟨le_rfl, hxy⟩ ⟨hxy, le_rfl⟩ hxy

lemma cosineProfile_eq_sq {b : ℝ} (hb : b ≠ 0) (t : ℝ) :
    cosineProfile b t = (Real.cos (b * t) ^ 2) ^ (1 / (2 * b ^ 2)) := by
  unfold cosineProfile
  have h2 : (1 / b ^ 2 : ℝ) = 2 * (1 / (2 * b ^ 2)) := by field_simp
  rw [h2, Real.rpow_mul (abs_nonneg _), Real.rpow_two, sq_abs]

/-- The derivative of `cosineProfile b`, for `b² ≤ 1/2`. -/
def profileDeriv (b t : ℝ) : ℝ :=
  2 * Real.cos (b * t) * (-Real.sin (b * t) * b) * (1 / (2 * b ^ 2)) *
    (Real.cos (b * t) ^ 2) ^ (1 / (2 * b ^ 2) - 1)

lemma one_le_profile_exp {b : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) :
    1 ≤ 1 / (2 * b ^ 2) := by
  rw [le_div_iff₀ (by positivity)]; linarith

lemma hasDerivAt_cosineProfile {b : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) (t : ℝ) :
    HasDerivAt (cosineProfile b) (profileDeriv b t) t := by
  have hg : HasDerivAt (fun t => Real.cos (b * t) ^ 2)
      (2 * Real.cos (b * t) * (-Real.sin (b * t) * b)) t := by
    have h1 : HasDerivAt (fun t => b * t) b t := by
      simpa using (hasDerivAt_id t).const_mul b
    convert h1.cos.pow 2 using 1
    push_cast; ring
  have heq : cosineProfile b = fun t => (Real.cos (b * t) ^ 2) ^ (1 / (2 * b ^ 2)) := by
    funext t; exact cosineProfile_eq_sq hb.ne' t
  rw [heq]
  exact hg.rpow_const (Or.inr (one_le_profile_exp hb hb2))

lemma continuous_profileDeriv {b : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) :
    Continuous (profileDeriv b) := by
  have hp : 0 ≤ 1 / (2 * b ^ 2) - 1 := by linarith [one_le_profile_exp hb hb2]
  have hc : Continuous fun t => Real.cos (b * t) := by fun_prop
  have hs : Continuous fun t => Real.sin (b * t) := by fun_prop
  unfold profileDeriv
  exact (((continuous_const.mul hc).mul (hs.neg.mul continuous_const)).mul
    continuous_const).mul ((hc.pow 2).rpow_const (fun _ => Or.inr hp))

lemma abs_profileDeriv_le {b : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) (t : ℝ) :
    |profileDeriv b t| ≤ 1 / b := by
  have hp : 0 ≤ 1 / (2 * b ^ 2) - 1 := by linarith [one_le_profile_exp hb hb2]
  have he : profileDeriv b t = -(1 / b) * (Real.sin (b * t) * Real.cos (b * t)) *
      (Real.cos (b * t) ^ 2) ^ (1 / (2 * b ^ 2) - 1) := by
    unfold profileDeriv; field_simp; ring
  have hr0 : 0 ≤ (Real.cos (b * t) ^ 2) ^ (1 / (2 * b ^ 2) - 1) :=
    Real.rpow_nonneg (sq_nonneg _) _
  have hr1 : (Real.cos (b * t) ^ 2) ^ (1 / (2 * b ^ 2) - 1) ≤ 1 :=
    Real.rpow_le_one (sq_nonneg _)
      ((sq_le_one_iff_abs_le_one _).2 (Real.abs_cos_le_one _)) hp
  have hsc : |Real.sin (b * t) * Real.cos (b * t)| ≤ 1 := by
    rw [abs_mul]
    exact mul_le_one₀ (Real.abs_sin_le_one _) (abs_nonneg _) (Real.abs_cos_le_one _)
  rw [he, abs_mul, abs_mul, abs_neg, abs_of_pos (by positivity : (0 : ℝ) < 1 / b),
    abs_of_nonneg hr0]
  calc 1 / b * |Real.sin (b * t) * Real.cos (b * t)| *
        (Real.cos (b * t) ^ 2) ^ (1 / (2 * b ^ 2) - 1)
      ≤ 1 / b * 1 * 1 :=
        mul_le_mul (mul_le_mul_of_nonneg_left hsc (by positivity)) hr1 hr0 (by positivity)
    _ = 1 / b := by ring

lemma continuous_profile_comp (b α : ℝ) :
    Continuous fun u => cosineProfile b (Real.pi * u / α) :=
  (continuous_cosineProfile b).comp (by fun_prop)

/-- Differentiation under the integral sign. -/
theorem hasDerivAt_profileIntegral {b a₀ : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2)
    (ha₀ : 0 < a₀) {k : ℝ → ℝ} (hk : Continuous k) :
    HasDerivAt (fun α => ∫ u in (0 : ℝ)..1, k u * cosineProfile b (Real.pi * u / α))
      (∫ u in (0 : ℝ)..1, k u *
        (profileDeriv b (Real.pi * u / a₀) * (-(Real.pi * u) / a₀ ^ 2))) a₀ := by
  have hPd := continuous_profileDeriv hb hb2
  have hball : ∀ α ∈ Metric.ball a₀ (a₀ / 2), a₀ / 2 < α := by
    intro α hα
    rw [Metric.mem_ball, Real.dist_eq] at hα
    linarith [(abs_lt.1 hα).1]
  have hinner : ∀ u α : ℝ, α ≠ 0 →
      HasDerivAt (fun α => Real.pi * u / α) (-(Real.pi * u) / α ^ 2) α := by
    intro u α hα
    have h := (hasDerivAt_inv hα).const_mul (Real.pi * u)
    convert h using 1
    simp only [neg_div, mul_neg, div_eq_mul_inv, neg_mul]
  have hF'c : Continuous fun u =>
      k u * (profileDeriv b (Real.pi * u / a₀) * (-(Real.pi * u) / a₀ ^ 2)) :=
    hk.mul ((hPd.comp (by fun_prop : Continuous fun u => Real.pi * u / a₀)).mul
      (by fun_prop))
  have key := intervalIntegral.hasDerivAt_integral_of_dominated_loc_of_deriv_le (𝕜 := ℝ)
    (μ := volume) (a := 0) (b := 1)
    (F := fun α u => k u * cosineProfile b (Real.pi * u / α))
    (F' := fun α u => k u * (profileDeriv b (Real.pi * u / α) * (-(Real.pi * u) / α ^ 2)))
    (x₀ := a₀) (bound := fun u => |k u| * (1 / b) * (Real.pi * (4 / a₀ ^ 2)))
    (half_pos ha₀)
    (Filter.Eventually.of_forall fun α =>
      (hk.mul (continuous_profile_comp b α)).aestronglyMeasurable)
    ((hk.mul (continuous_profile_comp b a₀)).intervalIntegrable 0 1)
    hF'c.aestronglyMeasurable ?_
    (((hk.abs.mul continuous_const).mul continuous_const).intervalIntegrable 0 1) ?_
  · exact key.2
  · refine Filter.Eventually.of_forall fun u hu α hα => ?_
    rw [uIoc_of_le zero_le_one] at hu
    have hα' := hball α hα
    have hαpos : 0 < α := by linarith
    have hu0 : 0 ≤ u := hu.1.le
    have hfrac : Real.pi * u / α ^ 2 ≤ Real.pi * (4 / a₀ ^ 2) := by
      rw [div_le_iff₀ (by positivity)]
      have h4 : a₀ ^ 2 / 4 ≤ α ^ 2 := by nlinarith
      have h1 : Real.pi * u ≤ Real.pi := by nlinarith [Real.pi_pos, hu.2]
      calc Real.pi * u ≤ Real.pi := h1
        _ = Real.pi * (4 / a₀ ^ 2) * (a₀ ^ 2 / 4) := by field_simp
        _ ≤ Real.pi * (4 / a₀ ^ 2) * α ^ 2 :=
          mul_le_mul_of_nonneg_left h4 (by positivity)
    have he : |-(Real.pi * u) / α ^ 2| = Real.pi * u / α ^ 2 := by
      rw [neg_div, abs_neg, abs_of_nonneg (by positivity)]
    show ‖k u * (profileDeriv b (Real.pi * u / α) * (-(Real.pi * u) / α ^ 2))‖ ≤
      |k u| * (1 / b) * (Real.pi * (4 / a₀ ^ 2))
    rw [Real.norm_eq_abs, abs_mul, abs_mul, he, mul_assoc]
    apply mul_le_mul_of_nonneg_left _ (abs_nonneg _)
    exact mul_le_mul (abs_profileDeriv_le hb hb2 _) hfrac (by positivity) (by positivity)
  · refine Filter.Eventually.of_forall fun u _ α hα => ?_
    have hαpos : 0 < α := by linarith [hball α hα, half_pos ha₀]
    exact ((hasDerivAt_cosineProfile hb hb2 _).comp α (hinner u α hαpos.ne')).const_mul (k u)

/-- Integration by parts in `u`. -/
lemma profileIntegral_deriv_eq {b a : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) (ha : 0 < a)
    {k j' : ℝ → ℝ} (hj' : Continuous j') (hk1 : k 1 = 0)
    (hj : ∀ u, HasDerivAt (fun u => u * k u) (j' u) u) :
    (∫ u in (0 : ℝ)..1, k u * (profileDeriv b (Real.pi * u / a) * (-(Real.pi * u) / a ^ 2))) =
      (1 / a) * ∫ u in (0 : ℝ)..1, j' u * cosineProfile b (Real.pi * u / a) := by
  have hlin : ∀ u, HasDerivAt (fun u => Real.pi * u / a) (Real.pi / a) u := by
    intro u
    simpa using ((hasDerivAt_id u).const_mul Real.pi).div_const a
  have hV : ∀ u, HasDerivAt (fun u => cosineProfile b (Real.pi * u / a))
      (profileDeriv b (Real.pi * u / a) * (Real.pi / a)) u :=
    fun u => (hasDerivAt_cosineProfile hb hb2 _).comp u (hlin u)
  have hU : ∀ u, HasDerivAt (fun u => -(u * k u) / a) (-(j' u) / a) u :=
    fun u => (hj u).neg.div_const a
  have hVc : Continuous fun u => profileDeriv b (Real.pi * u / a) * (Real.pi / a) :=
    ((continuous_profileDeriv hb hb2).comp
      (by fun_prop : Continuous fun u => Real.pi * u / a)).mul continuous_const
  have hibp := intervalIntegral.integral_mul_deriv_eq_deriv_mul (a := 0) (b := 1)
    (fun u _ => hU u) (fun u _ => hV u)
    ((hj'.neg.div_const a).intervalIntegrable 0 1) (hVc.intervalIntegrable 0 1)
  have hL : (fun u => k u * (profileDeriv b (Real.pi * u / a) * (-(Real.pi * u) / a ^ 2))) =
      fun u => -(u * k u) / a * (profileDeriv b (Real.pi * u / a) * (Real.pi / a)) := by
    funext u; field_simp; ring
  have hR : (fun u => -(j' u) / a * cosineProfile b (Real.pi * u / a)) =
      fun u => (-(1 / a)) * (j' u * cosineProfile b (Real.pi * u / a)) := by
    funext u; ring
  rw [hL, hibp, hR, intervalIntegral.integral_const_mul, hk1]
  simp only [mul_zero, zero_mul, neg_zero, zero_div, sub_zero, zero_sub]
  ring

lemma gaussian_half_integral_le {a : ℝ} (ha : 0 < a) :
    (∫ u in (0 : ℝ)..(1 / 2), Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2)) ≤
      a * phi0 := by
  have hβ : 0 < Real.pi ^ 2 / (2 * a ^ 2) := by positivity
  rw [intervalIntegral.integral_of_le (by norm_num)]
  calc (∫ u in Ioc (0 : ℝ) (1 / 2), Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2))
      ≤ ∫ u in Ioi (0 : ℝ), Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2) :=
        setIntegral_mono_set (μ := volume) (integrable_exp_neg_mul_sq hβ).integrableOn
          (Filter.Eventually.of_forall fun u => by simp only [Pi.zero_apply]; positivity)
          Ioc_subset_Ioi_self.eventuallyLE
    _ = √(Real.pi / (Real.pi ^ 2 / (2 * a ^ 2))) / 2 := integral_gaussian_Ioi _
    _ ≤ a * phi0 := by
        have hphi : phi0 ^ 2 = 1 / (2 * Real.pi) := by
          have := two_pi_phi0_sq
          field_simp
          linarith
        have hx : Real.pi / (Real.pi ^ 2 / (2 * a ^ 2)) = (2 * a * phi0) ^ 2 := by
          rw [mul_pow, hphi]
          field_simp
          ring
        rw [hx, Real.sqrt_sq (by have := phi0_pos; positivity)]
        linarith

lemma gaussian_half_moment_one {a : ℝ} (ha : 0 < a) :
    (∫ u in (0 : ℝ)..(1 / 2), u * Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2)) =
      a ^ 2 / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))) := by
  have hd : ∀ u ∈ uIcc (0 : ℝ) (1 / 2), HasDerivAt
      (fun u => -(a ^ 2 / Real.pi ^ 2) * Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2))
      (u * Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2)) u := by
    intro u _
    have h := (((hasDerivAt_pow 2 u).const_mul (-(Real.pi ^ 2 / (2 * a ^ 2)))).exp).const_mul
      (-(a ^ 2 / Real.pi ^ 2))
    convert h using 1
    field_simp
    ring
  rw [intervalIntegral.integral_eq_sub_of_hasDerivAt hd
    (by apply Continuous.intervalIntegrable; fun_prop)]
  have he : -(Real.pi ^ 2 / (2 * a ^ 2)) * (1 / 2 : ℝ) ^ 2 = -(Real.pi ^ 2 / (8 * a ^ 2)) := by
    field_simp; ring
  rw [he]
  simp only [ne_eq, OfNat.ofNat_ne_zero, not_false_eq_true, zero_pow, mul_zero, Real.exp_zero]
  ring

/-- The derivative bound along the ray. -/
lemma profile_moment_bound {b a c₁ : ℝ} (hb : 0 < b) (hba : b ≤ a) {j' : ℝ → ℝ}
    (hj' : Continuous j') (hc₁ : 1 ≤ c₁)
    (hlo : ∀ u ∈ Icc (0 : ℝ) (1 / 2), j' u ≤ c₁ - 2 * u)
    (hhi : ∀ u ∈ Icc (1 / 2 : ℝ) 1, j' u ≤ 0) :
    (1 / a) * ∫ u in (0 : ℝ)..1, j' u * cosineProfile b (Real.pi * u / a) ≤
      c₁ * phi0 - 2 * a / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))) := by
  have ha : 0 < a := hb.trans_le hba
  have hf : Continuous fun u => j' u * cosineProfile b (Real.pi * u / a) :=
    hj'.mul (continuous_profile_comp b a)
  have hE : Continuous fun u =>
      (c₁ - 2 * u) * Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2) := by fun_prop
  have hsplit := intervalIntegral.integral_add_adjacent_intervals (μ := volume) (a := 0)
    (b := 1 / 2) (c := 1) (hf.intervalIntegrable 0 (1 / 2)) (hf.intervalIntegrable (1 / 2) 1)
  have hhi' : (∫ u in (1 / 2 : ℝ)..1, j' u * cosineProfile b (Real.pi * u / a)) ≤ 0 := by
    have h := intervalIntegral.integral_mono_on (μ := volume) (by norm_num)
      (hf.intervalIntegrable (1 / 2) 1)
      (continuous_const.intervalIntegrable (1 / 2) 1)
      (fun u hu => mul_nonpos_of_nonpos_of_nonneg (hhi u hu) (cosineProfile_nonneg _ _) :
        ∀ u ∈ Icc (1 / 2 : ℝ) 1, j' u * cosineProfile b (Real.pi * u / a) ≤ (0 : ℝ))
    simpa using h
  have hlo' : (∫ u in (0 : ℝ)..(1 / 2), j' u * cosineProfile b (Real.pi * u / a)) ≤
      ∫ u in (0 : ℝ)..(1 / 2), (c₁ - 2 * u) *
        Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2) := by
    apply intervalIntegral.integral_mono_on (by norm_num) (hf.intervalIntegrable _ _)
      (hE.intervalIntegrable _ _)
    intro u hu
    have hW0 := cosineProfile_nonneg b (Real.pi * u / a)
    have hu0 := hu.1
    have hs : 0 ≤ Real.pi * u / a := by positivity
    have hbs : b * (Real.pi * u / a) ≤ Real.pi / 2 := by
      rw [← mul_div_assoc, div_le_iff₀ ha]
      have : b * u ≤ a * (1 / 2) := mul_le_mul hba hu.2 hu0 ha.le
      nlinarith [Real.pi_pos]
    have hWE : cosineProfile b (Real.pi * u / a) ≤
        Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2) := by
      have h := ZoneA.cosine_profile_le_quartic hb hs hbs
      unfold cosineProfile
      refine h.trans (Real.exp_le_exp.2 ?_)
      have he : -(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2 = -((Real.pi * u / a) ^ 2 / 2) := by
        field_simp; ring
      rw [he]
      have : 0 ≤ b ^ 2 * (Real.pi * u / a) ^ 4 / 12 := by positivity
      linarith
    have hc : 0 ≤ c₁ - 2 * u := by linarith [hu.2]
    calc j' u * cosineProfile b (Real.pi * u / a)
        ≤ (c₁ - 2 * u) * cosineProfile b (Real.pi * u / a) :=
          mul_le_mul_of_nonneg_right (hlo u hu) hW0
      _ ≤ (c₁ - 2 * u) * Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2) :=
          mul_le_mul_of_nonneg_left hWE hc
  have hint : (∫ u in (0 : ℝ)..(1 / 2), (c₁ - 2 * u) *
        Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2)) =
      c₁ * (∫ u in (0 : ℝ)..(1 / 2), Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2)) -
        2 * ∫ u in (0 : ℝ)..(1 / 2), u * Real.exp (-(Real.pi ^ 2 / (2 * a ^ 2)) * u ^ 2) := by
    rw [← intervalIntegral.integral_const_mul, ← intervalIntegral.integral_const_mul,
      ← intervalIntegral.integral_sub]
    · congr 1; funext u; ring
    · apply Continuous.intervalIntegrable; fun_prop
    · apply Continuous.intervalIntegrable; fun_prop
  have h0 := gaussian_half_integral_le ha
  have h1 := gaussian_half_moment_one ha
  have hI : (∫ u in (0 : ℝ)..1, j' u * cosineProfile b (Real.pi * u / a)) ≤
      c₁ * (a * phi0) - 2 * (a ^ 2 / Real.pi ^ 2 *
        (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2))))) := by
    rw [← hsplit]
    have := mul_le_mul_of_nonneg_left h0 (by linarith : (0 : ℝ) ≤ c₁)
    linarith
  calc (1 / a) * ∫ u in (0 : ℝ)..1, j' u * cosineProfile b (Real.pi * u / a)
      ≤ (1 / a) * (c₁ * (a * phi0) - 2 * (a ^ 2 / Real.pi ^ 2 *
          (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))))) :=
        mul_le_mul_of_nonneg_left hI (by positivity)
    _ = c₁ * phi0 - 2 * a / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))) := by
        field_simp
        ring

lemma exp_neg_ray_le {a : ℝ} (ha : 0 < a) (ha1 : a < 675 / 1000) :
    Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2))) ≤ 1 / 10 := by
  have ha2 : a ^ 2 < (675 / 1000) ^ 2 := pow_lt_pow_left₀ ha1 ha.le (by norm_num)
  have hX : 27 / 10 ≤ Real.pi ^ 2 / (8 * a ^ 2) := by
    rw [le_div_iff₀ (by positivity)]
    nlinarith [pi_sq_gt]
  have h1 := Real.quadratic_le_exp_of_nonneg (show (0 : ℝ) ≤ 27 / 20 by norm_num)
  have h2 : Real.exp (27 / 10) = Real.exp (27 / 20) * Real.exp (27 / 20) := by
    rw [← Real.exp_add]; norm_num
  have h3 : 10 ≤ Real.exp (27 / 10) := by rw [h2]; nlinarith
  have h4 : Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2))) ≤ Real.exp (-(27 / 10)) :=
    Real.exp_le_exp.2 (by linarith)
  have h5 : Real.exp (-(27 / 10)) * Real.exp (27 / 10) = 1 := by
    rw [← Real.exp_add]; simp
  nlinarith [Real.exp_pos (-(27 / 10))]

lemma phi0_lt : phi0 < 2 / 5 := by
  have h := two_pi_phi0_sq
  have hp := phi0_pos
  by_contra hc
  push_neg at hc
  have h2 : (2 / 5 : ℝ) ^ 2 ≤ phi0 ^ 2 := pow_le_pow_left₀ (by norm_num) hc 2
  nlinarith [Real.pi_gt_d2]

lemma phi0_a_pi_sq_le {a : ℝ} (ha : 0 < a) (ha1 : a < 675 / 1000) :
    phi0 * a * Real.pi ^ 2 ≤ 3 := by
  have h := mul_le_mul (mul_le_mul phi0_lt.le ha1.le ha.le (by norm_num)) pi_sq_lt.le
    (by positivity) (by norm_num)
  linarith

lemma ray_target_zero {a : ℝ} (ha : 0 < a) (ha1 : a < 675 / 1000) :
    1 * phi0 - 2 * a / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))) ≤
      phi a := by
  have he := exp_neg_ray_le ha ha1
  have hphi := phi_lower_quadratic a
  have hpi0 : 0 < Real.pi ^ 2 := by positivity
  have hkey : phi0 * a ^ 2 / 2 ≤ 2 * a / Real.pi ^ 2 * (9 / 10) := by
    rw [div_mul_eq_mul_div, le_div_iff₀ hpi0]
    nlinarith [phi0_a_pi_sq_le ha ha1]
  have hm : 2 * a / Real.pi ^ 2 * (9 / 10) ≤
      2 * a / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))) :=
    mul_le_mul_of_nonneg_left (by linarith) (by positivity)
  nlinarith

lemma ray_target_half {a : ℝ} (ha : 0 < a) (ha1 : a < 675 / 1000) :
    3 / 2 * phi0 - 2 * a / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))) ≤
      phi a + phi (a / 2) * (1 / 2) := by
  have he := exp_neg_ray_le ha ha1
  have hphi := phi_lower_quadratic a
  have hphi2 := phi_lower_quadratic (a / 2)
  have hpi0 : 0 < Real.pi ^ 2 := by positivity
  have hkey : 9 / 16 * phi0 * a ^ 2 ≤ 2 * a / Real.pi ^ 2 * (9 / 10) := by
    have hr : 2 * a / Real.pi ^ 2 * (9 / 10) = 2 * a * (9 / 10) / Real.pi ^ 2 := by ring
    rw [hr, le_div_iff₀ hpi0]
    nlinarith [phi0_a_pi_sq_le ha ha1]
  have hm : 2 * a / Real.pi ^ 2 * (9 / 10) ≤
      2 * a / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * a ^ 2)))) :=
    mul_le_mul_of_nonneg_left (by linarith) (by positivity)
  nlinarith

/-- Monotonicity along the ray `α ∈ [b, a]`. -/
theorem profile_ray_mono {b a c₁ : ℝ} (hb : 0 < b) (hba : b ≤ a) (ha1 : a < 675 / 1000)
    {k j' g g' : ℝ → ℝ} (hk : Continuous k) (hj' : Continuous j') (hk1 : k 1 = 0)
    (hj : ∀ u, HasDerivAt (fun u => u * k u) (j' u) u) (hc₁ : 1 ≤ c₁)
    (hlo : ∀ u ∈ Icc (0 : ℝ) (1 / 2), j' u ≤ c₁ - 2 * u)
    (hhi : ∀ u ∈ Icc (1 / 2 : ℝ) 1, j' u ≤ 0)
    (hg : ∀ α, 0 < α → HasDerivAt g (g' α) α)
    (htarget : ∀ α, 0 < α → α < 675 / 1000 →
      c₁ * phi0 - 2 * α / Real.pi ^ 2 * (1 - Real.exp (-(Real.pi ^ 2 / (8 * α ^ 2)))) ≤
        g' α) :
    g b - ∫ u in (0 : ℝ)..1, k u * cosineProfile b (Real.pi * u / b) ≤
      g a - ∫ u in (0 : ℝ)..1, k u * cosineProfile b (Real.pi * u / a) := by
  have hb2 : b ^ 2 ≤ 1 / 2 := by nlinarith
  apply le_of_hasDerivAt_nonneg (f := fun α =>
      g α - ∫ u in (0 : ℝ)..1, k u * cosineProfile b (Real.pi * u / α))
    (f' := fun α => g' α - ∫ u in (0 : ℝ)..1, k u *
      (profileDeriv b (Real.pi * u / α) * (-(Real.pi * u) / α ^ 2))) hba
  · intro α hα
    have hαpos : 0 < α := hb.trans_le hα.1
    exact (hg α hαpos).sub (hasDerivAt_profileIntegral hb hb2 hαpos hk)
  · intro α hα
    have hαpos : 0 < α := hb.trans_le hα.1
    show 0 ≤ g' α - ∫ u in (0 : ℝ)..1, k u *
      (profileDeriv b (Real.pi * u / α) * (-(Real.pi * u) / α ^ 2))
    rw [profileIntegral_deriv_eq hb hb2 hαpos hj' hk1 hj]
    have h1 := profile_moment_bound hb hα.1 hj' hc₁ hlo hhi
    have h2 := htarget α hαpos (hα.2.trans_lt ha1)
    linarith

/-- `k_h(u) = 1 - u + p(u)/2`. -/
def kHalf (u : ℝ) : ℝ := (1 - u) + kernelPoly u / 2

/-- `(u k_h(u))'`. -/
def jHalf' (u : ℝ) : ℝ := 3 / 2 - 2 * u - 15 / 4 * u ^ 2 + 2 * u ^ 3 + 5 / 4 * u ^ 4

lemma continuous_kHalf : Continuous kHalf := by unfold kHalf kernelPoly; fun_prop

lemma continuous_jHalf' : Continuous jHalf' := by unfold jHalf'; fun_prop

lemma kHalf_one : kHalf 1 = 0 := by unfold kHalf kernelPoly; norm_num

lemma hasDerivAt_jHalf (u : ℝ) : HasDerivAt (fun u => u * kHalf u) (jHalf' u) u := by
  have he : (fun u => u * kHalf u) =
      fun u => 3 / 2 * u - u ^ 2 - 5 / 4 * u ^ 3 + u ^ 4 / 2 + u ^ 5 / 4 := by
    funext u; unfold kHalf kernelPoly; ring
  rw [he]
  convert (((((hasDerivAt_id u).const_mul (3 / 2)).sub (hasDerivAt_pow 2 u)).sub
    ((hasDerivAt_pow 3 u).const_mul (5 / 4))).add ((hasDerivAt_pow 4 u).div_const 2)).add
    ((hasDerivAt_pow 5 u).div_const 4) using 1
  unfold jHalf'
  norm_num
  ring

lemma jHalf'_lo : ∀ u ∈ Icc (0 : ℝ) (1 / 2), jHalf' u ≤ 3 / 2 - 2 * u := by
  intro u hu
  unfold jHalf'
  have h0 := hu.1
  have h1 := hu.2
  nlinarith [mul_nonneg (mul_nonneg h0 h0) (by linarith : (0 : ℝ) ≤ 1 / 2 - u),
    mul_nonneg (mul_nonneg (mul_nonneg h0 h0) h0) (by linarith : (0 : ℝ) ≤ 1 / 2 - u)]

lemma jHalf'_hi : ∀ u ∈ Icc (1 / 2 : ℝ) 1, jHalf' u ≤ 0 := by
  intro u hu
  unfold jHalf'
  have h0 := hu.1
  have h1 := hu.2
  nlinarith [mul_nonneg (by linarith : (0 : ℝ) ≤ u - 1 / 2) (by linarith : (0 : ℝ) ≤ 1 - u),
    mul_nonneg (mul_nonneg (by linarith : (0 : ℝ) ≤ u - 1 / 2) (by linarith : (0 : ℝ) ≤ 1 - u))
      (by linarith : (0 : ℝ) ≤ u),
    mul_nonneg (mul_nonneg (by linarith : (0 : ℝ) ≤ u - 1 / 2) (by linarith : (0 : ℝ) ≤ 1 - u))
      (mul_nonneg (by linarith : (0 : ℝ) ≤ u) (by linarith : (0 : ℝ) ≤ u))]

lemma hasDerivAt_jZero (u : ℝ) : HasDerivAt (fun u => u * (1 - u)) (1 - 2 * u) u := by
  convert (hasDerivAt_id u).mul ((hasDerivAt_const u (1 : ℝ)).sub (hasDerivAt_id u)) using 1
  simp only [id_eq]; ring

/-- `c(α) - ∫₀¹ (1 - u) P(πu/α) du` is nondecreasing on `[b, 0.675)`. -/
theorem ray_zero {b a : ℝ} (hb : 0 < b) (hba : b ≤ a) (ha1 : a < 675 / 1000) :
    c b - ∫ u in (0 : ℝ)..1, (1 - u) * cosineProfile b (Real.pi * u / b) ≤
      c a - ∫ u in (0 : ℝ)..1, (1 - u) * cosineProfile b (Real.pi * u / a) :=
  profile_ray_mono (k := fun u => 1 - u) (j' := fun u => 1 - 2 * u) (g := c) (g' := phi)
    (c₁ := 1) hb hba ha1 (by fun_prop) (by fun_prop) (by norm_num) hasDerivAt_jZero le_rfl
    (fun u _ => le_rfl) (fun u hu => by show 1 - 2 * u ≤ 0; linarith [hu.1])
    (fun α _ => c_hasDerivAt α)
    (fun α hα hα1 => ray_target_zero hα hα1)

/-- `c(α) + c(α/2) - ∫₀¹ k_h(u) P(πu/α) du` is nondecreasing on `[b, 0.675)`. -/
theorem ray_half {b a : ℝ} (hb : 0 < b) (hba : b ≤ a) (ha1 : a < 675 / 1000) :
    (c b + c (b / 2)) - ∫ u in (0 : ℝ)..1, kHalf u * cosineProfile b (Real.pi * u / b) ≤
      (c a + c (a / 2)) - ∫ u in (0 : ℝ)..1, kHalf u * cosineProfile b (Real.pi * u / a) := by
  have hg : ∀ α : ℝ, 0 < α → HasDerivAt (fun α => c α + c (α / 2))
      (phi α + phi (α / 2) * (1 / 2)) α := by
    intro α _
    have h2 : HasDerivAt (fun α : ℝ => α / 2) (1 / 2) α := by
      simpa using (hasDerivAt_id α).div_const 2
    have h3 := (c_hasDerivAt (α / 2)).comp α h2
    exact (c_hasDerivAt α).add h3
  exact profile_ray_mono (k := kHalf) (j' := jHalf') (g := fun α => c α + c (α / 2))
    (g' := fun α => phi α + phi (α / 2) * (1 / 2)) (c₁ := 3 / 2) hb hba ha1
    continuous_kHalf continuous_jHalf' kHalf_one hasDerivAt_jHalf (by norm_num)
    jHalf'_lo jHalf'_hi hg (fun α hα hα1 => ray_target_half hα hα1)

end

end KellerKlein
