import KellerKlein.Full.LowerPrawitz

/-!
# Peeling one coefficient

Write `X = α ε + Y` where `ε` is the sign of one coordinate and `Y` is the Rademacher sum of
the remaining coefficients.  By the symmetry of `Y`,

* `P[|X| ≤ x] = ½ (P[|Y| ≤ x + a] + P[|Y| ≤ x - a])` for `x ≥ a = |α|`,
* `P[|X| ≤ x] = ½ (P[|Y| ≤ a + x] - P[|Y| < a - x])` for `0 ≤ x < a`,
* `P[|X| < x] = ½ (P[|Y| < x + a] + P[|Y| < x - a])` for `x > a`.
-/

open MeasureTheory Set Finset
open scoped BigOperators

namespace KellerKlein

noncomputable section

/-- Coefficients with the coordinate `i` removed. -/
def removeCoeff {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1)) : Fin n → ℝ :=
  fun j => c (i.succAbove j)

lemma rademacherSum_insertNth {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1)) (b : Bool)
    (ω : BoolCube n) :
    rademacherSum c (Fin.insertNth i b ω) =
      c i * rademacherSign b + rademacherSum (removeCoeff c i) ω := by
  unfold rademacherSum removeCoeff
  rw [Fin.sum_univ_succAbove _ i]
  simp [Fin.insertNth_apply_same, Fin.insertNth_apply_succAbove]

lemma cubeExpectation_split {n : ℕ} (i : Fin (n + 1)) (f : BoolCube (n + 1) → ℝ) :
    cubeExpectation f =
      (cubeExpectation (fun ω => f (Fin.insertNth i true ω)) +
        cubeExpectation (fun ω => f (Fin.insertNth i false ω))) / 2 := by
  unfold cubeExpectation
  let e := Fin.insertNthEquiv (fun _ : Fin (n + 1) => Bool) i
  have hsum : (∑ ω : BoolCube (n + 1), f ω) =
      ∑ p : Bool × BoolCube n, f (e p) := by
    rw [e.sum_comp]
  have he : ∀ p : Bool × BoolCube n, e p = Fin.insertNth i p.1 p.2 := by
    intro p
    rfl
  rw [hsum, Fintype.sum_prod_type]
  simp only [he, Fintype.sum_bool]
  rw [pow_succ]
  field_simp

lemma rademacher_expectation_peel {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1))
    (f : ℝ → ℝ) :
    cubeExpectation (fun ω => f (rademacherSum c ω)) =
      (cubeExpectation (fun ω => f (c i + rademacherSum (removeCoeff c i) ω)) +
        cubeExpectation (fun ω => f (-c i + rademacherSum (removeCoeff c i) ω))) / 2 := by
  rw [cubeExpectation_split i]
  congr 2
  · congr 1; funext ω; rw [rademacherSum_insertNth]; simp [rademacherSign]
  · congr 1; funext ω; rw [rademacherSum_insertNth]; simp [rademacherSign]

/-- The law of `X` is the average of the laws of `Y + a` and `Y - a`; by symmetry of `Y`
this is the law of `Y + |c i|` folded. -/
lemma rademacher_prob_peel {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1))
    (p : ℝ → Prop) (hp : ∀ y, p y ↔ p (-y)) :
    cubeProbability (fun ω => p (rademacherSum c ω)) =
      cubeProbability (fun ω => p (|c i| + rademacherSum (removeCoeff c i) ω)) := by
  classical
  rw [cubeProbability_eq_expectation, cubeProbability_eq_expectation,
    rademacher_expectation_peel c i (fun y => if p y then (1 : ℝ) else 0)]
  set d := removeCoeff c i
  have hsym : ∀ α : ℝ, cubeExpectation (fun ω => (fun y => if p y then (1 : ℝ) else 0)
        (-α + rademacherSum d ω)) =
      cubeExpectation (fun ω => (fun y => if p y then (1 : ℝ) else 0)
        (α + rademacherSum d ω)) := by
    intro α
    have h := rademacher_expectation_symmetric d
      (fun y => if p (-α + y) then (1 : ℝ) else 0)
    simp only at h
    rw [← h]
    congr 1
    funext ω
    have : p (-α + -rademacherSum d ω) ↔ p (α + rademacherSum d ω) := by
      rw [hp (α + rademacherSum d ω)]
      constructor <;> intro h <;> convert h using 1 <;> ring
    simp only [this]
  rcases le_total 0 (c i) with hci | hci
  · rw [abs_of_nonneg hci, hsym (c i)]
    ring
  · rw [abs_of_nonpos hci]
    have h2 := hsym (c i)
    simp only [neg_neg] at h2 ⊢
    rw [h2]
    ring

lemma cubeProbability_add_eq_or_add_and {n : ℕ} (p q : BoolCube n → Prop) :
    cubeProbability p + cubeProbability q =
      cubeProbability (fun ω => p ω ∨ q ω) + cubeProbability (fun ω => p ω ∧ q ω) := by
  classical
  rw [cubeProbability_eq_expectation, cubeProbability_eq_expectation,
    cubeProbability_eq_expectation, cubeProbability_eq_expectation,
    ← cubeExpectation_add, ← cubeExpectation_add]
  congr 1
  funext ω
  by_cases hp : p ω <;> by_cases hq : q ω <;> simp [hp, hq]

/-- Reflection of an interval event for a symmetric sum. -/
lemma rademacher_prob_reflect {n : ℕ} (d : Fin n → ℝ) (p : ℝ → Prop) :
    cubeProbability (fun ω => p (rademacherSum d ω)) =
      cubeProbability (fun ω => p (-rademacherSum d ω)) :=
  rademacher_prob_neg_symm d p

/-- `P[|X| ≤ x] = ½ (P[|Y| ≤ x + a] + P[|Y| ≤ x - a])` for `x ≥ a = |c i|`. -/
theorem peel_closed_ge {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1)) {x : ℝ}
    (hx : |c i| ≤ x) :
    rademacherConcentration c x =
      (rademacherConcentration (removeCoeff c i) (x + |c i|) +
        rademacherConcentration (removeCoeff c i) (x - |c i|)) / 2 := by
  set a := |c i|
  set d := removeCoeff c i
  have h1 : rademacherConcentration c x =
      cubeProbability (fun ω => |a + rademacherSum d ω| ≤ x) :=
    rademacher_prob_peel c i (fun y => |y| ≤ x) (fun y => by simp only [abs_neg])
  have h2 : cubeProbability (fun ω => |a + rademacherSum d ω| ≤ x) =
      cubeProbability (fun ω => |a - rademacherSum d ω| ≤ x) := by
    have := rademacher_prob_reflect d (fun y => |a + y| ≤ x)
    simpa [sub_eq_add_neg] using this
  have h3 := cubeProbability_add_eq_or_add_and
    (fun ω => |a + rademacherSum d ω| ≤ x) (fun ω => |a - rademacherSum d ω| ≤ x)
  have hor : cubeProbability (fun ω => |a + rademacherSum d ω| ≤ x ∨
      |a - rademacherSum d ω| ≤ x) = rademacherConcentration d (x + a) := by
    unfold rademacherConcentration
    apply cubeProbability_congr
    intro ω
    set y := rademacherSum d ω
    have ha : 0 ≤ a := abs_nonneg _
    constructor
    · rintro (h | h) <;> rw [abs_le] at h ⊢ <;> constructor <;> linarith [h.1, h.2]
    · intro h
      rw [abs_le] at h
      by_cases hy : y ≤ 0
      · left; rw [abs_le]; constructor <;> linarith
      · right; rw [abs_le]; constructor <;> linarith
  have hand : cubeProbability (fun ω => |a + rademacherSum d ω| ≤ x ∧
      |a - rademacherSum d ω| ≤ x) = rademacherConcentration d (x - a) := by
    unfold rademacherConcentration
    apply cubeProbability_congr
    intro ω
    set y := rademacherSum d ω
    constructor
    · rintro ⟨h, h'⟩
      rw [abs_le] at h h' ⊢; constructor <;> linarith [h.1, h.2, h'.1, h'.2]
    · intro h
      have ha : 0 ≤ a := abs_nonneg _
      rw [abs_le] at h
      constructor <;> rw [abs_le] <;> constructor <;> linarith
  rw [h1]
  rw [hor, hand, ← h2] at h3
  linarith

/-- `P[|X| ≤ x] = ½ (P[|Y| ≤ a + x] - P[|Y| < a - x])` for `0 ≤ x < a = |c i|`. -/
theorem peel_closed_lt {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1)) {x : ℝ}
    (hx0 : 0 ≤ x) (hx : x < |c i|) :
    rademacherConcentration c x =
      (rademacherConcentration (removeCoeff c i) (|c i| + x) -
        rademacherOpenConcentration (removeCoeff c i) (|c i| - x)) / 2 := by
  set a := |c i|
  set d := removeCoeff c i
  have h1 : rademacherConcentration c x =
      cubeProbability (fun ω => |a + rademacherSum d ω| ≤ x) :=
    rademacher_prob_peel c i (fun y => |y| ≤ x) (fun y => by simp only [abs_neg])
  have h2 : cubeProbability (fun ω => |a + rademacherSum d ω| ≤ x) =
      cubeProbability (fun ω => |a - rademacherSum d ω| ≤ x) := by
    have := rademacher_prob_reflect d (fun y => |a + y| ≤ x)
    simpa [sub_eq_add_neg] using this
  have h3 := cubeProbability_or_disjoint
    (fun ω => |a + rademacherSum d ω| ≤ x) (fun ω => |a - rademacherSum d ω| ≤ x)
    (by
      intro ω ⟨h, h'⟩
      dsimp only at h h'
      rw [abs_le] at h h'
      linarith [h.2, h'.2])
  have hor : cubeProbability (fun ω => |a + rademacherSum d ω| ≤ x ∨
      |a - rademacherSum d ω| ≤ x) =
      rademacherConcentration d (a + x) - rademacherOpenConcentration d (a - x) := by
    have hsplit := cubeProbability_or_disjoint
      (fun ω => |rademacherSum d ω| < a - x)
      (fun ω => |a + rademacherSum d ω| ≤ x ∨ |a - rademacherSum d ω| ≤ x)
      (by
        intro ω ⟨h, h'⟩
        dsimp only at h h'
        rw [abs_lt] at h
        rcases h' with h' | h' <;> rw [abs_le] at h' <;> linarith [h'.1, h'.2])
    have hunion : cubeProbability (fun ω => |rademacherSum d ω| < a - x ∨
        (|a + rademacherSum d ω| ≤ x ∨ |a - rademacherSum d ω| ≤ x)) =
        rademacherConcentration d (a + x) := by
      unfold rademacherConcentration
      apply cubeProbability_congr
      intro ω
      set y := rademacherSum d ω
      constructor
      · rintro (h | h | h)
        · rw [abs_lt] at h; rw [abs_le]; constructor <;> linarith
        · rw [abs_le] at h ⊢; constructor <;> linarith [h.1, h.2]
        · rw [abs_le] at h ⊢; constructor <;> linarith [h.1, h.2]
      · intro h
        rw [abs_le] at h
        by_cases hy : |y| < a - x
        · exact Or.inl hy
        · right
          rw [abs_lt, not_and_or, not_lt, not_lt] at hy
          rcases hy with hy | hy
          · left; rw [abs_le]; constructor <;> linarith
          · right; rw [abs_le]; constructor <;> linarith
    unfold rademacherOpenConcentration
    linarith
  rw [h1]
  rw [hor, ← h2] at h3
  linarith

/-- `P[|X| < x] = ½ (P[|Y| < x + a] + P[|Y| < x - a])` for `x > a = |c i|`. -/
theorem peel_open_gt {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1)) {x : ℝ}
    (hx : |c i| < x) :
    rademacherOpenConcentration c x =
      (rademacherOpenConcentration (removeCoeff c i) (x + |c i|) +
        rademacherOpenConcentration (removeCoeff c i) (x - |c i|)) / 2 := by
  set a := |c i|
  set d := removeCoeff c i
  have h1 : rademacherOpenConcentration c x =
      cubeProbability (fun ω => |a + rademacherSum d ω| < x) :=
    rademacher_prob_peel c i (fun y => |y| < x) (fun y => by simp only [abs_neg])
  have h2 : cubeProbability (fun ω => |a + rademacherSum d ω| < x) =
      cubeProbability (fun ω => |a - rademacherSum d ω| < x) := by
    have := rademacher_prob_reflect d (fun y => |a + y| < x)
    simpa [sub_eq_add_neg] using this
  have h3 := cubeProbability_add_eq_or_add_and
    (fun ω => |a + rademacherSum d ω| < x) (fun ω => |a - rademacherSum d ω| < x)
  have hor : cubeProbability (fun ω => |a + rademacherSum d ω| < x ∨
      |a - rademacherSum d ω| < x) = rademacherOpenConcentration d (x + a) := by
    unfold rademacherOpenConcentration
    apply cubeProbability_congr
    intro ω
    set y := rademacherSum d ω
    have ha : 0 ≤ a := abs_nonneg _
    constructor
    · rintro (h | h) <;> rw [abs_lt] at h ⊢ <;> constructor <;> linarith [h.1, h.2]
    · intro h
      rw [abs_lt] at h
      by_cases hy : y ≤ 0
      · left; rw [abs_lt]; constructor <;> linarith
      · right; rw [abs_lt]; constructor <;> linarith
  have hand : cubeProbability (fun ω => |a + rademacherSum d ω| < x ∧
      |a - rademacherSum d ω| < x) = rademacherOpenConcentration d (x - a) := by
    unfold rademacherOpenConcentration
    apply cubeProbability_congr
    intro ω
    set y := rademacherSum d ω
    constructor
    · rintro ⟨h, h'⟩
      rw [abs_lt] at h h' ⊢; constructor <;> linarith [h.1, h.2, h'.1, h'.2]
    · intro h
      have ha : 0 ≤ a := abs_nonneg _
      rw [abs_lt] at h
      constructor <;> rw [abs_lt] <;> constructor <;> linarith
  rw [h1]
  rw [hor, hand, ← h2] at h3
  linarith

/-- `P[|X| ≤ x] ≤ P[X < 0]`-type bound used for large coefficients: if `0 ≤ x < a` then
`P[|X| ≤ x] ≤ 1/2`. -/
theorem peel_closed_lt_le_half {n : ℕ} (c : Fin (n + 1) → ℝ) (i : Fin (n + 1)) {x : ℝ}
    (hx0 : 0 ≤ x) (hx : x < |c i|) :
    rademacherConcentration c x ≤ 1 / 2 := by
  rw [peel_closed_lt c i hx0 hx]
  set d := removeCoeff c i
  -- `P[|Y| ≤ a + x] - P[|Y| < a - x] = P[a - x ≤ |Y| ≤ a + x] ≤ P[|Y| > 0] ≤ 1`
  have hsplit := cubeProbability_or_disjoint
    (fun ω => |rademacherSum d ω| < |c i| - x)
    (fun ω => |c i| - x ≤ |rademacherSum d ω| ∧ |rademacherSum d ω| ≤ |c i| + x)
    (by intro ω ⟨h, h'⟩; linarith [h'.1])
  have hunion : cubeProbability (fun ω => |rademacherSum d ω| < |c i| - x ∨
      (|c i| - x ≤ |rademacherSum d ω| ∧ |rademacherSum d ω| ≤ |c i| + x)) =
      rademacherConcentration d (|c i| + x) := by
    unfold rademacherConcentration
    apply cubeProbability_congr
    intro ω
    constructor
    · rintro (h | h)
      · linarith
      · exact h.2
    · intro h
      by_cases h' : |rademacherSum d ω| < |c i| - x
      · exact Or.inl h'
      · exact Or.inr ⟨le_of_not_gt h', h⟩
  -- the annulus avoids `0`, so it has probability at most `P[Y ≠ 0] ≤ 1`
  have hle : cubeProbability (fun ω => |c i| - x ≤ |rademacherSum d ω| ∧
      |rademacherSum d ω| ≤ |c i| + x) ≤ 1 := cubeProbability_le_one _
  unfold rademacherOpenConcentration
  linarith

end

end KellerKlein
