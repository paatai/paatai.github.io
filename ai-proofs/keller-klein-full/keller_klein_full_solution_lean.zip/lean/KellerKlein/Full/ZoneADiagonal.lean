import KellerKlein.Full.ZoneARay
import KellerKlein.Full.Wallis

/-!
# Zone A, the diagonal `a = b`

At `a = b` the profile is `P(πu/b) = |cos πu|^N` with `N = 1/b²`. Reflecting `u ↦ 1 - u`:

* `∫₀¹ (1 - u) |cos πu|^N du = V(N)`, the Wallis integral;
* `∫₀¹ k_h(u) |cos πu|^N du = (3/2) V(N) + J/2` with `J = ∫₀^{1/2} u²(1-u)² cos^N(πu) du`,
  because `k_h(u) + k_h(1 - u) = 3/2 + u²(1-u)²/2`.

With `V(N)² ≤ 1/(2π(N + 1/2)) = φ₀² b²/(1 + b²/2)`, `J ≤ φ₀ b³/π²` (Gaussian majorant) and
`c(t) ≥ φ₀ (t - t³/6)` both endpoint functionals are nonnegative at `a = b`.
-/

namespace KellerKlein

noncomputable section

open MeasureTheory Set

lemma cosineProfile_diag {b : ℝ} (hb : b ≠ 0) (u : ℝ) :
    cosineProfile b (Real.pi * u / b) = |Real.cos (Real.pi * u)| ^ (1 / b ^ 2) := by
  unfold cosineProfile
  have : b * (Real.pi * u / b) = Real.pi * u := by field_simp
  rw [this]

lemma integral_reflect_half {f : ℝ → ℝ} (hf : Continuous f) :
    (∫ u in (0 : ℝ)..1, f u) = ∫ u in (0 : ℝ)..(1 / 2), (f u + f (1 - u)) := by
  have hsplit := intervalIntegral.integral_add_adjacent_intervals (μ := volume) (a := 0)
    (b := 1 / 2) (c := 1) (hf.intervalIntegrable 0 (1 / 2)) (hf.intervalIntegrable (1 / 2) 1)
  have hrefl : (∫ u in (0 : ℝ)..(1 / 2), f (1 - u)) = ∫ u in (1 / 2 : ℝ)..1, f u := by
    rw [intervalIntegral.integral_comp_sub_left f 1]
    norm_num
  have hc : Continuous fun u => f (1 - u) := hf.comp (by fun_prop)
  rw [intervalIntegral.integral_add (hf.intervalIntegrable _ _) (hc.intervalIntegrable _ _),
    hrefl, hsplit]

lemma integral_diag_eq {b : ℝ} (hb : b ≠ 0) {k : ℝ → ℝ} (hk : Continuous k) :
    (∫ u in (0 : ℝ)..1, k u * cosineProfile b (Real.pi * u / b)) =
      ∫ u in (0 : ℝ)..(1 / 2), (k u + k (1 - u)) * Real.cos (Real.pi * u) ^ (1 / b ^ 2) := by
  have hf : Continuous fun u => k u * |Real.cos (Real.pi * u)| ^ (1 / b ^ 2) :=
    hk.mul ((by fun_prop : Continuous fun u => |Real.cos (Real.pi * u)|).rpow_const
      (fun _ => Or.inr (by positivity)))
  have h1 : (fun u => k u * cosineProfile b (Real.pi * u / b)) =
      fun u => k u * |Real.cos (Real.pi * u)| ^ (1 / b ^ 2) := by
    funext u; rw [cosineProfile_diag hb]
  rw [h1, integral_reflect_half hf]
  apply intervalIntegral.integral_congr
  intro u hu
  rw [uIcc_of_le (by norm_num)] at hu
  have hc : 0 ≤ Real.cos (Real.pi * u) := cos_pi_mul_nonneg_of_mem hu.1 hu.2
  have hrefl : |Real.cos (Real.pi * (1 - u))| = Real.cos (Real.pi * u) := by
    rw [mul_sub, mul_one, Real.cos_pi_sub, abs_neg, abs_of_nonneg hc]
  simp only [hrefl, abs_of_nonneg hc]
  ring

theorem diag_zero_eq {b : ℝ} (hb : 0 < b) :
    (∫ u in (0 : ℝ)..1, (1 - u) * cosineProfile b (Real.pi * u / b)) = wallisV (1 / b ^ 2) := by
  rw [integral_diag_eq hb.ne' (k := fun u => 1 - u) (by fun_prop)]
  unfold wallisV
  congr 1
  funext u
  ring

/-- `J = ∫₀^{1/2} u²(1-u)² cos^N(πu) du`. -/
def diagJ (b : ℝ) : ℝ :=
  ∫ u in (0 : ℝ)..(1 / 2), u ^ 2 * (1 - u) ^ 2 * Real.cos (Real.pi * u) ^ (1 / b ^ 2)

lemma continuous_cos_pi_rpow' {b : ℝ} :
    Continuous fun u : ℝ => Real.cos (Real.pi * u) ^ (1 / b ^ 2) :=
  continuous_cos_pi_rpow (by positivity)

theorem diag_half_eq {b : ℝ} (hb : 0 < b) :
    (∫ u in (0 : ℝ)..1, kHalf u * cosineProfile b (Real.pi * u / b)) =
      3 / 2 * wallisV (1 / b ^ 2) + diagJ b / 2 := by
  rw [integral_diag_eq hb.ne' continuous_kHalf]
  have he : (fun u => (kHalf u + kHalf (1 - u)) * Real.cos (Real.pi * u) ^ (1 / b ^ 2)) =
      fun u => 3 / 2 * Real.cos (Real.pi * u) ^ (1 / b ^ 2) +
        (1 / 2) * (u ^ 2 * (1 - u) ^ 2 * Real.cos (Real.pi * u) ^ (1 / b ^ 2)) := by
    funext u; unfold kHalf kernelPoly; ring
  have hc := continuous_cos_pi_rpow' (b := b)
  have hc1 : Continuous fun u => 3 / 2 * Real.cos (Real.pi * u) ^ (1 / b ^ 2) :=
    continuous_const.mul hc
  have hc2 : Continuous fun u =>
      1 / 2 * (u ^ 2 * (1 - u) ^ 2 * Real.cos (Real.pi * u) ^ (1 / b ^ 2)) :=
    continuous_const.mul ((by fun_prop : Continuous fun u : ℝ => u ^ 2 * (1 - u) ^ 2).mul hc)
  rw [he, intervalIntegral.integral_add (hc1.intervalIntegrable _ _) (hc2.intervalIntegrable _ _),
    intervalIntegral.integral_const_mul, intervalIntegral.integral_const_mul]
  unfold wallisV diagJ
  ring

lemma integrable_sq_gauss {β : ℝ} (hβ : 0 < β) :
    Integrable (fun u : ℝ => u ^ 2 * Real.exp (-β * u ^ 2)) := by
  have h := integrable_rpow_mul_exp_neg_mul_sq hβ (s := (2 : ℝ)) (by norm_num)
  have he : (fun u : ℝ => u ^ 2 * Real.exp (-β * u ^ 2)) =
      fun u : ℝ => u ^ (2 : ℝ) * Real.exp (-β * u ^ 2) := by
    funext u; rw [Real.rpow_two]
  rw [he]; exact h

lemma integral_sq_gauss_Ioi {b : ℝ} (hb : 0 < b) :
    (∫ u in Ioi (0 : ℝ), u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2)) =
      (b / Real.pi) ^ 3 * halfMoment 2 := by
  have hl : 0 < Real.pi / b := div_pos Real.pi_pos hb
  have h := integral_comp_mul_left_Ioi (fun s => s ^ 2 * gaussian s) 0 hl
  rw [mul_zero, smul_eq_mul, inv_div] at h
  have hpt : (fun u : ℝ => u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2)) =
      fun u => (b / Real.pi) ^ 2 * ((Real.pi / b * u) ^ 2 * gaussian (Real.pi / b * u)) := by
    funext u
    unfold gaussian
    have e1 : -((Real.pi / b * u) ^ 2) / 2 = -(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2 := by
      field_simp; ring
    rw [e1]
    field_simp
    ring
  rw [hpt, integral_const_mul, h]
  unfold halfMoment
  ring

theorem diagJ_le {b : ℝ} (hb : 0 < b) : diagJ b ≤ phi0 * b ^ 3 / Real.pi ^ 2 := by
  have hβ : 0 < Real.pi ^ 2 / (2 * b ^ 2) := by positivity
  have hg : Continuous fun u : ℝ => u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2) := by
    fun_prop
  have hpt : ∀ u ∈ Icc (0 : ℝ) (1 / 2),
      u ^ 2 * (1 - u) ^ 2 * Real.cos (Real.pi * u) ^ (1 / b ^ 2) ≤
        u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2) := by
    intro u hu
    have hc : 0 ≤ Real.cos (Real.pi * u) := cos_pi_mul_nonneg_of_mem hu.1 hu.2
    have hu0 := hu.1
    have hs : 0 ≤ Real.pi * u / b := by positivity
    have he1 : b * (Real.pi * u / b) = Real.pi * u := by field_simp
    have hbs : b * (Real.pi * u / b) ≤ Real.pi / 2 := by
      rw [he1]; nlinarith [Real.pi_pos, hu.2]
    have h := ZoneA.cosine_profile_le_quartic hb hs hbs
    rw [he1, abs_of_nonneg hc] at h
    have he2 : -(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2 = -((Real.pi * u / b) ^ 2 / 2) := by
      field_simp; ring
    have hE : Real.cos (Real.pi * u) ^ (1 / b ^ 2) ≤
        Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2) := by
      rw [he2]
      refine h.trans (Real.exp_le_exp.2 ?_)
      have : 0 ≤ b ^ 2 * (Real.pi * u / b) ^ 4 / 12 := by positivity
      linarith
    have h1u : (1 - u) ^ 2 ≤ 1 := by nlinarith [hu.1, hu.2]
    have hr0 : 0 ≤ Real.cos (Real.pi * u) ^ (1 / b ^ 2) := Real.rpow_nonneg hc _
    calc u ^ 2 * (1 - u) ^ 2 * Real.cos (Real.pi * u) ^ (1 / b ^ 2)
        ≤ u ^ 2 * 1 * Real.cos (Real.pi * u) ^ (1 / b ^ 2) :=
          mul_le_mul_of_nonneg_right (mul_le_mul_of_nonneg_left h1u (sq_nonneg u)) hr0
      _ ≤ u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2) := by
          rw [mul_one]; exact mul_le_mul_of_nonneg_left hE (sq_nonneg u)
  have hJ : diagJ b ≤ ∫ u in (0 : ℝ)..(1 / 2),
      u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2) := by
    unfold diagJ
    apply intervalIntegral.integral_mono_on (by norm_num) _ (hg.intervalIntegrable _ _) hpt
    apply Continuous.intervalIntegrable
    exact (by fun_prop : Continuous fun u : ℝ => u ^ 2 * (1 - u) ^ 2).mul
      continuous_cos_pi_rpow'
  have hIoi : (∫ u in (0 : ℝ)..(1 / 2),
      u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2)) ≤
      ∫ u in Ioi (0 : ℝ), u ^ 2 * Real.exp (-(Real.pi ^ 2 / (2 * b ^ 2)) * u ^ 2) := by
    rw [intervalIntegral.integral_of_le (by norm_num)]
    exact setIntegral_mono_set (μ := volume) (integrable_sq_gauss hβ).integrableOn
      (Filter.Eventually.of_forall fun u => by simp only [Pi.zero_apply]; positivity)
      Ioc_subset_Ioi_self.eventuallyLE
  rw [integral_sq_gauss_Ioi hb, halfMoment_two] at hIoi
  have he : (b / Real.pi) ^ 3 * (Real.pi * phi0) = phi0 * b ^ 3 / Real.pi ^ 2 := by
    field_simp; ring
  linarith

lemma wallis_diag_bound {b : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) :
    wallisV (1 / b ^ 2) ^ 2 * (1 + b ^ 2 / 2) ≤ phi0 ^ 2 * b ^ 2 := by
  have hN : 1 / 2 ≤ 1 / b ^ 2 := by
    rw [le_div_iff₀ (by positivity)]; linarith
  have hV := wallisV_sq_le hN
  have hphi : phi0 ^ 2 = 1 / (2 * Real.pi) := by
    rw [eq_div_iff (by positivity)]
    linarith [two_pi_phi0_sq]
  have he : 1 / (2 * Real.pi * (1 / b ^ 2 + 1 / 2)) = phi0 ^ 2 * b ^ 2 / (1 + b ^ 2 / 2) := by
    rw [hphi]; field_simp
  rw [he, le_div_iff₀ (by positivity)] at hV
  exact hV

/-- `F₀(b) ≥ 0`. -/
theorem diag_zero_le {b : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) :
    (∫ u in (0 : ℝ)..1, (1 - u) * cosineProfile b (Real.pi * u / b)) ≤ c b := by
  rw [diag_zero_eq hb]
  have hV0 := wallisV_nonneg (1 / b ^ 2)
  have hV := wallis_diag_bound hb hb2
  have hc := c_lower_cubic hb.le
  have hp := phi0_pos
  have hT : 0 ≤ phi0 * (b - b ^ 3 / 6) := by
    apply mul_nonneg hp.le
    nlinarith
  have hpoly : b ^ 2 ≤ (b - b ^ 3 / 6) ^ 2 * (1 + b ^ 2 / 2) := by
    have h4 : 0 ≤ b ^ 4 * (12 - 10 * b ^ 2 + b ^ 4) := by
      apply mul_nonneg (by positivity); nlinarith
    nlinarith
  have hsq : wallisV (1 / b ^ 2) ^ 2 ≤ (phi0 * (b - b ^ 3 / 6)) ^ 2 := by
    have h1 : 0 < 1 + b ^ 2 / 2 := by positivity
    have h2 : phi0 ^ 2 * b ^ 2 ≤ (phi0 * (b - b ^ 3 / 6)) ^ 2 * (1 + b ^ 2 / 2) := by
      have := mul_le_mul_of_nonneg_left hpoly (sq_nonneg phi0)
      nlinarith
    have h3 : wallisV (1 / b ^ 2) ^ 2 * (1 + b ^ 2 / 2) ≤
        (phi0 * (b - b ^ 3 / 6)) ^ 2 * (1 + b ^ 2 / 2) := hV.trans h2
    exact le_of_mul_le_mul_right h3 h1
  have := (pow_le_pow_iff_left₀ hV0 hT two_ne_zero).1 hsq
  linarith

/-- `F_h(b) ≥ 0`. -/
theorem diag_half_le {b : ℝ} (hb : 0 < b) (hb2 : b ^ 2 ≤ 1 / 2) :
    (∫ u in (0 : ℝ)..1, kHalf u * cosineProfile b (Real.pi * u / b)) ≤ c b + c (b / 2) := by
  rw [diag_half_eq hb]
  have hV0 := wallisV_nonneg (1 / b ^ 2)
  have hV := wallis_diag_bound hb hb2
  have hJ := diagJ_le hb
  have hc1 := c_lower_cubic hb.le
  have hc2 := c_lower_cubic (show 0 ≤ b / 2 by positivity)
  have hp := phi0_pos
  have hpi : 9 ≤ Real.pi ^ 2 := by nlinarith [Real.pi_gt_three]
  have hpi0 : 0 < Real.pi ^ 2 := by positivity
  obtain ⟨x, hx_def⟩ : ∃ x, x = b ^ 2 := ⟨_, rfl⟩
  rw [← hx_def] at hV hb2
  have hx0 : 0 < x := by rw [hx_def]; positivity
  obtain ⟨R, hR_def⟩ : ∃ R, R = 3 / 2 - 3 * x / 16 - x / (2 * Real.pi ^ 2) := ⟨_, rfl⟩
  have hinv : x / (2 * Real.pi ^ 2) ≤ x / 18 := by
    apply div_le_div_of_nonneg_left hx0.le (by norm_num); linarith
  have hR0 : 3 / 2 - 35 * x / 144 ≤ R := by rw [hR_def]; linarith
  have hR0pos : 0 < 3 / 2 - 35 * x / 144 := by linarith
  have hRpos : 0 ≤ R := by linarith
  have hRsq : 9 / 4 ≤ R ^ 2 * (1 + x / 2) := by
    have h1 : (3 / 2 - 35 * x / 144) ^ 2 ≤ R ^ 2 :=
      pow_le_pow_left₀ hR0pos.le hR0 2
    have h2 : 9 / 4 ≤ (3 / 2 - 35 * x / 144) ^ 2 * (1 + x / 2) := by
      nlinarith [mul_nonneg hx0.le (by linarith : (0 : ℝ) ≤ 1 / 2 - x), pow_nonneg hx0.le 3]
    have h3 : (3 / 2 - 35 * x / 144) ^ 2 * (1 + x / 2) ≤ R ^ 2 * (1 + x / 2) :=
      mul_le_mul_of_nonneg_right h1 (by linarith)
    linarith
  obtain ⟨T, hT_def⟩ : ∃ T, T = phi0 * b * R := ⟨_, rfl⟩
  have hT0 : 0 ≤ T := by
    rw [hT_def]; exact mul_nonneg (mul_nonneg hp.le hb.le) hRpos
  have hsq : (3 / 2 * wallisV (1 / b ^ 2)) ^ 2 ≤ T ^ 2 := by
    have h1 : 0 < 1 + x / 2 := by positivity
    have h2 : (3 / 2 * wallisV (1 / b ^ 2)) ^ 2 * (1 + x / 2) ≤ T ^ 2 * (1 + x / 2) := by
      have e1 : (3 / 2 * wallisV (1 / b ^ 2)) ^ 2 * (1 + x / 2) =
          9 / 4 * (wallisV (1 / b ^ 2) ^ 2 * (1 + x / 2)) := by ring
      have e2 : T ^ 2 * (1 + x / 2) = phi0 ^ 2 * x * (R ^ 2 * (1 + x / 2)) := by
        rw [hT_def, hx_def]; ring
      rw [e1, e2, ← hx_def]
      have h3 : 9 / 4 * (wallisV (1 / x) ^ 2 * (1 + x / 2)) ≤ 9 / 4 * (phi0 ^ 2 * x) :=
        mul_le_mul_of_nonneg_left hV (by norm_num)
      have h4 : 9 / 4 * (phi0 ^ 2 * x) ≤ phi0 ^ 2 * x * (R ^ 2 * (1 + x / 2)) := by
        have := mul_le_mul_of_nonneg_left hRsq (by positivity : (0 : ℝ) ≤ phi0 ^ 2 * x)
        linarith
      linarith
    exact le_of_mul_le_mul_right h2 h1
  have hV3 := (pow_le_pow_iff_left₀ (by positivity) hT0 two_ne_zero).1 hsq
  have hTe : T = phi0 * (b - b ^ 3 / 6) + phi0 * (b / 2 - (b / 2) ^ 3 / 6) -
      phi0 * b ^ 3 / (2 * Real.pi ^ 2) := by
    rw [hT_def, hR_def, hx_def]; field_simp; ring
  have hJ2 : diagJ b / 2 ≤ phi0 * b ^ 3 / (2 * Real.pi ^ 2) := by
    have : phi0 * b ^ 3 / (2 * Real.pi ^ 2) = (phi0 * b ^ 3 / Real.pi ^ 2) / 2 := by
      field_simp; ring
    rw [this]; linarith
  linarith

end

end KellerKlein
