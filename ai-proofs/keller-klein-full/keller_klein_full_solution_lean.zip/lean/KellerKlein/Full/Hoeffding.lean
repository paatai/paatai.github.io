import KellerKlein.Full.Peeling
import Mathlib.Analysis.SpecialFunctions.Trigonometric.Series

/-!
# Hoeffding's inequality and rescaling for Rademacher sums
-/

open MeasureTheory Set Finset
open scoped BigOperators

namespace KellerKlein

noncomputable section

lemma bool_exp_sum (r : ℝ) :
    (∑ b : Bool, Real.exp (r * rademacherSign b)) = 2 * Real.cosh r := by
  rw [Fintype.sum_bool, Real.cosh_eq]
  simp [rademacherSign]
  ring

lemma rademacher_exp_sum {n : ℕ} (c : Fin n → ℝ) (s : ℝ) :
    (∑ ω : BoolCube n, Real.exp (s * rademacherSum c ω)) =
      (2 : ℝ) ^ n * ∏ i, Real.cosh (s * c i) := by
  have hpoint (ω : BoolCube n) :
      Real.exp (s * rademacherSum c ω) =
        ∏ i : Fin n, Real.exp ((s * c i) * rademacherSign (ω i)) := by
    rw [← Real.exp_sum]
    congr 1
    simp only [rademacherSum, Finset.mul_sum]
    apply Finset.sum_congr rfl
    intro i _
    ring
  calc
    _ = ∑ ω : BoolCube n, ∏ i : Fin n, Real.exp ((s * c i) * rademacherSign (ω i)) :=
      Finset.sum_congr rfl (fun ω _ => hpoint ω)
    _ = ∏ i : Fin n, ∑ b : Bool, Real.exp ((s * c i) * rademacherSign b) :=
      (Fintype.prod_sum (fun (i : Fin n) (b : Bool) =>
        Real.exp ((s * c i) * rademacherSign b))).symm
    _ = ∏ i : Fin n, 2 * Real.cosh (s * c i) := by
      apply Finset.prod_congr rfl
      intro i _
      exact bool_exp_sum _
    _ = _ := by
      rw [Finset.prod_mul_distrib]
      simp

lemma rademacher_exp_expectation_le {n : ℕ} (c : Fin n → ℝ) (hvar : ∑ i, c i ^ 2 = 1)
    (s : ℝ) :
    cubeExpectation (fun ω => Real.exp (s * rademacherSum c ω)) ≤ Real.exp (s ^ 2 / 2) := by
  unfold cubeExpectation
  rw [rademacher_exp_sum, mul_div_cancel_left₀ _ (by positivity)]
  calc
    (∏ i, Real.cosh (s * c i)) ≤ ∏ i, Real.exp ((s * c i) ^ 2 / 2) := by
      apply Finset.prod_le_prod
      · intro i _; exact (Real.cosh_pos _).le
      · intro i _; exact Real.cosh_le_exp_half_sq _
    _ = Real.exp (s ^ 2 / 2) := by
      rw [← Real.exp_sum]
      congr 1
      have : (∑ i, (s * c i) ^ 2 / 2) = s ^ 2 / 2 * ∑ i, c i ^ 2 := by
        rw [Finset.mul_sum]; apply Finset.sum_congr rfl; intro i _; ring
      rw [this, hvar, mul_one]

/-- Hoeffding: `P[X ≥ s] ≤ exp(-s²/2)` for a normalized Rademacher sum and `s ≥ 0`. -/
theorem hoeffding_upper_tail {n : ℕ} (c : Fin n → ℝ) (hvar : ∑ i, c i ^ 2 = 1)
    {s : ℝ} (hs : 0 ≤ s) :
    cubeProbability (fun ω => s ≤ rademacherSum c ω) ≤ Real.exp (-(s ^ 2) / 2) := by
  classical
  rw [cubeProbability_eq_expectation]
  have hpt : ∀ ω : BoolCube n, (if s ≤ rademacherSum c ω then (1 : ℝ) else 0) ≤
      Real.exp (-(s ^ 2)) * Real.exp (s * rademacherSum c ω) := by
    intro ω
    rw [← Real.exp_add]
    split_ifs with h
    · apply Real.one_le_exp
      nlinarith
    · exact (Real.exp_pos _).le
  calc
    _ ≤ cubeExpectation (fun ω => Real.exp (-(s ^ 2)) * Real.exp (s * rademacherSum c ω)) :=
      cubeExpectation_mono hpt
    _ = Real.exp (-(s ^ 2)) * cubeExpectation (fun ω => Real.exp (s * rademacherSum c ω)) :=
      cubeExpectation_const_mul _ _
    _ ≤ Real.exp (-(s ^ 2)) * Real.exp (s ^ 2 / 2) :=
      mul_le_mul_of_nonneg_left (rademacher_exp_expectation_le c hvar s) (Real.exp_pos _).le
    _ = Real.exp (-(s ^ 2) / 2) := by rw [← Real.exp_add]; congr 1; ring

/-- Hoeffding for the open concentration event: `P[|X| < s] ≥ 1 - 2 exp(-s²/2)`, `s ≥ 0`. -/
theorem hoeffding_open {n : ℕ} (c : Fin n → ℝ) (hvar : ∑ i, c i ^ 2 = 1)
    {s : ℝ} (hs : 0 ≤ s) :
    1 - 2 * Real.exp (-(s ^ 2) / 2) ≤ rademacherOpenConcentration c s := by
  have hup := hoeffding_upper_tail c hvar hs
  have hlow : cubeProbability (fun ω => rademacherSum c ω ≤ -s) ≤ Real.exp (-(s ^ 2) / 2) := by
    rw [rademacher_prob_neg_symm c (fun y => y ≤ -s)]
    have : cubeProbability (fun ω => -rademacherSum c ω ≤ -s) =
        cubeProbability (fun ω => s ≤ rademacherSum c ω) := by
      apply cubeProbability_congr; intro ω; constructor <;> intro h <;> linarith
    rw [this]; exact hup
  have hcompl : rademacherOpenConcentration c s =
      1 - cubeProbability (fun ω => s ≤ rademacherSum c ω ∨ rademacherSum c ω ≤ -s) := by
    unfold rademacherOpenConcentration
    rw [← cubeProbability_compl]
    apply cubeProbability_congr
    intro ω
    rw [abs_lt]
    constructor
    · rintro ⟨h1, h2⟩ (h | h) <;> linarith
    · intro h
      push_neg at h
      exact ⟨by linarith [h.2], h.1⟩
  have hunion : cubeProbability (fun ω => s ≤ rademacherSum c ω ∨ rademacherSum c ω ≤ -s) ≤
      cubeProbability (fun ω => s ≤ rademacherSum c ω) +
        cubeProbability (fun ω => rademacherSum c ω ≤ -s) := by
    have h := cubeProbability_add_eq_or_add_and
      (fun ω => s ≤ rademacherSum c ω) (fun ω => rademacherSum c ω ≤ -s)
    have h0 := cubeProbability_nonneg (fun ω => s ≤ rademacherSum c ω ∧ rademacherSum c ω ≤ -s)
    linarith
  linarith

/-- Hoeffding beyond the point where `exp(-x²/2) ≤ c a` gives (L) at `x`. -/
theorem lowerHalf_at_of_hoeffding {n : ℕ} (c : Fin n → ℝ) (hvar : ∑ i, c i ^ 2 = 1)
    {a x : ℝ} (hx : 0 ≤ x) (hxa : Real.exp (-(x ^ 2) / 2) ≤ KellerKlein.c a) :
    H x - H a ≤ rademacherOpenConcentration c x := by
  have h := hoeffding_open c hvar hx
  have hc := c_le_half x
  unfold H
  linarith

lemma rademacherSum_div {n : ℕ} (d : Fin n → ℝ) (σ : ℝ) (ω : BoolCube n) :
    rademacherSum (fun j => d j / σ) ω = rademacherSum d ω / σ := by
  unfold rademacherSum
  rw [Finset.sum_div]
  apply Finset.sum_congr rfl
  intro i _
  ring

lemma rademacherConcentration_scale {n : ℕ} (d : Fin n → ℝ) {σ : ℝ} (hσ : 0 < σ) (t : ℝ) :
    rademacherConcentration d t = rademacherConcentration (fun j => d j / σ) (t / σ) := by
  unfold rademacherConcentration
  apply cubeProbability_congr
  intro ω
  rw [rademacherSum_div, abs_div, abs_of_pos hσ, div_le_div_iff_of_pos_right hσ]

lemma rademacherOpenConcentration_scale {n : ℕ} (d : Fin n → ℝ) {σ : ℝ} (hσ : 0 < σ)
    (t : ℝ) :
    rademacherOpenConcentration d t =
      rademacherOpenConcentration (fun j => d j / σ) (t / σ) := by
  unfold rademacherOpenConcentration
  apply cubeProbability_congr
  intro ω
  rw [rademacherSum_div, abs_div, abs_of_pos hσ, div_lt_div_iff_of_pos_right hσ]

end

end KellerKlein
