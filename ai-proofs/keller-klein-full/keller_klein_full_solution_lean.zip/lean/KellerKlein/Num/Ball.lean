import Mathlib

/-!
# Fixed-point ball arithmetic

A `Ball` `⟨p, n, r⟩` (natural numbers) stands for the real interval of all `x` with
`|x · 2^64 - (p - n)| ≤ r`.  All operations are written with explicit `Nat` primitives so
that they can be evaluated efficiently by the Lean kernel (`decide +kernel`), and every
operation comes with a soundness lemma: if the inputs contain `x, y`, the output contains
the corresponding real result.
-/

namespace KellerKlein.Num

@[simp] lemma natDiv_eq (x y : ℕ) : Nat.div x y = x / y := rfl
@[simp] lemma natShiftRight_eq (x y : ℕ) : Nat.shiftRight x y = x >>> y := rfl
@[simp] lemma natShiftLeft_eq (x y : ℕ) : Nat.shiftLeft x y = x <<< y := rfl

/-- Scale of the fixed-point representation. -/
def S : ℕ := 18446744073709551616

lemma S_eq : S = 2 ^ 64 := by norm_num [S]

lemma S_pos : (0 : ℝ) < S := by norm_num [S]

structure Ball where
  p : ℕ
  n : ℕ
  r : ℕ
deriving Repr, DecidableEq

/-- The centre of a ball, in scaled units. -/
def Ball.c (b : Ball) : ℝ := (b.p : ℝ) - b.n

/-- Membership: `|x · S - (p - n)| ≤ r`. -/
def Ball.Mem (b : Ball) (x : ℝ) : Prop := |x * S - b.c| ≤ b.r

instance : Membership ℝ Ball := ⟨Ball.Mem⟩

lemma Ball.mem_def {b : Ball} {x : ℝ} : x ∈ b ↔ |x * S - ((b.p : ℝ) - b.n)| ≤ b.r := Iff.rfl

lemma Ball.mem_iff {b : Ball} {x : ℝ} :
    x ∈ b ↔ (b.p : ℝ) - b.n - b.r ≤ x * S ∧ x * S ≤ (b.p : ℝ) - b.n + b.r := by
  rw [Ball.mem_def, abs_le]
  constructor <;> rintro ⟨h1, h2⟩ <;> constructor <;> linarith

lemma cast_tsub_sub_tsub (a b : ℕ) : ((a - b : ℕ) : ℝ) - ((b - a : ℕ) : ℝ) = (a : ℝ) - b := by
  rcases le_total a b with h | h
  · rw [Nat.sub_eq_zero_of_le h, Nat.cast_sub h]; push_cast; ring
  · rw [Nat.sub_eq_zero_of_le h, Nat.cast_sub h]; push_cast; ring

lemma natdiv_le (m d : ℕ) : ((m / d : ℕ) : ℝ) * d ≤ m := by
  have := Nat.div_mul_le_self m d
  exact_mod_cast this

lemma lt_natdiv_add_one (m d : ℕ) (hd : 0 < d) : (m : ℝ) < (((m / d : ℕ) : ℝ) + 1) * d := by
  have h1 := Nat.div_add_mod m d
  have h2 := Nat.mod_lt m hd
  have : m < (m / d + 1) * d := by nlinarith
  exact_mod_cast this

lemma natdiv_bounds (m d : ℕ) (hd : 0 < d) :
    ((m / d : ℕ) : ℝ) ≤ (m : ℝ) / d ∧ (m : ℝ) / d < ((m / d : ℕ) : ℝ) + 1 := by
  have hd' : (0 : ℝ) < d := by exact_mod_cast hd
  constructor
  · rw [le_div_iff₀ hd']; exact natdiv_le m d
  · rw [div_lt_iff₀ hd']; exact lt_natdiv_add_one m d hd

/-! ### Basic operations -/

namespace Ball

@[inline] def norm (p n r : ℕ) : Ball := ⟨Nat.sub p n, Nat.sub n p, r⟩

lemma norm_c (p n r : ℕ) : (norm p n r).c = (p : ℝ) - n := by
  simp only [norm, Ball.c]
  exact cast_tsub_sub_tsub p n

lemma mem_norm {p n r : ℕ} {x : ℝ} : x ∈ norm p n r ↔ |x * S - ((p : ℝ) - n)| ≤ r := by
  change |x * S - (norm p n r).c| ≤ (norm p n r).r ↔ _
  rw [norm_c]; rfl

@[inline] def add (a b : Ball) : Ball := norm (Nat.add a.p b.p) (Nat.add a.n b.n) (Nat.add a.r b.r)

lemma mem_add {a b : Ball} {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : x + y ∈ add a b := by
  rw [add, mem_norm]
  rw [mem_def] at hx hy
  simp only [Nat.add_eq]
  push_cast
  have := abs_add_le (x * S - ((a.p : ℝ) - a.n)) (y * S - ((b.p : ℝ) - b.n))
  calc |(x + y) * S - ((a.p : ℝ) + b.p - (a.n + b.n))|
      = |(x * S - ((a.p : ℝ) - a.n)) + (y * S - ((b.p : ℝ) - b.n))| := by ring_nf
    _ ≤ _ := this
    _ ≤ _ := add_le_add hx hy

@[inline] def neg (a : Ball) : Ball := ⟨a.n, a.p, a.r⟩

lemma mem_neg {a : Ball} {x : ℝ} (hx : x ∈ a) : -x ∈ neg a := by
  rw [mem_def] at hx ⊢
  simp only [neg]
  rw [show -x * S - ((a.n : ℝ) - a.p) = -(x * S - ((a.p : ℝ) - a.n)) by ring, abs_neg]
  exact hx

@[inline] def sub (a b : Ball) : Ball := add a (neg b)

lemma mem_sub {a b : Ball} {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : x - y ∈ sub a b := by
  rw [sub_eq_add_neg]; exact mem_add hx (mem_neg hy)

/-- Widen the radius by `e` units. -/
@[inline] def widen (a : Ball) (e : ℕ) : Ball := ⟨a.p, a.n, Nat.add a.r e⟩

lemma mem_widen {a : Ball} {x : ℝ} (hx : x ∈ a) (e : ℕ) : x ∈ widen a e := by
  rw [mem_def] at hx ⊢
  simp only [widen, Nat.add_eq]; push_cast
  have : (0 : ℝ) ≤ e := Nat.cast_nonneg e
  linarith

/-- Exact multiplication by a natural number. -/
@[inline] def mulNat (a : Ball) (k : ℕ) : Ball := ⟨Nat.mul a.p k, Nat.mul a.n k, Nat.mul a.r k⟩

lemma mem_mulNat {a : Ball} {x : ℝ} (hx : x ∈ a) (k : ℕ) : x * k ∈ mulNat a k := by
  rw [mem_def] at hx ⊢
  simp only [mulNat, Nat.mul_eq]; push_cast
  have hk : (0 : ℝ) ≤ k := Nat.cast_nonneg k
  rw [show x * k * S - ((a.p : ℝ) * k - a.n * k) = (x * S - ((a.p : ℝ) - a.n)) * k by ring,
    abs_mul, abs_of_nonneg hk]
  exact mul_le_mul_of_nonneg_right hx hk

/-- Division by a positive natural number (rounded outward). -/
@[inline] def divNat (a : Ball) (k : ℕ) : Ball :=
  ⟨Nat.div a.p k, Nat.div a.n k, Nat.add (Nat.div a.r k) 2⟩

lemma mem_divNat {a : Ball} {x : ℝ} (hx : x ∈ a) {k : ℕ} (hk : 0 < k) : x / k ∈ divNat a k := by
  rw [mem_def] at hx ⊢
  simp only [divNat, Nat.add_eq, natDiv_eq]
  have hk' : (0 : ℝ) < k := by exact_mod_cast hk
  obtain ⟨hp1, hp2⟩ := natdiv_bounds a.p k hk
  obtain ⟨hn1, hn2⟩ := natdiv_bounds a.n k hk
  obtain ⟨hr1, hr2⟩ := natdiv_bounds a.r k hk
  have hmain : |x / k * S - ((a.p : ℝ) / k - a.n / k)| ≤ (a.r : ℝ) / k := by
    rw [show x / k * S - ((a.p : ℝ) / k - a.n / k) = (x * S - ((a.p : ℝ) - a.n)) / k by
      field_simp, abs_div, abs_of_pos hk']
    exact div_le_div_of_nonneg_right hx hk'.le
  push_cast
  rw [abs_le] at hmain ⊢
  constructor <;> linarith [hmain.1, hmain.2]

/-- Multiplication. -/
@[inline] def mul (a b : Ball) : Ball :=
  let P := Nat.shiftRight (Nat.add (Nat.mul a.p b.p) (Nat.mul a.n b.n)) 64
  let Q := Nat.shiftRight (Nat.add (Nat.mul a.p b.n) (Nat.mul a.n b.p)) 64
  let R := Nat.shiftRight (Nat.add (Nat.mul (Nat.add (Nat.add a.p a.n) a.r) b.r)
    (Nat.mul (Nat.add b.p b.n) a.r)) 64
  norm P Q (Nat.add R 2)

lemma shiftRight64_bounds (m : ℕ) :
    ((Nat.shiftRight m 64 : ℕ) : ℝ) ≤ (m : ℝ) / S ∧ (m : ℝ) / S < ((Nat.shiftRight m 64 : ℕ) : ℝ) + 1 := by
  have h : Nat.shiftRight m 64 = m / S := by
    rw [natShiftRight_eq, Nat.shiftRight_eq_div_pow, S_eq]
  rw [h]
  have := natdiv_bounds m S (by norm_num [S])
  exact this

lemma mem_mul {a b : Ball} {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : x * y ∈ mul a b := by
  rw [mem_def] at hx hy
  simp only [mul]
  rw [mem_norm]
  set X := x * S
  set Y := y * S
  have hS := S_pos
  obtain ⟨hP1, hP2⟩ := shiftRight64_bounds (Nat.add (Nat.mul a.p b.p) (Nat.mul a.n b.n))
  obtain ⟨hQ1, hQ2⟩ := shiftRight64_bounds (Nat.add (Nat.mul a.p b.n) (Nat.mul a.n b.p))
  obtain ⟨hR1, hR2⟩ := shiftRight64_bounds (Nat.add (Nat.mul (Nat.add (Nat.add a.p a.n) a.r) b.r)
    (Nat.mul (Nat.add b.p b.n) a.r))
  simp only [Nat.add_eq, Nat.mul_eq] at hP1 hP2 hQ1 hQ2 hR1 hR2 ⊢
  push_cast at hP1 hP2 hQ1 hQ2 hR1 hR2 ⊢
  have hc1 : |(a.p : ℝ) - a.n| ≤ (a.p : ℝ) + a.n := by
    have h1 : (0:ℝ) ≤ a.p := Nat.cast_nonneg _
    have h2 : (0:ℝ) ≤ a.n := Nat.cast_nonneg _
    rw [abs_le]; constructor <;> linarith
  have hc2 : |(b.p : ℝ) - b.n| ≤ (b.p : ℝ) + b.n := by
    have h1 : (0:ℝ) ≤ b.p := Nat.cast_nonneg _
    have h2 : (0:ℝ) ≤ b.n := Nat.cast_nonneg _
    rw [abs_le]; constructor <;> linarith
  set c1 : ℝ := (a.p : ℝ) - a.n
  set c2 : ℝ := (b.p : ℝ) - b.n
  have hr1 : (0 : ℝ) ≤ a.r := Nat.cast_nonneg _
  have hr2 : (0 : ℝ) ≤ b.r := Nat.cast_nonneg _
  -- |XY - c1 c2| ≤ (|c1| + r1) r2 + |c2| r1
  have hprod : |X * Y - c1 * c2| ≤ ((a.p : ℝ) + a.n + a.r) * b.r + ((b.p : ℝ) + b.n) * a.r := by
    have e : X * Y - c1 * c2 = (X - c1) * (Y - c2) + c1 * (Y - c2) + c2 * (X - c1) := by ring
    rw [e]
    have h1 : |(X - c1) * (Y - c2)| ≤ a.r * b.r := by
      rw [abs_mul]; exact mul_le_mul hx hy (abs_nonneg _) hr1
    have h2 : |c1 * (Y - c2)| ≤ ((a.p : ℝ) + a.n) * b.r := by
      rw [abs_mul]; exact mul_le_mul hc1 hy (abs_nonneg _) (by positivity)
    have h3 : |c2 * (X - c1)| ≤ ((b.p : ℝ) + b.n) * a.r := by
      rw [abs_mul]; exact mul_le_mul hc2 hx (abs_nonneg _) (by positivity)
    calc |(X - c1) * (Y - c2) + c1 * (Y - c2) + c2 * (X - c1)|
        ≤ |(X - c1) * (Y - c2)| + |c1 * (Y - c2)| + |c2 * (X - c1)| := abs_add_three _ _ _
      _ ≤ a.r * b.r + ((a.p : ℝ) + a.n) * b.r + ((b.p : ℝ) + b.n) * a.r := by linarith
      _ = _ := by ring
  have hxy : x * y * S = X * Y / S := by
    simp only [X, Y]; field_simp; ring
  rw [hxy]
  have hc12 : c1 * c2 = ((a.p : ℝ) * b.p + a.n * b.n) - ((a.p : ℝ) * b.n + a.n * b.p) := by
    simp only [c1, c2]; ring
  have hprod' : |X * Y / S - c1 * c2 / S| ≤
      (((a.p : ℝ) + a.n + a.r) * b.r + ((b.p : ℝ) + b.n) * a.r) / S := by
    rw [← sub_div, abs_div, abs_of_pos hS]
    exact div_le_div_of_nonneg_right hprod hS.le
  rw [hc12] at hprod'
  rw [abs_le] at hprod' ⊢
  rw [sub_div] at hprod'
  constructor <;> nlinarith [hprod'.1, hprod'.2]

/-- Exact multiplication by `2^k`. -/
@[inline] def shl (a : Ball) (k : ℕ) : Ball :=
  ⟨Nat.shiftLeft a.p k, Nat.shiftLeft a.n k, Nat.shiftLeft a.r k⟩

lemma mem_shl {a : Ball} {x : ℝ} (hx : x ∈ a) (k : ℕ) : x * 2 ^ k ∈ shl a k := by
  have h := mem_mulNat hx (2 ^ k)
  simp only [mulNat, Nat.mul_eq] at h
  simp only [shl, natShiftLeft_eq, Nat.shiftLeft_eq]
  push_cast at h
  exact h

/-- Division by `2^k` (rounded outward). -/
@[inline] def shr (a : Ball) (k : ℕ) : Ball :=
  ⟨Nat.shiftRight a.p k, Nat.shiftRight a.n k, Nat.add (Nat.shiftRight a.r k) 2⟩

lemma mem_shr {a : Ball} {x : ℝ} (hx : x ∈ a) (k : ℕ) : x / 2 ^ k ∈ shr a k := by
  have h := mem_divNat hx (k := 2 ^ k) (by positivity)
  simp only [divNat, natDiv_eq] at h
  simp only [shr, natShiftRight_eq, Nat.shiftRight_eq_div_pow, Nat.add_eq]
  push_cast at h
  exact h

/-! ### Constants -/

/-- The exact dyadic number `(p - n) / S`. -/
@[inline] def exact (p n : ℕ) : Ball := ⟨p, n, 0⟩

lemma mem_exact (p n : ℕ) : (((p : ℝ) - n) / S) ∈ exact p n := by
  rw [mem_def]; simp only [exact]
  rw [div_mul_cancel₀ _ S_pos.ne']; simp

/-- The natural number `k`. -/
@[inline] def ofNat (k : ℕ) : Ball := ⟨Nat.mul k S, 0, 0⟩

lemma mem_ofNat (k : ℕ) : (k : ℝ) ∈ ofNat k := by
  rw [mem_def]; simp [ofNat]

/-- A ball containing the rational number `num / den` (`den > 0`). -/
@[inline] def ofRat (num den : ℕ) : Ball := ⟨Nat.div (Nat.mul num S) den, 0, 1⟩

lemma mem_ofRat (num : ℕ) {den : ℕ} (hden : 0 < den) : ((num : ℝ) / den) ∈ ofRat num den := by
  rw [mem_def]; simp only [ofRat, Nat.mul_eq, natDiv_eq, Nat.cast_zero, sub_zero, Nat.cast_one]
  obtain ⟨h1, h2⟩ := natdiv_bounds (num * S) den hden
  push_cast at h1 h2
  have : (num : ℝ) / den * S = (num : ℝ) * S / den := by ring
  rw [this, abs_le]
  constructor <;> linarith

/-! ### Endpoints, comparisons -/

/-- Signed pairs `(u, v)` stand for `u - v` (in scaled units). -/
abbrev SP := ℕ × ℕ

def SP.val (q : SP) : ℝ := (q.1 : ℝ) - q.2

@[inline] def SP.le (x y : SP) : Bool := Nat.ble (Nat.add x.1 y.2) (Nat.add y.1 x.2)

lemma SP.le_val {x y : SP} (h : SP.le x y = true) : x.val ≤ y.val := by
  simp only [SP.le, Nat.ble_eq, Nat.add_eq] at h
  have : ((x.1 + y.2 : ℕ) : ℝ) ≤ ((y.1 + x.2 : ℕ) : ℝ) := by exact_mod_cast h
  push_cast at this
  simp only [SP.val]; linarith

lemma SP.lt_val {x y : SP} (h : SP.le x y = false) : y.val < x.val := by
  simp only [SP.le, Nat.add_eq] at h
  have h' : y.1 + x.2 < x.1 + y.2 := by
    rw [← Bool.not_eq_true, Nat.ble_eq] at h
    omega
  have : ((y.1 + x.2 : ℕ) : ℝ) < ((x.1 + y.2 : ℕ) : ℝ) := by exact_mod_cast h'
  push_cast at this
  simp only [SP.val]; linarith

@[inline] def SP.max (x y : SP) : SP := bif SP.le x y then y else x
@[inline] def SP.min (x y : SP) : SP := bif SP.le x y then x else y

lemma SP.max_val (x y : SP) : (SP.max x y).val = Max.max x.val y.val := by
  unfold SP.max
  cases h : SP.le x y
  · simp only [cond_false]; exact (max_eq_left (SP.lt_val h).le).symm
  · simp only [cond_true]; exact (max_eq_right (SP.le_val h)).symm

lemma SP.min_val (x y : SP) : (SP.min x y).val = Min.min x.val y.val := by
  unfold SP.min
  cases h : SP.le x y
  · simp only [cond_false]; exact (min_eq_right (SP.lt_val h).le).symm
  · simp only [cond_true]; exact (min_eq_left (SP.le_val h)).symm

@[inline] def SP.neg (x : SP) : SP := (x.2, x.1)

lemma SP.neg_val (x : SP) : (SP.neg x).val = -x.val := by simp [SP.neg, SP.val]

def SP.zero : SP := (0, 0)

lemma SP.zero_val : SP.zero.val = 0 := by simp [SP.zero, SP.val]

/-- Lower endpoint. -/
@[inline] def lo (a : Ball) : SP := (a.p, Nat.add a.n a.r)
/-- Upper endpoint. -/
@[inline] def hi (a : Ball) : SP := (Nat.add a.p a.r, a.n)

lemma lo_val (a : Ball) : a.lo.val = (a.p : ℝ) - a.n - a.r := by
  simp only [lo, SP.val, Nat.add_eq]; push_cast; ring

lemma hi_val (a : Ball) : a.hi.val = (a.p : ℝ) - a.n + a.r := by
  simp only [hi, SP.val, Nat.add_eq]; push_cast; ring

lemma mem_iff_lohi {a : Ball} {x : ℝ} : x ∈ a ↔ a.lo.val ≤ x * S ∧ x * S ≤ a.hi.val := by
  rw [mem_iff, lo_val, hi_val]

/-- The ball with given (scaled) endpoints. -/
@[inline] def ofLoHi (l h : SP) : Ball :=
  let w := Nat.sub (Nat.add h.1 l.2) (Nat.add l.1 h.2)
  norm (Nat.shiftRight (Nat.add l.1 h.1) 1) (Nat.shiftRight (Nat.add l.2 h.2) 1)
    (Nat.add (Nat.shiftRight w 1) 2)

lemma shiftRight1_bounds (m : ℕ) :
    ((Nat.shiftRight m 1 : ℕ) : ℝ) ≤ (m : ℝ) / 2 ∧ (m : ℝ) / 2 < ((Nat.shiftRight m 1 : ℕ) : ℝ) + 1 := by
  have h : Nat.shiftRight m 1 = m / 2 := by rw [natShiftRight_eq, Nat.shiftRight_eq_div_pow, pow_one]
  rw [h]
  have := natdiv_bounds m 2 (by norm_num)
  push_cast at this
  exact this

lemma mem_ofLoHi {l h : SP} {x : ℝ} (hl : l.val ≤ x * S) (hh : x * S ≤ h.val) :
    x ∈ ofLoHi l h := by
  simp only [ofLoHi]
  rw [mem_norm]
  set w := Nat.sub (Nat.add h.1 l.2) (Nat.add l.1 h.2) with hw_def
  obtain ⟨a1, a2⟩ := shiftRight1_bounds (Nat.add l.1 h.1)
  obtain ⟨b1, b2⟩ := shiftRight1_bounds (Nat.add l.2 h.2)
  obtain ⟨w1, w2⟩ := shiftRight1_bounds w
  have hw : ((h.1 : ℝ) + l.2) - (l.1 + h.2) ≤ (w : ℝ) := by
    have h1 : h.1 + l.2 ≤ w + (l.1 + h.2) := by simp only [hw_def, Nat.sub_eq, Nat.add_eq]; omega
    have h2 : ((h.1 + l.2 : ℕ) : ℝ) ≤ ((w + (l.1 + h.2) : ℕ) : ℝ) := by exact_mod_cast h1
    push_cast at h2; linarith
  simp only [SP.val] at hl hh
  simp only [Nat.add_eq] at a1 a2 b1 b2 ⊢
  push_cast at a1 a2 b1 b2 ⊢
  rw [abs_le]
  constructor <;> linarith

/-- `x ≤ y` for all `x ∈ a`, `y ∈ b`. -/
@[inline] def leB (a b : Ball) : Bool := Nat.ble (Nat.add (Nat.add (Nat.add a.p a.r) b.n) b.r) (Nat.add b.p a.n)

lemma le_of_leB {a b : Ball} (h : leB a b = true) {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : x ≤ y := by
  simp only [leB, Nat.ble_eq, Nat.add_eq] at h
  rw [mem_iff] at hx hy
  have h' : ((a.p + a.r + b.n + b.r : ℕ) : ℝ) ≤ ((b.p + a.n : ℕ) : ℝ) := by exact_mod_cast h
  push_cast at h'
  have hS := S_pos
  have : x * S ≤ y * S := by linarith [hx.2, hy.1]
  exact le_of_mul_le_mul_right this hS

/-- `x < y` for all `x ∈ a`, `y ∈ b`. -/
@[inline] def ltB (a b : Ball) : Bool := Nat.blt (Nat.add (Nat.add (Nat.add a.p a.r) b.n) b.r) (Nat.add b.p a.n)

lemma lt_of_ltB {a b : Ball} (h : ltB a b = true) {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : x < y := by
  simp only [ltB, Nat.blt_eq, Nat.add_eq] at h
  rw [mem_iff] at hx hy
  have h' : ((a.p + a.r + b.n + b.r : ℕ) : ℝ) < ((b.p + a.n : ℕ) : ℝ) := by exact_mod_cast h
  push_cast at h'
  have hS := S_pos
  have : x * S < y * S := by linarith [hx.2, hy.1]
  exact lt_of_mul_lt_mul_right this hS.le

/-- All elements are positive. -/
@[inline] def posB (a : Ball) : Bool := Nat.blt (Nat.add a.n a.r) a.p

lemma pos_of_posB {a : Ball} (h : posB a = true) {x : ℝ} (hx : x ∈ a) : 0 < x := by
  simp only [posB, Nat.blt_eq, Nat.add_eq] at h
  rw [mem_iff] at hx
  have h' : ((a.n + a.r : ℕ) : ℝ) < (a.p : ℝ) := by exact_mod_cast h
  push_cast at h'
  have : 0 < x * S := by linarith [hx.1]
  by_contra hneg
  push_neg at hneg
  nlinarith [S_pos]

/-- All elements are nonnegative. -/
@[inline] def nonnegB (a : Ball) : Bool := Nat.ble (Nat.add a.n a.r) a.p

lemma nonneg_of_nonnegB {a : Ball} (h : nonnegB a = true) {x : ℝ} (hx : x ∈ a) : 0 ≤ x := by
  simp only [nonnegB, Nat.ble_eq, Nat.add_eq] at h
  rw [mem_iff] at hx
  have h' : ((a.n + a.r : ℕ) : ℝ) ≤ (a.p : ℝ) := by exact_mod_cast h
  push_cast at h'
  have : 0 ≤ x * S := by linarith [hx.1]
  exact nonneg_of_mul_nonneg_left this S_pos

/-! ### Max, min, abs, positive part, intersection -/

@[inline] def max (a b : Ball) : Ball := ofLoHi (SP.max a.lo b.lo) (SP.max a.hi b.hi)

lemma mem_max {a b : Ball} {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : Max.max x y ∈ max a b := by
  rw [mem_iff_lohi] at hx hy
  apply mem_ofLoHi
  · rw [SP.max_val]
    rcases le_total x y with h | h
    · rw [max_eq_right h]
      have : x * S ≤ y * S := mul_le_mul_of_nonneg_right h S_pos.le
      exact max_le (by linarith) hy.1
    · rw [max_eq_left h]
      have : y * S ≤ x * S := mul_le_mul_of_nonneg_right h S_pos.le
      exact max_le hx.1 (by linarith)
  · rw [SP.max_val]
    rcases le_total x y with h | h
    · rw [max_eq_right h]; exact le_max_of_le_right hy.2
    · rw [max_eq_left h]; exact le_max_of_le_left hx.2

@[inline] def min (a b : Ball) : Ball := ofLoHi (SP.min a.lo b.lo) (SP.min a.hi b.hi)

lemma mem_min {a b : Ball} {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : Min.min x y ∈ min a b := by
  rw [mem_iff_lohi] at hx hy
  apply mem_ofLoHi
  · rw [SP.min_val]
    rcases le_total x y with h | h
    · rw [min_eq_left h]; exact min_le_of_left_le hx.1
    · rw [min_eq_right h]; exact min_le_of_right_le hy.1
  · rw [SP.min_val]
    rcases le_total x y with h | h
    · rw [min_eq_left h]
      have : x * S ≤ y * S := mul_le_mul_of_nonneg_right h S_pos.le
      exact le_min hx.2 (by linarith)
    · rw [min_eq_right h]
      have : y * S ≤ x * S := mul_le_mul_of_nonneg_right h S_pos.le
      exact le_min (by linarith) hy.2

/-- Positive part `max 0 x`. -/
@[inline] def pos (a : Ball) : Ball := ofLoHi (SP.max SP.zero a.lo) (SP.max SP.zero a.hi)

lemma mem_pos {a : Ball} {x : ℝ} (hx : x ∈ a) : Max.max 0 x ∈ pos a := by
  rw [mem_iff_lohi] at hx
  apply mem_ofLoHi
  · rw [SP.max_val, SP.zero_val]
    rcases le_total 0 x with h | h
    · rw [max_eq_right h]
      exact max_le (mul_nonneg h S_pos.le) hx.1
    · rw [max_eq_left h, zero_mul]
      exact max_le le_rfl (by nlinarith [S_pos])
  · rw [SP.max_val, SP.zero_val]
    rcases le_total 0 x with h | h
    · rw [max_eq_right h]; exact le_max_of_le_right hx.2
    · rw [max_eq_left h, zero_mul]; exact le_max_left _ _

/-- Negative part `max 0 (-x)`. -/
@[inline] def negPart (a : Ball) : Ball := pos (neg a)

lemma mem_negPart {a : Ball} {x : ℝ} (hx : x ∈ a) : Max.max 0 (-x) ∈ negPart a :=
  mem_pos (mem_neg hx)

/-- Absolute value. -/
@[inline] def abs (a : Ball) : Ball :=
  ofLoHi (SP.max SP.zero (SP.max a.lo (SP.neg a.hi))) (SP.max a.hi (SP.neg a.lo))

lemma mem_abs {a : Ball} {x : ℝ} (hx : x ∈ a) : |x| ∈ abs a := by
  rw [mem_iff_lohi] at hx
  apply mem_ofLoHi
  · rw [SP.max_val, SP.max_val, SP.neg_val, SP.zero_val]
    have hS := S_pos
    have h0 : 0 ≤ |x| * S := mul_nonneg (abs_nonneg x) hS.le
    have h1 : x * S ≤ |x| * S := mul_le_mul_of_nonneg_right (le_abs_self x) hS.le
    have h2 : -x * S ≤ |x| * S := mul_le_mul_of_nonneg_right (neg_le_abs x) hS.le
    refine max_le h0 (max_le (by linarith [hx.1]) ?_)
    linarith [hx.2]
  · rw [SP.max_val, SP.neg_val]
    rcases le_total 0 x with h | h
    · rw [abs_of_nonneg h]; exact le_max_of_le_left hx.2
    · rw [abs_of_nonpos h]
      apply le_max_of_le_right
      linarith [hx.1]

/-- Intersection of two enclosures of the same number. -/
@[inline] def inter (a b : Ball) : Ball := ofLoHi (SP.max a.lo b.lo) (SP.min a.hi b.hi)

lemma mem_inter {a b : Ball} {x : ℝ} (hx : x ∈ a) (hy : x ∈ b) : x ∈ inter a b := by
  rw [mem_iff_lohi] at hx hy
  apply mem_ofLoHi
  · rw [SP.max_val]; exact max_le hx.1 hy.1
  · rw [SP.min_val]; exact le_min hx.2 hy.2

/-- Convex hull of two balls. -/
@[inline] def hull (a b : Ball) : Ball := ofLoHi (SP.min a.lo b.lo) (SP.max a.hi b.hi)

lemma mem_hull_left {a b : Ball} {x : ℝ} (hx : x ∈ a) : x ∈ hull a b := by
  rw [mem_iff_lohi] at hx
  apply mem_ofLoHi
  · rw [SP.min_val]; exact min_le_of_left_le hx.1
  · rw [SP.max_val]; exact le_max_of_le_left hx.2

lemma mem_hull_right {a b : Ball} {x : ℝ} (hx : x ∈ b) : x ∈ hull a b := by
  rw [mem_iff_lohi] at hx
  apply mem_ofLoHi
  · rw [SP.min_val]; exact min_le_of_right_le hx.1
  · rw [SP.max_val]; exact le_max_of_le_right hx.2

/-- The ball `[l, h]` for exact dyadic endpoints given as signed pairs. -/
lemma mem_ofLoHi_of_le {l h : SP} {x : ℝ} (hl : l.val / S ≤ x) (hh : x ≤ h.val / S) :
    x ∈ ofLoHi l h := by
  apply mem_ofLoHi
  · rwa [div_le_iff₀ S_pos] at hl
  · rwa [le_div_iff₀ S_pos] at hh

lemma mem_of_le_of_le {B : Ball} {x y z : ℝ} (hy : y ∈ B) (hz : z ∈ B) (h1 : y ≤ x) (h2 : x ≤ z) :
    x ∈ B := by
  rw [mem_iff] at hy hz ⊢
  have e1 := mul_le_mul_of_nonneg_right h1 S_pos.le
  have e2 := mul_le_mul_of_nonneg_right h2 S_pos.le
  constructor <;> linarith [hy.1, hz.2]

/-! ### Interval product -/

/-- The exact ball at a signed pair. -/
@[inline] def ofSP (x : SP) : Ball := exact x.1 x.2

lemma mem_ofSP (x : SP) : x.val / S ∈ ofSP x := mem_exact x.1 x.2

/-- Product by corners: the hull of the four products of endpoints.  Unlike `mul`, this loses
nothing (beyond rounding) when both factors are wide or contain `0`. -/
@[inline] def imul (a b : Ball) : Ball :=
  let a0 := ofSP a.lo
  let a1 := ofSP a.hi
  let b0 := ofSP b.lo
  let b1 := ofSP b.hi
  hull (hull (mul a0 b0) (mul a0 b1)) (hull (mul a1 b0) (mul a1 b1))

lemma bilinear_lower {x0 x1 y0 y1 x y : ℝ} (hx0 : x0 ≤ x) (hx1 : x ≤ x1) (hy0 : y0 ≤ y)
    (hy1 : y ≤ y1) :
    (x0 * y0 ≤ x * y ∨ x0 * y1 ≤ x * y) ∨ (x1 * y0 ≤ x * y ∨ x1 * y1 ≤ x * y) := by
  rcases le_total 0 y with hy | hy
  · have h := mul_le_mul_of_nonneg_right hx0 hy
    rcases le_total 0 x0 with h0 | h0
    · exact Or.inl (Or.inl ((mul_le_mul_of_nonneg_left hy0 h0).trans h))
    · exact Or.inl (Or.inr ((mul_le_mul_of_nonpos_left hy1 h0).trans h))
  · have h := mul_le_mul_of_nonpos_right hx1 hy
    rcases le_total 0 x1 with h0 | h0
    · exact Or.inr (Or.inl ((mul_le_mul_of_nonneg_left hy0 h0).trans h))
    · exact Or.inr (Or.inr ((mul_le_mul_of_nonpos_left hy1 h0).trans h))

lemma bilinear_upper {x0 x1 y0 y1 x y : ℝ} (hx0 : x0 ≤ x) (hx1 : x ≤ x1) (hy0 : y0 ≤ y)
    (hy1 : y ≤ y1) :
    (x * y ≤ x0 * y0 ∨ x * y ≤ x0 * y1) ∨ (x * y ≤ x1 * y0 ∨ x * y ≤ x1 * y1) := by
  rcases le_total 0 y with hy | hy
  · have h := mul_le_mul_of_nonneg_right hx1 hy
    rcases le_total 0 x1 with h0 | h0
    · exact Or.inr (Or.inr (h.trans (mul_le_mul_of_nonneg_left hy1 h0)))
    · exact Or.inr (Or.inl (h.trans (mul_le_mul_of_nonpos_left hy0 h0)))
  · have h := mul_le_mul_of_nonpos_right hx0 hy
    rcases le_total 0 x0 with h0 | h0
    · exact Or.inl (Or.inr (h.trans (mul_le_mul_of_nonneg_left hy1 h0)))
    · exact Or.inl (Or.inl (h.trans (mul_le_mul_of_nonpos_left hy0 h0)))

lemma mem_imul {a b : Ball} {x y : ℝ} (hx : x ∈ a) (hy : y ∈ b) : x * y ∈ imul a b := by
  rw [mem_iff_lohi] at hx hy
  have hx0 : a.lo.val / S ≤ x := by rw [div_le_iff₀ S_pos]; exact hx.1
  have hx1 : x ≤ a.hi.val / S := by rw [le_div_iff₀ S_pos]; exact hx.2
  have hy0 : b.lo.val / S ≤ y := by rw [div_le_iff₀ S_pos]; exact hy.1
  have hy1 : y ≤ b.hi.val / S := by rw [le_div_iff₀ S_pos]; exact hy.2
  have m0 := mem_ofSP a.lo
  have m1 := mem_ofSP a.hi
  have n0 := mem_ofSP b.lo
  have n1 := mem_ofSP b.hi
  have c00 : a.lo.val / S * (b.lo.val / S) ∈ imul a b := mem_hull_left (mem_hull_left (mem_mul m0 n0))
  have c01 : a.lo.val / S * (b.hi.val / S) ∈ imul a b := mem_hull_left (mem_hull_right (mem_mul m0 n1))
  have c10 : a.hi.val / S * (b.lo.val / S) ∈ imul a b := mem_hull_right (mem_hull_left (mem_mul m1 n0))
  have c11 : a.hi.val / S * (b.hi.val / S) ∈ imul a b := mem_hull_right (mem_hull_right (mem_mul m1 n1))
  obtain ⟨l, hl, hlx⟩ : ∃ l, l ∈ imul a b ∧ l ≤ x * y := by
    rcases bilinear_lower hx0 hx1 hy0 hy1 with (h | h) | (h | h)
    exacts [⟨_, c00, h⟩, ⟨_, c01, h⟩, ⟨_, c10, h⟩, ⟨_, c11, h⟩]
  obtain ⟨u, hu, hxu⟩ : ∃ u, u ∈ imul a b ∧ x * y ≤ u := by
    rcases bilinear_upper hx0 hx1 hy0 hy1 with (h | h) | (h | h)
    exacts [⟨_, c00, h⟩, ⟨_, c01, h⟩, ⟨_, c10, h⟩, ⟨_, c11, h⟩]
  exact mem_of_le_of_le hl hu hlx hxu

/-! ### Upper bound extraction -/

/-- The upper endpoint, as a real number. -/
noncomputable def hiR (a : Ball) : ℝ := a.hi.val / S

noncomputable def loR (a : Ball) : ℝ := a.lo.val / S

lemma le_hiR {a : Ball} {x : ℝ} (hx : x ∈ a) : x ≤ a.hiR := by
  rw [mem_iff_lohi] at hx
  rw [hiR, le_div_iff₀ S_pos]; exact hx.2

lemma loR_le {a : Ball} {x : ℝ} (hx : x ∈ a) : a.loR ≤ x := by
  rw [mem_iff_lohi] at hx
  rw [loR, div_le_iff₀ S_pos]; exact hx.1

end Ball

end KellerKlein.Num
