import KellerKlein.Num.Cover
import KellerKlein.Full.Master
import KellerKlein.CrossoverBounds
import KellerKlein.GaussianTarget

/-!
# Soundness of the certified cell check

Every enclosure computed in `Num/CellDefs.lean` contains the corresponding real quantity:
first at grid points (`D`, `E`, `cos`, `sin`), then on a cell `u ∈ (p₀/S, p₁/S)` uniformly
over a box of `(a, ξ)`, then for the master integrand `gU` (`cellHi_sound`), its integral
(`sumCells_sound`) and finally for the inequality `J(a, y) ≤ c(a) + c(y)` (`boxOk_sound`).
-/

open Set MeasureTheory

namespace KellerKlein.Num

open Ball

noncomputable section

/-! ### Grid points -/

/-- The real number `p / S`. -/
def pt (p : ℕ) : ℝ := (p : ℝ) / S

lemma pt_nonneg (p : ℕ) : 0 ≤ pt p := div_nonneg (Nat.cast_nonneg p) S_pos.le

lemma mem_pt (p : ℕ) : pt p ∈ exact p 0 := by
  have := mem_exact p 0
  simpa [pt] using this

lemma pt_S : pt S = 1 := div_self S_pos.ne'

lemma pt_halfS : pt halfS = 1 / 2 := by
  unfold pt halfS S; norm_num

lemma pt_le {p q : ℕ} (h : p ≤ q) : pt p ≤ pt q :=
  div_le_div_of_nonneg_right (by exact_mod_cast h) S_pos.le

lemma pt_lt {p q : ℕ} (h : p < q) : pt p < pt q :=
  div_lt_div_of_pos_right (by exact_mod_cast h) S_pos

lemma pt_pos {p : ℕ} (h : 0 < p) : 0 < pt p := div_pos (by exact_mod_cast h) S_pos

lemma pt_sub {p q : ℕ} (h : q ≤ p) : pt (p - q) = pt p - pt q := by
  unfold pt; rw [Nat.cast_sub h, sub_div]

lemma pt_two_mul_le {p : ℕ} (h : 2 * p ≤ S) : pt p ≤ 1 / 2 := by
  have : (2 * p : ℝ) ≤ S := by exact_mod_cast h
  unfold pt; rw [div_le_iff₀ S_pos]; linarith

lemma pt_two_mul_lt {p : ℕ} (h : 2 * p < S) : pt p < 1 / 2 := by
  have : (2 * p : ℝ) < S := by exact_mod_cast h
  unfold pt; rw [div_lt_iff₀ S_pos]; linarith

lemma half_le_pt {p : ℕ} (h : S ≤ 2 * p) : 1 / 2 ≤ pt p := by
  have : (S : ℝ) ≤ 2 * p := by exact_mod_cast h
  unfold pt; rw [le_div_iff₀ S_pos]; linarith

lemma half_lt_pt {p : ℕ} (h : S < 2 * p) : 1 / 2 < pt p := by
  have : (S : ℝ) < 2 * p := by exact_mod_cast h
  unfold pt; rw [lt_div_iff₀ S_pos]; linarith

lemma pt_le_one {p : ℕ} (h : p ≤ S) : pt p ≤ 1 := by
  rw [← pt_S]; exact pt_le h

lemma mem_ivB {p q : ℕ} {u : ℝ} (h0 : pt p ≤ u) (h1 : u ≤ pt q) : u ∈ ivB p q := by
  apply mem_ofLoHi_of_le
  · simpa [SP.val, pt] using h0
  · simpa [SP.val, pt] using h1

lemma one_sub_mem_ivB {p0 p1 : ℕ} (hp1 : p1 ≤ S) {u : ℝ} (h0 : pt p0 ≤ u) (h1 : u ≤ pt p1) :
    1 - u ∈ ivB (S - p1) (S - p0) := by
  have hp0 : p0 ≤ S := by
    by_contra h
    have := pt_lt (lt_of_not_le h)
    have := pt_le hp1
    rw [pt_S] at *
    linarith
  apply mem_ivB
  · rw [pt_sub hp1, pt_S]; linarith
  · rw [pt_sub hp0, pt_S]; linarith

/-! ### Elementary facts about balls -/

lemma lo_mem (B : Ball) : B.lo.val / S ∈ B := by
  rw [mem_iff_lohi, div_mul_cancel₀ _ S_pos.ne', lo_val, hi_val]
  have : (0 : ℝ) ≤ B.r := Nat.cast_nonneg _
  constructor <;> linarith

lemma lo_le_of_mem {B : Ball} {x : ℝ} (hx : x ∈ B) : B.lo.val / S ≤ x := loR_le hx

lemma le_hi_of_mem {B : Ball} {x : ℝ} (hx : x ∈ B) : x ≤ B.hi.val / S := le_hiR hx

lemma mem_nonposB {X : Ball} {x : ℝ} (hx : x ∈ X) (h : x ≤ 0) : x ∈ nonposB X := by
  rw [mem_iff_lohi] at hx
  apply mem_ofLoHi
  · rw [SP.min_val]; exact min_le_of_left_le hx.1
  · rw [SP.min_val, SP.zero_val]
    exact le_min hx.2 (mul_nonpos_of_nonpos_of_nonneg h S_pos.le)

/-- A real number between the endpoints of `[0, h]`. -/
lemma mem_ofLoHi_zero {h : SP} {x : ℝ} (h0 : 0 ≤ x) (hh : x ≤ h.val / S) :
    x ∈ ofLoHi SP.zero h :=
  mem_ofLoHi_of_le (by rw [SP.zero_val, zero_div]; exact h0) hh

lemma mem_zero_iff_le {x : ℝ} (hx : x = 0) : x ∈ zero := by
  rw [hx]; exact mem_zero

/-! ### Special functions at grid points -/

lemma mem_trigPt (p : ℕ) :
    Real.cos (Real.pi * pt p) ∈ (trigPt p 0).1 ∧ Real.sin (Real.pi * pt p) ∈ (trigPt p 0).2 := by
  have := trigPt_mem p 0
  simpa [pt] using this

lemma mem_piPt (p : ℕ) : Real.pi * pt p ∈ mul PI (exact p 0) := mem_mul pi_mem (mem_pt p)

lemma mem_DptB {p : ℕ} (hok : DptOk p = true) : Dfun (Real.pi * pt p) ∈ DptB p := by
  obtain ⟨hc, hs⟩ := mem_trigPt p
  have := mem_sub mem_one (mem_mul (mem_piPt p) (mem_divB hok hc hs))
  unfold Dfun DptB
  exact this

lemma Dfun_le_of_le {y z : ℝ} (hy : 0 < y) (hyz : y ≤ z) (hz : z < Real.pi) :
    Dfun y ≤ Dfun z :=
  Dfun_monotoneOn ⟨hy, by linarith⟩ ⟨by linarith, hz⟩ hyz

/-- `DloB p` is a lower bound for `D` on `[π p/S, π)`. -/
lemma DloB_le {p : ℕ} (hok : DloOk p = true) {y : ℝ} (hy : Real.pi * pt p ≤ y)
    (hy0 : 0 < y) (hyπ : y < Real.pi) : (DloB p).lo.val / S ≤ Dfun y := by
  unfold DloB
  cases hb : Nat.beq p 0
  · simp only [cond_false]
    have hp0 : 0 < p := by
      rcases Nat.eq_zero_or_pos p with h | h
      · rw [h] at hb; simp at hb
      · exact h
    have hok' : DptOk p = true := by
      unfold DloOk at hok; rw [hb] at hok; simpa using hok
    refine (lo_le_of_mem (mem_DptB hok')).trans (Dfun_le_of_le ?_ hy hyπ)
    exact mul_pos Real.pi_pos (pt_pos hp0)
  · simp only [cond_true]
    have : (zero.lo).val / S = 0 := by simp [zero, lo, SP.val]
    rw [this]
    exact Dfun_nonneg hy0 hyπ

lemma mem_EptB {p : ℕ} (hok : EptOk p = true) : Efun (Real.pi * pt p) ∈ EptB p := by
  obtain ⟨hc, _⟩ := mem_trigPt p
  have hl := mem_logB hok hc
  have := mem_sub (mem_neg hl) (mem_shr (mem_mul (mem_piPt p) (mem_piPt p)) 1)
  unfold Efun EptB
  convert this using 1
  ring

lemma Efun_le_of_le {y z : ℝ} (hy : 0 ≤ y) (hyz : y ≤ z) (hz : z < Real.pi / 2) :
    Efun y ≤ Efun z :=
  Efun_monotoneOn ⟨hy, by linarith⟩ ⟨by linarith, hz⟩ hyz

/-! ### Gaussians -/

lemma mem_gaussB {X : Ball} {x : ℝ} (hx : x ∈ X) : gaussian x ∈ gaussB X := by
  have := mem_expB (mem_neg (mem_shr (mem_mul hx hx) 1))
  unfold gaussB gaussian
  convert this using 2
  ring

lemma gaussian_anti {s t : ℝ} (hs : 0 ≤ s) (hst : s ≤ t) : gaussian t ≤ gaussian s := by
  unfold gaussian
  apply Real.exp_le_exp.2
  nlinarith

/-- The data of an `a`-interval: `0 < a₀ ≤ a ≤ a₁`, `1/a₀ ∈ IA0`, `1/a₁ ∈ IA1`. -/
structure AData (IA0 IA1 : Ball) (a0 a1 a : ℝ) : Prop where
  pos : 0 < a0
  le0 : a0 ≤ a
  le1 : a ≤ a1
  mem0 : 1 / a0 ∈ IA0
  mem1 : 1 / a1 ∈ IA1

namespace AData

variable {IA0 IA1 : Ball} {a0 a1 a : ℝ} (h : AData IA0 IA1 a0 a1 a)
include h

lemma apos : 0 < a := lt_of_lt_of_le h.pos h.le0

lemma a1pos : 0 < a1 := lt_of_lt_of_le h.apos h.le1

lemma inv_le0 : 1 / a ≤ 1 / a0 := one_div_le_one_div_of_le h.pos h.le0

lemma inv_le1 : 1 / a1 ≤ 1 / a := one_div_le_one_div_of_le h.apos h.le1

lemma sq_le0 : 1 / a ^ 2 ≤ 1 / a0 * (1 / a0) := by
  have h1 := h.inv_le0
  have h2 : 0 ≤ 1 / a := by have := h.apos; positivity
  rw [show 1 / a ^ 2 = 1 / a * (1 / a) by ring]
  exact mul_le_mul h1 h1 h2 (h2.trans h1)

lemma sq_le1 : 1 / a1 * (1 / a1) ≤ 1 / a ^ 2 := by
  have h1 := h.inv_le1
  have h2 : 0 ≤ 1 / a1 := by have := h.a1pos; positivity
  rw [show 1 / a ^ 2 = 1 / a * (1 / a) by ring]
  exact mul_le_mul h1 h1 h2 (h2.trans h1)

end AData

lemma mem_GB {IA0 IA1 : Ball} {a0 a1 a : ℝ} (hA : AData IA0 IA1 a0 a1 a) {p0 p1 : ℕ} {u : ℝ}
    (hu0 : pt p0 ≤ u) (hu1 : u ≤ pt p1) : gaussian (Real.pi * u / a) ∈ GB IA0 IA1 p0 p1 := by
  have ha := hA.apos
  have hu : 0 ≤ u := (pt_nonneg p0).trans hu0
  have hpi := Real.pi_pos
  apply mem_ofLoHi_of_le
  · have hb := mem_gaussB (mem_mul (mem_piPt p1) hA.mem0)
    refine (lo_le_of_mem hb).trans (gaussian_anti (by positivity) ?_)
    rw [mul_div_assoc, mul_one_div, mul_div_assoc]
    apply mul_le_mul_of_nonneg_left _ hpi.le
    calc u / a ≤ pt p1 / a := div_le_div_of_nonneg_right hu1 ha.le
      _ ≤ pt p1 / a0 := div_le_div_of_nonneg_left (pt_nonneg p1) hA.pos hA.le0
  · have hb := mem_gaussB (mem_mul (mem_piPt p0) hA.mem1)
    refine (gaussian_anti (by have := pt_nonneg p0; have := hA.a1pos; positivity) ?_).trans
      (le_hi_of_mem hb)
    rw [mul_div_assoc, mul_one_div, mul_div_assoc]
    apply mul_le_mul_of_nonneg_left _ hpi.le
    calc pt p0 / a1 ≤ u / a1 := div_le_div_of_nonneg_right hu0 hA.a1pos.le
      _ ≤ u / a := div_le_div_of_nonneg_left hu ha hA.le1

/-! ### The factors `exp (-E/a²)` and `|cos π u| e^{(π u)²/2}` -/

lemma exp_neg_mul_le {s t E F : ℝ} (hs : 0 ≤ s) (hst : s ≤ t) (hE : 0 ≤ E) (hEF : E ≤ F) :
    Real.exp (-(t * F)) ≤ Real.exp (-(s * E)) := by
  apply Real.exp_le_exp.2
  have : s * E ≤ t * F := mul_le_mul hst hEF hE (hs.trans hst)
  linarith

lemma mem_eNB {IA0 IA1 : Ball} {a0 a1 a : ℝ} (hA : AData IA0 IA1 a0 a1 a) {p0 p1 : ℕ}
    (hok : eNOk p0 p1 = true) (hp : 2 * p1 ≤ S) {u : ℝ} (hu0 : pt p0 < u) (hu1 : u < pt p1) :
    Real.exp (-(1 / a ^ 2 * Efun (Real.pi * u))) ∈ eNB IA0 IA1 p0 p1 := by
  have hpi := Real.pi_pos
  have hu : 0 ≤ u := (pt_nonneg p0).trans hu0.le
  have hu2 : Real.pi * u < Real.pi / 2 := by
    have := pt_two_mul_le hp; nlinarith
  have hok' := hok
  unfold eNOk at hok'
  rw [Bool.and_eq_true] at hok'
  have hok0 : EptOk p0 = true := hok'.1
  have hE0 : 0 ≤ Efun (Real.pi * pt p0) := Efun_nonneg (by have := pt_nonneg p0; positivity)
    (by nlinarith)
  have hEu : Efun (Real.pi * pt p0) ≤ Efun (Real.pi * u) :=
    Efun_le_of_le (by have := pt_nonneg p0; positivity) (by nlinarith) hu2
  have ha2 : 0 ≤ 1 / a1 * (1 / a1) := by have := hA.a1pos; positivity
  apply mem_ofLoHi_of_le
  · cases hb : Nat.blt (2 * p1) S
    · rw [cond_false]
      have : (zero.lo).val / S = 0 := by simp [zero, lo, SP.val]
      rw [this]; exact (Real.exp_pos _).le
    · rw [cond_true]
      have hlt : 2 * p1 < S := Nat.blt_eq.mp hb
      have hok1 : EptOk p1 = true := by
        have h2 := hok'.2
        rw [hb] at h2
        simpa using h2
      have h12 := pt_two_mul_lt hlt
      have hp1 : Real.pi * pt p1 < Real.pi / 2 := by nlinarith
      have hE1 := mem_EptB hok1
      have hval : -(1 / a0 * (1 / a0) * Efun (Real.pi * pt p1)) ≤ 0 := by
        have : 0 ≤ Efun (Real.pi * pt p1) := Efun_nonneg (by have := pt_nonneg p1; positivity) hp1
        have : 0 ≤ 1 / a0 * (1 / a0) := by have := hA.pos; positivity
        nlinarith
      have hb' := mem_expB (mem_nonposB (mem_neg (mem_mul (mem_mul hA.mem0 hA.mem0) hE1)) hval)
      refine (lo_le_of_mem hb').trans ?_
      apply exp_neg_mul_le (by positivity) hA.sq_le0 (le_trans hE0 hEu)
      exact Efun_le_of_le (by positivity) (by nlinarith) hp1
  · have hE0' := mem_EptB hok0
    have hval : -(1 / a1 * (1 / a1) * Efun (Real.pi * pt p0)) ≤ 0 := by nlinarith
    have hb' := mem_expB (mem_nonposB (mem_neg (mem_mul (mem_mul hA.mem1 hA.mem1) hE0')) hval)
    refine le_trans ?_ (le_hi_of_mem hb')
    exact exp_neg_mul_le ha2 hA.sq_le1 hE0 hEu

/-- `|cos π u| e^{(π u)²/2}` at a point. -/
def cw (u : ℝ) : ℝ := |Real.cos (Real.pi * u)| * Real.exp ((Real.pi * u) ^ 2 / 2)

lemma mem_cwPt {p : ℕ} (hp : S ≤ 2 * p) (hp1 : p ≤ S) : cw (pt p) ∈ cwPt p := by
  obtain ⟨hc, _⟩ := mem_trigPt p
  have h12 := half_le_pt hp
  have h1 := pt_le_one hp1
  have hcos : Real.cos (Real.pi * pt p) ≤ 0 :=
    Real.cos_nonpos_of_pi_div_two_le_of_le (by nlinarith [Real.pi_pos]) (by nlinarith [Real.pi_pos])
  have := mem_mul (mem_neg hc) (mem_expB (mem_shr (mem_mul (mem_piPt p) (mem_piPt p)) 1))
  unfold cw cwPt
  rw [abs_of_nonpos hcos, show (Real.pi * pt p) ^ 2 / 2 = Real.pi * pt p * (Real.pi * pt p) / 2 ^ 1
    by ring]
  exact this

lemma cw_mono {u v : ℝ} (hu : 1 / 2 ≤ u) (huv : u ≤ v) (hv : v ≤ 1) : cw u ≤ cw v := by
  have hpi := Real.pi_pos
  have hcu : Real.cos (Real.pi * u) ≤ 0 :=
    Real.cos_nonpos_of_pi_div_two_le_of_le (by nlinarith) (by nlinarith)
  have hcv : Real.cos (Real.pi * v) ≤ 0 :=
    Real.cos_nonpos_of_pi_div_two_le_of_le (by nlinarith) (by nlinarith)
  have hc : Real.cos (Real.pi * v) ≤ Real.cos (Real.pi * u) :=
    Real.cos_le_cos_of_nonneg_of_le_pi (by nlinarith) (by nlinarith) (by nlinarith)
  have he : Real.exp ((Real.pi * u) ^ 2 / 2) ≤ Real.exp ((Real.pi * v) ^ 2 / 2) := by
    apply Real.exp_le_exp.2
    have : Real.pi * u ≤ Real.pi * v := by nlinarith
    have : 0 ≤ Real.pi * u := by nlinarith
    nlinarith
  unfold cw
  rw [abs_of_nonpos hcu, abs_of_nonpos hcv]
  exact mul_le_mul (by linarith) he (Real.exp_pos _).le (by linarith)

lemma mem_CWB {p0 p1 : ℕ} (hp0 : S ≤ 2 * p0) (hp1 : p1 ≤ S) {u : ℝ} (hu0 : pt p0 ≤ u)
    (hu1 : u ≤ pt p1) : cw u ∈ CWB p0 p1 := by
  have h12 := half_le_pt hp0
  have h1 := pt_le_one hp1
  have hp01 : p0 ≤ S := by
    by_contra h
    have := pt_lt (lt_of_not_le h); rw [pt_S] at this; linarith
  have hS0 : S ≤ 2 * p1 := by
    by_contra h
    have := pt_two_mul_lt (lt_of_not_le h); linarith
  apply mem_ofLoHi_of_le
  · exact (lo_le_of_mem (mem_cwPt hp0 hp01)).trans (cw_mono h12 hu0 (by linarith))
  · exact (cw_mono (by linarith) hu1 h1).trans (le_hi_of_mem (mem_cwPt hS0 hp1))

lemma mem_eNtB {IA0 IA1 : Ball} {a0 a1 a : ℝ} (hA : AData IA0 IA1 a0 a1 a) {p0 p1 : ℕ}
    (hok : eNtOk p0 p1 = true) (hp0 : S < 2 * p0) (hp1 : p1 ≤ S) {u : ℝ} (hu0 : pt p0 < u)
    (hu1 : u < pt p1) :
    Real.exp (-(1 / a ^ 2 * Efun (Real.pi * (1 - u)))) ∈ eNtB IA0 IA1 p0 p1 := by
  have hpi := Real.pi_pos
  have hp01 : p0 ≤ S := by
    by_contra h
    have := pt_lt (lt_of_not_le h); have := pt_le hp1; rw [pt_S] at *; linarith
  have hok0 : EptOk (S - p0) = true := by unfold eNtOk at hok; simp_all
  have hok1 : EptOk (S - p1) = true := by unfold eNtOk at hok; simp_all
  have h12 := half_lt_pt hp0
  have h1 := pt_le_one hp1
  have e0 : pt (S - p0) = 1 - pt p0 := by rw [pt_sub hp01, pt_S]
  have e1 : pt (S - p1) = 1 - pt p1 := by rw [pt_sub hp1, pt_S]
  have ht : 0 ≤ 1 - u := by linarith
  have ht2 : Real.pi * (1 - u) < Real.pi / 2 := by nlinarith
  have hE1 : 0 ≤ Efun (Real.pi * pt (S - p1)) := Efun_nonneg (by have := pt_nonneg (S - p1); positivity)
    (by rw [e1]; nlinarith)
  have hE1u : Efun (Real.pi * pt (S - p1)) ≤ Efun (Real.pi * (1 - u)) :=
    Efun_le_of_le (by have := pt_nonneg (S - p1); positivity) (by rw [e1]; nlinarith) ht2
  have hEu0 : Efun (Real.pi * (1 - u)) ≤ Efun (Real.pi * pt (S - p0)) :=
    Efun_le_of_le (by positivity) (by rw [e0]; nlinarith) (by rw [e0]; nlinarith)
  apply mem_ofLoHi_of_le
  · have hb := mem_EptB hok0
    have hval : -(1 / a0 * (1 / a0) * Efun (Real.pi * pt (S - p0))) ≤ 0 := by
      have : 0 ≤ 1 / a0 * (1 / a0) := by have := hA.pos; positivity
      nlinarith
    have hb' := mem_expB (mem_nonposB (mem_neg (mem_mul (mem_mul hA.mem0 hA.mem0) hb)) hval)
    refine (lo_le_of_mem hb').trans ?_
    exact exp_neg_mul_le (by have := hA.apos; positivity) hA.sq_le0 (hE1.trans hE1u) hEu0
  · have hb := mem_EptB hok1
    have ha2 : 0 ≤ 1 / a1 * (1 / a1) := by have := hA.a1pos; positivity
    have hval : -(1 / a1 * (1 / a1) * Efun (Real.pi * pt (S - p1))) ≤ 0 := by nlinarith
    have hb' := mem_expB (mem_nonposB (mem_neg (mem_mul (mem_mul hA.mem1 hA.mem1) hb)) hval)
    refine le_trans ?_ (le_hi_of_mem hb')
    exact exp_neg_mul_le ha2 hA.sq_le1 hE1 hE1u

/-! ### The weights `q(u) = π u ρ(u)` and `ρ(u)` -/

lemma lt_S_of_pt {p1 p : ℕ} (hp1 : p1 ≤ S) (h : p < p1) : p < S := lt_of_lt_of_le h hp1

lemma mem_qB {p0 p1 : ℕ} (hok : qOk p0 p1 = true) (hp1 : p1 ≤ S) {u : ℝ} (hu0 : pt p0 < u)
    (hu1 : u < pt p1) : Real.pi * u * rho u ∈ qB p0 p1 := by
  have hpi := Real.pi_pos
  have hu : 0 < u := lt_of_le_of_lt (pt_nonneg p0) hu0
  have h1 := pt_le_one hp1
  have hu1' : u < 1 := lt_of_lt_of_le hu1 h1
  have hp01 : p0 < p1 := by
    by_contra h
    have := pt_le (not_lt.mp h); linarith
  have hp0S : p0 ≤ S := (lt_of_lt_of_le hp01 hp1).le
  unfold qB
  cases hb : Nat.ble (2 * p1) S
  · -- right branch: `q(u) = u D(π(1-u))`
    rw [cond_false]
    unfold qOk at hok; rw [hb, cond_false] at hok; simp only [Bool.and_eq_true] at hok
    obtain ⟨⟨hp0, hlo⟩, hhi⟩ := hok
    have hp0' : 0 < p0 := by
      rcases Nat.eq_zero_or_pos p0 with h | h
      · rw [h] at hp0; simp at hp0
      · exact h
    rw [q_eq_right]
    have hy0 : 0 < Real.pi * (1 - u) := by nlinarith
    have hyπ : Real.pi * (1 - u) < Real.pi := by nlinarith
    have hDu : 0 ≤ Dfun (Real.pi * (1 - u)) := Dfun_nonneg hy0 hyπ
    apply mem_ofLoHi_of_le
    · have hd := DloB_le hlo (y := Real.pi * (1 - u)) (by rw [pt_sub hp1, pt_S]; nlinarith) hy0 hyπ
      have hm := mem_mul (mem_pt p0) (lo_mem (DloB (S - p1)))
      refine (lo_le_of_mem hm).trans ?_
      calc pt p0 * ((DloB (S - p1)).lo.val / S) ≤ pt p0 * Dfun (Real.pi * (1 - u)) :=
            mul_le_mul_of_nonneg_left hd (pt_nonneg p0)
        _ ≤ u * Dfun (Real.pi * (1 - u)) := mul_le_mul_of_nonneg_right hu0.le hDu
    · have hd := mem_DptB hhi
      have hm := mem_mul (mem_pt p1) hd
      refine le_trans ?_ (le_hi_of_mem hm)
      have hmono : Dfun (Real.pi * (1 - u)) ≤ Dfun (Real.pi * pt (S - p0)) := by
        rw [pt_sub hp0S, pt_S]
        exact Dfun_le_of_le hy0 (by nlinarith) (by nlinarith [pt_pos hp0'])
      calc u * Dfun (Real.pi * (1 - u)) ≤ pt p1 * Dfun (Real.pi * (1 - u)) :=
            mul_le_mul_of_nonneg_right hu1.le hDu
        _ ≤ pt p1 * Dfun (Real.pi * pt (S - p0)) :=
            mul_le_mul_of_nonneg_left hmono (pt_nonneg p1)
  · -- left branch: `q(u) = 1 - (1 - u) D(π u)`
    rw [cond_true]
    unfold qOk at hok; rw [hb, cond_true] at hok; simp only [Bool.and_eq_true] at hok
    obtain ⟨hhi, hlo⟩ := hok
    have hle : 2 * p1 ≤ S := Nat.ble_eq.mp hb
    have h12 := pt_two_mul_le hle
    rw [q_eq_left]
    have hy0 : 0 < Real.pi * u := by positivity
    have hyπ : Real.pi * u < Real.pi := by nlinarith
    have hDu : 0 ≤ Dfun (Real.pi * u) := Dfun_nonneg hy0 hyπ
    apply mem_ofLoHi_of_le
    · have hd := mem_DptB hhi
      have hm := mem_sub mem_one (mem_mul (mem_pt (S - p0)) hd)
      refine (lo_le_of_mem hm).trans ?_
      have hmono : Dfun (Real.pi * u) ≤ Dfun (Real.pi * pt p1) :=
        Dfun_le_of_le hy0 (by nlinarith) (by nlinarith)
      rw [pt_sub hp0S, pt_S]
      have : (1 - u) * Dfun (Real.pi * u) ≤ (1 - pt p0) * Dfun (Real.pi * pt p1) :=
        mul_le_mul (by linarith) hmono hDu (by linarith)
      linarith
    · have hd := DloB_le hlo (y := Real.pi * u) (by nlinarith) hy0 hyπ
      have hm := mem_sub mem_one (mem_mul (mem_pt (S - p1)) (lo_mem (DloB p0)))
      refine le_trans ?_ (le_hi_of_mem hm)
      rw [pt_sub hp1, pt_S]
      have : (1 - pt p1) * ((DloB p0).lo.val / S) ≤ (1 - u) * Dfun (Real.pi * u) :=
        calc (1 - pt p1) * ((DloB p0).lo.val / S) ≤ (1 - pt p1) * Dfun (Real.pi * u) :=
              mul_le_mul_of_nonneg_left hd (by linarith)
          _ ≤ (1 - u) * Dfun (Real.pi * u) := mul_le_mul_of_nonneg_right (by linarith) hDu
      linarith

lemma mem_rhoB {p0 p1 : ℕ} (hok : rhoOk p0 p1 = true) (hp1 : p1 ≤ S) {u : ℝ} (hu0 : pt p0 < u)
    (hu1 : u < pt p1) : rho u ∈ rhoB p0 p1 := by
  have hpi := Real.pi_pos
  unfold rhoOk at hok
  simp only [Bool.and_eq_true] at hok
  obtain ⟨⟨⟨hp0, hlo⟩, hhi⟩, hpiok⟩ := hok
  have hp0' : 0 < p0 := by
    rcases Nat.eq_zero_or_pos p0 with h | h
    · rw [h] at hp0; simp at hp0
    · exact h
  have hu : 0 < u := lt_of_le_of_lt (pt_nonneg p0) hu0
  have h1 := pt_le_one hp1
  have hu1' : u < 1 := lt_of_lt_of_le hu1 h1
  have hp01 : p0 < p1 := by
    by_contra h
    have := pt_le (not_lt.mp h); linarith
  have hp0S : p0 ≤ S := (lt_of_lt_of_le hp01 hp1).le
  have hy0 : 0 < Real.pi * (1 - u) := by nlinarith
  have hyπ : Real.pi * (1 - u) < Real.pi := by nlinarith
  rw [rho_eq_Dfun]
  unfold rhoB
  apply mem_ofLoHi_of_le
  · have hd := DloB_le hlo (y := Real.pi * (1 - u)) (by rw [pt_sub hp1, pt_S]; nlinarith) hy0 hyπ
    have hm := mem_divB hpiok (lo_mem (DloB (S - p1))) pi_mem
    refine (lo_le_of_mem hm).trans ?_
    exact div_le_div_of_nonneg_right hd hpi.le
  · have hm := mem_divB hpiok (mem_DptB hhi) pi_mem
    refine le_trans ?_ (le_hi_of_mem hm)
    apply div_le_div_of_nonneg_right _ hpi.le
    rw [pt_sub hp0S, pt_S]
    exact Dfun_le_of_le hy0 (by nlinarith) (by nlinarith [pt_pos hp0'])

/-! ### Nonzero balls, `cond`, and `sin z / z` -/

lemma ne_zero_of_invOk {X : Ball} (hok : invOk X = true) {x : ℝ} (hx : x ∈ X) : x ≠ 0 := by
  unfold invOk at hok
  rw [Bool.or_eq_true] at hok
  rcases hok with h | h
  · exact (pos_of_posB h hx).ne'
  · exact (neg_pos.mp (pos_of_posB h (mem_neg hx))).ne

lemma mem_cond {b : Bool} {A B : Ball} {x : ℝ} (h1 : b = true → x ∈ A) (h2 : b = false → x ∈ B) :
    x ∈ (bif b then A else B) := by
  cases b
  · exact h2 rfl
  · exact h1 rfl

lemma sinc_abs (z : ℝ) : Real.sin |z| / |z| = Real.sin z / z := by
  rcases le_total 0 z with h | h
  · rw [abs_of_nonneg h]
  · rw [abs_of_nonpos h, Real.sin_neg, neg_div_neg_eq]

lemma sinc_lipschitz' {z w : ℝ} (hz : z ≠ 0) (hw : w ≠ 0) :
    |Real.sin z / z - Real.sin w / w| ≤ |z - w| / 2 := by
  rw [← sinc_abs z, ← sinc_abs w]
  refine (sinc_lipschitz (abs_pos.2 hz) (abs_pos.2 hw)).trans ?_
  have := abs_abs_sub_abs_le_abs_sub z w
  linarith

lemma mem_sincB {W : Ball} (hok : sincOk W = true) {w : ℝ} (hw : w ∈ W) (hw0 : w ≠ 0) :
    Real.sin (Real.pi * w) / (Real.pi * w) ∈ sincB W := by
  have hc := mem_mul pi_mem (mem_exact W.p W.n)
  have hs := (trigPt_mem W.p W.n).2
  set c : ℝ := ((W.p : ℝ) - W.n) / S with hcdef
  have hc0 : Real.pi * c ≠ 0 := ne_zero_of_invOk hok hc
  have hcen := mem_divB hok hs hc
  have hδ : |w - c| ≤ (W.r : ℝ) / S := by
    rw [Ball.mem_def] at hw
    rw [le_div_iff₀ S_pos]
    have e1 : (w - c) * S = w * S - ((W.p : ℝ) - W.n) := by
      rw [hcdef, sub_mul, div_mul_cancel₀ _ S_pos.ne']
    have e2 : |w - c| * S = |(w - c) * S| := by rw [abs_mul, abs_of_pos S_pos]
    rw [e2, e1]; exact hw
  have hr : (W.r : ℝ) / S ∈ exact W.r 0 := by simpa using mem_exact W.r 0
  have hE := mem_shr (mem_mul pi_mem hr) 1
  have hlip := sinc_lipschitz' (mul_ne_zero Real.pi_ne_zero hw0) hc0
  have hdiff : |Real.sin (Real.pi * w) / (Real.pi * w) - Real.sin (Real.pi * c) / (Real.pi * c)| ≤
      Real.pi * ((W.r : ℝ) / S) / 2 ^ 1 := by
    refine hlip.trans ?_
    rw [← mul_sub, abs_mul, abs_of_pos Real.pi_pos]
    have := mul_le_mul_of_nonneg_left hδ Real.pi_pos.le
    rw [pow_one]
    linarith
  have herr : Real.sin (Real.pi * w) / (Real.pi * w) - Real.sin (Real.pi * c) / (Real.pi * c) ∈
      (⟨0, 0, (shr (mul PI (exact W.r 0)) 1).mag⟩ : Ball) := by
    rw [Ball.mem_def]
    simp only [Nat.cast_zero, sub_zero]
    have h1 := abs_mul_S_le_mag hE
    rw [abs_mul, abs_of_pos S_pos]
    have h2 := mul_le_mul_of_nonneg_right (hdiff.trans (le_abs_self _)) S_pos.le
    linarith
  have := mem_add hcen herr
  rw [show Real.sin (Real.pi * w) / (Real.pi * w) = Real.sin (Real.pi * c) / (Real.pi * c) +
    (Real.sin (Real.pi * w) / (Real.pi * w) - Real.sin (Real.pi * c) / (Real.pi * c)) by ring]
  exact this

/-! ### The kernel and the alias branches -/

lemma mem_kapB {XI : Ball} {p0 p1 : ℕ} (hok : kapOk XI p0 p1 = true) (hp1 : p1 ≤ S) {ξ u : ℝ}
    (hξ : ξ ∈ XI) (hξ0 : ξ ≠ 0) (hu0 : pt p0 < u) (hu1 : u < pt p1) :
    upperKernel ξ u ∈ kapB XI p0 p1 := by
  unfold kapOk at hok
  simp only [Bool.and_eq_true, Bool.or_eq_true] at hok
  obtain ⟨⟨hsinc, hq⟩, hrho⟩ := hok
  have hu : 0 < u := lt_of_le_of_lt (pt_nonneg p0) hu0
  have hw := mem_imul hξ (mem_ivB hu0.le hu1.le)
  have hT := trigBox_mem hw
  have hbase := mem_imul (one_sub_mem_ivB hp1 hu0.le hu1.le) hT.1
  have hw0 : ξ * u ≠ 0 := mul_ne_zero hξ0 hu.ne'
  have hks := mem_add hbase (mem_imul (mem_imul hξ (mem_qB hq hp1 hu0 hu1)) (mem_sincB hsinc hw hw0))
  have hpiw : Real.pi * (ξ * u) ≠ 0 := mul_ne_zero Real.pi_ne_zero hw0
  have e2 : upperKernel ξ u = (1 - u) * Real.cos (Real.pi * (ξ * u)) +
      rho u * Real.sin (Real.pi * (ξ * u)) := by
    unfold upperKernel; rw [show Real.pi * ξ * u = Real.pi * (ξ * u) by ring]
  have e1 : upperKernel ξ u = (1 - u) * Real.cos (Real.pi * (ξ * u)) +
      ξ * (Real.pi * u * rho u) * (Real.sin (Real.pi * (ξ * u)) / (Real.pi * (ξ * u))) := by
    rw [e2]; congr 1; field_simp; ring
  apply mem_cond
  · intro _
    rw [e1]; exact hks
  · intro hb
    have hr : rhoOk p0 p1 = true := by
      rcases hrho with h | h
      · rw [hb] at h; exact absurd h (by simp)
      · exact h
    have h2 := mem_add hbase (mem_imul (mem_rhoB hr hp1 hu0 hu1) hT.2)
    rw [← e2] at h2
    rw [← e1] at hks
    exact mem_inter hks h2

lemma S_eq_two_halfS : S = 2 * halfS := by unfold S halfS; norm_num

lemma mem_bB {XI : Ball} {p0 p1 : ℕ} (hrho : rhoOk p0 p1 = true) (hp0 : S ≤ 2 * p0)
    (hp1 : p1 ≤ S) {ξ u : ℝ} (hξ : ξ ∈ XI) (hu0 : pt p0 < u) (hu1 : u < pt p1) :
    max (bPlus ξ u) (bMinus ξ u) ∈ bB XI p0 p1 := by
  have hp01 : p0 < p1 := by
    by_contra h
    have := pt_le (not_lt.mp h); linarith
  have hS2 := S_eq_two_halfS
  have hh0 : halfS ≤ p0 := by omega
  have hh1 : halfS ≤ p1 := by omega
  have hSW := (trigBox_mem (mem_imul hξ (mem_ivB hu0.le hu1.le))).2
  have hH := trigBox_mem (mem_shr hξ 1)
  have hm : u - 1 / 2 ∈ ivB (p0 - halfS) (p1 - halfS) := by
    apply mem_ivB
    · rw [pt_sub hh0, pt_halfS]; linarith
    · rw [pt_sub hh1, pt_halfS]; linarith
  have hM := trigBox_mem (mem_imul hξ hm)
  have hT2 := mem_mulNat (one_sub_mem_ivB hp1 hu0.le hu1.le) 2
  have hRS := mem_imul (mem_rhoB hrho hp1 hu0 hu1) hSW
  have hP := mem_add (mem_neg (mem_imul (mem_imul hT2 hH.2) hM.2)) hRS
  have hN := mem_sub (mem_neg (mem_imul (mem_imul hT2 hH.1) hM.1)) hRS
  have hmax := mem_max hP hN
  have a1 : Real.pi * (ξ / 2 ^ 1) = Real.pi * ξ / 2 := by ring
  have a2 : Real.pi * (ξ * (u - 1 / 2)) = Real.pi * ξ * (u - 1 / 2) := by ring
  have a3 : Real.pi * (ξ * u) = Real.pi * ξ * u := by ring
  rw [a1, a2, a3] at hmax
  have eP : bPlus ξ u = -((1 - u) * ((2 : ℕ) : ℝ) * Real.sin (Real.pi * ξ / 2) *
      Real.sin (Real.pi * ξ * (u - 1 / 2))) + rho u * Real.sin (Real.pi * ξ * u) := by
    unfold bPlus; push_cast; ring
  have eN : bMinus ξ u = -((1 - u) * ((2 : ℕ) : ℝ) * Real.cos (Real.pi * ξ / 2) *
      Real.cos (Real.pi * ξ * (u - 1 / 2))) - rho u * Real.sin (Real.pi * ξ * u) := by
    unfold bMinus; push_cast; ring
  rw [eP, eN]
  exact hmax

/-! ### The cotangent remainder -/

lemma abs_cq_le {p0 p1 : ℕ} (hok : cqOk p0 p1 = true) (hp1 : p1 ≤ S) {u : ℝ} (hu0 : pt p0 < u)
    (hu1 : u < pt p1) : |(1 - u) * cotangentQ (Real.pi * u)| ≤ (cqB p0 p1).hi.val / S := by
  have hpi := Real.pi_pos
  have hu : 0 < u := lt_of_le_of_lt (pt_nonneg p0) hu0
  have h1 := pt_le_one hp1
  have hu1' : u < 1 := lt_of_lt_of_le hu1 h1
  unfold cqB
  cases hb : leB (mul PI (exact p1 0)) one
  · rw [cond_false]
    unfold cqOk at hok
    rw [hb, Bool.false_or] at hok
    simp only [Bool.and_eq_true] at hok
    obtain ⟨⟨hinv, hlo⟩, hpiok⟩ := hok
    have hp0 : Real.pi * pt p0 ≠ 0 := ne_zero_of_invOk hinv (mem_piPt p0)
    have hp0' : 0 < pt p0 := by
      rcases (pt_nonneg p0).lt_or_eq with h | h
      · exact h
      · rw [← h, mul_zero] at hp0; exact absurd rfl hp0
    have hpp0 : 0 < Real.pi * pt p0 := mul_pos hpi hp0'
    have hval := mem_sub (mem_sub (mem_invB hinv (mem_piPt p0))
      (mem_divNat (mem_mul (mem_pt (S - p1)) (mem_piPt p0)) (by norm_num : 0 < 3)))
      (mem_divB hpiok (lo_mem (DloB (S - p1))) pi_mem)
    refine le_trans ?_ (le_hi_of_mem hval)
    rw [abs_weighted_cotangentQ_eq hu hu1', rho_eq_Dfun, pt_sub hp1, pt_S]
    have hd := DloB_le hlo (y := Real.pi * (1 - u)) (by rw [pt_sub hp1, pt_S]; nlinarith)
      (by nlinarith) (by nlinarith)
    have i1 : 1 / (Real.pi * u) ≤ (Real.pi * pt p0)⁻¹ := by
      rw [← one_div]; exact one_div_le_one_div_of_le hpp0 (by nlinarith)
    have i2 : (1 - pt p1) * (Real.pi * pt p0) ≤ (1 - u) * (Real.pi * u) :=
      mul_le_mul (by linarith) (by nlinarith) hpp0.le (by linarith)
    have i3 : (DloB (S - p1)).lo.val / S / Real.pi ≤ Dfun (Real.pi * (1 - u)) / Real.pi :=
      div_le_div_of_nonneg_right hd hpi.le
    have e3 : (((3 : ℕ) : ℝ)) = 3 := by norm_num
    rw [e3]
    linarith
  · rw [cond_true]
    have hle := le_of_leB hb (mem_piPt p1) mem_one
    have hm := mem_divNat (mem_mul (mem_mul (mem_piPt p1) (mem_piPt p1)) (mem_piPt p1))
      (by norm_num : 0 < 30)
    refine le_trans ?_ (le_hi_of_mem hm)
    have hpu : Real.pi * u ≤ Real.pi * pt p1 := by nlinarith
    have hsmall := abs_weighted_cotangentQ_small hu hu1' (hpu.trans hle)
    have h3 : (Real.pi * u) ^ 3 ≤ Real.pi * pt p1 * (Real.pi * pt p1) * (Real.pi * pt p1) := by
      rw [show Real.pi * pt p1 * (Real.pi * pt p1) * (Real.pi * pt p1) = (Real.pi * pt p1) ^ 3
        by ring]
      exact pow_le_pow_left₀ (by positivity) hpu 3
    have e30 : (((30 : ℕ) : ℝ)) = 30 := by norm_num
    rw [e30]
    linarith

/-! ### The bound on one cell -/

lemma cellOk_spec {XI : Ball} {p0 p1 : ℕ} (h : cellOk XI p0 p1 = true) :
    p0 < p1 ∧ p1 ≤ S ∧ kapOk XI p0 p1 = true ∧ cqOk p0 p1 = true ∧
      (2 * p1 ≤ S → eNOk p0 p1 = true) ∧
      (S < 2 * p1 → S ≤ 2 * p0 ∧ (leftOfRoot p1 = true ∨
        (S < 2 * p0 ∧ eNtOk p0 p1 = true ∧ rhoOk p0 p1 = true))) := by
  unfold cellOk at h
  simp only [Bool.and_eq_true] at h
  obtain ⟨⟨⟨⟨h1, h2⟩, h3⟩, h4⟩, h5⟩ := h
  refine ⟨Nat.blt_eq.mp h1, Nat.ble_eq.mp h2, h3, h4, ?_, ?_⟩
  · intro h2p
    rw [show Nat.ble (2 * p1) S = true from Nat.ble_eq.mpr h2p, cond_true] at h5
    exact h5
  · intro h2p
    rw [show Nat.ble (2 * p1) S = false by
      rw [← Bool.not_eq_true, Nat.ble_eq]; omega, cond_false] at h5
    simp only [Bool.and_eq_true, Bool.or_eq_true] at h5
    obtain ⟨h6, h7⟩ := h5
    refine ⟨Nat.ble_eq.mp h6, ?_⟩
    rcases h7 with h7 | ⟨⟨h8, h9⟩, h10⟩
    · exact Or.inl h7
    · exact Or.inr ⟨Nat.blt_eq.mp h8, h9, h10⟩

section Cell

variable {XI IA0 IA1 : Ball} {a0 a1 a ξ y : ℝ} {p0 p1 : ℕ}

lemma cot_le (hA : AData IA0 IA1 a0 a1 a) (hξ : ξ ∈ XI) (hy : y / a = ξ)
    (hcq : cqOk p0 p1 = true) (hp1 : p1 ≤ S) {u : ℝ} (hu0 : pt p0 < u) (hu1 : u < pt p1) :
    cotU a y u ≤ |(1 - u) * cotangentQ (Real.pi * u)| * max 0 (-Real.sin (Real.pi * (ξ * u))) *
        gaussian (Real.pi * u / a) ∧
      |(1 - u) * cotangentQ (Real.pi * u)| * max 0 (-Real.sin (Real.pi * (ξ * u))) *
        gaussian (Real.pi * u / a) ∈
      mul (mul (ofLoHi SP.zero (cqB p0 p1).hi) (negPart (trigBox (mul XI (ivB p0 p1))).2))
        (GB IA0 IA1 p0 p1) := by
  have hu : 0 < u := lt_of_le_of_lt (pt_nonneg p0) hu0
  have hu1' : u < 1 := lt_of_lt_of_le hu1 (pt_le_one hp1)
  have hQ := weighted_cotangentQ_nonpos hu hu1'
  have hG := gaussian_nonneg (Real.pi * u / a)
  constructor
  · rw [cotU_eq hA.apos, hy, show Real.pi * ξ * u = Real.pi * (ξ * u) by ring,
      abs_of_nonpos hQ]
    apply mul_le_mul_of_nonneg_right _ hG
    have := le_max_right 0 (-Real.sin (Real.pi * (ξ * u)))
    nlinarith
  · have hc : |(1 - u) * cotangentQ (Real.pi * u)| ∈ ofLoHi SP.zero (cqB p0 p1).hi :=
      mem_ofLoHi_zero (abs_nonneg _) (abs_cq_le hcq hp1 hu0 hu1)
    exact mem_mul (mem_mul hc (mem_negPart (trigBox_mem (mem_mul hξ
      (mem_ivB hu0.le hu1.le))).2)) (mem_GB hA hu0.le hu1.le)

lemma gU_le_f1 (hA : AData IA0 IA1 a0 a1 a) (hξ : ξ ∈ XI) (hξ0 : ξ ≠ 0) (hy : y / a = ξ)
    (hok : cellOk XI p0 p1 = true) (h2 : 2 * p1 ≤ S) {u : ℝ} (hu0 : pt p0 < u)
    (hu1 : u < pt p1) : gU a y u ≤ (f1Hi XI IA0 IA1 p0 p1).val / S := by
  obtain ⟨-, hp1, hkap, hcq, hR1, -⟩ := cellOk_spec hok
  have hu : 0 < u := lt_of_le_of_lt (pt_nonneg p0) hu0
  have hu2 : u < 1 / 2 := lt_of_lt_of_le hu1 (pt_two_mul_le h2)
  have hK := mem_kapB hkap hp1 hξ hξ0 hu0 hu1
  have hG := mem_GB hA hu0.le hu1.le
  have hE := mem_eNB hA (hR1 h2) h2 hu0 hu1
  obtain ⟨hcot, hcotm⟩ := cot_le hA hξ hy hcq hp1 hu0 hu1
  have hm := mem_add (mem_mul (mem_mul (mem_negPart hK) hG) (mem_sub mem_one hE)) hcotm
  rw [gU_R1 hA.apos hu hu2, hy]
  exact (add_le_add_left hcot _).trans (le_hi_of_mem hm)

lemma gU_le_f2 (hA : AData IA0 IA1 a0 a1 a) (hξ : ξ ∈ XI) (hξ0 : ξ ≠ 0) (hy : y / a = ξ)
    (hok : cellOk XI p0 p1 = true) (h2 : S < 2 * p1) {u : ℝ} (hu0 : pt p0 < u)
    (hu1 : u < pt p1) (huθ : u ≤ crossoverRoot / Real.pi) :
    gU a y u ≤ (f2Hi XI IA0 IA1 p0 p1).val / S := by
  obtain ⟨-, hp1, hkap, hcq, -, hR⟩ := cellOk_spec hok
  obtain ⟨hp0, -⟩ := hR h2
  have hu2 : 1 / 2 < u := lt_of_le_of_lt (half_le_pt hp0) hu0
  have hK := mem_kapB hkap hp1 hξ hξ0 hu0 hu1
  have hG := mem_GB hA hu0.le hu1.le
  have hW := mem_CWB hp0 hp1 hu0.le hu1.le
  obtain ⟨hcot, hcotm⟩ := cot_le hA hξ hy hcq hp1 hu0 hu1
  have hm := mem_add (mem_mul (mem_mul (mem_negPart hK) hG) (mem_add mem_one hW)) hcotm
  rw [gU_R2 hA.apos hu2 huθ, hy]
  exact (add_le_add_left hcot _).trans (le_hi_of_mem hm)

lemma gU_le_f3 (hA : AData IA0 IA1 a0 a1 a) (hξ : ξ ∈ XI) (hξ0 : ξ ≠ 0) (hy : y / a = ξ)
    (hok : cellOk XI p0 p1 = true) (hp0 : S < 2 * p0) (hnt : eNtOk p0 p1 = true)
    (hrho : rhoOk p0 p1 = true) {u : ℝ} (hu0 : pt p0 < u) (hu1 : u < pt p1)
    (huθ : crossoverRoot / Real.pi < u) :
    gU a y u ≤ (f3Hi XI IA0 IA1 p0 p1).val / S := by
  obtain ⟨hp01, hp1, hkap, hcq, -, -⟩ := cellOk_spec hok
  have hu1' : u < 1 := lt_of_lt_of_le hu1 (pt_le_one hp1)
  have hK := mem_kapB hkap hp1 hξ hξ0 hu0 hu1
  have hG := mem_GB hA hu0.le hu1.le
  have hp0S : p0 ≤ S := (hp01.trans_le hp1).le
  have hGT := mem_GB hA (p0 := S - p1) (p1 := S - p0) (u := 1 - u)
    (by rw [pt_sub hp1, pt_S]; linarith) (by rw [pt_sub hp0S, pt_S]; linarith)
  have hEt := mem_eNtB hA hnt hp0 hp1 hu0 hu1
  have hB := mem_bB hrho hp0.le hp1 hξ hu0 hu1
  obtain ⟨hcot, hcotm⟩ := cot_le hA hξ hy hcq hp1 hu0 hu1
  have hm := mem_add (mem_sub (mem_add (mem_imul (mem_mul (mem_abs hK) hGT) (mem_sub hEt mem_one))
    (mem_imul hB hGT)) (mem_imul hK hG)) hcotm
  rw [gU_R3 hA.apos huθ hu1', hy]
  exact (add_le_add_left hcot _).trans (le_hi_of_mem hm)

theorem gU_le_cellHi (hA : AData IA0 IA1 a0 a1 a) (hξ : ξ ∈ XI) (hξ0 : ξ ≠ 0) (hy : y / a = ξ)
    (hok : cellOk XI p0 p1 = true) {u : ℝ} (hu0 : pt p0 < u) (hu1 : u < pt p1) :
    gU a y u ≤ (cellHi XI IA0 IA1 p0 p1).val / S := by
  obtain ⟨-, -, -, -, -, hR⟩ := cellOk_spec hok
  have hθ := crossoverRoot_bounds
  have hpi := Real.pi_pos
  unfold cellHi
  cases h2 : Nat.ble (2 * p1) S
  · rw [cond_false]
    have h2' : S < 2 * p1 := by
      rw [← Bool.not_eq_true, Nat.ble_eq] at h2; omega
    obtain ⟨hp0, hrest⟩ := hR h2'
    cases hl : leftOfRoot p1
    · rw [cond_false]
      have hr : S < 2 * p0 ∧ eNtOk p0 p1 = true ∧ rhoOk p0 p1 = true := by
        rcases hrest with h | h
        · rw [hl] at h; exact absurd h (by simp)
        · exact h
      obtain ⟨hp0', hnt, hrho⟩ := hr
      cases hrt : rightOfRoot p0
      · rw [cond_false, SP.max_val]
        rcases le_or_lt u (crossoverRoot / Real.pi) with hu | hu
        · have := gU_le_f2 hA hξ hξ0 hy hok h2' hu0 hu1 hu
          exact this.trans (div_le_div_of_nonneg_right (le_max_left _ _) S_pos.le)
        · have := gU_le_f3 hA hξ hξ0 hy hok hp0' hnt hrho hu0 hu1 hu
          exact this.trans (div_le_div_of_nonneg_right (le_max_right _ _) S_pos.le)
      · rw [cond_true]
        have hle := le_of_leB hrt (mem_ofRat 18 (by norm_num : 0 < 10)) (mem_piPt p0)
        have hu : crossoverRoot / Real.pi < u := by
          rw [div_lt_iff₀ hpi]
          have : (((18 : ℕ) : ℝ) / ((10 : ℕ) : ℝ)) = 9 / 5 := by norm_num
          rw [this] at hle
          nlinarith
        exact gU_le_f3 hA hξ hξ0 hy hok hp0' hnt hrho hu0 hu1 hu
    · rw [cond_true]
      have hle := le_of_leB hl (mem_piPt p1) (mem_ofRat 17 (by norm_num : 0 < 10))
      have hu : u ≤ crossoverRoot / Real.pi := by
        rw [le_div_iff₀ hpi]
        have : (((17 : ℕ) : ℝ) / ((10 : ℕ) : ℝ)) = 17 / 10 := by norm_num
        rw [this] at hle
        nlinarith
      exact gU_le_f2 hA hξ hξ0 hy hok h2' hu0 hu1 hu
  · rw [cond_true]
    exact gU_le_f1 hA hξ hξ0 hy hok (Nat.ble_eq.mp h2) hu0 hu1

/-! ### The sum over the cells -/

lemma intervalIntegrable_gU (ha : 0 < a) (ha1 : a ≤ 1) :
    IntervalIntegrable (gU a y) volume 0 1 := by
  have hE := intervalIntegrable_envelopeDifference (x := y) ha ha1
  have hC := intervalIntegrable_cotU (y := y) ha
  have hM := intervalIntegrable_indicator_mU a y
  exact (hE.add hC).sub hM

lemma sumCells_cons (p q : ℕ) (l : List ℕ) :
    sumCells XI IA0 IA1 p (q :: l) =
      ((Nat.add (Nat.mul (q - p) (cellHi XI IA0 IA1 p q).1) (sumCells XI IA0 IA1 q l).1.1,
        Nat.add (Nat.mul (q - p) (cellHi XI IA0 IA1 p q).2) (sumCells XI IA0 IA1 q l).1.2),
        cellOk XI p q && (sumCells XI IA0 IA1 q l).2) := rfl

lemma sumCells_cons_ok (p q : ℕ) (l : List ℕ) :
    (sumCells XI IA0 IA1 p (q :: l)).2 = (cellOk XI p q && (sumCells XI IA0 IA1 q l).2) := rfl

lemma sumCells_cons_val (p q : ℕ) (l : List ℕ) (hpq : p ≤ q) :
    (sumCells XI IA0 IA1 p (q :: l)).1.val / (S : ℝ) ^ 2 =
      (pt q - pt p) * ((cellHi XI IA0 IA1 p q).val / S) +
        (sumCells XI IA0 IA1 q l).1.val / (S : ℝ) ^ 2 := by
  rw [sumCells_cons]
  simp only [SP.val, Nat.add_eq, Nat.mul_eq]
  push_cast [Nat.cast_sub hpq]
  unfold pt
  field_simp
  ring

lemma le_lastOf : ∀ (l : List ℕ) (p : ℕ), (sumCells XI IA0 IA1 p l).2 = true → p ≤ lastOf p l
  | [], _, _ => le_rfl
  | q :: l, p, h => by
    rw [sumCells_cons_ok] at h
    simp only [Bool.and_eq_true] at h
    have h1 := (cellOk_spec h.1).1
    have h2 := le_lastOf l q h.2
    exact h1.le.trans h2

theorem sumCells_sound (hA : AData IA0 IA1 a0 a1 a) (ha1 : a ≤ 1) (hξ : ξ ∈ XI) (hξ0 : ξ ≠ 0)
    (hy : y / a = ξ) :
    ∀ (l : List ℕ) (p : ℕ), (sumCells XI IA0 IA1 p l).2 = true → lastOf p l ≤ S →
      (∫ u in (pt p)..(pt (lastOf p l)), gU a y u) ≤
        (sumCells XI IA0 IA1 p l).1.val / (S : ℝ) ^ 2
  | [], p, _, _ => by
    simp only [lastOf, intervalIntegral.integral_same]
    have : (sumCells XI IA0 IA1 p []).1 = SP.zero := rfl
    rw [this, SP.zero_val, zero_div]
  | q :: l, p, h, hl => by
    have hlast : lastOf p (q :: l) = lastOf q l := rfl
    rw [hlast] at hl ⊢
    rw [sumCells_cons_ok] at h
    simp only [Bool.and_eq_true] at h
    obtain ⟨hc, hr⟩ := h
    have IH := sumCells_sound hA ha1 hξ hξ0 hy l q hr hl
    obtain ⟨hpq, hq, -⟩ := cellOk_spec hc
    have hqe : q ≤ lastOf q l := le_lastOf l q hr
    have hint := intervalIntegrable_gU (y := y) hA.apos ha1
    have i1 := intervalIntegrable_sub_unit hint (pt_nonneg p) (pt_le hpq.le) (pt_le_one hq)
    have i2 := intervalIntegrable_sub_unit hint (pt_nonneg q) (pt_le hqe) (pt_le_one hl)
    rw [← intervalIntegral.integral_add_adjacent_intervals i1 i2]
    have hcell : (∫ u in (pt p)..(pt q), gU a y u) ≤
        (pt q - pt p) * ((cellHi XI IA0 IA1 p q).val / S) := by
      have := intervalIntegral.integral_mono_on_of_le_Ioo (pt_le hpq.le) i1
        intervalIntegrable_const (fun u hu => gU_le_cellHi hA hξ hξ0 hy hc hu.1 hu.2)
      rw [intervalIntegral.integral_const, smul_eq_mul] at this
      exact this
    rw [sumCells_cons_val p q l hpq.le]
    linarith

end Cell

/-! ### The constant `φ₀` and the moment `N` -/

lemma phi0_mem : phi0 ∈ PHI0B := by
  have hpi := pi_mem
  rw [Ball.mem_def] at hpi
  have hpi' := abs_le.mp hpi
  simp only [PI, Nat.cast_ofNat, Nat.cast_zero, sub_zero, Nat.cast_one] at hpi'
  have hS : (S : ℝ) = 18446744073709551616 := by norm_num [S]
  rw [hS] at hpi'
  rw [Ball.mem_def]
  simp only [PHI0B, Nat.cast_ofNat, Nat.cast_zero, sub_zero]
  rw [hS, abs_le]
  unfold phi0
  have ht0 : 0 < Real.sqrt (2 * Real.pi) := Real.sqrt_pos.2 (by positivity)
  have ht : Real.sqrt (2 * Real.pi) ^ 2 = 2 * Real.pi := Real.sq_sqrt (by positivity)
  set t := Real.sqrt (2 * Real.pi)
  rw [one_div, ← div_eq_inv_mul]
  constructor
  · -- `(p - 4) t ≤ S`
    have h1 : ((7359186146747302452 : ℝ) - 4) * t ≤ 18446744073709551616 := by
      have hsq : (((7359186146747302452 : ℝ) - 4) * t) ^ 2 ≤ (18446744073709551616 : ℝ) ^ 2 := by
        rw [mul_pow, ht]
        nlinarith
      nlinarith [sq_nonneg (((7359186146747302452 : ℝ) - 4) * t - 18446744073709551616),
        mul_pos ht0 (show (0 : ℝ) < 7359186146747302452 - 4 by norm_num)]
    rw [le_sub_iff_add_le, le_div_iff₀ ht0]
    linarith
  · have h1 : (18446744073709551616 : ℝ) ≤ ((7359186146747302452 : ℝ) + 4) * t := by
      have hsq : (18446744073709551616 : ℝ) ^ 2 ≤ (((7359186146747302452 : ℝ) + 4) * t) ^ 2 := by
        rw [mul_pow, ht]
        nlinarith
      nlinarith [sq_nonneg (((7359186146747302452 : ℝ) + 4) * t - 18446744073709551616),
        mul_pos ht0 (show (0 : ℝ) < 7359186146747302452 + 4 by norm_num)]
    rw [sub_le_iff_le_add, div_le_iff₀ ht0]
    linarith

lemma gaussianN_neg (x : ℝ) : gaussianN (-x) = -gaussianN x := by
  unfold gaussianN
  rw [← integral_neg]
  congr 1
  funext s
  rw [mul_neg, Real.sin_neg]
  ring

lemma phi_neg (x : ℝ) : phi (-x) = phi x := by
  unfold phi; rw [gaussian_neg]

lemma gaussianN_ge {x : ℝ} (hx0 : 0 ≤ x) (hx1 : x ≤ 1) :
    x - (1 - x ^ 2) * (Real.pi * phi0) ≤ gaussianN x := by
  have hD := (abs_le.mp (abs_gaussianD_le x)).1
  have hsq : 0 ≤ 1 - x ^ 2 := by nlinarith
  have := mul_le_mul_of_nonneg_left hD hsq
  rw [gaussianN_eq, gaussianM_eq]
  nlinarith

lemma exists_nHi {X1 : Ball} {x x1 : ℝ} (hx1 : x1 ∈ X1) (hx0 : 0 ≤ x) (hxx : x ≤ x1) :
    ∃ v, v ∈ nHiB X1 ∧ gaussianN x ≤ v := by
  have hφ := phi0_mem
  have hN := (abs_le.mp (abs_gaussianN_le x)).2
  cases hb : leB X1 one
  · refine ⟨_, ?_, hN⟩
    apply mem_cond
    · intro h; rw [hb] at h; exact absurd h (by simp)
    · intro _; exact mem_mul pi_mem hφ
  · have hle : x1 ≤ 1 := le_of_leB hb hx1 mem_one
    have h2 := gaussianN_le_two_mul hx0 (hxx.trans hle)
    refine ⟨_, ?_, le_min hN (show gaussianN x ≤ x1 * ((2 : ℕ) : ℝ) by push_cast; linarith)⟩
    apply mem_cond
    · intro _; exact mem_min (mem_mul pi_mem hφ) (mem_mulNat hx1 2)
    · intro h; rw [hb] at h; exact absurd h (by simp)

lemma exists_nLo {X0 X1 : Ball} {x x0 x1 : ℝ} (hx0m : x0 ∈ X0) (hx1m : x1 ∈ X1) (hx00 : 0 ≤ x0)
    (hx0 : x0 ≤ x) (hxx : x ≤ x1) : ∃ v, v ∈ nLoB X0 X1 ∧ v ≤ gaussianN x := by
  have hφ := phi0_mem
  have hN := (abs_le.mp (abs_gaussianN_le x)).1
  have hpφ : 0 ≤ Real.pi * phi0 := mul_nonneg Real.pi_pos.le phi0_pos.le
  cases hb : leB X1 one
  · refine ⟨_, ?_, show -(Real.pi * phi0) ≤ gaussianN x by linarith⟩
    apply mem_cond
    · intro h; rw [hb] at h; exact absurd h (by simp)
    · intro _; exact mem_neg (mem_mul pi_mem hφ)
  · have hle : x1 ≤ 1 := le_of_leB hb hx1m mem_one
    have h1 := gaussianN_ge (hx00.trans hx0) (hxx.trans hle)
    refine ⟨max (-(Real.pi * phi0)) (x0 - (1 - x0 * x0) * (Real.pi * phi0)), ?_,
      max_le (by linarith) ?_⟩
    · apply mem_cond
      · intro _
        exact mem_max (mem_neg (mem_mul pi_mem hφ))
          (mem_sub hx0m (mem_mul (mem_sub mem_one (mem_mul hx0m hx0m)) (mem_mul pi_mem hφ)))
      · intro h; rw [hb] at h; exact absurd h (by simp)
    · have h3 : 0 ≤ (x - x0) * (1 + (x + x0) * (Real.pi * phi0)) :=
        mul_nonneg (by linarith) (by nlinarith)
      nlinarith

/-! ### The target -/

/-- `c(a) - a φ(x) ≥ -φ₀ a₁³/6 + a₀ φ₀ (1 - e^{-x₀²/2})`. -/
lemma target_main {a a0 a1 x x0 : ℝ} (ha0 : 0 < a0) (h0 : a0 ≤ a) (h1 : a ≤ a1) (hx00 : 0 ≤ x0)
    (hx0 : x0 ≤ x) :
    -(phi0 * (a1 * a1 * a1)) / 6 + a0 * phi0 * (1 - gaussian x0) ≤ c a - a * phi x := by
  have ha : 0 < a := ha0.trans_le h0
  have hc := c_lower_cubic ha.le
  have hφ := phi0_pos
  have hg := gaussian_anti hx00 hx0
  have hg1 := gaussian_le_one x0
  have i1 : a0 * phi0 * (1 - gaussian x0) ≤ a * phi0 * (1 - gaussian x) :=
    mul_le_mul (mul_le_mul_of_nonneg_right h0 hφ.le) (by linarith) (by linarith)
      (mul_nonneg ha.le hφ.le)
  have i2 : a ^ 3 ≤ a1 * a1 * a1 := by
    rw [show a1 * a1 * a1 = a1 ^ 3 by ring]
    exact pow_le_pow_left₀ ha.le h1 3
  have i3 := mul_le_mul_of_nonneg_left i2 hφ.le
  unfold phi
  nlinarith

lemma targetB_false_le (hok : targetOk = true) {pa0 pa1 pm0 pm1 : ℕ} {a ξ : ℝ}
    (hpa : 0 < pt pa0) (ha0 : pt pa0 ≤ a) (ha1 : a ≤ pt pa1) (hξ0 : pt pm0 ≤ ξ)
    (hξ1 : ξ ≤ pt pm1) :
    (targetB false pa0 pa1 pm0 pm1).lo.val / S ≤ masterTarget a (a * ξ) := by
  unfold targetOk at hok
  rw [Bool.and_eq_true] at hok
  obtain ⟨hP3, -⟩ := hok
  have hφ := phi0_mem
  have hφp := phi0_pos
  have hpi := Real.pi_pos
  have ha : 0 < a := hpa.trans_le ha0
  have hm0 := pt_nonneg pm0
  have hx0 : pt pa0 * pt pm0 ≤ a * ξ := mul_le_mul ha0 hξ0 hm0 ha.le
  have hx1 : a * ξ ≤ pt pa1 * pt pm1 := mul_le_mul ha1 hξ1 (hm0.trans hξ0) (ha.le.trans ha1)
  have hx00 : 0 ≤ pt pa0 * pt pm0 := mul_nonneg hpa.le hm0
  have hX0 := mem_mul (mem_pt pa0) (mem_pt pm0)
  have hX1 := mem_mul (mem_pt pa1) (mem_pt pm1)
  obtain ⟨v, hv, hNv⟩ := exists_nHi hX1 (hx00.trans hx0) hx1
  have hball := mem_add (mem_add (mem_add
    (mem_neg (mem_divNat (mem_mul hφ (mem_mul (mem_mul (mem_pt pa1) (mem_pt pa1)) (mem_pt pa1)))
      (by norm_num : 0 < 6)))
    (mem_mul (mem_mul (mem_pt pa0) hφ) (mem_sub mem_one (mem_gaussB hX0))))
    (mem_divNat (mem_mul (mem_mul (mem_mul (mem_pt pa0) (mem_pt pa0)) hX0)
      (mem_mul hφ (mem_gaussB hX1))) (by norm_num : 0 < 3)))
    (mem_neg (mem_divB hP3 (mem_mul (mem_mul (mem_mul (mem_ivB ha0 ha1) (mem_ivB ha0 ha1))
      (mem_ivB ha0 ha1)) hv) (mem_mulNat (mem_mul pi_mem pi_mem) 3)))
  have hmem : _ ∈ targetB false pa0 pa1 pm0 pm1 := hball
  refine (lo_le_of_mem hmem).trans ?_
  have i1 := target_main hpa ha0 ha1 hx00 hx0
  have i2 : pt pa0 * pt pa0 * (pt pa0 * pt pm0) * (phi0 * gaussian (pt pa1 * pt pm1)) ≤
      a ^ 2 * (a * ξ) * phi (a * ξ) := by
    unfold phi
    have hg := gaussian_anti (hx00.trans hx0) hx1
    have hg0 := gaussian_nonneg (pt pa1 * pt pm1)
    have e1 : pt pa0 * pt pa0 ≤ a ^ 2 := by nlinarith
    have e2 := mul_le_mul e1 hx0 hx00 (sq_nonneg a)
    have e3 : phi0 * gaussian (pt pa1 * pt pm1) ≤ gaussian (a * ξ) * phi0 := by nlinarith
    exact mul_le_mul e2 e3 (mul_nonneg hφp.le hg0) (mul_nonneg (sq_nonneg a) (hx00.trans hx0))
  have i3 : a ^ 3 * gaussianN (a * ξ) / (3 * Real.pi ^ 2) ≤
      a * a * a * v / (Real.pi * Real.pi * ((3 : ℕ) : ℝ)) := by
    have : a ^ 3 * gaussianN (a * ξ) ≤ a * a * a * v := by
      rw [show a * a * a = a ^ 3 by ring]
      exact mul_le_mul_of_nonneg_left hNv (by positivity)
    rw [show Real.pi * Real.pi * ((3 : ℕ) : ℝ) = 3 * Real.pi ^ 2 by push_cast; ring]
    exact div_le_div_of_nonneg_right this (by positivity)
  unfold masterTarget
  have e6 : (((6 : ℕ) : ℝ)) = 6 := by norm_num
  have e3 : (((3 : ℕ) : ℝ)) = 3 := by norm_num
  rw [e6]
  rw [e3] at i3 ⊢
  linarith

lemma targetB_true_le (hok : targetOk = true) {pa0 pa1 pm0 pm1 : ℕ} {a ξ : ℝ}
    (hpa : 0 < pt pa0) (ha0 : pt pa0 ≤ a) (ha1 : a ≤ pt pa1) (hξ0 : pt pm0 ≤ ξ)
    (hξ1 : ξ ≤ pt pm1) :
    (targetB true pa0 pa1 pm0 pm1).lo.val / S ≤ masterTarget a (-(a * ξ)) := by
  unfold targetOk at hok
  rw [Bool.and_eq_true] at hok
  obtain ⟨hP3, -⟩ := hok
  have hφ := phi0_mem
  have hφp := phi0_pos
  have hpi := Real.pi_pos
  have ha : 0 < a := hpa.trans_le ha0
  have hm0 := pt_nonneg pm0
  have hx0 : pt pa0 * pt pm0 ≤ a * ξ := mul_le_mul ha0 hξ0 hm0 ha.le
  have hx1 : a * ξ ≤ pt pa1 * pt pm1 := mul_le_mul ha1 hξ1 (hm0.trans hξ0) (ha.le.trans ha1)
  have hx00 : 0 ≤ pt pa0 * pt pm0 := mul_nonneg hpa.le hm0
  have hX0 := mem_mul (mem_pt pa0) (mem_pt pm0)
  have hX1 := mem_mul (mem_pt pa1) (mem_pt pm1)
  obtain ⟨v, hv, hNv⟩ := exists_nLo hX0 hX1 hx00 hx0 hx1
  have hball := mem_add (mem_add (mem_add
    (mem_neg (mem_divNat (mem_mul hφ (mem_mul (mem_mul (mem_pt pa1) (mem_pt pa1)) (mem_pt pa1)))
      (by norm_num : 0 < 6)))
    (mem_mul (mem_mul (mem_pt pa0) hφ) (mem_sub mem_one (mem_gaussB hX0))))
    (mem_neg (mem_divNat (mem_mul (mem_mul (mem_mul (mem_pt pa1) (mem_pt pa1)) hX1)
      (mem_mul hφ (mem_gaussB hX0))) (by norm_num : 0 < 3))))
    (mem_divB hP3 (mem_mul (mem_mul (mem_mul (mem_ivB ha0 ha1) (mem_ivB ha0 ha1))
      (mem_ivB ha0 ha1)) hv) (mem_mulNat (mem_mul pi_mem pi_mem) 3))
  have hmem : _ ∈ targetB true pa0 pa1 pm0 pm1 := hball
  refine (lo_le_of_mem hmem).trans ?_
  have i1 := target_main hpa ha0 ha1 hx00 hx0
  have i2 : a ^ 2 * (a * ξ) * phi (a * ξ) ≤
      pt pa1 * pt pa1 * (pt pa1 * pt pm1) * (phi0 * gaussian (pt pa0 * pt pm0)) := by
    unfold phi
    have hg := gaussian_anti hx00 hx0
    have hg0 := gaussian_nonneg (a * ξ)
    have e1 : a ^ 2 ≤ pt pa1 * pt pa1 := by nlinarith
    have e2 := mul_le_mul e1 hx1 (hx00.trans hx0) (mul_self_nonneg _)
    have e3 : gaussian (a * ξ) * phi0 ≤ phi0 * gaussian (pt pa0 * pt pm0) := by nlinarith
    exact mul_le_mul e2 e3 (mul_nonneg hg0 hφp.le)
      (mul_nonneg (mul_self_nonneg _) (mul_nonneg (pt_nonneg _) (pt_nonneg _)))
  have i3 : a * a * a * v / (Real.pi * Real.pi * ((3 : ℕ) : ℝ)) ≤
      a ^ 3 * gaussianN (a * ξ) / (3 * Real.pi ^ 2) := by
    have : a * a * a * v ≤ a ^ 3 * gaussianN (a * ξ) := by
      rw [show a * a * a = a ^ 3 by ring]
      exact mul_le_mul_of_nonneg_left hNv (by positivity)
    rw [show Real.pi * Real.pi * ((3 : ℕ) : ℝ) = 3 * Real.pi ^ 2 by push_cast; ring]
    exact div_le_div_of_nonneg_right this (by positivity)
  unfold masterTarget
  rw [phi_neg, gaussianN_neg]
  have e6 : (((6 : ℕ) : ℝ)) = 6 := by norm_num
  have e3 : (((3 : ℕ) : ℝ)) = 3 := by norm_num
  have e7 : a ^ 2 * -(a * ξ) * phi (a * ξ) / 3 = -(a ^ 2 * (a * ξ) * phi (a * ξ) / 3) := by ring
  have e8 : a ^ 3 * -gaussianN (a * ξ) / (3 * Real.pi ^ 2) =
      -(a ^ 3 * gaussianN (a * ξ) / (3 * Real.pi ^ 2)) := by ring
  rw [e6, e7, e8]
  rw [e3] at i3 ⊢
  linarith

/-! ### The tails -/

lemma tails_le (hPI : invOk PI = true) {pa0 pa1 : ℕ} (hinv : invOk (ivB pa0 pa1) = true) {a : ℝ}
    (ha0 : pt pa0 ≤ a) (ha1 : a ≤ pt pa1) (ha : 0 < a) :
    tailBound a + aliasTailBound a ≤ (tailsB pa0 pa1).hi.val / S := by
  have hpi := Real.pi_pos
  have hθ := crossoverRoot_bounds
  have hA := mem_ivB ha0 ha1
  have hIA := mem_invB hinv hA
  have hIPI : Real.pi⁻¹ ∈ IPI := mem_invB hPI pi_mem
  have hA2 := mem_mul hA hA
  have hI2 := mem_mul hIPI hIPI
  have hI3 := mem_mul hI2 hIPI
  have htail := mem_mul (mem_mul hA2 (mem_add (mem_add (mem_add (mem_mulNat hI2 2) hI3)
    (mem_divNat (mem_mulNat hIPI 2) (by norm_num : 0 < 3)))
    (mem_divNat (mem_mul hA2 hI3) (by norm_num : 0 < 3)))) (mem_gaussB (mem_mul pi_mem hIA))
  have hali := mem_mul (mem_mul (mem_mul hA hIPI) (mem_mul hA hIPI))
    (mem_gaussB (mem_mul (mem_sub pi_mem (mem_ofRat 18 (by norm_num : 0 < 10))) hIA))
  have hsum := mem_add htail hali
  refine le_trans ?_ (le_hi_of_mem hsum)
  have e18 : (((18 : ℕ) : ℝ) / ((10 : ℕ) : ℝ)) = 9 / 5 := by norm_num
  have e2 : (((2 : ℕ) : ℝ)) = 2 := by norm_num
  have e3 : (((3 : ℕ) : ℝ)) = 3 := by norm_num
  rw [e18, e2, e3]
  have h1 : tailBound a = a * a * (Real.pi⁻¹ * Real.pi⁻¹ * 2 + Real.pi⁻¹ * Real.pi⁻¹ * Real.pi⁻¹ +
      Real.pi⁻¹ * 2 / 3 + a * a * (Real.pi⁻¹ * Real.pi⁻¹ * Real.pi⁻¹) / 3) *
      gaussian (Real.pi * a⁻¹) := by
    unfold tailBound
    rw [← div_eq_mul_inv]
    field_simp
    ring
  have h2 : aliasTailBound a ≤ a * Real.pi⁻¹ * (a * Real.pi⁻¹) *
      gaussian ((Real.pi - 9 / 5) * a⁻¹) := by
    unfold aliasTailBound
    rw [show (a / Real.pi) ^ 2 = a * Real.pi⁻¹ * (a * Real.pi⁻¹) by rw [div_eq_mul_inv]; ring]
    apply mul_le_mul_of_nonneg_left _ (by positivity)
    apply gaussian_anti
    · have : 0 ≤ Real.pi - 9 / 5 := by linarith [Real.pi_gt_three]
      positivity
    · rw [← div_eq_mul_inv]
      exact div_le_div_of_nonneg_right (by linarith) ha.le
  linarith

/-! ### The box theorem -/

lemma spAdd_val (x y : SP) : (spAdd x y).val = x.val + y.val := by
  simp only [spAdd, SP.val, Nat.add_eq]; push_cast; ring

lemma spMulS_val (x : SP) : (spMulS x).val = x.val * S := by
  simp only [spMulS, SP.val, Nat.mul_eq]; push_cast; ring

lemma boxOk_spec {lower : Bool} {pa0 pa1 pm0 pm1 : ℕ} {grid : List ℕ}
    (h : boxOk lower pa0 pa1 pm0 pm1 grid = true) :
    0 < pa0 ∧ pa1 ≤ S ∧ 0 < pm0 ∧ invOk (exact pa0 0) = true ∧ invOk (exact pa1 0) = true ∧
      invOk (ivB pa0 pa1) = true ∧ targetOk = true ∧
      (sumCells (xiB lower pm0 pm1) (invB (exact pa0 0)) (invB (exact pa1 0)) 0 grid).2 = true ∧
      lastOf 0 grid = S ∧
      (sumCells (xiB lower pm0 pm1) (invB (exact pa0 0)) (invB (exact pa1 0)) 0 grid).1.val +
        (tailsB pa0 pa1).hi.val * S ≤ (targetB lower pa0 pa1 pm0 pm1).lo.val * S := by
  unfold boxOk at h
  simp only [Bool.and_eq_true] at h
  obtain ⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨⟨h1, -⟩, h3⟩, h4⟩, -⟩, h6⟩, h7⟩, h8⟩, h9⟩, h10⟩, h11⟩, h12⟩ := h
  refine ⟨Nat.blt_eq.mp h1, Nat.ble_eq.mp h3, Nat.blt_eq.mp h4, h6, h7, h8, h9, h10,
    Nat.eq_of_beq_eq_true h11, ?_⟩
  have := SP.le_val h12
  rw [spAdd_val, spMulS_val, spMulS_val] at this
  exact this

lemma mem_xiB {lower : Bool} {pm0 pm1 : ℕ} {ξ : ℝ} (hξ0 : pt pm0 ≤ ξ) (hξ1 : ξ ≤ pt pm1) :
    (bif lower then -ξ else ξ) ∈ xiB lower pm0 pm1 := by
  cases lower
  · apply mem_cond
    · intro h; exact absurd h (by simp)
    · intro _
      apply mem_ofLoHi_of_le
      · simpa [SP.val, pt] using hξ0
      · simpa [SP.val, pt] using hξ1
  · apply mem_cond
    · intro _
      apply mem_ofLoHi_of_le
      · simp only [SP.val, Nat.cast_zero, zero_sub, neg_div]
        have : ξ ≤ (pm1 : ℝ) / S := hξ1
        show -((pm1 : ℝ) / S) ≤ -ξ
        linarith
      · simp only [SP.val, Nat.cast_zero, zero_sub, neg_div]
        have : (pm0 : ℝ) / S ≤ ξ := hξ0
        show -ξ ≤ -((pm0 : ℝ) / S)
        linarith
    · intro h; exact absurd h (by simp)

theorem boxOk_master {lower : Bool} {pa0 pa1 pm0 pm1 : ℕ} {grid : List ℕ}
    (h : boxOk lower pa0 pa1 pm0 pm1 grid = true) {a ξ y : ℝ} (ha0 : pt pa0 ≤ a)
    (ha1 : a ≤ pt pa1) (hξ0 : pt pm0 ≤ ξ) (hξ1 : ξ ≤ pt pm1)
    (hy : y / a = bif lower then -ξ else ξ)
    (htarget : (targetB lower pa0 pa1 pm0 pm1).lo.val / S ≤ masterTarget a y) :
    JUpper a y ≤ c a + c y := by
  obtain ⟨hpa0, hpa1, hpm0, h6, h7, h8, h9, h10, h11, h12⟩ := boxOk_spec h
  have hpa : 0 < pt pa0 := pt_pos hpa0
  have ha : 0 < a := hpa.trans_le ha0
  have ha1' : a ≤ 1 := ha1.trans (pt_le_one hpa1)
  have hA : AData (invB (exact pa0 0)) (invB (exact pa1 0)) (pt pa0) (pt pa1) a :=
    ⟨hpa, ha0, ha1, by rw [one_div]; exact mem_invB h6 (mem_pt pa0),
      by rw [one_div]; exact mem_invB h7 (mem_pt pa1)⟩
  have hξm := mem_xiB (lower := lower) hξ0 hξ1
  have hξ0' : (bif lower then -ξ else ξ) ≠ 0 := by
    have : 0 < ξ := (pt_pos hpm0).trans_le hξ0
    cases lower
    · exact this.ne'
    · exact neg_ne_zero.mpr this.ne'
  have hint := sumCells_sound hA ha1' hξm hξ0' hy grid 0 h10 (by rw [h11])
  rw [h11, pt_S, show pt 0 = 0 by simp [pt]] at hint
  have hm := master_le (y := y) ha ha1'
  have ht := tails_le (by unfold targetOk at h9; rw [Bool.and_eq_true] at h9; exact h9.2) h8
    ha0 ha1 ha
  have hS := S_pos
  have h12' : (sumCells (xiB lower pm0 pm1) (invB (exact pa0 0)) (invB (exact pa1 0)) 0 grid).1.val
      / (S : ℝ) ^ 2 + (tailsB pa0 pa1).hi.val / S ≤ (targetB lower pa0 pa1 pm0 pm1).lo.val / S := by
    rw [div_add_div _ _ (by positivity) hS.ne', div_le_div_iff₀ (by positivity) hS]
    nlinarith
  linarith

theorem boxOk_upper {pa0 pa1 pm0 pm1 : ℕ} {grid : List ℕ}
    (h : boxOk false pa0 pa1 pm0 pm1 grid = true) {a ξ : ℝ} (ha0 : pt pa0 ≤ a)
    (ha1 : a ≤ pt pa1) (hξ0 : pt pm0 ≤ ξ) (hξ1 : ξ ≤ pt pm1) :
    JUpper a (a * ξ) ≤ c a + c (a * ξ) := by
  obtain ⟨hpa0, -, -, -, -, -, h9, -⟩ := boxOk_spec h
  have ha : 0 < a := (pt_pos hpa0).trans_le ha0
  refine boxOk_master h ha0 ha1 hξ0 hξ1 ?_ (targetB_false_le h9 (pt_pos hpa0) ha0 ha1 hξ0 hξ1)
  rw [cond_false]; field_simp

theorem boxOk_lower {pa0 pa1 pm0 pm1 : ℕ} {grid : List ℕ}
    (h : boxOk true pa0 pa1 pm0 pm1 grid = true) {a ξ : ℝ} (ha0 : pt pa0 ≤ a)
    (ha1 : a ≤ pt pa1) (hξ0 : pt pm0 ≤ ξ) (hξ1 : ξ ≤ pt pm1) :
    JUpper a (-(a * ξ)) ≤ c a + c (-(a * ξ)) := by
  obtain ⟨hpa0, -, -, -, -, -, h9, -⟩ := boxOk_spec h
  have ha : 0 < a := (pt_pos hpa0).trans_le ha0
  refine boxOk_master h ha0 ha1 hξ0 hξ1 ?_ (targetB_true_le h9 (pt_pos hpa0) ha0 ha1 hξ0 hξ1)
  rw [cond_true]; field_simp; ring

end

end KellerKlein.Num
