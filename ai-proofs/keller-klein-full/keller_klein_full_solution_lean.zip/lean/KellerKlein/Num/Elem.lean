import KellerKlein.Num.Series

/-!
# Elementary functions on balls

`π`, `cos (π c)` and `sin (π c)` at dyadic points and on balls (the "δ-trick"), `exp`
(argument halving, Taylor, repeated squaring, clamping below `-45`), `log` on `(0, 1]`,
`sqrt`, and the reciprocal.  Each function has a soundness lemma.
-/

namespace KellerKlein.Num

open Ball

def one : Ball := ⟨S, 0, 0⟩
def zero : Ball := ⟨0, 0, 0⟩
/-- The interval `[-1, 1]`. -/
def unitBall : Ball := ⟨0, 0, S⟩

lemma mem_one : (1 : ℝ) ∈ one := by rw [Ball.mem_def]; simp [one]
lemma mem_zero : (0 : ℝ) ∈ zero := by rw [Ball.mem_def]; simp [zero]
lemma mem_unitBall {x : ℝ} (hx : |x| ≤ 1) : x ∈ unitBall := by
  rw [Ball.mem_def]; simp only [unitBall, Nat.cast_zero, sub_zero]
  rw [abs_mul, abs_of_pos S_pos]
  nlinarith [S_pos]

/-- A bound for `|x| · S` on a ball. -/
@[inline] def Ball.mag (a : Ball) : ℕ := Nat.add (Nat.add a.p a.n) a.r

lemma abs_mul_S_le_mag {a : Ball} {x : ℝ} (hx : x ∈ a) : |x| * S ≤ a.mag := by
  rw [Ball.mem_def] at hx
  simp only [Ball.mag, Nat.add_eq]; push_cast
  have h1 : |x| * S = |x * S| := by rw [abs_mul, abs_of_pos S_pos]
  have h2 : |x * S| ≤ |x * S - ((a.p : ℝ) - a.n)| + |(a.p : ℝ) - a.n| := by
    have := abs_add_le (x * S - ((a.p : ℝ) - a.n)) ((a.p : ℝ) - a.n)
    simpa using this
  have h3 : |(a.p : ℝ) - a.n| ≤ a.p + a.n := by
    have := Nat.cast_nonneg (α := ℝ) a.p; have := Nat.cast_nonneg (α := ℝ) a.n
    rw [abs_le]; constructor <;> linarith
  linarith

lemma abs_le_of_mag {a : Ball} {x : ℝ} (hx : x ∈ a) {M : ℕ} (hM : a.mag ≤ M) :
    |x| ≤ (M : ℝ) / S := by
  rw [le_div_iff₀ S_pos]
  have h := abs_mul_S_le_mag hx
  have : (a.mag : ℝ) ≤ M := by exact_mod_cast hM
  linarith

/-- Containment test. -/
@[inline] def subB (a b : Ball) : Bool := SP.le b.lo a.lo && SP.le a.hi b.hi

lemma mem_of_subB {a b : Ball} (h : subB a b = true) {x : ℝ} (hx : x ∈ a) : x ∈ b := by
  simp only [subB, Bool.and_eq_true] at h
  rw [mem_iff_lohi] at hx ⊢
  exact ⟨(SP.le_val h.1).trans hx.1, hx.2.trans (SP.le_val h.2)⟩

lemma mem_hull_of {a b : Ball} {x y z : ℝ} (hy : y ∈ a) (hz : z ∈ b) (h1 : y ≤ x) (h2 : x ≤ z) :
    x ∈ hull a b := by
  rw [mem_iff_lohi] at hy hz
  apply mem_ofLoHi
  · rw [SP.min_val]
    exact min_le_of_left_le (hy.1.trans (mul_le_mul_of_nonneg_right h1 S_pos.le))
  · rw [SP.max_val]
    exact le_max_of_le_right ((mul_le_mul_of_nonneg_right h2 S_pos.le).trans hz.2)

/-! ### π -/

def PI : Ball := ⟨57952155664616982739, 0, 1⟩

lemma pi_mem : Real.pi ∈ PI := by
  rw [Ball.mem_def]
  simp only [PI, S, Nat.cast_ofNat, Nat.cast_zero, sub_zero, Nat.cast_one]
  have h1 := Real.pi_gt_d20
  have h2 := Real.pi_lt_d20
  rw [abs_le]; constructor <;> nlinarith

/-! ### Cosine and sine near zero -/

def cosSer (Z : Ball) : Ball :=
  serAux (mul Z Z) (fun j => (2 * j + 1) * (2 * j + 2)) (fun _ => 1) true 12 0 one zero

def sinSer (Z : Ball) : Ball :=
  serAux (mul Z Z) (fun j => (2 * j + 2) * (2 * j + 3)) (fun _ => 1) true 12 0 Z zero

lemma cosSer_mem {Z : Ball} {z : ℝ} (hz : z ∈ Z) : cosPoly 12 z ∈ cosSer Z := by
  have h := serAux_mem (mul Z Z) (fun j => (2 * j + 1) * (2 * j + 2)) (fun _ => 1)
    (fun j => by positivity) (fun _ => Nat.one_pos) true (mem_mul hz hz)
    (fun j => z ^ (2 * j) / (2 * j).factorial) (by
      intro j
      dsimp only
      rw [show 2 * (j + 1) = 2 * j + 1 + 1 by ring, Nat.factorial_succ, Nat.factorial_succ]
      push_cast
      have : ((2 * j).factorial : ℝ) ≠ 0 := by positivity
      field_simp
      ring) 12 0 one zero 0 (by simpa using mem_one) mem_zero
  convert h using 1
  simp only [zero_add, Nat.cast_one, div_one, sgnR_true, cosPoly]
  apply Finset.sum_congr rfl; intro j _; ring

lemma sinSer_mem {Z : Ball} {z : ℝ} (hz : z ∈ Z) : sinPoly 12 z ∈ sinSer Z := by
  have h := serAux_mem (mul Z Z) (fun j => (2 * j + 2) * (2 * j + 3)) (fun _ => 1)
    (fun j => by positivity) (fun _ => Nat.one_pos) true (mem_mul hz hz)
    (fun j => z ^ (2 * j + 1) / (2 * j + 1).factorial) (by
      intro j
      dsimp only
      rw [show 2 * (j + 1) + 1 = 2 * j + 1 + 1 + 1 by ring, Nat.factorial_succ, Nat.factorial_succ]
      push_cast
      have : ((2 * j + 1).factorial : ℝ) ≠ 0 := by positivity
      field_simp
      ring) 12 0 Z zero 0 (by simpa using hz) mem_zero
  convert h using 1
  simp only [zero_add, Nat.cast_one, div_one, sgnR_true, sinPoly]
  apply Finset.sum_congr rfl; intro j _; ring

lemma mem_of_abs_sub_le {B : Ball} {x y : ℝ} (hy : y ∈ B) (h : |x - y| ≤ 1 / S) :
    x ∈ widen B 1 := by
  rw [Ball.mem_def] at hy ⊢
  simp only [widen, Nat.add_eq]; push_cast
  have h2 : |x * S - y * S| ≤ 1 := by
    rw [← sub_mul, abs_mul, abs_of_pos S_pos]
    have := mul_le_mul_of_nonneg_right h S_pos.le
    rwa [div_mul_cancel₀ _ S_pos.ne'] at this
  calc |x * S - ((B.p : ℝ) - B.n)| ≤ |x * S - y * S| + |y * S - ((B.p : ℝ) - B.n)| :=
        abs_sub_le _ _ _
    _ ≤ 1 + B.r := by linarith
    _ = _ := by ring

/-- `cos z` for `|z| ≤ 1` (falls back to `[-1, 1]`). -/
def cosCore (Z : Ball) : Ball := bif Nat.ble Z.mag S then widen (cosSer Z) 1 else unitBall

def sinCore (Z : Ball) : Ball := bif Nat.ble Z.mag S then widen (sinSer Z) 1 else unitBall

lemma mem_cosCore {Z : Ball} {z : ℝ} (hz : z ∈ Z) : Real.cos z ∈ cosCore Z := by
  unfold cosCore
  cases h : Nat.ble Z.mag S
  · exact mem_unitBall (Real.abs_cos_le_one z)
  · simp only [cond_true]
    have hz1 : |z| ≤ 1 := by
      have := abs_le_of_mag hz (Nat.ble_eq.mp h)
      rwa [div_self S_pos.ne'] at this
    exact mem_of_abs_sub_le (cosSer_mem hz) (abs_cos_sub_cosPoly_le hz1)

lemma mem_sinCore {Z : Ball} {z : ℝ} (hz : z ∈ Z) : Real.sin z ∈ sinCore Z := by
  unfold sinCore
  cases h : Nat.ble Z.mag S
  · exact mem_unitBall (Real.abs_sin_le_one z)
  · simp only [cond_true]
    have hz1 : |z| ≤ 1 := by
      have := abs_le_of_mag hz (Nat.ble_eq.mp h)
      rwa [div_self S_pos.ne'] at this
    exact mem_of_abs_sub_le (sinSer_mem hz) (abs_sin_sub_sinPoly_le hz1)

/-! ### `cos (π c)`, `sin (π c)` at a dyadic point -/

lemma cos_add_quarter (z : ℝ) (m : ℕ) :
    Real.cos (z + m * (Real.pi / 2)) =
      if m % 4 = 0 then Real.cos z else if m % 4 = 1 then -Real.sin z
      else if m % 4 = 2 then -Real.cos z else Real.sin z := by
  have hm : (m : ℝ) * (Real.pi / 2) = ((m % 4 : ℕ) : ℝ) * (Real.pi / 2) + (m / 4 : ℕ) * (2 * Real.pi) := by
    have := Nat.mod_add_div m 4
    have h' : (m : ℝ) = ((m % 4 : ℕ) : ℝ) + 4 * ((m / 4 : ℕ) : ℝ) := by exact_mod_cast this.symm
    rw [h']; ring
  rw [hm, ← add_assoc, Real.cos_add_nat_mul_two_pi]
  have h4 : m % 4 < 4 := Nat.mod_lt m (by norm_num)
  interval_cases h : m % 4
  · simp
  · simp [Real.cos_add_pi_div_two]
  · simp only [Nat.cast_ofNat]
    rw [show z + 2 * (Real.pi / 2) = z + Real.pi by ring, Real.cos_add_pi]; simp
  · simp only [Nat.cast_ofNat]
    rw [show z + 3 * (Real.pi / 2) = (z + Real.pi) + Real.pi / 2 by ring,
      Real.cos_add_pi_div_two, Real.sin_add_pi]; simp

lemma sin_add_quarter (z : ℝ) (m : ℕ) :
    Real.sin (z + m * (Real.pi / 2)) =
      if m % 4 = 0 then Real.sin z else if m % 4 = 1 then Real.cos z
      else if m % 4 = 2 then -Real.sin z else -Real.cos z := by
  have hm : (m : ℝ) * (Real.pi / 2) = ((m % 4 : ℕ) : ℝ) * (Real.pi / 2) + (m / 4 : ℕ) * (2 * Real.pi) := by
    have := Nat.mod_add_div m 4
    have h' : (m : ℝ) = ((m % 4 : ℕ) : ℝ) + 4 * ((m / 4 : ℕ) : ℝ) := by exact_mod_cast this.symm
    rw [h']; ring
  rw [hm, ← add_assoc, Real.sin_add_nat_mul_two_pi]
  have h4 : m % 4 < 4 := Nat.mod_lt m (by norm_num)
  interval_cases h : m % 4
  · simp
  · simp [Real.sin_add_pi_div_two]
  · simp only [Nat.cast_ofNat]
    rw [show z + 2 * (Real.pi / 2) = z + Real.pi by ring, Real.sin_add_pi]; simp
  · simp only [Nat.cast_ofNat]
    rw [show z + 3 * (Real.pi / 2) = (z + Real.pi) + Real.pi / 2 by ring,
      Real.sin_add_pi_div_two, Real.cos_add_pi]; simp

/-- Quadrant selection. -/
@[inline] def quad (q : ℕ) (a b c d : Ball) : Ball :=
  bif Nat.beq q 0 then a else bif Nat.beq q 1 then b else bif Nat.beq q 2 then c else d

lemma mem_quad {q : ℕ} (hq : q < 4) {a b c d : Ball} {x0 x1 x2 x3 : ℝ}
    (h0 : x0 ∈ a) (h1 : x1 ∈ b) (h2 : x2 ∈ c) (h3 : x3 ∈ d) :
    (if q = 0 then x0 else if q = 1 then x1 else if q = 2 then x2 else x3) ∈ quad q a b c d := by
  unfold quad
  interval_cases q <;> simpa

/-- `(cos (π v / S), sin (π v / S))` using the quarter-period shift `m`. -/
def trigShift (v m : ℕ) : Ball × Ball :=
  let Z := mul PI (norm v (Nat.mul m 9223372036854775808) 0)
  let C := cosCore Z
  let Sn := sinCore Z
  let q := m % 4
  (quad q C (neg Sn) (neg C) Sn, quad q Sn C (neg Sn) (neg C))

lemma trigShift_mem (v m : ℕ) :
    Real.cos (Real.pi * ((v : ℝ) / S)) ∈ (trigShift v m).1 ∧
      Real.sin (Real.pi * ((v : ℝ) / S)) ∈ (trigShift v m).2 := by
  have hy : ((v : ℝ) - (Nat.mul m 9223372036854775808 : ℕ)) / S ∈
      norm v (Nat.mul m 9223372036854775808) 0 := by
    rw [mem_norm, div_mul_cancel₀ _ S_pos.ne']; simp
  have hz := mem_mul pi_mem hy
  have hC := mem_cosCore hz
  have hS := mem_sinCore hz
  have hSne : (S : ℝ) ≠ 0 := S_pos.ne'
  have hkey : Real.pi * ((v : ℝ) / S) =
      Real.pi * (((v : ℝ) - (Nat.mul m 9223372036854775808 : ℕ)) / S) + m * (Real.pi / 2) := by
    have h2 : ((Nat.mul m 9223372036854775808 : ℕ) : ℝ) = m * ((S : ℝ) / 2) := by
      simp only [Nat.mul_eq]; push_cast; rw [S_eq]; norm_num
    rw [h2]; field_simp; ring
  have hq : m % 4 < 4 := Nat.mod_lt m (by norm_num)
  refine ⟨?_, ?_⟩
  · rw [hkey, cos_add_quarter]
    exact mem_quad hq hC (mem_neg hS) (mem_neg hC) hS
  · rw [hkey, sin_add_quarter]
    exact mem_quad hq hS hC (mem_neg hS) (mem_neg hC)

@[inline] def trigFix (b : Bool) (t : Ball × Ball) : Ball × Ball :=
  (t.1, bif b then neg t.2 else t.2)

lemma trigFix_fst (b : Bool) (t : Ball × Ball) : (trigFix b t).1 = t.1 := rfl
lemma trigFix_snd_false (t : Ball × Ball) : (trigFix false t).2 = t.2 := rfl
lemma trigFix_snd_true (t : Ball × Ball) : (trigFix true t).2 = neg t.2 := rfl

/-- `(cos (π c), sin (π c))` for the dyadic `c = (p - n)/S`. -/
def trigPt (p n : ℕ) : Ball × Ball :=
  trigFix (Nat.blt p n) (trigShift (Nat.add (Nat.sub p n) (Nat.sub n p))
    (Nat.shiftRight (Nat.add (Nat.add (Nat.sub p n) (Nat.sub n p)) 4611686018427387904) 63))

lemma trigPt_mem (p n : ℕ) :
    Real.cos (Real.pi * (((p : ℝ) - n) / S)) ∈ (trigPt p n).1 ∧
      Real.sin (Real.pi * (((p : ℝ) - n) / S)) ∈ (trigPt p n).2 := by
  rw [trigPt]
  obtain ⟨hc, hs⟩ := trigShift_mem (Nat.add (Nat.sub p n) (Nat.sub n p))
    (Nat.shiftRight (Nat.add (Nat.add (Nat.sub p n) (Nat.sub n p)) 4611686018427387904) 63)
  generalize trigShift (Nat.add (Nat.sub p n) (Nat.sub n p))
    (Nat.shiftRight (Nat.add (Nat.add (Nat.sub p n) (Nat.sub n p)) 4611686018427387904) 63) = t
    at hc hs ⊢
  have hvabs : ((Nat.add (Nat.sub p n) (Nat.sub n p) : ℕ) : ℝ) = |(p : ℝ) - n| := by
    simp only [Nat.add_eq, Nat.sub_eq]
    rcases le_total p n with h | h
    · rw [Nat.sub_eq_zero_of_le h, zero_add, Nat.cast_sub h, abs_of_nonpos (by
        have : (p : ℝ) ≤ n := by exact_mod_cast h
        linarith)]; ring
    · rw [Nat.sub_eq_zero_of_le h, add_zero, Nat.cast_sub h, abs_of_nonneg (by
        have : (n : ℝ) ≤ p := by exact_mod_cast h
        linarith)]
  rw [hvabs] at hc hs
  rw [trigFix_fst]
  refine ⟨?_, ?_⟩
  · have : Real.cos (Real.pi * (((p : ℝ) - n) / S)) = Real.cos (Real.pi * (|(p : ℝ) - n| / S)) := by
      rcases le_total 0 ((p : ℝ) - n) with h | h
      · rw [abs_of_nonneg h]
      · rw [abs_of_nonpos h, neg_div, mul_neg, Real.cos_neg]
    rw [this]; exact hc
  · cases hb : Nat.blt p n
    · rw [trigFix_snd_false]
      have h : (n : ℝ) ≤ p := by
        rw [← Bool.not_eq_true, Nat.blt_eq] at hb
        exact_mod_cast (not_lt.mp hb)
      rw [show ((p : ℝ) - n) = |(p : ℝ) - n| by rw [abs_of_nonneg (by linarith)]]
      exact hs
    · rw [trigFix_snd_true]
      have h : (p : ℝ) < n := by
        rw [Nat.blt_eq] at hb
        exact_mod_cast hb
      rw [show ((p : ℝ) - n) = -|(p : ℝ) - n| by rw [abs_of_neg (by linarith)]; ring,
        neg_div, mul_neg, Real.sin_neg]
      exact mem_neg hs

/-! ### `cos (π w)`, `sin (π w)` on a ball (the δ-trick) -/

/-- `(cos (π w), sin (π w))` for all `w` in the ball `W`. -/
def trigBox (W : Ball) : Ball × Ball :=
  let t := trigPt W.p W.n
  let E := mul PI (exact W.r 0)
  let CD := hull (sub one (shr (mul E E) 1)) one
  let SD : Ball := ⟨0, 0, Nat.add E.p E.r⟩
  (sub (mul t.1 CD) (mul t.2 SD), add (mul t.2 CD) (mul t.1 SD))

lemma trigBox_mem {W : Ball} {w : ℝ} (hw : w ∈ W) :
    Real.cos (Real.pi * w) ∈ (trigBox W).1 ∧ Real.sin (Real.pi * w) ∈ (trigBox W).2 := by
  simp only [trigBox]
  obtain ⟨hc, hs⟩ := trigPt_mem W.p W.n
  set c : ℝ := ((W.p : ℝ) - W.n) / S with hcdef
  set δ : ℝ := w - c with hδdef
  have hδ : |δ| ≤ (W.r : ℝ) / S := by
    rw [Ball.mem_def] at hw
    rw [le_div_iff₀ S_pos]
    have e1 : δ * S = w * S - ((W.p : ℝ) - W.n) := by
      rw [hδdef, hcdef, sub_mul, div_mul_cancel₀ _ S_pos.ne']
    have e2 : |δ| * S = |δ * S| := by rw [abs_mul, abs_of_pos S_pos]
    rw [e2, e1]; exact hw
  have hr : (W.r : ℝ) / S ∈ exact W.r 0 := by simpa using mem_exact W.r 0
  have hE := mem_mul pi_mem hr
  set e : ℝ := Real.pi * δ with hedef
  have he : |e| ≤ Real.pi * ((W.r : ℝ) / S) := by
    rw [hedef, abs_mul, abs_of_pos Real.pi_pos]
    exact mul_le_mul_of_nonneg_left hδ Real.pi_pos.le
  have hCD : Real.cos e ∈ hull (sub one (shr (mul (mul PI (exact W.r 0)) (mul PI (exact W.r 0))) 1)) one := by
    have h1 := mem_sub mem_one (mem_shr (mem_mul hE hE) 1)
    apply mem_hull_of h1 mem_one _ (Real.cos_le_one e)
    have h2 := Real.one_sub_sq_div_two_le_cos (x := e)
    have h3 : e ^ 2 ≤ (Real.pi * ((W.r : ℝ) / S)) * (Real.pi * ((W.r : ℝ) / S)) := by
      rw [← sq]; exact sq_le_sq' (by linarith [abs_le.mp he]) (abs_le.mp he).2
    have : (1 : ℝ) - (Real.pi * ((W.r : ℝ) / S)) * (Real.pi * ((W.r : ℝ) / S)) / 2 ^ 1 ≤ Real.cos e := by
      linarith
    exact this
  have hSD : Real.sin e ∈ (⟨0, 0, Nat.add (mul PI (exact W.r 0)).p (mul PI (exact W.r 0)).r⟩ : Ball) := by
    rw [Ball.mem_def]
    simp only [Nat.cast_zero, sub_zero, Nat.add_eq]; push_cast
    have h1 := Real.abs_sin_le_abs (x := e)
    rw [mem_iff] at hE
    have h2 : |Real.sin e * S| ≤ Real.pi * ((W.r : ℝ) / S) * S := by
      rw [abs_mul, abs_of_pos S_pos]
      exact mul_le_mul_of_nonneg_right (h1.trans he) S_pos.le
    have h3 : (0 : ℝ) ≤ (mul PI (exact W.r 0)).n := Nat.cast_nonneg _
    linarith [hE.2]
  have hw' : Real.pi * w = Real.pi * c + e := by rw [hedef, hδdef]; ring
  rw [hw', Real.cos_add, Real.sin_add]
  exact ⟨mem_sub (mem_mul hc hCD) (mem_mul hs hSD), mem_add (mem_mul hs hCD) (mem_mul hc hSD)⟩

/-! ### Exponential -/

def expSer (Z : Ball) : Ball := serAux Z (fun j => j + 1) (fun _ => 1) false 16 0 one zero

lemma expSer_mem {Z : Ball} {z : ℝ} (hz : z ∈ Z) :
    (∑ i ∈ Finset.range 16, z ^ i / i.factorial) ∈ expSer Z := by
  have h := serAux_mem Z (fun j => j + 1) (fun _ => 1) (fun j => Nat.succ_pos j)
    (fun _ => Nat.one_pos) false hz (fun j => z ^ j / j.factorial) (by
      intro j
      dsimp only
      rw [Nat.factorial_succ]; push_cast
      have : (j.factorial : ℝ) ≠ 0 := by positivity
      field_simp; ring) 16 0 one zero 0 (by simpa using mem_one) mem_zero
  convert h using 1
  simp [sgnR_false]

def sqIter : ℕ → Ball → Ball
  | 0, E => E
  | k + 1, E => sqIter k (mul E E)

lemma sqIter_mem : ∀ (k : ℕ) {E : Ball} {y : ℝ}, Real.exp y ∈ E →
    Real.exp (y * 2 ^ k) ∈ sqIter k E := by
  intro k
  induction k with
  | zero => intro E y h; simpa [sqIter] using h
  | succ k ih =>
    intro E y h
    simp only [sqIter]
    have h2 : Real.exp (2 * y) ∈ mul E E := by
      rw [show 2 * y = y + y by ring, Real.exp_add]; exact mem_mul h h
    have := ih h2
    rwa [show 2 * y * 2 ^ k = y * 2 ^ (k + 1) by ring] at this

/-- The number of halvings that bring `M` to at most `2^61` (structural recursion on the
fuel, so that the kernel can evaluate it; `Nat.log2` is defined by well-founded recursion). -/
def halvings : ℕ → ℕ → ℕ
  | 0, _ => 0
  | k + 1, M => bif Nat.ble M 2305843009213693952 then 0
      else Nat.succ (halvings k (Nat.shiftRight M 1))

lemma halvings_spec : ∀ (k M : ℕ), M / 2 ^ halvings k M ≤ max 2305843009213693952 (M / 2 ^ k) := by
  intro k
  induction k with
  | zero => intro M; simp [halvings]
  | succ k ih =>
    intro M
    simp only [halvings]
    cases h : Nat.ble M 2305843009213693952
    · simp only [cond_false]
      have h2 : Nat.shiftRight M 1 = M / 2 := by
        rw [natShiftRight_eq, Nat.shiftRight_eq_div_pow, pow_one]
      have := ih (M / 2)
      rw [h2]
      simp only [Nat.succ_eq_add_one, Nat.pow_succ', ← Nat.div_div_eq_div_mul]
      exact this
    · simp only [cond_true, pow_zero, Nat.div_one]
      exact le_max_of_le_left (Nat.ble_eq.mp h)

lemma div_halvings_le (M : ℕ) : M / 2 ^ halvings M M ≤ 2305843009213693952 := by
  refine (halvings_spec M M).trans (max_le le_rfl ?_)
  have : M < 2 ^ M := Nat.lt_two_pow_self
  rw [Nat.div_eq_of_lt this]; exact Nat.zero_le _

def expCore (X : Ball) : Ball :=
  let m := halvings X.mag X.mag
  sqIter m (widen (expSer (shr X m)) 1)

lemma shr_mag_le (X : Ball) :
    (shr X (halvings X.mag X.mag)).mag ≤ 4611686018427387904 := by
  set m := halvings X.mag X.mag
  set K := 2 ^ m with hK
  have hK0 : 0 < K := by positivity
  have hdiv : X.mag / K ≤ 2 ^ 61 := by
    have := div_halvings_le X.mag
    have e : (2 : ℕ) ^ 61 = 2305843009213693952 := by norm_num
    rw [e]; exact this
  have hsum : X.p / K + X.n / K + X.r / K ≤ X.mag / K := by
    have h1 := Nat.add_div_le_add_div X.p X.n K
    have h2 := Nat.add_div_le_add_div (X.p + X.n) X.r K
    have : X.mag = X.p + X.n + X.r := rfl
    rw [this]
    omega
  have e : (shr X m).mag = X.p / K + X.n / K + (X.r / K + 2) := by
    simp only [Ball.mag, shr, Nat.add_eq, natShiftRight_eq, Nat.shiftRight_eq_div_pow, hK]
  rw [e]
  have : (2 : ℕ) ^ 61 = 2305843009213693952 := by norm_num
  omega

lemma exp_taylor_err {z : ℝ} (hz : |z| ≤ 1 / 4) :
    |Real.exp z - ∑ i ∈ Finset.range 16, z ^ i / i.factorial| ≤ 1 / S := by
  have h := Real.exp_bound (x := z) (by linarith) (n := 16) (by norm_num)
  refine h.trans ?_
  have hp : |z| ^ 16 ≤ (1 / 4) ^ 16 := pow_le_pow_left₀ (abs_nonneg z) hz 16
  have : (1 / 4 : ℝ) ^ 16 * ((Nat.succ 16 : ℕ) / ((Nat.factorial 16 : ℕ) * (16 : ℕ))) ≤ 1 / S := by
    norm_num [Nat.factorial, S]
  calc |z| ^ 16 * ((Nat.succ 16 : ℕ) / ((Nat.factorial 16 : ℕ) * (16 : ℕ)))
      ≤ (1 / 4) ^ 16 * ((Nat.succ 16 : ℕ) / ((Nat.factorial 16 : ℕ) * (16 : ℕ))) :=
        mul_le_mul_of_nonneg_right hp (by positivity)
    _ ≤ 1 / S := this

lemma mem_expCore {X : Ball} {x : ℝ} (hx : x ∈ X) : Real.exp x ∈ expCore X := by
  unfold expCore
  set m := halvings X.mag X.mag
  have hz := mem_shr hx m
  have hz1 : |x / 2 ^ m| ≤ 1 / 4 := by
    have := abs_le_of_mag hz (shr_mag_le X)
    refine this.trans (le_of_eq ?_)
    rw [S_eq]; norm_num
  have hE := mem_of_abs_sub_le (expSer_mem hz) (exp_taylor_err hz1)
  have := sqIter_mem m hE
  rwa [div_mul_cancel₀ _ (by positivity)] at this

lemma exp_neg45_le : Real.exp (-45) ≤ 1 / S := by
  have h1 : Real.exp (-45) ≤ Real.exp (-(64 * Real.log 2)) := by
    apply Real.exp_le_exp.mpr
    have := Real.log_two_lt_d9
    linarith
  rw [show -(64 * Real.log 2) = Real.log ((2 : ℝ) ^ 64)⁻¹ by
    rw [Real.log_inv, Real.log_pow]; push_cast; ring, Real.exp_log (by positivity)] at h1
  have hS : (S : ℝ) = 2 ^ 64 := by rw [S_eq]; norm_num
  rw [hS, one_div]; exact h1

/-- `exp` on a ball (sound for every real argument). -/
def expB (X : Ball) : Ball :=
  bif SP.le X.hi (0, Nat.mul 45 S) then ⟨0, 0, 1⟩
  else bif SP.le (0, Nat.mul 45 S) X.lo then expCore X
  else ofLoHi SP.zero (expCore (ofLoHi (0, Nat.mul 45 S) X.hi)).hi

lemma neg45_val : SP.val (0, Nat.mul 45 S) = (-45 : ℝ) * S := by
  simp [SP.val, Nat.mul_eq]

lemma mem_expB_gen (F : Ball → Ball) (hF : ∀ {Y : Ball} {y : ℝ}, y ∈ Y → Real.exp y ∈ F Y)
    {X : Ball} {x : ℝ} (hx : x ∈ X) :
    Real.exp x ∈ (bif SP.le X.hi (0, Nat.mul 45 S) then ⟨0, 0, 1⟩
      else bif SP.le (0, Nat.mul 45 S) X.lo then F X
      else ofLoHi SP.zero (F (ofLoHi (0, Nat.mul 45 S) X.hi)).hi) := by
  have hxlh := mem_iff_lohi.mp hx
  cases h1 : SP.le X.hi (0, Nat.mul 45 S)
  · simp only [cond_false]
    cases h2 : SP.le (0, Nat.mul 45 S) X.lo
    · simp only [cond_false]
      have h1' := SP.lt_val h1
      rw [neg45_val] at h1'
      have hm45 : (-45 : ℝ) ∈ ofLoHi (0, Nat.mul 45 S) X.hi := by
        apply mem_ofLoHi
        · rw [neg45_val]
        · linarith
      have hE45 := hF hm45
      apply mem_ofLoHi
      · rw [SP.zero_val]; exact mul_nonneg (Real.exp_pos x).le S_pos.le
      · rcases le_total x (-45) with hle | hle
        · have := (mem_iff_lohi.mp hE45).2
          have h3 : Real.exp x * S ≤ Real.exp (-45) * S :=
            mul_le_mul_of_nonneg_right (Real.exp_le_exp.mpr hle) S_pos.le
          linarith
        · have hx' : x ∈ ofLoHi (0, Nat.mul 45 S) X.hi := by
            apply mem_ofLoHi
            · rw [neg45_val]; exact mul_le_mul_of_nonneg_right hle S_pos.le
            · exact hxlh.2
          exact (mem_iff_lohi.mp (hF hx')).2
    · simp only [cond_true]
      exact hF hx
  · simp only [cond_true]
    have h1' := SP.le_val h1
    rw [neg45_val] at h1'
    have hle : x ≤ -45 := by
      have : x * S ≤ -45 * S := by linarith [hxlh.2]
      exact le_of_mul_le_mul_right this S_pos
    rw [Ball.mem_def]
    simp only [Nat.cast_zero, sub_zero, Nat.cast_one]
    rw [abs_of_pos (mul_pos (Real.exp_pos x) S_pos)]
    have := (Real.exp_le_exp.mpr hle).trans exp_neg45_le
    rw [le_div_iff₀ S_pos] at this
    linarith

lemma mem_expB {X : Ball} {x : ℝ} (hx : x ∈ X) : Real.exp x ∈ expB X :=
  mem_expB_gen expCore mem_expCore hx

/-! ### Logarithm on `(0, 1]` -/

def LN2 : Ball := ⟨12786308645202655634, 0, 141⟩

def logSer (W : Ball) : Ball := serAux W (fun _ => 1) (fun j => j + 1) false 70 0 W zero

lemma logSer_mem {W : Ball} {w : ℝ} (hw : w ∈ W) :
    (∑ i ∈ Finset.range 70, w ^ (i + 1) / (i + 1)) ∈ logSer W := by
  have h := serAux_mem W (fun _ => 1) (fun j => j + 1) (fun _ => Nat.one_pos)
    (fun j => Nat.succ_pos j) false hw (fun j => w ^ (j + 1)) (by
      intro j; simp [pow_succ]) 70 0 W zero 0 (by simpa using hw) mem_zero
  convert h using 1
  simp [sgnR_false]

lemma log_series_err {w : ℝ} (hw : |w| ≤ 51 / 100) :
    |(∑ i ∈ Finset.range 70, w ^ (i + 1) / (i + 1)) + Real.log (1 - w)| ≤ 1 / S := by
  have h := Real.abs_log_sub_add_sum_range_le (x := w) (by linarith) 70
  refine h.trans ?_
  have hp : |w| ^ (70 + 1) ≤ ((51 : ℝ) / 100) ^ (70 + 1) := pow_le_pow_left₀ (abs_nonneg w) hw _
  have h1 : (49 : ℝ) / 100 ≤ 1 - |w| := by linarith
  have h2 : |w| ^ (70 + 1) / (1 - |w|) ≤ ((51 : ℝ) / 100) ^ (70 + 1) / ((49 : ℝ) / 100) :=
    div_le_div₀ (by positivity) hp (by norm_num) h1
  refine h2.trans ?_
  rw [S_eq]; norm_num

lemma log2_mem_series : Real.log 2 ∈ widen (logSer (exact 9223372036854775808 0)) 1 := by
  have hw : (1 / 2 : ℝ) ∈ exact 9223372036854775808 0 := by
    have h := mem_exact 9223372036854775808 0
    have e : (((9223372036854775808 : ℕ) : ℝ) - ((0 : ℕ) : ℝ)) / S = 1 / 2 := by
      rw [S_eq]; norm_num
    rwa [e] at h
  have h := logSer_mem hw
  apply mem_of_abs_sub_le h
  have := log_series_err (w := 1 / 2) (by rw [abs_of_pos (by norm_num)]; norm_num)
  rw [show (1 : ℝ) - 1 / 2 = 2⁻¹ by norm_num, Real.log_inv] at this
  rw [abs_sub_comm]
  simpa [sub_eq_add_neg] using this

lemma LN2_check : subB (widen (logSer (exact 9223372036854775808 0)) 1) LN2 = true := by
  decide +kernel

lemma log2_mem : Real.log 2 ∈ LN2 := mem_of_subB LN2_check log2_mem_series

/-- The number of doublings that bring `P ≥ 1` to at least `2^63` (structural recursion). -/
def doublings : ℕ → ℕ → ℕ
  | 0, _ => 0
  | k + 1, P => bif Nat.ble 9223372036854775808 P then 0
      else Nat.succ (doublings k (Nat.shiftLeft P 1))

/-- `log x` for `x ∈ (0, 1]` (requires `logOk`). -/
def logW (X : Ball) : Ball := sub one (shl X (doublings 64 X.p))

def logOk (X : Ball) : Bool := Nat.ble (logW X).mag (S * 51 / 100)

def logB (X : Ball) : Ball :=
  sub (neg (widen (logSer (logW X)) 1)) (mulNat LN2 (doublings 64 X.p))

lemma mem_logB {X : Ball} (hok : logOk X = true) {x : ℝ} (hx : x ∈ X) :
    Real.log x ∈ logB X := by
  unfold logB
  set k := doublings 64 X.p
  have hw : 1 - x * 2 ^ k ∈ logW X := mem_sub mem_one (mem_shl hx k)
  have hw1 : |1 - x * 2 ^ k| ≤ 51 / 100 := by
    have := abs_le_of_mag hw (Nat.ble_eq.mp hok)
    refine this.trans ?_
    rw [div_le_iff₀ S_pos]
    have : ((S * 51 / 100 : ℕ) : ℝ) ≤ (S * 51 : ℕ) / 100 := Nat.cast_div_le
    push_cast at this
    linarith
  have hser := logSer_mem hw
  have herr := log_series_err hw1
  have hpos : 0 < x * 2 ^ k := by
    have := abs_le.mp hw1; linarith
  have hx0 : 0 < x := by
    have : (0 : ℝ) < 2 ^ k := by positivity
    exact pos_of_mul_pos_left hpos this.le
  have hlog : Real.log x = Real.log (1 - (1 - x * 2 ^ k)) - Real.log 2 * k := by
    rw [sub_sub_cancel, Real.log_mul hx0.ne' (by positivity), Real.log_pow]; ring
  rw [hlog]
  apply mem_sub _ (mem_mulNat log2_mem k)
  have : -(∑ i ∈ Finset.range 70, (1 - x * 2 ^ k) ^ (i + 1) / (i + 1)) ∈
      neg (logSer (logW X)) := mem_neg hser
  have h2 := mem_of_abs_sub_le this (x := Real.log (1 - (1 - x * 2 ^ k))) (by
    rw [show Real.log (1 - (1 - x * 2 ^ k)) - -∑ i ∈ Finset.range 70, (1 - x * 2 ^ k) ^ (i + 1) / (↑i + 1) =
      (∑ i ∈ Finset.range 70, (1 - x * 2 ^ k) ^ (i + 1) / (↑i + 1)) + Real.log (1 - (1 - x * 2 ^ k)) by ring]
    exact herr)
  simpa [widen, neg] using h2

/-! ### Square root and reciprocal -/

def sqrtB (X : Ball) : Ball :=
  ofLoHi (Nat.sqrt (Nat.mul (Nat.sub X.p (Nat.add X.n X.r)) S), 0)
    (Nat.add (Nat.sqrt (Nat.mul (Nat.sub (Nat.add X.p X.r) X.n) S)) 1, 0)

lemma natsqrt_le_sqrt (m : ℕ) : ((Nat.sqrt m : ℕ) : ℝ) ≤ Real.sqrt m := by
  apply Real.le_sqrt_of_sq_le
  have := Nat.sqrt_le' m
  exact_mod_cast this

lemma sqrt_lt_natsqrt (m : ℕ) : Real.sqrt m < (Nat.sqrt m : ℝ) + 1 := by
  rw [Real.sqrt_lt' (by positivity)]
  have := Nat.lt_succ_sqrt' m
  exact_mod_cast this

lemma mem_sqrtB {X : Ball} {x : ℝ} (hx : x ∈ X) : Real.sqrt x ∈ sqrtB X := by
  rw [mem_iff] at hx
  unfold sqrtB
  apply mem_ofLoHi
  · simp only [SP.val, Nat.cast_zero, sub_zero]
    rcases le_or_lt x 0 with h | h
    · have hl : Nat.sub X.p (Nat.add X.n X.r) = 0 := by
        have : (X.p : ℝ) ≤ X.n + X.r := by nlinarith [S_pos]
        have : X.p ≤ X.n + X.r := by exact_mod_cast this
        simp only [Nat.sub_eq, Nat.add_eq]; omega
      rw [hl]
      simp only [Nat.mul_eq, Nat.zero_mul, Nat.sqrt_zero, Nat.cast_zero]
      exact mul_nonneg (Real.sqrt_nonneg _) S_pos.le
    · have h1 : ((Nat.sub X.p (Nat.add X.n X.r) : ℕ) : ℝ) ≤ x * S := by
        simp only [Nat.sub_eq, Nat.add_eq]
        rcases le_total X.p (X.n + X.r) with h' | h'
        · rw [Nat.sub_eq_zero_of_le h']; simp; nlinarith [S_pos]
        · rw [Nat.cast_sub h']; push_cast; linarith
      calc ((Nat.sqrt (Nat.mul (Nat.sub X.p (Nat.add X.n X.r)) S) : ℕ) : ℝ)
          ≤ Real.sqrt ((Nat.mul (Nat.sub X.p (Nat.add X.n X.r)) S : ℕ) : ℝ) := natsqrt_le_sqrt _
        _ ≤ Real.sqrt (x * S * S) := by
          apply Real.sqrt_le_sqrt
          simp only [Nat.mul_eq]; push_cast
          exact mul_le_mul_of_nonneg_right h1 S_pos.le
        _ = Real.sqrt x * S := by
          rw [show x * S * S = x * (S * S) by ring, Real.sqrt_mul h.le, Real.sqrt_mul_self S_pos.le]
  · simp only [SP.val, Nat.cast_zero, sub_zero]
    rcases le_or_lt x 0 with h | h
    · rw [Real.sqrt_eq_zero'.mpr h, zero_mul]; positivity
    · have h1 : x * S ≤ ((Nat.sub (Nat.add X.p X.r) X.n : ℕ) : ℝ) := by
        simp only [Nat.sub_eq, Nat.add_eq]
        rcases le_total (X.p + X.r) X.n with h' | h'
        · rw [Nat.sub_eq_zero_of_le h']
          have : ((X.p + X.r : ℕ) : ℝ) ≤ X.n := by exact_mod_cast h'
          push_cast at this; nlinarith [S_pos]
        · rw [Nat.cast_sub h']; push_cast; linarith
      have := sqrt_lt_natsqrt (Nat.mul (Nat.sub (Nat.add X.p X.r) X.n) S)
      calc Real.sqrt x * S = Real.sqrt (x * S * S) := by
            rw [show x * S * S = x * (S * S) by ring, Real.sqrt_mul h.le,
              Real.sqrt_mul_self S_pos.le]
        _ ≤ Real.sqrt ((Nat.mul (Nat.sub (Nat.add X.p X.r) X.n) S : ℕ) : ℝ) := by
          apply Real.sqrt_le_sqrt
          simp only [Nat.mul_eq]; push_cast
          exact mul_le_mul_of_nonneg_right h1 S_pos.le
        _ ≤ _ := by simp only [Nat.add_eq] at this ⊢; push_cast; linarith

/-- `1/x` for a positive ball (requires `posB X`). -/
def invPos (X : Ball) : Ball :=
  ofLoHi (Nat.div (Nat.mul S S) (Nat.sub (Nat.add X.p X.r) X.n), 0)
    (Nat.add (Nat.div (Nat.mul S S) (Nat.sub X.p (Nat.add X.n X.r))) 1, 0)

lemma mem_invPos {X : Ball} (hpos : posB X = true) {x : ℝ} (hx : x ∈ X) : x⁻¹ ∈ invPos X := by
  have hx0 := pos_of_posB hpos hx
  simp only [posB, Nat.blt_eq, Nat.add_eq] at hpos
  rw [mem_iff] at hx
  set l := Nat.sub X.p (Nat.add X.n X.r)
  set h := Nat.sub (Nat.add X.p X.r) X.n
  have hl : (l : ℝ) = X.p - X.n - X.r := by
    simp only [l, Nat.sub_eq, Nat.add_eq]; rw [Nat.cast_sub (by omega)]; push_cast; ring
  have hh : (h : ℝ) = X.p - X.n + X.r := by
    simp only [h, Nat.sub_eq, Nat.add_eq]; rw [Nat.cast_sub (by omega)]; push_cast; ring
  have hl0 : 0 < l := by simp only [l, Nat.sub_eq, Nat.add_eq]; omega
  have hh0 : 0 < h := by simp only [h, Nat.sub_eq, Nat.add_eq]; omega
  have hl0' : (0 : ℝ) < l := by exact_mod_cast hl0
  have hS := S_pos
  have hxS1 : (l : ℝ) ≤ x * S := by rw [hl]; exact hx.1
  have hxS2 : x * S ≤ (h : ℝ) := by rw [hh]; exact hx.2
  have key : x⁻¹ * S = S * S / (x * S) := by field_simp; ring
  unfold invPos
  apply mem_ofLoHi
  · simp only [SP.val, Nat.cast_zero, sub_zero]
    obtain ⟨d1, _⟩ := natdiv_bounds (Nat.mul S S) h hh0
    rw [key]
    refine d1.trans ?_
    simp only [Nat.mul_eq]; push_cast
    exact div_le_div_of_nonneg_left (by positivity) (by positivity) hxS2
  · simp only [SP.val, Nat.cast_zero, sub_zero, Nat.add_eq]
    obtain ⟨_, d2⟩ := natdiv_bounds (Nat.mul S S) l hl0
    rw [key]
    push_cast
    refine le_trans ?_ d2.le
    simp only [Nat.mul_eq]; push_cast
    exact div_le_div_of_nonneg_left (by positivity) hl0' hxS1

/-- `1/x` for a ball not containing `0` (requires `invOk`). -/
def invB (X : Ball) : Ball := bif posB X then invPos X else neg (invPos (neg X))

def invOk (X : Ball) : Bool := posB X || posB (neg X)

lemma mem_invB {X : Ball} (hok : invOk X = true) {x : ℝ} (hx : x ∈ X) : x⁻¹ ∈ invB X := by
  unfold invB
  cases h : posB X
  · simp only [cond_false]
    simp only [invOk, h, Bool.false_or] at hok
    have := mem_neg (mem_invPos hok (mem_neg hx))
    rwa [inv_neg, neg_neg] at this
  · simp only [cond_true]; exact mem_invPos h hx

def divB (A B : Ball) : Ball := mul A (invB B)

lemma mem_divB {A B : Ball} (hok : invOk B = true) {x y : ℝ} (hx : x ∈ A) (hy : y ∈ B) :
    x / y ∈ divB A B := by
  rw [div_eq_mul_inv]; exact mem_mul hx (mem_invB hok hy)

end KellerKlein.Num
