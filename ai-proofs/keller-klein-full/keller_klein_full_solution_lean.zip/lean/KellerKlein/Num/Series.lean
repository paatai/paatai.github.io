import KellerKlein.Num.Ball

/-!
# Series evaluation on balls, and Taylor bounds

* `serAux`: evaluation of `Σ σ_j P_j / e j` with `P_{j+1} = P_j X / d j` on balls, with a
  single soundness theorem `serAux_mem`;
* two-sided Taylor bounds for `cos` and `sin` valid for all `y ≥ 0` (by a derivative
  induction), giving `|cos z - cosPoly 12 z| ≤ 1/S` and `|sin z - sinPoly 12 z| ≤ 1/S`
  for `|z| ≤ 1`.
-/

namespace KellerKlein.Num

open Finset

/-- Sign of the `k`-th term: alternating or constant. -/
noncomputable def sgnR (alt : Bool) (k : ℕ) : ℝ := if alt = true ∧ k % 2 = 1 then -1 else 1

lemma sgnR_true (k : ℕ) : sgnR true k = (-1) ^ k := by
  unfold sgnR
  rcases Nat.even_or_odd k with ⟨m, hm⟩ | ⟨m, hm⟩
  · subst hm
    have : (m + m) % 2 = 0 := by omega
    simp [this, ← two_mul, pow_mul]
  · subst hm
    have : (2 * m + 1) % 2 = 1 := by omega
    simp [this, pow_succ, pow_mul]

lemma sgnR_false (k : ℕ) : sgnR false k = 1 := by simp [sgnR]

/-- Series evaluation: adds `σ_j P_j / e j` for `j = i, …, i+n-1`, `P_{j+1} = P_j X / d j`. -/
def serAux (X : Ball) (d e : ℕ → ℕ) (alt : Bool) : ℕ → ℕ → Ball → Ball → Ball
  | 0, _, _, acc => acc
  | n + 1, i, P, acc =>
    serAux X d e alt n (i + 1)
      (bif Nat.beq (d i) 1 then Ball.mul P X else Ball.divNat (Ball.mul P X) (d i))
      (bif alt && Nat.beq (Nat.mod i 2) 1 then
        Ball.sub acc (bif Nat.beq (e i) 1 then P else Ball.divNat P (e i))
       else Ball.add acc (bif Nat.beq (e i) 1 then P else Ball.divNat P (e i)))

theorem serAux_mem (X : Ball) (d e : ℕ → ℕ) (hd : ∀ j, 0 < d j) (he : ∀ j, 0 < e j)
    (alt : Bool) {x : ℝ} (hx : x ∈ X) (τ : ℕ → ℝ) (hτ : ∀ j, τ (j + 1) = τ j * x / d j) :
    ∀ (n i : ℕ) (P acc : Ball) (s : ℝ), τ i ∈ P → s ∈ acc →
      s + ∑ j ∈ range n, sgnR alt (i + j) * τ (i + j) / e (i + j) ∈ serAux X d e alt n i P acc := by
  intro n
  induction n with
  | zero => intro i P acc s _ hs; simpa [serAux] using hs
  | succ n ih =>
    intro i P acc s hP hs
    simp only [serAux]
    have ht : τ i / e i ∈ (bif Nat.beq (e i) 1 then P else Ball.divNat P (e i)) := by
      cases h : Nat.beq (e i) 1
      · simp only [cond_false]; exact Ball.mem_divNat hP (he i)
      · simp only [cond_true]
        rw [Nat.beq_eq] at h; rw [h]; simpa using hP
    have hP' : τ (i + 1) ∈ (bif Nat.beq (d i) 1 then Ball.mul P X else
        Ball.divNat (Ball.mul P X) (d i)) := by
      rw [hτ i]
      cases h : Nat.beq (d i) 1
      · simp only [cond_false]; exact Ball.mem_divNat (Ball.mem_mul hP hx) (hd i)
      · simp only [cond_true]
        rw [Nat.beq_eq] at h; rw [h]; simpa using Ball.mem_mul hP hx
    have hacc : s + sgnR alt i * τ i / e i ∈
        (bif alt && Nat.beq (Nat.mod i 2) 1 then
          Ball.sub acc (bif Nat.beq (e i) 1 then P else Ball.divNat P (e i))
         else Ball.add acc (bif Nat.beq (e i) 1 then P else Ball.divNat P (e i))) := by
      cases h : (alt && Nat.beq (Nat.mod i 2) 1)
      · simp only [cond_false]
        have hs1 : sgnR alt i = 1 := by
          unfold sgnR
          rw [if_neg]
          rintro ⟨h1, h2⟩
          have h3 : Nat.beq (Nat.mod i 2) 1 = true := by rw [Nat.beq_eq]; exact h2
          rw [h1, h3] at h
          simp at h
        rw [hs1, one_mul]
        exact Ball.mem_add hs ht
      · simp only [cond_true]
        have hs1 : sgnR alt i = -1 := by
          unfold sgnR
          rw [if_pos]
          rw [Bool.and_eq_true] at h
          refine ⟨h.1, ?_⟩
          have := h.2
          rw [Nat.beq_eq] at this
          exact this
        rw [hs1, neg_one_mul, neg_div, ← sub_eq_add_neg]
        exact Ball.mem_sub hs ht
    have := ih (i + 1) _ _ _ hP' hacc
    have heq : s + ∑ j ∈ range (n + 1), sgnR alt (i + j) * τ (i + j) / e (i + j) =
        (s + sgnR alt i * τ i / e i) +
          ∑ j ∈ range n, sgnR alt (i + 1 + j) * τ (i + 1 + j) / e (i + 1 + j) := by
      rw [Finset.sum_range_succ', add_zero]
      have hre : ∑ j ∈ range n, sgnR alt (i + (j + 1)) * τ (i + (j + 1)) / e (i + (j + 1)) =
          ∑ j ∈ range n, sgnR alt (i + 1 + j) * τ (i + 1 + j) / e (i + 1 + j) := by
        apply Finset.sum_congr rfl; intro j _; rw [show i + (j + 1) = i + 1 + j by ring]
      rw [hre]; ring
    rw [heq]; exact this

/-! ### Taylor bounds for `cos` and `sin` -/

noncomputable def cosPoly (n : ℕ) (y : ℝ) : ℝ :=
  ∑ i ∈ range n, (-1) ^ i * y ^ (2 * i) / (2 * i).factorial

noncomputable def sinPoly (n : ℕ) (y : ℝ) : ℝ :=
  ∑ i ∈ range n, (-1) ^ i * y ^ (2 * i + 1) / (2 * i + 1).factorial

lemma hasDerivAt_sinPoly (n : ℕ) (y : ℝ) : HasDerivAt (sinPoly n) (cosPoly n y) y := by
  unfold sinPoly cosPoly
  have : ∀ i ∈ range n, HasDerivAt (fun y : ℝ => (-1) ^ i * y ^ (2 * i + 1) / (2 * i + 1).factorial)
      ((-1) ^ i * y ^ (2 * i) / (2 * i).factorial) y := by
    intro i _
    have h := ((hasDerivAt_pow (2 * i + 1) y).const_mul ((-1 : ℝ) ^ i)).div_const
      ((2 * i + 1).factorial : ℝ)
    convert h using 1
    rw [Nat.factorial_succ]
    push_cast
    have : ((2 * i).factorial : ℝ) ≠ 0 := by positivity
    field_simp
    ring
  have h := HasDerivAt.sum this
  convert h using 1

lemma hasDerivAt_cosPoly_succ (n : ℕ) (y : ℝ) :
    HasDerivAt (cosPoly (n + 1)) (-sinPoly n y) y := by
  have he : cosPoly (n + 1) = fun y : ℝ => (1 : ℝ) + ∑ i ∈ range n,
      (-1 : ℝ) ^ (i + 1) * y ^ (2 * i + 2) / ((2 * i + 2).factorial : ℝ) := by
    funext y
    unfold cosPoly
    rw [Finset.sum_range_succ']
    simp only [pow_zero, mul_zero, Nat.factorial_zero, Nat.cast_one, div_one, one_mul]
    rw [add_comm]
    congr 1
  rw [he]
  have : ∀ i ∈ range n, HasDerivAt
      (fun y : ℝ => (-1 : ℝ) ^ (i + 1) * y ^ (2 * i + 2) / ((2 * i + 2).factorial : ℝ))
      (-((-1 : ℝ) ^ i * y ^ (2 * i + 1) / ((2 * i + 1).factorial : ℝ))) y := by
    intro i _
    have h := ((hasDerivAt_pow (2 * i + 2) y).const_mul ((-1 : ℝ) ^ (i + 1))).div_const
      ((2 * i + 2).factorial : ℝ)
    have hfac : ((2 * i + 2).factorial : ℝ) = (2 * i + 2) * (2 * i + 1).factorial := by
      rw [show 2 * i + 2 = (2 * i + 1) + 1 by ring, Nat.factorial_succ]; push_cast; ring
    convert h using 1
    rw [show 2 * i + 2 - 1 = 2 * i + 1 by omega, hfac]
    have : ((2 * i + 1).factorial : ℝ) ≠ 0 := by positivity
    push_cast
    field_simp
    ring
  have h := (HasDerivAt.sum this).const_add 1
  convert h using 1
  unfold sinPoly; rw [Finset.sum_neg_distrib]

lemma cosPoly_zero (n : ℕ) : cosPoly (n + 1) 0 = 1 := by
  unfold cosPoly
  rw [Finset.sum_range_succ']
  simp

lemma sinPoly_zero (n : ℕ) : sinPoly n 0 = 0 := by
  unfold sinPoly
  simp

lemma nonneg_of_hasDerivAt {f f' : ℝ → ℝ} (hf : ∀ t, HasDerivAt f (f' t) t) (h0 : f 0 = 0)
    (hpos : ∀ t, 0 ≤ t → 0 ≤ f' t) {y : ℝ} (hy : 0 ≤ y) : 0 ≤ f y := by
  have hmono : MonotoneOn f (Set.Ici 0) := by
    apply monotoneOn_of_deriv_nonneg (convex_Ici 0)
    · exact fun t _ => (hf t).continuousAt.continuousWithinAt
    · exact fun t _ => (hf t).differentiableAt.differentiableWithinAt
    · intro t ht
      rw [interior_Ici] at ht
      rw [(hf t).deriv]
      exact hpos t (le_of_lt ht)
  have := hmono (Set.left_mem_Ici) (Set.mem_Ici.mpr hy) hy
  linarith

theorem cos_sin_taylor (n : ℕ) : ∀ y, 0 ≤ y →
    0 ≤ (-1) ^ (n + 1) * (Real.cos y - cosPoly (n + 1) y) ∧
      0 ≤ (-1) ^ (n + 1) * (Real.sin y - sinPoly (n + 1) y) := by
  induction n with
  | zero =>
    intro y hy
    have hc : cosPoly 1 y = 1 := by simp [cosPoly]
    have hs : sinPoly 1 y = y := by simp [sinPoly]
    rw [hc, hs]
    constructor
    · have := Real.cos_le_one y; norm_num; linarith
    · have := Real.sin_le hy; norm_num; linarith
  | succ n ih =>
    have hcos : ∀ y, 0 ≤ y →
        0 ≤ (-1) ^ (n + 1 + 1) * (Real.cos y - cosPoly (n + 1 + 1) y) := by
      intro y hy
      apply nonneg_of_hasDerivAt
        (f := fun t => (-1) ^ (n + 1 + 1) * (Real.cos t - cosPoly (n + 1 + 1) t))
        (f' := fun t => (-1) ^ (n + 1) * (Real.sin t - sinPoly (n + 1) t))
      · intro t
        have h1 := ((Real.hasDerivAt_cos t).sub (hasDerivAt_cosPoly_succ (n + 1) t)).const_mul
          ((-1 : ℝ) ^ (n + 1 + 1))
        convert h1 using 1
        ring
      · simp [cosPoly_zero]
      · intro t ht; exact (ih t ht).2
      · exact hy
    refine fun y hy => ⟨hcos y hy, ?_⟩
    apply nonneg_of_hasDerivAt
      (f := fun t => (-1) ^ (n + 1 + 1) * (Real.sin t - sinPoly (n + 1 + 1) t))
      (f' := fun t => (-1) ^ (n + 1 + 1) * (Real.cos t - cosPoly (n + 1 + 1) t))
    · intro t
      exact ((Real.hasDerivAt_sin t).sub (hasDerivAt_sinPoly (n + 1 + 1) t)).const_mul
        ((-1 : ℝ) ^ (n + 1 + 1))
    · simp [sinPoly_zero]
    · intro t ht; exact hcos t ht
    · exact hy

lemma cosPoly_neg (n : ℕ) (y : ℝ) : cosPoly n (-y) = cosPoly n y := by
  unfold cosPoly
  apply Finset.sum_congr rfl
  intro i _
  rw [pow_mul, pow_mul, neg_sq]

lemma sinPoly_neg (n : ℕ) (y : ℝ) : sinPoly n (-y) = -sinPoly n y := by
  unfold sinPoly
  rw [← Finset.sum_neg_distrib]
  apply Finset.sum_congr rfl
  intro i _
  rw [pow_succ, pow_succ, pow_mul, pow_mul, neg_sq]
  ring

lemma cosPoly_succ (n : ℕ) (y : ℝ) :
    cosPoly (n + 1) y = cosPoly n y + (-1) ^ n * y ^ (2 * n) / (2 * n).factorial := by
  unfold cosPoly; rw [Finset.sum_range_succ]

lemma sinPoly_succ (n : ℕ) (y : ℝ) :
    sinPoly (n + 1) y = sinPoly n y + (-1) ^ n * y ^ (2 * n + 1) / (2 * n + 1).factorial := by
  unfold sinPoly; rw [Finset.sum_range_succ]

lemma S_inv_bound : (1 : ℝ) / (24 : ℕ).factorial ≤ 1 / S := by
  rw [div_le_div_iff₀ (by positivity) S_pos]
  norm_num [Nat.factorial, S]

theorem abs_cos_sub_cosPoly_le {z : ℝ} (hz : |z| ≤ 1) : |Real.cos z - cosPoly 12 z| ≤ 1 / S := by
  have key : ∀ y, 0 ≤ y → y ≤ 1 → |Real.cos y - cosPoly 12 y| ≤ 1 / S := by
    intro y hy hy1
    have h1 := (cos_sin_taylor 11 y hy).1
    have h2 := (cos_sin_taylor 12 y hy).1
    rw [cosPoly_succ] at h2
    norm_num at h1 h2
    have hp : y ^ 24 ≤ 1 := pow_le_one₀ hy hy1
    have hf : y ^ 24 / (24 : ℕ).factorial ≤ 1 / S := by
      calc y ^ 24 / (24 : ℕ).factorial ≤ 1 / (24 : ℕ).factorial :=
            div_le_div_of_nonneg_right hp (by positivity)
        _ ≤ 1 / S := S_inv_bound
    have hfac : ((24 : ℕ).factorial : ℝ) = 620448401733239439360000 := by norm_num [Nat.factorial]
    rw [hfac] at hf
    rw [abs_le]; constructor <;> linarith
  rcases le_total 0 z with h | h
  · exact key z h (by rwa [abs_of_nonneg h] at hz)
  · have := key (-z) (by linarith) (by rw [abs_of_nonpos h] at hz; linarith)
    rwa [Real.cos_neg, cosPoly_neg] at this

lemma S_inv_bound' : (1 : ℝ) / (25 : ℕ).factorial ≤ 1 / S := by
  rw [div_le_div_iff₀ (by positivity) S_pos]
  norm_num [Nat.factorial, S]

theorem abs_sin_sub_sinPoly_le {z : ℝ} (hz : |z| ≤ 1) : |Real.sin z - sinPoly 12 z| ≤ 1 / S := by
  have key : ∀ y, 0 ≤ y → y ≤ 1 → |Real.sin y - sinPoly 12 y| ≤ 1 / S := by
    intro y hy hy1
    have h1 := (cos_sin_taylor 11 y hy).2
    have h2 := (cos_sin_taylor 12 y hy).2
    rw [sinPoly_succ] at h2
    norm_num at h1 h2
    have hp : y ^ 25 ≤ 1 := pow_le_one₀ hy hy1
    have hf : y ^ 25 / (25 : ℕ).factorial ≤ 1 / S := by
      calc y ^ 25 / (25 : ℕ).factorial ≤ 1 / (25 : ℕ).factorial :=
            div_le_div_of_nonneg_right hp (by positivity)
        _ ≤ 1 / S := S_inv_bound'
    have hfac : ((25 : ℕ).factorial : ℝ) = 15511210043330985984000000 := by norm_num [Nat.factorial]
    rw [hfac] at hf
    rw [abs_le]; constructor <;> linarith
  rcases le_total 0 z with h | h
  · exact key z h (by rwa [abs_of_nonneg h] at hz)
  · have := key (-z) (by linarith) (by rw [abs_of_nonpos h] at hz; linarith)
    rw [Real.sin_neg, sinPoly_neg,
      show -Real.sin z - -sinPoly 12 z = -(Real.sin z - sinPoly 12 z) by ring, abs_neg] at this
    exact this

end KellerKlein.Num
