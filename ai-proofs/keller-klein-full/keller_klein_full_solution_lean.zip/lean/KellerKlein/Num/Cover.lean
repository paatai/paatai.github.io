import KellerKlein.Num.CellDefs

/-!
# Covers of the certified ranges

A *group* is an interval of the largest coefficient `a ∈ [k₀ 2⁻³², k₁ 2⁻³²]` together with a
chain of breakpoints `ξ₀ = m₀ 2⁻¹⁶ < m₁ 2⁻¹⁶ < ⋯ < m_K 2⁻¹⁶` of the normalized location
`ξ = x / a`.  The group check runs the box check of `Num/CellDefs.lean` on every box
`[a₀, a₁] × [m_i, m_{i+1}]` with one `u`-grid, and checks that locations beyond the last
breakpoint are outside the range of the half in question:

* upper half: `φ(x_e)/x_e ≤ φ₀ (a₀ - a₀³/6)` at `x_e = a₀ ξ_K`, so that `H(x) + H(a) ≥ 1` for
  `x ≥ a ξ_K` (Mills ratio);
* lower half: `exp (-x_e²/2) ≤ φ₀ (a₀ - a₀³/6)`, so that `c(a) ≥ exp (-x²/2)` for `x ≥ a ξ_K`.

All boxes of a group share the same `a`-interval and grid. Kernel reduction shares no work
between boxes: every box check evaluates all of its cell bounds, including the parts that do
not depend on `ξ`.

The certificate modules `Num/Cert/*.lean` do not evaluate `groupOk`. Each group is checked in
slices of at most six consecutive boxes, one `decide +kernel` proof of `boxesOk` per slice, and
its end condition `endOk` is one more `decide +kernel` proof. The slices are glued in `ξ` by
`slice_upper`, `sliceU_glue` and `group_upper` (for the lower half `slice_lower`, `sliceL_glue`
and `group_lower`), and groups are glued in `a` by `cover_glue`, all in `Num/CoverSound.lean`.
`groupOk` and `groupsOk` state the whole check of a group, and of a list of groups, as a single
Boolean term; their soundness theorems are in `Num/CoverSound.lean` but are not used.
-/

namespace KellerKlein.Num

open Ball

/-! ### The `u`-grid -/

def insP (x : ℕ) : List ℕ → List ℕ
  | [] => [x]
  | y :: l => bif Nat.blt x y then x :: y :: l else bif Nat.beq x y then y :: l else y :: insP x l

def insAll : List ℕ → List ℕ → List ℕ
  | [], acc => acc
  | x :: l, acc => insAll l (insP x acc)

def rangeN : ℕ → List ℕ
  | 0 => [0]
  | k + 1 => (k + 1) :: rangeN k

/-- `2⁴⁴`: grid points are multiples of `2⁻²⁰`. -/
def gridUnit : ℕ := 17592186044416

/-- The grid: `nl` equal cells on each lobe `[0, L]`, `[1 - L, 1]` with `L ≈ 3.2 a₀`
(capped at `1/2`), the middle cell `[L, 1 - L]`, and the points `1/2`, `0.54101…`,
`0.57300…` (which bracket `θ/π`).  The leading `0` is dropped. -/
def gridGen (pa0 nl : ℕ) : List ℕ :=
  let L0 := Nat.min (Nat.div (Nat.div (Nat.mul pa0 32) 10) gridUnit) 524288
  let g1 := (rangeN nl).map (fun i => Nat.div (Nat.mul i L0) nl)
  let g3 := (rangeN nl).map (fun i => Nat.sub 1048576 (Nat.div (Nat.mul i L0) nl))
  let pts := insAll (524288 :: 567296 :: 600832 :: g1 ++ g3) []
  (pts.map (fun x => Nat.mul x gridUnit)).tail

/-! ### Groups -/

/-- `2³²`: `a`-endpoints are multiples of `2⁻³²`. -/
def aUnit : ℕ := 4294967296

/-- `2⁴⁸`: `ξ`-breakpoints are multiples of `2⁻¹⁶`. -/
def xiUnit : ℕ := 281474976710656

/-- `ξ₀ · 2¹⁶`: `1/2` for the upper half, `3/2` for the lower half. -/
def xi0 (lower : Bool) : ℕ := bif lower then 98304 else 32768

/-- All boxes `[m_i, m_{i+1}]` of a chain pass. -/
def boxesOk (lower : Bool) (pa0 pa1 : ℕ) (grid : List ℕ) : ℕ → List ℕ → Bool
  | _, [] => true
  | m, m' :: l =>
    Nat.blt m m' && boxOk lower pa0 pa1 (Nat.mul m xiUnit) (Nat.mul m' xiUnit) grid &&
      boxesOk lower pa0 pa1 grid m' l

/-- `a₀ - a₀³/6` on a point ball. -/
def cubicB (A0 : Ball) : Ball := sub A0 (divNat (mul (mul A0 A0) A0) 6)

/-- The end condition at `x_e = a₀ ξ_K`. -/
def endOk (lower : Bool) (pa0 mK : ℕ) : Bool :=
  let A0 := exact pa0 0
  let XE := mul A0 (exact (Nat.mul mK xiUnit) 0)
  bif lower then leB (gaussB XE) (mul PHI0B (cubicB A0))
  else invOk XE && leB (divB (gaussB XE) XE) (cubicB A0)

/-- The check of one group `(k₀, k₁, n_lobe, [m₀, …, m_K])`. -/
def groupOk (lower : Bool) (g : ℕ × ℕ × ℕ × List ℕ) : Bool :=
  let pa0 := Nat.mul g.1 aUnit
  let pa1 := Nat.mul g.2.1 aUnit
  let grid := gridGen pa0 g.2.2.1
  match g.2.2.2 with
  | [] => false
  | m :: l => Nat.beq m (xi0 lower) && boxesOk lower pa0 pa1 grid m l && endOk lower pa0 (lastOf m l)

/-- All groups pass. -/
def groupsOk (lower : Bool) : List (ℕ × ℕ × ℕ × List ℕ) → Bool
  | [] => true
  | g :: l => groupOk lower g && groupsOk lower l

/-- The `a`-intervals of consecutive groups are contiguous, starting at `k`; returns the
final endpoint (or `0` on failure). -/
def aChain : ℕ → List (ℕ × ℕ × ℕ × List ℕ) → ℕ
  | k, [] => k
  | k, g :: l => bif Nat.beq g.1 k && Nat.blt g.1 g.2.1 then aChain g.2.1 l else 0

end KellerKlein.Num
