import KellerKlein.Num.Cert.All

/-!
# The certified envelope inequalities

The kernel-checked covers of `Num/Cert` restated on the decimal ranges used by the induction:
(U) for `0.07 ≤ a ≤ 1/2` and (L) for `0.1 ≤ a ≤ 0.55`.
-/

namespace KellerKlein.Num

open KellerKlein

lemma pt_aUnit (k : ℕ) : pt (Nat.mul k aUnit) = (k : ℝ) / 4294967296 := by
  simp only [pt, aUnit, S, Nat.mul_eq, Nat.cast_mul, Nat.cast_ofNat]
  ring

theorem upperFourier_certified {a x : ℝ} (ha : 7 / 100 ≤ a) (ha1 : a ≤ 1 / 2)
    (hx : a / 2 ≤ x) (ht : H x + H a < 1) : JUpper a x ≤ c a + c x := by
  have h0 : pt (Nat.mul 300647710 aUnit) ≤ a := by rw [pt_aUnit]; linarith
  have h1 : a ≤ pt (Nat.mul 2147483648 aUnit) := by rw [pt_aUnit]; linarith
  exact upper_certified a h0 h1 (by linarith) (by linarith) x hx ht

theorem lowerFourier_certified {a x : ℝ} (ha : 1 / 10 ≤ a) (ha1 : a ≤ 55 / 100)
    (hx : 3 * a / 2 ≤ x) (ht : c a < Real.exp (-(x ^ 2) / 2)) :
    JUpper a (-x) ≤ c a - c x := by
  have h0 : pt (Nat.mul 429496729 aUnit) ≤ a := by rw [pt_aUnit]; linarith
  have h1 : a ≤ pt (Nat.mul 2362232013 aUnit) := by rw [pt_aUnit]; linarith
  exact lower_certified a h0 h1 (by linarith) (by linarith) x hx ht

end KellerKlein.Num
