import KellerKlein.Num.Series
import KellerKlein.Num.CellSound

/-!
# Certified values of the Gaussian distribution function

For `t ≥ 0`, `c(t) = φ₀ Σ_k (-1)^k t^{2k+1} / (2^k k! (2k+1))`, and the partial sums
alternate around `c(t)/φ₀`: `(-1)^n (c(t) - φ₀ cPoly n t) ≥ 0` (from the alternating Taylor
bounds of `e^{-u}`, `u ≥ 0`, integrated from `0` to `t`).  `cB` encloses `c(t)` on a ball
of nonnegative reals with `40`/`41` terms.
-/

namespace KellerKlein.Num

open Finset KellerKlein Ball

noncomputable section

/-- `Σ_{k<n} (-u)^k / k!`. -/
def ePoly (n : ℕ) (u : ℝ) : ℝ := ∑ k ∈ range n, (-1) ^ k * u ^ k / k.factorial

lemma ePoly_succ_zero (n : ℕ) : ePoly (n + 1) 0 = 1 := by
  unfold ePoly
  rw [Finset.sum_range_succ']
  simp

lemma hasDerivAt_ePoly_succ (n : ℕ) (u : ℝ) : HasDerivAt (ePoly (n + 1)) (-ePoly n u) u := by
  have he : ePoly (n + 1) = fun u : ℝ => (1 : ℝ) + ∑ k ∈ range n,
      (-1 : ℝ) ^ (k + 1) * u ^ (k + 1) / ((k + 1).factorial : ℝ) := by
    funext u
    unfold ePoly
    rw [Finset.sum_range_succ']
    simp only [pow_zero, Nat.factorial_zero, Nat.cast_one, div_one, one_mul]
    rw [add_comm]
  rw [he]
  have : ∀ k ∈ range n, HasDerivAt
      (fun u : ℝ => (-1 : ℝ) ^ (k + 1) * u ^ (k + 1) / ((k + 1).factorial : ℝ))
      (-((-1 : ℝ) ^ k * u ^ k / (k.factorial : ℝ))) u := by
    intro k _
    have h := ((hasDerivAt_pow (k + 1) u).const_mul ((-1 : ℝ) ^ (k + 1))).div_const
      ((k + 1).factorial : ℝ)
    convert h using 1
    rw [Nat.factorial_succ, Nat.add_sub_cancel]
    have : (k.factorial : ℝ) ≠ 0 := by positivity
    push_cast
    field_simp
    ring
  have h := (HasDerivAt.sum this).const_add 1
  convert h using 1
  unfold ePoly
  rw [Finset.sum_neg_distrib]

/-- Alternating Taylor bounds for `e^{-u}`, `u ≥ 0`. -/
theorem exp_neg_taylor (n : ℕ) : ∀ u, 0 ≤ u → 0 ≤ (-1) ^ n * (Real.exp (-u) - ePoly n u) := by
  induction n with
  | zero =>
    intro u _
    simp only [pow_zero, one_mul, ePoly, Finset.range_zero, Finset.sum_empty, sub_zero]
    exact (Real.exp_pos _).le
  | succ n ih =>
    intro u hu
    apply nonneg_of_hasDerivAt
      (f := fun t => (-1) ^ (n + 1) * (Real.exp (-t) - ePoly (n + 1) t))
      (f' := fun t => (-1) ^ n * (Real.exp (-t) - ePoly n t))
    · intro t
      have h1 := (((Real.hasDerivAt_exp (-t)).comp t (hasDerivAt_neg t)).sub
        (hasDerivAt_ePoly_succ n t)).const_mul ((-1 : ℝ) ^ (n + 1))
      convert h1 using 1
      ring
    · simp [ePoly_succ_zero]
    · exact ih
    · exact hu

/-- `Σ_{k<n} (-1)^k t^{2k+1} / (2^k k! (2k+1))`. -/
def cPoly (n : ℕ) (t : ℝ) : ℝ :=
  ∑ k ∈ range n, (-1) ^ k * t ^ (2 * k + 1) / (2 ^ k * k.factorial * (2 * k + 1))

lemma cPoly_zero (n : ℕ) : cPoly n 0 = 0 := by simp [cPoly]

lemma hasDerivAt_cPoly (n : ℕ) (t : ℝ) : HasDerivAt (cPoly n) (ePoly n (t ^ 2 / 2)) t := by
  unfold cPoly ePoly
  have : ∀ k ∈ range n, HasDerivAt
      (fun t : ℝ => (-1) ^ k * t ^ (2 * k + 1) / (2 ^ k * k.factorial * (2 * k + 1)))
      ((-1) ^ k * (t ^ 2 / 2) ^ k / k.factorial) t := by
    intro k _
    have h := ((hasDerivAt_pow (2 * k + 1) t).const_mul ((-1 : ℝ) ^ k)).div_const
      ((2 : ℝ) ^ k * k.factorial * (2 * k + 1))
    convert h using 1
    rw [Nat.add_sub_cancel, div_pow, ← pow_mul]
    have : (k.factorial : ℝ) ≠ 0 := by positivity
    have : (2 * k + 1 : ℝ) ≠ 0 := by positivity
    push_cast
    field_simp
    ring
  exact HasDerivAt.sum this

lemma continuous_phi : Continuous phi := by
  unfold phi gaussian
  fun_prop

lemma hasDerivAt_c (t : ℝ) : HasDerivAt c (phi t) t :=
  (continuous_phi.integral_hasStrictDerivAt 0 t).hasDerivAt

/-- Alternating bounds for the Gaussian distribution function, `t ≥ 0`. -/
theorem c_taylor (n : ℕ) {t : ℝ} (ht : 0 ≤ t) : 0 ≤ (-1) ^ n * (c t - phi0 * cPoly n t) := by
  apply nonneg_of_hasDerivAt
    (f := fun s => (-1) ^ n * (c s - phi0 * cPoly n s))
    (f' := fun s => phi0 * ((-1) ^ n * (Real.exp (-(s ^ 2 / 2)) - ePoly n (s ^ 2 / 2))))
  · intro s
    have h1 := ((hasDerivAt_c s).sub ((hasDerivAt_cPoly n s).const_mul phi0)).const_mul
      ((-1 : ℝ) ^ n)
    convert h1 using 1
    unfold phi gaussian
    rw [show -(s ^ 2) / 2 = -(s ^ 2 / 2) by ring]
    ring
  · simp [cPoly_zero, c]
  · intro s _
    exact mul_nonneg phi0_pos.le (exp_neg_taylor n _ (by positivity))
  · exact ht

lemma c_ge_cPoly {m : ℕ} {t : ℝ} (ht : 0 ≤ t) : phi0 * cPoly (2 * m) t ≤ c t := by
  have := c_taylor (2 * m) ht
  rw [pow_mul, neg_one_sq, one_pow, one_mul] at this
  linarith

lemma c_le_cPoly {m : ℕ} {t : ℝ} (ht : 0 ≤ t) : c t ≤ phi0 * cPoly (2 * m + 1) t := by
  have := c_taylor (2 * m + 1) ht
  rw [pow_succ, pow_mul, neg_one_sq, one_pow, one_mul] at this
  linarith

/-! ### Ball evaluation -/

/-- `cPoly n` on a ball. -/
def cPolyB (X : Ball) (n : ℕ) : Ball :=
  serAux (Ball.mul X X) (fun j => 2 * (j + 1)) (fun j => 2 * j + 1) true n 0 X zero

lemma mem_cPolyB {X : Ball} {x : ℝ} (hx : x ∈ X) (n : ℕ) : cPoly n x ∈ cPolyB X n := by
  have h := serAux_mem (Ball.mul X X) (fun j => 2 * (j + 1)) (fun j => 2 * j + 1)
    (fun j => by show 0 < 2 * (j + 1); omega) (fun j => by show 0 < 2 * j + 1; omega) true
    (Ball.mem_mul hx hx)
    (fun j => x ^ (2 * j + 1) / (2 ^ j * j.factorial)) (fun j => by
      show x ^ (2 * (j + 1) + 1) / (2 ^ (j + 1) * ((j + 1).factorial : ℝ)) =
        x ^ (2 * j + 1) / (2 ^ j * (j.factorial : ℝ)) * (x * x) / ((2 * (j + 1) : ℕ) : ℝ)
      rw [Nat.factorial_succ]
      push_cast
      have : (j.factorial : ℝ) ≠ 0 := by positivity
      field_simp
      ring) n 0 X zero 0 (by simpa using hx) mem_zero
  convert h using 1
  rw [zero_add]
  unfold cPoly
  apply Finset.sum_congr rfl
  intro j _
  rw [zero_add, sgnR_true]
  push_cast
  have : (j.factorial : ℝ) ≠ 0 := by positivity
  field_simp

/-- An enclosure of `c(x)` for `x ∈ X`, `x ≥ 0`. -/
def cB (X : Ball) : Ball :=
  ofLoHi (Ball.mul PHI0B (cPolyB X 40)).lo (Ball.mul PHI0B (cPolyB X 41)).hi

lemma mem_cB {X : Ball} {x : ℝ} (hx : x ∈ X) (h0 : 0 ≤ x) : c x ∈ cB X := by
  apply mem_ofLoHi_of_le
  · exact (lo_le_of_mem (Ball.mem_mul phi0_mem (mem_cPolyB hx 40))).trans
      (c_ge_cPoly (m := 20) h0)
  · exact (c_le_cPoly (m := 20) h0).trans
      (le_hi_of_mem (Ball.mem_mul phi0_mem (mem_cPolyB hx 41)))

end

end KellerKlein.Num
