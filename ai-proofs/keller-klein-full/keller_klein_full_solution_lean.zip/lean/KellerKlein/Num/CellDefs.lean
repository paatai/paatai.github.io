import KellerKlein.Num.Elem

/-!
# The certified cell check: definitions

A box is `a ∈ [a₀, a₁]`, `|ξ| ∈ [m₀, m₁]` with a sign (`neg = true` for the lower half,
`y = -|ξ| a`), together with a grid `0 = u₀ < u₁ < ⋯ < u_K = 1` of dyadic points
(numerators over `S = 2⁶⁴`).  For every grid cell the check computes an upper bound of the
master integrand `gU` (file `Full/Master.lean`) on the open cell, uniformly over the box, and
sums them; the box passes if the sum plus the tail bounds is below a lower bound for the
target `masterTarget`.  Soundness is proved in `Num/CellSound.lean`.
-/

namespace KellerKlein.Num

open Ball

/-! ### Points and intervals -/

/-- The ball `[p/S, q/S]`. -/
def ivB (p q : ℕ) : Ball := ofLoHi (p, 0) (q, 0)

/-- `S / 2`. -/
def halfS : ℕ := 9223372036854775808

/-! ### Special functions at grid points -/

/-- `D(π p/S) = 1 - (π p/S) cot(π p/S)`. -/
def DptB (p : ℕ) : Ball :=
  sub one (mul (mul PI (exact p 0)) (divB (trigPt p 0).1 (trigPt p 0).2))

def DptOk (p : ℕ) : Bool := invOk (trigPt p 0).2

/-- `D` at a grid point, with the value `0` (a lower bound) at `p = 0`. -/
def DloB (p : ℕ) : Ball := bif Nat.beq p 0 then zero else DptB p

def DloOk (p : ℕ) : Bool := Nat.beq p 0 || DptOk p

/-- `E(π p/S) = -log cos(π p/S) - (π p/S)²/2`. -/
def EptB (p : ℕ) : Ball :=
  sub (neg (logB (trigPt p 0).1)) (shr (mul (mul PI (exact p 0)) (mul PI (exact p 0))) 1)

def EptOk (p : ℕ) : Bool := logOk (trigPt p 0).1

/-- The part of a ball in `(-∞, 0]`. -/
def nonposB (X : Ball) : Ball := ofLoHi (SP.min X.lo SP.zero) (SP.min X.hi SP.zero)

/-- `exp (-(x²)/2)` on a ball. -/
def gaussB (X : Ball) : Ball := expB (neg (shr (mul X X) 1))

/-! ### Enclosures on a cell `u ∈ (p₀/S, p₁/S)` -/

/-- `gaussian (π u / a)` for `a ∈ [a₀, a₁]`, `u ∈ [p₀/S, p₁/S]`; `IA0 ∋ 1/a₀`, `IA1 ∋ 1/a₁`. -/
def GB (IA0 IA1 : Ball) (p0 p1 : ℕ) : Ball :=
  ofLoHi (gaussB (mul (mul PI (exact p1 0)) IA0)).lo (gaussB (mul (mul PI (exact p0 0)) IA1)).hi

/-- `exp (-(E(π u))/a²)` on a cell inside `[0, 1/2]`. -/
def eNB (IA0 IA1 : Ball) (p0 p1 : ℕ) : Ball :=
  ofLoHi (bif Nat.blt (2 * p1) S then expB (nonposB (neg (mul (mul IA0 IA0) (EptB p1)))) else zero).lo
    (expB (nonposB (neg (mul (mul IA1 IA1) (EptB p0))))).hi

def eNOk (p0 p1 : ℕ) : Bool := EptOk p0 && (!(Nat.blt (2 * p1) S) || EptOk p1)

/-- `|cos(π p/S)| exp((π p/S)²/2)` at a point of `[1/2, 1]`. -/
def cwPt (p : ℕ) : Ball :=
  mul (neg (trigPt p 0).1) (expB (shr (mul (mul PI (exact p 0)) (mul PI (exact p 0))) 1))

def CWB (p0 p1 : ℕ) : Ball := ofLoHi (cwPt p0).lo (cwPt p1).hi

/-- `exp (-(E(π(1-u)))/a²)` on a cell inside `(1/2, 1]`. -/
def eNtB (IA0 IA1 : Ball) (p0 p1 : ℕ) : Ball :=
  ofLoHi (expB (nonposB (neg (mul (mul IA0 IA0) (EptB (S - p0)))))).lo
    (expB (nonposB (neg (mul (mul IA1 IA1) (EptB (S - p1)))))).hi

def eNtOk (p0 p1 : ℕ) : Bool := EptOk (S - p0) && EptOk (S - p1)

/-- `q(u) = π u ρ(u)`. -/
def qB (p0 p1 : ℕ) : Ball :=
  bif Nat.ble (2 * p1) S then
    ofLoHi (sub one (mul (exact (S - p0) 0) (DptB p1))).lo
      (sub one (mul (exact (S - p1) 0) (DloB p0))).hi
  else
    ofLoHi (mul (exact p0 0) (DloB (S - p1))).lo (mul (exact p1 0) (DptB (S - p0))).hi

def qOk (p0 p1 : ℕ) : Bool :=
  bif Nat.ble (2 * p1) S then DptOk p1 && DloOk p0
  else !(Nat.beq p0 0) && DloOk (S - p1) && DptOk (S - p0)

/-- `ρ(u) = D(π(1-u))/π`, for `p₀ > 0`. -/
def rhoB (p0 p1 : ℕ) : Ball :=
  ofLoHi (divB (DloB (S - p1)) PI).lo (divB (DptB (S - p0)) PI).hi

def rhoOk (p0 p1 : ℕ) : Bool := !(Nat.beq p0 0) && DloOk (S - p1) && DptOk (S - p0) && invOk PI

/-- `sin (π w) / (π w)` for `w` in a ball with nonzero centre. -/
def sincB (W : Ball) : Ball :=
  let E := shr (mul PI (exact W.r 0)) 1
  add (divB (trigPt W.p W.n).2 (mul PI (exact W.p W.n))) ⟨0, 0, E.mag⟩

def sincOk (W : Ball) : Bool := invOk (mul PI (exact W.p W.n))

/-- The kernel `upperKernel ξ u`, `ξ ∈ XI`. -/
def kapB (XI : Ball) (p0 p1 : ℕ) : Ball :=
  let W := imul XI (ivB p0 p1)
  let T := trigBox W
  let base := imul (ivB (S - p1) (S - p0)) T.1
  let ks := add base (imul (imul XI (qB p0 p1)) (sincB W))
  bif Nat.beq p0 0 then ks else inter ks (add base (imul (rhoB p0 p1) T.2))

def kapOk (XI : Ball) (p0 p1 : ℕ) : Bool :=
  sincOk (imul XI (ivB p0 p1)) && qOk p0 p1 && (Nat.beq p0 0 || rhoOk p0 p1)

/-- `max (bPlus ξ u) (bMinus ξ u)`, for `u ≥ 1/2`. -/
def bB (XI : Ball) (p0 p1 : ℕ) : Ball :=
  let SW := (trigBox (imul XI (ivB p0 p1))).2
  let H := trigBox (shr XI 1)
  let M := trigBox (imul XI (ivB (p0 - halfS) (p1 - halfS)))
  let T2 := mulNat (ivB (S - p1) (S - p0)) 2
  let RS := imul (rhoB p0 p1) SW
  max (add (neg (imul (imul T2 H.2) M.2)) RS) (sub (neg (imul (imul T2 H.1) M.1)) RS)

/-- An upper bound for `|(1-u) Q(π u)|` on the cell. -/
def cqB (p0 p1 : ℕ) : Ball :=
  bif leB (mul PI (exact p1 0)) one then
    divNat (mul (mul (mul PI (exact p1 0)) (mul PI (exact p1 0))) (mul PI (exact p1 0))) 30
  else
    sub (sub (invB (mul PI (exact p0 0)))
        (divNat (mul (exact (S - p1) 0) (mul PI (exact p0 0))) 3))
      (divB (DloB (S - p1)) PI)

def cqOk (p0 p1 : ℕ) : Bool :=
  leB (mul PI (exact p1 0)) one ||
    (invOk (mul PI (exact p0 0)) && DloOk (S - p1) && invOk PI)

/-! ### The cell bound -/

/-- `π u₁ ≤ 1.7` (so the cell lies left of `θ/π`). -/
def leftOfRoot (p1 : ℕ) : Bool := leB (mul PI (exact p1 0)) (ofRat 17 10)

/-- `π u₀ ≥ 1.8` (so the cell lies right of `θ/π`). -/
def rightOfRoot (p0 : ℕ) : Bool := leB (ofRat 18 10) (mul PI (exact p0 0))

/-- The upper bound on a cell left of `1/2`. -/
def f1Hi (XI IA0 IA1 : Ball) (p0 p1 : ℕ) : SP :=
  let K := kapB XI p0 p1
  let G := GB IA0 IA1 p0 p1
  let cot := mul (mul (ofLoHi SP.zero (cqB p0 p1).hi) (negPart (trigBox (mul XI (ivB p0 p1))).2)) G
  (add (mul (mul (negPart K) G) (sub one (eNB IA0 IA1 p0 p1))) cot).hi

/-- The upper bound from the formula valid for `1/2 < u ≤ θ/π`. -/
def f2Hi (XI IA0 IA1 : Ball) (p0 p1 : ℕ) : SP :=
  let K := kapB XI p0 p1
  let G := GB IA0 IA1 p0 p1
  let cot := mul (mul (ofLoHi SP.zero (cqB p0 p1).hi) (negPart (trigBox (mul XI (ivB p0 p1))).2)) G
  (add (mul (mul (negPart K) G) (add one (CWB p0 p1))) cot).hi

/-- The upper bound from the formula valid for `θ/π < u < 1`. -/
def f3Hi (XI IA0 IA1 : Ball) (p0 p1 : ℕ) : SP :=
  let K := kapB XI p0 p1
  let G := GB IA0 IA1 p0 p1
  let cot := mul (mul (ofLoHi SP.zero (cqB p0 p1).hi) (negPart (trigBox (mul XI (ivB p0 p1))).2)) G
  let GT := GB IA0 IA1 (S - p1) (S - p0)
  (add (sub (add (imul (mul (abs K) GT) (sub (eNtB IA0 IA1 p0 p1) one))
    (imul (bB XI p0 p1) GT)) (imul K G)) cot).hi

/-- The upper bound (scaled by `S`) of `gU` on the cell `(p₀/S, p₁/S)`. -/
def cellHi (XI IA0 IA1 : Ball) (p0 p1 : ℕ) : SP :=
  bif Nat.ble (2 * p1) S then f1Hi XI IA0 IA1 p0 p1
  else bif leftOfRoot p1 then f2Hi XI IA0 IA1 p0 p1
  else bif rightOfRoot p0 then f3Hi XI IA0 IA1 p0 p1
  else SP.max (f2Hi XI IA0 IA1 p0 p1) (f3Hi XI IA0 IA1 p0 p1)

/-- The side conditions of `cellHi`. -/
def cellOk (XI : Ball) (p0 p1 : ℕ) : Bool :=
  Nat.blt p0 p1 && Nat.ble p1 S && kapOk XI p0 p1 && cqOk p0 p1 &&
    (bif Nat.ble (2 * p1) S then eNOk p0 p1
     else Nat.ble S (2 * p0) &&
       (leftOfRoot p1 || (Nat.blt S (2 * p0) && eNtOk p0 p1 && rhoOk p0 p1)))

/-- The scaled sum `∑ (u_{k+1} - u_k) · bound_k` (scale `S²`) and the conjunction of the
side conditions. -/
def sumCells (XI IA0 IA1 : Ball) : ℕ → List ℕ → SP × Bool
  | _, [] => (SP.zero, true)
  | p, q :: l =>
    let r := sumCells XI IA0 IA1 q l
    let h := cellHi XI IA0 IA1 p q
    ((Nat.add (Nat.mul (q - p) h.1) r.1.1, Nat.add (Nat.mul (q - p) h.2) r.1.2),
      cellOk XI p q && r.2)

/-- The last element of `p :: l`. -/
def lastOf : ℕ → List ℕ → ℕ
  | p, [] => p
  | _, q :: l => lastOf q l

/-! ### Target and tails -/

/-- `φ₀ = 1/√(2π)` (certified in `Num/CellSound.lean` by squaring the endpoints). -/
def PHI0B : Ball := ⟨7359186146747302452, 0, 4⟩

/-- `1/π`. -/
def IPI : Ball := invB PI

/-- Upper bound for `tailBound a + aliasTailBound a`, `a ∈ [a₀, a₁]`. -/
def tailsB (pa0 pa1 : ℕ) : Ball :=
  let A := ivB pa0 pa1
  let IA := invB A
  let A2 := mul A A
  let I2 := mul IPI IPI
  let I3 := mul I2 IPI
  let tail := mul (mul A2 (add (add (add (mulNat I2 2) I3) (divNat (mulNat IPI 2) 3))
    (divNat (mul A2 I3) 3))) (gaussB (mul PI IA))
  let ali := mul (mul (mul A IPI) (mul A IPI)) (gaussB (mul (sub PI (ofRat 18 10)) IA))
  add tail ali

/-- An upper bound for `N(x)`, `x ∈ [x₀, x₁] ⊆ [0, ∞)` (upper half). -/
def nHiB (X1 : Ball) : Ball :=
  bif leB X1 one then min (mul PI PHI0B) (mulNat X1 2) else mul PI PHI0B

/-- A lower bound for `N(x)`, `x ∈ [x₀, x₁] ⊆ [0, ∞)` (lower half). -/
def nLoB (X0 X1 : Ball) : Ball :=
  bif leB X1 one then max (neg (mul PI PHI0B)) (sub X0 (mul (sub one (mul X0 X0)) (mul PI PHI0B)))
  else neg (mul PI PHI0B)

/-- A lower bound for `masterTarget a (±m a)` on the box (scale `S`, use `.lo`). -/
def targetB (lower : Bool) (pa0 pa1 pm0 pm1 : ℕ) : Ball :=
  let A0 := exact pa0 0
  let A1 := exact pa1 0
  let A := ivB pa0 pa1
  let A3 := mul (mul A A) A
  let X0 := mul A0 (exact pm0 0)
  let X1 := mul A1 (exact pm1 0)
  let P3 := mulNat (mul PI PI) 3
  let t1 := add (neg (divNat (mul PHI0B (mul (mul A1 A1) A1)) 6))
    (mul (mul A0 PHI0B) (sub one (gaussB X0)))
  bif lower then
    add (add t1 (neg (divNat (mul (mul (mul A1 A1) X1) (mul PHI0B (gaussB X0))) 3)))
      (divB (mul A3 (nLoB X0 X1)) P3)
  else
    add (add t1 (divNat (mul (mul (mul A0 A0) X0) (mul PHI0B (gaussB X1))) 3))
      (neg (divB (mul A3 (nHiB X1)) P3))

def targetOk : Bool := invOk (mulNat (mul PI PI) 3) && invOk PI

/-! ### The box check -/

def spMulS (x : SP) : SP := (Nat.mul x.1 S, Nat.mul x.2 S)

def spAdd (x y : SP) : SP := (Nat.add x.1 y.1, Nat.add x.2 y.2)

/-- The signed `ξ`-ball of a box. -/
def xiB (lower : Bool) (pm0 pm1 : ℕ) : Ball :=
  bif lower then ofLoHi (0, pm1) (0, pm0) else ofLoHi (pm0, 0) (pm1, 0)

/-- The box check. -/
def boxOk (lower : Bool) (pa0 pa1 pm0 pm1 : ℕ) (grid : List ℕ) : Bool :=
  let IA0 := invB (exact pa0 0)
  let IA1 := invB (exact pa1 0)
  let r := sumCells (xiB lower pm0 pm1) IA0 IA1 0 grid
  Nat.blt 0 pa0 && Nat.ble pa0 pa1 && Nat.ble pa1 S && Nat.blt 0 pm0 && Nat.ble pm0 pm1 &&
    invOk (exact pa0 0) && invOk (exact pa1 0) && invOk (ivB pa0 pa1) && targetOk && r.2 &&
    Nat.beq (lastOf 0 grid) S &&
    SP.le (spAdd r.1 (spMulS (tailsB pa0 pa1).hi)) (spMulS (targetB lower pa0 pa1 pm0 pm1).lo)

end KellerKlein.Num
