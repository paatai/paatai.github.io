import KellerKlein.Num.CellSound
import KellerKlein.GaussianError
import KellerKlein.Full.Reduction

/-!
# Soundness of the cover checker

A passing group `(k₀, k₁, n_lobe, [m₀, …, m_K])` proves the envelope inequality for every
`a ∈ [k₀ 2⁻³², k₁ 2⁻³²]` and every location in the range of the half in question:
the boxes cover `ξ ∈ [ξ₀, ξ_K]`, and the end condition excludes `ξ ≥ ξ_K`.  A list of
passing groups whose `a`-intervals are contiguous covers the union of the intervals.
-/

namespace KellerKlein.Num

open KellerKlein Ball

noncomputable section

lemma boxesOk_sound {lower : Bool} {pa0 pa1 : ℕ} {grid : List ℕ} :
    ∀ (m : ℕ) (l : List ℕ), boxesOk lower pa0 pa1 grid m l = true → ∀ {ξ : ℝ},
      pt (Nat.mul m xiUnit) ≤ ξ → ξ < pt (Nat.mul (lastOf m l) xiUnit) →
      ∃ pm0 pm1, boxOk lower pa0 pa1 pm0 pm1 grid = true ∧ pt pm0 ≤ ξ ∧ ξ ≤ pt pm1
  | m, [], _, ξ, h0, h1 => by
    simp only [lastOf] at h1
    exact absurd h0 (not_le.mpr h1)
  | m, m' :: l, h, ξ, h0, h1 => by
    simp only [boxesOk, Bool.and_eq_true] at h
    obtain ⟨⟨-, hb⟩, hl⟩ := h
    by_cases hξ : ξ ≤ pt (Nat.mul m' xiUnit)
    · exact ⟨_, _, hb, h0, hξ⟩
    · simp only [lastOf] at h1
      exact boxesOk_sound m' l hl (le_of_lt (lt_of_not_le hξ)) h1

lemma mem_cubicB {p : ℕ} :
    pt p - pt p * pt p * pt p / ((6 : ℕ) : ℝ) ∈ cubicB (exact p 0) :=
  mem_sub (mem_pt p) (mem_divNat (mem_mul (mem_mul (mem_pt p) (mem_pt p)) (mem_pt p))
    (by norm_num))

lemma cubic_mono {a0 a : ℝ} (h0 : 0 ≤ a0) (ha0 : a0 ≤ a) (ha1 : a ≤ 1) :
    a0 - a0 * a0 * a0 / ((6 : ℕ) : ℝ) ≤ a - a ^ 3 / 6 := by
  push_cast
  have e : a - a ^ 3 / 6 - (a0 - a0 * a0 * a0 / 6) =
      (a - a0) * (1 - (a ^ 2 + a * a0 + a0 ^ 2) / 6) := by ring
  have h2 : a ^ 2 + a * a0 + a0 ^ 2 ≤ 3 := by nlinarith
  have := mul_nonneg (sub_nonneg.mpr ha0)
    (show 0 ≤ 1 - (a ^ 2 + a * a0 + a0 ^ 2) / 6 by linarith)
  linarith

/-- The end condition of the upper half: beyond `x_e`, `H(x) + H(a) ≥ 1`. -/
lemma endOk_upper {pa0 mK : ℕ} (h : endOk false pa0 mK = true) {a x : ℝ}
    (ha0 : pt pa0 ≤ a) (ha1 : a ≤ 1) (hx : pt pa0 * pt (Nat.mul mK xiUnit) ≤ x) :
    1 ≤ H x + H a := by
  simp only [endOk] at h
  rw [cond_false, Bool.and_eq_true] at h
  obtain ⟨hinv, hle⟩ := h
  have hXE := mem_mul (mem_pt pa0) (mem_pt (Nat.mul mK xiUnit))
  have hxe0 := ne_zero_of_invOk hinv hXE
  have hxe : 0 < pt pa0 * pt (Nat.mul mK xiUnit) :=
    lt_of_le_of_ne (mul_nonneg (pt_nonneg _) (pt_nonneg _)) (Ne.symm hxe0)
  have h1 := le_of_leB hle (mem_divB hinv (mem_gaussB hXE) hXE) mem_cubicB
  have hx0 : 0 < x := hxe.trans_le hx
  have hm := gaussian_mills hx0
  have hg : gaussian x / x ≤ gaussian (pt pa0 * pt (Nat.mul mK xiUnit)) /
      (pt pa0 * pt (Nat.mul mK xiUnit)) := by
    have := gaussian_anti hxe.le hx
    calc gaussian x / x ≤ gaussian (pt pa0 * pt (Nat.mul mK xiUnit)) / x :=
          div_le_div_of_nonneg_right this hx0.le
      _ ≤ _ := div_le_div_of_nonneg_left (gaussian_nonneg _) hxe hx
  have hcub := cubic_mono (pt_nonneg pa0) ha0 ha1
  have hca := c_lower_cubic ((pt_nonneg pa0).trans ha0)
  have hφ := phi0_pos
  have e : phi x / x = phi0 * (gaussian x / x) := by unfold phi; ring
  rw [e] at hm
  have := mul_le_mul_of_nonneg_left (hg.trans (h1.trans hcub)) hφ.le
  unfold H
  linarith

/-- The end condition of the lower half: beyond `x_e`, `exp (-x²/2) ≤ c(a)`. -/
lemma endOk_lower {pa0 mK : ℕ} (h : endOk true pa0 mK = true) {a x : ℝ}
    (ha0 : pt pa0 ≤ a) (ha1 : a ≤ 1) (hx : pt pa0 * pt (Nat.mul mK xiUnit) ≤ x) :
    Real.exp (-(x ^ 2) / 2) ≤ c a := by
  simp only [endOk] at h
  rw [cond_true] at h
  have hXE := mem_mul (mem_pt pa0) (mem_pt (Nat.mul mK xiUnit))
  have h1 := le_of_leB h (mem_gaussB hXE) (mem_mul phi0_mem mem_cubicB)
  have hxe0 : 0 ≤ pt pa0 * pt (Nat.mul mK xiUnit) := mul_nonneg (pt_nonneg _) (pt_nonneg _)
  have hg := gaussian_anti hxe0 hx
  have hcub := cubic_mono (pt_nonneg pa0) ha0 ha1
  have hca := c_lower_cubic ((pt_nonneg pa0).trans ha0)
  have := mul_le_mul_of_nonneg_left hcub phi0_pos.le
  show gaussian x ≤ c a
  linarith

lemma pt_xi0_false : pt (Nat.mul (xi0 false) xiUnit) = 1 / 2 := by
  simp only [pt, xi0, xiUnit, S, cond_false]; norm_num

lemma pt_xi0_true : pt (Nat.mul (xi0 true) xiUnit) = 3 / 2 := by
  simp only [pt, xi0, xiUnit, S, cond_true]; norm_num

/-- A passing group of the upper half. -/
theorem groupOk_upper {g : ℕ × ℕ × ℕ × List ℕ} (h : groupOk false g = true) {a : ℝ}
    (ha0 : pt (Nat.mul g.1 aUnit) ≤ a) (ha1 : a ≤ pt (Nat.mul g.2.1 aUnit)) (ha : 0 < a)
    (ha1' : a ≤ 1) {x : ℝ} (hx : a / 2 ≤ x) (htail : H x + H a < 1) :
    JUpper a x ≤ c a + c x := by
  obtain ⟨k0, k1, nl, ms⟩ := g
  cases ms with
  | nil => simp [groupOk] at h
  | cons m l =>
    simp only [groupOk, Bool.and_eq_true] at h
    obtain ⟨⟨hm, hb⟩, he⟩ := h
    have hm' : m = xi0 false := Nat.eq_of_beq_eq_true hm
    have hxa : x = a * (x / a) := by field_simp
    have hξ0 : pt (Nat.mul m xiUnit) ≤ x / a := by
      rw [hm', pt_xi0_false, le_div_iff₀ ha]; linarith
    by_cases hK : x / a < pt (Nat.mul (lastOf m l) xiUnit)
    · obtain ⟨pm0, pm1, hbox, h0, h1⟩ := boxesOk_sound m l hb hξ0 hK
      have := boxOk_upper hbox ha0 ha1 h0 h1
      rwa [← hxa] at this
    · have hxe : pt (Nat.mul k0 aUnit) * pt (Nat.mul (lastOf m l) xiUnit) ≤ x := by
        rw [hxa]; exact mul_le_mul ha0 (le_of_not_lt hK) (pt_nonneg _) ha.le
      have := endOk_upper he ha0 ha1' hxe
      linarith

/-- A passing group of the lower half. -/
theorem groupOk_lower {g : ℕ × ℕ × ℕ × List ℕ} (h : groupOk true g = true) {a : ℝ}
    (ha0 : pt (Nat.mul g.1 aUnit) ≤ a) (ha1 : a ≤ pt (Nat.mul g.2.1 aUnit)) (ha : 0 < a)
    (ha1' : a ≤ 1) {x : ℝ} (hx : 3 * a / 2 ≤ x) (htail : c a < Real.exp (-(x ^ 2) / 2)) :
    JUpper a (-x) ≤ c a - c x := by
  obtain ⟨k0, k1, nl, ms⟩ := g
  cases ms with
  | nil => simp [groupOk] at h
  | cons m l =>
    simp only [groupOk, Bool.and_eq_true] at h
    obtain ⟨⟨hm, hb⟩, he⟩ := h
    have hm' : m = xi0 true := Nat.eq_of_beq_eq_true hm
    have hxa : x = a * (x / a) := by field_simp
    have hξ0 : pt (Nat.mul m xiUnit) ≤ x / a := by
      rw [hm', pt_xi0_true, le_div_iff₀ ha]; linarith
    by_cases hK : x / a < pt (Nat.mul (lastOf m l) xiUnit)
    · obtain ⟨pm0, pm1, hbox, h0, h1⟩ := boxesOk_sound m l hb hξ0 hK
      have := boxOk_lower hbox ha0 ha1 h0 h1
      rw [← hxa, c_neg] at this
      linarith
    · have hxe : pt (Nat.mul k0 aUnit) * pt (Nat.mul (lastOf m l) xiUnit) ≤ x := by
        rw [hxa]; exact mul_le_mul ha0 (le_of_not_lt hK) (pt_nonneg _) ha.le
      have := endOk_lower he ha0 ha1' hxe
      linarith

/-- A chain of passing groups covers the union of their `a`-intervals. -/
theorem groupsOk_cover {lower : Bool} {P : ℝ → Prop}
    (hg : ∀ g, groupOk lower g = true → ∀ a, pt (Nat.mul g.1 aUnit) ≤ a →
      a ≤ pt (Nat.mul g.2.1 aUnit) → P a) :
    ∀ (gs : List (ℕ × ℕ × ℕ × List ℕ)) (k : ℕ), groupsOk lower gs = true →
      k < aChain k gs → ∀ a, pt (Nat.mul k aUnit) ≤ a →
      a ≤ pt (Nat.mul (aChain k gs) aUnit) → P a
  | [], k, _, hk, _, _, _ => by simp [aChain] at hk
  | g :: l, k, h, hk, a, ha0, ha1 => by
    simp only [groupsOk, Bool.and_eq_true] at h
    obtain ⟨hg1, hl⟩ := h
    by_cases hc : (Nat.beq g.1 k && Nat.blt g.1 g.2.1) = true
    · have hch : aChain k (g :: l) = aChain g.2.1 l := by
        simp only [aChain, hc, cond_true]
      rw [hch] at hk ha1
      simp only [Bool.and_eq_true] at hc
      have hk1 : g.1 = k := Nat.eq_of_beq_eq_true hc.1
      by_cases ha : a ≤ pt (Nat.mul g.2.1 aUnit)
      · exact hg g hg1 a (by rw [hk1]; exact ha0) ha
      · have hlt : g.2.1 < aChain g.2.1 l := by
          by_contra hle
          push_neg at hle
          have := pt_le (show Nat.mul (aChain g.2.1 l) aUnit ≤ Nat.mul g.2.1 aUnit from
            Nat.mul_le_mul_right aUnit hle)
          exact ha (ha1.trans this)
        exact groupsOk_cover hg l g.2.1 hl hlt a (le_of_lt (lt_of_not_le ha)) ha1
    · have hch : aChain k (g :: l) = 0 := by
        rw [Bool.not_eq_true] at hc
        simp only [aChain, hc, cond_false]
      rw [hch] at hk
      exact absurd hk (Nat.not_lt_zero _)

/-- The statement certified for the upper half at a given `a`. -/
def UpperAt (a : ℝ) : Prop :=
  0 < a → a ≤ 1 → ∀ x, a / 2 ≤ x → H x + H a < 1 → JUpper a x ≤ c a + c x

/-- The statement certified for the lower half at a given `a`. -/
def LowerAt (a : ℝ) : Prop :=
  0 < a → a ≤ 1 → ∀ x, 3 * a / 2 ≤ x → c a < Real.exp (-(x ^ 2) / 2) →
    JUpper a (-x) ≤ c a - c x

theorem cover_upper (gs : List (ℕ × ℕ × ℕ × List ℕ)) (k k' : ℕ)
    (h : groupsOk false gs = true) (hch : aChain k gs = k') (hkk : k < k') :
    ∀ a, pt (Nat.mul k aUnit) ≤ a → a ≤ pt (Nat.mul k' aUnit) → UpperAt a := by
  subst hch
  exact groupsOk_cover (fun g hg a h0 h1 ha ha1 x hx ht => groupOk_upper hg h0 h1 ha ha1 hx ht)
    gs k h hkk

theorem cover_lower (gs : List (ℕ × ℕ × ℕ × List ℕ)) (k k' : ℕ)
    (h : groupsOk true gs = true) (hch : aChain k gs = k') (hkk : k < k') :
    ∀ a, pt (Nat.mul k aUnit) ≤ a → a ≤ pt (Nat.mul k' aUnit) → LowerAt a := by
  subst hch
  exact groupsOk_cover (fun g hg a h0 h1 ha ha1 x hx ht => groupOk_lower hg h0 h1 ha ha1 hx ht)
    gs k h hkk

/-! ### Slices: chains of boxes checked as separate declarations

The kernel keeps every intermediate term of a declaration in its caches, so the boxes of a
group are checked in slices of a few boxes each (one declaration per slice); the slices are
glued in `ξ`, the groups in `a`. -/

/-- The envelope inequality of the upper half on a rectangle of `(a, ξ)`. -/
def SliceU (pa0 pa1 m m' : ℕ) : Prop :=
  ∀ a ξ : ℝ, pt pa0 ≤ a → a ≤ pt pa1 → pt (Nat.mul m xiUnit) ≤ ξ →
    ξ ≤ pt (Nat.mul m' xiUnit) → JUpper a (a * ξ) ≤ c a + c (a * ξ)

/-- The envelope inequality of the lower half on a rectangle of `(a, ξ)`. -/
def SliceL (pa0 pa1 m m' : ℕ) : Prop :=
  ∀ a ξ : ℝ, pt pa0 ≤ a → a ≤ pt pa1 → pt (Nat.mul m xiUnit) ≤ ξ →
    ξ ≤ pt (Nat.mul m' xiUnit) → JUpper a (-(a * ξ)) ≤ c a + c (-(a * ξ))

lemma boxesOk_sound' {lower : Bool} {pa0 pa1 : ℕ} {grid : List ℕ} :
    ∀ (l : List ℕ) (m : ℕ), l ≠ [] → boxesOk lower pa0 pa1 grid m l = true → ∀ {ξ : ℝ},
      pt (Nat.mul m xiUnit) ≤ ξ → ξ ≤ pt (Nat.mul (lastOf m l) xiUnit) →
      ∃ pm0 pm1, boxOk lower pa0 pa1 pm0 pm1 grid = true ∧ pt pm0 ≤ ξ ∧ ξ ≤ pt pm1
  | [], _, hl, _, _, _, _ => absurd rfl hl
  | m' :: l, m, _, h, ξ, h0, h1 => by
    simp only [boxesOk, Bool.and_eq_true] at h
    obtain ⟨⟨-, hb⟩, hl⟩ := h
    by_cases hξ : ξ ≤ pt (Nat.mul m' xiUnit)
    · exact ⟨_, _, hb, h0, hξ⟩
    · cases l with
      | nil => exact absurd h1 hξ
      | cons m'' l' =>
        exact boxesOk_sound' (m'' :: l') m' (List.cons_ne_nil _ _) hl
          (le_of_lt (lt_of_not_le hξ)) h1

theorem slice_upper {pa0 pa1 : ℕ} {grid : List ℕ} {m m' : ℕ} {l : List ℕ} (hl : l ≠ [])
    (h : boxesOk false pa0 pa1 grid m l = true) (hlast : lastOf m l = m') :
    SliceU pa0 pa1 m m' := by
  intro a ξ ha0 ha1 h0 h1
  rw [← hlast] at h1
  obtain ⟨pm0, pm1, hb, hp0, hp1⟩ := boxesOk_sound' l m hl h h0 h1
  exact boxOk_upper hb ha0 ha1 hp0 hp1

theorem slice_lower {pa0 pa1 : ℕ} {grid : List ℕ} {m m' : ℕ} {l : List ℕ} (hl : l ≠ [])
    (h : boxesOk true pa0 pa1 grid m l = true) (hlast : lastOf m l = m') :
    SliceL pa0 pa1 m m' := by
  intro a ξ ha0 ha1 h0 h1
  rw [← hlast] at h1
  obtain ⟨pm0, pm1, hb, hp0, hp1⟩ := boxesOk_sound' l m hl h h0 h1
  exact boxOk_lower hb ha0 ha1 hp0 hp1

theorem sliceU_glue {pa0 pa1 m1 m2 m3 : ℕ} (h1 : SliceU pa0 pa1 m1 m2)
    (h2 : SliceU pa0 pa1 m2 m3) : SliceU pa0 pa1 m1 m3 := by
  intro a ξ ha0 ha1 h0 h3
  by_cases h : ξ ≤ pt (Nat.mul m2 xiUnit)
  · exact h1 a ξ ha0 ha1 h0 h
  · exact h2 a ξ ha0 ha1 (le_of_lt (lt_of_not_le h)) h3

theorem sliceL_glue {pa0 pa1 m1 m2 m3 : ℕ} (h1 : SliceL pa0 pa1 m1 m2)
    (h2 : SliceL pa0 pa1 m2 m3) : SliceL pa0 pa1 m1 m3 := by
  intro a ξ ha0 ha1 h0 h3
  by_cases h : ξ ≤ pt (Nat.mul m2 xiUnit)
  · exact h1 a ξ ha0 ha1 h0 h
  · exact h2 a ξ ha0 ha1 (le_of_lt (lt_of_not_le h)) h3

/-- A group of the upper half: the slices cover `ξ ∈ [1/2, ξ_K]`, the end condition the rest. -/
theorem group_upper {k0 k1 mK : ℕ}
    (hs : SliceU (Nat.mul k0 aUnit) (Nat.mul k1 aUnit) (xi0 false) mK)
    (he : endOk false (Nat.mul k0 aUnit) mK = true) :
    ∀ a, pt (Nat.mul k0 aUnit) ≤ a → a ≤ pt (Nat.mul k1 aUnit) → UpperAt a := by
  intro a ha0 ha1 ha ha1' x hx htail
  have hxa : x = a * (x / a) := by field_simp
  have hξ0 : pt (Nat.mul (xi0 false) xiUnit) ≤ x / a := by
    rw [pt_xi0_false, le_div_iff₀ ha]; linarith
  by_cases hK : x / a ≤ pt (Nat.mul mK xiUnit)
  · have := hs a (x / a) ha0 ha1 hξ0 hK
    rwa [← hxa] at this
  · have hxe : pt (Nat.mul k0 aUnit) * pt (Nat.mul mK xiUnit) ≤ x := by
      rw [hxa]; exact mul_le_mul ha0 (le_of_lt (lt_of_not_le hK)) (pt_nonneg _) ha.le
    have := endOk_upper he ha0 ha1' hxe
    linarith

/-- A group of the lower half: the slices cover `ξ ∈ [3/2, ξ_K]`, the end condition the rest. -/
theorem group_lower {k0 k1 mK : ℕ}
    (hs : SliceL (Nat.mul k0 aUnit) (Nat.mul k1 aUnit) (xi0 true) mK)
    (he : endOk true (Nat.mul k0 aUnit) mK = true) :
    ∀ a, pt (Nat.mul k0 aUnit) ≤ a → a ≤ pt (Nat.mul k1 aUnit) → LowerAt a := by
  intro a ha0 ha1 ha ha1' x hx htail
  have hxa : x = a * (x / a) := by field_simp
  have hξ0 : pt (Nat.mul (xi0 true) xiUnit) ≤ x / a := by
    rw [pt_xi0_true, le_div_iff₀ ha]; linarith
  by_cases hK : x / a ≤ pt (Nat.mul mK xiUnit)
  · have := hs a (x / a) ha0 ha1 hξ0 hK
    rw [← hxa, c_neg] at this
    linarith
  · have hxe : pt (Nat.mul k0 aUnit) * pt (Nat.mul mK xiUnit) ≤ x := by
      rw [hxa]; exact mul_le_mul ha0 (le_of_lt (lt_of_not_le hK)) (pt_nonneg _) ha.le
    have := endOk_lower he ha0 ha1' hxe
    linarith

/-- Gluing two adjacent ranges. -/
lemma cover_glue {P : ℝ → Prop} {k1 k2 k3 : ℕ}
    (h1 : ∀ a, pt (Nat.mul k1 aUnit) ≤ a → a ≤ pt (Nat.mul k2 aUnit) → P a)
    (h2 : ∀ a, pt (Nat.mul k2 aUnit) ≤ a → a ≤ pt (Nat.mul k3 aUnit) → P a) :
    ∀ a, pt (Nat.mul k1 aUnit) ≤ a → a ≤ pt (Nat.mul k3 aUnit) → P a := by
  intro a ha1 ha3
  by_cases h : a ≤ pt (Nat.mul k2 aUnit)
  · exact h1 a ha1 h
  · exact h2 a (le_of_lt (lt_of_not_le h)) ha3

end

end KellerKlein.Num
