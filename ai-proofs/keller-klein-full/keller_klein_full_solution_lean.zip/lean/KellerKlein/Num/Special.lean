import KellerKlein.Num.Elem
import KellerKlein.ZoneBKernel
import KellerKlein.Sinc

/-!
# Special functions of the cell check

`D(y) = 1 - y cot y` and `E(y) = -log cos y - y²/2`, their monotonicity, the identities
expressing the Prawitz weight `ρ` through `D`, a Lipschitz bound for `sin z / z`, and point
evaluators on balls.
-/

open Set

namespace KellerKlein.Num

open Ball

noncomputable section

/-- `D(y) = 1 - y cot y` (Lean's total division; the identities below are used on `(0, π)`). -/
def Dfun (y : ℝ) : ℝ := 1 - y * (Real.cos y / Real.sin y)

/-- `E(y) = -log cos y - y²/2`. -/
def Efun (y : ℝ) : ℝ := -Real.log (Real.cos y) - y ^ 2 / 2

lemma sin_sub_mul_cos_nonneg {y : ℝ} (hy : 0 ≤ y) (hyπ : y ≤ Real.pi) :
    0 ≤ Real.sin y - y * Real.cos y := by
  rcases lt_or_le y (Real.pi / 2) with h | h
  · have hc : 0 < Real.cos y := Real.cos_pos_of_mem_Ioo ⟨by linarith [Real.pi_pos], h⟩
    have ht := Real.le_tan hy h
    rw [Real.tan_eq_sin_div_cos, le_div_iff₀ hc] at ht
    linarith
  · have hc : Real.cos y ≤ 0 :=
      Real.cos_nonpos_of_pi_div_two_le_of_le h (by linarith [Real.pi_pos])
    have hs : 0 ≤ Real.sin y := Real.sin_nonneg_of_nonneg_of_le_pi hy hyπ
    nlinarith

lemma Dfun_eq {y : ℝ} (hs : Real.sin y ≠ 0) :
    Dfun y = (Real.sin y - y * Real.cos y) / Real.sin y := by
  unfold Dfun; field_simp

lemma Dfun_nonneg {y : ℝ} (hy : 0 < y) (hyπ : y < Real.pi) : 0 ≤ Dfun y := by
  have hs := Real.sin_pos_of_pos_of_lt_pi hy hyπ
  rw [Dfun_eq hs.ne']
  exact div_nonneg (sin_sub_mul_cos_nonneg hy.le hyπ.le) hs.le

lemma hasDerivAt_Dfun {y : ℝ} (hs : Real.sin y ≠ 0) :
    HasDerivAt Dfun ((y - Real.sin y * Real.cos y) / Real.sin y ^ 2) y := by
  have h := ((hasDerivAt_id y).mul ((Real.hasDerivAt_cos y).div (Real.hasDerivAt_sin y) hs))
  have h2 := (hasDerivAt_const y (1 : ℝ)).sub h
  convert h2 using 1
  have e : -Real.sin y * Real.sin y - Real.cos y * Real.cos y = -1 := by
    linear_combination -(Real.sin_sq_add_cos_sq y)
  simp only [id, e]
  field_simp
  ring

lemma Dfun_monotoneOn : MonotoneOn Dfun (Ioo 0 Real.pi) := by
  have hd : ∀ y ∈ Ioo 0 Real.pi,
      HasDerivAt Dfun ((y - Real.sin y * Real.cos y) / Real.sin y ^ 2) y := fun y hy =>
    hasDerivAt_Dfun (Real.sin_pos_of_pos_of_lt_pi hy.1 hy.2).ne'
  apply monotoneOn_of_deriv_nonneg (convex_Ioo 0 Real.pi)
  · exact fun y hy => (hd y hy).continuousAt.continuousWithinAt
  · intro y hy
    exact (hd y (interior_subset hy)).differentiableAt.differentiableWithinAt
  · intro y hy
    have hy' := interior_subset hy
    rw [(hd y hy').deriv]
    apply div_nonneg _ (sq_nonneg _)
    have h2 := Real.sin_le (show 0 ≤ 2 * y by linarith [hy'.1])
    rw [Real.sin_two_mul] at h2
    linarith

lemma hasDerivAt_Efun {y : ℝ} (hc : 0 < Real.cos y) :
    HasDerivAt Efun (Real.tan y - y) y := by
  have h := ((Real.hasDerivAt_cos y).log hc.ne').neg.sub
    ((hasDerivAt_pow 2 y).div_const 2)
  convert h using 1
  rw [Real.tan_eq_sin_div_cos]
  field_simp

lemma Efun_monotoneOn : MonotoneOn Efun (Ico 0 (Real.pi / 2)) := by
  have hc : ∀ y ∈ Ico 0 (Real.pi / 2), 0 < Real.cos y := fun y hy =>
    Real.cos_pos_of_mem_Ioo ⟨by linarith [hy.1, Real.pi_pos], hy.2⟩
  have hd : ∀ y ∈ Ico 0 (Real.pi / 2), HasDerivAt Efun (Real.tan y - y) y :=
    fun y hy => hasDerivAt_Efun (hc y hy)
  apply monotoneOn_of_deriv_nonneg (convex_Ico 0 (Real.pi / 2))
  · exact fun y hy => (hd y hy).continuousAt.continuousWithinAt
  · intro y hy
    exact (hd y (interior_subset hy)).differentiableAt.differentiableWithinAt
  · intro y hy
    have hy' := interior_subset hy
    rw [(hd y hy').deriv]
    have := Real.le_tan hy'.1 hy'.2
    linarith

lemma Efun_zero : Efun 0 = 0 := by simp [Efun]

lemma Efun_nonneg {y : ℝ} (hy : 0 ≤ y) (hy2 : y < Real.pi / 2) : 0 ≤ Efun y := by
  have := Efun_monotoneOn (show (0 : ℝ) ∈ Ico 0 (Real.pi / 2) from ⟨le_rfl, by positivity⟩)
    ⟨hy, hy2⟩ hy
  rwa [Efun_zero] at this

/-- `cos y ^ N = exp (-N y²/2) · exp (-N E(y))` for `cos y > 0`. -/
lemma cos_rpow_eq {y N : ℝ} (hc : 0 < Real.cos y) :
    Real.cos y ^ N = Real.exp (-(N * y ^ 2) / 2) * Real.exp (-(N * Efun y)) := by
  rw [Real.rpow_def_of_pos hc, ← Real.exp_add]
  congr 1
  unfold Efun; ring

/-! ### The Prawitz weight -/

lemma rho_eq_Dfun (u : ℝ) : rho u = Dfun (Real.pi * (1 - u)) / Real.pi := by
  unfold rho Dfun
  rw [show Real.pi * (1 - u) = Real.pi - Real.pi * u by ring, Real.cos_pi_sub, Real.sin_pi_sub]
  have hp := Real.pi_pos.ne'
  rw [neg_div]
  field_simp
  ring

lemma q_eq_left (u : ℝ) : Real.pi * u * rho u = 1 - (1 - u) * Dfun (Real.pi * u) := by
  unfold rho Dfun
  have hp := Real.pi_pos.ne'
  field_simp
  ring

lemma q_eq_right (u : ℝ) : Real.pi * u * rho u = u * Dfun (Real.pi * (1 - u)) := by
  rw [rho_eq_Dfun]
  have hp := Real.pi_pos.ne'
  field_simp
  ring

lemma rho_antitoneOn : AntitoneOn rho (Ioo 0 1) := by
  intro u hu v hv huv
  rw [rho_eq_Dfun, rho_eq_Dfun]
  apply div_le_div_of_nonneg_right _ Real.pi_pos.le
  apply Dfun_monotoneOn
  · exact ⟨by nlinarith [Real.pi_pos, hv.2], by nlinarith [Real.pi_pos, hv.1]⟩
  · exact ⟨by nlinarith [Real.pi_pos, hu.2], by nlinarith [Real.pi_pos, hu.1]⟩
  · nlinarith [Real.pi_pos]

/-- The weighted cotangent remainder, exactly. -/
lemma abs_weighted_cotangentQ_eq {u : ℝ} (hu : 0 < u) (hu1 : u < 1) :
    |(1 - u) * cotangentQ (Real.pi * u)| =
      1 / (Real.pi * u) - (1 - u) * (Real.pi * u) / 3 - rho u := by
  rw [abs_of_nonpos (weighted_cotangentQ_nonpos hu hu1), rho_remainder_eq u hu.ne']
  ring

/-! ### `sin z / z` -/

lemma abs_sin_sub_mul_cos_le (t : ℝ) (ht : 0 ≤ t) :
    |Real.sin t - t * Real.cos t| ≤ t ^ 2 / 2 := by
  have hg : ∀ s, HasDerivAt (fun s => s ^ 2 / 2 - (Real.sin s - s * Real.cos s))
      (s * (1 - Real.sin s)) s := by
    intro s
    have := ((hasDerivAt_pow 2 s).div_const 2).sub
      ((Real.hasDerivAt_sin s).sub ((hasDerivAt_id s).mul (Real.hasDerivAt_cos s)))
    convert this using 1
    simp only [id]; ring
  have hh : ∀ s, HasDerivAt (fun s => s ^ 2 / 2 + (Real.sin s - s * Real.cos s))
      (s * (1 + Real.sin s)) s := by
    intro s
    have := ((hasDerivAt_pow 2 s).div_const 2).add
      ((Real.hasDerivAt_sin s).sub ((hasDerivAt_id s).mul (Real.hasDerivAt_cos s)))
    convert this using 1
    simp only [id]; ring
  have h1 := nonneg_of_hasDerivAt hg (by simp) (fun s hs => mul_nonneg hs
    (by linarith [Real.sin_le_one s])) ht
  have h2 := nonneg_of_hasDerivAt hh (by simp) (fun s hs => mul_nonneg hs
    (by linarith [Real.neg_one_le_sin s])) ht
  rw [abs_le]
  constructor <;> linarith

lemma sinc_lipschitz {z w : ℝ} (hz : 0 < z) (hw : 0 < w) :
    |Real.sin z / z - Real.sin w / w| ≤ |z - w| / 2 := by
  have hd : ∀ t ∈ Ioi (0 : ℝ), HasDerivAt (fun t => Real.sin t / t)
      ((t * Real.cos t - Real.sin t) / t ^ 2) t := by
    intro t ht
    have := (Real.hasDerivAt_sin t).div (hasDerivAt_id t) (ne_of_gt ht)
    convert this using 1
    simp only [id]; ring
  have hb : ∀ t ∈ Ioi (0 : ℝ), ‖deriv (fun t => Real.sin t / t) t‖ ≤ 1 / 2 := by
    intro t ht
    rw [(hd t ht).deriv, Real.norm_eq_abs, abs_div, abs_of_pos (pow_pos (show (0 : ℝ) < t from ht) 2)]
    rw [div_le_iff₀ (pow_pos (show (0 : ℝ) < t from ht) 2)]
    have := abs_sin_sub_mul_cos_le t (le_of_lt ht)
    rw [abs_sub_comm] at this
    linarith
  have := (convex_Ioi (0 : ℝ)).norm_image_sub_le_of_norm_deriv_le
    (fun t ht => (hd t ht).differentiableAt) hb hw hz
  simp only [Real.norm_eq_abs] at this
  linarith

lemma sin_div_le_one {z : ℝ} (hz : 0 < z) : Real.sin z / z ≤ 1 := by
  rw [div_le_one hz]; exact (Real.sin_lt hz).le

end

end KellerKlein.Num
