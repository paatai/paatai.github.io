import KellerKlein.Num.GaussCDF
import KellerKlein.Num.CoverSound
import KellerKlein.Full.Induction

/-!
# Certified peeling inequalities

Box checkers for the peeling inequalities `PeelL` and `PeelU` of `Full/Induction.lean`, and
their soundness.  On a box `a ∈ [a₀, a₁]` every function entering the peeling bounds is
monotone in each variable:

* `σ(a) = √(1 - a²)` decreases and the level `min (a/σ) 1` increases with `a`;
* `loY a t` is bounded below using `σ(a₀)`, the level at `a₁` and the smallest `t`;
* `upY a t` is bounded above using `σ(a₁)`, the level at `a₁` and the largest `t`;
* `H(a + d) - H(a)` decreases in `a ≥ 0` and increases in `d ≥ 0`.

`H = 2c` is evaluated with `cB` (alternating series).  Arguments of `H` and of the Gaussian
in lower bounds are capped at `4`, where the series is still accurate.

Coordinates: `a`-endpoints are multiples of `2⁻³²`; for `PeelL` the boxes are in
`(a, d)` with `x = a + d`, for `PeelU` in `(a, x)`; `d`- and `x`-breakpoints are multiples
of `2⁻¹⁶`.
-/

namespace KellerKlein.Num

open KellerKlein Ball

/-! ### A kernel-reducible square root

`Nat.sqrt` is defined by well-founded recursion, which the kernel does not reduce well.
Newton's iteration with structural fuel produces a candidate `r`; the candidate is accepted
only after checking `r² ≤ m` (lower bound) or `m < (r + 1)²` (upper bound), and replaced by a
trivial bound otherwise. -/

def newtonStep (m r : ℕ) : ℕ := Nat.div (Nat.add r (Nat.div m r)) 2

def isqrtAux : ℕ → ℕ → ℕ → ℕ
  | 0, _, r => r
  | k + 1, m, r => bif Nat.blt (newtonStep m r) r then isqrtAux k m (newtonStep m r) else r

def isqrt (m : ℕ) : ℕ := isqrtAux 100 m (Nat.add (Nat.div m S) S)

/-- A validated lower square root from a candidate `r`. -/
def sqrtLoOf (r m : ℕ) : ℕ := bif Nat.ble (Nat.mul r r) m then r else 0

/-- A validated strict upper square root from a candidate `r`. -/
def sqrtHiOf (r m : ℕ) : ℕ :=
  bif Nat.blt m (Nat.mul (Nat.add r 1) (Nat.add r 1)) then Nat.add r 1 else Nat.add m 1

def sqrtLo (m : ℕ) : ℕ := sqrtLoOf (isqrt m) m

def sqrtHi (m : ℕ) : ℕ := sqrtHiOf (isqrt m) m

/-- `√x` on a ball. -/
def sqrtKB (X : Ball) : Ball :=
  ofLoHi (sqrtLo (Nat.mul (Nat.sub X.p (Nat.add X.n X.r)) S), 0)
    (sqrtHi (Nat.mul (Nat.sub (Nat.add X.p X.r) X.n) S), 0)

/-! ### Checkers -/

/-- `H(x) = 2 c(x)` on a ball of nonnegative reals. -/
def HB (X : Ball) : Ball := mulNat (cB X) 2

/-- `σ(a) = √(1 - a²)`. -/
def sigB (A : Ball) : Ball := sqrtKB (sub one (mul A A))

/-- An upper bound for the level `min (a/σ(a)) 1`, `a ≤ a₁`. -/
def ellB (A1 : Ball) : Ball :=
  bif invOk (sigB A1) then Ball.min (divB A1 (sigB A1)) one else one

/-- `min x 4`. -/
def capB (X : Ball) : Ball := Ball.min X (ofNat 4)

/-- A lower bound for `loY a t`, `a ∈ [a₀, a₁]`, `t ≥ t₀ ≥ 0`. -/
def loYB (A0 A1 T0 : Ball) : Ball :=
  Ball.pos (Ball.max (sub (HB (capB (divB T0 (sigB A0)))) (HB (ellB A1)))
    (sub one (mulNat (gaussB (capB (divB T0 (sigB A0)))) 2)))

/-- An upper bound for `upY a t`, `a ≤ a₁`, `0 ≤ t ≤ t₁`. -/
def upYB (A1 T1 : Ball) : Ball :=
  Ball.min one (add (HB (ellB A1)) (HB (divB T1 (sigB A1))))

/-- `PeelL a (a + d)` on the box `[a₀, a₁] × [d₀, d₁]`. -/
def peelLBox (pa0 pa1 pd0 pd1 : ℕ) : Bool :=
  invOk (sigB (exact pa0 0)) &&
    leB (sub (HB (exact (Nat.add pa0 pd1) 0)) (HB (exact pa0 0)))
      (divNat (add (loYB (exact pa0 0) (exact pa1 0) (exact (Nat.add (Nat.mul pa0 2) pd0) 0))
        (loYB (exact pa0 0) (exact pa1 0) (exact pd0 0))) 2)

/-- `PeelU a x` on the box `[a₀, a₁] × [x₀, x₁]`; each branch of `PeelU` is checked unless
the box lies entirely on the other side of the diagonal `x = a`. -/
def peelUBox (pa0 pa1 px0 px1 : ℕ) : Bool :=
  let R := add (HB (exact pa0 0)) (HB (exact px0 0))
  let U1 := upYB (exact pa1 0) (exact (Nat.add px1 pa1) 0)
  invOk (sigB (exact pa0 0)) && invOk (sigB (exact pa1 0)) &&
    (Nat.blt px1 pa0 ||
      leB (divNat (add U1 (upYB (exact pa1 0) (exact (Nat.sub px1 pa0) 0))) 2) R) &&
    (Nat.ble pa1 px0 ||
      leB (divNat (sub U1 (loYB (exact pa0 0) (exact pa1 0) (exact (Nat.sub pa0 px1) 0))) 2) R)

/-- All boxes `[m_i, m_{i+1}]` of a chain pass (`PeelL`). -/
def chainL (pa0 pa1 : ℕ) : ℕ → List ℕ → Bool
  | _, [] => true
  | m, m' :: l => peelLBox pa0 pa1 (Nat.mul m xiUnit) (Nat.mul m' xiUnit) && chainL pa0 pa1 m' l

/-- All boxes `[m_i, m_{i+1}]` of a chain pass (`PeelU`). -/
def chainU (pa0 pa1 : ℕ) : ℕ → List ℕ → Bool
  | _, [] => true
  | m, m' :: l => peelUBox pa0 pa1 (Nat.mul m xiUnit) (Nat.mul m' xiUnit) && chainU pa0 pa1 m' l

/-- Beyond `x = a₀ + d_K` the lower half has `c(a) ≥ e^{-x²/2}`. -/
def endLLarge (pa0 mK : ℕ) : Bool :=
  leB (gaussB (exact (Nat.add pa0 (Nat.mul mK xiUnit)) 0)) (cB (exact pa0 0))

/-- Beyond `x_K` the upper half has `H(x) + H(a) ≥ 1`. -/
def endU (pa0 mK : ℕ) : Bool :=
  leB one (add (HB (exact (Nat.mul mK xiUnit) 0)) (HB (exact pa0 0)))

/-- `H(0.675) ≥ 1/2`. -/
def c675Ok : Bool := leB (ofRat 1 4) (cB (ofRat 675 1000))

noncomputable section

/-! ### Soundness of the ball functions -/

lemma sqrtLoOf_sq_le (r m : ℕ) : sqrtLoOf r m * sqrtLoOf r m ≤ m := by
  unfold sqrtLoOf
  cases h : Nat.ble (Nat.mul r r) m
  · simp
  · simpa using h

lemma lt_sqrtHiOf_sq (r m : ℕ) : m < sqrtHiOf r m * sqrtHiOf r m := by
  unfold sqrtHiOf
  cases h : Nat.blt m (Nat.mul (Nat.add r 1) (Nat.add r 1))
  · simp only [cond_false, Nat.add_eq]
    nlinarith
  · simpa using h

lemma sqrtLo_sq_le (m : ℕ) : sqrtLo m * sqrtLo m ≤ m := sqrtLoOf_sq_le (isqrt m) m

lemma lt_sqrtHi_sq (m : ℕ) : m < sqrtHi m * sqrtHi m := lt_sqrtHiOf_sq (isqrt m) m

lemma sqrtHi_pos (m : ℕ) : 0 < sqrtHi m := by
  have h := lt_sqrtHi_sq m
  rcases Nat.eq_zero_or_pos (sqrtHi m) with h0 | h0
  · rw [h0] at h
    simp at h
  · exact h0

lemma sqrtLo_le_sqrt (m : ℕ) : (sqrtLo m : ℝ) ≤ Real.sqrt m := by
  apply Real.le_sqrt_of_sq_le
  have h := sqrtLo_sq_le m
  have h' : ((sqrtLo m * sqrtLo m : ℕ) : ℝ) ≤ m := by exact_mod_cast h
  push_cast at h'
  nlinarith

lemma sqrt_lt_sqrtHi (m : ℕ) : Real.sqrt m < sqrtHi m := by
  rw [Real.sqrt_lt' (by exact_mod_cast sqrtHi_pos m)]
  have h := lt_sqrtHi_sq m
  have h' : (m : ℝ) < ((sqrtHi m * sqrtHi m : ℕ) : ℝ) := by exact_mod_cast h
  push_cast at h'
  nlinarith

lemma mem_sqrtKB {X : Ball} {x : ℝ} (hx : x ∈ X) : Real.sqrt x ∈ sqrtKB X := by
  rw [mem_iff] at hx
  unfold sqrtKB
  apply mem_ofLoHi
  · simp only [SP.val, Nat.cast_zero, sub_zero]
    rcases le_or_lt x 0 with h | h
    · have hl : Nat.sub X.p (Nat.add X.n X.r) = 0 := by
        have : (X.p : ℝ) ≤ X.n + X.r := by nlinarith [S_pos]
        have : X.p ≤ X.n + X.r := by exact_mod_cast this
        simp only [Nat.sub_eq, Nat.add_eq]; omega
      rw [hl]
      simp only [Nat.mul_eq, Nat.zero_mul]
      calc ((sqrtLo 0 : ℕ) : ℝ) ≤ Real.sqrt ((0 : ℕ) : ℝ) := sqrtLo_le_sqrt 0
        _ = 0 := by simp
        _ ≤ Real.sqrt x * S := mul_nonneg (Real.sqrt_nonneg _) S_pos.le
    · have h1 : ((Nat.sub X.p (Nat.add X.n X.r) : ℕ) : ℝ) ≤ x * S := by
        simp only [Nat.sub_eq, Nat.add_eq]
        rcases le_total X.p (X.n + X.r) with h' | h'
        · rw [Nat.sub_eq_zero_of_le h']; simp; nlinarith [S_pos]
        · rw [Nat.cast_sub h']; push_cast; linarith
      calc ((sqrtLo (Nat.mul (Nat.sub X.p (Nat.add X.n X.r)) S) : ℕ) : ℝ)
          ≤ Real.sqrt ((Nat.mul (Nat.sub X.p (Nat.add X.n X.r)) S : ℕ) : ℝ) := sqrtLo_le_sqrt _
        _ ≤ Real.sqrt (x * S * S) := by
          apply Real.sqrt_le_sqrt
          simp only [Nat.mul_eq]; push_cast
          exact mul_le_mul_of_nonneg_right h1 S_pos.le
        _ = Real.sqrt x * S := by
          rw [show x * S * S = x * (S * S) by ring, Real.sqrt_mul h.le, Real.sqrt_mul_self S_pos.le]
  · simp only [SP.val, Nat.cast_zero, sub_zero]
    rcases le_or_lt x 0 with h | h
    · rw [Real.sqrt_eq_zero'.mpr h, zero_mul]; positivity
    · have h1 : x * S ≤ ((Nat.sub (Nat.add X.p X.r) X.n : ℕ) : ℝ) := by
        simp only [Nat.sub_eq, Nat.add_eq]
        rcases le_total (X.p + X.r) X.n with h' | h'
        · rw [Nat.sub_eq_zero_of_le h']
          have : ((X.p + X.r : ℕ) : ℝ) ≤ X.n := by exact_mod_cast h'
          push_cast at this; nlinarith [S_pos]
        · rw [Nat.cast_sub h']; push_cast; linarith
      have := sqrt_lt_sqrtHi (Nat.mul (Nat.sub (Nat.add X.p X.r) X.n) S)
      calc Real.sqrt x * S = Real.sqrt (x * S * S) := by
            rw [show x * S * S = x * (S * S) by ring, Real.sqrt_mul h.le,
              Real.sqrt_mul_self S_pos.le]
        _ ≤ Real.sqrt ((Nat.mul (Nat.sub (Nat.add X.p X.r) X.n) S : ℕ) : ℝ) := by
          apply Real.sqrt_le_sqrt
          simp only [Nat.mul_eq]; push_cast
          exact mul_le_mul_of_nonneg_right h1 S_pos.le
        _ ≤ _ := this.le

lemma mem_HB {X : Ball} {x : ℝ} (hx : x ∈ X) (h0 : 0 ≤ x) : H x ∈ HB X := by
  have e : H x = c x * ((2 : ℕ) : ℝ) := by
    unfold H
    push_cast
    ring
  rw [e]
  exact mem_mulNat (mem_cB hx h0) 2

lemma mem_sigB {A : Ball} {a : ℝ} (ha : a ∈ A) : peelSigma a ∈ sigB A := by
  have e : peelSigma a = Real.sqrt (1 - a * a) := by
    unfold peelSigma
    rw [sq]
  rw [e]
  exact mem_sqrtKB (mem_sub mem_one (mem_mul ha ha))

lemma peelSigma_nonneg (a : ℝ) : 0 ≤ peelSigma a := Real.sqrt_nonneg _

lemma peelSigma_anti {a b : ℝ} (ha : 0 ≤ a) (hab : a ≤ b) : peelSigma b ≤ peelSigma a := by
  unfold peelSigma
  apply Real.sqrt_le_sqrt
  nlinarith

lemma lt_one_of_peelSigma_ne {a : ℝ} (ha : 0 ≤ a) (h : peelSigma a ≠ 0) : a < 1 := by
  by_contra hc
  push_neg at hc
  apply h
  unfold peelSigma
  apply Real.sqrt_eq_zero'.mpr
  nlinarith

lemma peelSigma_pos_of {a : ℝ} (ha : 0 ≤ a) (ha1 : a < 1) : 0 < peelSigma a :=
  peelSigma_pos (by rw [abs_of_nonneg ha]; exact ha1)

lemma peelSigma_pos_of_invOk {A : Ball} (hok : invOk (sigB A) = true) {a : ℝ} (ha : a ∈ A) :
    0 < peelSigma a :=
  lt_of_le_of_ne (peelSigma_nonneg _) (Ne.symm (ne_zero_of_invOk hok (mem_sigB ha)))

lemma ell_bound {A1 : Ball} {a1 a : ℝ} (ha1 : a1 ∈ A1) (ha : 0 ≤ a) (haa : a ≤ a1) :
    ∃ ℓ, ℓ ∈ ellB A1 ∧ 0 ≤ ℓ ∧ peelLevel a ≤ ℓ := by
  unfold ellB
  cases h : invOk (sigB A1)
  · refine ⟨1, ?_, zero_le_one, min_le_right _ _⟩
    rw [cond_false]
    exact mem_one
  · have hσ1 := mem_sigB ha1
    have hσpos : 0 < peelSigma a1 := peelSigma_pos_of_invOk h ha1
    have ha10 : 0 ≤ a1 := ha.trans haa
    refine ⟨Min.min (a1 / peelSigma a1) 1, ?_, ?_, ?_⟩
    · rw [cond_true]
      exact mem_min (mem_divB h ha1 hσ1) mem_one
    · exact le_min (div_nonneg ha10 hσpos.le) zero_le_one
    · unfold peelLevel
      apply min_le_min _ le_rfl
      have hσa : peelSigma a1 ≤ peelSigma a := peelSigma_anti ha haa
      have hσa0 : 0 < peelSigma a := hσpos.trans_le hσa
      calc a / peelSigma a ≤ a1 / peelSigma a := div_le_div_of_nonneg_right haa hσa0.le
        _ ≤ a1 / peelSigma a1 := div_le_div_of_nonneg_left ha10 hσpos hσa

lemma mem_capB {X : Ball} {x : ℝ} (hx : x ∈ X) : Min.min x 4 ∈ capB X := by
  have h := mem_min hx (mem_ofNat 4)
  rw [Nat.cast_ofNat] at h
  exact h

lemma loYB_spec {A0 A1 T0 : Ball} (hok : invOk (sigB A0) = true) {a0 a1 a t0 t : ℝ}
    (ha0 : a0 ∈ A0) (ha1 : a1 ∈ A1) (ht0 : t0 ∈ T0) (h0 : 0 ≤ a0) (h0a : a0 ≤ a)
    (ha1' : a ≤ a1) (hlt : a < 1) (ht00 : 0 ≤ t0) (ht : t0 ≤ t) :
    ∃ v, v ∈ loYB A0 A1 T0 ∧ v ≤ loY a t := by
  have hσ0m := mem_sigB ha0
  have hσ0 : 0 < peelSigma a0 := peelSigma_pos_of_invOk hok ha0
  have ha : 0 ≤ a := h0.trans h0a
  have hσ : 0 < peelSigma a := peelSigma_pos_of ha hlt
  have hσle : peelSigma a ≤ peelSigma a0 := peelSigma_anti h0 h0a
  have hu := mem_divB hok ht0 hσ0m
  have hu0 : 0 ≤ t0 / peelSigma a0 := div_nonneg ht00 hσ0.le
  have hut : t0 / peelSigma a0 ≤ t / peelSigma a := by
    calc t0 / peelSigma a0 ≤ t / peelSigma a0 := div_le_div_of_nonneg_right ht hσ0.le
      _ ≤ t / peelSigma a := div_le_div_of_nonneg_left (ht00.trans ht) hσ hσle
  have hxm := mem_capB hu
  have hx00 : 0 ≤ Min.min (t0 / peelSigma a0) 4 := le_min hu0 (by norm_num)
  have hxt : Min.min (t0 / peelSigma a0) 4 ≤ t / peelSigma a := (min_le_left _ _).trans hut
  obtain ⟨ℓ, hℓm, hℓ0, hℓ⟩ := ell_bound ha1 ha ha1'
  refine ⟨Max.max 0 (Max.max (H (Min.min (t0 / peelSigma a0) 4) - H ℓ)
    (1 - gaussian (Min.min (t0 / peelSigma a0) 4) * ((2 : ℕ) : ℝ))), ?_, ?_⟩
  · exact mem_pos (mem_max (mem_sub (mem_HB hxm hx00) (mem_HB hℓm hℓ0))
      (mem_sub mem_one (mem_mulNat (mem_gaussB hxm) 2)))
  · unfold loY
    apply max_le_max le_rfl
    apply max_le_max
    · exact sub_le_sub (H_mono hxt) (H_mono hℓ)
    · have hg : Real.exp (-((t / peelSigma a) ^ 2) / 2) ≤
          gaussian (Min.min (t0 / peelSigma a0) 4) := gaussian_anti hx00 hxt
      push_cast
      linarith

lemma upYB_spec {A1 T1 : Ball} (hok : invOk (sigB A1) = true) {a1 a t1 t : ℝ}
    (ha1 : a1 ∈ A1) (ht1 : t1 ∈ T1) (ha : 0 ≤ a) (ha1' : a ≤ a1) (ht0 : 0 ≤ t)
    (ht : t ≤ t1) : ∃ w, w ∈ upYB A1 T1 ∧ upY a t ≤ w := by
  have hσ1m := mem_sigB ha1
  have hσ1 : 0 < peelSigma a1 := peelSigma_pos_of_invOk hok ha1
  have hσle : peelSigma a1 ≤ peelSigma a := peelSigma_anti ha ha1'
  have hσ : 0 < peelSigma a := hσ1.trans_le hσle
  have hu := mem_divB hok ht1 hσ1m
  have hu0 : 0 ≤ t1 / peelSigma a1 := div_nonneg (ht0.trans ht) hσ1.le
  have hut : t / peelSigma a ≤ t1 / peelSigma a1 := by
    calc t / peelSigma a ≤ t / peelSigma a1 := div_le_div_of_nonneg_left ht0 hσ1 hσle
      _ ≤ t1 / peelSigma a1 := div_le_div_of_nonneg_right ht hσ1.le
  obtain ⟨ℓ, hℓm, hℓ0, hℓ⟩ := ell_bound ha1 ha ha1'
  refine ⟨Min.min 1 (H ℓ + H (t1 / peelSigma a1)), ?_, ?_⟩
  · exact mem_min mem_one (mem_add (mem_HB hℓm hℓ0) (mem_HB hu hu0))
  · unfold upY
    exact min_le_min le_rfl (add_le_add (H_mono hℓ) (H_mono hut))

/-! ### Monotonicity of the left side of `PeelL` -/

lemma c_shift_anti {a0 a d : ℝ} (h0 : 0 ≤ a0) (ha : a0 ≤ a) (hd : 0 ≤ d) :
    c (a + d) - c (a0 + d) ≤ c a - c a0 := by
  rw [c_sub_c_eq, c_sub_c_eq]
  have e : (∫ t in (a0 + d)..(a + d), phi t) = ∫ s in a0..a, phi (s + d) :=
    (intervalIntegral.integral_comp_add_right (fun t => phi t) d).symm
  rw [e]
  apply intervalIntegral.integral_mono_on ha
  · exact (continuous_phi.comp (continuous_add_right d)).intervalIntegrable _ _
  · exact continuous_phi.intervalIntegrable _ _
  · intro s hs
    unfold phi
    apply mul_le_mul_of_nonneg_right _ phi0_pos.le
    exact gaussian_anti (by linarith [hs.1]) (by linarith)

lemma H_shift_anti {a0 a d : ℝ} (h0 : 0 ≤ a0) (ha : a0 ≤ a) (hd : 0 ≤ d) :
    H (a + d) - H a ≤ H (a0 + d) - H a0 := by
  have := c_shift_anti h0 ha hd
  unfold H
  linarith

lemma pt_add (p q : ℕ) : pt (Nat.add p q) = pt p + pt q := by
  simp only [pt, Nat.add_eq, Nat.cast_add, add_div]

lemma pt_two_mul_add (p q : ℕ) : pt (Nat.add (Nat.mul p 2) q) = 2 * pt p + pt q := by
  simp only [pt, Nat.add_eq, Nat.mul_eq, Nat.cast_add, Nat.cast_mul, Nat.cast_ofNat]
  ring

lemma pt_mul_two (p : ℕ) : pt (Nat.mul 2 p) = 2 * pt p := by
  simp only [pt, Nat.mul_eq, Nat.cast_mul, Nat.cast_ofNat]
  ring

/-! ### Soundness of the box checks -/

theorem peelLBox_sound {pa0 pa1 pd0 pd1 : ℕ} (h : peelLBox pa0 pa1 pd0 pd1 = true) {a d : ℝ}
    (ha0 : pt pa0 ≤ a) (ha1 : a ≤ pt pa1) (hlt : a < 1) (hd0 : pt pd0 ≤ d)
    (hd1 : d ≤ pt pd1) : PeelL a (a + d) := by
  unfold peelLBox at h
  rw [Bool.and_eq_true] at h
  obtain ⟨hok, hle⟩ := h
  have h00 := pt_nonneg pa0
  have hd00 := pt_nonneg pd0
  have hd : 0 ≤ d := hd00.trans hd0
  have hL1 := H_shift_anti h00 ha0 hd
  have hL2 : H (pt pa0 + d) ≤ H (pt pa0 + pt pd1) := H_mono (by linarith)
  have hm1 := mem_HB (mem_pt (Nat.add pa0 pd1)) (pt_nonneg _)
  rw [pt_add] at hm1
  have hm := mem_sub hm1 (mem_HB (mem_pt pa0) h00)
  obtain ⟨v1, hv1, hv1le⟩ := loYB_spec hok (mem_pt pa0) (mem_pt pa1)
    (mem_pt (Nat.add (Nat.mul pa0 2) pd0)) h00 ha0 ha1 hlt (pt_nonneg _)
    (t := a + d + a) (by rw [pt_two_mul_add]; linarith)
  obtain ⟨v2, hv2, hv2le⟩ := loYB_spec hok (mem_pt pa0) (mem_pt pa1) (mem_pt pd0) h00 ha0 ha1
    hlt hd00 (t := a + d - a) (by linarith)
  have hr := mem_divNat (mem_add hv1 hv2) (by norm_num : 0 < 2)
  have key := le_of_leB hle hm hr
  unfold PeelL
  push_cast at key
  linarith

theorem peelUBox_sound {pa0 pa1 px0 px1 : ℕ} (h : peelUBox pa0 pa1 px0 px1 = true) {a x : ℝ}
    (ha0 : pt pa0 ≤ a) (ha1 : a ≤ pt pa1) (hx0 : pt px0 ≤ x) (hx1 : x ≤ pt px1) :
    PeelU a x := by
  simp only [peelUBox, Bool.and_eq_true, Bool.or_eq_true] at h
  obtain ⟨⟨⟨hok0, hok1⟩, hU⟩, hL⟩ := h
  have h00 := pt_nonneg pa0
  have ha : 0 ≤ a := h00.trans ha0
  have hx : 0 ≤ x := (pt_nonneg px0).trans hx0
  have ha1lt : a < 1 := lt_of_le_of_lt ha1 (lt_one_of_peelSigma_ne (pt_nonneg _)
    (ne_zero_of_invOk hok1 (mem_sigB (mem_pt pa1))))
  have hR := mem_add (mem_HB (mem_pt pa0) h00) (mem_HB (mem_pt px0) (pt_nonneg _))
  have hRle : H (pt pa0) + H (pt px0) ≤ H a + H x := add_le_add (H_mono ha0) (H_mono hx0)
  obtain ⟨w1, hw1, hw1le⟩ := upYB_spec hok1 (mem_pt pa1) (mem_pt (Nat.add px1 pa1)) ha ha1
    (t := x + a) (by linarith) (by rw [pt_add]; linarith)
  unfold PeelU
  split_ifs with hax
  · rcases hU with hb | hle
    · have hlt : px1 < pa0 := by simpa using hb
      have := pt_lt hlt
      linarith
    · have hpx : pa0 ≤ px1 := by
        by_contra hc
        push_neg at hc
        have := pt_lt hc
        linarith
      obtain ⟨w2, hw2, hw2le⟩ := upYB_spec hok1 (mem_pt pa1) (mem_pt (Nat.sub px1 pa0)) ha ha1
        (t := x - a) (by linarith) (by rw [Nat.sub_eq, pt_sub hpx]; linarith)
      have key := le_of_leB hle (mem_divNat (mem_add hw1 hw2) (by norm_num)) hR
      push_cast at key
      linarith
  · rcases hL with hb | hle
    · have hle' : pa1 ≤ px0 := by simpa using hb
      have := pt_le hle'
      linarith
    · have ht0 : pt (Nat.sub pa0 px1) ≤ a - x := by
        by_cases hp : px1 ≤ pa0
        · rw [Nat.sub_eq, pt_sub hp]
          linarith
        · push_neg at hp
          rw [Nat.sub_eq, Nat.sub_eq_zero_of_le hp.le]
          simp only [pt, Nat.cast_zero, zero_div]
          linarith
      obtain ⟨v, hv, hvle⟩ := loYB_spec hok0 (mem_pt pa0) (mem_pt pa1) (mem_pt (Nat.sub pa0 px1))
        h00 ha0 ha1 ha1lt (pt_nonneg _) (t := a - x) ht0
      have key := le_of_leB hle (mem_divNat (mem_sub hw1 hv) (by norm_num)) hR
      push_cast at key
      rw [add_comm a x]
      linarith

/-! ### Chains, slices and groups -/

/-- `PeelL a (a + d)` on a rectangle of `(a, d)`. -/
def PeelLRect (pa0 pa1 m m' : ℕ) : Prop :=
  ∀ a d : ℝ, pt pa0 ≤ a → a ≤ pt pa1 → a < 1 → pt (Nat.mul m xiUnit) ≤ d →
    d ≤ pt (Nat.mul m' xiUnit) → PeelL a (a + d)

/-- `PeelU a x` on a rectangle of `(a, x)`. -/
def PeelURect (pa0 pa1 m m' : ℕ) : Prop :=
  ∀ a x : ℝ, pt pa0 ≤ a → a ≤ pt pa1 → pt (Nat.mul m xiUnit) ≤ x →
    x ≤ pt (Nat.mul m' xiUnit) → PeelU a x

theorem chainL_rect {pa0 pa1 : ℕ} : ∀ (l : List ℕ) (m : ℕ), l ≠ [] →
    chainL pa0 pa1 m l = true → PeelLRect pa0 pa1 m (lastOf m l)
  | [], _, hl, _ => absurd rfl hl
  | m' :: l, m, _, h => by
    simp only [chainL, Bool.and_eq_true] at h
    obtain ⟨hb, hl⟩ := h
    intro a d ha0 ha1 hlt h0 h1
    by_cases hd : d ≤ pt (Nat.mul m' xiUnit)
    · exact peelLBox_sound hb ha0 ha1 hlt h0 hd
    · cases l with
      | nil =>
        simp only [lastOf] at h1
        exact absurd h1 hd
      | cons m'' l' =>
        exact chainL_rect (m'' :: l') m' (List.cons_ne_nil _ _) hl a d ha0 ha1 hlt
          (le_of_lt (lt_of_not_le hd)) (by simpa only [lastOf] using h1)

theorem chainU_rect {pa0 pa1 : ℕ} : ∀ (l : List ℕ) (m : ℕ), l ≠ [] →
    chainU pa0 pa1 m l = true → PeelURect pa0 pa1 m (lastOf m l)
  | [], _, hl, _ => absurd rfl hl
  | m' :: l, m, _, h => by
    simp only [chainU, Bool.and_eq_true] at h
    obtain ⟨hb, hl⟩ := h
    intro a x ha0 ha1 h0 h1
    by_cases hx : x ≤ pt (Nat.mul m' xiUnit)
    · exact peelUBox_sound hb ha0 ha1 h0 hx
    · cases l with
      | nil =>
        simp only [lastOf] at h1
        exact absurd h1 hx
      | cons m'' l' =>
        exact chainU_rect (m'' :: l') m' (List.cons_ne_nil _ _) hl a x ha0 ha1
          (le_of_lt (lt_of_not_le hx)) (by simpa only [lastOf] using h1)

theorem sliceL {pa0 pa1 m m' : ℕ} {l : List ℕ} (hl : l ≠ []) (h : chainL pa0 pa1 m l = true)
    (hlast : lastOf m l = m') : PeelLRect pa0 pa1 m m' := by
  rw [← hlast]
  exact chainL_rect l m hl h

theorem sliceU {pa0 pa1 m m' : ℕ} {l : List ℕ} (hl : l ≠ []) (h : chainU pa0 pa1 m l = true)
    (hlast : lastOf m l = m') : PeelURect pa0 pa1 m m' := by
  rw [← hlast]
  exact chainU_rect l m hl h

theorem rectL_glue {pa0 pa1 m1 m2 m3 : ℕ} (h1 : PeelLRect pa0 pa1 m1 m2)
    (h2 : PeelLRect pa0 pa1 m2 m3) : PeelLRect pa0 pa1 m1 m3 := by
  intro a d ha0 ha1 hlt h0 h3
  by_cases h : d ≤ pt (Nat.mul m2 xiUnit)
  · exact h1 a d ha0 ha1 hlt h0 h
  · exact h2 a d ha0 ha1 hlt (le_of_lt (lt_of_not_le h)) h3

theorem rectU_glue {pa0 pa1 m1 m2 m3 : ℕ} (h1 : PeelURect pa0 pa1 m1 m2)
    (h2 : PeelURect pa0 pa1 m2 m3) : PeelURect pa0 pa1 m1 m3 := by
  intro a x ha0 ha1 h0 h3
  by_cases h : x ≤ pt (Nat.mul m2 xiUnit)
  · exact h1 a x ha0 ha1 h0 h
  · exact h2 a x ha0 ha1 (le_of_lt (lt_of_not_le h)) h3

/-- The statement certified for `PeelL` with large coefficients at a given `a`. -/
def PeelLLargeAt (a : ℝ) : Prop :=
  a < 1 → ∀ x, a < x → c a < Real.exp (-(x ^ 2) / 2) → PeelL a x

/-- The statement certified for `PeelL` in the near range at a given `a`. -/
def PeelLNearAt (a : ℝ) : Prop :=
  a < 1 → ∀ x, a < x → x ≤ 3 * a / 2 → PeelL a x

/-- The statement certified for `PeelU` at a given `a`. -/
def PeelUAt (a : ℝ) : Prop :=
  ∀ x, a / 2 ≤ x → H x + H a < 1 → PeelU a x

lemma pt_zero_mul : pt (Nat.mul 0 xiUnit) = 0 := by simp [pt]

theorem group_peelLLarge {k0 k1 mK : ℕ}
    (hs : PeelLRect (Nat.mul k0 aUnit) (Nat.mul k1 aUnit) 0 mK)
    (he : endLLarge (Nat.mul k0 aUnit) mK = true) :
    ∀ a, pt (Nat.mul k0 aUnit) ≤ a → a ≤ pt (Nat.mul k1 aUnit) → PeelLLargeAt a := by
  intro a ha0 ha1 hlt x hx hexp
  have hxa : x = a + (x - a) := by ring
  by_cases hK : x - a ≤ pt (Nat.mul mK xiUnit)
  · have := hs a (x - a) ha0 ha1 hlt (by rw [pt_zero_mul]; linarith) hK
    rwa [← hxa] at this
  · exfalso
    have h00 := pt_nonneg (Nat.mul k0 aUnit)
    have hxe : pt (Nat.mul k0 aUnit) + pt (Nat.mul mK xiUnit) ≤ x := by linarith
    have hm := mem_pt (Nat.add (Nat.mul k0 aUnit) (Nat.mul mK xiUnit))
    rw [pt_add] at hm
    have h1 := le_of_leB he (mem_gaussB hm) (mem_cB (mem_pt _) h00)
    have hg := gaussian_anti (add_nonneg h00 (pt_nonneg _)) hxe
    have hc := c_mono ha0
    have : Real.exp (-(x ^ 2) / 2) = gaussian x := rfl
    linarith

theorem group_peelLNear {k0 k1 mK : ℕ}
    (hs : PeelLRect (Nat.mul k0 aUnit) (Nat.mul k1 aUnit) 0 mK)
    (he : Nat.ble (Nat.mul k1 aUnit) (Nat.mul 2 (Nat.mul mK xiUnit)) = true) :
    ∀ a, pt (Nat.mul k0 aUnit) ≤ a → a ≤ pt (Nat.mul k1 aUnit) → PeelLNearAt a := by
  intro a ha0 ha1 hlt x hx hx3
  have hxa : x = a + (x - a) := by ring
  have hle : Nat.mul k1 aUnit ≤ Nat.mul 2 (Nat.mul mK xiUnit) := Nat.le_of_ble_eq_true he
  have hpt := pt_le hle
  rw [pt_mul_two] at hpt
  have := hs a (x - a) ha0 ha1 hlt (by rw [pt_zero_mul]; linarith) (by linarith)
  rwa [← hxa] at this

theorem group_peelU {k0 k1 m0 mK : ℕ}
    (hs : PeelURect (Nat.mul k0 aUnit) (Nat.mul k1 aUnit) m0 mK)
    (h0 : Nat.ble (Nat.mul 2 (Nat.mul m0 xiUnit)) (Nat.mul k0 aUnit) = true)
    (he : endU (Nat.mul k0 aUnit) mK = true) :
    ∀ a, pt (Nat.mul k0 aUnit) ≤ a → a ≤ pt (Nat.mul k1 aUnit) → PeelUAt a := by
  intro a ha0 ha1 x hx htail
  have hle : Nat.mul 2 (Nat.mul m0 xiUnit) ≤ Nat.mul k0 aUnit := Nat.le_of_ble_eq_true h0
  have hpt := pt_le hle
  rw [pt_mul_two] at hpt
  by_cases hK : x ≤ pt (Nat.mul mK xiUnit)
  · exact hs a x ha0 ha1 (by linarith) hK
  · exfalso
    have h00 := pt_nonneg (Nat.mul k0 aUnit)
    have h1 := le_of_leB he mem_one
      (mem_add (mem_HB (mem_pt (Nat.mul mK xiUnit)) (pt_nonneg _)) (mem_HB (mem_pt _) h00))
    have h2 := H_mono (le_of_lt (lt_of_not_le hK))
    have h3 := H_mono ha0
    linarith

theorem c675_of_ok (h : c675Ok = true) : 1 / 4 ≤ c (675 / 1000) := by
  have hx := mem_ofRat 675 (by norm_num : 0 < 1000)
  have h1 := mem_ofRat 1 (by norm_num : 0 < 4)
  have := le_of_leB h h1 (mem_cB hx (by norm_num))
  push_cast at this
  linarith

end

end KellerKlein.Num
