# NOTES (locked log). Tags: [PROVED] [CONDITIONAL] [NUMERICAL] [FAILED] [OBSERVATION]

Conventions: `f(x)=|x|^p`, `m_p = E|Z|^p = 2^{p/2}Γ((p+1)/2)/√π`, `A = Σ E|X_i|^p`,
`B = Σ E X_i^2`. For a finite measure `G` on `R\{0}` with `∫x dG = 0`, `X_G` is compound Poisson
with Lévy measure `G` (`E e^{itX_G} = exp ∫(e^{itx}-1)G(dx)`); `H(du) = u^2 G(du)` (Pinelis' units).

## 2026-10-26 17:25–18:40 UTC

1. [OBSERVATION] Samuels/Feige/Tomaszewski-counterpart/Steinhaus targets resolved 2025–2026
   (see TARGETS.md); dropped.

2. [NUMERICAL] Killer pass on Pinelis' conjectures (scripts `numerics/scan_families.py`,
   `numerics/killer_search.py`, moment routine `numerics/idlaw.py` validated vs mpmath to 1e-15):
   * p=3.5: Gaussian+one Poisson atom, two-sided and same-side two-atom Lévy measures, all below
     `A + m_p B^{p/2}`; best relative gaps -4e-5 (degenerate corner) to -2e-2.
   * p=4.5: two-sided two-atom measures below the Poisson value by 1e-4..5e-3 relative; same-side
     two-atom measures below by 1e-9..3e-6 (maximum at the merged single atom).
   * Apparent excesses ~1e-8 at λ~1e7 were float artefacts (scipy pmf mass 1-5e-9); fixed by
     renormalisation; the Edgeworth computation confirms they are not real.

3. [NUMERICAL] KKT shape test (`numerics/kkt_shape.py`): for `g_±(v) = Ψ_W(±v^{1/(p-2)})`,
   `Ψ_W(u) = E[f(W+u)-f(W)-u f'(W)]/u^2`:
   * p=3.5: symmetric W ⇒ g_± convex; skewed W ⇒ convex on the skew side, NOT convex on the anti-skew side.
   * p=4.5: symmetric W ⇒ g_± concave; skewed W ⇒ concave on the skew side, NOT concave on the anti-skew side.
   So a pure "convexity of the KKT curve" proof cannot work for either range with general W.

4. [PROVED] (writeup: RESULT_rosenthal34.tex) **Theorem.** For `3 <= p <= 4` and independent zero-mean
   `X_1..X_n` with finite p-th moments,
   `E|ΣX_i|^p <= ΣE|X_i|^p + m_p (ΣE X_i^2)^{p/2}`; the constant is sharp. Hence Pinelis'
   exact bound `ℰ_{p;A,B} = A + m_p B^{p/2}` holds on all of `(2,4]` (with his (2,3]).
   Proof: (a) Poissonisation `E f(S) <= E f(X_G)` for `f''` convex (`p>=3`), self-contained proof via
   Jensen on `u(s)=E f(s+ξ)-f(s)`; (b) for `2<p<4`,
   `|x|^p = κ_p ∫_0^∞ (cos tx - 1 + t²x²/2) t^{-p-1} dt`, `κ_p>0`, gives
   `E|X_G|^p - A - m_p B^{p/2} = κ_p ∫_0^∞ [e^{-a}cos b + a - e^{-g} - g] t^{-p-1} dt`
   with `a(t)=∫(1-cos tx)dG ∈ [0, g(t)]`, `g = t²B/2`, `b=∫sin(tx)dG`; the bracket is
   `<= F(a)-F(g) <= 0`, `F(x)=e^{-x}+x` increasing. (c) Sharpness: Gaussian + one far jump.
   Numerical sanity check (`numerics/verify_34.py`, 60 random sums, exact summation, mpmath bracket):
   all three inequalities hold; closest approach -3.4e-4 relative.

5. [PROVED] (same writeup) **Counterexample** to the general-X extension suggested by Pinelis
   ("Theorem 1.5 should hold for p∈(3,4)"): with `X ≡ 1` and `S ≈ uΠ̃_λ` (u=1/2, λ=1/10),
   `E|1+S|^p > A + E|1+√B Z|^p` for p∈(3,4) (≈3% at p=3.8). Mechanism: the cubic Taylor term
   `C(p,3)|x_0|^{p-3}u^3` dominates `|u|^p` for small u when p>3. (Numerical value: NUMERICAL; the
   first-order asymptotic proof: PROVED in the writeup.)

7. [PROVED] (RESULT_rosenthal34.tex, Thm 1.4) General moment functions: if
   `f(x)=κx⁴+∫(cos tx-1+t²x²/2)μ(dt)` (equivalently f'' is a continuous negative-definite function,
   f(0)=f'(0)=0) and f'' is convex, then `E f(ΣX_i) <= ΣE f(X_i) + E f(√B Z)` (4th moments assumed).

8. [PROVED] (Cor 1.2) Hilbert-space version for 2<p<=4: `E‖ΣX_i‖^p <= ΣE‖X_i‖^p + E‖Γ‖^p <= ΣE‖X_i‖^p + m_p(ΣE‖X_i‖²)^{p/2}`
   by averaging the scalar theorem over directions (‖x‖^p = γ^{-1}∫|<θ,x>|^p dσ) + Minkowski in L^{p/2}.
   (Side check, not needed: for p∈[3,4] every second directional derivative of ‖x‖^p is convex on R^d — sympy:
   det Hessian ∝ 3+(k²-4)cos⁴θ, k=p-2; PSD at p=3.)

9. [NUMERICAL] Killer pass on Thm 1.1 (`numerics/killer_theorem34.py`, Nelder–Mead over sums of 1–4
   discrete zero-mean summands, p=3,3.3,3.7,3.95): sup ratio E|S|^p/(A+m_pB^{p/2}) → 1 only in the
   far-jump limit; apparent 1+1e-12 values were float artefacts (60-digit re-evaluation: 0.99927).

10. [NUMERICAL] T1 (4<p<5): restricted search (λ_cand∈[0.01,100], p=4.1..4.9, 1–2 atoms + Gaussian)
    converges to the single Poisson atom (ratio exactly 1, no competitor). First-order test of
    Pinelis' Thm 1.3 with an extra mean-zero X (`numerics/first_order_45.py`): the skew-side branch
    dominates and is concave ⇒ no first-order counterexample (contrast with 3<p<4).

11. [FAILED/OBSTRUCTION] T1 proof attempts:
    * Fourier identity for 4<p<6: `c'(E|X_G|^p-A) = ∫(1-a-e^{-a}cos b + g²/2) t^{-p-1}dt`; the Poisson is not a
      pointwise maximiser of the integrand (a* = λ(1-cos ct) oscillates), so no pointwise proof.
    * Second variation of G ↦ E|X_G|^p is `-Re∫ φ_G conj(δψ)² t^{-p-1}dt` — indefinite; Pinelis' Prop 2.11 sign
      `(q-4)(q-5)` flips for q∈(4,5): two-sided two-atom configurations can be local maxima along his
      perturbation family; numerically they are globally below Poisson by 1e-4..5e-3 (relative).
    * Smallest obstruction: (i) a "merge lemma" for two same-side atoms valid for the self-consistent
      background W=Y_H (fails for general W on the anti-skew side, cf. item 3), and (ii) a global
      comparison of two-sided two-atom laws with the Poisson.

12. [PROVED] (RESULT §7, Prop 7.1) Symmetrisation of the Lévy measure: for 2<p<4,
    `E|X̃_G|^p <= E|X_{G_s}|^p`; for 4<p<6, `E|X̃_G|^p >= E|X_{G_s}|^p` with
    `c'(E|X̃_G|^p - E|X_{G_s}|^p) = ∫ e^{-a}(1-cos b) t^{-p-1}dt`. Gives a SECOND proof of Thm 1.1
    (zero-mean ⇒ symmetric case of FHJSZ/Ibragimov–Sharakhmetov) and explains the threshold p=4.
    Equivalent form: with U,V iid half-time increments of the Lévy process, the skewness gain is
    `E|U+V|^p - E|U-V|^p`.

13. [CONDITIONAL] (Prop 7.3) For 4<p<5, Pinelis' Poisson conjecture follows from the skewness inequality (SI):
    `E|X̃_G|^p - E|X_{G_s}|^p <= c^p(E|Π_λ-λ|^p - E|Π_{λ/2}-Π'_{λ/2}|^p)` for all G with the same (A,B)
    (uses Utev's symmetric theorem for p>4 for the symmetric part).

14. [NUMERICAL] SI: 180 random Lévy measures (p=4.2,4.5,4.8,5.5; 30-digit stabilised quadrature,
    identity vs direct summation agree to ≤1.8e-7): ratio ≤ 1, = 1 only for (near-)single atoms;
    max over genuinely multi-atom G: 0.9954. Same-|x| mixed-sign family (where SI ⟺ conjecture):
    Poisson optimal for λ∈[0.1,100]. Sign alignment for fixed G_s: optimal in 180/180 cases.

15. [NUMERICAL] Extra-summand version for symmetric two-point X = ±x0 and p∈{3.2,3.5,3.8}: no violation in
    ~900 random compound-Poisson S (max rel gap -1.2e-8, limit). Conjecture: Pinelis' Thm 1.5 holds for p∈(3,4)
    iff X is symmetric (⇐ proved when φ_X ≥ 0; ⇒ "only if" direction false in general? only shown that skewed
    X with E[|X|^{p-3}sign X] ≠ 0 fail).

16. [NUMERICAL + heuristic asymptotics] Exact obstruction for 4<p<5: in the same-|x| family
    G_θ = (λ/2)((1+θ)δ_1+(1-θ)δ_{-1}), `c' d²/dθ² E|Y_θ|^p = ∫ e^{-λ(1-cos t)} λ²(t-sin t)² cos(θλ(t-sin t)) t^{-p-1}dt`.
    For large λ: bump at t=0 ~ λ^{(p-2)/2} (>0), lattice bumps at t=2πk ~ λ^{3/2}Σ(2πk)^{1-p}cos(2πkθλ) (either sign).
    p=4.5, λ=2e4, θλ≡1/2: value -3769 (bump +6808, lattice -10577) ⇒ NOT convex in θ; p=5.5: lattice ≪ bump.
    The endpoint θ=±1 is still the max (first-order: λ^{(p-2)/2} ≫ λ^{1/2}). So convexity/second-variation proofs
    must fail exactly for p<5 — matches Pinelis' q>5 requirement; source = lattice structure of Poisson ch.f.

17. [CHECK] Independent adversarial referee pass (subagent, 2026-10-26 ~19:15 UTC): no CRITICAL/MAJOR issues;
    Theorems A, D, E, F, Prop G, Cor B, C, Prop 9.1, Rem 9.2 (second proof) judged correct; all numerical claims
    reproduced (e.g. Rem 9.5: bump 6807.89, lattice -10576.88, total -3768.98). 20 MINOR issues, all addressed in
    commit "Address referee report". Referee's extra findings now in the paper: Theorem D also at p=4; the extension
    fails at p=4 for X≡1 (L-R = 4EX_1^3 - 3B^2 = 0.0345 for instance (i)); closed form 1/c_p = -(2/π)sin(pπ/2)Γ(p+1)
    confirmed to 30 digits. Remaining risk flagged by referee: priority vs Utev 1985 (Russian, not checked) — mitigated
    by Pinelis 2015 (Utev's coauthor) explicitly calling 3<p<4 open.

18. [NUMERICAL → see 19 for the PROVED part] λ→0 regime of T1 (rare large jumps): E|X̃_G|^p = A + Q(G) + O(|G|^3) with
    Q(G)=½∬K dGdG, K(x,y)=|x+y|^p-|x|^p-|y|^p-p|x|^{p-2}xy-p|y|^{p-2}yx (exact 2nd-order expansion in the rates).
    Max of Q under ∫x²dG=∫|x|^pdG=1 (bounded atoms, Nelder–Mead, 300 starts): single atom optimal (ratio 1.0000000000)
    for p=4.2,4.5,4.8,5.5; control p=3.5: small atoms win (ratio 105), as expected below p=4.
    Possible proof route (not done): in H-units κ(y,z)=K/(y²z²) is (p-4)-homogeneous; suffices
    κ(y,z) ≤ κ(1,1)[2/(p-2) + (p-4)/(2(p-2))(|y|^{p-2}+|z|^{p-2})] — true on the diagonal by Young; off-diagonal unchecked.

19. [PROVED] (RESULT Prop 9.6) Second-order optimality of the Poisson for 4<p≤5: exact identity
    K(x,y) = ¼ p(p-1)(p-2)(p-3) x²y² E|xV+yV'|^{p-4} (V,V' iid density 2(1-v) on [0,1]; two FTC steps, f∈C⁴),
    so Q(G) = C_p B² E|Y₁V+Y₂V'|^{p-4} (Y iid ~ x²G/B). For r=p-4∈(0,1]: triangle ineq + Jensen (concavity of
    (R1,R2)↦(R1V+R2V')^r) + Lyapunov (E|Y|≤c) ⇒ Q(G) ≤ Q(λδ_c), equality iff single atom ±c. With the exact
    expansion E|X̃_{εG1}|^p = εA1 + ε²Q(G1) + O(ε³): Pinelis' conjecture holds along every ray in the rare-jump
    limit (non-uniform). Identity verified numerically to 1e-13. (p=5 is the threshold of THIS argument.)

20. [PROVED] (RESULT Theorem H) For 4<p<5 and all A,B>0:
    c^p E|Π_λ-λ|^p ≤ ℰ_{p;A,B} ≤ c^p E|Π_λ-λ|^p + C_p B^{p/2},  C_p = (2/c'_p)(12^{(6-p)/2}/(48(6-p)) + 12^{(4-p)/2}/(4(p-4))),
    c'_p = -Γ(-p)cos(πp/2) (C_4.5 ≈ 16.9). Proof: Fourier identity = c'Q(G) - ∫Re ρ(ψ) (ρ = e^z-1-z-z²/2),
    |ψ| ≤ g ⇒ |∫Re ρ(ψ)| ≤ κ_p λ^{p/2} uniformly; Q(G) ≤ Q(Poisson) (item 19). Hence ℰ = A + (2^{p-1}-p-1)Aλ + O(B^{p/2})
    as B^{p/2}/A → 0: Pinelis' value is correct to second order; Gaussian+far-jump misses the second-order term.
    Numerical check: remainder bound holds with margin 1e3; 300 random G satisfy the bound (in fact E ≤ Poisson).
    Open upgrade: exactness for λ ≤ λ0(p) would need quantitative stability of Prop 9.6(c) + local analysis at G*.

21. [CHECK] Second independent referee pass (2026-10-26 ~20:15 UTC) on the version with Prop 9.6 and Theorem H:
    no CRITICAL/MAJOR; 9 MINOR, all addressed: Prop 9.6(a) restricted to p≥3 (the N=0 term is O(ε^p));
    X̃_G typo in the Theorem H display; Theorem H stated in Section 1 in the uniform two-sided form
    |c^pE|Π_λ-λ|^p - A - q_pAλ| ≤ η_pB^{p/2}/c'_p and A+... upper bound; Remark 1.1 and Discussion item 3 updated;
    notation clashes removed (k_4 kernel, D_p, χ(ε) in the sharpness construction vs κ in Thm F); Remark (i)
    now notes Q(G) ≤ Q(λδ_c) also for p ≥ 5 via Pinelis Lemma 2.1 + Thm 1.3; Remark (iii) small-jump example at p=3.5.
    Constants re-verified: c'_p closed form vs series-stabilized quadrature (1e-9 rel.), C_p → 12 (p→4+),
    13.9/16.9/20.0 at p=4.2/4.5/4.8, 22.05 at p=5.
    Random search (killer_search2, k=3) apparent ratios 1+1e-12..2e-12 at p=4.1, 4.9: configurations collapse to
    the Poisson law (coincident atoms / zero rates) — float noise, not counterexamples.

22. [PROVED — pending referee] (RESULT Theorem I) Exactness of Pinelis' conjecture for 4<p<5 when λ ≤ λ₀(p).
    c=1, G ∈ 𝒢_λ (∫x²dG = ∫|x|^p dG = λ, any sign of mean), Y ~ x²G/λ, Φ(G) = E|X̃_G|^p = λ + Q(G) + T(G),
    T(G) = -(1/c'_p)∫Re ρ(ψ_G) t^{-p-1}dt.
    Weight: ω₀(s) = (p-3)/(p-2) + s^{p-2}/(p-2) - s ≥ 0 (AM-GM), ω̂(y) = ω₀(|y|) + 1_{y<0}(1+|y|^{p-2}); E ω₀(|Y|) = 1 - E|Y|.
    Lemma S (stability): if P(Y∈[1/2,2]) ≥ P(Y∈[-2,-1/2]) (WLOG by reflection), then
      Q(G*) - Q(G) ≥ c₁λ² E ω̂(Y). Proof: Lyapunov gap (1-u^r) ≥ r E ω₀ plus sign gap Σ ≥ 2g*π₊π₋,
      g* = r4^{r-1}/5 (mean-value theorem + E min(V,V') = 1/5), two cases on E ω₀ ≷ 1/(4C_ω).
    Lemma E: e_t(y) = h_t(y) - h_t(1) - h_t'(1)(|y|^{p-2}-1)/(p-2), h_t(y) = (e^{ity}-1-ity)/y²:
      |e_t| ≤ C_M t² ω̂ (C_M = max(968, 5max(1,C_ω))), and ψ_G - ψ_* = ∫e_t dH by the two constraints.
      KEY POINT: the subtraction makes δψ second order in the spread of Y around 1, the same order as the deficit.
    Then |ρ(ψ_G) - ρ(ψ_*)| ≤ |δψ| min(g²/2, 2g) ⇒ |T(G) - T(G*)| ≤ (C_M j_p/c'_p) λ^{p/2} E ω̂(Y).
    ⇒ Φ(G) - Φ(G*) ≤ λ² E ω̂ (C_T λ^{(p-4)/2} - c₁) < 0 unless G = G*.
    Numerics (check_small_lambda.py): Lemma E sup ratio 1.49/1.26/1.11 (≤ 968 ✓). Lemma S: the best constant is
    ≤ 0.128/0.449/0.959, attained near an all-negative two-point Y at (−1/2, −2); this is still ≥ c₁ = 0.0024/0.010/0.025 ✓
    at p = 4.2/4.5/4.8. λ₀ from the proof is (c₁c'_p/(2C_M j_p))^{2/(p−4)} = 2.4e-74/3.9e-28/3.9e-17 (tiny; exponent 2/(p−4)).
    [Corrected after the referee: the earlier 2e-71/6e-27/2e-16 omitted the factor 2.]
    Pinelis' own route (Props 2.9, 2.11) fails for q<5 because ψ_v(u) = E|v+uW|^{q-4} is not increasing in u
    (ψ_v''(0) ∝ (q-4)(q-5) < 0); that is why a perturbative route is used here.

23. [PROVED — pending referee] (RESULT Theorem J) Gaussian regime, 4<p<5, λ ≥ 1:
    Poisson ≤ ℰ ≤ Poisson + C̃ B^{p/2} λ^{-3/2}; Poisson = B^{p/2}(m_p + K_p/λ + O(λ^{-3/2})),
    K_p = (1/c'_p)(2^{(6-p)/2}Γ((6-p)/2)/144 − 2^{(4-p)/2}Γ((4-p)/2)/48) = Edgeworth coefficient
    (p)_4 m_{p-4}/24 + (p)_6 m_{p-6}/72 (equal to 12 digits at p = 4.1, ..., 4.9; K_4.5 = 2.36055).
    Second decomposition (exact, all λ): ψ_r := ψ_G + g, c'(Φ − λ − m_pλ^{p/2}) = L + N,
      L(G) = ∫Re ψ_r (1 − e^{-g}) t^{-p-1}dt = ∫κ_λ dG, κ_λ(x) = |x|^p Ψ(λ/x²), Ψ(μ) = ∫k₂(u)(1 − e^{-μu²/2})u^{-p-1}du,
      N(G) = −∫e^{-g} Re(e^{ψ_r} − 1 − ψ_r) t^{-p-1}dt.
    KEY LEMMA: φ_λ(s) = sΨ(λs^{-β}), β = 2/(p−2) < 1, is strictly concave because
    φ'' = −(βμ/s)((1−β)Ψ' − βμΨ'') and Ψ' > 0 > Ψ''. Hence L(G) = λEφ_λ(|Y|^{p-2}) ≤ L(G*) for ALL λ (Jensen).
    N = N_s − N_c − N_3: N_s ≤ N_s^+ (since |Im ψ_r| ≤ λt³/6), N_s^+ − N_s(G*) = O(λ^{(p-4)/2}),
    N_c(G*) = O(λ^{(p-4)/2}), |N_3| = O(λ^{(p-3)/2}) uniformly (a(t) ≥ 11g/16 for t ≤ 1/2).
    Numerics: Lemma second checked to 10 digits (4 cases); concavity on a grid for λ = 0.1 ... 100;
    300 random G at λ = 5, 20, 80 all below Poisson.
    [NUMERICAL] N(G) ≤ N(G*): 150/150 at λ ∈ {0.3, 1, 3, 10}; fails 64/150 at λ = 0.05 (conjecture still holds there).

24. [PROVED — pending referee] (RESULT Theorem K) Exactness for λ ≥ λ₁(p), 4<p<5.
    Lemma K0: |e_t| ≤ C_M min(t², t³) ω̂ (t<1: |e_t''| ≤ (3/4)t³ on [1/2,2]; off it ≤ (5/12) t³ (1+|y|^{p-2})).
    Lemma K1 (key): Im e_t(y) = t² F_t(y), F_t(y) = S(t) − S(ty) + tS'(t)(|y|^{p−2}−1)/(p−2), S(u) = (u − sin u)/u²
      = u/6 − R(u), R(u) = u∫(1−v)²/2 (1−cos uv)dv ∈ [0, min(u³/120, u/6)], |R'| ≤ u²/40, |R''| ≤ u/20.
      y>0: F_t = (t/6)ω₀(y) + Γ_t(y), |Γ_t| ≤ (t/12)ω₀ for t ≤ t₁; y<0: F_t(y) = F_t(|y|) + 2S(t|y|).
      ⇒ Im e_t ≥ c_B t³ ω̂ for t ≤ t₁ = min(0.45, (10/(3C_ω))^{1/2}). Numerically inf ratio ≈ 0.047 (p=4.5), > 0 up to t = 3.
    Near (Ω ≤ 1/(7C_M)): (Im ψ_*)² − (Im ψ_G)² = λ² ε_t (2σ − ε_t) ≥ (c_B/7) λ² Ω t⁶ ⇒ N_s deficit ≥ c_s λ^{(p−2)/2} Ω.
    Far: |EY'| ≤ 1 − E ω₀ − π₋ after reflection; N_s(G') ≤ (EY')² N_s^+ + O(λ^{1/2}) (σ_t(y) − t³y/6 = −t² R(ty),
      t² |R(ty)| ≤ C t^p |y|^{p−2} by interpolation with θ = (p−3)/2).
    Numerics (check_K1.py): K1 and K0 hold at p = 4.2, 4.5, 4.8 (sup |e_t|/(min(t², t³) ω̂) ≈ 1.49/1.26/1.11).

25. [CHECK] Referee of Theorem J (subagent, 2026-10-26 ~22:10 UTC): no CRITICAL/MAJOR; proof correct.
    Applied improvements:
    (i) remainder λ^{-3/2} → λ^{-2} (sharp). The cubic part of ρ(ψ_r) is (iy)³/6 + O(x y²), whose real part is small,
        so |N_3| = O(λ^{(p-4)/2}) + 3·2^p/p.
    (ii) K_p = p(p−1)(p−2)m_p/72 = C(p,3)m_p/12 exactly, via c'_p m_p = −2^{−p/2−1}Γ(−p/2) (duplication + reflection);
         K_4 = 1 and K_6 = 25 match the Poisson moments.
    (iii) maximizer set of L = all measures carried by {±c}; (iv) the N_c bound is now stated for every G (used in Theorem K);
    (v) notation: ρ unified, Θ_p in Thm E, φ_X in Thm D, l_1; (vi) Edgeworth credit [vB65, BR76];
    (vii) Remark on constants (informative from λ ≈ 10² at p = 4.5); (viii) the proof also works for 5 ≤ p < 6.
    Referee's checks: concavity of φ_1 over s ∈ [1e-12, 1e12] (max s²φ''/φ ≤ −0.035);
    Poisson limit at λ = 3·10⁴ matches K_4.5 to 8 digits; the next Edgeworth coefficient is visible.

26. [CHECK] Referee of Theorem I (subagent, 2026-10-26 ~22:40 UTC): no CRITICAL/MAJOR; proof correct.
    Fixed: the λ₀ numbers (factor 2), the Lemma S best-constant claim (worst case is an all-negative two-point Y),
    and the closed form C_ω = (1+2^{p-2})/ω₀(2). Theorems I–K now cite the explicit identity (eq:PhiQT).
    Numerics bug: idlaw._support pruned Poisson terms by probability only (k ≥ 5 dropped at λ = 1e-3, giving a
    relative error of 1e-11 in E|Π−λ|^p). It now prunes on w(1+|k−λ|)^p. The earlier apparent ratios 1+1e-12
    (ks2 at p = 4.1, 4.9) become 0.99999999999957 and 0.99999999999993: pruning artefacts, not violations.
    The referee's adversarial search found no G beating Poisson (KKT test passed for λ ∈ [1e-3, 200], p ∈ [4.02, 4.98]).

27. [CHECK] Referee of Theorem K (subagent, 2026-10-26 ~23:10 UTC): no CRITICAL/MAJOR; proof correct.
    Applied: Step 1 for t > 1/2 now uses |e^{z1}−e^{z0}| ≤ |z1−z0| min(1, 1/|Re z0|) with z0 = ψ_{G*}, |Re z0| = λ(1−cos t).
    Then J(λ) = ∫_{1/2}^∞ t^{1−p} min(1, 1/a_*) dt ≤ 2√2 π^{2−p} ζ(p−1) λ^{−1/2} + π² 2^{p−1}/(pλ), which turns the
    O(λΩ) term into O((λ^{1/2} + 1)Ω).
    Effect: λ₁ dropped from ≈1e30.5 (p=4.5, and unbounded as p↓4) to λ_near ≈ 1e13.0/1e12.3/1e11.8/1e11.4 at
    p = 4.05/4.2/4.5/4.8; λ_far ≈ 1e9.3 ... 1e6.0 (lambda1_constants.py). λ₁ is now bounded as p↓4.
    Also: y = 0 covered in Lemma K1; R odd noted; λ_near defined as a least threshold; abstract caveat; Remark rem:lambda1.
    Referee numerics: no G beats Poisson at λ = 20, 100, 400 (max ratio 1 + 1.8e-13, attained only at λδ_{±1} or
    split coincident atoms); measured ε_t/(t³Ω) ≈ 1/6 against c_B ≈ 0.005.

28. [CHECK] Final consistency pass (subagent, 2026-10-26 ~23:35 UTC): no CRITICAL/MAJOR. Verified the refined N_3
    estimate, the Gamma identities for K_p (sympy), the Step 1 Lipschitz/J(λ) bound (quadrature), and both remarks'
    numbers. All 46 labels resolve. Fixed:
    - λ_near is now "a threshold beyond which the bracket stays negative" (no least element exists);
    - the closed form of c'_p is justified (it is used for K_p);
    - \Im is set upright;
    - notation: Δ_p for the norm constant, λ' local, ϖ(u), ξ/η local;
    - Π_λ, c, λ defined in the abstract; counterfactual λ₁ ≈ 1e29;
    - Lemma Npart now states N_s, N_c, N_3 and all the bounds Theorem K uses.
    (Item 23's λ^{-3/2} is superseded by item 25: the rate is λ^{-2}.)
29. [NUMERICAL] DE k=3 at p=4.5 (seed 5) finished: best ratio 0.999999999425 (< 1). It converged to three coincident
    atoms ≈ −0.0316, i.e. the Poisson law split up. The k=3 runs at p=4.2 and 4.8 are still running at 23:40 UTC.

30. [CHECK] Literature (2026-10-26 ~23:50 UTC).
    - Utev 1985 is described (de la Peña–Ibragimov–Sharakhmetov 2003; IS02) as treating symmetric summands only, so it
      does not anticipate Theorem A.
    - IS02 ends with "A hypothesis": for 2<t<4 the zero-mean max-form constant C(t) equals the symmetric constant 1+m_t.
      Theorem A gives this for 3≤t≤4; Pinelis Thm 1.5 covers (2,3]. So the hypothesis is confirmed for all 2<t<4.
    - IS02 also guesses C(t) = E|θ−1|^t (θ ~ Poisson(1)) for t≥4. Under Pinelis' conjecture this is the case λ = 1:
      E|Π_λ−λ|^t / max(λ, λ^{t/2}) peaks at λ = 1 (numerically 6.677 at t = 4.5). It is inside the gap (λ₀, λ₁): still open.

6. [OBSERVATION] For `4<p<6`, the same identity with `|x|^p = κ'_p∫(1-cos tx - t²x²/2 + t⁴x⁴/24)t^{-p-1}dt`
   gives `E|X_G|^p - A - m_p B^{p/2} = κ'_p ∫ [F(g) - e^{-a}cos b - a] t^{-p-1}dt >= 0`:
   every compound Poisson law is ABOVE the Gaussian+far-jump value when 4<p<6 (consistent with
   the Poisson regime). Does not by itself bound the sup; T1 remains open.
