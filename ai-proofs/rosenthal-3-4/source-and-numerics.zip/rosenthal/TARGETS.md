# TARGETS — sharp inequalities whose extremal value is a moment-problem envelope

Mechanism focus: problems of the form `sup E F(X_1+...+X_n)` over independent summands with
prescribed (sums of) moments, where each summand's law solves a moment problem whose obstacle is a
space curve. The tools of de Dios Pont–Ivanisvili–Madrid (Michigan Math. J. 76 (2026)) — explicit
upper/lower hulls of curves with totally positive torsion (TPT), few-atom extremals with a fixed
endpoint pattern depending on the parity of the number of constraints, Carathéodory number
`floor((n+2)/2)` — enter through the *first-order (KKT) conditions*: at an optimum, the first
variation `u -> Psi_W(u)` must lie under an affine combination of the constraint functions with
contact exactly on the support of the extremal measure, i.e. the extremal is a principal
representation for the curve `u -> (constraints(u), Psi_W(u))`.

Literature status checked on 2026-10-26 (arXiv / web search). Problems I checked and **discarded**
because they were resolved recently:

* Samuels' conjecture (1966): claimed proof, Z. Ling, arXiv:2608.18392 (Aug 2026).
* Feige's conjecture, δ ≥ 1: Fu–Han–Wang–Yan–Zhang–Zhou, arXiv:2607.23980 (Jul 2026), via Gaffke's
  conjecture (Vlassis–Thomas, arXiv:2607.08415). The general δ case follows from Samuels.
* Tomaszewski (Keller–Klein 2022) and its counterpart `P(|X|>=1) >= 7/32` (Hollom–Portier, RSA 2025).
* Steinhaus `L_p–L_2` Khintchine constants: closed by Rapaport–Tkocz–Wu, arXiv:2512.09077.
* Symmetric exact Rosenthal: Utev (p>4), Figiel–Hitczenko–Johnson–Schechtman–Zinn 1997 and
  Ibragimov–Sharakhmetov 1997 (2<p≤4).

---

## T1. Exact Rosenthal bound, zero-mean summands, 4 < p < 5  (Pinelis' Poisson conjecture)

**Statement.** For `p in (4,5)`, `A,B>0`:
`sup E|X_1+...+X_n|^p = c^p E|Pi_lambda - lambda|^p`, the sup over all `n` and independent
zero-mean `X_i` with `sum E X_i^2 = B`, `sum E|X_i|^p = A`, where `c^p lambda = A`, `c^2 lambda = B`.

**Best known.** Proved for `p >= 5` (I. Pinelis, *Exact Rosenthal-type bounds*, Ann. Probab. 43
(2015) 2511–2544, Thm 1.3) and for even `p` (Bestsennaya–Utev 1991; Ibragimov–Sharakhmetov,
TVP 46 (2002)). Pinelis: "The cases p∈(3,4) and p∈(4,5) remain open. Certain considerations suggest
… Theorem 1.3 should hold for p∈(4,5)". No later resolution found (searched 2026-10-26).

**Why the tools apply.** By Utev–Pinelis Poissonization (valid for `p>=3`) the problem is a
maximization over Lévy measures `H` with two linear constraints (`int H = B`,
`int |u|^{p-2} H = A`). The KKT condition says the support of an optimal `H` is the contact set of
the curve `v -> (v, Psi_W(±v^{1/(p-2)}))` with its upper hull — exactly the planar (n=1) case of the
paper, and the two-sided problem is a two-branch hull. Pinelis' p≥5 proof uses convexity of
`|x|^{q-4}` twice; for q∈(4,5) the sign of `(q-4)(q-5)` flips, which is precisely where a
moment-envelope analysis of the anti-skew branch is needed.

## T2. Exact Rosenthal bound, zero-mean summands, 3 < p < 4

**Statement.** For `p in (3,4)` and independent zero-mean `X_i`:
`E|sum X_i|^p <= sum E|X_i|^p + E|Z|^p (sum E X_i^2)^{p/2}`, and the constant is sharp
(equivalently `sup = A + E|Z|^p B^{p/2}`). Pinelis also conjectured the version with an extra
independent summand `X` (his Thm 1.5 for p∈(3,4)).

**Best known.** `p in (2,3]` with general extra `X` (Pinelis 2015, Thm 1.5, via Tyurin's zero-bias
bound); `p=4` (trivial cumulant identity); symmetric summands, all `p in (2,4]` (FHJSZ 1997).
Open as stated by Pinelis 2015.

**Why the tools apply.** Same Lévy-measure/KKT reduction; the conjectured extremal (Gaussian plus
one far jump) corresponds to the *endpoint* principal representation (contacts only at `v=0` and
`v=∞`), i.e. convexity of the planar curve on each half-line.

## T3. Optimal constant in Bentkus' binomial-tail domination

**Statement.** For sums `M_n` of independent (or martingale) bounded differences, find the optimal
`c` in `P(M_n >= x) <= c P°(S_n >= x)` (Bentkus, Ann. Probab. 32 (2004) 1650–1673, Thm 1.1;
proved `c <= e^2/2`, conjectured `c_n increasing to 2`; "finding precise values of these constants in
the independent and i.i.d. cases is considered a very difficult mathematical problem").

**Why the tools apply.** The moment step `E(M_n-h)_+^2 <= E(S_n-h)_+^2` is the paper's even case
(n=2): upper hull = one free atom + the right endpoint `b`. Improving `c` requires using more of the
hull (several test functions / higher n).

## T4. Sharp Rosenthal constants for symmetric log-concave summands, and multi-constraint extremizers

**Statement.** Chasapis–Eskenazis–Tkocz (Bull. LMS 2022, §5.1–5.2): identify the best constant in
Rosenthal's inequality for independent symmetric log-concave summands; describe extremizers of
`sup E|sum X_j|^p` under `l >= 3` individual moment constraints. Stated as open/"elusive".

**Why the tools apply.** With `l` constraints the one-summand problem is a moment problem for a
curve in `R^{l+1}`; the paper's parity rule and Carathéodory number predict the atom structure
(log-concavity adds a non-linear constraint, so only partially applicable).

---

## Choice of attack

T2 and T1 (the two open ranges of Pinelis' problem): an explicitly stated open problem from
Ann. Probab., with a precise conjectured value, fully inside the moment-envelope mechanism, and
amenable to a numerical killer pass. Outcome so far: see `NOTES.md` and `RESULT_rosenthal34.tex`.

## Outcome (as of 2026-10-26 23:45 UTC; all theorems independently refereed)

* **T2 (3<p<4): SOLVED** (X=0 case, which is the headline "exact Rosenthal bound"). This also confirms the 2002
  Ibragimov–Sharakhmetov hypothesis (end of their TPA 46 paper) that the zero-mean max-form constant equals the symmetric
  one 1+m_t for 2<t<4; (2,3] was settled by Pinelis. Their companion hypothesis C(t) = E|Π₁−1|^t for t≥4 corresponds
  to λ = 1 and stays open for 4<t<5 (it lies in the gap between Theorems I and K). Theorem A of
  `RESULT_rosenthal34.pdf`: `ℰ_{p;A,B} = A + m_p B^{p/2}` for 3≤p≤4. Two independent proofs. The first combines
  Poissonization with a pointwise Fourier comparison. The second combines Poissonization, symmetrization of
  the Lévy measure, and the known symmetric case. Extensions: Hilbert-space, L^p-valued, and general
  moment functions (f'' convex and negative definite). Pinelis' extension with an extra summand X is **false**
  for skewed X, including deterministic X ≠ 0 (Theorem E). It is **true** when φ_X ≥ 0 (Theorem D), and
  numerically true for symmetric two-point X.
* **T1 (4<p<5): SOLVED near BOTH ends (λ ≤ λ₀(p) and λ ≥ λ₁(p)); OPEN for λ ∈ (λ₀, λ₁).**
  (000) PROVED (Theorem K, 2026-10-26 ~21:44 UTC): there is λ₁(p) < ∞ with ℰ = Poisson for all λ ≥ λ₁(p).
  The proof uses the second decomposition L + N_s − N_c − N_3 with ΔL ≤ 0 (concavity).
  - Near G*: the key pointwise lemma K1 gives Im e_t(y) ≥ c_B t³ ω̂(y) for t ≤ t₁. Hence the skewness deficit of N_s
    is ≥ c_s λ^{(p−2)/2} E ω̂, while the variations of N_c and N_3 are O(λ^{(p−3)/2} E ω̂). The large-t part uses
    |e^{z1} − e^{z0}| ≤ |z1 − z0| min(1, 1/|Re z0|) (referee's refinement).
  - Far from G*: after a reflection, N_s(G) ≤ (EY)² N_s^+ + O(λ^{1/2}) and 1 − (EY)² ≥ E ω̂/(10 + C_ω).
  - Thresholds from the proof's constants: λ₁ ≈ 1e11–1e13 for p ∈ [4.05, 4.95] (refereed; Remark rem:lambda1).
    For comparison, λ₀ ≈ 4e-28 at p = 4.5.
  (00) PROVED (Theorem I, 2026-10-26 ~21:12 UTC):
  there is λ₀(p) > 0 with ℰ_{p;A,B} = c^p E|Π_λ − λ|^p whenever λ = (B^{p/2}/A)^{2/(p−2)} ≤ λ₀(p), and λδ_{±c} are the only
  extremal Lévy measures. Proof: Q-deficit ≥ c₁λ² E ω̂(Y) (quantitative stability of Prop 9.6(c)) versus a remainder
  ≤ C λ^{p/2} E ω̂(Y). The remainder bound comes from a constraint-adapted Fourier bound |ψ_G − ψ_*| ≤ C_M t² λ E ω̂(Y).
  Caveat: the proof's λ₀ is tiny (4e-28 at p = 4.5; 5e-10 with the numerically observed constants).
  (0') PROVED (Theorem J, Gaussian regime λ → ∞): Poisson ≤ ℰ ≤ Poisson + C̃_p B^{p/2} λ^{-2} (sharp order), and
  Poisson = B^{p/2}(m_p + K_p/λ + O(λ^{-2})), with K_p = p(p−1)(p−2)m_p/72 (the Edgeworth coefficient). The tool is a second exact
  decomposition c'(Φ − λ − m_pλ^{p/2}) = L(G) + N(G). The leading part L is LINEAR in G, L(G) = λ E φ_λ(|Y|^{p−2}),
  with φ_λ(s) = sΨ(λ s^{−2/(p−2)}) strictly concave for every λ. That is a two-constraint moment problem whose
  extremal is a single atom, so L ≤ L(Poisson) for all λ. Numerically, N(G) ≤ N(G*) held for λ ≥ 0.3 (a sufficient
  condition for the conjecture) but fails at λ = 0.05.
  (0) PROVED (Theorem H): Poisson ≤ ℰ ≤ Poisson + C_p B^{p/2} for all A,B,
  so the conjectured value is correct to second order as B^{p/2}/A → 0. (i) PROVED: second-order optimality of the Poisson in the rare-jump regime
  (Prop. 9.6). Exact identity: K(x,y) = ¼p(p−1)(p−2)(p−3)x²y²E|xV+yV′|^{p−4}. The proof combines the triangle inequality,
  Jensen and Lyapunov. Consequence: the conjecture holds along every ray εG₁ as ε→0 (non-uniformly).
  (ii) Reduced to a "skewness inequality" (Prop. 9.3; uses Utev's symmetric theorem).
  The inequality is numerically verified (180 random Lévy measures, plus a full scan of the mixed-sign
  same-|x| family, where it is equivalent to the conjecture). Global differential-evolution searches find
  no counterexample. Obstruction: the sign of `(q-4)(q-5)` in Pinelis' second-variation argument flips, and
  the skew-side/anti-skew-side asymmetry of the KKT curve.
* T3, T4: not attacked.
* Role of the de Dios Pont–Ivanisvili–Madrid tools: they framed the search (KKT = contact set of the planar
  curve v ↦ (v, Ψ_W(±v^{1/(p-2)})) with its upper hull; convexity versus concavity on each branch predicted the
  extremal structure and the counterexample mechanism for 3<p<4). The final proofs do not need the hull
  parametrisation itself. The two-moment-problem principle (concave envelope ⇒ single-atom extremal) appears
  explicitly once, in Lemma lem:concave (Theorems J, K), for a planar curve, the simplest case of the paper's setting.
