# Moment-envelope extremal problems: the exact Rosenthal bound for 3 ≤ p ≤ 4, and both ends of 4 < p < 5

Research log for a 24-hour attempt (Oct 26–27, 2026) to use the convex-hull / moment-problem
results of de Dios Pont–Ivanisvili–Madrid (*Michigan Math. J.* 76 (2026)) on open sharp-inequality
problems whose extremal value is a moment-problem envelope.

## Results

Pinelis (*Ann. Probab.* 43 (2015)) determined the exact Rosenthal bound ℰ_{p;A,B} (sup of E|ΣXᵢ|^p over
independent zero-mean summands with ΣE|Xᵢ|^p = A, ΣE Xᵢ² = B) for p ∈ (2,3] ∪ [5,∞). He stated that
p ∈ (3,4) and p ∈ (4,5) remain open.

* **3 ≤ p ≤ 4 (Theorem A, solved).** For independent zero-mean X₁,…,Xₙ,

      E|X₁+…+Xₙ|^p ≤ Σ E|Xᵢ|^p + E|Z|^p (Σ E Xᵢ²)^{p/2},   Z ~ N(0,1),

  with sharp constants. In the max form this confirms the hypothesis of Ibragimov–Sharakhmetov (Theory Probab. Appl. 46
  (2002)) that the zero-mean constant equals the symmetric one for 3 < t < 4; the range 2 < t ≤ 3 was settled by
  Pinelis. The proof uses Utev's Poissonization plus a Fourier identity whose integrand is
  pointwise ≤ 0; a second proof goes through symmetrization. There are Hilbert-space, L^p-valued and
  general-moment-function versions (Corollaries B, C, Theorem F). Pinelis' suggested extension with an extra
  summand X is false (Theorem E), but holds when X has a nonnegative characteristic function (Theorem D).
* **4 < p < 5 (Pinelis' Poisson conjecture ℰ = c^p E|Π_λ − λ|^p, with λ = (B^{p/2}/A)^{2/(p−2)}).**
  * Theorem I: the conjecture holds when λ ≤ λ₀(p) (rare-jump regime B^{p/2} ≪ A).
  * Theorem K: the conjecture holds when λ ≥ λ₁(p) (Gaussian regime B^{p/2} ≫ A).
  * Theorems H and J: quantitative two-sided bounds in between. These give the asymptotics
    ℰ = A + (2^{p−1}−p−1)Aλ + O(B^{p/2}) and ℰ = B^{p/2}(m_p + K_p/λ + O(λ^{−2})), with K_p = p(p−1)(p−2)E|Z|^p/72.
  * The thresholds the proofs produce are λ₀ ≈ 4·10⁻²⁸ and λ₁ ≈ 10¹² at p = 4.5. λ₁ stays bounded as p ↓ 4,
    while λ₀ → 0. The intermediate range is still open, though the numerics support the conjecture there.

## Files

* `RESULT_rosenthal34.tex` / `.pdf`: full proofs.
* `TARGETS.md`: candidate open problems, their status as of Oct 2026, and the choice of attack.
* `NOTES.md`: locked log of claims tagged PROVED / CONDITIONAL / NUMERICAL / FAILED.
* `numerics/`: all scripts (Python 3: numpy, scipy, mpmath). These are evidence only, never part of a proof.

## Reproducing

```bash
pip install numpy scipy mpmath
cd numerics
python3 verify_34.py              # sanity checks of the three proof steps on random sums
python3 killer_theorem34.py 3.7   # adversarial search against the main theorem
python3 scan_families.py 4.5      # low-dimensional Lévy-measure scans (4<p<5)
python3 split_45_stable.py 4.5 10 # skewness inequality test (30-digit quadrature)
python3 check_small_lambda.py 4.5 # constants in the two lemmas behind Theorem I
python3 check_large_lambda.py 4.5 # second decomposition (Theorem J): identity and concavity checks
python3 check_K1.py 4.5           # one-sided bound for Im e_t behind Theorem K
cd .. && pdflatex RESULT_rosenthal34.tex && pdflatex RESULT_rosenthal34.tex
```
