"""First-order test of Pinelis' Theorem 1.3 extended to 4<p<5 (with an extra mean-zero X).

For small Levy measures H, E|X+Y_H|^p = E|X|^p + int Psi_X dH + O(|H|^2), with
Psi_X(u) = E[f(X+u)-f(X)-u f'(X)]/u^2, f=|.|^p.  Theorem 1.3 at first order requires that
G(v) := max(g_+(v), g_-(v)), g_±(v) = Psi_X(±v^{1/(p-2)}), coincides with its least concave majorant
on [0, inf) (with the far-jump slope 1 at infinity). We compute the gap  (concave majorant - G).
"""
import sys
import numpy as np


def psi(p, xv, xw, u):
    u = np.atleast_1d(u).astype(float)
    f0 = np.dot(xw, np.abs(xv) ** p)
    f1 = np.dot(xw, p * np.abs(xv) ** (p - 2) * xv)
    fu = (np.abs(xv[None, :] + u[:, None]) ** p) @ xw
    return (fu - f0 - u * f1) / u ** 2


def concave_majorant(v, G):
    # upper hull of points (v_i, G_i)
    hull = []
    for x, y in zip(v, G):
        while len(hull) >= 2:
            (x1, y1), (x2, y2) = hull[-2], hull[-1]
            if (y2 - y1) * (x - x1) <= (y - y1) * (x2 - x1):
                hull.pop()
            else:
                break
        hull.append((x, y))
    hx, hy = map(np.array, zip(*hull))
    return np.interp(v, hx, hy)


if __name__ == "__main__":
    p = float(sys.argv[1]) if len(sys.argv) > 1 else 4.5
    laws = {
        "2pt(-1,3)": (np.array([-1.0, 3.0]), np.array([0.75, 0.25])),
        "2pt(-1,10)": (np.array([-1.0, 10.0]), np.array([10 / 11, 1 / 11])),
        "2pt(-1,1.5)": (np.array([-1.0, 1.5]), np.array([0.6, 0.4])),
        "3pt": (np.array([-2.0, 0.5, 4.0]), None),
    }
    x3 = laws["3pt"][0]
    # weights for mean zero: solve w1+w2+w3=1, sum w x = 0 with w2 = 0.5
    w2 = 0.5
    A_ = np.array([[1, 1], [x3[0], x3[2]]])
    b_ = np.array([1 - w2, -w2 * x3[1]])
    w13 = np.linalg.solve(A_, b_)
    laws["3pt"] = (x3, np.array([w13[0], w2, w13[1]]))
    v = np.geomspace(1e-4, 1e4, 6000)
    u = v ** (1 / (p - 2))
    for name, (xv, xw) in laws.items():
        assert abs(np.dot(xv, xw)) < 1e-12
        gp = psi(p, xv, xw, u)
        gm = psi(p, xv, xw, -u)
        g0 = 0.5 * p * (p - 1) * np.dot(xw, np.abs(xv) ** (p - 2))
        vv = np.concatenate([[0.0], v])
        G = np.concatenate([[g0], np.maximum(gp, gm)])
        H = concave_majorant(vv, G)
        gap = H - G
        i = np.argmax(gap[1:]) + 1
        rel = gap[i] / G[i]
        which = "+" if gp[i - 1] >= gm[i - 1] else "-"
        print(f"p={p} X={name:12s}: max (majorant-G)/G = {rel:.3e} at v={vv[i]:.4g} (c={vv[i]**(1/(p-2)):.4g}), "
              f"larger branch there: {which}; frac(g- > g+) = {np.mean(gm > gp):.2f}")
