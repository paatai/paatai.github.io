"""Evidence only: does N(G) <= N(lambda delta_1) hold on G_lambda (c = 1)?

N(G) = c'_p (Phi(G) - lambda - m_p lambda^{p/2}) - L(G), with L(G) = sum_j m_j |x_j|^p Psi(lambda / x_j^2)
(the linear term of the large-lambda decomposition), Phi(G) = E|X~_G|^p by exact Poisson summation.
Since L(G) <= L(G*) always (concavity lemma), N(G) <= N(G*) for all G would imply Pinelis' conjecture.
"""
import sys
import numpy as np
import mpmath as mp

sys.path.insert(0, '.')
from idlaw import abs_moment, m_p  # noqa: E402

mp.mp.dps = 25
p = float(sys.argv[1]) if len(sys.argv) > 1 else 4.5
cprime = float(-mp.gamma(-p) * mp.cos(mp.pi * p / 2))
_cache = {}


def k2(u):
    if abs(u) < mp.mpf('0.5'):
        return sum((-1) ** k * u ** (2 * k) / mp.factorial(2 * k) for k in range(2, 25))
    return mp.cos(u) - 1 + u ** 2 / 2


def Psi(mu):
    key = round(float(mu), 12)
    if key not in _cache:
        _cache[key] = float(mp.quad(lambda u: k2(u) * (-mp.expm1(-mu * u ** 2 / 2)) * u ** (-p - 1),
                                    [0, 0.1, 1, 10, 100, mp.inf]))
    return _cache[key]


def L_of(lam, atoms):
    return sum(m * abs(x) ** p * Psi(lam / x ** 2) for x, m in atoms)


def N_of(lam, atoms):
    Phi = abs_moment(p, 0.0, atoms)
    return cprime * (Phi - lam - m_p(p) * lam ** (p / 2)) - L_of(lam, atoms), Phi


rng = np.random.default_rng(int(sys.argv[2]) if len(sys.argv) > 2 else 0)
def configs(mode):
    if mode == 'random':
        for trial in range(150):
            k = rng.integers(2, 4)
            xs = rng.choice([-1, 1], p=[0.3, 0.7], size=k) * np.exp(rng.normal(0, 0.6, size=k))
            yield xs, rng.dirichlet(np.ones(k))
    else:  # structured two-atom grid, 7 x 7 x 7 = 343 measures
        for x1 in [0.35, 0.7, 0.95, 1.05, 1.4, 2.0, -1.0]:
            for x2 in [-2.0, -1.0, -0.5, 0.5, 0.9, 1.2, 3.0]:
                for w1 in [0.05, 0.2, 0.35, 0.5, 0.65, 0.8, 0.95]:
                    yield np.array([x1, x2]), np.array([w1, 1 - w1])


mode = sys.argv[3] if len(sys.argv) > 3 else 'random'
for lam in [0.05, 0.3, 1.0, 3.0, 10.0]:
    Nstar, Phistar = N_of(lam, [(1.0, lam)])
    worst, worst_cfg, nviol, ntried, nphi = -np.inf, None, 0, 0, 0
    for xs, w in configs(mode):
        xs = xs / np.sum(w * np.abs(xs) ** (p - 2)) ** (1 / (p - 2))
        atoms = list(zip(xs, lam * w / xs ** 2))
        try:
            N, Phi = N_of(lam, atoms)
        except ValueError:
            continue
        ntried += 1
        nphi += Phi < Phistar
        d = N - Nstar
        if d > 0:
            nviol += 1
        if d > worst:
            worst, worst_cfg = d, (np.round(xs, 3), np.round(w, 3))
    print(f"p={p} {mode} lam={lam}: tried {ntried}; #(N(G)>N*)={nviol}; #(Phi(G)<Phi*)={nphi}; "
          f"max N(G)-N*={worst:.3e} at {worst_cfg}", flush=True)
