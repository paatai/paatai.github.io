"""Evidence only: Lemma K1 and the t^3 form of Lemma E.

K1:  Im e_t(y) >= c_B t^3 hat_omega(y) for 0 < t <= t_1 and all real y.
E':  |e_t(y)| <= C min(t^2, t^3) hat_omega(y) for all t > 0, y.
Here e_t(y) = h_t(y) - h_t(1) - h_t'(1)(|y|^{p-2}-1)/(p-2), h_t(y) = (e^{ity}-1-ity)/y^2.
"""
import sys
import numpy as np

p = float(sys.argv[1]) if len(sys.argv) > 1 else 4.5


def omega0(s):
    return (p - 3) / (p - 2) + s ** (p - 2) / (p - 2) - s


def hat_omega(y):
    return omega0(np.abs(y)) + (y < 0) * (1 + np.abs(y) ** (p - 2))


def S(u):
    # (u - sin u)/u^2, odd, stable near 0
    u = np.asarray(u, dtype=float)
    out = np.empty_like(u)
    sm = np.abs(u) < 1e-2
    us = u[sm]
    out[sm] = us / 6 - us ** 3 / 120 + us ** 5 / 5040
    ub = u[~sm]
    out[~sm] = (ub - np.sin(ub)) / ub ** 2
    return out


def Sprime(u):
    if abs(u) < 1e-2:
        return 1 / 6 - u ** 2 / 40 + u ** 4 / 1008
    return (1 - np.cos(u)) / u ** 2 - 2 * (u - np.sin(u)) / u ** 3


def im_e(t, y):
    # Im e_t(y) = t^2 [S(t) - S(ty) + t S'(t)(|y|^{p-2}-1)/(p-2)]
    return t ** 2 * (S(np.array([t]))[0] - S(t * y) + t * Sprime(t) * (np.abs(y) ** (p - 2) - 1) / (p - 2))


def full_e(t, y):
    y = np.asarray(y, dtype=complex)
    z = 1j * t * y
    h = np.where(np.abs(t * y) < 1e-3, -t ** 2 / 2 - 1j * t ** 3 * y / 6 + t ** 4 * y ** 2 / 24,
                 (np.exp(z) - 1 - z) / np.where(y == 0, 1, y) ** 2)
    h1 = np.exp(1j * t) - 1 - 1j * t
    hp1 = 1j * t * (np.exp(1j * t) - 1) - 2 * h1
    return h - h1 - hp1 / (p - 2) * (np.abs(y.real) ** (p - 2) - 1)


ys = np.concatenate([np.linspace(-30, 30, 120001), np.exp(np.linspace(-9, 9, 6001)), -np.exp(np.linspace(-9, 9, 6001))])
ys = ys[(np.abs(ys - 1) > 1e-6) & (ys != 0)]
print(f"p={p}")
for t in [0.01, 0.05, 0.1, 0.2, 0.3, 0.45, 0.6, 0.8, 1.0, 1.5, 2.0, 3.0]:
    r = im_e(t, ys) / (t ** 3 * hat_omega(ys))
    print(f"t={t:5.2f}: inf_y Im e_t/(t^3 hat_omega) = {np.min(r): .5f} at y={ys[np.argmin(r)]: .4f}")
worst = 0
for t in np.exp(np.linspace(np.log(1e-3), np.log(1e3), 200)):
    r = np.abs(full_e(t, ys)) / (min(t ** 2, t ** 3) * hat_omega(ys))
    worst = max(worst, np.max(r))
print(f"E': sup |e_t|/(min(t^2,t^3) hat_omega) = {worst:.4f}")
