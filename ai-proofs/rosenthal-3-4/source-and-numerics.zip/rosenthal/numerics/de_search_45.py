"""Global (differential evolution) killer search on Pinelis' Poisson conjecture, 4<p<5.
Lévy measure H = s^2 delta_0 + sum_j w_j delta_{c_j} with B = 1; ratio = E|Y_H|^p / Poisson(A(H),1).
Parameters: logits for (s^2, w_1..w_k), signed log-magnitudes for c_j. Rejects lam_cand outside [LO,HI]."""
import sys
import numpy as np
from scipy.optimize import differential_evolution
from idlaw import abs_moment, AB, poisson_candidate

p = float(sys.argv[1]); k = int(sys.argv[2]); seed = int(sys.argv[3])
LO, HI = 1e-3, 1e3


def ratio(th):
    logits = th[:k + 1]
    w = np.exp(logits - logits.max()); w /= w.sum()
    s2 = w[0]
    atoms = []
    for j in range(k):
        mag = np.exp(th[k + 1 + j]); sgn = 1.0 if th[2 * k + 1 + j] > 0 else -1.0
        c = sgn * mag; lam = w[j + 1] / c ** 2
        if lam < 1e-10:
            continue
        if lam > 2e3:
            return 0.0
        atoms.append((c, lam))
    if not atoms:
        return 0.0
    A, B = AB(p, s2, atoms)
    lam_c = (B ** (p / 2) / A) ** (2 / (p - 2))
    if not (LO <= lam_c <= HI):
        return 0.0
    try:
        return abs_moment(p, s2, atoms) / poisson_candidate(p, A, B)
    except ValueError:
        return 0.0


bounds = [(-6, 6)] * (k + 1) + [(-4, 3)] * k + [(-1, 1)] * k
res = differential_evolution(lambda t: -ratio(t), bounds, seed=seed, maxiter=300, popsize=25, tol=1e-12,
                             polish=True, workers=1)
th = res.x
print(f"p={p} k={k} seed={seed}: best ratio={-res.fun:.12f}")
logits = th[:k + 1]; w = np.exp(logits - logits.max()); w /= w.sum()
print("  gaussian var", w[0], "atoms", [((1 if th[2*k+1+j] > 0 else -1) * np.exp(th[k+1+j]), w[j+1]) for j in range(k)])
