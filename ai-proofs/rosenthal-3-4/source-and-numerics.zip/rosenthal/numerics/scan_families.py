"""Systematic scans of low-dimensional families of Levy measures (B = 1).

p in (3,4):  D = E|Y_H|^p - (A + m_p)            (conjecture: D <= 0)
p in (4,5):  D = E|Y_H|^p - Poisson(A, 1)        (conjecture: D <= 0)
"""
import sys
import numpy as np
from idlaw import abs_moment, AB, poisson_candidate, gauss_jump_candidate, m_p


def D(p, sigma2, atoms):
    A, B = AB(p, sigma2, atoms)
    val = abs_moment(p, sigma2, atoms)
    ref = max(poisson_candidate(p, A, B), gauss_jump_candidate(p, A, B))
    return val - ref, val, ref, A


def family_gauss_plus_poisson(p, ws, cs):
    best = (-np.inf, None)
    for w in ws:
        for c in cs:
            lam = w / c ** 2
            if lam > 2e4:
                continue
            d, val, ref, A = D(p, 1 - w, [(c, lam)])
            rel = d / ref
            if rel > best[0]:
                best = (rel, (w, c, lam, A))
    return best


def family_two_sided(p, A, ws, c1s, gauss=0.0):
    """H = gauss*delta_0 + w*delta_{c1} + (1-gauss-w)*delta_{-c2}, c2 fixed by the A-constraint."""
    best = (-np.inf, None)
    rest = 1.0 - gauss
    for w in ws:
        w1, w2 = w * rest, (1 - w) * rest
        for c1 in c1s:
            r = (A - w1 * c1 ** (p - 2))
            if r <= 0 or w2 <= 0:
                continue
            c2 = (r / w2) ** (1 / (p - 2))
            atoms = [(c1, w1 / c1 ** 2), (-c2, w2 / c2 ** 2)]
            if max(l for _, l in atoms) > 3e3:
                continue
            try:
                d, val, ref, AA = D(p, gauss, atoms)
            except ValueError:
                continue
            rel = d / ref
            if rel > best[0]:
                best = (rel, (w, c1, c2, atoms))
    return best


def family_same_side(p, A, ws, c1s, gauss=0.0):
    best = (-np.inf, None)
    rest = 1.0 - gauss
    for w in ws:
        w1, w2 = w * rest, (1 - w) * rest
        for c1 in c1s:
            r = (A - w1 * c1 ** (p - 2))
            if r <= 0 or w2 <= 0:
                continue
            c2 = (r / w2) ** (1 / (p - 2))
            atoms = [(c1, w1 / c1 ** 2), (c2, w2 / c2 ** 2)]
            if max(l for _, l in atoms) > 3e3:
                continue
            try:
                d, val, ref, AA = D(p, gauss, atoms)
            except ValueError:
                continue
            rel = d / ref
            if rel > best[0]:
                best = (rel, (w, c1, c2, atoms))
    return best


if __name__ == "__main__":
    p = float(sys.argv[1])
    ws = np.linspace(0.02, 1.0, 50)
    cs = np.exp(np.linspace(np.log(0.03), np.log(30), 90))
    print("p", p, "Gauss+Poisson best rel D:", family_gauss_plus_poisson(p, ws, cs), flush=True)
    for lamc in [0.05, 0.3, 1.0, 3.0, 10.0, 40.0]:
        A = lamc ** (1 - p / 2)  # B=1, Poisson candidate with this lambda
        ws2 = np.linspace(0.02, 0.98, 25)
        c1s = np.exp(np.linspace(np.log(0.05), np.log(A ** (1 / (p - 2)) * 3), 60))
        b2 = family_two_sided(p, A, ws2, c1s)
        b3 = family_same_side(p, A, ws2, c1s)
        print(f"p={p} lam_cand={lamc} A={A:.4g} two-sided best rel D={b2[0]:.3e} at {b2[1][:3] if b2[1] else None};"
              f" same-side best rel D={b3[0]:.3e} at {b3[1][:3] if b3[1] else None}", flush=True)
