"""Numerical checks (evidence only) for the large-lambda decomposition (Theorem J).

c'_p (Phi(G) - lambda - m_p lambda^{p/2}) = L(G) + N(G), where, with g = lambda t^2/2,
psi_r(t) = int (e^{itx} - 1 - itx + t^2x^2/2) G(dx),
L(G) = int Re psi_r(t) (1 - e^{-g}) t^{-p-1} dt = int kappa_lambda dG,
N(G) = - int e^{-g} Re(e^{psi_r} - 1 - psi_r) t^{-p-1} dt.
Checks: (1) the identity against exact Poisson summation, (2) concavity of
phi_lambda(s) = s Psi(lambda s^{-2/(p-2)}), (3) L(G) <= L(lambda delta_1) on random G, (4) the size of
Phi(G) - Phi(G*) relative to lambda^{(p-3)/2} for random G at large lambda.
"""
import sys
import numpy as np
import mpmath as mp
from scipy import special

sys.path.insert(0, '.')
from idlaw import abs_moment, m_p  # noqa: E402

mp.mp.dps = 30
p = float(sys.argv[1]) if len(sys.argv) > 1 else 4.5
cprime = float(-mp.gamma(-p) * mp.cos(mp.pi * p / 2))


def k2(u):
    u = mp.mpf(u)
    if abs(u) < mp.mpf('0.5'):
        return mp.nsum(lambda k: (-1) ** int(k) * u ** (2 * k) / mp.factorial(2 * k), [2, mp.inf])
    return mp.cos(u) - 1 + u ** 2 / 2


def Psi(mu):
    return mp.quad(lambda u: k2(u) * (-mp.expm1(-mu * u ** 2 / 2)) * u ** (-p - 1), [0, 0.1, 1, 10, 100, mp.inf])


def phi(lam, s):
    beta = 2 / (p - 2)
    return s * Psi(lam * s ** (-beta))


def LN(lam, atoms):
    """atoms: list of (x, mass) with sum mass x^2 = sum mass |x|^p = lam. Returns L, N via quadrature."""
    def r3(u):
        u = mp.mpf(u)
        if abs(u) < mp.mpf('0.5'):
            re = sum((-1) ** k * u ** (2 * k) / mp.factorial(2 * k) for k in range(2, 30))
            im = sum((-1) ** k * u ** (2 * k + 1) / mp.factorial(2 * k + 1) for k in range(1, 30))
            return mp.mpc(re, im)
        return mp.mpc(mp.cos(u) - 1 + u ** 2 / 2, mp.sin(u) - u)

    atoms = [(mp.mpf(float(x)), mp.mpf(float(m))) for x, m in atoms]

    def psir(t):
        return sum(m * r3(t * x) for x, m in atoms)

    def Lint(t):
        return mp.re(psir(t)) * (-mp.expm1(-lam * t ** 2 / 2)) * t ** (-p - 1)

    def Nint(t):
        g = lam * t ** 2 / 2
        if t < 1:
            z = psir(t)
            if abs(z) < mp.mpf('1e-3'):
                val = mp.exp(-g) * (z ** 2 / 2 + z ** 3 / 6 + z ** 4 / 24 + z ** 5 / 120)
            else:
                val = mp.exp(z - g) - mp.exp(-g) * (1 + z)
            return -mp.re(val) * t ** (-p - 1)
        # large t: psi = -a + i b computed directly (z - g would cancel catastrophically)
        a = sum(m * (1 - mp.cos(t * x)) for x, m in atoms)
        b = sum(m * (mp.sin(t * x) - t * x) for x, m in atoms)
        rez = g - a
        return -(mp.exp(-a) * mp.cos(b) - mp.exp(-g) * (1 + rez)) * t ** (-p - 1)

    pts = sorted(set([0] + [k * mp.pi for k in range(1, 60)] + [mp.mpf(1) / mp.sqrt(lam), 3 / mp.sqrt(lam)]))
    L = mp.quad(Lint, pts + [mp.inf])
    N = mp.quad(Nint, pts) + mp.quad(Nint, [pts[-1], mp.inf])
    return L, N


def Phi_exact(lam, atoms):
    # tilde X_G = sum c_j (N_j - lam_j) with lam_j = mass_j; abs_moment expects (c, rate) pairs
    return abs_moment(p, 0.0, [(x, m) for x, m in atoms])


if __name__ == '__main__':
    print(f"p={p}, c'_p={cprime:.6f}")
    # (2) concavity of phi_lambda in s; by phi_lambda(s) = lambda^{1/beta} phi_1(s lambda^{-1/beta}) the case lambda = 1 suffices
    ss = [mp.mpf(10) ** (k / 5) for k in range(-20, 21)]
    vals = [phi(1.0, s) for s in ss]
    sec = [(vals[i + 1] - vals[i]) / (ss[i + 1] - ss[i]) for i in range(len(ss) - 1)]
    mono = all(sec[i] > sec[i + 1] for i in range(len(sec) - 1))
    print(f"lambda=1, 41-point log grid s in [1e-4, 1e4]: secant slopes strictly decreasing (concave): {mono}")
    # (1) identity check
    for lam in [2.0, 10.0]:
        atoms = [(1.0, lam)]
        L, N = LN(lam, atoms)
        lhs = Phi_exact(lam, atoms)
        rhs = lam + float(m_p(p)) * lam ** (p / 2) + float((L + N) / cprime)
        print(f"identity G*=lam delta_1, lam={lam}: exact={lhs:.10f}  formula={rhs:.10f}")
        # a two-atom G with same constraints: x1=0.5, x2 chosen s.t. constraints hold
        x1, x2 = 0.5, 1.6
        # solve m1 x1^2 + m2 x2^2 = lam, m1 x1^p + m2 x2^p = lam
        Amat = np.array([[x1 ** 2, x2 ** 2], [x1 ** p, x2 ** p]])
        m1, m2 = np.linalg.solve(Amat, [lam, lam])
        atoms2 = [(x1, m1), (x2, m2)]
        L2, N2 = LN(lam, atoms2)
        lhs2 = Phi_exact(lam, atoms2)
        rhs2 = lam + float(m_p(p)) * lam ** (p / 2) + float((L2 + N2) / cprime)
        print(f"identity two-atom, lam={lam}: exact={lhs2:.10f}  formula={rhs2:.10f};  L2-L*={float(L2 - L):.6e}, N2-N*={float(N2 - N):.6e}")
    # (4) random G at large lambda: (Phi(G) - Phi(G*)) / lambda^{(p-3)/2}
    rng = np.random.default_rng(3)
    for lam in [5.0, 20.0, 80.0]:
        star = Phi_exact(lam, [(1.0, lam)])
        worst = -np.inf
        for trial in range(300):
            k = rng.integers(2, 4)
            xs = rng.choice([-1, 1], size=k) * np.exp(rng.normal(0, 0.7, size=k))
            w = rng.dirichlet(np.ones(k))
            mom = np.sum(w * np.abs(xs) ** (p - 2))
            xs = xs / mom ** (1 / (p - 2))  # E|Y|^{p-2}=1 for Y~w on xs
            masses = lam * w / xs ** 2
            try:
                val = Phi_exact(lam, list(zip(xs, masses)))
            except ValueError:
                continue
            worst = max(worst, (val - star) / lam ** ((p - 3) / 2))
        print(f"lam={lam}: Phi*={star:.6f}, max (Phi(G)-Phi*)/lam^((p-3)/2) over 300 random G = {worst:.4e}")
