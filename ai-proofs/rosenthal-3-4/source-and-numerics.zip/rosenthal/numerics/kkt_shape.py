"""Shape of the first-variation function along the moment curve.

For f(x)=|x|^p and a law W, Psi_W(u) = E[f(W+u)-f(W)-u f'(W)]/u^2 (Psi_W(0)=E f''(W)/2).
KKT for a maximiser H of E|Y_H|^p over {int H = B, int |u|^{p-2} H = A, supp in [-M,M]}:
    Psi_W(u) <= alpha + beta |u|^{p-2}  on [-M,M], equality on supp H,  W = Y_H.
So supp H on (0,M] is governed by the convexity of g_+(v) = Psi_W(v^{1/(p-2)}):
    g_+ strictly convex  => contacts only at v in {0, M^{p-2}}  (Gaussian + far jump)
    g_+ strictly concave => at most one contact on (0, M]       (single Poisson atom)
We test the sign of g_+'' for several laws W.
"""
import sys
import numpy as np
from idlaw import _support, gauss_abs_moment


def law_gauss(s=1.0):
    x, w = np.polynomial.hermite_e.hermegauss(200)
    return s * x, w / w.sum(), s  # discrete approx unused when s>0 handled analytically


def psi_discrete(p, vals, wts, u, sgauss=0.0):
    """Psi for W = discrete(vals,wts) + sgauss*Z, at array u (u != 0)."""
    u = np.atleast_1d(u)
    out = np.empty_like(u)
    if sgauss > 0:
        # E|v+sZ|^p, E[|v+sZ|^{p-2}(v+sZ)] via numerical quadrature on a fine grid
        z, gw = np.polynomial.hermite_e.hermegauss(160)
        gw = gw / gw.sum()
        pts = (vals[:, None] + sgauss * z[None, :]).ravel()
        pw = (wts[:, None] * gw[None, :]).ravel()
    else:
        pts, pw = vals, wts
    f0 = np.sum(pw * np.abs(pts) ** p)
    f1 = np.sum(pw * p * np.abs(pts) ** (p - 2) * pts)
    for i, uu in enumerate(u):
        if sgauss > 0:
            fu = np.sum(wts * gauss_abs_moment(vals + uu, sgauss, p))
        else:
            fu = np.sum(pw * np.abs(pts + uu) ** p)
        out[i] = (fu - f0 - uu * f1) / uu ** 2
    return out


def convexity_profile(p, vals, wts, sgauss=0.0, side=+1, vmax=50.0, n=400):
    v = np.exp(np.linspace(np.log(1e-3), np.log(vmax), n))
    u = side * v ** (1 / (p - 2))
    g = psi_discrete(p, vals, wts, u, sgauss)
    lv = np.log(v)
    # second derivative of g w.r.t. v on a log grid
    dg = np.gradient(g, v)
    d2g = np.gradient(dg, v)
    return v, g, d2g


if __name__ == "__main__":
    p = float(sys.argv[1])
    tests = {}
    # two-point mean-zero laws {-a, b}
    for a, b in [(1, 1), (1, 3), (3, 1), (1, 10), (10, 1), (0.2, 1)]:
        tests[f"2pt(-{a},{b})"] = (np.array([-a, b], float), np.array([b / (a + b), a / (a + b)]), 0.0)
    # centered Poisson
    for lam in [0.2, 1.0, 5.0]:
        k, w = _support(lam)
        tests[f"Pois({lam})"] = ((k - lam) / np.sqrt(lam), w, 0.0)
    tests["Gauss"] = (np.array([0.0]), np.array([1.0]), 1.0)
    k, w = _support(1.0)
    tests["Gauss(0.5)+Pois(1)"] = ((k - 1.0) * np.sqrt(0.5), w, np.sqrt(0.5))
    for name, (vals, wts, sg) in tests.items():
        for side in (+1, -1):
            v, g, d2g = convexity_profile(p, vals, wts, sg, side)
            inner = slice(5, -5)
            print(f"p={p} {name:22s} side={side:+d}: min g''={d2g[inner].min():+.3e} max g''={d2g[inner].max():+.3e}"
                  f"  frac(g''>0)={np.mean(d2g[inner] > 0):.2f}", flush=True)
