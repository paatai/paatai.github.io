"""Thresholds lambda_near, lambda_far in the proof of Theorem K, computed from the proof's explicit constants
(after the refined Lipschitz bound in Step 1). Evidence/bookkeeping only."""
import numpy as np
from scipy import integrate, special, optimize

G = special.gamma


def gauss_mom(alpha, k):
    """int_0^inf e^{-alpha t^2} t^k dt."""
    return 0.5 * alpha ** (-(k + 1) / 2) * G((k + 1) / 2)


def constants(p):
    omega0 = lambda s: (p - 3) / (p - 2) + s ** (p - 2) / (p - 2) - s
    s1 = np.linspace(0, 0.5, 20001)[:-1]
    s2 = np.exp(np.linspace(np.log(2), np.log(1e8), 400001))[1:]
    C_om = max(np.max((1 + s1 ** (p - 2)) / omega0(s1)), np.max((1 + s2 ** (p - 2)) / omega0(s2)),
               (1 + 2 ** (p - 2)) / omega0(2.0))
    C_M = max(968.0, 5 * max(1.0, C_om))
    t1 = min(0.45, np.sqrt(10 / (3 * C_om)))
    c_B = min(1 / 108, 1 / (24 * max(1.0, C_om)))
    c_s = c_B * np.exp(-0.5) / (14 * (6 - p))
    C1 = (C_M / 24) * 0.5 * 2 ** ((7 - p) / 2) * G((7 - p) / 2)            # coefficient of lambda^{(p-3)/2}
    C2a = (C_M / 72) * 0.5 * (32 / 11) ** ((9 - p) / 2) * G((9 - p) / 2)    # coefficient of lambda^{(p-3)/2}
    C3 = (C_M / 4) * gauss_mom(0.25, 5 - p)
    zeta = special.zeta(p - 1)

    def term2b(lam):
        J = 2 * np.sqrt(2) * np.pi ** (2 - p) * zeta * lam ** -0.5 + np.pi ** 2 * 2 ** (p - 1) / p / lam
        tail = integrate.quad(lambda t: np.exp(-lam * t * t / 4) * t ** (1 - p), 0.5, np.inf)[0]
        return C_M * lam * (J + 3 * tail)

    def near_excess(lam):  # >0 means the near-case inequality fails at lam
        return (C3 * lam ** 2 * np.exp(-lam * t1 ** 2 / 4) + (C1 + C2a) * lam ** ((p - 3) / 2) + term2b(lam)
                - c_s * lam ** ((p - 2) / 2))

    Om1 = 1 / (7 * C_M)
    n1 = 2 ** ((6 - p) / 2) * G((6 - p) / 2) / 144
    C4 = 120 ** (-(p - 3) / 2) * 6 ** ((p - 5) / 2)

    def far_excess(lam):
        a = lam / 2
        C5t = lam ** 2 / 2 * (C4 / 3 * gauss_mom(a, 2) + C4 ** 2 * gauss_mom(a, p - 1))
        C6t = lam ** 2 / 720 * gauss_mom(a, 7 - p)
        Nc = lam ** 2 / 1152 * gauss_mom(a, 7 - p)
        N3 = (lam ** 3 / 6 * (gauss_mom(a, 11 - p) / 13824 + gauss_mom(a, 9 - p) / 288)
              + lam ** 4 / 31104 * gauss_mom(11 * lam / 32, 11 - p) + 3 * 2 ** p / p)
        return C5t + C6t + 2 * (Nc + N3) - Om1 * n1 / (10 + C_om) * lam ** ((p - 2) / 2)

    def threshold(f):
        grid = np.logspace(0, 60, 6001)
        bad = [lam for lam in grid if not f(lam) < 0]
        return bad[-1] if bad else 1.0

    return dict(C_om=C_om, c_B=c_B, c_s=c_s, t1=t1,
                lam_near=threshold(near_excess), lam_far=threshold(far_excess))


if __name__ == '__main__':
    for p in [4.05, 4.2, 4.5, 4.8, 4.95]:
        d = constants(p)
        print(f"p={p}: C_omega={d['C_om']:.3f} c_B={d['c_B']:.4g} c_s={d['c_s']:.3g} t1={d['t1']:.3f} "
              f"log10 lambda_near={np.log10(d['lam_near']):.1f} log10 lambda_far={np.log10(d['lam_far']):.1f}")
