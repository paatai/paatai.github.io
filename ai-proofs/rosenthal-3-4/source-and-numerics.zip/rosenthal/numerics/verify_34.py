"""Numerical sanity checks for the claimed theorem (3 <= p < 4), all with exact summation:

  (i)   Poissonisation:  E|S|^p <= E|X_G|^p,  G = sum_i law(X_i) restricted to R\{0}
  (ii)  pointwise bracket: e^{-a}cos b + a - e^{-g} - g <= 0 (mpmath, 40 digits)
  (iii) final bound:     E|X_G|^p <= A + m_p B^{p/2}  and  E|S|^p <= A + m_p B^{p/2}
"""
import numpy as np
import mpmath as mp
from scipy.stats import poisson
from idlaw import m_p

rng = np.random.default_rng(7)
mp.mp.dps = 40


def zero_mean_law(npts):
    x = rng.normal(0, 1, npts) * np.exp(rng.normal(0, 0.7, npts))
    w = rng.dirichlet(np.ones(npts))
    x = x - np.dot(w, x)
    return x, w


def sum_law(laws):
    vals, wts = np.array([0.0]), np.array([1.0])
    for x, w in laws:
        vals = (vals[:, None] + x[None, :]).ravel()
        wts = (wts[:, None] * w[None, :]).ravel()
    return vals, wts


def compound_poisson_law(xs, ws, tail=1e-16):
    """Law of sum_k xs[k] N_k, N_k ~ Poisson(ws[k]) independent (exact up to tail truncation)."""
    vals, wts = np.array([0.0]), np.array([1.0])
    for x, lam in zip(xs, ws):
        K = int(lam + 12 * np.sqrt(lam) + 30)
        k = np.arange(K + 1)
        pk = poisson.pmf(k, lam)
        vals = (vals[:, None] + x * k[None, :]).ravel()
        wts = (wts[:, None] * pk[None, :]).ravel()
        keep = wts > tail
        vals, wts = vals[keep], wts[keep]
        # merge near-duplicates to keep size manageable
        if vals.size > 200000:
            order = np.argsort(vals)
            vals, wts = vals[order], wts[order]
            r = np.round(vals, 10)
            u, inv = np.unique(r, return_inverse=True)
            wts = np.bincount(inv, weights=wts)
            vals = u
    return vals, wts


def bracket_max(xs, ws, B, ts):
    worst = -mp.inf
    for t in ts:
        t = mp.mpf(t)
        a = mp.fsum([w * (1 - mp.cos(t * x)) for x, w in zip(xs, ws)])
        b = mp.fsum([w * mp.sin(t * x) for x, w in zip(xs, ws)])
        g = t * t * B / 2
        h = mp.e ** (-a) * mp.cos(b) + a - mp.e ** (-g) - g
        worst = max(worst, h / (1 + g * g))
    return worst


worst_final, worst_pois, worst_br = -np.inf, -np.inf, -mp.inf
for trial in range(60):
    p = rng.uniform(3.0, 4.0)
    n = int(rng.integers(1, 4))
    laws = [zero_mean_law(int(rng.integers(2, 4))) for _ in range(n)]
    vals, wts = sum_law(laws)
    ES = np.dot(wts, np.abs(vals) ** p)
    A = sum(np.dot(w, np.abs(x) ** p) for x, w in laws)
    B = sum(np.dot(w, x ** 2) for x, w in laws)
    xs = np.concatenate([x for x, _ in laws])
    ws = np.concatenate([w for _, w in laws])
    cv, cw = compound_poisson_law(xs, ws)
    EG = np.dot(cw, np.abs(cv) ** p) / cw.sum()
    bound = A + m_p(p) * B ** (p / 2)
    br = bracket_max([mp.mpf(float(x)) for x in xs], [mp.mpf(float(w)) for w in ws], mp.mpf(float(B)),
                     np.geomspace(1e-2, 50, 60))
    worst_final = max(worst_final, (EG - bound) / bound)
    worst_pois = max(worst_pois, (ES - EG) / EG)
    worst_br = max(worst_br, br)
    if trial < 10:
        print(f"p={p:.3f} n={n} E|S|^p={ES:.6g} <= E|X_G|^p={EG:.6g} <= A+m_pB^(p/2)={bound:.6g}  "
              f"max bracket/(1+g^2)={float(br):.3e}")
print("max rel (E|X_G|^p - bound)/bound:", worst_final)
print("max rel (E|S|^p - E|X_G|^p)/E|X_G|^p:", worst_pois)
print("max normalised bracket:", float(worst_br))
