"""For 4<p<6:  c'(E|X_G|^p - A - m_p B^{p/2}) = T_sym(G) + T_skew(G),
   T_sym  = int [F(g)-F(a)] t^{-p-1} dt   (depends on |x|-distribution only; maximised by single |x| (Utev))
   T_skew = int e^{-a}(1-cos b) t^{-p-1} dt.
Test whether T_skew(G) <= T_skew(G*) (G* = Poisson with same A,B) for random G, and check the identity
against direct computation."""
import sys
import numpy as np
from scipy.integrate import quad
from idlaw import abs_moment, AB, poisson_candidate, m_p

p = float(sys.argv[1]) if len(sys.argv) > 1 else 4.5
rng = np.random.default_rng(1)


def k4(s):
    return 1 - np.cos(s) - s * s / 2 + s ** 4 / 24


cprime = quad(lambda s: k4(s) * s ** (-p - 1), 0, 1, limit=200)[0] + quad(lambda s: k4(s) * s ** (-p - 1), 1, np.inf, limit=400)[0]


def terms(xs, ws):
    # G = sum ws delta_xs (Levy measure, int x dG need not vanish: we centre => b uses sin(tx)-tx)
    B = np.dot(ws, xs ** 2)

    def ab(t):
        a = np.dot(ws, 1 - np.cos(t * xs))
        b = np.dot(ws, np.sin(t * xs) - t * xs)
        return a, b
    def Tsym_int(t):
        a, b = ab(t); g = t * t * B / 2
        return ((np.exp(-g) + g) - (np.exp(-a) + a)) * t ** (-p - 1)
    def Tskew_int(t):
        a, b = ab(t)
        return np.exp(-a) * (1 - np.cos(b)) * t ** (-p - 1)
    edges = np.concatenate([[0], np.geomspace(1e-3, 1e4, 400)])
    Ts = sum(quad(Tsym_int, lo, hi, limit=100)[0] for lo, hi in zip(edges[:-1], edges[1:]))
    Tk = sum(quad(Tskew_int, lo, hi, limit=100)[0] for lo, hi in zip(edges[:-1], edges[1:]))
    return Ts, Tk, B


# Poisson reference with A, B
def poisson_terms(A, B):
    c = (A / B) ** (1 / (p - 2)); lam = B / c ** 2
    return terms(np.array([c]), np.array([lam]))


worst_skew = -np.inf
for trial in range(40):
    k = rng.integers(2, 4)
    xs = rng.normal(0, 1, k) * np.exp(rng.normal(0, 0.6, k))
    ws = rng.dirichlet(np.ones(k)) / xs ** 2  # H-weights -> B = 1
    A = np.dot(ws, np.abs(xs) ** p); B = np.dot(ws, xs ** 2)
    Ts, Tk, _ = terms(xs, ws)
    Ts0, Tk0, _ = poisson_terms(A, B)
    # consistency check with direct moment computation
    atoms = [(x, w) for x, w in zip(xs, ws)]
    direct = abs_moment(p, 0.0, atoms) - A - m_p(p) * B ** (p / 2)
    worst_skew = max(worst_skew, Tk / Tk0)
    if trial < 10:
        print(f"x={np.round(xs,3)} A={A:.3g}: direct={direct:.5g} identity={(Ts+Tk)/cprime:.5g} | "
              f"Tsym/Tsym*={Ts/Ts0:.4f}  Tskew/Tskew*={Tk/Tk0:.4f}")
print("max Tskew/Tskew* over trials:", worst_skew)
