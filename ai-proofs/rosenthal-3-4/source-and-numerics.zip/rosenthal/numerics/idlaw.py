"""Absolute moments of centered compound-Poisson-plus-Gaussian laws.

Y = sigma*Z + sum_j c_j (N_j - lam_j),  N_j ~ Poisson(lam_j) independent, Z ~ N(0,1).

In Pinelis' parametrisation H = sigma^2 delta_0 + sum_j w_j delta_{c_j}, w_j = c_j^2 lam_j,
B = int H = sigma^2 + sum_j w_j,  A = int |u|^{p-2} H(du) = sum_j |c_j|^p lam_j.
"""
import numpy as np
from scipy.special import hyp1f1, gammaln
from scipy.stats import poisson


_GH_X, _GH_W = np.polynomial.hermite_e.hermegauss(80)
_GH_W = _GH_W / np.sqrt(2 * np.pi)


def gauss_abs_moment(m, s, p):
    """E|m + s Z|^p, vectorised in m; s >= 0."""
    m = np.asarray(m, dtype=float)
    if s == 0:
        return np.abs(m) ** p
    out = np.empty_like(m)
    small = np.abs(m) <= 7.5 * s
    if np.any(small):
        z = -(m[small] ** 2) / (2 * s * s)
        const = s ** p * 2 ** (p / 2) * np.exp(gammaln((p + 1) / 2)) / np.sqrt(np.pi)
        out[small] = const * hyp1f1(-p / 2, 0.5, z)
    big = ~small
    if np.any(big):
        # kink of |m+sZ|^p lies beyond 7.5 standard deviations: smooth Gauss-Hermite
        mb = m[big]
        vals = np.abs(mb[:, None] + s * _GH_X[None, :]) ** p
        out[big] = vals @ _GH_W
    return out


def m_p(p):
    return 2 ** (p / 2) * np.exp(gammaln((p + 1) / 2)) / np.sqrt(np.pi)


def _support(lam, tail=1e-17, p=6.0):
    if lam <= 0:
        return np.array([0]), np.array([1.0])
    lo = max(0, int(lam - 15 * np.sqrt(lam) - 40))
    hi = int(lam + 15 * np.sqrt(lam) + 40)
    if hi - lo > 3_000_000:
        raise ValueError("Poisson support too large")
    k = np.arange(lo, hi + 1)
    w = poisson.pmf(k, lam)
    # prune on the contribution to a p-th moment, not on the probability alone: for small lam the
    # terms k >= 5 have tiny weight but large |k - lam|^p
    keep = w * (1 + np.abs(k - lam)) ** p > tail * min(lam, 1.0) * 1e-5
    if not keep.any():
        keep[np.argmax(w)] = True
    k, w = k[keep], w[keep]
    # scipy's pmf carries ~1e-9 relative error for huge lam; renormalise
    return k, w / w.sum()


def abs_moment(p, sigma2, atoms):
    """E|Y|^p for Y = sqrt(sigma2) Z + sum c_j (N_j - lam_j); atoms = [(c_j, lam_j), ...]."""
    s = np.sqrt(max(sigma2, 0.0))
    vals = np.array([0.0])
    wts = np.array([1.0])
    for (c, lam) in atoms:
        k, w = _support(lam, p=p)
        vals = (vals[:, None] + c * (k[None, :] - lam)).ravel()
        wts = (wts[:, None] * w[None, :]).ravel()
        if vals.size > 4_000_000:
            raise ValueError("support too large")
    return float(np.sum(wts * gauss_abs_moment(vals, s, p)))


def AB(p, sigma2, atoms):
    A = sum(abs(c) ** p * lam for c, lam in atoms)
    B = sigma2 + sum(c * c * lam for c, lam in atoms)
    return A, B


def poisson_candidate(p, A, B):
    """c^p E|Pi_lam - lam|^p with c^p lam = A, c^2 lam = B (Pinelis p>=5 extremal)."""
    c = (A / B) ** (1.0 / (p - 2))
    lam = B / c ** 2
    return abs_moment(p, 0.0, [(c, lam)])


def gauss_jump_candidate(p, A, B):
    """A + E|sqrt(B) Z|^p (Pinelis p in (2,3] extremal, conjectured for (3,4))."""
    return A + m_p(p) * B ** (p / 2)
