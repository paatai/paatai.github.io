"""Killer pass on Theorem 1.1: maximise E|S|^p / (A + m_p B^{p/2}) over finite sums of
independent zero-mean discrete summands (exact evaluation), 3 <= p <= 4. Ratio > 1 would refute it."""
import sys
import numpy as np
from scipy.optimize import minimize
from idlaw import m_p

rng = np.random.default_rng(int(sys.argv[2]) if len(sys.argv) > 2 else 3)
p = float(sys.argv[1])


def build(theta, n, k):
    laws = []
    th = theta.reshape(n, 2 * k)
    for row in th:
        x = np.sinh(row[:k]) * 3
        w = np.exp(row[k:] - row[k:].max())
        w /= w.sum()
        x = x - np.dot(w, x)
        laws.append((x, w))
    return laws


def ratio(theta, n, k):
    laws = build(theta, n, k)
    vals, wts = np.array([0.0]), np.array([1.0])
    for x, w in laws:
        vals = (vals[:, None] + x[None, :]).ravel()
        wts = (wts[:, None] * w[None, :]).ravel()
    A = sum(np.dot(w, np.abs(x) ** p) for x, w in laws)
    B = sum(np.dot(w, x ** 2) for x, w in laws)
    if B < 1e-12:
        return 0.0
    return np.dot(wts, np.abs(vals) ** p) / (A + m_p(p) * B ** (p / 2))


best = 0
for n in [1, 2, 3, 4]:
    for k in [2, 3]:
        for _ in range(12):
            th0 = rng.normal(0, 1.5, n * 2 * k)
            res = minimize(lambda t: -ratio(t, n, k), th0, method="Nelder-Mead",
                           options={"maxiter": 6000, "xatol": 1e-9, "fatol": 1e-13})
            r = -res.fun
            if r > best:
                best = r
                laws = build(res.x, n, k)
        print(f"p={p} n={n} k={k} best ratio so far={best:.10f}", flush=True)
print("FINAL best ratio", best)
for x, w in laws:
    print("  summand atoms", np.round(x, 4), "weights", np.round(w, 5))
