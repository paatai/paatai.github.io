"""Numerically stable test of the decomposition (4<p<6):
   c'(E|X_G|^p - A - m_p B^{p/2}) = T_sym(G) + T_skew(G),
   T_sym(G)  = int_0^inf [F(g)-F(a)] t^{-p-1} dt,  F(x)=e^{-x}+x,
   T_skew(G) = int_0^inf e^{-a}(1-cos b) t^{-p-1} dt,
a = sum w(1-cos tx), b = sum w(sin tx - tx), g = t^2 B/2 (centred compound Poisson, Levy measure G=sum w delta_x).
T_sym(G) <= T_sym(Poisson) by Utev's symmetric theorem; question: T_skew(G) <= T_skew(Poisson)?
All small-argument cancellations are removed by series expansions.
"""
import sys
import numpy as np
import mpmath as mp
from idlaw import abs_moment, m_p

mp.mp.dps = 30


def kser(s):            # cos s - 1 + s^2/2 >= 0
    if abs(s) < mp.mpf("0.3"):
        s2 = s * s
        return s2 * s2 * (mp.mpf(1) / 24 - s2 / 720 + s2 * s2 / 40320 - s2 ** 3 / 3628800)
    return mp.cos(s) - 1 + s * s / 2


def sinm(s):            # sin s - s
    if abs(s) < mp.mpf("0.3"):
        s2 = s * s
        return -s * s2 * (mp.mpf(1) / 6 - s2 / 120 + s2 * s2 / 5040 - s2 ** 3 / 362880)
    return mp.sin(s) - s


def k4ser(s):           # 1 - cos s - s^2/2 + s^4/24 >= 0
    if abs(s) < mp.mpf("0.5"):
        s2 = s * s
        return s2 ** 3 * (mp.mpf(1) / 720 - s2 / 40320 + s2 * s2 / 3628800 - s2 ** 3 / 479001600)
    return 1 - mp.cos(s) - s * s / 2 + s ** 4 / 24


def make_funcs(xs, ws, p):
    xs = [mp.mpf(float(x)) for x in xs]
    ws = [mp.mpf(float(w)) for w in ws]
    B = mp.fsum([w * x * x for x, w in zip(xs, ws)])

    def parts(t):
        a = mp.fsum([w * 2 * mp.sin(t * x / 2) ** 2 for x, w in zip(xs, ws)])
        b = mp.fsum([w * sinm(t * x) for x, w in zip(xs, ws)])
        d = mp.fsum([w * kser(t * x) for x, w in zip(xs, ws)])      # g - a >= 0
        g = t * t * B / 2
        return a, b, d, g

    def sym(t):
        a, b, d, g = parts(t)
        if d > 1:
            val = d - (mp.e ** (-a) - mp.e ** (-g))                   # F(g) - F(a)
        else:
            val = d - mp.e ** (-g) * mp.expm1(d)
        return val * t ** (-p - 1)

    def skew(t):
        a, b, d, g = parts(t)
        return mp.e ** (-a) * 2 * mp.sin(b / 2) ** 2 * t ** (-p - 1)
    return sym, skew, B


def integrate(fn, xs):
    xa = [abs(float(x)) for x in xs]
    pts = [mp.mpf(0)] + [mp.mpf(v) for v in np.geomspace(1e-2 / max(xa), 3e2 / min(xa), 90)] + [mp.inf]
    return mp.quad(fn, pts)


def kprime(p):
    return mp.quad(lambda s: k4ser(s) * s ** (-p - 1), [0, 0.5, 1, 10, 100, 1000, mp.inf])


if __name__ == "__main__":
    p = mp.mpf(sys.argv[1]) if len(sys.argv) > 1 else mp.mpf("4.5")
    ntr = int(sys.argv[2]) if len(sys.argv) > 2 else 25
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else int(float(p) * 1000)
    rng = np.random.default_rng(seed)
    cp = kprime(p)
    worst, worst_id = -1, 0
    for trial in range(ntr):
        k = int(rng.integers(1, 4))
        xs = rng.normal(0, 1, k) * np.exp(rng.normal(0, 0.6, k))
        ws = rng.dirichlet(np.ones(k)) / xs ** 2
        A = float(np.dot(ws, np.abs(xs) ** float(p))); B = float(np.dot(ws, xs ** 2))
        sym, skew, _ = make_funcs(xs, ws, p)
        Ts, Tk = integrate(sym, xs), integrate(skew, xs)
        c = (A / B) ** (1 / (float(p) - 2)); lam = B / c ** 2
        sym0, skew0, _ = make_funcs([c], [lam], p)
        Ts0, Tk0 = integrate(sym0, [c]), integrate(skew0, [c])
        direct = abs_moment(float(p), 0.0, list(zip(xs, ws))) - A - m_p(float(p)) * B ** (float(p) / 2)
        ident = float((Ts + Tk) / cp)
        r = float(Tk / Tk0)
        worst = max(worst, r)
        worst_id = max(worst_id, abs(ident - direct) / max(abs(direct), 1e-12))
        print(f"p={float(p)} x={np.round(xs,3)} lamcand={lam:.3g}: direct={direct:.7g} identity={ident:.7g} "
              f"Tsym/Tsym*={float(Ts/Ts0):.5f} Tskew/Tskew*={r:.5f}", flush=True)
    print("MAX Tskew/Tskew*:", worst, "  max rel identity error:", worst_id)
