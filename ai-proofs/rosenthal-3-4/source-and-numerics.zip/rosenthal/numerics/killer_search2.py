"""Numerical killer pass on Pinelis' conjectures (exact Rosenthal bound, 3<p<5).

Objective: ratio R(H) = E|Y_H|^p / max(Poisson(A,B), A + m_p B^{p/2}),
over H = sigma^2 delta_0 + sum_j w_j delta_{c_j}; R>1 would be a counterexample
to 'sup = max of the two known candidates'.
"""
import sys
import numpy as np
from scipy.optimize import minimize
from idlaw import abs_moment, AB, poisson_candidate, gauss_jump_candidate

rng = np.random.default_rng(int(sys.argv[2]) if len(sys.argv) > 2 else 0)
LAMLO, LAMHI = 0.01, 100.0


def unpack(theta, k):
    # theta: [s0, s1..sk (softmax weights incl. gaussian), c1..ck (log|c| ), signs fixed separately]
    logits = theta[: k + 1]
    w = np.exp(logits - logits.max())
    w = w / w.sum()  # total variance B = 1
    logc = theta[k + 1: 2 * k + 1]
    return w, np.exp(logc)


def ratio(theta, k, signs, p):
    w, c = unpack(theta, k)
    sigma2 = w[0]
    atoms = []
    for j in range(k):
        cj = signs[j] * c[j]
        lam = w[j + 1] / cj ** 2
        if lam > 400 or lam < 1e-12:
            if lam < 1e-12:
                continue
            return 0.0
        atoms.append((cj, lam))
    if not atoms:
        return 0.0
    A, B = AB(p, sigma2, atoms)
    lam_cand = (B ** (p / 2) / A) ** (2 / (p - 2))
    if not (LAMLO <= lam_cand <= LAMHI):
        return 0.0
    try:
        val = abs_moment(p, sigma2, atoms)
        ref = max(poisson_candidate(p, A, B), gauss_jump_candidate(p, A, B))
    except ValueError:
        return 0.0
    return val / ref


def search(p, k, signs, n_starts=30):
    best = (0, None)
    for _ in range(n_starts):
        theta0 = np.concatenate([rng.normal(0, 1.5, k + 1), rng.normal(0, 1.2, k)])
        res = minimize(lambda t: -ratio(t, k, signs, p), theta0, method="Nelder-Mead",
                       options={"maxiter": 3000, "xatol": 1e-7, "fatol": 1e-12})
        r = -res.fun
        if r > best[0]:
            best = (r, res.x)
    return best


if __name__ == "__main__":
    p = float(sys.argv[1])
    for k, signs in [(1, [1]), (2, [1, 1]), (2, [1, -1]), (3, [1, 1, -1]), (3, [1, -1, -1])]:
        r, th = search(p, k, signs)
        w, c = unpack(th, k)
        atoms = [(signs[j] * c[j], w[j + 1] / c[j] ** 2) for j in range(k)]
        A, B = AB(p, w[0], atoms)
        print(f"p={p} k={k} signs={signs} best ratio={r:.12f} sigma2={w[0]:.4g} "
              f"atoms(c,lam)={[(round(a, 4), round(b, 5)) for a, b in atoms]} A={A:.4g}",
              flush=True)
