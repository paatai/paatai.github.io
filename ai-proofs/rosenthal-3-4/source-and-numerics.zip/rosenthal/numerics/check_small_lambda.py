"""Numerical sanity checks (evidence only) for the small-lambda exactness argument (Theorem I).

(a) Lemma E: |e_t(y)| <= C_M t^2 hat_omega(y), with
    h_t(y) = (e^{ity}-1-ity)/y^2, e_t(y) = h_t(y) - h_t(1) - h_t'(1)/(p-2) (|y|^{p-2}-1).
(b) Lemma S: Q(lambda delta_1) - Q(G) >= c_1 lambda^2 E hat_omega(Y)   (lambda = 1 by homogeneity),
    with the reflection normalisation P(Y in [1/2,2]) >= P(Y in [-2,-1/2]).
(c) The constants C_omega, c_1, C_T and the resulting lambda_0 = (c_1/C_T)^{2/(p-4)}.
"""
import sys
import numpy as np
from scipy import integrate, special

p = float(sys.argv[1]) if len(sys.argv) > 1 else 4.5
r = p - 4
D_p = p * (p - 1) * (p - 2) * (p - 3) / 8


def omega0(s):
    return (p - 3) / (p - 2) + s ** (p - 2) / (p - 2) - s


def hat_omega(y):
    y = np.asarray(y, dtype=float)
    return omega0(np.abs(y)) + (y < 0) * (1 + np.abs(y) ** (p - 2))


def h(t, y):
    y = np.asarray(y, dtype=complex)
    out = np.empty_like(y)
    small = np.abs(t * y) < 1e-3
    z = 1j * t * y[~small]
    out[~small] = (np.exp(z) - 1 - z) / y[~small] ** 2
    ys = y[small]
    out[small] = -t ** 2 / 2 - 1j * t ** 3 * ys / 6 + t ** 4 * ys ** 2 / 24
    return out


def hprime1(t):
    return 1j * t * (np.exp(1j * t) - 1) - 2 * (np.exp(1j * t) - 1 - 1j * t)


def e_t(t, y):
    return h(t, y) - h(t, np.array([1.0]))[0] - hprime1(t) / (p - 2) * (np.abs(y) ** (p - 2) - 1)


# (c) C_omega = sup_{s notin [1/2,2]} (1+s^{p-2})/omega0(s)
s1 = np.linspace(0, 0.5, 20001)
s2 = np.exp(np.linspace(np.log(2), np.log(1e6), 200001))
C_omega = max(np.max((1 + s1 ** (p - 2)) / omega0(s1)), np.max((1 + s2 ** (p - 2)) / omega0(s2)))
print(f"p={p}: C_omega ~ {C_omega:.4f}")

# (a) Lemma E ratio
ys = np.concatenate([np.linspace(-50, 50, 200001), np.exp(np.linspace(-8, 8, 4001)),
                     -np.exp(np.linspace(-8, 8, 4001))])
ys = ys[np.abs(ys - 1) > 1e-7]
worst = 0
for t in np.exp(np.linspace(np.log(1e-3), np.log(1e4), 300)):
    ratio = np.max(np.abs(e_t(t, ys)) / (t ** 2 * hat_omega(ys)))
    worst = max(worst, ratio)
C_M = max(968, 5 * max(1, C_omega))
print(f"Lemma E: sup |e_t|/(t^2 hat_omega) ~ {worst:.3f}  (proof constant C_M = {C_M:.1f})")

# (b) Lemma S ratio over random finite G (lambda = 1): atoms y_j with H-weights w_j
rng = np.random.default_rng(1)
Vg, Vw = np.polynomial.legendre.leggauss(60)
Vg = (Vg + 1) / 2
Vw = Vw / 2 * 2 * (1 - Vg)  # density 2(1-v) on [0,1]


def EabsYV(y1, y2):
    # E|y1 V + y2 V'|^r for V,V' iid density 2(1-v)
    return np.einsum('i,j,ij->', Vw, Vw, np.abs(y1 * Vg[:, None] + y2 * Vg[None, :]) ** r)


e_r = EabsYV(1.0, 1.0)
min_ratio = np.inf
for trial in range(4000):
    k = rng.integers(1, 5)
    y = rng.choice([-1, 1], size=k) * np.exp(rng.normal(0, rng.choice([0.05, 0.3, 1.0, 2.0]), size=k))
    w = rng.dirichlet(np.ones(k))
    # enforce E|Y|^{p-2} = 1 by rescaling y (then y -> y / m^{1/(p-2)})
    m = np.sum(w * np.abs(y) ** (p - 2))
    y = y / m ** (1 / (p - 2))
    if np.sum(w * ((y >= 0.5) & (y <= 2))) < np.sum(w * ((y <= -0.5) & (y >= -2))):
        y = -y
    Q = sum(w[i] * w[j] * EabsYV(y[i], y[j]) for i in range(k) for j in range(k))
    deficit = D_p * (e_r - Q)
    Ew = np.sum(w * hat_omega(y))
    if Ew > 1e-10:
        min_ratio = min(min_ratio, deficit / Ew)
print(f"Lemma S: min deficit/E hat_omega over random G ~ {min_ratio:.4f}")
# explicit near-extremal configuration (found by the referee): Y two-point, all negative, at -1/2 and -2
# (just outside [-2,-1/2], so pi_+ = pi_- = 0 and Sigma = 0), weights fixed by E|Y|^{p-2} = 1
y = np.array([-0.5, -2.0])
w1 = (2.0 ** (p - 2) - 1) / (2.0 ** (p - 2) - 0.5 ** (p - 2))
w = np.array([w1, 1 - w1])
Q = sum(w[i] * w[j] * EabsYV(y[i], y[j]) for i in range(2) for j in range(2))
ratio_neg = D_p * (e_r - Q) / np.sum(w * hat_omega(y))
print(f"Lemma S: all-negative two-point Y at (-1/2, -2): deficit/E hat_omega = {ratio_neg:.6f}")
min_ratio = min(min_ratio, ratio_neg)

g_min_lb = r * 4 ** (r - 1) / 5  # g_* of Lemma S
c1a = D_p * r * e_r / (1 + 37 * C_omega)
c1b = D_p / max((1 + C_omega) / (r * e_r), 12 / g_min_lb)
c_1 = min(c1a, c1b)
print(f"proof constant c_1 = {c_1:.3e}")

cprime = -special.gamma(-p) * np.cos(np.pi * p / 2)
j_p = np.sqrt(8) ** (6 - p) / (8 * (6 - p)) + np.sqrt(8) ** (4 - p) / (p - 4)
C_T = C_M * j_p / cprime
lam0 = (c_1 / (2 * C_T)) ** (2 / (p - 4))
print(f"c'_p={cprime:.5f} j_p={j_p:.4f} C_T={C_T:.3e} -> lambda_0 = (c_1/(2 C_T))^(2/(p-4)) = {lam0:.3e}")
print(f"with the numerically observed constants: lambda_0 ~ {(min_ratio / (2 * worst * j_p / cprime)) ** (2 / (p - 4)):.3e}")
