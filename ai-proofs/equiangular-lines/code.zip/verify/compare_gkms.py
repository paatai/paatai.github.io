"""Compare Theorem U (odd centre, 2-adic AM-GM) with [GKMS16, Thm 5.21] (even centre).

For a Seidel matrix of order n with smallest eigenvalue -a of multiplicity n - d, and an even
integer mu, [GKMS16, Thm 5.21] gives sum_i (lam_i - mu)^2 >= d - m with m = dim ker(S - mu I).
For even mu, m = 0 if n is even ([GKMS16, Cor 3.6]: det(S - mu I) = det S = 1 (mod 2)) and m <= 1
if n is odd (S - mu I = J - I (mod 2) has rank n - 1 over F_2).  So n is excluded at an even centre
iff P2 - 2 mu P1 + d mu^2 < d - (n mod 2) for some even mu.

Prints, for every (a, d) of the Theorem U table domain, which of the two tests excludes
n0 = floor(R).  Exact integer arithmetic.
"""

import sys

from c1_uniform import excluded, relative_bound, sums


def gkms_even_excluded(a, d, n):
    P1, P2 = sums(a, d, n)
    gamma = n % 2
    k0 = P1 // d
    for mu in range(k0 - 4, k0 + 5):
        if mu % 2 == 0 and P2 - 2 * mu * P1 + d * mu * mu < d - gamma:
            return True, mu
    return False, None


def main():
    both = only_u = only_g = neither = 0
    rows = []
    for a in (5, 7, 9, 11, 13):
        for d in range(2, a * a - 2):
            R = relative_bound(a, d)
            n0 = int(R)
            if n0 <= 2 * d or R == n0:
                continue
            u, _ = excluded(a, d, n0, span=61)
            g, mu = gkms_even_excluded(a, d, n0)
            rows.append((a, d, n0, u, g))
            if u and g:
                both += 1
            elif u:
                only_u += 1
                print("only Theorem U:", a, d, n0)
            elif g:
                only_g += 1
                print("only GKMS16 even centre:", a, d, n0, "mu =", mu)
            else:
                neither += 1
    print(f"domain {len(rows)}: both {both}, only U {only_u}, only GKMS {only_g}, neither {neither}")
    # the family a = +-3 (mod 10), d = a^2 - 5, at the even centre
    bad = []
    for a in range(7, 2002, 2):
        if a % 10 not in (3, 7):
            continue
        d = a * a - 5
        n0 = int(relative_bound(a, d))
        g, _ = gkms_even_excluded(a, d, n0)
        if not g:
            bad.append(a)
    print("family a = +-3 mod 10, 7 <= a <= 2001, even centre fails for:", bad if bad else "none")
    return 0


if __name__ == "__main__":
    sys.exit(main())
