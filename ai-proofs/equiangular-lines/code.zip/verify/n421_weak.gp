\\ Program B without the parity refinement for Q (weakly type 2 only): cd verify && gp -q n421_weak.gp
\\ parisize is set here, at top level: changing it inside read() would abort the read.
default(parisize, 10^8);
WEAK = 1;
read("n421.gp");
