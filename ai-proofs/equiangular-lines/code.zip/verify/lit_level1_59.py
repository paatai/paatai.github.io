"""Second program for level 1 of 59 lines in R^18, built on an independently written deck_dp.py.

verify/second_program/deck_dp.py is an independently written program: sympy with pure-Python
ground types, exact rational eigenvalue isolation, the derivative principle, no code shared with program 1.
This driver only adds the case and compares.

For each psi (a leaf of the enumeration), chi_S = (x + 5)^41 (x - 11) psi(x - 11):
  * the factorisation is deck_dp.factor_S with the case dict(n=59, d=18, a=5,
    forced=[(11, 1)], c=11), i.e. (x + 5)^41 (x - 11) times the factors of psi(x - 11);
  * (F1) n = 59 is odd, so an even integer eigenvalue has multiplicity 1 (rank over GF(2));
    read off that factorisation;
  * (F2) chi_{S+I} = chi_S(x - 1) = sum a_i x^(59-i) (deck_dp.chi_shift_top) satisfies
    2^(i-1) | a_i, 2^i | a_i for even i ([GY19, Lemmas 3.1, 3.8], checked here) and
    [GY19, Lemma 3.12] for k <= 29 (deck_dp.l312_first_fail);
  * the deck is deck_dp.deck(deck_dp.setup(fac, case, box=False)): the members g of the
    principal submatrices S[i] (chi_{S[i]} = Quo_S g, [GSY21, Lemma 2.4]) with the trace
    conditions, interlacing, g(-5) != 0 (58 lines would otherwise lie in R^17, N(17) = 48)
    and chi_{S[i]}(x - 1) of type 2 (n - 1 = 58 is even, [GSY21, Lemmas 2.7, 2.8]);
  * Program 1's level-1 Farkas vector (data/level1_59/s<s>/<idx>.json, "farkas_A") is checked on
    this deck with deck_dp.check_cert: g.Y >= 0 for every member and h.Y < 0, where
    h = chi_S'/Quo_S is deck_dp's.

Usage: python3 lit_level1_59.py SHARD [workers] [indices...]
  reads runs/enum59_gp/gp_s<SHARD>of16.jsonl and data/level1_59/s<SHARD>/<idx>.json;
  writes runs/lit_level1_59/s<SHARD>/<idx>.json and prints one line per leaf.
"""

import json
import os
import sys
import time
from multiprocessing import Pool

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(HERE, "second_program"))
import deck_dp  # noqa: E402

CASE = "59_18"
CFG = dict(n=59, d=18, a=5, forced=[(11, 1)], c=11)
deck_dp.CASES[CASE] = CFG
deck_dp.N_PREV[CASE] = 48  # N(17) = 48 [GSY23]
KMAX = 29


def v2(a):
    return (a & -a).bit_length() - 1 if a else 10 ** 9


def f2_failure(psi):
    a = deck_dp.chi_shift_top(CFG, psi, 2 * KMAX + 2)
    if a[0] != 1 or a[1] != -59 or a[2] != 0:
        return "trace"
    for i in range(1, len(a)):
        if v2(a[i]) < (i if i % 2 == 0 else i - 1):
            return f"L31/L38 at i={i}"
    k = deck_dp.l312_first_fail(a, 59, KMAX)
    return None if k is None else f"L312 at k={k}"


def f1_failure(fac):
    for f, e in fac.items():
        if len(f) == 2 and e >= 2 and (-f[1]) % 2 == 0:
            return [-f[1], e]
    return None


def run(args):
    shard, idx, psi = args
    out_dir = os.path.join(ROOT, "runs", "lit_level1_59", f"s{shard}")
    out_path = os.path.join(out_dir, f"{idx}.json")
    if os.path.exists(out_path):
        with open(out_path) as fh:
            return json.load(fh)
    t0 = time.time()
    fac = deck_dp.factor_S(CFG, psi)
    res = {"idx": idx, "psi": psi}
    res["F1"] = f1_failure(fac)
    res["F2"] = f2_failure(psi) if res["F1"] is None else None
    mine_path = os.path.join(ROOT, "data", "level1_59", f"s{shard}", f"{idx}.json")
    mine = None
    if os.path.exists(mine_path):
        with open(mine_path) as fh:
            mine = json.load(fh)
    if res["F1"] is not None or res["F2"] is not None:
        res["verdict"] = "excluded (F1)" if res["F1"] is not None else "excluded (F2)"
    else:
        S = deck_dp.setup(fac, CFG, CASE, box=False)
        raw, filt, st = deck_dp.deck(S)
        res.update(delta=st["delta"], nodes=st["nodes"], deck_size=len(raw), h=S["h"])
        res["deck"] = raw
        if not raw:
            res["verdict"] = "excluded (empty deck)"
        elif mine is not None and mine.get("farkas_A") is not None:
            ok, ok_members, hY = deck_dp.check_cert(raw, S["h"], mine["farkas_A"])
            res["verdict"] = ("excluded (program 1's certificate A valid on this deck)" if ok else
                              f"certificate A FAILS (members ok: {ok_members}, h.Y = {hY})")
        else:
            res["verdict"] = "open"
    if mine is not None:
        cmp = {"F1": (mine["F1"] is None) == (res["F1"] is None),
               "F2": (mine["F2"] is None) == (res["F2"] is None)}
        if "deck" in res and "deck" in mine:
            cmp["deck"] = sorted(map(list, mine["deck"])) == res["deck"]
            cmp["h"] = mine.get("h") == res["h"]
        res["compare"] = cmp
    res["seconds"] = round(time.time() - t0, 2)
    os.makedirs(out_dir, exist_ok=True)
    with open(out_path + ".tmp", "w") as fh:
        json.dump(res, fh)
    os.replace(out_path + ".tmp", out_path)
    return res


def load_leaves(shard):
    path = os.path.join(ROOT, "runs", "enum59_gp", f"gp_s{shard}of16.jsonl")
    out = []
    with open(path) as fh:
        for line in fh:
            if not line.endswith("\n"):
                break
            d = json.loads(line)
            if "psi" in d:
                out.append(d["psi"])
    return out


def main():
    shard = int(sys.argv[1])
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    psis = load_leaves(shard)
    idxs = [int(a) for a in sys.argv[3:]] or list(range(len(psis)))
    jobs = [(shard, i, psis[i]) for i in idxs]
    with Pool(workers) as pool:
        for r in pool.imap_unordered(run, jobs):
            c = r.get("compare", {})
            bad = [k for k, v in c.items() if not v]
            print(time.strftime("%H:%M:%S"), r["idx"], r["verdict"],
                  f"deck={r.get('deck_size')}", "compare:" + ("ok" if c and not bad else
                                                              ("MISMATCH " + ",".join(bad)) if bad
                                                              else "none"),
                  f"{r['seconds']}s", flush=True)


if __name__ == "__main__":
    main()
