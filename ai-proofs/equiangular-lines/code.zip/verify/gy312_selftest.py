"""Validation of eqlines.gy312 ([GY19, Lemma 3.12]) on Seidel matrices that exist.

1. Random graphs A of odd order N = 5..61: the exact chi_{J-2A} must satisfy (R), (L31), (L38)
   and (L312) for every k <= (N-1)/2. The partition and power-sum evaluations of the right side
   must agree (k <= 8). For each k, adding 2^(2k) to a_{2k+1} must be detected at level k.
2. Odd-order principal submatrices of known line systems (files in data/constructions): the unitary
   two-graphs on 28 and 126 points, the 57-line systems in R^18 [GSY23], 72 lines in R^19 and
   90 lines in R^20.
"""

import random
import sys
import time
from pathlib import Path

from flint import fmpz_mat

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "src"))
from eqlines.gy312 import check_a, check_chi_S, plus_I_coeffs, rhs_newton, rhs_partition, v2_frac  # noqa: E402

CON = Path(__file__).resolve().parents[1] / "data" / "constructions"


def read_seidel(path):
    rows = [ln.strip() for ln in path.read_text().splitlines() if ln.strip() and not ln.startswith("#")]
    n = int(rows[0])
    return [[{"0": 0, "+": 1, "-": -1}[ch] for ch in r] for r in rows[1:1 + n]]


def random_graph_seidel(N, rng):
    p = rng.choice([0.2, 0.35, 0.5, 0.65, 0.8])
    S = [[0] * N for _ in range(N)]
    for i in range(N):
        for j in range(i + 1, N):
            S[i][j] = S[j][i] = -1 if rng.random() < p else 1
    return S


def main():
    t0 = time.time()
    rng = random.Random(312)
    checks, bits, mut = 0, [0, 0], 0
    for N in range(5, 62, 2):
        reps = 40 if N <= 21 else 12
        for _ in range(reps):
            S = random_graph_seidel(N, rng)
            chi = fmpz_mat(S).charpoly()
            a = plus_I_coeffs(chi)
            assert check_a(a, N) is None, (N, check_a(a, N))
            for k in range(2, (N - 1) // 2 + 1):
                r = rhs_newton(a, N, k)
                if k <= 8:
                    assert rhs_partition(a, N, k) == r
                assert v2_frac(a[2 * k + 1] - r) >= 2 * k + 1
                bits[(a[2 * k + 1] >> (2 * k)) & 1] += 1
                checks += 1
                b = list(a)
                b[2 * k + 1] += 2 ** (2 * k)
                assert check_a(b, N, k) == f"L312 at k={k}", (N, k, check_a(b, N, k))
                mut += 1
        print(f"random graphs of order {N}: {reps} OK", flush=True)
    print(f"(L312) checks on random graphs: {checks}; tested bit 0: {bits[0]}, 1: {bits[1]}; "
          f"{mut} single-bit mutations all detected", flush=True)

    known = [("classical/unitary_q3_n28_d7.seidel", 6), ("classical/unitary_q5_n126_d21.seidel", 3),
             ("known/gsy23_F1_n57_d18.seidel", 0), ("known/gsy23_F2_n57_d18.seidel", 0),
             ("known/gsy23_F3_n57_d18.seidel", 0), ("known/gsy23_F4_n57_d18.seidel", 0),
             ("known/u35_sec2_n72_d19.seidel", 4), ("known/u35_sec1_n90_d20.seidel", 4)]
    tot = 0
    for name, extra in known:
        S0 = read_seidel(CON / name)
        n0 = len(S0)
        subsets = []
        if n0 % 2 == 1:
            subsets.append(list(range(n0)))
        for _ in range(extra):
            for k in (1, 3):
                if (n0 - k) % 2 == 1:
                    subsets.append(sorted(rng.sample(range(n0), n0 - k)))
        for keep in subsets:
            S = [[S0[i][j] for j in keep] for i in keep]
            chi = fmpz_mat(S).charpoly()
            assert check_chi_S(chi) is None, (name, len(keep))
            tot += 1
        print(f"{name}: {len(subsets)} odd-order principal submatrices OK", flush=True)
    print(f"gy312 self-test OK: {checks} random-graph checks, {tot} submatrices of known systems, "
          f"{time.time() - t0:.0f} s")


if __name__ == "__main__":
    main()
