"""Negative tests for level 3 (src/eqlines/triples.py).

For genuine Seidel matrices S:
  * the members are the distinct g_i (chi_{S[i]} = mu g_i) and the pair types the distinct
    psihat_ij = S_ij psi_ij, with psi_ij computed from t_k = (S^k)_ij (exact matrix powers);
  * for sampled triples {i, j, k}: mu3 * Q (Level3.triangle with tau_ijk = S_ij S_jk S_ki) must
    equal the directly computed chi_{S[ijk]}, and the triangle type must be allowed;
  * for sampled edges (i, j): the edge system of (g_i, g_j, psihat_ij) on the true support must be
    feasible (the true counts are a solution), and the true counts are also checked to satisfy
    every row exactly.
Matrices: random Seidel matrices, randomly switched disjoint unions of cliques (multiple
eigenvalues), and vertex deletions from the unitary systems with 28 and 126 lines (data/constructions).
"""

import random
import sys
import time
from pathlib import Path

from flint import fmpz_mat, fmpz_poly

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "verify"))
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.seidel import coeffs_desc, random_seidel  # noqa: E402
from eqlines.triples import Level3, key  # noqa: E402
from jacobi_negative import CON, clique_union_seidel, minor, psi_from_t, read_seidel  # noqa: E402


def analyse(S, label, rng, ntri=40, nedge=6, low=None):
    n = len(S)
    p = fmpz_mat(S).charpoly()
    sp = SpecPoly(p)
    A = fmpz_mat(S)
    d = sp.delta
    powers = [fmpz_mat(n, n, [1 if a == b else 0 for a in range(n) for b in range(n)])]
    for _ in range(d):
        powers.append(powers[-1] * A)
    minc = [int(v) for v in reversed(sp.minp.coeffs())]
    gkey, G, typ = {}, {}, []
    for i in range(n):
        ci = fmpz_mat(minor(S, {i})).charpoly()
        g, r = divmod(ci, sp.mu)
        assert r == 0
        k = key(g)
        if k not in gkey:
            gkey[k] = len(gkey)
            G[gkey[k]] = g
        typ.append(gkey[k])
    uhat = {}
    E = {}
    for i in range(n):
        for j in range(i + 1, n):
            t = [int(powers[k][i, j]) for k in range(d)]
            u = S[i][j] * psi_from_t(minc, t)
            uhat[(i, j)] = uhat[(j, i)] = u
            a, b = min(typ[i], typ[j]), max(typ[i], typ[j])
            E.setdefault((a, b), {})[key(u)] = u
    L = Level3(sp, G, {k: list(v.values()) for k, v in E.items()},
               nonzero_at=[low] if low is not None else [])
    # triangles
    ntri_ok = 0
    for _ in range(ntri):
        i, j, k = rng.sample(range(n), 3)
        tau = S[i][j] * S[j][k] * S[k][i]
        Q = L.triangle(typ[i], typ[j], typ[k], uhat[(i, j)], uhat[(j, k)], uhat[(i, k)], tau)
        assert Q is not None, (label, i, j, k, "true triangle type rejected")
        chi = fmpz_mat(minor(S, {i, j, k})).charpoly()
        assert L.mu3 * Q == chi, (label, i, j, k, "triple Jacobi identity mismatch")
        ntri_ok += 1
    # edges
    counts = {}
    for i in range(n):
        counts[typ[i]] = counts.get(typ[i], 0) + 1
    support = sorted(counts)
    nedge_ok = 0
    for _ in range(nedge):
        i, j = rng.sample(range(n), 2)
        a, b, u = typ[i], typ[j], uhat[(i, j)]
        built = L.edge_system(a, b, u, support=support)
        rows, rhs, names, tris = built
        # the true solution
        tidx = {}
        for t, (h, u1, u2, tau, _Q) in enumerate(tris):
            tidx[(h, key(u1), key(u2), tau)] = t
        x = [0] * len(names)
        col = {nm: c for c, nm in enumerate(names)}
        for h in support:
            if ("n", h) in col:
                x[col[("n", h)]] = counts[h] - 1
        for k in range(n):
            if k in (i, j):
                continue
            tau = S[i][j] * S[j][k] * S[k][i]
            tk = (typ[k], key(uhat[(i, k)]), key(uhat[(j, k)]), tau)
            assert tk in tidx, (label, i, j, k, "true triangle missing from the edge system")
            x[col[("c", tidx[tk])]] += 1
        for end, v in (("i", i), ("j", j)):
            f = typ[v]
            for k in range(n):
                if k == v:
                    continue
                h = typ[k]
                ws = [key(w) for w in L.pairs(f, h)]
                x[col[("m", end, h, ws.index(key(uhat[(v, k)])))]] += 1
        for r, (row, bb) in enumerate(zip(rows, rhs)):
            lhs = sum(c * xx for c, xx in zip(row, x) if c)
            assert lhs == bb, (label, i, j, "row", r, "true counts violate a row", lhs, bb)
        st, _ = L.solve_edge(a, b, u, support=support)
        assert st != "certified", (label, i, j, "edge system certified infeasible for a true edge")
        nedge_ok += 1
    return ntri_ok, nedge_ok, len(G), sum(len(v) for v in E.values())


def main():
    t0 = time.time()
    rng = random.Random(2026)
    tt = te = 0
    for n in range(7, 12):
        for rep in range(3):
            S = random_seidel(n, rng, rng.choice([0.3, 0.5, 0.7]))
            a, b, ng, ne = analyse(S, f"random n={n}", rng, ntri=25, nedge=3)
            tt += a
            te += b
        print(f"random order {n}: OK", flush=True)
    for sizes, dels in [([2, 2, 2, 3, 3, 3, 4, 4], 0), ([2, 2, 3, 3, 3, 4, 4, 5, 5], 0),
                        ([1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4], 0), ([2, 2, 2, 3, 3, 3, 4, 4, 4], 1),
                        ([3, 3, 3, 3, 5, 5, 5], 0), ([2, 2, 2, 2, 3, 3, 3, 3, 6, 6], 2),
                        ([1, 1, 1, 1, 2, 2, 2, 4, 4, 4], 1)]:
        S = clique_union_seidel(sizes, rng)
        for _ in range(dels):
            S = minor(S, {rng.randrange(len(S))})
        a, b, ng, ne = analyse(S, f"clique union {sizes}", rng, ntri=40, nedge=5)
        tt += a
        te += b
        print(f"clique union {sizes} minus {dels}: order {len(S)}, {ng} members, {ne} pair "
              f"types, {a} triangles and {b} edges OK", flush=True)
    for name, low, ks, reps in [("unitary_q3_n28_d7.seidel", -3, [3, 4, 5, 6], 2),
                                ("unitary_q5_n126_d21.seidel", -5, [3, 5], 1)]:
        S0 = read_seidel(CON / name)
        n0 = len(S0)
        for k in ks:
            for rep in range(reps):
                keep = sorted(rng.sample(range(n0), n0 - k))
                S = [[S0[i][j] for j in keep] for i in keep]
                a, b, ng, ne = analyse(S, f"{name} minus {k}", rng, ntri=40, nedge=4, low=low)
                tt += a
                te += b
                print(f"{name} minus {k} (rep {rep}): order {len(S)}, {ng} members, {ne} pair "
                      f"types, {a} triangles and {b} edges OK", flush=True)
    print(f"triples negative tests OK: {tt} triangles, {te} edges, {time.time() - t0:.0f} s")


if __name__ == "__main__":
    main()
