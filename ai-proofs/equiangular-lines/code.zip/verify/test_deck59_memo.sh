#!/bin/bash
# Re-runs verify/deck59.gp (or $GPFILE) on leaves S/I and compares every output line, except the
# timing field, with the stored runs/p2_59/l1/s<S>/<I>.txt.  Used on 6 leaves whose stored outputs
# came from the version before the roots of D_(k-1) were passed down the stack (deployed 23:58 UTC
# on 2026-10-23; log logs/validation/deck59_memo_vs_old.log).
# Usage: verify/test_deck59_memo.sh S/I [S/I ...]
cd "$(dirname "$0")/.."
GPFILE=${GPFILE:-verify/deck59.gp}
T=$(mktemp -d)
for spec in "$@"; do
  s=${spec%/*}; i=${spec#*/}
  python3 verify/p2_export_leaf.py $s $i $T/cert_${s}_$i.gp
  IN=runs/enum59_gp/gp_s${s}of16.txt CERT=$T/cert_${s}_$i.gp OUT=$T/${s}_$i.txt \
    FROM=$i TO=$i gp -q -f $GPFILE < /dev/null > /dev/null 2>> $T/err.log
  python3 - $s $i $T << 'EOF'
import re, sys
s, i, T = sys.argv[1:4]
strip = lambda L: [re.sub(r" ms \d+$", "", l) for l in L]
old = open(f"runs/p2_59/l1/s{s}/{i}.txt").read().splitlines()
new = open(f"{T}/{s}_{i}.txt").read().splitlines()
ms = lambda L: re.search(r" ms (\d+)", L[0]).group(1)
print(f"s{s}/{i} same={strip(old) == strip(new)} lines={len(new)} head={new[0][:60]} "
      f"ms_old={ms(old)} ms_new={ms(new)}", flush=True)
EOF
done
rm -rf $T
