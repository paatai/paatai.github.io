"""Resolve listed leaves of a c35_cert.py run with a different branching rule.

Enumerates the leaves exactly as c35_cert.run_all and c35_cert_resume.py do (same module, same
options), and searches only the leaves given by --leaves.  Branching rule "t1": among the
cardinality groups that still need a node, take a smallest one in the blocks given by --blocks
(default T1b and T1c), and only when there is none a smallest one over all blocks; otherwise the
search is c35_cert.Search's (same propagation, LPs, certificates, child order).  Rule "default"
is c35_cert's own choice.

Writes one record per listed leaf in c35_cert's certificate format (same key: instance head,
path, references, leaf index, unit), so that c35_cert_resume.py --from copies the resolved ones
into a complete certificate file.  Any branching group gives a valid tree for --check (child i:
opts[:i] -> 0, opts[i] -> 1; last child: all opts -> 0), so this program is not part of the
trusted base: its trees are verified by the unchanged `c35_cert.py --check`.

Usage: python3 c35_cert_hard.py CASE SUPPORT [c35_cert run options] --leaves N [N ...]
                                --out F --log F [--rule t1|default] [--blocks 1,2] [--budget B]
"""
import argparse
import gzip
import hashlib
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(100000)
import c35_cert as C  # noqa: E402

with open(os.path.abspath(__file__), "rb") as _f:
    HARD_HASH = hashlib.sha256(_f.read()).hexdigest()[:16]


class SearchPref(C.Search):
    def __init__(self, leaf, budget, blocks, progress=None):
        super().__init__(leaf, budget=budget)
        self.blocks = set(blocks)
        self.progress = progress

    def groups(self, alive, f1, f1m):
        L = self.leaf
        out = []
        for lab, bi, sv, req in list(self.labels) + [
                (L.Sm[f], bi, sv, int(L.req[f, bi, si]))
                for f in f1 for bi in range(3) for si, sv in ((0, -1), (1, 1))]:
            g = alive & (L.typ == bi) & (lab == sv)
            need = req - int((g & f1m).sum())
            opts = np.nonzero(g & ~f1m)[0]
            if need >= 1 and len(opts):
                out.append((bi, opts))
        return out

    def run(self, fix0=(), fix1=(), depth=0):
        if self.rows0 is None:
            return {"C": "block sum not integral"}, True
        alive, f1, why = self.state(fix0, fix1)
        if alive is None:
            return {"C": why}, True
        if self.lps >= self.budget:
            return {"U": 1}, False
        rows, lo, hi = self.lp_data(alive, f1)
        self.lps += 1
        if self.progress is not None and self.lps % 500 == 0:
            self.progress(self.lps, depth)
        st, val = C.certificate(rows, self.leaf.n, lo, hi)
        if st == "INFEASIBLE":
            return {"L": sorted(val.items())}, True
        if st == "UNKNOWN":
            return {"U": "lp"}, False
        x = val
        L = self.leaf
        f1m = np.zeros(L.n, dtype=bool)
        f1m[f1] = True
        cand = self.groups(alive, f1, f1m)
        pool = [o for bi, o in cand if bi in self.blocks] or [o for _, o in cand]
        best = None
        for o in pool:
            if best is None or len(o) < len(best):
                best = o
        if best is None:
            frac = [(abs(x[j] - 0.5), j) for j in np.nonzero(alive & ~f1m)[0]]
            if not frac:
                return {"U": "integral"}, False
            best = np.array([min(frac)[1]])
        opts = sorted(best.tolist(), key=lambda j: -x[j])
        ch = []
        ok = True
        for i in range(len(opts) + 1):
            nf0 = tuple(fix0) + tuple(opts[:i])
            nf1 = tuple(fix1) + ((opts[i],) if i < len(opts) else ())
            sub, good = self.run(nf0, nf1, depth + 1)
            ch.append(sub)
            if not good:
                ok = False
                break
        return {"B": [int(o) for o in opts], "ch": ch}, ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=["74", "94"])
    ap.add_argument("support", choices=["015", "0125", "012"])
    ap.add_argument("--struct")
    ap.add_argument("--maxdimF", type=int)
    ap.add_argument("--budget", type=int, default=100000)
    ap.add_argument("--out", required=True)
    ap.add_argument("--log", required=True)
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--shard-level", type=int)
    ap.add_argument("--no-orbits", action="store_true")
    ap.add_argument("--full-refs", action="store_true")
    ap.add_argument("--leaves", type=int, nargs="+", required=True)
    ap.add_argument("--rule", choices=["t1", "default"], default="t1")
    ap.add_argument("--blocks", default="1,2")
    args = ap.parse_args()

    targets = sorted(set(args.leaves))
    blocks = [int(b) for b in args.blocks.split(",")] if args.rule == "t1" else [0, 1, 2]
    model = C.Model(args.case, args.support)
    only = args.struct.split(",") if args.struct else None
    shard, nshard = (int(x) for x in args.shard.split("/"))
    t_start = time.time()
    logf = open(args.log, "a")

    def log(d):
        logf.write(json.dumps(d) + "\n")
        logf.flush()

    certs = gzip.open(args.out, "wt")
    stats = {}
    li = 0
    done = 0
    sh = None
    if args.shard_level is not None:
        sh = dict(level=args.shard_level, i=shard, n=nshard, count=0, cur=None)
    for inst in C.instances(model, lambda d: None, only=only, max_dimF=args.maxdimF,
                            orbits=not args.no_orbits):
        if done == len(targets):
            break
        head = inst.head()
        for refs, filters, path in C.leaves(inst, dict(orbits=not args.no_orbits,
                                                       full_refs=args.full_refs, shard_level=sh),
                                            lambda d: None):
            li += 1
            if sh is None and (li - 1) % nshard != shard:
                continue
            if li - 1 not in targets:
                continue
            t0 = time.time()
            key = dict(head, path=path, refs=[r.to_json() for r in refs], leaf=li - 1)
            if sh is not None:
                key["unit"] = sh["cur"]
            leaf = C.Leaf(inst, refs, filters)

            def progress(lps, depth, _li=li - 1, _t0=t0):
                log(dict(progress=_li, lps=lps, depth=depth, time=round(time.time() - _t0, 1)))

            srch = (SearchPref(leaf, args.budget, blocks, progress) if args.rule == "t1"
                    else SearchPref(leaf, args.budget, [0, 1, 2], progress))
            tree, ok = srch.run()
            status = "INFEASIBLE" if ok else "UNRESOLVED"
            stats[status] = stats.get(status, 0) + 1
            info = dict(key, refs=[(r.kind, r.typ, r.name) for r in refs], nodes=leaf.n,
                        lps=srch.lps, status=status, time=round(time.time() - t0, 2),
                        tree=C.tree_size(tree), rule=args.rule, blocks=blocks)
            log(info)
            certs.write(json.dumps(dict(key, tree=tree, resolved=ok)) + "\n")
            certs.flush()
            done += 1
            if done == len(targets):
                break
    certs.close()
    missing = sorted(set(targets) - set(range(li)))
    log(dict(summary=stats, targets=len(targets), found=done, missing=missing, leaves_seen=li,
             shard=args.shard, time=round(time.time() - t_start, 1), code=C.CODE_HASH,
             hard_code=HARD_HASH, args=vars(args)))


if __name__ == "__main__":
    main()
