"""Transcribe program 1's level-1 Farkas vectors into GP syntax for verify/deck59.gp (data only).

Usage: python3 p2_export.py SHARD
  reads runs/enum59_gp/gp_s<SHARD>of16.jsonl (for the number of leaves) and
  data/level1_59/s<SHARD>/<idx>.json; writes runs/p2_59/certA_s<SHARD>.gp.
"""

import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    s = int(sys.argv[1])
    with open(os.path.join(ROOT, "runs", "enum59_gp", f"gp_s{s}of16.jsonl")) as fh:
        n = sum(1 for line in fh if line.startswith('{"psi"'))
    lines = [f"CERTA = vector({n}, i, 0);"]
    d = os.path.join(ROOT, "data", "level1_59", f"s{s}")
    for f in sorted(os.listdir(d)) if os.path.isdir(d) else []:
        if not f.endswith(".json"):
            continue
        with open(os.path.join(d, f)) as fh:
            r = json.load(fh)
        y = r.get("farkas_A")
        if y is not None:
            lines.append(f"CERTA[{r['idx'] + 1}] = [{', '.join(str(int(v)) for v in y)}];")
    out = os.path.join(ROOT, "runs", "p2_59")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, f"certA_s{s}.gp"), "w") as fh:
        fh.write("\n".join(lines) + "\n")
    print(f"shard {s}: {n} leaves, {len(lines) - 1} certificates")


if __name__ == "__main__":
    main()
