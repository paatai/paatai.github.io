"""Numerical cross-check of the exact pair rules in c35gen (dim F <= 1) and c35ref (dim F = 2).

For random samples of nodes we build the actual vectors z = omega + phi in R^nc + R^dimF from the
node data (walk heights, F-part components) and compare the true inner product with the
relation the exact integer rule assigns.  Every pair must satisfy: rule says a  <=>  |z.z' - a| < 1e-9
(for a in the allowed set of the pair's types).
"""
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from c35gen import build as build_gen  # noqa: E402
from c35gen import walk_data  # noqa: E402
from c35ref import build_nodes, rotation_orbits  # noqa: E402

rng = np.random.default_rng(1)


def check(Z, t0, rel, sample=3000):
    n = len(Z)
    bad = 0
    tot = 0
    for _ in range(sample):
        i, j = rng.integers(0, n, 2)
        if i == j:
            continue
        ip = float(Z[i] @ Z[j])
        if t0[i] and t0[j]:
            allowed = (1, -3)
        elif t0[i] or t0[j]:
            allowed = (2, -2)
        else:
            allowed = (0, -4, 2, -2)
        for a in allowed:
            tot += 1
            if bool(rel[a][i, j]) != (abs(ip - a) < 1e-9):
                bad += 1
    return bad, tot


def gen_vectors(g):
    D = g["D"]
    om = g["om"].astype(float) / D
    R = g["R"].astype(float) / D
    phi = g["eps"] * np.sqrt(np.maximum(R, 0))
    Z = np.hstack([om, phi[:, None]]) if g["dimF"] == 1 else om
    N = g["Ns"]
    assert np.allclose((Z * Z).sum(1), N)
    return Z


def ref_vectors(g):
    D, R0 = g["D"], g["R0"]
    om = g["om"].astype(float) / D
    alpha = g["Ct"].astype(float) / D / np.sqrt(R0 / D)
    beta = np.sqrt(np.maximum(g["B"].astype(float), 0) / (D * D * R0))
    Z = np.hstack([om, alpha[:, None], (g["eps"] * beta)[:, None]])
    assert np.allclose((Z * Z).sum(1), g["Ns"]), np.abs((Z * Z).sum(1) - g["Ns"]).max()
    return Z


def main():
    tot_bad = 0
    for case, part in [("74_19", (12, 4)), ("74_19", (8, 8)), ("94_20", (8, 4, 4, 4))]:
        g = build_gen(case, part)
        Z = gen_vectors(g)
        bad, tot = check(Z, g["t0"], g["rel"])
        print(case, part, "c35gen pairs checked", tot, "mismatches", bad)
        tot_bad += bad
    for part in [(8, 4, 4), (6, 6, 4)]:
        D, om, G, St = walk_data(part)
        W = np.diag(G)
        for caseB, ref_N in ((False, 9), (True, 8)):
            reps = rotation_orbits(part, St, np.nonzero(W < ref_N * D)[0])
            for ref in reps[:3]:
                g = build_nodes("74_19", part, int(ref), ref_N, caseB)
                Z = ref_vectors(g)
                # the reference is the last node: its F-part must be (sqrt r0, 0)
                assert abs(Z[-1, -1]) < 1e-12
                bad, tot = check(Z, g["t0"], g["rel"])
                print("74_19", part, "ref", int(ref), "caseB" if caseB else "caseA",
                      "c35ref pairs checked", tot, "mismatches", bad)
                tot_bad += bad
    print("TOTAL MISMATCHES", tot_bad)
    sys.exit(1 if tot_bad else 0)


if __name__ == "__main__":
    main()
