"""Negative tests for the Seidel-compatibility test (src/eqlines/compat.py).

For genuine Seidel matrices S, the deck members g_i = chi_{S[i]} / mu of any two
vertices must be compatible, and a member occurring at two vertices must be
self-compatible.  A single failure would mean the test is unsound.

Matrices: random Seidel matrices of orders 6..13 (both parities; generic spectra, all
eigenvalues simple), and vertex deletions from the unitary two-graph systems with 28 and
126 lines (files in data/constructions), which have multiple eigenvalues and a few simple ones.
"""

import random
import sys
import time
from pathlib import Path

from flint import fmpz_mat

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from eqlines.compat import Compat  # noqa: E402
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.seidel import coeffs_desc, random_seidel  # noqa: E402

CON = Path(__file__).resolve().parents[1] / "data" / "constructions" / "classical"


def read_seidel(path):
    rows = [ln.strip() for ln in path.read_text().splitlines() if ln.strip() and not ln.startswith("#")]
    n = int(rows[0])
    return [[{"0": 0, "+": 1, "-": -1}[ch] for ch in r] for r in rows[1:1 + n]]


def principal(S, i):
    return [[S[a][b] for b in range(len(S)) if b != i] for a in range(len(S)) if a != i]


def check_matrix(S, label, vertices=None):
    n = len(S)
    p = fmpz_mat(S).charpoly()
    sp = SpecPoly(p)
    vs = list(range(n)) if vertices is None else vertices
    members, where = [], {}
    gi = {}
    for i in vs:
        ci = fmpz_mat(principal(S, i)).charpoly()
        g, r = divmod(ci, sp.mu)
        assert r == 0
        key = tuple(coeffs_desc(g))
        if key not in where:
            where[key] = len(members)
            members.append(list(key))
        gi[i] = where[key]
    cp = Compat(sp, members)
    assert cp.min_parity_ok(), label
    pairs = 0
    for a in range(len(vs)):
        for b in range(a + 1, len(vs)):
            assert cp.compatible(gi[vs[a]], gi[vs[b]]), (label, vs[a], vs[b])
            pairs += 1
    simple = len(cp.simple)
    return pairs, simple, len(members)


def main():
    t0 = time.time()
    rng = random.Random(2026)
    tot = 0
    for n in range(6, 14):
        for rep in range(12):
            S = random_seidel(n, rng, rng.choice([0.3, 0.5, 0.7]))
            pairs, simple, m = check_matrix(S, f"random n={n} rep={rep}")
            tot += pairs
        print(f"random Seidel matrices of order {n}: 12 matrices OK", flush=True)
    for name, ks, reps in [("unitary_q3_n28_d7.seidel", [1, 2, 3, 4, 5, 6, 8], 4),
                           ("unitary_q5_n126_d21.seidel", [1, 2, 3, 4, 6], 2)]:
        S0 = read_seidel(CON / name)
        n0 = len(S0)
        for k in ks:
            for rep in range(reps):
                keep = sorted(rng.sample(range(n0), n0 - k))
                S = [[S0[i][j] for j in keep] for i in keep]
                verts = None if len(S) <= 40 else sorted(rng.sample(range(len(S)), 24))
                pairs, simple, m = check_matrix(S, f"{name} minus {k} rep {rep}", verts)
                tot += pairs
                print(f"{name} minus {k} vertices (rep {rep}): order {len(S)}, {simple} simple "
                      f"eigenvalues, {m} distinct deck members, {pairs} vertex pairs OK", flush=True)
    print(f"compat negative tests OK: {tot} vertex pairs, {time.time() - t0:.0f} s")


if __name__ == "__main__":
    main()
