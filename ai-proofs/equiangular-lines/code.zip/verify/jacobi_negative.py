"""Negative tests for the Jacobi pair enumeration (src/eqlines/jacobi.py).

For genuine Seidel matrices S and vertex pairs (i, j):
  * psi_ij is computed from t_k = (S^k)_{ij} (exact integer matrix powers);
  * the identity chi_{S[ij]} = mu2 (f g - psi^2) / Sim is checked against the directly
    computed characteristic polynomial of S[ij];
  * PairSpace.pair_polys(f, g, S_ij) must contain psi_ij.
Matrices: random Seidel matrices of orders 7..12 and vertex deletions from the unitary
systems with 28 and 126 lines.
"""

import random
import sys
import time
from pathlib import Path

from flint import fmpz_mat, fmpz_poly

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.jacobi import PairSpace  # noqa: E402
from eqlines.seidel import random_seidel  # noqa: E402

CON = Path("/cursor/stores/bot/eqlines/EQ-CON/constructions/classical")


def read_seidel(path):
    rows = [ln.strip() for ln in path.read_text().splitlines() if ln.strip() and not ln.startswith("#")]
    n = int(rows[0])
    return [[{"0": 0, "+": 1, "-": -1}[ch] for ch in r] for r in rows[1:1 + n]]


def minor(S, drop):
    keep = [k for k in range(len(S)) if k not in drop]
    return [[S[a][b] for b in keep] for a in keep]


def psi_from_t(minc, t):
    d = len(minc) - 1
    c = []
    for rr in range(d):
        c.append(sum(minc[a] * t[rr - a] for a in range(rr + 1)))
    return fmpz_poly(list(reversed(c)))


def check(S, label, pairs, low=None):
    n = len(S)
    p = fmpz_mat(S).charpoly()
    sp = SpecPoly(p)
    ps = PairSpace(sp, nonzero_at=[low] if low is not None else None)
    A = fmpz_mat(S)
    d = sp.delta
    powers = [fmpz_mat(n, n, [1 if a == b else 0 for a in range(n) for b in range(n)])]
    for _ in range(d):
        powers.append(powers[-1] * A)
    minc = [int(v) for v in reversed(sp.minp.coeffs())]
    gs = {}
    for i in set(v for pr in pairs for v in pr):
        ci = fmpz_mat(minor(S, {i})).charpoly()
        g, r = divmod(ci, sp.mu)
        assert r == 0
        gs[i] = g
    for i, j in pairs:
        t = [int(powers[k][i, j]) for k in range(d)]
        psi = psi_from_t(minc, t)
        f, g = gs[i], gs[j]
        num = f * g - psi * psi
        P, r = divmod(num, ps.sim)
        assert r == 0, (label, i, j, "Sim does not divide f g - psi^2")
        chi_ij = fmpz_mat(minor(S, {i, j})).charpoly()
        assert ps.mu2 * P == chi_ij, (label, i, j, "Jacobi identity mismatch")
        found = [q for q, _P in ps.pair_polys(f, g, S[i][j])]
        assert psi in found, (label, i, j, "true psi not enumerated", len(found))
    return len(pairs), ps.s, ps.D


def main():
    t0 = time.time()
    rng = random.Random(77)
    tot = 0
    for n in range(7, 13):
        for rep in range(6):
            S = random_seidel(n, rng, rng.choice([0.3, 0.5, 0.7]))
            pairs = [(i, j) for i in range(n) for j in range(n) if i != j][:20]
            k, s, D = check(S, f"random n={n}", pairs)
            tot += k
        print(f"random order {n}: OK", flush=True)
    for name, low, ks, reps in [("unitary_q3_n28_d7.seidel", -3, [2, 3, 4, 5, 6, 8], 3),
                                ("unitary_q5_n126_d21.seidel", -5, [2, 3, 4, 6], 2)]:
        S0 = read_seidel(CON / name)
        n0 = len(S0)
        for k in ks:
            for rep in range(reps):
                keep = sorted(rng.sample(range(n0), n0 - k))
                S = [[S0[i][j] for j in keep] for i in keep]
                n = len(S)
                verts = rng.sample(range(n), 6)
                pairs = [(i, j) for i in verts for j in verts if i != j]
                cnt, s, D = check(S, f"{name} minus {k}", pairs, low=low)
                tot += cnt
                print(f"{name} minus {k} (rep {rep}): order {n}, deg Sim {s}, D {D}, "
                      f"{cnt} ordered pairs OK", flush=True)
    for sizes, dels in [([2, 2, 2, 3, 3, 3, 4, 4], 0), ([2, 2, 3, 3, 3, 4, 4, 5, 5], 0),
                        ([1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4], 0), ([2, 2, 2, 3, 3, 3, 4, 4, 4], 1),
                        ([1, 1, 2, 2, 3, 3, 4, 4, 5, 5], 0), ([3, 3, 3, 3, 5, 5, 5], 0),
                        ([2, 2, 2, 2, 3, 3, 3, 3, 6, 6], 2), ([1, 1, 1, 1, 2, 2, 2, 4, 4, 4], 1),
                        ([1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4], 0),
                        ([1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5], 0),
                        ([2, 2, 2, 3, 3, 3, 4, 4, 4, 5, 5, 5], 0)]:
        S = clique_union_seidel(sizes, rng)
        for _ in range(dels):
            v = rng.randrange(len(S))
            S = minor(S, {v})
        n = len(S)
        verts = rng.sample(range(n), 7)
        pairs = [(i, j) for i in verts for j in verts if i != j]
        cnt, s, D = check(S, f"clique union {sizes}", pairs)
        tot += cnt
        print(f"clique union {sizes} minus {dels}: order {n}, deg Sim {s}, D {D}, {cnt} ordered pairs OK",
              flush=True)
    print(f"jacobi negative tests OK: {tot} ordered pairs, {time.time() - t0:.0f} s")


def clique_union_seidel(sizes, rng):
    """Seidel matrix of a disjoint union of cliques, randomly switched."""
    n = sum(sizes)
    block = []
    for b, sz in enumerate(sizes):
        block += [b] * sz
    S = [[0 if a == c else (-1 if block[a] == block[c] else 1) for c in range(n)] for a in range(n)]
    sw = [rng.choice([1, -1]) for _ in range(n)]
    return [[sw[a] * S[a][c] * sw[c] for c in range(n)] for a in range(n)]


if __name__ == "__main__":
    main()
