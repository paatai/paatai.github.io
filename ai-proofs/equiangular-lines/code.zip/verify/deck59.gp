\\ Second program for level 1 of 59 equiangular lines in R^18 (PARI/GP): decks and Farkas vectors.
\\ Written without the code of src/ (only the mathematical statements).
\\
\\ For a leaf psi of verify/enum59.gp, chi = chi_S = (x+5)^41 (x-11) psi(x-11) (n = 59), factored over Z.
\\ Min = product of the distinct irreducible factors, mu = chi/Min, delta = deg Min, t = delta - 1,
\\ lambda_1 < ... < lambda_delta the distinct eigenvalues.  For a vertex i, chi_{S[i]} = mu g with g
\\ monic of degree t (Cauchy interlacing: every eigenvalue of multiplicity m stays with
\\ multiplicity >= m - 1), and:
\\  (a) traces: S[i] is a Seidel matrix of order 58, so chi_{S[i]} = x^58 + 0 x^57 - C(58,2) x^56 + ...;
\\      with mu = x^m + m1 x^(m-1) + m2 x^(m-2) + ... this fixes b1 = -m1, b2 = -C(58,2) - m2 + m1^2;
\\  (b) interlacing: w_j = g(lambda_j) / Min'(lambda_j) >= 0 for every j (then g = sum_j w_j Min/(x -
\\      lambda_j), whose roots interlace the lambda_j);
\\  (c) chi_{S[i]}(x - 1) = chi_{S[i]+I} is type 2 (order 58 even, [GSY21, Lemma 2.7]): 2^k divides its
\\      x^(58-k) coefficient.  With f(x) type 2 <=> f(2y)/2^deg f in Z[y], Gauss's lemma over Z_(2)
\\      gives: mu(x-1) and g(x-1) are type 2 (else the deck is empty);
\\  (d) g(-5) != 0: otherwise -5 has multiplicity 41 in chi_{S[i]}, i.e. 58 lines in R^17, but
\\      N(17) = 48 [GSY23].
\\ Enumeration of g = sum_j b_j x^(t-j) from the top: D_k = g^(t-k) has degree k and depends on b_0..b_k
\\ only, D_k' = D_(k-1), and b_k enters only the constant term, with factor (t-k)!.  The roots of
\\ g^(m) interlace those of g (Rolle), so the i-th root of D_k lies in [lambda_i, lambda_(i+t-k+1)].
\\ Necessary on b_k, given the roots rho of D_(k-1): (-1)^(k-j) D_k(rho_j) >= 0 (Rolle), and for a
\\ window end a strictly between rho_(i-1) and rho_i (where D_k is monotone with the root z_i):
\\ z_i >= a iff (-1)^(k-i) D_k(a) <= 0, z_i <= a iff (-1)^(k-i) D_k(a) >= 0; and the congruence (c)
\\ for the x^(t-k) coefficient of g(x - 1).  These bounds are evaluated in floating point
\\ (realprecision 100) at polrootsreal's roots and widened by an explicit Lipschitz margin; a node is
\\ dropped only if D_k does not have k real roots (polrootsreal, exact isolation) or a root lies
\\ outside its window by more than 10^-60 (relative).
\\ Leaves are decided exactly: the sign of g at an irrational lambda_j is read off a rational
\\ isolating interval of lambda_j on which g mod q has no root (polsturm, bisection).
\\
\\ Level-1 certificate: an integer Y with Y.g >= 0 for every deck member and Y.h < 0, where
\\ h = chi'/mu = sum_i g_i (descending coefficients), proves that sum_g n_g g = h has no solution
\\ with n >= 0.
\\
\\ Usage: IN=leaves.txt CERT=certs.gp OUT=out.txt gp -q -f verify/deck59.gp
\\   IN: lines [c_0, ..., c_17] (psi, descending; enum59.gp's output; other lines ignored);
\\   CERT: defines CERTA, a vector with CERTA[idx + 1] = Y or 0 (idx 0-based leaf number).
\\   OUT: per leaf [idx, delta, #deck, verdict] then the deck members, one per line.
\\   Optional FROM/TO (0-based, inclusive) restrict the leaves.

default(realprecision, 100);
default(parisizemax, 2^31);
NN = 59;

\\ exact sign of r at the root of the irreducible q in the rational interval [lo, hi]
xsign(r, q, lo, hi) = {
  my(m, s);
  r = r % q;
  if(r == 0, return(0));
  if(poldegree(q) == 1, return(sign(polcoef(r, 0))));
  while(polsturm(r, [lo, hi]) > 0,
    m = (lo + hi) / 2; s = sign(subst(q, x, m));
    if(s == 0, error("rational root of an irreducible factor"));
    if(sign(subst(q, x, lo)) == s, lo = m, hi = m));
  sign(subst(r, x, lo));
}

\\ the distinct eigenvalues: [q, lo, hi, float], sorted, with verified disjoint isolating intervals
eigs(Min) = {
  my(F = factor(Min)[, 1], L = List(), V);
  for(i = 1, #F,
    my(q = F[i], rts);
    if(poldegree(q) == 1,
      my(r = -polcoef(q, 0) / polcoef(q, 1)); listput(L, [q, r, r, r * 1.]),
      rts = polrootsreal(q);
      if(#rts != poldegree(q), error("non-real eigenvalue"));
      for(j = 1, #rts,
        my(lo = floor(rts[j] * 2^150) / 2^150 - 1 / 2^140, hi = ceil(rts[j] * 2^150) / 2^150 + 1 / 2^140);
        if(polsturm(q, [lo, hi]) != 1, error("isolation failed"));
        listput(L, [q, lo, hi, rts[j]]))));
  V = vecsort(Vec(L), 4);
  for(j = 1, #V - 1, if(!(V[j][3] < V[j + 1][2]), error("intervals overlap")));
  V;
}

\\ setup for psi; returns [chi, Min, mu, h, E, b1, b2, mushift_ok]
setup(psi) = {
  my(chi, F, Min, mu, h, E, m1, m2, b1, b2);
  chi = (x + 5)^41 * (x - 11) * subst(Pol(psi), x, x - 11);
  if(poldegree(chi) != NN, error("degree"));
  F = factor(chi);
  Min = prod(i = 1, #F[, 1], F[i, 1]);
  mu = chi / Min;
  h = deriv(chi) / mu;
  if(type(h) != "t_POL" || denominator(content(h)) != 1, error("h"));
  E = eigs(Min);
  m1 = polcoef(mu, poldegree(mu) - 1); m2 = polcoef(mu, poldegree(mu) - 2);
  b1 = -m1; b2 = -binomial(NN - 1, 2) - m2 + m1^2;
  [chi, Min, mu, h, E, b1, b2, type2(subst(mu, x, x - 1))];
}

type2(f) = my(d = poldegree(f)); for(k = 0, d, if(polcoef(f, d - k) % 2^k, return(0))); 1;

\\ congruence class of b_k (mod 2^k) from (c), given b_0..b_(k-1) in c (c[j+1] = b_j)
cong(c, k, t) = -sum(j = 0, k - 1, c[j + 1] * binomial(t - j, k - j) * (-1)^(k - j)) % 2^k;

\\ is the deck member g allowed (exact)?
leafok(g, E) = {
  my(d = #E);
  for(j = 1, d,
    my(s = xsign(g, E[j][1], E[j][2], E[j][3]), want = (-1)^(d - j));
    if(s != 0 && s != want, return(0)));
  subst(g, x, -5) != 0;
}

\\ [v, mg]: v = -P(pt)/q at a float point pt (error <= (|pt| + 1) 10^-90), mg an explicit bound on
\\ the error of v (Lipschitz: Pa = (P with |coefficients|)', plus rounding)
bound(P, Pa, pt, q) = {
  my(v = -subst(P, x, pt), e = (abs(pt) + 1) * 10.^-90);
  [v / q, (subst(Pa, x, abs(pt) + e) * e + abs(v) * 10.^-95 + 10.^-90) / q];
}

near(a, b) = abs(a - b) <= 10.^-60 * (1 + abs(a) + abs(b));

\\ depth-first enumeration; returns [members (descending coefficient vectors, sorted), nodes]
deck(S) = {
  my(E = S[5], d = #E, t = d - 1, lam, out = List(), c0, stack, nodes = 0);
  if(!S[8], return([[], 0]));
  lam = vector(d, j, E[j][4]);
  if(t == 0, return([[[1]], 1]));
  c0 = if(t == 1, [1, S[6]], [1, S[6], S[7]]);
  for(k = 1, #c0 - 1, if((c0[k + 1] - cong(c0, k, t)) % 2^k, return([[], 0])));
  \\ stack entries [c, rho]: rho = sorted roots of D_(#c - 1), found when the parent accepted c
  \\ (0 for the start), since deriv(Pk) below is exactly the parent's D_(k-1) = Pk + b q
  stack = List([[c0, 0]]);
  while(#stack,
    my(c = stack[#stack][1], k, Pk, Pa, q, rho = stack[#stack][2], lo = -oo, hi = +oo, md, r0, top, bot);
    listpop(stack);
    k = #c;
    if(k == t + 1,
      if(leafok(Pol(c), E), listput(out, c));
      next);
    nodes++;
    \\ D_k = Pk + b_k (t - k)!, Pk = (b_0 x^t + ... + b_(k-1) x^(t-k+1))^(t-k)
    Pk = sum(j = 1, k, c[j] * x^(t - j + 1)); for(s = 1, t - k, Pk = deriv(Pk));
    Pa = deriv(Pol(apply(abs, Vec(Pk))));
    q = (t - k)!;
    if(rho === 0, rho = vecsort(polrootsreal(deriv(Pk))));
    if(#rho != k - 1, next);
    for(j = 1, k - 1,
      my(B = bound(Pk, Pa, rho[j], q));
      if((k - j) % 2 == 0, lo = max(lo, B[1] - B[2]), hi = min(hi, B[1] + B[2])));
    for(i = 1, k,
      my(L = lam[i], U = lam[i + t - k + 1], left = if(i == 1, -oo, rho[i - 1]), right = if(i == k, +oo, rho[i]));
      if((i == 1 || (L > left && !near(L, left))) && (i == k || (L < right && !near(L, right))),
        my(B = bound(Pk, Pa, L, q));
        if((k - i) % 2 == 0, hi = min(hi, B[1] + B[2]), lo = max(lo, B[1] - B[2])));
      if((i == 1 || (U > left && !near(U, left))) && (i == k || (U < right && !near(U, right))),
        my(B = bound(Pk, Pa, U, q));
        if((k - i) % 2 == 0, lo = max(lo, B[1] - B[2]), hi = min(hi, B[1] + B[2]))));
    if(lo == -oo || hi == +oo, error(Str("unbounded b_", k, " at ", c)));
    md = 2^k; r0 = cong(c, k, t);
    bot = ceil(lo); top = floor(hi);
    bot = bot + ((r0 - bot) % md);
    forstep(b = bot, top, md,
      my(rts = polrootsreal(Pk + b * q), ok = (#rts == k));
      if(ok, rts = vecsort(rts);
        for(i = 1, k,
          if((rts[i] < lam[i] && !near(rts[i], lam[i])) || (rts[i] > lam[i + t - k + 1] && !near(rts[i], lam[i + t - k + 1])), ok = 0; break)));
      if(ok, listput(stack, [concat(c, [b]), rts]))));
  [vecsort(Vec(out)), nodes];
}

dot(u, v) = sum(i = 1, #u, u[i] * v[i]);

{
  my(lines = readstr(getenv("IN")), OUTF = getenv("OUT"), fr, to, idx = -1);
  read(getenv("CERT"));
  fr = if(getenv("FROM"), eval(getenv("FROM")), 0);
  to = if(getenv("TO"), eval(getenv("TO")), 10^9);
  for(li = 1, #lines,
    my(s = lines[li], psi, S, D, Dk, h, Y, verdict, t0);
    if(#s == 0 || Vecsmall(s)[1] != 91, next);   \\ '['
    idx++;
    if(idx < fr || idx > to, next);
    t0 = getabstime();
    psi = eval(s);
    S = setup(psi);
    D = deck(S); Dk = D[1];
    h = Vec(S[4]);
    Y = if(idx + 1 <= #CERTA, CERTA[idx + 1], 0);
    if(#Dk == 0, verdict = "empty deck",
      if(Y == 0, verdict = "no certificate",
        if(#Y != #h, error("certificate length"));
        verdict = if(dot(Y, h) < 0 && vecmin(vector(#Dk, j, dot(Y, Dk[j]))) >= 0, "certificate valid", "certificate FAILS")));
    write(OUTF, Str("leaf ", [idx, #S[5], #Dk, D[2]], " ", verdict, " h ", h, " ms ", getabstime() - t0));
    for(j = 1, #Dk, write(OUTF, Dk[j])));
  write(OUTF, "done");
}
quit;
