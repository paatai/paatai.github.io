"""Stage (S) fast path: on real star systems, StarSystem.solve gives the exact simplex's status.

Usage: python3 verify/test_star_fastpath.py [--seed=K] [--cap=C] [--samples=N] S/I [S/I ...]

For each leaf S/I with a level-2 record that reached stage (S), the star system is built as in
src/level2_59.py (pair types of stage J). The supports are all subsets of the open cliques if a
clique has at most 12 members, else N random subsets of sizes 1..C per clique. For every support
the status of StarSystem.solve must equal the status of exactlp.solve on the same rows, and every
certificate must pass the exact check. Set SRC=<dir> to test a copy of src/ before installing it.
"""
import json
import os
import random
import sys
import time
from itertools import combinations

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SRC = os.environ.get("SRC", os.path.join(ROOT, "src"))
sys.path.insert(0, SRC)
from eqlines import exactlp  # noqa: E402
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.jacobi import PairSpace  # noqa: E402
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.star import StarSystem, poly  # noqa: E402
from run_level1_59 import chi59  # noqa: E402


def supports(cliques, cap, samples, rng):
    seen = []
    have = set()
    for C in cliques:
        C = sorted(C)
        if len(C) <= 12:
            cand = [U for r in range(1, len(C) + 1) for U in combinations(C, r)]
        else:
            cand = [tuple(sorted(rng.sample(C, rng.randint(1, min(cap, len(C))))))
                    for _ in range(samples)]
        for U in cand:
            if U not in have:
                have.add(U)
                seen.append(U)
    return seen


def main():
    seed, cap, samples, leaves = 1, 8, 40, []
    for a in sys.argv[1:]:
        if a.startswith("--seed="):
            seed = int(a[7:])
        elif a.startswith("--cap="):
            cap = int(a[6:])
        elif a.startswith("--samples="):
            samples = int(a[10:])
        else:
            leaves.append(a)
    rng = random.Random(seed)
    print(f"star.py from {SRC}; seed {seed}, cap {cap}, samples {samples}", flush=True)
    bad = 0
    for leaf in leaves:
        s, i = leaf.split("/")
        with open(os.path.join(ROOT, "data", "level2_59", f"s{s}", f"{i}.json")) as fh:
            L2 = json.load(fh)
        sp = SpecPoly(chi59(L2["psi"]))
        ps = PairSpace(sp, nonzero_at=[-5])
        G = [coeffs_to_poly(c) for c in L2["deck"]]
        pairs = {}
        for key, found in L2["J"]["pairs"].items():
            a, b = map(int, key.split(","))
            pairs[(a, b)] = [poly(P) for _sig, _psi, P in found]
        st = StarSystem(sp, ps, G, sp.h, pairs)
        Us = supports(L2["J"]["open_cliques"], cap, samples, rng)
        if "S" in L2 and L2["S"]["supports"]:
            stored = {tuple(e["support"]): e["status"] for e in L2["S"]["supports"]}
        else:
            stored = {}
        counts = {}
        t_new = t_old = 0.0
        for U in Us:
            built = st.build(U)
            t0 = time.time()
            new, data = st.solve(U)
            t1 = time.time()
            if built is None:
                old = "not-clique"
            elif not built[2]:
                old = "feasible" if all(v == 0 for v in built[1]) else "certified"
            else:
                o, _v = exactlp.solve(built[0], built[1])
                old = "feasible" if o == "feasible" else "certified"
            t2 = time.time()
            t_new += t1 - t0
            t_old += t2 - t1
            ok = new == old and (U not in stored or stored[U] == new)
            if new == "certified":
                ok = ok and StarSystem.verify_farkas(built[0], built[1], data["y"])
            if new == "feasible" and built is not None and built[2]:
                from fractions import Fraction
                ok = ok and exactlp.check_feasible(built[0], built[1], [Fraction(v) for v in data["x"]])
            counts[(old, new)] = counts.get((old, new), 0) + 1
            if not ok:
                bad += 1
                print(f"  MISMATCH {leaf} U={list(U)} exact={old} new={new} stored={stored.get(U)}", flush=True)
        print(f"{leaf}: {len(Us)} supports, (exact, new) counts {sorted(counts.items())}, "
              f"stored compared {sum(1 for U in Us if U in stored)}, "
              f"time new {t_new:.1f}s, exact {t_old:.1f}s", flush=True)
    print("ALL SAME" if bad == 0 else f"{bad} MISMATCHES")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
