"""Resume, or complete, a run of c35_cert.py.

Enumerates the leaves of a run exactly as c35_cert.run_all does (same module, same options) and
writes a new certificate file and log in c35_cert's formats:
* a leaf whose record in a --from file is resolved, with the same leaf index, path, references,
  unit and instance head, is copied verbatim (no search);
* a leaf listed in --defer is written unresolved ({"U": "deferred"}) without a search;
* every other leaf is searched: by c35_cert's branch and bound with --budget LPs and, optionally,
  --leaf-time seconds, and with --lookahead W the branching group is chosen among the W smallest
  cardinality groups as the one with the fewest children that survive propagation (W = 0 is
  c35_cert's own choice, and then the trees are identical to c35_cert's).
The output is checked by `c35_cert.py --check` like any other certificate file, so this program
is not part of the trusted base; its log ends with a summary line that c35_cert_checkall.py reads.

Usage: python3 c35_cert_resume.py CASE SUPPORT [c35_cert run options] --out F --log F
                                  [--from F ...] [--defer N ...] [--lookahead W] [--leaf-time S]
"""
import argparse
import gzip
import hashlib
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(100000)
import c35_cert as C  # noqa: E402

with open(os.path.abspath(__file__), "rb") as _f:
    RESUME_HASH = hashlib.sha256(_f.read()).hexdigest()[:16]


def read_records(path):
    """Records of a certificate file in order; a file cut off by a killed run is read up to its
    last complete record."""
    out = []
    f = gzip.open(path, "rt")
    try:
        for line in f:
            if not line.endswith("\n"):
                break
            try:
                out.append((json.loads(line), line.rstrip("\n")))
            except json.JSONDecodeError:
                break
    except EOFError:
        pass
    return out


def read_infos(path):
    out = {}
    if path and os.path.exists(path):
        for line in open(path):
            if line.startswith("{") and '"status"' in line:
                d = json.loads(line)
                if "leaf" in d:
                    out[d["leaf"]] = d
    return out


class Search2(C.Search):
    def __init__(self, leaf, budget, width=0, deadline=None):
        super().__init__(leaf, budget=budget)
        self.width, self.deadline = width, deadline

    def groups(self, alive, f1, f1m):
        L = self.leaf
        out = []
        for lab, bi, sv, req in list(self.labels) + [
                (L.Sm[f], bi, sv, int(L.req[f, bi, si]))
                for f in f1 for bi in range(3) for si, sv in ((0, -1), (1, 1))]:
            g = alive & (L.typ == bi) & (lab == sv)
            need = req - int((g & f1m).sum())
            opts = np.nonzero(g & ~f1m)[0]
            if need >= 1 and len(opts):
                out.append(opts)
        return out

    def choose(self, fix0, fix1, cand, x):
        if self.width == 0:
            best = None
            for opts in cand:
                if best is None or len(opts) < len(best):
                    best = opts
            return sorted(best.tolist(), key=lambda j: -x[j])
        order = sorted(range(len(cand)), key=lambda i: len(cand[i]))[:self.width]
        best, score = None, None
        for gi in order:
            o = sorted(cand[gi].tolist(), key=lambda j: -x[j])
            surv = 0
            for i in range(len(o)):
                a, _, _ = self.state(tuple(fix0) + tuple(o[:i]), tuple(fix1) + (o[i],))
                surv += a is not None
                if score is not None and surv >= score:
                    break
            if score is None or surv < score:
                best, score = o, surv
        return best

    def run(self, fix0=(), fix1=(), depth=0):
        if self.rows0 is None:
            return {"C": "block sum not integral"}, True
        alive, f1, why = self.state(fix0, fix1)
        if alive is None:
            return {"C": why}, True
        if self.lps >= self.budget:
            return {"U": 1}, False
        if self.deadline is not None and time.time() > self.deadline:
            return {"U": "time"}, False
        rows, lo, hi = self.lp_data(alive, f1)
        self.lps += 1
        st, val = C.certificate(rows, self.leaf.n, lo, hi)
        if st == "INFEASIBLE":
            return {"L": sorted(val.items())}, True
        if st == "UNKNOWN":
            return {"U": "lp"}, False
        x = val
        L = self.leaf
        f1m = np.zeros(L.n, dtype=bool)
        f1m[f1] = True
        cand = self.groups(alive, f1, f1m)
        if cand:
            opts = self.choose(fix0, fix1, cand, x)
        else:
            frac = [(abs(x[j] - 0.5), j) for j in np.nonzero(alive & ~f1m)[0]]
            if not frac:
                return {"U": "integral"}, False
            opts = [int(min(frac)[1])]
        ch = []
        ok = True
        for i in range(len(opts) + 1):
            nf0 = tuple(fix0) + tuple(opts[:i])
            nf1 = tuple(fix1) + ((opts[i],) if i < len(opts) else ())
            sub, good = self.run(nf0, nf1, depth + 1)
            ch.append(sub)
            if not good:
                ok = False
                break
        return {"B": [int(o) for o in opts], "ch": ch}, ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=["74", "94"])
    ap.add_argument("support", choices=["015", "0125", "012"])
    ap.add_argument("--struct")
    ap.add_argument("--maxdimF", type=int)
    ap.add_argument("--budget", type=int, default=20000)
    ap.add_argument("--out", required=True)
    ap.add_argument("--log", required=True)
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--shard-level", type=int)
    ap.add_argument("--no-orbits", action="store_true")
    ap.add_argument("--full-refs", action="store_true")
    ap.add_argument("--from", dest="from_", nargs="*", default=[],
                    help="certificate files whose resolved records are reused")
    ap.add_argument("--from-log", nargs="*", default=[],
                    help="their run logs (per-leaf statistics for the copied leaves)")
    ap.add_argument("--defer", type=int, nargs="*", default=[])
    ap.add_argument("--lookahead", type=int, default=0)
    ap.add_argument("--leaf-time", type=float)
    args = ap.parse_args()

    reuse, infos = {}, {}
    for p in args.from_:
        for rec, line in read_records(p):
            if rec.get("resolved"):
                reuse[rec["leaf"]] = (rec, line, p)
    for p in args.from_log:
        infos.update(read_infos(p))
    defer = set(args.defer)

    model = C.Model(args.case, args.support)
    only = args.struct.split(",") if args.struct else None
    shard, nshard = (int(x) for x in args.shard.split("/"))
    t_start = time.time()
    logf = open(args.log, "a")

    def log(d):
        logf.write(json.dumps(d) + "\n")
        logf.flush()

    certs = gzip.open(args.out, "wt")
    stats = {}
    li = 0
    ncopy = 0
    sh = None
    if args.shard_level is not None:
        sh = dict(level=args.shard_level, i=shard, n=nshard, count=0, cur=None)
    for inst in C.instances(model, log, only=only, max_dimF=args.maxdimF,
                            orbits=not args.no_orbits):
        head = inst.head()
        for refs, filters, path in C.leaves(inst, dict(orbits=not args.no_orbits,
                                                       full_refs=args.full_refs, shard_level=sh),
                                            log):
            li += 1
            if sh is None and (li - 1) % nshard != shard:
                continue
            t0 = time.time()
            key = dict(head, path=path, refs=[r.to_json() for r in refs], leaf=li - 1)
            if sh is not None:
                key["unit"] = sh["cur"]
            kj = json.loads(json.dumps(key))
            got = reuse.get(li - 1)
            if got is not None and li - 1 not in defer:
                rec, line, src = got
                assert {k: rec.get(k) for k in kj} == kj, ("record differs", li - 1, src)
                assert rec["resolved"] and set(rec) == set(kj) | {"tree", "resolved"}
                certs.write(line + "\n")
                certs.flush()
                ncopy += 1
                stats["INFEASIBLE"] = stats.get("INFEASIBLE", 0) + 1
                old = infos.get(li - 1, {})
                info = dict(key, refs=[(r.kind, r.typ, r.name) for r in refs],
                            nodes=old.get("nodes"), lps=old.get("lps"), status="INFEASIBLE",
                            time=old.get("time"), copied=os.path.basename(src))
                if "tree" in old:
                    info["tree"] = old["tree"]
                log(info)
                continue
            if li - 1 in defer:
                tree, ok, n, lps = {"U": "deferred"}, False, None, 0
            else:
                leaf = C.Leaf(inst, refs, filters)
                dl = None if args.leaf_time is None else t0 + args.leaf_time
                srch = Search2(leaf, args.budget, width=args.lookahead, deadline=dl)
                tree, ok = srch.run()
                n, lps = leaf.n, srch.lps
            status = "INFEASIBLE" if ok else "UNRESOLVED"
            stats[status] = stats.get(status, 0) + 1
            info = dict(key, refs=[(r.kind, r.typ, r.name) for r in refs], nodes=n, lps=lps,
                        status=status, time=round(time.time() - t0, 2), tree=C.tree_size(tree))
            if li - 1 in defer:
                info["deferred"] = True
            log(info)
            certs.write(json.dumps(dict(key, tree=tree, resolved=ok)) + "\n")
            certs.flush()
    certs.close()
    log(dict(summary=stats, leaves=li, shard=args.shard,
             units=None if sh is None else sh["count"], time=round(time.time() - t_start, 1),
             code=C.CODE_HASH, resume_code=RESUME_HASH, copied=ncopy, args=vars(args)))


if __name__ == "__main__":
    main()
