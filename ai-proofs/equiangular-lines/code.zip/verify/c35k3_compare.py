"""Cross-check of program 1's third-level leaves (src/c35k3.py) against program 2's leaves
(verify/c35_cert.py) for 74 (0,1,5) structure (4,4,4,4), where dim F = 3 and both programs end
with three node references.

For each program-2 leaf (references x_1, x_2, x_3 and the case A/B of each level, from its path),
build program 1's third-level leaf for the same references and compare
* the node sets: (N, steps on the class-a lines, D * F-inner products with the references), with
  program 2's T1b and T1c nodes merged (program 1 leaves the class to a CP-SAT variable).
  Program 2's type-1 references have a class, program 1's do not, so program 1 also generates
  type-1 nodes whose relations with the type-1 references fit no class (value 0 or -4 means the
  same class, +-2 a different one); its model excludes them through the class constraints, since
  the references are selected.  These are counted and left out of the comparison;
* the pair relations: program 1's relation matrices (z-inner product a, exact integer rule) against
  the z-inner products computed from program 2's node data (class-a part plus F-part).

usage: python3 c35k3_compare.py [--leaves N] [--stride S] [--shard i/n --shard-level L]
"""
import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.setrecursionlimit(100000)
import c35k as K  # noqa: E402
import c35k3 as K3  # noqa: E402
import c35_cert as P2  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--leaves", type=int, default=200)
    ap.add_argument("--stride", type=int, default=1)
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--shard-level", type=int)
    args = ap.parse_args()
    part = (4, 4, 4, 4)
    wk = K.Walks("74_19", part)
    widx = {tuple(int(v) for v in s): j for j, s in enumerate(wk.St.tolist())}
    model = P2.Model("74", "015")
    sh = None
    if args.shard_level is not None:
        i, n = (int(x) for x in args.shard.split("/"))
        sh = dict(level=args.shard_level, i=i, n=n, count=0, cur=None)
    opts = dict(orbits=True, full_refs=True)
    if sh is not None:
        opts["shard_level"] = sh
    done = bad = seen = ninc = 0
    nn = []
    for inst in P2.instances(model, lambda d: None, only=["C4", "C4", "C4", "C4"]):
        q, rem = divmod(inst.D, wk.D)
        assert rem == 0 and inst.dimF == wk.dimF == 3
        P4 = inst.base.P4
        for refs, filters, path in P2.leaves(inst, opts, lambda d: None):
            seen += 1
            if (seen - 1) % args.stride:
                continue
            leaf = P2.Leaf(inst, refs, filters)
            G2 = leaf.frame.G
            assert all(G2[r][s] % q == 0 for r in range(3) for s in range(3))
            G1 = [[G2[r][s] // q for s in range(3)] for r in range(3)]
            refs1 = []
            for r, x in enumerate(refs):
                assert x.kind == "node"
                refs1.append((widx[tuple(int(v) for v in x.steps)], 9 if x.typ == "T0" else 8,
                              G1[r]))
            caseB, caseB2, caseB3 = (p[0] == "B" for p in path)
            nd = K3.third_level_nodes(wk, refs1, caseB, caseB2, caseB3)
            t1refs = [(r, x.typ) for r, x in enumerate(refs) if x.typ != "T0"]
            set1 = {}
            for i in range(len(nd["js"])):
                key = (int(nd["Ns"][i]), tuple(int(v) for v in wk.St[nd["js"][i]]),
                       tuple(q * int(c) for c in nd["Ct"][i]))
                assert key not in set1 and nd["B"][i] == 0
                if nd["Ns"][i] == 8 and t1refs and not nd["isref"][i]:
                    j = int(nd["js"][i])
                    vals = []
                    for r, _ in t1refs:
                        num = int(nd["Ct"][i, r]) + int(wk.G[j, refs1[r][0]])
                        assert num % wk.D == 0
                        vals.append(num // wk.D in (0, -4))
                    if not any(all(s == (cl == ty) for s, (_, ty) in zip(vals, t1refs))
                               for cl in ("T1b", "T1c")):
                        ninc += 1
                        continue
                set1[key] = i
            set2 = {}
            for i, x in enumerate(leaf.nodes):
                assert x["R"] == 0
                key = (9 if x["typ"] == "T0" else 8, tuple(int(v) for v in x["steps"]),
                       tuple(int(c) for c in x["C"]))
                set2.setdefault(key, i)
            ok = set(set1) == set(set2)
            msg = ""
            if ok:
                keys = sorted(set1)
                i1 = np.array([set1[k] for k in keys])
                i2 = [set2[k] for k in keys]
                S = np.array([leaf.nodes[i]["steps"] for i in i2], dtype=float)
                C = np.array([leaf.nodes[i]["C"] for i in i2], dtype=float)
                Ginv = np.array([[float(int(leaf.frame.adj[a, b])) / leaf.frame.det
                                  for b in range(3)] for a in range(3)])
                rho = (S @ P4.astype(float) @ S.T + C @ Ginv @ C.T) / inst.D
                t0 = np.array([k[0] == 9 for k in keys])
                rel = K.relations(wk, nd)
                for a in (1, -3, 2, -2, 0, -4):
                    allowed = (np.outer(t0, t0) if a in (1, -3) else
                               np.outer(~t0, ~t0) if a in (0, -4) else
                               np.ones((len(keys), len(keys)), dtype=bool))
                    exp = (np.abs(rho - a) < 1e-6) & allowed
                    np.fill_diagonal(exp, False)
                    got = rel[a][np.ix_(i1, i1)]
                    if not np.array_equal(exp, got):
                        ok = False
                        msg += " relation %d differs in %d entries" % (a, int((exp != got).sum()))
            else:
                msg = " node sets: %d only in program 1, %d only in program 2" % (
                    len(set(set1) - set(set2)), len(set(set2) - set(set1)))
            done += 1
            nn.append(len(set1))
            if not ok:
                bad += 1
                print("MISMATCH leaf", seen - 1, path, msg, flush=True)
            if done % 25 == 0:
                print("compared", done, "mismatches", bad, "nodes mean", round(float(np.mean(nn)), 1),
                      "class-inconsistent program-1 nodes dropped", ninc, flush=True)
            if done >= args.leaves:
                break
        if done >= args.leaves:
            break
    print("74 (0,1,5) (4,4,4,4): compared %d leaves, mismatches %d; program 1 has %d more type-1 "
          "nodes whose relations with the type-1 references fit no class (its CP-SAT model excludes "
          "them through the class constraints)" % (done, bad, ninc), flush=True)


if __name__ == "__main__":
    main()
