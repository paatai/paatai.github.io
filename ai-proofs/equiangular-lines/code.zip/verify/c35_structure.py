"""Mechanical check of the structure of candidate #35 (CLAIMS.md U6) from the level-2 data of U5,
and of the input of the certifier verify/c35_cert.py.

Input: data/level2_l312/CASE/35.json (the six deck members g_t) and data/level2j_l312/CASE/35.json
(every pair polynomial psi with its entry S).  With Min = prod (x - lam) over the distinct
eigenvalues lam_1 > lam_2 > lam_3 > -5 of #35 and E_lam the spectral projections,
    (E_lam)_vv = g_v(lam) / Min'(lam),      (E_lam)_uv = psi_uv(lam) / Min'(lam)   (u != v).
The scaled components X_v = (sqrt2 r_v, sqrt3 z_v, p_v) of V_1 + V_2 + V_3 satisfy
<X_u, X_v> = 6 (S + 5I)_uv, i.e.
    2 r_u r_v = 6 (lam_1 + 5) E_1,   3 <z_u, z_v> = 6 (lam_2 + 5) E_2,   <p_u, p_v> = 6 (lam_3 + 5) E_3.

Checks (each prints PASS or raises):
  (1) the norms (r^2, |z|^2, |p|^2) of the six types, and r in {0, 1, 2, 3};
  (2) every pair tuple (S, rr', zz', pp') satisfies 2rr' + 3zz' + pp' = 6S and Cauchy-Schwarz;
  (3) the V_3 (p-part) facts of U6(b): types 0 and 5 have p parallel to one line w0 and type 1 has
      p orthogonal to it; after switching every line with r > 0 to r > 0, two type-1 p-parts have
      inner product 4 or -2 (three directions at 120 degrees), and the type-2 and type-5 values
      are those of the positions p = sigma sqrt3 w0 - 2u_x and p = +-2 sqrt3 w0;
  (4) soundness of the certifier's pair rules: for every support and every pair of line kinds of
      verify/c35_cert.Model, the pairs (S, <z, z'>) that the pair data allow for the model's
      positions (after switching) are among those the model allows; equality is reported.
"""
import itertools
import json
import os
import sys
from fractions import Fraction as Q

sys.path.insert(0, os.path.dirname(__file__))
import c35_cert as P2  # noqa: E402

ROOT = os.path.join(os.path.dirname(__file__), "..")
LAM = {"74_19": (17, 15, 11, -5), "94_20": (21, 19, 15, -5)}
TYPE_OF = {"T0": 0, "T1a": 1, "T1b": 1, "T1c": 1}


def ev(c, x):
    v = 0
    for a in c:
        v = v * x + a
    return v


def mind(lam, i):
    out = 1
    for j, mu in enumerate(lam):
        if j != i:
            out *= lam[i] - mu
    return out


def type_norms(case, deck):
    lam = LAM[case]
    out = []
    for g in deck:
        w = [Q(ev(g, lam[i]), mind(lam, i)) for i in range(3)]
        r2, z2, p2 = Q(6 * (lam[0] + 5), 2) * w[0], Q(6 * (lam[1] + 5), 3) * w[1], 6 * (lam[2] + 5) * w[2]
        out.append((r2, z2, p2))
    return out


def pair_tuples(case, pairs):
    lam = LAM[case]
    out = {}
    for key, found in pairs.items():
        a, b = map(int, key.split(","))
        tl = []
        for S, psi, _P in found:
            e = [Q(ev(psi, lam[i]), mind(lam, i)) for i in range(3)]
            rr = Q(6 * (lam[0] + 5), 2) * e[0]
            zz = Q(6 * (lam[1] + 5), 3) * e[1]
            pp = 6 * (lam[2] + 5) * e[2]
            tl.append((S, rr, zz, pp))
        out[(a, b)] = out[(b, a)] = tl
    return out


def kind_type(nm):
    if nm in TYPE_OF:
        return TYPE_OF[nm]
    return 2 if nm.startswith("t") else 5


def main():
    ok_all = True
    for case in ("74_19", "94_20"):
        L2 = json.load(open(os.path.join(ROOT, f"data/level2_l312/{case}/35.json")))
        LJ = json.load(open(os.path.join(ROOT, f"data/level2j_l312/{case}/35.json")))
        norms = type_norms(case, L2["deck"])
        rt = {}
        print(f"== {case}: types (r^2, |z|^2, |p|^2):",
              [tuple(str(x) for x in n) for n in norms])
        for t, (r2, z2, p2) in enumerate(norms):
            assert 2 * r2 + 3 * z2 + p2 == 30
            if t in (0, 1, 2, 5):
                rt[t] = {Q(0): 0, Q(1): 1, Q(4): 2, Q(9): 3}[r2]
        exp = {0: (0, 9, 3), 1: (1, 8, 4), 2: (2, 5, 7), 5: (3, 0, 12)}
        for t, (r, z2, p2) in exp.items():
            assert (rt[t], norms[t][1], norms[t][2]) == (r, z2, p2), t
        print("  (1) PASS: types 0, 1, 2, 5 have (r, |z|^2, |p|^2) = (0,9,3), (1,8,4), (2,5,7), (3,0,12)")
        tup = pair_tuples(case, LJ["pairs"])
        for (a, b), tl in tup.items():
            for S, rr, zz, pp in tl:
                assert 2 * rr + 3 * zz + pp == 6 * S, (a, b)
                assert rr * rr <= norms[a][0] * norms[b][0]
                assert zz * zz <= norms[a][1] * norms[b][1] and pp * pp <= norms[a][2] * norms[b][2]
        print("  (2) PASS: 2rr' + 3zz' + pp' = 6S and Cauchy-Schwarz for all",
              sum(len(v) for v in LJ["pairs"].values()), "pair polynomials")

        def norm_set(a, b):
            """tuples after switching both lines to r > 0 (types with r > 0)"""
            out = set()
            for S, rr, zz, pp in tup[(a, b)]:
                if rt[a] and rt[b]:
                    e = 1 if rr > 0 else -1
                    out.add((e * S, e * rr, e * zz, e * pp))
                else:
                    out.add((S, rr, zz, pp))
            return out
        pv = lambda a, b: sorted({str(t[3]) for t in tup[(a, b)]})
        assert {abs(t[3]) for t in tup[(0, 0)]} == {3}
        assert {t[3] for t in tup[(0, 1)]} == {0}
        assert {abs(t[3]) for t in tup[(0, 2)]} == {3}
        assert {abs(t[3]) for t in tup[(0, 5)]} == {6}
        assert {t[3] for t in norm_set(1, 1)} == {4, -2}
        assert {t[3] for t in norm_set(1, 2)} == {-4, 2}
        assert {t[3] for t in norm_set(1, 5)} == {0}
        assert {t[3] for t in norm_set(2, 2)} <= {7, 1, -5}
        assert {abs(t[3]) for t in norm_set(2, 5)} == {6}
        assert {abs(t[3]) for t in tup[(5, 5)]} == {12}
        for a in (3, 4):
            assert all(not tup[(a, b)] for b in (1, 2, 5)), a
        print("  (3) PASS: <p,p'> values: (0,0)", pv(0, 0), "(0,1)", pv(0, 1), "(0,2)", pv(0, 2),
              "(0,5)", pv(0, 5), "(1,1)", sorted(str(t[3]) for t in norm_set(1, 1)),
              "(1,2)", sorted(str(t[3]) for t in norm_set(1, 2)),
              "(2,2)", sorted({str(t[3]) for t in norm_set(2, 2)}),
              "(5,5)", pv(5, 5), "; types 3, 4 pair only with 0 and themselves")
        # (4) certifier pair rules
        for sup in ("015", "0125", "012"):
            m = P2.Model(case[:2], sup)
            kinds = list(P2.BLOCKS) + m.single
            n_eq = n_tot = 0
            for u, v in itertools.combinations_with_replacement(kinds, 2):
                if u == v and u in m.single:
                    continue
                a, b = kind_type(u), kind_type(v)
                ru_rv = m.r[u] * m.r[v]
                puv = m.K(u, v) - 2 * ru_rv
                true = set()
                for S, rr, zz, pp in tup[(a, b)]:
                    for e in (1, -1):
                        if e * rr == ru_rv and e * pp == puv:
                            true.add((e * S, e * zz))
                model = {(S, z) for z, S in m.allowed(u, v).items()}
                if u in m.T5 or v in m.T5:
                    model = {(m.S_T5(v if u in m.T5 else u, u if u in m.T5 else v), Q(0))}
                if not true <= model:
                    ok_all = False
                    print("  (4) FAIL", case, sup, u, v, "data", sorted(true), "model", sorted(model))
                n_tot += 1
                n_eq += true == model
            print(f"  (4) support {sup}: {n_tot} kind pairs, data set within model set for all; "
                  f"equal for {n_eq}")
    print("C35 STRUCTURE CHECK:", "ALL PASS" if ok_all else "FAILED")


if __name__ == "__main__":
    main()
