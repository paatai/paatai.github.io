"""Cross-check of the two #35 programs on identical leaves: src/c35u.py (program 1, CP-SAT model)
and verify/c35_cert.py (program 2, LP certificates).  For every instance of program 1 whose
type-2 references already give k >= dim F - 1, build the leaf in both programs and compare the
node sets (type, steps, S against the type-2 lines, eps, F-coordinates, residual) and the full
relation matrices.

usage: c35_cert_compare.py CASE(74_19|94_20) SUPPORT(0125|012) [--maxdimF k] [--limit n]
"""
import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
sys.path.insert(0, os.path.dirname(__file__))
import c35u  # noqa: E402
import c35_cert as P2  # noqa: E402


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case")
    ap.add_argument("support")
    ap.add_argument("--maxdimF", type=int)
    ap.add_argument("--limit", type=int, default=10 ** 9)
    args = ap.parse_args()
    sup = c35u.Support(args.case, args.support)
    model = P2.Model(args.case[:2], args.support)
    arows = P2.class_a_rows(model)
    graphs = {H["mask"]: H for H in P2.relation_graphs(model)}
    done = mism = 0
    for H, rows, comps, assign in c35u.enumerate_instances(sup, args.maxdimF, None):
        inst1 = c35u.Instance(sup, H, rows, comps, assign)
        if not inst1.other_gram_ok():
            continue
        # H mask of program 1 (same pair order and bit convention)
        t2 = sup.t2
        pairs = [(u, v) for i, u in enumerate(t2) for v in t2[i + 1:]]
        mask = sum(1 << k for k, (u, v) in enumerate(pairs) if sup.allowed(u, v)[H["ip"][(u, v)]] == -1)
        H2 = graphs[mask]
        assert all(H2["rows"][t] == rows[t] for t in t2), "type-2 row counts differ"
        partners = {}
        for nm, v in assign.items():
            partners.setdefault(v, []).append(nm)
        partners = {v: tuple(sorted(l)) for v, l in partners.items()}
        S1, Om1 = inst1.base.walks()
        for ownj in inst1.own_candidates():
            fx, refs = inst1.setup_fixed(ownj)
            if not c35u.check_base_sum(inst1, fx) or len(refs) < inst1.dimF - 1:
                continue
            own_steps = {nm: S1[j] for nm, j in ownj.items()}
            inst2 = P2.Instance(model, H2, comps, partners, own_steps)
            inst2.arows = arows
            assert inst2.gram_ok(model.T2) and inst2.base_sum_ok()
            refs2 = P2.type2_refs(inst2)
            assert [r.name for r in refs2] == refs, (refs, [r.name for r in refs2])
            nodes1, ctx = c35u.build_nodes(inst1, fx, refs)
            leaf = P2.Leaf(inst2, refs2, [])
            # the programs scale F-inner products by different denominators D1 | D2
            q, rem = divmod(inst2.D, inst1.base.D)
            assert rem == 0
            k = ctx["k"]
            assert ctx["Delta"] * q ** k == leaf.frame.det
            key1 = [(x["t"], tuple(int(v) for v in S1[x["j"]]), tuple(sorted(x["sing"].items())),
                     int(x["eps"]), tuple(q * int(c) for c in x["Ct"]), q ** (k + 1) * int(x["B"]))
                    for x in nodes1]
            key2 = [(x["typ"], tuple(int(v) for v in x["steps"]),
                     tuple(sorted(x["Srow"].items())), int(x["eps"]), tuple(x["C"]), int(x["R"]))
                    for x in leaf.nodes]
            ok = sorted(key1) == sorted(key2)
            if ok and nodes1:
                Sm1, _ = c35u.relations(inst1, nodes1, ctx)
                o1 = np.argsort(np.array([str(k) for k in key1]))
                o2 = np.argsort(np.array([str(k) for k in key2]))
                ok = np.array_equal(Sm1[np.ix_(o1, o1)], leaf.Sm[np.ix_(o2, o2)])
                if not ok:
                    d = (Sm1[np.ix_(o1, o1)] != leaf.Sm[np.ix_(o2, o2)])
                    print("relation mismatch entries:", int(d.sum()), flush=True)
            done += 1
            if not ok:
                mism += 1
                print("MISMATCH", comps, H["E"], assign, ownj, len(key1), len(key2), flush=True)
            if done >= args.limit:
                break
        if done >= args.limit:
            break
    print(f"{args.case} {args.support}: compared {done} leaves, mismatches {mism}", flush=True)


if __name__ == "__main__":
    main()
