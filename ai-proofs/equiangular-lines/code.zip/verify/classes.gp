\\ Independent regeneration of P_{n,e} = {chi_S mod 2^e Z[x] : S a Seidel matrix of order n} [GY19, sec. 3]
\\ (PARI/GP; no code of src/gen_classes.py or src/eqlines).
\\ Random Seidel matrices (GP's own generator, edge densities cycling through DENS) are drawn until
\\ the number of distinct classes reaches the bound of [GY19, Cor. 3.4] (n even: 2^C(e-2,2)) or
\\ [GY19, Cor. 3.13] (n odd: 2^(C(e-2,2)+1)); reaching the bound proves that the list is complete.
\\ The list is then compared with CL (read from CLASSES, written from the Python list).
\\ Usage: N=59 E=7 SEED=1 CLASSES=data/P_59_7.gp gp -q -f verify/classes.gp < /dev/null
default(parisizemax, 2^31);
n = eval(getenv("N")); e = eval(getenv("E")); seed = eval(getenv("SEED"));
read(getenv("CLASSES"));   \\ defines CL
bound = 2^(binomial(e - 2, 2) + n % 2);
DENS = [1/2, 3/10, 7/10, 1/5, 4/5, 1/10, 9/10, 2/5, 3/5, 1/20, 19/20];

\\ the s-th sample (0-based) after setrand(seed): reproducible by calling sample() s + 1 times
sample(s) = {
  my(S = matrix(n, n), thr = floor(DENS[s % #DENS + 1] * 2^30));
  for(i = 1, n, for(j = i + 1, n, S[i, j] = if(random(2^30) < thr, -1, 1); S[j, i] = S[i, j]));
  S;
}

{
  my(found = Map(), cnt = 0, s = 0, S, p, key, wit = List(), t0 = getabstime(), mine, theirs);
  setrand(seed);
  while(cnt < bound && s < 10^6,
    S = sample(s);
    if(S != S~ || vector(n, i, S[i, i]) != vector(n), error("not a Seidel matrix"));
    for(i = 1, n, for(j = 1, n, if(i != j && abs(S[i, j]) != 1, error("not a Seidel matrix"))));
    p = charpoly(S);
    if(poldegree(p) != n || pollead(p) != 1, error("charpoly"));
    key = Vec(p) % 2^e;
    if(!mapisdefined(found, key), mapput(found, key, s); listput(wit, [key, s]); cnt++);
    s++);
  mine = Set(apply(w -> w[1], Vec(wit)));
  theirs = Set(CL);
  print("n = ", n, ", e = ", e, ", seed = ", seed, ": ", cnt, " classes in ", s, " samples (bound ", bound,
        "), ", (getabstime() - t0) \ 1000, " s");
  print("complete: ", cnt == bound);
  print("CLASSES has ", #CL, " entries, ", #theirs, " distinct");
  print("equal to CLASSES: ", mine == theirs);
  if(mine != theirs,
    print("only here: ", #setminus(mine, theirs), ", only in CLASSES: ", #setminus(theirs, mine)));
}
quit;
