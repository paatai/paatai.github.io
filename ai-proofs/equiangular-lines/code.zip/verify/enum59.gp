\\ Second program for the degree-17 enumeration of 59 equiangular lines in R^18 (PARI/GP).
\\ Written without the code of src/enum59.py or src/eqlines (only the mathematical statements).
\\
\\ Lists every psi = x^17 + c_1 x^16 + ... + c_17 in Z[x] with c_1 = -7, c_2 = -8, all roots real, and
\\  (E)   2^i | c_i for even i, 2^(i-1) | c_i for odd i;
\\  (P)   chi_S = (x+5)^41 (x-11) psi(x-11) mod 2^7 lies in the complete class list P_{59,7}
\\        (tested on the coefficients that are already final: positions 0..i after c_i, the whole
\\        class after c_7, since every later c_i is 0 mod 2^7 by (E));
\\  (L)   [GY19, Lemma 3.12] for chi_{S+I} = chi_S(x-1) = sum_i c_i (x+4)^41 (x-12)^(18-i), whose
\\        coefficients a_0..a_j depend only on c_0..c_j: after c_i for odd i >= 9, the conditions
\\        2^(j-1) | a_j (odd j), 2^j | a_j (even j) for j <= i and the congruences at all levels
\\        k <= (i-1)/2.  The right side is evaluated as the literal partition sum of the lemma.
\\ Real-rootedness: D_i = psi^(17-i) depends only on c_0..c_i and D_i' = D_(i-1).  If D_i is
\\ real-rooted, then (-1)^(i-k) D_i(mu_k) >= 0 at the roots mu_1 <= ... <= mu_(i-1) of D_(i-1)
\\ (Rolle), which bounds C = c_i (17-i)! = D_i(0).  The bounds are evaluated at polrootsreal's
\\ roots (realprecision 100) and widened by an explicit Lipschitz margin; every candidate in the
\\ widened range is then tested: D_i must have i real roots (with multiplicity) by polrootsreal
\\ (exact isolation), and a leaf must also pass polsturm on its squarefree part.  One candidate beyond each
\\ end of the widened range is tested too, and must fail (otherwise the run stops with an error).
\\
\\ Children are visited in decreasing order of c_i, so the nodes with c_0..c_5 fixed are met in the
\\ same order as in src/enum59.py; shard s of N takes those numbered s mod N (0-based).
\\
\\ Usage: SHARD=s NSHARD=N CLASSES=data/P_59_7.gp OUT=file gp -q -f verify/enum59.gp
\\ Output: one line per leaf, [c_0, ..., c_17]; a last line "summary [...]".

default(realprecision, 100);
default(parisizemax, 2^31);
T = 17; NN = 59;
SH = eval(getenv("SHARD")); NSH = eval(getenv("NSHARD"));
OUTF = getenv("OUT");
read(getenv("CLASSES"));   \\ defines CL: vector of the 2048 class keys (60 residues mod 128 each)
if(#CL != 2048, error("P_{59,7} must have 2048 classes"));
if(#Set(CL) != 2048, error("class keys not distinct"));

emod(i) = if(i % 2 == 0, 2^i, 2^(i - 1));

VV = vector(T + 1, i1, my(i = i1 - 1, v = Vec((x + 5)^41 * (x - 11)^(T + 1 - i))); concat(vector(i), v) % 128);
for(i1 = 1, T + 1, if(#VV[i1] != 60, error("VV length")));
WW = vector(T + 1, i1, my(i = i1 - 1, v = Vec((x + 4)^41 * (x - 12)^(T + 1 - i))); concat(vector(i), v)[1 .. T + 1]);
PS = vector(6, k, if(k >= 3, Set(vector(#CL, j, CL[j][1 .. k + 1])), []));
FULL = Set(CL);

\\ partition data of [GY19, Lemma 3.12] at level k: [parts, C_d(m)] over d | 2k, partitions of d, m_(2k) = 0
{
  LDATA = vector(8);
  for(k = 2, 8,
    my(L = List(), tk = 2 * k);
    fordiv(tk, d, forpart(p = d,
      my(m = vector(d), sz, C);
      for(t = 1, #p, m[p[t]]++);
      if(d < tk || m[tk] == 0,
        sz = vecsum(m);
        C = 2^tk * d * eulerphi(tk / d) / tk * (sz - 1)! / prod(j = 1, d, m[j]!);
        listput(L, [Vec(p), C]))));
    LDATA[k] = Vec(L));
}

\\ a = [a_0, ..., a_m] (1-based: a[j+1] = a_j)
l312(a, k) = {
  my(s = vector(2 * k), tot = 0);
  for(j = 1, k,
    s[2 * j - 1] = (a[2 * j + 2] + a[2 * j + 1] + a[2 * j] * a[4]) / 2^(2 * j - 1);
    s[2 * j] = a[2 * j + 2] / (2^(2 * j) * NN));
  for(t = 1, #LDATA[k], my(e = LDATA[k][t], p = e[1]); tot += e[2] * prod(u = 1, #p, s[p[u]]));
  valuation(a[2 * k + 2] - tot, 2) >= 2 * k + 1;
}

gyok(a, i) = {
  if(a[1] != 1 || a[2] != -NN || a[3] != 0, return(0));
  for(j = 1, i, my(need = if(j % 2 == 0, j, j - 1)); if(valuation(a[j + 1], 2) < need, return(0)));
  for(k = 2, (i - 1) \ 2, if(!l312(a[1 .. 2 * k + 2], k), return(0)));
  1;
}

nodes = 0; leaves = 0; splitn = 0; mine = 0; levn = vector(T + 1);

realrooted(D) = my(g = D / gcd(D, deriv(D))); polsturm(g) == poldegree(g);

\\ returns [0] if c_i = ci fails (P) or (L), else [1, residues mod 2^7, a_0..a_17] after c_i
cand_ok(c, i, ci, r, A) = {
  my(r2 = r, A2);
  if(i >= 3 && i <= 7,
    r2 = (r + ci * VV[i + 1]) % 128;
    if(i <= 6, if(!setsearch(PS[i], r2[1 .. i + 1]), return([0])),
               if(!setsearch(FULL, r2), return([0]))));
  A2 = A + ci * WW[i + 1];
  if(i % 2 == 1 && i >= 9, if(!gyok(A2, i), return([0])));
  [1, r2, A2];
}

expand(c, mu, r, A) = {
  my(i, Pi, q, lo = -oo, hi = +oo, cmin, cmax, md, top, bot, Pa);
  i = #c;
  Pi = sum(j = 1, i, c[j] * x^(T - j + 1));
  q = (T - i)!;
  if(i == 6,
    splitn++;
    if((splitn - 1) % NSH != SH, return());
    mine++);
  for(t = 1, T - i, Pi = deriv(Pi));
  Pa = deriv(Pol(apply(abs, Vec(Pi))));
  for(k = 1, i - 1,
    my(v, eps, mg);
    v = -subst(Pi, x, mu[k]);
    eps = (abs(mu[k]) + 1) * 10.^(-90);
    mg = subst(Pa, x, abs(mu[k]) + eps) * eps + abs(v) * 10.^(-95) + 10.^(-90);
    if((i - k) % 2 == 0, lo = max(lo, v - mg), hi = min(hi, v + mg)));
  cmin = ceil(lo / q); cmax = floor(hi / q);
  md = emod(i);
  top = floor(cmax / md) * md; bot = ceil(cmin / md) * md;
  \\ one candidate beyond each end must not give a real-rooted D_i
  foreach([top + md, bot - md], ce, if(realrooted(Pi + ce * q), error(Str("range too small at ", c, " ", ce))));
  forstep(ci = top, bot, -md,
    my(res = cand_ok(c, i, ci, r, A));
    if(res[1],
      my(D = Pi + ci * q, rts = polrootsreal(D));
      if(#rts == i,
        nodes++; levn[i + 1]++;
        if(i == T,
          if(!realrooted(D), error(Str("leaf fails polsturm: ", concat(c, ci))));
          leaves++;
          write(OUTF, concat(c, ci)),
          expand(concat(c, ci), vecsort(rts), res[2], res[3])))));
}

{
  my(c = [1, -7, -8], D2 = sum(j = 1, 3, c[j] * x^(T - j + 1)), r, A);
  for(t = 1, T - 2, D2 = deriv(D2));
  if(!realrooted(D2), error("D_2 not real-rooted"));
  r = sum(i = 1, 3, c[i] * VV[i]) % 128;
  A = sum(i = 1, 3, c[i] * WW[i]);
  if(A[1] != 1 || A[2] != -NN || A[3] != 0, error("a_0, a_1, a_2"));
  expand(c, vecsort(polrootsreal(D2)), r, A);
  write(OUTF, Str("summary ", [nodes, leaves, splitn, mine], " levels ", levn));
}
quit;
