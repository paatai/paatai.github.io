\\ Independent PARI/GP verification that there are no 421 equiangular lines in R^44.
\\ Written independently of the Python pipeline (src/n421_*.py); shares only the
\\ exported stripping chain and Farkas certificates (data/n421/export.gp), which are
\\ re-checked here against objects recomputed from scratch.
\\
\\   cd verify && gp -q n421.gp
\\   cd verify && gp -q n421_weak.gp   (same check without the parity refinement for Q:
\\                                      only 2^(i-1) | a_i; reads data/n421_weak/export.gp)
\\
\\ Exactness: all decisions use exact integer/rational arithmetic and Sturm sequences.
\\ Floating point (polrootsreal) is used only to compute candidate RANGES, which are
\\ widened; every candidate in a range is then tested exactly.

default(realprecision, 200);
if (default(parisize) < 10^8, default(parisize, 10^8));
WEAK = if (type(WEAK) == "t_INT", WEAK, 0);
read(if (WEAK, "../data/n421_weak/export.gp", "../data/n421/export.gp"));

N = 421; DIM = 44; A = 7; M = N - DIM;

\\ ------------------------------------------------------------------
\\ 1. stripping chain: each step must satisfy T^r < r^r 4^(r - (N mod 2))
\\ ------------------------------------------------------------------
{
  my(P1 = A*M, P2 = N*(N-1) - A^2*M, r = DIM, g = N % 2, T, k);
  if ([P1, P2] != [2639, 158347], error("moments"));
  for (j = 1, #CHAIN,
    k = CHAIN[j];
    if (k % 2 != 1, error("even kappa"));
    T = P2 - 2*k*P1 + r*k^2;
    if (!(T^r < r^r * 4^(r-g)), error("chain step ", j, " is not forced"));
    r--; P1 -= k; P2 -= k^2);
  if ([r, P1, P2] != [13, 780, 46836], error("chain end"));
  if ([P1 - 59*r, P2 - 118*P1 + r*59^2] != [13, 49], error("shifted moments"));
  if (#select(v -> v == 59, CHAIN) != 16 || #select(v -> v == 61, CHAIN) != 15, error("counts"));
  print("[1] stripping chain verified: 59 x16, 61 x15, remainder degree 13 with p1 = 13, p2 = 49");
}

\\ ------------------------------------------------------------------
\\ exact helpers
\\ ------------------------------------------------------------------
\\ Yun squarefree decomposition: [[s_1,1],[s_2,2],...] with D = const * prod s_j^j
sqfdec(D) =
{
  my(res = List(), b = D', c = gcd(D, b), w = D/c, y = b/c, z, dd, i = 1);
  z = y - w';
  while (poldegree(w) > 0,
    dd = gcd(w, z);
    if (poldegree(dd) > 0, listput(res, [dd, i]));
    w = w/dd; y = z/dd; z = y - w'; i++);
  Vec(res)
};
\\ number of roots of D (with multiplicity) in the closed interval I = [a, b]
nroots(SQ, I) = sum(j = 1, #SQ, SQ[j][2] * polsturm(SQ[j][1], I));
isrealrooted(SQ, deg) = nroots(SQ, [-oo, +oo]) == deg;

\\ D_i = f^{(t-i)} from the prefix c = [c_0, ..., c_i]
Dfrom(c, t, i) = sum(j = 0, i, c[j+1] * ((t-j)!/(i-j)!) * 'x^(i-j));

\\ ------------------------------------------------------------------
\\ generic exhaustive enumerator (Rolle / derivative interlacing)
\\   f monic of degree t, c_1, c_2 given; c_i restricted to a residue class
\\   congr(i, c) = [residue, modulus]; okD(i, D, SQ) a necessary condition on D_i.
\\ For a real-rooted D_i = P + C (C = c_i (t-i)!), with mu_1 <= .. <= mu_{i-1} the
\\ roots of D_{i-1} = D_i': (-1)^(i-k) (P(mu_k) + C) >= 0 for all k.
\\ ------------------------------------------------------------------
enumrr(t, c1, c2, congr, okD) =
{
  my(out = List(), stack = List(), c, i, rts, P, lo, hi, q, w, cmin, cmax, rm, Di, SQ, nodes = 0, v);
  c = [1, c1, c2];
  Di = Dfrom(c, t, 2); SQ = sqfdec(Di);
  if (!isrealrooted(SQ, 2) || !okD(2, Di, SQ), return([[], 0]));
  if (t == 2, return([[c], 1]));
  listput(stack, c);
  while (#stack,
    c = stack[#stack]; listpop(stack);
    i = #c; nodes++;
    rts = polrootsreal(Dfrom(c, t, i-1));
    P = Dfrom(concat(c, [0]), t, i);
    lo = -oo; hi = +oo;
    for (k = 1, i-1,
      v = -subst(P, 'x, rts[k]);
      if ((i-k) % 2 == 0, lo = max(lo, v), hi = min(hi, v)));
    q = (t-i)!;
    w = 10^(-60) * (1 + abs(lo) + abs(hi));
    cmin = ceil((lo - w)/q); cmax = floor((hi + w)/q);
    rm = congr(i, c);
    forstep (cc = cmin + ((rm[1] - cmin) % rm[2]), cmax, rm[2],
      my(cn = concat(c, [cc]), Dn = Dfrom(cn, t, i), SQn = sqfdec(Dn));
      if (!isrealrooted(SQn, i) || !okD(i, Dn, SQn), next);
      if (i == t, listput(out, cn), listput(stack, cn))));
  [Vec(out), nodes]
};

\\ ------------------------------------------------------------------
\\ 2. remainder polynomials Q (degree 13, x = lambda - 59)
\\    2^(i-1) | a_i (i odd), 2^i | a_i (i even); with WEAK only 2^(i-1) | a_i
\\ ------------------------------------------------------------------
QLIST = 0;
{
  my(res, t0 = getabstime(), mine, theirs);
  res = enumrr(13, -13, 60, (i, c) -> [0, 2^(if (i % 2 || WEAK, i-1, i))], (i, D, SQ) -> 1);
  QLIST = res[1];
  mine = vecsort(QLIST); theirs = vecsort(vector(#CERTS, j, CERTS[j][1]));
  if (mine != theirs, error("remainder lists differ: GP ", #mine, " vs exported ", #theirs));
  print("[2] remainder enumeration: ", #QLIST, " polynomials, ", res[2], " nodes, identical to the exported list (",
        getabstime() - t0, " ms)");
}

\\ ------------------------------------------------------------------
\\ 3. decks of each candidate
\\ ------------------------------------------------------------------
\\ box for the roots of g: other eigenvalues of S[i] (order 420, -7 of multiplicity exactly 376)
BOXL = 0; BOXU = 0;
{
  my(m1 = M - 1, P1 = A*m1, P2 = (N-1)*(N-2) - A^2*m1, disc = DIM*P2 - P1^2, s);
  if ([P1, P2, disc] != [2632, 157556, 5040], error("deck moments"));
  s = sqrtint((DIM-1)*disc) + 1;   \\ s > sqrt(43 * 5040)
  BOXL = (P1 - s)/DIM; BOXU = (P1 + s)/DIM;
}

\\ current candidate data (globals used by the deck predicates)
EIGQ = 0; EIGLO = 0; EIGHI = 0; DELTA = 0; TDEG = 0;

\\ isolate all distinct eigenvalues: factor list FL = [[q, e], ...] (irreducible q)
isolate(FL) =
{
  my(L = List(), r, al, be, eps = 10^(-80));
  for (j = 1, #FL,
    my(qq = FL[j][1]);
    r = polrootsreal(qq);
    if (#r != poldegree(qq), error("non-real eigenvalue"));
    for (k = 1, #r,
      al = floor(r[k]/eps)*eps - eps; be = al + 3*eps;
      if (polsturm(qq, [al, be]) != 1 || subst(qq, 'x, al)*subst(qq, 'x, be) >= 0, error("isolation"));
      listput(L, [r[k], al, be, qq])));
  L = vecsort(Vec(L), 1);
  for (k = 1, #L - 1, if (!(L[k][3] < L[k+1][2]), error("overlap")));
  L
};

\\ exact sign of g at the eigenvalue with enclosure [al, be] and minimal polynomial qq
signat(g, al, be, qq) =
{
  my(a1 = al, b1 = be, mid);
  if (g % qq == 0, return(0));
  while (polsturm(g, [a1, b1]) != 0,
    mid = (a1 + b1)/2;
    if (subst(qq, 'x, mid) == 0, a1 = mid - (b1-a1)/4; b1 = mid + (b1-a1)/4; next);
    if (subst(qq, 'x, a1)*subst(qq, 'x, mid) < 0, b1 = mid, a1 = mid));
  sign(subst(g, 'x, a1))
};

\\ pruning predicate for D_i: roots in the box, k-th root in its interlacing window
deckokD(i, D, SQ) =
{
  my(t = TDEG, lo, hi);
  if (nroots(SQ, [BOXL, BOXU]) != i, return(0));
  for (k = 1, i,
    lo = max(EIGLO[k], BOXL); hi = min(EIGHI[k + t - i + 1], BOXU);
    if (nroots(SQ, [-oo, lo]) > k - 1, return(0));
    if (nroots(SQ, [-oo, hi]) < k, return(0)));
  1
};

\\ type-2 congruence for g(x-1): coefficient beta_i of x^(t-i) must be 0 mod 2^i
deckcongr(i, c) =
{
  my(t = TDEG, part);
  part = sum(j = 0, i-1, c[j+1] * ('x - 1)^(t-j));
  [(-polcoef(part, t-i)) % 2^i, 2^i]
};

\\ exact leaf test
deckleaf(g) =
{
  my(t = TDEG, gm = subst(g, 'x, 'x - 1));
  for (i = 0, t, if (polcoef(gm, t-i) % 2^i != 0, return(0)));
  if (subst(g, 'x, -A) == 0, return(0));
  for (j = 1, DELTA,
    my(s = signat(g, EIGQ[j][2], EIGQ[j][3], EIGQ[j][4]));
    if (s != 0 && s != (-1)^(DELTA - j), return(0)));
  1
};

{
  my(t0 = getabstime(), tot = 0, maxdeck = 0, totnodes = 0);
  for (idx = 1, #CERTS,
    my(Qc = CERTS[idx][1], Y = CERTS[idx][2], Q, FQ, FL, minp, h, b1, b2, res, deckv, hv, Yv, extra);
    Q = Pol(Qc);
    FQ = factor(subst(Q, 'x, 'x - 59));
    \\ full factorisation of p = (x+7)^377 (x-59)^16 (x-61)^15 Q(x-59)
    FL = List([['x + 7, M], ['x - 59, 16], ['x - 61, 15]]);
    for (k = 1, #FQ~,
      my(qq = FQ[k, 1], e = FQ[k, 2], found = 0);
      if (pollead(qq) < 0, qq = -qq);
      for (l = 1, #FL, if (FL[l][1] == qq, FL[l][2] += e; found = 1));
      if (!found, listput(FL, [qq, e])));
    FL = Vec(FL);
    if (sum(k = 1, #FL, poldegree(FL[k][1]) * FL[k][2]) != N, error("degree"));
    minp = prod(k = 1, #FL, FL[k][1]);
    DELTA = poldegree(minp); TDEG = DELTA - 1;
    \\ h = p'/mu = sum_k e_k q_k' prod_{l != k} q_l
    h = sum(k = 1, #FL, FL[k][2] * FL[k][1]' * minp / FL[k][1]);
    if (pollead(h) != N, error("h"));
    EIGQ = isolate(FL);
    if (#EIGQ != DELTA, error("eigen count"));
    EIGLO = vector(DELTA, j, EIGQ[j][2] - 10^(-40));
    EIGHI = vector(DELTA, j, EIGQ[j][3] + 10^(-40));
    b1 = polcoef(minp, DELTA - 1);
    b2 = polcoef(minp, DELTA - 2) + (N - 1);
    res = enumrr(TDEG, b1, b2, deckcongr, deckokD);
    deckv = select(c -> deckleaf(Pol(c)), res[1]);
    totnodes += res[2];
    if (#deckv != CERTS[idx][3], error("deck size differs for candidate ", idx - 1, ": GP ", #deckv, " vs ", CERTS[idx][3]));
    if (#Y != DELTA, error("certificate length"));
    for (j = 1, #deckv, if (Vec(Pol(deckv[j])) * Y~ < 0, error("certificate fails on a deck member, candidate ", idx - 1)));
    hv = Vec(h) * Y~;
    if (!(hv < 0), error("certificate fails on h, candidate ", idx - 1));
    tot++; maxdeck = max(maxdeck, #deckv));
  print("[3] decks recomputed for all ", tot, " candidates (", totnodes, " nodes, max deck ", maxdeck,
        "); every exported Farkas certificate is valid on the GP deck (", getabstime() - t0, " ms)");
}
print("n421.gp: no Seidel matrix of order 421 with smallest eigenvalue -7 of multiplicity 377 exists.");
quit;
