"""Negative tests for stage R (src/eqlines/star.py, RelaxedStar).

For genuine Seidel matrices S (the families of verify/triples_negative.py): members are the
distinct g_i, pair types the distinct psihat_ij.  For sampled vertices i of type f:
  * K = the true support: the true counts (n_g, and m_{g,u} seen from i) satisfy every row of
    RelaxedStar.build_relaxed(K, f) exactly, and solve_relaxed(K, f) does not certify;
  * K = the support plus a fake member F (a copy of another member's polynomial, pair types copied
    from that member, with a loop): the true counts with n_F = 0 still satisfy every row, and
    solve_relaxed does not certify.
"""

import random
import sys
import time
from pathlib import Path

from flint import fmpz_mat

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
sys.path.insert(0, str(ROOT / "verify"))
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.seidel import random_seidel  # noqa: E402
from eqlines.star import RelaxedStar  # noqa: E402
from eqlines.triples import key  # noqa: E402
from jacobi_negative import CON, clique_union_seidel, minor, psi_from_t, read_seidel  # noqa: E402


def analyse(S, label, rng, nv=4):
    n = len(S)
    sp = SpecPoly(fmpz_mat(S).charpoly())
    A = fmpz_mat(S)
    d = sp.delta
    powers = [fmpz_mat(n, n, [1 if a == b else 0 for a in range(n) for b in range(n)])]
    for _ in range(d):
        powers.append(powers[-1] * A)
    minc = [int(v) for v in reversed(sp.minp.coeffs())]
    gkey, G, typ = {}, {}, []
    for i in range(n):
        g, r = divmod(fmpz_mat(minor(S, {i})).charpoly(), sp.mu)
        assert r == 0
        k = key(g)
        if k not in gkey:
            gkey[k] = len(gkey)
            G[gkey[k]] = g
        typ.append(gkey[k])
    uhat, E = {}, {}
    for i in range(n):
        for j in range(i + 1, n):
            t = [int(powers[k][i, j]) for k in range(d)]
            u = S[i][j] * psi_from_t(minc, t)
            uhat[(i, j)] = uhat[(j, i)] = u
            a, b = min(typ[i], typ[j]), max(typ[i], typ[j])
            E.setdefault((a, b), {})[key(u)] = u
    E = {k: list(v.values()) for k, v in E.items()}
    counts = {}
    for i in range(n):
        counts[typ[i]] = counts.get(typ[i], 0) + 1
    support = sorted(counts)
    F = len(G)
    src = rng.choice(support)
    G2 = dict(G)
    G2[F] = G[src]
    E2 = dict(E)
    for g in support:
        a, b = min(src, g), max(src, g)
        E2[(g, F)] = list(E.get((a, b), [])) or [uhat[(0, 1)]]
    E2[(F, F)] = [uhat[(0, 1)]]
    checked = 0
    for i in rng.sample(range(n), min(nv, n)):
        f = typ[i]
        for K, GG, EE in ((support, G, E), (support + [F], G2, E2)):
            rs = RelaxedStar(sp, [GG[c] for c in range(max(K) + 1)], sp.h, EE)
            built = rs.build_relaxed(K, f)
            assert built is not None, (label, i, "true support is not a clique")
            rows, rhs, names, labels, bounds = built
            col = {nm: c for c, nm in enumerate(names)}
            x = [0] * len(names)
            for g in K:
                if ("n", g) in col:
                    x[col[("n", g)]] = counts.get(g, 0) - (1 if g == f else 0)
            for j in range(n):
                if j == i:
                    continue
                g = typ[j]
                ws = [key(w) for w in rs.pairs[(f, g)]]
                x[col[("m", g, ws.index(key(uhat[(i, j)])))]] += 1
            for r, (row, bb) in enumerate(zip(rows, rhs)):
                lhs = sum(c * xx for c, xx in zip(row, x) if c)
                assert lhs == bb, (label, i, labels[r], "true counts violate a row", lhs, bb)
            for j, (lo, hi) in bounds.items():
                assert lo <= x[j] <= hi, (label, i, names[j], "true count outside its bounds")
            st, _ = rs.solve_relaxed(K, f)
            assert st != "certified", (label, i, "relaxed star certified for a true vertex")
            checked += 1
    return checked, len(G)


def main():
    t0 = time.time()
    rng = random.Random(2027)
    tot = 0
    for n in range(7, 12):
        for rep in range(3):
            S = random_seidel(n, rng, rng.choice([0.3, 0.5, 0.7]))
            c, _ng = analyse(S, f"random n={n}", rng)
            tot += c
        print(f"random order {n}: OK", flush=True)
    for sizes, dels in [([2, 2, 2, 3, 3, 3, 4, 4], 0), ([2, 2, 3, 3, 3, 4, 4, 5, 5], 0),
                        ([1, 1, 1, 2, 2, 2, 3, 3, 3, 4, 4], 0), ([2, 2, 2, 3, 3, 3, 4, 4, 4], 1),
                        ([3, 3, 3, 3, 5, 5, 5], 0), ([2, 2, 2, 2, 3, 3, 3, 3, 6, 6], 2)]:
        S = clique_union_seidel(sizes, rng)
        for _ in range(dels):
            S = minor(S, {rng.randrange(len(S))})
        c, ng = analyse(S, f"clique union {sizes}", rng)
        tot += c
        print(f"clique union {sizes} minus {dels}: order {len(S)}, {ng} members, {c} systems OK",
              flush=True)
    for name, ks in [("unitary_q3_n28_d7.seidel", [3, 4, 5]), ("unitary_q5_n126_d21.seidel", [5])]:
        S0 = read_seidel(CON / name)
        n0 = len(S0)
        for k in ks:
            keep = sorted(rng.sample(range(n0), n0 - k))
            S = [[S0[i][j] for j in keep] for i in keep]
            c, ng = analyse(S, f"{name} minus {k}", rng, nv=3)
            tot += c
            print(f"{name} minus {k}: order {len(S)}, {ng} members, {c} systems OK", flush=True)
    print(f"stage R negative tests OK: {tot} systems, {time.time() - t0:.0f} s")


if __name__ == "__main__":
    main()
