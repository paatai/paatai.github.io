"""Exact verification for Claims C1 (N(44) <= 421) and C2 (single-kappa criterion).

Criterion (Theorem U in MAIN_RESULT.tex).  Let a be odd, and let S be a Seidel matrix
of order n with smallest eigenvalue -a of multiplicity n - d (so the other d
eigenvalues lam_i satisfy sum lam = a(n-d), sum lam^2 = n(n-1) - a^2(n-d)).
For an odd kappa put s = sum (lam_i - kappa), T = sum (lam_i - kappa)^2 and
gamma = n mod 2.  Let eta* = max{eta in [0, d] : eta = 0 or eta^eta 4^(eta-gamma) <= T^eta}.
Then s^2 <= eta* T.  So if s^2 > eta* T for some odd kappa, S does not exist.

Everything below is exact integer / rational arithmetic.

Usage: python3 c1_uniform.py            (C1 + the C2 table)
"""

from fractions import Fraction


def sums(a, d, n):
    m = n - d
    return a * m, n * (n - 1) - a * a * m


def eta_star(T, d, gamma):
    best = 0
    for eta in range(1, d + 1):
        if eta ** eta * 4 ** (eta - gamma) <= T ** eta:
            best = eta
    return best


def excluded_by(a, d, n, kappa):
    P1, P2 = sums(a, d, n)
    s = P1 - d * kappa
    T = P2 - 2 * kappa * P1 + d * kappa * kappa
    es = eta_star(T, d, n % 2)
    return s * s > es * T, dict(kappa=kappa, s=s, T=T, eta_star=es)


def excluded(a, d, n, span=12):
    P1, _ = sums(a, d, n)
    k0 = P1 // d
    for kappa in range(k0 - span, k0 + span + 1):
        if kappa % 2 == 1:
            ok, info = excluded_by(a, d, n, kappa)
            if ok:
                return True, info
    return False, None


def relative_bound(a, d):
    return Fraction((a * a - 1) * d, a * a - d)


def check_C1():
    a, d, n = 7, 44, 422
    P1, P2 = sums(a, d, n)
    assert (P1, P2) == (2646, 159140)
    ok61, info61 = excluded_by(a, d, n, 61)
    ok59, info59 = excluded_by(a, d, n, 59)
    assert info61["s"] == -38 and info61["T"] == 52 and info61["eta_star"] == 13
    assert ok61 and ok59
    # other angles / lower rank (published bounds, recomputed here):
    assert 2 * d < n                                   # Neumann: 1/alpha odd
    assert 2 * (d - 1) < n                             # Lemmens-Seidel, alpha = 1/3
    assert 276 < n                                     # alpha = 1/5 (Balla Thm 1.2 / Cao et al.)
    assert relative_bound(7, 43) < n                   # alpha = 1/7, rank <= 43: 344
    assert all(relative_bound(b, d) < n for b in range(9, 200, 2))  # alpha = 1/b, b >= 9
    assert relative_bound(7, 44) < 423                 # relative bound: n <= 422
    print("C1: 422 lines in R^44 excluded:", info61, info59)


def table_C2(alist=(5, 7, 9, 11, 13), print_all=False):
    rows = []
    for a in alist:
        for d in range(2, a * a - 2):
            R = relative_bound(a, d)
            n0 = int(R)
            if n0 <= 2 * d:
                continue
            if R == n0:
                continue  # integral relative bound: tight case = ETF, handled classically
            ok, info = excluded(a, d, n0)
            if ok:
                # does the bound for rank d-1 stay below n0 - 1? (needed for N_{1/a}(d) <= n0-1)
                low = int(relative_bound(a, d - 1))
                rows.append((a, d, float(R), n0, info["kappa"], info["s"], info["T"], info["eta_star"],
                             low <= n0 - 1))
    return rows


if __name__ == "__main__":
    import sys
    if "--rows" in sys.argv:
        # canonical format shared with c1_uniform.gp (smallest witness in a +-61 window)
        for a, d, _R, n0, _k, _s, _T, _e, low_ok in table_C2():
            ok, info = excluded(a, d, n0, span=61)
            assert ok
            print("ROW", a, d, n0, info["kappa"], info["s"], info["T"], info["eta_star"],
                  int(low_ok))
        print("COUNT", len(table_C2()))
        sys.exit(0)
    check_C1()
    rows = table_C2()
    print("C2 table: a d R floor(R) kappa s T eta* rank-(d-1)-ok")
    for r in rows:
        print(*r)
    print("count", len(rows))
