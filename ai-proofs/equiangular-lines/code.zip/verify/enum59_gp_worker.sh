#!/bin/bash
# Claims shards of verify/enum59.gp (16 shards, the same split as src/enum59_worker.sh) by mkdir
# locks and runs them one at a time.
cd "$(dirname "$0")/.."
N=16
mkdir -p runs/enum59_gp logs/enum59_gp
for s in $(seq 0 $((N - 1))); do
  mkdir runs/enum59_gp/lock_${s}of${N} 2>/dev/null || continue
  rm -f runs/enum59_gp/gp_s${s}of${N}.txt
  SHARD=$s NSHARD=$N CLASSES=data/P_59_7.gp OUT=runs/enum59_gp/gp_s${s}of${N}.txt \
    gp -q -f verify/enum59.gp < /dev/null > logs/enum59_gp/gp_s${s}of${N}.log 2>&1
  echo "$(date -u +%H:%M:%S) shard $s/$N rc=$?" >> logs/enum59_gp/workers.log
done
