"""Negative controls for verify/lv23_59.gp: perturbed exports of src/cert59.py must be rejected.

Usage: python3 lv23_negative.py LEAVES DECKS IDX EXPORT.json [IDX EXPORT.json ...]
  LEAVES: verify/enum59.gp leaves (psi lines); DECKS: verify/deck59.gp output containing leaf IDX;
  EXPORT.json: src/cert59.py's export of leaf IDX (must be accepted unperturbed).

Every applicable perturbation below is transcribed (verify/json2gp.py) and checked by lv23_59.gp; it
is "accepted" if the verdict starts with "excluded" with no mismatches and no failures.  The
unperturbed export must be accepted and every perturbation rejected; exit status 1 otherwise.
"""

import copy
import json
import os
import re
import subprocess
import sys
import tempfile
from fractions import Fraction

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)


def neg(v):
    return str(-Fraction(v)) if isinstance(v, str) else -v


def perturbations(d):
    out = []
    C = d["C"]
    cert = [c for c in C["cliques"] if "cert" in c]
    if cert:
        e = copy.deepcopy(d)
        c = next(c for c in e["C"]["cliques"] if "cert" in c)
        c["cert"] = [neg(v) for v in c["cert"]]
        out.append(("C certificate negated", e))
    e = copy.deepcopy(d)
    e["deck_full"] = e["deck_full"][1:]
    out.append(("deck member dropped", e))
    e = copy.deepcopy(d)
    e["h"] = e["h"][:-1] + [e["h"][-1] + 2]
    out.append(("h changed", e))
    J = d.get("J")
    if J:
        for k, v in J["pairs"].items():
            if v:
                e = copy.deepcopy(d)
                e["J"]["pairs"][k] = v[1:]
                out.append((f"J pair type of {k} dropped", e))
                break
        e = copy.deepcopy(d)
        e["J"]["members"] = e["J"]["members"][1:]
        out.append(("J member dropped", e))
    S = d.get("S")
    if S:
        for i, s in enumerate(S["supports"]):
            if s.get("status") == "certified":
                e = copy.deepcopy(d)
                t = e["S"]["supports"][i]
                t["y"] = [[lab, neg(v)] for lab, v in t["y"]]
                out.append((f"S certificate of {s['m']} negated", e))
                break
        if S["supports"]:
            e = copy.deepcopy(d)
            e["S"]["supports"] = e["S"]["supports"][1:]
            out.append(("S support record dropped", e))
    R = d.get("R")
    if R:
        e = copy.deepcopy(d)
        t = e["R"][0]["rounds"][0]["dead"][0]
        t["y"] = [[lab, neg(v)] for lab, v in t["y"]]
        out.append(("R certificate negated", e))
        e = copy.deepcopy(d)
        t = e["R"][0]["rounds"][0]["dead"][0]
        big = max(range(len(t["y"])), key=lambda r: abs(Fraction(t["y"][r][1])))
        t["y"] = t["y"][:big] + t["y"][big + 1:]
        out.append(("R largest row dropped", e))
        e = copy.deepcopy(d)
        rd = e["R"][0]["rounds"][0]
        gone = {x["f"] for x in rd["dead"]}
        left = [g for g in rd["alive"] if g not in gone]
        if left:
            rd["dead"][0]["f"] = left[0]
            out.append(("R removed member replaced by a surviving one", e))
        elif len(rd["dead"]) > 1:
            rd["dead"][0]["f"], rd["dead"][1]["f"] = rd["dead"][1]["f"], rd["dead"][0]["f"]
            out.append(("R two removed members swapped", e))
        e = copy.deepcopy(d)
        del e["R"][0]["rounds"][0]["dead"][0]
        out.append(("R removal dropped", e))
        e = copy.deepcopy(d)
        e["R"] = e["R"][1:]
        out.append(("R record dropped", e))
    L3 = d.get("L3")
    if L3 and L3.get("supports"):
        for i, s in enumerate(L3["supports"]):
            steps = s["steps"]
            for j, st in enumerate(steps):
                if "y" in st:
                    e = copy.deepcopy(d)
                    t = e["L3"]["supports"][i]["steps"][j]
                    t["y"] = [[lab, neg(v)] for lab, v in t["y"]]
                    out.append((f"L3 support {s['m']} step {j} certificate negated", e))
                    e = copy.deepcopy(d)
                    t = e["L3"]["supports"][i]["steps"][j]
                    big = max(range(len(t["y"])), key=lambda r: abs(Fraction(t["y"][r][1])))
                    t["y"] = t["y"][:big] + t["y"][big + 1:]
                    out.append((f"L3 support {s['m']} step {j} largest row dropped", e))
                    e = copy.deepcopy(d)
                    t = e["L3"]["supports"][i]["steps"][j]
                    t["edge"] = [t["edge"][0], t["edge"][1], t["edge"][2][:-1] + [t["edge"][2][-1] + 2]]
                    out.append((f"L3 support {s['m']} step {j} edge type changed", e))
                    e = copy.deepcopy(d)
                    e["L3"]["supports"][i]["steps"][j]["ntri"] += 1
                    out.append((f"L3 support {s['m']} step {j} triangle count changed", e))
                    break
            for j, st in enumerate(steps):
                if "tree" in st:
                    e = copy.deepcopy(d)
                    node = e["L3"]["supports"][i]["steps"][j]["tree"]
                    while "y" not in node:
                        node = node["le"]
                    node["y"] = [[lab, neg(v)] for lab, v in node["y"]]
                    out.append((f"L3 support {s['m']} step {j} tree leaf negated", e))
                    break
            r = s.get("reason")
            if r and r[0] == "no pair type":
                last = max(j for j, st in enumerate(steps) if sorted(st["edge"][:2]) == sorted(r[1:3]))
                e = copy.deepcopy(d)
                del e["L3"]["supports"][i]["steps"][last]
                out.append((f"L3 support {s['m']} step {last} (last on the reason pair) dropped", e))
                e = copy.deepcopy(d)
                e["L3"]["supports"][i]["reason"] = ["no pair type", r[2], r[2]] if r[1] != r[2] else ["no pair type", r[1], r[1] + 1]
                out.append((f"L3 support {s['m']} reason pair changed", e))
            if r and r[0] == "vertex stars":
                e = copy.deepcopy(d)
                e["L3"]["supports"][i]["steps"] = steps[:-1]
                out.append((f"L3 support {s['m']} last step dropped", e))
                e = copy.deepcopy(d)
                t = e["L3"]["supports"][i]
                t["star_y"] = [[lab, neg(v)] for lab, v in t["star_y"]]
                out.append((f"L3 support {s['m']} vertex-star certificate negated", e))
        e = copy.deepcopy(d)
        e["L3"]["supports"] = e["L3"]["supports"][1:]
        out.append(("L3 support record dropped", e))
    return out


def run(leaves, decks, idx, export, tmp, tag):
    expdir = os.path.join(tmp, tag)
    os.makedirs(expdir, exist_ok=True)
    src = os.path.join(expdir, "in.json")
    with open(src, "w") as fh:
        json.dump(export, fh)
    subprocess.run([sys.executable, os.path.join(HERE, "json2gp.py"), src,
                    os.path.join(expdir, f"{idx}.gp"), "EXP"], check=True)
    outf = os.path.join(expdir, "out.txt")
    env = dict(os.environ, LEAVES=leaves, DECKS=decks, EXPDIR=expdir,
               CLASSES=os.path.join(ROOT, "data", "P_58_7.gp"), OUT=outf, IDXS=f"[{idx}]")
    subprocess.run(["gp", "-q", "-f", os.path.join(HERE, "lv23_59.gp")], env=env, cwd=ROOT,
                   stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
    lines = open(outf).read().splitlines() if os.path.exists(outf) else []
    line = next((l for l in lines if l.startswith(f"leaf {idx} ")), "")
    m = re.match(r"leaf \d+ (.*?) \| p1 .*? \| mismatches (\[.*?\]) \| failures (\[.*?\]) \|", line)
    if not m:
        return False, line or "no output (GP error)"
    accepted = m.group(1).startswith("excluded") and m.group(2) == "[]" and m.group(3) == "[]"
    return accepted, line


def main():
    leaves, decks = sys.argv[1], sys.argv[2]
    args = sys.argv[3:]
    bad = 0
    with tempfile.TemporaryDirectory() as tmp:
        for t in range(0, len(args), 2):
            idx, path = int(args[t]), args[t + 1]
            with open(path) as fh:
                d = json.load(fh)
            ok, line = run(leaves, decks, idx, d, tmp, f"{idx}_base")
            print(f"leaf {idx} unperturbed: {'accepted' if ok else 'REJECTED'}")
            if not ok:
                print("   ", line)
                bad += 1
            for n, (name, e) in enumerate(perturbations(d)):
                ok, line = run(leaves, decks, idx, e, tmp, f"{idx}_{n}")
                verdict = line.split(" | ")[0] if line else ""
                print(f"leaf {idx} {name}: {'ACCEPTED' if ok else 'rejected'} ({verdict}; "
                      f"{' | '.join(line.split(' | ')[2:4])})")
                bad += ok
    print("all controls pass" if not bad else f"{bad} CONTROLS FAIL")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
