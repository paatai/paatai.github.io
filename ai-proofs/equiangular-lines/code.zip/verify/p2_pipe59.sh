#!/bin/bash
# Program 2 for the leaves of 59 lines in R^18, leaf by leaf as program 1's records appear.
#   Level 1: verify/deck59.gp on the leaf with program 1's Farkas vector (verify/p2_export.py), then
#            verify/p2_compare_l1.py (deck, h and verdict equal).
#   Levels 2, 3 (leaves that program 1 sends to level 2): src/cert59.py exports program 1's records
#            (with its exact self-check), verify/json2gp.py transcribes them, verify/lv23_59.gp
#            recomputes everything and re-checks the certificates.
# A leaf is redone when one of program 1's records is newer than program 2's output.
# Outputs: runs/p2_59/l1/s<S>/<idx>.{txt,cmp}, runs/p2_59/l23/s<S>/<idx>.txt; log logs/p2_59/pipe.log.
cd "$(dirname "$0")/.."
N=16
mkdir -p logs/p2_59
lpA() { python3 -c "import json, sys; print(json.load(open(sys.argv[1]))['lp_A'])" "$1"; }
lpB() { python3 -c "import json, sys; print(json.load(open(sys.argv[1]))['lp_B'])" "$1"; }
v2() { python3 -c "import json, sys; print(json.load(open(sys.argv[1]))['verdict'])" "$1"; }
done_() { [ -f "$1" ] && [ "$(tail -1 "$1")" = done ]; }
while true; do
  pending=0
  for s in $(seq 0 $((N - 1))); do
    leaves=runs/enum59_gp/gp_s${s}of${N}.txt
    n=$(grep -c '^\[' $leaves)
    mkdir -p runs/p2_59/l1/s$s runs/p2_59/l23/s$s/exp
    for idx in $(seq 0 $((n - 1))); do
      l1=data/level1_59/s$s/$idx.json
      o1=runs/p2_59/l1/s$s/$idx.txt
      if [ ! -f $l1 ]; then pending=$((pending + 1)); continue; fi
      if ! done_ $o1 || [ $l1 -nt $o1 ]; then
        python3 verify/p2_export.py $s > /dev/null
        rm -f $o1
        IN=$leaves CERT=runs/p2_59/certA_s$s.gp OUT=$o1 FROM=$idx TO=$idx \
          gp -q -f verify/deck59.gp < /dev/null > /dev/null 2>> logs/p2_59/gp_err.log
        python3 verify/p2_compare_l1.py $s $o1 > runs/p2_59/l1/s$s/$idx.cmp 2>&1 \
          || echo "$(date -u +%H:%M:%S) LEVEL-1 MISMATCH s$s $idx" >> logs/p2_59/pipe.log
      fi
      [ "$(lpA $l1)" = infeasible ] && continue
      if [ "$(lpB $l1)" = infeasible ]; then
        grep -q "B-ONLY s$s $idx\$" logs/p2_59/pipe.log 2>/dev/null \
          || echo "$(date -u +%H:%M:%S) B-ONLY s$s $idx" >> logs/p2_59/pipe.log
        pending=$((pending + 1)); continue
      fi
      l2=data/level2_59/s$s/$idx.json
      l3=data/level3_59/s$s/$idx.json
      if [ ! -f $l2 ]; then pending=$((pending + 1)); continue; fi
      if [ "$(v2 $l2)" = open ] && [ ! -f $l3 ]; then pending=$((pending + 1)); continue; fi
      o23=runs/p2_59/l23/s$s/$idx.txt
      if done_ $o23 && [ ! $l2 -nt $o23 ] && { [ ! -f $l3 ] || [ ! $l3 -nt $o23 ]; } && [ ! $o1 -nt $o23 ]; then
        continue
      fi
      if ! python3 src/cert59.py $s $idx >> logs/p2_59/cert59.log 2>&1; then
        echo "$(date -u +%H:%M:%S) cert59 FAILED s$s $idx" >> logs/p2_59/pipe.log
        continue
      fi
      python3 verify/json2gp.py runs/cert59/s$s/$idx.json runs/p2_59/l23/s$s/exp/$idx.gp EXP
      rm -f $o23
      LEAVES=$leaves DECKS=$o1 EXPDIR=runs/p2_59/l23/s$s/exp CLASSES=data/P_58_7.gp OUT=$o23 \
        IDXS="[$idx]" gp -q -f verify/lv23_59.gp < /dev/null > /dev/null 2>> logs/p2_59/gp_err.log
      echo "$(date -u +%H:%M:%S) s$s $(head -1 $o23 | cut -c1-200)" >> logs/p2_59/pipe.log
    done
  done
  echo "$(date -u +%H:%M:%S) pass done, pending $pending" >> logs/p2_59/pipe.log
  [ $pending = 0 ] && break
  sleep 300
done
