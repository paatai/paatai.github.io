\\ Stage X for the leaf s5/25 of 59 lines in R^18 (program 2, PARI/GP).
\\ Written from the statement of the section on s5/25 in t18_sections.tex, without the code of
\\ src/s525_59.py (program 1).  Every count is printed for comparison with program 1.
\\
\\ Part 1 (the leaf, on program 2's own records).  Leaf 25 of runs/enum59_gp/gp_s5of16.txt, its level-1
\\ deck runs/p2_59/l1/s5/25.txt (verify/deck59.gp); verify/lv23_59.gp is loaded as a library and its
\\ checkleaf re-run on program 1's export runs/p2_59/l23/s5/exp/25.gp.  Required: verdict open, no
\\ mismatch (in particular program 2's own open supports after stage S are the export's), no certificate
\\ failure, a single open support U, and level 3 leaves U open.  Then, on program 2's own deck and pair
\\ polynomials (pairpolys of verify/lv23_59.gp):
\\   sum_{f in U} n_f g_f = h has a unique solution (the system has rank |U|);
\\   with E_lambda(p) = p(lambda)/Min'(lambda): the member g40 with n = 40 has E_15 = 1/20, E_11 = 15/64,
\\   and E_theta > 0 at both roots theta of q = x^2 - 21x + 94 (trace and norm of g40/Min' in Q[x]/(q)
\\   positive, q real-rooted); the other members of U have E_15 = 0; the pair polynomials
\\   psihat = sigma psi of (g40, g40) are 6, each with e = 20 E_15(psihat) in {-1, 0, 1},
\\   psihat = tau g40 (mod q) with tau = +-1, and 64 E_11(psihat) = 4 - 4 e - tau.
\\ Part 2 (the finite statement).  A = {0..19}, cycles Z_c = (4c, 4c+1, 4c+2, 4c+3), C their adjacency
\\   matrix, P the opposite-vertex involution, beta = 5I - C - 3P, omega = (+,+,-,-) on Z_0, Z_1, Z_2 and
\\   (+,-,+,-) on Z_3, Z_4.  beta = T~ T for T in Z^(15 x 20) with the rows 2(e_0 - e_2), 2(e_1 - e_3),
\\   e_0 - e_1 + e_2 - e_3 on each Z_c; every beta-product is a dot product of the vectors z = T sigma.
\\   Profiles Pi_eps: sigma in {+-1}^20 balanced on every Z_c with |z|^2 = 128 and z.(T omega) = 32 eps.
\\   Assignments (s_1, .., s_4), s_j in Pi_{eps_j}, with Gram matrix 128 I - 64 C_4, of kind adj
\\   (eps = (+,+,-,-)) and alt (eps = (+,-,+,-)): searched as s_1, s_3 (product 0), then s_2 and s_4 among
\\   the profiles with product -64 with both, with s_2.s_4 = 0.
\\   Spans W: keyed by Q_W = 256 P_W, P_W the orthogonal projector onto T W (basis-free), and
\\   cross-checked against the Hermite normal form of the saturated lattice W cap Z^20
\\   (mathnf(matrixqz(., -2))): the two keys give the same partition of the assignments.
\\   Orthogonality: W perp_beta W' iff <Q_W, Q_W'>_F = 256^2 tr(P_W P_W') = 256^2 |P_W P_W'|_F^2 = 0.
\\   Counts: orthogonal pairs by kinds; triangles of adj spans; and, alt span by alt span, the adj spans
\\   orthogonal to it, the edges and the triangles among them.  Excluded iff no alt span is orthogonal
\\   to a pairwise orthogonal triple of adj spans.
\\
\\ Usage: gp -q -f verify/s525_59.gp      (with LEAVES unset; writes runs/p2_59/x/s5/25.txt)

if(getenv("LEAVES"), error("LEAVES must be unset: verify/lv23_59.gp would run its driver"));
\\ set before read(): a change of parisizemax inside read() resets the stack and ends the read
default(parisizemax, 2^32);
read("verify/lv23_59.gp");
if(type(checkleaf) != "t_CLOSURE", error("verify/lv23_59.gp not loaded"));

OUTX = "runs/p2_59/x/s5/25.txt";
XLOG = List();
xlog(s) = { print(s); listput(~XLOG, s); }
bitlist(n) = { my(L = List()); while(n, my(v = valuation(n, 2)); listput(~L, v); n = bitxor(n, 1 << v)); Vec(L); }

\\ ---------------------------------------------------------------- part 1
part1() = {
  my(leaves, decks, dk, psi, res, U, Sopen, F, fac, Mx, n, i40, g40, dM, q = x^2 - 21 * x + 94, E, pp,
     types, tab);
  leaves = readleaves("runs/enum59_gp/gp_s5of16.txt");
  decks = readdecks("runs/p2_59/l1/s5/25.txt");
  if(!mapisdefined(decks, 25, &dk), error("no level-1 deck for leaf 25"));
  psi = leaves[26];
  read("data/P_58_7.gp"); P58 = Set(CL);
  read("runs/p2_59/l23/s5/exp/25.gp");
  if(get(EXP, "shard") != 5 || get(EXP, "idx") != 25, error("export is not s5/25"));
  Sopen = get(get(EXP, "S"), "open");
  if(#Sopen != 1, error("export: not a single open support"));
  U = Sopen[1];
  res = checkleaf(psi, dk, EXP);
  if(res[1] != "open" || res[2] != [] || res[3] != [] || res[4] != Str("support ", U, " open at level 3"),
    error(Str("levels 2/3: ", res)));
  F = factor(CHI);
  fac = vecsort(vector(#F[, 1], i, [Vec(F[i, 1]), F[i, 2]]));
  if(fac != vecsort([[[1, 5], 41], [[1, -11], 14], [[1, -15], 2], [[1, -21, 94], 1]]), error("chi"));
  if(MIN != (x + 5) * (x - 11) * (x - 15) * q || poldisc(q) <= 0, error("Min"));
  xlog(Str("part 1: chi = (x+5)^41 (x-11)^14 (x-15)^2 (x^2-21x+94); levels 2/3 (verify/lv23_59.gp): ",
           res[1], ", mismatches ", res[2], ", failures ", res[3], ", the single open support ", U,
           " is open at level 3"));
  Mx = matrix(5, #U, r, c, Vec(GD[U[c] + 1])[r]);
  if(matrank(Mx) != #U, error("deck system rank"));
  n = matinverseimage(Mx, Vec(HH)~);
  if(#n == 0 || Mx * n != Vec(HH)~, error("deck system inconsistent"));
  n = Vec(n);
  if(vecsort(n) != [2, 17, 40], error(Str("deck counts ", n)));
  i40 = U[select(t -> n[t] == 40, [1 .. #U])[1]];
  g40 = GD[i40 + 1];
  xlog(Str("part 1: deck counts on ", U, ": n = ", n, " (unique); g40 = ", g40));
  dM = deriv(MIN);
  E = ((p, lam) -> subst(p, x, lam) / subst(dM, x, lam));
  for(t = 1, #U, my(g = GD[U[t] + 1]);
    if(U[t] == i40,
      my(r = Mod(g, q) / Mod(dM, q));
      if(E(g, 15) != 1/20 || E(g, 11) != 15/64, error("E_15, E_11 of g40"));
      if(trace(r) <= 0 || norm(r) <= 0, error("E_theta of g40")),
      if(E(g, 15) != 0, error("E_15 of the other members"))));
  xlog("part 1: g40 has E_15 = 1/20, E_11 = 15/64, E_theta > 0 at both roots of q; the other two members have E_15 = 0");
  pp = pairpolys(g40, g40);
  types = Set(vector(#pp, t, pp[t][1] * Pol(pp[t][2])));
  if(#types != 6, error(Str(#types, " pair types")));
  tab = vector(#types, t,
    my(u = types[t], e = 20 * E(u, 15), e11 = 64 * E(u, 11), tau);
    tau = if(Mod(u - g40, q) == 0, 1, if(Mod(u + g40, q) == 0, -1, error("psihat != +- g40 mod q")));
    if(e != -1 && e != 0 && e != 1, error("e"));
    if(e11 != 4 - 4 * e - tau, error("E_11 relation"));
    [e, tau, e11, u]);
  tab = vecsort(tab);
  xlog(Str("part 1: the 6 pair types of (g40, g40): (e, tau, 64 psihat(11)/Min'(11)) = ",
           vector(#tab, t, tab[t][1 .. 3])));
  for(t = 1, #tab, xlog(Str("part 1:   psihat = ", tab[t][4])));
  [n, tab];
}

\\ ---------------------------------------------------------------- part 2
\\ globals of part 2: ZZ (z-vectors of the profiles, as columns), PRO (profiles), GR (Gram), IP, IM
assign(e) = {
  my(out = List(), I = vector(4, j, if(e[j] == 1, IP, IM)));
  for(a = 1, #I[1], my(s1 = I[1][a]);
    for(c = 1, #I[3], my(s3 = I[3][c], L2, L4);
      if(GR[s1, s3] != 0, next);
      L2 = select(s -> GR[s1, s] == -64 && GR[s3, s] == -64, I[2]);
      L4 = select(s -> GR[s1, s] == -64 && GR[s3, s] == -64, I[4]);
      for(b = 1, #L2, for(d = 1, #L4,
        if(GR[L2[b], L4[d]] == 0, listput(~out, [s1, L2[b], s3, L4[d]]))))));
  Vec(out);
}

projkey(t) = {
  my(Y = matconcat(vector(3, j, ZZ[, t[j]])), G = Y~ * Y, Q);
  if(G != [128, -64, 0; -64, 128, -64; 0, -64, 128], error("Gram of s_1, s_2, s_3"));
  Q = 256 * Y * G^(-1) * Y~;
  if(denominator(Q) != 1 || Q * Q != 256 * Q || trace(Q) != 768, error("projector"));
  Q;
}

hnfkey(t) = {
  my(H = mathnf(matrixqz(matconcat(vector(4, j, PRO[t[j]]~)), -2)));
  if(matsize(H) != [20, 3], error("span of dimension != 3"));
  H;
}

part2() = {
  my(N = 20, Cm = matrix(N, N), Pm = matrix(N, N), BETA, T, OMEGA, zom, BAL, LP = List(), LM = List(),
     kinds = [["adj", [1, 1, -1, -1]], ["alt", [1, -1, 1, -1]]], REPS = vector(2),
     cnt = vector(2), shared = 0, nA, nL, nW, V, Vt, NBA, NBL, CH = 300, aa, al, la, ll, t6, x3, q6);
  for(c = 0, 4, for(t = 0, 3,
    my(i = 4 * c + t, j = 4 * c + (t + 1) % 4, k = 4 * c + (t + 2) % 4);
    Cm[i + 1, j + 1] = 1; Cm[j + 1, i + 1] = 1; Pm[i + 1, k + 1] = 1));
  BETA = 5 * matid(N) - Cm - 3 * Pm;
  T = matrix(15, N);
  for(c = 0, 4, my(r = 3 * c, o = 4 * c);
    T[r + 1, o + 1] = 2; T[r + 1, o + 3] = -2;
    T[r + 2, o + 2] = 2; T[r + 2, o + 4] = -2;
    T[r + 3, o + 1] = 1; T[r + 3, o + 2] = -1; T[r + 3, o + 3] = 1; T[r + 3, o + 4] = -1);
  if(T~ * T != BETA, error("beta != T~ T"));
  if((matid(N) - Cm / 2) * BETA / 8 * (matid(N) - Cm / 2) != matid(N) - Cm / 2, error("beta/8 is not H^+"));
  OMEGA = concat(concat(vector(3, c, [1, 1, -1, -1])), concat(vector(2, c, [1, -1, 1, -1])));
  zom = T * OMEGA~;
  if(norml2(zom) != 128, error("omega beta omega != 128"));
  BAL = select(v -> vecsum(v) == 0, vector(16, m, vector(4, t, 1 - 2 * bittest(m - 1, t - 1))));
  if(#BAL != 6, error("balanced blocks"));
  forvec(ix = vector(5, c, [1, 6]),
    my(s = concat(vector(5, c, BAL[ix[c]])), z = T * s~, d);
    if(norml2(z) != 128, next);
    d = z~ * zom;
    if(d == 32, listput(~LP, s), if(d == -32, listput(~LM, s))));
  xlog(Str("part 2: profiles |Pi_+| = ", #LP, ", |Pi_-| = ", #LM));
  PRO = concat(Vec(LP), Vec(LM));
  IP = [1 .. #LP]; IM = [#LP + 1 .. #PRO];
  ZZ = matconcat(vector(#PRO, i, T * PRO[i]~));
  GR = ZZ~ * ZZ;
  for(k = 1, 2,
    my(A = assign(kinds[k][2]), KP = Map(), HS = Map(), reps = List());
    for(i = 1, #A, my(t = A[i], Q = projkey(t), H = hnfkey(t), v);
      if(mapisdefined(KP, Q, &v),
        if(v != H, error("projector and HNF partitions differ")),
        if(mapisdefined(HS, H), error("one lattice, two projectors"));
        mapput(KP, Q, H); mapput(HS, H, Q); listput(~reps, Q)));
    REPS[k] = Vec(reps); cnt[k] = [#A, #reps];
    xlog(Str("part 2: kind ", kinds[k][1], ": ", #A, " cycle assignments, ", #reps,
             " distinct spans (all of dimension 3; projector and HNF keys agree)")));
  shared = #setintersect(Set(REPS[1]), Set(REPS[2]));
  xlog(Str("part 2: spans realized by both kinds: ", shared));
  nA = #REPS[1]; nL = #REPS[2]; nW = nA + nL;
  V = matrix(nW, 225);
  for(i = 1, nW, my(Q = if(i <= nA, REPS[1][i], REPS[2][i - nA]));
    for(k = 1, 225, V[i, k] = Q[(k - 1) % 15 + 1, (k - 1) \ 15 + 1]));
  Vt = V~;
  NBA = vector(nW); NBL = vector(nW);
  forstep(s0 = 1, nW, CH,
    my(s1 = min(nW, s0 + CH - 1), Ob = V[s0 .. s1, ] * Vt);
    for(r = 1, s1 - s0 + 1,
      my(i = s0 + r - 1, zs = select(z -> z == 0, Ob[r, ], 1), ba = 0, bl = 0);
      if(Ob[r, i] != 3 * 256^2, error("diagonal"));
      for(m = 1, #zs, my(j = zs[m]); if(j <= nA, ba = bitor(ba, 1 << (j - 1)), bl = bitor(bl, 1 << (j - nA - 1))));
      NBA[i] = ba; NBL[i] = bl));
  aa = sum(i = 1, nA, hammingweight(NBA[i]));
  al = sum(i = 1, nA, hammingweight(NBL[i]));
  la = sum(i = nA + 1, nW, hammingweight(NBA[i]));
  ll = sum(i = nA + 1, nW, hammingweight(NBL[i]));
  if(aa % 2 || ll % 2 || al != la, error("orthogonality is not symmetric"));
  xlog(Str("part 2: beta-orthogonal pairs of spans: adj-adj ", aa / 2, ", adj-alt ", al, ", alt-alt ", ll / 2));
  t6 = 0;
  for(a = 1, nA, my(Na = NBA[a], bl = bitlist(Na));
    for(m = 1, #bl, t6 += hammingweight(bitand(Na, NBA[bl[m] + 1]))));
  if(t6 % 6, error("triangle count"));
  x3 = 0; q6 = 0;
  for(l = nA + 1, nW, my(N0 = NBA[l], nb = bitlist(N0));
    for(m = 1, #nb, my(Na = bitand(N0, NBA[nb[m] + 1]), cb = bitlist(Na));
      x3 += #cb;
      for(k = 1, #cb, q6 += hammingweight(bitand(Na, NBA[cb[k] + 1])))));
  if(x3 % 2 || q6 % 6, error("alt-first counts"));
  xlog(Str("part 2: pairwise orthogonal (adj, adj, alt) triples of spans: ", x3 / 2));
  xlog(Str("part 2: pairwise orthogonal triples of adj spans: ", t6 / 6,
           "; alt spans with a pairwise orthogonal triple of adj spans orthogonal to it (counted with the triples): ",
           q6 / 6));
  [cnt, shared, [aa / 2, al, ll / 2], x3 / 2, t6 / 6, q6 / 6];
}

{
  my(t0 = getabstime(), r1, r2, verdict);
  r1 = part1();
  r2 = part2();
  verdict = if(r2[6] == 0, "excluded", "open");
  xlog(Str("s5/25: ", verdict, " (X) ", (getabstime() - t0) \ 1000, " s"));
  system("mkdir -p runs/p2_59/x/s5");
  system(Str("rm -f ", OUTX, ".tmp"));
  for(i = 1, #XLOG, write(Str(OUTX, ".tmp"), XLOG[i]));
  write(Str(OUTX, ".tmp"), "done");
  system(Str("mv ", OUTX, ".tmp ", OUTX));
}
