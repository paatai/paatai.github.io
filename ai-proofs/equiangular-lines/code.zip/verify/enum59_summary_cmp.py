"""Compare the per-shard summaries of the two 59-line enumerations.

Program 1: runs/enum59/l312_s{s}of16.jsonl (last line: {"summary": {...}}).
Program 2: runs/enum59_gp/gp_s{s}of16.txt (last line: summary [nodes, leaves, split_nodes, mine] levels [...]).
Also compares the leaf lists themselves, in order.
"""
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
N = 16


def p1(s):
    psis, summ = [], None
    with open(os.path.join(ROOT, "runs", "enum59", f"l312_s{s}of{N}.jsonl")) as fh:
        for line in fh:
            d = json.loads(line)
            if "psi" in d:
                psis.append(d["psi"])
            elif "summary" in d:
                summ = d["summary"]
    return psis, summ


def p2(s):
    psis, summ = [], None
    with open(os.path.join(ROOT, "runs", "enum59_gp", f"gp_s{s}of{N}.txt")) as fh:
        for line in fh:
            if line.startswith("["):
                psis.append(json.loads(line))
            elif line.startswith("summary"):
                m = re.match(r"summary \[(.*)\] levels \[(.*)\]", line.strip())
                a = [int(x) for x in m.group(1).split(",")]
                lv = [int(x) for x in m.group(2).split(",")]
                summ = {"nodes": a[0], "leaves": a[1], "split_nodes": a[2], "mine": a[3],
                        "level_nodes": lv}
    return psis, summ


def main():
    bad = 0
    tot = {"nodes": 0, "leaves": 0}
    for s in range(N):
        a, sa = p1(s)
        b, sb = p2(s)
        if sa is None or sb is None:
            print(f"shard {s:2d}: summary missing (p1 {sa is not None}, p2 {sb is not None})")
            bad += 1
            continue
        keys = ("nodes", "leaves", "split_nodes", "mine", "level_nodes")
        same = all(sa[k] == sb[k] for k in keys) and a == b and len(a) == sa["leaves"]
        bad += not same
        tot["nodes"] += sa["nodes"]
        tot["leaves"] += sa["leaves"]
        print(f"shard {s:2d}: {'EQUAL' if same else 'DIFFERENT'} nodes {sa['nodes']} / {sb['nodes']}, "
              f"leaves {len(a)} / {len(b)}, split nodes {sa['split_nodes']}, mine {sa['mine']}")
    print(f"total: nodes {tot['nodes']}, leaves {tot['leaves']}")
    print("ALL EQUAL" if bad == 0 else f"{bad} SHARDS DIFFER")
    return 1 if bad else 0


if __name__ == "__main__":
    sys.exit(main())
