\\ Independent PARI/GP verification of Claims C1 (N(44) <= 421) and C2 (Theorem U table).
\\ Written separately from c1_uniform.py; only integer / rational arithmetic is used.
\\
\\ Criterion (Theorem U).  a odd, S Seidel of order n, eigenvalue -a of multiplicity
\\ exactly n-d, remaining eigenvalues l_1..l_d.  For odd k let s = sum(l_i - k),
\\ T = sum (l_i - k)^2, g = n mod 2.  If eta = #{i : l_i != k} then
\\ eta = 0 or eta^eta * 4^(eta-g) <= T^eta, and s^2 <= eta*T.
\\
\\ Usage:  gp -q c1_uniform.gp      (writes the table to stdout)

\\ (P1, P2) = (sum l_i, sum l_i^2), from tr S = 0 and tr S^2 = n(n-1).
moments(a, d, n) = [a*(n-d), n*(n-1) - a^2*(n-d)];

\\ largest admissible eta in [0, d]; scanned downwards, no monotonicity assumed
etastar(T, d, g) =
{
  forstep(e = d, 1, -1, if (e^e * 4^(e-g) <= T^e, return(e)));
  0
};

\\ returns [s, T, etastar] for odd k
witness(a, d, n, k) =
{
  my(m = moments(a, d, n), s, T);
  s = m[1] - d*k;
  T = m[2] - 2*k*m[1] + d*k^2;
  [s, T, etastar(T, d, n % 2)]
};

isexcluded(a, d, n, k) = my(w = witness(a, d, n, k)); w[1]^2 > w[3]*w[2];

\\ smallest odd witness k in a wide window around the mean P1/d
minwitness(a, d, n) =
{
  my(m = moments(a, d, n), c = floor(m[1]/d), k);
  forstep(k = 2*floor((c-60)/2)+1, c+61, 2, if (isexcluded(a, d, n, k), return(k)));
  0  \\ 0 is even, so it is never a witness: means "not excluded"
};

relbound(a, d) = (a^2-1)*d/(a^2-d);

\\ ---------------- C1 ----------------
{
  my(a = 7, d = 44, n = 422, m, w, ks);
  m = moments(a, d, n);
  if (m != [2646, 159140], error("moments"));
  w = witness(a, d, n, 61);
  if (w != [-38, 52, 13], error("witness 61: ", w));
  if (!isexcluded(a, d, n, 61), error("61 does not exclude"));
  ks = [];
  forstep(k = -a, 2*a*(n-d), 2, if (isexcluded(a, d, n, k), ks = concat(ks, k)));
  if (ks != [59, 61], error("unexpected witness set ", ks));
  \\ other angles and lower rank
  if (!(2*d < n), error("Neumann"));
  if (!(2*(d-1) < n), error("1/3"));
  if (!(276 < n), error("1/5"));
  if (!(relbound(7, 43) == 344), error("rank 43"));
  \\ R(b,44) = 44 + 44*43/(b^2-44) is decreasing in b for b^2 > 44, so b = 9 suffices
  if (!(relbound(9, 44) < n), error("1/9"));
  if (!(floor(relbound(7, 44)) == 422), error("relative bound"));
  print("C1 OK: witnesses ", ks, "; kappa=61 gives [s,T,eta*] = ", w);
}

\\ ---------------- C2 table ----------------
\\ rows: a d floor(R) kappa_min s T eta* rank_ok
{
  my(cnt = 0);
  forstep(a = 5, 13, 2,
    for(d = 2, a^2-3,
      my(R = relbound(a, d), n0 = floor(R), k, w, low);
      if (n0 <= 2*d || R == n0, next);
      k = minwitness(a, d, n0);
      if (k == 0, next);
      w = witness(a, d, n0, k);
      low = floor(relbound(a, d-1));
      print("ROW ", a, " ", d, " ", n0, " ", k, " ", w[1], " ", w[2], " ", w[3], " ", if (low <= n0-1, 1, 0));
      cnt++));
  print("COUNT ", cnt);
}
quit;
