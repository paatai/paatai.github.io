"""Checks of the fast path of eqlines.rr.real_roots_or_none against the exact root isolation.

  python3 verify/test_rr_fastpath.py random          20,000 random integer polynomials (nonreal,
                                                     multiple and clustered roots): same decision
                                                     as complex_roots, and every enclosure
                                                     contains the exact root;
  python3 verify/test_rr_fastpath.py calls S/I/CAP ...   the same check on every call made while
                                                     enumerating the deck of leaf S/I (CAP nodes);
  python3 verify/test_rr_fastpath.py decks S/I ...   whole decks recomputed: members and node
                                                     counts equal to data/level1_59/s<S>/<I>.json
                                                     (computed with the old root path).
"""

import json
import os
import random
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
import eqlines.rr as rr  # noqa: E402
from flint import fmpz_poly  # noqa: E402

fast_impl = rr._simple_real_roots_certified
new = rr.real_roots_or_none


def reference(f):
    out = []
    for z, m in f.complex_roots():
        if not z.imag.is_zero():
            return None
        out.extend([z.real] * m)
    out.sort(key=lambda b: float(b.mid()))
    return out


def check(f, stats):
    a, b = new(f), reference(f)
    if b is None:
        stats["nonreal"] += 1
        assert a is None and fast_impl(f) is None, f
        return a
    stats["real"] += 1
    if f.gcd(f.derivative()).degree() > 0:
        stats["multiple"] += 1
        assert fast_impl(f) is None, f
    if fast_impl(f) is not None:
        stats["fast"] += 1
    assert a is not None and len(a) == len(b), f
    for x, y in zip(a, b):
        assert x.contains(y.mid()), (f, x, y)
    return a


def random_test():
    random.seed(1)
    stats = {"real": 0, "nonreal": 0, "fast": 0, "multiple": 0}
    for trial in range(20000):
        kind = trial % 3
        d = random.randint(1, 10)
        if kind == 0:
            f = fmpz_poly([random.randint(-60, 60) for _ in range(d)] + [random.randint(1, 5)])
        elif kind == 1:
            f = fmpz_poly([1])
            for _ in range(d):
                f *= fmpz_poly([random.randint(-12, 12), 1])
        else:
            f = fmpz_poly([1])
            for _ in range(d):
                f *= fmpz_poly([random.randint(-9, 9), random.choice([1, 2, 3])])
            if random.random() < 0.5:
                f *= fmpz_poly([random.randint(1, 30), random.randint(-3, 3), 1])
        if f.degree() >= 1:
            check(f, stats)
    print(stats, "ALL RANDOM CHECKS PASSED")


def leaf(spec):
    from eqlines.deck import SpecPoly
    from run_level1_59 import chi59, load_psis
    s, i = map(int, spec.split("/")[:2])
    psi = load_psis(os.path.join(ROOT, "runs", "enum59_gp", f"gp_s{s}of16.jsonl"))[i]
    return s, i, SpecPoly(chi59(psi))


def calls_test(specs):
    from eqlines.deck import deck
    stats = {"real": 0, "nonreal": 0, "fast": 0, "multiple": 0}
    rr.real_roots_or_none = lambda f: check(f, stats)
    for spec in specs:
        cap = int(spec.split("/")[2])
        _s, _i, sp = leaf(spec)
        t0 = time.time()
        try:
            deck(sp, nonzero_at=[-5], stats={}, max_nodes=cap)
        except RuntimeError:
            pass
        print(spec, "delta", sp.delta, stats, f"{time.time() - t0:.1f}s", flush=True)
    print("ALL CALL CHECKS PASSED")


def decks_test(specs):
    from eqlines.deck import deck
    calls = {"fast": 0, "fallback": 0}

    def counting(f):
        out = fast_impl(f)
        calls["fast" if out is not None else "fallback"] += 1
        return out

    rr._simple_real_roots_certified = counting
    bad = 0
    for spec in specs:
        s, i, sp = leaf(spec)
        with open(os.path.join(ROOT, "data", "level1_59", f"s{s}", f"{i}.json")) as fh:
            L1 = json.load(fh)
        st = {}
        calls.update(fast=0, fallback=0)
        t0 = time.time()
        D = deck(sp, nonzero_at=[-5], stats=st)
        same = sorted(map(tuple, D)) == sorted(map(tuple, L1["deck"])) and st == L1["stats"]
        bad += not same
        print(f"{spec} delta={sp.delta} deck={len(D)} same={same} nodes={st} old={L1['stats']} "
              f"t={time.time() - t0:.1f}s t_old={L1['t_deck']:.1f}s {calls}", flush=True)
    print("ALL DECKS SAME" if not bad else f"{bad} DECKS DIFFER")
    return bad


if __name__ == "__main__":
    mode, args = sys.argv[1], sys.argv[2:]
    if mode == "random":
        random_test()
    elif mode == "calls":
        calls_test(args)
    else:
        sys.exit(1 if decks_test(args) else 0)
