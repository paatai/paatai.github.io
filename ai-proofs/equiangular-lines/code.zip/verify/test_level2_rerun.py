"""Recomputes level 2 (src/level2_59.py analyse) for leaves S/I into a temporary directory and
compares the whole record, except the timing field "t", with data/level2_59/s<S>/<I>.json.

Used on 9 leaves (stages C, J and S; three open) whose stored records came from the version
before SpecPoly._isolate kept its result per precision (deployed 23:45 UTC on 2026-10-23; log
logs/validation/level2_isolate_cache_vs_old.log).
Usage: python3 verify/test_level2_rerun.py S/I [S/I ...]
"""

import json
import os
import sys
import tempfile
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
import level2_59  # noqa: E402

bad = 0
for spec in sys.argv[1:]:
    s, i = map(int, spec.split("/"))
    with open(os.path.join(ROOT, "data", "level2_59", f"s{s}", f"{i}.json")) as fh:
        old = json.load(fh)
    d1 = os.path.join(ROOT, "data", "level1_59", f"s{s}")
    with open(os.path.join(d1, f"{i}.json")) as fh:
        psi = json.load(fh)["psi"]
    out = tempfile.mkdtemp(prefix="l2rerun_")
    t0 = time.time()
    level2_59.analyse((i, psi, d1, out, 12))
    t = time.time() - t0
    with open(os.path.join(out, f"{i}.json")) as fh:
        new = json.load(fh)
    diff = [k for k in sorted(set(old) | set(new)) if k != "t" and old.get(k) != new.get(k)]
    bad += bool(diff)
    print(f"{spec} D={len(old['deck'])} verdict={new['verdict']} same={not diff} diff={diff} "
          f"t_new={t:.1f}s t_old={old['t']:.1f}s", flush=True)
print("ALL SAME" if not bad else f"{bad} DIFFER")
sys.exit(1 if bad else 0)
