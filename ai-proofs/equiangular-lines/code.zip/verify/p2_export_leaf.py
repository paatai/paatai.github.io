"""p2_export.py for one leaf: program 1's level-1 Farkas vector in GP syntax (data only).

Usage: python3 p2_export_leaf.py SHARD IDX OUT
  writes OUT with CERTA = vector(n, i, 0) and, if data/level1_59/s<SHARD>/<IDX>.json has a
  certificate on the full deck, CERTA[IDX + 1] = [...], the format of p2_export.py.  deck59.gp
  run with FROM = TO = IDX reads only that entry, so concurrent jobs on one shard need not share
  runs/p2_59/certA_s<SHARD>.gp.
"""

import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def main():
    s, idx, out = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
    with open(os.path.join(ROOT, "runs", "enum59_gp", f"gp_s{s}of16.jsonl")) as fh:
        n = sum(1 for line in fh if line.startswith('{"psi"'))
    lines = [f"CERTA = vector({n}, i, 0);"]
    with open(os.path.join(ROOT, "data", "level1_59", f"s{s}", f"{idx}.json")) as fh:
        r = json.load(fh)
    assert r["idx"] == idx
    y = r.get("farkas_A")
    if y is not None:
        lines.append(f"CERTA[{idx + 1}] = [{', '.join(str(int(v)) for v in y)}];")
    with open(out + ".tmp", "w") as fh:
        fh.write("\n".join(lines) + "\n")
    os.replace(out + ".tmp", out)


if __name__ == "__main__":
    main()
