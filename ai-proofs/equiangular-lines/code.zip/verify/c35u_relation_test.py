"""Independent check of the c35u pair relations: realise every node as an explicit vector in
span(L_a) + F (float coordinates: walk part, Cholesky coordinates of F against the reference
F-parts, and the signed residual eps*beta), recompute all inner products directly and compare
with the integer pair rule used by c35u.relations.  Also checks every node against the fixed
type-2 vectors.

usage: python3 verify/c35u_relation_test.py 74_19 012 P5,P5,C4 [--limit N]
"""
import argparse
import os
import sys

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "src"))
import c35u  # noqa: E402


def realise(inst, ctx, nodes):
    b, D = inst.base, inst.base.D
    S, Om = b.walks()
    k = ctx["k"]
    Gamma = np.array(ctx["Gt"], dtype=float) / D
    L = np.linalg.cholesky(Gamma)
    extra = 1 if k == inst.dimF - 1 else 0

    def fpart(Ct, B, eps):
        c = np.array(Ct, dtype=float) / D
        f = np.linalg.solve(L, c)
        if extra:
            beta = np.sqrt(max(B, 0) / (D * ctx["Delta"]))
            f = np.concatenate([f, [eps * beta]])
        return f

    vecs = []
    for x in nodes:
        w = Om[x["j"]].astype(float) / D
        vecs.append(np.concatenate([w, fpart(x["Ct"], x["B"], x["eps"])]))
    fixed = {}
    for nm, fv in ctx["fx"].items():
        w = fv["om"].astype(float) / D
        fixed[nm] = np.concatenate([w, fpart(fv["Ct"], 0, 0)])
    return np.array(vecs), fixed


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case")
    ap.add_argument("support")
    ap.add_argument("struct")
    ap.add_argument("--limit", type=int, default=3)
    args = ap.parse_args()
    sup = c35u.Support(args.case, args.support)
    only = tuple((s[0], int(s[1:])) for s in args.struct.split(","))
    done = 0
    for H, rows, comps, assign in c35u.enumerate_instances(sup, None, only):
        inst = c35u.Instance(sup, H, rows, comps, assign)
        if not inst.other_gram_ok():
            continue
        for ownj in inst.own_candidates():
            fx, refs = inst.setup_fixed(ownj)
            if not c35u.check_base_sum(inst, fx):
                continue
            if len(refs) < inst.dimF - 1:
                continue
            nodes, ctx = c35u.build_nodes(inst, fx, refs)
            V, fixed = realise(inst, ctx, nodes)
            # norms
            tl = ["T0", "T1b", "T1c"]
            norms = np.einsum("ij,ij->i", V, V)
            bad_norm = int(np.sum(np.abs(norms - np.array([x["N"] for x in nodes])) > 1e-6))
            # fixed vectors: norms, mutual inner products, node relations
            bad_fixed = 0
            for nm, v in fixed.items():
                if abs(v @ v - 5) > 1e-6:
                    bad_fixed += 1
                for o, w in fixed.items():
                    if o != nm and abs(v @ w - fx[nm]["ip"][o]) > 1e-6:
                        bad_fixed += 1
            bad_rel_fixed = 0
            for i, x in enumerate(nodes):
                for nm, v in fixed.items():
                    val = V[i] @ v
                    if abs(val - x["relB"][nm]) > 1e-6:
                        bad_rel_fixed += 1
            Sm, ti = c35u.relations(inst, nodes, ctx)
            G = V @ V.T
            mism = 0
            for i in range(len(nodes)):
                for j in range(len(nodes)):
                    if i == j:
                        continue
                    al = sup.allowed(tl[ti[i]], tl[ti[j]])
                    hit = [Sv for a, Sv in al.items() if abs(G[i, j] - a) < 1e-6]
                    want = hit[0] if hit else 0
                    if want != Sm[i, j]:
                        mism += 1
            print(dict(struct=args.struct, H=H["E"], assign=assign, refs=refs, k=ctx["k"], dimF=inst.dimF,
                       nodes=len(nodes), bad_norm=bad_norm, bad_fixed=bad_fixed,
                       bad_rel_fixed=bad_rel_fixed, pair_mismatches=mism,
                       compatible_pairs=int((Sm != 0).sum()) // 2))
            done += 1
            if done >= args.limit:
                return


if __name__ == "__main__":
    main()
