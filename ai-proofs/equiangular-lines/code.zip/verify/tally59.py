"""Leaf-by-leaf tally of both programs for 59 lines in R^18 (reads outputs only).

For every leaf psi of verify/enum59.gp (shards 0-15):
  enumeration: program 1 (src/enum59.py --l312) complete on the shard and equal leaf for leaf;
  program 1:   level 1 (Farkas on the full deck "L1", on the class-filtered deck "L1B"), level 2
               ("C", "J", "S"), level 3 / stage R ("L3"), stage X for a leaf open after level 3
               (src/s525_59.py: "X"), or "open" / "pending";
  program 2:   verify/deck59.gp ("L1": certificate valid, deck and h equal to program 1's),
               verify/lv23_59.gp (an "excluded ..." verdict with no mismatch and no failure), or,
               for a leaf open after level 3, verify/s525_59.gp ("X").
A leaf is DONE when both programs exclude it.  Usage: python3 tally59.py [--list] [--json=OUT]
"""

import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
N = 16


def jload(p):
    try:
        with open(p) as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def gp_leaves(s):
    with open(os.path.join(ROOT, "runs", "enum59_gp", f"gp_s{s}of{N}.txt")) as fh:
        return [json.loads(line) for line in fh if line.startswith("[")]


def p1_enum(s):
    p = os.path.join(ROOT, "runs", "enum59", f"l312_s{s}of{N}.jsonl")
    if not os.path.exists(p):
        return None, False
    leaves, done = [], False
    with open(p) as fh:
        for line in fh:
            r = json.loads(line)
            if "psi" in r:
                leaves.append(r["psi"])
            elif "time" in json.dumps(r):
                done = True
    return leaves, done


def p1_verdict(s, idx):
    L1 = jload(os.path.join(ROOT, "data", "level1_59", f"s{s}", f"{idx}.json"))
    if L1 is None:
        return "pending"
    if L1.get("F1") is not None or L1.get("F2") is not None:
        return "F"
    if L1["lp_A"] == "infeasible":
        return "L1"
    if L1["lp_B"] == "infeasible":
        return "L1B"
    L2 = jload(os.path.join(ROOT, "data", "level2_59", f"s{s}", f"{idx}.json"))
    if L2 is None:
        return "pending"
    v = L2["verdict"]
    if v.startswith("excluded"):
        return v[len("excluded ("):-1]
    L3 = jload(os.path.join(ROOT, "data", "level3_59", f"s{s}", f"{idx}.json"))
    if L3 is None:
        return "pending"
    if L3["verdict"] == "excluded":
        return "L3+R" if "R" in L3 else "L3"
    X = jload(os.path.join(ROOT, "data", "stageX_59", f"s{s}", f"{idx}.json"))
    if X is not None and X.get("verdict") == "excluded" and (X["shard"], X["idx"]) == (s, idx):
        return "X"
    return "open"


LINE = re.compile(r"leaf \d+ (.*?) \| p1 .*? \| mismatches (\[.*?\]) \| failures (\[.*?\]) \|")


def p2_verdict(s, idx):
    o1 = os.path.join(ROOT, "runs", "p2_59", "l1", f"s{s}", f"{idx}.txt")
    c1 = os.path.join(ROOT, "runs", "p2_59", "l1", f"s{s}", f"{idx}.cmp")
    try:
        lines = open(o1).read().splitlines()
    except OSError:
        return "pending"
    if not lines or lines[-1] != "done":
        return "pending"
    cmp_ = open(c1).read() if os.path.exists(c1) else ""
    if "mismatches 0" not in cmp_:
        return "L1 MISMATCH"
    if " certificate valid " in lines[0]:
        return "L1"
    if " certificate FAILS " in lines[0]:
        return "L1 CERT FAILS"
    o23 = os.path.join(ROOT, "runs", "p2_59", "l23", f"s{s}", f"{idx}.txt")
    try:
        l23 = open(o23).read().splitlines()
    except OSError:
        return "pending"
    if not l23 or l23[-1] != "done":
        return "pending"
    m = LINE.match(l23[0])
    if not m:
        return "L23 ERROR"
    if m.group(2) != "[]" or m.group(3) != "[]":
        return "L23 MISMATCH"
    v = m.group(1)
    if v.startswith("excluded"):
        return v[len("excluded ("):-1]
    if v == "open":
        try:
            lx = open(os.path.join(ROOT, "runs", "p2_59", "x", f"s{s}", f"{idx}.txt")).read().splitlines()
        except OSError:
            return v
        if lx and lx[-1] == "done" and any(t.startswith(f"s{s}/{idx}: excluded (X) ") for t in lx):
            return "X"
    return v


def main():
    show = "--list" in sys.argv
    out_json = next((a[7:] for a in sys.argv[1:] if a.startswith("--json=")), None)
    rows, tot = [], {}
    enum_ok = []
    for s in range(N):
        gl = gp_leaves(s)
        pl, done = p1_enum(s)
        if pl is None:
            es = "p1 not started"
        elif pl != gl[:len(pl)]:
            es = "p1 DIFFERS"
        elif done and len(pl) == len(gl):
            es = "equal"
        elif done:
            es = "p1 DIFFERS (complete, fewer leaves)"
        else:
            es = f"p1 running ({len(pl)}/{len(gl)}, prefix)"
        enum_ok.append(es == "equal")
        for idx in range(len(gl)):
            a, b = p1_verdict(s, idx), p2_verdict(s, idx)
            state = "DONE" if (a not in ("pending", "open") and b[:1].isupper() and b not in
                               ("pending", "open") and "MISMATCH" not in b and "FAIL" not in b
                               and "ERROR" not in b) else "-"
            rows.append({"shard": s, "idx": idx, "p1": a, "p2": b, "state": state})
        sub = [r for r in rows if r["shard"] == s]
        nd = sum(r["state"] == "DONE" for r in sub)
        print(f"shard {s:2d}: {len(gl):3d} leaves, enumeration {es}; both programs exclude {nd}")
        for r in sub:
            tot[(r["p1"], r["p2"])] = tot.get((r["p1"], r["p2"]), 0) + 1
    print("verdict pairs (program 1, program 2):")
    for k in sorted(tot, key=lambda k: -tot[k]):
        print(f"  {k[0]:>8} / {k[1]:<16} {tot[k]}")
    done = sum(r["state"] == "DONE" for r in rows)
    bad = [r for r in rows if any(t in r["p2"] for t in ("MISMATCH", "FAIL", "ERROR"))]
    opn = [r for r in rows if r["p1"] == "open" or r["p2"] == "open"]
    print(f"total {len(rows)} leaves: both programs exclude {done}; open {len(opn)}; "
          f"program 2 problems {len(bad)}; enumeration equal on {sum(enum_ok)} of {N} shards")
    if show:
        for r in opn + bad:
            print("  ", r)
    if out_json:
        with open(out_json, "w") as fh:
            json.dump({"rows": rows, "enum_equal": enum_ok}, fh)


if __name__ == "__main__":
    main()
