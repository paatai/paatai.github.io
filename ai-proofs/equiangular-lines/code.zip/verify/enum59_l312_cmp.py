"""Consistency check of the [GY19, Lemma 3.12] prefix test of src/enum59.py --l312.

The coefficients a_0..a_j of chi_{S+I} depend only on c_0..c_j, so a leaf of the run without the
prefix test passes the prefix tests iff its full a_0..a_17 pass Lemma 3.12 at every level k <= 8
(with (R), (L31), (L38) on a_0..a_17).  For each shard given, the leaves of the run with --l312 must
therefore be exactly the leaves of the run without it that pass that test.

Usage: python3 enum59_l312_cmp.py WITH.jsonl WITHOUT.jsonl [WITH2.jsonl WITHOUT2.jsonl ...]
"""
import json
import os
import sys

from flint import fmpz_poly

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
from eqlines.gy312 import check_a, plus_I_coeffs  # noqa: E402


def load(path):
    out = []
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("{") and '"psi"' in line:
                out.append(tuple(json.loads(line)["psi"]))
    return out


def chi(psi):
    p = fmpz_poly(list(reversed(psi)))
    return fmpz_poly([5, 1]) ** 41 * fmpz_poly([-11, 1]) * p(fmpz_poly([-11, 1]))


def main():
    args = sys.argv[1:]
    assert args and len(args) % 2 == 0, __doc__
    ok = True
    for w, wo in zip(args[::2], args[1::2]):
        new, old = load(w), load(wo)
        filt = [p for p in old if check_a(plus_I_coeffs(chi(p))[:18], 59, 8) is None]
        same = sorted(filt) == sorted(new) and len(set(new)) == len(new)
        ok &= same
        print(f"{os.path.basename(w)}: {len(new)} leaves; {os.path.basename(wo)}: {len(old)} leaves, "
              f"{len(filt)} pass Lemma 3.12 (k <= 8): {'EQUAL' if same else 'DIFFERENT'}")
    print("ALL EQUAL" if ok else "MISMATCH")
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
