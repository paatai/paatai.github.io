"""Level-1 interlacing decks by the derivative principle, with exact signs at eigenvalues of any
degree (no FLINT, no program 1 code; sympy is forced to its pure-Python ground types). It is a second
program for program 1's `deck` on the (-a, a^2) family candidates, and it re-checks the probe's Farkas
certificates on its own decks.

S is a putative Seidel matrix of order n with chi_S = (x + a)^(n-d) prod_v (x - v)^m_v Q(x - c),
lines with angle 1/a spanning R^d; mu_1 < ... < mu_delta are its distinct eigenvalues. For a vertex
i, chi_{S[i]} = Quo_S g with g monic of degree t = delta - 1 ([GSY21, Lemma 2.4]), and
  (T) tr S[i] = 0 and tr S[i]^2 = (n-1)(n-2) fix the power sums p1, p2 of the roots of g;
  (I) g interlaces Min_S: its roots satisfy mu_j <= nu_j <= mu_(j+1) (Cauchy);
  (R) the n-1 lines of S[i] span R^d (n-1 exceeds N(d-1)), so -a has multiplicity exactly n-1-d
      in chi_{S[i]}, and the other d eigenvalues, among them the roots of g, lie in [L, U]
      (Cauchy-Schwarz on their sum and sum of squares, as in deck_indep.py);
  (2) n-1 even: chi_{S[i]}(x-1) is type 2 [GSY21, Lemma 2.7], so Quo_S(x-1) and g(x-1) are type 2
      [GSY21, Lemma 2.8]. Type 2 is invariant under even shifts and c is odd, so G(y) = g(y + c)
      is type 2: 2^k | G_k.
So the roots of g lie in the windows [P_j, P_(j+1)], j = 1..t, where P_j is mu_j clipped to [L, U].

Enumeration of G = sum_k G_k y^(t-k) from the top, as in enum_indep.py. F_k = G^(t-k)/(t-k)!
= sum_(i<=k) C(t-i, t-k) G_i y^(k-i) has constant term G_k and F_k' = (t-k+1) F_(k-1). Necessary
conditions on F_k, given the roots rho_1 <= ... <= rho_(k-1) of F_(k-1):
  * alternation: (-1)^(k-1-j) F_k(rho_j) <= 0, F_k(B) >= 0 and (-1)^k F_k(A) >= 0, where the
    rational interval [A, B] contains [P_1, P_(t+1)] - c;
  * windows: the i-th root of G^(m) lies in [y_i, y_(i+m)], so the i-th root z_i of F_k lies in
    [P_i, P_(i+t-k+1)] - c. On [rho_(i-1), rho_i] (rho_0 = -inf, rho_k = +inf) F_k is monotone,
    increasing iff k - i is even, and contains z_i. So for rationals alpha <= P_i - c and
    beta >= P_(i+t-k+1) - c that lie strictly inside (rho_(i-1), rho_i):
    (-1)^(k-i) F_k(alpha) <= 0 and (-1)^(k-i) F_k(beta) >= 0.
Every bound on G_k uses rational enclosures and is rounded outward; a window bound is skipped when
its point cannot be placed strictly between the rho's. Every node is checked exactly (F_k has k
real roots in [A, B]); a node is dropped by the window condition only when an isolating interval
lies wholly outside its window.
Leaves: exact weak sign alternation of g at P_1..P_(t+1), which is equivalent to (I) with (R) by
the closure argument in deck_indep.py. At an eigenvalue mu whose irreducible factor f has degree
>= 2, r = g mod f is in Z[x], and r(mu) = 0 iff r = 0; otherwise the sign of r(mu) is read off an
interval evaluation on a bisected isolating interval of mu, which terminates because r(mu) != 0.

Certificates: h = chi_S'/Quo_S = sum_f e_f f' Min_S/f ([GSY21, Thm 2.3]) is computed from the
factorisation. The probe's integer Farkas vector Y is re-checked on this deck: g.Y >= 0 for every
member and h.Y < 0 (descending coefficients), so sum_g c_g g = h has no solution with c >= 0.

    python3 scripts/deck_dp.py CASE [IDX ...] [--workers N] [--l312-pass]
        no IDX: every candidate in data/probe/CASE; --l312-pass: those passing C7's filter
"""

import glob
import json
import os
import sys
import time
from fractions import Fraction
from math import comb, factorial, gcd, isqrt
from multiprocessing import Pool

# sympy would otherwise use python-flint for its integers and polynomials when it is installed
os.environ["SYMPY_GROUND_TYPES"] = "python"
import sympy  # noqa: E402
from sympy.external.gmpy import GROUND_TYPES  # noqa: E402

assert GROUND_TYPES == "python", GROUND_TYPES

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# the (-a, a^2) family cases of scripts/probe_family.py (data only; that module is not imported)
CASES = {
    "421_44": dict(n=421, d=44, a=7, forced=[(59, 16), (61, 15)], c=59),
    "287_42": dict(n=287, d=42, a=7, forced=[(41, 29)], c=41),
    "539_45": dict(n=539, d=45, a=7, forced=[(77, 32)], c=77),
    "735_46": dict(n=735, d=46, a=7, forced=[(105, 33)], c=105),
    "1127_47": dict(n=1127, d=47, a=7, forced=[(161, 34)], c=161),
    # [GSY21]: chi_S = (x+5)^(n-d) (x-kappa)^m 2^13 psi((x-kappa)/2), deg psi = 13 (program 1's U4 list)
    "74_19": dict(n=74, d=19, a=5, kappa=15, m_kappa=6, c=15, kind="psi"),
    "94_20": dict(n=94, d=20, a=5, kappa=19, m_kappa=7, c=19, kind="psi"),
}
LEVEL1_DIR = os.environ.get("LEVEL1_DIR", os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "data", "level1"))
X = sympy.Symbol("x")
EPS = Fraction(1, 2 ** 40)


# ---------- integer polynomials as descending coefficient lists ----------

def peval(p, x):
    acc = Fraction(0)
    for a in p:
        acc = acc * x + a
    return acc


def ieval(p, lo, hi):
    """Enclosure of p on [lo, hi] (interval Horner, exact rationals)."""
    rlo = rhi = Fraction(0)
    for a in p:
        cands = (rlo * lo, rlo * hi, rhi * lo, rhi * hi)
        rlo, rhi = min(cands) + a, max(cands) + a
    return rlo, rhi


def pmul(p, q):
    out = [0] * (len(p) + len(q) - 1)
    for i, a in enumerate(p):
        for j, b in enumerate(q):
            out[i + j] += a * b
    return out


def padd(p, q):
    if len(p) < len(q):
        p, q = q, p
    q = [0] * (len(p) - len(q)) + list(q)
    return [a + b for a, b in zip(p, q)]


def pderiv(p):
    t = len(p) - 1
    return [a * (t - i) for i, a in enumerate(p[:-1])]


def prem(p, f):
    """Remainder of p modulo the monic integer polynomial f."""
    r = list(p)
    k = len(f) - 1
    while len(r) > k:
        lead = r[0]
        for i in range(len(f)):
            r[i] -= lead * f[i]
        assert r[0] == 0
        r.pop(0)
    return r


def taylor(p, s):
    """Descending coefficients of p(x + s)."""
    t = len(p) - 1
    out = [0] * (t + 1)
    for j, a in enumerate(p):
        k = t - j
        for i in range(k + 1):
            out[t - i] += a * comb(k, i) * s ** (k - i)
    return out


def is_type2(p):
    return all(a % (1 << i) == 0 for i, a in enumerate(p))


def sgn(v):
    return (v > 0) - (v < 0)


def floor_frac(v):
    return v.numerator // v.denominator


def ceil_frac(v):
    return -((-v.numerator) // v.denominator)


# ---------- eigenvalues ----------

def bisect(e):
    """Halve the isolating interval of the irrational eigenvalue e (a root of e['f'])."""
    f, lo, hi = e["f"], e["lo"], e["hi"]
    mid = (lo + hi) / 2
    vm = peval(f, mid)
    assert vm != 0
    if sgn(vm) == sgn(peval(f, lo)):
        e["lo"] = mid
    else:
        e["hi"] = mid


def _add(fac, p, e):
    key = tuple(int(v) for v in p)
    assert key[0] == 1
    fac[key] = fac.get(key, 0) + e


def factor_S(cfg, Qc):
    """{f: e}: the factorisation of chi_S into monic irreducibles over Z."""
    if cfg.get("kind") == "psi":
        return factor_S_psi(cfg, Qc)
    r = sympy.Symbol("r")
    fac = {}
    _add(fac, [1, cfg["a"]], cfg["n"] - cfg["d"])
    for v, mv in cfg["forced"]:
        _add(fac, [1, -v], mv)
    for f, e in sympy.Poly(list(Qc), r).factor_list()[1]:
        _add(fac, taylor([int(v) for v in f.all_coeffs()], -cfg["c"]), int(e))
    return fac


def factor_S_psi(cfg, psi):
    """chi_S = (x + a)^(n-d) (x - kappa)^m 2^13 psi((x - kappa)/2): each monic factor f(y) of psi
    of degree k becomes 2^k f((x - kappa)/2) = sum_j f_j 2^j (x - kappa)^(k-j)."""
    y = sympy.Symbol("y")
    kappa = cfg["kappa"]
    fac = {}
    _add(fac, [1, cfg["a"]], cfg["n"] - cfg["d"])
    _add(fac, [1, -kappa], cfg["m_kappa"])
    assert len(psi) == 14 and psi[0] == 1
    for f, e in sympy.Poly([int(v) for v in psi], y).factor_list()[1]:
        fc = [int(v) for v in f.all_coeffs()]
        k = len(fc) - 1
        px = [0]
        for j, cj in enumerate(fc):
            px = padd(px, [cj * 2 ** j * v for v in binom_power(-kappa, k - j)])
        _add(fac, px, int(e))
    assert sum(e * (len(f) - 1) for f, e in fac.items()) == cfg["n"]
    return fac


def factor_member(fac_S, g):
    """{f: e} for chi_{S[i]} = Quo_S g."""
    fac = {}
    for f, e in fac_S.items():
        if e > 1:
            _add(fac, f, e - 1)
    for f, e in sympy.Poly(list(g), X).factor_list()[1]:
        _add(fac, [int(v) for v in f.all_coeffs()], int(e))
    return fac


def eigenvalues(fac):
    """The distinct eigenvalues, sorted, each with its irreducible factor f and a rational
    isolating interval [lo, hi] of width < EPS (lo = hi when rational)."""
    eig = []
    for f in fac:
        if len(f) == 2:
            eig.append(dict(f=f, lo=Fraction(-f[1]), hi=Fraction(-f[1])))
            continue
        ivs = sympy.Poly(list(f), X).intervals()
        assert len(ivs) == len(f) - 1 and all(m == 1 for _, m in ivs), "non-real eigenvalue"
        for (lo, hi), _ in ivs:
            lo, hi = Fraction(int(lo.p), int(lo.q)), Fraction(int(hi.p), int(hi.q))
            assert lo < hi and sgn(peval(f, lo)) * sgn(peval(f, hi)) < 0
            eig.append(dict(f=f, lo=lo, hi=hi))
    while True:
        eig.sort(key=lambda e: e["lo"])
        clash = [i for i in range(len(eig) - 1) if eig[i]["hi"] >= eig[i + 1]["lo"]]
        if not clash:
            break
        for i in clash:
            for e in (eig[i], eig[i + 1]):
                if e["lo"] < e["hi"]:
                    bisect(e)
    for e in eig:
        while e["hi"] - e["lo"] >= EPS:
            bisect(e)
    return eig


def compare_point(e, v):
    """Sign of mu_e - v for a rational v (mu_e != v unless mu_e is that rational)."""
    while True:
        if e["lo"] == e["hi"]:
            return sgn(e["lo"] - v)
        if e["hi"] < v:
            return -1
        if e["lo"] > v:
            return 1
        bisect(e)


def sign_at(g, pt):
    """Exact sign of g at a clipped point: ('rat', v) or ('eig', e)."""
    if pt[0] == "rat":
        return sgn(peval(g, pt[1]))
    e = dict(pt[1])
    if e["lo"] == e["hi"]:
        return sgn(peval(g, e["lo"]))
    rr = prem(g, list(e["f"]))
    if not any(rr):
        return 0
    while True:
        vlo, vhi = ieval(rr, e["lo"], e["hi"])
        if vlo > 0:
            return 1
        if vhi < 0:
            return -1
        bisect(e)


def pt_lo(pt):
    return pt[1] if pt[0] == "rat" else pt[1]["lo"]


def pt_hi(pt):
    return pt[1] if pt[0] == "rat" else pt[1]["hi"]


# ---------- real roots of the F_k ----------

def real_roots(p, A, B):
    """None unless every root of p is real and in [A, B] (exact: square-free factorisation and
    Sturm counts on the closed interval); else isolating intervals of width < EPS, repeated by
    multiplicity, sorted."""
    P = sympy.Poly(p, X)
    sa = sympy.Rational(A.numerator, A.denominator)
    sb = sympy.Rational(B.numerator, B.denominator)
    if sum(k * f.count_roots(sa, sb) for f, k in P.sqf_list()[1]) != P.degree():
        return None
    out = []
    for (lo, hi), mult in P.intervals(eps=sympy.Rational(EPS.numerator, EPS.denominator)):
        out.extend([(Fraction(int(lo.p), int(lo.q)), Fraction(int(hi.p), int(hi.q)))] * mult)
    assert len(out) == P.degree()
    out.sort()
    return out


# ---------- the deck ----------

# upper bounds on N(d-1) for the case's d (probe_family.py's table; N(18) <= 59 [GS24], N(19) <= 74
# [GSY21]): a principal submatrix of order n1 > N_PREV still spans R^d, which justifies (R)
N_PREV = {"421_44": 344, "287_42": 276, "539_45": 422, "735_46": 540, "1127_47": 736,
          "74_19": 59, "94_20": 74}
KMAX = 12  # Lemma 3.12 is applied for k <= KMAX (C7's filter at level 2)


def weakly_type2(p):
    return all(a % (1 << (i - 1)) == 0 for i, a in enumerate(p) if i >= 1)


def binom_power(u, k):
    """Descending coefficients of (x + u)^k."""
    return [comb(k, i) * u ** i for i in range(k + 1)]


def setup(fac, cfg, case, kmax=KMAX, box=True):
    """The deck of a Seidel matrix of order N with chi = prod f^e: members g = chi_{M[j]}/Quo of
    the principal submatrices M[j], of order n1 = N - 1. box=False replaces (R) by its first half
    only, g(-a) != 0 (program 1's D6 without D7), so that the windows are [mu_j, mu_(j+1)] with
    a strict sign condition at mu_1 = -a; kmax bounds the k of Lemma 3.12 (odd n1)."""
    d, a, c = cfg["d"], cfg["a"], cfg["c"]
    N = sum(e * (len(f) - 1) for f, e in fac.items())
    n1 = N - 1
    assert n1 > N_PREV[case] and c % 2 == 1
    eig = eigenvalues(fac)
    delta = len(eig)
    assert delta == sum(len(f) - 1 for f in fac)
    t = delta - 1
    assert eig[0]["lo"] == eig[0]["hi"] == -a
    q1 = q2 = 0
    for f, e in fac.items():
        if e > 1:
            f1 = f[1]
            f2 = f[2] if len(f) > 2 else 0
            q1 += (e - 1) * (-f1)
            q2 += (e - 1) * (f1 * f1 - 2 * f2)
    p1 = -q1
    p2 = n1 * (n1 - 1) - q2
    P1 = a * (n1 - d)
    P2 = n1 * (n1 - 1) - a * a * (n1 - d)
    rr = isqrt((d - 1) * (d * P2 - P1 * P1)) + 1
    L, U = Fraction(P1 - rr, d), Fraction(P1 + rr, d)
    if box:
        assert L > -a and compare_point(eig[1], L) > 0 and compare_point(eig[-2], U) < 0
        pts = [("rat", L)] + [("eig", e) for e in eig[1:-1]]
        pts.append(("rat", U) if compare_point(eig[-1], U) > 0 else ("eig", eig[-1]))
    else:
        pts = [("rat", Fraction(-a))] + [("eig", e) for e in eig[1:]]
    h = [0]
    for f, e in fac.items():
        rest = [1]
        for f2 in fac:
            if f2 != f:
                rest = pmul(rest, list(f2))
        h = padd(h, [e * v for v in pmul(pderiv(list(f)), rest)])
    assert len(h) == delta and h[0] == N
    # Quo(x - 1), exactly
    quo1 = [1]
    for f, e in sorted(fac.items(), key=lambda kv: -kv[1]):
        if e > 1:
            f1 = taylor(list(f), -1)
            if len(f1) == 2:
                quo1 = pmul(quo1, binom_power(f1[1], e - 1))
            else:
                for _ in range(e - 1):
                    quo1 = pmul(quo1, f1)
    assert len(quo1) == n1 - t + 1
    if n1 % 2 == 0:     # chi_{M[j]}(x-1) type 2: both factors type 2 [GSY21, Lemmas 2.7, 2.8]
        ok, strong = is_type2(quo1), True
    else:               # weakly type 2: both weakly, and g(x-1) type 2 unless Quo(x-1) is
        ok, strong = weakly_type2(quo1), not is_type2(quo1)
    s1 = p1 - t * c
    s2 = p2 - 2 * c * p1 + t * c * c
    S = dict(N=N, n1=n1, t=t, delta=delta, pts=pts, h=h, ok=ok, strong=strong, s1=s1, s2=s2,
             L=L, U=U, c=c, fac={",".join(map(str, f)): e for f, e in fac.items()},
             strict_first=not box, kmax=kmax)
    if n1 % 2 == 1:
        mod = 1 << (n1 + 2)
        S["quo1_mod"] = [v % mod for v in quo1]
        S["quo1_top"] = (quo1 + [0] * (2 * kmax + 2))[:2 * kmax + 2]
    return S


# ---------- odd order: [GSY21, Thm 2.5] on the full product, and [GY19, Lemma 3.12] ----------

def thm25_ok(quo1_mod, g1, n1):
    """chi_{M[j]}(x-1) = Quo(x-1) g(x-1) = sum a_i x^(n1-i) with n1 odd: a_0 = 1, a_1 = -n1,
    a_2 = 0, 2^(i-1) | a_i for odd i and 2^i | a_i for even i [GSY21, Thm 2.5]. Computed
    modulo 2^(n1+2), which decides every condition."""
    mod = 1 << (n1 + 2)
    prod = [0] * (len(quo1_mod) + len(g1) - 1)
    for j, b in enumerate(g1):
        if b:
            for i, a in enumerate(quo1_mod):
                prod[i + j] += a * b
    if prod[0] != 1 or (prod[1] + n1) % mod or prod[2] % mod:
        return False
    for i in range(3, len(prod)):
        need = i - 1 if i % 2 else i
        if prod[i] % (1 << need):
            return False
    return True


def _phi(m):
    return sum(1 for j in range(1, m + 1) if gcd(j, m) == 1)


def _partitions(n, maxpart):
    if n == 0:
        yield {}
        return
    for p in range(min(n, maxpart), 0, -1):
        for rest in _partitions(n - p, p):
            r = dict(rest)
            r[p] = r.get(p, 0) + 1
            yield r


_L312_TERMS = {}


def l312_terms(k):
    """(C_d(m), parts) over d | 2k and partitions m of d with m_(2k) = 0 [GY19, Lemma 3.12]."""
    if k not in _L312_TERMS:
        terms = []
        tk = 2 * k
        for d in range(1, tk + 1):
            if tk % d:
                continue
            for m in _partitions(d, d):
                if m.get(tk, 0):
                    continue
                tot = sum(m.values())
                den = 1
                for v in m.values():
                    den *= factorial(v)
                coef = Fraction(2 ** tk * d * _phi(tk // d) * factorial(tot - 1), tk * den)
                terms.append((coef, tuple(sorted(m.items()))))
        _L312_TERMS[k] = terms
    return _L312_TERMS[k]


def v2(v):
    v = abs(v)
    return (v & -v).bit_length() - 1


def l312_svals(a, N, D):
    """[s_0 (unused), s_1, ..., s_D]: s_(2j) = a_(2j+1)/(2^(2j) N) and
    s_(2j-1) = (a_(2j+1) + a_(2j) + a_(2j-1) a_3)/2^(2j-1) [GY19, Lemma 3.12]; uses a_0..a_(D+1)."""
    s = [Fraction(0)] * (D + 1)
    for i in range(1, D + 1):
        if i % 2 == 0:
            s[i] = Fraction(a[i + 1], (1 << i) * N)
        else:
            s[i] = Fraction(a[i + 2] + a[i + 1] + a[i] * a[3], 1 << i)
    return s


def l312_rhs_partition(s, k):
    """sum_(d|2k) sum_(m partition of d, m_(2k) = 0) C_d(m) P_d(m), term by term."""
    rhs = Fraction(0)
    for coef, parts in l312_terms(k):
        term = coef
        for p, mlt in parts:
            term *= s[p] ** mlt
        rhs += term
    return rhs


def neglog_coeffs(s, D):
    """w_1..w_D of -log(1 - u(t)) = sum_d w_d t^d with u = sum_(i<=D) s_i t^i. By the exponential
    formula w_d = sum over partitions m of d of (|m| - 1)!/prod m_i! prod s_i^(m_i), the inner sum
    of Lemma 3.12. Computed from (1 - u) w' = u': d w_d = d s_d + sum_(i<d) (d - i) s_i w_(d-i)."""
    w = [Fraction(0)] * (D + 1)
    for dd in range(1, D + 1):
        acc = dd * s[dd]
        for i in range(1, dd):
            if s[i]:
                acc += (dd - i) * s[i] * w[dd - i]
        w[dd] = acc / dd
    return w


def l312_rhs_series(w, s, k):
    """The same sum from w: the only partition of 2k with a part 2k is {2k}, whose term is s_(2k)."""
    tk = 2 * k
    rhs = Fraction(0)
    for d in range(1, tk + 1):
        if tk % d == 0:
            Ld = w[d] - (s[tk] if d == tk else 0)
            rhs += Fraction((1 << tk) * d * _phi(tk // d), tk) * Ld
    return rhs


def l312_first_fail(a, N, kmax, method="series"):
    """chi_{S+I} = sum a_i x^(N-i), N odd: the first k in 2..kmax (2k+1 <= N) where
    a_(2k+1) = sum_(d|2k) sum_m C_d(m) P_d(m) (mod 2^(2k+1)) fails [GY19, Lemma 3.12]; None if
    none. method "partition": the literal partition sum; "series": the same sum through
    neglog_coeffs. The congruence is tested as v_2(lhs - rhs) >= 2k+1 in exact rationals (an even
    denominator counts as a failure)."""
    kmax = min(kmax, (N - 1) // 2)
    k, top = 2, 3
    while k <= kmax:
        top = min(kmax, 2 * top)
        D = 2 * top
        s = l312_svals(a, N, D)
        w = neglog_coeffs(s, D) if method == "series" else None
        for kk in range(k, top + 1):
            rhs = l312_rhs_series(w, s, kk) if method == "series" else l312_rhs_partition(s, kk)
            diff = a[2 * kk + 1] - rhs
            if diff.numerator != 0 and (v2(diff.numerator) - v2(diff.denominator) < 2 * kk + 1):
                return kk
        k = top + 1
    return None


def F_coeffs(G, k, t):
    return [comb(t - i, t - k) * G[i] for i in range(k + 1)]


def windows_ok(Z, m, t, alpha, beta):
    """False only if some isolating interval of a root of F_m lies wholly outside its window."""
    for i in range(1, m + 1):
        lo, hi = Z[i - 1]
        if hi < alpha[i] or lo > beta[i + t - m + 1]:
            return False
    return True


def children(G, rho, k, t, A, B, alpha, beta, strong):
    K = F_coeffs(G + [0], k, t)
    lo_b, hi_b = None, None

    def upper(v):
        nonlocal hi_b
        hi_b = v if hi_b is None else min(hi_b, v)

    def lower(v):
        nonlocal lo_b
        lo_b = v if lo_b is None else max(lo_b, v)

    for j, (l, u) in enumerate(rho, start=1):
        klo, khi = ieval(K, l, u)
        if (k - 1 - j) % 2 == 0:
            upper(floor_frac(-klo))
        else:
            lower(ceil_frac(-khi))
    lower(ceil_frac(-peval(K, B)))
    if k % 2 == 0:
        lower(ceil_frac(-peval(K, A)))
    else:
        upper(floor_frac(-peval(K, A)))
    for i in range(1, k + 1):
        left = rho[i - 2][1] if i >= 2 else None
        right = rho[i - 1][0] if i <= k - 1 else None
        inc = (k - i) % 2 == 0

        def inside(p):
            return (left is None or p > left) and (right is None or p < right)

        al, be = alpha[i], beta[i + t - k + 1]
        if inside(al):      # (-1)^(k-i) F_k(al) <= 0
            v = peval(K, al)
            (upper(floor_frac(-v)) if inc else lower(ceil_frac(-v)))
        if inside(be):      # (-1)^(k-i) F_k(be) >= 0
            v = peval(K, be)
            (lower(ceil_frac(-v)) if inc else upper(floor_frac(-v)))
    if lo_b is None or hi_b is None or lo_b > hi_b:
        return []
    s = 1 << (k if strong else k - 1)
    first = -((-lo_b) // s) * s
    return list(range(first, hi_b + 1, s))


def top_mul(p, q, T):
    """The first T descending coefficients of p q (p given to at least T coefficients)."""
    return [sum(p[i - j] * q[j] for j in range(min(i, len(q) - 1) + 1)) for i in range(T)]


def deck(S):
    """(raw, filtered, stats). raw: the members with (T), (I), (R), (2), and for odd n1 also
    [GSY21, Thm 2.5] on the full product. filtered: for odd n1, those passing [GY19, Lemma 3.12]
    for k <= S['kmax'] (C7's filter); for even n1 the same as raw. stats['first_fail'][j] is the
    first failing k of raw[j] (None: passes)."""
    t, c, pts, n1, kmax = S["t"], S["c"], S["pts"], S["n1"], S["kmax"]
    stats = dict(t=t, delta=S["delta"], nodes=0, leaves=0, l312_removed={}, first_fail=[])
    if not S["ok"] or (S["s1"] ** 2 - S["s2"]) % 2:
        return [], [], stats
    strong = S["strong"]
    G = [1, -S["s1"], (S["s1"] ** 2 - S["s2"]) // 2]
    if G[1] % (2 if strong else 1) or G[2] % (4 if strong else 2):
        return [], [], stats
    A = pt_lo(pts[0]) - c
    B = pt_hi(pts[-1]) - c
    alpha = [None] + [pt_lo(p) - c for p in pts]
    beta = [None] + [pt_hi(p) - c for p in pts]
    want = [(-1) ** (t + 1 - j) for j in range(1, t + 2)]
    found = []

    def leaf(Gfull):
        stats["leaves"] += 1
        Z = real_roots(F_coeffs(Gfull, t, t), A, B)
        if Z is None or not windows_ok(Z, t, t, alpha, beta):
            return
        g = taylor(Gfull, -c)
        if S["strict_first"] and sign_at(g, pts[0]) == 0:
            return
        if not all(w * sign_at(g, p) >= 0 for w, p in zip(want, pts)):
            return
        if n1 % 2 == 0:
            found.append((g, None))
            return
        g1 = taylor(g, -1)
        if not thm25_ok(S["quo1_mod"], g1, n1):
            return
        found.append((g, l312_first_fail(top_mul(S["quo1_top"], g1, 2 * kmax + 2), n1, kmax)))

    if t == 2:
        leaf(G)
    else:
        stack = [(G, 3)]
        while stack:
            Gp, k = stack.pop()
            stats["nodes"] += 1
            rho = real_roots(F_coeffs(Gp, k - 1, t), A, B)
            if rho is None or not windows_ok(rho, k - 1, t, alpha, beta):
                continue
            for v in children(Gp, rho, k, t, A, B, alpha, beta, strong):
                if k == t:
                    leaf(Gp + [v])
                else:
                    stack.append((Gp + [v], k + 1))
    found.sort(key=lambda gk: gk[0])
    for _, kf in found:
        stats["first_fail"].append(kf)
        if kf is not None:
            key = f"k={kf}"
            stats["l312_removed"][key] = stats["l312_removed"].get(key, 0) + 1
    return [g for g, _ in found], [g for g, kf in found if kf is None], stats


def check_cert(dk, h, Y):
    """Farkas: g.Y >= 0 for every member and h.Y < 0 (exact integers)."""
    Y = [int(v) for v in Y]
    assert len(Y) == len(h) and all(len(g) == len(Y) for g in dk)
    ok_members = all(sum(a * b for a, b in zip(g, Y)) >= 0 for g in dk)
    hY = sum(a * b for a, b in zip(h, Y))
    return ok_members and hY < 0, ok_members, hY


def load_json(path):
    if not os.path.exists(path):
        return None
    with open(path) as fh:
        return json.load(fh)


def run_one(args):
    case, idx = args
    cfg = CASES[case]
    lvl1 = load_json(os.path.join(ROOT, "data", "probe", case, f"{idx}.json"))
    t0 = time.time()
    S = setup(factor_S(cfg, lvl1["Q"]), cfg, case)
    dk, _, st = deck(S)
    theirs = sorted(lvl1["deck"])
    res = dict(idx=idx, t=st["t"], delta=st["delta"], nodes=st["nodes"], leaves=st["leaves"],
               deck_size=len(dk), prog1_size=len(theirs), identical=(dk == theirs),
               only_here=len(set(map(tuple, dk)) - set(map(tuple, theirs))),
               only_prog1=len(set(map(tuple, theirs)) - set(map(tuple, dk))),
               probe_lp=lvl1["lp"], h=S["h"], deck=dk)
    Y = lvl1.get("farkas")
    if not dk:
        res["verdict"] = "empty deck (infeasible: h != 0)"
    elif Y is None:
        res["verdict"] = "no certificate in the probe"
    else:
        ok, ok_members, hY = check_cert(dk, S["h"], Y)
        res["verdict"] = ("infeasible (probe certificate valid on this deck)" if ok else
                          f"certificate FAILS (members ok: {ok_members}, h.Y = {hY})")
    res["seconds"] = round(time.time() - t0, 2)
    return res


def run_member(args):
    """Level 2: the deck of M = S[i] for a vertex i whose level-1 member is lvl1['deck'][k]
    (program 1's order, as in probe_level2.py and level2_member.py)."""
    case, idx, k = args
    cfg = CASES[case]
    ddir = os.path.join(ROOT, "data", "probe", case)
    lvl1 = load_json(os.path.join(ddir, f"{idx}.json"))
    e = lvl1["deck"][k]
    t0 = time.time()
    S = setup(factor_member(factor_S(cfg, lvl1["Q"]), e), cfg, case)
    raw, filt, st = deck(S)
    res = dict(idx=idx, member=k, g=e, order=S["N"], t=st["t"], strong=S["strong"],
               nodes=st["nodes"], leaves=st["leaves"], raw_size=len(raw), size=len(filt),
               l312_removed=st["l312_removed"], h=S["h"], deck=filt, compare={}, certs={})
    # stored outputs of program 1 (program 1's deck, C7's filter, program 1's LP)
    m1 = load_json(os.path.join(ddir, f"level2_member_{idx}_{k}_nogy19.json"))
    if m1:
        res["compare"]["raw deck = level2_member nogy19 deck"] = sorted(m1["deck"]) == raw
    m2 = load_json(os.path.join(ddir, f"level2_member_{idx}_{k}.json"))
    if m2:
        res["compare"]["filtered deck = level2_member deck"] = sorted(m2["deck"]) == filt
        res["compare"]["h = level2_member h"] = m2["h"] == S["h"]
        if m2.get("certificate"):
            res["certs"]["level2_member"] = m2["certificate"]
    ci = load_json(os.path.join(ddir, f"ci_{idx}_{k}.json"))
    if ci:
        res["compare"]["filtered deck = ci cache deck"] = sorted(ci["deck"]) == filt
        res["compare"]["raw size = ci cache raw"] = ci["raw"] == len(raw)
        res["compare"]["h = ci cache h"] = ci["h"] == S["h"]
    pl = load_json(os.path.join(ddir, f"level2_{idx}_gy19.json"))
    if pl and str(k) in pl["members"]:
        mem = pl["members"][str(k)]
        res["compare"]["sizes = probe_level2 (raw, filtered)"] = (
            (mem.get("deck_size_raw"), mem.get("deck_size")) == (len(raw), len(filt)))
        res["probe_level2_verdict"] = mem.get("verdict")
        if mem.get("cert"):
            res["certs"]["probe_level2"] = mem["cert"]
    if not filt:
        res["verdict"] = "infeasible (empty filtered deck)"
    elif res["certs"]:
        outs = {}
        for src, Y in res["certs"].items():
            ok, ok_members, hY = check_cert(filt, S["h"], Y)
            outs[src] = "valid" if ok else f"FAILS (members ok: {ok_members}, h.Y = {hY})"
        res["cert_check"] = outs
        res["verdict"] = ("infeasible (certificate valid on this deck)"
                          if all(v == "valid" for v in outs.values()) else "certificate FAILS")
    else:
        res["verdict"] = "no certificate stored"
    res["seconds"] = round(time.time() - t0, 2)
    return res


T3_KMAX = {"74_19": 36, "94_20": 46}  # (n1 - 1)/2: Lemma 3.12 in full for members of order n1


def run_t3(args):
    """Target 3, level 1: the deck of the candidate psi of 74/R^19 or 94/R^20 (members of odd
    order 73, resp. 93), built from psi alone with (R) reduced to g(-5) != 0, compared with
    program 1's U4 output (deck, P_(n-1,7) flags, Farkas vectors A and B) and with C7(c), (d)."""
    case, idx = args
    cfg = CASES[case]
    L = load_json(os.path.join(LEVEL1_DIR, case, f"{idx}.json"))
    psi = json.loads(L["psi"]) if isinstance(L["psi"], str) else L["psi"]
    t0 = time.time()
    fac = factor_S_psi(cfg, psi)
    S = setup(fac, cfg, case, kmax=T3_KMAX[case], box=False)
    raw, filt, st = deck(S)
    k3 = [g for g, kf in zip(raw, st["first_fail"]) if kf is None or kf > 3]
    cls = sorted(g for g, ok in zip(L["deck"], L["class_ok"]) if ok)
    res = dict(case=case, idx=idx, psi=psi, t=st["t"], nodes=st["nodes"], leaves=st["leaves"],
               raw_size=len(raw), k3_size=len(k3), size=len(filt), l312_removed=st["l312_removed"],
               h=S["h"], deck=raw, first_fail=st["first_fail"], compare={}, certs={})
    res["compare"]["factorisation = U4 factors"] = (
        sorted(fac.items()) == sorted((tuple(f), e) for f, e in L["factors"]))
    res["compare"]["h = U4 h"] = S["h"] == L["h"]
    res["compare"]["raw deck = U4 deck"] = raw == sorted(L["deck"])
    res["compare"]["k<=3 deck = U4 P_(n-1,7) members"] = k3 == cls
    if L.get("farkas_A") is not None:
        res["certs"]["U4 A on raw deck"] = check_cert(raw, S["h"], L["farkas_A"])[0]
    if L.get("farkas_B") is not None:
        res["certs"]["U4 B on k<=3 deck"] = check_cert(k3, S["h"], L["farkas_B"])[0]
    res["u4_lp"] = [L["lp_A"], L["lp_B"]]
    if not raw:
        res["u4_here"] = "excluded (empty deck)"
    elif res["certs"].get("U4 A on raw deck") or res["certs"].get("U4 B on k<=3 deck"):
        res["u4_here"] = "excluded (U4 certificate valid on this deck)"
    else:
        res["u4_here"] = "not excluded at U4's level"
    pr = load_json(os.path.join(ROOT, "data", "probe", f"t3_{case}", f"{idx}.json"))
    if pr is not None:
        res["compare"]["full-filter deck = C7 probe kept_deck"] = filt == sorted(pr["kept_deck"])
        mine = {}
        for kf in st["first_fail"]:
            key = "ok" if kf is None else f"k={kf}"
            mine[key] = mine.get(key, 0) + 1
        res["compare"]["first-failing-k counts = C7 probe"] = mine == pr["member_status"]
        if pr.get("certificate"):
            res["certs"]["C7 probe on full-filter deck"] = check_cert(filt, S["h"], pr["certificate"])[0]
        res["c7_probe_verdict"] = pr["verdict"]
    res["seconds"] = round(time.time() - t0, 2)
    return res


def main_t3(case, idxs, workers):
    t0 = time.time()
    if not idxs:
        idxs = sorted(int(f[:-5]) for f in os.listdir(os.path.join(LEVEL1_DIR, case))
                      if f.endswith(".json"))
    results = {}
    with Pool(workers) as pool:
        for res in pool.imap_unordered(run_t3, [(case, i) for i in idxs], chunksize=1):
            results[res["idx"]] = res
            cmp = ", ".join(f"{key}: {val}" for key, val in res["compare"].items())
            print(f"{case} #{res['idx']}: t = {res['t']}, nodes {res['nodes']}, raw {res['raw_size']}, "
                  f"k<=3 {res['k3_size']}, full filter {res['size']}; U4 LP {res['u4_lp']}; "
                  f"{res['u4_here']}; certificates {res['certs']}; [{cmp}] ({res['seconds']}s)",
                  flush=True)
    mism = sorted(i for i, r in results.items() if not all(r["compare"].values()))
    bad = sorted(i for i, r in results.items() if not all(r["certs"].values()))
    surv = sorted(i for i, r in results.items() if r["u4_here"].startswith("not"))
    c7 = sorted(i for i, r in results.items() if r["certs"].get("C7 probe on full-filter deck"))
    print(f"{case}: {len(results)} candidates; comparison mismatches: {mism}; certificate failures: "
          f"{bad}; not excluded by U4's certificates: {len(surv)} {surv}; of these, excluded by "
          f"C7(c)/(d) certificates on the full-filter decks: {c7} ({time.time() - t0:.0f}s)", flush=True)
    tag = "all" if len(idxs) == 169 else "_".join(map(str, idxs))
    out = os.path.join(ROOT, "data", "probe", f"t3_{case}", f"deck_dp_t3_{tag}.json")
    with open(out, "w") as fh:
        json.dump({str(i): results[i] for i in sorted(results)}, fh)


# ---------- validation of the Lemma 3.12 implementation ----------

def chi_shift_top(cfg, Qc, T):
    """Top T coefficients of chi_S(x - 1) for a level-1 candidate."""
    tops = [binom_power(cfg["a"] - 1, cfg["n"] - cfg["d"])[:T]]
    for v, mv in cfg["forced"]:
        tops.append(binom_power(-v - 1, mv)[:T])
    tops.append(taylor(list(Qc), -(cfg["c"] + 1)))
    out = [1]
    for p in tops:
        p = list(p) + [0] * max(0, T - len(p))
        out = top_mul(p, out + [0] * max(0, T - len(out)), T)
    return out


def l312_selftest(ngraphs):
    import random
    rng = random.Random(20261022)
    ok = True
    checks = ones = 0
    nval = 0
    for it in range(40):
        D = 20
        s = [Fraction(0)] + [Fraction(rng.randint(-60, 60), rng.choice([1, 1, 3, 5, 7, 15, 2, 4]))
                             for _ in range(D)]
        w = neglog_coeffs(s, D)
        for k in range(1, D // 2 + 1):
            nval += 1
            if l312_rhs_series(w, s, k) != l312_rhs_partition(s, k):
                ok = False
                print(f"  series and partition sums differ at k = {k}")
    print(f"right side of Lemma 3.12: series = literal partition sum, exactly, in {nval} "
          f"(random rational s, k <= 10) evaluations: {ok}", flush=True)
    for it in range(ngraphs):
        N = rng.choice([7, 9, 11, 13, 15, 17, 19, 21])
        Amat = [[0] * N for _ in range(N)]
        for i in range(N):
            for j in range(i + 1, N):
                if rng.random() < rng.choice([0.2, 0.5, 0.8]):
                    Amat[i][j] = Amat[j][i] = 1
        M = sympy.Matrix(N, N, lambda i, j: 1 - 2 * Amat[i][j])  # J - 2A = S + I
        a = [int(v) for v in M.charpoly(X).all_coeffs()]
        assert a[0] == 1 and a[1] == -N and a[2] == 0
        kmax = (N - 1) // 2
        s = l312_svals(a, N, 2 * kmax)
        w = neglog_coeffs(s, 2 * kmax)
        for k in range(2, kmax + 1):
            if l312_rhs_series(w, s, k) != l312_rhs_partition(s, k):
                ok = False
                print(f"  series and partition sums differ at k = {k} (order {N})")
        for method in ("series", "partition"):
            if l312_first_fail(a, N, kmax, method) is not None:
                ok = False
                print(f"  FAIL ({method}) on a real Seidel matrix of order {N}")
        for k in range(2, kmax + 1):
            checks += 1
            ones += (a[2 * k + 1] >> (2 * k)) & 1
            b = list(a)
            b[2 * k + 1] += 1 << (2 * k)
            for method in ("series", "partition"):
                if l312_first_fail(b, N, kmax, method) != k:
                    ok = False
                    print(f"  perturbation at k = {k} (order {N}, {method}) not detected")
    print(f"real Seidel matrices: {ngraphs} random graphs, {checks} (graph, k) checks, "
          f"tested bit 1 in {ones}; both methods pass every graph, agree on the right side, and "
          f"detect every perturbation a_(2k+1) + 2^(2k) at its k: {ok}", flush=True)
    c7 = load_json(os.path.join(ROOT, "data", "probe", "gy19_lemma312.json"))
    for case in ("421_44", "1127_47"):
        cfg = CASES[case]
        ref = c7[case]
        idxs = sorted(int(os.path.basename(p)[:-5]) for p in
                      glob.glob(os.path.join(ROOT, "data", "probe", case, "[0-9]*.json")))
        agree = 0
        for i in idxs:
            Qc = load_json(os.path.join(ROOT, "data", "probe", case, f"{i}.json"))["Q"]
            a = chi_shift_top(cfg, Qc, 2 * ref["kmax"] + 2)
            kf = l312_first_fail(a, cfg["n"], ref["kmax"])
            mine = "pass" if kf is None else kf
            theirs = "pass" if i in ref["pass"] else ref["first_failing_k"][str(i)]
            agree += mine == theirs
            if mine != theirs:
                ok = False
                print(f"  {case} #{i}: first failing k {mine} here, {theirs} in C7")
        print(f"{case}: first failing k (k <= {ref['kmax']}) agrees with C7 "
              f"(gy19_lemma312.py, audited in A.11) for {agree} of {len(idxs)} candidates", flush=True)
    print("L312 SELFTEST", "PASS" if ok else "FAIL")
    return ok


def main():
    argv = sys.argv[1:]
    if argv and argv[0] == "--l312-selftest":
        sys.exit(0 if l312_selftest(int(argv[1]) if len(argv) > 1 else 60) else 1)
    workers = 4
    if "--workers" in argv:
        k = argv.index("--workers")
        workers = int(argv[k + 1])
        del argv[k:k + 2]
    if argv[0] == "--t3":
        main_t3(argv[1], [int(s) for s in argv[2:]], workers)
        return
    case = argv[0]
    ddir = os.path.join(ROOT, "data", "probe", case)
    t0 = time.time()
    if "--level2" in argv:
        k = argv.index("--level2")
        spec = argv[k + 1] if len(argv) > k + 1 else "all"
        idx = int(argv[1])
        lvl1 = load_json(os.path.join(ddir, f"{idx}.json"))
        members = (list(range(len(lvl1["deck"]))) if spec == "all"
                   else [int(s) for s in spec.split(",")])
        results = {}
        with Pool(workers) as pool:
            for res in pool.imap_unordered(run_member, [(case, idx, m) for m in members],
                                           chunksize=1):
                results[res["member"]] = res
                cmp = ", ".join(f"{key}: {val}" for key, val in res["compare"].items())
                print(f"{case} #{idx} member {res['member']}: order {res['order']}, t = {res['t']}, "
                      f"{'type 2' if res['strong'] else 'weakly type 2'}, nodes {res['nodes']}, "
                      f"raw {res['raw_size']}, after Lemma 3.12 {res['size']} {res['l312_removed']}; "
                      f"{res['verdict']} {res.get('cert_check', '')}; [{cmp}] ({res['seconds']}s)",
                      flush=True)
        mism = [m for m, r in results.items() if not all(r["compare"].values())]
        bad = [m for m, r in results.items() if "FAILS" in r["verdict"]]
        infeas = sorted(m for m, r in results.items() if r["verdict"].startswith("infeasible"))
        print(f"{case} #{idx}: {len(results)} members; infeasible at level 2: {infeas}; "
              f"comparison mismatches: {mism}; certificate failures: {bad} "
              f"({time.time() - t0:.0f}s)", flush=True)
        tag = "all" if spec == "all" else spec.replace(",", "_")
        out = os.path.join(ddir, f"deck_dp_level2_{idx}_{tag}.json")
        with open(out, "w") as fh:
            json.dump({str(m): results[m] for m in sorted(results)}, fh)
        return
    l312 = "--l312-pass" in argv
    argv = [a for a in argv if a != "--l312-pass"]
    if argv[1:]:
        idxs = [int(s) for s in argv[1:]]
    elif l312:
        idxs = load_json(os.path.join(ROOT, "data", "probe", "gy19_lemma312.json"))[case]["pass"]
    else:
        idxs = sorted(int(os.path.basename(p)[:-5])
                      for p in glob.glob(os.path.join(ddir, "[0-9]*.json")))
    results = {}
    with Pool(workers) as pool:
        for res in pool.imap_unordered(run_one, [(case, i) for i in idxs], chunksize=1):
            results[res["idx"]] = res
            print(f"{case} #{res['idx']}: t = {res['t']}, nodes {res['nodes']}, deck {res['deck_size']} "
                  f"(program 1 {res['prog1_size']}, identical {res['identical']}); probe LP {res['probe_lp']}; "
                  f"{res['verdict']} ({res['seconds']}s)", flush=True)
    ident = sum(r["identical"] for r in results.values())
    bad = [i for i, r in results.items() if "FAILS" in r["verdict"]]
    print(f"{case}: {len(results)} candidates, decks identical to program 1's for {ident}; "
          f"certificate failures: {bad} ({time.time() - t0:.0f}s)", flush=True)
    tag = "l312" if l312 and not argv[1:] else ("all" if not argv[1:] else "_".join(argv[1:]))
    with open(os.path.join(ddir, f"deck_dp_{tag}.json"), "w") as fh:
        json.dump({str(k): results[k] for k in sorted(results)}, fh)


if __name__ == "__main__":
    main()
