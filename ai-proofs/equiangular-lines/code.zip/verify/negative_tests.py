"""Negative tests for the Theorem U criterion: it must never exclude a line system that exists.

1. Moment level: every subset of a known system that is too large to lie in a hyperplane
   spans the same space, so its Seidel matrix has eigenvalue -a of multiplicity exactly n - d.
   For all such (a, d, n) no odd kappa may satisfy the exclusion inequality.
2. Matrix level: delete random vertices from the unitary two-graph systems (126 lines in R^21,
   344 lines in R^43; files in data/constructions), compute the exact characteristic polynomial, and
   check the two inequalities of the proof, eta <= eta*(T) and s^2 <= eta*T, for every odd kappa.
"""

import random
import sys
from pathlib import Path

from flint import fmpz_mat, fmpz_poly

sys.path.insert(0, str(Path(__file__).resolve().parent))
from c1_uniform import eta_star, excluded_by, sums  # noqa: E402

CON = Path(__file__).resolve().parents[1] / "data" / "constructions" / "classical"

# (a, d, smallest n that forces full rank, largest n known to exist)
FAMILIES = [
    (3, 7, 17, 28),      # 28 lines in R^7; N(6) = 16
    (5, 21, 95, 126),    # unitary q=5; N(20) <= 94
    (5, 22, 127, 176),   # N(21) = 126
    (5, 23, 177, 276),   # N(22) = 176
    (7, 43, 289, 344),   # unitary q=7; N(42) <= 288
]
SINGLE = [(5, 18, 57), (5, 19, 72), (5, 20, 90)]


def moment_level():
    count = 0
    cases = [(a, d, n) for a, d, lo, hi in FAMILIES for n in range(lo, hi + 1)] + SINGLE
    for a, d, n in cases:
        P1, _ = sums(a, d, n)
        k0 = P1 // d
        for kappa in range(k0 - 61, k0 + 62):
            if kappa % 2 == 1:
                ok, info = excluded_by(a, d, n, kappa)
                assert not ok, ("criterion excludes an existing system", a, d, n, info)
                count += 1
    print(f"moment level: {len(cases)} (a,d,n) cases, {count} (case,kappa) pairs, none excluded")


def read_seidel(path):
    rows = [ln.strip() for ln in path.read_text().splitlines() if ln.strip() and not ln.startswith("#")]
    n = int(rows[0])
    m = [[{"0": 0, "+": 1, "-": -1}[ch] for ch in r] for r in rows[1:1 + n]]
    assert len(m) == n and all(len(r) == n for r in m)
    return m


def root_multiplicity(p, r):
    lin = fmpz_poly([-r, 1])
    k = 0
    while True:
        q, rem = divmod(p, lin)
        if rem != 0:
            return k
        p, k = q, k + 1


def matrix_level(name, a, d, deletions, seed=7):
    S = read_seidel(CON / name)
    n0 = len(S)
    rng = random.Random(seed)
    for k in deletions:
        keep = sorted(rng.sample(range(n0), n0 - k))
        sub = [[S[i][j] for j in keep] for i in keep]
        n = len(sub)
        chi = fmpz_mat(sub).charpoly()
        mult = root_multiplicity(chi, -a)
        assert mult == n - d, (name, k, mult)
        P1, P2 = sums(a, d, n)
        checked = 0
        for kappa in range(-a + 2, 2 * (P1 // d) + 3, 2):
            s = P1 - d * kappa
            T = P2 - 2 * kappa * P1 + d * kappa * kappa
            eta = d - root_multiplicity(chi, kappa)
            es = eta_star(T, d, n % 2)
            assert eta <= es and s * s <= eta * T, (name, k, kappa, eta, es, s, T)
            checked += 1
        print(f"matrix level: {name} minus {k} vertices (n={n}): -{a} has multiplicity {mult}; "
              f"eta <= eta* and s^2 <= eta*T hold for {checked} odd kappa")


if __name__ == "__main__":
    moment_level()
    matrix_level("unitary_q5_n126_d21.seidel", 5, 21, [0, 1, 5, 20])
    matrix_level("unitary_q7_n344_d43.seidel", 7, 43, [0, 1, 3, 30])
    print("negative tests OK")
