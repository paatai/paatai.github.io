"""Per-structure summary of c35_cert.py run logs (leaves, statuses, LPs, B&B nodes, time).

    python3 verify/c35_cert_table.py LOG [LOG ...]

Shards of one run may be given together; instance-level exclusions are counted once per shard set."""
import json
import sys
from collections import Counter, defaultdict


def main():
    per = defaultdict(lambda: dict(leaves=0, status=Counter(), lps=0, time=0.0, tree=Counter()))
    excl = defaultdict(Counter)
    summaries = []
    seen_excl = set()
    for path in sys.argv[1:]:
        recs = [json.loads(line) for line in open(path)]
        # one run = one (case, support); some instance-level records do not repeat them
        cs = {(d["case"], d["support"]) for d in recs if "case" in d and "support" in d}
        cs |= {(d["args"]["case"], d["args"]["support"]) for d in recs if "summary" in d}
        assert len(cs) == 1, (path, cs)
        case, support = cs.pop()
        for d in recs:
            if "summary" in d:
                summaries.append((path, d["summary"], d["leaves"], d.get("units"), d["code"]))
                continue
            if "struct" not in d or "status" not in d:
                continue
            d = dict(d, case=case, support=support)
            key = (case, support, ",".join(d["struct"]))
            if "leaf" in d:
                p = per[key]
                p["leaves"] += 1
                p["status"][d["status"]] += 1
                p["lps"] += d.get("lps", 0)
                p["time"] += d.get("time", 0)
                p["tree"].update(d.get("tree", {}))
            elif d["status"].startswith("EXCLUDED"):
                k = json.dumps(d, sort_keys=True)
                if k not in seen_excl:
                    seen_excl.add(k)
                    excl[key][d["status"]] += 1
    keys = sorted(set(per) | set(excl), key=lambda k: (k[0], k[1], k[2]))
    print("| case | support | structure | leaves | verdicts | LPs | B&B branch nodes | time (s) | instance-level exclusions |")
    print("| --- | --- | --- | --- | --- | --- | --- | --- | --- |")
    for k in keys:
        p = per.get(k)
        ex = "; ".join(f"{v} {s[10:-1]}" for s, v in sorted(excl[k].items())) if k in excl else ""
        if p:
            print(f"| {k[0]} | {k[1]} | {k[2]} | {p['leaves']} | {dict(p['status'])} | {p['lps']} | "
                  f"{p['tree'].get('B', 0)} | {p['time']:.0f} | {ex} |")
        else:
            print(f"| {k[0]} | {k[1]} | {k[2]} | 0 | | | | | {ex} |")
    print()
    for s in summaries:
        print(s)


if __name__ == "__main__":
    main()
