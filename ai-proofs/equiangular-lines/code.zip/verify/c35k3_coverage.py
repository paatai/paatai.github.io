"""Coverage check for program 1 on 74 (0,1,5) structure (4,4,4,4) (dim F = 3).

Re-enumerates the second-level leaves of `c35k.py --k 2` (in c35k3's order) and requires each one
to be decided:
* at level 2: an INFEASIBLE record for the leaf (same references, cases and row) in one of the
  leaf logs (c35k.py's log or c35k3.py's --out files); or
* at level 3: every third-level leaf, enumerated here with c35k3's rule for x_3, has an INFEASIBLE
  sub-leaf record (same idx, case B3, x_3 and row) in one of the sub-leaf logs (c35k3.py's stdout).
Records that are FEASIBLE anywhere are reported. The leaf logs' "level 3" status is not trusted:
a leaf counts as decided at level 3 only through its sub-leaf records.

usage: python3 c35k3_coverage.py --leaf-logs F ... --sub-logs F ...
"""
import argparse
import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src"))
import c35k as K  # noqa: E402
import c35k3 as K3  # noqa: E402


def records(paths):
    for p in paths:
        for line in open(p):
            try:
                yield p, json.loads(line)
            except json.JSONDecodeError:
                continue


def is_feasible(d, st):
    """CP-SAT reports a found solution as OPTIMAL (no objective) or FEASIBLE."""
    return ("solution" in d or st.startswith("OPTIMAL") or st.startswith("FEASIBLE")
            or bool((d.get("level3") or {}).get("feasible")))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--leaf-logs", nargs="+", required=True)
    ap.add_argument("--sub-logs", nargs="*", default=[])
    args = ap.parse_args()
    lvl2, feasible = {}, []
    for p, d in records(args.leaf_logs):
        if "refs" not in d or "caseB2" not in d:
            continue
        st = d.get("status", "")
        key = K3.leaf_key(d["caseB"], d["refs"], d["caseB2"], d["row2"])
        if is_feasible(d, st):
            feasible.append((p, d.get("idx"), st))
        own = d["level2"]["status"] if "level2" in d else st
        if own.startswith("INFEASIBLE"):
            lvl2.setdefault(key, os.path.basename(p))
    subs = {}
    for p, d in records(args.sub_logs):
        if "sub" not in d:
            continue
        st = d.get("status", "")
        if is_feasible(d, st):
            feasible.append((p, d.get("idx"), st))
        if st.startswith("INFEASIBLE"):
            subs.setdefault(K3.sub_key(d["idx"], d["caseB3"], d["j3"], d["row3"]),
                            os.path.basename(p))
    wk = K.Walks("74_19", (4, 4, 4, 4))
    table = K.walk_perm_table((4, 4, 4, 4), wk.St)
    n = n2 = n3 = nsub = 0
    by_file = {}
    missing = []
    for idx, (caseB, refs2, caseB2) in enumerate(K3.second_level(wk, table)):
        n += 1
        row2 = refs2[1][2]
        key = K3.leaf_key(caseB, refs2, caseB2, row2)
        if key in lvl2:
            n2 += 1
            by_file[lvl2[key]] = by_file.get(lvl2[key], 0) + 1
            continue
        (j1, N1, r1row), (j2, N2, _) = refs2
        stab12 = table[(table[:, j1] == j1) & (table[:, j2] == j2)]
        if not any(k[0] == idx for k in subs):
            missing.append((idx, "no level-2 record and no sub-leaf record"))
            continue
        ok, cnt, miss = True, 0, 0
        for caseB3 in ((False, True) if not (caseB or caseB2) else (True,)):
            seen = set()
            for (j3, N3, row3) in K3.third_refs(wk, refs2, caseB, caseB2, caseB3):
                k3 = (N3, row3[0], row3[1], int(stab12[:, j3].min()))
                if k3 in seen:
                    continue
                seen.add(k3)
                cnt += 1
                if K3.sub_key(idx, caseB3, j3, row3) not in subs:
                    ok = False
                    miss += 1
        if ok:
            n3 += 1
            nsub += cnt
        else:
            missing.append((idx, "%d of %d sub-leaves undecided" % (miss, cnt)))
    print(json.dumps(dict(second_level_leaves=n, decided_level2=n2, decided_level3=n3,
                          level3_subleaves=nsub, level2_by_file=by_file,
                          undecided=len(missing), feasible_records=len(feasible))))
    for m in missing[:50]:
        print("UNDECIDED", *m)
    for f in feasible[:50]:
        print("FEASIBLE", *f)
    print("COVERAGE " + ("COMPLETE" if not missing and not feasible else "INCOMPLETE"))


if __name__ == "__main__":
    main()
