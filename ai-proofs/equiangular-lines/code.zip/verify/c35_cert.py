"""Independent certifier for candidate #35 (74 lines in R^19, 94 lines in R^20).

Shares no code with src/c35*.py.  Same mathematical model (CLAIMS.md U6, U8), derived and coded
differently:
  * p-parts in the basis (w, u_a, u_b) of V11, w = sqrt3 w0, Gram diag(3) + [[1, -1/2], [-1/2, 1]],
    u_c = -u_a - u_b; frames, cross frames and eigen-equations are checked from these positions;
  * row counts and block sums solved from S E = lambda E and sum r z = sum z p^T = 0 in that basis;
  * the base class L_a enters only through its Gram matrix M = 8I - 4A: for z outside L_a with steps
    s_i = <z, q_i>/2 the walk part has <omega_x, omega_y> = 4 s_x^T M^+ s_y (exact Moore-Penrose
    inverse), and s is admissible iff it lies in the range of M;
  * type-2 relation graphs, structures, partner assignments are enumerated without symmetry
    reduction; own type-2 lines and node references are reduced by explicit automorphisms of the
    (-4)-graph that fix every fixed vector (each one checked);
  * every leaf is decided by an LP whose infeasibility is proved by an integer Farkas vector checked
    in exact arithmetic, with branch and bound over column groups when the LP is feasible.
"""
import argparse
import gzip
import itertools
import json
import os
import sys
import time
from fractions import Fraction as Q
from functools import reduce
from hashlib import sha256
from math import gcd, isqrt, lcm

import numpy as np

CODE_HASH = sha256(open(__file__, "rb").read()).hexdigest()[:16]
# C35_CERT_PYINT=1 computes every residual in Python ints (no int64 fast path)
PYINT = os.environ.get("C35_CERT_PYINT") == "1"

# ----------------------------------------------------------------------------- exact helpers


def q_inv(M):
    """Exact inverse of a square rational matrix (list of lists) or None."""
    n = len(M)
    A = [[Q(x) for x in row] + [Q(int(i == j)) for j in range(n)] for i, row in enumerate(M)]
    for c in range(n):
        p = next((r for r in range(c, n) if A[r][c] != 0), None)
        if p is None:
            return None
        A[c], A[p] = A[p], A[c]
        pv = A[c][c]
        A[c] = [x / pv for x in A[c]]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c]
                A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return [row[n:] for row in A]


def q_det(M):
    n = len(M)
    A = [[Q(x) for x in row] for row in M]
    d = Q(1)
    for c in range(n):
        p = next((r for r in range(c, n) if A[r][c] != 0), None)
        if p is None:
            return Q(0)
        if p != c:
            A[c], A[p] = A[p], A[c]
            d = -d
        d *= A[c][c]
        for r in range(c + 1, n):
            if A[r][c] != 0:
                f = A[r][c] / A[c][c]
                A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return d


def q_solve(M, b):
    inv = q_inv(M)
    assert inv is not None
    return [sum(inv[i][j] * Q(b[j]) for j in range(len(b))) for i in range(len(b))]


def psd_rank(G):
    """(is_psd, rank) of a symmetric rational matrix: symmetric Gaussian elimination with diagonal
    pivots (a zero diagonal entry with a nonzero row means indefinite)."""
    A = [[Q(x) for x in row] for row in G]
    n = len(A)
    live = list(range(n))
    rank = 0
    while live:
        piv = max(live, key=lambda i: A[i][i])
        if A[piv][piv] < 0:
            return False, rank
        if A[piv][piv] == 0:
            if any(A[i][j] != 0 for i in live for j in live):
                return False, rank
            break
        rank += 1
        live.remove(piv)
        for i in live:
            f = A[i][piv] / A[piv][piv]
            if f:
                for j in live:
                    A[i][j] -= f * A[piv][j]
    return True, rank


def is_square(n):
    return n >= 0 and isqrt(n) ** 2 == n


# ----------------------------------------------------------------------------- the line types

CASES = {
    "74": dict(dimV=15, frame=40, lam=(17, 15, 11), sumr2=66, pframe=96),
    "94": dict(dimV=16, frame=48, lam=(21, 19, 15), sumr2=78, pframe=120),
}
# (n0, n_class, singletons) per support; singletons are (name, r, p) with p in (w, u_a, u_b)
UX = {"a": (0, 1, 0), "b": (0, 0, 1), "c": (0, -1, -1)}


def _p(*xs):
    return tuple(Q(x) for x in xs)


def _sub(p, q):
    return tuple(a - b for a, b in zip(p, q))


def _scale(c, p):
    return tuple(Q(c) * a for a in p)


def support_singletons(sup):
    W = _p(1, 0, 0)
    out = []
    if sup == "015":
        out = [("f+", 3, _scale(2, W)), ("f-", 3, _scale(-2, W))]
    elif sup == "0125":
        for x in "abc":
            out.append(("t" + x, 2, _sub(_scale(-1, W), _scale(2, _p(*UX[x])))))
        out.append(("f", 3, _scale(2, W)))
    elif sup == "012":
        for x in "abc":
            for sg, nm in ((1, "+"), (-1, "-")):
                out.append(("t" + x + nm, 2, _sub(_scale(sg, W), _scale(2, _p(*UX[x])))))
    else:
        raise ValueError(sup)
    return out


COUNTS = {("74", "015"): (24, 16), ("74", "0125"): (25, 15), ("74", "012"): (26, 14),
          ("94", "015"): (32, 20), ("94", "0125"): (33, 19), ("94", "012"): (34, 18)}
G3 = [[Q(3), Q(0), Q(0)], [Q(0), Q(1), Q(-1, 2)], [Q(0), Q(-1, 2), Q(1)]]
BLOCKS = ("T0", "T1a", "T1b", "T1c")
NORM_R = {0: 9, 1: 8, 2: 5, 3: 0}
SQRT_P2 = {0: 3, 1: 4, 2: 7, 3: 12}


def pip(p, q):
    return sum(p[i] * G3[i][j] * q[j] for i in range(3) for j in range(3))


class Model:
    """Line types of one support: block types T0, T1a, T1b, T1c and singletons."""

    def __init__(self, case, sup):
        cfg = CASES[case]
        self._memo = {}
        self.case, self.sup = case, sup
        self.dimV, self.fr = cfg["dimV"], cfg["frame"]
        self.lam_r, _, self.lam_p = cfg["lam"]
        n0, nc = COUNTS[(case, sup)]
        self.size = {"T0": n0, "T1a": nc, "T1b": nc, "T1c": nc}
        self.r = {"T0": 0, "T1a": 1, "T1b": 1, "T1c": 1}
        self.p = {"T0": _p(1, 0, 0)}
        for x in "abc":
            self.p["T1" + x] = _scale(2, _p(*UX[x]))
        self.single = []
        for nm, r, p in support_singletons(sup):
            self.r[nm], self.p[nm] = r, p
            self.single.append(nm)
        self.T2 = [s for s in self.single if self.r[s] == 2]
        self.T5 = [s for s in self.single if self.r[s] == 3]
        self.N = {nm: NORM_R[self.r[nm]] for nm in self.r}
        for nm in self.r:
            assert pip(self.p[nm], self.p[nm]) == SQRT_P2[self.r[nm]], nm
            assert 2 * self.r[nm] ** 2 + 3 * self.N[nm] + pip(self.p[nm], self.p[nm]) == 30
        self.check_frames()
        self.bsum = self._block_sums()

    def cls(self, nm):
        if nm.startswith("T1"):
            return nm[2]
        if nm.startswith("t"):
            return nm[1]
        return None

    def K(self, u, v):
        key = ("K", u, v)
        if key not in self._memo:
            self._memo[key] = 2 * self.r[u] * self.r[v] + pip(self.p[u], self.p[v])
        return self._memo[key]

    def zval(self, u, v, S):
        return Q(6 * S - self.K(u, v), 3)

    def allowed(self, u, v):
        """{z-inner product: S} for distinct lines of types u, v (Cauchy-Schwarz).  The dict is
        shared between calls (callers only read it)."""
        key = ("allowed", u, v)
        if key not in self._memo:
            out = {}
            for S in (1, -1):
                b = self.zval(u, v, S)
                if b * b <= self.N[u] * self.N[v]:
                    out[b] = S
            self._memo[key] = out
        return self._memo[key]

    def check_frames(self):
        """sum r^2, sum p p^T = c G3^{-1}, sum r p = 0 over all lines (with the counts)."""
        lines = [(nm, self.size[nm]) for nm in BLOCKS] + [(s, 1) for s in self.single]
        assert sum(m * self.r[nm] ** 2 for nm, m in lines) == CASES[self.case]["sumr2"]
        S = [[sum(m * self.p[nm][i] * self.p[nm][j] for nm, m in lines) for j in range(3)]
             for i in range(3)]
        G3i = q_inv(G3)
        c = CASES[self.case]["pframe"]
        assert all(S[i][j] == c * G3i[i][j] for i in range(3) for j in range(3)), S
        assert all(sum(m * self.r[nm] * self.p[nm][i] for nm, m in lines) == 0 for i in range(3))

    def _system(self):
        """Columns: blocks; rows: the r-coordinate and the three p-coordinates."""
        return [[Q(self.r[b]) for b in BLOCKS]] + [[self.p[b][i] for b in BLOCKS] for i in range(3)]

    def row_counts(self, typ, S):
        """For a line of type typ (block name or singleton) with S entries S[s] against every other
        singleton s: minus counts per block (excluding the line itself), or None if impossible."""
        rhs = [Q(self.lam_r * self.r[typ])] + [Q(self.lam_p) * self.p[typ][i] for i in range(3)]
        for s in self.single:
            if s == typ:
                continue
            rhs[0] -= S[s] * self.r[s]
            for i in range(3):
                rhs[i + 1] -= S[s] * self.p[s][i]
        sig = q_solve(self._system(), rhs)
        out = {}
        for b, x in zip(BLOCKS, sig):
            n = self.size[b] - (1 if b == typ else 0)
            m = (n - x) / 2
            if m.denominator != 1 or not 0 <= m <= n:
                return None
            out[b] = int(m)
        return out

    def _block_sums(self):
        """coef[b][s]: Z_b = sum_{v in b} z_v = sum_s coef[b][s] z_s (s singletons; z_s = 0 for T5)."""
        coef = {b: {} for b in BLOCKS}
        M = self._system()
        for s in self.single:
            sol = q_solve(M, [-Q(self.r[s])] + [-self.p[s][i] for i in range(3)])
            for b, x in zip(BLOCKS, sol):
                coef[b][s] = x
        return coef

    def S_T5(self, typ, f):
        """S entry of a line of type typ with a type-5 line f (z_f = 0 forces 6S = K)."""
        k = self.K(typ, f)
        assert k in (6, -6), (typ, f, k)
        return 1 if k == 6 else -1


# ----------------------------------------------------------------------------- the base class


class Base:
    """Base class L_a with (-4)-graph a union of components ('C', m) (cycle) and ('P', k) (path with
    k vertices); Gram M = 8I - 4A."""

    def __init__(self, comps):
        self.comps = [tuple(c) for c in comps]
        self.start = []
        n = 0
        for t, k in self.comps:
            assert (t == "C" and k >= 4 and k % 2 == 0) or (t == "P" and k >= 1)
            self.start.append(n)
            n += k
        self.nc = n
        self.ncyc = sum(1 for t, _ in self.comps if t == "C")
        self.rank = n - self.ncyc
        A = np.zeros((n, n), dtype=np.int64)
        for (t, k), s0 in zip(self.comps, self.start):
            for i in range(k - (1 if t == "P" else 0)):
                a, b = s0 + i, s0 + (i + 1) % k
                A[a, b] = A[b, a] = 1
        self.A = A
        self.M = 8 * np.eye(n, dtype=np.int64) - 4 * A
        # exact Moore-Penrose inverse, block by block
        Mp = [[Q(0)] * n for _ in range(n)]
        self.kernel = []
        for (t, k), s0 in zip(self.comps, self.start):
            blk = [[Q(int(self.M[s0 + i, s0 + j])) for j in range(k)] for i in range(k)]
            if t == "C":
                inv = q_inv([[blk[i][j] + 1 for j in range(k)] for i in range(k)])
                inv = [[inv[i][j] - Q(1, k * k) for j in range(k)] for i in range(k)]
                self.kernel.append(list(range(s0, s0 + k)))
            else:
                inv = q_inv(blk)
            for i in range(k):
                for j in range(k):
                    Mp[s0 + i][s0 + j] = inv[i][j]
        Mq = [[Q(int(x)) for x in row] for row in self.M]
        MMp = [[sum(Mq[i][l] * Mp[l][j] for l in range(n)) for j in range(n)] for i in range(n)]
        MMpM = [[sum(MMp[i][l] * Mq[l][j] for l in range(n)) for j in range(n)] for i in range(n)]
        assert MMpM == Mq
        MpMMp = [[sum(Mp[i][l] * MMp[l][j] for l in range(n)) for j in range(n)] for i in range(n)]
        assert MpMMp == Mp and all(MMp[i][j] == MMp[j][i] for i in range(n) for j in range(n))
        self.Mp = Mp
        self.MMp = MMp
        self.Dw = lcm(*[(4 * x).denominator for row in Mp for x in row])
        P4 = np.array([[int(4 * self.Dw * x) for x in row] for row in Mp], dtype=np.int64)
        assert all(P4[i, j] == 4 * self.Dw * Mp[i][j] for i in range(n) for j in range(n))
        self.P4 = P4

    def in_range(self, s):
        """s in range(M)  <=>  (I - M M^+) s = 0."""
        n = self.nc
        return all(Q(int(s[i])) == sum(self.MMp[i][j] * int(s[j]) for j in range(n)) for i in range(n))

    def wnorm(self, s, t=None):
        """D_w <omega_s, omega_t> (integer)."""
        t = s if t is None else t
        return int(np.asarray(s, dtype=np.int64) @ self.P4 @ np.asarray(t, dtype=np.int64))

    def walks(self, values, bound):
        """Step vectors with s_i in values[i] (per-vertex tuples), in range(M), D_w-norm <= bound.
        Returns an int8 array (rows) and the D_w-norms; both are cached and read-only."""
        key = (tuple(tuple(int(x) for x in v) for v in values), int(bound))
        if not hasattr(self, "_walks"):
            self._walks = {}
        if key not in self._walks:
            S, W = self._walks_new(values, bound)
            S.setflags(write=False)
            W.setflags(write=False)
            self._walks[key] = (S, W)
        return self._walks[key]

    def _walks_new(self, values, bound):
        per = []
        for (t, k), s0 in zip(self.comps, self.start):
            idx = list(range(s0, s0 + k))
            P = self.P4[np.ix_(idx, idx)]
            # (I - M M^+) restricted to the component, scaled to integers
            Kq = [[Q(int(i == j)) - self.MMp[s0 + i][s0 + j] for j in range(k)] for i in range(k)]
            dk = lcm(*[x.denominator for row in Kq for x in row])
            Ki = np.array([[int(x * dk) for x in row] for row in Kq], dtype=np.int64)
            rows = []
            for combo in itertools.product(*[values[i] for i in idx]):
                v = np.array(combo, dtype=np.int64)
                if Ki.any() and (Ki @ v).any():
                    continue
                w = int(v @ P @ v)
                if w <= bound:
                    rows.append((w, combo))
            rows.sort()
            per.append(rows)
        out, norms = [], []

        def rec(ci, acc, w):
            if ci == len(per):
                out.append(acc)
                norms.append(w)
                return
            for wc, combo in per[ci]:
                if w + wc > bound:
                    break
                rec(ci + 1, acc + list(combo), w + wc)

        rec(0, [], 0)
        S = np.array(out, dtype=np.int8).reshape(len(out), self.nc)
        return S, np.array(norms, dtype=np.int64)

    def explicit(self):
        """Explicit class vectors q_i (rows) in coordinates: cycle C_m uses m coordinates, path P_k
        uses k + 1; q_i = 2 (e_i - e_{i+1})."""
        dims = [k if t == "C" else k + 1 for t, k in self.comps]
        off = np.cumsum([0] + dims)
        Qm = np.zeros((self.nc, int(off[-1])), dtype=np.int64)
        for ci, ((t, k), s0) in enumerate(zip(self.comps, self.start)):
            for i in range(k):
                a = off[ci] + i
                b = off[ci] + ((i + 1) % k if t == "C" else i + 1)
                Qm[s0 + i, a] += 2
                Qm[s0 + i, b] -= 2
        assert np.array_equal(Qm @ Qm.T, self.M)
        return Qm

    def automorphisms(self):
        """Automorphisms of the (-4)-graph as index permutations perm (vertex i -> perm[i]):
        dihedral groups of the cycles, reversal of paths, permutations of equal components.
        Cached; the array is read-only."""
        if not hasattr(self, "_auts"):
            self._auts = self._automorphisms_new()
            self._auts.setflags(write=False)
        return self._auts

    def _automorphisms_new(self):
        comp_syms = []
        for t, k in self.comps:
            if t == "C":
                syms = [[(j + r) % k for j in range(k)] for r in range(k)]
                syms += [[(r - j) % k for j in range(k)] for r in range(k)]
            else:
                syms = [list(range(k))] + ([list(range(k))[::-1]] if k > 1 else [])
            comp_syms.append(syms)
        groups = {}
        for ci, c in enumerate(self.comps):
            groups.setdefault(c, []).append(ci)
        perms = []
        for combo in itertools.product(*[list(itertools.permutations(v)) for v in groups.values()]):
            target = {}
            for orig, new in zip(groups.values(), combo):
                for o, nn in zip(orig, new):
                    target[o] = nn
            for local in itertools.product(*comp_syms):
                perm = np.zeros(self.nc, dtype=np.int64)
                for ci, ((t, k), s0) in enumerate(zip(self.comps, self.start)):
                    d0 = self.start[target[ci]]
                    for j in range(k):
                        perm[s0 + j] = d0 + local[ci][j]
                perms.append(perm)
        P = np.array(perms, dtype=np.int64)
        for c0 in range(0, len(P), 4096):
            ch = P[c0:c0 + 4096]
            assert np.array_equal(self.M[ch[:, :, None], ch[:, None, :]],
                                  np.broadcast_to(self.M, (len(ch), self.nc, self.nc)))
        return P


_BASES = {}


def get_base(comps):
    """One Base per structure (a Base is never modified after construction, apart from caches)."""
    key = tuple(tuple(c) for c in comps)
    if key not in _BASES:
        _BASES[key] = Base(comps)
    return _BASES[key]


def act(perm, S):
    """Image of step vectors (rows of S) under the automorphism perm: s'[perm[i]] = s[i]."""
    out = np.empty_like(S)
    out[..., perm] = S
    return out


# ----------------------------------------------------------------------------- type-2 configurations


def relation_graphs(model):
    """Every S assignment among the type-2 lines whose z-Gram is PSD of rank <= dim V and whose
    row counts are admissible.  Yields dict(mask, S, zip, rows)."""
    T2 = model.T2
    pairs = [(u, v) for i, u in enumerate(T2) for v in T2[i + 1:]]
    for mask in range(1 << len(pairs)):
        S = {}
        for k, (u, v) in enumerate(pairs):
            S[(u, v)] = S[(v, u)] = -1 if mask >> k & 1 else 1
        zip_ = {}
        for u in T2:
            for v in T2:
                zip_[(u, v)] = Q(model.N[u]) if u == v else model.zval(u, v, S[(u, v)])
        ok, rk = psd_rank([[zip_[(u, v)] for v in T2] for u in T2])
        if not ok or rk > model.dimV:
            continue
        rows = {}
        for t in T2:
            St = {s: (S[(t, s)] if s in T2 else model.S_T5(t, s)) for s in model.single if s != t}
            rows[t] = model.row_counts(t, St)
        if any(r is None for r in rows.values()):
            continue
        yield dict(mask=mask, S=S, zip=zip_, rows=rows)


def class_a_rows(model):
    """Row counts of a T1a line for every S pattern P (set of type-2 lines with S = -1)."""
    out = {}
    T2 = model.T2
    for m in range(1 << len(T2)):
        P = frozenset(t for i, t in enumerate(T2) if m >> i & 1)
        S = {t: (-1 if t in P else 1) for t in T2}
        for f in model.T5:
            S[f] = model.S_T5("T1a", f)
        out[P] = model.row_counts("T1a", S)
    return out


def check_degree_rule(model, arows):
    """The (-4)-degree of a class-a vector is 2 - #(other-class type-2 lines with S = -1)."""
    other = [t for t in model.T2 if model.cls(t) != "a"]
    for P, rc in arows.items():
        d = 2 - len(P & set(other))
        if d < 0:
            assert rc is None or rc["T1a"] == d
            continue
        assert rc is not None and rc["T1a"] == d, (P, rc)


def structures(nc, npaths):
    """Component lists: npaths paths (sizes >= 1, non-increasing) and even cycles >= 4."""
    out = []

    def cyc(rest, mx, acc):
        if rest == 0:
            out.append(list(acc))
            return
        for m in range(min(rest, mx), 3, -1):
            if m % 2 == 0:
                cyc(rest - m, m, acc + [("C", m)])

    def pth(left, rest, mx, acc):
        if left == 0:
            cyc(rest, rest, acc)
            return
        for k in range(min(rest - (left - 1), mx), 0, -1):
            pth(left - 1, rest - k, k, acc + [("P", k)])

    pth(npaths, nc, nc, [])
    return out


def partner_assignments(base, slots):
    """Maps vertex -> tuple of partner lines filling the deficits (P_k ends: 1, P_1: 2) with the
    given slots (list of line names, with multiplicity); distinct lines per vertex."""
    deficit = {}
    for (t, k), s0 in zip(base.comps, base.start):
        if t == "P":
            if k == 1:
                deficit[s0] = 2
            else:
                deficit[s0] = deficit.get(s0, 0) + 1
                deficit[s0 + k - 1] = deficit.get(s0 + k - 1, 0) + 1
    if sum(deficit.values()) != len(slots):
        return []
    verts = sorted(deficit)
    seen, out = set(), []

    def rec(i, fill):
        if i == len(slots):
            key = tuple((v, tuple(sorted(fill[v]))) for v in verts)
            if key not in seen:
                seen.add(key)
                out.append({v: tuple(sorted(fill[v])) for v in verts})
            return
        t = slots[i]
        for v in verts:
            if len(fill[v]) < deficit[v] and t not in fill[v]:
                fill[v].append(t)
                rec(i + 1, fill)
                fill[v].pop()

    rec(0, {v: [] for v in verts})
    return out


def orbit_reps(keys, steps_list, perms, max_gens=256, seed=0):
    """Representatives of the orbits of candidates under the group generated by perms (a subset of
    the automorphisms fixing all fixed data).  Candidate i is (keys[i], steps_list[i]) where
    steps_list[i] is a tuple of step vectors; perm acts on each.  Any subset of the group gives a
    complete set of representatives.  Asserts that the candidate set is invariant."""
    n = len(keys)
    if n == 0:
        return []
    index = {(keys[i], b"".join(np.asarray(s, dtype=np.int8).tobytes() for s in steps_list[i])): i
             for i in range(n)}
    parent = list(range(n))

    def find(i):
        while parent[i] != i:
            parent[i] = parent[parent[i]]
            i = parent[i]
        return i

    gens = perms
    if len(perms) > max_gens:
        rng = np.random.default_rng(seed)
        gens = perms[rng.choice(len(perms), max_gens, replace=False)]
    nst = len(steps_list[0])
    stacks = [np.array([steps_list[i][j] for i in range(n)], dtype=np.int8) for j in range(nst)]
    for perm in gens:
        imgs = [act(perm, S) for S in stacks]
        for i in range(n):
            key = (keys[i], b"".join(imgs[j][i].tobytes() for j in range(nst)))
            j = index.get(key)
            assert j is not None, "candidate set not invariant"
            a, b = find(i), find(j)
            if a != b:
                parent[max(a, b)] = min(a, b)
    return sorted({find(i) for i in range(n)})


def stabiliser(perms, fixed_steps):
    keep = np.ones(len(perms), dtype=bool)
    for s in fixed_steps:
        s = np.asarray(s, dtype=np.int8)
        img = np.empty((len(perms), len(s)), dtype=np.int8)
        img[np.arange(len(perms))[:, None], perms] = s[None, :]
        keep &= (img == s[None, :]).all(axis=1)
    return perms[keep]


class Instance:
    """Support data, relation graph H, base structure, partners and own type-2 lines."""

    def __init__(self, model, H, comps, partners, own_steps):
        self.model, self.H = model, H
        self.base = b = get_base(comps)
        self.D = b.Dw
        self.dimF = model.dimV - b.rank
        self.T2 = model.T2
        self.partners = partners
        self.steps = {}
        for t in self.T2:
            if model.cls(t) == "a":
                self.steps[t] = np.asarray(own_steps[t], dtype=np.int8)
            else:
                s = np.full(b.nc, step_value(model, t, 1), dtype=np.int8)
                for v, lines in partners.items():
                    if t in lines:
                        s[v] = step_value(model, t, -1)
                self.steps[t] = s
        D = self.D
        # D-scaled F-Gram of the type-2 lines
        self.Phi = {}
        for t in self.T2:
            for u in self.T2:
                v = D * H["zip"][(t, u)] - b.wnorm(self.steps[t], self.steps[u])
                assert v.denominator == 1
                self.Phi[(t, u)] = int(v)
        # S patterns of the class-a vectors and their row counts
        self.P = []
        for v in range(b.nc):
            P = set()
            for t in self.T2:
                if self.steps[t][v] == step_value(model, t, -1):
                    P.add(t)
                else:
                    assert self.steps[t][v] == step_value(model, t, 1)
            self.P.append(frozenset(P))

    def head(self):
        return dict(case=self.model.case, support=self.model.sup, H=self.H["mask"],
                    struct=[f"{t}{k}" for t, k in self.base.comps],
                    partners={str(v): list(l) for v, l in self.partners.items()},
                    own={t: [int(x) for x in self.steps[t]] for t in self.T2 if self.model.cls(t) == "a"},
                    dimF=self.dimF)

    def gram_ok(self, names):
        ok, rk = psd_rank([[Q(self.Phi[(t, u)]) for u in names] for t in names])
        return ok and rk <= self.dimF

    def base_sum_ok(self):
        """Z_T1a = sum of the class-a vectors: equal inner products with every q_i and zero F-part."""
        m, b = self.model, self.base
        coef = m.bsum["T1a"]
        for i in range(b.nc):
            lhs = sum(coef[t] * 2 * int(self.steps[t][i]) for t in self.T2)
            if lhs != int(b.M[:, i].sum()):
                return False
        tot = sum(coef[t] * coef[u] * self.Phi[(t, u)] for t in self.T2 for u in self.T2)
        return tot == 0

    def class_rows(self, arows):
        """Minus counts (T0, T1b, T1c) of every class-a vector; None if some pattern is impossible."""
        out = []
        for v in range(self.base.nc):
            rc = arows[self.P[v]]
            if rc is None:
                return None
            out.append(rc)
        return out


def step_value(model, typ, S):
    """Step <z, q>/2 of a line of type typ against a class-a vector with entry S."""
    v = model.zval("T1a", typ, S) / 2
    assert v.denominator == 1
    return int(v)


def own_patterns(model, H, base, t):
    """Step vectors of an own-class type-2 line t: S = -1 on exactly m_t(T1a) class vectors."""
    m = H["rows"][t]["T1a"]
    plus, minus = step_value(model, t, 1), step_value(model, t, -1)
    S, W = base.walks([(plus, minus)] * base.nc, model.N[t] * base.Dw)
    return [s for s in S if int((s == minus).sum()) == m]


def instances(model, log, only=None, max_dimF=None, orbits=True):
    """All instances (H, structure, partners, own lines) passing the instance-level tests, own
    lines reduced up to automorphisms fixing the other-class lines (unless orbits=False)."""
    arows = class_a_rows(model)
    if model.T2:
        check_degree_rule(model, arows)
    other = [t for t in model.T2 if model.cls(t) != "a"]
    own = [t for t in model.T2 if model.cls(t) == "a"]
    nc = model.size["T1a"]
    graphs = list(relation_graphs(model)) if model.T2 else [dict(mask=0, S={}, zip={}, rows={})]
    for H in graphs:
        slots = []
        for t in other:
            slots += [t] * H["rows"][t]["T1a"]
        if len(slots) % 2:
            log(dict(H=H["mask"], status="EXCLUDED (odd number of partner slots)"))
            continue
        for comps in structures(nc, len(slots) // 2):
            if only and [f"{t}{k}" for t, k in comps] != only:
                continue
            base = get_base(comps)
            dimF = model.dimV - base.rank
            if dimF < 0:
                log(dict(H=H["mask"], struct=[f"{t}{k}" for t, k in comps], dimF=dimF,
                         status="EXCLUDED (class-a vectors span more than the space)"))
                continue
            if max_dimF is not None and dimF > max_dimF:
                continue
            for partners in partner_assignments(base, slots):
                inst0 = Instance(model, H, comps, partners,
                                 {t: np.full(base.nc, step_value(model, t, 1)) for t in own})
                head = inst0.head()
                head.pop("own")
                if not inst0.gram_ok(other):
                    log(dict(head, status="EXCLUDED (other-class type-2 F-Gram)"))
                    continue
                cands = [own_patterns(model, H, base, t) for t in own]
                good = []
                for combo in itertools.product(*cands):
                    inst = Instance(model, H, comps, partners, dict(zip(own, combo)))
                    if not inst.gram_ok(model.T2) or not inst.base_sum_ok():
                        continue
                    if inst.class_rows(arows) is None:
                        continue
                    good.append(inst)
                if not good:
                    log(dict(head, status="EXCLUDED (no own type-2 lines)",
                             own=int(np.prod([len(c) for c in cands])) if own else 0))
                    continue
                if own and orbits:
                    perms = stabiliser(base.automorphisms(), [inst0.steps[t] for t in other])
                    reps = orbit_reps([0] * len(good), [tuple(g.steps[t] for t in own) for g in good],
                                      perms)
                    good = [good[i] for i in reps]
                    log(dict(head, status="own lines", orbits=len(good), stab=len(perms)))
                for inst in good:
                    inst.arows = arows
                    yield inst


# ----------------------------------------------------------------------------- references, nodes


class Ref:
    """Reference vector: a type-2 line, or a node (typ, steps, values with the earlier references
    and with every type-2 line)."""

    def __init__(self, kind, typ, steps, rel=(), rel2=None, name=None):
        self.kind, self.typ, self.name = kind, typ, name
        self.steps = np.asarray(steps, dtype=np.int8)
        self.rel = tuple(rel)
        self.rel2 = dict(rel2 or {})

    def key(self):
        return (self.kind, self.typ, self.name, self.steps.tobytes(), self.rel)

    def to_json(self):
        return dict(kind=self.kind, typ=self.typ, name=self.name,
                    steps=[int(x) for x in self.steps], rel=[str(x) for x in self.rel],
                    rel2={t: str(v) for t, v in self.rel2.items()})


def fip(inst, r, s, i, j):
    """D <phi_r, phi_s> for references r = refs[i], s = refs[j]."""
    D, b, m = inst.D, inst.base, inst.model
    if r.kind == "t2" and s.kind == "t2":
        return inst.Phi[(r.name, s.name)]
    if i == j:
        return m.N[r.typ] * D - b.wnorm(r.steps)
    if i < j:
        r, s, i, j = s, r, j, i
    # r = refs[i] is a node, i > j
    if s.kind == "t2":
        a = r.rel2[s.name]
    else:
        a = r.rel[j]
    v = D * a - b.wnorm(r.steps, s.steps)
    assert v.denominator == 1
    return int(v)


class Frame:
    def __init__(self, inst, refs):
        self.inst, self.refs = inst, list(refs)
        k = len(refs)
        self.k = k
        self.G = [[fip(inst, refs[i], refs[j], i, j) for j in range(k)] for i in range(k)]
        if k:
            det = q_det(self.G)
            assert det > 0 and det.denominator == 1
            inv = q_inv(self.G)
            adj = [[det * x for x in row] for row in inv]
            assert all(x.denominator == 1 for row in adj for x in row)
            self.det = int(det)
            self.adj = np.array([[int(x) for x in row] for row in adj], dtype=object)
        else:
            self.det, self.adj = 1, np.zeros((0, 0), dtype=object)
        self.L = inst.D * self.det
        self.ref_steps = np.array([r.steps for r in refs], dtype=np.int64).reshape(k, inst.base.nc)
        self.amax = max([abs(int(x)) for x in self.adj.flat] + [0])
        self.A64 = self.adj.astype(np.int64) if self.amax < 2 ** 62 else None

    def residual(self, N, Wt, C):
        """R = N L - W det - C^T adj C for rows of C, exact: in int64 when the bound below rules
        out overflow of every partial sum, in Python ints otherwise."""
        k = self.k
        Wt = np.asarray(Wt, dtype=np.int64)
        C = np.asarray(C, dtype=np.int64).reshape(len(Wt), k)
        cmax = int(np.abs(C).max()) if C.size else 0
        wmax = int(np.abs(Wt).max()) if Wt.size else 0
        bound = k * k * max(cmax, 1) ** 2 * self.amax + abs(N * self.L) + wmax * abs(self.det) + 1
        if bound < 2 ** 62 and not PYINT:
            q = ((C @ self.A64) * C).sum(axis=1) if k else np.zeros(len(Wt), dtype=np.int64)
            return N * self.L - Wt * self.det - q
        out = []
        for w, c in zip(Wt, C):
            c = [int(x) for x in c]
            q = sum(c[i] * int(self.adj[i, j]) * c[j] for i in range(k) for j in range(k))
            out.append(N * self.L - int(w) * self.det - q)
        return np.array(out, dtype=object)


def ref_type(r):
    return r.name if r.kind == "t2" else r.typ


def gen_nodes(inst, frame, types, filters, want):
    """Nodes of the given block types relative to frame.refs.
    want = 'positive' (R > 0, no eps), 'leaf' (eps for R > 0; R = 0 required if k = dim F).
    Returns a list of dicts."""
    m, b, D = inst.model, inst.base, inst.D
    k, refs = frame.k, frame.refs
    nonref = [t for t in inst.T2 if not any(r.kind == "t2" and r.name == t for r in refs)]
    Ct2 = {t: [fip_t2(inst, t, r, j) for j, r in enumerate(refs)] for t in nonref}
    pre = {}
    out = []
    for typ in types:
        plus, minus = step_value(m, typ, 1), step_value(m, typ, -1)
        S, Wt = b.walks([(plus, minus)] * b.nc, m.N[typ] * D)
        if len(S) == 0:
            continue
        S64 = S.astype(np.int64)
        WR = S64 @ b.P4 @ frame.ref_steps.T if k else np.zeros((len(S), 0), dtype=np.int64)
        WT = {t: S64 @ b.P4 @ inst.steps[t].astype(np.int64) for t in nonref}
        Al = [m.allowed(typ, ref_type(r)) for r in refs]
        for combo in itertools.product(*[sorted(a) for a in Al]):
            Da = np.array([int(D * a) for a in combo], dtype=np.int64)
            C = Da[None, :] - WR
            R = frame.residual(m.N[typ], Wt, C)
            assert want in ("positive", "leaf")
            if want == "positive":
                sel = R > 0
            elif k == inst.dimF:
                sel = R == 0
            else:
                sel = R >= 0
            sel = np.asarray(sel, dtype=bool) & filter_mask(inst, typ, Wt, C, filters)
            for i in np.nonzero(sel)[0].tolist():
                Ri = int(R[i])
                Ci = [int(x) for x in C[i]]
                rel2, Srow = {}, {}
                for r, a in zip(refs, combo):
                    if r.kind == "t2":
                        rel2[r.name] = a
                ok = True
                for t in nonref:
                    num = int(WT[t][i]) * frame.det + sum(
                        Ci[p] * int(frame.adj[p, q]) * Ct2[t][q] for p in range(k) for q in range(k))
                    val = Q(num, frame.L)
                    if val not in m.allowed(typ, t):
                        ok = False
                        break
                    rel2[t] = val
                if not ok:
                    continue
                for t in inst.T2:
                    Srow[t] = m.allowed(typ, t)[rel2[t]]
                for f in m.T5:
                    Srow[f] = m.S_T5(typ, f)
                key = (typ, tuple(sorted(Srow.items())))
                if key not in pre:
                    pre[key] = m.row_counts(typ, Srow)
                rc = pre[key]
                if rc is None or rc["T1a"] != int((S[i] == minus).sum()):
                    continue
                node = dict(typ=typ, steps=S[i], W=int(Wt[i]), C=Ci, R=Ri, rel=combo, rel2=rel2,
                            Srow=Srow, rc=rc)
                if want == "leaf" and Ri > 0:
                    out.append(dict(node, eps=1))
                    out.append(dict(node, eps=-1))
                else:
                    out.append(dict(node, eps=0))
    return out


def fip_t2(inst, t, r, j):
    """D <phi_t, phi_r> for a type-2 line t and reference r = refs[j]."""
    if r.kind == "t2":
        return inst.Phi[(t, r.name)]
    v = inst.D * r.rel2[t] - inst.base.wnorm(inst.steps[t], r.steps)
    assert v.denominator == 1
    return int(v)


def filter_mask(inst, typ, Wt, C, filters):
    """Level filters ('A', frame_j, Rmax) or ('B', frame_j, Rmax) for the rows of C (inner products
    with the current references, whose first frame_j.k are those of frame_j): under case A no T0
    vector has a larger residual than the reference; under case B every T0 vector lies in
    span(refs_j) and no T1 vector has a larger residual."""
    ok = np.ones(len(Wt), dtype=bool)
    for kind, fk, Rmax in filters:
        if typ != "T0" and kind == "A":
            continue
        Rk = fk.residual(inst.model.N[typ], Wt, C[:, :fk.k])
        if typ == "T0" and kind == "B":
            ok &= np.asarray(Rk == 0, dtype=bool)
        else:
            ok &= np.asarray(Rk <= Rmax, dtype=bool)
    return ok


def type2_refs(inst):
    """Greedy basis of the type-2 F-parts (other-class lines first)."""
    m = inst.model
    order = [t for t in inst.T2 if m.cls(t) != "a"] + [t for t in inst.T2 if m.cls(t) == "a"]
    chosen = []
    for t in order:
        trial = chosen + [t]
        if q_det([[Q(inst.Phi[(u, v)]) for v in trial] for u in trial]) != 0:
            chosen.append(t)
    return [Ref("t2", t, inst.steps[t], name=t) for t in chosen]


def leaves(inst, opts, log):
    """Yield (refs, filters, path) for every leaf of the reference recursion."""
    refs0 = type2_refs(inst)
    perms_all = inst.base.automorphisms() if opts.get("orbits", True) else None
    fixed_steps = [inst.steps[t] for t in inst.T2]

    # F is spanned by the F-parts of the T0, T1b, T1c and type-2 lines, so while k < dim F one of
    # the cases A, B below applies; leaves at k = dim F - 1 use the residual direction.
    stop = inst.dimF if opts.get("full_refs") else inst.dimF - 1
    # optional sharding by subtrees: every subtree at node-reference depth `level`, and every leaf
    # above that depth, is one unit; units are dealt out to the shards in order of generation
    sh = opts.get("shard_level")

    def own():
        i = sh["count"]
        sh["count"] += 1
        sh["cur"] = i
        return i % sh["n"] == sh["i"]

    def rec(refs, filters, path):
        k = len(refs)
        if sh is not None and len(path) == sh["level"] and not own():
            return
        if k >= stop:
            if sh is None or len(path) >= sh["level"] or own():
                yield refs, filters, path
            return
        frame = Frame(inst, refs)
        # case A: some T0 vector has F-part outside span(refs); x = one with maximal residual.
        # case B: all T0 F-parts lie in span(refs); x = a T1 vector (class b or c) with maximal
        # residual.  The filter ('B', frame, R(x)) imposes both conditions on the subtree.
        for case, types in (("A", ["T0"]), ("B", ["T1b", "T1c"])):
            cands = gen_nodes(inst, frame, types, filters, "positive")
            if perms_all is not None:
                stab = stabiliser(perms_all, fixed_steps + [r.steps for r in refs])
                keys = [(c["typ"], tuple(str(a) for a in c["rel"]), c["R"]) for c in cands]
                reps = orbit_reps(keys, [(c["steps"],) for c in cands], stab)
            else:
                stab, reps = None, list(range(len(cands)))
            log(dict(level=k, case=case, candidates=len(cands), orbits=len(reps),
                     stab=None if stab is None else len(stab), path=path))
            for i in reps:
                c = cands[i]
                x = Ref("node", c["typ"], c["steps"], rel=c["rel"], rel2=c["rel2"])
                nf = filters + [(case, frame, c["R"])]
                yield from rec(refs + [x], nf, path + [(case, i)])

    yield from rec(refs0, [], [])


# ----------------------------------------------------------------------------- leaves

_SQF = {}


def squarefree(n):
    """n = t s^2 with t squarefree; returns (t, s)."""
    if n not in _SQF:
        from sympy import factorint
        t, s = 1, 1
        for p, e in factorint(n).items():
            s *= p ** (e // 2)
            if e % 2:
                t *= p
        assert t * s * s == n
        _SQF[n] = (t, s)
    return _SQF[n]


TYP = {"T0": 0, "T1b": 1, "T1c": 2}
BL = ("T0", "T1b", "T1c")
TOL = 1e-6


class Leaf:
    def __init__(self, inst, refs, filters):
        self.inst, self.refs = inst, refs
        m, b = inst.model, inst.base
        self.frame = fr = Frame(inst, refs)
        self.k = fr.k
        assert self.k in (inst.dimF - 1, inst.dimF)
        nodes = gen_nodes(inst, fr, list(BL), filters, "leaf")
        for j, r in enumerate(refs):
            if r.kind != "node":
                continue
            Srow = {t: m.allowed(r.typ, t)[r.rel2[t]] for t in inst.T2}
            for f in m.T5:
                Srow[f] = m.S_T5(r.typ, f)
            rc = m.row_counts(r.typ, Srow)
            assert rc is not None
            nodes.append(dict(typ=r.typ, steps=r.steps, W=b.wnorm(r.steps), C=list(fr.G[j]), R=0,
                              eps=0, rel=None, rel2=r.rel2, Srow=Srow, rc=rc, fixed=True))
        self.nodes = nodes
        n = len(nodes)
        self.n = n
        self.typ = np.array([TYP[x["typ"]] for x in nodes], dtype=np.int64)
        self.S = np.array([x["steps"] for x in nodes], dtype=np.int64).reshape(n, b.nc)
        self.fixed = np.array([bool(x.get("fixed")) for x in nodes], dtype=bool)
        self.Ct2 = {t: [fip_t2(inst, t, r, j) for j, r in enumerate(refs)] for t in inst.T2}
        self.req = np.zeros((n, 3, 2), dtype=np.int64)
        for i, x in enumerate(nodes):
            for bi, bn in enumerate(BL):
                tot = m.size[bn] - (1 if x["typ"] == bn else 0)
                self.req[i, bi, 0] = x["rc"][bn]
                self.req[i, bi, 1] = tot - x["rc"][bn]
        self._relations()

    def _relations(self):
        """Sm[i, j] = S_ij for compatible pairs, 0 otherwise.  Floating point with tolerance TOL:
        an exactly compatible pair always passes (rounding errors are << TOL), so the relation is
        a superset of the true one and only weakens the model."""
        inst, fr, n = self.inst, self.frame, self.n
        m, b, D = inst.model, inst.base, inst.D
        Cf = np.array([x["C"] for x in self.nodes], dtype=float).reshape(n, self.k)
        if self.k:
            Ginv = np.array([[float(int(fr.adj[i, j])) / fr.det for j in range(self.k)]
                             for i in range(self.k)])
        else:
            Ginv = np.zeros((0, 0))
        res = np.array([x["R"] / fr.L for x in self.nodes], dtype=float)
        ev = np.array([x["eps"] for x in self.nodes], dtype=float)
        sq = ev * np.sqrt(res)
        Sm = np.zeros((n, n), dtype=np.int8)
        al = {}
        for a in BL:
            for c in BL:
                al[(TYP[a], TYP[c])] = m.allowed(a, c)
        P4 = b.P4.astype(float)
        CG = Cf @ Ginv
        for r0 in range(0, n, 1024):
            r1 = min(n, r0 + 1024)
            rho = (self.S[r0:r1].astype(float) @ P4 @ self.S.T.astype(float)
                   + CG[r0:r1] @ Cf.T) / D
            rho += np.outer(sq[r0:r1], sq)
            out = np.zeros((r1 - r0, n), dtype=np.int8)
            for (ta, tc), d in al.items():
                mask = (self.typ[r0:r1, None] == ta) & (self.typ[None, :] == tc)
                for val, S in d.items():
                    hit = mask & (np.abs(rho - float(val)) < TOL)
                    out[hit] = S
            Sm[r0:r1] = out
        np.fill_diagonal(Sm, 0)
        self.Sm = Sm

    def core(self, alive, fix1):
        """Iterated counting prune; returns the alive mask (fix1 nodes may die = conflict)."""
        alive = alive.copy()
        while True:
            idx = np.nonzero(alive)[0]
            if len(idx) == 0:
                return alive
            sub = self.Sm[np.ix_(idx, idx)]
            neg = (sub == -1).astype(np.float32)
            pos = (sub == 1).astype(np.float32)
            bad = np.zeros(len(idx), dtype=bool)
            for bi in range(3):
                cols = (self.typ[idx] == bi).astype(np.float32)
                cn, cp = neg @ cols, pos @ cols
                bad |= (cn < self.req[idx, bi, 0] - 0.5) | (cp < self.req[idx, bi, 1] - 0.5)
            if not bad.any():
                return alive
            alive[idx[bad]] = False

    # --------------------------------------------------------------------- exact rows

    def root_rows(self):
        """Exact equality rows (cols, coefs, rhs) over all node variables; None if a block sum is
        not integral (then the instance is impossible: the left-hand sides are integers)."""
        inst, fr, n, k = self.inst, self.frame, self.n, self.k
        m, b, D = inst.model, inst.base, inst.D
        T2 = inst.T2
        rows = []
        nodes = self.nodes
        S = self.S
        C = [[int(c) for c in x["C"]] for x in nodes]

        def add(cols, coefs, rhs, tag):
            rows.append((np.asarray(cols, dtype=np.int64), [int(c) for c in coefs], rhs, tag))

        # block sizes
        for bi, bn in enumerate(BL):
            cols = np.nonzero(self.typ == bi)[0]
            add(cols, [1] * len(cols), m.size[bn], ("size", bn))
        # walk block of the frame: sum s s^T = (fr M - M^2)/4 - sum_t s_t s_t^T
        M = b.M.astype(object)
        Tw = (m.fr * M - M.dot(M))
        for t in T2:
            st = inst.steps[t].astype(object)
            Tw = Tw - 4 * np.outer(st, st)
        for i in range(b.nc):
            for i2 in range(i, b.nc):
                assert Tw[i, i2] % 4 == 0
                prod = S[:, i] * S[:, i2]
                cols = np.nonzero(prod)[0]
                add(cols, prod[cols], int(Tw[i, i2] // 4), ("ww", i, i2))
        # walk-F cross block and F block
        Ct = {t: self.Ct2[t] for t in T2}
        for i in range(b.nc):
            for r in range(k):
                coefs = [int(S[j, i]) * C[j][r] for j in range(n)]
                cols = [j for j in range(n) if coefs[j]]
                rhs = -sum(int(inst.steps[t][i]) * Ct[t][r] for t in T2)
                add(cols, [coefs[j] for j in cols], rhs, ("wf", i, r))
        for r in range(k):
            for r2 in range(r, k):
                coefs = [C[j][r] * C[j][r2] for j in range(n)]
                cols = [j for j in range(n) if coefs[j]]
                rhs = m.fr * D * fr.G[r][r2] - sum(Ct[t][r] * Ct[t][r2] for t in T2)
                add(cols, [coefs[j] for j in cols], rhs, ("ff", r, r2))
        # residual direction (k = dim F - 1)
        if k == inst.dimF - 1:
            Rj = [x["R"] for x in nodes]
            cols = [j for j in range(n) if Rj[j]]
            add(cols, [Rj[j] for j in cols], m.fr * fr.L, ("rr",))
            classes = {}
            for j in cols:
                t, s = squarefree(Rj[j])
                classes.setdefault(t, []).append((j, s * nodes[j]["eps"]))
            for t, mem in sorted(classes.items()):
                for i in range(b.nc):
                    cc = [(j, u * int(S[j, i])) for j, u in mem if S[j, i]]
                    add([j for j, _ in cc], [c for _, c in cc], 0, ("re", t, "w", i))
                for r in range(k):
                    cc = [(j, u * C[j][r]) for j, u in mem if C[j][r]]
                    add([j for j, _ in cc], [c for _, c in cc], 0, ("re", t, "f", r))
                for bi in range(3):
                    cc = [(j, u) for j, u in mem if self.typ[j] == bi]
                    add([j for j, _ in cc], [c for _, c in cc], 0, ("re", t, "b", bi))
        # block sums: Z_b = sum_t coef_b(t) z_t (walk part and F-part)
        for bi, bn in enumerate(BL):
            coef = m.bsum[bn]
            inb = np.nonzero(self.typ == bi)[0]
            for i in range(b.nc):
                rhs = sum(coef[t] * int(inst.steps[t][i]) for t in T2)
                if Q(rhs).denominator != 1:
                    return None
                cols = [j for j in inb if S[j, i]]
                add(cols, [int(S[j, i]) for j in cols], int(rhs), ("bw", bn, i))
            for r in range(k):
                rhs = sum(coef[t] * Ct[t][r] for t in T2)
                if Q(rhs).denominator != 1:
                    return None
                cols = [j for j in inb if C[j][r]]
                add(cols, [C[j][r] for j in cols], int(rhs), ("bf", bn, r))
        # columns of the type-2 lines
        for t in T2:
            for bi, bn in enumerate(BL):
                cols = [j for j in range(n) if self.typ[j] == bi and nodes[j]["Srow"][t] == -1]
                add(cols, [1] * len(cols), inst.H["rows"][t][bn], ("col", t, bn))
        return rows

    def fixed_rows(self, i):
        """Row counts of a selected node i (excluding itself)."""
        out = []
        for bi in range(3):
            for si, sv in ((0, -1), (1, 1)):
                cols = np.nonzero((self.typ == bi) & (self.Sm[i] == sv))[0]
                out.append((cols, [1] * len(cols), int(self.req[i, bi, si]), ("fix", i, bi, sv)))
        return out


# ----------------------------------------------------------------------------- LP and certificates


def margin(rows, lo, hi, Y):
    """Exact Farkas margin of integer multipliers Y (dict row -> int):
    sum_r Y_r b_r - max_{lo <= x <= hi} sum_r Y_r a_r x.  Positive  =>  rows infeasible on the box."""
    c = {}
    tot = 0
    for r, y in Y.items():
        cols, coefs, rhs, _ = rows[r]
        tot += y * rhs
        for j, a in zip(cols.tolist(), coefs):
            c[j] = c.get(j, 0) + y * a
    for j, cj in c.items():
        tot -= cj * (hi[j] if cj > 0 else lo[j])
    return tot


_HIGHS = []


def highs_lp(rows, n, lo, hi, phase1=False, presolve=True):
    """Solve on one shared Highs object (creating it is slow); the caller reads the result before
    the next call."""
    import highspy
    from scipy.sparse import csr_matrix
    nr = len(rows)
    scale = np.array([max([abs(c) for c in r[1]] + [1]) for r in rows], dtype=float)
    indptr = np.cumsum([0] + [len(r[0]) for r in rows])
    indices = np.concatenate([r[0] for r in rows]) if nr else np.zeros(0, dtype=np.int64)
    data = np.concatenate([np.asarray(r[1], dtype=float) / s for r, s in zip(rows, scale)]) if nr \
        else np.zeros(0)
    A = csr_matrix((data, indices, indptr), shape=(nr, n))
    b = np.array([float(r[2]) for r in rows]) / scale
    if not _HIGHS:
        _HIGHS.append(highspy.Highs())
    h = _HIGHS[0]
    h.clearModel()
    h.clearSolver()
    h.setOptionValue("output_flag", False)
    h.setOptionValue("presolve", "on" if presolve else "off")
    lp = highspy.HighsLp()
    if phase1:
        from scipy.sparse import hstack, identity
        I = identity(nr, format="csr")
        A = hstack([A, I, -I]).tocsr()
        ncol = n + 2 * nr
        lp.col_cost_ = np.concatenate([np.zeros(n), np.ones(2 * nr)])
        lp.col_lower_ = np.concatenate([lo, np.zeros(2 * nr)]).astype(float)
        lp.col_upper_ = np.concatenate([hi, np.full(2 * nr, np.inf)]).astype(float)
    else:
        ncol = n
        lp.col_cost_ = np.zeros(n)
        lp.col_lower_ = np.asarray(lo, dtype=float)
        lp.col_upper_ = np.asarray(hi, dtype=float)
    Ac = A.tocsc()
    lp.num_col_, lp.num_row_ = ncol, nr
    lp.row_lower_, lp.row_upper_ = b, b
    lp.a_matrix_.format_ = highspy.MatrixFormat.kColwise
    lp.a_matrix_.start_ = Ac.indptr
    lp.a_matrix_.index_ = Ac.indices
    lp.a_matrix_.value_ = Ac.data
    h.passModel(lp)
    h.run()
    st = h.modelStatusToString(h.getModelStatus())
    return h, st, scale


def certificate(rows, n, lo, hi):
    """('INFEASIBLE', Y) with an exactly verified integer Farkas vector, or ('FEASIBLE', x) or
    ('UNKNOWN', None).  The LP solver only sees the columns with hi > 0 (a column with
    lo = hi = 0 adds nothing to any row or margin); Y is checked against all columns."""
    keep = np.nonzero(np.asarray(hi) > 0)[0]
    pos = np.full(n, -1, dtype=np.int64)
    pos[keep] = np.arange(len(keep))
    red = []
    for cols, coefs, rhs, tag in rows:
        m = pos[cols] >= 0
        red.append((pos[cols][m], [c for c, k in zip(coefs, m) if k], rhs, tag))
    st, val = _certificate(red, len(keep), np.asarray(lo)[keep], np.asarray(hi)[keep])
    if st == "FEASIBLE":
        x = np.zeros(n)
        x[keep] = val
        return st, x
    if st == "INFEASIBLE":
        assert margin(rows, lo, hi, val) > 0
    return st, val


def _certificate(rows, n, lo, hi):
    h, st, scale = highs_lp(rows, n, lo, hi)
    if st == "Optimal":
        return "FEASIBLE", np.array(h.getSolution().col_value)
    tries = []
    if st == "Infeasible":
        _, has, ray = h.getDualRay()
        if has:
            tries.append(np.array(ray))
        else:
            h2, st2, _ = highs_lp(rows, n, lo, hi, presolve=False)
            _, has, ray = h2.getDualRay()
            if has:
                tries.append(np.array(ray))
    h3, st3, _ = highs_lp(rows, n, lo, hi, phase1=True)
    if st3 == "Optimal" and h3.getInfo().objective_function_value > 1e-9:
        tries.append(np.array(h3.getSolution().row_dual))
    elif st3 == "Optimal" and not tries:
        return "FEASIBLE", np.array(h3.getSolution().col_value)[:n]
    for y in tries:
        z = y / scale
        mx = np.abs(z).max()
        if mx == 0:
            continue
        for bits in (8, 16, 24, 32, 40, 52):
            F = 2.0 ** bits / mx
            Y = {int(r): int(round(v * F)) for r, v in enumerate(z) if round(v * F) != 0}
            g = reduce(gcd, Y.values(), 0)
            for sg in (1, -1):
                Ys = {r: sg * v // g for r, v in Y.items()}
                if margin(rows, lo, hi, Ys) > 0:
                    return "INFEASIBLE", Ys
    return "UNKNOWN", None


class Search:
    """Branch and bound over 0/1 node variables for one leaf.  Tree nodes:
    {'L': Y} LP certificate, {'C': reason} counting conflict, {'B': opts, 'ch': [...]} branching
    (child i: opts[:i] -> 0, opts[i] -> 1; last child: all opts -> 0)."""

    def __init__(self, leaf, budget=20000):
        self.leaf, self.budget = leaf, budget
        self.rows0 = leaf.root_rows()
        self.lps = 0
        inst = leaf.inst
        self.labels = []
        n = leaf.n
        for t in inst.T2:
            lab = np.array([x["Srow"][t] for x in leaf.nodes], dtype=np.int64)
            for bi, bn in enumerate(BL):
                mi = inst.H["rows"][t][bn]
                self.labels.append((lab, bi, -1, mi))
                self.labels.append((lab, bi, 1, inst.model.size[bn] - mi))
        for v in range(inst.base.nc):
            rc = inst.arows[inst.P[v]]
            for bi, bn in enumerate(BL):
                self.labels.append((leaf.S[:, v], bi, -1, rc[bn]))
                self.labels.append((leaf.S[:, v], bi, 1, inst.model.size[bn] - rc[bn]))
        zero = np.zeros(n, dtype=np.int64)
        self.sizes = [(zero, bi, 0, inst.model.size[bn]) for bi, bn in enumerate(BL)]

    def state(self, fix0, fix1):
        """(alive, f1, conflict) for the fixings, by propagation to a fixed point:
        * a node incompatible with a selected node is removed;
        * counting core: a node without enough compatible partners of some (block, S) is removed;
        * cardinality groups (block sizes, type-2 columns, class-a minus counts, and the (block, S)
          partner counts of every selected node; each prescribes the exact number of selected
          nodes in the group): a full group loses its other nodes, a group with exactly the
          required number of nodes left has all of them selected, and a group with too many
          selected or too few left is a conflict.
        The propagation is recomputed by --check, so it is part of the certificate."""
        L = self.leaf
        f1set = set(fix1) | set(np.nonzero(L.fixed)[0].tolist())
        if set(fix0) & f1set:
            return None, sorted(f1set), "selected node excluded"
        alive = np.ones(L.n, dtype=bool)
        alive[list(fix0)] = False
        cleared = set()
        while True:
            for f in sorted(f1set - cleared):
                inc = L.Sm[f] == 0
                inc[f] = False
                alive &= ~inc
                cleared.add(f)
            f1 = sorted(f1set)
            if not alive[f1].all():
                return None, f1, "fixed pair incompatible"
            alive = L.core(alive, f1)
            if not alive[f1].all():
                return None, f1, "core removes a fixed node"
            f1m = np.zeros(L.n, dtype=bool)
            f1m[f1] = True
            groups = self.sizes + self.labels + [
                (L.Sm[f], bi, sv, int(L.req[f, bi, si]))
                for f in f1 for bi in range(3) for si, sv in ((0, -1), (1, 1))]
            changed = False
            new1 = set()
            for lab, bi, sv, req in groups:
                g = alive & (L.typ == bi) & (lab == sv)
                c1, ca = int((g & f1m).sum()), int(g.sum())
                if c1 > req or ca < req:
                    return None, f1, "cardinality conflict"
                if ca > c1 and c1 == req:
                    alive[g & ~f1m] = False
                    changed = True
                elif ca > c1 and ca == req:
                    new1.update(np.nonzero(g & ~f1m)[0].tolist())
                    changed = True
            if not changed:
                return alive, f1, None
            f1set |= new1

    def lp_data(self, alive, f1):
        L = self.leaf
        rows = list(self.rows0)
        for f in f1:
            rows += L.fixed_rows(f)
        lo = np.zeros(L.n, dtype=np.int64)
        lo[f1] = 1
        hi = alive.astype(np.int64)
        return rows, lo, hi

    def run(self, fix0=(), fix1=(), depth=0):
        if self.rows0 is None:
            return {"C": "block sum not integral"}, True
        alive, f1, why = self.state(fix0, fix1)
        if alive is None:
            return {"C": why}, True
        if self.lps >= self.budget:
            return {"U": 1}, False
        rows, lo, hi = self.lp_data(alive, f1)
        self.lps += 1
        st, val = certificate(rows, self.leaf.n, lo, hi)
        if st == "INFEASIBLE":
            return {"L": sorted(val.items())}, True
        if st == "UNKNOWN":
            return {"U": "lp"}, False
        x = val
        L = self.leaf
        f1m = np.zeros(L.n, dtype=bool)
        f1m[f1] = True
        best = None
        groups = list(self.labels) + [(L.Sm[f], bi, sv, int(L.req[f, bi, si]))
                                      for f in f1 for bi in range(3) for si, sv in ((0, -1), (1, 1))]
        for lab, bi, sv, req in groups:
            g = alive & (L.typ == bi) & (lab == sv)
            need = req - int((g & f1m).sum())
            opts = np.nonzero(g & ~f1m)[0]
            if need >= 1 and len(opts) and (best is None or len(opts) < len(best)):
                best = opts
        if best is None:
            frac = [(abs(x[j] - 0.5), j) for j in np.nonzero(alive & ~f1m)[0]]
            if not frac:
                return {"U": "integral"}, False
            best = np.array([min(frac)[1]])
        opts = sorted(best.tolist(), key=lambda j: -x[j])
        ch = []
        ok = True
        for i in range(len(opts) + 1):
            nf0 = tuple(fix0) + tuple(opts[:i])
            nf1 = tuple(fix1) + ((opts[i],) if i < len(opts) else ())
            sub, good = self.run(nf0, nf1, depth + 1)
            ch.append(sub)
            if not good:
                ok = False
                break
        return {"B": [int(o) for o in opts], "ch": ch}, ok

    def check(self, tree, fix0=(), fix1=()):
        """Exact re-verification of a stored tree (no LP solver)."""
        if self.rows0 is None:
            return tree == {"C": "block sum not integral"}
        alive, f1, why = self.state(fix0, fix1)
        if "C" in tree:
            return alive is None
        if alive is None:
            return False
        if "L" in tree:
            rows, lo, hi = self.lp_data(alive, f1)
            return margin(rows, lo, hi, dict(tree["L"])) > 0
        if "B" in tree:
            opts = tree["B"]
            if len(tree["ch"]) != len(opts) + 1:
                return False
            for i, sub in enumerate(tree["ch"]):
                nf0 = tuple(fix0) + tuple(opts[:i])
                nf1 = tuple(fix1) + ((opts[i],) if i < len(opts) else ())
                if not self.check(sub, nf0, nf1):
                    return False
            return True
        return False


# ----------------------------------------------------------------------------- driver


def run_all(args):
    model = Model(args.case, args.support)
    only = args.struct.split(",") if args.struct else None
    shard, nshard = (int(x) for x in args.shard.split("/"))
    t_start = time.time()
    logf = open(args.log, "a") if args.log else sys.stdout

    def log(d):
        logf.write(json.dumps(d) + "\n")
        logf.flush()

    certs = gzip.open(args.out, "wt") if args.out else None
    check_recs = None
    if args.check:
        check_recs = iter(gzip.open(args.check, "rt"))
    stats = {}
    li = 0
    # --shard-level: the counter runs over all instances, so the units of the whole run are dealt
    # out to the shards; otherwise leaves are dealt out by their index
    sh = None
    if args.shard_level is not None:
        sh = dict(level=args.shard_level, i=shard, n=nshard, count=0, cur=None)
    for inst in instances(model, log, only=only, max_dimF=args.maxdimF, orbits=not args.no_orbits):
        head = inst.head()
        for refs, filters, path in leaves(inst, dict(orbits=not args.no_orbits,
                                                     full_refs=args.full_refs, shard_level=sh), log):
            li += 1
            if sh is None and (li - 1) % nshard != shard:
                continue
            t0 = time.time()
            leaf = Leaf(inst, refs, filters)
            srch = Search(leaf, budget=args.budget)
            key = dict(head, path=path, refs=[r.to_json() for r in refs], leaf=li - 1)
            if sh is not None:
                key["unit"] = sh["cur"]
            if check_recs is not None:
                rec = json.loads(next(check_recs))
                assert rec["leaf"] == li - 1 and rec["path"] == [list(p) for p in path], rec["leaf"]
                ok = srch.check(rec["tree"]) and rec["resolved"]
                status = "VERIFIED" if ok else "CHECK FAILED"
                tree = None
            else:
                tree, ok = srch.run()
                status = "INFEASIBLE" if ok else "UNRESOLVED"
            stats[status] = stats.get(status, 0) + 1
            info = dict(key, refs=[(r.kind, r.typ, r.name) for r in refs], nodes=leaf.n,
                        lps=srch.lps, status=status, time=round(time.time() - t0, 2))
            if tree is not None:
                info["tree"] = tree_size(tree)
            log(info)
            if certs is not None:
                certs.write(json.dumps(dict(key, tree=tree, resolved=ok)) + "\n")
                certs.flush()
    if certs is not None:
        certs.close()
    if check_recs is not None and next(check_recs, None) is not None:
        stats["EXTRA RECORDS IN CERTIFICATE FILE"] = 1
    log(dict(summary=stats, leaves=li, shard=args.shard,
             units=None if sh is None else sh["count"], time=round(time.time() - t_start, 1),
             code=CODE_HASH, args=vars(args)))


def tree_size(t):
    if "B" in t:
        out = {"B": 1, "L": 0, "C": 0, "U": 0}
        for c in t["ch"]:
            s = tree_size(c)
            for k in out:
                out[k] += s[k]
        return out
    return {"B": 0, "L": int("L" in t), "C": int("C" in t), "U": int("U" in t)}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=["74", "94"])
    ap.add_argument("support", choices=["015", "0125", "012"])
    ap.add_argument("--struct")
    ap.add_argument("--maxdimF", type=int)
    ap.add_argument("--budget", type=int, default=20000)
    ap.add_argument("--out")
    ap.add_argument("--check")
    ap.add_argument("--log")
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--shard-level", type=int,
                    help="deal out the subtrees at this node-reference depth (and the leaves above "
                         "it) instead of single leaves; every shard enumerates only its own subtrees")
    ap.add_argument("--no-orbits", action="store_true")
    ap.add_argument("--full-refs", action="store_true",
                    help="node references until k = dim F (all leaves exact)")
    run_all(ap.parse_args())


if __name__ == "__main__":
    main()
