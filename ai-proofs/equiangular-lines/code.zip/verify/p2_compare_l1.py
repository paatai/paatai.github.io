"""Compare verify/deck59.gp's output with program 1's level-1 files (comparison only).

Usage: python3 p2_compare_l1.py SHARD GP_OUT [GP_OUT ...]
For every leaf in the GP outputs: the deck (as a set of descending coefficient lists) and h must
equal program 1's (data/level1_59/s<SHARD>/<idx>.json), and the verdicts must agree: program 1
"lp_A = infeasible" <=> GP "certificate valid"; GP "certificate FAILS" or "empty deck" is reported.
Prints one line per mismatch and a summary; exit status 1 on any mismatch.
"""

import json
import os
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def parse(path):
    out, cur = {}, None
    with open(path) as fh:
        for line in fh:
            line = line.strip()
            if line.startswith("leaf "):
                head = line[5:]
                lb = head.index("]")
                idx, delta, size, nodes = json.loads(head[:lb + 1])
                rest = head[lb + 2:]
                verdict = rest[:rest.index(" h ")]
                h = json.loads(rest[rest.index(" h ") + 3:rest.index(" ms ")])
                cur = {"delta": delta, "size": size, "nodes": nodes, "verdict": verdict, "h": h,
                       "deck": []}
                out[idx] = cur
            elif line.startswith("["):
                cur["deck"].append(json.loads(line))
    return out


def main():
    s = int(sys.argv[1])
    gp = {}
    for p in sys.argv[2:]:
        gp.update(parse(p))
    bad = 0
    stats = {"compared": 0, "excluded both": 0, "open both": 0, "program 1 missing": 0}
    for idx in sorted(gp):
        g = gp[idx]
        if len(g["deck"]) != g["size"]:
            print(f"leaf {idx}: GP output truncated")
            bad += 1
            continue
        path = os.path.join(ROOT, "data", "level1_59", f"s{s}", f"{idx}.json")
        if not os.path.exists(path):
            stats["program 1 missing"] += 1
            continue
        with open(path) as fh:
            m = json.load(fh)
        stats["compared"] += 1
        if m["F1"] is not None or m["F2"] is not None:
            print(f"leaf {idx}: program 1 excludes by F1/F2 ({m['F1']}, {m['F2']}); GP: {g['verdict']}")
            bad += 1
            continue
        mine = sorted(map(list, m["deck"]))
        if mine != sorted(g["deck"]):
            print(f"leaf {idx}: DECK MISMATCH ({len(mine)} vs {len(g['deck'])})")
            bad += 1
        if m["h"] != g["h"]:
            print(f"leaf {idx}: h MISMATCH")
            bad += 1
        p1_excl = m["lp_A"] == "infeasible"
        if p1_excl and g["verdict"] != "certificate valid":
            print(f"leaf {idx}: program 1 infeasible (A) but GP says {g['verdict']}")
            bad += 1
        elif not p1_excl and g["verdict"] not in ("no certificate",):
            print(f"leaf {idx}: program 1 open at A but GP says {g['verdict']}")
            bad += 1
        else:
            stats["excluded both" if p1_excl else "open both"] += 1
    print(f"shard {s}: {stats}, mismatches {bad}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
