"""Exact rational feasibility for {A x = b, x >= 0} (Phase-1 simplex, Bland's rule).

Returns ("feasible", x) with x an exact rational solution, or ("infeasible", y) with an exact
Farkas vector: A^T y >= 0 and b.y < 0. Both answers are re-checked exactly by the caller-facing
helpers check_feasible / check_farkas. Intended for small systems (hundreds of columns).
"""

from fractions import Fraction


def check_feasible(A, b, x):
    if any(v < 0 for v in x):
        return False
    return all(sum(Fraction(a) * v for a, v in zip(row, x)) == bi for row, bi in zip(A, b))


def check_farkas(A, b, y):
    ncol = len(A[0]) if A else 0
    for j in range(ncol):
        if sum(Fraction(A[i][j]) * y[i] for i in range(len(A)) if A[i][j]) < 0:
            return False
    return sum(Fraction(bi) * yi for bi, yi in zip(b, y)) < 0


def solve(A, b):
    m = len(A)
    n = len(A[0]) if m else 0
    sign = [(-1 if bi < 0 else 1) for bi in b]
    # tableau rows: [A_i * sign | I | b_i * sign]
    T = []
    for i in range(m):
        row = [Fraction(sign[i] * A[i][j]) for j in range(n)]
        row += [Fraction(1 if k == i else 0) for k in range(m)]
        row.append(Fraction(sign[i] * b[i]))
        T.append(row)
    basis = [n + i for i in range(m)]
    cost = [Fraction(0)] * n + [Fraction(1)] * m
    ncols = n + m

    def reduced(j):
        return cost[j] - sum(cost[basis[i]] * T[i][j] for i in range(m))

    while True:
        enter = None
        for j in range(ncols):
            if j in basis:
                continue
            if reduced(j) < 0:
                enter = j
                break
        if enter is None:
            break
        best, leave = None, None
        for i in range(m):
            a = T[i][enter]
            if a > 0:
                r = T[i][-1] / a
                if best is None or r < best or (r == best and basis[i] < basis[leave]):
                    best, leave = r, i
        if leave is None:
            raise RuntimeError("phase 1 unbounded (impossible)")
        piv = T[leave][enter]
        T[leave] = [v / piv for v in T[leave]]
        for i in range(m):
            if i != leave and T[i][enter] != 0:
                f = T[i][enter]
                Ti, Tl = T[i], T[leave]
                T[i] = [vi - f * vl for vi, vl in zip(Ti, Tl)]
        basis[leave] = enter
    obj = sum(cost[basis[i]] * T[i][-1] for i in range(m))
    if obj == 0:
        x = [Fraction(0)] * n
        for i in range(m):
            if basis[i] < n:
                x[basis[i]] = T[i][-1]
        assert check_feasible(A, b, x)
        return "feasible", x
    # duals of phase 1: w_k = cost_B B^{-1} e_k, read from the artificial columns:
    # reduced cost of artificial k is 1 - w_k (scaled system), so w_k = 1 - reduced(n + k).
    w = [Fraction(1) - reduced(n + k) for k in range(m)]
    y = [-w[k] * sign[k] for k in range(m)]
    assert check_farkas(A, b, y)
    return "infeasible", y
