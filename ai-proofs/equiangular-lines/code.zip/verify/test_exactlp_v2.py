"""The exact LP of program 1, new (src/eqlines/exactlp.py) against old (verify/ref/exactlp_v1.py).

v1 (used until 24 Oct 2026, 06:24 UTC): phase 1 on a dense Fraction tableau, Bland's rule.
v2: phase-1 revised simplex over Q with exact flint solves, Dantzig's rule, Bland's rule after
50 pivots without decrease.  Both return ("feasible", x) or ("infeasible", y) and check the
answer exactly, so only the running time may differ.  This script requires equal statuses and
re-checks every answer of v2 here as well:
  1. random systems {A x = b, x >= 0} (feasible, infeasible, degenerate, b = 0), 3,000 per seed;
  2. the stage-(S) star systems of every support of size <= MAXR inside the open pair cliques
     (at most 12 members) of the given leaves, rebuilt from their level-2 records;
  3. v2 alone on the stored systems of data/validation/exactlp/ (supports on which v1 ran for
     more than an hour without an answer).
Usage: python3 verify/test_exactlp_v2.py [--seeds 1,2,3] [--leaf S/IDX/MAXR ...] [--hard]
"""

import argparse
import glob
import json
import os
import random
import sys
import time
from itertools import combinations

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
sys.path.insert(0, os.path.join(ROOT, "verify", "ref"))
import exactlp_v1 as v1  # noqa: E402
from eqlines import exactlp as v2  # noqa: E402


def check(A, b, status, vec):
    if status == "feasible":
        assert v2.check_feasible(A, b, vec)
    else:
        assert v2.check_farkas(A, b, vec)


def random_systems(seed):
    rng = random.Random(seed)
    cnt, t1, t2 = {}, 0.0, 0.0
    for case in range(3000):
        m, n, kind, R = rng.randint(1, 9), rng.randint(1, 12), rng.randint(0, 3), rng.choice([1, 2, 5, 100])
        A = [[rng.randint(-R, R) if rng.random() < 0.6 else 0 for _ in range(n)] for _ in range(m)]
        if kind == 0:
            x0 = [rng.randint(0, 3) if rng.random() < 0.5 else 0 for _ in range(n)]
            b = [sum(a * v for a, v in zip(row, x0)) for row in A]
        elif kind == 1:
            b = [rng.randint(-R, R) for _ in range(m)]
        elif kind == 2:
            base = A[: max(1, m // 2)]
            A = [list(rng.choice(base)) for _ in range(m)]
            x0 = [rng.randint(0, 1) for _ in range(n)]
            b = [sum(a * v for a, v in zip(row, x0)) for row in A]
            if rng.random() < 0.5:
                b[rng.randrange(m)] += rng.choice([-1, 1])
        else:
            b = [0] * m
        t0 = time.time()
        s1, _ = v1.solve(A, b)
        ta = time.time()
        s2, y2 = v2.solve(A, b)
        tb = time.time()
        t1, t2 = t1 + ta - t0, t2 + tb - ta
        if s1 != s2:
            print(f"MISMATCH seed {seed} case {case}: v1 {s1}, v2 {s2}", flush=True)
            return False
        check(A, b, s2, y2)
        cnt[(kind, s2)] = cnt.get((kind, s2), 0) + 1
    print(f"random seed {seed}: 3000 systems, statuses equal {sorted(cnt.items())}; "
          f"v1 {t1:.1f}s v2 {t2:.1f}s", flush=True)
    return True


def leaf_supports(s, idx, maxr):
    from eqlines.deck import SpecPoly
    from eqlines.jacobi import PairSpace
    from eqlines.rr import coeffs_to_poly
    from eqlines.star import StarSystem, poly
    from run_level1_59 import chi59, load_psis
    psis = load_psis(os.path.join(ROOT, "runs", "enum59_gp", f"gp_s{s}of16.jsonl"))
    with open(os.path.join(ROOT, "data", "level1_59", f"s{s}", f"{idx}.json")) as fh:
        L1 = json.load(fh)
    with open(os.path.join(ROOT, "data", "level2_59", f"s{s}", f"{idx}.json")) as fh:
        L2 = json.load(fh)
    assert L1["psi"] == psis[idx] == L2["psi"]
    sp = SpecPoly(chi59(psis[idx]))
    D = [c for c, ok in zip(L1["deck"], L1["class_ok"]) if ok]
    J = L2["J"]
    ps = PairSpace(sp, nonzero_at=[-5])
    G = [coeffs_to_poly(c) for c in D]
    pairs = {}
    for key, found in J["pairs"].items():
        a, b = map(int, key.split(","))
        pairs[(a, b)] = [poly(P) for _sig, _psi, P in found]
    st = StarSystem(sp, ps, G, sp.h, pairs)
    seen, cnt, t1, t2 = set(), {}, 0.0, 0.0
    for C in J["open_cliques"]:
        if len(C) > 12:
            continue
        for r in range(1, min(maxr, len(C)) + 1):
            for U in combinations(sorted(C), r):
                if U in seen:
                    continue
                seen.add(U)
                built = st.build(U)
                if built is None:
                    continue
                rows, rhs, names = built
                if not names:
                    continue
                t0 = time.time()
                s1, _ = v1.solve(rows, rhs)
                ta = time.time()
                s2, y2 = v2.solve(rows, rhs)
                tb = time.time()
                t1, t2 = t1 + ta - t0, t2 + tb - ta
                if s1 != s2:
                    print(f"MISMATCH s{s}/{idx} support {U}: v1 {s1}, v2 {s2}", flush=True)
                    return False
                check(rows, rhs, s2, y2)
                cnt[s2] = cnt.get(s2, 0) + 1
    print(f"s{s}/{idx}, supports of size <= {maxr}: {sum(cnt.values())} systems, statuses equal "
          f"{sorted(cnt.items())}; v1 {t1:.1f}s v2 {t2:.1f}s", flush=True)
    return True


def hard():
    ok = True
    for fn in sorted(glob.glob(os.path.join(ROOT, "data", "validation", "exactlp", "lp_*.json"))):
        with open(fn) as fh:
            d = json.load(fh)
        t0 = time.time()
        s2, y2 = v2.solve(d["rows"], d["rhs"])
        check(d["rows"], d["rhs"], s2, y2)
        print(f"{os.path.basename(fn)} m={len(d['rows'])} n={len(d['rows'][0])}: v2 {s2} "
              f"(answer checked) {time.time() - t0:.1f}s", flush=True)
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--seeds", default="1,2,3")
    ap.add_argument("--leaf", action="append", default=[])
    ap.add_argument("--hard", action="store_true")
    a = ap.parse_args()
    ok = True
    for seed in [int(v) for v in a.seeds.split(",") if v]:
        ok = random_systems(seed) and ok
    for spec in a.leaf:
        s, idx, maxr = map(int, spec.split("/"))
        ok = leaf_supports(s, idx, maxr) and ok
    if a.hard:
        ok = hard() and ok
    print("EXACTLP V2 TEST:", "ALL PASS" if ok else "FAIL", flush=True)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
