"""Compare the leaves and leaf node lists of two versions of c35_cert.py.

    python3 c35_cert_nodes_compare.py OLD.py NEW.py CASE SUPPORT [--struct S] [--full-refs]
        [--shard i/n --shard-level L] [--max-leaves N]

Both versions enumerate the leaves of the same run; for every leaf the (refs, filters) and the full
node data (type, steps, W, C, R, eps, S row, row counts, fixed) must agree exactly and in order."""
import argparse
import importlib.util
import itertools
import sys


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


def node_key(x):
    return (x["typ"], tuple(int(v) for v in x["steps"]), int(x["W"]), tuple(int(c) for c in x["C"]),
            int(x["R"]), int(x["eps"]), tuple(sorted((k, int(v)) for k, v in x["Srow"].items())),
            tuple(sorted(x["rc"].items())), bool(x.get("fixed")))


def leaf_stream(mod, args):
    model = mod.Model(args.case, args.support)
    only = args.struct.split(",") if args.struct else None
    sh = None
    if args.shard_level is not None:
        i, n = (int(x) for x in args.shard.split("/"))
        sh = dict(level=args.shard_level, i=i, n=n, count=0, cur=None)
    opts = dict(orbits=True, full_refs=args.full_refs)
    if sh is not None:
        opts["shard_level"] = sh
    for inst in mod.instances(model, lambda d: None, only=only):
        for refs, filters, path in mod.leaves(inst, opts, lambda d: None):
            leaf = mod.Leaf(inst, refs, filters)
            yield (inst.head(), [r.key() for r in refs], path,
                   [node_key(x) for x in leaf.nodes], leaf.Sm.tobytes())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("old")
    ap.add_argument("new")
    ap.add_argument("case")
    ap.add_argument("support")
    ap.add_argument("--struct")
    ap.add_argument("--full-refs", action="store_true")
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--shard-level", type=int)
    ap.add_argument("--max-leaves", type=int)
    args = ap.parse_args()
    A = leaf_stream(load(args.old, "cert_old"), args)
    B = leaf_stream(load(args.new, "cert_new"), args)
    n = bad = nodes = 0
    for a, b in itertools.zip_longest(A, B):
        if args.max_leaves is not None and n >= args.max_leaves:
            break
        n += 1
        if a is None or b is None or a != b:
            bad += 1
            print("MISMATCH at leaf", n - 1, None if a is None else a[2], None if b is None else b[2])
            if bad > 5:
                break
        else:
            nodes += len(a[3])
    print(f"leaves compared {n}, nodes {nodes}, mismatches {bad}")
    sys.exit(1 if bad else 0)


if __name__ == "__main__":
    main()
