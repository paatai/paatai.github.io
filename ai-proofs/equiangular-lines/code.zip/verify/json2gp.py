"""Transcribe JSON files (src/cert59.py exports) into PARI/GP literals, without interpreting them.

  JSON list   -> GP vector
  JSON object -> GP vector of [key, value] pairs (keys as GP strings, in file order)
  string      -> bare GP rational if it is an integer or a fraction "p/q", else a GP string
  int         -> integer;  true/false -> 1/0;  null -> "null"

Usage: python3 json2gp.py IN.json OUT.gp NAME     (OUT.gp defines NAME = <literal>;)
"""

import json
import re
import sys

NUM = re.compile(r"-?\d+(/\d+)?")


def emit(v, out):
    if isinstance(v, bool):
        out.append("1" if v else "0")
    elif v is None:
        out.append('"null"')
    elif isinstance(v, int):
        out.append(str(v))
    elif isinstance(v, str):
        if NUM.fullmatch(v):
            out.append(v)
        else:
            assert '"' not in v and "\\" not in v, v
            out.append('"' + v + '"')
    elif isinstance(v, list):
        out.append("[")
        for i, e in enumerate(v):
            if i:
                out.append(",")
            emit(e, out)
        out.append("]")
    elif isinstance(v, dict):
        out.append("[")
        for i, (k, e) in enumerate(v.items()):
            if i:
                out.append(",")
            assert isinstance(k, str) and '"' not in k and "\\" not in k, k
            out.append('["' + k + '",')
            emit(e, out)
            out.append("]")
        out.append("]")
    else:
        raise TypeError(f"unsupported JSON value {v!r}")


def main():
    src, dst, name = sys.argv[1:4]
    with open(src) as fh:
        data = json.load(fh)
    out = [name, " = "]
    emit(data, out)
    out.append(";\n")
    with open(dst, "w") as fh:
        fh.write("".join(out))


if __name__ == "__main__":
    main()
