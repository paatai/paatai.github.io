"""Negative tests for the row-resolvent system (eqlines.star.ResolventStar).

For genuine Seidel matrices S:
  1. for every vertex i, with g_i = chi_{S[i]}/mu and psihat_ij = S_ij psi_ij (psi_ij from
     t_k = (S^k)_ij), the identities
        (L) sum_{j != i} psihat_ij = x g_i - Min,
        (Q) sum_{j != i} psihat_ij(x) psihat_ij(y) = (g_i(x) Min(y) - g_i(y) Min(x))/(y - x) - g_i(x) g_i(y)
     are checked exactly ((Q) as a polynomial identity in Z[x, y], via coefficients);
  2. the system built by ResolventStar for the true support, with the true psihat sets, is
     satisfied exactly by the true counts (n_g and, for every vertex i, the counts of its row).
Matrices: random Seidel matrices, vertex deletions from the unitary systems with 28 and 126
lines, the four 57-line systems in R^18, 72 lines in R^19 and 90 lines in R^20.
"""

import random
import sys
import time
from fractions import Fraction
from pathlib import Path

from flint import fmpz_mat, fmpz_poly

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "src"))
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.seidel import random_seidel  # noqa: E402
from eqlines.star import ResolventStar  # noqa: E402

CON = Path(__file__).resolve().parents[1] / "data" / "constructions"


def read_seidel(path):
    rows = [ln.strip() for ln in path.read_text().splitlines() if ln.strip() and not ln.startswith("#")]
    n = int(rows[0])
    return [[{"0": 0, "+": 1, "-": -1}[ch] for ch in r] for r in rows[1:1 + n]]


def minor(S, drop):
    keep = [k for k in range(len(S)) if k not in drop]
    return [[S[a][b] for b in keep] for a in keep]


def bivariate_coeffs_lhs(us):
    """Coefficient matrix C[a][b] of sum_u u(x) u(y) (ascending powers)."""
    d = max(u.degree() for u in us) + 1 if us else 1
    C = [[0] * d for _ in range(d)]
    for u in us:
        c = [int(v) for v in u.coeffs()] + [0] * (d - len(u.coeffs()))
        for a in range(d):
            if c[a]:
                for b in range(d):
                    C[a][b] += c[a] * c[b]
    return C


def bivariate_coeffs_rhs(g, M):
    """Coefficients of (g(x) M(y) - g(y) M(x)) / (y - x) - g(x) g(y), ascending, as a dict."""
    gc = [int(v) for v in g.coeffs()]
    mc = [int(v) for v in M.coeffs()]
    # (x^a y^b - x^b y^a)/(y - x) for a < b equals sum_{k=a}^{b-1} x^k y^(a+b-1-k) ... derived:
    # x^a y^b - x^b y^a = x^a y^a (y^(b-a) - x^(b-a)) and (y^m - x^m)/(y - x) = sum_k x^k y^(m-1-k).
    out = {}

    def add(a, b, v):
        if v:
            out[(a, b)] = out.get((a, b), 0) + v

    for a, ga in enumerate(gc):
        for b, mb in enumerate(mc):
            v = ga * mb  # term g_a x^a * M_b y^b  minus  g_a y^a * M_b x^b
            if not v or a == b:
                continue
            if a < b:
                m = b - a
                for k in range(m):
                    add(a + k, a + m - 1 - k, v)
            else:
                m = a - b
                for k in range(m):
                    add(b + k, b + m - 1 - k, -v)
    for a, ga in enumerate(gc):
        for b, gb in enumerate(gc):
            add(a, b, -ga * gb)
    return out


def check(S, label, nverts=None, rng=None):
    n = len(S)
    A = fmpz_mat(S)
    p = A.charpoly()
    sp = SpecPoly(p)
    d = sp.delta
    M = sp.minp
    minc = [int(v) for v in reversed(M.coeffs())]
    powers = [fmpz_mat(n, n, [1 if a == b else 0 for a in range(n) for b in range(n)])]
    for _ in range(d):
        powers.append(powers[-1] * A)
    x = fmpz_poly([0, 1])
    g = {}
    for i in range(n):
        q, r = divmod(fmpz_mat(minor(S, {i})).charpoly(), sp.mu)
        assert r == 0
        g[i] = q
    psihat = {}
    for i in range(n):
        for j in range(i + 1, n):
            t = [int(powers[k][i, j]) for k in range(d)]
            c = [sum(minc[a] * t[rr - a] for a in range(rr + 1)) for rr in range(d)]
            psi = fmpz_poly(list(reversed(c)))
            psihat[(i, j)] = psihat[(j, i)] = S[i][j] * psi
    verts = range(n) if nverts is None else rng.sample(range(n), nverts)
    for i in verts:
        us = [psihat[(i, j)] for j in range(n) if j != i]
        lhs = sum(us, fmpz_poly([0]))
        assert lhs == x * g[i] - M, (label, i, "(L)")
        CL = bivariate_coeffs_lhs(us)
        CR = bivariate_coeffs_rhs(g[i], M)
        dd = len(CL)
        for (a, b), v in CR.items():
            if a >= dd or b >= dd:
                assert v == 0, (label, i, "(Q) degree", a, b)
        for a in range(dd):
            for b in range(dd):
                assert CL[a][b] == CR.get((a, b), 0), (label, i, "(Q)", a, b)
    # the built system, true support
    keys = {}
    types = []
    deck = []
    for i in range(n):
        k = tuple(int(v) for v in g[i].coeffs())
        if k not in keys:
            keys[k] = len(deck)
            deck.append(g[i])
        types.append(keys[k])
    U = sorted(set(types))
    sets = {}
    for i in range(n):
        for j in range(n):
            if i != j and types[i] <= types[j]:
                sets.setdefault((types[i], types[j]), {})[tuple(int(v) for v in psihat[(i, j)].coeffs())] = psihat[(i, j)]
    rs = ResolventStar(sp, deck, sp.h, {k: list(v.values()) for k, v in sets.items()})
    rows, rhs, names = rs.build(U)
    cnt = {a: types.count(a) for a in U}
    for i in verts:
        f = types[i]
        xv = []
        for nm in names:
            if nm[0] == "n":
                xv.append(cnt[nm[1]] - 1)
                continue
            _, ff, gg, k = nm
            if ff != f:
                # rows of other types are filled from a vertex of that type
                i2 = types.index(ff)
            else:
                i2 = i
            u = rs.pairs[(ff, gg)][k]
            xv.append(sum(1 for j in range(n) if j != i2 and types[j] == gg and psihat[(i2, j)] == u))
        for row, b in zip(rows, rhs):
            assert sum(Fraction(a) * v for a, v in zip(row, xv)) == b, (label, i, "built system")
    return len(list(verts)), d, len(U)


def main():
    t0 = time.time()
    rng = random.Random(4242)
    tot = 0
    for N in range(6, 15):
        for _ in range(8):
            S = random_seidel(N, rng, rng.choice([0.3, 0.5, 0.7]))
            k, d, u = check(S, f"random {N}")
            tot += k
        print(f"random Seidel matrices of order {N}: 8 OK", flush=True)
    for name, ks, reps in [("classical/unitary_q3_n28_d7.seidel", [0, 1, 2, 3, 5], 2),
                           ("classical/unitary_q5_n126_d21.seidel", [0, 1, 2, 3], 1),
                           ("known/gsy23_F1_n57_d18.seidel", [0, 1, 2], 1),
                           ("known/gsy23_F2_n57_d18.seidel", [0, 1], 1),
                           ("known/gsy23_F3_n57_d18.seidel", [0, 1], 1),
                           ("known/gsy23_F4_n57_d18.seidel", [0, 1], 1),
                           ("known/u35_sec2_n72_d19.seidel", [0, 1, 2], 1),
                           ("known/u35_sec1_n90_d20.seidel", [0, 1, 2], 1)]:
        S0 = read_seidel(CON / name)
        n0 = len(S0)
        for k in ks:
            for rep in range(reps):
                keep = sorted(rng.sample(range(n0), n0 - k))
                S = [[S0[i][j] for j in keep] for i in keep]
                nv = None if len(S) <= 60 else 12
                c, d, u = check(S, f"{name} minus {k}", nv, rng)
                tot += c
                print(f"{name} minus {k}: order {len(S)}, {d} distinct eigenvalues, {u} deck "
                      f"members, {c} vertex rows OK", flush=True)
    print(f"resolvent negative tests OK: {tot} vertex rows, {time.time() - t0:.0f} s")


if __name__ == "__main__":
    main()
