# Referee's guide: EQ-UP claims

EQ-UP, 24 Oct 2026 (first version). An entry point for a referee; it adds no mathematics. The
statements and proofs are in `MAIN_RESULT.pdf` (source `MAIN_RESULT.tex`, `t18_sections.tex`)
and `CLAIMS.md`; the audit requests, with every command and code hash, in `AUDIT_REQUEST.md`; the
audit verdicts in `/cursor/stores/bot/eqlines/EQ-AUD/AUDIT.md`. Paths are relative to the EQ-UP
mirror `/cursor/stores/bot/eqlines/EQ-UP/` (the git repository has the same layout, without the
files listed under "Store-only files" in `AUDIT_REQUEST.md`).

| claim | statement | paper | audit | referee |
| --- | --- | --- | --- | --- |
| U1 | no 421 equiangular lines in R^44, so N(44) <= 420 (published 422) | Thm 1, sec. 3–5 | A.10 VALID WITH FIXES (applied) | EQ-REF1 VALID |
| T20 | no 94 lines in R^20, so N(20) <= 93 (published 94 [GSY21]; 90 lines exist) | Thm 2, sec. 7–11 | A.19 VALID | EQ-REF4 VALID WITH FIXES (F1–F4, text only, applied) |
| **T19** | no 74 lines in R^19, so **N(19) <= 73** (published 74 [GSY21]; 72 lines exist) | Thm 3, sec. 7–11 | **A.28 VALID** (no fix) | **pending** |
| **T18** | no 59 lines in R^18, so **N(18) <= 58** (published 59 [GS24]; 57 lines exist [GSY23]) | Thm 4, sec. 12 | **filed 24 Oct 08:37 UTC, not audited yet** | – |

All four are computer-assisted. Our standard (`CLAIMS.md`, top): exact arithmetic, complete case
coverage, and two independently written programs that agree; floating point may propose but
never decides.

## T19: N(19) <= 73

**Same proof as T20.** T19 runs T20's chain on the 74-line data, with the same code:
[GSY21] reduction (169 candidate spectra) -> U4 level 1 -> U5 level 2 (only #3 and #35 left; #3 is
EQ-LIT's C5) -> U6 structure of #35 -> U7 base-class model -> every leaf excluded by program 1
(U8, CP-SAT) and by program 2 (U9, exact integer Farkas certificates; no shared code). EQ-REF4
refereed this chain for 94 lines (`EQ-REF4/REFEREE.md`); its four fixes are to the text and are
applied for both theorems. What is specific to 74 lines:

1. **Data.** chi_S = (x+5)^55 (x-15)^6 phi with phi of degree 13, 169 candidates (Lemma 15:
   T = 52 at kappa = 15 forces six eigenvalues 15); 22 survive level 1 (U4), and
   level 2 (U5) leaves #3 and #35. #35 is chi_S = (x-17)(x-15)^15(x-11)^3(x+5)^55 (sec. 7).
   U4 and U5 cover 74 and 94 together (A.15, A.16 VALID, three programs each).
2. **Structure of #35 for 74** (sec. 8, U6): three supports, (0,1,5), (0,1,2,5) and (0,1,2), each
   with forced type counts (`src/star_counts_35.py`; `verify/c35_structure.py` checks (1)–(4)).
3. **Size.** In support (0,1,5) the class graph is a union of even cycles of total length 16:
   the seven partitions (16), (12,4), (10,6), (8,8), (8,4,4), (6,6,4), (4,4,4,4). Program 2 has
   335,020 leaves in 15 certificate files (T20: 444 leaves), 136,587 of them in (4,4,4,4).
4. **The 42 hard leaves of (4,4,4,4)** were closed by `verify/c35_cert_hard.py`, which only
   changes the branching order (type-1 groups first); its trees have `c35_cert.py`'s format, and
   `c35_cert_resume.py --from` merged them into one file per shard. Neither needs to be trusted:
   the unchanged `--check` rebuilds every leaf and replays every tree of the merged files.
5. **Program 1 for (4,4,4,4)** needed a third reference (`src/c35k3.py`); `verify/c35k3_coverage.py`
   re-enumerates all 1,490 second-level leaves and their third-level leaves and requires an
   INFEASIBLE record for each (`logs/c35k3_coverage_final.txt`: COVERAGE COMPLETE).

**Independent confirmations.** EQ-AUD A.28: their own program 3 excludes every case (298,259
leaves; every LP refutation an exact Farkas vector), and all 15 of our certificate files pass the
frozen `--check` on their machine. EQ-LIT's C18 is a further program for the last step (A.27 VALID
WITH FIXES; T19 does not depend on it).

**Quick checks** (commands in `AUDIT_REQUEST.md`, "For T19"; times on a loaded 8-core machine):

| check | command (in `verify/`) | expected | time |
| --- | --- | --- | --- |
| structure inputs | `python3 c35_structure.py` | `C35 STRUCTURE CHECK: ALL PASS` | seconds |
| nine smaller files | `python3 c35_cert_checkall.py ../logs/cert_final ../runs/cert_final /tmp/chk1 --only 74_015_16 74_015_12_4 74_015_10_6 74_015_8_8 74_015_8_4_4_s0 74_015_8_4_4_s1 74_015_6_6_4_s0 74_015_6_6_4_s1 74_0125` | nine `PASS` | 20 min |
| (4,4,4,4), merged | `python3 c35_cert_checkall.py ../logs/cert_final_merged ../runs/cert_final_merged /tmp/chk3` | two `PASS` | 1 h 45 min |
| (0,1,2), one shard | `python3 c35_cert_checkall.py ../logs/cert_final ../runs/cert_final /tmp/chk2_0 --only 74_012_s0` | `PASS` | 80 min |
| U9 table | `python3 c35_cert_table.py` on the 15 plain logs | 136,587 INFEASIBLE in (0,1,5) C4,C4,C4,C4 | seconds |

Python 3.12 with numpy; the search needs highspy, `--check` needs no LP solver. Do not run Python
with `-O` (it strips the asserts).

## T18: N(18) <= 58

**Proof** (sec. 12; `CLAIMS.md` T18 has the same content with the data). Since 59 > 2·18, the
angle is arccos(1/a) with a odd; a = 3 allows at most 34 lines and a >= 7 fewer than 28 (relative
bound), so a = 5, and -5 has multiplicity 41 (Lemma 19). The forcing lemma
(Lemma 10, the step in [GSY21, Lemma 3.1]) at kappa = 11 gives the eigenvalue 11, so
chi_S = (x+5)^41 (x-11) psi(x-11) with psi of degree 17. An exact enumeration with the
congruences (E), (P), (L) leaves 1,214 candidates (Lemma 20). Each is excluded by one of: level 1
(an exact Farkas vector on its deck), level 2 (compatibility (C), pair polynomials (J),
vertex-star systems (S)), level 3 (triangle types, edge systems) with stage R for large pair
cliques, or, for the one candidate that level 3 leaves open (s5/25), stage X (Lemma 21,
Proposition 22 and Corollary 23, sec. 12.5).

**Two programs on every step.** Program 1 (Python, python-flint, HiGHS only as a proposer) and
program 2 (PARI/GP, written from the statements in the paper; it reads only program 1's
certificates and checks them against its own systems). Result (`logs/tally59_final.txt`): all
1,214 excluded by both, each at the same stage (572 level 1, 526 (C), 33 (J), 53 (S), 17 stage R,
11 level 3, 1 level 3 with stage R, 1 stage X), no disagreement in decks, cliques, pair types,
open supports or certificates, and both enumerations equal on all 16 shards. EQ-AUD's own
pipeline (`EQ-AUD/audits/t18`) reached the same count at every stage before the filing.

**Where an error common to both programs would sit** (both implement the same statements, so
their agreement does not test these; the full list is in `AUDIT_REQUEST.md`, T18, "What to
review"): the odd-order rules ((F1), (D3), the compatibility parity, (J1), (J5), the triangle
conditions (T1)–(T5)) and the soundness of the stage-R relaxation; Lemma s525 (pen and paper);
the completeness of the class lists P_{59,7} and P_{58,7} (both reach the bounds of [GY19]); the
prefix tests of (P) and (L) in the enumeration.

**Quick checks.** One leaf through both programs: the commands in `AUDIT_REQUEST.md`, T18,
"Reproduce one leaf" (e.g. a level-1 leaf takes seconds; s5/25 is the stage-X leaf). The tally:
`python3 verify/tally59.py` (`--list` for per-leaf verdicts). Store-only records (level 2 and the
certificate exports, too large for git): `sha256sum -c MANIFEST59.sha256` in the mirror.
`data/level2_59/s11/26.json` (112 MB) exceeds the store's file size limit and is mirrored as
`data/level2_59/s11/26.json.gz`; run `gzip -dk` on it first.

## Not claimed

`CLAIMS.md` F1–F4 and the paper's "What remains": 58 lines in R^18, 73 in R^19, 93 in R^20 and
420 in R^44 are open; the method of T18 does not reach them within the deadline (paper, sec. 13).
