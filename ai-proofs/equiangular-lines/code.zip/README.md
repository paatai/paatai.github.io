# EQ-UP: upper bounds for equiangular lines

Working repository of **EQ-UP**, the upper-bound agent of the equiangular-lines team
(coordination: `/cursor/stores/bot/eqlines/COMMON.md`). Every exclusion is exact: integer and
rational arithmetic, certified ball arithmetic, and exact Farkas certificates. Every computer step
is done by two independently written programs.

## Results

| bound | published bound | claim and status |
| --- | --- | --- |
| N(44) <= 420 (no 421 lines in R^44) | 422 | U1: EQ-AUD A.10 VALID WITH FIXES (applied), referee EQ-REF1 VALID |
| N(20) <= 93 (no 94 lines in R^20) | 94 [GSY21] | T20: EQ-AUD A.19 VALID, referee EQ-REF4 VALID WITH FIXES (applied) |
| N(19) <= 73 (no 74 lines in R^19) | 74 [GSY21] | T19: EQ-AUD A.28 VALID; referee pending |
| N(18) <= 58 (no 59 lines in R^18) | 59 [GS24] | T18: filed for audit on 24 Oct 2026, 08:37 UTC |

A claim becomes a team result only when EQ-AUD and a referee both rate it VALID. Reporting is the
coordinator's job.

| File | Contents |
| --- | --- |
| `MAIN_RESULT.tex` / `.pdf` | Paper: Theorems 1–4 with proofs, computations and negative tests |
| `CLAIMS.md` | Every claim, tagged PROVED / CONDITIONAL / NUMERICAL / FAILED |
| `STATUS.md` | Current state, open work, timeline |
| `AUDIT_REQUEST.md` | What EQ-AUD is asked to check, with the commands for every step |
| `REFEREE_GUIDE.md` | Entry point for referees: each claim, where its proof and audit are, and quick checks |

## Layout

| Path | Contents |
| --- | --- |
| `src/eqlines/` | Library: real-rooted enumeration (`rr.py`), Seidel and type-2 tools (`seidel.py`), interlacing decks (`deck.py`), exact Farkas certificates (`lpcert.py`, `farkas.py`), exact simplex (`exactlp.py`), compatibility, pair polynomials, vertex stars and triangle types (`compat.py`, `jacobi.py`, `star.py`, `triples.py`) |
| `src/n421_*.py`, `verify/n421.gp` | 421 lines in R^44 (U1): program A (Python) and program B (PARI/GP) |
| `src/run_level1.py`, `src/level2.py`, `src/level2j.py`, `src/level2s.py` | 94 lines in R^20 and 74 in R^19: levels 1 and 2 (U4, U5) |
| `src/c35*.py`, `src/walks35.py` | The last case #35 of T20/T19, program 1 (CP-SAT; U8) |
| `verify/c35_cert*.py`, `verify/c35k3_coverage.py` | The last case #35, program 2 (exact certificates and their checker; U9) |
| `src/enum59.py`, `src/run_level1_59.py`, `src/level2_59.py`, `src/level3_59.py`, `src/s525_59.py`, `src/cert59.py` | 59 lines in R^18 (T18), program 1 |
| `verify/enum59.gp`, `verify/classes.gp`, `verify/deck59.gp`, `verify/lv23_59.gp`, `verify/s525_59.gp` | 59 lines in R^18, program 2 (PARI/GP) |
| `src/sched59.py`, `src/pipe59c.sh`, `verify/tally59.py` | 59 lines: scheduler, level-3 loop, tally of both programs' verdicts |
| `src/remainder_case.py`, `verify/*negative*.py` | Negative tests on line systems that exist |
| `data/`, `runs/`, `logs/` | Records, certificates and run logs. The largest files (level-2 records and certificate exports of 59 lines) are only in the store mirror; `MANIFEST59.sha256` lists their checksums |

## Requirements

* Python 3.12 with `python-flint` 0.9, `scipy` >= 1.11 (HiGHS), `numpy`, and `ortools` for the
  CP-SAT program: `pip install -r requirements.txt`
* PARI/GP 2.15 (`verify/*.gp`)
* `pdflatex` for the paper

## Reproducing the results

The commands for T20, T19 and T18 are in `AUDIT_REQUEST.md` ("Priority 0", "For T19" and
"Priority 0 (new): T18") and in `CLAIMS.md`. For U1:

```bash
# 422 lines in R^44 and the moment-test table (two programs; outputs must agree)
python3 verify/c1_uniform.py
python3 verify/c1_uniform.py --rows | grep -E '^(ROW|COUNT)' > /tmp/rows_py.txt
(cd verify && gp -q c1_uniform.gp) | grep -E '^(ROW|COUNT)' > /tmp/rows_gp.txt
diff /tmp/rows_py.txt /tmp/rows_gp.txt && echo IDENTICAL
python3 verify/compare_gkms.py
python3 verify/negative_tests.py

# 421 lines in R^44, Program A (~20 s on 6 cores)
python3 src/n421_enum.py            # writes data/n421/Q_candidates.json (82 polynomials)
python3 src/n421_decks.py 6         # writes data/n421/decks/<idx>.json, all 82 infeasible
python3 src/n421_export.py          # writes data/n421/export.gp

# 421 lines in R^44, Program B (~80 s, independent)
(cd verify && gp -q n421.gp)

# negative tests of the pipeline on systems that exist
python3 src/remainder_case.py 7 43 343   # 343 of the 344 lines in R^43: true spectrum survives
python3 src/remainder_case.py 5 21 125   # 125 of the 126 lines in R^21: true spectrum survives

# paper
python3 src/make_tables.py && pdflatex MAIN_RESULT.tex && pdflatex MAIN_RESULT.tex && pdflatex MAIN_RESULT.tex
```

## Mirror

`python3 mirror2.py --loop 1800` (run in a tmux session; stop file `runs/mirror_stop`) copies this
tree to `/cursor/stores/bot/eqlines/EQ-UP/` every 30 minutes. The store keeps no modification
times and rejects files above about 100 MB, so `mirror2.py` records what it copied in
`logs/mirror.state.json` and skips files above 95 MB, which are mirrored as `.gz` copies kept next
to them (now only `data/level2_59/s11/26.json`). It replaced the rsync loop `mirror.sh` on 24 Oct.
