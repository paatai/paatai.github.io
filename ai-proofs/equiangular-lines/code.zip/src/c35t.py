"""Exact search for candidate #35, support U = (0, 1, 2, 5) (CLAIMS.md, U6/U8).

Normalisation (U6): every line of type r > 0 is switched to eps = +1, type 0 to p = +sqrt3 w0, and
the type-5 line f to p = +2 sqrt3 w0.  The V-components z (scaled) then satisfy
    <z_u, z_v> = (6 S_uv - K_uv) / 3,   K_uv = 2 r_u r_v + <p_u, p_v>,
with the rigid positions (r, p):
    T0  (n0 lines)  r = 0, p = sqrt3 w0,            |z|^2 = 9
    T1x (nc each)   r = 1, p = 2 u_x,  x = a, b, c, |z|^2 = 8
    t_x (one each)  r = 2, p = -sqrt3 w0 - 2 u_x,   |z|^2 = 5
    f               r = 3, p = 2 sqrt3 w0,          z = 0.
74/R^19: n0 = 25, nc = 15, V = R^15, frame 40.  94/R^20: n0 = 33, nc = 19, V = R^16, frame 48.
All t-t, t-f, T-f entries of S are +1.  Every row count of a T0 or T1 line is fixed by its
entries against t_a, t_b, t_c (a 4 x 4 linear system from S E = lambda E on V17 + V11).

Base class L_a: its (-4)-graph is a path P_k (k vectors; k = 1 is an isolated vector) plus even
cycles, the path ends being the unique partners v_a^b, v_a^c of t_b, t_c with entry -1.  In
coordinates q_i = 2(e_i - e_{i+1}) along each component, a vector y outside L_a has steps
s_i = <y, q_i>/2, heights h_{i+1} = h_i - s_i, walk part omega = heights centred per component,
and an F-part in F = span(L_a)^perp, dim F = dimV - (nc - c).  t_b has s = -2 at q_1 and 0
elsewhere, t_c has s = -2 at q_k; their F-parts are opposite, phi and -phi.  t_b is the first
reference; t_a (enumerated) is the second when its F-part is independent of phi.
Pair rules and the frame are exact integer identities as in c35k (D = lcm of component sizes).
"""
import argparse
import itertools
import json
import time
from fractions import Fraction as Fr
from math import lcm

import numpy as np
from ortools.sat.python import cp_model

CASES = {
    "74_19": dict(dimV=15, frame=40, n0=25, nc=15, lam_r=17, lam_p=11),
    "94_20": dict(dimV=16, frame=48, n0=33, nc=19, lam_r=21, lam_p=15),
}

# positions: r and p in coordinates (w0 / sqrt3, Pi_1, Pi_2 / sqrt3), u_a = (1, 0),
# u_b = (-1/2, sqrt3/2), u_c = (-1/2, -sqrt3/2); the equations S p = lambda p are linear, so the
# rescaled coordinates can be used.
U = {"a": (Fr(1), Fr(0)), "b": (Fr(-1, 2), Fr(1, 2)), "c": (Fr(-1, 2), Fr(-1, 2))}
POS = {"T0": (0, Fr(1), Fr(0), Fr(0)), "f": (3, Fr(2), Fr(0), Fr(0))}
for _x in "abc":
    POS["T1" + _x] = (1, Fr(0), 2 * U[_x][0], 2 * U[_x][1])
    POS["t" + _x] = (2, Fr(-1), -2 * U[_x][0], -2 * U[_x][1])
NORM = {"T0": 9, "T1a": 8, "T1b": 8, "T1c": 8, "ta": 5, "tb": 5, "tc": 5}
BLOCKS = ["T0", "T1a", "T1b", "T1c"]
SINGLE = ["ta", "tb", "tc", "f"]


def pair_K(t1, t2):
    """K = 2 r r' + <p, p'> in true units (<p, p'> = 3 w w' + 4 (pi.pi') with the rescaling)."""
    r1, *p1 = POS[t1]
    r2, *p2 = POS[t2]
    # true p = (sqrt3 * p[0]) w0 + Pi with Pi = (p[1], sqrt3 p[2])
    return 2 * r1 * r2 + 3 * p1[0] * p2[0] + p1[1] * p2[1] + 3 * p1[2] * p2[2]


def allowed_B(t1, t2):
    """{B: S} for the pair of block types: B = (6 S - K) / 3 must be an integer."""
    K = pair_K(t1, t2)
    out = {}
    for S in (1, -1):
        B = Fr(6 * S - K, 3)
        if B.denominator == 1:
            out[int(B)] = S
    return out


def row_counts(case, tu, sing):
    """Numbers m[tau] of lines v != u in block tau with S_uv = -1, for a line u of type tu whose
    entries against the singletons are sing = {name: S}.  Returns None if not integral in range."""
    cfg = CASES[case]
    n = {"T0": cfg["n0"], "T1a": cfg["nc"], "T1b": cfg["nc"], "T1c": cfg["nc"]}
    lam = [cfg["lam_r"], cfg["lam_p"], cfg["lam_p"], cfg["lam_p"]]
    pu = POS[tu]
    rhs = []
    for k in range(4):
        v = Fr(lam[k]) * pu[k]
        for tau in BLOCKS:
            v -= POS[tau][k] * (n[tau] - (1 if tu == tau else 0))
        for s, S in sing.items():
            if s != tu:
                v -= POS[s][k] * S
        rhs.append(v)
    M = [[-2 * POS[tau][k] for tau in BLOCKS] for k in range(4)]
    sol = solve4(M, rhs)
    out = {}
    for tau, x in zip(BLOCKS, sol):
        if x.denominator != 1 or x < 0 or x > n[tau] - (1 if tu == tau else 0):
            return None
        out[tau] = int(x)
    return out


def solve4(M, b):
    A = [list(map(Fr, row)) + [Fr(bb)] for row, bb in zip(M, b)]
    n = len(A)
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0)
        A[c], A[p] = A[p], A[c]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c] / A[c][c]
                A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return [A[i][n] / A[i][i] for i in range(n)]


# ---------------------------------------------------------------- base class coordinates
class Base:
    """Components of L_a: ('P', k) or ('C', m).  Coordinates: k + 1 per path, m per cycle."""

    def __init__(self, comps):
        self.comps = comps
        self.sizes = [k + 1 if t == "P" else k for t, k in comps]
        self.nvec = sum(k for _, k in comps)
        self.ncoord = sum(self.sizes)
        self.D = lcm(*self.sizes)
        self.c = sum(1 for t, _ in comps if t == "C")
        offs = np.cumsum([0] + self.sizes)
        self.coord_ranges = [(int(offs[i]), int(offs[i + 1])) for i in range(len(comps))]
        # class vectors q in coordinates: list of (component, index i) -> vector
        self.qs = []
        for ci, (t, k) in enumerate(comps):
            a, b = self.coord_ranges[ci]
            for i in range(k):
                v = np.zeros(self.ncoord, dtype=np.int64)
                v[a + i] += 2
                v[a + (i + 1) % (b - a)] -= 2
                self.qs.append(v)
        self.Q = np.array(self.qs)

    def heights(self, steps):
        """steps: flat list over class vectors (component order).  D * centred heights."""
        out = np.zeros(self.ncoord, dtype=np.int64)
        pos = 0
        for ci, (t, k) in enumerate(self.comps):
            a, b = self.coord_ranges[ci]
            n = b - a
            s = steps[pos:pos + k]
            pos += k
            if t == "C" and sum(s) != 0:
                return None
            h = [0]
            for x in s[: n - 1]:
                h.append(h[-1] - x)
            tot = sum(h)
            for i in range(n):
                out[a + i] = self.D * h[i] - (self.D // n) * tot
        return out

    def walks(self, values=(1, -1)):
        """All step patterns with steps in `values` (closed on cycles).  Returns (steps, D*omega)."""
        per = []
        for t, k in self.comps:
            opts = [s for s in itertools.product(values, repeat=k) if t == "P" or sum(s) == 0]
            per.append(opts)
        S, Om = [], []
        for combo in itertools.product(*per):
            st = [x for s in combo for x in s]
            S.append(st)
            Om.append(self.heights(st))
        return np.array(S, dtype=np.int64), np.array(Om, dtype=np.int64)

    def ip(self, om1, om2):
        """D * <omega1, omega2> from D-scaled heights (exact integer)."""
        return int(om1 @ om2) // self.D


def check_ip_integral(base, om1, om2):
    v = int(om1 @ om2)
    assert v % base.D == 0
    return v // base.D


# ---------------------------------------------------------------- the model
def adj_det(Gt):
    k = len(Gt)
    if k == 1:
        return [[1]], Gt[0][0]
    if k == 2:
        a, b, c = Gt[0][0], Gt[0][1], Gt[1][1]
        return [[c, -b], [-b, a]], a * c - b * b
    raise NotImplementedError


def squarefree_split(B):
    s, t, p = 1, B, 2
    while p * p <= t:
        while t % (p * p) == 0:
            t //= p * p
            s *= p
        p += 1
    return t, s


class Problem:
    def __init__(self, case, comps):
        self.case = case
        self.cfg = CASES[case]
        self.base = Base(comps)
        b = self.base
        assert b.nvec == self.cfg["nc"], (b.nvec, self.cfg["nc"])
        assert comps[0][0] == "P" and all(t == "C" for t, _ in comps[1:])
        self.k = comps[0][1]
        self.dimF = self.cfg["dimV"] - (b.nvec - b.c)
        D = b.D
        # t_b, t_c
        st_b = [0] * b.nvec
        st_c = [0] * b.nvec
        st_b[0] = -2
        st_c[self.k - 1] = -2
        self.om_b = b.heights(st_b)
        self.om_c = b.heights(st_c)
        self.st_b, self.st_c = st_b, st_c
        Wb = check_ip_integral(b, self.om_b, self.om_b)  # D * W
        Wc = check_ip_integral(b, self.om_c, self.om_c)
        assert Wb == Wc
        self.R_b = 5 * D - Wb  # D * |phi|^2
        assert self.R_b > 0
        # F-part of t_c: <F_c, phi> = <t_c, t_b> - <omega_c, omega_b> = -1 - <..>
        self.c_cb = -D - check_ip_integral(b, self.om_c, self.om_b)
        assert self.c_cb == -self.R_b, "F(t_c) = -F(t_b) expected"
        # sum of L_a = t_a - tau = -(t_b + t_c)
        assert np.array_equal(b.Q.sum(axis=0) * D, -(self.om_b + self.om_c))
        self.Wall, self.Omall = None, None

    # S-entries of a vector with steps st against the class vectors
    @staticmethod
    def minus_steps(st, kind):
        """number of class-a vectors with S = -1 against y: for +-2 patterns S = s, for 0/-4
        patterns S = s + 1."""
        if kind == "pm":
            return sum(1 for x in st if x == -1)
        return sum(1 for x in st if x == -2)

    def ta_candidates(self):
        """Walks of t_a on L_a (+-1 steps), with the number of -1 steps forced by its row
        counts, <omega_a, omega_b + omega_c> = -2 (from <t_a, t_b> = <t_a, t_c> = -1), and
        |F(t_a)|^2 >= <F(t_a), phi>^2 / |phi|^2."""
        b, D = self.base, self.base.D
        sing = {"tb": 1, "tc": 1, "f": 1}
        m = row_counts(self.case, "ta", sing)
        want_minus = m["T1a"]
        S, Om = b.walks()
        out = []
        for st, om in zip(S, Om):
            if sum(1 for x in st if x == -1) != want_minus:
                continue
            Wa = check_ip_integral(b, om, om)
            if Wa > 5 * D:
                continue
            gb = check_ip_integral(b, om, self.om_b)
            gc = check_ip_integral(b, om, self.om_c)
            if gb + gc != -2 * D:
                continue
            c_ab = -D - gb  # D <F_a, phi>
            Ra = 5 * D - Wa  # D |F_a|^2
            # B = Delta R - c^2 with Delta = R_b (k = 1, Gt = [[R_b]])
            Bres = self.R_b * Ra - c_ab * c_ab
            if Bres < 0:
                continue
            if self.dimF == 1 and Bres != 0:
                continue
            out.append(dict(st=[int(x) for x in st], om=om, W=Wa, c_ab=c_ab, R=Ra, B=Bres))
        return out, m

    def orbit_reps(self, cands):
        """Representatives under rotations of the cycles and permutations of equal cycles."""
        b = self.base
        comps = b.comps
        cyc = [i for i, (t, _) in enumerate(comps) if t == "C"]
        groups = {}
        for i in cyc:
            groups.setdefault(comps[i][1], []).append(i)
        starts = np.cumsum([0] + [k for _, k in comps])
        perms = []
        for combo in itertools.product(*[list(itertools.permutations(v)) for v in groups.values()]):
            mp = {i: i for i in range(len(comps))}
            for orig, new in zip(groups.values(), combo):
                for o, n_ in zip(orig, new):
                    mp[o] = n_
            perms.append(mp)
        seen, reps = set(), []
        for cnd in cands:
            key = tuple(cnd["st"])
            if key in seen:
                continue
            reps.append(cnd)
            st = cnd["st"]
            for mp in perms:
                for rots in itertools.product(*[range(comps[i][1]) if comps[i][0] == "C" else [0]
                                                for i in range(len(comps))]):
                    t = [0] * len(st)
                    for i, (tp, k) in enumerate(comps):
                        src, dst = starts[i], starts[mp[i]]
                        for j in range(k):
                            t[dst + (j + rots[i]) % k] = st[src + j]
                    seen.add(tuple(t))
        return reps

    def stab_maps(self, st):
        """Index maps (source position -> target position on the step vector) given by rotations
        of cycles and permutations of equal cycles that fix the step vector st."""
        comps = self.base.comps
        starts = np.cumsum([0] + [k for _, k in comps])
        groups = {}
        for i, (t, k) in enumerate(comps):
            if t == "C":
                groups.setdefault(k, []).append(i)
        maps = []
        for combo in itertools.product(*[list(itertools.permutations(v)) for v in groups.values()]):
            mp = {i: i for i in range(len(comps))}
            for orig, new in zip(groups.values(), combo):
                for o, n_ in zip(orig, new):
                    mp[o] = n_
            for rots in itertools.product(*[range(k) if t == "C" else [0] for t, k in comps]):
                tgt = np.zeros(len(st), dtype=np.int64)
                for i, (tp, k) in enumerate(comps):
                    for j in range(k):
                        tgt[starts[i] + j] = starts[mp[i]] + (j + rots[i]) % k
                img = [0] * len(st)
                for s_, t_ in enumerate(tgt):
                    img[t_] = st[s_]
                if list(img) == list(st):
                    maps.append(tgt)
        return maps

    def build_nodes(self, ta, x2=None, listing=False):
        """Nodes for T0, T1b, T1c given t_a.  References: t_b, then t_a if its F-part is
        independent of phi, then the node x2 (a dict from a listing run) if given.  With
        listing=True the references may span less than dim F - 1 (no eps split; B >= 0 only)."""
        b, D = self.base, self.base.D
        S, Om = b.walks()
        self.S, self.Om = S, Om
        fx = {
            "tb": dict(t="tb", om=self.om_b, N=5, ip={"tb": 5, "tc": -1, "ta": -1}),
            "tc": dict(t="tc", om=self.om_c, N=5, ip={"tb": -1, "tc": 5, "ta": -1}),
            "ta": dict(t="ta", om=ta["om"], N=5, ip={"tb": -1, "tc": -1, "ta": 5}),
        }
        refs = ["tb"] + (["ta"] if ta["B"] > 0 else [])
        if x2 is not None:
            fx["x2"] = dict(t=x2["t"], om=Om[x2["j"]], N=x2["N"],
                            ip=dict(x2["relB"], x2=x2["N"]))
            for s in ("ta", "tb", "tc"):
                fx[s]["ip"]["x2"] = x2["relB"][s]
            refs.append("x2")
        k = len(refs)
        exact = k == self.dimF
        if not listing:
            assert k in (self.dimF, self.dimF - 1), (k, self.dimF)

        def gw(o1, o2):
            return check_ip_integral(b, o1, o2)

        Gt = [[D * fx[r]["ip"][s] - gw(fx[r]["om"], fx[s]["om"]) for s in refs] for r in refs]
        A, Delta = adj_det(Gt)
        A = np.array(A, dtype=np.int64)
        assert Delta > 0
        for nm, fv in fx.items():
            fv["Ct"] = np.array([D * fv["ip"][r] - gw(fv["om"], fx[r]["om"]) for r in refs], dtype=np.int64)
            Bv = int(Delta * (fv["N"] * D - gw(fv["om"], fv["om"])) - fv["Ct"] @ A @ fv["Ct"])
            assert Bv == 0, (nm, Bv)
        self.fixed = fx
        Wall = (Om * Om).sum(axis=1) // D
        g = {nm: (Om @ fv["om"]) // D for nm, fv in fx.items()}
        minus = (S == -1).sum(axis=1)
        nodes = []
        types = [("T0", 9), ("T1b", 8), ("T1c", 8)]
        for tname, N in types:
            AB = {nm: allowed_B(tname, fv["t"]) for nm, fv in fx.items()}
            for j in np.nonzero(Wall <= N * D)[0]:
                R = N * D - int(Wall[j])
                for avec in itertools.product(*[list(AB[r].keys()) for r in refs]):
                    Ct = np.array([D * a - int(g[r][j]) for a, r in zip(avec, refs)], dtype=np.int64)
                    Bn = int(Delta * R - Ct @ A @ Ct)
                    if Bn < 0 or (exact and Bn != 0):
                        continue
                    relB = dict(zip(refs, avec))
                    ok = True
                    for nm, fv in fx.items():
                        if nm in relB:
                            continue
                        hit = [a for a in AB[nm]
                               if D * Delta * a - Delta * int(g[nm][j]) - int(Ct @ A @ fv["Ct"]) == 0]
                        if not hit:
                            ok = False
                            break
                        relB[nm] = hit[0]
                    if not ok:
                        continue
                    sing = {s: allowed_B(tname, s)[relB[s]] for s in ("ta", "tb", "tc")}
                    sing["f"] = 1
                    m = row_counts(self.case, tname, sing)
                    if m is None or m["T1a"] != int(minus[j]):
                        continue
                    for e in ([0] if (Bn == 0 or listing) else [1, -1]):
                        nodes.append(dict(t=tname, j=int(j), N=N, Ct=Ct, B=Bn, eps=e, m=m, sing=sing,
                                          relB=relB))
        if x2 is not None:
            fv = fx["x2"]
            nodes.append(dict(t=x2["t"], j=x2["j"], N=x2["N"], Ct=fv["Ct"], B=0, eps=0, m=x2["m"],
                              sing=x2["sing"], relB=dict(x2["relB"]), forced=True))
        self.k_refs, self.A, self.Delta, self.Gt, self.exact = k, A, Delta, Gt, exact
        self.refs = refs
        return nodes

    def relations(self, nodes):
        """Allowed relation (and the S entry) for every pair of nodes; -9 = incompatible."""
        b, D = self.base, self.base.D
        n = len(nodes)
        js = np.array([x["j"] for x in nodes])
        Ct = np.array([x["Ct"] for x in nodes], dtype=np.int64).reshape(n, self.k_refs)
        Bv = np.array([x["B"] for x in nodes], dtype=np.int64)
        ev = np.array([x["eps"] for x in nodes], dtype=np.int64)
        tn = [x["t"] for x in nodes]
        Gw = (self.Om[js] @ self.Om[js].T) // D
        CAC = (Ct @ self.A) @ Ct.T
        BB = np.outer(Bv, Bv)
        EE = np.outer(ev, ev)
        Sm = np.zeros((n, n), dtype=np.int8)  # S entry for compatible pairs, 0 if incompatible
        tidx = {"T0": 0, "T1b": 1, "T1c": 2}
        ti = np.array([tidx[t] for t in tn])
        for t1 in tidx:
            for t2 in tidx:
                AB = allowed_B(t1, t2)
                mask = np.outer(ti == tidx[t1], ti == tidx[t2])
                for a, S in AB.items():
                    Y = D * self.Delta * a - self.Delta * Gw - CAC
                    ok = (Y * Y == BB) & ((Y == 0) | (np.sign(Y) == EE)) & mask
                    Sm[ok] = S
        np.fill_diagonal(Sm, 0)
        return Sm, ti


def core_prune(nodes, Sm, ti, nb):
    """Iteratively remove nodes that cannot meet their row counts.  nb: block sizes for T0, T1b,
    T1c.  m['T0'] etc. are the -1 counts; plus counts are (n - [same]) - m."""
    alive = np.ones(len(nodes), dtype=bool)
    names = ["T0", "T1b", "T1c"]
    need = []
    req = np.zeros((len(nodes), 3, 2), dtype=np.int64)  # [i, block, 0: S=-1 / 1: S=+1]
    for i, x in enumerate(nodes):
        row = []
        for bi, nm in enumerate(names):
            tot = nb[bi] - (1 if x["t"] == nm else 0)
            row.append((bi, -1, x["m"][nm]))
            row.append((bi, 1, tot - x["m"][nm]))
            req[i, bi, 0] = x["m"][nm]
            req[i, bi, 1] = tot - x["m"][nm]
        need.append(row)
    neg = Sm == -1
    pos = Sm == 1
    while True:
        bad = np.zeros_like(alive)
        for bi in range(3):
            cols = (alive & (ti == bi)).astype(np.int32)
            bad |= alive & ((neg @ cols) < req[:, bi, 0])
            bad |= alive & ((pos @ cols) < req[:, bi, 1])
        if not bad.any():
            return alive, need
        alive &= ~bad


def run_cpsat(P, nodes, Sm, ti, time_limit, workers):
    cfg = P.cfg
    nb = [cfg["n0"], cfg["nc"], cfg["nc"]]
    alive, need = core_prune(nodes, Sm, ti, nb)
    info = dict(nodes=len(nodes), core=int(alive.sum()))
    forced = [i for i, x in enumerate(nodes) if x.get("forced")]
    if any(not alive[i] for i in forced):
        info["status"] = "INFEASIBLE (core, forced node)"
        return info, None
    for bi in range(3):
        if (alive & (ti == bi)).sum() < nb[bi]:
            info["status"] = "INFEASIBLE (core)"
            return info, None
    idx = np.nonzero(alive)[0]
    n = len(idx)
    D, b = P.base.D, P.base
    S2 = Sm[np.ix_(idx, idx)]
    t2 = ti[idx]
    m = cp_model.CpModel()
    x = [m.NewBoolVar(f"x{i}") for i in range(n)]
    for ii, i in enumerate(idx):
        if nodes[i].get("forced"):
            m.Add(x[ii] == 1)
    for bi in range(3):
        m.Add(sum(x[i] for i in range(n) if t2[i] == bi) == nb[bi])
    ncl = 0
    for i in range(n):
        for j in np.nonzero(S2[i, i + 1:] == 0)[0] + i + 1:
            m.AddBoolOr([x[i].Not(), x[int(j)].Not()])
            ncl += 1
    for ii, i in enumerate(idx):
        for (bj, s, kk) in need[i]:
            cols = [jj for jj in range(n) if t2[jj] == bj and S2[ii, jj] == s]
            m.Add(sum(x[jj] for jj in cols) == kk).OnlyEnforceIf(x[ii])
    # singleton column counts (t_a, t_b, t_c against each block)
    for s in ("ta", "tb", "tc"):
        ms = row_counts(P.case, s, {o: 1 for o in ("ta", "tb", "tc", "f") if o != s})
        for bi, nm in enumerate(["T0", "T1b", "T1c"]):
            cols = [jj for jj in range(n) if t2[jj] == bi and nodes[idx[jj]]["sing"][s] == -1]
            m.Add(sum(x[jj] for jj in cols) == ms[nm])
    # frame: walk block, F block, cross block; zero sums
    om = P.Om[[nodes[i]["j"] for i in idx]]
    Ct = np.array([nodes[i]["Ct"] for i in idx], dtype=np.int64).reshape(n, P.k_refs)
    Bv = np.array([nodes[i]["B"] for i in idx], dtype=np.int64)
    ev = np.array([nodes[i]["eps"] for i in idx], dtype=np.int64)
    fr = cfg["frame"]
    # target for the walk block: D^2 (frame * Proj_span) minus the fixed vectors
    Pa = np.zeros((b.ncoord, b.ncoord), dtype=object)
    for (a0, a1) in b.coord_ranges:
        nn = a1 - a0
        for i in range(a0, a1):
            for j in range(a0, a1):
                Pa[i, j] = Fr(int(i == j)) - Fr(1, nn)
    T = np.zeros((b.ncoord, b.ncoord), dtype=object)
    for i in range(b.ncoord):
        for j in range(b.ncoord):
            T[i, j] = fr * D * D * Pa[i, j]
    # class vectors q: in D-scaled heights, q itself (projection of q is q)
    for q in b.Q:
        qD = q * D
        T -= np.outer(qD, qD).astype(object)
    for nm in ("ta", "tb", "tc"):
        o = P.fixed[nm]["om"].astype(object)
        T -= np.outer(o, o)
    for p in range(b.ncoord):
        for q in range(p, b.ncoord):
            val = T[p, q]
            assert Fr(val).denominator == 1
            terms = [(int(om[i, p] * om[i, q]), i) for i in range(n) if om[i, p] * om[i, q] != 0]
            m.Add(sum(c * x[i] for c, i in terms) == int(val))
    kref = P.k_refs
    Gt = P.Gt
    fixedCt = {nm: P.fixed[nm]["Ct"] for nm in ("ta", "tb", "tc")}
    for r in range(kref):
        for s in range(r, kref):
            tgt = fr * D * Gt[r][s] - sum(int(fixedCt[nm][r] * fixedCt[nm][s]) for nm in fixedCt)
            m.Add(sum(int(Ct[i, r] * Ct[i, s]) * x[i] for i in range(n)) == tgt)
        for p in range(b.ncoord):
            tgt = -sum(int(P.fixed[nm]["om"][p] * fixedCt[nm][r]) for nm in fixedCt)
            terms = [(int(Ct[i, r] * om[i, p]), i) for i in range(n) if Ct[i, r] * om[i, p] != 0]
            m.Add(sum(c * x[i] for c, i in terms) == tgt)
    if kref == P.dimF - 1:
        m.Add(sum(int(Bv[i]) * x[i] for i in range(n)) == fr * D * P.Delta)
        classes = {}
        for i in range(n):
            if Bv[i] > 0:
                t, s = squarefree_split(int(Bv[i]))
                classes.setdefault(t, []).append((i, s * int(ev[i])))
        for t, mem in classes.items():
            for r in range(kref):
                m.Add(sum(int(Ct[i, r]) * c * x[i] for i, c in mem) == 0)
            for p in range(b.ncoord):
                terms = [(c * int(om[i, p]), i) for i, c in mem if om[i, p] != 0]
                if terms:
                    m.Add(sum(cf * x[i] for cf, i in terms) == 0)
            for bi in range(3):
                m.Add(sum(c * x[i] for i, c in mem if t2[i] == bi) == 0)
    # zero sums: sum_T0 z = tau = t_a + t_b + t_c; sum_T1b z = t_b - tau; sum_T1c z = t_c - tau
    tau_om = sum(P.fixed[nm]["om"] for nm in ("ta", "tb", "tc"))
    tau_Ct = sum(fixedCt[nm] for nm in ("ta", "tb", "tc"))
    targets = {0: (tau_om, tau_Ct), 1: (P.fixed["tb"]["om"] - tau_om, fixedCt["tb"] - tau_Ct),
               2: (P.fixed["tc"]["om"] - tau_om, fixedCt["tc"] - tau_Ct)}
    for bi, (tom, tct) in targets.items():
        for p in range(b.ncoord):
            m.Add(sum(int(om[i, p]) * x[i] for i in range(n) if t2[i] == bi and om[i, p] != 0) == int(tom[p]))
        for r in range(kref):
            m.Add(sum(int(Ct[i, r]) * x[i] for i in range(n) if t2[i] == bi and Ct[i, r] != 0) == int(tct[r]))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_workers = workers
    t0 = time.time()
    st = solver.Solve(m)
    info.update(clauses=ncl, status=solver.StatusName(st), time=round(time.time() - t0, 1))
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = [int(idx[i]) for i in range(n) if solver.Value(x[i])]
    return info, sol


def structures(case):
    """Possible structures of a class: path P_k (k >= 1) plus even cycles >= 4, with dim F >= 1."""
    cfg = CASES[case]
    nc = cfg["nc"]
    out = []

    def cyc(rem, maxp, cur):
        if rem == 0:
            yield tuple(cur)
            return
        for p in range(min(rem, maxp), 3, -1):
            if p % 2 == 0:
                yield from cyc(rem - p, p, cur + [p])

    for k in range(1, nc + 1, 2):
        for cy in cyc(nc - k, nc - k, []):
            c = len(cy)
            dimF = cfg["dimV"] - (nc - c)
            if dimF >= 1:
                out.append(((("P", k),) + tuple(("C", m) for m in cy), dimF))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=sorted(CASES))
    ap.add_argument("--struct", help="e.g. P11,C4")
    ap.add_argument("--maxdimF", type=int, default=1)
    ap.add_argument("--time", type=float, default=600)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--out")
    args = ap.parse_args()
    todo = []
    for comps, dimF in structures(args.case):
        if args.struct:
            want = tuple((s[0], int(s[1:])) for s in args.struct.split(","))
            if comps != want:
                continue
        elif dimF > args.maxdimF:
            continue
        todo.append(comps)
    results = []

    def solve(P, ta, x2=None, keep=None, tag=None):
        nodes = P.build_nodes(ta, x2=x2)
        if keep is not None:
            nodes = [x for x in nodes if x.get("forced") or keep(x)]
        if not nodes:
            info = dict(nodes=0, status="INFEASIBLE (no nodes)")
        else:
            Sm, ti = P.relations(nodes)
            info, sol = run_cpsat(P, nodes, Sm, ti, args.time, args.workers)
            if sol is not None:
                info["solution"] = [dict(t=nodes[i]["t"], st=[int(v) for v in P.S[nodes[i]["j"]]],
                                         Ct=[int(v) for v in nodes[i]["Ct"]], B=int(nodes[i]["B"]),
                                         eps=int(nodes[i]["eps"])) for i in sol]
        info.update(case=args.case, struct=[f"{t}{k}" for t, k in comps], ta=ta["st"],
                    ta_B=int(ta["B"]))
        if tag:
            info.update(tag)
        print(json.dumps(info), flush=True)
        results.append(info)
        if args.out:
            with open(args.out, "w") as fh:
                json.dump(results, fh)

    for comps in todo:
        P = Problem(args.case, comps)
        cands, m_ta = P.ta_candidates()
        reps = P.orbit_reps(cands)
        print(json.dumps(dict(case=args.case, struct=[f"{t}{k}" for t, k in comps], dimF=P.dimF,
                              D=P.base.D, ta_minus=m_ta, ta_walks=len(cands), ta_orbits=len(reps))),
              flush=True)
        for ta in reps:
            k0 = 1 + (1 if ta["B"] > 0 else 0)
            if k0 >= P.dimF - 1:
                solve(P, ta)
                continue
            assert k0 == P.dimF - 2
            # second reference: case A, a T0 vector with F-part outside span(refs); case B, all
            # T0 F-parts in span(refs) and a T1 vector outside.  Orbits under the stabiliser.
            listing = P.build_nodes(ta, listing=True)
            widx = {tuple(int(v) for v in s): j for j, s in enumerate(P.S)}
            maps = P.stab_maps(ta["st"])

            def orbit_reps_nodes(cands_):
                seen, out = set(), []
                for x in cands_:
                    key = (x["t"], x["j"], tuple(sorted((r, x["relB"][r]) for r in P.refs)))
                    if key in seen:
                        continue
                    out.append(x)
                    st = P.S[x["j"]]
                    for tg in maps:
                        img = np.zeros_like(st)
                        img[tg] = st
                        jj = widx[tuple(int(v) for v in img)]
                        seen.add((x["t"], jj, key[2]))
                return out

            A_c = orbit_reps_nodes([x for x in listing if x["t"] == "T0" and x["B"] > 0])
            B_c = orbit_reps_nodes([x for x in listing if x["t"] != "T0" and x["B"] > 0])
            zeroT0 = {(x["j"], tuple(sorted((r, x["relB"][r]) for r in P.refs)))
                      for x in listing if x["t"] == "T0" and x["B"] == 0}
            refs0 = list(P.refs)
            print(json.dumps(dict(ta=ta["st"], caseA=len(A_c), caseB=len(B_c),
                                  stab=len(maps))), flush=True)
            for x2 in A_c:
                solve(P, ta, x2=x2, tag=dict(caseB=False, x2=[x2["t"], x2["j"], x2["relB"]["tb"]]))
            for x2 in B_c:
                solve(P, ta, x2=x2,
                      keep=lambda y: y["t"] != "T0" or (y["j"], tuple(sorted((r, y["relB"][r]) for r in refs0))) in zeroT0,
                      tag=dict(caseB=True, x2=[x2["t"], x2["j"], x2["relB"]["tb"]]))


if __name__ == "__main__":
    main()
