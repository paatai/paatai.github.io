#!/bin/bash
# Helper for pipe59b.sh: level 1 and level 2 on the shards in the order given (pipe59b.sh goes
# 0 -> 15), with $W workers; caches are shared by index.
cd "$(dirname "$0")"
W=$1; shift
for s in "$@"; do
  f=../runs/enum59_gp/gp_s${s}of16.jsonl
  [ -f $f ] || continue
  mkdir -p ../data/level1_59/s$s ../data/level2_59/s$s
  python3 run_level1_59.py $f $W --out=../data/level1_59/s$s >> ../logs/level59/l1_s$s.log 2>&1
  python3 level2_59.py $f --in=../data/level1_59/s$s --out=../data/level2_59/s$s $W \
    >> ../logs/level59/l2_s$s.log 2>&1
  echo "$(date -u +%H:%M:%S) helper shard $s done" >> ../logs/level59/helper.log
done
