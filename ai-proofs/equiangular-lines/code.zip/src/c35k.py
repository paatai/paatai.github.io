"""Exact search for candidate #35, support U = (0, 1, 5), with k reference vectors.

Setting and notation as in c35gen: V = span(L_a) + F, dim F = dimF, every vector outside L_a is
z = omega + phi (walk part omega on the cycles of L_a, F-part phi), |omega|^2 = W, |phi|^2 = r = N - W.

References x_1..x_k (vectors of the configuration) with linearly independent F-parts, F-Gram
Gamma.  A node is (walk, N, relations a_{x r} with the references, eps); its F-part has
c_x = (a_{x r} - <omega_x, omega_r>)_r, projection c^T Gamma^-1 c <= r and orthogonal part
eps * beta, beta^2 = r - c^T Gamma^-1 c.  With k = dimF the orthogonal part must vanish; with
k = dimF - 1 it is one-dimensional (eps = +-1, or 0).  Pair rule (exact):
    a - <omega_x, omega_y> - c_x^T Gamma^-1 c_y = eps_x eps_y beta_x beta_y.
In integers (D = walk denominator, Gamma = Gt / D, Delta = det Gt, A = adj Gt, c = Ct / D):
    Y = D Delta a - Delta G_xy - Ct_x^T A Ct_y,   B_x = Delta R_x - Ct_x^T A Ct_x,
    rule: Y^2 = B_x B_y and sign Y = eps_x eps_y.
Frame (sum z z^T = frame I, all blocks) and zero sums become linear constraints:
    sum Ct Ct^T = frame D Gt,  sum B = frame D Delta (k = dimF - 1),  sum omega Ct^T = 0,
    beta-terms split by the square class of B.

Reference choice (complete up to symmetry): x_1 is a type-0 vector with r > 0 and maximal r
among type 0 (case A), or, if every type-0 vector has r = 0, a type-1 vector with maximal r
(case B).  x_1 runs over orbit representatives under rotations of the cycles of L_a and
permutations of equal cycles.  With k = 2, x_2 is a vector whose F-part is independent of
phi_1, chosen of type 0 if possible (case A2) with maximal beta relative to x_1, else type 1
(case B2); x_2 runs over all nodes relative to x_1 (no further symmetry used).
"""
import argparse
import itertools
import json
import time

import numpy as np
from ortools.sat.python import cp_model

from c35gen import CASES, core, needs, walk_data

ALLOWED = {(True, True): (1, -3), (True, False): (2, -2), (False, True): (2, -2),
           (False, False): (0, -4, 2, -2)}


def squarefree_split(B):
    s, t, p = 1, B, 2
    while p * p <= t:
        while t % (p * p) == 0:
            t //= p * p
            s *= p
        p += 1
    return t, s


def adj_det(Gt):
    k = len(Gt)
    if k == 1:
        return [[1]], Gt[0][0]
    if k == 2:
        a, b, c = Gt[0][0], Gt[0][1], Gt[1][1]
        return [[c, -b], [-b, a]], a * c - b * b
    raise NotImplementedError


class Walks:
    def __init__(self, case, part):
        self.case, self.part = case, part
        cfg = CASES[case]
        self.cfg = cfg
        self.dimF = cfg["dimV"] - cfg["nc"] + len(part)
        self.D, self.om, self.G, self.St = walk_data(part)
        self.W = np.diag(self.G).copy()


def make_nodes(wk, refs, caseB, extra_filter=None):
    """refs: list of (walk j, N, F-row) where F-row[s] = D * Gamma_{rs} (integers).
    Returns node arrays (references appended last)."""
    D, G, W = wk.D, wk.G, wk.W
    k = len(refs)
    Gt = [[refs[r][2][s] for s in range(k)] for r in range(k)]
    A, Delta = adj_det(Gt)
    assert Delta > 0
    A = np.array(A, dtype=np.int64)
    exact = k == wk.dimF
    r1 = refs[0]
    R1 = Gt[0][0]
    nodes = []
    for N in (9, 8):
        isT0 = N == 9
        for j in np.nonzero(W <= N * D)[0]:
            Rj = int(N * D - W[j])
            if caseB and isT0 and Rj != 0:
                continue
            if (isT0 or caseB) and Rj > R1 and (isT0 == (r1[1] == 9)):
                continue
            rel_lists = [ALLOWED[(isT0, rf[1] == 9)] for rf in refs]
            for avec in itertools.product(*rel_lists):
                Ct = np.array([int(D * a - G[j, rf[0]]) for a, rf in zip(avec, refs)], dtype=np.int64)
                B = int(Delta * Rj - Ct @ A @ Ct)
                if B < 0 or (exact and B != 0):
                    continue
                for e in ([0] if B == 0 else [1, -1]):
                    nodes.append((int(j), N, Ct, B, e))
    for r, rf in enumerate(refs):
        Ct = np.array(rf[2], dtype=np.int64)
        B = int(Delta * rf[2][r] - Ct @ A @ Ct)
        assert B == 0
        nodes.append((int(rf[0]), rf[1], Ct, 0, 0))
    js = np.array([x[0] for x in nodes], dtype=np.int64)
    Ns = np.array([x[1] for x in nodes])
    Ct = np.array([x[2] for x in nodes], dtype=np.int64).reshape(len(nodes), k)
    B = np.array([x[3] for x in nodes], dtype=np.int64)
    eps = np.array([x[4] for x in nodes], dtype=np.int64)
    isref = np.zeros(len(nodes), dtype=bool)
    isref[len(nodes) - k:] = True
    return dict(js=js, Ns=Ns, Ct=Ct, B=B, eps=eps, isref=isref, A=A, Delta=int(Delta), Gt=Gt)


def relations(wk, nd, rows=None):
    """Relation matrices for node rows (default all) against all nodes."""
    D = wk.D
    js, Ct, B, eps, Ns = nd["js"], nd["Ct"], nd["B"], nd["eps"], nd["Ns"]
    if rows is None:
        rows = np.arange(len(js))
    t0 = Ns == 9
    Gn = wk.G[np.ix_(js[rows], js)]
    CAC = (Ct[rows] @ nd["A"]) @ Ct.T
    BB = np.outer(B[rows], B)
    EE = np.outer(eps[rows], eps)
    Delta = nd["Delta"]
    rel = {}
    for a in (1, -3, 2, -2, 0, -4):
        Y = D * Delta * a - Delta * Gn - CAC
        ok = (Y * Y == BB) & ((Y == 0) | (np.sign(Y) == EE))
        ok[np.arange(len(rows)), rows] = False
        if a in (1, -3):
            ok &= np.outer(t0[rows], t0)
        elif a in (0, -4):
            ok &= np.outer(~t0[rows], ~t0)
        rel[a] = ok
    return rel


def prune_by_refs(wk, nd):
    """Keep nodes that have an allowed relation with every reference (true by construction
    except for the references' mutual consistency) -- and compute the full relations."""
    rel = relations(wk, nd)
    return rel


def run_model(wk, nd, rel, time_limit, workers=8):
    cfg = wk.cfg
    need0, need1 = needs(wk.case)
    g = dict(t0=nd["Ns"] == 9, rel=rel)
    alive = core(g, need0, need1)
    info = dict(nodes=int(len(nd["js"])), core=int(alive.sum()))
    t0all = nd["Ns"] == 9
    if not alive[nd["isref"]].all() or (alive & t0all).sum() < cfg["n0"] \
            or (alive & ~t0all).sum() < 2 * cfg["nc"]:
        info["status"] = "INFEASIBLE (core)"
        return info, None
    idx = np.nonzero(alive)[0]
    n = len(idx)
    D, nc, part = wk.D, cfg["nc"], wk.part
    t0 = t0all[idx]
    R = {a: rel[a][np.ix_(idx, idx)] for a in rel}
    om = wk.om[nd["js"][idx]]
    Ct = nd["Ct"][idx]
    B = nd["B"][idx]
    eps = nd["eps"][idx]
    isref = nd["isref"][idx]
    k = Ct.shape[1]
    m = cp_model.CpModel()
    b = [m.NewBoolVar(f"b{i}") for i in range(n)]
    for i in np.nonzero(isref)[0]:
        m.Add(b[i] == 1)
    beta = [m.NewBoolVar(f"c{i}") if not t0[i] else None for i in range(n)]
    gam = [None] * n
    for i in range(n):
        if not t0[i]:
            gam[i] = m.NewBoolVar(f"g{i}")
            m.AddBoolAnd([b[i], beta[i]]).OnlyEnforceIf(gam[i])
            m.AddBoolOr([b[i].Not(), beta[i].Not(), gam[i]])
    m.Add(sum(b[i] for i in range(n) if t0[i]) == cfg["n0"])
    m.Add(sum(b[i] for i in range(n) if not t0[i]) == 2 * nc)
    m.Add(sum(gam[i] for i in range(n) if not t0[i]) == nc)
    anyrel = np.zeros((n, n), dtype=bool)
    for a in R:
        anyrel |= R[a]
    same = R[0] | R[-4]
    diff = (R[2] | R[-2]) & np.outer(~t0, ~t0)
    ncl = 0
    for i in range(n):
        for j in np.nonzero(~anyrel[i, i + 1:])[0] + i + 1:
            m.AddBoolOr([b[i].Not(), b[int(j)].Not()])
            ncl += 1
        if not t0[i]:
            for j in np.nonzero(same[i, i + 1:])[0] + i + 1:
                m.Add(beta[i] == beta[int(j)]).OnlyEnforceIf([b[i], b[int(j)]])
            for j in np.nonzero(diff[i, i + 1:])[0] + i + 1:
                m.Add(beta[i] != beta[int(j)]).OnlyEnforceIf([b[i], b[int(j)]])
    for i in range(n):
        need = need0 if t0[i] else need1
        for a, to0, kk in need:
            cols = [int(j) for j in np.nonzero(R[a][i])[0] if t0[j] == to0]
            m.Add(sum(b[j] for j in cols) == kk).OnlyEnforceIf(b[i])
    Pa = np.zeros((nc, nc))
    Lap = np.zeros((nc, nc))
    off = 0
    for mi in part:
        Pa[off:off + mi, off:off + mi] = np.eye(mi) - 1.0 / mi
        for kk in range(mi):
            e = np.zeros(nc)
            e[off + kk], e[off + (kk + 1) % mi] = 2, -2
            Lap += np.outer(e, e)
        off += mi
    Ti = np.rint(D * D * (cfg["frame"] * Pa - Lap)).astype(np.int64)
    fr = cfg["frame"]
    for p in range(nc):
        for q in range(p, nc):
            m.Add(sum(int(om[i, p] * om[i, q]) * b[i] for i in range(n) if om[i, p] * om[i, q] != 0)
                  == int(Ti[p, q]))
    Gt = nd["Gt"]
    for r in range(k):
        for s in range(r, k):
            m.Add(sum(int(Ct[i, r] * Ct[i, s]) * b[i] for i in range(n)) == fr * D * Gt[r][s])
        for p in range(nc):
            m.Add(sum(int(Ct[i, r] * om[i, p]) * b[i] for i in range(n) if Ct[i, r] * om[i, p] != 0) == 0)
        m.Add(sum(int(Ct[i, r]) * b[i] for i in range(n) if t0[i]) == 0)
        m.Add(sum(int(Ct[i, r]) * gam[i] for i in range(n) if not t0[i]) == 0)
        m.Add(sum(int(Ct[i, r]) * b[i] for i in range(n) if not t0[i]) == 0)
    if k == wk.dimF - 1:
        m.Add(sum(int(B[i]) * b[i] for i in range(n)) == fr * D * nd["Delta"])
        classes = {}
        for i in range(n):
            if B[i] > 0:
                t, s = squarefree_split(int(B[i]))
                classes.setdefault(t, []).append((i, s * int(eps[i])))
        for t, mem in classes.items():
            for r in range(k):
                m.Add(sum(int(Ct[i, r]) * c * b[i] for i, c in mem) == 0)
            for p in range(nc):
                terms = [(c * int(om[i, p]), i) for i, c in mem if om[i, p] != 0]
                if terms:
                    m.Add(sum(cf * b[i] for cf, i in terms) == 0)
            m.Add(sum(c * b[i] for i, c in mem if t0[i]) == 0)
            m.Add(sum(c * gam[i] for i, c in mem if not t0[i]) == 0)
            m.Add(sum(c * b[i] for i, c in mem if not t0[i]) == 0)
    for p in range(nc):
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * gam[i] for i in range(n) if not t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if not t0[i]) == 0)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_workers = workers
    t = time.time()
    st = solver.Solve(m)
    info.update(clauses=ncl, status=solver.StatusName(st), time=round(time.time() - t, 1))
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = [int(idx[i]) for i in range(n) if solver.Value(b[i])]
    return info, sol


def rotation_orbits(part, St, cand):
    key = {tuple(s): j for j, s in enumerate(St.tolist())}
    offs = np.cumsum([0] + list(part))
    cycles = [list(range(offs[i], offs[i + 1])) for i in range(len(part))]
    groups = {}
    for i, mi in enumerate(part):
        groups.setdefault(mi, []).append(i)
    perms = []
    for combo in itertools.product(*[list(itertools.permutations(v)) for v in groups.values()]):
        mp = {}
        for orig, new in zip(groups.values(), combo):
            for o, n_ in zip(orig, new):
                mp[o] = n_
        perms.append(mp)
    seen = set()
    reps = []
    candset = set(int(j) for j in cand)
    for j in cand:
        j = int(j)
        if j in seen:
            continue
        reps.append(j)
        s = St[j]
        orbit = set()
        for mp in perms:
            for rots in itertools.product(*[range(m) for m in part]):
                t = [0] * len(s)
                for i in range(len(part)):
                    src, dst, mi = cycles[i], cycles[mp[i]], part[i]
                    for kk in range(mi):
                        t[dst[(kk + rots[i]) % mi]] = s[src[kk]]
                orbit.add(key[tuple(t)])
        seen |= orbit & candset
    return reps


def level2_filter(wk, nd, caseB2):
    """x_2 maximises the residual relative to x_1 among vectors of its type; in case B2 every
    type-0 vector has zero residual relative to x_1.  B1 = D^2 (|phi_1|^2 |phi|^2 - <phi, phi_1>^2)."""
    R = np.array([int(N * wk.D - wk.W[j]) for j, N in zip(nd["js"], nd["Ns"])], dtype=np.int64)
    R1 = nd["Gt"][0][0]
    B1 = R1 * R - nd["Ct"][:, 0] * nd["Ct"][:, 0]
    i2 = len(nd["js"]) - 1
    assert nd["isref"][i2] and B1[i2] > 0
    t0 = nd["Ns"] == 9
    if caseB2:
        bad = (t0 & (B1 > 0)) | (~t0 & (B1 > B1[i2]))
    else:
        bad = t0 & (B1 > B1[i2])
    keep = ~bad | nd["isref"]
    out = dict(nd)
    for key in ("js", "Ns", "Ct", "B", "eps", "isref"):
        out[key] = nd[key][keep]
    return out


def walk_perm_table(part, St):
    """All walk permutations induced by cycle rotations and permutations of equal cycles."""
    key = {tuple(s): j for j, s in enumerate(St.tolist())}
    offs = np.cumsum([0] + list(part))
    cycles = [list(range(offs[i], offs[i + 1])) for i in range(len(part))]
    groups = {}
    for i, mi in enumerate(part):
        groups.setdefault(mi, []).append(i)
    table = []
    for combo in itertools.product(*[list(itertools.permutations(v)) for v in groups.values()]):
        mp = {}
        for orig, new in zip(groups.values(), combo):
            for o, n_ in zip(orig, new):
                mp[o] = n_
        for rots in itertools.product(*[range(m) for m in part]):
            src_idx = np.zeros(offs[-1], dtype=np.int64)
            for i in range(len(part)):
                src, dst, mi = cycles[i], cycles[mp[i]], part[i]
                for kk in range(mi):
                    src_idx[dst[(kk + rots[i]) % mi]] = src[kk]
            img = St[:, src_idx]
            table.append([key[tuple(r)] for r in img.tolist()])
    return np.array(table, dtype=np.int64)


def first_refs(wk, caseB):
    ref_N = 8 if caseB else 9
    cand = np.nonzero(wk.W < ref_N * wk.D)[0]
    reps = rotation_orbits(wk.part, wk.St, cand)
    return [(int(j), ref_N, [int(ref_N * wk.D - wk.W[j])]) for j in reps]


def second_refs(wk, ref1, caseB, caseB2):
    """Candidates x_2 relative to x_1: nodes with B > 0 (F-part independent of phi_1)."""
    nd = make_nodes(wk, [ref1], caseB)
    out = []
    want_N = 8 if caseB2 else 9
    for i in range(len(nd["js"]) - 1):
        if nd["Ns"][i] != want_N or nd["B"][i] <= 0 or nd["eps"][i] != 1:
            continue
        j = int(nd["js"][i])
        R2 = int(want_N * wk.D - wk.W[j])
        c12 = int(nd["Ct"][i, 0])
        out.append((j, want_N, [c12, R2], int(nd["B"][i])))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case")
    ap.add_argument("part")
    ap.add_argument("--k", type=int, default=1)
    ap.add_argument("--time", type=float, default=900)
    ap.add_argument("--out")
    ap.add_argument("--only", choices=["A", "B"])
    ap.add_argument("--workers", type=int, default=8)
    args = ap.parse_args()
    part = tuple(int(x) for x in args.part.split(","))
    wk = Walks(args.case, part)
    assert args.k in (wk.dimF - 1, wk.dimF) and args.k >= 1
    table = walk_perm_table(part, wk.St) if args.k == 2 else None
    out = []
    for caseB in (False, True):
        if args.only and args.only != ("B" if caseB else "A"):
            continue
        refs1 = first_refs(wk, caseB)
        print(f"{args.case} {part} dimF={wk.dimF} k={args.k} case {'B' if caseB else 'A'}: "
              f"{len(refs1)} first-reference orbits", flush=True)
        for ref1 in refs1:
            todo = [[ref1]]
            if args.k == 2:
                todo = []
                stab = table[table[:, ref1[0]] == ref1[0]]
                for caseB2 in ((False, True) if not caseB else (True,)):
                    seen = set()
                    for (j2, N2, row2, B2) in second_refs(wk, ref1, caseB, caseB2):
                        key = (N2, row2[0], int(stab[:, j2].min()))
                        if key in seen:
                            continue
                        seen.add(key)
                        r1row = [ref1[2][0], row2[0]]
                        todo.append([(ref1[0], ref1[1], r1row), (j2, N2, row2), caseB2])
                print(f"  first reference {ref1[0]}: stabiliser {len(stab)}, "
                      f"{len(todo)} second-reference orbits", flush=True)
            for refs in todo:
                caseB2 = None
                if args.k == 2:
                    refs, caseB2 = refs[:2], refs[2]
                nd = make_nodes(wk, refs, caseB)
                if caseB2 is not None:
                    nd = level2_filter(wk, nd, caseB2)
                rel = relations(wk, nd)
                info, sol = run_model(wk, nd, rel, args.time, workers=args.workers)
                info.update(case=args.case, part=list(part), caseB=caseB,
                            refs=[(r[0], r[1]) for r in refs])
                if caseB2 is not None:
                    info.update(caseB2=caseB2, row2=refs[1][2])
                print(json.dumps(info), flush=True)
                info["solution"] = sol
                out.append(info)
                if args.out:
                    with open(args.out, "w") as fh:
                        json.dump(out, fh)


if __name__ == "__main__":
    main()
