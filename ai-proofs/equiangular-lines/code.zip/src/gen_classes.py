"""Generate P_{n,e} by random sampling; save classes with witness sample indices.

Usage: python3 gen_classes.py n e [seed] [max_samples]
Output: data/P_<n>_<e>.json  {n, e, seed, samples, complete, target, classes: [[key, s], ...]}
A class is certified by its witness: sample_matrix(n, seed, s) has chi mod 2^e = key.
"""

import json
import sys
import time

sys.path.insert(0, __file__.rsplit("/", 1)[0])
from eqlines.seidel import generate_classes, max_classes  # noqa: E402


def main():
    n, e = int(sys.argv[1]), int(sys.argv[2])
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    maxs = int(sys.argv[4]) if len(sys.argv) > 4 else 10 ** 7
    t0 = time.time()
    wit = {}
    cl, s, ok = generate_classes(n, e, seed=seed, max_samples=maxs, witnesses=wit,
                                 log=lambda m: print(m, f"{time.time() - t0:.0f}s", flush=True))
    out = {"n": n, "e": e, "seed": seed, "samples": s, "complete": ok,
           "target": max_classes(n, e), "classes": [[list(k), wit[k]] for k in sorted(cl)]}
    path = f"{__file__.rsplit('/', 2)[0]}/data/P_{n}_{e}.json"
    with open(path, "w") as fh:
        json.dump(out, fh)
    print("done", n, e, len(cl), s, ok, f"{time.time() - t0:.0f}s", flush=True)


if __name__ == "__main__":
    main()
