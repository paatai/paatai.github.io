"""Multi-kappa stripping (iterated GSY Lemma 3.1) for n lines at angle 1/a in R^d.

State: r unknown eigenvalues (all > -a) with power sums P1 = sum lam, P2 = sum lam^2,
whose monic polynomial phi satisfies: phi(x + kappa) is type 2 (n even) / weakly
type 2 (n odd) for every odd kappa (Lemmas 2.7, 2.8 of [GSY21]: the stripped
factors (x + a)^{n-d} and (x - kappa_j)^{e_j} shift to type-2 factors).
Hence |phi(kappa)| is 0 or divisible by 2^{r - gamma}; by AM-GM, if
    sum (lam - kappa)^2 < r * 4^{(r - gamma)/r}     (exact: T^r < r^r 4^{r-gamma})
then kappa is an eigenvalue and is stripped.  At the fixpoint we test
Cauchy-Schwarz (sum (lam - c))^2 <= r * sum (lam - c)^2 (c arbitrary; we use the
exact variance form  r P2 - P1^2 >= 0).

Usage: python3 strip_scan.py a d [nmin nmax]
"""

import sys
from fractions import Fraction


def forced(T, r, gamma):
    """True iff T^r < r^r 4^(r-gamma), i.e. r*4^((r-gamma)/r) > T (exact)."""
    if r <= 0:
        return False
    return T ** r < r ** r * 4 ** (r - gamma)


def strip(a, d, n, kmin=None, kmax=None):
    m = n - d
    gamma = n % 2
    P1 = a * m
    P2 = n * (n - 1) - a * a * m
    r = d
    stripped = {}
    mean = Fraction(P1, d)
    lo = kmin if kmin is not None else int(mean) - 15
    hi = kmax if kmax is not None else int(mean) + 15
    changed = True
    while changed and r > 0:
        changed = False
        for kappa in range(lo, hi + 1):
            if kappa % 2 == 0 or kappa <= -a:
                continue
            while r > 0:
                T = P2 - 2 * kappa * P1 + r * kappa * kappa
                if forced(T, r, gamma):
                    stripped[kappa] = stripped.get(kappa, 0) + 1
                    r -= 1
                    P1 -= kappa
                    P2 -= kappa * kappa
                    changed = True
                else:
                    break
    var_ok = (r * P2 - P1 * P1 >= 0) if r > 0 else (P1 == 0 and P2 == 0)
    return dict(n=n, r=r, P1=P1, P2=P2, stripped=stripped, excluded=not var_ok)


def main():
    a, d = int(sys.argv[1]), int(sys.argv[2])
    R = Fraction((a * a - 1) * d, a * a - d) if d < a * a else None
    nmax = int(sys.argv[4]) if len(sys.argv) > 4 else int(R)
    nmin = int(sys.argv[3]) if len(sys.argv) > 3 else nmax - 20
    print(f"a={a} d={d} R={float(R) if R else None}")
    for n in range(nmax, nmin - 1, -1):
        res = strip(a, d, n)
        print(n, "EXCLUDED" if res["excluded"] else "open", "r=", res["r"], "stripped=", res["stripped"],
              "P1=", res["P1"], "P2=", res["P2"])


if __name__ == "__main__":
    main()
