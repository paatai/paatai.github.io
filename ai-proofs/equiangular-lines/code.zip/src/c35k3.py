"""Program 1 with a third reference: the second-level leaves of `c35k.py --k 2`, split by a third
reference x_3 when CP-SAT does not decide them within --time2 seconds, or at once when the
second-level core has more than --split-above nodes.

Setting, node rules and CP-SAT model as in c35k.py (imported unchanged).  The second-level leaves
(x_1, x_2) are enumerated exactly as by c35k.py --k 2, in the same order; leaf number i goes to
shard i mod n.

Third reference (dim F = 3).  The F-parts span F (sum phi phi^T = frame I_F), so some vector has
F-part outside span(phi_1, phi_2).  x_3 is a type-0 vector with maximal residual relative to
span(phi_1, phi_2) among type-0 vectors (case A3), or, if every type-0 vector has zero residual,
a type-1 vector with maximal residual among type-1 vectors (case B3).  In cases B and B2 every
type-0 F-part lies in span(phi_1), so only B3 occurs.  The residual direction is a line of F and
the reflection of F in span(phi_1, phi_2) fixes x_1 and x_2, so eps_3 = +1.  x_3 runs over all
candidates up to the walk permutations fixing the walks of x_1 and x_2 (these fix x_1, x_2 and
every F-part).  With three references every node's F-part is exact (B = 0), and the third-level
node set carries the maximality conditions of x_1 (in make_nodes), x_2 and x_3:
    B1  = R1 R - C1^2                         (residual relative to phi_1, times D^2 R1-scale)
    B12 = det(G12) R - c^T adj(G12) c          (residual relative to span(phi_1, phi_2))
A second-level leaf is INFEASIBLE iff its own model is, or every third-level model is.

Resuming: --skip takes c35k/c35k3 leaf records (second-level leaves decided there are skipped),
--skip-sub takes c35k3 sub-leaf logs (third-level leaves decided there are skipped and logged as
SKIPPED; a leaf with such sub-leaves is split at once).

Usage: python3 c35k3.py CASE PART [--shard i/n] [--time2 S] [--split-above N] [--time3 S]
                        [--workers W] [--skip LOG ...] [--skip-sub LOG ...] [--only-idx I ...]
                        --out F
"""
import argparse
import json
import time

import numpy as np

import c35k as K
from c35gen import core, needs

_adj_det2 = K.adj_det


def adj_det(Gt):
    if len(Gt) <= 2:
        return _adj_det2(Gt)
    assert len(Gt) == 3
    cof = [[0] * 3 for _ in range(3)]
    for i in range(3):
        for j in range(3):
            r = [x for x in range(3) if x != i]
            c = [x for x in range(3) if x != j]
            m = Gt[r[0]][c[0]] * Gt[r[1]][c[1]] - Gt[r[0]][c[1]] * Gt[r[1]][c[0]]
            cof[i][j] = (-1) ** (i + j) * m
    det = sum(Gt[0][j] * cof[0][j] for j in range(3))
    return [[cof[j][i] for j in range(3)] for i in range(3)], det


K.adj_det = adj_det


def second_level(wk, table):
    """The second-level leaves of c35k.py --k 2, in its order."""
    for caseB in (False, True):
        for ref1 in K.first_refs(wk, caseB):
            stab = table[table[:, ref1[0]] == ref1[0]]
            for caseB2 in ((False, True) if not caseB else (True,)):
                seen = set()
                for (j2, N2, row2, B2) in K.second_refs(wk, ref1, caseB, caseB2):
                    key = (N2, row2[0], int(stab[:, j2].min()))
                    if key in seen:
                        continue
                    seen.add(key)
                    r1row = [ref1[2][0], row2[0]]
                    yield caseB, [(ref1[0], ref1[1], r1row), (j2, N2, row2)], caseB2


def leaf_key(caseB, refs, caseB2, row2):
    return (bool(caseB), tuple(tuple(int(x) for x in r[:2]) for r in refs), bool(caseB2),
            tuple(int(x) for x in row2))


def third_refs(wk, refs2, caseB, caseB2, caseB3):
    nd = K.level2_filter(wk, K.make_nodes(wk, refs2, caseB), caseB2)
    want_N = 8 if caseB3 else 9
    out = []
    for i in range(len(nd["js"])):
        if nd["isref"][i] or nd["Ns"][i] != want_N or nd["B"][i] <= 0 or nd["eps"][i] != 1:
            continue
        j = int(nd["js"][i])
        R3 = int(want_N * wk.D - wk.W[j])
        out.append((j, want_N, [int(nd["Ct"][i, 0]), int(nd["Ct"][i, 1]), R3]))
    return out


def third_level_nodes(wk, refs3, caseB, caseB2, caseB3):
    nd = K.make_nodes(wk, refs3, caseB)
    R = np.array([int(N * wk.D - wk.W[j]) for j, N in zip(nd["js"], nd["Ns"])], dtype=np.int64)
    Gt = nd["Gt"]
    R1, c12, R2 = Gt[0][0], Gt[0][1], Gt[1][1]
    C1, C2 = nd["Ct"][:, 0], nd["Ct"][:, 1]
    t0 = nd["Ns"] == 9
    n = len(nd["js"])
    i2, i3 = n - 2, n - 1
    assert nd["isref"][i2] and nd["isref"][i3] and not nd["isref"][:n - 3].any()
    B1 = R1 * R - C1 * C1
    assert B1[i2] > 0
    if caseB2:
        bad = (t0 & (B1 > 0)) | (~t0 & (B1 > B1[i2]))
    else:
        bad = t0 & (B1 > B1[i2])
    B12 = (R1 * R2 - c12 * c12) * R - (R2 * C1 * C1 - 2 * c12 * C1 * C2 + R1 * C2 * C2)
    assert B12[i3] > 0
    if caseB3:
        bad |= (t0 & (B12 > 0)) | (~t0 & (B12 > B12[i3]))
    else:
        bad |= t0 & (B12 > B12[i3])
    keep = ~bad | nd["isref"]
    out = dict(nd)
    for key in ("js", "Ns", "Ct", "B", "eps", "isref"):
        out[key] = nd[key][keep]
    return out


def decided(status):
    return status.startswith("INFEASIBLE")


def sub_key(idx, caseB3, j3, row3):
    return (int(idx), bool(caseB3), int(j3), tuple(int(x) for x in row3))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case")
    ap.add_argument("part")
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--time2", type=float, default=120)
    ap.add_argument("--split-above", type=int, default=2500,
                    help="split without a second-level solve when the core is larger")
    ap.add_argument("--time3", type=float, default=900)
    ap.add_argument("--workers", type=int, default=1)
    ap.add_argument("--skip", nargs="*", default=[],
                    help="c35k/c35k3 logs; second-level leaves INFEASIBLE there are skipped")
    ap.add_argument("--skip-sub", nargs="*", default=[],
                    help="c35k3 sub-leaf logs; third-level leaves INFEASIBLE there are skipped")
    ap.add_argument("--only-idx", type=int, nargs="*")
    ap.add_argument("--out", required=True)
    args = ap.parse_args()
    part = tuple(int(x) for x in args.part.split(","))
    wk = K.Walks(args.case, part)
    assert wk.dimF == 3
    need0, need1 = needs(args.case)
    table = K.walk_perm_table(part, wk.St)
    shard, nshard = (int(x) for x in args.shard.split("/"))
    skip = set()
    for p in args.skip:
        for line in open(p):
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "refs" in d and decided(d.get("status", "")) and "caseB2" in d:
                skip.add(leaf_key(d["caseB"], d["refs"], d["caseB2"], d["row2"]))
    skip_sub = set()
    for p in args.skip_sub:
        for line in open(p):
            try:
                d = json.loads(line)
            except json.JSONDecodeError:
                continue
            if "sub" in d and decided(d.get("status", "")):
                skip_sub.add(sub_key(d["idx"], d["caseB3"], d["j3"], d["row3"]))
    split_idx = {k[0] for k in skip_sub}
    out = open(args.out, "a")

    def emit(d):
        out.write(json.dumps(d) + "\n")
        out.flush()

    stats = {}
    t_start = time.time()
    nleaf = 0
    for idx, (caseB, refs2, caseB2) in enumerate(second_level(wk, table)):
        nleaf += 1
        if idx % nshard != shard or (args.only_idx is not None and idx not in args.only_idx):
            continue
        row2 = refs2[1][2]
        key = leaf_key(caseB, refs2, caseB2, row2)
        base = dict(idx=idx, case=args.case, part=list(part), caseB=caseB,
                    refs=[(r[0], r[1]) for r in refs2], caseB2=caseB2, row2=row2)
        if key in skip:
            stats["SKIPPED"] = stats.get("SKIPPED", 0) + 1
            emit(dict(base, status="SKIPPED (decided in a --skip log)"))
            continue
        t0 = time.time()
        nd = K.level2_filter(wk, K.make_nodes(wk, refs2, caseB), caseB2)
        rel = K.relations(wk, nd)
        ncore = int(core(dict(t0=nd["Ns"] == 9, rel=rel), need0, need1).sum())
        if ncore > args.split_above:
            info, sol = dict(nodes=int(len(nd["js"])), core=ncore, status="UNKNOWN",
                             note="not solved: core above --split-above"), None
        elif idx in split_idx:
            info, sol = dict(nodes=int(len(nd["js"])), core=ncore, status="UNKNOWN",
                             note="not solved: sub-leaves in a --skip-sub log"), None
        else:
            info, sol = K.run_model(wk, nd, rel, args.time2, workers=args.workers)
        rec = dict(base, level2=info)
        if sol is not None:
            rec["solution"] = sol
        status = info["status"]
        if status == "UNKNOWN":
            (j1, N1, r1row), (j2, N2, _) = refs2
            R1, c12, R2 = r1row[0], r1row[1], row2[1]
            stab12 = table[(table[:, j1] == j1) & (table[:, j2] == j2)]
            subs = {}
            unknown, feasible = [], []
            nsub = 0
            tmax = 0.0
            for caseB3 in ((False, True) if not (caseB or caseB2) else (True,)):
                seen = set()
                for (j3, N3, row3) in third_refs(wk, refs2, caseB, caseB2, caseB3):
                    k3 = (N3, row3[0], row3[1], int(stab12[:, j3].min()))
                    if k3 in seen:
                        continue
                    seen.add(k3)
                    if sub_key(idx, caseB3, j3, row3) in skip_sub:
                        nsub += 1
                        st3 = "SKIPPED (decided in a --skip-sub log)"
                        subs[st3] = subs.get(st3, 0) + 1
                        print(json.dumps(dict(idx=idx, sub=nsub, caseB3=caseB3, j3=j3, row3=row3,
                                              status=st3)), flush=True)
                        continue
                    refs3 = [(j1, N1, [R1, c12, row3[0]]), (j2, N2, [c12, R2, row3[1]]),
                             (j3, N3, row3)]
                    nd3 = third_level_nodes(wk, refs3, caseB, caseB2, caseB3)
                    i3, s3 = K.run_model(wk, nd3, K.relations(wk, nd3), args.time3,
                                         workers=args.workers)
                    nsub += 1
                    subs[i3["status"]] = subs.get(i3["status"], 0) + 1
                    tmax = max(tmax, i3.get("time", 0.0))
                    print(json.dumps(dict(idx=idx, sub=nsub, caseB3=caseB3, j3=j3, row3=row3,
                                          **i3)), flush=True)
                    if s3 is not None:
                        feasible.append(dict(j3=j3, N3=N3, row3=row3, solution=s3))
                    elif not decided(i3["status"]):
                        unknown.append(dict(j3=j3, N3=N3, row3=row3, caseB3=caseB3, info=i3))
            rec["level3"] = dict(subleaves=nsub, statuses=subs, max_time=tmax,
                                 unknown=unknown, feasible=feasible)
            status = ("FEASIBLE (level 3)" if feasible else
                      "UNKNOWN (level 3)" if unknown else "INFEASIBLE (level 3)")
        rec["status"] = status
        rec["time"] = round(time.time() - t0, 1)
        stats[status] = stats.get(status, 0) + 1
        emit(rec)
    emit(dict(summary=stats, second_level_leaves=nleaf, shard=args.shard,
              time=round(time.time() - t_start, 1), args=vars(args)))


if __name__ == "__main__":
    main()
