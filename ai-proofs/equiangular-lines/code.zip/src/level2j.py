"""Level 2 with the Jacobi pair test (eqlines.jacobi) for 74 lines in R^19 / 94 in R^20.

For each open candidate of level2.py (data/level2/CASE/<idx>.json):
  1. the J-graph on the filtered deck: an edge f - g (loop if f = g) iff
     PairSpace.pair_polys(f, g, sigma) is nonempty for sigma = +1 or -1;
  2. maximal cliques; for each, the LP sum n_f g_f = h, n >= 0, n_f <= 1 without loop,
     with an exact certificate when infeasible (as in level2.py).
The pair polynomials P (chi_{S[ij]} = mu2 P) are stored for the vertex-star LP.

With --l312 the input is data/level2_l312/ (decks filtered by [GY19, Lemma 3.12]) and the
output data/level2j_l312/.

Usage: python3 level2j.py [--l312] CASE [workers] [indices...]
Output: data/level2j/CASE/<idx>.json
"""

import json
import os
import sys
import time
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.compat import maximal_cliques  # noqa: E402
from eqlines.deck import SpecPoly, candidate_poly  # noqa: E402
from eqlines.jacobi import PairSpace  # noqa: E402
from eqlines.lpcert import (find_farkas_bounded, find_feasible_bounded,  # noqa: E402
                            integer_certificate, verify_farkas_bounded)
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import coeffs_desc  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CASES = {
    "74_19": dict(kappa=15, m_low=55, m_kappa=6),
    "94_20": dict(kappa=19, m_low=74, m_kappa=7),
}


def dirs(l312):
    s = "_l312" if l312 else ""
    return os.path.join(ROOT, "data", "level2" + s), os.path.join(ROOT, "data", "level2j" + s)


def analyse(args):
    case, idx, l312 = args
    cfg = CASES[case]
    with open(os.path.join(dirs(l312)[0], case, f"{idx}.json")) as fh:
        L2 = json.load(fh)
    t0 = time.time()
    sp = SpecPoly(candidate_poly(L2["psi"], cfg["kappa"], cfg["m_low"], cfg["m_kappa"]))
    D = L2["deck"]
    G = [coeffs_to_poly(c) for c in D]
    ps = PairSpace(sp, nonzero_at=[-5])
    members = sorted(set(i for C in L2.get("open_cliques", []) for i in C))
    pairs = {}
    adj = {a: set() for a in members}
    loop = {}
    for ia, a in enumerate(members):
        for b in members[ia:]:
            found = []
            for sigma in (1, -1):
                for psi, P in ps.pair_polys(G[a], G[b], sigma):
                    found.append([sigma, coeffs_desc(psi), coeffs_desc(P)])
            pairs[f"{a},{b}"] = found
            if a == b:
                loop[a] = bool(found)
            elif found:
                adj[a].add(b)
                adj[b].add(a)
    res = {"case": case, "idx": idx, "members": members, "pairs": pairs,
           "edges": sorted([a, b] for a in adj for b in adj[a] if a < b),
           "loops": [a for a in members if loop[a]]}
    out, feasible = [], []
    for C in sorted(maximal_cliques(adj), key=lambda c: sorted(c)) if members else []:
        C = sorted(C)
        DC = [D[i] for i in C]
        ub = [not loop[i] for i in C]
        st, _x = find_feasible_bounded(sp, DC, ub)
        entry = {"clique": C, "lp": st}
        if st != "feasible":
            Y = find_farkas_bounded(sp, DC, ub)
            if Y is not None:
                Z = integer_certificate(Y)
                assert verify_farkas_bounded(DC, L2["h"], Z, ub)
                entry["cert"] = Z
        if "cert" not in entry:
            feasible.append(C)
        out.append(entry)
    res["cliques"] = out
    res["open_cliques"] = feasible
    res["verdict"] = "excluded" if not feasible else "open"
    res["t"] = time.time() - t0
    return res


def main():
    l312 = "--l312" in sys.argv
    argv = [a for a in sys.argv[1:] if a != "--l312"]
    din, dout = dirs(l312)
    case = argv[0]
    workers = int(argv[1]) if len(argv) > 1 else 6
    if len(argv) > 2:
        idxs = [int(a) for a in argv[2:]]
    else:
        idxs = []
        for fn in sorted(os.listdir(os.path.join(din, case))):
            with open(os.path.join(din, case, fn)) as fh:
                if json.load(fh)["verdict"] == "open":
                    idxs.append(int(fn[:-5]))
    os.makedirs(os.path.join(dout, case), exist_ok=True)
    with Pool(workers) as pool:
        for res in pool.imap_unordered(analyse, [(case, i, l312) for i in sorted(idxs)]):
            with open(os.path.join(dout, case, f"{res['idx']}.json"), "w") as fh:
                json.dump(res, fh)
            npairs = sum(len(v) for v in res["pairs"].values())
            print(time.strftime("%H:%M:%S"), case, res["idx"], f"members={len(res['members'])}",
                  f"edges={len(res['edges'])}", f"loops={len(res['loops'])}", f"pairpolys={npairs}",
                  f"cliques={len(res['cliques'])}", f"open={len(res['open_cliques'])}",
                  res["verdict"], f"{res['t']:.1f}s", flush=True)


if __name__ == "__main__":
    main()
