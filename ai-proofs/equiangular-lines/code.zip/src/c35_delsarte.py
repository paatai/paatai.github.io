"""Multi-type Delsarte test for candidate #35, support U = (0, 1, 5).

For every degree k the kernel K_k(x, y) = |x|^k |y|^k C_k^{(n-2)/2}(<x, y> / (|x||y|)) is positive
semidefinite on R^n.  The counts of inner products between the V-components z of the lines are
determined by the row counts (CLAIMS.md), so the block sums
    M_k[s, t] = sum_{u in s, v in t} K_k(z_u, z_v),   s, t in {T0, La, Lb, Lc},
are known exactly; each M_k must be positive semidefinite.  Exact rational arithmetic.
"""
import sys
from fractions import Fraction as F

import sympy as sp

CASES = {
    # n = dim V; type-0 count and norm, class size and norm; per-vertex counts of inner products
    "74_19": dict(n=15, n0=24, nc=16, N0=9, N1=8,
                  t0t0={1: 15, -3: 8}, t0c={2: 8, -2: 8}, ct0={2: 12, -2: 12},
                  own={0: 13, -4: 2}, other={2: 8, -2: 8}),
    "94_20": dict(n=16, n0=32, nc=20, N0=9, N1=8,
                  t0t0={1: 21, -3: 10}, t0c={2: 10, -2: 10}, ct0={2: 16, -2: 16},
                  own={0: 17, -4: 2}, other={2: 10, -2: 10}),
}


def kernel_poly(n, k):
    """Homogeneous form P(a, b, c) = |x|^k |y|^k C_k(c / sqrt(a b)) with a = |x|^2, b = |y|^2, c = <x, y>."""
    t = sp.Symbol("t")
    C = sp.Poly(sp.gegenbauer(k, sp.Rational(n - 2, 2), t), t)
    coeffs = {m: F(int(sp.numer(cf)), int(sp.denom(cf))) for (m,), cf in C.terms()}

    def P(a, b, c):
        tot = F(0)
        for m, cf in coeffs.items():
            # |x|^k |y|^k (c / sqrt(ab))^m = (ab)^((k - m)/2) c^m, k - m even
            assert (k - m) % 2 == 0
            tot += cf * F(a * b) ** ((k - m) // 2) * F(c) ** m
        return tot
    return P


def blocks(case, k):
    c = CASES[case]
    P = kernel_poly(c["n"], k)
    N0, N1, n0, nc = c["N0"], c["N1"], c["n0"], c["nc"]
    M = [[F(0)] * 4 for _ in range(4)]
    M[0][0] = n0 * (P(N0, N0, N0) + sum(m * P(N0, N0, a) for a, m in c["t0t0"].items()))
    for x in (1, 2, 3):
        M[x][x] = nc * (P(N1, N1, N1) + sum(m * P(N1, N1, a) for a, m in c["own"].items()))
        v = n0 * sum(m * P(N0, N1, a) for a, m in c["t0c"].items())
        M[0][x] = M[x][0] = v
        for y in (1, 2, 3):
            if y != x:
                M[x][y] = nc * sum(m * P(N1, N1, a) for a, m in c["other"].items())
    return M


def main():
    for case in sys.argv[1:] or sorted(CASES):
        for k in range(1, 13):
            M = blocks(case, k)
            Ms = sp.Matrix(4, 4, lambda i, j: sp.Rational(M[i][j].numerator, M[i][j].denominator))
            ev = [sp.N(e, 8) for e in Ms.eigenvals(multiple=True)]
            tot = sum(sum(r) for r in M)
            print(case, k, "total", float(tot), "min eig", min(float(sp.re(e)) for e in ev))


if __name__ == "__main__":
    main()
