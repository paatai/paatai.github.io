#!/bin/bash
# Claims shards of enum59.py --l312 (16 shards) by mkdir locks and runs them one at a time.
cd "$(dirname "$0")"
N=16
for s in $(seq 0 $((N - 1))); do
  mkdir ../runs/enum59/lock_${s}of${N} 2>/dev/null || continue
  python3 enum59.py --shard $s/$N --classes ../data/P_59_7.json --l312 \
    --out ../runs/enum59/l312_s${s}of${N}.jsonl \
    > ../logs/enum59/l312_s${s}of${N}.log 2> ../logs/enum59/l312_s${s}of${N}.err
  echo "$(date -u +%H:%M:%S) shard $s/$N rc=$?" >> ../logs/enum59/workers.log
done
