"""One-line extensions of an equiangular system at angle 1/a.

A unit vector w (in any dimension) makes angle 1/a with every line of a system with Seidel
matrix S of rank-d Gram matrix G = I + S/a iff sigma = a X w is a +-1 vector in col(G) and
sigma^T G^+ sigma <= a^2.  We enumerate col(G) cap {+-1}^n through an information set I of
size d (G restricted to the columns I has rank d): sigma is determined by sigma_I.
"""
import argparse
import itertools
import json
import sys
from fractions import Fraction

import flint
import numpy as np


def read_seidel(path):
    rows = [ln.strip() for ln in open(path) if ln.strip() and not ln.startswith("#")]
    n = int(rows[0])
    S = [[0] * n for _ in range(n)]
    for i, r in enumerate(rows[1:n + 1]):
        assert len(r) == n
        for j, ch in enumerate(r):
            S[i][j] = {"0": 0, "+": 1, "-": -1}[ch]
    for i in range(n):
        assert S[i][i] == 0
        for j in range(n):
            assert S[i][j] == S[j][i]
    return S


def rref_basis(M):
    """Column space basis of the integer matrix M: returns (pivot columns, B) with
    col(M) = { B t }, B = M[:, piv] * inv(M[piv_rows, piv]) so that B[I] = identity."""
    n = M.nrows()
    A = flint.fmpq_mat(M)
    R, rank = A.transpose().rref()
    # row space of M^T = column space of M; R rows (first rank) form a basis with pivots
    piv = []
    for r in range(rank):
        for c in range(n):
            if R[r, c] != 0:
                piv.append(c)
                break
    B = flint.fmpq_mat(n, rank)
    for r in range(rank):
        for c in range(n):
            B[c, r] = R[r, c]
    return piv, B


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("seidel")
    ap.add_argument("--a", type=int, default=5)
    ap.add_argument("--out")
    args = ap.parse_args()
    S = read_seidel(args.seidel)
    n = len(S)
    a = args.a
    Sm = flint.fmpz_mat(S)
    cp = Sm.charpoly()
    print("n =", n, "charpoly factors:", [(str(f), e) for f, e in cp.factor()[1]])
    M = flint.fmpz_mat([[S[i][j] + (a if i == j else 0) for j in range(n)] for i in range(n)])
    piv, B = rref_basis(M)
    d = len(piv)
    print("rank of S + aI:", d, "information set:", piv)
    Bf = np.array([[float(B[i, j].p) / float(B[i, j].q) for j in range(d)] for i in range(n)])
    sols = []
    # sigma_I in {+-1}^d with sigma_I[0] = +1 (sigma and -sigma give the same line)
    nb = d - 1
    chunk = 1 << 14
    signs_tail = None
    for start in range(0, 1 << nb, chunk):
        idx = np.arange(start, min(start + chunk, 1 << nb), dtype=np.int64)
        T = np.ones((len(idx), d))
        for b in range(nb):
            T[:, b + 1] = 1 - 2 * ((idx >> b) & 1)
        V = T @ Bf.T
        ok = np.all(np.abs(np.abs(V) - 1) < 1e-6, axis=1)
        for k in np.nonzero(ok)[0]:
            sols.append([int(round(v)) for v in V[k]])
    print("candidate +-1 vectors (float):", len(sols))
    exact = []
    G = flint.fmpq_mat(M) * flint.fmpq(1, a)
    # norm via B: w_par^2 = sigma^T G^+ sigma / a^2; with sigma = B t and G restricted ...
    # compute G^+ sigma by solving G y = sigma in the column space: y = B z, G B z = sigma
    GB = G * B
    for s in sols:
        sig = flint.fmpq_mat([[x] for x in s])
        t = flint.fmpq_mat([[s[p]] for p in piv])
        assert B * t == sig, "not in column space"
        # least squares: GB z = sig, GB has full column rank d
        z = (GB.transpose() * GB).solve(GB.transpose() * sig)
        assert GB * z == sig
        y = B * z
        nrm = (sig.transpose() * y)[0, 0] / (a * a)
        exact.append((s, nrm))
    exact.sort(key=lambda e: e[1])
    for s, nrm in exact[:20]:
        print("norm^2 =", nrm, "plus:", sum(1 for x in s if x > 0))
    good = [(s, nrm) for s, nrm in exact if nrm <= 1]
    print("extensions with |w_par|^2 <= 1:", len(good), " with |w_par|^2 == 1:", sum(1 for _, r in good if r == 1))
    if args.out:
        json.dump({"n": n, "a": a, "rank": d, "piv": piv,
                   "sols": [{"sigma": s, "norm2": str(r)} for s, r in exact]}, open(args.out, "w"))


if __name__ == "__main__":
    main()
