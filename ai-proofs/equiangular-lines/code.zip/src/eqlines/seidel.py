"""Congruence conditions on characteristic polynomials of Seidel matrices.

References (statements used verbatim):
  [GY19]  Greaves, Yatsyna, On equiangular lines in 17 dimensions and the
          characteristic polynomial of a Seidel matrix, Math. Comp. 2019.
  [GSY21] Greaves, Syatriadi, Yatsyna, Equiangular lines in low dimensional
          Euclidean spaces, Combinatorica 2021.

* Theorem 2.5 of [GSY21] (= [GY19, Section 3]): for S Seidel of order n write
  chi_{S+I}(x) = sum a_i x^{n-i}.  Then a_0 = 1, a_1 = -n, a_2 = 0; if n is even
  then 2^i | a_i for all i; if n is odd then 2^{i-1} | a_i for odd i and
  2^i | a_i for even i.
* Lemma 2.7 of [GSY21]: chi_{S - kappa I} is weakly type 2 for kappa odd, and
  type 2 if n is even.
* Lemma 2.8 of [GSY21]: factorisation rules for (weakly) type 2.
* Corollary 3.13 of [GY19]: for n odd, |P_{n,e}| <= 2^{C(e-2,2)+1}, where
  P_{n,e} = {chi_S mod 2^e Z[x] : S Seidel of order n}.
"""

import random
from math import comb

from flint import fmpz_mat, fmpz_poly


def coeffs_desc(p):
    """Descending coefficient list of an fmpz_poly."""
    return [int(c) for c in reversed(p.coeffs())]


def from_desc(c):
    return fmpz_poly(list(reversed([int(x) for x in c])))


def shift(p, a):
    """p(x + a)."""
    return p(fmpz_poly([a, 1]))


def v2(a):
    a = int(a)
    if a == 0:
        return 10 ** 9
    return (a & -a).bit_length() - 1


def is_type2(p):
    c = coeffs_desc(p)
    return all(v2(c[i]) >= i for i in range(len(c)))


def is_weakly_type2(p):
    c = coeffs_desc(p)
    return all(v2(c[i]) >= i - 1 for i in range(1, len(c)))


def seidel_plus_I_condition(q, n):
    """Theorem 2.5 of [GSY21] applied to q = chi_{S+I}(x) = chi_S(x-1), n = deg q.
    Returns True iff the divisibility conditions hold (top coefficients a1=-n,
    a2=0 are checked separately by callers that know the trace data)."""
    c = coeffs_desc(q)
    assert len(c) == n + 1
    if n % 2 == 0:
        return all(v2(c[i]) >= i for i in range(n + 1))
    for i in range(1, n + 1):
        need = i if i % 2 == 0 else i - 1
        if v2(c[i]) < need:
            return False
    return True


def random_seidel(n, rng, p_edge=0.5):
    """Random Seidel matrix of order n: S = J - I - 2A for a G(n, p_edge) graph."""
    rows = [[0] * n for _ in range(n)]
    for i in range(n):
        for j in range(i + 1, n):
            s = -1 if rng.random() < p_edge else 1
            rows[i][j] = s
            rows[j][i] = s
    return rows


def charpoly_int(rows):
    return fmpz_mat(rows).charpoly()


def class_key(p, e):
    """Coefficient vector of p mod 2^e (descending)."""
    m = 1 << e
    return tuple(int(c) % m for c in coeffs_desc(p))


def max_classes(n, e):
    k = comb(e - 2, 2) if e >= 2 else 0
    return 2 ** (k + 1) if n % 2 == 1 else 2 ** k


DENSITIES = [0.5, 0.3, 0.7, 0.2, 0.8, 0.1, 0.9, 0.4, 0.6, 0.05, 0.95]


def sample_matrix(n, seed, s):
    """The s-th sample of the class search: reproducible from (n, seed, s)."""
    rng = random.Random(f"{seed}:{n}:{s}")
    return random_seidel(n, rng, DENSITIES[s % len(DENSITIES)])


def generate_classes(n, e, seed=1, max_samples=10 ** 7, log=None, witnesses=None):
    """Random search for the set P_{n,e}.  Returns (classes, samples, complete)
    where complete=True iff the number of classes found reaches the upper bound
    of [GY19, Cor 3.13 / Cor 3.4], in which case the found set IS P_{n,e}.
    If `witnesses` is a dict, the sample index s of the first matrix found in each
    class is stored; sample_matrix(n, seed, s) regenerates it."""
    target = max_classes(n, e)
    classes = set()
    s = 0
    while s < max_samples and len(classes) < target:
        key = class_key(charpoly_int(sample_matrix(n, seed, s)), e)
        if key not in classes:
            classes.add(key)
            if witnesses is not None:
                witnesses[key] = s
        s += 1
        if log is not None and s % 2000 == 0:
            log(f"n={n} e={e} samples={s} classes={len(classes)}/{target}")
    return classes, s, len(classes) >= target
