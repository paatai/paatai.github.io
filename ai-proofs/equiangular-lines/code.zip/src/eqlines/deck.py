"""Interlacing characteristic polynomials ("decks") of a candidate characteristic
polynomial p of a Seidel matrix S of order n.

For p = chi_S write Min_p = prod of the distinct monic irreducible factors of p,
mu = p / Min_p and delta = deg Min_p.  For every vertex i, chi_{S[i]} = mu * g
with g monic of degree delta - 1 (Lemma 2.4 of [GSY21] / Lemma 2.7 of [GS24]):

  (D1) g = x^{t} + b1 x^{t-1} + b2 x^{t-2} + ...,  t = delta - 1,
       b1 = a1, b2 = a2 + n - 1 where Min_p = x^delta + a1 x^{delta-1} + a2 x^{delta-2} + ...
  (D2) g interlaces Min_p (Cauchy interlacing), equivalently
       w_j := g(lambda_j) / Min_p'(lambda_j) >= 0 for every distinct eigenvalue lambda_j;
  (D3) g(x-1) is weakly type 2, and type 2 if n-1 is even or mu(x-1) is not type 2
       (Lemmas 2.7, 2.8 of [GSY21]);
  (D4) if n-1 is odd: chi_{S[i]}(x-1) = mu(x-1) g(x-1) satisfies Theorem 2.5 of [GSY21];
  (D5) optionally: mu*g mod 2^e lies in a supplied complete list P_{n-1,e};
  (D6) optionally ("dimension filter"): g(lambda) != 0 for a supplied eigenvalue lambda
       (used for lambda = -1/alpha when S[i] cannot have that eigenvalue with the
       same multiplicity as S, e.g. because the corresponding line system in one
       dimension less would violate a known upper bound).
  (D7) optionally: every root of g lies in a supplied interval [L, U] (e.g. from the
       trace moments of S[i] once its smallest eigenvalue multiplicity is known).

Every polynomial g returned satisfies (D1)-(D6) and every g satisfying them is
returned (the enumeration of rr.enumerate_real_rooted is exhaustive, and the
windows / congruences used for pruning are consequences of (D2), (D3)).
"""

from math import comb

from flint import arb, ctx, fmpz_poly

from .rr import coeffs_to_poly, enumerate_real_rooted
from .seidel import (class_key, coeffs_desc, is_type2, seidel_plus_I_condition,
                     shift)


class SpecPoly:
    """Candidate characteristic polynomial with its factorisation and certified
    sorted distinct eigenvalues."""

    def __init__(self, p, prec=256):
        self.p = p
        self.n = p.degree()
        content, facs = p.factor()
        if content != 1:
            raise ValueError("p must be monic")
        self.facs = [(q, int(e)) for q, e in facs]
        minp = fmpz_poly([1])
        for q, _e in self.facs:
            minp *= q
        self.minp = minp
        mu, r = divmod(p, minp)
        assert r == 0
        self.mu = mu
        self.delta = minp.degree()
        self.prec = prec
        self._isolate(prec)
        h, r = divmod(p.derivative(), mu)
        assert r == 0
        self.h = h  # p'/mu, degree delta-1, leading coefficient n

    def _isolate(self, prec):
        # complex_roots is deterministic at a fixed precision, so a stored result is reused.
        hit = self.__dict__.setdefault("_iso", {}).get(prec)
        if hit is not None:
            self.lams, self.lam_fac, self.mult = (list(v) for v in hit)
            return
        old = ctx.prec
        ctx.prec = prec
        try:
            roots = []
            for idx, (q, _e) in enumerate(self.facs):
                for z, m in q.complex_roots():
                    if not z.imag.is_zero() or m != 1:
                        raise ValueError("p is not real-rooted / factor not squarefree")
                    roots.append((z.real, idx))
            roots.sort(key=lambda r: float(r[0].mid()))
            for k in range(len(roots) - 1):
                if not bool(roots[k][0] < roots[k + 1][0]):
                    raise ValueError("eigenvalue isolation failed; raise precision")
        finally:
            ctx.prec = old
        self.lams = [r for r, _ in roots]
        self.lam_fac = [i for _, i in roots]
        self.mult = [self.facs[i][1] for i in self.lam_fac]
        self._iso[prec] = (tuple(self.lams), tuple(self.lam_fac), tuple(self.mult))

    def eig_index(self, value):
        """Index of the distinct eigenvalue equal to the integer `value`."""
        for j, idx in enumerate(self.lam_fac):
            q = self.facs[idx][0]
            if q.degree() == 1 and -int(q.coeffs()[0]) == value:
                return j
        return None

    def sign_at(self, g, j):
        """Exact sign of g at the j-th distinct eigenvalue."""
        q = self.facs[self.lam_fac[j]][0]
        if g % q == 0:
            return 0
        prec = self.prec
        lam = self.lams[j]
        while True:
            old = ctx.prec
            ctx.prec = prec
            try:
                v = g(lam)
                if v > 0:
                    return 1
                if v < 0:
                    return -1
            finally:
                ctx.prec = old
            prec *= 2
            if prec > 1 << 16:
                raise RuntimeError("sign determination failed")
            self._isolate(prec)
            lam = self.lams[j]

    def interlaces(self, g):
        """Exact test of (D2): sign g(lambda_j) in {0, sign Min_p'(lambda_j)}."""
        d = self.delta
        for j in range(d):
            s = self.sign_at(g, j)
            want = 1 if (d - 1 - j) % 2 == 0 else -1
            if s != 0 and s != want:
                return False
        return True

    def weights_float(self, g):
        """Approximate weights w_j (floats), for LP heuristics only."""
        dm = self.minp.derivative()
        out = []
        for lam in self.lams:
            out.append(float((g(lam) / dm(lam)).mid()))
        return out

    def mult_vector(self):
        return list(self.mult)


def deck(sp, classes=None, e=7, nonzero_at=None, use_odd_cond=True, stats=None,
         max_nodes=None, root_box=None):
    """Return the list of descending coefficient lists of all g satisfying (D1)-(D6).

    classes: optional set of class keys (tuples, descending coefficients of
             chi mod 2^e) forming the complete set P_{n-1,e}.
    nonzero_at: optional list of integer eigenvalues lambda with g(lambda) != 0 required.
    root_box: optional (L, U) (arb or rationals) with every root of g in [L, U]
              (D7).  Then every root of every derivative of g is in [L, U] as well.
    """
    n = sp.n
    t = sp.delta - 1
    a = coeffs_desc(sp.minp)
    b1 = a[1]
    b2 = a[2] + n - 1
    lam = sp.lams
    if t == 0:
        return [[1]]
    mu1 = shift(sp.mu, -1)
    need_type2 = ((n - 1) % 2 == 0) or (not is_type2(mu1))

    def beta(c, i):
        return sum(c[j] * comb(t - j, i - j) * (-1) ** (i - j) for j in range(i + 1))

    def ok_beta(c, i):
        need = i if need_type2 else i - 1
        b = beta(c, i)
        return b % (1 << need) == 0 if need > 0 else True

    if t == 1:
        cands = [[1, b1]]
        if root_box is not None and not (root_box[0] <= -b1 <= root_box[1]):
            cands = []
    else:
        pre = [1, b1, b2]
        if not (ok_beta(pre, 1) and ok_beta(pre, 2)):
            return []
        cands = None

    def congr(i, pref):
        need = i if need_type2 else i - 1
        mod = 1 << need
        s = sum(pref[j] * comb(t - j, i - j) * (-1) ** (i - j) for j in range(i))
        return ({(-s) % mod}, mod)

    box = None if root_box is None else (arb(root_box[0]), arb(root_box[1]))

    def windows(i, k):
        L, U = lam[k - 1], lam[k + t - i]
        if box is not None:
            L, U = L.max(box[0]), U.min(box[1])
        return (L, U)

    zero_idx = []
    if nonzero_at:
        for v in nonzero_at:
            j = sp.eig_index(v)
            if j is not None:
                zero_idx.append(j)

    def leaf(c):
        g = coeffs_to_poly(c)
        if not sp.interlaces(g):
            return False
        for j in zero_idx:
            if sp.sign_at(g, j) == 0:
                return False
        f = sp.mu * g
        if use_odd_cond and (n - 1) % 2 == 1:
            if not seidel_plus_I_condition(shift(f, -1), n - 1):
                return False
        if classes is not None and (n - 1) % 2 == 1:
            if class_key(f, e) not in classes:
                return False
        return True

    if cands is not None:
        return [c for c in cands if leaf(c)]
    out = []
    for c in enumerate_real_rooted(t, b1, b2, congr=congr, windows=windows, leaf=leaf,
                                   stats=stats, max_nodes=max_nodes):
        out.append(c)
    return out


def candidate_poly(psi_desc, kappa, m_low, m_kappa, low=-5):
    """p(x) = (x - low)^{m_low} (x - kappa)^{m_kappa} * 2^deg psi * psi((x - kappa)/2)."""
    d = len(psi_desc) - 1
    # phi(x) = sum_j c_j 2^j (x - kappa)^{d - j}
    xk = fmpz_poly([-kappa, 1])
    phi = fmpz_poly([0])
    for j, cj in enumerate(psi_desc):
        phi += cj * (2 ** j) * xk ** (d - j)
    return fmpz_poly([-low, 1]) ** m_low * xk ** m_kappa * phi


_ = arb  # re-exported for callers that build windows by hand
