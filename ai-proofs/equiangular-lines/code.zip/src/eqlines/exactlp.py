"""Exact rational feasibility for {A x = b, x >= 0} (phase-1 revised simplex over Q).

Returns ("feasible", x) with x an exact rational solution, or ("infeasible", y) with an exact
Farkas vector: A^T y >= 0 and b.y < 0. Both answers are re-checked exactly by the caller-facing
helpers check_feasible / check_farkas before they are returned, so the pivot rule below affects
only the running time, never the answer.

Phase 1 of the sign-normalised system [sA | I] (x, a) = |b|, (x, a) >= 0, minimising sum(a),
from the all-artificial basis.  Every basis solve is exact (flint's fmpz_mat.solve, over Q).
Pivot rule: Dantzig's (most negative reduced cost); after DEGEN consecutive pivots without a
strict decrease of the objective, Bland's rule (smallest index; cannot cycle) until the next
strict decrease.  Ties in the ratio test go to the smallest basic index.
"""

from fractions import Fraction

from flint import fmpq, fmpz_mat

DEGEN = 50


def check_feasible(A, b, x):
    if any(v < 0 for v in x):
        return False
    return all(sum(Fraction(a) * v for a, v in zip(row, x)) == bi for row, bi in zip(A, b))


def check_farkas(A, b, y):
    ncol = len(A[0]) if A else 0
    for j in range(ncol):
        if sum(Fraction(A[i][j]) * y[i] for i in range(len(A)) if A[i][j]) < 0:
            return False
    return sum(Fraction(bi) * yi for bi, yi in zip(b, y)) < 0


def _frac(q):
    return Fraction(int(q.p), int(q.q))


def solve(A, b):
    m = len(A)
    n = len(A[0]) if m else 0
    if m == 0:
        return "feasible", [Fraction(0)] * n
    sign = [(-1 if bi < 0 else 1) for bi in b]
    Ms = [[sign[i] * A[i][j] for j in range(n)] + [1 if k == i else 0 for k in range(m)]
          for i in range(m)]
    N = n + m
    cost = [0] * n + [1] * m
    MT = fmpz_mat(Ms).transpose()
    bvec = fmpz_mat([[sign[i] * b[i]] for i in range(m)])
    basis = list(range(n, N))
    best_obj, stall = None, 0
    while True:
        B = fmpz_mat([[Ms[i][j] for j in basis] for i in range(m)])
        xB = B.solve(bvec)
        w = B.transpose().solve(fmpz_mat([[cost[j]] for j in basis]))
        obj = sum((xB[i, 0] for i in range(m) if basis[i] >= n), fmpq(0))
        if best_obj is None or obj < best_obj:
            best_obj, stall = obj, 0
        else:
            stall += 1
        W, den = w.numer_denom()
        MW = MT * W
        inb = set(basis)
        enter, low = None, None
        for j in range(N):
            if j in inb:
                continue
            d = cost[j] * den - MW[j, 0]
            if d < 0:
                if stall >= DEGEN:
                    enter = j
                    break
                if low is None or d < low:
                    enter, low = j, d
        if enter is None:
            break
        u = B.solve(fmpz_mat([[Ms[i][enter]] for i in range(m)]))
        ratio, leave = None, None
        for i in range(m):
            if u[i, 0] > 0:
                r = xB[i, 0] / u[i, 0]
                if ratio is None or r < ratio or (r == ratio and basis[i] < basis[leave]):
                    ratio, leave = r, i
        if leave is None:
            raise RuntimeError("phase 1 unbounded (impossible)")
        basis[leave] = enter
    if obj == 0:
        x = [Fraction(0)] * n
        for i in range(m):
            if basis[i] < n:
                x[basis[i]] = _frac(xB[i, 0])
        assert check_feasible(A, b, x)
        return "feasible", x
    y = [-_frac(w[k, 0]) * sign[k] for k in range(m)]
    assert check_farkas(A, b, y)
    return "infeasible", y
