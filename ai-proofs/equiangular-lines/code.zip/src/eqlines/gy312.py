"""The 2-adic congruences of [GY19, Lemma 3.12] for Seidel matrices of odd order.

[GY19] Greaves, Yatsyna, On equiangular lines in 17 dimensions and the characteristic polynomial
       of a Seidel matrix, Math. Comp. 88 (2019).

Let S be a Seidel matrix of odd order N and chi_{S+I}(x) = sum_i a_i x^(N-i). Then
  (R)    a_0 = 1, a_1 = -N, a_2 = 0                         [GY19, Remark 3.3];
  (L31)  2^(i-1) | a_i for i >= 1                          [GY19, Lemma 3.1];
  (L38)  2^i | a_i for even i                              [GY19, Lemma 3.8];
  (L312) for 2 <= k <= (N-1)/2                              [GY19, Lemma 3.12]:
           a_{2k+1} = sum_{d | 2k} sum_{m} C_d(m) P_d(m)   (mod 2^(2k+1)),
         over m = (m_1, ..., m_d) with sum_j j m_j = d and m_{2k} = 0, where
           C_d(m) = 2^(2k) (d phi(2k/d) / 2k) (m_1 + ... + m_d - 1)! / (m_1! ... m_d!),
           P_d(m) = prod_j s_j^(m_j),
           s_{2j} = a_{2j+1} / (2^(2j) N),  s_{2j-1} = (a_{2j+1} + a_{2j} + a_{2j-1} a_3) / 2^(2j-1).
The lemma is stated for chi_{J-2A} with A an Euler graph; chi_{S+I} is a switching invariant and,
for odd N, every switching class contains an Euler graph, so it holds for every S.

Two evaluations of the right side are provided: the literal partition sum (rhs_partition) and the
equivalent power-sum form (rhs_newton): sum_m d (|m|-1)!/prod m_j! prod s_j^(m_j) over all m with
sum j m_j = d is the d-th coefficient p_d of t d/dt log 1/(1 - sum_j s_j t^j), which satisfies
p_d = d s_d + sum_{i<d} s_i p_{d-i}; the constraint m_{2k} = 0 removes the single term 2k s_{2k}.
All arithmetic is in exact rationals; the congruence is tested as v_2(a_{2k+1} - rhs) >= 2k + 1.
"""

from fractions import Fraction
from math import factorial

from flint import fmpz_poly

INF = 10 ** 9


def v2_int(a):
    a = int(a)
    if a == 0:
        return INF
    return (a & -a).bit_length() - 1


def v2_frac(q):
    q = Fraction(q)
    if q == 0:
        return INF
    return v2_int(q.numerator) - v2_int(q.denominator)


def phi(n):
    r, m, p = n, n, 2
    while p * p <= m:
        if m % p == 0:
            while m % p == 0:
                m //= p
            r -= r // p
        p += 1
    if m > 1:
        r -= r // m
    return r


def divisors(n):
    return [d for d in range(1, n + 1) if n % d == 0]


def plus_I_coeffs(chi_S, upto=None):
    """Coefficients a_0..a_upto of chi_{S+I}(x) = chi_S(x - 1), from an fmpz_poly chi_S."""
    q = chi_S(fmpz_poly([-1, 1]))
    c = [int(x) for x in reversed(q.coeffs())]
    return c if upto is None else c[:upto + 1]


def s_values(a, N, k):
    """s_1, ..., s_{2k} (index 0 unused) for the congruence at level k; needs a_0..a_{2k+1}."""
    s = [None] * (2 * k + 1)
    for j in range(1, k + 1):
        s[2 * j - 1] = Fraction(a[2 * j + 1] + a[2 * j] + a[2 * j - 1] * a[3], 2 ** (2 * j - 1))
        s[2 * j] = Fraction(a[2 * j + 1], 2 ** (2 * j) * N)
    return s


def _partitions(d, maxpart):
    """Multiplicity vectors m (dict part -> count) of the partitions of d with parts <= maxpart."""
    def rec(rem, largest):
        if rem == 0:
            yield {}
            return
        for p in range(min(rem, largest), 0, -1):
            for rest in rec(rem - p, p):
                m = dict(rest)
                m[p] = m.get(p, 0) + 1
                yield m
    yield from rec(d, maxpart)


def rhs_partition(a, N, k):
    """Right side of (L312) at level k, literal partition sum."""
    s = s_values(a, N, k)
    n2k = 2 * k
    tot = Fraction(0)
    for d in divisors(n2k):
        for m in _partitions(d, d):
            if m.get(n2k, 0) != 0:
                continue
            size = sum(m.values())
            c = Fraction(2 ** n2k * d * phi(n2k // d) * factorial(size - 1), n2k)
            for j, mj in m.items():
                c /= factorial(mj)
            pr = Fraction(1)
            for j, mj in m.items():
                pr *= s[j] ** mj
            tot += c * pr
    return tot


def rhs_newton(a, N, k):
    """Right side of (L312) at level k via p_d = d s_d + sum_{i<d} s_i p_{d-i}, s_{2k} := 0."""
    s = s_values(a, N, k)
    n2k = 2 * k
    s[n2k] = Fraction(0)
    p = [Fraction(0)] * (n2k + 1)
    for d in range(1, n2k + 1):
        p[d] = d * s[d] + sum((s[i] * p[d - i] for i in range(1, d)), Fraction(0))
    tot = sum((phi(n2k // d) * p[d] for d in divisors(n2k)), Fraction(0))
    return tot * Fraction(2 ** n2k, n2k)


def check_a(a, N, kmax=None, rhs=rhs_newton):
    """All of (R), (L31), (L38), (L312) for k <= kmax on a = [a_0, ..., a_m] (m >= 2 kmax + 1).
    Returns None if all hold, otherwise a string naming the first failure."""
    assert N % 2 == 1
    if a[0] != 1 or a[1] != -N or a[2] != 0:
        return "R"
    top = len(a) - 1
    for i in range(1, top + 1):
        need = i if i % 2 == 0 else i - 1
        if v2_int(a[i]) < need:
            return f"L31/L38 at i={i}"
    kk = (N - 1) // 2 if kmax is None else min(kmax, (N - 1) // 2)
    kk = min(kk, (top - 1) // 2)
    for k in range(2, kk + 1):
        if v2_frac(a[2 * k + 1] - rhs(a, N, k)) < 2 * k + 1:
            return f"L312 at k={k}"
    return None


def check_chi_S(chi_S, kmax=None):
    """check_a for chi_S (an fmpz_poly of odd degree N)."""
    N = chi_S.degree()
    kk = (N - 1) // 2 if kmax is None else min(kmax, (N - 1) // 2)
    return check_a(plus_I_coeffs(chi_S), N, kk)
