"""Level 3: triangle types and edge systems.

Notation as in eqlines.jacobi and eqlines.star: p = chi_S of order n, Min = Min_p, R(x) = (xI - S)^{-1},
R_ii = g_i / Min, R_ij = psi_ij / Min (i != j), psihat_ij = S_ij psi_ij (a function of the pair
type), and for three distinct vertices the triangle sign tau_ijk = S_ij S_jk S_ki (switching
invariant).  Write Sim, Dbl, L3 for the products of the distinct irreducible factors of p of
multiplicity 1, 2, >= 3, and mu3 = prod_{m >= 3} q^(m - 3).

Triangle types.  Jacobi's identity chi_{S[T]} = chi_S det R[T] for T = {i, j, k} gives
    chi_{S[ijk]} = mu3 * Q,  Q = B / (Sim^2 Dbl),
    B = g_i g_j g_k + 2 tau u_ij u_jk u_ik - g_i u_jk^2 - g_j u_ik^2 - g_k u_ij^2  (u = psihat),
since R_ij R_jk R_ki = tau u_ij u_jk u_ik / Min^3.  A triangle type is *allowed* if
  (T1) Sim^2 Dbl divides B;
  (T2) mu3 Q is monic of degree n - 3 with the trace coefficients of a Seidel matrix of that order;
  (T3) mu3 Q (x - 1) satisfies [GSY21, Thm 2.5] (eqlines.seidel.seidel_plus_I_condition);
  (T4) Q(v) != 0 for v in nonzero_at (as for the pair polynomials: for v = -5 the subgraph would
       be n - 3 lines in one dimension less);
  (T5) mu3 Q interlaces chi_{S[ij]} = mu2 P_ij for each of the three edges (Cauchy), i.e. Q
       interlaces L3 P_ij.
Every triangle of a Seidel matrix with these vertex and pair types has an allowed type.

Edge systems.  For an edge type (a, b, u) (i of type a, j of type b, psihat_ij = u), let
c_{h,u1,u2,tau} count the k != i, j of type h with psihat_ik = u1, psihat_jk = u2, tau_ijk = tau.
Then, besides the counts (sum = n_h - [h = a] - [h = b]):
  (La) (RS)_ij = x R_ij:      sum c tau u1(x) = x u(x) - g_a(x);
  (Lb) (SR)_ij = x R_ij:      sum c tau u2(x) = x u(x) - g_b(x);
  (Q)  (R(x) R(y))_ij = (R_ij(x) - R_ij(y)) / (y - x):
       sum c tau u1(x) u2(y) = (u(x) Min(y) - u(y) Min(x)) / (y - x) - g_a(x) u(y) - u(x) g_b(y);
and the counts are linked to the vertex stars of i and j (eqlines.star.ResolventStar, whose
rows (L) and (Q) are added for both ends, and the deck identity):
sum_{u2,tau} c_{h,u1,u2,tau} = m^i_{h,u1} - [h = b, u1 = u], and symmetrically for j.  (The
derivative principle sum_k chi_{S[ijk]} = chi_{S[ij]}' follows from these: its terms are the
diagonal x = y of (Q), the vertex stars and the deck identity.)  Every identity has degree
< delta in each variable, so it is imposed modulo each irreducible factor of Min (CRT; at
x = theta for a rational eigenvalue theta).  The system A x = b, x >= 0 is decided by
eqlines.farkas: only an exactly verified Farkas vector counts as infeasible.
"""

from math import comb

from flint import fmpz_poly

from . import farkas
from .jacobi import interlaces
from .seidel import coeffs_desc, seidel_plus_I_condition, shift


def poly(c):
    return fmpz_poly(list(reversed([int(v) for v in c])))


def key(P):
    return tuple(coeffs_desc(P)) if P != 0 else (0,)


def points(deg):
    """deg + 1 integer points centred at 0."""
    lo = -(deg // 2)
    return list(range(lo, lo + deg + 1))


class Level3:
    def __init__(self, sp, G, E, nonzero_at=(-5,)):
        """sp: SpecPoly; G: dict member -> fmpz_poly g; E: dict (a, b), a <= b -> list of
        distinct psihat (fmpz_poly) of the pair types between members a and b."""
        self.sp, self.n = sp, sp.n
        self.G = dict(G)
        self.U = sorted(self.G)
        self.E = {}
        for (a, b), us in E.items():
            uniq = {key(u): u for u in us}
            self.E[(a, b)] = [uniq[k] for k in sorted(uniq)]
        one = fmpz_poly([1])
        sim, dbl, l3, mu2, mu3 = one, one, one, one, one
        for q, m in sp.facs:
            if m == 1:
                sim *= q
            elif m == 2:
                dbl *= q
            else:
                l3 *= q
            if m >= 2:
                mu2 *= q ** (m - 2)
            if m >= 3:
                mu3 *= q ** (m - 3)
        self.sim, self.dbl, self.l3, self.mu2, self.mu3 = sim, dbl, l3, mu2, mu3
        self.den3 = sim * sim * dbl
        self.minp = sp.minp
        self.nonzero_at = list(nonzero_at)
        self._tri = {}
        self._P = {}

    def pairs(self, a, b):
        return self.E.get((min(a, b), max(a, b)), [])

    def P(self, a, b, u):
        k = (min(a, b), max(a, b), key(u))
        if k not in self._P:
            P, r = divmod(self.G[a] * self.G[b] - u * u, self.sim)
            assert r == 0
            self._P[k] = P
        return self._P[k]

    def triangle(self, a, b, c, uab, ubc, uac, tau):
        """Q for an allowed triangle type, else None (cached; symmetric in the vertices)."""
        k = (tuple(sorted([(a, key(ubc)), (b, key(uac)), (c, key(uab))])), tau)
        if k in self._tri:
            return self._tri[k]
        ga, gb, gc = self.G[a], self.G[b], self.G[c]
        B = ga * gb * gc + 2 * tau * uab * ubc * uac - ga * ubc * ubc - gb * uac * uac \
            - gc * uab * uab
        res = None
        Q, r = divmod(B, self.den3)
        if r == 0 and all(int(Q(v)) != 0 for v in self.nonzero_at):
            chi = self.mu3 * Q
            N = self.n - 3
            cd = coeffs_desc(chi)
            if chi.degree() == N and cd[0] == 1 and cd[1] == 0 and cd[2] == -comb(N, 2) \
                    and seidel_plus_I_condition(shift(chi, -1), N):
                ok = True
                for (x, y, u) in ((a, b, uab), (b, c, ubc), (a, c, uac)):
                    if not interlaces(Q, self.l3 * self.P(x, y, u)):
                        ok = False
                        break
                if ok:
                    res = Q
        self._tri[k] = res
        return res

    def triangle_types(self, a, b, u):
        """Allowed (h, u1, u2, tau, Q) for the edge type (a, b, u): k of type h, psihat_ik = u1,
        psihat_jk = u2."""
        out = []
        for h in self.U:
            for u1 in self.pairs(a, h):
                for u2 in self.pairs(b, h):
                    for tau in (1, -1):
                        Q = self.triangle(a, b, h, u, u2, u1, tau)
                        if Q is not None:
                            out.append((h, u1, u2, tau, Q))
        return out

    # ---- spectral rows ---------------------------------------------------------------------
    # A polynomial identity of degree < delta holds iff it holds modulo every irreducible factor
    # q of Min (CRT, Min squarefree); for q = x - theta this is evaluation at theta.  Bivariate
    # identities of degree < delta in each variable are reduced modulo q(x) and q'(y).
    def spec(self, f):
        if not hasattr(self, "_facs"):
            self._facs = [q for q, _m in self.sp.facs]
        assert f == 0 or f.degree() < self.sp.delta
        out = []
        for q in self._facs:
            r = f % q
            c = [int(v) for v in r.coeffs()] if r != 0 else []
            out += c + [0] * (q.degree() - len(c))
        return out

    def spec2_dd(self, u):
        """Spectral matrix of (u(x) Min(y) - u(y) Min(x)) / (y - x)."""
        d = self.sp.delta
        uc = [int(v) for v in u.coeffs()] if u != 0 else []
        Mc = [int(v) for v in self.minp.coeffs()]
        C = [[0] * d for _ in range(d)]
        for p, up in enumerate(uc):
            if not up:
                continue
            for q, mq in enumerate(Mc):
                if not mq or q == p:
                    continue
                if q > p:
                    for r in range(q - p):
                        C[q - 1 - r][p + r] += up * mq
                else:
                    for r in range(p - q):
                        C[p - 1 - r][q + r] -= up * mq
        cols = [self.spec(fmpz_poly([C[p][q] for p in range(d)])) for q in range(d)]
        # cols[q] = spectral vector (in x) of the coefficient of y^q; then reduce in y
        rows = []
        for k in range(d):
            yk = fmpz_poly([cols[q][k] for q in range(d)])
            rows.append(self.spec(yk))
        return rows  # rows[k][l]: x-component k, y-component l

    def _sv(self, f):
        k = ("sv", key(f))
        if k not in self._P:
            self._P[k] = self.spec(f)
        return self._P[k]

    def edge_system(self, a, b, u, support=None, nfix=None):
        """Rows, rhs, names, triangle types of the edge system for (a, b, u) on the support
        (default: all members); nfix optionally fixes the counts n_h."""
        U = sorted(support) if support is not None else self.U
        if a not in U or b not in U:
            return None
        sp, d = self.sp, self.sp.delta
        x = fmpz_poly([0, 1])
        tris = [t for t in self.triangle_types(a, b, u) if t[0] in U]
        names, col = [], {}

        def var(nm):
            col[nm] = len(names)
            names.append(nm)

        loops = {h: bool(self.pairs(h, h)) for h in U}
        if nfix is None:
            for h in U:
                if loops[h]:
                    var(("n", h))
        for t in range(len(tris)):
            var(("c", t))
        for end, f in (("i", a), ("j", b)):
            for h in U:
                for w in range(len(self.pairs(f, h))):
                    var(("m", end, h, w))
        rows, rhs = [], []

        def add(row, r):
            rows.append(row)
            rhs.append(r)

        def nval(h):
            if nfix is not None:
                return None, nfix[h]
            return (col[("n", h)], 1) if loops[h] else (None, 1)

        if nfix is None:
            sh = self._sv(sp.h)
            sg = {h: self._sv(self.G[h]) for h in U}
            for k in range(d):
                row = [0] * len(names)
                r = sh[k]
                for h in U:
                    c, k0 = nval(h)
                    r -= k0 * sg[h][k]
                    if c is not None:
                        row[c] = sg[h][k]
                add(row, r)
        for h in U:
            row = [0] * len(names)
            for t, tt in enumerate(tris):
                if tt[0] == h:
                    row[col[("c", t)]] = 1
            c, k0 = nval(h)
            if c is not None:
                row[c] -= 1
            add(row, k0 - (1 if h == a else 0) - (1 if h == b else 0))
        for end, f, other, pos in (("i", a, b, 1), ("j", b, a, 2)):
            for h in U:
                for w, uw in enumerate(self.pairs(f, h)):
                    row = [0] * len(names)
                    for t, tt in enumerate(tris):
                        if tt[0] == h and key(tt[pos]) == key(uw):
                            row[col[("c", t)]] = 1
                    row[col[("m", end, h, w)]] -= 1
                    add(row, -(1 if (h == other and key(uw) == key(u)) else 0))
                row = [0] * len(names)
                for w in range(len(self.pairs(f, h))):
                    row[col[("m", end, h, w)]] = 1
                c, k0 = nval(h)
                if c is not None:
                    row[c] -= 1
                add(row, k0 - (1 if h == f else 0))
            # vertex star of this end: (L) and (Q) on the diagonal
            sL = self._sv(x * self.G[f] - self.minp)
            sgf = self._sv(self.G[f])
            DD = self.spec2_dd(self.G[f])
            for k in range(d):
                row = [0] * len(names)
                for h in U:
                    for w, uw in enumerate(self.pairs(f, h)):
                        row[col[("m", end, h, w)]] = self._sv(uw)[k]
                add(row, sL[k])
            for k in range(d):
                for l in range(k, d):
                    row = [0] * len(names)
                    for h in U:
                        for w, uw in enumerate(self.pairs(f, h)):
                            sw = self._sv(uw)
                            row[col[("m", end, h, w)]] = sw[k] * sw[l]
                    add(row, DD[k][l] - sgf[k] * sgf[l])
        su = self._sv(u)
        sga, sgb = self._sv(self.G[a]), self._sv(self.G[b])
        for pos, g in ((1, self.G[a]), (2, self.G[b])):
            sR = self._sv(x * u - g)
            for k in range(d):
                row = [0] * len(names)
                for t, tt in enumerate(tris):
                    row[col[("c", t)]] = tt[3] * self._sv(tt[pos])[k]
                add(row, sR[k])
        DDu = self.spec2_dd(u)
        for k in range(d):
            for l in range(d):
                row = [0] * len(names)
                for t, tt in enumerate(tris):
                    row[col[("c", t)]] = tt[3] * self._sv(tt[1])[k] * self._sv(tt[2])[l]
                add(row, DDu[k][l] - sga[k] * su[l] - su[k] * sgb[l])
        return rows, rhs, names, tris

    def solve_edge(self, a, b, u, support=None, nfix=None, integer=False, max_nodes=4000):
        """LP decision; with integer=True an LP-feasible system is then decided over the
        integers by eqlines.farkas.branch_and_bound (exact Farkas vector at every leaf)."""
        built = self.edge_system(a, b, u, support, nfix)
        if built is None:
            return "absent", None
        rows, rhs, names, tris = built
        st, y = farkas.decide(rows, rhs)
        if st == "certified":
            return "certified", {"y": [str(v) for v in y], "ntri": len(tris)}
        if integer and st == "feasible":
            st2, t = farkas.branch_and_bound(rows, rhs, max_nodes=max_nodes)
            if st2 == "certified":
                return "certified", {"tree": t, "ntri": len(tris)}
            return ("feasible-int" if st2 == "feasible" else "unknown-int"), {"ntri": len(tris)}
        return st, {"ntri": len(tris)}
