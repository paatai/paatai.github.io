"""Seidel-compatibility of interlacing characteristic polynomials (level 2).

Let S be a Seidel matrix of order n with chi_S = p, Min = Min_p, and let
Sim = prod_{simple eigenvalues} (x - lambda), M = Min / Sim (M vanishes exactly on
the multiple eigenvalues).  For a vertex i write chi_{S[i]} = mu * g_i (deck member).
For a simple eigenvalue lambda with unit eigenvector u, u(i)^2 = g_i(lambda)/Min'(lambda)
[GSY23, Lemma 4.4], and Min'(lambda) = M(lambda) Sim'(lambda).  Hence for i != j and
every k >= 0

    (x^k M)(S)_{ij} = sum_{lambda simple} lambda^k M(lambda) u(i) u(j)
                    = sum_{lambda simple} d_lambda lambda^k sqrt(g_i g_j(lambda)) / Sim'(lambda)

for some signs d in {+-1}^{simple}.  The left side is an integer, and its parity is
fixed by S = J - I (mod 2):

    n even: S^2 = I (mod 2), so off-diagonal entries of r(S) are = sum_{k odd} r_k;
    n odd : off-diagonal entries of S^k (k >= 1) are odd [GSY23, sec. 4], so they are
            = r(1) - r(0).

This is [GSY23, Lemma 4.7] with xi = Sim, q = M and multipliers x^k (0 <= k < deg Sim,
which span Z[x] M modulo Min), plus the parity rule, which [GSY23] states for odd n
only.  Two deck members g, h are *compatible* if some sign vector d makes all these
numbers integers of the right parity; a member is *self-compatible* if this holds
for g = h (needed when two vertices have the same deck member).

Exactness: every value is an arb ball.  A sign vector is rejected only if, for some
k, the ball contains no integer, or contains exactly one integer and that integer has
the wrong parity.  Incompatibility is therefore proved; compatibility is only
"not refuted" (which is the safe direction for exclusions).
"""

from itertools import product

from flint import arb, ctx, fmpz_poly

from .rr import coeffs_to_poly
from .seidel import coeffs_desc


def off_parity(r, n):
    """Parity of the off-diagonal entries of r(S) for a Seidel matrix S of order n."""
    c = list(reversed(coeffs_desc(r)))  # ascending
    if n % 2 == 0:
        return sum(c[k] for k in range(1, len(c), 2)) % 2
    return (sum(c) - c[0]) % 2


def diag_parity(r, n):
    """Parity of the diagonal entries of r(S)."""
    c = list(reversed(coeffs_desc(r)))
    if n % 2 == 0:
        return sum(c[k] for k in range(0, len(c), 2)) % 2
    return c[0] % 2


class Compat:
    def __init__(self, sp, D, prec=512):
        self.sp = sp
        self.n = sp.n
        self.D = [list(c) for c in D]
        self.G = [coeffs_to_poly(c) for c in self.D]
        self.simple = [j for j in range(sp.delta) if sp.mult[j] == 1]
        sim = fmpz_poly([1])
        for q, e in sp.facs:
            if e == 1:
                sim *= q
        self.sim = sim
        M, r = divmod(sp.minp, sim)
        assert r == 0
        self.M = M
        self.s = sim.degree()
        self.prec = prec
        x = fmpz_poly([0, 1])
        self.par = [off_parity(x ** k * M, self.n) for k in range(self.s)]
        self._cache = {}
        self._vals = {}

    def min_parity_ok(self):
        """Necessary condition on p itself: Min(S) = 0 has even entries."""
        return off_parity(self.sp.minp, self.n) == 0 and diag_parity(self.sp.minp, self.n) == 0

    def _values(self, a, prec):
        key = (a, prec)
        if key not in self._vals:
            sp = self.sp
            old = ctx.prec
            ctx.prec = prec
            try:
                sp._isolate(prec)
                out = []
                for j in self.simple:
                    q = sp.facs[sp.lam_fac[j]][0]
                    if self.G[a] % q == 0:
                        out.append(None)
                    else:
                        out.append(self.G[a](sp.lams[j]))
                self._vals[key] = out
            finally:
                ctx.prec = old
        return self._vals[key]

    def _test(self, a, b, prec):
        """Return 'incompatible', 'compatible' or 'unknown' at the given precision."""
        sp = self.sp
        old = ctx.prec
        ctx.prec = prec
        try:
            va = self._values(a, prec)
            vb = self._values(b, prec)
            sp._isolate(prec)
            dsim = self.sim.derivative()
            terms = []
            for idx, j in enumerate(self.simple):
                lam = sp.lams[j]
                if va[idx] is None or vb[idx] is None:
                    terms.append(None)
                    continue
                prodv = va[idx] * vb[idx]
                if not prodv > 0:
                    return "unknown"
                base = prodv.sqrt() / dsim(lam)
                terms.append([base * lam ** k for k in range(self.s)])
            live = [i for i, t in enumerate(terms) if t is not None]
            unknown = False
            # d and -d give negated values; fix the sign of the first live term.
            choices = [(1,)] + [(1, -1)] * (len(live) - 1) if live else []
            for signs in product(*choices):
                ok = True
                undecided = False
                for k in range(self.s):
                    tot = arb(0)
                    for sgn, i in zip(signs, live):
                        tot += sgn * terms[i][k]
                    if not tot.contains_integer():
                        ok = False
                        break
                    m = tot.unique_fmpz()
                    if m is None:
                        undecided = True
                        continue
                    if int(m) % 2 != self.par[k]:
                        ok = False
                        break
                if ok and not undecided:
                    return "compatible"
                if ok and undecided:
                    unknown = True
            return "unknown" if unknown else "incompatible"
        finally:
            ctx.prec = old

    def compatible(self, a, b):
        key = (min(a, b), max(a, b))
        if key in self._cache:
            return self._cache[key]
        prec = self.prec
        while True:
            r = self._test(a, b, prec)
            if r != "unknown":
                break
            prec *= 2
            if prec > 1 << 14:
                r = "compatible"  # undecided: keep (safe direction)
                break
        res = (r == "compatible")
        self._cache[key] = res
        return res

    def graph(self, idxs=None):
        """Adjacency sets and self-loop flags on the members idxs (default: all)."""
        idxs = list(range(len(self.D))) if idxs is None else list(idxs)
        adj = {a: set() for a in idxs}
        loop = {}
        for ia, a in enumerate(idxs):
            loop[a] = self.compatible(a, a)
            for b in idxs[ia + 1:]:
                if self.compatible(a, b):
                    adj[a].add(b)
                    adj[b].add(a)
        return adj, loop


def maximal_cliques(adj):
    """Bron-Kerbosch with pivoting; yields frozensets."""
    out = []

    def bk(R, P, X):
        if not P and not X:
            out.append(frozenset(R))
            return
        u = max(P | X, key=lambda v: len(adj[v] & P))
        for v in list(P - adj[u]):
            bk(R | {v}, P & adj[v], X & adj[v])
            P = P - {v}
            X = X | {v}

    bk(set(), set(adj), set())
    return out


_ = coeffs_desc
