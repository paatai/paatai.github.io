"""Deciding {A x = b, x >= 0} for integer data: floating point finds, exact arithmetic proves.

`decide(rows, rhs)` returns
  ("certified", y)   y a primitive integer vector with A^T y >= 0 and b.y < 0, checked exactly
                     (Farkas: the system has no solution, rational or integer);
  ("feasible", None) the floating-point Farkas LP is infeasible (so, up to rounding, the system
                     has a nonnegative solution);
  ("unknown", None)  a float Farkas vector was found but could not be made exact.
Only "certified" is ever used to exclude anything; the other two keep the case open.
"""

from fractions import Fraction

import numpy as np
from scipy.optimize import linprog

from .lpcert import _exact_solve_closest, integer_certificate


def check_farkas(rows, rhs, y):
    y = [Fraction(v) for v in y]
    ncol = len(rows[0]) if rows else 0
    for j in range(ncol):
        if sum(Fraction(r[j]) * yy for r, yy in zip(rows, y) if r[j] and yy) < 0:
            return False
    return sum(Fraction(bb) * yy for bb, yy in zip(rhs, y) if bb and yy) < 0


def decide(rows, rhs, tols=(1e-9, 1e-7, 1e-11, 1e-5)):
    m = len(rows)
    if m == 0:
        return "feasible", None
    n = len(rows[0])
    if n == 0:
        for i, v in enumerate(rhs):
            if v != 0:
                y = [0] * m
                y[i] = -1 if v > 0 else 1
                return "certified", y
        return "feasible", None
    A = np.array([[float(v) for v in r] for r in rows])
    b = np.array([float(v) for v in rhs])
    s = np.maximum(np.abs(A).max(axis=1), np.abs(b))
    s[s == 0] = 1.0
    As, bs = A / s[:, None], b / s
    res = linprog(np.zeros(m), A_ub=-As.T, b_ub=np.zeros(n), A_eq=bs[None, :], b_eq=[-1.0],
                  bounds=[(None, None)] * m, method="highs-ds")
    if res.status == 2:
        return "feasible", None
    if res.status != 0:
        return "unknown", None
    ys = res.x
    slack = As.T @ ys
    yf = ys / s
    scale = max(1.0, float(np.abs(ys).max()))
    for tl in tols:
        tight = [j for j in range(n) if slack[j] <= tl * scale]
        erows = [[int(rows[i][j]) for i in range(m)] for j in tight] + [[int(v) for v in rhs]]
        erhs = [0] * len(tight) + [-1]
        Y = _exact_solve_closest(erows, erhs, yf)
        if Y is not None and check_farkas(rows, rhs, Y):
            Z = integer_certificate(Y)
            assert check_farkas(rows, rhs, Z)
            return "certified", Z
    return "unknown", None


def bounded_form(rows, rhs, bounds):
    """{A x = b, lo <= x <= hi} -> standard form {A' x' = b', x' >= 0} with x = lo + x'[:n] and
    one slack per finite upper bound (row x'_j + s_j = hi_j - lo_j)."""
    n = len(rows[0]) if rows else 0
    ub = sorted(j for j, (lo, hi) in bounds.items() if hi is not None)
    R = [list(r) + [0] * len(ub) for r in rows]
    h = list(rhs)
    for j, (lo, hi) in bounds.items():
        if lo:
            for i, r in enumerate(rows):
                if r[j]:
                    h[i] -= r[j] * lo
    for t, j in enumerate(ub):
        lo, hi = bounds[j]
        row = [0] * (n + len(ub))
        row[j] = 1
        row[n + t] = 1
        R.append(row)
        h.append(hi - (lo or 0))
    return R, h


def _lp_point(rows, rhs):
    A = np.array([[float(v) for v in r] for r in rows])
    b = np.array([float(v) for v in rhs])
    s = np.maximum(np.abs(A).max(axis=1), np.abs(b))
    s[s == 0] = 1.0
    res = linprog(np.zeros(A.shape[1]), A_eq=A / s[:, None], b_eq=b / s,
                  bounds=[(0, None)] * A.shape[1], method="highs-ds")
    return res.x if res.status == 0 else None


def exact_point(rows, rhs, tols=(1e-9, 1e-7, 1e-11)):
    """An exact rational x >= 0 with A x = b, checked exactly, or None.

    The floating-point LP point only proposes a support; x is the exact solution on that support
    closest to it. None means only that this attempt failed."""
    n = len(rows[0]) if rows else 0
    xf = _lp_point(rows, rhs) if n else None
    if xf is None:
        return None
    for tl in tols:
        supp = [j for j in range(n) if xf[j] > tl]
        x = [Fraction(0)] * n
        if supp:
            Y = _exact_solve_closest([[r[j] for j in supp] for r in rows], rhs, xf[supp])
            if Y is None or any(v < 0 for v in Y):
                continue
            for j, v in zip(supp, Y):
                x[j] = v
        if all(sum(Fraction(r[j]) * x[j] for j in supp if r[j]) == bb for r, bb in zip(rows, rhs)):
            return x
    return None


def branch_and_bound(rows, rhs, max_nodes=4000):
    """Integer feasibility of {A x = b, x >= 0 integer}.  Returns
      ("certified", tree)  tree: {"y": Farkas vector} at a leaf, or {"var": j, "k": k,
                           "le": subtree for x_j <= k, "ge": subtree for x_j >= k + 1};
                           every leaf is checked exactly (see check_tree);
      ("feasible", x)      an exact integer solution;
      ("unknown", None)    node limit, or a float LP / exactification failure.
    """
    n = len(rows[0]) if rows else 0
    count = [0]

    def rec(bounds):
        count[0] += 1
        if count[0] > max_nodes:
            return "unknown", None
        for j, (lo, hi) in bounds.items():
            if hi is not None and hi < (lo or 0):
                R, h = bounded_form(rows, rhs, bounds)
                st, y = decide(R, h)
                return (st, {"y": y}) if st == "certified" else ("unknown", None)
        R, h = bounded_form(rows, rhs, bounds)
        st, y = decide(R, h)
        if st == "certified":
            return "certified", {"y": y}
        if st == "unknown":
            return "unknown", None
        xp = _lp_point(R, h)
        if xp is None:
            return "unknown", None
        x = [(bounds.get(j, (0, None))[0] or 0) + xp[j] for j in range(n)]
        frac = [(abs(v - round(v)), j) for j, v in enumerate(x) if abs(v - round(v)) > 1e-7]
        if not frac:
            xi = [int(round(v)) for v in x]
            if all(v >= 0 for v in xi) and all(sum(a * v for a, v in zip(r, xi)) == bb
                                               for r, bb in zip(rows, rhs)):
                return "feasible", xi
            return "unknown", None
        _, j = max(frac)
        k = int(np.floor(x[j]))
        lo, hi = bounds.get(j, (0, None))
        b1 = dict(bounds)
        b1[j] = (lo, k)
        s1, t1 = rec(b1)
        if s1 != "certified":
            return s1, t1
        b2 = dict(bounds)
        b2[j] = (k + 1, hi)
        s2, t2 = rec(b2)
        if s2 != "certified":
            return s2, t2
        return "certified", {"var": j, "k": k, "le": t1, "ge": t2}

    st, t = rec({})
    if st == "certified":
        assert check_tree(rows, rhs, t)
    return st, t


def check_tree(rows, rhs, tree, bounds=None):
    """Exact check of a branch-and-bound certificate (every integer x >= 0 lies in some leaf, and
    every leaf system has a verified Farkas vector)."""
    bounds = dict(bounds or {})
    if "y" in tree:
        R, h = bounded_form(rows, rhs, bounds)
        return check_farkas(R, h, tree["y"])
    j, k = tree["var"], tree["k"]
    lo, hi = bounds.get(j, (0, None))
    b1 = dict(bounds)
    b1[j] = (lo, k)
    b2 = dict(bounds)
    b2[j] = (k + 1, hi)
    return check_tree(rows, rhs, tree["le"], b1) and check_tree(rows, rhs, tree["ge"], b2)
