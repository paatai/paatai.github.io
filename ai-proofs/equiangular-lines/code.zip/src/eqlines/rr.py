"""Exhaustive enumeration of real-rooted monic integer polynomials.

Setting.  f(x) = sum_{j=0}^t c_j x^{t-j}, c_0 = 1, with c_1, c_2 prescribed.
For 2 <= i <= t let D_i = f^{(t-i)} (degree i, positive leading coefficient):

    D_i(x) = sum_{j=0}^{i} c_j (t-j)!/(i-j)! x^{i-j},   D_i' = D_{i-1}.

If f is real-rooted then so is every D_i.  Write D_i = P_i + C with
C = c_i (t-i)! and P_i(0) = 0.  If mu_1 <= ... <= mu_{i-1} are the roots of
D_{i-1} (with multiplicity) then D_i is real-rooted iff

    (-1)^{i-k} (P_i(mu_k) + C) >= 0     for k = 1, ..., i-1.

So the admissible values of c_i form an interval.  The interval endpoints are
computed in ball arithmetic (an outer enclosure), and *every* accepted node is
re-verified exactly: flint's certified root isolation returns real roots with an
imaginary part that is exactly zero, so `is_real_rooted` is an exact test.

Optional pruning data (all of it only ever removes polynomials that provably
violate a necessary condition):
  * congruences: c_i must lie in a set of residues modulo some modulus that may
    depend on the prefix (c_0, ..., c_{i-1});
  * root windows: the k-th smallest root of D_i must lie in [L, U].  Since D_i is
    monotone between consecutive roots of D_{i-1}, a window on a root of D_i is
    a linear condition on C, which is used to shrink the range of c_i before
    any root isolation is done.  The window is re-checked on the certified
    roots of every accepted D_i.

Fast path of `real_roots_or_none`: floating-point roots (numpy) only propose.  Each is
refined by Newton steps (at most 6, on midpoints), and a sign change of f between two exact
dyadic points around it is checked in ball arithmetic.  deg f such disjoint sign changes
prove that all roots are real and simple and enclose each one; how the points were found
plays no role.  Whenever this fails (a nonreal or multiple root, or an uncertain sign), the
exact test with complex_roots decides.
"""

from math import factorial

import numpy as np
from flint import arb, arb_poly, ctx, fmpq, fmpz_poly

ctx.prec = 128
_EPS = arb(2) ** -60
_TOL = arb(2) ** -100


def is_real_rooted(f):
    """Exact test that all complex roots of the integer polynomial f are real."""
    if f.degree() <= 0:
        return True
    for z, _m in f.complex_roots():
        if not z.imag.is_zero():
            return False
    return True


def real_roots_sorted(f):
    """Certified real roots (arb balls) of a real-rooted integer polynomial, with
    multiplicity, sorted.  Raises if some root is not real."""
    out = []
    for z, m in f.complex_roots():
        if not z.imag.is_zero():
            raise ValueError("polynomial is not real-rooted")
        out.extend([z.real] * m)
    out.sort(key=lambda b: float(b.mid()))
    return out


def _simple_real_roots_certified(f):
    """Sorted enclosures of the roots of f if they are proved real and simple, else None."""
    d = f.degree()
    if d < 1:
        return []
    r = np.roots([float(int(a)) for a in reversed(f.coeffs())])
    if (len(r) != d or not np.all(np.isfinite(r))
            or np.any(np.abs(r.imag) > 1e-6 * (1.0 + np.abs(r.real)))):
        return None
    fp = arb_poly(f)
    dp = fp.derivative()
    out, prev = [], None
    for x0 in np.sort(r.real):
        x = arb(float(x0))
        for _ in range(6):
            dx = dp(x)
            if not (dx > 0 or dx < 0):
                return None
            step = (fp(x) / dx).mid()
            x = (x - step).mid()
            if abs(step) < _TOL * (1 + abs(x)):
                break
        e = _EPS * (1 + abs(x))
        lo, hi = (x - e).mid(), (x + e).mid()
        if not (lo < hi) or (prev is not None and not (prev < lo)):
            return None
        slo, shi = fp(lo), fp(hi)
        if not ((slo < 0 and shi > 0) or (slo > 0 and shi < 0)):
            return None
        out.append(lo.union(hi))
        prev = hi
    return out


def real_roots_or_none(f):
    """Certified real roots (sorted, with multiplicity) or None if f has a
    nonreal root.  Fast path (see the module docstring), else one root isolation
    call (exact decision, see is_real_rooted)."""
    fast = _simple_real_roots_certified(f)
    if fast is not None:
        return fast
    out = []
    for z, m in f.complex_roots():
        if not z.imag.is_zero():
            return None
        out.extend([z.real] * m)
    out.sort(key=lambda b: float(b.mid()))
    return out


def _arb_lt(a, b):
    """True only if a < b is certain."""
    return bool(a < b)


def _dyadic_to_fmpq(x):
    man, ex = x.man_exp()
    man, ex = int(man), int(ex)
    return fmpq(man * 2 ** ex) if ex >= 0 else fmpq(man, 2 ** (-ex))


def arb_endpoints(x):
    """Exact rational endpoints (lo, hi) of the ball x."""
    m = _dyadic_to_fmpq(x.mid())
    r = _dyadic_to_fmpq(x.rad())
    return m - r, m + r


def _floor_div_up(x_arb, q):
    """floor(hi/q) where hi is the exact upper endpoint of the ball: an integer
    that is >= the largest admissible c for every value in the ball."""
    _lo, hi = arb_endpoints(x_arb)
    return int((hi / q).floor())


def _ceil_div_low(x_arb, q):
    lo, _hi = arb_endpoints(x_arb)
    return int((lo / q).ceil())


def _poly_from_c(c, t, i):
    """D_i as an fmpz_poly from the prefix c[0..i]."""
    coeffs = [0] * (i + 1)  # coeffs[k] = coefficient of x^k
    for j in range(i + 1):
        coeffs[i - j] = c[j] * (factorial(t - j) // factorial(i - j))
    return fmpz_poly(coeffs)


def _eval_P(c, t, i, x):
    """Evaluate P_i(x) = D_i(x) - D_i(0) at an arb x (Horner)."""
    acc = arb(0)
    for j in range(i):
        acc = acc * x + c[j] * (factorial(t - j) // factorial(i - j))
    return acc * x


def enumerate_real_rooted(t, c1, c2, congr=None, windows=None, leaf=None,
                          max_nodes=None, stats=None):
    """Yield coefficient lists [c_0, ..., c_t] (c_0 = 1) of all real-rooted monic
    integer polynomials of degree t with the given c_1, c_2, satisfying the
    optional constraints.

    congr(i, prefix) -> None | (residues_set, modulus): admissible residues of c_i.
    windows(i, k) -> None | (L, U): arb bounds (either may be None) for the k-th
        smallest root (1-based) of D_i = f^{(t-i)}.
    leaf(c) -> bool: optional final filter.
    """
    if stats is None:
        stats = {}
    stats.setdefault("nodes", 0)
    stats.setdefault("leaves", 0)
    c = [1, c1, c2]
    if t < 2:
        raise ValueError("t >= 2 required")
    D2 = _poly_from_c(c, t, 2)
    if not is_real_rooted(D2):
        return
    roots2 = real_roots_sorted(D2)
    if not _check_windows(windows, 2, roots2):
        return
    if t == 2:
        if leaf is None or leaf(list(c)):
            yield list(c)
        return
    stack = [(c, roots2)]
    while stack:
        pref, mu = stack.pop()
        i = len(pref)  # we now choose c_i
        stats["nodes"] += 1
        if max_nodes is not None and stats["nodes"] > max_nodes:
            raise RuntimeError("node limit exceeded")
        q = factorial(t - i)
        lo = None  # lower bound for C (arb)
        hi = None
        Pmu = [_eval_P(pref, t, i, m) for m in mu]
        for k in range(1, i):
            v = -Pmu[k - 1]
            if (i - k) % 2 == 0:
                lo = v if lo is None else _arb_max(lo, v)
            else:
                hi = v if hi is None else _arb_min(hi, v)
        # windows on roots of D_i -> linear constraints on C
        if windows is not None:
            ok = True
            for k in range(1, i + 1):
                w = windows(i, k)
                if w is None:
                    continue
                L, U = w
                left = mu[k - 2] if k >= 2 else None
                right = mu[k - 1] if k <= i - 1 else None
                sigma = 1 if (i - k) % 2 == 0 else -1
                if L is not None:
                    if right is not None and _arb_lt(right, L):
                        ok = False
                        break
                    inside = (left is None or _arb_lt(left, L)) and (right is None or _arb_lt(L, right))
                    if inside:
                        v = -_eval_P(pref, t, i, L)
                        if sigma == 1:
                            hi = v if hi is None else _arb_min(hi, v)
                        else:
                            lo = v if lo is None else _arb_max(lo, v)
                if U is not None:
                    if left is not None and _arb_lt(U, left):
                        ok = False
                        break
                    inside = (left is None or _arb_lt(left, U)) and (right is None or _arb_lt(U, right))
                    if inside:
                        v = -_eval_P(pref, t, i, U)
                        if sigma == 1:
                            lo = v if lo is None else _arb_max(lo, v)
                        else:
                            hi = v if hi is None else _arb_min(hi, v)
            if not ok:
                continue
        if lo is None or hi is None:
            raise RuntimeError("unbounded range; need t >= 3 with c1,c2 fixed")
        cmin = _ceil_div_low(lo, q)
        cmax = _floor_div_up(hi, q)
        if cmin > cmax:
            continue
        cg = congr(i, pref) if congr is not None else None
        if cg is None:
            cand = range(cmin, cmax + 1)
        else:
            res, mod = cg
            cand = _residue_range(cmin, cmax, res, mod)
        for ci in cand:
            newc = pref + [ci]
            Di = _poly_from_c(newc, t, i)
            rts = real_roots_or_none(Di)
            if rts is None:
                continue
            if not _check_windows(windows, i, rts):
                continue
            if i == t:
                stats["leaves"] += 1
                if leaf is None or leaf(newc):
                    yield newc
            else:
                stack.append((newc, rts))


def _arb_max(a, b):
    return a.max(b)


def _arb_min(a, b):
    return a.min(b)


def _residue_range(cmin, cmax, residues, mod):
    out = []
    for r in sorted(set(x % mod for x in residues)):
        start = cmin + ((r - cmin) % mod)
        out.extend(range(start, cmax + 1, mod))
    out.sort()
    return out


def _check_windows(windows, i, roots):
    if windows is None:
        return True
    for k in range(1, i + 1):
        w = windows(i, k)
        if w is None:
            continue
        L, U = w
        r = roots[k - 1]
        if L is not None and _arb_lt(r, L):
            return False
        if U is not None and _arb_lt(U, r):
            return False
    return True


def coeffs_to_poly(c):
    """[c_0..c_t] (descending) -> fmpz_poly."""
    return fmpz_poly(list(reversed(c)))


def poly_to_coeffs(p):
    """fmpz_poly -> descending coefficient list."""
    return [int(x) for x in reversed(p.coeffs())]
