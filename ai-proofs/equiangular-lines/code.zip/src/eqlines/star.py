"""Vertex stars (level 2.5): the Jacobi pair polynomials summed around one vertex.

Notation as in eqlines.jacobi: p = chi_S of order n, mu, mu2, deck members g (chi_{S[i]} = mu g),
and for vertices i != j, chi_{S[ij]} = mu2 P_ij with P_ij in Pairs(g_i, g_j) (pair_polys over
both signs). Since sum_{j != i} chi_{S[ij]} = chi_{S[i]}',

    (V)  sum_{j != i} P_ij = H_{g_i},   H_g := (mu g)' / mu2,

and for every vertex i and every member g, the number of j != i with g_j = g is n_g - [g = g_i].

Star system for a support U (the members with n_g >= 1; n_g = 0 outside U):
  variables n_g (g in U; n_g >= 1, and n_g = 1 if g has no loop in the pair graph) and
  m^f_{g,P} >= 0 (f, g in U, P in Pairs(f, g)), with
    (E1) sum_g n_g g = h                                 (the deck identity);
    (E2) sum_P m^f_{g,P} = n_g - [g = f]                 (f, g in U);
    (E3) sum_{g,P} m^f_{g,P} P = H_f                     (f in U).
A configuration with support U gives a solution (n_g from S, m^f from any vertex of type f).
The polynomial identities are imposed at deg + 1 integer points (equivalent, and better
conditioned than coefficients). Infeasibility is certified by an exact Farkas vector y for
A x = b, x >= 0 (after n_g = 1 + n'_g): A^T y >= 0 and b.y < 0. Floating-point LPs first propose
a Farkas vector or a feasible point (eqlines.farkas), which counts only after an exact check;
when neither check succeeds, an exact rational simplex (eqlines.exactlp) decides.
"""

from fractions import Fraction

from flint import fmpz_poly

from . import exactlp, farkas
from .lpcert import integer_certificate


def eval_points(deg, lo=-6):
    return list(range(lo, lo + deg + 1))


class StarSystem:
    def __init__(self, sp, ps, deck_polys, h, pairs):
        """deck_polys: list of fmpz_poly g; h: fmpz_poly; pairs: dict (a, b) -> list of
        distinct fmpz_poly P for a <= b (deck indices)."""
        self.sp, self.ps = sp, ps
        self.G = deck_polys
        self.h = h
        self.pairs = {}
        for (a, b), Ps in pairs.items():
            uniq = {tuple(coeffs_of(P)): P for P in Ps}
            self.pairs[(a, b)] = [uniq[k] for k in sorted(uniq)]
            self.pairs[(b, a)] = self.pairs[(a, b)]
        self.H = {}
        for a, g in enumerate(deck_polys):
            num = (sp.mu * g).derivative()
            q, r = divmod(num, ps.mu2)
            assert r == 0
            self.H[a] = q
        self.dg = sp.delta - 1
        self.dP = None
        for Ps in self.pairs.values():
            for P in Ps:
                self.dP = P.degree()
                break
            if self.dP is not None:
                break

    def loop(self, a):
        return bool(self.pairs.get((a, a)))

    def build(self, U):
        """Integer system (A, b, names) with x >= 0, or None if U is not a clique."""
        U = list(U)
        for i, a in enumerate(U):
            for b in U[i:]:
                if a != b and not self.pairs.get((a, b)):
                    return None
        fixed = {a: 1 for a in U if not self.loop(a)}
        names = []
        col = {}
        for a in U:
            if a not in fixed:
                col[("n", a)] = len(names)
                names.append(("n", a))
        for f in U:
            for g in U:
                for k, _P in enumerate(self.pairs.get((f, g), [])):
                    col[("m", f, g, k)] = len(names)
                    names.append(("m", f, g, k))
        rows, rhs = [], []
        xs1 = eval_points(self.dg)
        for x in xs1:
            row = [0] * len(names)
            r = int(self.h(x))
            for a in U:
                v = int(self.G[a](x))
                if a in fixed:
                    r -= v
                else:
                    row[col[("n", a)]] = v
                    r -= v  # n_a = 1 + n'_a
            rows.append(row)
            rhs.append(r)
        for f in U:
            for g in U:
                row = [0] * len(names)
                for k, _P in enumerate(self.pairs.get((f, g), [])):
                    row[col[("m", f, g, k)]] = 1
                r = -(1 if g == f else 0)
                if g in fixed:
                    r += 1
                else:
                    row[col[("n", g)]] = -1
                    r += 1
                rows.append(row)
                rhs.append(r)
        if self.dP is not None:
            xs2 = eval_points(self.dP)
            for f in U:
                for x in xs2:
                    row = [0] * len(names)
                    for g in U:
                        for k, P in enumerate(self.pairs.get((f, g), [])):
                            row[col[("m", f, g, k)]] = int(P(x))
                    rows.append(row)
                    rhs.append(int(self.H[f](x)))
        return rows, rhs, names

    @staticmethod
    def verify_farkas(rows, rhs, y):
        y = [Fraction(v) for v in y]
        ncol = len(rows[0]) if rows else 0
        for j in range(ncol):
            if sum(Fraction(r[j]) * yy for r, yy in zip(rows, y) if r[j]) < 0:
                return False
        return sum(Fraction(b) * yy for b, yy in zip(rhs, y)) < 0

    def solve(self, U):
        """('not-clique', None) | ('feasible', exact x) | ('certified', exact Farkas y)."""
        built = self.build(U)
        if built is None:
            return "not-clique", None
        rows, rhs, names = built
        if not names:
            if all(v == 0 for v in rhs):
                return "feasible", {"x": [], "names": names}
            y = [Fraction(0)] * len(rhs)
            k = next(i for i, v in enumerate(rhs) if v != 0)
            y[k] = Fraction(-1 if rhs[k] > 0 else 1)
            return "certified", {"y": [str(v) for v in y], "names": names}
        status, y = farkas.decide(rows, rhs)
        if status == "certified":
            assert self.verify_farkas(rows, rhs, y)
            return "certified", {"y": [str(a) for a in y], "names": names}
        if status == "feasible":
            x = farkas.exact_point(rows, rhs)
            if x is not None:
                assert exactlp.check_feasible(rows, rhs, x)
                return "feasible", {"x": [str(a) for a in x], "names": names}
        status, v = exactlp.solve(rows, rhs)
        if status == "feasible":
            return "feasible", {"x": [str(a) for a in v], "names": names}
        y = integer_certificate(v)
        assert self.verify_farkas(rows, rhs, y)
        return "certified", {"y": [str(a) for a in y], "names": names}


class ResolventStar(StarSystem):
    """Row i of the resolvent R(x) = (xI - S)^{-1} = sum_lambda E_lambda / (x - lambda).

    With R_ii = g_i / Min and R_ij = psi_ij / Min (i != j), and psihat_ij = S_ij psi_ij:
      (L) (S R(x))_ii = x R_ii(x) - 1:
            sum_{j != i} psihat_ij(x) = x g_i(x) - Min(x);
      (Q) (R(x) R(y))_ii = (R_ii(x) - R_ii(y)) / (y - x)  (resolvent identity):
            sum_{j != i} psihat_ij(x) psihat_ij(y) = (g_i(x) Min(y) - g_i(y) Min(x)) / (y - x)
                                                     - g_i(x) g_i(y).
    (Q) on the diagonal x = y is the star identity (E3), so this system refines StarSystem.
    Variables m^f_{g,u} count the j != i (i of type f) with g_j = g and psihat_ij = u, where
    u runs over the distinct psihat = sigma psi of the pairs found by PairSpace.pair_polys.
    Both identities are imposed at delta (resp. delta x delta, x <= y) integer points, which
    determines polynomials of degree <= delta - 1 in each variable.
    """

    def __init__(self, sp, deck_polys, h, psihats):
        self.sp = sp
        self.G = deck_polys
        self.h = h
        self.pairs = {}
        for (a, b), us in psihats.items():
            uniq = {tuple(coeffs_of(u)): u for u in us}
            self.pairs[(a, b)] = [uniq[k] for k in sorted(uniq)]
            self.pairs[(b, a)] = self.pairs[(a, b)]
        self.minp = sp.minp
        self.dg = sp.delta - 1
        self.pts = eval_points(sp.delta - 1)

    def _B(self, f, x, y):
        g, M = self.G[f], self.minp
        if x == y:
            return int(g(x) * M.derivative()(x) - g.derivative()(x) * M(x) - g(x) * g(x))
        num = int(g(x) * M(y) - g(y) * M(x))
        q, r = divmod(num, y - x)
        assert r == 0
        return q - int(g(x) * g(y))

    def build(self, U):
        U = list(U)
        for i, a in enumerate(U):
            for b in U[i:]:
                if a != b and not self.pairs.get((a, b)):
                    return None
        fixed = {a: 1 for a in U if not self.loop(a)}
        names, col = [], {}
        for a in U:
            if a not in fixed:
                col[("n", a)] = len(names)
                names.append(("n", a))
        for f in U:
            for g in U:
                for k in range(len(self.pairs.get((f, g), []))):
                    col[("m", f, g, k)] = len(names)
                    names.append(("m", f, g, k))
        rows, rhs = [], []
        for x in eval_points(self.dg):
            row = [0] * len(names)
            r = int(self.h(x))
            for a in U:
                v = int(self.G[a](x))
                r -= v
                if a not in fixed:
                    row[col[("n", a)]] = v
            rows.append(row)
            rhs.append(r)
        for f in U:
            for g in U:
                row = [0] * len(names)
                for k in range(len(self.pairs.get((f, g), []))):
                    row[col[("m", f, g, k)]] = 1
                r = 1 - (1 if g == f else 0)
                if g not in fixed:
                    row[col[("n", g)]] = -1
                rows.append(row)
                rhs.append(r)
        for f in U:
            for x in self.pts:
                row = [0] * len(names)
                for g in U:
                    for k, u in enumerate(self.pairs.get((f, g), [])):
                        row[col[("m", f, g, k)]] = int(u(x))
                rows.append(row)
                rhs.append(int(x * self.G[f](x) - self.minp(x)))
            for ia, x in enumerate(self.pts):
                for y in self.pts[ia:]:
                    row = [0] * len(names)
                    for g in U:
                        for k, u in enumerate(self.pairs.get((f, g), [])):
                            row[col[("m", f, g, k)]] = int(u(x) * u(y))
                    rows.append(row)
                    rhs.append(self._B(f, x, y))
        return rows, rhs, names


def coeffs_of(P):
    return [int(c) for c in reversed(P.coeffs())]


def poly(c):
    return fmpz_poly(list(reversed([int(v) for v in c])))


class RelaxedStar(ResolventStar):
    """One vertex star over a clique with a free support (stage R, for cliques too large for
    the support-by-support systems).

    For a clique K of the pair graph and a member f of K, a configuration whose support
    U = {g : n_g >= 1} lies in K and contains f gives, from any vertex i of type f, a solution of
      (E1) sum_{g in K} n_g g(x) = h(x);
      (E2) sum_u m_{g,u} = n_g - [g = f]                        (g in K);
      (L)  sum_{g, u} m_{g,u} u(x) = x g_f(x) - Min(x);
      (Q)  sum_{g, u} m_{g,u} u(x) u(y) = DD(g_f)(x, y) - g_f(x) g_f(y)   (x <= y);
    with n_f >= 1, n_g >= 0 (n_g <= 1 for members without a loop) and m_{g,u} >= 0, where u runs
    over the pair types psihat of (f, g).  If it has no solution, no support contained in K
    contains f, and f can be removed from K.
    Variables ("n", g): n_g for g != f, n_f - 1 for g = f (only if f has a loop; else n_f = 1),
    and ("m", g, k).  Rows in the order of `labels`; the certificate is in box form:
    sum_v min over the box of (y^T A)_v v > y.b.
    """

    def build_relaxed(self, K, f):
        K = sorted(K)
        if f not in K:
            return None
        for i, a in enumerate(K):
            for b in K[i + 1:]:
                if not self.pairs.get((a, b)):
                    return None
        loop = {g: self.loop(g) for g in K}
        names, col, bounds = [], {}, {}
        for g in K:
            if g == f and not loop[g]:
                continue
            col[("n", g)] = len(names)
            if g != f and not loop[g]:
                bounds[len(names)] = (0, 1)
            names.append(("n", g))
        for g in K:
            for k in range(len(self.pairs.get((f, g), []))):
                col[("m", g, k)] = len(names)
                names.append(("m", g, k))
        rows, rhs, labels = [], [], []
        for x in self.pts:
            row = [0] * len(names)
            for g in K:
                if ("n", g) in col:
                    row[col[("n", g)]] = int(self.G[g](x))
            rows.append(row)
            rhs.append(int(self.h(x)) - int(self.G[f](x)))
            labels.append(["E1", x])
        for g in K:
            if g == f and not loop[g]:
                continue
            row = [0] * len(names)
            for k in range(len(self.pairs.get((f, g), []))):
                row[col[("m", g, k)]] = 1
            row[col[("n", g)]] = -1
            rows.append(row)
            rhs.append(0)
            labels.append(["E2", g])
        for x in self.pts:
            row = [0] * len(names)
            for g in K:
                for k, u in enumerate(self.pairs.get((f, g), [])):
                    row[col[("m", g, k)]] = int(u(x))
            rows.append(row)
            rhs.append(int(x * self.G[f](x) - self.minp(x)))
            labels.append(["L", x])
        for ia, x in enumerate(self.pts):
            for y in self.pts[ia:]:
                row = [0] * len(names)
                for g in K:
                    for k, u in enumerate(self.pairs.get((f, g), [])):
                        row[col[("m", g, k)]] = int(u(x) * u(y))
                rows.append(row)
                rhs.append(self._B(f, x, y))
                labels.append(["Q", x, y])
        return rows, rhs, names, labels, bounds

    @staticmethod
    def check_box(rows, rhs, y, bounds):
        y = [Fraction(v) for v in y]
        n = len(rows[0]) if rows else 0
        tot = Fraction(0)
        for j in range(n):
            c = sum(y[r] * rows[r][j] for r in range(len(rows)) if rows[r][j] and y[r])
            if c < 0:
                if j not in bounds:
                    return False
                tot += c * bounds[j][1]
        return tot > sum(y[r] * rhs[r] for r in range(len(rhs)) if y[r])

    def solve_relaxed(self, K, f):
        """('not-clique', None) | ('open', None) | ('certified', {'y': box-form vector})."""
        from . import farkas
        built = self.build_relaxed(K, f)
        if built is None:
            return "not-clique", None
        rows, rhs, names, labels, bounds = built
        R, hh = farkas.bounded_form(rows, rhs, bounds)
        st, y = farkas.decide(R, hh)
        if st != "certified":
            return "open", None
        yb = [Fraction(v) for v in y[:len(rows)]]
        assert self.check_box(rows, rhs, yb, bounds)
        return "certified", {"y": [str(v) for v in yb], "labels": labels}
