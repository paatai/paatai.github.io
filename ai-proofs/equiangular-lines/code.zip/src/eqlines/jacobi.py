"""Pairs of vertices via the Jacobi identity (level 2).

Let S be a Seidel matrix of order n, p = chi_S, Min = Min_p, Sim = product of the
simple-eigenvalue factors, M = Min/Sim, mu = p/Min and mu2 = mu/M (so a root of p of
multiplicity m >= 2 has multiplicity m - 2 in mu2).  For vertices i != j let
f = chi_{S[i]}/mu, g = chi_{S[j]}/mu (deck members) and

    phi(x) = adj(xI - S)_{ij},     phi/p = sum_lambda E_lambda(i,j)/(x - lambda)
                                         = sum_{k>=0} (S^k)_{ij} x^{-k-1}.

Then phi = mu * psi with psi in Z[x]: psi = polynomial part of Min(x) sum_k t_k x^{-k-1},
t_k = (S^k)_{ij}, so psi has degree delta - 2 and leading coefficient t_1 = S_{ij} = +-1.
The Jacobi identity for the 2x2 minors of the adjugate gives

    chi_{S[i]} chi_{S[j]} - chi_S chi_{S[ij]} = phi^2,
    hence  chi_{S[ij]} = mu2 * P,   P = (f g - psi^2) / Sim.

Necessary conditions used here (all exact):
  (J1) t_k = (S^k)_{ij} has the parity of the off-diagonal entries of S^k
       (n even: k odd; n odd: all k >= 1);
  (J2) psi(lambda)^2 = f(lambda) g(lambda) at every simple eigenvalue (E_lambda has rank 1),
       i.e. Sim divides f g - psi^2;
  (J3) psi(lambda)^2 <= f(lambda) g(lambda) at every multiple eigenvalue
       (psi(lambda) = E_lambda(i,j) Min'(lambda), Cauchy-Schwarz for E_lambda >= 0);
  (J4) chi_{S[ij]} = mu2 P is real-rooted and interlaces chi_{S[i]} and chi_{S[j]}
       (equivalently P interlaces M f and M g);
  (J5) S[ij] is a Seidel matrix of order n - 2: tr = 0, tr S[ij]^2 = (n-2)(n-3), and
       chi_{S[ij]}(x - 1) satisfies [GSY21, Thm 2.5];
  (J6) optional: P(lambda0) != 0 for a supplied eigenvalue lambda0 (dimension count).
For a pair of deck members and a sign sigma = S_{ij}, `pair_polys` returns every psi
satisfying (J1)-(J6) together with P.  If both signs give nothing, no two vertices of
S can carry f and g.

Enumeration: by (J2), psi = pi + Sim * r, where pi in Z[x] (deg < deg Sim) interpolates
d_lambda sqrt(f g(lambda)) at the simple eigenvalues for some sign vector d (pi has
integer coefficients because psi does and Sim is monic).  Every sign vector is tried;
pi is computed in ball arithmetic, rounded only if every coefficient ball contains a
unique integer, and then verified exactly (Sim | f g - pi^2).  The remaining
coefficients of r (r = sigma x^D + ..., D = delta - 2 - deg Sim) are fixed one at a time
(_r_candidates): (J3) bounds r at every multiple eigenvalue, divided differences over
subsets of them enclose the next coefficient in ball arithmetic, and (J1) is applied to
every prefix.  Every surviving psi is then tested exactly.
"""

from itertools import combinations, product

from flint import arb, ctx, fmpz_poly

from .seidel import coeffs_desc, seidel_plus_I_condition, shift


def _poly_arb_coeffs_div_linear(P, lam):
    """Coefficients (ascending, arb) of P(x)/(x - lam) for a root lam of P."""
    c = [arb(int(v)) for v in P.coeffs()]  # ascending
    d = len(c) - 1
    q = [arb(0)] * d
    acc = arb(0)
    for k in range(d, 0, -1):
        acc = acc * lam + c[k]
        q[k - 1] = acc
    return q


def _real_roots(q, prec):
    old = ctx.prec
    ctx.prec = prec
    try:
        out = []
        for z, m in q.complex_roots():
            if not z.imag.is_zero() or m != 1:
                raise ValueError("factor not real squarefree")
            out.append(z.real)
        return out
    finally:
        ctx.prec = old


def interlaces(A, B, prec=256):
    """Exact test: A (monic, deg N-1) interlaces B (monic, deg N, real-rooted), i.e. the
    roots alpha_k of A and beta_k of B satisfy beta_k <= alpha_k <= beta_{k+1}."""
    if B.degree() != A.degree() + 1:
        return False
    G = A.gcd(B)
    A1, r1 = divmod(A, G)
    B1, r2 = divmod(B, G)
    assert r1 == 0 and r2 == 0
    if B1.degree() == 0:
        return False
    if B1.gcd(B1.derivative()).degree() > 0:
        return False  # a multiple root of B1 that is not a root of A1
    dB = B1.derivative()
    while True:
        old = ctx.prec
        ctx.prec = prec
        try:
            roots = []
            ok_iso = True
            for z, m in B1.complex_roots():
                if not z.imag.is_zero():
                    return False  # B not real-rooted
                roots.append(z.real)
            for b in roots:
                va = A1(b)
                vb = dB(b)
                sa = 1 if va > 0 else (-1 if va < 0 else 0)
                sb = 1 if vb > 0 else (-1 if vb < 0 else 0)
                if sa == 0 or sb == 0:
                    ok_iso = False
                    break
                if sa != sb:
                    return False
            if ok_iso:
                return True
        finally:
            ctx.prec = old
        prec *= 2
        if prec > 1 << 15:
            raise RuntimeError("interlacing test: precision exhausted")


class PairSpace:
    def __init__(self, sp, nonzero_at=None, prec=512):
        self.sp = sp
        self.n = sp.n
        self.prec = prec
        sim = fmpz_poly([1])
        mult = []
        for q, e in sp.facs:
            if e == 1:
                sim *= q
            else:
                mult.append((q, e))
        self.sim = sim
        self.s = sim.degree()
        M, r = divmod(sp.minp, sim)
        assert r == 0
        self.M = M
        mu2 = fmpz_poly([1])
        for q, e in mult:
            mu2 *= q ** (e - 2)
        self.mu2 = mu2
        self.delta = sp.delta
        self.D = self.delta - 2 - self.s
        self.simple_roots = []   # arb roots of Sim
        self.multiple_roots = []  # (arb root, factor)
        for q, e in sp.facs:
            for lam in _real_roots(q, prec):
                if e == 1:
                    self.simple_roots.append(lam)
                else:
                    self.multiple_roots.append((lam, q))
        self.nonzero_at = list(nonzero_at or [])
        x = fmpz_poly([0, 1])
        self.x = x
        self.minc = coeffs_desc(sp.minp)  # m_0 .. m_delta

    def t_from_psi(self, psi):
        """t_0..t_{delta-1} from the coefficients of psi (descending, padded to delta)."""
        d = self.delta
        c = coeffs_desc(psi) if psi != 0 else [0]
        c = [0] * (d - len(c)) + c  # c_0..c_{d-1}
        m = self.minc
        t = []
        for rr in range(d):
            v = c[rr] - sum(m[a] * t[rr - a] for a in range(1, rr + 1))
            t.append(v)
        return t

    def parity_ok(self, t):
        if t[0] != 0 or abs(t[1]) != 1:
            return False
        for k in range(2, len(t)):
            want = (k % 2) if self.n % 2 == 0 else 1
            if t[k] % 2 != want:
                return False
        return True

    def _pis(self, f, g):
        """All pi in Z[x], deg < s, with Sim | f g - pi^2 coming from some sign vector."""
        if self.s == 0:
            return [fmpz_poly([0])]
        fg = f * g
        prec = self.prec
        while True:
            old = ctx.prec
            ctx.prec = prec
            try:
                ds = self.sim.derivative()
                roots, vals = [], []
                certified = True
                for lam, q in self._simple_with_factor():
                    roots.append(lam)
                    if fg % q == 0:
                        vals.append(arb(0))
                        continue
                    v = fg(lam)
                    if v > 0:
                        vals.append(v.sqrt())
                    elif v < 0:
                        raise ValueError("f g negative at a simple eigenvalue")
                    else:
                        certified = False
                        break
                if not certified:
                    prec *= 2
                    continue
                basis = [_poly_arb_coeffs_div_linear(self.sim, lam) for lam in roots]
                dsv = [ds(lam) for lam in roots]
                out = set()
                undecided = False
                live = [k for k, v in enumerate(vals) if not v.is_zero()]
                for signs in product((1, -1), repeat=len(live)):
                    sg = [0] * len(vals)
                    for k, s_ in zip(live, signs):
                        sg[k] = s_
                    coeffs = []
                    ok = True
                    for e_ in range(self.s):
                        tot = arb(0)
                        for k in live:
                            tot += sg[k] * vals[k] * basis[k][e_] / dsv[k]
                        if not tot.contains_integer():
                            ok = False
                            break
                        m = tot.unique_fmpz()
                        if m is None:
                            undecided = True
                            ok = False
                            break
                        coeffs.append(int(m))
                    if ok:
                        pi = fmpz_poly(coeffs)
                        if (fg - pi * pi) % self.sim == 0:
                            out.add(tuple(coeffs))
                if undecided:
                    prec *= 2
                    if prec > 1 << 14:
                        raise RuntimeError("interpolation undecided")
                    continue
                return [fmpz_poly(list(c)) for c in sorted(out)]
            finally:
                ctx.prec = old

    def _simple_with_factor(self):
        out = []
        for q, e in self.sp.facs:
            if e == 1:
                for lam in _real_roots(q, ctx.prec):
                    out.append((lam, q))
        return out

    def _u_intervals(self, f, g, pi, sigma):
        """For each multiple eigenvalue lam: (lam, lo, hi) with u(lam) in [lo, hi], where
        r = sigma x^D + u and |pi(lam) + Sim(lam) r(lam)| <= sqrt(f g(lam))  (J3)."""
        D = self.D
        fg = f * g
        out = []
        for lam, q in self.multiple_roots:
            w = fg(lam)
            if fg % q == 0:
                W = arb(0)
            elif w > 0:
                W = w.sqrt()
            else:
                W = arb(w.abs_upper()).sqrt()
            sv = self.sim(lam)
            pv = pi(lam)
            lo = (-W - pv) / sv
            hi = (W - pv) / sv
            if not (sv > 0):
                lo, hi = hi, lo
            lead = sigma * lam ** D
            out.append((lam, lo - lead, hi - lead))
        return out

    def _r_candidates(self, f, g, pi, sigma):
        """Integer coefficient vectors (r_1..r_D) of r = sigma x^D + r_1 x^{D-1} + ... + r_D
        compatible with (J3) at the multiple eigenvalues and with the parity of t_2..t_{D+1}.

        Coordinates are fixed one at a time.  With r_1..r_k fixed, v = sum_{l>k} r_l x^{D-l}
        has degree D-k-1 and its leading coefficient r_{k+1} is the divided difference
        sum_{lam in T} v(lam) / prod_{mu in T, mu != lam} (lam - mu) for any set T of D-k
        multiple eigenvalues; every T gives an enclosure, and their intersection is used."""
        D = self.D
        old = ctx.prec
        ctx.prec = self.prec
        try:
            iv = self._u_intervals(f, g, pi, sigma)
            lams = [t[0] for t in iv]
            mid = [(t[1] + t[2]) / 2 for t in iv]
            rad = [arb(((t[2] - t[1]) / 2).abs_upper()) for t in iv]
            base = [mid[k] + arb(0, rad[k].abs_upper()) for k in range(len(iv))]
            nm = len(iv)
            subsets = {m: list(combinations(range(nm), m)) for m in range(1, D + 1)}
            weights = {}
            for m, subs in subsets.items():
                for T in subs:
                    ws = []
                    for k in T:
                        den = arb(1)
                        for kk in T:
                            if kk != k:
                                den *= lams[k] - lams[kk]
                        ws.append(1 / den)
                    weights[T] = ws
            out = []

            def rec(k, fixed, vals):
                if k == D:
                    out.append(list(fixed))
                    return
                m = D - k
                lo_b, hi_b = None, None
                for T in subsets[m]:
                    tot = arb(0)
                    for w_, kk in zip(weights[T], T):
                        tot += w_ * vals[kk]
                    lo_i = int(tot.lower().floor().unique_fmpz())
                    hi_i = int(tot.upper().ceil().unique_fmpz())
                    lo_b = lo_i if lo_b is None else max(lo_b, lo_i)
                    hi_b = hi_i if hi_b is None else min(hi_b, hi_i)
                    if lo_b > hi_b:
                        return
                for c in range(lo_b, hi_b + 1):
                    if not self._prefix_parity_ok(pi, sigma, fixed + [c]):
                        continue
                    nv = [vals[kk] - c * lams[kk] ** (m - 1) for kk in range(nm)]
                    rec(k + 1, fixed + [c], nv)

            rec(0, [], base)
            return out
        finally:
            ctx.prec = old

    def _prefix_parity_ok(self, pi, sigma, prefix):
        """Parity of t_2..t_{k+1} once r_1..r_k are fixed (they do not depend on later r_l)."""
        D = self.D
        k = len(prefix)
        rest = [0] * (D - k)
        r = fmpz_poly(list(reversed([sigma] + prefix + rest)))
        psi = pi + self.sim * r
        t = self.t_from_psi(psi)
        upto = min(k + 1, self.delta - 1)
        for kk in range(2, upto + 1):
            want = (kk % 2) if self.n % 2 == 0 else 1
            if t[kk] % 2 != want:
                return False
        return True

    def _cs_ok(self, f, g, psi):
        """(J3) at every multiple eigenvalue (exact for rational ones)."""
        fg = f * g
        for lam, q in self.multiple_roots:
            if q.degree() == 1:
                x0 = -int(q.coeffs()[0])
                if int(psi(x0)) ** 2 > int(fg(x0)):
                    return False
            else:
                R = fg - psi * psi  # need R(lam) >= 0 at roots of q
                if R % q == 0:
                    continue
                prec = self.prec
                while True:
                    old = ctx.prec
                    ctx.prec = prec
                    try:
                        roots = _real_roots(q, prec)
                        decided = True
                        bad = False
                        for lm in roots:
                            v = R(lm)
                            if v < 0:
                                bad = True
                                break
                            if not v > 0:
                                decided = False
                        if bad:
                            return False
                        if decided:
                            break
                    finally:
                        ctx.prec = old
                    prec *= 2
                    if prec > 1 << 14:
                        break  # undecided: keep (safe)
        return True

    def check_P(self, f, g, psi):
        """(J2)-(J6) for a given psi; returns P or None."""
        num = f * g - psi * psi
        P, r = divmod(num, self.sim)
        if r != 0:
            return None
        for v in self.nonzero_at:
            if int(P(v)) == 0:
                return None
        N = self.n - 2
        chi = self.mu2 * P
        c = coeffs_desc(chi)
        if c[1] != 0 or c[2] != -N * (N - 1) // 2:
            return None
        if not seidel_plus_I_condition(shift(chi, -1), N):
            return None
        if not interlaces(P, self.M * f) or not interlaces(P, self.M * g):
            return None
        return P

    def pair_polys(self, f, g, sigma):
        """All (psi, P) for vertices carrying f, g with S_ij = sigma."""
        out = []
        for pi in self._pis(f, g):
            if self.D < 0:
                cands = [pi]
            elif self.D == 0:
                cands = [pi + self.sim * sigma]
            else:
                cands = []
                for rest in self._r_candidates(f, g, pi, sigma):
                    r = fmpz_poly(list(reversed([sigma] + list(rest))))
                    cands.append(pi + self.sim * r)
            for psi in cands:
                c = coeffs_desc(psi) if psi != 0 else [0]
                c = [0] * (self.delta - len(c)) + c
                if len(c) > self.delta or c[0] != 0 or c[1] != sigma:
                    continue
                t = self.t_from_psi(psi)
                if not self.parity_ok(t):
                    continue
                if not self._cs_ok(f, g, psi):
                    continue
                P = self.check_P(f, g, psi)
                if P is not None:
                    out.append((psi, P))
        return out

