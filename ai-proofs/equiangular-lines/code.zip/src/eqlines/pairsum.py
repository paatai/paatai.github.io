"""Aggregated pair counts for a fixed integer configuration n (level 2, symmetric).

For a support U with multiplicities n_g, let M_{f,g,u} be the number of ordered pairs (i, j),
i != j, with g_i = f, g_j = g and psihat_ij = u. Since psihat_ij = psihat_ji,
    (S)  M_{f,g,u} = M_{g,f,u},
    (C)  sum_u M_{f,g,u} = n_f (n_g - [f = g]),
and summing the row-resolvent identities (eqlines.star.ResolventStar) over the n_f vertices of
type f,
    (L)  sum_{g,u} M_{f,g,u} u(x) = n_f (x g_f(x) - Min(x)),
    (Q)  sum_{g,u} M_{f,g,u} u(x) u(y) = n_f B_f(x, y).
M_{f,f,u} is even (each unordered pair is counted twice): write M_{f,f,u} = 2 K_{f,f,u}.
Variables: K_{f,f,u} and M_{f,g,u} for f < g (shared by both orders), all >= 0.
"""

from .star import ResolventStar, eval_points


class PairSum:
    def __init__(self, rs: ResolventStar):
        self.rs = rs

    def build(self, U, n):
        rs = self.rs
        U = sorted(U)
        names, col = [], {}
        for ia, f in enumerate(U):
            for g in U[ia:]:
                for k in range(len(rs.pairs.get((f, g), []))):
                    col[(f, g, k)] = len(names)
                    names.append((f, g, k))
        # coefficient of variable (a, b, k) in the type-f equations: 2 if a == b == f,
        # 1 if f in {a, b} and a != b, else 0
        def mult(f, a, b):
            if a == b:
                return 2 if a == f else 0
            return 1 if f in (a, b) else 0

        rows, rhs = [], []
        for f in U:
            for g in U:
                a, b = min(f, g), max(f, g)
                row = [0] * len(names)
                for k in range(len(rs.pairs.get((a, b), []))):
                    row[col[(a, b, k)]] = 2 if a == b else 1
                rows.append(row)
                rhs.append(n[f] * (n[g] - (1 if f == g else 0)))
        pts = eval_points(rs.dg)
        for f in U:
            for x in pts:
                row = [0] * len(names)
                for (a, b, k), j in col.items():
                    c = mult(f, a, b)
                    if c:
                        row[j] = c * int(rs.pairs[(a, b)][k](x))
                rows.append(row)
                rhs.append(n[f] * int(x * rs.G[f](x) - rs.minp(x)))
            for ia, x in enumerate(pts):
                for y in pts[ia:]:
                    row = [0] * len(names)
                    for (a, b, k), j in col.items():
                        c = mult(f, a, b)
                        if c:
                            u = rs.pairs[(a, b)][k]
                            row[j] = c * int(u(x) * u(y))
                    rows.append(row)
                    rhs.append(n[f] * rs._B(f, x, y))
        return rows, rhs, names
