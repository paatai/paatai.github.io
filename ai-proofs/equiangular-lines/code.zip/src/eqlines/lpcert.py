"""Exact Farkas certificates for interlacing configurations.

Lemma 2.6 of [GS24]: if p = chi_S then there are integers n_f >= 0 (f in Deck(p))
with sum_f n_f * (mu * g_f) = p'.  Dividing by mu: sum_f n_f g_f = h := p'/mu.

Certificate of infeasibility (Corollary 2.8 of [GS24]): a rational vector Y with
    Coeff(g_f) . Y >= 0 for all f in Deck(p)   and   Coeff(h) . Y < 0.
Verification is a finite exact integer/rational computation (`verify_farkas`).

Floating point LP (HiGHS) is only used to *find* a certificate (or a feasible
configuration); every reported certificate is re-verified exactly.
"""

from fractions import Fraction

import numpy as np
from flint import fmpq, fmpq_mat
from scipy.optimize import linprog, milp, LinearConstraint, Bounds

from .rr import coeffs_to_poly


def _dot(c, Y):
    return sum(Fraction(int(a)) * b for a, b in zip(c, Y))


def verify_farkas(D, h_desc, Y):
    """Exact check: all Coeff(g).Y >= 0 and Coeff(h).Y < 0."""
    Y = [Fraction(y) for y in Y]
    for c in D:
        if _dot(c, Y) < 0:
            return False
    return _dot(h_desc, Y) < 0


def verify_feasible(D, h_desc, nvec):
    """Exact check that nvec >= 0 and sum n_f Coeff(g_f) = Coeff(h)."""
    nvec = [Fraction(v) for v in nvec]
    if any(v < 0 for v in nvec):
        return False
    d = len(h_desc)
    for k in range(d):
        if sum(nvec[i] * int(D[i][k]) for i in range(len(D))) != int(h_desc[k]):
            return False
    return True


def integer_certificate(Y):
    """Scale a rational certificate to a primitive integer vector."""
    from math import gcd
    Y = [Fraction(y) for y in Y]
    den = 1
    for y in Y:
        den = den * y.denominator // gcd(den, y.denominator)
    Z = [int(y * den) for y in Y]
    g = 0
    for z in Z:
        g = gcd(g, abs(z))
    if g > 1:
        Z = [z // g for z in Z]
    return Z


def _weights_matrix(sp, D):
    W = np.array([sp.weights_float(coeffs_to_poly(c)) for c in D], dtype=float)
    return W


def _functional_to_coeffs(sp, y):
    """Y_k = sum_j y_j lambda_j^{t-k} / Min'(lambda_j), k = 0..t (floats)."""
    t = sp.delta - 1
    dm = sp.minp.derivative()
    Y = np.zeros(t + 1)
    for j, lam in enumerate(sp.lams):
        lf = float(lam.mid())
        dmv = float(dm(lam).mid())
        for k in range(t + 1):
            Y[k] += y[j] * lf ** (t - k) / dmv
    return Y


def _exact_solve_closest(rows, rhs, Yf):
    """Exact rational solution of rows.Y = rhs closest (scaled l2) to Yf, or None."""
    m = len(rows)
    d = len(Yf)
    A = fmpq_mat(m, d, [fmpq(int(v)) for r in rows for v in r])
    b = fmpq_mat(m, 1, [fmpq(int(v.numerator), int(v.denominator)) if isinstance(v, Fraction)
                        else fmpq(int(v)) for v in rhs])
    aug = fmpq_mat(m, d + 1, [A[i, j] if j < d else b[i, 0] for i in range(m) for j in range(d + 1)])
    R, rank = aug.rref()
    # pivot columns
    piv = []
    r = 0
    for j in range(d + 1):
        if r < rank and R[r, j] != 0:
            piv.append(j)
            r += 1
    if d in piv:
        return None  # inconsistent
    free = [j for j in range(d) if j not in piv]
    scale = np.array([max(abs(v), 1e-300) for v in Yf])
    # Y = Ypart + sum_f z_f e_f - (pivot adjustments)
    # For free variables choose values close to Yf, rationalised; pivots then determined.
    best = None
    for denlim in (10 ** 6, 10 ** 9, 10 ** 12, 10 ** 15):
        Y = [None] * d
        for j in free:
            Y[j] = Fraction(float(Yf[j])).limit_denominator(denlim) if np.isfinite(Yf[j]) else Fraction(0)
        for i, j in enumerate(piv):
            v = Fraction(int(R[i, d].p), int(R[i, d].q))
            for jj in free:
                coef = R[i, jj]
                if coef != 0:
                    v -= Fraction(int(coef.p), int(coef.q)) * Y[jj]
            Y[j] = v
        best = Y
        err = max(abs(float(Y[k]) - Yf[k]) / scale[k] for k in range(d))
        if err < 1e-6:
            break
    _ = scale
    return best


def find_farkas(sp, D, tol=1e-9, W=None):
    """Try to find an exact certificate of infeasibility.  Returns Y (list of
    Fractions, verified) or None if the LP looks feasible / exactification failed."""
    if not D:
        return [Fraction(0)] * (sp.delta - 1) + [Fraction(-1)]  # empty deck: any Y with h.Y<0
    if W is None:
        W = _weights_matrix(sp, D)
    m = np.array(sp.mult_vector(), dtype=float)
    d = sp.delta
    # minimise m.y  s.t.  W y >= 0,  m.y >= -1
    A_ub = np.vstack([-W, -m[None, :]])
    b_ub = np.concatenate([np.zeros(len(D)), [1.0]])
    res = linprog(m, A_ub=A_ub, b_ub=b_ub, bounds=[(None, None)] * d, method="highs")
    if res.status != 0 or res.fun > -0.5:
        return None
    y = res.x
    slack = W @ y
    h = [int(v) for v in reversed(sp.h.coeffs())]
    Yf = _functional_to_coeffs(sp, y)
    for tl in (tol, 1e-7, 1e-11, 1e-5):
        tight = [i for i in range(len(D)) if slack[i] < tl * max(1.0, np.abs(y).max())]
        rows = [D[i] for i in tight] + [h]
        rhs = [0] * len(tight) + [-1]
        Y = _exact_solve_closest(rows, rhs, Yf)
        if Y is not None and verify_farkas(D, h, Y):
            return Y
    return None


def find_farkas_vertex(D, h_desc, max_subsets=2 * 10 ** 6):
    """Exact search for a Farkas certificate without floating point.

    P = {Y : Coeff(g_f).Y >= 0, Coeff(h).Y = -1} is nonempty iff a certificate exists.
    Let M be the deck matrix (rows Coeff(g_f)), r = rank M, and F the non-pivot columns
    of rref(M).  (1) If some kernel vector Y of M has h.Y != 0, it gives a certificate.
    (2) Otherwise h is orthogonal to ker M, so P is nonempty iff its slice Y_F = 0 is
    nonempty; on that slice Y -> MY is injective, so the slice is a pointed polyhedron
    and (if nonempty) has a vertex, cut out by r-1 linearly independent tight rows of M,
    h.Y = -1 and Y_F = 0.  All (r-1)-subsets of rows are tried.  Returns a verified
    certificate, or None, which (if max_subsets was not hit) proves that no
    certificate exists."""
    from itertools import combinations
    d = len(h_desc)
    rows = [[int(v) for v in c] for c in D]
    if not rows:
        Y = [Fraction(0)] * d
        Y[0] = Fraction(-1, int(h_desc[0]))
        return Y
    M = fmpq_mat(len(rows), d, [fmpq(v) for r in rows for v in r])
    R, rk = M.rref()
    piv, r = [], 0
    for j in range(d):
        if r < rk and R[r, j] != 0:
            piv.append(j)
            r += 1
    free = [j for j in range(d) if j not in piv]
    for f in free:
        Y = [Fraction(0)] * d
        Y[f] = Fraction(1)
        for i, j in enumerate(piv):
            c = R[i, f]
            Y[j] = -Fraction(int(c.p), int(c.q))
        hv = _dot(h_desc, Y)
        if hv != 0:
            Y = [y / (-hv) for y in Y]
            assert verify_farkas(D, h_desc, Y)
            return Y
    count = 0
    extra = [[1 if k == f else 0 for k in range(d)] for f in free]
    for sub in combinations(range(len(rows)), rk - 1):
        count += 1
        if count > max_subsets:
            raise RuntimeError("too many subsets")
        mat = [rows[i] for i in sub] + [list(map(int, h_desc))] + extra
        A = fmpq_mat(d, d, [fmpq(v) for row in mat for v in row])
        if A.rank() < d:
            continue
        b = fmpq_mat(d, 1, [fmpq(0)] * (rk - 1) + [fmpq(-1)] + [fmpq(0)] * len(free))
        sol = A.solve(b)
        Y = [Fraction(int(sol[k, 0].p), int(sol[k, 0].q)) for k in range(d)]
        if verify_farkas(D, h_desc, Y):
            return Y
    return None


def verify_farkas_bounded(D, h_desc, Y, ub):
    """Exact check of a certificate for {n >= 0, n_f <= 1 if ub[f], sum n_f g_f = h}:
    Coeff(g_f).Y >= 0 whenever not ub[f], and
    Coeff(h).Y + sum_{ub[f]} max(0, -Coeff(g_f).Y) < 0.
    (If n were feasible: 0 <= sum n_f (g_f.Y + z_f) <= h.Y + sum_ub z_f < 0 with
    z_f = max(0, -g_f.Y).)"""
    Y = [Fraction(y) for y in Y]
    tot = _dot(h_desc, Y)
    for c, u in zip(D, ub):
        v = _dot(c, Y)
        if u:
            if v < 0:
                tot -= v
        elif v < 0:
            return False
    return tot < 0


def find_farkas_bounded(sp, D, ub, tol=1e-9, W=None):
    """Exact certificate for the bounded system (see verify_farkas_bounded) or None."""
    if not D:
        return find_farkas(sp, D)
    if not any(ub):
        return find_farkas(sp, D, W=W)
    if W is None:
        W = _weights_matrix(sp, D)
    m = np.array(sp.mult_vector(), dtype=float)
    d = sp.delta
    nu = [i for i in range(len(D)) if ub[i]]
    nz = len(nu)
    # variables (y, z): minimise m.y + sum z  s.t.  W_f y + z_f >= 0, z >= 0, m.y + sum z >= -1
    A = np.zeros((len(D) + 1, d + nz))
    A[:len(D), :d] = -W
    for col, i in enumerate(nu):
        A[i, d + col] = -1.0
    A[len(D), :d] = -m
    A[len(D), d:] = -1.0
    b = np.concatenate([np.zeros(len(D)), [1.0]])
    cost = np.concatenate([m, np.ones(nz)])
    res = linprog(cost, A_ub=A, b_ub=b, bounds=[(None, None)] * d + [(0, None)] * nz, method="highs")
    if res.status != 0 or res.fun > -0.5:
        return None
    y = res.x[:d]
    slack = W @ y
    h = [int(v) for v in reversed(sp.h.coeffs())]
    Yf = _functional_to_coeffs(sp, y)
    scale = max(1.0, np.abs(y).max())
    for tl in (tol, 1e-7, 1e-11, 1e-5):
        tight = [i for i in range(len(D)) if abs(slack[i]) < tl * scale]
        neg = [i for i in nu if slack[i] <= -tl * scale]
        norm = list(h)
        for i in neg:
            norm = [a - int(c) for a, c in zip(norm, D[i])]
        rows = [D[i] for i in tight] + [norm]
        rhs = [0] * len(tight) + [-1]
        Y = _exact_solve_closest(rows, rhs, Yf)
        if Y is not None and verify_farkas_bounded(D, h, Y, ub):
            return Y
    return None


def find_feasible_bounded(sp, D, ub, W=None):
    """LP feasibility with n_f <= 1 for ub[f]."""
    if not D:
        return "infeasible", None
    if W is None:
        W = _weights_matrix(sp, D)
    m = np.array(sp.mult_vector(), dtype=float)
    bnds = [(0, 1) if u else (0, None) for u in ub]
    res = linprog(np.zeros(len(D)), A_eq=W.T, b_eq=m, bounds=bnds, method="highs")
    if res.status == 0:
        return "feasible", res.x
    if res.status == 2:
        return "infeasible", None
    return "unknown", None


def find_feasible(sp, D, W=None):
    """LP feasibility of sum n_f w_f = mult, n >= 0.  Returns (status, n_float)."""
    if not D:
        return "infeasible", None
    if W is None:
        W = _weights_matrix(sp, D)
    m = np.array(sp.mult_vector(), dtype=float)
    res = linprog(np.zeros(len(D)), A_eq=W.T, b_eq=m, bounds=[(0, None)] * len(D), method="highs")
    if res.status == 0:
        return "feasible", res.x
    if res.status == 2:
        return "infeasible", None
    return "unknown", None


def exact_feasible_point(sp, D, nfloat, tol=1e-7):
    """Turn a float feasible configuration into an exact rational one on its support."""
    h = [int(v) for v in reversed(sp.h.coeffs())]
    supp = [i for i in range(len(D)) if nfloat[i] > tol]
    d = sp.delta
    # Solve sum_{i in supp} n_i D[i] = h exactly (least-norm via rref on transposed system)
    A = fmpq_mat(d, len(supp), [fmpq(int(D[i][k])) for k in range(d) for i in supp])
    b = fmpq_mat(d, 1, [fmpq(v) for v in h])
    try:
        sol = A.solve(b)
        nv = [Fraction(0)] * len(D)
        for idx, i in enumerate(supp):
            v = sol[idx, 0]
            nv[i] = Fraction(int(v.p), int(v.q))
        if verify_feasible(D, h, nv):
            return nv
    except Exception:
        pass
    return None


def find_integer_feasible(sp, D, W=None, time_limit=60):
    """MILP search for an integer configuration (heuristic; a None answer is NOT a proof)."""
    if not D:
        return None
    h = np.array([int(v) for v in reversed(sp.h.coeffs())], dtype=float)
    A = np.array([[float(v) for v in c] for c in D]).T
    # scale rows for conditioning
    s = np.maximum(np.abs(A).max(axis=1), 1.0)
    cons = LinearConstraint(A / s[:, None], h / s, h / s)
    res = milp(np.zeros(len(D)), constraints=[cons], integrality=np.ones(len(D)),
               bounds=Bounds(0, sp.n), options={"time_limit": time_limit})
    if res.status == 0 and res.x is not None:
        nv = [int(round(v)) for v in res.x]
        hh = [int(v) for v in reversed(sp.h.coeffs())]
        if verify_feasible(D, hh, nv):
            return nv
    return None
