"""Level-1 analysis of all candidate characteristic polynomials of a case.

Case "74_19": p = (x+5)^55 (x-15)^6 2^13 psi((x-15)/2)  (74 lines in R^19)
Case "94_20": p = (x+5)^74 (x-19)^7 2^13 psi((x-19)/2)  (94 lines in R^20)
psi ranges over data/psi_deg13_p1m5_p2_13.json.

For every candidate: Deck(p) with filters (D1)-(D4), (D6: g(-5) != 0); each deck
member is flagged with membership of mu*g mod 2^7 in P_{n-1,7}.  Then exact Farkas
certificates are sought (a) on the full deck, (b) on the class-filtered deck.

Usage: python3 run_level1.py [--e=E] CASE [workers] [indices...]
       (--e=E filters by the complete list P_{n-1,E} instead of P_{n-1,7})
Output: data/level1/CASE/<idx>.json  (data/level1_eE/CASE/ for E != 7)
"""

import gzip
import json
import os
import sys
import time
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.deck import SpecPoly, candidate_poly, deck  # noqa: E402
from eqlines.lpcert import find_farkas, find_feasible, integer_certificate  # noqa: E402
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import class_key, coeffs_desc  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CASES = {
    "74_19": dict(kappa=15, m_low=55, m_kappa=6, n=74),
    "94_20": dict(kappa=19, m_low=74, m_kappa=7, n=94),
}
_classes = {}


def load_classes(m, e=7):
    key = (m, e)
    if key not in _classes:
        path = os.path.join(ROOT, "data", f"P_{m}_{e}.json")
        if os.path.exists(path):
            with open(path) as fh:
                js = json.load(fh)
        else:
            with gzip.open(path + ".gz", "rt") as fh:
                js = json.load(fh)
        assert js["complete"] and len(js["classes"]) == js["target"]
        _classes[key] = set(tuple(k) for k, _s in js["classes"])
    return _classes[key]


def out_dir(case, e):
    return os.path.join(ROOT, "data", "level1" if e == 7 else f"level1_e{e}", case)


def analyse(args):
    case, idx, psi, e = args
    cfg = CASES[case]
    out_path = os.path.join(out_dir(case, e), f"{idx}.json")
    if os.path.exists(out_path):
        return idx, "cached"
    t0 = time.time()
    p = candidate_poly(psi, cfg["kappa"], cfg["m_low"], cfg["m_kappa"])
    sp = SpecPoly(p)
    st = {}
    D = deck(sp, nonzero_at=[-5], stats=st)
    t_deck = time.time() - t0
    cls = load_classes(sp.n - 1, e)
    flags = [class_key(sp.mu * coeffs_to_poly(c), e) in cls for c in D]
    DB = [c for c, f in zip(D, flags) if f]
    h = coeffs_desc(sp.h)
    res = {"case": case, "idx": idx, "psi": psi, "class_e": e,
           "factors": [[coeffs_desc(q), m] for q, m in sp.facs],
           "delta": sp.delta, "mult": sp.mult, "h": h,
           "deck": D, "class_ok": flags, "stats": st, "t_deck": t_deck}
    YA = find_farkas(sp, D)
    res["farkas_A"] = integer_certificate(YA) if YA is not None else None
    res["lp_A"] = "infeasible" if YA is not None else find_feasible(sp, D)[0]
    if YA is None:
        YB = find_farkas(sp, DB)
        res["farkas_B"] = integer_certificate(YB) if YB is not None else None
        res["lp_B"] = "infeasible" if YB is not None else find_feasible(sp, DB)[0]
    else:
        res["farkas_B"] = None
        res["lp_B"] = "infeasible(A)"
    res["t_total"] = time.time() - t0
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path + ".tmp", "w") as fh:
        json.dump(res, fh)
    os.replace(out_path + ".tmp", out_path)
    return idx, f"delta={sp.delta} deck={len(D)}/{len(DB)} A={res['lp_A']} B={res['lp_B']} {res['t_total']:.1f}s"


def main():
    e = 7
    argv = []
    for a in sys.argv[1:]:
        if a.startswith("--e="):
            e = int(a[4:])
        else:
            argv.append(a)
    case = argv[0]
    workers = int(argv[1]) if len(argv) > 1 else 7
    with open(os.path.join(ROOT, "data", "psi_deg13_p1m5_p2_13.json")) as fh:
        psis = json.load(fh)
    idxs = [int(a) for a in argv[2:]] or list(range(len(psis)))
    cfg = CASES[case]
    # longest first: sort by number of distinct eigenvalues
    order = sorted(idxs, key=lambda i: -SpecPoly(candidate_poly(psis[i], cfg["kappa"], cfg["m_low"], cfg["m_kappa"])).delta)
    jobs = [(case, i, psis[i], e) for i in order]
    with Pool(workers) as pool:
        for idx, msg in pool.imap_unordered(analyse, jobs):
            print(time.strftime("%H:%M:%S"), case, idx, msg, flush=True)


if __name__ == "__main__":
    main()
