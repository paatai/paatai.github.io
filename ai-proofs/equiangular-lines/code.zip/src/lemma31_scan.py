"""Exact scan: GSY Lemma 3.1 + Cauchy-Schwarz for equiangular lines with angle 1/a.

For n lines in R^d with angle arccos(1/a) spanning R^d, the Seidel matrix S has
smallest eigenvalue -a with multiplicity n - d, and the other d eigenvalues
satisfy  sum lam = a (n - d),  sum lam^2 = n(n-1) - a^2 (n-d).
Lemma 3.1 of [GSY21] (kappa odd, T = sum (lam - kappa)^2, gamma = n mod 2):
for every eta in [theta, d] with eta * 4^{(eta-gamma)/eta} > T one eigenvalue equals kappa.
Hence d+1-theta eigenvalues equal kappa and the remaining r = theta-1 satisfy
  sum (lam - kappa) = s := a(n-d) - d kappa,   sum (lam - kappa)^2 = T,
so Cauchy-Schwarz requires s^2 <= r T  (and s = 0, T = 0 if r = 0).
All comparisons are exact: eta * 4^{(eta-gamma)/eta} > T  <=>  eta^eta 4^{eta-gamma} > T^eta.

Usage: python3 lemma31_scan.py a d [nmin nmax]
"""

import sys


def theta_of(T, d, gamma):
    """Smallest eta >= 1 such that eta^eta * 4^(eta-gamma) > T^eta (monotone in eta)."""
    for eta in range(1, d + 1):
        if eta ** eta * 4 ** (eta - gamma) > T ** eta:
            return eta
    return None


def analyse(a, d, n):
    m = n - d
    S1 = a * m
    S2 = n * (n - 1) - a * a * m
    best = None
    # try every odd kappa near the mean; Lemma 3.1 holds for any odd kappa
    mean = S1 / d
    k0 = int(mean)
    for kappa in range(k0 - 7, k0 + 8):
        if kappa % 2 == 0:
            continue
        T = S2 - 2 * kappa * S1 + d * kappa * kappa
        th = theta_of(T, d, n % 2)
        if th is None:
            r, s = d, S1 - d * kappa
        else:
            r = th - 1
            s = S1 - d * kappa
        excluded = (s * s > r * T) if r > 0 else (s != 0 or T != 0)
        rec = dict(kappa=kappa, T=T, theta=th, r=r, s=s, excluded=excluded)
        if excluded:
            return rec
        if best is None or r < best["r"]:
            best = rec
    return best


def main():
    a, d = int(sys.argv[1]), int(sys.argv[2])
    rel = (a * a - 1) * d / (a * a - d) if d < a * a else None
    nmax = int(sys.argv[4]) if len(sys.argv) > 4 else (int(rel) if rel else 3 * d)
    nmin = int(sys.argv[3]) if len(sys.argv) > 3 else nmax - 30
    print(f"a={a} d={d} relative bound={rel}")
    for n in range(nmax, nmin - 1, -1):
        r = analyse(a, d, n)
        print(n, r)


if __name__ == "__main__":
    main()
