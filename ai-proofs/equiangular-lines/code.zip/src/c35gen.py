"""Exact walk-coordinate search for candidate #35, support U = (0, 1, 5), for 74 lines in R^19
and 94 lines in R^20 (CLAIMS.md, U5/U6).

In both cases the V-components z (scaled by sqrt 10) of the type-0 and type-1 lines are
    n0 vectors of norm 9 (type 0),  three classes of nc vectors of norm 8 (type 1)
in a space V of dimension dimV, with inner products
    type 0 / type 0 : 1 or -3          type 0 / type 1 : +-2
    same class      : 0 or -4          different class : +-2,
the partner counts NEED0 / NEED1 below, zero sums over type 0 and over each class, and the
tight frame  sum z z^T = frame * I_V.
    74 / R^19: dimV = 15, n0 = 24, nc = 16, frame 40;
    94 / R^20: dimV = 16, n0 = 32, nc = 20, frame 48.
The (-4)-graph of a class is 2-regular with even cycles (m_1, ..., m_c), sum m_i = nc.  Its
vectors are 2(e_k - e_{k+1}) along the cycles in R^nc, spanning a space of dimension nc - c,
and V = span(L_a) + F with dim F = dimV - nc + c.  Every other vector is a closed +-1 walk on
each cycle (omega, centred) plus an F-part.  This module handles dim F <= 1 exactly: the
F-part is eps * sqrt(N - W) (eps = +-1, or 0 when W = N), and two vectors are consistent with
inner product a iff a - <omega, omega'> = eps eps' sqrt((N - W)(N' - W')).
"""
import argparse
import json
import time

import numpy as np
from ortools.sat.python import cp_model

from walks35 import gram_D, walk_vectors

CASES = {
    "74_19": dict(dimV=15, n0=24, nc=16, frame=40),
    "94_20": dict(dimV=16, n0=32, nc=20, frame=48),
}


def needs(case):
    c = CASES[case]
    n0, nc = c["n0"], c["nc"]
    # type 0: within type 0 the row sum is (n0 - 1) - 2 * (#minus); it equals 7 resp. 11.
    rs0 = {"74_19": 7, "94_20": 11}[case]
    minus0 = (n0 - 1 - rs0) // 2
    need0 = [(1, True, n0 - 1 - minus0), (-3, True, minus0), (2, False, nc), (-2, False, nc)]
    need1 = [(2, True, n0 // 2), (-2, True, n0 // 2), (-4, False, 2), (0, False, nc - 3),
             (2, False, nc // 2), (-2, False, nc // 2)]
    return need0, need1


def partitions(total):
    out = []

    def rec(rem, maxp, cur):
        if rem == 0:
            out.append(tuple(cur))
            return
        for p in range(min(rem, maxp), 3, -1):
            if p % 2 == 0:
                rec(rem - p, p, cur + [p])

    rec(total, total, [])
    return out


def walk_data(part):
    D, H, Sm, St = walk_vectors(part)
    G = gram_D(part, H, Sm)
    om = D * H.copy()
    off = 0
    for i, mi in enumerate(part):
        om[:, off:off + mi] -= (D // mi) * Sm[:, [i]]
        off += mi
    return D, om, G, St


def build(case, part):
    cfg = CASES[case]
    dimF = cfg["dimV"] - cfg["nc"] + len(part)
    assert dimF in (0, 1), dimF
    D, om, G, St = walk_data(part)
    W = np.diag(G).copy()
    js, eps, Ns = [], [], []
    for N in (9, 8):
        cand = np.nonzero(W == N * D)[0] if dimF == 0 else np.nonzero(W <= N * D)[0]
        for j in cand:
            r = N * D - W[j]
            for e in ([0] if r == 0 else [1, -1]):
                js.append(j)
                eps.append(e)
                Ns.append(N)
    js, eps, Ns = np.array(js, dtype=np.int64), np.array(eps), np.array(Ns)
    Gn = G[np.ix_(js, js)]
    R = Ns * D - W[js]
    RR = np.outer(R, R)
    EE = np.outer(eps, eps)
    t0 = Ns == 9
    rel = {}
    for a in (1, -3, 2, -2, 0, -4):
        X = D * a - Gn
        ok = (X * X == RR) & ((X == 0) | (np.sign(X) == EE))
        np.fill_diagonal(ok, False)
        if a in (1, -3):
            ok &= np.outer(t0, t0)
        elif a in (0, -4):
            ok &= np.outer(~t0, ~t0)
        rel[a] = ok
    return dict(case=case, part=part, dimF=dimF, D=D, js=js, eps=eps, Ns=Ns, t0=t0, rel=rel,
                om=om[js], R=R, St=St[js])


def core(g, need0, need1):
    t0, rel = g["t0"], g["rel"]
    alive = np.ones(len(t0), dtype=bool)
    while True:
        bad = np.zeros_like(alive)
        for mask, need in ((t0, need0), (~t0, need1)):
            for a, to0, k in need:
                cols = alive & (t0 if to0 else ~t0)
                deg = rel[a][:, cols].sum(axis=1)
                bad |= alive & mask & (deg < k)
        if not bad.any():
            return alive
        alive &= ~bad


def solve(case, part, time_limit=1800.0, workers=8, log=print):
    cfg = CASES[case]
    need0, need1 = needs(case)
    g = build(case, part)
    alive = core(g, need0, need1)
    idx = np.nonzero(alive)[0]
    n = len(idx)
    res = dict(case=case, part=list(part), dimF=g["dimF"], nodes=int(len(g["js"])),
               core=int(n), core_type0=int(g["t0"][idx].sum()))
    if (g["t0"][idx].sum() < cfg["n0"]) or ((~g["t0"][idx]).sum() < 2 * cfg["nc"]):
        res["status"] = "INFEASIBLE (core)"
        log(json.dumps(res))
        return res, None
    D = g["D"]
    nc = cfg["nc"]
    t0 = g["t0"][idx]
    rel = {a: g["rel"][a][np.ix_(idx, idx)] for a in g["rel"]}
    om = g["om"][idx]
    R = g["R"][idx]
    m = cp_model.CpModel()
    b = [m.NewBoolVar(f"b{i}") for i in range(n)]
    beta = [m.NewBoolVar(f"c{i}") if not t0[i] else None for i in range(n)]
    gam = [None] * n
    for i in range(n):
        if not t0[i]:
            gam[i] = m.NewBoolVar(f"g{i}")
            m.AddBoolAnd([b[i], beta[i]]).OnlyEnforceIf(gam[i])
            m.AddBoolOr([b[i].Not(), beta[i].Not(), gam[i]])
    m.Add(sum(b[i] for i in range(n) if t0[i]) == cfg["n0"])
    m.Add(sum(b[i] for i in range(n) if not t0[i]) == 2 * nc)
    m.Add(sum(gam[i] for i in range(n) if not t0[i]) == nc)
    anyrel = np.zeros((n, n), dtype=bool)
    for a in rel:
        anyrel |= rel[a]
    same = rel[0] | rel[-4]
    diff = (rel[2] | rel[-2]) & np.outer(~t0, ~t0)
    npairs = 0
    for i in range(n):
        for j in range(i + 1, n):
            if not anyrel[i, j]:
                m.AddBoolOr([b[i].Not(), b[j].Not()])
                npairs += 1
            elif not t0[i] and not t0[j]:
                if same[i, j]:
                    m.Add(beta[i] == beta[j]).OnlyEnforceIf([b[i], b[j]])
                elif diff[i, j]:
                    m.Add(beta[i] != beta[j]).OnlyEnforceIf([b[i], b[j]])
    for i in range(n):
        need = need0 if t0[i] else need1
        for a, to0, k in need:
            cols = [j for j in np.nonzero(rel[a][i])[0] if t0[j] == to0]
            m.Add(sum(b[j] for j in cols) == k).OnlyEnforceIf(b[i])
    Pa = np.zeros((nc, nc))
    Lap = np.zeros((nc, nc))
    off = 0
    for mi in part:
        Pa[off:off + mi, off:off + mi] = np.eye(mi) - 1.0 / mi
        for k in range(mi):
            e = np.zeros(nc)
            e[off + k], e[off + (k + 1) % mi] = 2, -2
            Lap += np.outer(e, e)
        off += mi
    T = D * D * (cfg["frame"] * Pa - Lap)
    Ti = np.rint(T).astype(np.int64)
    assert np.allclose(T, Ti)
    for p in range(nc):
        for q in range(p, nc):
            m.Add(sum(int(om[i, p] * om[i, q]) * b[i] for i in range(n) if om[i, p] * om[i, q] != 0)
                  == int(Ti[p, q]))
    m.Add(sum(int(R[i]) * b[i] for i in range(n)) == cfg["frame"] * g["dimF"] * D)
    for p in range(nc):
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * gam[i] for i in range(n) if not t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if not t0[i]) == 0)
    if g["dimF"] == 1:
        # F-part s_x = eps sqrt(R_x / D) = eps s'_x sqrt(t_x) / D with R_x D = s'^2 t (t squarefree):
        # cross block of the frame and the zero sums of s, split by square class.
        from c35ref import squarefree_split
        eps = g["eps"][idx]
        classes = {}
        for i in range(n):
            if R[i] > 0:
                t, s = squarefree_split(int(R[i]) * D)
                classes.setdefault(t, []).append((i, s * int(eps[i])))
        for t, mem in classes.items():
            for p in range(nc):
                terms = [(c * int(om[i, p]), i) for i, c in mem if om[i, p] != 0]
                if terms:
                    m.Add(sum(cf * b[i] for cf, i in terms) == 0)
            m.Add(sum(c * b[i] for i, c in mem if t0[i]) == 0)
            m.Add(sum(c * gam[i] for i, c in mem if not t0[i]) == 0)
            m.Add(sum(c * b[i] for i, c in mem if not t0[i]) == 0)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_workers = workers
    t = time.time()
    st = solver.Solve(m)
    res.update(exclusion_clauses=npairs, status=solver.StatusName(st), time=round(time.time() - t, 1))
    log(json.dumps(res))
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = [int(idx[i]) for i in range(n) if solver.Value(b[i])]
    return res, sol


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=sorted(CASES))
    ap.add_argument("--parts", nargs="*")
    ap.add_argument("--time", type=float, default=1800)
    ap.add_argument("--out")
    args = ap.parse_args()
    cfg = CASES[args.case]
    if args.parts:
        parts = [tuple(int(x) for x in p.split(",")) for p in args.parts]
    else:
        parts = [p for p in partitions(cfg["nc"]) if cfg["dimV"] - cfg["nc"] + len(p) in (0, 1)]
    out = []
    for p in parts:
        r, sol = solve(args.case, p, time_limit=args.time)
        r["solution"] = sol
        out.append(r)
        if args.out:
            with open(args.out, "w") as fh:
                json.dump(out, fh, indent=1)


if __name__ == "__main__":
    main()
