"""Frame LP for candidate #35, U = (0, 1, 5), class L_a with c = 2 cycles (float screen).

Variables c_x in [0, 1] for the nodes of the coloured core (c35_core).  Constraints:
  sum_{type 0} c_x = 24, sum_{type 1} c_x = 32,
  sum_x c_x z_x z_x^T + 4 * Lap(L_a cycles) = 40 * P,        P = I - J/16 (frame on 1^perp),
  sum_{type 0} c_x z_x = 0,  sum_{type 1} c_x z_x = 0,
where z_x = omega_x + s_x f, f = 1_{C_1}/m_1 - 1_{C_2}/m_2, s_x = eps sqrt(m_1 m_2 (N - W)/16).
"""
import sys

import numpy as np
from scipy.optimize import linprog

from c35_core import build, core


def lp(part):
    g = build(part)
    alive = core(g)
    D = g["D"]
    m1, m2 = part
    f = np.array([1.0 / m1] * m1 + [-1.0 / m2] * m2)
    idx = np.nonzero(alive)[0]
    H = g["H"][g["js"][idx]].astype(float)
    Sm = g["Sm"][g["js"][idx]].astype(float)
    om = H.copy()
    om[:, :m1] -= (Sm[:, 0] / m1)[:, None]
    om[:, m1:] -= (Sm[:, 1] / m2)[:, None]
    W = (om * om).sum(1)
    N = g["Ns"][idx].astype(float)
    r = np.maximum(N - W, 0)
    s = g["eps"][idx] * np.sqrt(m1 * m2 * r / 16.0)
    Z = om + s[:, None] * f[None, :]
    assert np.allclose((Z * Z).sum(1), N)
    n = len(idx)
    t0 = g["t0"][idx]
    rows, rhs = [], []
    rows.append(t0.astype(float)); rhs.append(24)
    rows.append((~t0).astype(float)); rhs.append(32)
    Lap = np.zeros((16, 16))
    for (a, b) in [(k, (k + 1) % m1) for k in range(m1)] + [(m1 + k, m1 + (k + 1) % m2) for k in range(m2)]:
        v = np.zeros(16); v[a] = 2; v[b] = -2
        Lap += np.outer(v, v)
    P = np.eye(16) - np.ones((16, 16)) / 16
    T = 40 * P - Lap
    iu = np.triu_indices(16)
    for (i, j) in zip(*iu):
        rows.append(Z[:, i] * Z[:, j]); rhs.append(T[i, j])
    for k in range(16):
        rows.append(Z[:, k] * t0); rhs.append(0)
        rows.append(Z[:, k] * (~t0)); rhs.append(0)
    A = np.array(rows)
    b = np.array(rhs, dtype=float)
    res = linprog(np.zeros(n), A_eq=A, b_eq=b, bounds=[(0, 1)] * n, method="highs")
    print(part, "core nodes", n, "LP status:", res.status, res.message, flush=True)
    return res


if __name__ == "__main__":
    for p in sys.argv[1:] or ["12,4", "8,8"]:
        lp(tuple(int(x) for x in p.split(",")))
