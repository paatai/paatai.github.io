"""Exact search for candidate #35, U = (0, 1, 5), 74 lines in R^19, class L_a with dim F >= 2.

Notation as in c35gen.  When dim F = k + 1 we fix k reference vectors x_1..x_k of the
configuration whose F-parts are linearly independent (Gram Gamma).  For any other vector x the
inner products c_x = (phi_x . phi_r)_r = (a_{x r} - <omega_x, omega_r>)_r are fixed by its
relations a_{x r} with the references, so
    phi_x = (projection on span(phi_r), determined by c_x) + eps_x beta_x u,
with u a unit vector orthogonal to the references, beta_x^2 = r_x - c_x^T Gamma^{-1} c_x >= 0
and eps_x = +-1 (0 if beta_x = 0).  Two vectors are then consistent with inner product a iff
    a - <omega_x, omega_y> - c_x^T Gamma^{-1} c_y = eps_x eps_y beta_x beta_y,
an exact condition (we square it and compare signs, in integers).

k = 1 here (partitions (8,4,4) and (6,6,4)).  The reference x_1 runs over the orbits of the
cycle rotations (and swaps of equal cycles).  Case A: x_1 is a type-0 vector with r > 0 and
maximal r among type 0.  Case B: every type-0 vector has r = 0 and x_1 is a type-1 vector with
r > 0 (and maximal r among type 1).  Every configuration falls under one of these, up to the
symmetry.
"""
import argparse
import itertools
import json
import time

import numpy as np
from ortools.sat.python import cp_model

from c35gen import CASES, core, needs, walk_data

ALLOWED = {(True, True): (1, -3), (True, False): (2, -2), (False, True): (2, -2),
           (False, False): (0, -4, 2, -2)}


def squarefree_split(B):
    """B = s^2 t with t squarefree; returns (t, s)."""
    s, t, p = 1, B, 2
    while p * p <= t:
        while t % (p * p) == 0:
            t //= p * p
            s *= p
        p += 1
    return t, s


def rotation_orbits(part, St, cand):
    """Orbit representatives (indices into the walk list) of cand under rotations of each cycle
    and permutations of equal-length cycles.  Walks are identified by their step sequences."""
    key = {tuple(s): j for j, s in enumerate(St.tolist())}
    offs = np.cumsum([0] + list(part))
    cycles = [list(range(offs[i], offs[i + 1])) for i in range(len(part))]
    groups = {}
    for i, mi in enumerate(part):
        groups.setdefault(mi, []).append(i)
    perms = []
    for combo in itertools.product(*[list(itertools.permutations(v)) for v in groups.values()]):
        mp = {}
        for orig, new in zip(groups.values(), combo):
            for o, n_ in zip(orig, new):
                mp[o] = n_
        perms.append(mp)
    seen = set()
    reps = []
    candset = set(int(j) for j in cand)
    for j in cand:
        j = int(j)
        if j in seen:
            continue
        reps.append(j)
        s = St[j]
        orbit = set()
        for mp in perms:
            for rots in itertools.product(*[range(m) for m in part]):
                t = [0] * len(s)
                for i in range(len(part)):
                    src = cycles[i]
                    dst = cycles[mp[i]]
                    mi = part[i]
                    for k in range(mi):
                        t[dst[(k + rots[i]) % mi]] = s[src[k]]
                orbit.add(key[tuple(t)])
        seen |= orbit & candset
    return reps


def build_nodes(case, part, ref, ref_N, caseB):
    D, om, G, St = walk_data(part)
    W = np.diag(G).copy()
    R0 = ref_N * D - W[ref]
    assert R0 > 0
    q = int(R0)                     # Gamma = r_0 = R0 / D, Gamma^{-1} = D / R0
    nodes = []                      # (walk j, N, a_ref, Ctil, B, eps)
    for N in (9, 8):
        isT0 = N == 9
        for j in np.nonzero(W <= N * D)[0]:
            Rj = int(N * D - W[j])
            if caseB and isT0 and Rj != 0:
                continue
            if isT0 and not caseB and Rj > R0:
                continue
            if (not isT0) and caseB and Rj > R0:
                continue
            for a in ALLOWED[(isT0, ref_N == 9)]:
                Ct = int(D * a - G[j, ref])           # D * c_x
                # beta^2 * D^2 q / D... B = D q R_j - Ct * (D) * Ct ; Qtil = D, q = R0
                B = D * q * Rj - D * Ct * Ct
                if B < 0:
                    continue
                for e in ([0] if B == 0 else [1, -1]):
                    nodes.append((int(j), N, a, Ct, B, e))
    # the reference itself: c = r_0, i.e. Ct = R0 (D * r_0), B = 0
    nodes.append((int(ref), ref_N, None, int(R0), 0, 0))
    js = np.array([x[0] for x in nodes], dtype=np.int64)
    Ns = np.array([x[1] for x in nodes])
    Ct = np.array([x[3] for x in nodes], dtype=np.int64)
    B = np.array([x[4] for x in nodes], dtype=np.int64)
    eps = np.array([x[5] for x in nodes], dtype=np.int64)
    isref = np.zeros(len(nodes), dtype=bool)
    isref[-1] = True
    t0 = Ns == 9
    Gn = G[np.ix_(js, js)]
    # Y = D^2 q a - D q G_ij - Qtil * Ct_i Ct_j   with Qtil = D, q = R0
    CC = np.outer(Ct, Ct)
    BB = np.outer(B, B)
    EE = np.outer(eps, eps)
    rel = {}
    for a in (1, -3, 2, -2, 0, -4):
        Y = D * D * q * a - D * q * Gn - D * CC
        ok = (Y * Y == BB) & ((Y == 0) | (np.sign(Y) == EE))
        np.fill_diagonal(ok, False)
        if a in (1, -3):
            ok &= np.outer(t0, t0)
        elif a in (0, -4):
            ok &= np.outer(~t0, ~t0)
        rel[a] = ok
    # F-frame and sums (rational parts):  alpha_x = c_x / sqrt(r_0) -> alpha^2 = Ct^2 / (D R0)
    return dict(case=case, part=part, D=D, js=js, Ns=Ns, t0=t0, rel=rel, om=om[js], Ct=Ct, B=B,
                eps=eps, isref=isref, R0=int(R0), q=q, Wj=W[js], N_D=Ns * D)


def solve_ref(case, part, ref, ref_N, caseB, time_limit=600.0, workers=8):
    cfg = CASES[case]
    need0, need1 = needs(case)
    g = build_nodes(case, part, ref, ref_N, caseB)
    alive = core(g, need0, need1)
    res = dict(case=case, part=list(part), ref=int(ref), ref_N=ref_N, caseB=caseB,
               nodes=int(len(g["js"])), core=int(alive.sum()))
    if not alive[g["isref"]].all() or (alive & g["t0"]).sum() < cfg["n0"] \
            or (alive & ~g["t0"]).sum() < 2 * cfg["nc"]:
        res["status"] = "INFEASIBLE (core)"
        return res, None
    idx = np.nonzero(alive)[0]
    n = len(idx)
    D, nc = g["D"], cfg["nc"]
    t0 = g["t0"][idx]
    rel = {a: g["rel"][a][np.ix_(idx, idx)] for a in g["rel"]}
    om = g["om"][idx]
    Ct = g["Ct"][idx]
    B = g["B"][idx]
    isref = g["isref"][idx]
    m = cp_model.CpModel()
    b = [m.NewBoolVar(f"b{i}") for i in range(n)]
    for i in np.nonzero(isref)[0]:
        m.Add(b[i] == 1)
    beta = [m.NewBoolVar(f"c{i}") if not t0[i] else None for i in range(n)]
    gam = [None] * n
    for i in range(n):
        if not t0[i]:
            gam[i] = m.NewBoolVar(f"g{i}")
            m.AddBoolAnd([b[i], beta[i]]).OnlyEnforceIf(gam[i])
            m.AddBoolOr([b[i].Not(), beta[i].Not(), gam[i]])
    m.Add(sum(b[i] for i in range(n) if t0[i]) == cfg["n0"])
    m.Add(sum(b[i] for i in range(n) if not t0[i]) == 2 * nc)
    m.Add(sum(gam[i] for i in range(n) if not t0[i]) == nc)
    anyrel = np.zeros((n, n), dtype=bool)
    for a in rel:
        anyrel |= rel[a]
    same = rel[0] | rel[-4]
    diff = (rel[2] | rel[-2]) & np.outer(~t0, ~t0)
    for i in range(n):
        nz = np.nonzero(~anyrel[i, i + 1:])[0] + i + 1
        for j in nz:
            m.AddBoolOr([b[i].Not(), b[int(j)].Not()])
        if not t0[i]:
            for j in np.nonzero(same[i, i + 1:])[0] + i + 1:
                if not t0[j]:
                    m.Add(beta[i] == beta[int(j)]).OnlyEnforceIf([b[i], b[int(j)]])
            for j in np.nonzero(diff[i, i + 1:])[0] + i + 1:
                m.Add(beta[i] != beta[int(j)]).OnlyEnforceIf([b[i], b[int(j)]])
    for i in range(n):
        need = need0 if t0[i] else need1
        for a, to0, k in need:
            cols = [int(j) for j in np.nonzero(rel[a][i])[0] if t0[j] == to0]
            m.Add(sum(b[j] for j in cols) == k).OnlyEnforceIf(b[i])
    Pa = np.zeros((nc, nc))
    Lap = np.zeros((nc, nc))
    off = 0
    for mi in part:
        Pa[off:off + mi, off:off + mi] = np.eye(mi) - 1.0 / mi
        for k in range(mi):
            e = np.zeros(nc)
            e[off + k], e[off + (k + 1) % mi] = 2, -2
            Lap += np.outer(e, e)
        off += mi
    Ti = np.rint(D * D * (cfg["frame"] * Pa - Lap)).astype(np.int64)
    for p in range(nc):
        for qq in range(p, nc):
            m.Add(sum(int(om[i, p] * om[i, qq]) * b[i] for i in range(n) if om[i, p] * om[i, qq] != 0)
                  == int(Ti[p, qq]))
    # F-frame in the basis (phi_ref / |phi_ref|, u):  sum alpha^2 = frame, sum beta^2 = frame
    #   alpha^2 = Ct^2 / (D R0),   beta^2 = B / (D^2 R0)
    R0 = g["R0"]
    m.Add(sum(int(Ct[i] * Ct[i]) * b[i] for i in range(n)) == cfg["frame"] * D * R0)
    m.Add(sum(int(B[i]) * b[i] for i in range(n)) == cfg["frame"] * D * D * R0)
    # zero sums: omega and alpha over type 0, over L_b (gam) and over type 1
    for p in range(nc):
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * gam[i] for i in range(n) if not t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if not t0[i]) == 0)
    m.Add(sum(int(Ct[i]) * b[i] for i in range(n) if t0[i]) == 0)
    m.Add(sum(int(Ct[i]) * gam[i] for i in range(n) if not t0[i]) == 0)
    m.Add(sum(int(Ct[i]) * b[i] for i in range(n) if not t0[i]) == 0)
    # cross blocks of the frame: sum alpha omega = 0 (rational); terms with beta = sqrt(B)/(D sqrt R0)
    # are split by the square class of B:  beta_x = s_x sqrt(t) / (D sqrt R0), B = s_x^2 t.
    for p in range(nc):
        m.Add(sum(int(Ct[i] * om[i, p]) * b[i] for i in range(n) if Ct[i] * om[i, p] != 0) == 0)
    eps = g["eps"][idx]
    classes = {}
    for i in range(n):
        if B[i] > 0:
            t, s = squarefree_split(int(B[i]))
            classes.setdefault(t, []).append((i, s * int(eps[i])))
    for t, mem in classes.items():
        m.Add(sum(int(Ct[i]) * c * b[i] for i, c in mem) == 0)
        for p in range(nc):
            terms = [(c * int(om[i, p]), i) for i, c in mem if om[i, p] != 0]
            if terms:
                m.Add(sum(cf * b[i] for cf, i in terms) == 0)
        m.Add(sum(c * b[i] for i, c in mem if t0[i]) == 0)
        m.Add(sum(c * gam[i] for i, c in mem if not t0[i]) == 0)
        m.Add(sum(c * b[i] for i, c in mem if not t0[i]) == 0)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_workers = workers
    t = time.time()
    st = solver.Solve(m)
    res.update(status=solver.StatusName(st), time=round(time.time() - t, 1))
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = [int(idx[i]) for i in range(n) if solver.Value(b[i])]
    return res, sol


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("part")
    ap.add_argument("--case", default="74_19")
    ap.add_argument("--time", type=float, default=600)
    ap.add_argument("--out")
    args = ap.parse_args()
    part = tuple(int(x) for x in args.part.split(","))
    D, om, G, St = walk_data(part)
    W = np.diag(G)
    out = []
    for caseB in (False, True):
        ref_N = 8 if caseB else 9
        cand = np.nonzero((W < ref_N * D))[0]
        reps = rotation_orbits(part, St, cand)
        print(f"{part} case {'B' if caseB else 'A'}: {len(cand)} reference walks, {len(reps)} orbits",
              flush=True)
        for ref in reps:
            r, sol = solve_ref(args.case, part, int(ref), ref_N, caseB, time_limit=args.time)
            r["solution"] = sol
            print(json.dumps({k: v for k, v in r.items() if k != "solution"}), flush=True)
            out.append(r)
            if args.out:
                with open(args.out, "w") as fh:
                    json.dump(out, fh)


if __name__ == "__main__":
    main()
