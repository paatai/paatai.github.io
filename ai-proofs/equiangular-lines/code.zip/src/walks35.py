"""Walk coordinates for candidate #35, support U = (0, 1, 5), 74 lines in R^19.

Setting (see CLAIMS.md, U5): the V_15-components z (scaled by sqrt 10) of the 72 lines of types
0 and 1 are 24 vectors of norm 9 (type 0) and three classes L_a, L_b, L_c of 16 vectors of norm 8
(type 1), with inner products
    type 0 / type 0 : 1 or -3          type 0 / type 1 : +-2
    same class      : 0 or -4          different class : +-2.
Within a class the (-4)-graph is a disjoint union of cycles and the vectors of a cycle are
2(e_k - e_{k+1}) in suitable orthonormal coordinates, so V_15 = 1^perp in R^16.  A vector outside
L_a has v_k - v_{k+1} = +-1 along every cycle edge: on each cycle C_i it is a closed +-1 walk
(centred: omega) plus a constant mu_i, with sum_i m_i mu_i = 0.

This module enumerates the walk vectors for a cycle partition (m_1, ..., m_c) of 16 and computes
D * <omega, omega'> as integers, D = lcm(m_i).
"""
import itertools
from math import lcm

import numpy as np


def step_sequences(m):
    out = []
    for ups in itertools.combinations(range(m), m // 2):
        s = [-1] * m
        for u in ups:
            s[u] = 1
        out.append(s)
    return out


def walk(s):
    w = [0]
    for x in s[:-1]:
        w.append(w[-1] + x)
    return w


def walk_vectors(part):
    """All tuples of closed walks, one per cycle.  Returns (D, Wint, Sums, steps) where
    Wint[j] is the integer vector of heights (concatenated over cycles), Sums[j][i] the height
    sum on cycle i, so that D<omega_j, omega_l> = D * Wint_j . Wint_l - sum_i (D/m_i) Sums_ji Sums_li."""
    D = lcm(*part)
    per = [[(s, walk(s)) for s in step_sequences(m)] for m in part]
    H, Sm, St = [], [], []
    for combo in itertools.product(*per):
        h = []
        sm = []
        st = []
        for s, w in combo:
            h.extend(w)
            sm.append(sum(w))
            st.extend(s)
        H.append(h)
        Sm.append(sm)
        St.append(st)
    return D, np.array(H, dtype=np.int64), np.array(Sm, dtype=np.int64), np.array(St, dtype=np.int64)


def gram_D(part, H, Sm, H2=None, Sm2=None):
    """D * <omega_j, omega_l> for all j (rows of H) and l (rows of H2)."""
    D = lcm(*part)
    if H2 is None:
        H2, Sm2 = H, Sm
    G = D * (H @ H2.T)
    for i, m in enumerate(part):
        G -= (D // m) * np.outer(Sm[:, i], Sm2[:, i])
    return G


def partitions16():
    out = []

    def rec(rem, maxp, cur):
        if rem == 0:
            out.append(tuple(cur))
            return
        for p in range(min(rem, maxp), 3, -1):
            if p % 2 == 0:
                rec(rem - p, p, cur + [p])

    rec(16, 16, [])
    return out


if __name__ == "__main__":
    for part in partitions16():
        D, H, Sm, St = walk_vectors(part)
        G = gram_D(part, H, Sm)
        W = np.diag(G)
        print(part, "D =", D, "walk vectors:", len(H), "min W:", W.min() / D,
              "#W<=9D:", int((W <= 9 * D).sum()), "#W<=8D:", int((W <= 8 * D).sum()))
