"""Coloured-core pruning for candidate #35, U = (0, 1, 5), when the class L_a has c = 2 cycles.

With c = 2 the F-part of a vector is one number, so vectors (omega, eps), (omega', eps') of norms
N, N' are consistent with inner product a iff
    a - <omega, omega'> = eps eps' sqrt((N - W)(N' - W')),     W = |omega|^2,
where eps = +-1 is the sign of the F-part (eps = 0 when N = W).

Nodes: type 0 (N = 9) and type 1 of the classes L_b, L_c (N = 8).  Necessary counts in a
configuration (CLAIMS.md, U5):
  type 0 : 15 type-0 partners at 1, 8 at -3; 16 type-1 partners at 2, 16 at -2;
  type 1 : 12 type-0 partners at 2, 12 at -2; type-1 partners: 2 at -4, 13 at 0, 8 at 2, 8 at -2.
"""
import sys

import numpy as np

from walks35 import gram_D, walk_vectors


def build(part):
    D, H, Sm, St = walk_vectors(part)
    G = gram_D(part, H, Sm)
    W = np.diag(G).copy()
    js, eps, Ns = [], [], []
    for N in (9, 8):
        for j in np.nonzero(W <= N * D)[0]:
            r = N * D - W[j]
            for e in ([0] if r == 0 else [1, -1]):
                js.append(j)
                eps.append(e)
                Ns.append(N)
    js, eps, Ns = np.array(js), np.array(eps), np.array(Ns)
    Gn = G[np.ix_(js, js)]
    R = Ns * D - W[js]
    RR = np.outer(R, R)
    EE = np.outer(eps, eps)
    t0 = Ns == 9
    rel = {}
    for a in (1, -3, 2, -2, 0, -4):
        X = D * a - Gn
        ok = (X * X == RR) & ((X == 0) | (np.sign(X) == EE))
        np.fill_diagonal(ok, False)
        if a in (1, -3):
            ok &= np.outer(t0, t0)
        elif a in (0, -4):
            ok &= np.outer(~t0, ~t0)
        rel[a] = ok
    return dict(D=D, js=js, eps=eps, Ns=Ns, t0=t0, rel=rel, H=H, Sm=Sm, St=St, G=G)


NEED0 = [(1, True, 15), (-3, True, 8), (2, False, 16), (-2, False, 16)]
NEED1 = [(2, True, 12), (-2, True, 12), (-4, False, 2), (0, False, 13), (2, False, 8), (-2, False, 8)]


def core(g, alive=None):
    t0, rel = g["t0"], g["rel"]
    if alive is None:
        alive = np.ones(len(t0), dtype=bool)
    alive = alive.copy()
    while True:
        bad = np.zeros_like(alive)
        for mask, need in ((t0, NEED0), (~t0, NEED1)):
            for a, to0, k in need:
                cols = alive & (t0 if to0 else ~t0)
                deg = rel[a][:, cols].sum(axis=1)
                bad |= alive & mask & (deg < k)
        if not bad.any():
            return alive
        alive &= ~bad


def main():
    parts = [tuple(int(x) for x in p.split(",")) for p in sys.argv[1:]] or [(12, 4), (10, 6), (8, 8)]
    for part in parts:
        g = build(part)
        alive = core(g)
        print(part, "nodes", len(g["js"]), "type0", int(g["t0"].sum()),
              "core:", int((alive & g["t0"]).sum()), "type 0,", int((alive & ~g["t0"]).sum()), "type 1",
              flush=True)


if __name__ == "__main__":
    main()
