"""Leaf-level scheduler for both programs on the leaves of 59 lines in R^18.

Replaces the shard-sequential drivers src/pipe59b.sh, src/helper59.sh and verify/p2_pipe59.sh:
the same commands on the same files, one leaf per job, so that no shard waits for a large leaf.
  P1-L1   src/run_level1_59.py (one leaf)       -> data/level1_59/s<S>/<idx>.json
  P1-L2   src/level2_59.py (one leaf)           -> data/level2_59/s<S>/<idx>.json
  P2-L1   verify/p2_export_leaf.py, verify/deck59.gp, verify/p2_compare_l1.py
                                                -> runs/p2_59/l1/s<S>/<idx>.{txt,cmp}
  P2-CMP  verify/p2_compare_l1.py alone (.cmp missing or older than .txt)
  P2-L23  src/cert59.py, verify/json2gp.py, verify/lv23_59.gp
                                                -> runs/p2_59/l23/s<S>/<idx>.txt
Level 3 stays with src/pipe59c.sh.  A job is started under the conditions of the old drivers
(output missing, or an input newer than the output); a failed job is not retried until one of
its inputs changes.  Within each program the largest expected cost goes first, except that
program 2's short jobs (P2-CMP, P2-L23) go before its decks.
Control files, re-read every pass:
  runs/sched59_p1, runs/sched59_p2   numbers of parallel jobs (default 3 and 2);
  runs/sched59_stop                  start nothing new; exit when the running jobs are done;
  runs/sched59_hold                  lines "KIND SHARD [IDX] [while PID] [kill PID,PID,...]":
                                     do not start these jobs (while PID lives); once the output
                                     of KIND SHARD IDX exists, send SIGTERM to the listed PIDs.
Usage: python3 src/sched59.py [--dry-run]
Log: logs/sched59.log (jobs' own output: logs/sched59_jobs.out).  One instance at a time
(runs/sched59.pid); a new instance adopts the running jobs listed in runs/sched59_running.json.
"""

import json
import os
import signal
import subprocess
import sys
import time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(ROOT, "src"))
from eqlines.deck import SpecPoly  # noqa: E402
from level2_59 import level1_open  # noqa: E402
from run_level1_59 import chi59, load_psis  # noqa: E402

N = 16
LOG = os.path.join(ROOT, "logs", "sched59.log")
NICE = {"P1": 10, "P2": 10}
EST_P1_L1 = {7: 2, 8: 8, 9: 60, 10: 300, 11: 1500}
EST_P2_L1 = {7: 1, 8: 8, 9: 70, 10: 500, 11: 3000}
POLL = 4


def path(*a):
    return os.path.join(ROOT, *a)


def log(msg):
    with open(LOG, "a") as fh:
        fh.write(time.strftime("%H:%M:%S", time.gmtime()) + " " + msg + "\n")


def mtime(p):
    try:
        return os.stat(p).st_mtime_ns
    except OSError:
        return None


def newer(a, b):
    ma, mb = mtime(a), mtime(b)
    return ma is not None and mb is not None and ma > mb


def done_(p):
    try:
        with open(p, "rb") as fh:
            fh.seek(0, 2)
            n = fh.tell()
            fh.seek(max(0, n - 256))
            tail = fh.read().decode(errors="replace")
    except OSError:
        return False
    return tail.rstrip("\n").split("\n")[-1] == "done"


_cache = {}


def summary(p, kind):
    """The few fields the scheduler needs from a JSON record (cached by mtime and size)."""
    try:
        st = os.stat(p)
    except OSError:
        return None
    key = (st.st_mtime_ns, st.st_size)
    c = _cache.get(p)
    if c is not None and c[0] == key:
        return c[1]
    try:
        with open(p) as fh:
            r = json.load(fh)
    except (OSError, ValueError):
        return None
    if kind == "L1":
        v = {"F": r.get("F1") is not None or r.get("F2") is not None,
             "lp_A": r.get("lp_A"), "lp_B": r.get("lp_B"),
             "open": level1_open(r) if "lp_A" in r else False,
             "D": sum(1 for ok in r.get("class_ok", []) if ok)}
    else:
        v = {"verdict": r.get("verdict")}
    _cache[p] = (key, v)
    return v


def read_int(p, default):
    try:
        with open(p) as fh:
            return int(fh.read().strip())
    except (OSError, ValueError):
        return default


def alive(pid):
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def read_holds():
    out = []
    try:
        with open(path("runs", "sched59_hold")) as fh:
            lines = fh.read().splitlines()
    except OSError:
        return out
    for line in lines:
        w = line.split()
        if len(w) < 2 or w[0].startswith("#"):
            continue
        h = {"kind": w[0], "shard": int(w[1]), "idx": None, "while": None, "kill": []}
        rest = w[2:]
        if rest and rest[0].isdigit():
            h["idx"] = int(rest[0])
            rest = rest[1:]
        while len(rest) >= 2:
            if rest[0] == "while":
                h["while"] = int(rest[1])
            elif rest[0] == "kill":
                h["kill"] = [int(x) for x in rest[1].split(",")]
            rest = rest[2:]
        out.append(h)
    return out


class Leaves:
    def __init__(self):
        self.n, self.delta = [], {}
        for s in range(N):
            psis = load_psis(path("runs", "enum59_gp", f"gp_s{s}of{N}.jsonl"))
            with open(path("runs", "enum59_gp", f"gp_s{s}of{N}.txt")) as fh:
                ntxt = sum(1 for line in fh if line.startswith("["))
            assert ntxt == len(psis), (s, ntxt, len(psis))
            self.n.append(len(psis))
            for i, psi in enumerate(psis):
                self.delta[(s, i)] = SpecPoly(chi59(psi)).delta


def files(s, i):
    return {
        "l1": path("data", "level1_59", f"s{s}", f"{i}.json"),
        "l2": path("data", "level2_59", f"s{s}", f"{i}.json"),
        "l3": path("data", "level3_59", f"s{s}", f"{i}.json"),
        "o1": path("runs", "p2_59", "l1", f"s{s}", f"{i}.txt"),
        "cmp": path("runs", "p2_59", "l1", f"s{s}", f"{i}.cmp"),
        "o23": path("runs", "p2_59", "l23", f"s{s}", f"{i}.txt"),
    }


def command(kind, s, i):
    jl = f"runs/enum59_gp/gp_s{s}of{N}.jsonl"
    leaves = f"runs/enum59_gp/gp_s{s}of{N}.txt"
    o1 = f"runs/p2_59/l1/s{s}/{i}.txt"
    cmp_ = f"runs/p2_59/l1/s{s}/{i}.cmp"
    o23 = f"runs/p2_59/l23/s{s}/{i}.txt"
    compare = (f"python3 verify/p2_compare_l1.py {s} {o1} > {cmp_} 2>&1 || echo \"$(date -u "
               f"+%H:%M:%S) LEVEL-1 MISMATCH s{s} {i}\" >> logs/p2_59/pipe.log")
    if kind == "P1-L1":
        return (f"cd src && python3 run_level1_59.py ../{jl} 1 --out=../data/level1_59/s{s} {i} "
                f">> ../logs/level59/l1_s{s}.log 2>&1")
    if kind == "P1-L2":
        return (f"cd src && python3 level2_59.py ../{jl} --in=../data/level1_59/s{s} "
                f"--out=../data/level2_59/s{s} 1 {i} >> ../logs/level59/l2_s{s}.log 2>&1")
    if kind == "P2-L1":
        cert = f"runs/p2_59/certA_leaf/s{s}_{i}.gp"
        return (f"mkdir -p runs/p2_59/l1/s{s} runs/p2_59/certA_leaf && "
                f"python3 verify/p2_export_leaf.py {s} {i} {cert} && rm -f {o1} && "
                f"{{ IN={leaves} CERT={cert} OUT={o1} FROM={i} TO={i} gp -q -f verify/deck59.gp "
                f"< /dev/null > /dev/null 2>> logs/p2_59/gp_err.log; {compare}; }}")
    if kind == "P2-CMP":
        return compare
    if kind == "P2-L23":
        return (f"mkdir -p runs/p2_59/l23/s{s}/exp && "
                f"{{ python3 src/cert59.py {s} {i} >> logs/p2_59/cert59.log 2>&1 || "
                f"{{ echo \"$(date -u +%H:%M:%S) cert59 FAILED s{s} {i}\" >> logs/p2_59/pipe.log; "
                f"exit 1; }}; }} && "
                f"python3 verify/json2gp.py runs/cert59/s{s}/{i}.json "
                f"runs/p2_59/l23/s{s}/exp/{i}.gp EXP && rm -f {o23} && "
                f"{{ LEAVES={leaves} DECKS={o1} EXPDIR=runs/p2_59/l23/s{s}/exp "
                f"CLASSES=data/P_58_7.gp OUT={o23} IDXS=\"[{i}]\" gp -q -f verify/lv23_59.gp "
                f"< /dev/null > /dev/null 2>> logs/p2_59/gp_err.log; "
                f"echo \"$(date -u +%H:%M:%S) s{s} $(head -1 {o23} | cut -c1-200)\" "
                f">> logs/p2_59/pipe.log; }}")
    raise ValueError(kind)


def fresh_l23(f):
    return (done_(f["o23"]) and not newer(f["l2"], f["o23"]) and not newer(f["l3"], f["o23"])
            and not newer(f["o1"], f["o23"]))


def succeeded(kind, f):
    if kind == "P1-L1":
        return os.path.exists(f["l1"])
    if kind == "P1-L2":
        return os.path.exists(f["l2"])
    cmp_ok = os.path.exists(f["cmp"]) and not newer(f["o1"], f["cmp"])
    if kind == "P2-L1":
        return done_(f["o1"]) and not newer(f["l1"], f["o1"]) and cmp_ok
    if kind == "P2-CMP":
        return cmp_ok
    return fresh_l23(f)


def signature(f):
    return tuple(mtime(f[k]) for k in ("l1", "l2", "l3", "o1"))


def candidates(L, running, failed, notes):
    """Eligible jobs: list of (program, priority, kind, s, i)."""
    busy = {(prog, s, i) for (kind, s, i) in running for prog in (kind[:2],)}
    out = []
    for s in range(N):
        for i in range(L.n[s]):
            f = files(s, i)
            d = L.delta[(s, i)]
            jobs = []
            a = summary(f["l1"], "L1")
            if a is None:
                if not os.path.exists(f["l1"]):
                    jobs.append(("P1", EST_P1_L1.get(d, 0.5), "P1-L1"))
            elif a["F"]:
                notes.add(f"F-LEAF s{s} {i} (no lp fields; needs separate handling)")
            else:
                if a["open"] and not os.path.exists(f["l2"]):
                    jobs.append(("P1", 4e-4 * a["D"] ** 2, "P1-L2"))
                if not done_(f["o1"]) or newer(f["l1"], f["o1"]):
                    jobs.append(("P2", EST_P2_L1.get(d, 0.2), "P2-L1"))
                elif not os.path.exists(f["cmp"]) or newer(f["o1"], f["cmp"]):
                    jobs.append(("P2", 1e9, "P2-CMP"))
                elif a["lp_A"] != "infeasible":
                    if a["lp_B"] == "infeasible":
                        notes.add(f"B-ONLY s{s} {i}")
                    else:
                        b = summary(f["l2"], "L2")
                        if b is not None and (b["verdict"] != "open" or os.path.exists(f["l3"])):
                            if not fresh_l23(f):
                                jobs.append(("P2", 1e8, "P2-L23"))
            for prog, pri, kind in jobs:
                if (prog, s, i) in busy:
                    continue
                if failed.get((kind, s, i)) == signature(f):
                    continue
                out.append((prog, pri, kind, s, i))
    return out


def held(holds, kind, s, i):
    short = kind[3:]
    for h in holds:
        if h["kind"] != short or h["shard"] != s or (h["idx"] is not None and h["idx"] != i):
            continue
        if h["while"] is None or alive(h["while"]):
            return True
    return False


def apply_kills(holds, done_kills):
    for h in holds:
        if not h["kill"] or h["idx"] is None:
            continue
        f = files(h["shard"], h["idx"])
        out = {"L1": f["l1"], "L2": f["l2"]}.get(h["kind"])
        key = (h["kind"], h["shard"], h["idx"])
        if out and os.path.exists(out) and key not in done_kills:
            for pid in h["kill"]:
                try:
                    os.kill(pid, signal.SIGTERM)
                    log(f"killed {pid} (output of {key} exists)")
                except ProcessLookupError:
                    pass
            done_kills.add(key)


STATE = path("runs", "sched59_running.json")


def adopt():
    """Jobs of an earlier instance that still run (pid alive), from runs/sched59_running.json."""
    try:
        with open(STATE) as fh:
            old = json.load(fh)
    except (OSError, ValueError):
        return {}
    out = {}
    for rec in old:
        if alive(rec["pid"]):
            out[(rec["kind"], rec["s"], rec["i"])] = (rec["pid"], rec["t0"])
    return out


def save_state(running):
    recs = [{"kind": k[0], "s": k[1], "i": k[2],
             "pid": p.pid if hasattr(p, "pid") else p, "t0": t0}
            for k, (p, t0) in running.items()]
    with open(STATE + ".tmp", "w") as fh:
        json.dump(recs, fh)
    os.replace(STATE + ".tmp", STATE)


def finished(p):
    if hasattr(p, "poll"):
        return p.poll() is not None, p.returncode
    return not alive(p), None


PIDFILE = path("runs", "sched59.pid")


def other_instance():
    try:
        with open(PIDFILE) as fh:
            pid = int(fh.read().strip())
    except (OSError, ValueError):
        return None
    if pid == os.getpid() or not alive(pid):
        return None
    try:
        with open(f"/proc/{pid}/cmdline", "rb") as fh:
            if b"sched59.py" not in fh.read():
                return None
    except OSError:
        return None
    return pid


def main():
    dry = "--dry-run" in sys.argv
    os.makedirs(os.path.dirname(LOG), exist_ok=True)
    if not dry:
        other = other_instance()
        if other is not None:
            log(f"not started: instance {other} is running")
            return
        with open(PIDFILE, "w") as fh:
            fh.write(f"{os.getpid()}\n")
    joblog = open(path("logs", "sched59_jobs.out"), "a")
    L = Leaves()
    running, failed, notes_seen, done_kills = adopt(), {}, set(), set()
    if not dry:
        log(f"start, pid {os.getpid()}, {sum(L.n)} leaves, adopted {sorted(running)}")
    while True:
        for key, (proc, t0) in list(running.items()):
            fin, rc = finished(proc)
            if not fin:
                continue
            kind, s, i = key
            del running[key]
            f = files(s, i)
            ok = succeeded(kind, f)
            if not ok:
                failed[key] = signature(f)
            log(f"{'done' if ok else 'FAILED'} {kind} s{s} {i} rc={rc} {time.time() - t0:.0f}s")
        holds = read_holds()
        if not dry:
            apply_kills(holds, done_kills)
        stop = os.path.exists(path("runs", "sched59_stop"))
        slots = {"P1": read_int(path("runs", "sched59_p1"), 3),
                 "P2": read_int(path("runs", "sched59_p2"), 2)}
        notes = set()
        cand = candidates(L, running, failed, notes)
        for n in sorted(notes - notes_seen):
            log(n)
        notes_seen |= notes
        cand = [c for c in cand if not held(holds, c[2], c[3], c[4])]
        cand.sort(key=lambda c: -c[1])
        if dry:
            for prog in ("P1", "P2"):
                sub = [c for c in cand if c[0] == prog]
                kinds = {}
                for c in sub:
                    kinds[c[2]] = kinds.get(c[2], 0) + 1
                print(prog, kinds, "first:", [(c[2], c[3], c[4], round(c[1], 1)) for c in sub[:8]])
            print("notes:", sorted(notes))
            return
        if stop and not running:
            log("stop file: exit")
            return
        if not stop:
            for prog in ("P2", "P1"):
                free = slots[prog] - sum(1 for k in running if k[0][:2] == prog)
                started = set()
                for c in cand:
                    if free <= 0:
                        break
                    _, _, kind, s, i = c
                    if c[0] != prog or (s, i) in started:
                        continue
                    proc = subprocess.Popen(
                        ["nice", "-n", str(NICE[prog]), "bash", "-c", command(kind, s, i)],
                        cwd=ROOT, stdin=subprocess.DEVNULL, stdout=joblog,
                        stderr=subprocess.STDOUT, start_new_session=True)
                    running[(kind, s, i)] = (proc, time.time())
                    started.add((s, i))
                    free -= 1
                    log(f"start {kind} s{s} {i} (est {c[1]:.0f})")
        save_state(running)
        time.sleep(POLL)


if __name__ == "__main__":
    main()
