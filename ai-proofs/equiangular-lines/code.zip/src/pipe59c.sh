#!/bin/bash
# Level 3 (level3_59.py) on every level-2 result with verdict "open", as they appear (runs next to
# pipe59b.sh; outputs are cached by file name), until ../runs/pipe59c_stop exists.
cd "$(dirname "$0")"
N=16
mkdir -p ../logs/level59
while [ ! -f ../runs/pipe59c_stop ]; do
  for s in $(seq 0 $((N - 1))); do
    [ -d ../data/level2_59/s$s ] || continue
    python3 level3_59.py --dir=../data/level2_59/s$s --out=../data/level3_59/s$s \
      >> ../logs/level59/l3_s$s.log 2>&1
  done
  sleep 120
done
