"""Exhaustive enumeration of the degree-17 remainder for 59 equiangular lines in R^18.

If 59 lines span R^18 (they must: N(17) = 48 < 59), the angle is arccos(1/5), the eigenvalue -5
of the Seidel matrix S has multiplicity 41, and [GSY21, Lemma 3.1] at kappa = 11 (T = 65,
theta = 18) forces the eigenvalue 11. Write the other 17 eigenvalues as 11 + y_j. Then
psi(y) = prod (y - y_j) is a monic integer polynomial with

    sum y_j = 7, sum y_j^2 = 65   (so c1 = -7, c2 = -8),

all roots real, and

    2^k | c_k for even k,   2^(k-1) | c_k for odd k.                                  (E)

Proof of (E). [GSY21, Thm 2.5] (from [GY19, sec. 3]): for n odd, chi_{S+I} = sum a_i x^(n-i)
has 2^i | a_i for even i and 2^(i-1) | a_i for odd i. Equivalently Q(x) = p(2x)/2^n is A + B/2
with A in Z[x] and B in Z[x] even (only even powers; n is odd). Shifting x -> x + s keeps this
form: the odd-power coefficients of B(x + s) are sums of b_j C(j, k) s^(j-k) with j even, k odd,
and C(j, k) is even. Hence chi_{S - kappa I}(y) = chi_{S+I}(y + kappa + 1) has (E) for every odd
kappa (degree n). At kappa = 11, chi_{S - 11 I}(y) = q(y) psi(y) with q = (y + 16)^41 y. Then
q(2x)/2^42 = (x + 8)^41 x = x^42 mod 2, and 2 psi(2x)/2^17 is in Z[x] ([GSY21, Lemma 2.8]: psi is
weakly type 2). So 2 chi_{S-11I}(2x)/2^59 = x^42 * 2 psi(2x)/2^17 mod 2, and (E) for chi_{S-11I}
(even coefficients of 2Q at odd powers of x) gives: psi(2x)/2^17 has integer coefficients at odd
powers of x, i.e. 2^k | c_k for even k. (Checked on 300 random Seidel matrices of orders 57 and
59 at five odd centres: no violation.)

    python3 src/enum59.py --shard i/N --out FILE

writes one JSON line per real-rooted psi (coefficients c_0..c_17, descending) and a final summary.
Shards split the tree at level --split (default 5) by node order, so their union is the full list.
"""
import argparse
import json
import os
import sys
import time

from flint import fmpz_poly

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines import rr  # noqa: E402
from eqlines.gy312 import check_a  # noqa: E402

T, C1, C2 = 17, -7, -8


def congr(i, _pref):
    return ([0], 2 ** (i if i % 2 == 0 else i - 1))


class ClassFilter:
    """chi_S = (x + 5)^41 (x - 11) psi(x - 11) mod 2^e must lie in P_{59,e} ([GY19]; the list is
    complete when its size reaches the bound 2^(C(e-2,2)+1) of [GY19, Cor. 3.13]). chi_S is linear
    in (c_0, ..., c_17): chi = sum c_i v_i with v_i = (x + 5)^41 (x - 11)^(18 - i), and position j
    of chi (the coefficient of x^(59-j)) involves only c_0..c_j. So after c_k is chosen, positions
    0..k are final mod 2^e; once every later c_i is 0 mod 2^e by (E), the whole class is final."""

    def __init__(self, path):
        from flint import fmpz_poly
        with open(path) as fh:
            d = json.load(fh)
        assert d["n"] == 59 and d["complete"] and len(d["classes"]) == d["target"], path
        self.e = d["e"]
        self.m = 1 << self.e
        keys = [tuple(k) for k, _w in d["classes"]]
        assert all(len(k) == 60 for k in keys)
        self.full = set(keys)
        self.last = max(k for k in range(3, T + 1) if congr(k, None)[1] < self.m)
        self.pref = {k: {key[:k + 1] for key in keys} for k in range(3, self.last)}
        base = fmpz_poly([5, 1]) ** 41
        x11 = fmpz_poly([-11, 1])
        self.v = []
        for i in range(T + 1):
            c = [int(a) for a in reversed((base * x11 ** (T + 1 - i)).coeffs())]
            c = [0] * i + c
            assert len(c) == 60 and c[i] == 1
            self.v.append([a % self.m for a in c])

    def start(self, prefix):
        r = [0] * 60
        for i, ci in enumerate(prefix):
            r = [(a + ci * b) % self.m for a, b in zip(r, self.v[i])]
        return r

    def step(self, r, k, ck):
        """Residues after choosing c_k, or None if no class of P_{59,e} is compatible."""
        if k > self.last:
            return r
        r2 = [(a + ck * b) % self.m for a, b in zip(r, self.v[k])]
        if k < self.last:
            return r2 if tuple(r2[:k + 1]) in self.pref[k] else None
        return r2 if tuple(r2) in self.full else None


class L312Filter:
    """[GY19, Lemma 3.12] (eqlines/gy312.py) on prefixes.  chi_{S+I} = chi_S(x - 1) =
    sum_i c_i w_i with w_i = (x + 4)^41 (x - 12)^(18 - i), so its coefficients a_0..a_j depend
    only on c_0..c_j.  After c_{2k+1} is chosen (2k + 1 <= 17) the congruences at all levels
    <= k are final; check_a also re-checks (R), (L31) and (L38) on a_0..a_{2k+1}."""

    def __init__(self):
        base = fmpz_poly([4, 1]) ** 41
        x12 = fmpz_poly([-12, 1])
        self.w = []
        for i in range(T + 1):
            c = [int(a) for a in reversed((base * x12 ** (T + 1 - i)).coeffs())]
            c = [0] * i + c
            assert len(c) == 60 and c[i] == 1
            self.w.append(c[:T + 1])

    def start(self, prefix):
        a = [0] * (T + 1)
        for i, ci in enumerate(prefix):
            a = [x + ci * y for x, y in zip(a, self.w[i])]
        return a

    def step(self, a, i, ci):
        """Coefficients after choosing c_i, or None if a congruence of level (i - 1)/2 fails."""
        a2 = [x + ci * y for x, y in zip(a, self.w[i])]
        if i % 2 == 1 and i >= 9 and check_a(a2[:i + 1], 59, (i - 1) // 2) is not None:
            return None
        return a2


def children(pref, mu, cf=None, res=None, lf=None, la=None):
    i = len(pref)
    q = rr.factorial(T - i)
    lo = hi = None
    Pmu = [rr._eval_P(pref, T, i, m) for m in mu]
    for k in range(1, i):
        v = -Pmu[k - 1]
        if (i - k) % 2 == 0:
            lo = v if lo is None else lo.max(v)
        else:
            hi = v if hi is None else hi.min(v)
    cmin = rr._ceil_div_low(lo, q)
    cmax = rr._floor_div_up(hi, q)
    if cmin > cmax:
        return []
    resid, mod = congr(i, pref)
    out = []
    for ci in rr._residue_range(cmin, cmax, resid, mod):
        r2 = a2 = None
        if cf is not None:
            r2 = cf.step(res, i, ci)
            if r2 is None:
                continue
        if lf is not None:
            a2 = lf.step(la, i, ci)
            if a2 is None:
                continue
        newc = pref + [ci]
        rts = rr.real_roots_or_none(rr._poly_from_c(newc, T, i))
        if rts is not None:
            out.append((newc, rts, r2, a2))
    return out


def run(shard, nshard, split, out, cf=None, lf=None):
    c = [1, C1, C2]
    D2 = rr._poly_from_c(c, T, 2)
    assert rr.is_real_rooted(D2)
    stats = dict(nodes=0, split_nodes=0, mine=0, leaves=0)
    level_nodes = [0] * (T + 1)
    t0 = time.time()
    stack = [(c, rr.real_roots_sorted(D2), cf.start(c) if cf is not None else None,
              lf.start(c) if lf is not None else None)]
    while stack:
        pref, mu, res, la = stack.pop()
        i = len(pref)
        if i == split + 1:
            stats["split_nodes"] += 1
            if (stats["split_nodes"] - 1) % nshard != shard:
                continue
            stats["mine"] += 1
        for newc, rts, r2, a2 in children(pref, mu, cf, res, lf, la):
            stats["nodes"] += 1
            level_nodes[len(newc) - 1] += 1
            if len(newc) == T + 1:
                assert rr.is_real_rooted(rr.coeffs_to_poly(newc))
                stats["leaves"] += 1
                out.write(json.dumps(dict(psi=newc)) + "\n")
                out.flush()
            else:
                stack.append((newc, rts, r2, a2))
    stats["level_nodes"] = level_nodes
    stats["time"] = round(time.time() - t0, 1)
    return stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--split", type=int, default=5)
    ap.add_argument("--out", required=True)
    ap.add_argument("--classes", help="complete P_{59,e} file (data/P_59_7.json) to filter by")
    ap.add_argument("--l312", action="store_true", help="prefix test of [GY19, Lemma 3.12]")
    args = ap.parse_args()
    shard, nshard = (int(x) for x in args.shard.split("/"))
    cf = ClassFilter(args.classes) if args.classes else None
    lf = L312Filter() if args.l312 else None
    with open(args.out, "w") as out:
        stats = run(shard, nshard, args.split, out, cf, lf)
        out.write(json.dumps(dict(summary=stats, shard=args.shard, split=args.split,
                                  classes=args.classes, l312=args.l312)) + "\n")
    print(json.dumps(stats))


if __name__ == "__main__":
    main()
