"""Size estimates from the systematic samples of src/est/enumgen*.py and src/est/enum58.py.

Every shard i/N generates the whole tree down to the split level s and expands only the split
nodes with index = i mod N (in DFS order), so the estimate is
    nodes = top + (nodes below s in the samples) * split_nodes / (sampled subtrees),
and the same ratio for leaves and time (time also includes the top, so it is a slight
overestimate).  Shards stopped by --tmax ("timeout") sample only the first part of the range;
they are reported separately, with split_nodes taken from a complete shard of the same case.

    python3 src/est/estimate.py runs/est_enum/*.jsonl
"""
import json
import sys
from collections import defaultdict


def summary(path):
    with open(path) as fh:
        last = None
        for line in fh:
            if line.startswith('{"summary"'):
                last = json.loads(line)
    if last is None:
        raise SystemExit(f"{path}: no summary line")
    s = last["summary"]
    if "n" not in s:
        s.update(n=58, d=18, kappa=11)
    s["split"] = last["split"]
    s["nshard"] = int(last["shard"].split("/")[1])
    s["classes"] = last.get("classes", "data/P_58_7.json (default of enum58.py)")
    s["path"] = path
    return s


def main(paths):
    groups = defaultdict(list)
    sums = [summary(p) for p in paths]
    complete = {}
    for s in sums:
        key = (s["n"], s["d"], s["kappa"])
        if not s.get("timeout"):
            top = s["level_nodes"][:s["split"] + 1]
            if key in complete:
                assert complete[key] == (top, s["split_nodes"]), s["path"]
            complete[key] = (top, s["split_nodes"])
        groups[key + (s["nshard"], bool(s.get("timeout")))].append(s)
    for (n, d, kappa, nshard, partial), ss in sorted(groups.items()):
        top, total_split = complete[(n, d, kappa)]
        mine = sum(s["mine"] for s in ss)
        below = sum(sum(s["level_nodes"][s["split"] + 1:]) for s in ss)
        leaves = sum(s["leaves"] for s in ss)
        cpu = sum(s["time"] for s in ss)
        f = total_split / mine
        print(f"n={n} d={d} kappa={kappa}: {len(ss)} shard(s) of 1/{nshard}"
              f"{' stopped by --tmax (first part of the range only)' if partial else ''}")
        print(f"  files: {', '.join(s['path'] for s in ss)}")
        print(f"  sampled: {mine} of {total_split} subtrees, {below:,} nodes below the split, "
              f"{leaves} leaves, {cpu:,.0f} CPU-s")
        print(f"  estimate: {sum(top) + below * f:.3g} nodes, {leaves * f:.3g} leaves, "
              f"{cpu * f / 3600:.3g} CPU-h")


if __name__ == "__main__":
    main(sys.argv[1:])
