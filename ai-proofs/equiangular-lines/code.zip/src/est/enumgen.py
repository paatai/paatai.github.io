"""Scratch size estimate (not a record): the remainder phi for n equiangular lines in R^d, angle 1/5.

chi_S = (x + 5)^(n - d) phi(x - kappa), phi monic of degree d with sum y = 5(n - d) - d kappa,
sum y^2 = T(kappa).  Congruences: type 2 (n even) or weakly type 2 (n odd) for phi.
Filters: chi_S mod 2^e in P_{n,e} (--classes), and for odd n [GY19, Lemma 3.12] on prefixes.
Same DFS as src/enum59.py; --shard i/N keeps every N-th split node.
"""
import argparse
import gzip
import json
import os
import sys
import time

from flint import fmpz_poly

sys.path.insert(0, "/workspace/src")
from eqlines import rr  # noqa: E402
from eqlines.gy312 import check_a  # noqa: E402


def setup(n, d, kappa):
    s1 = 5 * (n - d) - d * kappa
    s2 = n * (n - 1) - 25 * (n - d) - 2 * kappa * 5 * (n - d) + d * kappa * kappa
    assert (s1 * s1 - s2) % 2 == 0
    return s1, s2, -s1, (s1 * s1 - s2) // 2


def congr_fn(n):
    if n % 2 == 0:
        return lambda i, _p: ([0], 2 ** i)
    return lambda i, _p: ([0], 2 ** (i if i % 2 == 0 else i - 1))


class ClassFilter:
    def __init__(self, path, n, d, kappa, congr):
        op = gzip.open if path.endswith(".gz") else open
        with op(path, "rt") as fh:
            dd = json.load(fh)
        assert dd["n"] == n and dd["complete"] and len(dd["classes"]) == dd["target"], path
        self.e = dd["e"]
        self.m = 1 << self.e
        keys = [tuple(k) for k, _w in dd["classes"]]
        assert all(len(k) == n + 1 for k in keys)
        self.full = set(keys)
        self.last = max(k for k in range(3, d + 1) if congr(k, None)[1] < self.m)
        self.pref = {k: {key[:k + 1] for key in keys} for k in range(3, self.last)}
        base = fmpz_poly([5, 1]) ** (n - d)
        xk = fmpz_poly([-kappa, 1])
        self.v = []
        for i in range(d + 1):
            c = [int(a) for a in reversed((base * xk ** (d - i)).coeffs())]
            c = [0] * i + c
            assert len(c) == n + 1 and c[i] == 1
            self.v.append([a % self.m for a in c])
        self.n = n

    def start(self, prefix):
        r = [0] * (self.n + 1)
        for i, ci in enumerate(prefix):
            r = [(a + ci * b) % self.m for a, b in zip(r, self.v[i])]
        return r

    def step(self, r, k, ck):
        if k > self.last:
            return r
        r2 = [(a + ck * b) % self.m for a, b in zip(r, self.v[k])]
        if k < self.last:
            return r2 if tuple(r2[:k + 1]) in self.pref[k] else None
        return r2 if tuple(r2) in self.full else None


class L312Filter:
    def __init__(self, n, d, kappa):
        base = fmpz_poly([4, 1]) ** (n - d)
        xk = fmpz_poly([-(kappa + 1), 1])
        self.w = []
        self.n, self.d = n, d
        for i in range(d + 1):
            c = [int(a) for a in reversed((base * xk ** (d - i)).coeffs())]
            c = [0] * i + c
            assert len(c) == n + 1 and c[i] == 1
            self.w.append(c[:d + 1])

    def start(self, prefix):
        a = [0] * (self.d + 1)
        for i, ci in enumerate(prefix):
            a = [x + ci * y for x, y in zip(a, self.w[i])]
        return a

    def step(self, a, i, ci):
        a2 = [x + ci * y for x, y in zip(a, self.w[i])]
        if i % 2 == 1 and i >= 5 and check_a(a2[:i + 1], self.n, (i - 1) // 2) is not None:
            return None
        return a2


def children(T, congr, pref, mu, cf=None, res=None, lf=None, la=None):
    i = len(pref)
    q = rr.factorial(T - i)
    lo = hi = None
    Pmu = [rr._eval_P(pref, T, i, m) for m in mu]
    for k in range(1, i):
        v = -Pmu[k - 1]
        if (i - k) % 2 == 0:
            lo = v if lo is None else lo.max(v)
        else:
            hi = v if hi is None else hi.min(v)
    cmin = rr._ceil_div_low(lo, q)
    cmax = rr._floor_div_up(hi, q)
    if cmin > cmax:
        return []
    resid, mod = congr(i, pref)
    out = []
    for ci in rr._residue_range(cmin, cmax, resid, mod):
        r2 = a2 = None
        if cf is not None:
            r2 = cf.step(res, i, ci)
            if r2 is None:
                continue
        if lf is not None:
            a2 = lf.step(la, i, ci)
            if a2 is None:
                continue
        newc = pref + [ci]
        rts = rr.real_roots_or_none(rr._poly_from_c(newc, T, i))
        if rts is not None:
            out.append((newc, rts, r2, a2))
    return out


def run(T, C1, C2, congr, shard, nshard, split, out, cf=None, lf=None, tmax=None):
    c = [1, C1, C2]
    D2 = rr._poly_from_c(c, T, 2)
    assert rr.is_real_rooted(D2)
    stats = dict(nodes=0, split_nodes=0, mine=0, leaves=0, leaves_k=0)
    level_nodes = [0] * (T + 1)
    t0 = time.time()
    stack = [(c, rr.real_roots_sorted(D2), cf.start(c) if cf else None, lf.start(c) if lf else None)]
    while stack:
        if tmax is not None and time.time() - t0 > tmax:
            stats["timeout"] = True
            break
        pref, mu, res, la = stack.pop()
        i = len(pref)
        if i == split + 1:
            stats["split_nodes"] += 1
            if (stats["split_nodes"] - 1) % nshard != shard:
                continue
            stats["mine"] += 1
        for newc, rts, r2, a2 in children(T, congr, pref, mu, cf, res, lf, la):
            stats["nodes"] += 1
            level_nodes[len(newc) - 1] += 1
            if len(newc) == T + 1:
                stats["leaves"] += 1
                if newc[-1] == 0:
                    stats["leaves_k"] += 1
                out.write(json.dumps(dict(phi=newc)) + "\n")
                out.flush()
            else:
                stack.append((newc, rts, r2, a2))
    stats["level_nodes"] = level_nodes
    stats["time"] = round(time.time() - t0, 1)
    return stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--n", type=int, required=True)
    ap.add_argument("--d", type=int, required=True)
    ap.add_argument("--kappa", type=int, required=True)
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--split", type=int, default=5)
    ap.add_argument("--out", required=True)
    ap.add_argument("--classes", default=None)
    ap.add_argument("--no-l312", action="store_true")
    ap.add_argument("--tmax", type=float, default=None)
    args = ap.parse_args()
    n, d, kappa = args.n, args.d, args.kappa
    s1, s2, C1, C2 = setup(n, d, kappa)
    congr = congr_fn(n)
    assert C1 % congr(1, None)[1] == 0 and C2 % congr(2, None)[1] == 0, (C1, C2)
    shard, nshard = (int(x) for x in args.shard.split("/"))
    cf = ClassFilter(args.classes, n, d, kappa, congr) if args.classes else None
    lf = L312Filter(n, d, kappa) if (n % 2 == 1 and not args.no_l312) else None
    with open(args.out, "w") as out:
        stats = run(d, C1, C2, congr, shard, nshard, args.split, out, cf, lf, args.tmax)
        stats.update(n=n, d=d, kappa=kappa, s1=s1, s2=s2, C1=C1, C2=C2)
        out.write(json.dumps(dict(summary=stats, shard=args.shard, split=args.split,
                                  classes=args.classes)) + "\n")
    print(json.dumps(stats))


if __name__ == "__main__":
    main()
