"""Scratch size estimate (not a record): real-rooted type-2 phi for 58 lines in R^18.

chi_S = (x + 5)^40 phi(x - 11), phi(y) = sum c_i y^(18 - i) monic of degree 18,
sum y = 2, sum y^2 = 84 (c1 = -2, c2 = -40), 2^k | c_k for all k (n even), and
chi_S mod 2^7 in P_{58,7}.  Same DFS as src/enum59.py; --shard i/N keeps every N-th split node.
"""
import argparse
import json
import os
import sys
import time

from flint import fmpz_poly

sys.path.insert(0, "/workspace/src")
from eqlines import rr  # noqa: E402

T, C1, C2 = 18, -2, -40
N_LINES = 58


def congr(i, _pref):
    return ([0], 2 ** i)


class ClassFilter:
    def __init__(self, path):
        with open(path) as fh:
            d = json.load(fh)
        assert d["n"] == N_LINES and d["complete"] and len(d["classes"]) == d["target"], path
        self.e = d["e"]
        self.m = 1 << self.e
        keys = [tuple(k) for k, _w in d["classes"]]
        assert all(len(k) == N_LINES + 1 for k in keys)
        self.full = set(keys)
        self.last = max(k for k in range(3, T + 1) if congr(k, None)[1] < self.m)
        self.pref = {k: {key[:k + 1] for key in keys} for k in range(3, self.last)}
        base = fmpz_poly([5, 1]) ** (N_LINES - 18)
        x11 = fmpz_poly([-11, 1])
        self.v = []
        for i in range(T + 1):
            c = [int(a) for a in reversed((base * x11 ** (T - i)).coeffs())]
            c = [0] * i + c
            assert len(c) == N_LINES + 1 and c[i] == 1
            self.v.append([a % self.m for a in c])

    def start(self, prefix):
        r = [0] * (N_LINES + 1)
        for i, ci in enumerate(prefix):
            r = [(a + ci * b) % self.m for a, b in zip(r, self.v[i])]
        return r

    def step(self, r, k, ck):
        if k > self.last:
            return r
        r2 = [(a + ck * b) % self.m for a, b in zip(r, self.v[k])]
        if k < self.last:
            return r2 if tuple(r2[:k + 1]) in self.pref[k] else None
        return r2 if tuple(r2) in self.full else None


def children(pref, mu, cf=None, res=None):
    i = len(pref)
    q = rr.factorial(T - i)
    lo = hi = None
    Pmu = [rr._eval_P(pref, T, i, m) for m in mu]
    for k in range(1, i):
        v = -Pmu[k - 1]
        if (i - k) % 2 == 0:
            lo = v if lo is None else lo.max(v)
        else:
            hi = v if hi is None else hi.min(v)
    cmin = rr._ceil_div_low(lo, q)
    cmax = rr._floor_div_up(hi, q)
    if cmin > cmax:
        return []
    resid, mod = congr(i, pref)
    out = []
    for ci in rr._residue_range(cmin, cmax, resid, mod):
        r2 = None
        if cf is not None:
            r2 = cf.step(res, i, ci)
            if r2 is None:
                continue
        newc = pref + [ci]
        rts = rr.real_roots_or_none(rr._poly_from_c(newc, T, i))
        if rts is not None:
            out.append((newc, rts, r2))
    return out


def run(shard, nshard, split, out, cf=None, tmax=None):
    c = [1, C1, C2]
    D2 = rr._poly_from_c(c, T, 2)
    assert rr.is_real_rooted(D2)
    stats = dict(nodes=0, split_nodes=0, mine=0, leaves=0, leaves_11=0)
    level_nodes = [0] * (T + 1)
    t0 = time.time()
    stack = [(c, rr.real_roots_sorted(D2), cf.start(c) if cf is not None else None)]
    while stack:
        if tmax is not None and time.time() - t0 > tmax:
            stats["timeout"] = True
            break
        pref, mu, res = stack.pop()
        i = len(pref)
        if i == split + 1:
            stats["split_nodes"] += 1
            if (stats["split_nodes"] - 1) % nshard != shard:
                continue
            stats["mine"] += 1
        for newc, rts, r2 in children(pref, mu, cf, res):
            stats["nodes"] += 1
            level_nodes[len(newc) - 1] += 1
            if len(newc) == T + 1:
                stats["leaves"] += 1
                if newc[-1] == 0:
                    stats["leaves_11"] += 1
                out.write(json.dumps(dict(phi=newc)) + "\n")
                out.flush()
            else:
                stack.append((newc, rts, r2))
    stats["level_nodes"] = level_nodes
    stats["time"] = round(time.time() - t0, 1)
    return stats


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--shard", default="0/1")
    ap.add_argument("--split", type=int, default=5)
    ap.add_argument("--out", required=True)
    ap.add_argument("--classes", default="/workspace/data/P_58_7.json")
    ap.add_argument("--tmax", type=float, default=None)
    args = ap.parse_args()
    shard, nshard = (int(x) for x in args.shard.split("/"))
    cf = ClassFilter(args.classes) if args.classes else None
    with open(args.out, "w") as out:
        stats = run(shard, nshard, args.split, out, cf, args.tmax)
        out.write(json.dumps(dict(summary=stats, shard=args.shard, split=args.split)) + "\n")
    print(json.dumps(stats))


if __name__ == "__main__":
    main()
