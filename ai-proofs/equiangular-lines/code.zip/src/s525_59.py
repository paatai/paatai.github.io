"""Stage X for the leaf s5/25 of 59 lines in R^18 (program 1).

The leaf chi_S = (x+5)^41 (x-11)^14 (x-15)^2 (x^2-21x+94) survives levels 1-3: the only open support
of stage (S) is {16, 19, 20}, and level 3 leaves it open.  The argument (t18_sections.tex, section on
s5/25) has two parts.

Part 1 (this leaf's data, from program 1's own records data/level{1,2,3}_59/s5/25.json).  Checked
exactly: the open support is {16, 19, 20} and level 3 leaves only it; the deck identity
sum n_f g_f = h on it has the unique solution n = (2, 40, 17); with E_theta(i,i) = g(theta)/Min'(theta),
the member with n = 40 has E_15 = 1/20, E_11 = 15/64 and E_theta > 0 at both roots theta of
q = x^2-21x+94, the other two members have E_15 = 0; every pair type psihat of two vertices of the
40-member satisfies, with e = 20 psihat(15)/Min'(15) and psihat = tau g (mod q):
    e in {-1, 0, 1},  tau in {-1, 1},  64 psihat(11)/Min'(11) = 4 - 4 e - tau.
Part 2 (a finite statement, independent of the leaf).  A = {0..19} with the 4-cycles
Z_c = (4c, 4c+1, 4c+2, 4c+3), C their adjacency matrix, P the opposite-vertex involution,
beta = 5I - C - 3P (= 8 H^+ for H = I - C/2), and omega = (+,+,-,-) on Z_0, Z_1, Z_2 and (+,-,+,-) on
Z_3, Z_4.  Profiles Pi_eps: sigma in {+-1}^20 balanced on every Z_c with sigma beta sigma = 128 and
sigma beta omega = 32 eps.  A cycle assignment of kind adj (eps = (+,+,-,-)) or alt (eps = (+,-,+,-)):
(sigma_1..sigma_4), sigma_j in Pi_{eps_j}, sigma_j beta sigma_l = 128 [j = l] - 64 [j - l = +-1 mod 4].
Claim: no three spans of assignments of kind adj and one of kind alt are pairwise beta-orthogonal.
Every count is printed, for comparison with program 2 (verify/s525_59.gp).

Usage: python3 src/s525_59.py [--out=data/stageX_59/s5/25.json]
"""

import itertools
import json
import os
import sys
import time
from fractions import Fraction

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
S_, IDX = 5, 25


# ---------------------------------------------------------------- polynomials over Q (descending lists)
def pmul(a, b):
    out = [Fraction(0)] * (len(a) + len(b) - 1)
    for i, u in enumerate(a):
        for j, v in enumerate(b):
            out[i + j] += u * v
    return out


def pdiff(a):
    n = len(a) - 1
    return [c * (n - i) for i, c in enumerate(a[:-1])]


def peval(a, t):
    r = Fraction(0) if not isinstance(t, Q65) else Q65(0, 0)
    for c in a:
        r = r * t + c
    return r


def pmod(a, m):
    a = [Fraction(c) for c in a]
    while len(a) >= len(m):
        f = a[0] / m[0]
        for i in range(len(m)):
            a[i] -= f * m[i]
        a.pop(0)
    while a and a[0] == 0:
        a.pop(0)
    return a


class Q65:
    """a + b sqrt(65), a, b rational."""

    def __init__(self, a, b):
        self.a, self.b = Fraction(a), Fraction(b)

    def __add__(self, o):
        o = o if isinstance(o, Q65) else Q65(o, 0)
        return Q65(self.a + o.a, self.b + o.b)

    __radd__ = __add__

    def __mul__(self, o):
        o = o if isinstance(o, Q65) else Q65(o, 0)
        return Q65(self.a * o.a + 65 * self.b * o.b, self.a * o.b + self.b * o.a)

    __rmul__ = __mul__

    def inv(self):
        n = self.a * self.a - 65 * self.b * self.b
        assert n != 0
        return Q65(self.a / n, -self.b / n)

    def __truediv__(self, o):
        return self * o.inv()

    def __eq__(self, o):
        o = o if isinstance(o, Q65) else Q65(o, 0)
        return self.a == o.a and self.b == o.b

    def positive(self):
        a, b = self.a, self.b
        if a >= 0 and b >= 0:
            return a > 0 or b > 0
        if a <= 0 and b <= 0:
            return False
        return a * a > 65 * b * b if a > 0 else 65 * b * b > a * a


THETAS = [Q65(Fraction(21, 2), Fraction(1, 2)), Q65(Fraction(21, 2), Fraction(-1, 2))]


def jload(p):
    with open(p) as fh:
        return json.load(fh)


def part1(log):
    L1 = jload(os.path.join(ROOT, "data", "level1_59", f"s{S_}", f"{IDX}.json"))
    L2 = jload(os.path.join(ROOT, "data", "level2_59", f"s{S_}", f"{IDX}.json"))
    L3 = jload(os.path.join(ROOT, "data", "level3_59", f"s{S_}", f"{IDX}.json"))
    fac = sorted((tuple(f), m) for f, m in L1["factors"])
    assert fac == sorted([((1, -21, 94), 1), ((1, -15), 2), ((1, -11), 14), ((1, 5), 41)]), fac
    q = [1, -21, 94]
    Min = [Fraction(1)]
    for f, _m in L1["factors"]:
        Min = pmul(Min, [Fraction(c) for c in f])
    dMin = pdiff(Min)
    assert L2["verdict"] == "open" and L2["S"]["open_supports"] == [[16, 19, 20]]
    assert L2["S"]["skipped_cliques"] == []
    assert L3["verdict"] == "open" and [s["support"] for s in L3["supports"]] == [[16, 19, 20]]
    log(f"part 1: chi = (x+5)^41 (x-11)^14 (x-15)^2 (x^2-21x+94); open support [16, 19, 20] "
        f"(level 2: {len(L2['S']['supports'])} supports, level 3 leaves it open)")
    U = [16, 19, 20]
    g = {f: [Fraction(c) for c in L2["deck"][f]] for f in U}
    h = [Fraction(c) for c in L2["h"]]
    # unique solution of sum n_f g_f = h (5 equations, 3 unknowns): Gauss-Jordan
    M = [[g[f][r] for f in U] + [h[r]] for r in range(5)]
    piv = []
    row = 0
    for col in range(3):
        k = next((i for i in range(row, 5) if M[i][col] != 0), None)
        assert k is not None, "deck system not of full rank"
        M[row], M[k] = M[k], M[row]
        M[row] = [v / M[row][col] for v in M[row]]
        for i in range(5):
            if i != row and M[i][col] != 0:
                fct = M[i][col]
                M[i] = [a - fct * b for a, b in zip(M[i], M[row])]
        piv.append(col)
        row += 1
    assert all(M[i][3] == 0 for i in range(3, 5)), "deck system inconsistent"
    n = {f: M[i][3] for i, f in enumerate(U)}
    assert [n[f] for f in U] == [2, 40, 17], n
    log(f"part 1: deck counts n_16 = 2, n_19 = 40, n_20 = 17 (unique)")

    def E(poly, th):
        return peval(poly, th) / peval(dMin, th)

    for f in U:
        e15, e11 = E(g[f], Fraction(15)), E(g[f], Fraction(11))
        if f == 19:
            assert e15 == Fraction(1, 20) and e11 == Fraction(15, 64)
            assert all(E(g[f], th).positive() for th in THETAS)
        else:
            assert e15 == 0
    log("part 1: member 19: E_15 = 1/20, E_11 = 15/64, E_theta > 0 at both roots of q; members 16, 20: E_15 = 0")
    gq = pmod(g[19], q)
    types = set()
    for sig, psi, _P in L2["J"]["pairs"]["19,19"]:
        types.add(tuple(sig * c for c in psi))
    table = []
    for u in sorted(types):
        u = [Fraction(c) for c in u]
        e = 20 * E(u, Fraction(15))
        uq = pmod(u, q)
        tau = 1 if uq == gq else (-1 if uq == [-c for c in gq] else None)
        assert e in (-1, 0, 1) and tau is not None, (u, e)
        assert all(E(u, th) == tau * E(g[19], th) for th in THETAS)
        e11 = 64 * E(u, Fraction(11))
        assert e11 == 4 - 4 * e - tau, (u, e, tau, e11)
        table.append({"psihat": [str(c) for c in u], "e": int(e), "tau": tau, "64E11": int(e11)})
    assert len(table) == 6
    log("part 1: the 6 pair types of (19,19): (e, tau, 64 psihat(11)/Min'(11)) = "
        + ", ".join(f"({t['e']}, {t['tau']}, {t['64E11']})" for t in table))
    return {"n": [2, 40, 17], "pair_types_19_19": table}


# ---------------------------------------------------------------- part 2
def part2(log):
    N = 20
    C = np.zeros((N, N), dtype=np.int64)
    P = np.zeros((N, N), dtype=np.int64)
    for c in range(5):
        for t in range(4):
            i, j = 4 * c + t, 4 * c + (t + 1) % 4
            C[i, j] = C[j, i] = 1
            P[4 * c + t, 4 * c + (t + 2) % 4] = 1
    beta = 5 * np.eye(N, dtype=np.int64) - C - 3 * P
    adjpat, altpat = (1, 1, -1, -1), (1, -1, 1, -1)
    omega = np.array(adjpat * 3 + altpat * 2, dtype=np.int64)
    # sanity: beta = 8 H^+ with H = I - C/2, i.e. (I - C/2) beta = 8 (I - J_c/4) blockwise
    Jc = np.zeros((N, N), dtype=np.int64)
    for c in range(5):
        Jc[4 * c:4 * c + 4, 4 * c:4 * c + 4] = 1
    assert np.array_equal((2 * np.eye(N, dtype=np.int64) - C) @ beta, 16 * np.eye(N, dtype=np.int64) - 4 * Jc)
    assert np.array_equal(beta @ Jc, np.zeros((N, N), dtype=np.int64))
    bal = [v for v in itertools.product((1, -1), repeat=4) if sum(v) == 0]
    assert len(bal) == 6
    prof = {1: [], -1: []}
    for blocks in itertools.product(bal, repeat=5):
        s = np.array(sum(blocks, ()), dtype=np.int64)
        if s @ beta @ s != 128:
            continue
        z = s @ beta @ omega
        if z in (32, -32):
            prof[int(z // 32)].append(s)
    log(f"part 2: profiles |Pi_+| = {len(prof[1])}, |Pi_-| = {len(prof[-1])}")
    allp = prof[1] + prof[-1]
    X = np.array(allp)
    G = (X @ beta @ X.T).tolist()
    np_ = len(prof[1])
    idx = {1: list(range(np_)), -1: list(range(np_, len(allp)))}

    def assignments(pat):
        out = []
        d0, d1, d2, d3 = (idx[e] for e in pat)
        for a in d0:
            for b in d1:
                if G[a][b] != -64:
                    continue
                for c in d2:
                    if G[a][c] != 0 or G[b][c] != -64:
                        continue
                    for d in d3:
                        if G[a][d] == -64 and G[b][d] == 0 and G[c][d] == -64:
                            out.append((a, b, c, d))
        return out

    def rref(rows):
        m = [[Fraction(int(v)) for v in r] for r in rows]
        r = 0
        for c in range(len(m[0])):
            k = next((i for i in range(r, len(m)) if m[i][c] != 0), None)
            if k is None:
                continue
            m[r], m[k] = m[k], m[r]
            inv = 1 / m[r][c]
            m[r] = [v * inv for v in m[r]]
            for i in range(len(m)):
                if i != r and m[i][c] != 0:
                    fct = m[i][c]
                    m[i] = [a - fct * b for a, b in zip(m[i], m[r])]
            r += 1
            if r == len(m):
                break
        return tuple(tuple(v) for v in m[:r])

    W = {}
    counts = {}
    for kind, pat in (("adj", adjpat), ("alt", altpat)):
        A = assignments(pat)
        spaces = {}
        for t in A:
            assert not (X[t[0]] + X[t[1]] + X[t[2]] + X[t[3]]).any()
            key = rref([X[i] for i in t])
            assert len(key) == 3
            spaces.setdefault(key, t)
        W[kind] = list(spaces.values())
        counts[kind] = {"assignments": len(A), "subspaces": len(spaces)}
        log(f"part 2: kind {kind}: {len(A)} cycle assignments, {len(spaces)} distinct spans (all of dimension 3)")
    reps = [(k, t) for k in ("adj", "alt") for t in W[k]]
    B = np.array([X[i] for _k, t in reps for i in t[:3]], dtype=np.int64)  # 3 rows per subspace
    nW = len(reps)
    BB = B @ beta
    kinds = np.array([k == "adj" for k, _t in reps])
    ia, il = [int(i) for i in np.nonzero(kinds)[0]], [int(i) for i in np.nonzero(~kinds)[0]]
    maskalt = sum(1 << i for i in il)
    maskadj = sum(1 << i for i in ia)
    nbr = []
    CH = 400
    for s0 in range(0, nW, CH):
        m = min(nW, s0 + CH) - s0
        blk = (BB[3 * s0:3 * (s0 + m)] @ B.T).reshape(m, 3, nW, 3)
        orth = (blk == 0).all(axis=(1, 3))
        for i in range(m):
            row = orth[i].copy()
            row[s0 + i] = False
            nbr.append(int.from_bytes(np.packbits(row[::-1]).tobytes(), "big") >> ((-nW) % 8))
    for i in range(nW):
        for j in (0, nW - 1):
            assert ((nbr[i] >> j) & 1) == ((nbr[j] >> i) & 1)
    pairs = {"adj-adj": sum(bin(nbr[i] & maskadj).count("1") for i in ia) // 2,
             "adj-alt": sum(bin(nbr[i] & maskalt).count("1") for i in ia),
             "alt-alt": sum(bin(nbr[i] & maskalt).count("1") for i in il) // 2}
    log(f"part 2: beta-orthogonal pairs of spans: {pairs}")
    tri, quad, x3 = 0, 0, 0
    for a in ia:
        for b in ia:
            if b <= a or not (nbr[a] >> b) & 1:
                continue
            x3 += bin(nbr[a] & nbr[b] & maskalt).count("1")
            common = nbr[a] & nbr[b] & maskadj
            while common:
                low = common & -common
                c = low.bit_length() - 1
                common ^= low
                if c <= b:
                    continue
                tri += 1
                quad += bin(nbr[a] & nbr[b] & nbr[c] & maskalt).count("1")
    log(f"part 2: pairwise orthogonal (adj, adj, alt) triples of spans: {x3}")
    log(f"part 2: pairwise orthogonal triples of adj spans: {tri}; with an alt span orthogonal to all three: {quad}")
    return {"profiles": [len(prof[1]), len(prof[-1])], "kinds": counts, "orthogonal_pairs": pairs,
            "adj_adj_alt_triples": x3, "adj_triples": tri, "adj_triples_with_alt": quad}


def main():
    out = next((a[6:] for a in sys.argv[1:] if a.startswith("--out=")),
               os.path.join(ROOT, "data", "stageX_59", f"s{S_}", f"{IDX}.json"))
    t0 = time.time()
    lines = []

    def log(m):
        print(m, flush=True)
        lines.append(m)

    r1 = part1(log)
    r2 = part2(log)
    verdict = "excluded" if r2["adj_triples_with_alt"] == 0 else "open"
    log(f"s{S_}/{IDX}: {verdict} (X) {time.time() - t0:.1f} s")
    os.makedirs(os.path.dirname(out), exist_ok=True)
    with open(out + ".tmp", "w") as fh:
        json.dump({"shard": S_, "idx": IDX, "verdict": verdict, "part1": r1, "part2": r2, "log": lines,
                   "t": time.time() - t0}, fh, indent=1)
    os.replace(out + ".tmp", out)


if __name__ == "__main__":
    main()
