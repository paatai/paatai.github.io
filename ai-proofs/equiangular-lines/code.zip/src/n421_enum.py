"""Remainder polynomials for 421 equiangular lines in R^44 (angle arccos 1/7).

Setting (see MAIN_RESULT.tex, Section 4).  A Seidel matrix S of order 421 with
smallest eigenvalue -7 of multiplicity exactly 377 has, by iterated stripping
(strip_scan.py), eigenvalue 59 with multiplicity >= 16 and 61 with multiplicity
>= 15, so
    chi_S(x) = (x+7)^377 (x-59)^16 (x-61)^15 Q(x-59),
where Q is monic of degree 13 with power sums p1 = 13, p2 = 49 (from tr S = 0,
tr S^2 = 421*420), real roots, and coefficients a_i (Q = sum a_i x^{13-i}) with
    2^{i-1} | a_i (i odd),   2^i | a_i (i even)
(weakly type 2 plus the parity refinement; Lemma 4.1 in MAIN_RESULT.tex).
Every root of Q is >= 1 - 6 (variance), so no further window is needed.

Usage: python3 n421_enum.py [--weak] [out.json]
  --weak  drop the parity refinement (only 2^{i-1} | a_i for all i >= 1, i.e. weakly type 2);
          output goes to data/n421_weak/.  Used to show the result does not need the refinement.
"""

import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from eqlines.rr import enumerate_real_rooted  # noqa: E402

T = 13
C1 = -13
C2 = (13 * 13 - 49) // 2  # e2 = (p1^2 - p2)/2 = 60


WEAK = "--weak" in sys.argv


def congr(i, _pref):
    k = i - 1 if (i % 2 == 1 or WEAK) else i
    return ({0}, 1 << k)


def main():
    args = [a for a in sys.argv[1:] if a != "--weak"]
    sub = "n421_weak" if WEAK else "n421"
    out = Path(args[0]) if args else Path(__file__).resolve().parent.parent / "data" / sub / "Q_candidates.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    stats = {}
    t0 = time.time()
    found = []
    for c in enumerate_real_rooted(T, C1, C2, congr=congr, stats=stats):
        found.append(c)
        if len(found) % 100 == 0:
            print(f"{len(found)} found, nodes={stats['nodes']}, {time.time()-t0:.0f}s", flush=True)
    dt = time.time() - t0
    out.write_text(json.dumps(dict(t=T, c1=C1, c2=C2, count=len(found), stats=stats,
                                   seconds=dt, polys=found)))
    print(f"done: {len(found)} polynomials, stats={stats}, {dt:.1f}s -> {out}")


if __name__ == "__main__":
    main()
