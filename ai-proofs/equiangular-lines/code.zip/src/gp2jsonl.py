"""Converts a complete shard of verify/enum59.gp to the .jsonl format of src/enum59.py.

Usage: python3 gp2jsonl.py GP_TXT OUT_JSONL [PY_JSONL]
  Writes OUT_JSONL only if GP_TXT ends with its summary line.  With PY_JSONL (the same shard of
  enum59.py, possibly still running or not yet started), checks that its leaves are a prefix of
  GP_TXT's leaves and, if PY_JSONL is complete, that the two leaf lists and the node counts per
  level are equal.
"""

import json
import os
import sys


def read_gp(path):
    leaves, summary = [], None
    with open(path) as fh:
        for line in fh:
            if not line.endswith("\n"):
                break
            line = line.strip()
            if line.startswith("summary"):
                a, b = line[len("summary"):].split("levels")
                summary = {"counts": json.loads(a), "levels": json.loads(b)}
            elif line.startswith("["):
                leaves.append(json.loads(line))
    return leaves, summary


def read_py(path):
    leaves, summary = [], None
    with open(path) as fh:
        for line in fh:
            if not line.endswith("\n"):
                break
            d = json.loads(line)
            if "psi" in d:
                leaves.append(d["psi"])
            elif "summary" in d:
                summary = d["summary"]
    return leaves, summary


def main():
    gp_path, out_path = sys.argv[1], sys.argv[2]
    leaves, summary = read_gp(gp_path)
    if summary is None:
        print(f"{gp_path}: incomplete ({len(leaves)} leaves so far)")
        return 1
    if summary["counts"][1] != len(leaves):
        print(f"{gp_path}: summary says {summary['counts'][1]} leaves, file has {len(leaves)}")
        return 2
    with open(out_path + ".tmp", "w") as fh:
        for psi in leaves:
            fh.write(json.dumps({"psi": psi}) + "\n")
        fh.write(json.dumps({"summary": summary, "source": gp_path}) + "\n")
    os.replace(out_path + ".tmp", out_path)
    msg = f"{gp_path}: {len(leaves)} leaves -> {out_path}"
    if len(sys.argv) > 3 and not os.path.exists(sys.argv[3]):
        msg += "; python shard not started"
    elif len(sys.argv) > 3:
        py, py_summary = read_py(sys.argv[3])
        if py != leaves[:len(py)]:
            print(msg + f"; PYTHON DIFFERS from GP within its first {len(py)} leaves")
            return 3
        msg += f"; python's {len(py)} leaves are a prefix"
        if py_summary is not None:
            same = py == leaves
            msg += f"; python complete: leaves {'EQUAL' if same else 'DIFFERENT'}"
            c = summary["counts"]
            nodes_same = [py_summary["nodes"], py_summary["leaves"], py_summary["split_nodes"],
                          py_summary["mine"]] == c and py_summary["level_nodes"] == summary["levels"]
            msg += f", node counts {'EQUAL' if nodes_same else 'DIFFERENT'}"
            if not (same and nodes_same):
                print(msg)
                return 3
    print(msg)
    return 0


if __name__ == "__main__":
    sys.exit(main())
