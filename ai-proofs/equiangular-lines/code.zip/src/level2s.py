"""Vertex-star systems (eqlines.star) for the candidates left open by level2j.py.

For each open candidate (data/level2j[_l312]/CASE/<idx>.json) and every nonempty subset U of
an LP-feasible maximal clique of the pair graph, the star system with support U is decided.
Infeasible systems get an exact Farkas vector, re-verified here. If every U is infeasible,
the candidate is excluded.

With --resolvent the row-resolvent system (eqlines.star.ResolventStar) is used instead.

Usage: python3 level2s.py [--l312] [--resolvent] CASE [indices...]
Output: data/level2s[_l312]/CASE/<idx>.json  (data/level2r[_l312]/ with --resolvent)
"""

import json
import os
import sys
import time
from itertools import combinations

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.deck import SpecPoly, candidate_poly  # noqa: E402
from eqlines.jacobi import PairSpace  # noqa: E402
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.star import ResolventStar, StarSystem, poly  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CASES = {
    "74_19": dict(kappa=15, m_low=55, m_kappa=6),
    "94_20": dict(kappa=19, m_low=74, m_kappa=7),
}


def analyse(case, idx, l312, resolvent=False):
    s = "_l312" if l312 else ""
    cfg = CASES[case]
    with open(os.path.join(ROOT, "data", "level2" + s, case, f"{idx}.json")) as fh:
        L2 = json.load(fh)
    with open(os.path.join(ROOT, "data", "level2j" + s, case, f"{idx}.json")) as fh:
        LJ = json.load(fh)
    t0 = time.time()
    sp = SpecPoly(candidate_poly(L2["psi"], cfg["kappa"], cfg["m_low"], cfg["m_kappa"]))
    ps = PairSpace(sp, nonzero_at=[-5])
    G = [coeffs_to_poly(c) for c in L2["deck"]]
    pairs = {}
    for key, found in LJ["pairs"].items():
        a, b = map(int, key.split(","))
        if resolvent:
            pairs[(a, b)] = [sig * poly(psi) for sig, psi, _P in found]
        else:
            pairs[(a, b)] = [poly(P) for _sig, _psi, P in found]
    st = ResolventStar(sp, G, sp.h, pairs) if resolvent else StarSystem(sp, ps, G, sp.h, pairs)
    seen = set()
    out = []
    for C in LJ["open_cliques"]:
        for r in range(1, len(C) + 1):
            for U in combinations(sorted(C), r):
                if U in seen:
                    continue
                seen.add(U)
                status, data = st.solve(U)
                if status == "not-clique":
                    continue
                out.append({"support": list(U), "status": status,
                            **({"cert": data} if status == "certified" else {})})
    open_ = [e["support"] for e in out if e["status"] != "certified"]
    return {"case": case, "idx": idx, "supports": out, "open_supports": open_,
            "verdict": "excluded" if not open_ else "open", "t": time.time() - t0}


def main():
    l312 = "--l312" in sys.argv
    resolvent = "--resolvent" in sys.argv
    argv = [a for a in sys.argv[1:] if a not in ("--l312", "--resolvent")]
    case = argv[0]
    s = "_l312" if l312 else ""
    if len(argv) > 1:
        idxs = [int(a) for a in argv[1:]]
    else:
        d = os.path.join(ROOT, "data", "level2j" + s, case)
        idxs = []
        for fn in sorted(os.listdir(d), key=lambda f: int(f[:-5])):
            with open(os.path.join(d, fn)) as fh:
                if json.load(fh)["verdict"] == "open":
                    idxs.append(int(fn[:-5]))
    dout = os.path.join(ROOT, "data", ("level2r" if resolvent else "level2s") + s, case)
    os.makedirs(dout, exist_ok=True)
    for idx in idxs:
        res = analyse(case, idx, l312, resolvent)
        with open(os.path.join(dout, f"{idx}.json"), "w") as fh:
            json.dump(res, fh)
        cnt = {}
        for e in res["supports"]:
            cnt[e["status"]] = cnt.get(e["status"], 0) + 1
        print(time.strftime("%H:%M:%S"), case, idx, cnt, "open supports:", res["open_supports"],
              res["verdict"], f"{res['t']:.1f}s", flush=True)


if __name__ == "__main__":
    main()
