"""CP-SAT model for candidate #35, U = (0, 1, 5), class L_a with c = 2 cycles.

Selection variables b_x over the coloured core (c35_core), class variables beta_x for type-1
nodes (L_b vs L_c).  Constraints (all necessary, see c35_core / c35_lp):
  * 24 type-0 and 32 type-1 nodes, 16 of them in L_b;
  * every selected pair has an allowed relation; for type-1 pairs 0 / -4 forces the same class
    and +-2 different classes;
  * exact partner counts of every selected node (NEED0, NEED1);
  * frame on span(L_a) (rational part) and on F:  sum b_x omega_x omega_x^T = 40 P_a - Lap,
    sum b_x (N_x - W_x) = 40;
  * zero sums of omega over type 0, over L_b and over L_c.
"""
import sys
import time

import numpy as np
from ortools.sat.python import cp_model

from c35_core import NEED0, NEED1, build, core


def model(part, time_limit=600.0, workers=8):
    g = build(part)
    alive = core(g)
    idx = np.nonzero(alive)[0]
    n = len(idx)
    D = g["D"]
    m1, m2 = part
    t0 = g["t0"][idx]
    rel = {a: g["rel"][a][np.ix_(idx, idx)] for a in g["rel"]}
    H = g["H"][g["js"][idx]]
    Sm = g["Sm"][g["js"][idx]]
    om = D * H.copy()
    om[:, :m1] -= (D // m1) * Sm[:, [0]]
    om[:, m1:] -= (D // m2) * Sm[:, [1]]
    W = (om * om).sum(1)  # D^2 |omega|^2
    N = g["Ns"][idx]
    R = N * D * D - W      # D^2 (N - W)
    m = cp_model.CpModel()
    b = [m.NewBoolVar(f"b{i}") for i in range(n)]
    beta = [m.NewBoolVar(f"c{i}") if not t0[i] else None for i in range(n)]
    gam = [None] * n
    for i in range(n):
        if not t0[i]:
            gam[i] = m.NewBoolVar(f"g{i}")
            m.AddBoolAnd([b[i], beta[i]]).OnlyEnforceIf(gam[i])
            m.AddBoolOr([b[i].Not(), beta[i].Not(), gam[i]])
    m.Add(sum(b[i] for i in range(n) if t0[i]) == 24)
    m.Add(sum(b[i] for i in range(n) if not t0[i]) == 32)
    m.Add(sum(gam[i] for i in range(n) if not t0[i]) == 16)
    anyrel = np.zeros((n, n), dtype=bool)
    for a in rel:
        anyrel |= rel[a]
    same = rel[0] | rel[-4]
    diff = (rel[2] | rel[-2]) & np.outer(~t0, ~t0)
    npairs = 0
    for i in range(n):
        for j in range(i + 1, n):
            if not anyrel[i, j]:
                m.AddBoolOr([b[i].Not(), b[j].Not()])
                npairs += 1
            elif not t0[i] and not t0[j]:
                if same[i, j]:
                    m.Add(beta[i] == beta[j]).OnlyEnforceIf([b[i], b[j]])
                elif diff[i, j]:
                    m.Add(beta[i] != beta[j]).OnlyEnforceIf([b[i], b[j]])
    for i in range(n):
        need = NEED0 if t0[i] else NEED1
        for a, to0, k in need:
            cols = [j for j in np.nonzero(rel[a][i])[0] if t0[j] == to0]
            m.Add(sum(b[j] for j in cols) == k).OnlyEnforceIf(b[i])
    # frame on span(L_a): sum b_x (D omega)(D omega)^T = D^2 (40 P_a - Lap)
    Pa = np.zeros((16, 16))
    Pa[:m1, :m1] = np.eye(m1) - 1.0 / m1
    Pa[m1:, m1:] = np.eye(m2) - 1.0 / m2
    Lap = np.zeros((16, 16))
    for (u, v) in [(k, (k + 1) % m1) for k in range(m1)] + [(m1 + k, m1 + (k + 1) % m2) for k in range(m2)]:
        e = np.zeros(16)
        e[u], e[v] = 2, -2
        Lap += np.outer(e, e)
    T = D * D * (40 * Pa - Lap)
    Ti = np.rint(T).astype(np.int64)
    assert np.allclose(T, Ti)
    for p in range(16):
        for q in range(p, 16):
            m.Add(sum(int(om[i, p] * om[i, q]) * b[i] for i in range(n) if om[i, p] * om[i, q] != 0)
                  == int(Ti[p, q]))
    m.Add(sum(int(R[i]) * b[i] for i in range(n)) == 40 * D * D)
    for p in range(16):
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * gam[i] for i in range(n) if not t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * b[i] for i in range(n) if not t0[i]) == 0)
    print(part, "core", n, "(type0", int(t0.sum()), ") exclusion clauses", npairs, flush=True)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_workers = workers
    t = time.time()
    st = solver.Solve(m)
    print(part, "status", solver.StatusName(st), "time", round(time.time() - t, 1), flush=True)
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = [int(idx[i]) for i in range(n) if solver.Value(b[i])]
    return solver.StatusName(st), sol, g


if __name__ == "__main__":
    tl = float(sys.argv[1]) if len(sys.argv) > 1 else 600
    for p in sys.argv[2:] or ["8,8", "12,4"]:
        model(tuple(int(x) for x in p.split(",")), time_limit=tl)
