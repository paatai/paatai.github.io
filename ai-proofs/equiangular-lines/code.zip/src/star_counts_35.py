"""Type counts of candidate #35 per support (CLAIMS.md U6(a)): the vertex-star systems of
src/level2s.py with n_2 and n_5 fixed; prints the feasible (n2, n5) per support.

usage: python3 src/star_counts_35.py   (output: logs/star_counts_35.log)
"""
import json, sys
sys.path.insert(0,'src')
from eqlines.deck import SpecPoly, candidate_poly
from eqlines.jacobi import PairSpace
from eqlines.rr import coeffs_to_poly
from eqlines.star import StarSystem, poly
from eqlines import exactlp
CASES = {"74_19": dict(kappa=15, m_low=55, m_kappa=6), "94_20": dict(kappa=19, m_low=74, m_kappa=7)}
for case in CASES:
    cfg=CASES[case]
    L2 = json.load(open(f'data/level2_l312/{case}/35.json'))
    LJ = json.load(open(f'data/level2j_l312/{case}/35.json'))
    sp = SpecPoly(candidate_poly(L2["psi"], cfg["kappa"], cfg["m_low"], cfg["m_kappa"]))
    ps = PairSpace(sp, nonzero_at=[-5])
    G = [coeffs_to_poly(c) for c in L2["deck"]]
    pairs = {}
    for key, found in LJ["pairs"].items():
        a, b = map(int, key.split(","))
        pairs[(a, b)] = [poly(P) for _sig, _psi, P in found]
    st = StarSystem(sp, ps, G, sp.h, pairs)
    for U in ([0,1,5],[0,1,2],[0,1,2,5]):
        rows, rhs, names = st.build(U)
        ncol=len(names)
        col={nm:i for i,nm in enumerate(names)}
        feas=[]
        rng2 = range(1,40) if 2 in U else [None]
        rng5 = range(1,6) if 5 in U else [None]
        for n2 in rng2:
            for n5 in rng5:
                R=[r[:] for r in rows]; B=rhs[:]
                for g,val in ((2,n2),(5,n5)):
                    if val is None: continue
                    if ('n',g) in col:
                        row=[0]*ncol; row[col[('n',g)]]=1; R.append(row); B.append(val-1)
                    elif val!=1: R=None; break
                if R is None: continue
                s,_=exactlp.solve(R,B)
                if s=='feasible':
                    # recover n0,n1 from solution
                    feas.append((n2,n5,[ (nm, str(_[i])) for i,nm in enumerate(names) if nm[0]=='n']))
        print(case, U, 'feasible (n2,n5):', [(f[0],f[1]) for f in feas])
        for f in feas[:3]: print('   ', f)
