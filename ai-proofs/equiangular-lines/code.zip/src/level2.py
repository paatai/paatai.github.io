"""Level 2 for the level-1 survivors of 74 lines in R^19 and 94 lines in R^20.

Input: data/level1/CASE/<idx>.json (deck filtered by the complete class list P_{n-1,7}).
For each candidate p:
  1. the compatibility graph on the filtered deck (eqlines.compat): an edge g - h if g, h
     are Seidel-compatible, a loop at g if g is self-compatible;
  2. by [GSY23, Cor. 4.8] the members used by S form a clique, and a member without a
     loop is used at most once;
  3. for every maximal clique C, the LP  sum_{f in C} n_f g_f = h, n >= 0, n_f <= 1 for
     members without a loop, is decided; infeasible cliques get an exact certificate
     (lpcert.verify_farkas_bounded).
If every maximal clique is infeasible, p is excluded.

With --l312 the deck is further filtered by [GY19, Lemma 3.12] at order n - 1 (eqlines.gy312),
and the output goes to data/level2_l312/.

Usage: python3 level2.py [--l312] CASE [workers] [indices...]
Output: data/level2/CASE/<idx>.json
"""

import json
import os
import sys
import time
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.compat import Compat, maximal_cliques  # noqa: E402
from eqlines.deck import SpecPoly, candidate_poly  # noqa: E402
from eqlines.gy312 import check_chi_S  # noqa: E402
from eqlines.lpcert import (find_farkas_bounded, find_feasible_bounded,  # noqa: E402
                            integer_certificate, verify_farkas_bounded)
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import coeffs_desc  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
CASES = {
    "74_19": dict(kappa=15, m_low=55, m_kappa=6),
    "94_20": dict(kappa=19, m_low=74, m_kappa=7),
}
SURVIVORS = {
    "74_19": [3, 9, 20, 27, 35, 42, 50, 78, 81, 83, 85, 89, 91, 99, 100, 110, 111, 142, 144, 149, 153, 162],
    "94_20": [3, 9, 20, 27, 35, 50, 78, 81, 83, 89, 91, 99, 100, 110, 111, 142, 144, 149, 153, 162],
}


def out_root(l312):
    return os.path.join(ROOT, "data", "level2_l312" if l312 else "level2")


def analyse(args):
    case, idx, l312 = args
    cfg = CASES[case]
    with open(os.path.join(ROOT, "data", "level1", case, f"{idx}.json")) as fh:
        L1 = json.load(fh)
    t0 = time.time()
    p = candidate_poly(L1["psi"], cfg["kappa"], cfg["m_low"], cfg["m_kappa"])
    sp = SpecPoly(p)
    assert coeffs_desc(sp.h) == L1["h"]
    D = [c for c, ok in zip(L1["deck"], L1["class_ok"]) if ok]
    n_class = len(D)
    if l312:
        D = [c for c in D if check_chi_S(sp.mu * coeffs_to_poly(c)) is None]
    cp = Compat(sp, D)
    res = {"case": case, "idx": idx, "psi": L1["psi"], "h": L1["h"], "deck": D,
           "l312": l312, "deck_class_ok": n_class,
           "simple": [j for j in cp.simple], "min_parity_ok": cp.min_parity_ok()}
    if not cp.min_parity_ok():
        res["verdict"] = "excluded (Min parity)"
        res["t"] = time.time() - t0
        return res
    adj, loop = cp.graph()
    res["edges"] = sorted([a, b] for a in adj for b in adj[a] if a < b)
    res["loops"] = [a for a in sorted(loop) if loop[a]]
    cliques = maximal_cliques(adj)
    out = []
    feasible = []
    for C in sorted(cliques, key=lambda c: sorted(c)):
        C = sorted(C)
        DC = [D[i] for i in C]
        ub = [not loop[i] for i in C]
        st, _x = find_feasible_bounded(sp, DC, ub)
        entry = {"clique": C, "lp": st}
        if st != "feasible":
            Y = find_farkas_bounded(sp, DC, ub)
            if Y is None:
                entry["lp"] = "infeasible-uncertified" if st == "infeasible" else st
            else:
                Z = integer_certificate(Y)
                assert verify_farkas_bounded(DC, L1["h"], Z, ub)
                entry["cert"] = Z
        if "cert" not in entry:
            feasible.append(C)
        out.append(entry)
    res["cliques"] = out
    res["open_cliques"] = feasible
    res["verdict"] = "excluded" if not feasible else "open"
    res["t"] = time.time() - t0
    return res


def main():
    l312 = "--l312" in sys.argv
    argv = [a for a in sys.argv[1:] if a != "--l312"]
    case = argv[0]
    workers = int(argv[1]) if len(argv) > 1 else 6
    idxs = [int(a) for a in argv[2:]] or SURVIVORS[case]
    os.makedirs(os.path.join(out_root(l312), case), exist_ok=True)
    with Pool(workers) as pool:
        for res in pool.imap_unordered(analyse, [(case, i, l312) for i in idxs]):
            path = os.path.join(out_root(l312), case, f"{res['idx']}.json")
            with open(path, "w") as fh:
                json.dump(res, fh)
            nc = len(res.get("cliques", []))
            print(time.strftime("%H:%M:%S"), case, res["idx"],
                  f"deck={len(res['deck'])}/{res['deck_class_ok']}",
                  f"simple={len(res['simple'])}", f"edges={len(res.get('edges', []))}",
                  f"loops={len(res.get('loops', []))}", f"cliques={nc}",
                  f"open={len(res.get('open_cliques', []))}", res["verdict"], f"{res['t']:.1f}s", flush=True)


if __name__ == "__main__":
    main()
