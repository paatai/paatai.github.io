"""Exact search for candidate #35, supports with type 2: U = (0, 1, 2, 5) and U = (0, 1, 2).

Generalises src/c35t.py (which handles (0,1,2,5) only); the two programs share no code.

Normalisation (CLAIMS.md U6/U8): lines of type r > 0 switched to eps = +1, type 0 to p = +sqrt3 w0.
Rigid positions (r, p) with p in coordinates (w0/sqrt3, Pi_1, Pi_2/sqrt3):
    T0            r = 0, p = (1, 0)               |z|^2 = 9
    T1x           r = 1, p = (0, 2 u_x)           |z|^2 = 8
    (0,1,2,5):  t_x  r = 2, p = (-1, -2 u_x)      |z|^2 = 5,   f: r = 3, p = (2, 0), z = 0
    (0,1,2):    t_x+, t_x-  r = 2, p = (sigma, -2 u_x),  |z|^2 = 5   (one at each position)
Pair rule: <z_u, z_v> = (6 S_uv - K_uv)/3 with K = 2 r r' + <p, p'>.
Row counts of T0/T1 lines and the block sums Z_tau = sum_{v in tau} z_v follow from the singleton
(type 2 and 5) data by the 4 x 4 linear systems of S E = lambda E and of the cross frames.

Base class L_a: its (-4)-graph is a union of paths and even cycles; the path ends are the
minus-partners in L_a of the type-2 lines of the other classes.  Walk model as in c35t: for a
vector y outside L_a, steps s_i = <y, q_i>/2, heights h_{i+1} = h_i - s_i, omega = heights centred
per component, F-part in F = span(L_a)^perp, written against reference vectors (type-2 lines, then
if necessary one node, Case A/B).  All identities are exact integers with D = lcm(component sizes).
"""
import argparse
import itertools
import json
import time
from fractions import Fraction as Fr
from math import lcm

import numpy as np

CASES = {
    "74_19": dict(dimV=15, frame=40, lam_r=17, lam_p=11,
                  n={"0125": (25, 15), "012": (26, 14)}),
    "94_20": dict(dimV=16, frame=48, lam_r=21, lam_p=15,
                  n={"0125": (33, 19), "012": (34, 18)}),
}
UX = {"a": (Fr(1), Fr(0)), "b": (Fr(-1, 2), Fr(1, 2)), "c": (Fr(-1, 2), Fr(-1, 2))}
BLOCKS = ["T0", "T1a", "T1b", "T1c"]


class Support:
    def __init__(self, case, name):
        self.case, self.name = case, name
        cfg = CASES[case]
        self.n0, self.nc = cfg["n"][name]
        self.pos = {"T0": (0, Fr(1), Fr(0), Fr(0))}
        self.norm = {"T0": 9}
        for x in "abc":
            self.pos["T1" + x] = (1, Fr(0), 2 * UX[x][0], 2 * UX[x][1])
            self.norm["T1" + x] = 8
        self.single = []
        if name == "0125":
            for x in "abc":
                self.pos["t" + x] = (2, Fr(-1), -2 * UX[x][0], -2 * UX[x][1])
                self.norm["t" + x] = 5
                self.single.append("t" + x)
            self.pos["f"] = (3, Fr(2), Fr(0), Fr(0))
            self.norm["f"] = 0
            self.single.append("f")
        else:
            for x in "abc":
                for s, sg in (("+", 1), ("-", -1)):
                    nm = "t" + x + s
                    self.pos[nm] = (2, Fr(sg), -2 * UX[x][0], -2 * UX[x][1])
                    self.norm[nm] = 5
                    self.single.append(nm)
        self.t2 = [s for s in self.single if self.norm[s] == 5]
        self.size = {"T0": self.n0, "T1a": self.nc, "T1b": self.nc, "T1c": self.nc}
        self.lam = [cfg["lam_r"], cfg["lam_p"], cfg["lam_p"], cfg["lam_p"]]

    def cls(self, nm):
        return nm[1] if nm.startswith("t") else (nm[2] if nm.startswith("T1") else None)

    def K(self, u, v):
        r1, *p1 = self.pos[u]
        r2, *p2 = self.pos[v]
        return 2 * r1 * r2 + 3 * p1[0] * p2[0] + p1[1] * p2[1] + 3 * p1[2] * p2[2]

    def allowed(self, u, v):
        """{B: S} for lines of types u, v (B = (6S - K)/3 integral, |B| <= sqrt(N N'))."""
        out = {}
        K = self.K(u, v)
        for S in (1, -1):
            B = Fr(6 * S - K, 3)
            if B.denominator == 1 and B * B <= self.norm[u] * self.norm[v]:
                out[int(B)] = S
        return out

    def _solve(self, rhs):
        M = [[-2 * self.pos[t][k] for t in BLOCKS] for k in range(4)]
        return solve_lin(M, rhs)

    def row_counts(self, tu, sing):
        """m[tau] = #{v in block tau, v != u : S_uv = -1} for a line of type tu with entries sing
        against all singletons (other than itself).  None if not integral / out of range."""
        rhs = []
        for k in range(4):
            v = Fr(self.lam[k]) * self.pos[tu][k]
            for t in BLOCKS:
                v -= self.pos[t][k] * (self.size[t] - (1 if tu == t else 0))
            for s, S in sing.items():
                if s != tu:
                    v -= self.pos[s][k] * S
            rhs.append(v)
        out = {}
        for t, x in zip(BLOCKS, self._solve(rhs)):
            if x.denominator != 1 or x < 0 or x > self.size[t] - (1 if tu == t else 0):
                return None
            out[t] = int(x)
        return out

    def block_sums(self):
        """Z_tau = sum_s coef[tau][s] z_s from sum_v r_v z_v = 0 and sum_v z_v p_v^T = 0."""
        coef = {t: {} for t in BLOCKS}
        for s in self.single:
            rhs = [-self.pos[s][k] for k in range(4)]
            M = [[self.pos[t][k] for t in BLOCKS] for k in range(4)]
            sol = solve_lin(M, rhs)
            for t, x in zip(BLOCKS, sol):
                coef[t][s] = x
        return coef


def solve_lin(M, b):
    A = [list(map(Fr, row)) + [Fr(bb)] for row, bb in zip(M, b)]
    n = len(A)
    for c in range(n):
        p = next(r for r in range(c, n) if A[r][c] != 0)
        A[c], A[p] = A[p], A[c]
        for r in range(n):
            if r != c and A[r][c] != 0:
                f = A[r][c] / A[c][c]
                A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    return [A[i][n] / A[i][i] for i in range(n)]


def frac_rank_psd(G):
    """(rank, psd) of a symmetric rational matrix by exact LDL^T."""
    A = [[Fr(x) for x in row] for row in G]
    n = len(A)
    rank = 0
    used = [False] * n
    for _ in range(n):
        piv = next((i for i in range(n) if not used[i] and A[i][i] != 0), None)
        if piv is None:
            if any(A[i][j] != 0 for i in range(n) for j in range(n) if not used[i] and not used[j]):
                return rank, False
            break
        if A[piv][piv] < 0:
            return rank, False
        used[piv] = True
        rank += 1
        for i in range(n):
            if used[i]:
                continue
            f = A[i][piv] / A[piv][piv]
            for j in range(n):
                if not used[j]:
                    A[i][j] -= f * A[piv][j]
    return rank, True


def adjugate(Gt):
    k = len(Gt)
    M = [[Fr(x) for x in row] for row in Gt]
    det = Fr(1)
    A = [row[:] + [Fr(int(i == j)) for j in range(k)] for i, row in enumerate(M)]
    for c in range(k):
        p = next(r for r in range(c, k) if A[r][c] != 0)
        if p != c:
            A[c], A[p] = A[p], A[c]
            det = -det
        det *= A[c][c]
        pv = A[c][c]
        A[c] = [x / pv for x in A[c]]
        for r in range(k):
            if r != c and A[r][c] != 0:
                f = A[r][c]
                A[r] = [x - f * y for x, y in zip(A[r], A[c])]
    inv = [row[k:] for row in A]
    adj = [[det * inv[i][j] for j in range(k)] for i in range(k)]
    assert det.denominator == 1 and all(x.denominator == 1 for row in adj for x in row)
    return [[int(x) for x in row] for row in adj], int(det)


def squarefree_split(B):
    s, t, p = 1, B, 2
    while p * p <= t:
        while t % (p * p) == 0:
            t //= p * p
            s *= p
        p += 1
    return t, s


class Base:
    def __init__(self, comps):
        self.comps = comps
        self.sizes = [k + 1 if t == "P" else k for t, k in comps]
        self.nvec = sum(k for _, k in comps)
        self.ncoord = sum(self.sizes)
        self.D = lcm(*self.sizes)
        self.c = sum(1 for t, _ in comps if t == "C")
        offs = np.cumsum([0] + self.sizes)
        self.rng = [(int(offs[i]), int(offs[i + 1])) for i in range(len(comps))]
        self.vstart = [int(v) for v in np.cumsum([0] + [k for _, k in comps])]
        qs = []
        for ci, (t, k) in enumerate(comps):
            a, b = self.rng[ci]
            for i in range(k):
                v = np.zeros(self.ncoord, dtype=np.int64)
                v[a + i] += 2
                v[a + (i + 1) % (b - a)] -= 2
                qs.append(v)
        self.Q = np.array(qs)
        self._walks = None

    def heights(self, steps):
        out = np.zeros(self.ncoord, dtype=np.int64)
        pos = 0
        for ci, (t, k) in enumerate(self.comps):
            a, b = self.rng[ci]
            n = b - a
            s = steps[pos:pos + k]
            pos += k
            if t == "C":
                assert sum(s) == 0
            h = [0]
            for x in s[: n - 1]:
                h.append(h[-1] - x)
            tot = sum(h)
            for i in range(n):
                out[a + i] = self.D * h[i] - (self.D // n) * tot
        return out

    def walks(self):
        if self._walks is None:
            per = []
            for t, k in self.comps:
                per.append([s for s in itertools.product((1, -1), repeat=k) if t == "P" or sum(s) == 0])
            S, Om = [], []
            for combo in itertools.product(*per):
                st = [x for s in combo for x in s]
                S.append(st)
                Om.append(self.heights(st))
            self._walks = (np.array(S, dtype=np.int64), np.array(Om, dtype=np.int64))
        return self._walks

    def gw(self, o1, o2):
        v = int(o1 @ o2)
        assert v % self.D == 0
        return v // self.D

    def maps(self):
        """Index maps on step vectors: rotations of cycles, permutations of equal cycles and of
        equal paths (paths keep their orientation)."""
        comps = self.comps
        groups = {}
        for i, tk in enumerate(comps):
            groups.setdefault(tk, []).append(i)
        out = []
        for combo in itertools.product(*[list(itertools.permutations(v)) for v in groups.values()]):
            mp = {}
            for orig, new in zip(groups.values(), combo):
                for o, n_ in zip(orig, new):
                    mp[o] = n_
            for rots in itertools.product(*[range(k) if t == "C" else [0] for t, k in comps]):
                tgt = np.zeros(self.nvec, dtype=np.int64)
                for i, (tp, k) in enumerate(comps):
                    for j in range(k):
                        tgt[self.vstart[i] + j] = self.vstart[mp[i]] + (j + rots[i]) % k
                out.append((tgt, mp))
        return out


# ------------------------------------------------------------------ configurations of type 2
def t2_graphs(sup):
    """For (0,1,2): relation graphs H on the six type-2 lines (edge = S = -1), PSD Gram, up to
    S3 x (sigma flip).  For (0,1,2,5): the single graph (all S = +1)."""
    t2 = sup.t2
    pairs = [(u, v) for i, u in enumerate(t2) for v in t2[i + 1:]]
    graphs = []
    seen = set()
    for mask in range(1 << len(pairs)):
        E = {pairs[k] for k in range(len(pairs)) if mask >> k & 1}
        ip = {}
        okp = True
        for (u, v) in pairs:
            S = -1 if (u, v) in E else 1
            al = {s: b for b, s in sup.allowed(u, v).items()}
            if S not in al:
                okp = False
                break
            ip[(u, v)] = ip[(v, u)] = al[S]
        if not okp:
            continue
        G = [[5 if u == v else ip[(u, v)] for v in t2] for u in t2]
        rank, psd = frac_rank_psd(G)
        if not psd or rank > CASES[sup.case]["dimV"]:
            continue
        key = canon_graph(sup, E)
        if key in seen:
            continue
        seen.add(key)
        graphs.append(dict(E=sorted(E), ip=ip, rank=rank))
    return graphs


def canon_graph(sup, E):
    """Canonical form under the stabiliser of the base class a: the swap b <-> c (a reflection of
    Pi) and, for (0,1,2), sigma -> -sigma (reflection of w0 with all type-0 lines switched)."""
    best = None
    for perm in ("abc", "acb"):
        for flip in ((1, -1) if sup.name == "012" else (1,)):
            def mp(nm):
                x = perm["abc".index(nm[1])]
                if len(nm) == 2:
                    return "t" + x
                s2 = nm[2] if flip == 1 else ("-" if nm[2] == "+" else "+")
                return "t" + x + s2
            key = tuple(sorted(tuple(sorted((mp(u), mp(v)))) for u, v in E))
            if best is None or key < best:
                best = key
    return best


def t2_rows(sup, H):
    """Row counts of every type-2 line under H; None if some row is impossible."""
    out = {}
    for u in sup.t2:
        sing = {}
        for v in sup.single:
            if v == u:
                continue
            if v in sup.t2:
                sing[v] = sup.allowed(u, v)[H["ip"][(u, v)]]
            else:
                sing[v] = 1
        m = sup.row_counts(u, sing)
        if m is None:
            return None
        out[u] = m
    return out


def class_structures(sup, npaths):
    """Components of a class of size nc with exactly npaths paths (k >= 1 vectors each) and
    even cycles >= 4, listed up to order (paths sorted, cycles sorted)."""
    nc = sup.nc
    res = []

    def cyc(rem, maxp):
        if rem == 0:
            yield ()
            return
        for p in range(min(rem, maxp), 3, -1):
            if p % 2 == 0:
                for rest in cyc(rem - p, p):
                    yield (p,) + rest

    def paths(rem, cnt, maxk):
        if cnt == 0:
            yield ()
            return
        for k in range(min(rem, maxk), 0, -1):
            for rest in paths(rem - k, cnt - 1, k):
                yield (k,) + rest

    for ps in paths(nc, npaths, nc):
        rem = nc - sum(ps)
        if rem < 0:
            continue
        for cy in cyc(rem, rem):
            res.append(tuple(("P", k) for k in ps) + tuple(("C", m) for m in cy))
    return res


# ------------------------------------------------------------------ the problem instance
class Instance:
    """Base class a with given components, type-2 graph H, and the assignment of the
    minus-partners in L_a of the type-2 lines of classes b, c to path ends."""

    def __init__(self, sup, H, rows, comps, assign):
        self.sup, self.H, self.rows, self.comps = sup, H, rows, comps
        self.base = Base(comps)
        b = self.base
        self.dimF = CASES[sup.case]["dimV"] - (b.nvec - b.c)
        self.assign = assign  # name -> class-vector index (path end) for other-class type-2 lines
        self.fx = {}
        for nm in sup.t2:
            if sup.cls(nm) == "a":
                continue
            st = [0] * b.nvec
            if nm in assign:
                st[assign[nm]] = -2
            self.fx[nm] = dict(t=nm, om=b.heights(st), st=st, N=5)
        for nm in self.fx:
            self.fx[nm]["ip"] = {o: (5 if o == nm else H["ip"][(nm, o)]) for o in self.fx}

    def other_gram_ok(self):
        b, D = self.base, self.base.D
        names = list(self.fx)
        G = [[Fr(D * self.fx[u]["ip"][v] - b.gw(self.fx[u]["om"], self.fx[v]["om"]), D) for v in names]
             for u in names]
        rank, psd = frac_rank_psd(G)
        return psd and rank <= self.dimF

    def own_candidates(self):
        """Own-class type-2 lines: walks with the required minus count, W <= 5, consistent F-Gram
        with the other type-2 lines (PSD, rank <= dim F).  For (0,1,2) pairs (t_a+, t_a-)."""
        sup, b, D = self.sup, self.base, self.base.D
        own = [nm for nm in sup.t2 if sup.cls(nm) == "a"]
        S, Om = b.walks()
        W = (Om * Om).sum(axis=1) // D
        minus = (S == -1).sum(axis=1)
        per = {}
        for nm in own:
            want = self.rows[nm]["T1a"]
            js = [int(j) for j in np.nonzero((W <= 5 * D) & (minus == want))[0]]
            ok = []
            for j in js:
                if self._gram_ok({nm: j}):
                    ok.append(j)
            per[nm] = ok
        if len(own) == 1:
            return [{own[0]: j} for j in per[own[0]]]
        u, v = own
        out = []
        for ju in per[u]:
            for jv in per[v]:
                if self._gram_ok({u: ju, v: jv}):
                    out.append({u: ju, v: jv})
        return out

    def _gram_ok(self, ownj):
        b, D = self.base, self.base.D
        S, Om = b.walks()
        vecs = {nm: fv["om"] for nm, fv in self.fx.items()}
        for nm, j in ownj.items():
            vecs[nm] = Om[j]
        names = list(vecs)

        def ip(u, v):
            if u == v:
                return 5
            return self.H["ip"][(u, v)]
        G = [[Fr(D * ip(u, v) - b.gw(vecs[u], vecs[v]), D) for v in names] for u in names]
        rank, psd = frac_rank_psd(G)
        return psd and rank <= self.dimF

    def setup_fixed(self, ownj):
        """All type-2 lines as fixed vectors; references = greedy basis of their F-parts."""
        b, D = self.base, self.base.D
        S, Om = b.walks()
        fx = {nm: dict(fv) for nm, fv in self.fx.items()}
        for nm, j in ownj.items():
            fx[nm] = dict(t=nm, om=Om[j], st=[int(x) for x in S[j]], N=5)
        for nm in fx:
            fx[nm]["ip"] = {o: (5 if o == nm else self.H["ip"][(nm, o)]) for o in fx}
        refs = []
        for nm in sorted(fx, key=lambda s: (self.sup.cls(s) == "a", s)):
            trial = refs + [nm]
            G = [[D * fx[u]["ip"][v] - b.gw(fx[u]["om"], fx[v]["om"]) for v in trial] for u in trial]
            r, _ = frac_rank_psd(G)
            if r == len(trial):
                refs = trial
        return fx, refs


# ------------------------------------------------------------------ nodes and the CP-SAT model
def build_nodes(inst, fx, refs, extra=None, listing=False):
    sup, b, D = inst.sup, inst.base, inst.base.D
    S, Om = b.walks()
    fx = {nm: dict(fv, ip=dict(fv["ip"])) for nm, fv in fx.items()}
    refs = list(refs)
    if extra is not None:
        fx["x2"] = dict(t=extra["t"], om=Om[extra["j"]], N=extra["N"], ip=dict(extra["relB"], x2=extra["N"]))
        for nm in fx:
            if nm != "x2":
                fx[nm]["ip"]["x2"] = extra["relB"][nm]
        refs.append("x2")
    k = len(refs)
    exact = k == inst.dimF
    if not listing:
        assert k in (inst.dimF, inst.dimF - 1), (k, inst.dimF)
    Gt = [[D * fx[r]["ip"][s] - b.gw(fx[r]["om"], fx[s]["om"]) for s in refs] for r in refs]
    A, Delta = adjugate(Gt)
    A = np.array(A, dtype=np.int64)
    assert Delta > 0
    for nm, fv in fx.items():
        fv["Ct"] = np.array([D * fv["ip"][r] - b.gw(fv["om"], fx[r]["om"]) for r in refs], dtype=np.int64)
        Bv = int(Delta * (fv["N"] * D - b.gw(fv["om"], fv["om"])) - fv["Ct"] @ A @ fv["Ct"])
        assert Bv == 0, (nm, Bv)
    W = (Om * Om).sum(axis=1) // D
    g = {nm: (Om @ fv["om"]) // D for nm, fv in fx.items()}
    minus = (S == -1).sum(axis=1)
    nodes = []
    t2names = [nm for nm in fx if nm != "x2"]
    for tname in ("T0", "T1b", "T1c"):
        N = sup.norm[tname]
        AB = {nm: sup.allowed(tname, fv["t"]) for nm, fv in fx.items()}
        for j in np.nonzero(W <= N * D)[0]:
            R = N * D - int(W[j])
            for avec in itertools.product(*[list(AB[r].keys()) for r in refs]):
                Ct = np.array([D * a - int(g[r][j]) for a, r in zip(avec, refs)], dtype=np.int64)
                Bn = int(Delta * R - Ct @ A @ Ct)
                if Bn < 0 or (exact and Bn != 0):
                    continue
                relB = dict(zip(refs, avec))
                ok = True
                for nm, fv in fx.items():
                    if nm in relB:
                        continue
                    hit = [a for a in AB[nm]
                           if D * Delta * a - Delta * int(g[nm][j]) - int(Ct @ A @ fv["Ct"]) == 0]
                    if not hit:
                        ok = False
                        break
                    relB[nm] = hit[0]
                if not ok:
                    continue
                sing = {nm: sup.allowed(tname, nm)[relB[nm]] for nm in t2names}
                for s in sup.single:
                    if s not in sing:
                        sing[s] = 1
                m = sup.row_counts(tname, sing)
                if m is None or m["T1a"] != int(minus[j]):
                    continue
                for e in ([0] if (Bn == 0 or listing) else [1, -1]):
                    nodes.append(dict(t=tname, j=int(j), N=N, Ct=Ct, B=Bn, eps=e, m=m, sing=sing, relB=relB))
    if extra is not None:
        nodes.append(dict(t=extra["t"], j=extra["j"], N=extra["N"], Ct=fx["x2"]["Ct"], B=0, eps=0,
                          m=extra["m"], sing=extra["sing"], relB=dict(extra["relB"]), forced=True))
    ctx = dict(fx=fx, refs=refs, k=k, A=A, Delta=Delta, Gt=Gt, exact=exact)
    return nodes, ctx


def relations(inst, nodes, ctx):
    sup, D = inst.sup, inst.base.D
    S, Om = inst.base.walks()
    n = len(nodes)
    js = np.array([x["j"] for x in nodes])
    Ct = np.array([x["Ct"] for x in nodes], dtype=np.int64).reshape(n, ctx["k"])
    Bv = np.array([x["B"] for x in nodes], dtype=np.int64)
    ev = np.array([x["eps"] for x in nodes], dtype=np.int64)
    tl = ["T0", "T1b", "T1c"]
    ti = np.array([tl.index(x["t"]) for x in nodes])
    Gw = (Om[js] @ Om[js].T) // D
    CAC = (Ct @ ctx["A"]) @ Ct.T
    BB = np.outer(Bv, Bv)
    EE = np.outer(ev, ev)
    Sm = np.zeros((n, n), dtype=np.int8)
    for a1, t1 in enumerate(tl):
        for a2, t2 in enumerate(tl):
            mask = np.outer(ti == a1, ti == a2)
            for a, Sv in sup.allowed(t1, t2).items():
                Y = D * ctx["Delta"] * a - ctx["Delta"] * Gw - CAC
                ok = (Y * Y == BB) & ((Y == 0) | (np.sign(Y) == EE)) & mask
                Sm[ok] = Sv
    np.fill_diagonal(Sm, 0)
    return Sm, ti


def solve_model(inst, nodes, ctx, time_limit, workers, skip=()):
    sup, b, D = inst.sup, inst.base, inst.base.D
    S, Om = b.walks()
    Sm, ti = relations(inst, nodes, ctx)
    tl = ["T0", "T1b", "T1c"]
    nb = [sup.n0, sup.nc, sup.nc]
    N_ = len(nodes)
    req = np.zeros((N_, 3, 2), dtype=np.int64)
    for i, x in enumerate(nodes):
        for bi, nm in enumerate(tl):
            tot = nb[bi] - (1 if x["t"] == nm else 0)
            req[i, bi, 0] = x["m"][nm]
            req[i, bi, 1] = tot - x["m"][nm]
    alive = np.ones(N_, dtype=bool)
    neg, pos = Sm == -1, Sm == 1
    while True:
        bad = np.zeros_like(alive)
        for bi in range(3):
            cols = (alive & (ti == bi)).astype(np.int32)
            bad |= alive & ((neg @ cols) < req[:, bi, 0])
            bad |= alive & ((pos @ cols) < req[:, bi, 1])
        if not bad.any():
            break
        alive &= ~bad
    info = dict(nodes=N_, core=int(alive.sum()))
    if any(x.get("forced") and not alive[i] for i, x in enumerate(nodes)):
        info["status"] = "INFEASIBLE (core, forced node)"
        return info, None
    for bi in range(3):
        if (alive & (ti == bi)).sum() < nb[bi]:
            info["status"] = "INFEASIBLE (core)"
            return info, None
    from ortools.sat.python import cp_model

    idx = np.nonzero(alive)[0]
    n = len(idx)
    S2 = Sm[np.ix_(idx, idx)]
    t2 = ti[idx]
    m = cp_model.CpModel()
    x = [m.NewBoolVar(f"x{i}") for i in range(n)]
    for ii, i in enumerate(idx):
        if nodes[i].get("forced"):
            m.Add(x[ii] == 1)
    for bi in range(3):
        m.Add(sum(x[i] for i in range(n) if t2[i] == bi) == nb[bi])
    ncl = 0
    for i in range(n):
        for j in np.nonzero(S2[i, i + 1:] == 0)[0] + i + 1:
            m.AddBoolOr([x[i].Not(), x[int(j)].Not()])
            ncl += 1
    for ii, i in enumerate(idx):
        if "rows" in skip:
            break
        for bi in range(3):
            for si, Sv in ((0, -1), (1, 1)):
                cols = [jj for jj in range(n) if t2[jj] == bi and S2[ii, jj] == Sv]
                m.Add(sum(x[jj] for jj in cols) == int(req[i, bi, si])).OnlyEnforceIf(x[ii])
    # columns of the type-2 lines
    fx = ctx["fx"]
    t2names = [nm for nm in fx if nm != "x2"]
    for s in ([] if "columns" in skip else t2names):
        ms = inst.rows[s]
        for bi, nm in enumerate(tl):
            cols = [jj for jj in range(n) if t2[jj] == bi and nodes[idx[jj]]["sing"][s] == -1]
            m.Add(sum(x[jj] for jj in cols) == ms[nm])
    om = Om[[nodes[i]["j"] for i in idx]]
    k = ctx["k"]
    Ct = np.array([nodes[i]["Ct"] for i in idx], dtype=np.int64).reshape(n, k)
    Bv = np.array([nodes[i]["B"] for i in idx], dtype=np.int64)
    ev = np.array([nodes[i]["eps"] for i in idx], dtype=np.int64)
    fr = CASES[sup.case]["frame"]
    # walk block of the frame
    T = np.zeros((b.ncoord, b.ncoord), dtype=object)
    for (a0, a1) in b.rng:
        nn = a1 - a0
        for i in range(a0, a1):
            for j in range(a0, a1):
                T[i, j] = fr * D * D * (Fr(int(i == j)) - Fr(1, nn))
    for q in b.Q:
        T -= np.outer(q * D, q * D).astype(object)
    for nm in t2names:
        o = fx[nm]["om"].astype(object)
        T -= np.outer(o, o)
    for p in range(0 if "frame" in skip else b.ncoord):
        for q in range(p, b.ncoord):
            val = Fr(T[p, q])
            assert val.denominator == 1
            terms = [(int(om[i, p] * om[i, q]), i) for i in range(n) if om[i, p] * om[i, q] != 0]
            m.Add(sum(c * x[i] for c, i in terms) == int(val))
    Gt = ctx["Gt"]
    for r in range(0 if "frame" in skip else k):
        for s in range(r, k):
            tgt = fr * D * Gt[r][s] - sum(int(fx[nm]["Ct"][r] * fx[nm]["Ct"][s]) for nm in t2names)
            m.Add(sum(int(Ct[i, r] * Ct[i, s]) * x[i] for i in range(n)) == tgt)
        for p in range(b.ncoord):
            tgt = -sum(int(fx[nm]["om"][p] * fx[nm]["Ct"][r]) for nm in t2names)
            terms = [(int(Ct[i, r] * om[i, p]), i) for i in range(n) if Ct[i, r] * om[i, p] != 0]
            m.Add(sum(c * x[i] for c, i in terms) == tgt)
    if k == inst.dimF - 1:
        m.Add(sum(int(Bv[i]) * x[i] for i in range(n)) == fr * D * ctx["Delta"])
        classes = {}
        for i in range(n):
            if Bv[i] > 0:
                t, s = squarefree_split(int(Bv[i]))
                classes.setdefault(t, []).append((i, s * int(ev[i])))
        for t, mem in classes.items():
            for r in range(k):
                m.Add(sum(int(Ct[i, r]) * c * x[i] for i, c in mem) == 0)
            for p in range(b.ncoord):
                terms = [(c * int(om[i, p]), i) for i, c in mem if om[i, p] != 0]
                if terms:
                    m.Add(sum(cf * x[i] for cf, i in terms) == 0)
            for bi in range(3):
                m.Add(sum(c * x[i] for i, c in mem if t2[i] == bi) == 0)
    # block sums Z_tau = sum_s coef z_s (walk and F coordinates; the beta parts of all type-2
    # lines vanish)
    coef = sup.block_sums()
    for bi, nm in enumerate([] if "blocksum" in skip else tl):
        tom = sum((coef[nm][s] * fx[s]["om"].astype(object) for s in t2names), np.zeros(b.ncoord, dtype=object))
        tct = sum((coef[nm][s] * fx[s]["Ct"].astype(object) for s in t2names), np.zeros(k, dtype=object))
        for p in range(b.ncoord):
            v = Fr(tom[p])
            if v.denominator != 1:
                info["status"] = "INFEASIBLE (block sum not integral)"
                return info, None
            m.Add(sum(int(om[i, p]) * x[i] for i in range(n) if t2[i] == bi and om[i, p] != 0) == int(v))
        for r in range(k):
            v = Fr(tct[r])
            if v.denominator != 1:
                info["status"] = "INFEASIBLE (block sum not integral)"
                return info, None
            m.Add(sum(int(Ct[i, r]) * x[i] for i in range(n) if t2[i] == bi and Ct[i, r] != 0) == int(v))
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_workers = workers
    t0 = time.time()
    st = solver.Solve(m)
    info.update(clauses=ncl, status=solver.StatusName(st), time=round(time.time() - t0, 1))
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = [int(idx[i]) for i in range(n) if solver.Value(x[i])]
    return info, sol


def check_base_sum(inst, fx):
    """sum of L_a = Z_{T1a} = sum_s coef[T1a][s] z_s: walk part must equal sum q, F-part 0."""
    sup, b, D = inst.sup, inst.base, inst.base.D
    coef = sup.block_sums()["T1a"]
    names = [nm for nm in fx if nm != "x2"]
    tom = sum((coef[s] * fx[s]["om"].astype(object) for s in names), np.zeros(b.ncoord, dtype=object))
    if any(Fr(tom[p]) != int(b.Q.sum(axis=0)[p] * D) for p in range(b.ncoord)):
        return False
    # F-part: sum coef_s F(z_s) = 0  <=>  its Gram norm vanishes
    tot = Fr(0)
    for u in names:
        for v in names:
            tot += coef[u] * coef[v] * Fr(D * fx[u]["ip"][v] - b.gw(fx[u]["om"], fx[v]["om"]), D)
    return tot == 0


def enumerate_instances(sup, max_dimF=None, only_struct=None):
    """Yield (H, rows, comps, assign) for base class a."""
    for H in t2_graphs(sup):
        rows = t2_rows(sup, H)
        if rows is None:
            continue
        partners = [nm for nm in sup.t2 if sup.cls(nm) != "a" and rows[nm]["T1a"] == 1]
        assert all(rows[nm]["T1a"] <= 1 for nm in sup.t2 if sup.cls(nm) != "a"), rows
        q = len(partners)
        if q % 2:
            continue
        for comps in class_structures(sup, q // 2):
            if only_struct and comps != only_struct:
                continue
            base = Base(comps)
            dimF = CASES[sup.case]["dimV"] - (base.nvec - base.c)
            if dimF < 0 or (max_dimF is not None and dimF > max_dimF):
                continue
            ends = []
            for ci, (t, k) in enumerate(comps):
                if t == "P":
                    s0 = base.vstart[ci]
                    ends.append((ci, s0))
                    ends.append((ci, s0 + k - 1))
            seen = set()
            for perm in itertools.permutations(range(len(ends)), q):
                assign = {nm: ends[e][1] for nm, e in zip(partners, perm)}
                # each path end slot holds exactly one partner (an isolated vector holds two)
                key = tuple(sorted(assign.items()))
                if key in seen:
                    continue
                seen.add(key)
                yield H, rows, comps, assign


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("case", choices=sorted(CASES))
    ap.add_argument("support", choices=["0125", "012"])
    ap.add_argument("--maxdimF", type=int, default=None)
    ap.add_argument("--struct")
    ap.add_argument("--time", type=float, default=600)
    ap.add_argument("--workers", type=int, default=8)
    ap.add_argument("--dry", action="store_true")
    ap.add_argument("--out")
    args = ap.parse_args()
    sup = Support(args.case, args.support)
    only = None
    if args.struct:
        only = tuple((s[0], int(s[1:])) for s in args.struct.split(","))
    results = []

    def emit(d):
        print(json.dumps(d), flush=True)
        results.append(d)
        if args.out:
            with open(args.out, "w") as fh:
                json.dump(results, fh)

    for H, rows, comps, assign in enumerate_instances(sup, args.maxdimF, only):
        inst = Instance(sup, H, rows, comps, assign)
        head = dict(case=args.case, support=args.support, H=[list(e) for e in H["E"]],
                    struct=[f"{t}{k}" for t, k in comps], assign=assign, dimF=inst.dimF)
        if not inst.other_gram_ok():
            emit(dict(head, status="EXCLUDED (type-2 F-Gram)"))
            continue
        owns = inst.own_candidates()
        good = []
        for ownj in owns:
            fx, refs = inst.setup_fixed(ownj)
            if check_base_sum(inst, fx):
                good.append((ownj, fx, refs))
        if not good:
            emit(dict(head, status="EXCLUDED (no own type-2 lines)", own=len(owns)))
            continue
        # orbit reduction of own lines under the stabiliser of the fixed data
        maps = [(tg, mp) for tg, mp in inst.base.maps()
                if all(np.array_equal(np.array(inst.fx[nm]["st"])[np.argsort(tg)], np.array(inst.fx[nm]["st"]))
                       for nm in inst.fx)]
        S, Om = inst.base.walks()
        widx = {tuple(int(v) for v in s): j for j, s in enumerate(S)}
        seen, reps = set(), []
        for ownj, fx, refs in good:
            key = tuple(sorted(ownj.items()))
            if key in seen:
                continue
            reps.append((ownj, fx, refs))
            for tg, mp in maps:
                img = {}
                for nm, j in ownj.items():
                    st = np.zeros(inst.base.nvec, dtype=np.int64)
                    st[tg] = S[j]
                    img[nm] = widx[tuple(int(v) for v in st)]
                seen.add(tuple(sorted(img.items())))
        emit(dict(head, status="own lines", own=len(owns), good=len(good), orbits=len(reps)))
        if args.dry:
            continue
        for ownj, fx, refs in reps:
            k0 = len(refs)
            tag = dict(head, own={nm: [int(v) for v in S[j]] for nm, j in ownj.items()}, refs=refs)
            if k0 >= inst.dimF - 1:
                nodes, ctx = build_nodes(inst, fx, refs)
                info, sol = solve_model(inst, nodes, ctx, args.time, args.workers) if nodes else (
                    dict(nodes=0, status="INFEASIBLE (no nodes)"), None)
                emit(dict(tag, **info, solution=sol is not None))
                continue
            if k0 < inst.dimF - 2:
                emit(dict(tag, status="SKIPPED (needs more than one node reference)"))
                continue
            listing, lctx = build_nodes(inst, fx, refs, listing=True)
            stab = [tg for tg, mp in maps
                    if all(np.array_equal(S[j][np.argsort(tg)], S[j]) for j in ownj.values())]
            keyr = lambda y: (y["t"], y["j"], tuple(sorted((r, y["relB"][r]) for r in refs)))

            def reps_of(c):
                seen2, out = set(), []
                for y in c:
                    kk = keyr(y)
                    if kk in seen2:
                        continue
                    out.append(y)
                    for tg in stab:
                        st = np.zeros(inst.base.nvec, dtype=np.int64)
                        st[tg] = S[y["j"]]
                        seen2.add((y["t"], widx[tuple(int(v) for v in st)], kk[2]))
                return out
            A_c = reps_of([y for y in listing if y["t"] == "T0" and y["B"] > 0])
            B_c = reps_of([y for y in listing if y["t"] != "T0" and y["B"] > 0])
            zero = {keyr(y) for y in listing if y["t"] == "T0" and y["B"] == 0}
            emit(dict(tag, status="split", caseA=len(A_c), caseB=len(B_c), stab=len(stab)))
            for caseB, cl in ((False, A_c), (True, B_c)):
                for x2 in cl:
                    nodes, ctx = build_nodes(inst, fx, refs, extra=x2)
                    if caseB:
                        nodes = [y for y in nodes if y.get("forced") or y["t"] != "T0" or keyr(y) in zero]
                    info, sol = solve_model(inst, nodes, ctx, args.time, args.workers)
                    emit(dict(tag, **info, caseB=caseB, x2=[x2["t"], x2["j"]], solution=sol is not None))


if __name__ == "__main__":
    main()
