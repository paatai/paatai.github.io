"""Level 2 for the level-1 survivors of 59 lines in R^18.

The three stages of level2.py, level2j.py and level2s.py (written for 74 and 94 lines), in
sequence; only the candidate polynomial and the paths differ.  Input: data/level1_59/<idx>.json
(run_level1_59.py), p = (x + 5)^41 (x - 11) psi(x - 11), n = 59.

  (C) the compatibility graph (eqlines.compat) on the class-filtered deck, its maximal cliques
      and, for each, the LP  sum_{f in C} n_f g_f = h, n >= 0, n_f <= 1 for members without a
      loop ([GSY23, Cor. 4.8]); infeasible cliques get an exact certificate
      (lpcert.verify_farkas_bounded);
  (J) on the members of the LP-feasible cliques of (C): the Jacobi pair graph (eqlines.jacobi)
      with (J6) P(-5) != 0 (otherwise S[ij] has the eigenvalue -5 with multiplicity 40, i.e. 57
      lines in R^17, contradicting N(17) = 48), its maximal cliques and their bounded LPs;
  (S) for every nonempty subset U of an LP-feasible clique of (J): the vertex-star system
      (eqlines.star.StarSystem) with support U, decided exactly.
A candidate is excluded at the first stage that leaves nothing open.

Usage: python3 level2_59.py PSI_FILE [--in=DIR] [--out=DIR] [--max-star=K] [workers] [indices...]
  (indices default to the candidates open after level 1 in --in)
Output: data/level2_59/<idx>.json
"""

import json
import os
import sys
import time
from itertools import combinations
from multiprocessing import Pool

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.compat import Compat, maximal_cliques  # noqa: E402
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.jacobi import PairSpace  # noqa: E402
from eqlines.lpcert import (find_farkas_bounded, find_feasible_bounded,  # noqa: E402
                            integer_certificate, verify_farkas_bounded)
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import coeffs_desc  # noqa: E402
from eqlines.star import StarSystem, poly  # noqa: E402
from run_level1_59 import chi59  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
IN = os.path.join(ROOT, "data", "level1_59")
OUT = os.path.join(ROOT, "data", "level2_59")


def level1_open(L1):
    return L1["F1"] is None and L1["F2"] is None and L1["lp_A"] != "infeasible" \
        and L1["lp_B"] != "infeasible"


def clique_lps(sp, D, h, adj, loop):
    out, feasible = [], []
    for C in sorted(maximal_cliques(adj), key=lambda c: sorted(c)) if adj else []:
        C = sorted(C)
        DC = [D[i] for i in C]
        ub = [not loop[i] for i in C]
        st, _x = find_feasible_bounded(sp, DC, ub)
        entry = {"clique": C, "lp": st}
        if st != "feasible":
            Y = find_farkas_bounded(sp, DC, ub)
            if Y is not None:
                Z = integer_certificate(Y)
                assert verify_farkas_bounded(DC, h, Z, ub)
                entry["cert"] = Z
            elif st == "infeasible":
                entry["lp"] = "infeasible-uncertified"
        if "cert" not in entry:
            feasible.append(C)
        out.append(entry)
    return out, feasible


def stage_c(sp, D, h):
    cp = Compat(sp, D)
    res = {"simple": list(cp.simple), "min_parity_ok": cp.min_parity_ok()}
    if not cp.min_parity_ok():
        res["open_cliques"] = []
        return res
    adj, loop = cp.graph()
    res["edges"] = sorted([a, b] for a in adj for b in adj[a] if a < b)
    res["loops"] = [a for a in sorted(loop) if loop[a]]
    res["cliques"], res["open_cliques"] = clique_lps(sp, D, h, adj, loop)
    return res


def stage_j(sp, D, h, open_c):
    G = [coeffs_to_poly(c) for c in D]
    ps = PairSpace(sp, nonzero_at=[-5])
    members = sorted(set(i for C in open_c for i in C))
    pairs, adj, loop = {}, {a: set() for a in members}, {}
    for ia, a in enumerate(members):
        for b in members[ia:]:
            found = []
            for sigma in (1, -1):
                for psi, P in ps.pair_polys(G[a], G[b], sigma):
                    found.append([sigma, coeffs_desc(psi), coeffs_desc(P)])
            pairs[f"{a},{b}"] = found
            if a == b:
                loop[a] = bool(found)
            elif found:
                adj[a].add(b)
                adj[b].add(a)
    res = {"members": members, "pairs": pairs,
           "edges": sorted([a, b] for a in adj for b in adj[a] if a < b),
           "loops": [a for a in members if loop[a]]}
    res["cliques"], res["open_cliques"] = clique_lps(sp, D, h, adj, loop)
    return res, ps


def stage_s(sp, ps, D, J, max_star):
    G = [coeffs_to_poly(c) for c in D]
    pairs = {}
    for key, found in J["pairs"].items():
        a, b = map(int, key.split(","))
        pairs[(a, b)] = [poly(P) for _sig, _psi, P in found]
    st = StarSystem(sp, ps, G, sp.h, pairs)
    seen, out, skipped = set(), [], []
    for C in J["open_cliques"]:
        if len(C) > max_star:
            skipped.append(C)
            continue
        for r in range(1, len(C) + 1):
            for U in combinations(sorted(C), r):
                if U in seen:
                    continue
                seen.add(U)
                status, data = st.solve(U)
                if status == "not-clique":
                    continue
                out.append({"support": list(U), "status": status,
                            **({"cert": data} if status == "certified" else {})})
    open_ = [e["support"] for e in out if e["status"] != "certified"]
    return {"supports": out, "open_supports": open_, "skipped_cliques": skipped}


def analyse(args):
    idx, psi, din, dout, max_star = args
    out_path = os.path.join(dout, f"{idx}.json")
    if os.path.exists(out_path):
        with open(out_path) as fh:
            return json.load(fh)
    with open(os.path.join(din, f"{idx}.json")) as fh:
        L1 = json.load(fh)
    assert L1["psi"] == psi and level1_open(L1)
    t0 = time.time()
    sp = SpecPoly(chi59(psi))
    h = coeffs_desc(sp.h)
    assert h == L1["h"]
    D = [c for c, ok in zip(L1["deck"], L1["class_ok"]) if ok]
    res = {"idx": idx, "psi": psi, "h": h, "deck": D}
    res["C"] = stage_c(sp, D, h)
    verdict = "excluded (C)" if not res["C"]["open_cliques"] else None
    if verdict is None:
        res["J"], ps = stage_j(sp, D, h, res["C"]["open_cliques"])
        if not res["J"]["open_cliques"]:
            verdict = "excluded (J)"
        else:
            res["S"] = stage_s(sp, ps, D, res["J"], max_star)
            ok = not res["S"]["open_supports"] and not res["S"]["skipped_cliques"]
            verdict = "excluded (S)" if ok else "open"
    res["verdict"] = verdict
    res["t"] = time.time() - t0
    os.makedirs(dout, exist_ok=True)
    with open(out_path + ".tmp", "w") as fh:
        json.dump(res, fh)
    os.replace(out_path + ".tmp", out_path)
    return res


def main():
    from run_level1_59 import load_psis
    din, dout, max_star = IN, OUT, 12
    argv = []
    for a in sys.argv[1:]:
        if a.startswith("--in="):
            din = a[5:]
        elif a.startswith("--out="):
            dout = a[6:]
        elif a.startswith("--max-star="):
            max_star = int(a[11:])
        else:
            argv.append(a)
    psis = load_psis(argv[0])
    workers = int(argv[1]) if len(argv) > 1 else 2
    if len(argv) > 2:
        idxs = [int(a) for a in argv[2:]]
    else:
        idxs = []
        for fn in sorted(os.listdir(din), key=lambda f: int(f.split(".")[0])):
            if fn.endswith(".json"):
                with open(os.path.join(din, fn)) as fh:
                    if level1_open(json.load(fh)):
                        idxs.append(int(fn[:-5]))
    jobs = [(i, psis[i], din, dout, max_star) for i in idxs]
    with Pool(workers) as pool:
        for res in pool.imap_unordered(analyse, jobs):
            c = res["C"]
            j = res.get("J", {})
            s = res.get("S", {})
            print(time.strftime("%H:%M:%S"), res["idx"], f"deck={len(res['deck'])}",
                  f"C:cliques={len(c.get('cliques', []))}/open={len(c['open_cliques'])}",
                  f"J:members={len(j.get('members', []))}/open={len(j.get('open_cliques', []))}",
                  f"S:supports={len(s.get('supports', []))}/open={len(s.get('open_supports', []))}"
                  f"/skipped={len(s.get('skipped_cliques', []))}",
                  res["verdict"], f"{res['t']:.1f}s", flush=True)


if __name__ == "__main__":
    main()
