"""Strip -> remainder enumeration -> decks -> Farkas, for a general case (a, d, n).

This is the pipeline of n421_enum.py / n421_decks.py with the parameters derived
from (a, d, n) instead of hard-coded, used for N = 421 and for negative tests on
line systems that exist (where the true characteristic polynomial must survive).

Hypotheses (checked or supplied):
  * S Seidel of order n, -a of multiplicity exactly n - d;
  * principal submatrices of order n - 1 span R^d as well (supply `rank_drop_impossible`
    after checking N_{1/a}(d-1) < n - 1), so -a has multiplicity n - d - 1 in S[i].
Remainder lattice (shift kappa0 = an odd stripped value):
  n even: Q(x) = prod (x - (lambda - kappa0)) is type 2: 2^i | a_i;
  n odd : 2^{i-1} | a_i, and 2^i | a_i for even i provided F^ is a square mod 2
          (F = the stripped part, see MAIN_RESULT.tex Lemma 4.2); asserted below.

Usage: python3 remainder_case.py a d n [workers]
"""

import json
import os
import sys
import time
from math import isqrt
from multiprocessing import Pool

from flint import fmpq, fmpz_poly

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.deck import SpecPoly, deck  # noqa: E402
from eqlines.lpcert import (find_farkas, find_farkas_vertex, find_feasible,  # noqa: E402
                            integer_certificate)
from eqlines.rr import coeffs_to_poly, enumerate_real_rooted  # noqa: E402
from eqlines.seidel import coeffs_desc  # noqa: E402
from n421_export import chain  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def setup(a, d, n):
    steps, r, P1, P2 = chain(a, d, n)
    stripped = {}
    for k in steps:
        stripped[k] = stripped.get(k, 0) + 1
    kappa0 = max(stripped, key=lambda k: stripped[k]) if stripped else None
    if kappa0 is None:
        raise ValueError("nothing stripped")
    s1 = P1 - r * kappa0
    s2 = P2 - 2 * kappa0 * P1 + r * kappa0 * kappa0
    assert (s1 * s1 - s2) % 2 == 0
    e2 = (s1 * s1 - s2) // 2
    E = [0, 0]
    E[((-a - kappa0) // 2) % 2] += n - d
    for k, e in stripped.items():
        E[((k - kappa0) // 2) % 2] += e
    parity_ok = (n % 2 == 0) or (E[0] % 2 == 0 and E[1] % 2 == 0)
    return dict(a=a, d=d, n=n, steps=steps, stripped=stripped, r=r, kappa0=kappa0,
                c1=-s1, c2=e2, parity_square=parity_ok)


def congr_for(n, square):
    def congr(i, _pref):
        if n % 2 == 0:
            k = i
        else:
            k = i if (i % 2 == 0 and square) else i - 1
        return ({0}, 1 << k)
    return congr


def enum_remainders(cfg):
    if cfg["r"] < 3:
        raise ValueError("remainder degree < 3 not handled here")
    return list(enumerate_real_rooted(cfg["r"], cfg["c1"], cfg["c2"],
                                      congr=congr_for(cfg["n"], cfg["parity_square"])))


def full_poly(cfg, Qc):
    x = fmpz_poly([0, 1])
    p = (x + cfg["a"]) ** (cfg["n"] - cfg["d"])
    for k, e in cfg["stripped"].items():
        p *= (x - k) ** e
    return p * coeffs_to_poly(Qc)(x - cfg["kappa0"])


def deck_box(cfg):
    a, d, n = cfg["a"], cfg["d"], cfg["n"]
    m1 = n - 1 - d
    P1 = a * m1
    P2 = (n - 1) * (n - 2) - a * a * m1
    disc = d * P2 - P1 * P1
    rr = isqrt((d - 1) * disc) + 1
    return fmpq(P1 - rr, d), fmpq(P1 + rr, d)


def analyse(args):
    cfg, idx, Qc = args
    t0 = time.time()
    sp = SpecPoly(full_poly(cfg, Qc))
    Dk = deck(sp, nonzero_at=[-cfg["a"]], root_box=deck_box(cfg))
    res = dict(idx=idx, Q=Qc, delta=sp.delta, mult=sp.mult, h=coeffs_desc(sp.h), deck=Dk,
               factors=[[coeffs_desc(q), e] for q, e in sp.facs])
    if not Dk:
        res["lp"], res["farkas"] = "empty deck", None
    else:
        Y = find_farkas(sp, Dk)
        if Y is None:
            Y = find_farkas_vertex(Dk, coeffs_desc(sp.h))
        res["farkas"] = integer_certificate(Y) if Y is not None else None
        res["lp"] = "infeasible" if Y is not None else find_feasible(sp, Dk)[0]
    res["t"] = time.time() - t0
    return res


def run(a, d, n, workers=6, out=None):
    cfg = setup(a, d, n)
    Qs = enum_remainders(cfg)
    with Pool(workers) as pool:
        results = pool.map(analyse, [(cfg, i, q) for i, q in enumerate(Qs)])
    summary = dict(cfg=cfg, count=len(Qs),
                   excluded=sum(1 for r in results if r["lp"] in ("infeasible", "empty deck")),
                   results=results)
    if out:
        with open(out, "w") as fh:
            json.dump(summary, fh)
    return summary


if __name__ == "__main__":
    a, d, n = map(int, sys.argv[1:4])
    w = int(sys.argv[4]) if len(sys.argv) > 4 else 6
    s = run(a, d, n, w, out=os.path.join(ROOT, "data", f"remainder_{a}_{d}_{n}.json"))
    c = s["cfg"]
    print(f"a={a} d={d} n={n}: stripped {c['stripped']} remainder degree {c['r']} "
          f"(c1={c['c1']}, c2={c['c2']}, parity-square={c['parity_square']}): "
          f"{s['count']} remainders, {s['excluded']} excluded")
    for r in s["results"]:
        if r["lp"] not in ("infeasible", "empty deck"):
            print("  survivor", r["idx"], "mult", r["mult"], "factors", r["factors"], "deck", len(r["deck"]), r["lp"])
