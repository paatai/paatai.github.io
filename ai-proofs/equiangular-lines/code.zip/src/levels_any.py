"""Levels 1-3 for one candidate characteristic polynomial p of a Seidel matrix (any order n).

The stages of run_level1_59.py, level2_59.py and level3_59.py with p given directly:
  (0) for odd n: an even integer eigenvalue has multiplicity <= 1 (as in run_level1_59, (F1)) and
      [GY19, Lemma 3.12] (eqlines.gy312.check_chi_S); for even n: no even integer eigenvalue
      (S - lam I = J - I is invertible mod 2) and [GSY21, Thm 2.5] for p(x - 1);
  (1) Deck(p) with g(v) != 0 for v in --nonzero (eqlines.deck) and exact Farkas certificates
      for sum n_g g = p'/mu (eqlines.lpcert);
  (2) Seidel compatibility with clique LPs, Jacobi pair graph with clique LPs, vertex stars;
  (3) edge systems with triangle types (level3_59.run_support).
--nonzero=-5 is valid when S[T] with the eigenvalue -5 of multiplicity m - |T| + 1 would be
|T| - 1 too many lines for the dimension (for the 59- and 58-line cases: N(17) = 48).

Usage: python3 levels_any.py "FACTORS" [--nonzero=-5] [--out=FILE]
  FACTORS: e.g. "(x+5)^40 (x-5) (x-9)^4 (x-11)^5 (x-13)^8" (linear factors only), or a JSON list
  of descending coefficients.
"""

import json
import re
import sys
import time

from flint import fmpz_poly

sys.path.insert(0, __import__("os").path.dirname(__import__("os").path.abspath(__file__)))
from eqlines.deck import SpecPoly, deck  # noqa: E402
from eqlines.gy312 import check_chi_S  # noqa: E402
from eqlines.lpcert import find_farkas, integer_certificate  # noqa: E402
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import coeffs_desc, seidel_plus_I_condition, shift  # noqa: E402
from level2_59 import stage_c, stage_j, stage_s  # noqa: E402
from level3_59 import pair_types, run_support  # noqa: E402


def parse(s):
    s = s.strip()
    if s.startswith("["):
        return fmpz_poly(list(reversed(json.loads(s))))
    p = fmpz_poly([1])
    for m in re.finditer(r"\(x([+-]\d+)?\)(?:\^(\d+))?", s.replace(" ", "")):
        c = int(m.group(1)) if m.group(1) else 0
        e = int(m.group(2)) if m.group(2) else 1
        p *= fmpz_poly([c, 1]) ** e
    return p


def levels(p, nonzero=(-5,), log=print, max_star=12):
    t0 = time.time()
    sp = SpecPoly(p)
    n = sp.n
    res = {"p": coeffs_desc(p), "factors": [[coeffs_desc(q), m] for q, m in sp.facs]}
    for q, m in sp.facs:
        if q.degree() == 1:
            r = -int(q.coeffs()[0])
            if r % 2 == 0 and (n % 2 == 0 or m >= 2):
                res["verdict"] = f"excluded (0): even eigenvalue {r} with multiplicity {m}, n = {n}"
                return res
    if n % 2 == 1:
        bad = check_chi_S(p)
        if bad is not None:
            res["verdict"] = f"excluded (0): Lemma 3.12 {bad}"
            return res
    elif not seidel_plus_I_condition(shift(p, -1), n):
        res["verdict"] = "excluded (0): type 2"
        return res
    D = deck(sp, nonzero_at=list(nonzero))
    res["deck"] = D
    log(f"deck: {len(D)} members ({time.time() - t0:.1f}s)")
    Y = find_farkas(sp, D)
    if Y is not None:
        res["farkas"] = integer_certificate(Y)
        res["verdict"] = "excluded (1)"
        return res
    h = coeffs_desc(sp.h)
    res["C"] = stage_c(sp, D, h)
    log(f"C: {len(res['C'].get('cliques', []))} cliques, {len(res['C']['open_cliques'])} open")
    if not res["C"]["open_cliques"]:
        res["verdict"] = "excluded (C)"
        return res
    res["J"], ps = stage_j(sp, D, h, res["C"]["open_cliques"])
    log(f"J: {len(res['J']['members'])} members, {len(res['J']['open_cliques'])} open cliques")
    if not res["J"]["open_cliques"]:
        res["verdict"] = "excluded (J)"
        return res
    res["S"] = stage_s(sp, ps, D, res["J"], max_star)
    log(f"S: {len(res['S']['supports'])} supports, open {res['S']['open_supports']}, "
        f"skipped {res['S']['skipped_cliques']}")
    if not res["S"]["open_supports"] and not res["S"]["skipped_cliques"]:
        res["verdict"] = "excluded (S)"
        return res
    if res["S"]["skipped_cliques"]:
        res["verdict"] = "open (S: cliques skipped)"
        return res
    members = sorted(set(a for s in res["S"]["open_supports"] for a in s))
    G = {a: coeffs_to_poly(D[a]) for a in members}
    E0 = pair_types(res, set(members))
    res["L3"] = []
    for U in sorted(res["S"]["open_supports"], key=lambda s: (len(s), s)):
        r = run_support(sp, G, E0, U, log)
        res["L3"].append(r)
        log(f"L3 support {U}: {r['verdict']}")
    res["verdict"] = "excluded (3)" if all(r["verdict"] == "excluded" for r in res["L3"]) else "open"
    res["t"] = time.time() - t0
    return res


def main():
    nonzero = [-5]
    out = None
    args = []
    for a in sys.argv[1:]:
        if a.startswith("--nonzero="):
            nonzero = [int(v) for v in a[10:].split(",") if v]
        elif a.startswith("--out="):
            out = a[6:]
        else:
            args.append(a)
    p = parse(args[0])
    res = levels(p, nonzero)
    print("verdict:", res["verdict"], flush=True)
    if out:
        with open(out, "w") as fh:
            json.dump(res, fh)


if __name__ == "__main__":
    main()
