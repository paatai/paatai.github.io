"""Level-1 analysis of the candidates for 59 equiangular lines in R^18.

Every psi in the input (the union of the shards of src/enum59.py) gives the candidate
    p = chi_S = (x + 5)^41 (x - 11) psi(x - 11)        (n = 59).

(F1) n is odd, so an even integer eigenvalue lam of S has multiplicity at most 1: S - lam I is
     J + I mod 2, whose kernel over GF(2) is spanned by the all-ones vector, so
     rank_Q (S - lam I) >= rank_GF(2) (S - lam I) = n - 1.
(F2) the congruences of [GY19, Lemma 3.12] for chi_{S+I} at odd order 59 (eqlines/gy312.py,
     every k <= 29).
Candidates passing (F1) and (F2) get Deck(p) (eqlines/deck.py) with (D1)-(D3) (n - 1 = 58 is
even, so g(x - 1) must be type 2) and
(D6) g(-5) != 0: otherwise S[i] has the eigenvalue -5 with multiplicity 41, i.e. 58 lines in
     R^17, contradicting N(17) = 48 [GSY23].
Each deck member g is flagged with membership of mu*g mod 2^7 in P_{58,7} (complete: 1024
classes, the bound of [GY19, Cor. 3.4] for even order).  Exact Farkas certificates
(eqlines/lpcert.py) are sought for sum_g n_g g = p'/mu, n_g >= 0, on (A) the full deck and,
if (A) has none, (B) the class-filtered deck.

Usage: python3 run_level1_59.py PSI_FILE [workers] [indices...]
  PSI_FILE: JSON list of psi (descending coefficients), or a .jsonl written by enum59.py.
Output: data/level1_59/<idx>.json
"""

import json
import os
import sys
import time
from multiprocessing import Pool

from flint import fmpz_poly

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.deck import SpecPoly, deck  # noqa: E402
from eqlines.gy312 import check_chi_S  # noqa: E402
from eqlines.lpcert import find_farkas, find_feasible, integer_certificate  # noqa: E402
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import class_key, coeffs_desc  # noqa: E402
from run_level1 import load_classes  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(ROOT, "data", "level1_59")
N, MULT_LOW, KAPPA = 59, 41, 11


def load_psis(path):
    """A .jsonl may still be growing: an unterminated last line is not read."""
    if path.endswith(".jsonl"):
        out = []
        with open(path) as fh:
            for line in fh:
                if not line.endswith("\n"):
                    break
                d = json.loads(line)
                if "psi" in d:
                    out.append(d["psi"])
        return out
    with open(path) as fh:
        return json.load(fh)


def chi59(psi):
    """(x + 5)^41 (x - 11) psi(x - 11) for psi given by descending coefficients."""
    x11 = fmpz_poly([-KAPPA, 1])
    d = len(psi) - 1
    q = fmpz_poly([0])
    for j, cj in enumerate(psi):
        q += cj * x11 ** (d - j)
    p = fmpz_poly([5, 1]) ** MULT_LOW * x11 * q
    assert p.degree() == N
    return p


def even_eigenvalue_violation(sp):
    """(F1): an even integer eigenvalue of multiplicity >= 2, or None."""
    for q, m in sp.facs:
        if q.degree() == 1 and m >= 2:
            r = -int(q.coeffs()[0])
            if r % 2 == 0:
                return [r, m]
    return None


def analyse(args):
    idx, psi, e, out_dir = args
    out_path = os.path.join(out_dir, f"{idx}.json")
    if os.path.exists(out_path):
        return idx, "cached"
    t0 = time.time()
    p = chi59(psi)
    sp = SpecPoly(p)
    res = {"idx": idx, "psi": psi, "class_e": e,
           "factors": [[coeffs_desc(q), m] for q, m in sp.facs],
           "delta": sp.delta, "mult": sp.mult}
    bad = even_eigenvalue_violation(sp)
    res["F1"] = bad
    res["F2"] = check_chi_S(p) if bad is None else None
    if bad is not None:
        msg = f"F1 even eigenvalue {bad[0]} with multiplicity {bad[1]}"
    elif res["F2"] is not None:
        msg = f"F2 {res['F2']}"
    else:
        st = {}
        D = deck(sp, nonzero_at=[-5], stats=st)
        cls = load_classes(N - 1, e)
        flags = [class_key(sp.mu * coeffs_to_poly(c), e) in cls for c in D]
        DB = [c for c, f in zip(D, flags) if f]
        res.update({"h": coeffs_desc(sp.h), "deck": D, "class_ok": flags, "stats": st,
                    "t_deck": time.time() - t0})
        YA = find_farkas(sp, D)
        res["farkas_A"] = integer_certificate(YA) if YA is not None else None
        res["lp_A"] = "infeasible" if YA is not None else find_feasible(sp, D)[0]
        if YA is None:
            YB = find_farkas(sp, DB)
            res["farkas_B"] = integer_certificate(YB) if YB is not None else None
            res["lp_B"] = "infeasible" if YB is not None else find_feasible(sp, DB)[0]
        else:
            res["farkas_B"] = None
            res["lp_B"] = "infeasible(A)"
        msg = f"delta={sp.delta} deck={len(D)}/{len(DB)} A={res['lp_A']} B={res['lp_B']}"
    res["t_total"] = time.time() - t0
    os.makedirs(out_dir, exist_ok=True)
    with open(out_path + ".tmp", "w") as fh:
        json.dump(res, fh)
    os.replace(out_path + ".tmp", out_path)
    return idx, f"{msg} {res['t_total']:.1f}s"


def main():
    e = 7
    out_dir = OUT
    argv = []
    for a in sys.argv[1:]:
        if a.startswith("--e="):
            e = int(a[4:])
        elif a.startswith("--out="):
            out_dir = a[6:]
        else:
            argv.append(a)
    psis = load_psis(argv[0])
    workers = int(argv[1]) if len(argv) > 1 else 2
    idxs = [int(a) for a in argv[2:]] or list(range(len(psis)))
    jobs = [(i, psis[i], e, out_dir) for i in idxs]
    with Pool(workers) as pool:
        for idx, msg in pool.imap_unordered(analyse, jobs):
            print(time.strftime("%H:%M:%S"), idx, msg, flush=True)


if __name__ == "__main__":
    main()
