"""Interlacing test for the 82 candidate characteristic polynomials of 421 lines in R^44.

For each remainder Q (data/n421/Q_candidates.json)
    p(x) = (x+7)^377 (x-59)^16 (x-61)^15 Q(x-59).
Deck members S[i] have order 420.  Since N(43) = 344 < 420, S[i] spans R^44, so -7
has multiplicity exactly 376 in S[i]:  g(-7) != 0 (D6).  The other 44 eigenvalues of
S[i] have sum 7*376 = 2632 and square sum 420*419 - 49*376 = 157556, hence lie in
[(2632 - sqrt(43*5040))/44, (2632 + sqrt(43*5040))/44] which is inside
[2166/44, 3098/44] (D7).  n - 1 = 420 is even, so g(x-1) is type 2 (D3).
Then an exact Farkas certificate is sought for  sum_f n_f g_f = p'/mu, n_f >= 0.

Usage: python3 n421_decks.py [--weak] [workers] [indices...]
Output: data/n421/decks/<idx>.json  (data/n421_weak/decks/ with --weak)
"""

import json
import os
import sys
import time
from math import isqrt
from multiprocessing import Pool

from flint import fmpq, fmpz_poly

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.deck import SpecPoly, deck  # noqa: E402
from eqlines.lpcert import (find_farkas, find_farkas_vertex, find_feasible,  # noqa: E402
                            integer_certificate)
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import coeffs_desc  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
N, D, A = 421, 44, 7
M_LOW, M59, M61 = 377, 16, 15
SUB = "n421_weak" if "--weak" in sys.argv else "n421"


def box():
    m = N - 1 - D
    P1 = A * m
    P2 = (N - 1) * (N - 2) - A * A * m
    disc = D * P2 - P1 * P1
    assert (P1, P2, disc) == (2632, 157556, 5040)
    r = isqrt((D - 1) * disc) + 1  # r >= sqrt(43*5040)
    return fmpq(P1 - r, D), fmpq(P1 + r, D)


def candidate(Qc):
    Q = coeffs_to_poly(Qc)
    x = fmpz_poly([0, 1])
    return (x + 7) ** M_LOW * (x - 59) ** M59 * (x - 61) ** M61 * Q(x - 59)


def analyse(args):
    idx, Qc = args
    out_path = os.path.join(ROOT, "data", SUB, "decks", f"{idx}.json")
    if os.path.exists(out_path):
        return idx, "cached"
    t0 = time.time()
    p = candidate(Qc)
    sp = SpecPoly(p)
    assert sp.n == N
    st = {}
    Dk = deck(sp, nonzero_at=[-A], stats=st, root_box=box())
    t_deck = time.time() - t0
    res = {"idx": idx, "Q": Qc,
           "factors": [[coeffs_desc(q), e] for q, e in sp.facs],
           "delta": sp.delta, "mult": sp.mult, "h": coeffs_desc(sp.h),
           "deck": Dk, "stats": st, "t_deck": t_deck}
    if not Dk:
        res["lp"] = "empty deck"
        res["farkas"] = None
    else:
        Y = find_farkas(sp, Dk)
        res["method"] = "highs+exact"
        if Y is None:
            Y = find_farkas_vertex(Dk, coeffs_desc(sp.h))
            res["method"] = "vertex"
        res["farkas"] = integer_certificate(Y) if Y is not None else None
        res["lp"] = "infeasible" if Y is not None else find_feasible(sp, Dk)[0]
    res["t_total"] = time.time() - t0
    os.makedirs(os.path.dirname(out_path), exist_ok=True)
    with open(out_path + ".tmp", "w") as fh:
        json.dump(res, fh)
    os.replace(out_path + ".tmp", out_path)
    return idx, f"delta={sp.delta} deck={len(Dk)} lp={res['lp']} {res['t_total']:.1f}s"


def main():
    args = [a for a in sys.argv[1:] if a != "--weak"]
    workers = int(args[0]) if args else 6
    with open(os.path.join(ROOT, "data", SUB, "Q_candidates.json")) as fh:
        polys = json.load(fh)["polys"]
    idxs = [int(a) for a in args[1:]] or list(range(len(polys)))
    jobs = [(i, polys[i]) for i in idxs]
    with Pool(workers) as pool:
        for idx, msg in pool.imap_unordered(analyse, jobs):
            print(time.strftime("%H:%M:%S"), idx, msg, flush=True)


if __name__ == "__main__":
    main()
