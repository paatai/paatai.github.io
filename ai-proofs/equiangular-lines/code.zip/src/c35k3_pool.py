"""Run c35k3.py on the undecided second-level leaves of 74 (0,1,5) (4,4,4,4), one leaf per process,
on a fixed number of workers (a scheduler only: every result is a normal c35k3.py output, and
verify/c35k3_coverage.py checks the union of all logs).

A leaf is undecided when it has no INFEASIBLE level-2 record in the leaf logs and not every one of
its third-level leaves has an INFEASIBLE record in the sub-leaf logs (the rules of
c35k3_coverage.py). Order: leaves with some sub-leaf records first (they are split at once), then
case A leaves without case B2 (the ones with a non-empty core) from the highest index down, then
the rest in index order. Each job gets --skip/--skip-sub with the given logs plus every pool
output that exists when it starts (c35k3.py reads them before it writes, so a restarted pool also
skips what an earlier pool run decided).

usage: python3 c35k3_pool.py --workers P --leaf-logs F ... --sub-logs F ... --outdir DIR
                             [--time2 S] [--split-above N] [--time3 S]
"""
import argparse
import glob
import json
import os
import subprocess
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import c35k as K  # noqa: E402
import c35k3 as K3  # noqa: E402


def records(paths):
    for p in paths:
        for line in open(p):
            try:
                yield json.loads(line)
            except json.JSONDecodeError:
                continue


def undecided(leaf_logs, sub_logs, batch=1):
    """The jobs, as lists of leaf indices: one leaf per job, except that the leaves with case B
    or B2 (empty core so far) go in groups of `batch`."""
    lvl2 = set()
    for d in records(leaf_logs):
        if "refs" not in d or "caseB2" not in d:
            continue
        own = d["level2"]["status"] if "level2" in d else d.get("status", "")
        if own.startswith("INFEASIBLE"):
            lvl2.add(K3.leaf_key(d["caseB"], d["refs"], d["caseB2"], d["row2"]))
    subs = set()
    for d in records(sub_logs):
        if "sub" in d and d.get("status", "").startswith("INFEASIBLE"):
            subs.add(K3.sub_key(d["idx"], d["caseB3"], d["j3"], d["row3"]))
    started = {k[0] for k in subs}
    wk = K.Walks("74_19", (4, 4, 4, 4))
    table = K.walk_perm_table((4, 4, 4, 4), wk.St)
    out = []
    for idx, (caseB, refs2, caseB2) in enumerate(K3.second_level(wk, table)):
        if K3.leaf_key(caseB, refs2, caseB2, refs2[1][2]) in lvl2:
            continue
        if idx in started:
            (j1, _, _), (j2, _, _) = refs2
            stab12 = table[(table[:, j1] == j1) & (table[:, j2] == j2)]
            done = True
            for caseB3 in ((False, True) if not (caseB or caseB2) else (True,)):
                seen = set()
                for (j3, N3, row3) in K3.third_refs(wk, refs2, caseB, caseB2, caseB3):
                    k3 = (N3, row3[0], row3[1], int(stab12[:, j3].min()))
                    if k3 in seen:
                        continue
                    seen.add(k3)
                    if K3.sub_key(idx, caseB3, j3, row3) not in subs:
                        done = False
            if done:
                continue
        out.append((idx, caseB, caseB2, idx in started))
    first = [[o[0]] for o in out if o[3]]
    heavy = [[i] for i in sorted((o[0] for o in out if not o[3] and not o[1] and not o[2]),
                                 reverse=True)]
    rest = [o[0] for o in out if not o[3] and (o[1] or o[2])]
    return first + heavy + [rest[i:i + batch] for i in range(0, len(rest), batch)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--workers", type=int, required=True)
    ap.add_argument("--leaf-logs", nargs="+", required=True)
    ap.add_argument("--sub-logs", nargs="*", default=[])
    ap.add_argument("--outdir", required=True, help="per-leaf outputs: IDX.jsonl, IDX.log, IDX.err")
    ap.add_argument("--time2", type=float, default=600)
    ap.add_argument("--split-above", type=int, default=2000)
    ap.add_argument("--time3", type=float, default=900)
    ap.add_argument("--batch", type=int, default=25)
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    pool_logs = lambda ext: sorted(glob.glob(os.path.join(a.outdir, "*." + ext)))
    queue = undecided(a.leaf_logs + pool_logs("jsonl"), a.sub_logs + pool_logs("log"), a.batch)
    print(json.dumps(dict(event="queue", jobs=len(queue), leaves=sum(map(len, queue)),
                          order=queue)), flush=True)
    here = os.path.dirname(os.path.abspath(__file__))
    running = {}
    t_start = time.time()
    while queue or running:
        while queue and len(running) < a.workers:
            job = queue.pop(0)
            base = os.path.join(a.outdir, "-".join(map(str, job)) if len(job) < 3
                                else "%d-%d" % (job[0], job[-1]))
            cmd = [sys.executable, "-u", os.path.join(here, "c35k3.py"), "74_19", "4,4,4,4",
                   "--shard", "0/1", "--only-idx", *map(str, job), "--time2", str(a.time2),
                   "--split-above", str(a.split_above), "--time3", str(a.time3), "--workers", "1",
                   "--skip", *a.leaf_logs, *pool_logs("jsonl"),
                   "--skip-sub", *a.sub_logs, *pool_logs("log"),
                   "--out", base + ".jsonl"]
            p = subprocess.Popen(cmd, cwd=here, stdout=open(base + ".log", "a"),
                                 stderr=open(base + ".err", "a"),
                                 env=dict(os.environ, OMP_NUM_THREADS="1"))
            running[p] = (job, base, time.time())
            print(json.dumps(dict(event="start", job=job, pid=p.pid, left=len(queue))), flush=True)
        time.sleep(2)
        for p in [q for q in running if q.poll() is not None]:
            job, base, t0 = running.pop(p)
            st = {}
            for d in records([base + ".jsonl"]):
                if d.get("idx") in job:
                    st[d["idx"]] = d.get("status")
            print(json.dumps(dict(event="end", job=job, rc=p.returncode, status=st,
                                  missing=[i for i in job if i not in st],
                                  time=round(time.time() - t0, 1))), flush=True)
    print(json.dumps(dict(event="done", time=round(time.time() - t_start, 1))), flush=True)


if __name__ == "__main__":
    main()
