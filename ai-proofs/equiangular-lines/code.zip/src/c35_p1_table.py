"""Summary of program 1 (src/c35*.py, CP-SAT) for candidate #35: status counts per (case, support,
structure) from its logs and result files.

    python3 src/c35_p1_table.py [--json OUT]
"""
import argparse
import glob
import json
import os
import re
from collections import Counter, defaultdict

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def norm_struct(d):
    if "struct" in d:
        return ",".join(d["struct"])
    if "part" in d:
        return ",".join(f"C{k}" for k in d["part"])
    return None


def rows():
    """(case, support, struct, status) from every JSON line of the program 1 logs/results."""
    files = sorted(glob.glob(os.path.join(ROOT, "logs", "c35*.log")) +
                   glob.glob(os.path.join(ROOT, "results", "c35*.json")) +
                   glob.glob(os.path.join(ROOT, "runs", "c35*.json")))
    seen = set()
    for f in files:
        base = os.path.basename(f)
        # c35ref_*: first reference model, superseded by c35k (same cases, all decided there)
        if base.startswith(("c35_cert", "c35ref_")):
            continue
        sup_hint = "015"
        if base.startswith("c35t"):
            sup_hint = "0125"
        try:
            if f.endswith(".json"):
                data = json.load(open(f))
                recs = data if isinstance(data, list) else []
            else:
                recs = []
                for line in open(f):
                    line = line.strip()
                    if line.startswith("{"):
                        try:
                            recs.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        except (OSError, json.JSONDecodeError):
            continue
        for d in recs:
            if not isinstance(d, dict) or "status" not in d:
                continue
            st = norm_struct(d)
            if st is None:
                continue
            # the same record can be in a log and in a result file
            key = json.dumps({k: v for k, v in d.items() if k not in ("time", "solution")},
                             sort_keys=True)
            if key in seen:
                continue
            seen.add(key)
            case = d.get("case", "?").split("_")[0]
            sup = d.get("support", sup_hint)
            yield base, case, sup, st, d["status"]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json")
    args = ap.parse_args()
    table = defaultdict(Counter)
    srcs = defaultdict(set)
    for base, case, sup, st, status in rows():
        key = (case, sup, st)
        s = re.sub(r"\s*\(.*", "", status) if status.startswith("INFEASIBLE") else status
        table[key][s] += 1
        srcs[key].add(base)
    out = []
    for key in sorted(table):
        c = table[key]
        bad = {k: v for k, v in c.items() if not (k.startswith("INFEASIBLE") or k.startswith("EXCLUDED")
                                                   or k in ("own lines", "split"))}
        out.append(dict(case=key[0], support=key[1], struct=key[2], counts=dict(c), open=bad,
                        files=sorted(srcs[key])))
        print(f"{key[0]:3} {key[1]:5} {key[2]:22} {dict(c)}  {'OPEN ' + str(bad) if bad else ''}  "
              f"[{', '.join(sorted(srcs[key]))}]")
    if args.json:
        json.dump(out, open(args.json, "w"), indent=1)


if __name__ == "__main__":
    main()
