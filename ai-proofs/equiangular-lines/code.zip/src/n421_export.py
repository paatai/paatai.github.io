"""Export the n = 421 data for the independent GP verifier (verify/n421.gp).

Writes data/n421/export.gp (data/n421_weak/export.gp with --weak) defining
  CHAIN = [kappa_1, kappa_2, ...]   the stripping steps, in order (each step strips one
                                    eigenvalue kappa_j; the forcing inequality is re-checked)
  CERTS = [[Q, Y, decksize], ...]   Q descending coefficients of the remainder,
                                    Y the integer Farkas certificate (descending coefficients)
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from strip_scan import forced  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def chain(a, d, n):
    m = n - d
    gamma = n % 2
    P1, P2, r = a * m, n * (n - 1) - a * a * m, d
    steps = []
    changed = True
    lo, hi = P1 // d - 15, P1 // d + 15
    while changed and r > 0:
        changed = False
        for kappa in range(lo, hi + 1):
            if kappa % 2 == 0 or kappa <= -a:
                continue
            while r > 0 and forced(P2 - 2 * kappa * P1 + r * kappa * kappa, r, gamma):
                steps.append(kappa)
                r, P1, P2 = r - 1, P1 - kappa, P2 - kappa * kappa
                changed = True
    return steps, r, P1, P2


def main():
    sub = "n421_weak" if "--weak" in sys.argv else "n421"
    steps, r, P1, P2 = chain(7, 44, 421)
    assert (steps.count(59), steps.count(61), r, P1, P2) == (16, 15, 13, 780, 46836), (steps, r, P1, P2)
    with open(os.path.join(ROOT, "data", sub, "Q_candidates.json")) as fh:
        count = json.load(fh)["count"]
    certs = []
    for idx in range(count):
        with open(os.path.join(ROOT, "data", sub, "decks", f"{idx}.json")) as fh:
            res = json.load(fh)
        assert res["farkas"] is not None
        certs.append((res["Q"], res["farkas"], len(res["deck"])))
    out = os.path.join(ROOT, "data", sub, "export.gp")
    with open(out, "w") as fh:
        fh.write("CHAIN = [" + ",".join(map(str, steps)) + "];\n")
        fh.write("CERTS = [" + ",\\\n".join(
            "[[" + ",".join(map(str, q)) + "],[" + ",".join(map(str, y)) + "]," + str(k) + "]"
            for q, y, k in certs) + "];\n")
    print("wrote", out, "chain length", len(steps))


if __name__ == "__main__":
    main()
