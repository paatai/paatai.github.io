"""Level 3 for the level-2 survivors of 59 lines in R^18 (eqlines.triples).

Input: data/level2_59/<shard>/<idx>.json (level2_59.py) with verdict "open".  For every open
support U of stage (S), starting from the pair types of stage (J) between members of U:
  repeat
    for every edge type (a, b, u) (a <= b in U): decide its edge system on U; if an exact Farkas
      vector certifies it infeasible, delete u from the pair types of (a, b);
    if some pair a != b of U has no pair type left, U is excluded;
    the vertex-star system (eqlines.star.ResolventStar) of U with the remaining pair types is
      decided as well (infeasible: U excluded);
  until nothing changes; then the same with every LP-feasible edge system decided over the
  integers (eqlines.farkas.branch_and_bound: an exact Farkas vector at every leaf), and the LP
  loop again after any deletion.
The deletions are recorded in order (each certificate refers to the pair types left at that
point), so a replay can re-verify every step.
Stage R, for the cliques that stage (S) skipped (too many supports): in rounds, every member f
whose relaxed vertex-star system (eqlines.star.RelaxedStar: f present, the other members of the
current clique free) has an exact box-form Farkas vector is removed; the supports inside the
clique avoid the removed members, so the clique is excluded when no member is left.
A candidate is excluded if every open support is and every skipped clique is emptied by stage R.

Usage: python3 level3_59.py [L2_FILE...] [--dir=L2_DIR] [--out=DIR]
  --dir: every file of L2_DIR with verdict "open"; files already in DIR are skipped.
"""

import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import coeffs_desc  # noqa: E402
from eqlines.star import RelaxedStar, ResolventStar, poly  # noqa: E402
from eqlines.triples import Level3, key  # noqa: E402
from run_level1_59 import chi59  # noqa: E402


def pair_types(L2, members):
    E = {}
    for k, found in L2["J"]["pairs"].items():
        a, b = map(int, k.split(","))
        if a in members and b in members:
            uniq = {}
            for sig, psi, _P in found:
                u = sig * poly(psi)
                uniq[key(u)] = u
            E[(min(a, b), max(a, b))] = [uniq[k2] for k2 in sorted(uniq)]
    return E


def run_support(sp, G, E0, U, log, integer=True):
    U = sorted(U)
    E = {k: list(v) for k, v in E0.items() if k[0] in U and k[1] in U}
    steps = []
    use_int = False
    while True:
        changed = False
        L = Level3(sp, {a: G[a] for a in U}, E)
        for a in U:
            for b in U:
                if b < a:
                    continue
                for u in list(E.get((a, b), [])):
                    st, data = L.solve_edge(a, b, u, support=U, integer=use_int)
                    if st == "certified":
                        E[(a, b)] = [w for w in E[(a, b)] if key(w) != key(u)]
                        step = {"edge": [a, b, coeffs_desc(u)], "ntri": data["ntri"]}
                        if "y" in data:
                            step["y"] = data["y"]
                        else:
                            step["tree"] = data["tree"]
                        steps.append(step)
                        changed = True
                        L = Level3(sp, {c: G[c] for c in U}, E)
                        log(f"    U={U}: edge ({a},{b}) type {len(steps)} certified "
                            f"({'LP' if 'y' in data else 'integer'}; {data['ntri']} triangle types)")
                    elif st.startswith("unknown"):
                        log(f"    U={U}: edge ({a},{b}) {st} (kept)")
        for i, a in enumerate(U):
            for b in U[i + 1:]:
                if not E.get((a, b)):
                    return {"support": U, "verdict": "excluded", "reason": f"no pair type ({a},{b})",
                            "steps": steps}
        rs = ResolventStar(sp, [G.get(c, None) for c in range(max(U) + 1)], sp.h,
                           {k: v for k, v in E.items()})
        status, data = rs.solve(U)
        if status == "certified":
            return {"support": U, "verdict": "excluded", "reason": "vertex stars", "star_cert": data,
                    "steps": steps}
        if not changed:
            if integer and not use_int:
                use_int = True
                continue
            left = {f"{a},{b}": [coeffs_desc(u) for u in v] for (a, b), v in E.items()}
            return {"support": U, "verdict": "open", "steps": steps, "pair_types_left": left}
        use_int = False


def stage_r(sp, G, E, K, log):
    """Remove, in rounds, every member f of the clique K whose relaxed vertex-star system on the
    members left is certified infeasible; the rounds are recorded for the replay."""
    alive = sorted(K)
    rounds = []
    while alive:
        Gl = [G.get(c) for c in range(max(alive) + 1)]
        rs = RelaxedStar(sp, Gl, sp.h, {k: v for k, v in E.items() if k[0] in alive and k[1] in alive})
        dead = []
        for f in alive:
            st, data = rs.solve_relaxed(alive, f)
            if st == "certified":
                dead.append({"f": f, "y": data["y"]})
        if not dead:
            break
        rounds.append({"alive": alive, "dead": dead})
        gone = {d["f"] for d in dead}
        alive = [g for g in alive if g not in gone]
        log(f"    R: clique of {len(K)}: removed {sorted(gone)}, {len(alive)} left")
    return {"clique": sorted(K), "rounds": rounds, "alive": alive}


def analyse(path, out_dir):
    with open(path) as fh:
        L2 = json.load(fh)
    t0 = time.time()
    tag = os.path.splitext(os.path.basename(path))[0]
    sp = SpecPoly(chi59(L2["psi"]))
    skipped = L2["S"]["skipped_cliques"]
    supports = [s for s in L2["S"]["open_supports"]]
    members = sorted(set(a for s in supports for a in s) | set(a for C in skipped for a in C))
    G = {a: coeffs_to_poly(L2["deck"][a]) for a in members}
    E0 = pair_types(L2, set(members))
    lines = []

    def log(msg):
        lines.append(msg)
        print(msg, flush=True)

    res = {"source": path, "psi": L2["psi"], "factors": [[coeffs_desc(q), m] for q, m in sp.facs],
           "supports": []}
    if skipped:
        res["R"] = []
        for K in skipped:
            r = stage_r(sp, G, E0, K, log)
            res["R"].append(r)
            log(f"  {tag} clique of {len(K)} (stage R): {len(r['rounds'])} rounds, "
                f"{len(r['alive'])} members left")
    for U in sorted(supports, key=lambda s: (len(s), s)):
        r = run_support(sp, G, E0, U, log)
        res["supports"].append(r)
        log(f"  {tag} support {U}: {r['verdict']} ({len(r['steps'])} edge types deleted"
            + (f"; {r['reason']}" if r["verdict"] == "excluded" else "") + ")")
    ok_s = all(r["verdict"] == "excluded" for r in res["supports"])
    ok_r = all(not r["alive"] for r in res.get("R", []))
    res["verdict"] = "excluded" if ok_s and ok_r else ("open" if not ok_s else "open (R)")
    res["t"] = time.time() - t0
    os.makedirs(out_dir, exist_ok=True)
    out = os.path.join(out_dir, os.path.basename(path))
    with open(out + ".tmp", "w") as fh:
        json.dump(res, fh)
    os.replace(out + ".tmp", out)
    return res


def main():
    out_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data",
                           "level3_59")
    paths = []
    for a in sys.argv[1:]:
        if a.startswith("--out="):
            out_dir = a[6:]
        elif a.startswith("--dir="):
            d = a[6:]
            for fn in sorted(os.listdir(d), key=lambda f: int(f.split(".")[0])):
                if fn.endswith(".json"):
                    with open(os.path.join(d, fn)) as fh:
                        if json.load(fh).get("verdict") == "open":
                            paths.append(os.path.join(d, fn))
        else:
            paths.append(a)
    paths = [p for p in paths if not os.path.exists(os.path.join(out_dir, os.path.basename(p)))]
    for p in paths:
        res = analyse(p, out_dir)
        print(time.strftime("%H:%M:%S"), p, res["verdict"], f"{res['t']:.1f}s", flush=True)


if __name__ == "__main__":
    main()
