#!/bin/bash
# As pipe59.sh, but on the shards of verify/enum59.gp (faster than enum59.py) once each is complete,
# converted by gp2jsonl.py (which also checks that the leaves of enum59.py so far are a prefix, so
# the per-index caches in data/level1_59/s<s> and data/level2_59/s<s> serve both programs).
# Workers per stage: the number in ../runs/pipe59_workers (default 2), read on every pass.
cd "$(dirname "$0")"
N=16
mkdir -p ../logs/level59
while true; do
  W=$(cat ../runs/pipe59_workers 2>/dev/null || echo 2)
  complete=1
  for s in $(seq 0 $((N - 1))); do
    g=../runs/enum59_gp/gp_s${s}of${N}.txt
    f=../runs/enum59_gp/gp_s${s}of${N}.jsonl
    if [ ! -f $f ]; then
      if [ -f $g ] && grep -q '^summary' $g; then
        python3 gp2jsonl.py $g $f ../runs/enum59/l312_s${s}of${N}.jsonl >> ../logs/level59/convert.log 2>&1 \
          || { rm -f $f; complete=0; continue; }
      else
        complete=0; continue
      fi
    fi
    mkdir -p ../data/level1_59/s$s ../data/level2_59/s$s
    python3 run_level1_59.py $f $W --out=../data/level1_59/s$s >> ../logs/level59/l1_s$s.log 2>&1
    python3 level2_59.py $f --in=../data/level1_59/s$s --out=../data/level2_59/s$s $W \
      >> ../logs/level59/l2_s$s.log 2>&1
  done
  echo "$(date -u +%H:%M:%S) pass done complete=$complete W=$W" >> ../logs/level59/pipe.log
  [ $complete = 1 ] && break
  sleep 120
done
