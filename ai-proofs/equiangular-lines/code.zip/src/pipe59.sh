#!/bin/bash
# Runs run_level1_59.py (Lemma 3.12 in full, the even-eigenvalue rule, level 1) and level2_59.py on
# the leaves of every shard of enum59.py --l312 as they appear (both cache their results by index
# within the shard file, which only grows), until all 16 shards are complete and processed.
cd "$(dirname "$0")"
N=16
mkdir -p ../logs/level59
while true; do
  complete=1
  for s in $(seq 0 $((N - 1))); do
    f=../runs/enum59/l312_s${s}of${N}.jsonl
    if [ ! -f $f ]; then complete=0; continue; fi
    grep -q '"summary"' $f || complete=0
    mkdir -p ../data/level1_59/s$s ../data/level2_59/s$s
    python3 run_level1_59.py $f 1 --out=../data/level1_59/s$s >> ../logs/level59/l1_s$s.log 2>&1
    python3 level2_59.py $f --in=../data/level1_59/s$s --out=../data/level2_59/s$s 1 \
      >> ../logs/level59/l2_s$s.log 2>&1
  done
  echo "$(date -u +%H:%M:%S) pass done complete=$complete" >> ../logs/level59/pipe.log
  [ $complete = 1 ] && break
  sleep 300
done
