"""Relaxed CP-SAT model for candidate #35, U = (0, 1, 5), any cycle partition of L_a.

The F-part (dimension c - 1) of each vector is not modelled; a walk vector may carry several
F-parts, so it gets an integer multiplicity n_x.  Constraints (all necessary):
  * sum n_x = 24 over type-0 walk vectors (N = 9), 32 over type-1 walk vectors (N = 8);
  * walk frame  sum n_x omega_x omega_x^T = 40 P_a - Lap_a  (exact);
  * F trace     sum n_x (N_x - W_x) = 40 (c - 1);
  * zero sums of omega over type 0 and over type 1;
  * Cauchy-Schwarz on F-parts: two used vectors x, y need an allowed inner product a with
    (a - <omega_x, omega_y>)^2 <= (N_x - W_x)(N_y - W_y) (also for two copies of one walk);
  * partner counts, relaxed: a used x needs, for each required relation a, enough weight on
    partners y for which a is CS-possible.
"""
import sys
import time
from math import lcm

import numpy as np
from ortools.sat.python import cp_model

from c35_core import NEED0, NEED1
from walks35 import gram_D, walk_vectors


def build_relaxed(part):
    D, H, Sm, St = walk_vectors(part)
    G = gram_D(part, H, Sm)
    W = np.diag(G).copy()
    js, Ns = [], []
    for N in (9, 8):
        sel = np.nonzero(W <= N * D)[0]
        js += list(sel)
        Ns += [N] * len(sel)
    js, Ns = np.array(js), np.array(Ns)
    Gn = G[np.ix_(js, js)]
    R = Ns * D - W[js]          # D (N - W)
    RR = np.outer(R, R)
    t0 = Ns == 9
    poss = {}
    for a in (1, -3, 2, -2, 0, -4):
        X = D * a - Gn
        ok = X * X <= RR
        if a in (1, -3):
            ok &= np.outer(t0, t0)
        elif a in (0, -4):
            ok &= np.outer(~t0, ~t0)
        else:
            ok &= ~np.outer(t0, t0)
        poss[a] = ok
    return dict(D=D, js=js, Ns=Ns, t0=t0, poss=poss, H=H, Sm=Sm, R=R, G=Gn)


def relaxed_core(g):
    """Prune walk vectors that cannot meet the relaxed partner counts even using every
    other surviving walk vector with multiplicity up to 24 / 32."""
    t0, poss = g["t0"], g["poss"]
    alive = np.ones(len(t0), dtype=bool)
    while True:
        bad = np.zeros_like(alive)
        for mask, need in ((t0, NEED0), (~t0, NEED1)):
            for a, to0, k in need:
                cols = alive & (t0 if to0 else ~t0)
                deg = poss[a][:, cols].sum(axis=1)
                bad |= alive & mask & (deg == 0)
        if not bad.any():
            return alive
        alive &= ~bad


def model(part, time_limit=600.0, workers=8):
    g = build_relaxed(part)
    alive = relaxed_core(g)
    idx = np.nonzero(alive)[0]
    n = len(idx)
    D = g["D"]
    c = len(part)
    t0 = g["t0"][idx]
    poss = {a: g["poss"][a][np.ix_(idx, idx)] for a in g["poss"]}
    H = g["H"][g["js"][idx]]
    Sm = g["Sm"][g["js"][idx]]
    om = D * H.copy()
    off = 0
    for i, mi in enumerate(part):
        om[:, off:off + mi] -= (D // mi) * Sm[:, [i]]
        off += mi
    R = g["R"][idx]
    m = cp_model.CpModel()
    nx = [m.NewIntVar(0, 24 if t0[i] else 32, f"n{i}") for i in range(n)]
    bx = [m.NewBoolVar(f"b{i}") for i in range(n)]
    for i in range(n):
        m.Add(nx[i] >= 1).OnlyEnforceIf(bx[i])
        m.Add(nx[i] == 0).OnlyEnforceIf(bx[i].Not())
        anyself = any(poss[a][i, i] for a in poss)
        if not anyself:
            m.Add(nx[i] <= 1)
    m.Add(sum(nx[i] for i in range(n) if t0[i]) == 24)
    m.Add(sum(nx[i] for i in range(n) if not t0[i]) == 32)
    anyp = np.zeros((n, n), dtype=bool)
    for a in poss:
        anyp |= poss[a]
    npairs = 0
    for i in range(n):
        for j in range(i + 1, n):
            if not anyp[i, j]:
                m.AddBoolOr([bx[i].Not(), bx[j].Not()])
                npairs += 1
    for i in range(n):
        need = NEED0 if t0[i] else NEED1
        for a, to0, k in need:
            cols = [j for j in np.nonzero(poss[a][i])[0] if t0[j] == to0]
            selfw = 1 if poss[a][i, i] else 0
            # partners other than x itself: n_x - 1 copies of x when a is possible for (x, x)
            m.Add(sum(nx[j] for j in cols) - selfw >= k).OnlyEnforceIf(bx[i])
    Pa = np.zeros((16, 16))
    Lap = np.zeros((16, 16))
    off = 0
    for mi in part:
        Pa[off:off + mi, off:off + mi] = np.eye(mi) - 1.0 / mi
        for k in range(mi):
            e = np.zeros(16)
            e[off + k], e[off + (k + 1) % mi] = 2, -2
            Lap += np.outer(e, e)
        off += mi
    T = D * D * (40 * Pa - Lap)
    Ti = np.rint(T).astype(np.int64)
    assert np.allclose(T, Ti)
    for p in range(16):
        for q in range(p, 16):
            terms = [(int(om[i, p] * om[i, q]), nx[i]) for i in range(n) if om[i, p] * om[i, q] != 0]
            m.Add(sum(cf * v for cf, v in terms) == int(Ti[p, q]))
    m.Add(sum(int(R[i]) * nx[i] for i in range(n)) == 40 * (c - 1) * D)
    for p in range(16):
        m.Add(sum(int(om[i, p]) * nx[i] for i in range(n) if t0[i]) == 0)
        m.Add(sum(int(om[i, p]) * nx[i] for i in range(n) if not t0[i]) == 0)
    print(part, "relaxed nodes", n, "(type0", int(t0.sum()), ") exclusion clauses", npairs, flush=True)
    solver = cp_model.CpSolver()
    solver.parameters.max_time_in_seconds = time_limit
    solver.parameters.num_workers = workers
    t = time.time()
    st = solver.Solve(m)
    print(part, "status", solver.StatusName(st), "time", round(time.time() - t, 1), flush=True)
    sol = None
    if st in (cp_model.OPTIMAL, cp_model.FEASIBLE):
        sol = {int(idx[i]): solver.Value(nx[i]) for i in range(n) if solver.Value(nx[i])}
    return solver.StatusName(st), sol, g


if __name__ == "__main__":
    tl = float(sys.argv[1]) if len(sys.argv) > 1 else 600
    for p in sys.argv[2:] or ["8,8", "12,4", "10,6"]:
        model(tuple(int(x) for x in p.split(",")), time_limit=tl)
