"""Generate the LaTeX appendix tables of MAIN_RESULT.tex from the data files.

  tables/n421_candidates.tex : the 82 candidates for 421 lines in R^44
  tables/thmU_rows.tex       : the Theorem U table (a <= 13)
"""

import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "verify"))

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def poly_tex(desc):
    deg = len(desc) - 1
    terms = []
    for i, c in enumerate(desc):
        e = deg - i
        if c == 0:
            continue
        sgn = "-" if c < 0 else "+"
        a = abs(c)
        if e == 0:
            body = str(a)
        else:
            coef = "" if a == 1 else str(a)
            body = coef + ("x" if e == 1 else f"x^{{{e}}}")
        terms.append((sgn, body))
    s = ("-" if terms[0][0] == "-" else "") + terms[0][1]
    for sgn, body in terms[1:]:
        s += f" {sgn} {body}"
    return s


def n421_table():
    rows = []
    for idx in range(82):
        with open(os.path.join(ROOT, "data", "n421", "decks", f"{idx}.json")) as fh:
            r = json.load(fh)
        ints, others = [], []
        for q, e in r["factors"]:
            if len(q) == 2:
                lam = -q[1]
                if lam in (-7,):
                    continue
                ints.append((lam, e))
            else:
                others.append((q, e))
        ints.sort()
        ip = ", ".join(f"{lam}" + (f"^{{{e}}}" if e > 1 else "") for lam, e in ints)
        op = ", ".join(f"$({poly_tex(q)})" + (f"^{{{e}}}" if e > 1 else "") + "$" for q, e in others)
        Ymax = max(len(str(abs(y))) for y in r["farkas"])
        rows.append(f"{idx} & ${ip}$ & {op if op else '--'} & {r['delta']} & {len(r['deck'])} & {Ymax} \\\\")
    return "\n".join(rows)


def thmU_table():
    from c1_uniform import table_C2
    rows = []
    for a, d, R, n0, k, s, T, es, low in table_C2():
        rows.append(f"{a} & {d} & {R:.3f} & {n0} & {k} & {s} & {T} & {es} \\\\")
    return "\n".join(rows)


N421_HEAD = r"""\begin{longtable}{rlp{6.2cm}rrr}
\caption{Candidates $\chi_S=(x+7)^{377}(x-59)^{16}(x-61)^{15}Q(x-59)$.}\label{tab:cand}\\
\toprule
\# & integer eigenvalues & other factors & $\delta$ & deck & $|Y|$ \\
\midrule
\endfirsthead
\toprule
\# & integer eigenvalues & other factors & $\delta$ & deck & $|Y|$ \\
\midrule
\endhead
\bottomrule
\endlastfoot
"""

THMU_HEAD = r"""\begin{longtable}{rrrrrrrr}
\caption{Excluded top values of Proposition~\ref{prop:U}.}\label{tab:U}\\
\toprule
$a$ & $d$ & $R$ & $n_0$ & $\kappa$ & $s$ & $T$ & $\eta^*$ \\
\midrule
\endfirsthead
\toprule
$a$ & $d$ & $R$ & $n_0$ & $\kappa$ & $s$ & $T$ & $\eta^*$ \\
\midrule
\endhead
\bottomrule
\endlastfoot
"""


def main():
    out = os.path.join(ROOT, "tables")
    os.makedirs(out, exist_ok=True)
    with open(os.path.join(out, "n421_candidates.tex"), "w") as fh:
        fh.write(N421_HEAD + n421_table() + "\n\\end{longtable}\n")
    with open(os.path.join(out, "thmU_rows.tex"), "w") as fh:
        fh.write(THMU_HEAD + thmU_table() + "\n\\end{longtable}\n")
    print("tables written to", out)


if __name__ == "__main__":
    main()
