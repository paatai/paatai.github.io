"""Program 1's level-2 and level-3 certificates for 59 lines in R^18, exported in a semantic form
that does not depend on program 1's internal orders, with an exact replay self-check.  The
export is the input of the second program (verify/lv23_59.gp).

Members are numbered by their position in the sorted class-filtered deck (descending coefficient
lists, lexicographic).  Polynomials are descending coefficient lists; rationals are strings.

Level 2 (src/level2_59.py):
  C: compatibility edges and loops, maximal cliques; a certified clique K carries Z (integers, over
     the descending coefficients of h) with g.Z >= 0 for members of K with a loop and
     h.Z + sum_{members of K without a loop} max(0, -g.Z) < 0 (n_g <= 1 without a loop);
  J: pair polynomials [sigma, psi, P] for each pair of members (psi = adj(xI - S)_ij / mu with
     leading coefficient sigma = S_ij, chi_{S[ij]} = mu2 P), edges, loops, cliques as in C;
  S: per support U, the star system of eqlines.star.StarSystem with the pair types P:
       ["E1", x]     sum_{g in U, loop} (n_g - 1) g(x) = h(x) - sum_{g in U} g(x)
       ["E2", f, g]  sum_P m(f, g, P) - [loop g] (n_g - 1) = 1 - [f = g]
       ["E3", f, x]  sum_{g, P} m(f, g, P) P(x) = H_f(x),  H_f = (mu g_f)' / mu2
     at x in (-6, ..., delta - 7) for E1 and (-6, ..., deg P - 6) for E3; variables n_g - 1 >= 0
     (loop members), m(f, g, P) >= 0.
Level 3 (src/level3_59.py), per open support U: the deleted edge types in order with their
certificates, and the final reason ("no pair type (a,b)", or the vertex-star system of
eqlines.star.ResolventStar: rows E1, E2 as above and
       ["L", f, x]       sum_{g, w} m(f, g, w) w(x) = x g_f(x) - Min(x)
       ["Qd", f, x, y]   sum m(f, g, w) w(x) w(y) = DD(g_f)(x, y) - g_f(x) g_f(y)   (x <= y)
     at x, y in P = (-6, ..., delta - 7), with the pair types w = psihat left at that point).
  Edge system of (a, b, u) on U (eqlines.triples.Level3.edge_system), variables
       ["n", h]                n_h - 1 >= 0 for members with a loop (n_h = 1 otherwise),
       ["c", h, u1, u2, tau]   third vertices k of member h with psihat_ik = u1, psihat_jk = u2,
                               tau_ijk = tau (allowed triangle types only),
       ["m", e, h, w]          for e = "i" (member a) and e = "j" (member b): the k != e of
                               member h with psihat_ek = w,
  and rows (x, y in P)
       ["deck", x]          sum_{h loop} (n_h - 1) g_h(x) = h(x) - sum_{h in U} g_h(x)
       ["count", h]         sum_{c of member h} c - [loop h] (n_h - 1) = 1 - [h = a] - [h = b]
       ["link", e, h, w]    sum_{c of member h with u_e = w} c - m(e, h, w) = -[h = other, w = u]
       ["starcount", e, h]  sum_w m(e, h, w) - [loop h] (n_h - 1) = 1 - [h = member of e]
       ["L", e, x]          sum m(e, h, w) w(x) = x g_e(x) - Min(x)
       ["Qd", e, x, y]      sum m(e, h, w) w(x) w(y) = DD(g_e)(x, y) - g_e(x) g_e(y)   (x <= y)
       ["La", x]            sum c tau u1(x) = x u(x) - g_a(x)
       ["Lb", x]            sum c tau u2(x) = x u(x) - g_b(x)
       ["Q", x, y]          sum c tau u1(x) u2(y) = DD(u)(x, y) - g_a(x) u(y) - u(x) g_b(y)
  where u_i = u1, u_j = u2, "other" is b for e = i and a for e = j, and
  DD(f)(x, y) = (f(x) Min(y) - f(y) Min(x))/(y - x), = f(x) Min'(x) - f'(x) Min(x) at x = y.
  Both sides of every identity have degree < delta in each variable, so the points determine it.
  A certificate y (label -> rational) has sum_r y_r A_{r,v} >= 0 for every variable v and
  sum_r y_r b_r < 0.  A tree {"var", "k", "le", "ge"} splits on a variable (v <= k, v >= k + 1);
  its leaves {"y"} hold in box form: sum_v min_{box} (y.A_v) v > y.b.
Stage R (src/level3_59.py, for the cliques that stage S skipped): per clique, rounds
  {"alive", "dead": [{"f", "y"}]}; each y is a box-form certificate for the relaxed vertex-star
  system of f on the members alive (eqlines.star.RelaxedStar; rows in Leaf.export_R), and the
  clique is excluded when no member is left.
Program 1 solves the edge systems with spectral rows (remainders modulo the irreducible factors
of Min); the point form here is the exact image y_P = M^T y_spec (M^T Y M for bivariate rows) with
M = T V^-1, T the spectral map and V the Vandermonde matrix of P.  The self-check rebuilds every
system in point form from the row definitions above and requires equal column sums.

Usage: python3 cert59.py SHARD [idx ...] [--l1=DIR --l2=DIR --l3=DIR --out=DIR]
       (default: every level-2 file of data/level2_59/s<SHARD>)
Output: runs/cert59/s<SHARD>/<idx>.json
"""

import json
import os
import sys
from fractions import Fraction

from flint import fmpq, fmpq_mat, fmpz_poly

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from eqlines.deck import SpecPoly  # noqa: E402
from eqlines.farkas import bounded_form, check_farkas  # noqa: E402
from eqlines.jacobi import PairSpace  # noqa: E402
from eqlines.lpcert import verify_farkas_bounded  # noqa: E402
from eqlines.rr import coeffs_to_poly  # noqa: E402
from eqlines.seidel import coeffs_desc  # noqa: E402
from eqlines.star import RelaxedStar, ResolventStar, StarSystem, eval_points, poly  # noqa: E402
from eqlines.triples import Level3, key  # noqa: E402
from level3_59 import pair_types  # noqa: E402
from run_level1_59 import chi59  # noqa: E402

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def cd(p):
    return coeffs_desc(p) if p != 0 else [0]


def fr(v):
    return str(Fraction(v))


def ev(p, x):
    return int(p(x)) if p != 0 else 0


def dd(f, M, x, y):
    if x == y:
        return ev(f, x) * ev(M.derivative(), x) - ev(f.derivative(), x) * ev(M, x)
    num = ev(f, x) * ev(M, y) - ev(f, y) * ev(M, x)
    assert num % (y - x) == 0
    return num // (y - x)


def data_dirs(s):
    return [os.path.join(ROOT, "data", f"level{k}_59", f"s{s}") for k in (1, 2, 3)]


class Leaf:
    def __init__(self, s, idx, dirs=None):
        self.s, self.idx = s, idx
        d1, d2, d3 = dirs or data_dirs(s)
        with open(os.path.join(d1, f"{idx}.json")) as fh:
            self.L1 = json.load(fh)
        with open(os.path.join(d2, f"{idx}.json")) as fh:
            self.L2 = json.load(fh)
        p3 = os.path.join(d3, f"{idx}.json")
        self.L3 = None
        if os.path.exists(p3):
            with open(p3) as fh:
                self.L3 = json.load(fh)
        self.sp = SpecPoly(chi59(self.L2["psi"]))
        D = self.L2["deck"]
        order = sorted(range(len(D)), key=lambda a: D[a])
        self.ci = {a: i for i, a in enumerate(order)}
        self.G = {a: coeffs_to_poly(D[a]) for a in range(len(D))}
        self.pts = eval_points(self.sp.delta - 1)
        self.minp = self.sp.minp
        self.h = self.sp.h

    # ---------------- level 2 ----------------
    def export_cliques(self, stage):
        D = self.L2["deck"]
        h = self.L2["h"]
        loops = set(stage["loops"])
        out = []
        for e in stage["cliques"]:
            C = e["clique"]
            rec = {"m": sorted(self.ci[a] for a in C), "lp": e["lp"]}
            if "cert" in e:
                ub = [a not in loops for a in C]
                assert verify_farkas_bounded([D[a] for a in C], h, e["cert"], ub)
                rec["cert"] = [str(int(v)) for v in e["cert"]]
            out.append(rec)
        return out

    def export_C(self):
        C = self.L2["C"]
        res = {"min_parity_ok": C["min_parity_ok"]}
        if "edges" in C:
            res["edges"] = sorted(sorted([self.ci[a], self.ci[b]]) for a, b in C["edges"])
            res["loops"] = sorted(self.ci[a] for a in C["loops"])
            res["cliques"] = self.export_cliques(C)
        return res

    def export_J(self):
        J = self.L2["J"]
        pairs = {}
        for k, found in J["pairs"].items():
            a, b = map(int, k.split(","))
            ca, cb = sorted([self.ci[a], self.ci[b]])
            pairs[f"{ca},{cb}"] = sorted(found)
        return {"members": sorted(self.ci[a] for a in J["members"]), "pairs": pairs,
                "edges": sorted(sorted([self.ci[a], self.ci[b]]) for a, b in J["edges"]),
                "loops": sorted(self.ci[a] for a in J["loops"]),
                "cliques": self.export_cliques(J)}

    def export_S(self):
        S = self.L2["S"]
        ps = PairSpace(self.sp, nonzero_at=[-5])
        pairs = {}
        for k, found in self.L2["J"]["pairs"].items():
            a, b = map(int, k.split(","))
            pairs[(a, b)] = [poly(P) for _s, _p, P in found]
        Gl = [self.G[a] for a in range(len(self.G))]
        st = StarSystem(self.sp, ps, Gl, self.h, pairs)
        out = []
        for e in S["supports"]:
            U = e["support"]
            rec = {"m": sorted(self.ci[a] for a in U), "status": e["status"]}
            if e["status"] == "certified":
                rows, rhs, names = st.build(U)
                labels = [["E1", x] for x in eval_points(st.dg)]
                labels += [["E2", self.ci[f], self.ci[g]] for f in U for g in U]
                if st.dP is not None:
                    labels += [["E3", self.ci[f], x] for f in U for x in eval_points(st.dP)]
                assert len(labels) == len(rows)
                y = e["cert"]["y"]
                assert st.verify_farkas(rows, rhs, y)
                rec["y"] = [[lab, fr(v)] for lab, v in zip(labels, y) if Fraction(v) != 0]
            out.append(rec)
        return {"supports": out, "open": sorted(sorted(self.ci[a] for a in U) for U in S["open_supports"]),
                "skipped": sorted(sorted(self.ci[a] for a in C) for C in S["skipped_cliques"])}

    # ---------------- level 3 ----------------
    def spectral_M(self, L):
        d = self.sp.delta
        x = fmpz_poly([0, 1])
        T = fmpq_mat(d, d)
        for i in range(d):
            col = L.spec(x ** i)
            for k in range(d):
                T[k, i] = col[k]
        V = fmpq_mat(d, d)
        for a, xa in enumerate(self.pts):
            for i in range(d):
                V[a, i] = xa ** i
        return T * V.inv()

    def labels_edge(self, L, a, b, u, U, names):
        """Row labels of L.edge_system(a, b, u, support=U) in its order, grouped:
        [(kind, labels)] with kind 'scalar', 'uni' (delta spectral rows) or 'sym'/'full'."""
        d = self.sp.delta
        ci = self.ci
        groups = [("uni", "deck", [])]
        groups.append(("scalar", None, [["count", ci[h]] for h in U]))
        for end, f in (("i", a), ("j", b)):
            sc = []
            for h in U:
                for w in L.pairs(f, h):
                    sc.append(["link", end, ci[h], cd(w)])
                sc.append(["starcount", end, ci[h]])
            groups.append(("scalar", None, sc))
            groups.append(("uni", ["L", end], []))
            groups.append(("sym", ["Qd", end], []))
        groups.append(("uni", ["La"], []))
        groups.append(("uni", ["Lb"], []))
        groups.append(("full", ["Q"], []))
        n = 0
        for kind, _t, labs in groups:
            n += len(labs) if kind == "scalar" else (d if kind == "uni" else
                                                     (d * (d + 1) // 2 if kind == "sym" else d * d))
        return groups, n

    def to_points(self, L, groups, y):
        d = self.sp.delta
        M = self.spectral_M(L)
        out = []
        pos = 0
        for kind, tag, labs in groups:
            if kind == "scalar":
                for lab in labs:
                    v = Fraction(y[pos])
                    pos += 1
                    if v:
                        out.append([lab, fr(v)])
                continue
            tag = ["deck"] if tag == "deck" else tag
            if kind == "uni":
                ys = fmpq_mat(d, 1, [fmpq(Fraction(y[pos + k]).numerator,
                                          Fraction(y[pos + k]).denominator) for k in range(d)])
                pos += d
                yp = M.transpose() * ys
                for k_, xa in enumerate(self.pts):
                    v = yp[k_, 0]
                    if v != 0:
                        out.append([tag + [xa], fr(Fraction(int(v.p), int(v.q)))])
                continue
            Y = fmpq_mat(d, d)
            if kind == "sym":
                for k in range(d):
                    for l_ in range(k, d):
                        v = Fraction(y[pos])
                        pos += 1
                        Y[k, l_] = fmpq(v.numerator, v.denominator)
            else:
                for k in range(d):
                    for l_ in range(d):
                        v = Fraction(y[pos])
                        pos += 1
                        Y[k, l_] = fmpq(v.numerator, v.denominator)
            Z = M.transpose() * Y * M
            for ia, xa in enumerate(self.pts):
                for ib, xb in enumerate(self.pts):
                    if kind == "sym":
                        if ib < ia:
                            continue
                        v = Z[ia, ib] + (Z[ib, ia] if ib != ia else 0)
                    else:
                        v = Z[ia, ib]
                    if v != 0:
                        out.append([tag + [xa, xb], fr(Fraction(int(v.p), int(v.q)))])
        assert pos == len(y)
        return out

    def var_labels(self, L, names, tris, a, b):
        ci = self.ci
        out = []
        for nm in names:
            if nm[0] == "n":
                out.append(["n", ci[nm[1]]])
            elif nm[0] == "c":
                h, u1, u2, tau, _Q = tris[nm[1]]
                out.append(["c", ci[h], cd(u1), cd(u2), tau])
            else:
                _m, end, h, w = nm
                f = a if end == "i" else b
                out.append(["m", end, ci[h], cd(L.pairs(f, h)[w])])
        return out

    def point_rows(self, L, a, b, u, U, vlabels, tris, rlabels):
        """The point-form system from the row definitions in the module docstring (self-check)."""
        G, minp, ci = L.G, self.minp, self.ci
        inv = {ci[h]: h for h in U}
        loops = {h: bool(L.pairs(h, h)) for h in U}
        col = {json.dumps(v): j for j, v in enumerate(vlabels)}
        x = fmpz_poly([0, 1])
        cvars = [(j, v) for j, v in enumerate(vlabels) if v[0] == "c"]
        rows, rhs = [], []
        for lab in rlabels:
            row = [0] * len(vlabels)
            k = lab[0]
            if k == "deck":
                xa = lab[1]
                r = ev(self.h, xa) - sum(ev(G[h], xa) for h in U)
                for h in U:
                    if loops[h]:
                        row[col[json.dumps(["n", ci[h]])]] = ev(G[h], xa)
            elif k == "count":
                h = inv[lab[1]]
                for j, v in cvars:
                    if v[1] == lab[1]:
                        row[j] = 1
                if loops[h]:
                    row[col[json.dumps(["n", lab[1]])]] -= 1
                r = 1 - (h == a) - (h == b)
            elif k == "link":
                _k, end, hc, w = lab
                pos = 2 if end == "i" else 3
                other = b if end == "i" else a
                for j, v in cvars:
                    if v[1] == hc and v[pos] == w:
                        row[j] = 1
                row[col[json.dumps(["m", end, hc, w])]] -= 1
                r = -1 if (inv[hc] == other and w == cd(u)) else 0
            elif k == "starcount":
                _k, end, hc = lab
                f = a if end == "i" else b
                h = inv[hc]
                for ww in L.pairs(f, h):
                    row[col[json.dumps(["m", end, hc, cd(ww)])]] = 1
                if loops[h]:
                    row[col[json.dumps(["n", hc])]] -= 1
                r = 1 - (h == f)
            elif k in ("L", "Qd"):
                end = lab[1]
                f = a if end == "i" else b
                for h in U:
                    for ww in L.pairs(f, h):
                        jj = col[json.dumps(["m", end, ci[h], cd(ww)])]
                        row[jj] = ev(ww, lab[2]) if k == "L" else ev(ww, lab[2]) * ev(ww, lab[3])
                if k == "L":
                    r = ev(x * G[f] - minp, lab[2])
                else:
                    r = dd(G[f], minp, lab[2], lab[3]) - ev(G[f], lab[2]) * ev(G[f], lab[3])
            elif k in ("La", "Lb"):
                xa = lab[1]
                pos = 2 if k == "La" else 3
                for j, v in cvars:
                    row[j] = v[4] * ev(poly(v[pos]), xa)
                r = ev(x * u - (G[a] if k == "La" else G[b]), xa)
            elif k == "Q":
                xa, xb = lab[1], lab[2]
                for j, v in cvars:
                    row[j] = v[4] * ev(poly(v[2]), xa) * ev(poly(v[3]), xb)
                r = dd(u, minp, xa, xb) - ev(G[a], xa) * ev(u, xb) - ev(u, xa) * ev(G[b], xb)
            else:
                raise ValueError(lab)
            rows.append(row)
            rhs.append(r)
        return rows, rhs

    def check_points(self, L, a, b, u, U, vlabels, tris, ypts, rows_s, rhs_s, y_s, bounds=None):
        """The point-form certificate gives the same column sums and right side as the spectral one."""
        rlabels = [lab for lab, _v in ypts]
        rows, rhs = self.point_rows(L, a, b, u, U, vlabels, tris, rlabels)
        yv = [Fraction(v) for _l, v in ypts]
        ys = [Fraction(v) for v in y_s]
        nv = len(vlabels)
        for j in range(nv):
            sp_ = sum(ys[r] * rows_s[r][j] for r in range(len(rows_s)) if rows_s[r][j])
            pp = sum(yv[r] * rows[r][j] for r in range(len(rows)) if rows[r][j])
            assert sp_ == pp, ("column", vlabels[j], sp_, pp)
        sb = sum(ys[r] * rhs_s[r] for r in range(len(rhs_s)))
        pb = sum(yv[r] * rhs[r] for r in range(len(rhs)))
        assert sb == pb, ("rhs", sb, pb)

    def convert_tree(self, L, a, b, u, U, rows, rhs, names, tris, vlabels, groups, tree, bounds):
        if "y" in tree:
            R, hh = bounded_form(rows, rhs, bounds)
            assert check_farkas(R, hh, tree["y"])
            yA = [str(v) for v in tree["y"][:len(rows)]]
            ypts = self.to_points(L, groups, yA)
            self.check_points(L, a, b, u, U, vlabels, tris, ypts, rows, rhs, yA)
            self.check_box(rows, rhs, [Fraction(v) for v in yA], bounds)
            return {"y": ypts}
        j, k = tree["var"], tree["k"]
        lo, hi = bounds.get(j, (0, None))
        b1, b2 = dict(bounds), dict(bounds)
        b1[j] = (lo, k)
        b2[j] = (k + 1, hi)
        return {"var": vlabels[j], "k": k,
                "le": self.convert_tree(L, a, b, u, U, rows, rhs, names, tris, vlabels, groups,
                                        tree["le"], b1),
                "ge": self.convert_tree(L, a, b, u, U, rows, rhs, names, tris, vlabels, groups,
                                        tree["ge"], b2)}

    @staticmethod
    def check_box(rows, rhs, y, bounds):
        """Box form of a leaf: sum_v min over the box of c_v v > y.b, c = A^T y."""
        for j, (lo, hi) in bounds.items():
            if hi is not None and hi < (lo or 0):
                return
        n = len(rows[0]) if rows else 0
        tot = Fraction(0)
        for j in range(n):
            c = sum(y[r] * rows[r][j] for r in range(len(rows)) if rows[r][j])
            lo, hi = bounds.get(j, (0, None))
            lo = lo or 0
            if c >= 0:
                tot += c * lo
            else:
                assert hi is not None, "negative column without an upper bound"
                tot += c * hi
        assert tot > sum(y[r] * rhs[r] for r in range(len(rhs))), "box condition"

    def export_L3(self):
        if self.L3 is None or "supports" not in self.L3:
            return None
        ci = self.ci
        members = sorted(set(a for r in self.L3["supports"] for a in r["support"]))
        E0 = pair_types(self.L2, set(members))
        out = []
        for r in self.L3["supports"]:
            U = sorted(r["support"])
            E = {k: list(v) for k, v in E0.items() if k[0] in U and k[1] in U}
            steps = []
            for st in r["steps"]:
                a, b, uc = st["edge"]
                u = poly(uc)
                L = Level3(self.sp, {c: self.G[c] for c in U}, E)
                rows, rhs, names, tris = L.edge_system(a, b, u, support=U)
                assert len(tris) == st["ntri"]
                groups, nrows = self.labels_edge(L, a, b, u, U, names)
                assert nrows == len(rows), (nrows, len(rows))
                vlabels = self.var_labels(L, names, tris, a, b)
                rec = {"edge": [ci[a], ci[b], cd(u)], "ntri": st["ntri"]}
                if "y" in st:
                    assert check_farkas(rows, rhs, st["y"])
                    ypts = self.to_points(L, groups, st["y"])
                    self.check_points(L, a, b, u, U, vlabels, tris, ypts, rows, rhs, st["y"])
                    rec["y"] = ypts
                else:
                    rec["tree"] = self.convert_tree(L, a, b, u, U, rows, rhs, names, tris,
                                                    vlabels, groups, st["tree"], {})
                steps.append(rec)
                key_u = key(u)
                kk = (min(a, b), max(a, b))
                assert any(key(w) == key_u for w in E[kk])
                E[kk] = [w for w in E[kk] if key(w) != key_u]
            rec = {"m": sorted(ci[a] for a in U), "verdict": r["verdict"], "steps": steps}
            if r["verdict"] == "excluded":
                rec["reason"] = r["reason"]
                if r["reason"].startswith("no pair type"):
                    a, b = map(int, r["reason"][len("no pair type ("):-1].split(","))
                    assert not E.get((min(a, b), max(a, b)))
                    rec["reason"] = ["no pair type", ci[a], ci[b]]
                else:
                    rs = ResolventStar(self.sp, [self.G.get(c) for c in range(max(U) + 1)], self.h,
                                       {k: v for k, v in E.items()})
                    rows, rhs, names = rs.build(U)
                    labels = [["E1", x] for x in eval_points(rs.dg)]
                    labels += [["E2", ci[f], ci[g]] for f in U for g in U]
                    for f in U:
                        labels += [["L", ci[f], x] for x in rs.pts]
                        labels += [["Qd", ci[f], x, y] for ia, x in enumerate(rs.pts)
                                   for y in rs.pts[ia:]]
                    assert len(labels) == len(rows)
                    y = r["star_cert"]["y"]
                    assert rs.verify_farkas(rows, rhs, y)
                    rec["reason"] = ["vertex stars"]
                    rec["star_y"] = [[lab, fr(v)] for lab, v in zip(labels, y) if Fraction(v) != 0]
            else:
                rec["pair_types_left"] = r.get("pair_types_left")
            out.append(rec)
        return {"supports": out, "verdict": self.L3["verdict"]}

    # ---------------- stage R ----------------
    def relaxed_rows(self, alive, f, vlabels, rlabels, loops):
        """The relaxed vertex-star system of f on `alive` from the row definitions (self-check)."""
        G, minp, ci = self.G, self.minp, self.ci
        inv = {ci[g]: g for g in alive}
        col = {json.dumps(v): j for j, v in enumerate(vlabels)}
        x = fmpz_poly([0, 1])
        mvars = [(j, v) for j, v in enumerate(vlabels) if v[0] == "m"]
        rows, rhs = [], []
        for lab in rlabels:
            row = [0] * len(vlabels)
            if lab[0] == "E1":
                for g in alive:
                    j = col.get(json.dumps(["n", ci[g]]))
                    if j is not None:
                        row[j] = ev(G[g], lab[1])
                r = ev(self.h, lab[1]) - ev(G[f], lab[1])
            elif lab[0] == "E2":
                g = inv[lab[1]]
                for j, v in mvars:
                    if v[1] == lab[1]:
                        row[j] = 1
                row[col[json.dumps(["n", lab[1]])]] = -1
                r = 0
                assert g != f or loops[f]
            elif lab[0] == "L":
                for j, v in mvars:
                    row[j] = ev(poly(v[2]), lab[1])
                r = ev(x * G[f] - minp, lab[1])
            elif lab[0] == "Q":
                for j, v in mvars:
                    row[j] = ev(poly(v[2]), lab[1]) * ev(poly(v[2]), lab[2])
                r = dd(G[f], minp, lab[1], lab[2]) - ev(G[f], lab[1]) * ev(G[f], lab[2])
            else:
                raise ValueError(lab)
            rows.append(row)
            rhs.append(r)
        return rows, rhs

    def export_R(self):
        """Stage R: per skipped clique the rounds of removals, each with its box-form certificate.
        Variables ["n", g] (n_g for g != f, n_f - 1 if f has a loop; n_g <= 1 for g != f without
        a loop) and ["m", g, w] (the j != i of member g with psihat_ij = w); rows
          ["E1", x]  sum_{g != f} n_g g(x) + [loop f] (n_f - 1) f(x) = h(x) - f(x)
          ["E2", g]  sum_w m(g, w) - n_g = 0      (for g = f: n_f - 1)
          ["L", x]   sum m(g, w) w(x) = x f(x) - Min(x)
          ["Q", x, y]  sum m(g, w) w(x) w(y) = DD(f)(x, y) - f(x) f(y)   (x <= y in P)."""
        if self.L3 is None or "R" not in self.L3:
            return None
        ci = self.ci
        members = sorted(set(a for r in self.L3["R"] for a in r["clique"]))
        E0 = pair_types(self.L2, set(members))
        out = []
        for r in self.L3["R"]:
            alive = sorted(r["clique"])
            rounds = []
            for rd in r["rounds"]:
                assert sorted(rd["alive"]) == alive
                Gl = [self.G.get(c) for c in range(max(alive) + 1)]
                rs = RelaxedStar(self.sp, Gl, self.h,
                                 {k: v for k, v in E0.items() if k[0] in alive and k[1] in alive})
                loops = {g: rs.loop(g) for g in alive}
                dead = []
                for d_ in rd["dead"]:
                    f = d_["f"]
                    rows, rhs, names, labels, bounds = rs.build_relaxed(alive, f)
                    y = [Fraction(v) for v in d_["y"]]
                    assert len(y) == len(rows) and rs.check_box(rows, rhs, y, bounds)
                    vlabels = [["n", ci[nm[1]]] if nm[0] == "n" else
                               ["m", ci[nm[1]], cd(rs.pairs[(f, nm[1])][nm[2]])] for nm in names]
                    rl = [[lab[0], ci[lab[1]]] if lab[0] == "E2" else lab for lab in labels]
                    rows2, rhs2 = self.relaxed_rows(alive, f, vlabels, rl, loops)
                    assert rows2 == rows and rhs2 == rhs, "stage R rows"
                    dead.append({"f": ci[f], "y": [[lab, fr(v)] for lab, v in zip(rl, y) if v]})
                rounds.append({"alive": sorted(ci[a] for a in alive), "dead": dead})
                gone = {d_["f"] for d_ in rd["dead"]}
                alive = [g for g in alive if g not in gone]
            assert alive == sorted(r["alive"])
            out.append({"clique": sorted(ci[a] for a in r["clique"]), "rounds": rounds,
                        "alive": sorted(ci[a] for a in alive)})
        return out

    def export(self):
        L1, L2 = self.L1, self.L2
        res = {"shard": self.s, "idx": self.idx, "psi": L2["psi"], "delta": self.sp.delta,
               "points": self.pts, "h": L2["h"],
               "deck_full": sorted(L1["deck"]), "D": sorted(L2["deck"]),
               "L2_verdict": L2["verdict"]}
        res["C"] = self.export_C()
        if "J" in L2:
            res["J"] = self.export_J()
        if "S" in L2:
            res["S"] = self.export_S()
        if L2["verdict"] == "open" and self.L3 is not None:
            res["L3"] = self.export_L3() if "supports" in self.L3 else {"verdict": self.L3["verdict"]}
            if "R" in self.L3:
                res["R"] = self.export_R()
        return res


def main():
    opts = {a[2:].split("=", 1)[0]: a.split("=", 1)[1] for a in sys.argv[1:] if a.startswith("--")}
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    s = int(args[0])
    dirs = data_dirs(s)
    dirs = [opts.get(f"l{k + 1}", dirs[k]) for k in range(3)]
    idxs = [int(a) for a in args[1:]] or sorted(int(f[:-5]) for f in os.listdir(dirs[1])
                                                if f.endswith(".json"))
    out_dir = opts.get("out", os.path.join(ROOT, "runs", "cert59", f"s{s}"))
    os.makedirs(out_dir, exist_ok=True)
    for idx in idxs:
        lf = Leaf(s, idx, dirs)
        res = lf.export()
        with open(os.path.join(out_dir, f"{idx}.json"), "w") as fh:
            json.dump(res, fh)
        l3 = res.get("L3") or {}
        print(f"s{s} {idx}: L2 {res['L2_verdict']}, L3 {l3.get('verdict')}, "
              f"{sum(len(r.get('steps', [])) for r in l3.get('supports', []))} steps; self-check OK",
              flush=True)


if __name__ == "__main__":
    main()
