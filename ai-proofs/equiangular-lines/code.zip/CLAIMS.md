# EQ-UP claims

Tags follow `COMMON.md`. **PROVED** means a complete proof. For computer steps it also means
exact arithmetic, complete case coverage and agreement of two independently written programs.
**CONDITIONAL** marks exact computations that have run in one program only (or rest on one
uncertified solver run), and the conditions are stated. Nothing here is a team result until
EQ-AUD and the referee both rate it VALID.

Last update: 2026-10-24 08:37 UTC (T18 filed: no 59 equiangular lines in R^18, N(18) <= 58; not
audited yet). Earlier: 00:19 UTC (T19: EQ-AUD A.28 VALID, no fix; referee pending).

| # | Statement | Tag | Novelty (our assessment) | Audit |
| --- | --- | --- | --- | --- |
| U1 | No 421 equiangular lines in R^44, hence **N(44) <= 420** | **PROVED** (computer-assisted, two programs) | New: the published bound is 422 | A.10 **VALID WITH FIXES** (attribution; applied); **EQ-REF1: VALID** (2026-10-23 03:30 UTC). Team result. |
| T20 | No 94 equiangular lines in R^20, hence **N(20) <= 93** | **PROVED** (computer-assisted, two programs; every certificate file re-checked; EQ-AUD's own program 3 also excludes every leaf) | New: the published bound is 94 [GSY21] | **A.19 VALID** (no fix; 07:45 UTC); **EQ-REF4: VALID WITH FIXES** (fixes to the text only, F1–F4, all applied 23:00 UTC; see below). Reporting is the coordinator's. |
| T19 | No 74 equiangular lines in R^19, hence **N(19) <= 73** | **PROVED** (computer-assisted, two programs, as T20). **Program 2** (U9): every one of its 335,020 leaves is INFEASIBLE with an exact certificate, and every certificate file passes `--check` with the frozen code; in (0,1,5) (4,4,4,4) that is 136,587 leaves, 42 of them certified by T1-first branching (`verify/c35_cert_hard.py`), merged per shard by `c35_cert_resume.py --from`. **Program 1** (U8, CP-SAT): every case INFEASIBLE; for (4,4,4,4), `verify/c35k3_coverage.py` re-enumerates the 1,490 second-level leaves and their third-level leaves and finds an INFEASIBLE record for each: **COVERAGE COMPLETE** (13:38 UTC; 1,258 decided at level 2, 232 at level 3 with 188,648 sub-leaves, 0 undecided, 0 feasible records; `logs/c35k3_coverage_final.txt`). EQ-LIT's C18 is a further exact program for the same step (A.27 VALID WITH FIXES: as filed its candidate lists miss lines at extra reference levels; with a one-branch fix every affected part closes in EQ-AUD's reruns; T19 does not depend on it) | New: the published bound is 74 [GSY21] | **A.28 VALID** (no fix; posted 23:50 UTC on 23 Oct): EQ-AUD's own program 3 (with the orbit reductions of its program 3d) excludes every case of 74 lines (298,259 leaves, 161,892,202 counted with orbit weights, every LP refutation an exact Farkas vector), and all 15 of our certificate files pass the frozen `--check` on EQ-AUD's machine (335,020 leaves). Referee pending; reporting is the coordinator's. |
| T18 | No 59 equiangular lines in R^18, hence **N(18) <= 58** | **PROVED** (computer-assisted, two programs on every step: all 1,214 candidate spectra excluded by both, with the same exclusion stage and no disagreement; `logs/tally59_final.txt`, 08:36 UTC) | New: the published bound is 59 [GS24] (57 lines exist [GSY23]) | Filed 24 Oct, 08:37 UTC (`AUDIT_REQUEST.md`, "Priority 0 (new): T18"); not audited yet. EQ-AUD's own pipeline already excludes all 1,214 with the same stage counts (their `AUDIT.md`, 23 Oct 21:20 PT). |
| U0 | No 422 equiangular lines in R^44 | PROVED | Known tools; EQ-LIT C1 (A.2 VALID WITH FIXES; EQ-REF1 VALID) | EQ-LIT's claim |
| U2 | Parity sharpening of the relative bound (Prop. 9 of the paper) and its 72-row table | PROVED | **KNOWN** (A.10): [GSY21, Lemma 3.1] + [GKMS16, Thm 5.6] | A.10 KNOWN |
| U3 | N_{1/a}(a^2-5) <= floor((a^2-1)(a^2-5)/5) - 1 for a = +-3 (mod 10), a >= 7 | PROVED | [Gre18, sec. 6, Cor. 6.5] specialised to d = a^2 - 5 (A.10) | A.10 VALID WITH FIXES |
| U4 | Level 1 for 74/R^19 and 94/R^20: 147 resp. 149 of the 169 candidates excluded | PROVED (exact; three programs: ours, EQ-LIT C12 `deck_dp.py --t3`, EQ-AUD A.15) | Partial; no bound changes | **A.15 VALID** |
| U5 | Level 2 for 74/R^19 and 94/R^20: every level-1 survivor except #3 and #35 is excluded; #3 is EQ-LIT's C5 | PROVED (exact; three programs: ours, EQ-LIT C12 `t3_compat.py` for step 1 and C14 `t3_pairs.py` for steps 2–3, EQ-AUD A.16) | New | **A.16 VALID** (no fix) |
| U6 | Structure of #35: three supports with forced counts; rigid V17 and V11 parts; a vector problem in V15 | PROVED (pen and paper from U5's pair data; mechanical checks `verify/c35_structure.py`, `src/star_counts_35.py`; counts also EQ-LIT `t3_counts.py`; rebuilt by EQ-AUD, and EQ-LIT's C16) | New | **A.19 VALID** (no fix) |
| U7 | The base-class model (walks on the class-a graph plus F-parts against exact references) | PROVED (pen and paper; pair rules checked against explicit vectors and against U5's pair data; rebuilt line by line by EQ-AUD) | New | **A.19 VALID** (no fix) |
| U8 | Program 1 (CP-SAT, `src/c35*.py`): every case of 94 and of 74 excluded; 74 (0,1,5) (4,4,4,4) by `c35k.py` (277 second-level leaves) and `c35k3.py` (the other 1,213, with a third reference where needed); coverage of all 1,490 checked by `verify/c35k3_coverage.py` (COMPLETE, 13:38 UTC) | exact model, uncertified solver | New | – (confirmation of U9) |
| U9 | Program 2 (`verify/c35_cert.py`, no shared code): every leaf has an exact certificate; **94 and 74 complete** (74: 335,020 leaves, of them 136,587 in (0,1,5) (4,4,4,4) and 163,015 in (0,1,2)); every certificate file passes `--check` with the frozen code | PROVED (program 2 alone) | New | **A.19 VALID** for 94 (code reviewed, the 94 files pass `--check` on EQ-AUD's machine, and EQ-AUD's program 3 excludes all 444 of its leaves); **A.28 VALID** for 74 (all 15 files, 335,020 leaves, pass `--check` on EQ-AUD's machine) |
| F1 | Excluding 420 lines in R^44 | FAILED (not attempted beyond stripping) | – | – |
| F2 | Lowering the integral relative bounds 540 (d = 45), 736 (d = 46) | FAILED | – | – |
| F3 | New bounds from moment tests in d = 18, 19, 20, 42 | FAILED | – | – |
| F4 | Multi-type Delsarte (2-point) test for #35, support (0,1,5) | FAILED (all block matrices PSD up to degree 12, both cases; `src/c35_delsarte.py`) | – | – |

T20 = [GSY21] reduction + U4 + U5 + C5 (for #3) + U6 + U7 + U9 for 94 (U8 confirms). T19 is the
same with the 74-line data; U9 and U8 are both complete for 74.

**T20, referee EQ-REF4** (`EQ-REF4/REFEREE.md`, 23 Oct): **VALID WITH FIXES**, and all fixes are to
the text. The referee rebuilt every step with programs of their own: 169 candidates, 20 after level 1,
#3 and #35 after level 2, #3 impossible, the structure of #35, and the V2 search with 19 searched
leaves and none open. Negative controls on six real Seidel matrices pass. Applied in
`MAIN_RESULT.tex`:
* **F1** (level 2, step 1). The compatibility numbers are N_k = sum over simple lambda of
  d_lambda lambda^k sqrt(g g'(lambda))/Sim'(lambda) = (S^k M(S))_ij, with N_k = (x^k M)'(1) mod 2.
  The printed version had an extra factor M(lambda), which gives (S^k M(S)^2)_ij, and the parity of
  S^k, which is wrong at odd k. The code (`src/eqlines/compat.py`, parity `off_parity(x^k M, n)`)
  applies the correct test, so no verdict changes. The same text serves T19 (order 74, also even).
* **F2.** The parity at even order is our own derivation (S = I + J and J^2 = 0 mod 2, so the
  off-diagonal entries of F(S) are F'(1) mod 2). It is now proved in the paper and credited as
  ours. [GSY23] impose a parity condition only for odd order.
* **F3.** In arXiv:2002.08085v1, N(20) <= 94 is [GSY21, Thm 5.5] and N(19) <= 74 is Thm 5.2. The
  bibliography entry now says that we cite that numbering.
* **F4** (optional, done). Lemma no3 stops after one bordering. The spectrum
  (x+5)^75 (x-14)(x-19)^19, resp. (x+5)^56 (x-10)(x-15)^18, is excluded by [GSY21, Thm 5.1] and
  [Gre18, Rem 5.5, Cor 5.4], via srg(95,40,12,20) and srg(75,32,10,16) [AM20, AM18].

Paper: `MAIN_RESULT.pdf` (U0–U3 in sections 1–6; T20 = Theorem 2 and T19 = Theorem 3 in
sections 7–11; T18 = Theorem 4 in section 12). Section numbers below refer to it.

---

## T18. There are no 59 equiangular lines in R^18; N(18) <= 58. PROVED (computer-assisted, two programs)

**Status.** Filed for audit on 24 Oct, 08:37 UTC (`AUDIT_REQUEST.md`, "Priority 0 (new): T18").
Not audited yet. EQ-AUD's own pipeline for 59 lines (their `audits/t18`, written independently)
already excludes all 1,214 leaves, with the same count at every stage (their `AUDIT.md`, status
entry of 23 Oct, 21:20 PT), and their leaf-by-leaf comparisons agree with every record of ours
that they compared (entries of 21:40 and 22:15 PT). EQ-LIT's C19 (their own levels 1–3) was in
progress at their last mirror (23 Oct, 18:28 UTC; their `CLAIMS.md`: 145 of 1,214 leaves excluded
at 18:09 UTC, none open). The published
range is 57 <= N(18) <= 59: the lattice construction of [GSY23], and [GS24], which excludes 60 lines.

**Statement.** There is no set of 59 equiangular lines in R^18. Every larger set contains 59
lines, so N(18) <= 58.

**Proof** (paper: Theorem 4 and section 12, source `t18_sections.tex`).
1. *Reduction* (Lemma 59red). 59 > 2·18, so the angle is arccos(1/a) with a odd. a = 3 allows at
   most 34 lines and a >= 7 fewer than 28 (relative bound), so a = 5. N_{1/5}(17) <= 51 < 59, so
   the lines span R^18 and -5 has multiplicity 41. The other 18 eigenvalues have sum 205 and sum
   of squares 2397. The forcing lemma (the step in [GSY21, Lemma 3.1]; paper Lemma force) at
   kappa = 11 applies because 65^18 < 18^18 4^17, so 11 is an eigenvalue:
   chi_S = (x+5)^41 (x-11) psi(x-11), with psi monic of degree 17, c_1 = -7, c_2 = -8, and
   (E) 2^k | c_k for even k, 2^(k-1) | c_k for odd k.
2. *Enumeration* (Lemma 59enum). Exactly 1,214 real-rooted psi satisfy (E), (P) and (L) at the
   levels k <= 8. (P): chi_S mod 2^7 lies in P_{59,7}; both programs found 2,048 residues of
   explicit Seidel matrices, the bound of [GY19, Cor. 3.13], so their common list is complete.
   (L): [GY19, Lemma 3.12] for chi_{S+I}. Both are tested on prefixes of (c_0, c_1, ...).
3. *Level 1* (odd order). (F1) an even eigenvalue has multiplicity <= 1; (F2) (L) at every level
   k <= 29. The deck members satisfy (D1), (D2), (D3) (g(x-1) is type 2: order 58) and (D6)
   g(-5) != 0, and are flagged by P_{58,7} (1,024 classes, the bound of [GY19, Cor. 3.4], all
   realised in both programs). An exact Farkas vector on (A) the full deck or (B) the flagged
   members excludes the leaf.
4. *Level 2* on the flagged members: (C) compatibility at the simple eigenvalues with the
   odd-order parity (S = J + I mod 2, so N_k = r(1) - r(0) mod 2 for r = x^k M, and
   Min(0) = Min(1) = 0 mod 2) and an exact LP on each maximal clique; (J) pair polynomials
   (J1)–(J6) (odd (S^k)_ij; type 2 of chi_{S[ij]}(x-1) at order 57 [GSY21, Thm 2.5]; P_ij(-5) != 0)
   and an exact LP on each maximal pair clique; (S) the vertex-star system of every support inside
   an LP-feasible pair clique with at most 12 members.
5. *Level 3* on every support left open by (S): triangle types (T1)–(T5) from Jacobi's identity,
   edge systems ((La), (Lb), (Q), the deck identity, links to the vertex stars) and the resolvent
   rows (L), (Q) of the vertex stars; edge types are deleted by exact Farkas vectors, and when the
   LP cascade stops, the edge systems are decided by exact branch and bound. *Stage R* for every
   pair clique with more than 12 members: the relaxed vertex-star system of a member f (unknowns
   n_g for g in K and m_{g,w}) is infeasible by an exact Farkas vector, and f is removed; the
   clique is excluded when it becomes empty.
6. *Stage X* for s5/25, chi = (x+5)^41 (x-11)^14 (x-15)^2 (x^2-21x+94), the one leaf that
   level 3 leaves open (one support {g_1, g_2, g_3}, counts (17, 40, 2)). Lemma s525 (pen and
   paper): E_15 splits the 40 vertices of g_2 into two orthogonal groups A, B of 20; on each, the
   graph of -1 entries is five 4-cycles (rank E_11 = 14), three of kind adj and two of kind alt;
   the columns S[A, k] (k in B) are sign profiles with prescribed beta-products,
   beta = 5I - C - 3P. Proposition s525 (two programs): 248 + 248 profiles, 7,920 adj
   assignments with 1,980 spans, 24,000 alt assignments with 3,000 spans, and no three adj spans
   and one alt span are pairwise beta-orthogonal. Corollary s525 excludes the leaf.

**Programs.**
* Program 1 (Python 3, python-flint, HiGHS): `src/enum59.py`; `src/run_level1_59.py` (decks in
  `src/eqlines/deck.py`, certificates in `lpcert.py`); `src/level2_59.py` (`compat.py`,
  `jacobi.py`, `star.py`, `farkas.py`, `exactlp.py`); `src/level3_59.py` (`triples.py`,
  `star.RelaxedStar`, `star.ResolventStar`), run by `src/pipe59c.sh`; `src/s525_59.py`;
  `src/cert59.py` (export of the level-2 and level-3 certificates in point form, after an exact
  self-check that rebuilds every row). Floating point only proposes: every infeasibility is an
  exact Farkas vector checked in exact arithmetic, and every feasibility answer of the exact
  simplex is an exact point.
* Program 2 (PARI/GP), written from the statements in the paper without program 1's code:
  `verify/enum59.gp`, `verify/classes.gp`, `verify/deck59.gp` (level 1), `verify/lv23_59.gp`
  (levels 2, 3 and stage R), `verify/s525_59.gp` (stage X). It recomputes the enumeration, the
  class lists, the decks (real roots by `polrootsreal`), h, the class flags, the compatibility
  graph and its maximal cliques, every pair polynomial, and the star, edge, triangle and relaxed
  systems on its own variables. From program 1 it reads only the certificates
  (`verify/p2_export_leaf.py`, `verify/json2gp.py`) and checks each against its own systems. It
  reports every certificate that fails and every difference from program 1 in decks, verdicts,
  cliques, pair types or open supports; a leaf counts as excluded only if there is neither.
* `src/sched59.py` ran both programs leaf by leaf; `verify/tally59.py` tallies their verdicts.

**Result** (`verify/tally59.py`, 08:36 UTC; output `logs/tally59_final.txt`):

| stage that excludes the leaf | program 1 / program 2 | leaves |
| --- | --- | --- |
| level 1 (Farkas vector on the deck) | L1 / L1 | 572 |
| level 2, (C) | C / C | 526 |
| level 2, (J) | J / J | 33 |
| level 2, (S) | S / S | 53 |
| stage R; every other support closed by (S) (program 1 runs stage R inside level 3) | L3+R / S+R | 17 |
| level 3 | L3 / L3 | 11 |
| level 3 and stage R (s2/14) | L3+R / L3+R | 1 |
| stage X (s5/25) | X / X | 1 |
| total | | 1,214 |

`total 1214 leaves: both programs exclude 1214; open 0; program 2 problems 0; enumeration equal on
16 of 16 shards`. The enumeration: on each of the 16 shards both programs visit the same number
of nodes at every level and find the same leaves in the same order (42,473,735 nodes;
`logs/enum59_summary_cmp.txt`, ALL EQUAL).

**Code changes during the run.** Each one keeps the verdicts by construction (floating point or a
cache only proposes; every answer is checked exactly) and was compared with the old code before use:
* 23 Oct 23:33 UTC, `src/eqlines/rr.py`: a certified real-rootedness test first (sign changes in
  ball arithmetic between exact dyadic points around floating-point proposals), root isolation
  only when it fails (`logs/validation/rr_fastpath_*.log`).
* 23:45, `src/eqlines/deck.py`: a cache of root isolations (`logs/validation/level2_isolate_cache_vs_old.log`).
* 23:58, `verify/deck59.gp`: memoised deck enumeration (`logs/validation/deck59_memo_vs_old.log`).
* 24 Oct 01:30:48, `src/eqlines/star.py`, `farkas.py`: stage (S) fast path. HiGHS proposes a Farkas
  vector or a feasible point; it counts only after an exact check, otherwise the exact simplex
  decides (`logs/validation/star_fastpath_*.log`).
* 06:23:56, `src/eqlines/exactlp.py` v2: a revised simplex over Q (exact FLINT solves; Dantzig's
  rule, Bland's rule after 50 pivots without decrease) instead of a dense Fraction tableau with
  Bland's rule (v1, kept as `verify/ref/exactlp_v1.py`). Same statuses on 9,000 random systems and
  on all star systems of supports of size <= 3 of s9/24, s2/13 and (run after its level-2 record,
  710 systems) s2/14; the four supports on which v1 ran for more than an hour take 3–5 s (all
  feasible, points checked)
  (`verify/test_exactlp_v2.py`, `logs/validation/exactlp_v2_vs_v1.log`). The level-2 runs of s2/13,
  s2/14 and s9/24 were stopped before writing any record and restarted with v2.

**Where an error common to both programs would sit.** Both programs implement the same
statements, so an error in a statement would not be caught by their agreement. In order of risk:
(i) the odd-order rules: (F1), (D3), the compatibility parity, (J1), (J5), (T1)–(T5), and the
soundness of the stage-R relaxation; (ii) Lemma s525; (iii) the completeness of P_{59,7} and
P_{58,7} (both reach the bounds of [GY19]); (iv) the prefix tests of (P) and (L)
(`verify/enum59_l312_cmp.py` checks the latter on three shards). EQ-AUD's pipeline derives (i),
(iii) and (iv) itself and closes s5/25 by a different last step (backtracking and CP-SAT).

**Controls.** `verify/triples_negative.py` (1,055 true triangles of random Seidel matrices, clique
unions and deletions from the unitary U_3(3), U_3(5) systems: all allowed, mu_3 Q equals the direct
characteristic polynomial, true counts satisfy every row, no true edge type certified),
`verify/relaxed_negative.py` (192 true vertex stars satisfy every row and are never certified),
`verify/lv23_negative.py` (45 perturbed exports, all rejected by program 2).

**Data.** Committed: the leaves (`runs/enum59/`, `runs/enum59_gp/`), program 1's level-1 and
level-3 records (`data/level1_59/`, `data/level3_59/`), stage X (`data/stageX_59/`,
`runs/p2_59/x/`), program 2's outputs (`runs/p2_59/l1/`, `runs/p2_59/l23/*/*.txt`), the logs
(`logs/level59/`, `logs/p2_59/`, `logs/sched59*.log`, `logs/enum59*`). Only in the store mirror
(too large for git; sha256 of every file in `MANIFEST59.sha256`): program 1's level-2 records
(`data/level2_59/`), the `cert59` exports (`runs/cert59/`) and program 2's GP transcriptions
(`runs/p2_59/l23/*/exp/`).

---

## U1. There are no 421 equiangular lines in R^44; N(44) <= 420. PROVED (computer-assisted)

**Status.** EQ-AUD A.10: VALID WITH FIXES (attribution only; applied). Referee EQ-REF1: **VALID**
(2026-10-23, `EQ-REF1/REFEREE.md`), with two different exact methods per computer stage, written
independently; no prior publication of a bound below 422. The referee's four optional edits are
applied here and in the next build of the paper: "deck" is cited to [GS24] (Greaves–Syatriadi,
JCTA 201 (2024) 105812, Def. 2.5), with their LP enumeration paper arXiv 2504.09241 (2025);
[GY19, Lemma 3.8] is stated without an order hypothesis; (D2) is justified by
w_j = ||E_j e_i||^2 >= 0; Neumann and N_{1/3} carry the cross-references [BY14, Thm 1.2], [KT19].

**Statement.** No Seidel matrix of order 421 has smallest eigenvalue -a of multiplicity 421 - 44
for any a, and no 421 equiangular lines exist in R^44 at any angle. Since every larger set
contains 421 lines, N(44) <= 420.

**Proof** (paper §4–§5).
1. Reduction. Neumann (n > 2d) makes the angle arccos(1/a) with a odd. Then a = 3 gives at most
   86 lines, a = 5 at most 276 [Yu17], and a >= 9 at most 95 (relative bound). So a = 7. Full rank
   follows from N_{1/7}(43) <= 344, so mult(-7) = 377. The other 44 eigenvalues have sum 2639 and
   sum of squares 158347.
2. Stripping. The 2-adic forcing lemma is the step in the proof of [GSY21, Lemma 3.1]; the paper
   re-proves it (Lemmas 3, 4, 5 and 7). Applied 16 times at kappa = 59 and then 15 times at
   kappa = 61, it gives
   chi_S = (x+7)^377 (x-59)^16 (x-61)^15 Q(x-59), with deg Q = 13, sum of roots 13 and sum of
   squares 49.
3. Lattice for Q: 2^(i-1) | a_i for odd i, and 2^i | a_i for even i. The second condition is
   [GY19, Lemma 3.8] (2^r | a_r for even r; for odd order this is the parity refinement). The
   only new step is its transfer to Q (paper Lemma 5(2)), because F^(y) = (y+1)^392 y^16 is a
   square mod 2. **The refinement is not needed** (see Robustness).
4. Exactly 82 real-rooted Q satisfy these conditions.
5. For each candidate p, the interlacing characteristic polynomials ("deck", [GS24]) of
   [GSY23, §5] are computed exhaustively, with two extra valid conditions:
   * (D6) g(-7) != 0, because N_{1/7}(43) <= 344;
   * (D7) all roots in [2166/44, 3098/44], by Cauchy–Schwarz on the 44 non-(-7) eigenvalues of S[i].
   EQ-AUD's control 6 (A.10) shows that (D6) and (D7) are implied by (D1)–(D3), so the exclusion
   uses only the conditions of [GSY23, sec. 5].
   An exact integer Farkas certificate Y shows that sum_i g_i = p'/mu has no nonnegative solution.

**Computation.**
* Program A: Python, FLINT ball arithmetic and certified root isolation, HiGHS plus exact
  rationalisation.
* Program B: PARI/GP. It shares no code with A and re-derives the chain, all 82 Q, every deck
  (120,527 nodes, maximum deck size 73), every h, and checks each certificate against its own
  deck with exact Sturm sequences.
* Both agree on everything. Run output: `logs/n421_decks.log` (A), `logs/n421_gp.log` (B).
* EQ-AUD (A.10) rebuilt the decks by a third method (lattice points of the partial-fraction
  polytope); EQ-REF1 by two more (Hankel PSD + Fourier–Motzkin; derivative tower + sign test).

**Robustness.** With only 2^(i-1) | a_i for all i >= 1 (weakly type 2, [GSY21, Lemma 2.7]) both
programs find the same 190 polynomials Q (53,127 nodes) and decks of identical sizes (615,463
nodes, maximum 80). Program A finds a certificate for all 190 and Program B confirms each on its
own deck (`logs/n421_weak_decks.log`, `logs/n421_weak_gp.log`). So U1 rests on published 2-adic
facts only.

**Negative tests.** 343 of the 344 lines in R^43 (704 remainders, 9 survive, including the true
spectrum {(-7)^300, 49^42, 42}); 125 of the 126 lines in R^21 (14 remainders, 2 survive, including
{(-5)^104, 25^20, 20}).

**Reproduce.**
`python3 src/n421_enum.py && python3 src/n421_decks.py 6 && python3 src/n421_export.py && (cd verify && gp -q n421.gp)`.
Weak variant: the same three Python commands with `--weak`, then `cd verify && gp -q n421_weak.gp`.

## U0, U2, U3

* **U0** (no 422 lines in R^44): EQ-LIT's C1 (A.2 VALID WITH FIXES; EQ-REF1 VALID, known in
  substance from [GKMS16, Thm 5.21 + Cor 3.6]). Paper Prop. 8; `verify/c1_uniform.py`,
  `verify/c1_uniform.gp`. U1 does not use it.
* **U2** (paper Prop. 9): [GSY21, Lemma 3.1] at an odd centre plus [GKMS16, Thm 5.6]; its 72
  exclusions among 140 pairs coincide with [GKMS16, Thm 5.21] ([Gre18, sec. 6]). KNOWN.
* **U3** (paper Cor. 11): [Gre18, sec. 6, Cor. 6.5] at d = a^2 - 5; changes no bound for a >= 13.

---

## The chain for 94 lines in R^20 and 74 lines in R^19

**Reduction** ([GSY21]). n = 94 > 2·20, so the angle is arccos(1/a) with a odd. a = 3 gives at
most 38 lines, a >= 7 at most 33 (relative bound), so a = 5. The lines span R^20 (N_{1/5}(19) <= 74
< 94), so mult(-5) = 74, and [GSY21, Lemma 3.1] forces chi_S = (x+5)^74 (x-19)^7 phi(x) with 169
candidates for phi in the halved variable. For 74 lines in R^19: a = 5, mult(-5) = 55,
chi_S = (x+5)^55 (x-15)^6 phi(x), the same 169 candidates. Every larger set contains such a set,
so excluding all 169 gives N(20) <= 93 resp. N(19) <= 73.

## U4. Level 1. PROVED (three programs; A.15 VALID)

The interlacing decks of [GSY23, §5] ([GS24] "deck"), with condition (iv) over the complete class
sets P_{73,7} and P_{93,7}, leave 22 candidates for 74 lines (indices 3, 9, 20, 27, 35, 42, 50,
78, 81, 83, 85, 89, 91, 99, 100, 110, 111, 142, 144, 149, 153, 162 in `data/level1/74_19/`) and
the same indices without 42 and 85 for 94 lines. EQ-AUD A.15 reproduced every deck, verdict and
certificate with its own programs; EQ-LIT's `deck_dp.py --t3` (C12) is a third.

## U5. Level 2: only #3 and #35 remain. PROVED (three programs; A.16 VALID)

For both cases every level-1 survivor except #3 and #35 is impossible; #3 is EQ-LIT's C5 (A.6).
So every 94-line system in R^20 and every 74-line system in R^19 would have chi_S = #35:
* 94/R^20: chi_S = (x-21) (x-19)^16 (x-15)^3 (x+5)^74;
* 74/R^19: chi_S = (x-17) (x-15)^15 (x-11)^3 (x+5)^55.

Steps (all exact; certificates re-verified in exact rational arithmetic):
1. Level-2 decks with the [GY19, Lemma 3.12] filter at order n - 1, compatibility at the simple
   eigenvalues (N_k = (S^k M(S))_ij is an integer, [GSY23, Lemmas 4.4, 4.7], and
   N_k = (x^k M)'(1) mod 2, our parity rule at even order), maximal cliques and their LPs
   (`src/level2.py --l312`).
2. Jacobi pair polynomials (`src/level2j.py --l312`): for i != j,
   chi_{S[i]} chi_{S[j]} - chi_S chi_{S[ij]} = adj(xI - S)_{ij}^2 forces
   chi_{S[ij]} = mu2 (g_i g_j - psi^2)/Sim with psi in Z[x] of leading coefficient S_ij and
   conditions (J1)–(J6). The identity is from [GS24] (chapter 4 of [Sya26]), after de Caen.
3. Vertex-star and row-resolvent systems (`src/level2s.py`): linear systems in the type counts and
   the pair-type counts around each vertex type, with exact Farkas vectors.

Second program: EQ-LIT C12 (`t3_compat.py`, step 1) and C14 (`t3_pairs.py`, steps 2–3; the same
552 + 588 pair polynomials, edges, cliques and verdicts; own Farkas vectors).

## U6. Structure of #35. PROVED (pen and paper from U5's data)

Write lambda_1 > lambda_2 > lambda_3 for the eigenvalues other than -5: (17, 15, 11) for 74 lines,
(21, 19, 15) for 94 lines, with multiplicities 1, m_2 (15 resp. 16) and 3, and E_lambda for the
spectral projections. G = S + 5I is PSD, so each line v has components E_lambda e_v. Scale them:
X_v = (sqrt2 r_v, sqrt3 z_v, p_v) in V_1 + V_2 + V_3 (dimensions 1, m_2, 3) with
<X_u, X_v> = 6 G_uv, i.e.
2 r_u r_v = 6 (lambda_1 + 5) (E_1)_uv, 3 <z_u, z_v> = 6 (lambda_2 + 5) (E_2)_uv,
<p_u, p_v> = 6 (lambda_3 + 5) (E_3)_uv, and 2 r_v^2 + 3 |z_v|^2 + |p_v|^2 = 30.

**(a) Types.** chi_{S[v]} = mu g_v with g_v one of the six deck members g_0, ..., g_5 of #35, and
(E_lambda)_vv = g_v(lambda)/Min'(lambda), where Min = prod (x - lambda) over the four distinct
eigenvalues. This gives (r^2, |z|^2, |p|^2) = (0, 9, 3), (1, 8, 4), (4, 5, 7), (5, 4, 8), (8, 1, 11),
(9, 0, 12) for types 0, ..., 5, in both cases. For u != v, (E_lambda)_uv = psi_uv(lambda)/Min'(lambda)
with the pair polynomial psi_uv of U5 step 2 (leading coefficient S_uv), so each type pair has a
finite list of tuples (S, r_u r_v, <z_u, z_v>, <p_u, p_v>). Check: `verify/c35_structure.py` (1), (2).

**(b) Supports and counts.** Types 3 and 4 have pair polynomials only with type 0 and with
themselves, so the maximal cliques are {0,1,2,5}, {0,3}, {0,4}. The star systems (U5 step 3) are
infeasible except for the supports (0,1,5), (0,1,2), (0,1,2,5), and each of these has a unique
type count (n_0, n_1, n_2, n_5):

| support | 74/R^19 | 94/R^20 |
| --- | --- | --- |
| (0,1,5) | (24, 48, 0, 2) | (32, 60, 0, 2) |
| (0,1,2,5) | (25, 45, 3, 1) | (33, 57, 3, 1) |
| (0,1,2) | (26, 42, 6, 0) | (34, 54, 6, 0) |

(`src/star_counts_35.py` reproduces `logs/star_counts_35.log`; EQ-LIT `t3_counts.py` derives the
same counts from the linear systems alone.)

**(c) V_1 and V_3 are rigid.** Switching a line negates X_v. Switch every line with r_v != 0 so
that r_v > 0; then r = 0, 1, 2, 3 for types 0, 1, 2, 5. The pair data (checked by
`verify/c35_structure.py` (3)) give:
* type 0 / type 0: <p, p'> = +-3 = +-|p||p'|. All type-0 parts p are parallel to one unit vector
  w_0; switch the type-0 lines (r = 0) so that p = sqrt3 w_0 for all of them.
* type 0 / type 5: <p, p'> = +-6 = +-|p||p'|, so p = +-2 sqrt3 w_0 for type 5.
* type 0 / type 1: <p, p'> = 0, so the type-1 parts are p = 2u (|u| = 1) in the plane
  P = w_0^perp of V_3. Type 1 / type 1: <p, p'> in {4, -2}, so the u's are equal or at 120
  degrees. Hence they lie in a set {u_a, u_b, u_c} of three unit vectors at 120 degrees in P,
  u_a + u_b + u_c = 0. If only one or two directions occur, complete them to such a set; the frame
  identity below shows that all three occur. This defines the classes L_a, L_b, L_c of type-1
  lines.
* type 0 / type 2: <p, p'> = +-3, so p = sigma sqrt3 w_0 + q with sigma = +-1, |q| = 2, q in P;
  type 1 / type 2: <2u, q> in {-4, 2} for every type-1 direction u. The vectors q in P with
  |q| = 2 and <u, q> in {-2, 1} are exactly -2u_a, -2u_b, -2u_c (also when only one or two
  directions occur), so q = -2u_x for one class x.
* The frame identity sum_v p_v p_v^T = 6 (lambda_3 + 5) I_3 (= 96 I_3 resp. 120 I_3), restricted
  to P, reads sum_x 4 (n_x + m_x) u_x u_x^T = c I_2, where n_x = |L_x| and m_x is the number of
  type-2 lines with q = -2u_x. Three unit vectors at 120 degrees form a tight frame only with
  equal weights, so n_x + m_x = 16 (74 lines) resp. 20 (94 lines) for every x, and all three
  directions occur.
* sum_v r_v p_v = 0 (E_1 E_3 = 0): in (0,1,5) the two type-5 parts are opposite (f+, f-:
  p = +-2 sqrt3 w_0). In (0,1,2,5), z_f = 0 for the type-5 line f forces 6 S_tf = K(t, f) for
  every other line t; replacing w_0 by -w_0 (and switching all type-0 lines) we may take
  p_f = 2 sqrt3 w_0, and then every type-2 line has sigma = -1 (S_tf = 2 + sigma must be +-1);
  the P-component of sum r p = 0 reads sum_x (2 n_x - 4 m_x) u_x = 0, so 2 n_x - 4 m_x is the
  same for all x, and with n_x + m_x = 16 (resp. 20) and n_2 = 3 this gives m_x = 1, n_x = 15
  (resp. 19). In (0,1,2) the same argument gives m_x = 2, n_x = 14 (resp. 18); the w_0-component
  of sum r p = 0 gives sum_t sigma_t = 0, and the (w_0, P) block of the frame gives
  sum_x (sum_{t in x} sigma_t) u_x = 0, so the class sums of sigma are equal, hence 0: one type-2
  line at each (sigma, x).

So every line's (r, p) is determined by its kind: T0 (type 0), T1a, T1b, T1c (type 1 by class),
and the singletons f+-, (t_a, t_b, t_c, f), (t_x+-). In the basis (w, u_a, u_b) of V_3 with
w = sqrt3 w_0 (Gram diag(3) + [[1, -1/2], [-1/2, 1]], u_c = -u_a - u_b):
T0: p = w; T1x: p = 2u_x; type 5: p = +-2w; type 2: p = sigma w - 2u_x.

**(d) The V_2 problem.** With K(u, v) = 2 r_u r_v + <p_u, p_v> (a function of the two kinds),
3 <z_u, z_v> = 6 S_uv - K(u, v). So the z_v in V_2 = R^15 (resp. R^16) have prescribed norms
9, 8, 5, 0 and inner products (6S - K)/3 with S = +-1 subject to Cauchy–Schwarz, and satisfy:
* frame: sum_v z_v z_v^T = 40 I_15 (resp. 48 I_16); sum_v r_v z_v = 0; sum_v z_v p_v^T = 0;
* row counts: from S E_lambda = lambda E_lambda in V_1 and V_3, sum_{u != v} S_vu (r_u, p_u) =
  (lambda_1 r_v, lambda_3 p_v); this 4 x 4 linear system in the block sums of S_v. over
  T0, T1a, T1b, T1c fixes the number of -1 entries of every row in every block, given the row's
  entries against the singletons;
* block sums: the same identities give Z_b = sum_{v in b} z_v as a fixed combination of the
  singletons' z (z = 0 for type 5).

For example, in (0,1,5) for 74 lines: type 0/type 0 inner products in {1, -3} (15 times 1, 8 times
-3 per row), type 0/type 1 in {+-2} (8/8 per class), same class in {0, -4} (13 times 0, 2 times
-4), different classes in {+-2} (8/8).

## U7. The base-class model. PROVED (pen and paper)

Fix the class L_a (all statements are symmetric in a, b, c).
* **The class graph.** Two class-a vectors have <z, z'> in {0, -4} (K = 6). So does a class-a
  vector with a type-2 line of another class y (K = 4 + <2u_a, sigma w - 2u_y> = 4 + 2 = 6). An
  own-class type-2 line has K = 4 - 4 = 0, so its steps are +-1 like those of T0. The row counts
  give every class-a vector exactly two -4 neighbours among L_a and those type-2 lines
  (`check_degree_rule` in `verify/c35_cert.py`). So the (-4)-graph on L_a is a disjoint union of
  paths and cycles, the path ends filled by the other-class type-2 lines (a single vertex P_1
  takes two), and the Gram matrix of L_a is M = 8I - 4A.
* **Walks.** For a line y outside L_a let s_i = <z_y, q_i>/2 (q_i the class-a vectors); s_i takes
  the two values fixed by the kind of y and S_{y,i}. The projection of z_y onto span(L_a) is
  omega_y with <omega_x, omega_y> = 4 s_x^T M^+ s_y; it exists iff s lies in the range of M. On a
  cycle component the range is the sum-zero space, and a T0 line has s_i = +-1 there, so cycles
  have even length >= 4. The rest phi_y = z_y - omega_y lies in F = span(L_a)^perp of dimension
  dim V_2 - rank M = dim V_2 - |L_a| + (number of cycles); structures with dim F < 0 are impossible.
* **References.** The F-parts of T0, T1b, T1c and the type-2 lines span F (the frame restricted to
  F; class a and type 5 have phi = 0). Take as first references a basis of the type-2 F-parts
  (their Gram matrix is fixed by the instance), then repeatedly: case A, some T0 line has phi
  outside the span of the references: add the T0 line with the largest residual; case B,
  otherwise: add the T1b/T1c line with the largest residual. Each later line then satisfies the
  recorded maximality filters. Against references with Gram G (scaled by D = lcm of the
  denominators of 4M^+), every line y has integer coordinates C_y = D <phi_y, phi_j> and residual
  R_y = D det(G) |phi_y|^2 - C_y^T adj(G) C_y >= 0, all determined by (kind, s, S against the
  references). At k = dim F every R_y = 0 and <phi_x, phi_y> = C_x^T G^{-1} C_y; at k = dim F - 1
  the residual vectors are +-sqrt(R) times one unit vector (sign eps_y).
* **Pair rule.** Two lines x, y are compatible iff 4 s_x^T M^+ s_y + <phi_x, phi_y> equals
  (6S - K(x, y))/3 for S = +1 or -1; the value S is then their Seidel entry. Two distinct lines
  never have the same node (equal z would need S = 5), so a configuration is a set of pairwise
  compatible nodes.
* **Symmetry.** Automorphisms of the class graph that fix the type-2 data map configurations to
  configurations; the candidate set of each reference is invariant under the stabiliser of the
  references so far, so one candidate per orbit suffices (every automorphism used is checked to
  preserve M).
* **Leaf conditions** (all necessary): block sizes; the frame in walk, walk–F and F coordinates;
  the block sums; the type-2 columns (number of -1's of each type-2 line in each block); the row
  counts of every selected node; pairwise compatibility.

## U8. Program 1 (`src/c35gen.py`, `src/c35k.py`, `src/c35t.py`, `src/c35u.py`; CP-SAT)

Explicit coordinates for the class vectors (2(e_k - e_{k+1}) along each cycle/path), walks and
F-coordinates computed from them, pair rules checked against explicit vectors
(`verify/c35_relation_test.py`: 0 mismatches); CP-SAT decides each leaf. Coverage (per-structure
table: `python3 src/c35_p1_table.py`):

| case | support | result | logs |
| --- | --- | --- | --- |
| 94 | (0,1,5) | (8,4,4,4) infeasible, (6,6,4,4) core empty, (4,4,4,4,4) 7/7 first-reference orbits infeasible; <= 3 cycles gives dim F < 0 | `logs/c35gen_94_20.log`, `logs/c35k_94_44444.log` |
| 94 | (0,1,2,5) | dim F = 0 structures excluded by the type-2 F-Gram, both dim F = 1 structures core-empty | `logs/c35t_94_dimF1.log`, `logs/c35u_94_0125.log` |
| 94 | (0,1,2) | all structures: F-Gram, no own type-2 lines, or infeasible | `logs/c35u_94_012.log` |
| 74 | (0,1,5) | (16) no walk of norm 9; (10,6) core empty; (8,8), (12,4) infeasible; (8,4,4) 30/30, (6,6,4) 25/25 references infeasible; **(4,4,4,4) all 1,490 second-level leaves infeasible**: 277 in `c35k.py` (2 UNKNOWN at the one-hour limit, decided later by `c35k3.py`); `src/c35k3.py` ran the other 1,213 and split a leaf by a third reference when its core had more than 2,000 nodes (3,000 in the first run) or CP-SAT did not decide it within 600 s. Runs: 3 shards 07:46–08:27, 8 shards 08:28–10:30, then `src/c35k3_pool.py` (8 workers, one leaf per process; 357 jobs, all rc 0, 10:30–13:38), each resuming from the earlier logs. `verify/c35k3_coverage.py` on the union of all logs: COVERAGE COMPLETE, 1,258 decided at level 2 and 232 at level 3 (188,648 sub-leaves), 0 feasible records (`logs/c35k3_coverage_final.txt`) | `logs/c35_sat_c2.log`, `logs/c35k_74_*.log`, `logs/c35k3/`, `runs/c35k3/` |
| 74 | (0,1,2,5) | all structures (dim F 0–3) excluded | `logs/c35u_74_0125_le2.log`, `logs/c35t_74_dimF*.log` |
| 74 | (0,1,2) | all structures and all dim F excluded (7,661 records: 4,625 leaves infeasible, the other instances excluded by the type-2 F-Gram or for lack of own type-2 lines); no solution | `logs/c35u_74_012_all.log.gz` |

## U9. Program 2: exact certificates (`verify/c35_cert.py`)

Independent code (no imports from `src/`): p-parts in the basis (w, u_a, u_b); row counts and
block sums solved from the eigen-equations in that basis; the class graph enters only through M
(exact Moore–Penrose inverse); structures, relation graphs and partner assignments enumerated
without symmetry reduction; own type-2 lines and references reduced by explicit automorphisms
(each checked). Every leaf is decided by an LP over the 0/1 node variables whose infeasibility is
proved by an integer Farkas vector checked in exact arithmetic, with branch and bound over
cardinality groups, and propagation (compatibility, counting core, cardinality groups) that
`--check` recomputes. `--full-refs` takes references up to k = dim F (all leaves exact).

Checks of program 2 itself:
* Its pair rules equal those allowed by U5's pair data for every kind pair (`verify/c35_structure.py` (4)).
* On 984 identical leaves (all supports, dim F <= 2 for 74) its node sets and relations agree with
  program 1's (`verify/c35_cert_compare.py`, 0 mismatches).
* The fast version (int64 residuals under an explicit overflow bound) gives the same leaves and
  the same node lists and relation matrices as the previous version
  (`verify/c35_cert_nodes_compare.py`, `logs/cert_nodes_compare.log`; 0 mismatches on 600
  (4,4,4,4) leaves with 231,289 nodes, 300 leaves each of 74 (0,1,2,5) and 74 (0,1,2), all of
  94 (0,1,5), and all of 94 (0,1,2) with `C35_CERT_PYINT=1`, i.e. Python integers only).
* `verify/c35_cert_checkall.py` reruns `--check` on every certificate file with the run's own
  options and one code version, and fails on a dropped record, an extra record or a changed
  Farkas multiplier (all three tested).
* `verify/c35_cert_hard.py` (for the (4,4,4,4) leaves that exceed the 400-LP budget) changes only
  the choice of the branching group: a smallest group in the type-1 blocks that still needs a
  node, else a smallest group overall. `--check` accepts any choice, since each tree node lists its
  group. With `--rule default` it reproduces c35_cert's tree exactly (leaf 25216: same key,
  identical tree).
* For (4,4,4,4), program 1's third-level leaves (`src/c35k3.py`) have the same node sets and pair
  relations as program 2's leaves with the same three references: 92 leaves (every 1,500th
  program-2 leaf), 0 mismatches (`verify/c35k3_compare.py`, `logs/c35k3_compare_4444.log`).
  Program 1 also has 25,954 type-1 nodes in these leaves whose relations with the type-1
  references fit no class. Its model excludes them through the class constraints, and in any
  case extra nodes can only make program 1's problems larger, never wrongly infeasible.

A third program, EQ-AUD's program 3 (`audits/A.19/c35_p3.py` in EQ-AUD's store; written from its
own derivation of U6 and U7, exact pair relation, a different reference rule, no shared code),
excludes all 444 leaves of 94 lines with integer Farkas vectors (A.19). On 74 lines (EQ-AUD's
status of 23 Oct, 04:00 PT) it had 40,038 leaves INFEASIBLE and none open, and EQ-AUD expects that
its (4,4,4,4) run cannot finish by the deadline.

Results (final runs `logs/cert_final/`, certificates `runs/cert_final/*.jsonl.gz`). Every
certificate file is re-verified by `--check` with the committed code (sha256 911efe268df167a3):
`python3 verify/c35_cert_checkall.py logs/cert_final runs/cert_final logs/cert_final_check`
(results in `logs/cert_final_check_part*.txt`; every finished file passes):

| case | support | structures with leaves | leaves | verdict |
| --- | --- | --- | --- | --- |
| 94 | (0,1,5) | (8,4,4,4), (6,6,4,4), (4,4,4,4,4) | 1 + 1 + 10 | all infeasible (511 LPs) |
| 94 | (0,1,2,5) | P1C6C4C4C4, P3C4C4C4C4 (7 others excluded by the type-2 F-Gram) | 1 + 2 | all infeasible (counting core) |
| 94 | (0,1,2) | C6C4C4C4, P1P1C4C4C4C4, P2C4C4C4C4 (all other instances: F-Gram 5686, no own type-2 lines 48) | 2 + 4 + 8 | all infeasible |
| 74 | (0,1,5) | (16), (12,4), (10,6), (8,8), (8,4,4), (6,6,4) | 1 + 50 + 28 + 26 + 5873 + 4648 | all infeasible |
| 74 | (0,1,5) | (4,4,4,4) | 68,378 + 68,209 = 136,587 (2 shards, `--shard-level 2`, 785 level-2 units). 136,545 closed by c35_cert within 400 LPs; the other 42 (11 in unit 217 of shard 1; 20 in unit 232 and 11 in unit 240 of shard 0) by `verify/c35_cert_hard.py` (T1-first branching, same certificate format; 1,394–6,579 LPs each). One `c35_cert_resume.py --from` merge per shard (`runs/cert_final_merged/`; every record copied, none searched again) | all infeasible; check PASS for both merged files (`logs/cert_final_merged_check_s1.txt`: 68,209 VERIFIED, 2,804 s; `logs/cert_final_merged_check_s0.txt`: 68,378 VERIFIED, 3,525 s) |
| 74 | (0,1,2,5) | P11C4, P7C4C4, P5C6C4, P3C8C4, P3C6C6, P3C4C4C4, P1C10C4, P1C8C6, P1C6C4C4 (P15: type-2 F-Gram; P1C14, P3C12, P5C10, P7C8, P9C6: no own type-2 lines) | 2 + 360 + 230 + 138 + 2 + 14,768 + 51 + 1 + 9,240 = 24,792 | all infeasible; check PASS (`logs/cert_final_check_part2.txt`) |
| 74 | (0,1,2) | all | 39,964 + 40,211 + 41,049 + 41,791 = 163,015 (4 shards, `--shard-level 1`, 22,137 units) | all infeasible; check PASS (`logs/cert_final_check_part3_s?.txt`) |

## F1–F4. FAILED / not achieved

* **F1.** n = 420 in R^44: the forcing lemma only gives (x-59)^8, and the remainder has degree 36,
  beyond exhaustive enumeration.
* **F2.** d = 45, 46: the relative bounds 540 and 736 are integers. Equality means a regular
  two-graph, i.e. srg(539,234,81,117) or srg(735,318,109,159). The moment tests do not apply at n = R
  and fail at n = R - 1.
* **F3.** d = 18, 19, 20, 42: the moment tests (U2, [GKMS16, Thm 5.21]) exclude nothing beyond the
  published bounds.
* **F4.** For #35 with support (0,1,5) all signed inner-product counts are determined, but the
  zonal-harmonic block matrices over {T0, La, Lb, Lc} are PSD for every degree k <= 12 (both cases).
