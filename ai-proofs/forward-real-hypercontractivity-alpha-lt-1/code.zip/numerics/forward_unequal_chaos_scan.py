"""Where does (2.17) (M >= 0) fail to imply the chaos conditions M_m >= 0 of Proposition 6.2
(RESULT_forward_real_hypercontractivity, Remark 6.7)? Two rho-correlated functions, k = 1, unequal parameters.
Floating point. At p = p* (smallest p with M >= 0) we compute min over m = 2..60 of lam_min(M_m)/p.
(1) random parameters, with rho and x_j concentrated near 1, by ranges of r;
(2) targeted minimisation over (rho, x1, x2) at fixed r.
"""
import numpy as np
from scipy.optimize import brentq, minimize

rng = np.random.default_rng(11)


def lam_min(rho, r, x1, x2, p, m):
    a = p - 1 - (r - 1) * x1 ** (2 * m); d = p - 1 - (r - 1) * x2 ** (2 * m); b = (p - r * (x1 * x2) ** m) * rho ** m
    return 0.5 * (a + d) - np.sqrt(0.25 * (a - d) ** 2 + b * b)


def pstar(rho, r, x1, x2):
    f = lambda p: lam_min(rho, r, x1, x2, p, 1)
    lo = max(r, 1.0)
    if f(lo) >= 0:
        return lo
    hi = lo * 2
    while f(hi) < 0:
        hi *= 2
    return brentq(f, lo, hi, xtol=1e-13)


def worst(rho, r, x1, x2):
    ps = pstar(rho, r, x1, x2)
    return min(lam_min(rho, r, x1, x2, ps, m) for m in range(2, 61)) / ps


if __name__ == "__main__":
    bins = [(0.05, 1), (1, 2), (2, 2.5), (2.5, 3), (3, 5), (5, 10), (10, 20)]
    print("(1) random parameters (rho = 1 - 10^-u, x_j = 1 - 10^-v, u, v uniform in (0, 2.5)):")
    first = {}
    for lo, hi in bins:
        n = fails = 0; mn = np.inf
        for _ in range(40000):
            r = np.exp(rng.uniform(np.log(lo), np.log(hi)))
            rho = 1 - 10 ** -rng.uniform(0, 2.5)
            x1, x2 = 1 - 10 ** -rng.uniform(0, 2.5, 2)
            w = worst(rho, r, x1, x2)
            n += 1; fails += w < -1e-12; mn = min(mn, w)
            if w < -1e-12:
                ps = pstar(rho, r, x1, x2)
                m0 = next(m for m in range(2, 61) if lam_min(rho, r, x1, x2, ps, m) < -1e-12 * ps)
                first[m0] = first.get(m0, 0) + 1
        print(f"  r in [{lo}, {hi}): {fails} of {n} cases with some lam_min(M_m) < 0 at p*; min lam_min/p* = {mn:+.3e}")
    print("  first failing level m in the failing cases:", dict(sorted(first.items())))
    print("(3) the point (rho, r, x1, x2, p) = (0.97, 8, 0.95, 0.5, 47): min over m = 1..60 of lam_min(M_m) =",
          f"{min(lam_min(0.97, 8, 0.95, 0.5, 47, m) for m in range(1, 61)):+.4e}")
    print("(2) targeted minimisation of min_m lam_min(M_m)/p* over (rho, x1, x2) at fixed r:")
    for r in (0.5, 0.9, 1.5, 2.0, 2.2, 2.5, 3.0, 5.0):
        best = np.inf
        for _ in range(60):
            z0 = rng.normal(0, 2, 3)
            f = lambda z: worst(1 / (1 + np.exp(-z[0])), r, 1 / (1 + np.exp(-z[1])), 1 / (1 + np.exp(-z[2])))
            res = minimize(f, z0, method="Nelder-Mead", options={"maxiter": 2000, "xatol": 1e-10, "fatol": 1e-15})
            best = min(best, res.fun)
        print(f"  r = {r}: min over parameters of min_m lam_min(M_m)/p* = {best:+.3e}", flush=True)
