"""Floating-point attack (evidence only) on the open case of RESULT_forward_real_hypercontractivity, Section 6:
two rho-correlated functions (k = 1), unequal parameters x1, x2, 1 < r <= 2, at the threshold p* of (2.17):
    ||T_{x1} f(X) T_{x2} g(Y)||_{L^r} <= ||f(X) g(Y)||_{L^p}.
Test functions f, g = exp(sum_{k=1}^{6} a_k T_k(s)), T_k Chebyshev, s = t/sqrt(16 + t^2), a = AMAX tanh(v)
(non-Gaussian, bounded log f). Mehler operator by 1D Gauss-Hermite
quadrature, expectations by tensor quadrature; BFGS with NQ = 48, then re-evaluation with 80 and 120 nodes; only
optimisers whose two re-evaluated values agree (relative 1e-3) are reported, with the finest value.
"""
import sys
import warnings
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from numpy.polynomial.hermite_e import hermevander
from scipy.optimize import minimize, brentq

warnings.filterwarnings("ignore")
K = 6


def pstar(r, rho, x1, x2):
    def det(p):
        a, b = p - 1 - (r - 1) * x1 ** 2, p - 1 - (r - 1) * x2 ** 2
        return a * b - ((p - r * x1 * x2) * rho) ** 2
    lo = max(1 + (r - 1) * x1 ** 2, 1 + (r - 1) * x2 ** 2, r) + 1e-12
    hi = 1e4
    return brentq(det, lo, hi) if det(lo) < 0 else lo


def make(NQ, rho, x1, x2):
    xs, ws = hermegauss(NQ)
    ws = ws / np.sqrt(2 * np.pi)
    X = np.repeat(xs, NQ)
    Y = rho * X + np.sqrt(1 - rho * rho) * np.tile(xs, NQ)
    W = np.repeat(ws, NQ) * np.tile(ws, NQ)
    return xs, ws, X, Y, W


AMAX = 0.3


def basis(t):
    return hermevander(t / np.sqrt(1 + t * t / 16), K)[:, 1:]


def Tx(logcoef, x, pts, xs, ws):
    z = x * pts[:, None] + np.sqrt(1 - x * x) * xs[None, :]
    lf = basis(z.ravel()).dot(logcoef).reshape(z.shape)
    m = lf.max(axis=1, keepdims=True)
    return np.log(np.sum(ws[None, :] * np.exp(lf - m), axis=1)) + m[:, 0]


def ratio(par, r, p, x1, x2, Q):
    xs, ws, X, Y, W = Q
    a, b = AMAX * np.tanh(par[:K]), AMAX * np.tanh(par[K:])
    lt = r * (Tx(a, x1, X, xs, ws) + Tx(b, x2, Y, xs, ws))
    m = lt.max()
    L = (np.log(np.sum(W * np.exp(lt - m))) + m) / r
    lp = p * (basis(X) @ a + basis(Y) @ b)
    m2 = lp.max()
    R = (np.log(np.sum(W * np.exp(lp - m2))) + m2) / p
    return L - R


if __name__ == "__main__":
    rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
    cases = [(1.5, 0.8, 0.95, 0.5), (2.0, 0.8, 0.95, 0.5), (2.0, 0.9, 0.99, 0.7), (1.5, 0.6, 0.9, 0.2),
             (1.8, 0.95, 0.98, 0.6)]
    for (r, rho, x1, x2) in cases:
        p = pstar(r, rho, x1, x2)
        Qs = [make(n, rho, x1, x2) for n in (48, 80, 120)]
        stable = []
        for it in range(16):
            x0 = rng.normal(0, 0.3, 2 * K)
            res = minimize(lambda v: -ratio(v, r, p, x1, x2, Qs[0]), x0, method="BFGS", options={"maxiter": 200})
            if not np.isfinite(res.fun):
                continue
            vals = [-res.fun] + [ratio(res.x, r, p, x1, x2, Q) for Q in Qs[1:]]
            if abs(vals[1] - vals[2]) <= 1e-3 * max(abs(vals[2]), 1e-9):
                stable.append(vals[-1])
        print(f"r={r}, rho={rho}, x=({x1},{x2}), p*={p:.5f}: {len(stable)} stable optimisers, best stable log-ratio "
              f"{max(stable) if stable else float('nan'):+.3e} (> 0 would be a violation)", flush=True)
