"""Floating-point scan (evidence only) for Theorem 6.9 of RESULT_forward_real_hypercontractivity: does the hypothesis
(a) + (c) hold for the minimal solution of the differential inequality (b)? Random points with 1 < r <= 2 and with
2 < r <= 8; sanity checks: the certified counterexamples (E1)-(E3) and random points with r > 2 where some chaos
matrix M_m is indefinite at p* (sufficiency is false there, so the hypothesis must fail)."""
import numpy as np
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
def pstar(r, rho, x1, x2):
    det=lambda p:(p-1-(r-1)*x1**2)*(p-1-(r-1)*x2**2)-((p-r*x1*x2)*rho)**2
    lo=max(1+(r-1)*x1**2,1+(r-1)*x2**2,r,1.0)+1e-12
    return brentq(det,lo,1e5) if det(lo)<0 else None
def analyse(r,rho,x1,x2,verbose=False):
    ps=pstar(r,rho,x1,x2)
    if ps is None: return None
    M11=ps-1-(r-1)*x1**2; M12=(ps-r*x1*x2)*rho
    kap=M11/M12
    N11,N22,N12=1+(r-1)*x1**2,1+(r-1)*x2**2,r*rho*x1*x2
    c1=N11-kap*N12; c2=N12-kap*N22
    phimin=max((1-c1)/kap, c2+kap)
    phmax=lambda q: min((q-c1)/(kap*q),(kap*q+c2)/q)
    phi0=rho*x1*x2
    start=max(phi0,phimin)
    if start>phmax(r)+1e-12: return (ps,False,'start')
    # minimal growth ODE phi' = max(g1/(kap q), kap g2/q)
    def rhs(q,y):
        ph=y[0]; g1=(c1-1+kap*ph)/(q-1); g2=(ph-c2-kap)/(kap*(q-1))
        return [max(g1/(kap*q),kap*g2/q,0.0)]
    qs=np.linspace(r,ps,2001)
    sol=solve_ivp(rhs,(r,ps),[start],t_eval=qs,rtol=1e-10,atol=1e-12)
    ph=sol.y[0]
    margin=min(phmax(q)-p for q,p in zip(qs,ph))
    ok=margin>=-1e-9
    return (ps,ok,'path' if not ok else 'ok', margin)
rng=np.random.default_rng(0)
cnt=0; okc=0; reasons={'start':0,'path':0}
examples=[]
for it in range(4000):
    r=rng.uniform(1.0001,2.0); rho=rng.uniform(0.05,0.95); x1,x2=rng.uniform(0.05,1.0,2)
    if abs(x1-x2)<0.02: continue
    res=analyse(r,rho,x1,x2)
    if res is None: continue
    cnt+=1
    if res[1]: okc+=1; examples.append((r,rho,x1,x2,res[0],res[3]))
    else: reasons[res[2]]+=1
print(f"random open-case points with a threshold p*: {cnt}; lossless path exists: {okc}; failures: {reasons}")
for e in examples[:12]: print("  r=%.3f rho=%.3f x=(%.3f,%.3f) p*=%.4f margin=%.3e"%e)
for c in ((1.5,0.8,0.95,0.5),(1.5,0.6,0.9,0.2),(1.2,0.5,0.8,0.3),(2.0,0.8,0.95,0.5),(1.5,0.8,0.7,0.7)):
    print(c, analyse(*c))

print("--- sanity: certified counterexamples of the forward note (must NOT have lossless paths) ---")
for name,(rho,r,x1,x2) in (("E1",(0.97,5,1.0,0.8)),("E2",(0.98,8,0.98,0.8)),("E3",(0.97,8,0.95,0.5))):
    print(name, (rho,r,x1,x2), analyse(r,rho,x1,x2))
cnt=0; okc=0
rng=np.random.default_rng(1)
for it in range(3000):
    r=rng.uniform(2.0,8.0); rho=rng.uniform(0.05,0.99); x1,x2=rng.uniform(0.05,1.0,2)
    res=analyse(r,rho,x1,x2)
    if res is None: continue
    cnt+=1; okc+=res[1]
print(f"r in (2,8]: {cnt} points, lossless path exists at {okc}")

def Mm(m,r,rho,x1,x2,p):
    return np.array([[p-1-(r-1)*x1**(2*m),(p-r*(x1*x2)**m)*rho**m],[(p-r*(x1*x2)**m)*rho**m,p-1-(r-1)*x2**(2*m)]])
rng=np.random.default_rng(7)
bad=0; tested=0; okcount=0
for it in range(200000):
    r=rng.uniform(2.0,12.0); rho=rng.uniform(0.85,0.999); x1=rng.uniform(0.9,1.0); x2=rng.uniform(0.3,1.0)
    ps=pstar(r,rho,x1,x2)
    if ps is None: continue
    lam=min(np.linalg.eigvalsh(Mm(m,r,rho,x1,x2,ps))[0] for m in range(2,30))
    if lam< -1e-9:
        tested+=1
        res=analyse(r,rho,x1,x2)
        if res[1]:
            bad+=1
            if bad<5: print("CONTRADICTION at",r,rho,x1,x2,ps,lam,res)
    if tested>=400: break
print(f"points with a failing chaos level at p* (sufficiency false): {tested}; lossless path claimed at {bad}")
# also: points where lossless path claimed -> check all chaos levels nonnegative
cl=0; viol=0
for it in range(20000):
    r=rng.uniform(1.0,12.0); rho=rng.uniform(0.05,0.999); x1,x2=rng.uniform(0.05,1.0,2)
    res=analyse(r,rho,x1,x2)
    if res is None or not res[1]: continue
    cl+=1
    ps=res[0]
    lam=min(np.linalg.eigvalsh(Mm(m,r,rho,x1,x2,ps))[0] for m in range(1,30))
    if lam< -1e-8*ps: viol+=1
print(f"points with a lossless path: {cl}; of these with a negative chaos level: {viol}")


# Corollary 6.10: closed-form criterion w_j(r, phi_s) <= 1, compared with the integration of the extremal ODE above
def explicit(r, rho, x1, x2):
    ps = pstar(r, rho, x1, x2)
    if ps is None:
        return None
    M11 = ps - 1 - (r - 1) * x1 ** 2
    M12 = (ps - r * x1 * x2) * rho
    kap = M11 / M12
    al1, al2 = 1 + (r - 1) * x1 ** 2, 1 + (r - 1) * x2 ** 2
    c1 = al1 - kap * r * rho * x1 * x2
    c2 = r * rho * x1 * x2 - kap * al2
    phis = max(rho * x1 * x2, (1 - c1) / kap, c2 + kap)
    w1 = (c1 - 1 + kap * r * phis) / (r - 1)
    w2 = (r * phis - c2 - kap) / (kap * (r - 1))
    return w1 <= 1 + 1e-12 and w2 <= 1 + 1e-12


rng = np.random.default_rng(11)
agree = disagree = 0
for it in range(20000):
    r = rng.uniform(1.0001, 8.0); rho = rng.uniform(0.02, 0.99); x1, x2 = rng.uniform(0.02, 1.0, 2)
    a = analyse(r, rho, x1, x2)
    if a is None:
        continue
    if bool(a[1]) == bool(explicit(r, rho, x1, x2)):
        agree += 1
    else:
        disagree += 1
print(f"Corollary 6.10 criterion vs integration of the extremal ODE: agree at {agree} points, disagree at {disagree}")

# where the criterion of Corollary 6.10 fails (1 < r <= 2): by rho and by max(x1, x2)
import collections
rng = np.random.default_rng(21)
tab = collections.defaultdict(lambda: [0, 0])
smallest = 2.0
for it in range(300000):
    r = rng.uniform(1.0001, 2.0); rho = rng.uniform(0.0, 0.9999); x1, x2 = rng.uniform(0.0, 1.0, 2)
    try:
        ok = explicit(r, rho, x1, x2)
    except (ValueError, RuntimeError, ZeroDivisionError):
        continue
    if ok is None:
        continue
    key = (min(int(rho * 5), 4), min(int(max(x1, x2) * 5), 4))
    tab[key][0] += 1
    tab[key][1] += (not ok)
    if not ok:
        smallest = min(smallest, max(x1, x2))
print("failure fraction of the criterion of Corollary 6.10, 1 < r <= 2 (rows: rho, columns: max(x1,x2), bins 0.2):")
for i in range(5):
    print(f"  rho in [{i / 5:.1f},{(i + 1) / 5:.1f}): " + " ".join(
        f"{tab[(i, j)][1] / tab[(i, j)][0]:5.2f}" if tab[(i, j)][0] else "  -  " for j in range(5)))
print(f"smallest max(x1, x2) among failures: {smallest:.4f}")
