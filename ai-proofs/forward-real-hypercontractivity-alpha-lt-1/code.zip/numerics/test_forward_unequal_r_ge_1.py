"""n = 2, unequal parameters, r >= 1: search for violations just inside the conjectured region (floating point).

For (rho, r, x1, x2) where the lossless matrix flow is impossible (the scaled extremal direction S v* has
|w2/w1| outside [theta, 1/theta] somewhere on the straight path), take p = p* (1 + 1e-2), where p* is the smallest p
with M(p) >= 0 ([IK25, (2.17)]), and search for f, g with log-ratio > 0.
"""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.optimize import brentq, minimize

rng = np.random.default_rng(11)
ND, WT = hermegauss(100)
WT = WT / WT.sum()


def Tfun(fun, s):
    c = np.sqrt(max(0.0, 1 - s * s))
    def h(y):
        y = np.asarray(y, dtype=float)
        return (fun(s * y[..., None] + c * ND) * WT).sum(-1)
    return h


def Eprod(hs, rho):
    pts = np.sqrt(rho) * ND[:, None] + np.sqrt(1 - rho) * ND[None, :]
    out = np.ones(len(ND))
    for h in hs:
        out = out * (h(pts) * WT[None, :]).sum(1)
    return (out * WT).sum()


def logratio(f, g, x1, x2, rho, r, p):
    Tf, Tg = Tfun(f, x1), Tfun(g, x2)
    lhs = np.log(Eprod([lambda t: Tf(t) ** r, lambda t: Tg(t) ** r], rho)) / r
    rhs = np.log(Eprod([lambda t: f(t) ** p, lambda t: g(t) ** p], rho)) / p
    return lhs - rhs


def Mmat(x1, x2, rho, r, p):
    return np.array([[p - 1 - (r - 1) * x1 ** 2, (p - r * x1 * x2) * rho],
                     [(p - r * x1 * x2) * rho, p - 1 - (r - 1) * x2 ** 2]])


def pstar(x1, x2, rho, r):
    f = lambda p: np.linalg.eigvalsh(Mmat(x1, x2, rho, r, p))[0]
    return r if f(r) >= 0 else brentq(f, r, 50.0)


cases = [(0.6, 1.5, 0.95, 0.3), (0.5, 2.0, 0.9, 0.2), (0.8, 1.2, 0.99, 0.5), (0.4, 3.0, 0.8, 0.15)]
for (rho, r, x1, x2) in cases:
    ps = pstar(x1, x2, rho, r)
    p = ps * 1.01
    M = Mmat(x1, x2, rho, r, p)
    ev, evec = np.linalg.eigh(M)
    v = evec[:, 0]
    a0 = 0.8 * v / np.linalg.norm(v)
    expo = logratio(lambda t: np.exp(a0[0] * t), lambda t: np.exp(a0[1] * t), x1, x2, rho, r, p)

    def neg(th):
        a1, a2, c1, c2, d1, d2, w1, w2, e1, e2 = th
        f = lambda t: np.exp(np.clip(a1 * t + c1 * np.tanh(w1 * (t - d1)) + e1 * np.exp(-(t - d1) ** 2), -50, 50))
        g = lambda t: np.exp(np.clip(a2 * t + c2 * np.tanh(w2 * (t - d2)) + e2 * np.exp(-(t - d2) ** 2), -50, 50))
        val = logratio(f, g, x1, x2, rho, r, p)
        return -val if np.isfinite(val) else 1e3

    best = -np.inf
    for k in range(8):
        th0 = np.concatenate([a0 * rng.uniform(0.3, 1.5), rng.normal(0, 0.7, 8)])
        res = minimize(neg, th0, method="Nelder-Mead", options={"maxiter": 1500, "xatol": 1e-7, "fatol": 1e-12})
        best = max(best, -res.fun)
    print(f"rho={rho}, r={r}, x=({x1},{x2}), p*={ps:.4f}, p={p:.4f}: eig(M)=({ev[0]:+.4f},{ev[1]:+.4f}); "
          f"bottom-eigenvector exponentials {expo:+.3e}; optimised {best:+.3e}", flush=True)
