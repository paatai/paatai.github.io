"""Forward real inequality with UNEQUAL parameters (n = 2): numerical test of the natural conjecture (floating point).

|| T_{x1} f(X) T_{x2} g(Y) ||_r <= || f(X) g(Y) ||_p,  (X, Y) rho-correlated, p >= 1, 0 < r < p.
Conjecture ([IK25, (2.17)] with alpha = r/p): M = [[p-1-(r-1)x1^2, (p - r x1 x2) rho], [., p-1-(r-1)x2^2]] >= 0.
Exponentials f = e^{a y}, g = e^{b y} give log-ratio -(a,b) M (a,b)^T / 2, so M >= 0 is necessary.
The equal-parameter proof (RESULT_forward_real_hypercontractivity) gives sufficiency only under the stronger
condition obtained by equalising x1, x2 at q = 1, e.g. (1 - r(1-rho)) x1 x2 >= 1 - p(1-rho) for r <= 1.
Here we test points where M >= 0 holds but that sufficient condition fails, with random and optimised functions.
"""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.optimize import minimize

rng = np.random.default_rng(5)
ND, WT = hermegauss(100)
WT = WT / WT.sum()


def Tfun(fun, s):
    c = np.sqrt(max(0.0, 1 - s * s))
    def h(y):
        y = np.asarray(y, dtype=float)
        return (fun(s * y[..., None] + c * ND) * WT).sum(-1)
    return h


def Eprod(hs, rho):
    pts = np.sqrt(rho) * ND[:, None] + np.sqrt(1 - rho) * ND[None, :]
    out = np.ones(len(ND))
    for h in hs:
        out = out * (h(pts) * WT[None, :]).sum(1)
    return (out * WT).sum()


def logratio(f, g, x1, x2, rho, r, p):
    Tf, Tg = Tfun(f, x1), Tfun(g, x2)
    lhs = np.log(Eprod([lambda t: Tf(t) ** r, lambda t: Tg(t) ** r], rho)) / r
    rhs = np.log(Eprod([lambda t: f(t) ** p, lambda t: g(t) ** p], rho)) / p
    return lhs - rhs


def Mmat(x1, x2, rho, r, p):
    return np.array([[p - 1 - (r - 1) * x1 ** 2, (p - r * x1 * x2) * rho],
                     [(p - r * x1 * x2) * rho, p - 1 - (r - 1) * x2 ** 2]])


cases = [(0.5, 1.5, 0.5, 0.9, 0.3), (0.5, 1.5, 0.5, 0.95, 0.25), (0.6, 1.6, 1.5, 0.95, 0.55),
         (0.7, 2.0, 1.8, 0.98, 0.62), (0.5, 1.4, 0.3, 0.9, 0.2), (0.4, 1.3, 1.2, 0.97, 0.5)]
for (rho, p, r, x1, x2) in cases:
    M = Mmat(x1, x2, rho, r, p)
    lam = np.linalg.eigvalsh(M)
    suff = (1 - r * (1 - rho)) * x1 * x2 - (1 - p * (1 - rho)) if r <= 1 else None
    worst = -np.inf
    for _ in range(80):
        a = rng.normal(0, 0.8, 4)
        d = rng.normal(0, 1.0, 4)
        w = rng.uniform(0.3, 2.0, 2)
        f = lambda t, a=a, d=d, w=w: np.exp(a[0] * t + a[1] * np.tanh(w[0] * (t - d[0])) + 0.3 * np.sin(w[1] * t + d[1]))
        g = lambda t, a=a, d=d, w=w: np.exp(a[2] * t + a[3] * np.tanh(w[1] * (t - d[2])) + 0.3 * np.cos(w[0] * t + d[3]))
        worst = max(worst, logratio(f, g, x1, x2, rho, r, p))

    def neg(th):
        a1, a2, c1, c2, d1, d2, w1, w2 = th
        f = lambda t: np.exp(a1 * t + c1 * np.tanh(w1 * (t - d1)))
        g = lambda t: np.exp(a2 * t + c2 * np.tanh(w2 * (t - d2)))
        return -logratio(f, g, x1, x2, rho, r, p)

    best = -np.inf
    for _ in range(6):
        res = minimize(neg, rng.normal(0, 0.7, 8), method="Nelder-Mead", options={"maxiter": 800})
        best = max(best, -res.fun)
    print(f"rho={rho}, p={p}, r={r}, x=({x1},{x2}): eig(M)=({lam[0]:+.4f},{lam[1]:+.4f}), "
          f"equalised sufficient condition margin={suff if suff is None else round(suff, 4)}; "
          f"max log-ratio random {worst:+.3e}, optimised {best:+.3e}", flush=True)
