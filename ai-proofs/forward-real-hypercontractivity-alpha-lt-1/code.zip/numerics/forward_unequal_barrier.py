"""Dilation barrier for the chaos conditions (RESULT_forward_real_hypercontractivity, Proposition 6.6 and the text
after it). Floating point; evidence only.

In log coordinates rho = e^{-sigma}, x1^2 = e^{-u}, x2^2 = e^{-v}, M_m is M at (m sigma, m u, m v), and det M >= 0
iff sigma >= sigma*(u, v) = chi((u+v)/2) - phi(u)/2 - phi(v)/2, phi(s) = log(p-1-(r-1)e^{-s}), chi(s) = log(p - r e^{-s}).
"M >= 0 implies M_m >= 0 for all m" follows if sigma*(t u, t v) <= t sigma*(u, v) for t >= 1, i.e. if
Psi = 2 [sigma* - (u d_u + v d_v) sigma*] = g(u) + g(v) - 2 h((u+v)/2) >= 0, g = s phi' - phi, h = s chi' - chi.
We sample Psi at random (u, v, p, r) with p > r, p >= 1.
"""
import numpy as np

rng = np.random.default_rng(2)


def Psi(u, v, p, r):
    A, c = p - 1, r - 1
    phi = lambda s: np.log(A - c * np.exp(-s)); dphi = lambda s: c / (A * np.exp(s) - c)
    chi = lambda s: np.log(p - r * np.exp(-s)); dchi = lambda s: r / (p * np.exp(s) - r)
    g = lambda s: s * dphi(s) - phi(s); h = lambda s: s * dchi(s) - chi(s)
    return g(u) + g(v) - 2 * h((u + v) / 2)


if __name__ == "__main__":
    for lo, hi in [(0.05, 1), (1, 2), (2, 2.5), (2.5, 5), (5, 10)]:
        neg = tot = 0; mn = np.inf
        for _ in range(300000):
            r = rng.uniform(lo, hi); p = max(r, 1.0) + np.exp(rng.uniform(-7, 5))
            u, v = np.exp(rng.uniform(-9, 3, 2))
            if (p - 1) - (r - 1) * np.exp(-u) <= 0 or (p - 1) - (r - 1) * np.exp(-v) <= 0:
                continue
            val = Psi(u, v, p, r)
            tot += 1; mn = min(mn, val); neg += val < -1e-12
        print(f"r in [{lo}, {hi}): {tot} points, Psi < 0 at {neg}; min Psi = {mn:+.3e}", flush=True)
    from scipy.optimize import minimize
    import mpmath as mp
    mp.mp.dps = 50

    def Psi_mp(u, v, p, r):
        u, v, p, r = map(mp.mpf, (u, v, p, r)); A, c = p - 1, r - 1
        phi = lambda s: mp.log(A - c * mp.e ** (-s)); dphi = lambda s: c / (A * mp.e ** s - c)
        chi = lambda s: mp.log(p - r * mp.e ** (-s)); dchi = lambda s: r / (p * mp.e ** s - r)
        g = lambda s: s * dphi(s) - phi(s); h = lambda s: s * dchi(s) - chi(s)
        return g(u) + g(v) - 2 * h((u + v) / 2)

    print("targeted minimisation of Psi over (u, v, p) at fixed r (u, v <= e^3; minimiser re-evaluated in 50 digits):")
    for r in (1.5, 2.0, 2.01, 2.05):
        best, arg = np.inf, None
        for _ in range(200):
            z0 = np.array([rng.uniform(-9, 3), rng.uniform(-9, 3), rng.uniform(-6, 6)])
            def f(z):
                z = np.clip(z, [-30, -30, -12], [3, 3, 8])
                u, v, p = np.exp(z[0]), np.exp(z[1]), max(r, 1.0) + np.exp(z[2])
                if (p - 1) - (r - 1) * np.exp(-u) <= 0 or (p - 1) - (r - 1) * np.exp(-v) <= 0:
                    return 1e3
                val = Psi(u, v, p, r)
                return val if np.isfinite(val) else 1e3
            res = minimize(f, z0, method="Nelder-Mead", options={"maxiter": 3000, "xatol": 1e-12, "fatol": 1e-16})
            if res.fun < best:
                best, arg = res.fun, np.clip(res.x, [-30, -30, -12], [3, 3, 8])
        u, v, p = np.exp(arg[0]), np.exp(arg[1]), max(r, 1.0) + np.exp(arg[2])
        print(f"  r = {r}: min Psi = {best:+.3e} (float) at u = {u:.2e}, v = {v:.2e}, p = {p:.4g}; "
              f"50-digit value there: {mp.nstr(Psi_mp(u, v, p, r), 4)}", flush=True)
