"""Certificate for Proposition 6.11 (Theorem 6.9, Corollary 6.10) of RESULT_forward_real_hypercontractivity (Arb ball arithmetic, python-flint).

Two rho-correlated functions, unequal parameters x1, x2 in (0,1], r > 1. With M = M_1 the matrix of (2.17) and p* its
threshold (largest root of det M(p) = 0), let kappa = M_11(p*)/M_12(p*), c1 = 1 + (r-1) x1^2 - kappa r rho x1 x2,
c2 = r rho x1 x2 - kappa (1 + (r-1) x2^2), gamma1(phi) = c1 - 1 + kappa phi, gamma2(phi) = phi - c2 - kappa,
phi_min = max((1 - c1)/kappa, c2 + kappa). Theorem 6.9: if a continuous, piecewise C^1, non-decreasing phi on [r, p*]
has phi(r) >= max(rho x1 x2, phi_min), gamma1(phi(r)) + gamma2(phi(r)) > 0,
    phi' >= max(gamma1(phi)/(kappa q (q-1)), gamma2(phi)/(q (q-1)))   on each piece,   and   phi(p*) <= rho,
then (2.16) with alpha = r/p holds at p = p*, so (2.17) is sufficient (and sharp) at this point.
The script checks the closed-form criterion of Corollary 6.10 (w_j(r, phi_s) <= 1, phi_s = max(rho x1 x2, phi_min)),
and, independently, builds a polygonal phi on K pieces of [r, p*] and verifies all conditions in ball arithmetic. On a piece
[q_k, q_{k+1}] the right side is increasing in phi (gamma_j increasing, gamma_j >= 0) and decreasing in q, so it is
bounded by its value at (q_k, phi_{k+1}); the slope sigma_k is chosen above that bound and the bound is re-checked.
"""
import sys
from fractions import Fraction as F
import flint

flint.ctx.prec = 256

arb = flint.arb


def A(x):
    x = F(x)
    return arb(x.numerator) / x.denominator


def certify(rho, r, x1, x2, K=400, verbose=True):
    rho, r, x1, x2 = A(rho), A(r), A(x1), A(x2)
    al1, al2, be = 1 + (r - 1) * x1 ** 2, 1 + (r - 1) * x2 ** 2, r * x1 * x2
    # det M(p) = (p - al1)(p - al2) - rho^2 (p - be)^2 = a p^2 + b p + c
    a = 1 - rho ** 2
    b = -(al1 + al2) + 2 * rho ** 2 * be
    c = al1 * al2 - rho ** 2 * be ** 2
    ps = (-b + (b ** 2 - 4 * a * c).sqrt()) / (2 * a)
    ok = bool(ps > al1) and bool(ps > al2) and bool(ps > r)
    kap = (ps - al1) / ((ps - be) * rho)
    ok &= bool(kap > 0)
    c1 = al1 - kap * rho * be
    c2 = rho * be - kap * al2
    g1 = lambda ph: c1 - 1 + kap * ph
    g2 = lambda ph: ph - c2 - kap
    phi0 = rho * x1 * x2
    t1, t2 = (1 - c1) / kap, c2 + kap
    lo_start = max(phi0.upper(), t1.upper(), t2.upper())
    phis = arb(lo_start) * (1 + arb(1) / 10 ** 9)  # a value certainly >= max(phi0, phi_min)
    ok &= bool(phis >= phi0) and bool(phis >= t1) and bool(phis >= t2) and bool(g1(phis) + g2(phis) > 0)
    # Corollary 6.10: closed-form criterion
    w1s = (c1 - 1 + kap * r * phis) / (r - 1)
    w2s = (r * phis - c2 - kap) / (kap * (r - 1))
    cor_ok = bool(w1s <= 1) and bool(w2s <= 1) and bool(g1(phis) + g2(phis) > 0)
    K0 = 1 - c1 - kap * c2 - kap ** 2
    dq = (ps - r) / K
    ph = phis
    minslack = None
    for k in range(K):
        q = r + k * dq
        den = q * (q - 1) - dq
        if not bool(den > 0):
            return False, "piece too long"
        s1 = (g1(ph) / (kap * den)).upper()
        s2 = (g2(ph) / den).upper()
        sig = arb(max(s1, s2, 0)) * (1 + arb(1) / 10 ** 6)
        ph_next = ph + sig * dq
        need = max((g1(ph_next) / (kap * q * (q - 1))).upper(), (g2(ph_next) / (q * (q - 1))).upper())
        ok &= bool(sig >= arb(need)) and bool(g1(ph) >= 0) and bool(g2(ph) >= 0)
        ph = ph_next
    end_ok = bool(ph <= rho)
    ok &= end_ok
    if verbose:
        print(f"rho={rho.str(6)}, r={r.str(6)}, x=({x1.str(6)},{x2.str(6)}): p* = {ps.str(12)}, kappa = {kap.str(8)}, "
              f"phi_start = {phis.str(8)}; Corollary 6.10: w(r, phi_s) = ({w1s.str(6)}, {w2s.str(6)}) <= 1, K0 = "
              f"{K0.str(4)}: {cor_ok}; polygonal path (Theorem 6.9): phi(p*) = {ph.str(8)} <= rho: {end_ok}; "
              f"all checks: {'PASSED' if (ok and cor_ok) else 'FAILED'}")
    return ok and cor_ok, ps


if __name__ == "__main__":
    pts = [(F(3, 5), F(3, 2), F(9, 10), F(1, 5)), (F(1, 2), F(6, 5), F(4, 5), F(3, 10)),
           (F(7, 10), F(2), F(7, 10), F(2, 5)), (F(4, 5), F(9, 5), F(3, 5), F(3, 4))]
    allok = True
    for P in pts:
        ok, _ = certify(*P)
        allok &= ok
    print("CERTIFIED: (2.17) is sufficient at all listed points (Theorem 6.9, Corollary 6.10)" if allok else "NOT CERTIFIED")
    print("sanity (must fail): certified counterexample E1 of Proposition 6.3:")
    certify(F(97, 100), F(5), F(1), F(4, 5))
