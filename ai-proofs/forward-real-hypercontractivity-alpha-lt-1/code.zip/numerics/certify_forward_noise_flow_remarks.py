"""Ball-arithmetic checks (python-flint, 256 bits) of the closed-form statements made after Corollary 6.10 and in the
proof of Proposition 6.11 of RESULT_forward_real_hypercontractivity.

Notation as in certify_forward_noise_flow.py: alpha_j = 1 + (r-1) x_j^2, beta = r x1 x2, p* the larger root of
det M(p) = (p - alpha_1)(p - alpha_2) - rho^2 (p - beta)^2, kappa = M_11(p*)/M_12(p*), c1, c2 as in the note,
phi_s = max(rho x1 x2, (1 - c1)/kappa, c2 + kappa), and
    w1(q, phi) = (c1 - 1 + kappa q phi)/(q - 1),    w2(q, phi) = (q phi - c2 - kappa)/(kappa (q - 1)).
By Corollary 6.10 (both directions) the hypothesis of Theorem 6.9 fails as soon as max_j w_j(r, phi_s) > 1. Since w_j(r, .)
is increasing, w_j(r, phi_s) >= w_j(r, phi) for each of the three candidates phi in the max, which gives rigorous lower
bounds without deciding the max.

(1) (rho, x1, x2) = (3/5, 1, 3/10): w_1(r, phi_s) > 1.09 at r = 1 + j/100, j = 1..100, and at r = 1 + 10^-k,
    k = 3..8 (the values approach 1.09 as r -> 1; at r = 1, (2.17) is sufficient by Proposition 6.1).
(2) (rho, r, x1, x2) = (3/5, 11/10, 99/100, 3/10): w_1(r, phi_s) > 1.
(3) (r, rho, x1, x2) = (2, 6249/6250, 163/400, 4083/5000): w_2(r, phi_s) > 1 although max(x1, x2) < 0.8166.
(4) End values phi(p*) of the exact path of Corollary 6.10 (w_1 or w_2 held constant) at the four points of
    Proposition 6.11.
(5) w_1(r, phi_s) > 1 at (rho, r, x1, x2) = (4/5, 3/2, 19/20, 1/2), (4/5, 2, 19/20, 1/2), (3/5, 2, 1, 3/10), where
    forward_noise_flow_nonhyp_attack.py was run at p = p*.
"""
from fractions import Fraction as F
import flint

flint.ctx.prec = 256
arb = flint.arb


def A(x):
    x = F(x)
    return arb(x.numerator) / x.denominator


def data(rho, r, x1, x2):
    rho, r, x1, x2 = A(rho), A(r), A(x1), A(x2)
    al1, al2, be = 1 + (r - 1) * x1 ** 2, 1 + (r - 1) * x2 ** 2, r * x1 * x2
    a = 1 - rho ** 2
    b = -(al1 + al2) + 2 * rho ** 2 * be
    c = al1 * al2 - rho ** 2 * be ** 2
    ps = (-b + (b ** 2 - 4 * a * c).sqrt()) / (2 * a)
    assert bool(ps > al1) and bool(ps > al2) and bool(ps > r), "p* <= max(alpha_j, r): outside the range of Thm 6.9"
    kap = (ps - al1) / ((ps - be) * rho)
    assert bool(kap > 0)
    c1 = al1 - kap * rho * be
    c2 = rho * be - kap * al2
    cands = [rho * x1 * x2, (1 - c1) / kap, c2 + kap]
    w1 = lambda q, ph: (c1 - 1 + kap * q * ph) / (q - 1)
    w2 = lambda q, ph: (q * ph - c2 - kap) / (kap * (q - 1))
    return dict(rho=rho, r=r, ps=ps, kap=kap, c1=c1, c2=c2, cands=cands, w1=w1, w2=w2)


def wmax_lower(d):
    """rigorous lower bounds for w_1(r, phi_s), w_2(r, phi_s): maxima over the candidates (balls)."""
    r = d["r"]
    l1 = max(d["w1"](r, ph).lower() for ph in d["cands"])
    l2 = max(d["w2"](r, ph).lower() for ph in d["cands"])
    return arb(l1), arb(l2)


def phis_exact(d):
    """phi_s as a ball, when the maximum among the candidates is decidable."""
    cs = d["cands"]
    i = max(range(3), key=lambda k: float(cs[k].mid()))
    assert all(k == i or bool(cs[i] > cs[k]) for k in range(3)), "max not decidable"
    return cs[i], i


allok = True
print("(1) (rho, x1, x2) = (3/5, 1, 3/10): lower bounds for w_1(r, phi_s)")
worst = None
for j in list(range(1, 101)):
    r = F(1) + F(j, 100)
    d = data(F(3, 5), r, F(1), F(3, 10))
    l1, l2 = wmax_lower(d)
    ok = bool(l1 > A(F(109, 100)))
    allok &= ok
    if worst is None or float(l1.mid()) < float(worst[1].mid()):
        worst = (r, l1)
    if j in (1, 10, 25, 50, 75, 100):
        print(f"   r = {float(r):.2f}: w_1(r, phi_s) >= {l1.str(8)}, w_2(r, phi_s) >= {l2.str(8)}  (w_1 > 1.09: {ok})")
print(f"   smallest lower bound for w_1 over r = 1 + j/100, j = 1..100: {worst[1].str(8)} at r = {float(worst[0]):.2f}")
for k in range(3, 9):
    r = F(1) + F(1, 10 ** k)
    d = data(F(3, 5), r, F(1), F(3, 10))
    l1, l2 = wmax_lower(d)
    ok = bool(l1 > A(F(109, 100)))
    allok &= ok
    print(f"   r = 1 + 1e-{k}: w_1(r, phi_s) >= {l1.str(10)}, w_2(r, phi_s) >= {l2.str(10)}  (w_1 > 1.09: {ok})")

print("(2) (rho, r, x1, x2) = (3/5, 11/10, 99/100, 3/10)")
d = data(F(3, 5), F(11, 10), F(99, 100), F(3, 10))
ph, i = phis_exact(d)
w1s, w2s = d["w1"](d["r"], ph), d["w2"](d["r"], ph)
ok = bool(w1s > 1)
allok &= ok
print(f"   p* = {d['ps'].str(12)}, kappa = {d['kap'].str(8)}, phi_s = candidate {i} = {ph.str(8)}; "
      f"w_1 = {w1s.str(8)}, w_2 = {w2s.str(8)}  (w_1 > 1: {ok})")

print("(3) (r, rho, x1, x2) = (2, 6249/6250, 163/400, 4083/5000)")
d = data(F(6249, 6250), F(2), F(163, 400), F(4083, 5000))
ph, i = phis_exact(d)
w1s, w2s = d["w1"](d["r"], ph), d["w2"](d["r"], ph)
ok = bool(w2s > 1)
allok &= ok
print(f"   p* = {d['ps'].str(12)}, kappa = {d['kap'].str(8)}, phi_s = candidate {i} = {ph.str(8)}; "
      f"w_1 = {w1s.str(10)}, w_2 = {w2s.str(10)}  (w_2 > 1: {ok})")

print("(4) exact path of Corollary 6.10 at the points of Proposition 6.11: end value phi(p*) against rho")
for P in [(F(3, 5), F(3, 2), F(9, 10), F(1, 5)), (F(1, 2), F(6, 5), F(4, 5), F(3, 10)),
          (F(7, 10), F(2), F(7, 10), F(2, 5)), (F(4, 5), F(9, 5), F(3, 5), F(3, 4))]:
    d = data(*P)
    ph, i = phis_exact(d)
    r, ps, kap, c1, c2 = d["r"], d["ps"], d["kap"], d["c1"], d["c2"]
    K0 = 1 - c1 - kap * c2 - kap ** 2
    assert bool(K0 < 0) or bool(K0 > 0)
    if bool(K0 < 0):
        W = d["w1"](r, ph)
        end = ((ps - 1) * W + 1 - c1) / (kap * ps)
        held = "w_1"
    else:
        W = d["w2"](r, ph)
        end = (kap * (ps - 1) * W + c2 + kap) / ps
        held = "w_2"
    ok = bool(end <= d["rho"]) and bool(ph > d["cands"][0])
    allok &= ok
    print(f"   (rho, r, x1, x2) = ({P[0]}, {P[1]}, {P[2]}, {P[3]}): pause needed (phi_s > rho x1 x2): "
          f"{bool(ph > d['cands'][0])}; K0 = {K0.str(4)}, {held} held at {W.str(6)}; phi(p*) = {end.str(8)} <= rho: "
          f"{bool(end <= d['rho'])}")

print("(5) further points where the criterion fails (used for the attacks at p = p*)")
for P in [(F(4, 5), F(3, 2), F(19, 20), F(1, 2)), (F(4, 5), F(2), F(19, 20), F(1, 2)), (F(3, 5), F(2), F(1), F(3, 10))]:
    d = data(*P)
    l1, l2 = wmax_lower(d)
    ok = bool(l1 > 1)
    allok &= ok
    print(f"   (rho, r, x1, x2) = ({P[0]}, {P[1]}, {P[2]}, {P[3]}): p* = {d['ps'].str(10)}, w_1(r, phi_s) >= {l1.str(6)} "
          f"(> 1: {ok})")

print("ALL CHECKS PASSED" if allok else "SOME CHECK FAILED")
