"""Checks for RESULT_forward_real_hypercontractivity with general (non-equicorrelated) covariances.

xi = (xi_1, ..., xi_n), xi_j standard real Gaussians, Sigma = cov(xi) a random correlation matrix, lam = lambda_min.
(A) Reverse correlated log-Sobolev with general pairing B (zero diagonal, B >= -Id):
    Ent(prod Psi_j(xi_j)) >= -lam * sum_{i<j} B_ij E[Psi_i'(xi_i) Psi_j'(xi_j) prod_{l != i,j} Psi_l(xi_l)].
    Tested with B = (Sigma - Id)/(1 - lam) and with random B scaled to lambda_min(B) = -1.
(B) The inequality || prod_j T_x f_j(xi_j) ||_r <= || prod_j f_j(xi_j) ||_p just above the threshold
    x^2 = (1 - p lam)/(1 - r lam) (random f_j), and its violation just below by exponentials along the bottom
    eigenvector.
Expectations of products of one-variable functions are computed exactly up to quadrature error by conditioning:
xi = sqrt(lam) A + eta, eta ~ N(0, Sigma - lam Id) (rank n-1), nested Gauss-Hermite quadrature.
Floating point; evidence for the algebra, not part of the proof.
"""
import itertools

import numpy as np
from numpy.polynomial.hermite_e import hermegauss

rng = np.random.default_rng(7)
ND, WT = hermegauss(60)
WT = WT / WT.sum()
fails = []


def random_corr(n):
    G = rng.normal(size=(n, n + 1))
    C = G @ G.T
    d = np.sqrt(np.diag(C))
    return C / np.outer(d, d)


def Eprod(hs, Sigma, lam):
    """E prod_j h_j(xi_j), xi ~ N(0, Sigma), using xi = sqrt(lam') A + eta with lam' slightly below lam."""
    n = len(hs)
    lamp = lam * (1 - 1e-9)
    evals, evecs = np.linalg.eigh(Sigma - lamp * np.eye(n))
    keep = evals > 1e-7
    L = evecs[:, keep] * np.sqrt(evals[keep])          # eta = L z, z standard of dim m
    m = L.shape[1]
    total = 0.0
    for idx in itertools.product(range(len(ND)), repeat=m):
        z = ND[list(idx)]
        w = np.prod(WT[list(idx)])
        eta = L @ z
        prod = 1.0
        for j, h in enumerate(hs):
            prod *= (h(eta[j] + np.sqrt(lamp) * ND) * WT).sum()
        total += w * prod
    return total


def ent_prod(psis, Sigma, lam):
    EH = Eprod(psis, Sigma, lam)
    s = 0.0
    for k in range(len(psis)):
        hs = list(psis)
        hs[k] = (lambda ps: (lambda t: ps(t) * np.log(ps(t))))(psis[k])
        s += Eprod(hs, Sigma, lam)
    return s - EH * np.log(EH)


def rand_logfun():
    a = rng.normal(0, 0.7)
    c = rng.normal(0, 0.7, 3)
    d = rng.normal(0, 1.0, 3)
    w = rng.uniform(0.3, 2.0)
    phi = lambda t: a * t + c[0] * np.tanh(t - d[0]) + c[1] * np.sin(w * t + d[1]) + c[2] * np.exp(-(t - d[2]) ** 2)
    dphi = lambda t: (a + c[0] / np.cosh(t - d[0]) ** 2 + c[1] * w * np.cos(w * t + d[1])
                      - 2 * c[2] * (t - d[2]) * np.exp(-(t - d[2]) ** 2))
    return phi, dphi


def Tfun(fun, s):
    c = np.sqrt(max(0.0, 1 - s * s))
    def h(y):
        y = np.asarray(y, dtype=float)
        return (fun(s * y[..., None] + c * ND) * WT).sum(-1)
    return h


print("(A) reverse correlated log-Sobolev with general B, n = 3", flush=True)
worst = np.inf
for trial in range(40):
    n = 3
    Sigma = random_corr(n)
    lam = np.linalg.eigvalsh(Sigma)[0]
    if lam < 0.05:
        continue
    if trial % 2 == 0:
        B = (Sigma - np.eye(n)) / (1 - lam)
    else:
        B = rng.normal(size=(n, n))
        B = (B + B.T) / 2
        np.fill_diagonal(B, 0.0)
        B = B / (-np.linalg.eigvalsh(B)[0])
    fs = [rand_logfun() for _ in range(n)]
    Ps = [(lambda ph: (lambda t: np.exp(ph(t))))(ph) for ph, _ in fs]
    dPs = [(lambda ph, dph: (lambda t: np.exp(ph(t)) * dph(t)))(ph, dph) for ph, dph in fs]
    ent = ent_prod(Ps, Sigma, lam)
    rhs = 0.0
    for i in range(n):
        for j in range(i + 1, n):
            hs = list(Ps)
            hs[i], hs[j] = dPs[i], dPs[j]
            rhs += B[i, j] * Eprod(hs, Sigma, lam)
    rhs *= -lam
    if rhs > 1e-10:
        worst = min(worst, ent / rhs)
ok = worst >= 1 - 1e-7
print(f"  {'ok ' if ok else 'FAIL'} min Ent / RHS over cases with RHS > 0: {worst:.6f}", flush=True)
if not ok:
    fails.append("A")


def logratio(fs, x, Sigma, lam, r, p):
    Ts = [Tfun(fj, x) for fj in fs]
    lhs = np.log(Eprod([(lambda Tj: (lambda t: Tj(t) ** r))(Tj) for Tj in Ts], Sigma, lam)) / r
    rhs = np.log(Eprod([(lambda fj: (lambda t: fj(t) ** p))(fj) for fj in fs], Sigma, lam)) / p
    return lhs - rhs


print("(B) n = 3, random covariance: above the threshold no violation, below exponentials violate", flush=True)
for trial in range(6):
    n = 3
    while True:
        Sigma = random_corr(n)
        lam = np.linalg.eigvalsh(Sigma)[0]
        if 0.2 < lam < 0.6:
            break
    p = rng.uniform(1.0, 0.95 / lam)            # p lam < 1 <= p
    r = rng.uniform(0.2, p * 0.95)
    xs2 = (1 - p * lam) / (1 - r * lam)
    x = np.sqrt(min(1.0, xs2 * 1.03))
    worst = -np.inf
    for _ in range(12):
        fs = [(lambda ph: (lambda t: np.exp(ph(t))))(rand_logfun()[0]) for _ in range(n)]
        worst = max(worst, logratio(fs, x, Sigma, lam, r, p))
    evals, evecs = np.linalg.eigh(Sigma)
    a = evecs[:, 0]
    xb = np.sqrt(xs2 * 0.97)
    fs = [(lambda aj: (lambda t: np.exp(aj * t)))(aj) for aj in a]
    lb = logratio(fs, xb, Sigma, lam, r, p)
    pred = ((1 - xb * xb) + r * lam * xb * xb - p * lam) * (a @ a) / 2
    ok = worst <= 1e-9 and lb > 0 and abs(lb - pred) < 1e-7
    print(f"  {'ok ' if ok else 'FAIL'} lam={lam:.3f}, p={p:.3f}, r={r:.3f}, x*^2={xs2:.4f}: above max log-ratio "
          f"{worst:+.3e}; below {lb:+.3e} (closed form {pred:+.3e})", flush=True)
    if not ok:
        fails.append("B")

print()
print("ALL CHECKS PASSED" if not fails else f"FAILURES: {fails}", flush=True)
