"""Checks for RESULT_forward_real_hypercontractivity (floating point; evidence for the algebra, not a proof).

Setting: xi_1..xi_n equicorrelated standard Gaussians (E xi_i xi_j = rho >= 0), T_x the Mehler (Ornstein-Uhlenbeck)
operator with real x. Theorem: for p >= 1, 0 < r < p,
    || prod_j T_x f_j(xi_j) ||_r <= || prod_j f_j(xi_j) ||_p  for all f_j >= 0
    <=>  (1 - x^2) + r x^2 (1 - rho) <= p (1 - rho).
(A) Reverse correlated log-Sobolev: Ent(F(X)G(Y)) >= -(1 - rho) E F'(X) G'(Y) (in fact >= (1-rho)|E F'G'|),
    random F, G; equality for anti-aligned exponentials; n = 3 version.
(B) Derivative of Phi(q, rho, s) = (1/q) log E[(T_s f(X) T_s g(Y))^q] against finite differences:
    q^2 E[W] dPhi = dq Ent(W) + q^2 (ds/s) E[W((q-1)(a^2+b^2) + 2 rho q a b)] + q^3 drho E[W a b].
(C) The inequality at random f, g just above the threshold, and a local optimiser over a rich family.
(D) Below the threshold, anti-aligned exponentials violate it (closed form).
(E) n = 3: random tests above the threshold, violation below.
All expectations of products of one-variable functions are computed by nested Gauss-Hermite quadrature over the
common factor: xi_j = sqrt(rho) Z + sqrt(1-rho) A_j.
"""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.optimize import minimize

rng = np.random.default_rng(1)
ND, WT = hermegauss(100)
WT = WT / WT.sum()
fails = []


def Tfun(fun, s):
    """T_s fun (Gauss-Hermite in the noise variable)."""
    c = np.sqrt(max(0.0, 1 - s * s))
    def h(y):
        y = np.asarray(y, dtype=float)
        return (fun(s * y[..., None] + c * ND) * WT).sum(-1)
    return h


def Eprod(hs, rho):
    """E prod_j h_j(xi_j) for equicorrelated standard xi_j (rho >= 0), nested quadrature."""
    pts = np.sqrt(rho) * ND[:, None] + np.sqrt(1 - rho) * ND[None, :]   # [Z, A]
    out = np.ones(len(ND))
    for h in hs:
        out = out * (h(pts) * WT[None, :]).sum(1)
    return (out * WT).sum()


def ent_prod(psis, rho):
    """Ent(prod_j psi_j(xi_j)) = sum_k E[prod_j psi_j * log psi_k] - E log E."""
    EH = Eprod(psis, rho)
    s = 0.0
    for k in range(len(psis)):
        hs = list(psis)
        hs[k] = (lambda ps: (lambda t: ps(t) * np.log(ps(t))))(psis[k])
        s += Eprod(hs, rho)
    return s - EH * np.log(EH)


def rand_logfun():
    """A random smooth log-function: linear tilt + bounded oscillating/sigmoid/bump parts, and its derivative."""
    a = rng.normal(0, 0.8)
    c = rng.normal(0, 0.8, 3)
    d = rng.normal(0, 1.0, 3)
    w = rng.uniform(0.3, 2.0)
    phi = lambda t: a * t + c[0] * np.tanh(t - d[0]) + c[1] * np.sin(w * t + d[1]) + c[2] * np.exp(-(t - d[2]) ** 2)
    dphi = lambda t: (a + c[0] / np.cosh(t - d[0]) ** 2 + c[1] * w * np.cos(w * t + d[1])
                      - 2 * c[2] * (t - d[2]) * np.exp(-(t - d[2]) ** 2))
    return phi, dphi


print("(A) reverse correlated log-Sobolev", flush=True)
worst = np.inf
for _ in range(500):
    rho = rng.uniform(0.0, 0.95)
    (p1, d1), (p2, d2) = rand_logfun(), rand_logfun()
    F = lambda t: np.exp(p1(t))
    G = lambda t: np.exp(p2(t))
    ent = ent_prod([F, G], rho)
    cross = Eprod([lambda t: F(t) * d1(t), lambda t: G(t) * d2(t)], rho)
    if abs(cross) > 1e-10:
        worst = min(worst, ent / ((1 - rho) * abs(cross)))
ok = worst >= 1 - 1e-8
print(f"  {'ok ' if ok else 'FAIL'} n=2: min Ent/((1-rho)|E F'G'|) over 500 random pairs = {worst:.6f}", flush=True)
if not ok:
    fails.append("A2")
rho, a = 0.6, 0.7
F = lambda t: np.exp(a * t)
G = lambda t: np.exp(-a * t)
eq = ent_prod([F, G], rho) / ((1 - rho) * abs(Eprod([lambda t: a * F(t), lambda t: -a * G(t)], rho)))
print(f"  anti-aligned exponentials: ratio = {eq:.12f} (equality case)", flush=True)
worst = np.inf
for _ in range(300):
    rho = rng.uniform(0.0, 0.95)
    fs = [rand_logfun() for _ in range(3)]
    Ps = [(lambda ph: (lambda t: np.exp(ph(t))))(ph) for ph, _ in fs]
    dPs = [(lambda ph, dph: (lambda t: np.exp(ph(t)) * dph(t)))(ph, dph) for ph, dph in fs]
    ent = ent_prod(Ps, rho)
    S = 0.0
    for j in range(3):
        for k in range(j + 1, 3):
            hs = list(Ps)
            hs[j], hs[k] = dPs[j], dPs[k]
            S += Eprod(hs, rho)
    if S < -1e-10:
        worst = min(worst, ent / ((1 - rho) * (-S)))
ok = worst >= 1 - 1e-8
print(f"  {'ok ' if ok else 'FAIL'} n=3: min Ent/(-(1-rho) sum E[psi_j' psi_k' psi_l]) over negative cases = {worst:.6f}",
      flush=True)
if not ok:
    fails.append("A3")

print("(B) derivative formula of Phi(q, rho, s)", flush=True)
for _ in range(6):
    (p1, d1), (p2, d2) = rand_logfun(), rand_logfun()
    f = lambda t: np.exp(p1(t))
    g = lambda t: np.exp(p2(t))
    q, rho, s = rng.uniform(0.5, 2.5), rng.uniform(0.1, 0.8), rng.uniform(0.4, 0.9)
    dq, drho, ds = rng.normal(size=3)

    def Phi(q, rho, s):
        Tf, Tg = Tfun(f, s), Tfun(g, s)
        return np.log(Eprod([lambda t: Tf(t) ** q, lambda t: Tg(t) ** q], rho)) / q

    h = 1e-5
    fd = (Phi(q + h * dq, rho + h * drho, s + h * ds) - Phi(q - h * dq, rho - h * drho, s - h * ds)) / (2 * h)
    Tf, Tg = Tfun(f, s), Tfun(g, s)
    dTf = Tfun(lambda t: f(t) * d1(t), s)
    dTg = Tfun(lambda t: g(t) * d2(t), s)
    A_ = lambda t: s * dTf(t) / Tf(t)      # (T_s f)'/T_s f, since (T_s f)' = s T_s(f')
    B_ = lambda t: s * dTg(t) / Tg(t)
    Wf, Wg = (lambda t: Tf(t) ** q), (lambda t: Tg(t) ** q)
    EW = Eprod([Wf, Wg], rho)
    ent = ent_prod([Wf, Wg], rho)
    fis = ((q - 1) * (Eprod([lambda t: Wf(t) * A_(t) ** 2, Wg], rho) + Eprod([Wf, lambda t: Wg(t) * B_(t) ** 2], rho))
           + 2 * rho * q * Eprod([lambda t: Wf(t) * A_(t), lambda t: Wg(t) * B_(t)], rho))
    crs = Eprod([lambda t: Wf(t) * A_(t), lambda t: Wg(t) * B_(t)], rho)
    formula = (dq * ent + q * q * (ds / s) * fis + q ** 3 * drho * crs) / (q * q * EW)
    err = abs(fd - formula) / max(1e-12, abs(formula))
    ok = err < 1e-6
    print(f"  {'ok ' if ok else 'FAIL'} finite difference {fd:+.10f} vs formula {formula:+.10f} (rel. {err:.1e})",
          flush=True)
    if not ok:
        fails.append("B")


def logratio(fs, x, rho, r, p):
    Ts = [Tfun(fj, x) for fj in fs]
    lhs = np.log(Eprod([(lambda Tj: (lambda t: Tj(t) ** r))(Tj) for Tj in Ts], rho)) / r
    rhs = np.log(Eprod([(lambda fj: (lambda t: fj(t) ** p))(fj) for fj in fs], rho)) / p
    return lhs - rhs


print("(C) n = 2 just above the threshold x^2 = (1-P)/(1-r(1-rho)), P = p(1-rho)", flush=True)
worst_all = -np.inf
for (rho, p, r) in [(0.5, 1.5, 0.5), (0.5, 1.5, 1.0), (0.5, 1.8, 1.4), (0.7, 2.5, 2.0), (0.3, 1.2, 0.3),
                    (0.8, 4.0, 3.0)]:
    P = p * (1 - rho)
    c1 = (1 - P) / (1 - r * (1 - rho))
    x = np.sqrt(min(1.0, c1 * 1.02))
    worst = -np.inf
    for _ in range(80):
        (p1, _), (p2, _) = rand_logfun(), rand_logfun()
        worst = max(worst, logratio([lambda t: np.exp(p1(t)), lambda t: np.exp(p2(t))], x, rho, r, p))

    def neg(theta):
        a1, a2, c1_, c2_, d1_, d2_, w = theta
        f = lambda t: np.exp(a1 * t + c1_ * np.tanh(w * (t - d1_)))
        g = lambda t: np.exp(a2 * t + c2_ * np.tanh(w * (t - d2_)))
        return -logratio([f, g], x, rho, r, p)

    best = -np.inf
    for _ in range(4):
        res = minimize(neg, rng.normal(0, 0.7, 7), method="Nelder-Mead", options={"maxiter": 400})
        best = max(best, -res.fun)
    worst_all = max(worst_all, worst, best)
    print(f"  rho={rho}, p={p}, r={r}: c1={c1:.4f}, x^2={x*x:.4f}; max log-ratio random {worst:+.2e}, "
          f"optimised {best:+.2e}", flush=True)
ok = worst_all <= 1e-9
print(f"  {'ok ' if ok else 'FAIL'} no violation above the threshold (max log-ratio {worst_all:+.2e})", flush=True)
if not ok:
    fails.append("C")

print("(D) below the threshold anti-aligned exponentials violate", flush=True)
for (rho, p, r) in [(0.5, 1.5, 0.5), (0.5, 1.5, 1.0), (0.7, 2.5, 2.0)]:
    P = p * (1 - rho)
    c1 = (1 - P) / (1 - r * (1 - rho))
    x = np.sqrt(c1 * 0.98)
    a = 1.0
    lr = logratio([lambda t: np.exp(a * t), lambda t: np.exp(-a * t)], x, rho, r, p)
    pred = (2 * a * a) * ((1 - x * x) + r * x * x * (1 - rho) - P) / 2   # |a|^2 = a_1^2 + a_2^2 = 2a^2
    ok = lr > 0 and abs(lr - pred) < 1e-9
    print(f"  {'ok ' if ok else 'FAIL'} rho={rho}, p={p}, r={r}: log-ratio {lr:+.6e} (closed form {pred:+.6e})",
          flush=True)
    if not ok:
        fails.append("D")

print("(E) n = 3 equicorrelated functions, same threshold", flush=True)
for (rho, p, r) in [(0.5, 1.5, 1.0), (0.6, 2.0, 1.5), (0.4, 1.4, 0.6)]:
    P = p * (1 - rho)
    c1 = (1 - P) / (1 - r * (1 - rho))
    x = np.sqrt(c1 * 1.03)
    worst = -np.inf
    for _ in range(60):
        fs = [(lambda ph: (lambda t: np.exp(ph(t))))(rand_logfun()[0]) for _ in range(3)]
        worst = max(worst, logratio(fs, x, rho, r, p))
    ok = worst <= 1e-9
    xb = np.sqrt(c1 * 0.97)
    lb = logratio([lambda t: np.exp(t), lambda t: np.exp(-0.5 * t), lambda t: np.exp(-0.5 * t)], xb, rho, r, p)
    ok2 = lb > 0
    print(f"  {'ok ' if ok and ok2 else 'FAIL'} rho={rho}, p={p}, r={r}: above (x^2={x*x:.4f}) max log-ratio "
          f"{worst:+.3e}; below (x^2={xb*xb:.4f}) exponentials {lb:+.3e}", flush=True)
    if not (ok and ok2):
        fails.append("E")

print()
print("ALL CHECKS PASSED" if not fails else f"FAILURES: {fails}", flush=True)
