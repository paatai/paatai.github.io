"""Forward real inequality with unequal parameters, Gaussian test functions (closed forms, floating point).

    || T_{x1} f(X) T_{x2} g(Y) ||_r <= || f(X) g(Y) ||_p,   (X, Y) rho-correlated standard normals, f, g >= 0.

f(t) = exp(a t - beta t^2/2), g(t) = exp(b t - delta t^2/2).  T_x maps Gaussians to Gaussians:
    T_x f(y) = D^{-1/2} exp(c^2 a^2/(2D) + (a x/D) y - (beta x^2/D) y^2/2),  c^2 = 1 - x^2,  D = 1 + beta c^2 > 0.
With E_Sigma exp(u.W - W.A W/2) = det(I + Sigma A)^{-1/2} exp(u.(Sigma^{-1} + A)^{-1} u/2), the log-ratio is
    L = C(beta, delta) + Q_{beta,delta}(a, b),
C the constant part (centred Gaussians) and Q a quadratic form in (a, b).  At beta = delta = 0, C = 0 and
Q = -(a, b) M (a, b)^T / 2 with M = [[p-1-(r-1)x1^2, (p - r x1 x2) rho], [., p-1-(r-1)x2^2]] ([IK25, (2.17)]).
So "(2.17) suffices" requires C <= 0 and Q <= 0 for every admissible (beta, delta).
"""
import numpy as np
from scipy.optimize import minimize


def parts(beta, delta, x1, x2, rho, r, p):
    """Return (C, Qmat) or None if the right side is infinite (inequality trivially true), or 'inf' if only the
    left side is infinite (violation)."""
    S = np.array([[1.0, rho], [rho, 1.0]])
    Si = np.linalg.inv(S)
    c1, c2 = 1 - x1 * x1, 1 - x2 * x2
    D1, D2 = 1 + beta * c1, 1 + delta * c2
    Kp = Si + np.diag([p * beta, p * delta])
    if np.linalg.eigvalsh(Kp)[0] <= 0:
        return None
    if D1 <= 0 or D2 <= 0:
        return "inf"
    b1, b2 = beta * x1 * x1 / D1, delta * x2 * x2 / D2
    Kr = Si + np.diag([r * b1, r * b2])
    if np.linalg.eigvalsh(Kr)[0] <= 0:
        return "inf"
    C = (-0.5 * np.log(D1) - 0.5 * np.log(D2)
         - np.log(np.linalg.det(np.eye(2) + S @ np.diag([r * b1, r * b2]))) / (2 * r)
         + np.log(np.linalg.det(np.eye(2) + S @ np.diag([p * beta, p * delta]))) / (2 * p))
    L = np.diag([x1 / D1, x2 / D2])
    Q = (np.diag([c1 / (2 * D1), c2 / (2 * D2)]) + (r / 2) * L @ np.linalg.inv(Kr) @ L
         - (p / 2) * np.linalg.inv(Kp))
    return C, 0.5 * (Q + Q.T)


def Mmat(x1, x2, rho, r, p):
    return np.array([[p - 1 - (r - 1) * x1 * x1, (p - r * x1 * x2) * rho],
                     [(p - r * x1 * x2) * rho, p - 1 - (r - 1) * x2 * x2]])


def score(v, *args):
    """max(C, lambda_max(Q)) at (beta, delta) = (sinh v0, sinh v1); +inf for a left-only divergence."""
    beta, delta = np.sinh(v[0]), np.sinh(v[1])
    out = parts(beta, delta, *args)
    if out is None:
        return -np.inf
    if isinstance(out, str):
        return np.inf
    C, Q = out
    return max(C, np.linalg.eigvalsh(Q)[-1])


def best(args, rng, nstart=60):
    bestv, bestx = -np.inf, None
    for _ in range(nstart):
        v0 = rng.normal(0, 2, 2)
        s0 = score(v0, *args)
        if s0 == np.inf:
            return np.inf, np.sinh(v0)
        if not np.isfinite(s0):
            continue
        res = minimize(lambda v: -score(v, *args) if np.isfinite(score(v, *args)) else 1e6, v0,
                       method="Nelder-Mead", options={"maxiter": 4000, "xatol": 1e-12, "fatol": 1e-15})
        val = -res.fun
        if val > bestv:
            bestv, bestx = val, np.sinh(res.x)
    return bestv, bestx


if __name__ == "__main__":
    rng = np.random.default_rng(1)
    print("Sanity check, equal parameters (theorem: no violation when M >= 0):")
    for (rho, p, r, x) in [(0.5, 1.5, 0.5, 0.8), (0.5, 1.5, 1.2, 0.9), (0.3, 1.2, 0.6, 0.7)]:
        ev = np.linalg.eigvalsh(Mmat(x, x, rho, r, p))[0]
        if ev < 0:
            continue
        v, at = best((x, x, rho, r, p), rng)
        print(f"  rho={rho} p={p} r={r} x1=x2={x}: lam_min(M)={ev:+.4f}  max over Gaussians={v:+.3e} at {at}")
    print("Unequal parameters, (2.17) holding (lam_min(M) >= 0), random draws:")
    worst = []
    ntest = 0
    while ntest < 400:
        rho = rng.uniform(0.05, 0.9); p = rng.uniform(1.0, 3.0); r = rng.uniform(0.1, p * 0.98)
        x1, x2 = rng.uniform(0.0, 1.0, 2)
        ev = np.linalg.eigvalsh(Mmat(x1, x2, rho, r, p))[0]
        if ev < 0 or ev > 0.05:
            continue
        ntest += 1
        v, at = best((x1, x2, rho, r, p), rng, nstart=25)
        worst.append((v, rho, p, r, x1, x2, ev, at))
        if v > 1e-10:
            print(f"  VIOLATION: rho={rho:.4f} p={p:.4f} r={r:.4f} x=({x1:.4f},{x2:.4f}) lam_min(M)={ev:.2e}: "
                  f"{v:+.3e} at (beta,delta)={at}", flush=True)
    worst.sort(key=lambda w: -w[0])
    print(f"{ntest} random cases with 0 <= lam_min(M) <= 0.05; top 5 scores:")
    for w in worst[:5]:
        print(f"  {w[0]:+.3e}  rho={w[1]:.3f} p={w[2]:.3f} r={w[3]:.3f} x=({w[4]:.3f},{w[5]:.3f}) lam_min(M)={w[6]:.2e}")
