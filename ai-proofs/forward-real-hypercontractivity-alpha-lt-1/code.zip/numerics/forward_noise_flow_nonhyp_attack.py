"""Direct attack on (eq:unequal) at p = pfac * p* with non-Gaussian test functions (floating point; evidence only).
Written by an independent referee of RESULT_forward_real_hypercontractivity (noise-flow pass) and committed unchanged
apart from this header and the import name. Used for the remark after Corollary 6.10: at (rho,r,x1,x2)=(0.6,1.1,0.99,0.3),
where the hypothesis of Theorem 6.9 fails, no violation is found at p = p*; the same attack finds the violation at (E1).

log f = t y + sum_m a_m psi_m(y) + A log(1 + e^{beta - (y-c)^2/(2 w^2)}), same for g (own parameters);
psi_m: He_1..He_6 of t = y/sqrt(1+y^2/16) (normalised), tanh((y-1)/0.7), tanh((y+1)/0.7), and a bounded
second-chaos-like term y^2/(1+y^2/9) - 0.9.
Basis values on the inner Gauss-Hermite points of T_{x_j} are precomputed. Bounded L-BFGS-B, multi-start; the best
candidates are re-evaluated with an independent finer quadrature (fastquad.Fast on a larger, finer grid).
Usage: python3 forward_noise_flow_nonhyp_attack.py rho r x1 x2 pfac seed nstarts"""
import os, sys, time, math
os.environ.setdefault("OMP_NUM_THREADS", "1")
import numpy as np
from numpy.polynomial.hermite_e import hermegauss, hermeval
from scipy.optimize import minimize
from forward_noise_flow_fastquad import Fast

rho, r, x1, x2, pfac = [float(v) for v in sys.argv[1:6]]
seed = int(sys.argv[6]); nst = int(sys.argv[7]); TB = float(sys.argv[8]) if len(sys.argv) > 8 else 1.5
al1, al2, be = 1 + (r - 1) * x1**2, 1 + (r - 1) * x2**2, r * x1 * x2
qa = 1 - rho**2; qb = -(al1 + al2) + 2 * rho**2 * be; qc = al1 * al2 - rho**2 * be**2
ps = (-qb + math.sqrt(qb * qb - 4 * qa * qc)) / (2 * qa)
p = pfac * ps
kap = (ps - al1) / ((ps - be) * rho)

NH = 6
def basis(y):
    t = y / np.sqrt(1 + y * y / 16)
    out = [hermeval(t, np.eye(NH + 1)[k]) / math.sqrt(math.factorial(k)) for k in range(1, NH + 1)]
    out += [np.tanh((y - 1) / 0.7), np.tanh((y + 1) / 0.7), y * y / (1 + y * y / 9) - 0.9]
    return np.array(out)
NB = NH + 3
NP = 1 + NB + 4

L, n, ni = 12.0, 481, 80
y = np.linspace(-L, L, n); h = y[1] - y[0]
zi, wi = hermegauss(ni); wi = wi / np.sqrt(2 * np.pi)
def Kmat(th):
    X, Y = np.meshgrid(y, y, indexing='ij'); d = 1 - th * th
    return h * h * np.exp(-(X * X - 2 * th * X * Y + Y * Y) / (2 * d)) / (2 * np.pi * np.sqrt(d))
K = Kmat(rho)
Pts = {s: s * y[:, None] + math.sqrt(max(1 - s * s, 0)) * zi[None, :] for s in (x1, x2)}
Bs = {s: basis(P) for s, P in Pts.items()}
B1 = basis(y)

def logfun_on(par, P, B):
    t = par[0]; co = par[1:1 + NB]; A, beta, c, lw = par[1 + NB:]
    w = math.exp(lw)
    v = t * P + np.tensordot(co, B, axes=1)
    return v + A * np.log1p(np.exp(beta - (P - c)**2 / (2 * w * w)))

def logT(par, s):
    V = logfun_on(par, Pts[s], Bs[s])
    m = V.max(axis=1, keepdims=True)
    return np.log(np.exp(V - m) @ wi) + m[:, 0]

def logE(la, lb):
    ma, mb = la.max(), lb.max()
    return math.log(np.exp(la - ma) @ K @ np.exp(lb - mb)) + ma + mb

def ratio(z):
    pf, pg = z[:NP], z[NP:]
    lhs = logE(r * logT(pf, x1), r * logT(pg, x2)) / r
    rhs = logE(p * logfun_on(pf, y, B1), p * logfun_on(pg, y, B1)) / p
    return lhs - rhs

def ratio_fine(z, Q):
    pf, pg = z[:NP], z[NP:]
    mk = lambda par: (lambda yy: logfun_on(par, yy, basis(yy)))
    return Q.log_ratio(rho, r, p, x1, x2, mk(pf), mk(pg))

lo1 = np.array([-TB] + [-0.6] * NB + [-1.0, -3.0, -5.0, math.log(0.25)])
hi1 = np.array([TB] + [0.6] * NB + [1.0, 4.0, 5.0, math.log(2.0)])
lo = np.concatenate([lo1, lo1]); hi = np.concatenate([hi1, hi1])
bounds = list(zip(lo, hi))

rng = np.random.default_rng(seed)
t0 = time.time()
res_all = []
for s in range(nst):
    z0 = np.clip(rng.uniform(lo, hi) * rng.choice([0.1, 0.3, 1.0]), lo, hi)
    if s % 3 == 0:
        tau = rng.uniform(-0.8 * TB, 0.8 * TB); z0[0] = tau; z0[NP] = float(np.clip(-kap * tau, -TB, TB))
    res = minimize(lambda z: -ratio(z), z0, method='L-BFGS-B', bounds=bounds,
                   options=dict(maxiter=600, maxfun=40000, ftol=1e-15, gtol=1e-11))
    res_all.append((-res.fun, res.x))
res_all.sort(key=lambda t: -t[0])
fine = Fast(20.0, 1601, 160)
print(f"point rho={rho} r={r} x=({x1},{x2}) p*={ps:.10f} kappa={kap:.6f} p={p:.10f} (factor {pfac}); {nst} starts, "
      f"{time.time() - t0:.0f}s")
bestf = -np.inf
for v, z in res_all[:4]:
    vf = ratio_fine(z, fine); bestf = max(bestf, vf)
    pf, pg = z[:NP], z[NP:]
    print(f"  coarse {v:+.3e}  fine {vf:+.3e}  tilts ({pf[0]:+.3f},{pg[0]:+.3f}) [-kappa = {-kap:+.4f}, ratio "
          f"{(pg[0]/pf[0]) if abs(pf[0]) > 1e-6 else float('nan'):+.4f}]  bump A ({pf[1+NB]:+.2f},{pg[1+NB]:+.2f})  "
          f"max|coef| {np.abs(np.concatenate([pf[1:1+NB], pg[1:1+NB]])).max():.3f}")
print(f"BEST fine-grid log-ratio: {bestf:+.3e}  ({'VIOLATION' if bestf > 1e-9 else 'no violation'})")
