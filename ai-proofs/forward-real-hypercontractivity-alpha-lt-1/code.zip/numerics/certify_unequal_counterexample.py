"""Certificate for RESULT_forward_real_hypercontractivity, Proposition 6.3: the source's condition (2.17) is not
sufficient for two rho-correlated functions with unequal parameters (k = 1, outer exponent r = alpha p in (0, p)).

Inequality (main):  || T_{x1} f(X) T_{x2} g(Y) ||_r <= || f(X) g(Y) ||_p.
Chaos-m matrices (Proposition 6.2):
    M_m = [[p-1-(r-1) x1^{2m}, (p - r (x1 x2)^m) rho^m], [., p-1-(r-1) x2^{2m}]],  M_1 = M  ((2.17) <=> M >= 0).
(A) exact rational arithmetic: M is positive definite and M_2 has a negative eigenvalue (det M_2 < 0), for E1 and E2.
    By Proposition 6.2 this already disproves sufficiency. For E3 every M_m (m >= 1) is positive definite
    (exactly for m <= 3, by an explicit bound for m >= 4), so all second-order conditions hold there.
(B) Arb ball arithmetic: explicit centred Gaussians f = exp(-c1 y^2/2), g = exp(-c2 y^2/2) violate (main), via the
    closed form  log-ratio = -1/2 log D1 - 1/2 log D2 - 1/(2r) log det(I + S A_r) + 1/(2p) log det(I + S A_p),
    D_j = 1 + c_j (1 - x_j^2), A_r = r diag(c_j x_j^2 / D_j), A_p = p diag(c_j), S = [[1, rho], [rho, 1]],
    valid when D_j > 0 and S^{-1} + A_r, S^{-1} + A_p are positive definite (checked exactly).
(C) floating-point cross-check of (B) by direct Gauss-Hermite quadrature (T_x by 1D quadrature), for E1 and E2.
"""
from fractions import Fraction as Fr
from flint import arb, ctx
import numpy as np
from numpy.polynomial.hermite_e import hermegauss

ctx.prec = 256

EXAMPLES = [
    # (rho, r, x1, x2, p, c1, c2)
    ("E1", Fr(97, 100), Fr(5), Fr(1), Fr(4, 5), Fr(29, 2), Fr(49, 100), Fr(-31, 100)),
    ("E2", Fr(49, 50), Fr(8), Fr(49, 50), Fr(4, 5), Fr(25), Fr(1, 5), Fr(-3, 20)),
]
# E3: every M_m is positive definite, yet a centred Gaussian violates the inequality.
E3 = ("E3", Fr(97, 100), Fr(8), Fr(19, 20), Fr(1, 2), Fr(47), Fr(-653, 2500), Fr(4373, 5000))


def Mm(rho, r, x1, x2, p, m):
    return (p - 1 - (r - 1) * x1 ** (2 * m), (p - r * (x1 * x2) ** m) * rho ** m, p - 1 - (r - 1) * x2 ** (2 * m))


def posdef(a, b, d):
    return a > 0 and a * d - b * b > 0


def inv2(a, b, d):
    det = a * d - b * b
    return d / det, -b / det, a / det


def to_arb(q):
    return arb(q.numerator) / arb(q.denominator)


def certify(name, rho, r, x1, x2, p, c1, c2):
    print(f"{name}: rho={rho}, r={r}, x=({x1},{x2}), p={p}, alpha=r/p={r / p}; c=({c1},{c2})")
    a, b, d = Mm(rho, r, x1, x2, p, 1)
    print(f"  (A) M = [[{float(a):.6f}, {float(b):.6f}], [., {float(d):.6f}]]: positive definite (exact): {posdef(a, b, d)},"
          f" det M = {float(a * d - b * b):.6e}")
    a2, b2, d2 = Mm(rho, r, x1, x2, p, 2)
    print(f"      M_2: det = {float(a2 * d2 - b2 * b2):.6e} (exact sign {'negative' if a2 * d2 - b2 * b2 < 0 else 'non-negative'}),"
          f" diagonal ({float(a2):.4f}, {float(d2):.4f}) -> M_2 indefinite: {a2 * d2 - b2 * b2 < 0}")
    # (B) exact admissibility, then Arb
    D1, D2 = 1 + c1 * (1 - x1 ** 2), 1 + c2 * (1 - x2 ** 2)
    b1, bb2 = c1 * x1 ** 2 / D1, c2 * x2 ** 2 / D2
    si = inv2(Fr(1), rho, Fr(1))
    Kr = (si[0] + r * b1, si[1], si[2] + r * bb2)
    Kp = (si[0] + p * c1, si[1], si[2] + p * c2)
    adm = D1 > 0 and D2 > 0 and posdef(*Kr) and posdef(*Kp)
    print(f"  (B) admissible (exact: D_j > 0, S^-1 + A_r > 0, S^-1 + A_p > 0): {adm}")

    def logdet_I_plus_SA(a11, a22):
        # det(I + S diag(a11, a22)) = (1 + a11)(1 + a22) - rho^2 a11 a22   (exact rational)
        return (1 + a11) * (1 + a22) - rho * rho * a11 * a22
    dr = logdet_I_plus_SA(r * b1, r * bb2)
    dp = logdet_I_plus_SA(p * c1, p * c2)
    L = (-to_arb(D1).log() / 2 - to_arb(D2).log() / 2 - to_arb(dr).log() / (2 * to_arb(r))
         + to_arb(dp).log() / (2 * to_arb(p)))
    print(f"      log-ratio (Arb, 256 bits) = {L}")
    print(f"      certified positive: {bool(L > 0)}")
    # (C) quadrature cross-check
    if name == "E3":
        print("  (C) skipped: this Gaussian is close to the boundary of integrability (normalised determinants about"
              " 2e-4 and 2e-3), where fixed-node Gauss-Hermite quadrature is inaccurate; the closed form is the one"
              " cross-checked at E1 and E2.")
        return adm and bool(L > 0) and posdef(a, b, d)
    nd, wt = hermegauss(160); wt = wt / wt.sum()
    rf, x1f, x2f, pf, c1f, c2f, rhof = map(float, (r, x1, x2, p, c1, c2, rho))
    f = lambda t: np.exp(-c1f * t * t / 2)
    g = lambda t: np.exp(-c2f * t * t / 2)
    T = lambda h, x, y: (h(x * y[:, None] + np.sqrt(1 - x * x) * nd[None, :]) * wt[None, :]).sum(1)
    X = np.repeat(nd, len(nd)); Z = np.tile(nd, len(nd)); W = np.repeat(wt, len(nd)) * np.tile(wt, len(nd))
    Y = rhof * X + np.sqrt(1 - rhof ** 2) * Z
    lhs = np.log((W * (T(f, x1f, X) * T(g, x2f, Y)) ** rf).sum()) / rf
    rhs = np.log((W * (f(X) * g(Y)) ** pf).sum()) / pf
    print(f"  (C) Gauss-Hermite (160 x 160, T by 160-point quadrature): log-ratio = {lhs - rhs:+.10e}")
    return adm and bool(L > 0) and posdef(a, b, d) and (a2 * d2 - b2 * b2 < 0 or name == "E3")


def all_chaos_posdef(rho, r, x1, x2, p, m0=4):
    """M_m positive definite for every m >= 1: exactly for m < m0; for m >= m0 via the bounds
    (M_m)_jj >= p-1-(r-1) x_j^{2 m0} (r > 1, x_j^{2m} decreasing), |(M_m)_12| <= p rho^{m0} (0 < r (x1x2)^m < p)."""
    assert r > 1 and 0 < x1 < 1 and 0 < x2 < 1 and 0 < r * x1 * x2 < p
    exact = all(posdef(*Mm(rho, r, x1, x2, p, m)) for m in range(1, m0))
    d1 = p - 1 - (r - 1) * x1 ** (2 * m0); d2 = p - 1 - (r - 1) * x2 ** (2 * m0)
    tail = d1 > 0 and d2 > 0 and d1 * d2 - (p * rho ** m0) ** 2 > 0
    print(f"  M_m positive definite for m < {m0} (exact): {exact}; for m >= {m0}: d1*d2 = {float(d1 * d2):.4f} > "
          f"(p rho^{m0})^2 = {float((p * rho ** m0) ** 2):.4f}: {tail}")
    return exact and tail


if __name__ == "__main__":
    ok = all(certify(*e) for e in EXAMPLES)
    ok3 = certify(*E3) and all_chaos_posdef(*E3[1:6])
    print("ALL CERTIFIED" if ok and ok3 else "CERTIFICATE FAILED")
