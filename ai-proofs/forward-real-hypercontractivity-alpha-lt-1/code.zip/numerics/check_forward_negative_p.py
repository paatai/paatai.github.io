"""Forward real note, Proposition 1.3 (p < 0): random test of the source's form (2.16),
    (E prod_j (T_x f_j(xi_j))^{alpha p})^{1/alpha} <= E prod_j f_j(xi_j)^p,
for n = 2, 3 equicorrelated standard Gaussians (rho in [0, 0.9)), p in (-3, -0.2), alpha in (0.05, 0.95),
x in (-1, 1) and random smooth positive f_j.  Nested Gauss-Hermite quadrature over the common factor
(floating point; evidence only).  The script prints the largest value of log LHS - log RHS."""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss

ND, WT = hermegauss(100)
WT = WT / WT.sum()


def Tfun(fun, s):
    c = np.sqrt(max(0.0, 1 - s * s))
    return lambda y: (fun(s * np.asarray(y, float)[..., None] + c * ND) * WT).sum(-1)


def Eprod(hs, rho):
    pts = np.sqrt(rho) * ND[:, None] + np.sqrt(1 - rho) * ND[None, :]
    out = np.ones(len(ND))
    for h in hs:
        out = out * (h(pts) * WT[None, :]).sum(1)
    return (out * WT).sum()


if __name__ == "__main__":
    rng = np.random.default_rng(9)
    worst = -np.inf
    for trial in range(400):
        rho = rng.uniform(0, 0.9); p = -rng.uniform(0.2, 3); al = rng.uniform(0.05, 0.95); x = rng.uniform(-1, 1)
        n = rng.integers(2, 4)
        fs = []
        for _ in range(n):
            a, c, d, w = rng.normal(0, 0.8), rng.normal(0, 0.8), rng.normal(0, 1), rng.uniform(0.3, 2)
            fs.append(lambda t, a=a, c=c, d=d, w=w: np.exp(a * t + c * np.tanh(w * (t - d)) + 0.3 * np.sin(w * t)))
        Ts = [Tfun(f, x) for f in fs]
        lhs = np.log(Eprod([lambda t, T=T: T(t) ** (al * p) for T in Ts], rho)) / al
        rhs = np.log(Eprod([lambda t, f=f: f(t) ** p for f in fs], rho))
        worst = max(worst, lhs - rhs)
    print("max of log LHS - log RHS of (2.16) over 400 random cases with p<0, alpha in (0,1):", worst)
