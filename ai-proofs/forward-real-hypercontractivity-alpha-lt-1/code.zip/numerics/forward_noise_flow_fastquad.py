"""(Helper for forward_noise_flow_nonhyp_attack.py; written by an independent referee.)
Fast quadrature for E_theta[A(X) B(Y)] (theta-correlated standard scalar Gaussians): uniform grid on [-L, L],
trapezoid rule with the exact bivariate density (spectrally accurate for smooth, Gaussian-decaying integrands);
T_s f evaluated on the grid by inner Gauss-Hermite (accurate for every s in [0,1])."""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss


class Fast:
    def __init__(self, L=14.0, n=701, n_inner=90):
        self.y = np.linspace(-L, L, n)
        self.h = self.y[1] - self.y[0]
        zi, wi = hermegauss(n_inner)
        self.zi, self.wi = zi, wi / np.sqrt(2 * np.pi)
        self._K = {}

    def K(self, theta):
        """matrix h^2 * phi_theta(y_i, y_j)."""
        key = round(float(theta), 15)
        if key not in self._K:
            if len(self._K) > 64:
                self._K.clear()
            y = self.y
            d = 1 - theta * theta
            X, Y = np.meshgrid(y, y, indexing='ij')
            self._K[key] = self.h**2 * np.exp(-(X * X - 2 * theta * X * Y + Y * Y) / (2 * d)) / (2 * np.pi * np.sqrt(d))
        return self._K[key]

    def T(self, fun, s, y=None):
        y = self.y if y is None else y
        c = np.sqrt(max(1.0 - s * s, 0.0))
        return fun(s * y[:, None] + c * self.zi[None, :]) @ self.wi

    def logT(self, logfun, s, y=None):
        """log T_s e^{logfun} computed stably."""
        y = self.y if y is None else y
        c = np.sqrt(max(1.0 - s * s, 0.0))
        V = logfun(s * y[:, None] + c * self.zi[None, :])
        m = V.max(axis=1, keepdims=True)
        return (np.log(np.exp(V - m) @ self.wi) + m[:, 0])

    def E(self, theta, A, B):
        return A @ self.K(theta) @ B

    def logE_prod(self, theta, la, lb):
        """log E_theta[e^{la(X)} e^{lb(Y)}] for log-values la, lb on the grid (stable)."""
        ma, mb = la.max(), lb.max()
        return np.log(np.exp(la - ma) @ self.K(theta) @ np.exp(lb - mb)) + ma + mb

    def Phi(self, q, theta, s1, s2, lf, lg):
        """Phi = (1/q) log E_theta[(T_{s1} f)^q (T_{s2} g)^q], f = e^{lf}, g = e^{lg}."""
        return self.logE_prod(theta, q * self.logT(lf, s1), q * self.logT(lg, s2)) / q

    def grad(self, q, theta, s1, s2, lf, lfp, lg, lgp):
        """formulas of Section 6.1; lfp = (log f)'. a1 = (T f)'/T f = s1 T(f')/T f."""
        lF = self.logT(lf, s1); lG = self.logT(lg, s2)
        # T(f')/T(f) = T(f lf')/T(f): weighted average of lf' under the inner measure
        def ratio(lfun, lfunp, s):
            c = np.sqrt(max(1.0 - s * s, 0.0))
            P = s * self.y[:, None] + c * self.zi[None, :]
            V = lfun(P); m = V.max(axis=1, keepdims=True)
            Wt = np.exp(V - m) * self.wi[None, :]
            return (Wt * lfunp(P)).sum(1) / Wt.sum(1)
        a1 = s1 * ratio(lf, lfp, s1); a2 = s2 * ratio(lg, lgp, s2)
        A0 = np.exp(q * (lF - lF.max())); B0 = np.exp(q * (lG - lG.max()))
        K = self.K(theta)
        KB0 = K @ B0; KBa = K @ (B0 * a2); KBl = K @ (B0 * lG)
        EW = A0 @ KB0
        E11 = (A0 * a1 * a1) @ KB0 / EW
        E22 = A0 @ (K @ (B0 * a2 * a2)) / EW
        E12 = (A0 * a1) @ KBa / EW
        ElogW = q * ((A0 * lF) @ KB0 + A0 @ KBl) / EW
        logEW = np.log(EW) + q * (lF.max() + lG.max())
        ent = ElogW - logEW  # Ent(W)/E W
        g = np.array([ent / q**2, q * E12, ((q - 1) * E11 + theta * q * E12) / s1, ((q - 1) * E22 + theta * q * E12) / s2])
        return g

    def log_ratio(self, rho, r, p, x1, x2, lf, lg):
        """log ||T_{x1} f(X) T_{x2} g(Y)||_r - log ||f(X) g(Y)||_p under rho-correlation."""
        lhs = self.logE_prod(rho, r * self.logT(lf, x1), r * self.logT(lg, x2)) / r
        rhs = self.logE_prod(rho, p * lf(self.y), p * lg(self.y)) / p
        return lhs - rhs
