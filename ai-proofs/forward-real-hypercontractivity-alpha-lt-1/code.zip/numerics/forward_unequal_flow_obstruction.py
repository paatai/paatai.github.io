"""Lossless paths for the flow method with unequal parameters, n = 2, r >= 1 (RESULT_forward_real_hypercontractivity,
Remark 6.7). Floating point; a statement about the method, not about the inequality.

N(q, th, s1, s2) = [[1 + (q-1)s1^2, q th s1 s2], [q th s1 s2, 1 + (q-1)s2^2]] is the matrix of the Gaussian log-ratio
for exponential test functions. At the boundary p = p* of (2.17) (smallest p with M(p) >= 0) the matrix M = N_end - N_0
is singular with kernel v*. A path that is lossless for the extremal exponentials keeps N on the segment N_0 + tau M.
Along it, with q the free control: s_j^2 = (N_jj - 1)/(q - 1) and th = N_12/(q s1 s2). The domain requires s_j <= 1
(i.e. q >= N_jj) and th < 1. Holding q fixed is always admissible; increasing q is allowed only where a diagonal
D >= 0 with Sigma_th - D >= 0 kills w = S v*, which requires the ratio R = |w2/w1| to lie in [th, 1/th], and then
q' <= F (the bound of the separate-noise lemma). The reachable set of q at time tau is an interval [L(tau), hi(tau)],
L = max(N11, N22); the path is infeasible iff hi < L at some tau.

An earlier version of this script aborted at the first failure of the ratio condition instead of pausing, and did
not check s_j <= 1; it reported 1314 failures out of 1707 cases, all at tau = 0, which was an artefact.
"""
import numpy as np
from scipy.optimize import brentq

rng = np.random.default_rng(3)


def Mmat(x1, x2, rho, r, p):
    return np.array([[p - 1 - (r - 1) * x1 ** 2, (p - r * x1 * x2) * rho],
                     [(p - r * x1 * x2) * rho, p - 1 - (r - 1) * x2 ** 2]])


def pstar(x1, x2, rho, r):
    f = lambda p: np.linalg.eigvalsh(Mmat(x1, x2, rho, r, p))[0]
    return r if f(r) >= 0 else brentq(f, r, 50.0)


def feasible(x1, x2, rho, r, ps, nt):
    N0 = np.array([[1 + (r - 1) * x1 ** 2, r * rho * x1 * x2], [r * rho * x1 * x2, 1 + (r - 1) * x2 ** 2]])
    M = Mmat(x1, x2, rho, r, ps)
    ev, evec = np.linalg.eigh(M)
    v, u, m = evec[:, 0], evec[:, 1], ev[1]
    taus = np.linspace(0, 1, nt)
    hi = r
    for k in range(nt - 1):
        tau, dt = taus[k], taus[k + 1] - taus[k]
        N = N0 + tau * M
        if hi < max(N[0, 0], N[1, 1]) - 1e-12:
            return "s>1"
        if hi >= ps:
            return "ok"
        s = np.sqrt(np.maximum(np.diag(N) - 1, 0) / (hi - 1))
        th = N[0, 1] / (hi * s[0] * s[1])
        if th >= 1:
            c = np.sqrt((N[0, 0] - 1) * (N[1, 1] - 1)) / N[0, 1]
            if c < 1:
                hi = 1 / (1 - c) * (1 - 1e-12)
                s = np.sqrt(np.maximum(np.diag(N) - 1, 0) / (hi - 1))
                th = N[0, 1] / (hi * s[0] * s[1])
        w = s * v
        R = abs(w[1] / w[0]) if w[0] != 0 else np.inf
        if w[0] * w[1] < 0 and th * R <= 1 + 1e-12 and th / R <= 1 + 1e-12:
            F = min(M[0, 0] / s[0] ** 2, M[1, 1] / s[1] ** 2, m * (u / s) @ (u / s) / (th * (R + 1 / R)))
            hi += F * dt
    return "ok" if hi >= ps - 1e-6 else "budget"


if __name__ == "__main__":
    cases = []
    for trial in range(3000):
        rho = rng.uniform(0.05, 0.95)
        r = rng.uniform(1.0, 4.0)
        x1, x2 = rng.uniform(0.05, 1.0, 2)
        ps = pstar(x1, x2, rho, r)
        if ps < 1 or ps <= r + 1e-9:
            continue
        cases.append((x1, x2, rho, r, ps))
    print(f"random cases with r >= 1, p* > r, p* >= 1: {len(cases)}")
    for nt in (2001, 8001):
        cnt = {}
        for c in cases:
            a = feasible(*c, nt)
            cnt[a] = cnt.get(a, 0) + 1
        print(f"  {nt} steps: " + ", ".join(f"{k}: {v}" for k, v in sorted(cnt.items())), flush=True)
    print("('ok' = a lossless candidate path reaches p*; 's>1' = infeasible because some s_j would exceed 1)")
