"""Check of the expansion behind RESULT_forward_real_hypercontractivity, Proposition 6.5 (mpmath, 50 digits).

x1 = 1, rho = exp(-sigma), x2 = exp(-kappa sigma), A = p - r,
D_m(sigma, kappa) = det M_m = A (A + (r-1)(1 - e^{-2 m kappa sigma})) - (A + r(1 - e^{-m kappa sigma}))^2 e^{-2 m sigma}
                  = 2 m A (A - kappa) sigma + m^2 q(kappa) sigma^2 + O(sigma^3),
q(kappa) = (2A - A r - r^2) kappa^2 + 4 A r kappa - 2 A^2.
On the boundary D_1(sigma, kappa(sigma)) = 0:  D_2 = 2 A^2 K sigma^2 + O(sigma^3),  K = 2 - (p-2)(r-2).
"""
import mpmath as mp

mp.mp.dps = 50


def D(m, A, r, sig, kap):
    return A * (A + (r - 1) * (1 - mp.e ** (-2 * m * kap * sig))) - (A + r * (1 - mp.e ** (-m * kap * sig))) ** 2 * mp.e ** (-2 * m * sig)


def q(A, r, kap):
    return (2 * A - A * r - r * r) * kap ** 2 + 4 * A * r * kap - 2 * A * A


if __name__ == "__main__":
    print("(1) second-order coefficient: (D_m - 2 m A (A - kappa) sigma)/sigma^2 at sigma = 1e-8 vs m^2 q(kappa)")
    for (A, r, kap) in [(3, 2.5, 2), (10, 5, 9), (1, 1.5, 0.7), (40, 2.05, 39)]:
        A, r, kap = mp.mpf(A), mp.mpf(r), mp.mpf(kap)
        sig = mp.mpf("1e-8")
        for m in (1, 2, 3):
            val = (D(m, A, r, sig, kap) - 2 * m * A * (A - kap) * sig) / sig ** 2
            print(f"  A={mp.nstr(A, 4)} r={mp.nstr(r, 4)} kappa={mp.nstr(kap, 4)} m={m}: {mp.nstr(val, 12)} vs {mp.nstr(m * m * q(A, r, kap), 12)}")
    print("(2) D_2/sigma^2 on the boundary D_1 = 0 (kappa solved), against the limit 2 A^2 K")
    for (r, p) in [(2.05, 45), (2.2, 15), (2.5, 7), (3, 6), (5, 14.5), (2.5, 5.5), (1.5, 4), (2, 10)]:
        r, p = mp.mpf(r), mp.mpf(p)
        A, K = p - r, 2 - (p - 2) * (r - 2)
        vals = []
        for sig in (mp.mpf("1e-3"), mp.mpf("1e-5"), mp.mpf("1e-7")):
            kap = mp.findroot(lambda k: D(1, A, r, sig, k), A)
            vals.append(mp.nstr(D(2, A, r, sig, kap) / sig ** 2, 8))
        print(f"  r={mp.nstr(r, 4)} p={mp.nstr(p, 4)}: K={mp.nstr(K, 5)}, 2A^2K={mp.nstr(2 * A * A * K, 8)}; at sigma = 1e-3, 1e-5, 1e-7: {vals}")
