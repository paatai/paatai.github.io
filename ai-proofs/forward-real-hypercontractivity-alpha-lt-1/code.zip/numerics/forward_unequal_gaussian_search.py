"""Non-perturbative search for violations of the unequal-parameter inequality by centred Gaussians at the threshold
p = p* of (2.17), for small r (RESULT_forward_real_hypercontractivity, Remark 6.7). Floating point; evidence only.

f = exp(-c1 y^2/2), g = exp(-c2 y^2/2) (closed forms as in certify_unequal_counterexample.py). For each r, random
(rho, x1, x2) concentrated near 1, p = p* (1 + 1e-9), and a grid + Nelder-Mead search over (c1, c2) in the
admissible region; the score is the largest log-ratio (positive = violation).
"""
import itertools
import numpy as np
from scipy.optimize import brentq, minimize

rng = np.random.default_rng(21)


def logratio(rho, r, x1, x2, p, c1, c2):
    S = np.array([[1, rho], [rho, 1.0]]); Si = np.linalg.inv(S)
    D1, D2 = 1 + c1 * (1 - x1 ** 2), 1 + c2 * (1 - x2 ** 2)
    if D1 <= 0 or D2 <= 0:
        return None
    b1, b2 = c1 * x1 ** 2 / D1, c2 * x2 ** 2 / D2
    Ar, Ap = np.diag([r * b1, r * b2]), np.diag([p * c1, p * c2])
    if np.linalg.eigvalsh(Si + Ar)[0] <= 1e-12 or np.linalg.eigvalsh(Si + Ap)[0] <= 1e-12:
        return None
    return (-np.log(D1) / 2 - np.log(D2) / 2 - np.log(np.linalg.det(np.eye(2) + S @ Ar)) / (2 * r)
            + np.log(np.linalg.det(np.eye(2) + S @ Ap)) / (2 * p))


def lam_min(rho, r, x1, x2, p):
    a = p - 1 - (r - 1) * x1 ** 2; d = p - 1 - (r - 1) * x2 ** 2; b = (p - r * x1 * x2) * rho
    return 0.5 * (a + d) - np.sqrt(0.25 * (a - d) ** 2 + b * b)


def pstar(rho, r, x1, x2):
    lo = max(r, 1.0)
    if lam_min(rho, r, x1, x2, lo) >= 0:
        return lo
    hi = 2 * lo
    while lam_min(rho, r, x1, x2, hi) < 0:
        hi *= 2
    return brentq(lambda p: lam_min(rho, r, x1, x2, p), lo, hi, xtol=1e-13)


def best(rho, r, x1, x2, p):
    top = (-np.inf, None)
    for c in itertools.product(np.linspace(-3, 3, 41), repeat=2):
        v = logratio(rho, r, x1, x2, p, *c)
        if v is not None and v > top[0]:
            top = (v, c)
    f = lambda c: -(logratio(rho, r, x1, x2, p, *c) or -1e3)
    res = minimize(f, top[1], method="Nelder-Mead", options={"xatol": 1e-12, "fatol": 1e-15, "maxiter": 4000})
    return max(top[0], -res.fun)


if __name__ == "__main__":
    for r in (0.3, 0.7, 1.3, 1.7, 2.0, 2.2, 2.5):
        worst, n = -np.inf, 0
        for _ in range(300):
            rho = 1 - 10 ** -rng.uniform(0, 2.5)
            x1, x2 = 1 - 10 ** -rng.uniform(0, 2.5, 2)
            ps = pstar(rho, r, x1, x2)
            if ps <= max(r, 1.0) + 1e-9:
                continue
            n += 1
            worst = max(worst, best(rho, r, x1, x2, ps * (1 + 1e-9)))
        print(f"r = {r}: {n} random cases at p = p*: largest centred-Gaussian log-ratio {worst:+.3e}", flush=True)
