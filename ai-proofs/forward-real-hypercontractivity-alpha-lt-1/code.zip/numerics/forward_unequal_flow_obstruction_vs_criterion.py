"""Compare the discretised path search of forward_unequal_flow_obstruction.py (Remark 6.7(b) of
RESULT_forward_real_hypercontractivity) with the closed-form criterion of Corollary 6.10 / Proposition 6.12 on the
same 1707 random cases (floating point). Written by an independent referee; committed with the paths made relative."""
import sys
import numpy as np
import os
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
import importlib.util
spec = importlib.util.spec_from_file_location('obs', os.path.join(HERE, 'forward_unequal_flow_obstruction.py'))
obs = importlib.util.module_from_spec(spec)
spec.loader.exec_module(obs)  # main block is guarded; module-level rng seeded with 3

rng = np.random.default_rng(3)
cases = []
for trial in range(3000):
    rho = rng.uniform(0.05, 0.95)
    r = rng.uniform(1.0, 4.0)
    x1, x2 = rng.uniform(0.05, 1.0, 2)
    ps = obs.pstar(x1, x2, rho, r)
    if ps < 1 or ps <= r + 1e-9:
        continue
    cases.append((x1, x2, rho, r, ps))
print("cases:", len(cases))


def criterion(x1, x2, rho, r):
    al1, al2, be = 1 + (r - 1) * x1**2, 1 + (r - 1) * x2**2, r * x1 * x2
    a = 1 - rho**2
    b = -(al1 + al2) + 2 * rho**2 * be
    c = al1 * al2 - rho**2 * be**2
    ps = (-b + np.sqrt(b * b - 4 * a * c)) / (2 * a)
    kap = (ps - al1) / (rho * (ps - be))
    c1 = al1 - kap * rho * be
    c2 = rho * be - kap * al2
    phis = max(rho * x1 * x2, (1 - c1) / kap, c2 + kap)
    w1 = (c1 - 1 + kap * r * phis) / (r - 1)
    w2 = (r * phis - c2 - kap) / (kap * (r - 1))
    g = (c1 - 1 + kap * phis) + (phis - c2 - kap)
    return ps, max(w1, w2), g


tab = {}
examples = []
for cse in cases:
    x1, x2, rho, r, ps = cse
    a = obs.feasible(x1, x2, rho, r, ps, 2001)
    ps2, wmax, g = criterion(x1, x2, rho, r)
    crit = (wmax <= 1 + 1e-9) and g > 1e-12
    key = (a, crit)
    tab[key] = tab.get(key, 0) + 1
    if (a == 'ok') != crit and len(examples) < 8:
        examples.append((round(r, 4), round(rho, 4), round(x1, 4), round(x2, 4), round(ps, 4), a, round(wmax, 6), abs(ps - ps2)))
print("(script outcome, criterion holds): count")
for k, v in sorted(tab.items(), key=str):
    print("  ", k, v)
print("disagreements (r, rho, x1, x2, p*, script, max w_j(r,phi_s), |p* diff|):")
for e in examples:
    print("  ", e)
