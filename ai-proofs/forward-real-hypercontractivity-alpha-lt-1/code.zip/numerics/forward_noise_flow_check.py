"""Quadrature check (floating point, evidence only) of Lemma 6.8 of RESULT_forward_real_hypercontractivity along the
explicit path of Theorem 6.9 at (rho, r, x1, x2) = (0.6, 1.5, 0.9, 0.2): Phi must be non-decreasing for every pair of
test functions, and constant for the extremal exponentials exp(tau t), exp(-tau kappa t)."""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.optimize import brentq
from scipy.integrate import solve_ivp
r,rho,x1,x2=1.5,0.6,0.9,0.2
det=lambda p:(p-1-(r-1)*x1**2)*(p-1-(r-1)*x2**2)-((p-r*x1*x2)*rho)**2
ps=brentq(det,max(1+(r-1)*x1**2,1+(r-1)*x2**2,r)+1e-12,1e4)
M11=ps-1-(r-1)*x1**2; M12=(ps-r*x1*x2)*rho; kap=M11/M12
N11,N22,N12=1+(r-1)*x1**2,1+(r-1)*x2**2,r*rho*x1*x2
c1=N11-kap*N12; c2=N12-kap*N22
phimin=max((1-c1)/kap,c2+kap); phi0=rho*x1*x2
W=lambda q,ph: ((c1-1+kap*q*ph)/(q-1),(q*ph-c2-kap)/(kap*(q-1)))
def rhs(q,y):
    ph=y[0]; g1=(c1-1+kap*ph)/(q-1); g2=(ph-c2-kap)/(kap*(q-1))
    return [max(g1/(kap*q),kap*g2/q,0.0)]
start=max(phi0,phimin)
sol=solve_ivp(rhs,(r,ps),[start],dense_output=True,rtol=1e-11,atol=1e-13)
phend=sol.sol(ps)[0]
print(f"p*={ps:.6f} kappa={kap:.5f} phi0={phi0:.4f} phimin={phimin:.4f} phi(p*)={phend:.5f} (<= rho={rho})")
# path samples: (q, w1, w2, phi)
pts=[]
for ph in np.linspace(phi0,start,15): pts.append((r,)+W(r,ph)+(ph,))
for q in np.linspace(r,ps,60)[1:]:
    ph=sol.sol(q)[0]; pts.append((q,)+W(q,ph)+(ph,))
for ph in np.linspace(phend,rho,15)[1:]: pts.append((ps,)+W(ps,ph)+(ph,))
# quadrature
NQ=90; xs,ws=hermegauss(NQ); ws=ws/np.sqrt(2*np.pi)
def Ts(f,s,y): return np.array([np.sum(ws*f(s*yy+np.sqrt(max(1-s*s,0))*xs)) for yy in y])
def Psi(f,g,q,w1,w2,ph):
    s1,s2=np.sqrt(min(w1,1)),np.sqrt(min(w2,1)); th=ph/(s1*s2)
    X=np.repeat(xs,NQ); Y=th*X+np.sqrt(1-th*th)*np.tile(xs,NQ); Wt=np.repeat(ws,NQ)*np.tile(ws,NQ)
    u1=Ts(f,s1,xs); # T_{s1} f at nodes xs (X takes node values)
    # Y is not on the node grid: evaluate T_{s2} g at Y directly
    u2=Ts(g,s2,Y)
    U1=np.repeat(u1,NQ)
    return np.log(np.sum(Wt*(U1*u2)**q))/q
rng=np.random.default_rng(3)
worst=0.0
for t in range(6):
    a=rng.normal(0,0.6,4); b=rng.normal(0,0.6,4)
    f=lambda y,a=a: np.exp(a[0]*np.sin(1.1*y)+a[1]*np.cos(0.7*y+0.3)+a[2]*np.tanh(y-0.5)+a[3]*np.exp(-y*y/4))
    g=lambda y,b=b: np.exp(b[0]*np.sin(0.9*y+1)+b[1]*np.cos(1.3*y)+b[2]*np.tanh(2*y+0.2)+b[3]*np.exp(-(y-1)**2/3))
    vals=np.array([Psi(f,g,*pp) for pp in pts])
    dec=np.min(np.diff(vals))
    worst=min(worst,dec)
    # endpoints: start = log ||T f T g||_r under rho ; end = log ||f g||_{p*} under rho
    print(f"test {t}: Psi start {vals[0]:+.6f}, end {vals[-1]:+.6f}, smallest increment along path {dec:+.3e}")
print("most negative increment over all tests:",worst)
print("--- near the extremal exponentials f = exp(tau*t)(1+eps h1), g = exp(-tau*kappa*t)(1+eps h2) ---")
worst=0.0
for (tau,eps) in ((0.4,0.0),(0.4,0.05),(0.8,0.05),(0.4,0.2),(1.0,0.1)):
    h1=lambda y: np.sin(1.7*y)*np.exp(-y*y/8); h2=lambda y: np.cos(1.1*y+0.4)*np.exp(-y*y/8)
    f=lambda y,tau=tau,eps=eps: np.exp(tau*y)*(1+eps*h1(y))
    g=lambda y,tau=tau,eps=eps: np.exp(-tau*kap*y)*(1+eps*h2(y))
    vals=np.array([Psi(f,g,*pp) for pp in pts])
    dec=np.min(np.diff(vals)); worst=min(worst,dec)
    print(f"tau={tau}, eps={eps}: Psi start {vals[0]:+.8f}, end {vals[-1]:+.8f}, total {vals[-1]-vals[0]:+.3e}, smallest increment {dec:+.3e}")
print("most negative increment:",worst)
