"""Theorem L (level-one inequality for nonnegative functions on the q-biased cube) and the boundary orbit D12.

Theorem L (MAIN_RESULT, Section 9.7).  For 0 < q <= 1/2, beta = (1-2q)/q, c = (1-q)^2/q, rho* = -q/(1-q) and
f >= 0 on the q-biased cube,
    q E f^2 + beta (E f)^2 - W^1(f) - c E[f(x) f(y)] = sum_{|S|>=3} (q - c rho*^{|S|}) fhat(S)^2 >= 0,
where (x, y) is the rho*-correlated pair (coordinates independent; y_i = -1 if x_i = +1, and
Pr[y_i = +1 | x_i = -1] = q/(1-q)).  Checked: the displayed joint law of (x_i, y_i), E[x_i y_i] = 1-4q, the
correlation rho* and the coefficients e_0 = e_1 = e_2 = 0, e_k (k >= 3) with their displayed intermediate forms
(sympy, general q; signs of e_k and c for q < 1/2 and q = 1/2), nonnegativity of the coupling, the identity itself
on random f (floating point, n <= 6), the equality cases 1{x_1=1} h, deg h <= 1 (floating point), and the three
examples 1{x_1=1}, 1{x_1=x_2=1}, 1{x_1=1,x_2=-1} (exact, equality in both inequalities).

D12 (MAIN_RESULT, Section 9.8, Proposition 9.11 = prop:g2).  The function g2(w1,w2,w3,u1,u2) = +1 iff (u1,u2) in A''_w with
  A''_{+++} = {(+,+)}, A''_{++-} = A''_{+-+} = {}, A''_{+--} = all but (+,+), A''_{-++} = {(+,+),(-,-)},
  A''_{-+-} = {(+,-)}, A''_{--+} = {(-,+)}, A''_{---} = {(+,-),(-,+)}.
Exact checks of every number in Section 9.8 (data of g2 including the displayed inner sums, the orbit size 12, the
extensions g_{2,m}, pi_+-, the four displayed pair laws, the correlations with their displayed numerators and
denominators, the spectral coefficients with their displayed expressions, 185/864, the final combination, and the two
equality decoders), then brute force (exact for decoders with values in {-1,0,1}, k <= 2; floating point for random
[-1,1]-valued decoders, k <= 4): Gamma <= reduction bound = spectral formula <= (E P^2 - E P)/2 <= 0.
Finally the claims of Section 11 about the one-class orbits B12 and C12 (the obstruction to a cubic-free majorant).
"""
import itertools
import math
from fractions import Fraction as Fr

import numpy as np
import sympy as sp

# ================================================================ Theorem L
qs = sp.symbols("q", positive=True)
beta_s = (1 - 2 * qs) / qs
c_s = (1 - qs) ** 2 / qs
rho_s = -qs / (1 - qs)
ev = {0: qs + beta_s, 1: qs - 1}
for k in range(2, 9):
    ev[k] = qs
for k, e in ev.items():
    d = sp.simplify(e - c_s * rho_s**k)
    if k <= 2:
        assert d == 0, (k, d)
    else:
        # d = q (1 - (-1)^k (q/(1-q))^(k-2)) >= 0 for 0 < q <= 1/2
        assert sp.simplify(d - qs * (1 - (-1) ** k * (qs / (1 - qs)) ** (k - 2))) == 0
print("Theorem L: eigenvalues of qI + beta Pi_0 - Pi_1 - c T_rho* are 0, 0, 0 at levels 0, 1, 2 and "
      "q(1 - (-1)^k (q/(1-q))^(k-2)) at level k >= 3  [EXACT, general q]")
for qq in (Fr(3, 8), Fr(2, 5), Fr(5, 12), Fr(1, 2), Fr(1, 10)):
    kern = {(1, 1): Fr(0), (1, -1): Fr(1), (-1, 1): qq / (1 - qq), (-1, -1): (1 - 2 * qq) / (1 - qq)}
    assert all(v >= 0 for v in kern.values()) and kern[1, 1] + kern[1, -1] == 1 and kern[-1, 1] + kern[-1, -1] == 1
    assert qq * kern[1, 1] + (1 - qq) * kern[-1, 1] == qq  # y has the q-biased law
    ex = qq * kern[1, 1] + (1 - qq) * kern[-1, -1] - qq * kern[1, -1] - (1 - qq) * kern[-1, 1]  # E[xy] (+-1 values)
    m = 2 * qq - 1
    assert (ex - m * m) / (1 - m * m) == -qq / (1 - qq)
print("rho*-coupling: nonnegative kernel, q-biased marginals, correlation -q/(1-q)  [EXACT]")
# the displayed joint law of (x_i, y_i) and the numbers derived from it (general q, sympy)
joint = {(1, 1): sp.Integer(0), (1, -1): qs, (-1, 1): qs, (-1, -1): 1 - 2 * qs}
assert sp.simplify(sum(joint.values()) - 1) == 0
assert sp.simplify(joint[1, 1] + joint[1, -1] - qs) == 0 and sp.simplify(joint[1, 1] + joint[-1, 1] - qs) == 0
Exy = sum(v * a * b for (a, b), v in joint.items())
assert sp.expand(Exy - (1 - 4 * qs)) == 0
corr = ((1 - 4 * qs) - (1 - 2 * qs) ** 2) / (1 - (1 - 2 * qs) ** 2)
assert sp.simplify(corr - (-4 * qs**2) / (4 * qs * (1 - qs))) == 0 and sp.simplify(corr - rho_s) == 0
for k_, (lhs_, shown) in {1: (qs - 1 - c_s * rho_s, qs - 1 + (1 - qs)), 2: (qs - c_s * rho_s**2, qs - qs)}.items():
    assert sp.simplify(lhs_ - shown) == 0 and shown == 0
assert sp.simplify(qs + beta_s - c_s) == 0  # e_0
for qq in (Fr(3, 8), Fr(2, 5), Fr(5, 12), Fr(1, 10), Fr(1, 2)):
    r_ = qq / (1 - qq)
    cc = (1 - qq) ** 2 / qq
    ek = {k: qq - cc * (-r_) ** k for k in range(3, 16)}
    assert all(ek[k] == qq * (1 - (-1) ** k * r_ ** (k - 2)) for k in ek)
    if qq < Fr(1, 2):
        assert cc > 0 and all(e > 0 for e in ek.values())
    else:  # q = 1/2: y = -x a.s., e_k = 0 for even k and 2q for odd k
        assert joint[1, 1].subs(qs, sp.Rational(1, 2)) == 0 and (1 - 2 * qs).subs(qs, sp.Rational(1, 2)) == 0
        assert all(ek[k] == (0 if k % 2 == 0 else 2 * qq) for k in ek)
print("joint law (0, q, q, 1-2q), E[x_i y_i] = 1-4q, correlation -4q^2/(4q(1-q)) = rho*, e_0 = e_1 = e_2 = 0,"
      " e_k > 0 (q < 1/2) and e_k = 0 / 2q for even / odd k (q = 1/2)  [EXACT]")


def level1_exact(qq, n, f):
    """W^1(f), E f, E f^2 on the qq-biased cube (rational: the normalisation of chi enters squared)."""
    pts_ = list(itertools.product([1, -1], repeat=n))
    wt = {x: math.prod(qq if t == 1 else 1 - qq for t in x) for x in pts_}
    W1_ = sum(sum(wt[x] * f(x) * (x[i] - (2 * qq - 1)) for x in pts_) ** 2 for i in range(n)) / (4 * qq * (1 - qq))
    return W1_, sum(wt[x] * f(x) for x in pts_), sum(wt[x] * f(x) ** 2 for x in pts_)


for qq in (Fr(3, 8), Fr(2, 5), Fr(5, 12), Fr(1, 10), Fr(1, 2)):
    for n in (2, 3):
        for f in (lambda x: Fr(int(x[0] == 1)), lambda x: Fr(int(x[0] == x[1] == 1)),
                  lambda x: Fr(int(x[0] == 1 and x[1] == -1))):
            W1_, Ef, Ef2 = level1_exact(qq, n, f)
            assert Ef2 == Ef and W1_ == qq * Ef2 + (1 - 2 * qq) / qq * Ef**2 == qq * Ef + (1 - 2 * qq) / qq * Ef**2
print("1{x_1=1}, 1{x_1=x_2=1}, 1{x_1=1,x_2=-1}: equality in both inequalities of Theorem L (q in {3/8,2/5,5/12,1/10,1/2})"
      "  [EXACT]")


def theorem_L_float(qf, n, f):
    pts = np.array(list(itertools.product([1, -1], repeat=n)))
    mu = np.prod(np.where(pts > 0, qf, 1 - qf), axis=1)
    u, v = math.sqrt((1 - qf) / qf), math.sqrt(qf / (1 - qf))
    chi1 = np.where(pts > 0, u, -v)
    fhat1 = (mu * f) @ chi1
    W1 = float(fhat1 @ fhat1)
    Ef, Ef2 = float(mu @ f), float(mu @ (f * f))
    # E f(x) f(y) under the rho* coupling (exact sum over pairs)
    kx = {(1, 1): 0.0, (1, -1): 1.0, (-1, 1): qf / (1 - qf), (-1, -1): (1 - 2 * qf) / (1 - qf)}
    K = np.ones((len(pts), len(pts)))
    for i in range(n):
        K *= np.array([[kx[(a, b)] for b in pts[:, i]] for a in pts[:, i]])
    Exy = float((mu * f) @ K @ f)
    # level >= 3 weight with eigenvalues
    rest = 0.0
    for r in range(3, n + 1):
        for S in itertools.combinations(range(n), r):
            chiS = np.prod(chi1[:, list(S)], axis=1)
            rest += (qf - (1 - qf) ** 2 / qf * (-qf / (1 - qf)) ** r) * float(mu @ (f * chiS)) ** 2
    lhs = qf * Ef2 + (1 - 2 * qf) / qf * Ef * Ef - W1 - (1 - qf) ** 2 / qf * Exy
    return lhs, rest, Exy


rng = np.random.default_rng(0)
worst = 0.0
for trial in range(300):
    qf = float(rng.choice([3 / 8, 2 / 5, 5 / 12, 1 / 2, 0.2, 0.3]))
    n = int(rng.integers(1, 7))
    f = rng.random(2**n) * (rng.random(2**n) < rng.random())
    lhs, rest, Exy = theorem_L_float(qf, n, f)
    assert abs(lhs - rest) < 1e-10 and rest > -1e-12 and Exy >= 0
    worst = max(worst, abs(lhs - rest))
print(f"(float) 300 random f >= 0, n <= 6: identity holds (max error {worst:.1e}), all terms >= 0")
for qf in (3 / 8, 2 / 5):
    for n in (2, 3, 4):
        pts = np.array(list(itertools.product([1, -1], repeat=n)))
        u, v = math.sqrt((1 - qf) / qf), math.sqrt(qf / (1 - qf))
        coef = rng.normal(size=n - 1)
        coef *= 0.9 / (v * np.clip(coef, 0, None).sum() + u * np.clip(-coef, 0, None).sum())
        hh = 1 + np.where(pts[:, 1:] > 0, u, -v) @ coef
        assert hh.min() >= 0
        f = (pts[:, 0] > 0) * hh
        mu = np.prod(np.where(pts > 0, qf, 1 - qf), axis=1)
        chi1 = np.where(pts > 0, u, -v)
        W1 = float(((mu * f) @ chi1) @ ((mu * f) @ chi1))
        assert abs(qf * float(mu @ (f * f)) + (1 - 2 * qf) / qf * float(mu @ f) ** 2 - W1) < 1e-12
print("(float) equality for f = 1{x_1 = 1} h with h >= 0 of degree <= 1")

# ================================================================ D12: the function g2
W = list(itertools.product([1, -1], repeat=3))
U = list(itertools.product([1, -1], repeat=2))
A = {(1, 1, 1): [(1, 1)], (1, 1, -1): [], (1, -1, 1): [],
     (1, -1, -1): [x for x in U if x != (1, 1)],
     (-1, 1, 1): [(1, 1), (-1, -1)], (-1, 1, -1): [(1, -1)], (-1, -1, 1): [(-1, 1)], (-1, -1, -1): [(1, -1), (-1, 1)]}
g = {w + x: (1 if x in A[w] else -1) for w in W for x in U}
pts5 = list(g)


def coef(S):
    return Fr(sum(g[x] * math.prod(x[i] for i in S) for x in pts5), 32)


mu = coef(())
l1 = [coef((i,)) for i in range(5)]
dep = all(any(g[x] != g[x[:i] + (-x[i],) + x[i + 1:]] for x in pts5) for i in range(5))
h = {w: Fr(sum(g[w + x] for x in U), 4) for w in W}
print("g2: depends on all coordinates:", dep, " mu =", mu, " level-1 =", [str(c) for c in l1])
print("h (order +++,++-,...,---) =", [str(h[w]) for w in W])
assert dep and mu == Fr(-3, 8) and l1[3] == 0 and l1[4] == 0 and all(c == Fr(-1, 8) for c in l1[:3])
assert [h[w] for w in W] == [Fr(x, 2) for x in (-1, -2, -2, 1, 0, -1, -1, 0)]
assert sum(v * v for v in h.values()) / 8 == -mu and max(h.values()) > 0
assert all(g[(-1, 1, 1) + x] == x[0] * x[1] for x in U)  # g2(-,+,+,u) = u1 u2
assert all(h[w] == Fr(len(A[w]), 2) - 1 for w in W)
assert [sum(h[w] * w[j] for w in W) / 8 for j in range(3)] == l1[:3]  # hhat({j}) = ghat({w_j})
sigma = 1 if mu > 0 else -1
assert sigma == -1 and Fr(1, 2) + abs(mu) / 2 == Fr(11, 16)  # triv_{g2} = 11/16
assert sigma * h[(1, -1, -1)] == Fr(-1, 2)  # Theorem C(ii): s^U > triv
nonzero = [S for r in range(6) for S in itertools.combinations(range(5), r) if coef(S) != 0]
assert nonzero != [(0, 1, 2, 3, 4)]  # not +- a parity
SHOWN = [(1, 1, 1), (1, -1, -1), (-1, 1, 1), (-1, 1, -1), (-1, -1, 1), (-1, -1, -1)]  # w = +++, +--, -++, -+-, --+, ---
inner = {i: [sum(x[i] for x in A[w]) for w in SHOWN] for i in range(2)}
for i in range(2):
    print(f"inner sums of u_{i + 1} over A''_w, w = +++, +--, -++, -+-, --+, ---:", inner[i])
    assert 2 * Fr(sum(sum(x[i] for x in A[w]) for w in W), 32) == l1[3 + i] == 0  # ghat({u_i}) = 2*2^-5*sum = 0
assert inner[0] == [1, -1, 0, 1, -1, 0] and inner[1] == [1, -1, 0, -1, 1, 0]
assert all(A[w] == [] for w in W if w not in SHOWN)  # A''_{++-} = A''_{+-+} = {}
hard = set()
with open("outputs/hard288.txt") as fh:
    for line in fh:
        line = line.strip()
        if line and not line.startswith("#"):
            try:
                hard.add(tuple(Fr(t) for t in line.replace(",", " ").split()[:8]))
            except (ValueError, ZeroDivisionError):
                pass
assert len(hard) == 288
assert tuple(2 * h[w] for w in W) in hard
IDX = {w: i for i, w in enumerate(W)}
orb = set()  # orbit under the symmetries of Lemma sym: permutations of J, h -> -h, h -> h(-w)
for perm in itertools.permutations(range(3)):
    for nw in (1, -1):
        for nh in (1, -1):
            orb.add(tuple(nh * 2 * h[W[IDX[tuple(nw * w[perm[j]] for j in range(3))]]] for w in W))
assert len(orb) == 12 and orb <= hard
print("2h is in hard288.txt; its orbit has 12 elements, all in hard288")
for m in (6, 7, 8):  # g_{2,m}(w, u_1, ..., u_{m-3}) = g2(w, u_1, u_2 ... u_{m-3})
    Um = list(itertools.product([1, -1], repeat=m - 3))
    gm = {w + x: g[w + (x[0], math.prod(x[1:]))] for w in W for x in Um}
    ptsm = list(gm)
    assert {w: Fr(sum(gm[w + x] for x in Um), 2 ** (m - 3)) for w in W} == h and Fr(sum(gm.values()), 2 ** m) == mu
    assert [Fr(sum(gm[y] * y[i] for y in ptsm), 2 ** m) for i in range(m)] == [Fr(-1, 8)] * 3 + [Fr(0)] * (m - 3)
    assert all(any(gm[y] != gm[y[:i] + (-y[i],) + y[i + 1:]] for y in ptsm) for i in range(m))
print("g_{2,m}, m = 6, 7, 8: same h and mu, level-one coefficients -1/8 on w and 0 on every u_i, depends on all coordinates")

p1, p2, p3 = sp.symbols("p1 p2 p3")
twoh = p1 - p2 - p3 - 2 * p1 * p2 - 2 * p1 * p3 + 2 * p2 * p3 + 2 * p1 * p2 * p3
for w in W:
    assert twoh.subs({p1: (1 + w[0]) // 2, p2: (1 + w[1]) // 2, p3: (1 + w[2]) // 2}) == 2 * h[w]
# the displayed vertex values at p = (1,1,1), (1,1,0), ..., (0,0,0)
assert [twoh.subs({p1: (1 + w[0]) // 2, p2: (1 + w[1]) // 2, p3: (1 + w[2]) // 2}) for w in W] == [-1, -2, -2, 1, 0, -1, -1, 0]
assert sp.expand(twoh - (-p1 - p2 - p3 + 2 * p2 * p3 + 2 * p1 * (1 - p2) * (1 - p3))) == 0
assert sp.expand((-p1 - p2 - p3 + 2 * p2 * p3 + 2 * p1 * (1 - p2)) - twoh - 2 * p1 * (1 - p2) * p3) == 0
print("2h(p) = -p1-p2-p3+2p2p3+2p1(1-p2)(1-p3) and the reduction adds 2p1(1-p2)p3 >= 0  [EXACT]")

pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W} for b in (1, -1)}
beta = {}
lam = {}
for b in (1, -1):
    assert sum(pi[b].values()) == 1
    bs = [sum(pi[b][w] for w in W if w[j] == 1) for j in range(3)]
    assert bs[0] == bs[1] == bs[2]
    beta[b] = bs[0]
    m2 = (2 * beta[b] - 1) ** 2
    for (j, l) in [(0, 1), (0, 2), (1, 2)]:
        lam[b, j, l] = (sum(pi[b][w] * w[j] * w[l] for w in W) - m2) / (1 - m2)
    for w in W:  # invariance under exchanging columns 2 and 3
        assert pi[b][w] == pi[b][(w[0], w[2], w[1])]
print("pi_+ =", [str(pi[1][w]) for w in W])
print("pi_- =", [str(pi[-1][w]) for w in W])
print("beta_+ =", beta[1], " beta_- =", beta[-1])
print("lambda^{12}_+-, lambda^{23}_+- =", [str(lam[b, 0, 1]) for b in (1, -1)], [str(lam[b, 1, 2]) for b in (1, -1)])
assert beta[1] == Fr(2, 5) and beta[-1] == Fr(6, 11)
assert (lam[1, 0, 1], lam[-1, 0, 1], lam[1, 1, 2], lam[-1, 1, 2]) == (Fr(-1, 4), Fr(1, 12), Fr(7, 12), Fr(-17, 60))
assert lam[1, 0, 2] == lam[1, 0, 1] and lam[-1, 0, 2] == lam[-1, 0, 1]
assert pi[1][(1, -1, 1)] == 0 and pi[1][(1, 1, -1)] == 0
assert [pi[1][w] for w in W] == [Fr(1, 10), Fr(0), Fr(0), Fr(3, 10), Fr(1, 5), Fr(1, 10), Fr(1, 10), Fr(1, 5)]
assert [pi[-1][w] for w in W] == [Fr(3, 22), Fr(2, 11), Fr(2, 11), Fr(1, 22), Fr(1, 11), Fr(3, 22), Fr(3, 22), Fr(1, 11)]
assert all(pi[1][w] == (1 + h[w]) / 5 and pi[-1][w] == (1 - h[w]) / 11 for w in W)
PAIRS = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def pair_law(b, j, l):
    return [sum(pi[b][w] for w in W if (w[j], w[l]) == c) for c in PAIRS]


LAWS = {(1, 0, 1): [Fr(1, 10), Fr(3, 10), Fr(3, 10), Fr(3, 10)], (-1, 0, 1): [Fr(7, 22), Fr(5, 22), Fr(5, 22), Fr(5, 22)],
        (1, 1, 2): [Fr(3, 10), Fr(1, 10), Fr(1, 10), Fr(1, 2)], (-1, 1, 2): [Fr(5, 22), Fr(7, 22), Fr(7, 22), Fr(3, 22)]}
for (b, j, l), law in LAWS.items():  # the displayed pair laws, and the correlations computed from them
    assert pair_law(b, j, l) == law, (b, j, l)
    m2 = (2 * beta[b] - 1) ** 2
    assert (law[0] - law[1] - law[2] + law[3] - m2) / (1 - m2) == lam[b, j, l]
for (j, l) in [(0, 1), (1, 2)]:
    print(f"law of (w{j + 1},w{l + 1}) on (++,+-,-+,--): pi_+:", [str(x) for x in pair_law(1, j, l)],
          " pi_-:", [str(x) for x in pair_law(-1, j, l)])
assert (2 * beta[1] - 1) ** 2 == Fr(1, 25) and (2 * beta[-1] - 1) ** 2 == Fr(1, 121)
assert lam[1, 0, 1] == (Fr(-1, 5) - Fr(1, 25)) / Fr(24, 25) == Fr(-1, 4)
assert lam[-1, 0, 1] == (Fr(1, 11) - Fr(1, 121)) / Fr(120, 121) == Fr(1, 12)
assert lam[1, 1, 2] == (Fr(3, 5) - Fr(1, 25)) / Fr(24, 25) == Fr(7, 12)
assert lam[-1, 1, 2] == (Fr(-3, 11) - Fr(1, 121)) / Fr(120, 121) == Fr(-17, 60)
print("pi_+-, the four pair laws and lambda^{12}_+-, lambda^{23}_+- (displayed numerators/denominators)  [EXACT]")


def aS(npos, nneg):
    return lam[1, 1, 2] ** npos * lam[-1, 1, 2] ** nneg - lam[1, 0, 1] ** npos * lam[-1, 0, 1] ** nneg


rest = Fr(5, 18)
print("a_S, |S|=1:  nu=+:", aS(1, 0), "  nu=-:", aS(0, 1), ";  |S|=2 (++, +-, --):", aS(2, 0), aS(1, 1), aS(0, 2))
assert aS(1, 0) == Fr(5, 6) and aS(0, 1) == Fr(-11, 30) and aS(2, 0) == rest
assert aS(1, 1) == Fr(-13, 90) and aS(0, 2) == Fr(11, 150)
assert (Fr(7, 12) ** 3 + Fr(1, 4) ** 3) < rest
for k in range(3, 14):
    for npos in range(k + 1):
        assert aS(npos, k - npos) <= Fr(7, 12) ** k + Fr(1, 4) ** k <= rest
# the displayed expressions
assert aS(1, 0) == Fr(7, 12) + Fr(1, 4) and aS(0, 1) == Fr(-17, 60) - Fr(1, 12)
assert aS(2, 0) == Fr(49, 144) - Fr(1, 16) and aS(1, 1) == -Fr(7, 12) * Fr(17, 60) + Fr(1, 4) * Fr(1, 12)
assert aS(0, 2) == Fr(289, 3600) - Fr(1, 144)
assert Fr(7, 12) ** 3 + Fr(1, 4) ** 3 == Fr(185, 864) < rest
assert all(aS(npos, s - npos) <= rest for s in range(1, 9) for npos in range(s + 1) if (s, npos) != (1, 1))
print("a_S <= 5/18 for every nonempty S other than a singleton {i} with nu_i = +1; (7/12)^3 + (1/4)^3 = 185/864  [EXACT]")
qD, bD = Fr(2, 5), Fr(1, 2)
assert bD == (1 - 2 * qD) / qD
assert qD * (1 - qD) == Fr(6, 25)  # the bound of Theorem K for q = 2/5
assert Fr(5, 6) - rest == Fr(5, 9) and Fr(5, 9) * qD == Fr(2, 9) and Fr(5, 9) * bD == Fr(5, 18) and Fr(2, 9) + rest == Fr(1, 2)
s2, pp = sp.symbols("s2 p")
final = (sp.Rational(5, 6) - sp.Rational(5, 18)) * (sp.Rational(2, 5) * s2 + sp.Rational(1, 2) * pp**2) + sp.Rational(5, 18) * (s2 - pp**2)
assert sp.expand(final - s2 / 2) == 0
print("(5/6 - 5/18)(q E P^2 + beta p^2) + (5/18)(E P^2 - p^2) = E P^2 / 2 for q = 2/5, beta = 1/2  [EXACT]")


def gamma_and_bounds(nu, Fvals, exact):
    k = len(nu)
    zs = list(itertools.product([1, -1], repeat=k))
    F = dict(zip(zs, Fvals))
    one = Fr(1) if exact else 1.0
    hval = {w: (h[w] if exact else float(h[w])) for w in W}
    piv = {b: {w: (pi[b][w] if exact else float(pi[b][w])) for w in W} for b in (1, -1)}
    gam = red = 0 * one
    for rows in itertools.product(W, repeat=k):
        wt = one
        for i, r in enumerate(rows):
            wt *= piv[nu[i]][r]
        if wt == 0:
            continue
        y = [F[tuple(rows[i][j] for i in range(k))] for j in range(3)]
        P = [(one + yj) / 2 for yj in y]
        hy = sum(hval[w] * math.prod((one + w[j] * y[j]) / 2 for j in range(3)) for w in W)
        gam += wt * hy
        red += wt * (-P[0] - P[1] - P[2] + 2 * P[1] * P[2] + 2 * P[0] * (1 - P[1])) / 2
    bet = [beta[n] if exact else float(beta[n]) for n in nu]
    Pz = {z: (one + F[z]) / 2 for z in zs}
    wz = {z: math.prod(bet[i] if z[i] == 1 else 1 - bet[i] for i in range(k)) for z in zs}
    pbar = sum(wz[z] * Pz[z] for z in zs)
    ep2 = sum(wz[z] * Pz[z] ** 2 for z in zs)
    spec = -pbar
    for r in range(1, k + 1):
        for S in itertools.combinations(range(k), r):
            if exact:
                chi = {z: math.prod(sp.Rational(z[i] - (2 * bet[i] - 1)) / (2 * sp.sqrt(bet[i] * (1 - bet[i]))) for i in S) for z in zs}
                sq = sp.nsimplify(sp.nsimplify(sum(wz[z] * Pz[z] * chi[z] for z in zs)) ** 2)
            else:
                chi = {z: math.prod((z[i] - (2 * bet[i] - 1)) / (2 * math.sqrt(bet[i] * (1 - bet[i]))) for i in S) for z in zs}
                sq = sum(wz[z] * Pz[z] * chi[z] for z in zs) ** 2
            npos = sum(1 for i in S if nu[i] == 1)
            spec += 2 * (aS(npos, r - npos) if exact else float(aS(npos, r - npos))) * sq
    return gam, red, spec / 2, (ep2 - pbar) / 2


best_exact = None
for k in (1, 2):
    for nu in itertools.product([1, -1], repeat=k):
        for Fv in itertools.product([1, -1, 0], repeat=2**k):
            gam, red, spec, fin = gamma_and_bounds(nu, [Fr(x) for x in Fv], True)
            assert gam <= red and sp.simplify(sp.Rational(red) - spec) == 0 and sp.Rational(spec) <= fin <= 0
            best_exact = gam if best_exact is None else max(best_exact, gam)
print("k<=2, values in {-1,0,1}: Gamma <= reduction = spectral <= (E P^2 - E P)/2 <= 0, max Gamma =", best_exact, " [EXACT]")
def triple_and_level1(nu, Fv):
    """E[P1(1-P2)P3], p, E P^2 and W_+ (exactly) for the decoder with values Fv."""
    k = len(nu)
    zs = list(itertools.product([1, -1], repeat=k))
    P = {z: (1 + Fr(f)) / 2 for z, f in zip(zs, Fv)}
    e = Fr(0)
    for rows in itertools.product(W, repeat=k):
        wt = math.prod(pi[nu[i]][rows[i]] for i in range(k))
        if wt:
            c = [tuple(rows[i][j] for i in range(k)) for j in range(3)]
            e += wt * P[c[0]] * (1 - P[c[1]]) * P[c[2]]
    bet = [beta[n] for n in nu]
    wz = {z: math.prod(bet[i] if z[i] == 1 else 1 - bet[i] for i in range(k)) for z in zs}
    Wp = sum(sum(wz[z] * P[z] * (z[i] - (2 * bet[i] - 1)) for z in zs) ** 2 / (4 * bet[i] * (1 - bet[i]))
             for i in range(k) if nu[i] == 1)
    return e, sum(wz[z] * P[z] for z in zs), sum(wz[z] * P[z] ** 2 for z in zs), Wp


for nu, Fv, name, pval in [((1,), (1, -1), "dictator", Fr(2, 5)), ((1, 1), (1, -1, -1, -1), "AND2", Fr(4, 25))]:
    gam, red, spec, fin = gamma_and_bounds(nu, [Fr(x) for x in Fv], True)
    assert gam == 0 and red == 0 and fin == 0
    e3, pv, ep2, Wp = triple_and_level1(nu, Fv)
    assert e3 == 0 and pv == pval and ep2 == pv and Wp == qD * ep2 + bD * pv**2  # P1(1-P2)P3 = 0; equality in Theorem L
    print(f"  {name}: Gamma = reduction bound = final bound = 0; p = {pv}, P1(1-P2)P3 = 0 a.s., W_+ = {Wp} "
          f"= (2/5) E P^2 + (1/2) p^2")
assert pi[1][(1, -1, 1)] == 0  # dictator: P1(1-P2)P3 = 0 because pi_+(+-+) = 0
e3, pv, ep2, Wp = triple_and_level1((1, 1), (1, -1, -1, -1))
assert aS(2, 0) == rest and Wp == Fr(48, 625) < Fr(6, 25)  # AND2: its only set above level one, S = {1,2}, has a_S = 5/18
assert -pv + 2 * (Fr(5, 9) * Fr(6, 25) + rest * (ep2 - pv**2)) == Fr(68, 375) > 0
print("  AND2 with W_+ <= 6/25 (Theorem K) instead of Theorem L: the final bound would be 2 Gamma <= 68/375, not <= 0")
worst_gam = -np.inf
for trial in range(400):
    k = int(rng.integers(1, 5))
    nu = tuple(int(x) for x in rng.choice([1, -1], size=k))
    Fv = list(np.clip(rng.uniform(-1.3, 1.3, size=2**k), -1, 1))
    gam, red, spec, fin = gamma_and_bounds(nu, Fv, False)
    assert gam <= red + 1e-12 and abs(red - spec) < 1e-10 and spec <= fin + 1e-12 and fin <= 1e-15
    worst_gam = max(worst_gam, gam)
print(f"(float) 400 random decoders, k<=4: reduction = spectral <= final <= 0, max Gamma = {worst_gam:.3e}")
print("Theorem L and D12 verified.")

# ================================================================ the two other one-class orbits (Section 11)
VERT = {w: tuple((1 + x) // 2 for x in w) for w in W}  # p-coordinates of the vertices


def cubic_coeff(h2):  # coefficient of p1 p2 p3 in the multilinear extension of the vertex values h2 (dict w -> value)
    return sum(h2[w] * (-1) ** (3 - sum(VERT[w])) for w in W)


def ext(h2, y):  # multilinear extension at p in [0,1]^3
    return sum(h2[w] * math.prod(y[j] if w[j] == 1 else 1 - y[j] for j in range(3)) for w in W)


for name, vals in (("B12", (-2, -1, -1, 1, 0, 0, 0, -1)), ("C12", (-1, -2, -2, 1, -1, 0, 0, -1))):
    h2 = {w: Fr(v) for w, v in zip(W, vals)}
    hh = {w: v / 2 for w, v in h2.items()}
    mu_ = sum(hh.values()) / 8
    pip = {w: (1 + hh[w]) / (8 * (1 + mu_)) for w in W}
    off = [w for w in W if pip[w] == 0]
    print(f"{name}: 2h = {vals}, mu = {mu_}, cubic coefficient of 2h = {cubic_coeff(h2)}, pi_+ vanishes at {off}")
    if name == "B12":
        assert off == [(1, 1, 1)] and cubic_coeff(h2) == 2 and (-1) ** (3 - sum(VERT[(1, 1, 1)])) == 1
        print("  raising h at +++ increases the (positive) cubic coefficient: no quadratic h' >= h agrees with h on supp pi_+")
    else:
        assert off == [(1, 1, -1), (1, -1, 1)] and cubic_coeff(h2) == 6
        h2p = dict(h2)
        h2p[(1, 1, -1)] += 3
        h2p[(1, -1, 1)] += 3
        assert cubic_coeff(h2p) == 0
        Pv = {1: Fr(1), -1: Fr(1, 6)}
        gam_true = sum(pip[w] * ext(hh, [Pv[w[j]] for j in range(3)]) for w in W)
        gam_quad = sum(pip[w] * ext({v: x / 2 for v, x in h2p.items()}, [Pv[w[j]] for j in range(3)]) for w in W)
        print(f"  h' = h + (3/2)(B_++- + B_+-+); k=1 decoder P(1)=1, P(-1)=1/6 (p = {Fr(2, 5) + Fr(3, 5) * Fr(1, 6)}):"
              f" quadratic bound {gam_quad}, true Gamma_+ = {gam_true}")
        assert gam_quad == Fr(1, 72) and gam_true == Fr(-29, 144)
print("Section 11 claims on the orbits B12 and C12 verified.  [EXACT]")
