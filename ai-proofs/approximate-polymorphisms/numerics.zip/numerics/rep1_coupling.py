"""Exact verification of the cubic coupling proof that the orbit rep1 (2h = (-2,-2,-1,0,-1,1,0,-1), classes {1},{2,3}) is trivial
(Proposition "rep1" in Section 11 of MAIN_RESULT.tex), and hence also rep9 (class flip).

  * h' >= h is h raised by 1 at ++- (h' = h elsewhere, in particular at +++):
        8h'(y) = -2 - y1 - 2y3 - y1y2 - y1y3 - 2y2y3 + y1y2y3.
  * rho_b on {-1,1}^4, coordinates (x, z, z', v): rho_+ has mass 1/5 at +--- and 1/10 at ++--, +-+-, -++-, -+-+, -+--, --++,
    --+-, ---+;  rho_- = (1 - 5 rho_+)/11.  Marginals: (x, z, v) ~ (w2, w3, w1) under pi_b (the full row law), (x, z') ~ (z, z') ~
    (w2, w3) and (z', v) ~ (w3, w1).  With columns Xh, Zh, Zh', Vh of a matrix with independent rows ~ rho_{nu_i}, E[h'(Y)] = E[R]
    for R(x,z,z',v) = (-2 - x - z' - v - xv - xz' - zz' - z'v + xzv)/8, and
        -8R = (1+x)(1+z')(1+v) + [(1+x)(1+z)(1+z')(1-v) + (1+x)(1-z)(1-z')(1+v) + (1-x)(1+z)(1+z')(1+v) + (1-x)(1-z)(1-z')(1-v)]/4.
  * Random exact tests (k <= 3, every nu, random rational / Boolean / dictator class-wise decoders) of
        Gamma_nu(F) <= Gamma'_nu(F) [pi] = E_rho[R] <= 0.
  * Flipping either class of rep1 gives a function in the orbit of rep9 with the classes kept (checked exactly).
usage: python3 rep1_coupling.py [trials=200] [seed=1]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
W4 = list(itertools.product((1, -1), repeat=4))
H2 = [-2, -2, -1, 0, -1, 1, 0, -1]
REP9 = [-1, -2, 0, -1, 1, -2, -1, 0]
h = {w: Fr(v, 2) for w, v in zip(W3, H2)}
mu = sum(h.values()) / 8
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
SUBSETS = [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def multilinear(vals):
    return {S: sum(vals[w] * chi(S, w) for w in W3) / 8 for S in SUBSETS}


def ext(coef, y):
    return sum((c * chi(S, y) for S, c in coef.items()), Fr(0))


def marg(law, idx):
    out = {}
    for w, p in law.items():
        key = tuple(w[a] for a in idx)
        out[key] = out.get(key, 0) + p
    return out


def R8(x, z, zp, v):
    return -2 - x - zp - v - x * v - x * zp - z * zp - zp * v + x * z * v


def R8_decomposition(x, z, zp, v):
    return -((1 + x) * (1 + zp) * (1 + v) + Fr(1, 4) * ((1 + x) * (1 + z) * (1 + zp) * (1 - v) + (1 + x) * (1 - z) * (1 - zp) * (1 + v)
                                                       + (1 - x) * (1 + z) * (1 + zp) * (1 + v) + (1 - x) * (1 - z) * (1 - zp) * (1 - v)))


def orbit(vals):
    out = set()
    for perm in itertools.permutations(range(3)):
        for sgn in (1, -1):
            for neg in (1, -1):
                f = {w: v for w, v in zip(W3, vals)}
                out.add(tuple(sgn * f[tuple(neg * w[perm[a]] for a in range(3))] for w in W3))
    return out


def classes(vals):
    c = multilinear({w: Fr(v) for w, v in zip(W3, vals)})
    groups = {}
    for a in range(3):
        groups.setdefault(c[(a,)], []).append(a)
    return sorted(groups.values())


def main():
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    assert mu == Fr(-3, 8) and sum(v * v for v in h.values()) / 8 == -mu
    for b in (1, -1):
        assert sum(pi[b].values()) == 1 and min(pi[b].values()) >= 0
    ch = multilinear(h)
    assert [ch[(a,)] for a in range(3)] == [Fr(-1, 4), Fr(-1, 8), Fr(-1, 8)]
    supp = [w for w in W3 if pi[1][w] > 0]
    print("pi_+ :", [str(pi[1][w]) for w in W3])
    print("pi_- :", [str(pi[-1][w]) for w in W3])
    print("level one (-1/4,-1/8,-1/8): classes {1},{2,3}; supp pi_+ misses:", [w for w in W3 if w not in supp])

    hp = dict(h)
    hp[(1, 1, -1)] = h[(1, 1, -1)] + 1
    assert all(hp[w] >= h[w] for w in W3) and all(hp[w] == h[w] for w in supp)
    chp = multilinear(hp)
    assert {S: 8 * c for S, c in chp.items() if c} == {(): -2, (0,): -1, (2,): -2, (0, 1): -1, (0, 2): -1, (1, 2): -2,
                                                       (0, 1, 2): 1}
    print("h' = h raised by 1 at ++-: 8h' = -2 - y1 - 2y3 - y1y2 - y1y3 - 2y2y3 + y1y2y3  [exact]")

    atoms = {(1, -1, -1, -1): 2, (1, 1, -1, -1): 1, (1, -1, 1, -1): 1, (-1, 1, 1, -1): 1, (-1, 1, -1, 1): 1, (-1, 1, -1, -1): 1,
             (-1, -1, 1, 1): 1, (-1, -1, 1, -1): 1, (-1, -1, -1, 1): 1}
    rho = {1: {u: Fr(atoms.get(u, 0), 10) for u in W4}}
    rho[-1] = {u: (1 - 5 * rho[1][u]) / 11 for u in W4}
    assert rho[-1] == {u: (Fr(1, 8) - (1 + mu) * rho[1][u]) / (1 - mu) for u in W4}
    for b in (1, -1):
        r = rho[b]
        assert sum(r.values()) == 1 and min(r.values()) >= 0
        assert marg(r, (0, 1, 3)) == marg(pi[b], (1, 2, 0))
        assert marg(r, (0, 2)) == marg(r, (1, 2)) == marg(pi[b], (1, 2))
        assert marg(r, (2, 3)) == marg(pi[b], (2, 0))
        assert marg(pi[b], (1,)) == marg(pi[b], (2,))
        print(f"rho_{'+' if b > 0 else '-'} :", {''.join('+' if t > 0 else '-' for t in u): str(p) for u, p in r.items() if p})
    print("rho_b >= 0; (x,z,v) ~ (w2,w3,w1), (x,z') ~ (z,z') ~ (w2,w3), (z',v) ~ (w3,w1) under pi_b; w2 ~ w3  [exact]")

    for u in W4:
        assert R8(*u) == R8_decomposition(*u) <= 0
    zeros = [u for u in W4 if R8(*u) == 0]
    assert all(R8(*u) == 0 for u in W4 if rho[1][u] > 0)
    print("8R = -2 - x - z' - v - xv - xz' - zz' - z'v + xzv = -(nonnegative products), so R <= 0 on [-1,1]^4; "
          f"R vanishes at {len(zeros)} vertices including all atoms of rho_+  [exact]")

    for K in ([0], [1, 2]):
        flipped = tuple(int(2 * h[tuple(-w[a] if a in K else w[a] for a in range(3))]) for w in W3)
        assert flipped in orbit(tuple(REP9)) and classes(flipped) == classes(H2)
        print(f"flipping the class {[a + 1 for a in K]} gives {flipped}, in the orbit of rep9, classes kept  [exact]")

    def expectations(nu, F, Fs, k):
        Eh = Ehp = Fr(0)
        for rows in itertools.product(W3, repeat=k):
            p = Fr(1)
            for i, w in enumerate(rows):
                p *= pi[nu[i]][w]
            if p == 0:
                continue
            y = tuple((Fs, F, F)[j][tuple(w[j] for w in rows)] for j in range(3))
            Eh += p * ext(ch, y)
            Ehp += p * ext(chp, y)
        ER = Fr(0)
        for rows in itertools.product(W4, repeat=k):
            p = Fr(1)
            for i, u in enumerate(rows):
                p *= rho[nu[i]][u]
            if p == 0:
                continue
            cols = [tuple(u[j] for u in rows) for j in range(4)]
            ER += p * R8(F[cols[0]], F[cols[1]], F[cols[2]], Fs[cols[3]]) / 8
        return Eh, Ehp, ER

    worst = None
    count = 0
    for k in (1, 2, 3):
        cube = list(itertools.product((1, -1), repeat=k))
        for nu in itertools.product((1, -1), repeat=k):
            ntr = trials if k < 3 else max(1, trials // 10)
            for t in range(ntr):
                mode = t % 3
                if mode == 0:
                    F = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                    Fs = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                elif mode == 1:
                    F = {z: Fr(rng.choice((-1, 1))) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1))) for z in cube}
                else:
                    r = rng.randrange(k)
                    F = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                Eh, Ehp, ER = expectations(nu, F, Fs, k)
                assert Eh <= Ehp, (k, nu)
                assert Ehp == ER <= 0, (k, nu)
                count += 1
                if worst is None or Ehp > worst[0]:
                    worst = (Ehp, k, nu)
    print(f"{count} random exact tests (k <= 3, every nu): Gamma <= Gamma'[pi] = E_rho[R] <= 0 in every case; "
          f"largest Gamma' = {worst[0]} (k={worst[1]}, nu={worst[2]})")
    print("rep1 (and rep9) trivial: Gamma_nu(F) <= 0 for every k, nu and class-wise decoder  [proof in MAIN_RESULT.tex]")


if __name__ == '__main__':
    main()
