"""The explicit m = 5 boundary function g0 of Theorem E (MAIN_RESULT, Section 9; orbit "A12" of hard288).

g0(w1,w2,w3,u1,u2) = +1  iff  (u1,u2) in A_w, where
  A_{+++} = A_{++-} = A_{+-+} = {},  A_{+--} = all but (+,+),
  A_{-++} = {(+,+),(-,-)},  A_{-+-} = {(+,+)},  A_{--+} = {(+,-)},  A_{---} = {(-,+)}.

Exact checks (Fractions / sympy) of every number used in Section 9 for g0, i.e. in the proofs of Theorem E and
Corollary E', Proposition 9.1 (prop:E), Lemma 9.2 (lem:E-red), Lemma 9.3 (lem:E-spec), Section 9.5 and the remark after it:
  data of g0: h = |A_w|/2 - 1, mu = -1/2, sigma = -1, triv = 3/4, level-one coefficients -1/8 (w_j) and 0 (u_i) together
    with the displayed formula and inner sums for the u-coefficients, dependence on all coordinates, sigma h(+--) = -1/2,
    2h in hard288; the same data for the extensions g_m (m = 6, 7, 8) of Corollary E';
  the row laws pi_+- (displayed values, the formulas (1+h)/4, (1-h)/12, and the conditional laws of w given g0 = +-1),
    the multilinear identity for 2h(p) (all 8 vertices and symbolically), the invariance of pi_+- under w2 <-> w3,
    beta_+ = 3/8, beta_- = 13/24 (also via E w_j = b hhat({j})/(1+b mu)), the four displayed pair laws, the
    correlations lambda^{12}_+-, lambda^{23}_+- with their displayed numerators and denominators, the identity
    E[chi_S(x) chi_T(x')] = 1{S=T} lambda_S for the column pairs (all nu with k <= 3), a* = 3259/3375;
  the spectral coefficients a_S = lambda^{23}_S - 4 lambda^{12}_S in every case displayed in Lemma 9.3, the bound a_S <= a*
    for every row-sign pattern with 1 <= |S| <= 8 other than a singleton {i} with nu_i = +1, and the tail bound
    (7/15)^s + 4 (3/5)^s <= a* for s >= 3;
  the case split of Section 9.5 (2p-3p^2+(43/15)(p-p^2) = 1-(8p-3)(11p-5)/15, G(3/8) = 1, G'(3/8) = (a*-1)/4, concavity;
    the resulting bound is <= 1 on a rational grid, with equality only at p = 3/8) and the remark after it (dictator decoder: every inequality is an equality; max G = 1 + 841/180684000 ~ 1 + 4.7e-6
    at p = 10009/26768 ~ 0.3739).
Then a brute-force test of the whole chain, for decoders F with values in {-1,0,1} and k <= 2 in exact rational
arithmetic, and for random [-1,1]-valued decoders with k <= 4 in floating point:
  2 Gamma = E[2h(P1,P2,P3)] <= 2EP1 - 4E[P1P2] + E[P2P3] - 1 = 2p - 3p^2 - 1 + sum_{S != {}} a_S Phat(S)^2
          <= 2p - 3p^2 - 1 + a*(p-p^2) + (43/15 - a*) W_+ <= 0,  with E[P1P3] = E[P1P2], W_+ = W^1(Pbar) <= 15/64.
"""
import itertools
import math
from fractions import Fraction as Fr

import numpy as np
import sympy as sp

W = list(itertools.product([1, -1], repeat=3))  # order +++, ++-, +-+, +--, -++, -+-, --+, ---
U = list(itertools.product([1, -1], repeat=2))
A = {(1, 1, 1): [], (1, 1, -1): [], (1, -1, 1): [],
     (1, -1, -1): [u for u in U if u != (1, 1)],
     (-1, 1, 1): [(1, 1), (-1, -1)], (-1, 1, -1): [(1, 1)], (-1, -1, 1): [(1, -1)], (-1, -1, -1): [(-1, 1)]}
g = {w + u: (1 if u in A[w] else -1) for w in W for u in U}
pts = list(g)
PAIRS = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def coef(S):
    return Fr(sum(g[x] * math.prod(x[i] for i in S) for x in pts), 32)


def frs(xs):
    return [str(x) for x in xs]


# ---------------------------------------------------------------- data of g0
mu = coef(())
l1 = [coef((i,)) for i in range(5)]
dep = [any(g[x] != g[x[:i] + (-x[i],) + x[i + 1:]] for x in pts) for i in range(5)]
h = {w: Fr(sum(g[w + u] for u in U), 4) for w in W}
sigma = 1 if mu > 0 else -1
triv = Fr(1, 2) + abs(mu) / 2
hhat1 = [sum(h[w] * w[j] for w in W) / 8 for j in range(3)]
print("g0^{-1}(+1):", sorted(x for x in pts if g[x] == 1))
print("depends on all coordinates:", all(dep), " mu =", mu, " sigma =", sigma, " triv =", triv,
      " level-1 =", frs(l1))
print("h (order +++,++-,...,---) =", frs(h[w] for w in W))
assert all(dep)
assert all(g[(-1, 1, 1) + u] == u[0] * u[1] for u in U)  # g0(-,+,+,u) = u1 u2: dependence on u1, u2 via A_{-++}
assert [h[w] for w in W] == [Fr(-1), Fr(-1), Fr(-1), Fr(1, 2), Fr(0), Fr(-1, 2), Fr(-1, 2), Fr(-1, 2)]
assert all(h[w] == Fr(len(A[w]), 2) - 1 for w in W)
assert mu == sum(h.values()) / 8 == Fr(-1, 2) and sigma == -1 and triv == Fr(3, 4)
assert l1 == [Fr(-1, 8)] * 3 + [Fr(0)] * 2 and hhat1 == l1[:3]  # J = {1,2,3}, equal coefficients: one class
nonzero = [S for r in range(6) for S in itertools.combinations(range(5), r) if coef(S) != 0]
assert nonzero != [(0, 1, 2, 3, 4)]  # not +- a parity
assert sigma * h[(1, -1, -1)] == Fr(-1, 2)  # Theorem C(ii): s^U > triv
assert sum(v * v for v in h.values()) / 8 == abs(mu)  # boundary case ||h||^2 = |mu|
SHOWN = [(1, -1, -1), (-1, 1, 1), (-1, 1, -1), (-1, -1, 1), (-1, -1, -1)]  # w = +--, -++, -+-, --+, ---
inner = {i: [sum(u[i] for u in A[w]) for w in SHOWN] for i in range(2)}
for i in range(2):
    print(f"inner sums of u_{i + 1} over A_w, w = +--, -++, -+-, --+, ---:", inner[i])
    assert 2 * Fr(sum(sum(u[i] for u in A[w]) for w in W), 32) == l1[3 + i] == 0  # ghat({u_i}) = 2*2^-5*sum = 0
assert inner[0] == [-1, 0, 1, 1, -1] and inner[1] == [-1, 0, 1, -1, 1]
assert all(A[w] == [] for w in W if w not in SHOWN)  # the omitted w contribute empty inner sums
hard = set()
with open("outputs/hard288.txt") as fh:
    for line in fh:
        line = line.strip()
        if line and not line.startswith("#"):
            try:
                hard.add(tuple(Fr(t) for t in line.replace(",", " ").split()[:8]))
            except (ValueError, ZeroDivisionError):
                pass
assert len(hard) == 288  # the file lists 2h
assert tuple(2 * h[w] for w in W) == (-2, -2, -2, 1, 0, -1, -1, -1) and tuple(2 * h[w] for w in W) in hard
print("2h = (-2,-2,-2,1,0,-1,-1,-1) is in hard288.txt (288 entries parsed)")

# Corollary E': g_m(w, u_1, ..., u_{m-3}) = g0(w, u_1, u_2 u_3 ... u_{m-3})
for m in (6, 7, 8):
    Um = list(itertools.product([1, -1], repeat=m - 3))
    gm = {w + u: g[w + (u[0], math.prod(u[1:]))] for w in W for u in Um}
    ptsm = list(gm)
    cm = [Fr(sum(gm[x] * x[i] for x in ptsm), 2 ** m) for i in range(m)]
    hm = {w: Fr(sum(gm[w + u] for u in Um), 2 ** (m - 3)) for w in W}
    assert hm == h and Fr(sum(gm.values()), 2 ** m) == mu and cm == [Fr(-1, 8)] * 3 + [Fr(0)] * (m - 3)
    assert all(any(gm[x] != gm[x[:i] + (-x[i],) + x[i + 1:]] for x in ptsm) for i in range(m))
print("g_m, m = 6, 7, 8: same h, mu and level-one coefficients (-1/8 on w, 0 on every u_i), depends on all coordinates")

# ---------------------------------------------------------------- row laws
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W} for b in (1, -1)}
print("pi_+ =", frs(pi[1][w] for w in W))
print("pi_- =", frs(pi[-1][w] for w in W))
assert [pi[1][w] for w in W] == [Fr(0), Fr(0), Fr(0), Fr(3, 8), Fr(1, 4), Fr(1, 8), Fr(1, 8), Fr(1, 8)]
assert [pi[-1][w] for w in W] == [Fr(1, 6), Fr(1, 6), Fr(1, 6), Fr(1, 24), Fr(1, 12), Fr(1, 8), Fr(1, 8), Fr(1, 8)]
assert all(pi[1][w] == (1 + h[w]) / 4 and pi[-1][w] == (1 - h[w]) / 12 for w in W)
for b in (1, -1):  # pi_b is the law of w given g0 = b, for a uniform input (w, u)
    nb = sum(1 for x in pts if g[x] == b)
    assert all(pi[b][w] == Fr(sum(1 for u in U if g[w + u] == b), nb) for w in W)
print("pi_+- = (1 +- h)/(8 (1 +- mu)) = conditional laws of w given g0 = +-1  [EXACT]")

# ---------------------------------------------------------------- Lemma 9.2: multilinear form, symmetry
p1, p2, p3 = sp.symbols("p1 p2 p3")
twoh = -1 + 2 * p1 - 3 * p1 * p2 - 3 * p1 * p3 + p2 * p3 + 2 * p1 * p2 * p3
vertex_vals = [twoh.subs({p1: (1 + w[0]) // 2, p2: (1 + w[1]) // 2, p3: (1 + w[2]) // 2}) for w in W]
assert vertex_vals == [-2, -2, -2, 1, 0, -1, -1, -1] == [2 * h[w] for w in W]
ext = sum(sp.Rational(h[w].numerator, h[w].denominator)
          * sp.prod([pj if w[j] == 1 else 1 - pj for j, pj in enumerate((p1, p2, p3))]) for w in W)
assert sp.expand(2 * ext - twoh) == 0
print("2h(p) = -1 + 2p1 - 3p1p2 - 3p1p3 + p2p3 + 2p1p2p3 (values -2,-2,-2,1,0,-1,-1,-1 at the vertices)  [EXACT]")
for b in (1, -1):
    assert all(pi[b][w] == pi[b][(w[0], w[2], w[1])] for w in W)
    assert pi[b][(1, 1, -1)] == pi[b][(1, -1, 1)] and pi[b][(-1, 1, -1)] == pi[b][(-1, -1, 1)]
print("pi_+ and pi_- are invariant under w2 <-> w3  [EXACT]")

# ---------------------------------------------------------------- biases, pair laws, correlations
beta = {}
for b in (1, -1):
    assert sum(pi[b].values()) == 1 and min(pi[b].values()) >= 0
    bs = [sum(pi[b][w] for w in W if w[j] == 1) for j in range(3)]
    assert bs[0] == bs[1] == bs[2]
    beta[b] = bs[0]
    for j in range(3):  # E_{pi_b} w_j = b hhat({j}) / (1 + b mu)
        assert sum(pi[b][w] * w[j] for w in W) == b * hhat1[j] / (1 + b * mu) == 2 * beta[b] - 1
print("beta_+ =", beta[1], " beta_- =", beta[-1])
assert beta[1] == Fr(3, 8) and beta[-1] == Fr(13, 24)
for bt in beta.values():  # chi^{(beta)} has mean 0 and variance 1 when Pr[t = 1] = beta
    m_ = 2 * bt - 1
    assert bt * (1 - m_) + (1 - bt) * (-1 - m_) == 0
    assert (bt * (1 - m_) ** 2 + (1 - bt) * (1 + m_) ** 2) / (4 * bt * (1 - bt)) == 1


def pair_law(b, j, l):
    return [sum(pi[b][w] for w in W if (w[j], w[l]) == c) for c in PAIRS]


for (j, l) in [(0, 1), (1, 2)]:
    print(f"law of (w{j + 1},w{l + 1}) on (++,+-,-+,--): pi_+:", frs(pair_law(1, j, l)), " pi_-:", frs(pair_law(-1, j, l)))
assert pair_law(1, 0, 1) == [Fr(0), Fr(3, 8), Fr(3, 8), Fr(1, 4)]
assert pair_law(-1, 0, 1) == [Fr(1, 3), Fr(5, 24), Fr(5, 24), Fr(1, 4)]
assert pair_law(1, 1, 2) == [Fr(1, 4), Fr(1, 8), Fr(1, 8), Fr(1, 2)]
assert pair_law(-1, 1, 2) == [Fr(1, 4), Fr(7, 24), Fr(7, 24), Fr(1, 6)]
assert all(pair_law(b, 0, 2) == pair_law(b, 0, 1) for b in (1, -1))
lam = {}
Eww = {}
for b in (1, -1):
    m_ = 2 * beta[b] - 1
    for (j, l) in [(0, 1), (0, 2), (1, 2)]:
        law = pair_law(b, j, l)
        Eww[b, j, l] = law[0] - law[1] - law[2] + law[3]
        lam[b, j, l] = (Eww[b, j, l] - m_ * m_) / (1 - m_ * m_)
        # the same number as E[chi(w_j) chi(w_l)] computed from the definition of chi^{(beta_b)}
        assert sum(pi[b][w] * (w[j] - m_) * (w[l] - m_) for w in W) / (4 * beta[b] * (1 - beta[b])) == lam[b, j, l]
assert (Eww[1, 0, 1], Eww[-1, 0, 1], Eww[1, 1, 2], Eww[-1, 1, 2]) == (Fr(-1, 2), Fr(1, 6), Fr(1, 2), Fr(-1, 6))
assert (2 * beta[1] - 1) ** 2 == Fr(1, 16) and (2 * beta[-1] - 1) ** 2 == Fr(1, 144)
assert lam[1, 0, 1] == (Fr(-1, 2) - Fr(1, 16)) / Fr(15, 16) == Fr(-3, 5)
assert lam[-1, 0, 1] == (Fr(1, 6) - Fr(1, 144)) / Fr(143, 144) == Fr(23, 143)
assert lam[1, 1, 2] == (Fr(1, 2) - Fr(1, 16)) / Fr(15, 16) == Fr(7, 15)
assert lam[-1, 1, 2] == (Fr(-1, 6) - Fr(1, 144)) / Fr(143, 144) == Fr(-25, 143)
assert lam[1, 0, 2] == lam[1, 0, 1] and lam[-1, 0, 2] == lam[-1, 0, 1]
print("lambda^{12}_+- =", frs([lam[1, 0, 1], lam[-1, 0, 1]]), " lambda^{23}_+- =", frs([lam[1, 1, 2], lam[-1, 1, 2]]),
      " (lambda^{13} = lambda^{12})  [EXACT]")
# E[chi_S(x) chi_T(x')] = 1{S=T} prod_{i in S} lambda_{nu_i} for (x,x') = (X,Y) (lambda^{12}), (Y,Z) (lambda^{23}), and
# (X,X) (orthonormality); chi_S = prod_{i in S} (x_i - m_i) / sqrt(4 beta_i (1 - beta_i)), so compare unnormalised products
for k in (1, 2, 3):
    for nu in (itertools.product([1, -1], repeat=k) if k < 3 else [(1, 1, 1), (1, 1, -1), (1, -1, -1), (-1, -1, -1)]):
        subsets = [S for r in range(k + 1) for S in itertools.combinations(range(k), r)]
        ms = [2 * beta[n] - 1 for n in nu]
        acc = {(jl, S, T): Fr(0) for jl in ((0, 1), (1, 2), (0, 0)) for S in subsets for T in subsets}
        for rows in itertools.product(W, repeat=k):
            wt = math.prod(pi[nu[i]][rows[i]] for i in range(k))
            if wt == 0:
                continue
            vec = [{S: math.prod(rows[i][j] - ms[i] for i in S) for S in subsets} for j in range(3)]
            for (j, l) in ((0, 1), (1, 2), (0, 0)):
                for S in subsets:
                    for T in subsets:
                        acc[(j, l), S, T] += wt * vec[j][S] * vec[l][T]
        for S in subsets:
            nrm = math.prod(4 * beta[nu[i]] * (1 - beta[nu[i]]) for i in S)
            for T in subsets:
                for (j, l), corr in (((0, 1), lambda b: lam[b, 0, 1]), ((1, 2), lambda b: lam[b, 1, 2]), ((0, 0), lambda b: 1)):
                    want = math.prod(corr(nu[i]) for i in S) * nrm if S == T else 0
                    assert acc[(j, l), S, T] == want, (nu, S, T, j, l)
print("E[chi_S(x)chi_T(x')] = 1{S=T} lambda_S for (X,Y), (Y,Z), and orthonormality of chi_S, all nu with k <= 3  [EXACT]")

# ---------------------------------------------------------------- Lemma 9.3: spectral coefficients
L12 = {b: lam[b, 0, 1] for b in (1, -1)}
L23 = {b: lam[b, 1, 2] for b in (1, -1)}


def aS(signs):
    """a_S = lambda^{23}_S - 4 lambda^{12}_S for a set S whose rows have the signs nu_i in `signs`."""
    return math.prod(L23[s] for s in signs) - 4 * math.prod(L12[s] for s in signs)


astar = Fr(7, 15) ** 3 + 4 * Fr(3, 5) ** 3
c43 = Fr(43, 15)
assert astar == Fr(3259, 3375) and 0 <= astar < 1 and c43 - astar == Fr(6416, 3375) > 0
assert aS(()) == -3  # S = {}: 2p - 4p^2 + p^2 = 2p - 3p^2
assert aS((1,)) == Fr(7, 15) + Fr(12, 5) == c43 and -4 * L12[1] == Fr(12, 5)
assert aS((-1,)) == Fr(-25, 143) - Fr(92, 143) == Fr(-117, 143) < 0 and -4 * L12[-1] == Fr(-92, 143)
assert aS((1, 1)) == Fr(49, 225) - Fr(36, 25) == Fr(-11, 9)
assert aS((1, -1)) == aS((-1, 1)) == -Fr(7, 15) * Fr(25, 143) + 4 * Fr(3, 5) * Fr(23, 143) == Fr(653, 2145)
assert aS((-1, -1)) == Fr(625 - 2116, 20449) == Fr(-1491, 20449) < 0
assert max(aS((-1,)), aS((1, 1)), aS((1, -1)), aS((-1, -1))) < astar
print("a_S: {+} ->", aS((1,)), " {-} -> -117/143 =", aS((-1,)), " {+,+} ->", aS((1, 1)), " {+,-} ->", aS((1, -1)),
      " {-,-} ->", aS((-1, -1)), ";  a* =", astar)
worst = None
for s in range(1, 9):
    for signs in itertools.product([1, -1], repeat=s):
        if signs == (1,):
            continue
        assert aS(signs) <= astar, signs
        worst = aS(signs) if worst is None else max(worst, aS(signs))
print("a_S <= a* for all 510 row-sign patterns with 1 <= |S| <= 8 except {+};  largest of these a_S =", worst)
mx23 = max(abs(L23[b]) for b in (1, -1))
mx12 = max(abs(L12[b]) for b in (1, -1))
assert mx23 == Fr(7, 15) and mx12 == Fr(3, 5) and mx23 ** 3 + 4 * mx12 ** 3 == astar
for s in range(3, 61):  # both ratios are < 1, so the bound decreases in s
    bound = mx23 ** s + 4 * mx12 ** s
    assert bound <= astar and bound > mx23 ** (s + 1) + 4 * mx12 ** (s + 1)
    for npos in range(s + 1):
        sg = (1,) * npos + (-1,) * (s - npos)
        assert aS(sg) <= abs(math.prod(L23[x] for x in sg)) + 4 * abs(math.prod(L12[x] for x in sg)) <= bound
print("|S| >= 3: a_S <= (7/15)^|S| + 4 (3/5)^|S| <= (7/15)^3 + 4 (3/5)^3 = a* = 3259/3375  [EXACT]")

# ---------------------------------------------------------------- Section 9.5: case split; remark
q = Fr(3, 8)
assert q * (1 - q) == Fr(15, 64)  # Theorem K: W_+ <= 15/64
p = sp.symbols("p")
A_s, c43_s = sp.Rational(astar.numerator, astar.denominator), sp.Rational(43, 15)
first = 2 * p - 3 * p**2 + c43_s * (p - p**2)
assert sp.expand(first - (1 - (8 * p - 3) * (11 * p - 5) / 15)) == 0
assert sorted(sp.solve((8 * p - 3) * (11 * p - 5), p)) == [sp.Rational(3, 8), sp.Rational(5, 11)]
G = 2 * p - 3 * p**2 + A_s * (p - p**2) + (c43_s - A_s) * sp.Rational(15, 64)
r38 = sp.Rational(3, 8)
assert 2 * r38 == sp.Rational(3, 4) and 3 * r38**2 == sp.Rational(27, 64) and c43_s * sp.Rational(15, 64) == sp.Rational(43, 64)
assert r38 - r38**2 == sp.Rational(15, 64)
assert G.subs(p, r38) == sp.Rational(3, 4) - sp.Rational(27, 64) + sp.Rational(43, 64) == 1
assert sp.diff(G, p).subs(p, r38) == (A_s - 1) / 4 < 0
assert sp.diff(G, p, 2) == -6 - 2 * A_s < 0
assert G.subs(p, sp.Rational(5, 11)) < 1
print("2p-3p^2+(43/15)(p-p^2) = 1-(8p-3)(11p-5)/15;  G(3/8) = 3/4-27/64+43/64 = 1, G'(3/8) = (a*-1)/4 < 0, G'' < 0  [EXACT]")
pstar = sp.solve(sp.diff(G, p), p)[0]
Gmax = G.subs(p, pstar)
print(f"remark: max G = 1 + {Gmax - 1} = 1 + {float(Gmax - 1):.4e} at p = {pstar} = {float(pstar):.6f}")
assert pstar == sp.Rational(10009, 26768) and Gmax - 1 == sp.Rational(841, 180684000)
assert pstar < r38 and round(float(pstar), 4) == 0.3739 and f"{float(Gmax - 1):.1e}" == "4.7e-06"
assert all(first.subs(p, t) > 1 for t in (sp.Rational(3, 8) + sp.Rational(1, 10**6), sp.Rational(2, 5), sp.Rational(5, 11) - sp.Rational(1, 10**6)))


def rhs(t):  # right-hand side of the display in Section 9.5 (bound for 2 Gamma + 1)
    return 2 * t - 3 * t * t + astar * (t - t * t) + (c43 - astar) * min(t - t * t, Fr(15, 64))


grid = [Fr(j, 4000) for j in range(4001)]
assert all(rhs(t) <= 1 for t in grid) and [t for t in grid if rhs(t) == 1] == [Fr(3, 8)]
print("right-hand side of Section 9.5 <= 1 on the grid p = j/4000, with equality only at p = 3/8  [EXACT]")

# ---------------------------------------------------------------- the chain on explicit decoders


def analyse(nu, Fvals, exact):
    """All quantities of Lemmas 9.2, 9.3 and Section 9.5 for the decoder F (values Fvals on {-1,1}^k, k = len(nu))."""
    k = len(nu)
    zs = list(itertools.product([1, -1], repeat=k))
    F = dict(zip(zs, Fvals))
    cv = (lambda x: x) if exact else float
    one = cv(Fr(1))
    hv = {w: cv(h[w]) for w in W}
    piv = {b: {w: cv(pi[b][w]) for w in W} for b in (1, -1)}
    P = {z: (one + F[z]) / 2 for z in zs}
    gam = E1 = E12 = E13 = E23 = E123 = 0 * one
    for rows in itertools.product(W, repeat=k):
        wt = one
        for i, r in enumerate(rows):
            wt *= piv[nu[i]][r]
        if wt == 0:
            continue
        cols = [tuple(rows[i][j] for i in range(k)) for j in range(3)]
        y = [F[c] for c in cols]
        Pc = [P[c] for c in cols]
        gam += wt * sum(hv[w] * math.prod((one + w[j] * y[j]) / 2 for j in range(3)) for w in W)
        E1 += wt * Pc[0]
        E12 += wt * Pc[0] * Pc[1]
        E13 += wt * Pc[0] * Pc[2]
        E23 += wt * Pc[1] * Pc[2]
        E123 += wt * Pc[0] * Pc[1] * Pc[2]
    bet = [cv(beta[n]) for n in nu]
    wz = {z: math.prod(bet[i] if z[i] == 1 else 1 - bet[i] for i in range(k)) for z in zs}
    pm = sum(wz[z] * P[z] for z in zs)
    EP2 = sum(wz[z] * P[z] ** 2 for z in zs)
    sq = {}  # Phat(S)^2, rational: the normalisation of chi_S enters squared
    for r in range(k + 1):
        for S in itertools.combinations(range(k), r):
            c = sum(wz[z] * P[z] * math.prod(z[i] - (2 * bet[i] - 1) for i in S) for z in zs)
            sq[S] = c * c / math.prod(4 * bet[i] * (1 - bet[i]) for i in S)
    nz = [S for S in sq if S]
    l12 = {S: math.prod(cv(L12[nu[i]]) for i in S) for S in sq}
    l23 = {S: math.prod(cv(L23[nu[i]]) for i in S) for S in sq}
    spec = 2 * pm - 3 * pm**2 + sum(cv(aS(tuple(nu[i] for i in S))) * sq[S] for S in nz)
    plus = [i for i in range(k) if nu[i] == 1]
    Wp = sum(sq[(i,)] for i in plus)
    # Pbar(x_+) = E[P | x_+] on the 3/8-biased cube of the nu = +1 rows, and its level-one weight
    Pbar = {}
    for z in zs:
        key = tuple(z[i] for i in plus)
        Pbar[key] = Pbar.get(key, 0 * one) + wz[z] * P[z] / math.prod(bet[i] if z[i] == 1 else 1 - bet[i] for i in plus)
    b38 = cv(beta[1])
    wzp = {x: math.prod(b38 if t == 1 else 1 - b38 for t in x) for x in Pbar}
    W1bar = sum(sum(wzp[x] * Pbar[x] * (x[a] - (2 * b38 - 1)) for x in Pbar) ** 2 / (4 * b38 * (1 - b38))
                for a in range(len(plus)))
    as_, c43_ = cv(astar), cv(c43)
    lemma3 = 2 * pm - 3 * pm**2 + as_ * (pm - pm**2) + (c43_ - as_) * Wp
    final = 2 * pm - 3 * pm**2 + as_ * (pm - pm**2) + (c43_ - as_) * min(pm - pm**2, cv(Fr(15, 64)))
    return dict(gam=gam, poly=-1 + 2 * E1 - 3 * E12 - 3 * E13 + E23 + 2 * E123, red=2 * E1 - 4 * E12 + E23 - 1,
                E1=E1, E12=E12, E13=E13, E23=E23, E12s=sum(l12[S] * sq[S] for S in sq),
                E23s=sum(l23[S] * sq[S] for S in sq), p=pm, sq0=sq[()], var=sum(sq[S] for S in nz), EP2=EP2,
                spec=spec, Wp=Wp, W1bar=W1bar, lemma3=lemma3, final=final)


d = analyse((1,), [Fr(1), Fr(-1)], True)  # the dictator decoder: k = 1, nu = (+1), F(z) = z
assert pi[1][(1, 1, 1)] == pi[1][(1, 1, -1)] == 0 and d["E12"] == 0  # P1 P2 = 0 a.s.
assert d["gam"] == 0 and d["p"] == Fr(3, 8) and d["Wp"] == d["var"] == Fr(15, 64)
assert 2 * d["gam"] == d["red"] and d["red"] + 1 == d["spec"] == d["lemma3"] == d["final"] == 1
print("dictator (k=1, nu=+1, F(z)=z): Gamma = 0, p = 3/8, P1P2 = 0 a.s., W_+ = Var P = 15/64; "
      "every inequality of the chain is an equality  [EXACT]")

best_exact = None
count = 0
for k in (1, 2):
    for nu in itertools.product([1, -1], repeat=k):
        for Fv in itertools.product([1, -1, 0], repeat=2**k):
            d = analyse(nu, [Fr(x) for x in Fv], True)
            assert 2 * d["gam"] == d["poly"] and d["E13"] == d["E12"] and d["E1"] == d["p"]
            assert d["E12"] == d["E12s"] and d["E23"] == d["E23s"] and d["sq0"] == d["p"] ** 2
            assert d["var"] == d["EP2"] - d["p"] ** 2 <= d["p"] - d["p"] ** 2
            assert 2 * d["gam"] <= d["red"] and d["red"] + 1 == d["spec"] <= d["lemma3"]
            assert d["Wp"] == d["W1bar"] and d["Wp"] <= d["var"] and d["Wp"] <= Fr(15, 64)
            assert 2 * d["gam"] + 1 <= d["final"] <= 1 and d["gam"] <= 0
            best_exact = d["gam"] if best_exact is None else max(best_exact, d["gam"])
            count += 1
print(f"{count} decoders, k<=2, values in {{-1,0,1}}: 2Gamma <= reduction bound = spectral formula - 1 <= Lemma 9.3 bound - 1,"
      f" W_+ = W^1(Pbar) <= min(Var P, 15/64), final bound <= 1; max Gamma = {best_exact}  [EXACT]")
assert best_exact == 0
rng = np.random.default_rng(0)
worst_gam = -np.inf
for trial in range(400):
    k = int(rng.integers(1, 5))
    nu = tuple(int(x) for x in rng.choice([1, -1], size=k))
    Fv = list(np.clip(rng.uniform(-1.3, 1.3, size=2**k), -1, 1))
    d = analyse(nu, Fv, False)
    assert abs(2 * d["gam"] - d["poly"]) < 1e-12 and abs(d["E13"] - d["E12"]) < 1e-12
    assert abs(d["E12"] - d["E12s"]) < 1e-12 and abs(d["E23"] - d["E23s"]) < 1e-12
    assert 2 * d["gam"] <= d["red"] + 1e-12 and abs(d["red"] + 1 - d["spec"]) < 1e-10 and d["spec"] <= d["lemma3"] + 1e-12
    assert abs(d["Wp"] - d["W1bar"]) < 1e-12 and d["Wp"] <= 15 / 64 + 1e-12 and d["final"] <= 1 + 1e-12
    worst_gam = max(worst_gam, d["gam"])
print(f"(float) 400 random [-1,1]-valued decoders, k<=4: the same chain holds, max Gamma = {worst_gam:.3e} (<= 0)")
print("g0 verified: every number of Section 9 used for Theorem E checked.")
