"""Deeper label constructions for candidate hard h (from q6_hsearch.py).

For k label rows with output labels nu in {+-1}^k (rows independent, row i ~ pi_{nu_i},
pi_b(a) = (1 + b h(a)) / (2^d (1 + b mu))) and class-wise decoders F_c : {+-1}^k -> {+-1, 0}
(0 = an independent uniformly random effective input, i.e. multilinear extension at 0),
compute max of E[h(F(W))] (h normalised to mu < 0).  Positive => s_g nontrivial.
"""
import itertools
import sys
import numpy as np

d = int(sys.argv[1]); r = int(sys.argv[2]); KMAX = int(sys.argv[3]) if len(sys.argv) > 3 else 2
ALLOW0 = (len(sys.argv) > 4 and sys.argv[4] == '0')
H = np.load(f'outputs/hard_h_d{d}_r{r}.npy')
P = np.array(list(itertools.product([1, -1], repeat=d)))
n = len(P)
idx = {tuple(p): i for i, p in enumerate(P)}


def hml(h, w):
    """multilinear extension of h at w in {-1,0,1}^d."""
    zs = [j for j in range(d) if w[j] == 0]
    if not zs:
        return h[idx[tuple(w)]]
    tot = 0.0
    for s in itertools.product([1, -1], repeat=len(zs)):
        ww = list(w)
        for j, v in zip(zs, s):
            ww[j] = v
        tot += h[idx[tuple(ww)]]
    return tot / 2 ** len(zs)


def best_labels(hv, k):
    mu = hv.mean()
    h = hv * (-1 if mu > 0 else 1)
    mu = h.mean()
    l1 = h @ P / n
    key = np.round(l1, 10)
    uniq = sorted(set(key))
    cls = [uniq.index(v) for v in key]
    R = len(uniq)
    pi = {b: (1 + b * h) / (n * (1 + b * mu)) for b in (1, -1)}
    labs = list(itertools.product([1, -1], repeat=k))
    lid = {l: i for i, l in enumerate(labs)}
    outs = [1, -1, 0] if ALLOW0 else [1, -1]
    Fs = list(itertools.product(outs, repeat=len(labs)))
    # precompute h on {-1,0,1}^d
    hcache = {}
    best = (-np.inf, None)
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        Ws = list(itertools.product(range(n), repeat=k))
        wts = np.array([np.prod([pi[nu[i]][Wi[i]] for i in range(k)]) for Wi in Ws])
        keep = wts > 0
        Ws = [W for W, kk in zip(Ws, keep) if kk]
        wts = wts[keep]
        col = np.array([[lid[tuple(int(P[Wi[i]][j]) for i in range(k))] for j in range(d)] for Wi in Ws])
        if len(Fs) ** R > 2_000_000:
            return None
        for combo in itertools.product(range(len(Fs)), repeat=R):
            eff = np.empty(col.shape, dtype=int)
            for j in range(d):
                eff[:, j] = np.array(Fs[combo[cls[j]]])[col[:, j]]
            tot = 0.0
            for wt, row in zip(wts, eff):
                t = tuple(row)
                if t not in hcache:
                    hcache[t] = hml(h, t)
                tot += wt * hcache[t]
            if tot > best[0]:
                best = (tot, (nu, combo))
    return best


nwin = 0
for t, hv in enumerate(H):
    res = []
    for k in range(1, KMAX + 1):
        b = best_labels(hv, k)
        res.append(None if b is None else round(b[0], 6))
        if b is not None and b[0] > 1e-9:
            break
    win = any(v is not None and v > 1e-9 for v in res)
    nwin += win
    if t < 30 or not win:
        print(t, 'h=', list(np.round(hv, 3)), 'best by k:', res)
print(f"{nwin}/{len(H)} candidate hard h are beaten by k<={KMAX} labels (allow0={ALLOW0})")
