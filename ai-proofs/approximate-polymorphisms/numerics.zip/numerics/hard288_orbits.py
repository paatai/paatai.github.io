"""Orbit structure of the 288 boundary functions under the symmetries of the nontriviality question.

By Theorem D, whether s_g > triv depends only on h, and it is invariant under
  (1) permutations of the three J-coordinates,
  (2) h -> -h          (sigma and the two row laws pi_+ and pi_- are exchanged),
  (3) h -> h(-w)       (with F(z) -> -F(-z)).
For each h in hard288 we record its orbit, its mean, its level-one coefficients and whether all
level-one coefficients are equal (a single class, as for g0).
Output: one line per orbit.
"""
import itertools

import numpy as np

W = list(itertools.product((1, -1), repeat=3))  # order +++, ++-, ..., ---
IDX = {w: i for i, w in enumerate(W)}


def act(h, perm, neg_w, neg_h):
    out = [0] * 8
    for w in W:
        w2 = tuple(w[perm[j]] for j in range(3))
        if neg_w:
            w2 = tuple(-x for x in w2)
        out[IDX[w]] = h[IDX[w2]] * (-1 if neg_h else 1)
    return tuple(out)


def canon(h):
    imgs = [act(h, p, a, b) for p in itertools.permutations(range(3)) for a in (0, 1) for b in (0, 1)]
    return min(imgs)


def fourier(h2):
    h = np.array(h2) / 2
    mu = h.mean()
    lvl1 = [float(np.mean([h[IDX[w]] * w[j] for w in W])) for j in range(3)]
    return mu, lvl1


def orbit(h):
    return {act(h, p, a, b) for p in itertools.permutations(range(3)) for a in (0, 1) for b in (0, 1)}


hs = [tuple(int(x) for x in line.split()) for line in open('outputs/hard288.txt')]
assert len(set(hs)) == len(hs)
orbits = {}
for h in hs:
    orbits.setdefault(canon(h), []).append(h)
for c, mem in orbits.items():
    assert set(mem) == orbit(mem[0]), "list not closed under the symmetry group"
n_pos = sum(1 for h in hs if sum(h) > 0)
print(f"{len(hs)} functions, {len(orbits)} orbits; every full orbit is contained in the list "
      f"(so the list is closed under the group, in particular under h -> -h); {n_pos} have mu > 0")
g0 = (-2, -2, -2, 1, 0, -1, -1, -1)
for c, mem in sorted(orbits.items(), key=lambda kv: -len(kv[1])):
    rep = mem[0]
    mu, l1 = fourier(rep)
    one_class = len(set(abs(x) for x in l1)) == 1 and len(set(l1)) == 1
    tag = " <- g0" if canon(g0) == c else ""
    print(f"size {len(mem):2d}  rep 2h={rep}  mu={mu:+.4f}  level1={[round(x, 4) for x in l1]}"
          f"  one-class={one_class}{tag}")
