"""Gaussian limit of threshold decoders for the 17 open m = 9 pairs (floating point, exploratory).

For one class (|J| = 2), sigma Gamma_nu(F) = H(p) + 4|b| (E[P(X)P(Z)] - p^2) with H(p) = sigma h(2p-1, 2p-1), P = (1+F)/2 and
p = E P.  Take k rows of the dangerous sign nu_* (correlation -a between X_r and Z_r) and the threshold decoder
P = 1[#{r : X_r = c} <= tau].  As k -> infinity with p fixed, (counts of X, counts of Z) is asymptotically bivariate normal with
correlation -a, and E[P(X)P(Z)] -> Lambda_{-a}(p) = Pr[G1 <= t, G2 <= t] with Phi(t) = p.  So

    G_inf(p) = H(p) + 4|b| (Lambda_{-a}(p) - p^2),     Lambda_rho(p) - p^2 = int_0^rho exp(-t^2/(1+s)) / (2 pi sqrt(1-s^2)) ds,

is a limit of values sigma Gamma_nu(F).  If G_inf(p) < 0 for some p, the candidate has a certificate with large k.  The script
prints min G_inf next to min Phi# (Proposition 10.6), and checks that a exceeds the correlation lambda of the rows of the other
sign (so a is the largest correlation of a row, the parameter of the invariance principle for decoders with small influences).

usage: python3 m9_gauss_limit.py
"""
import sys
from fractions import Fraction as Fr

import numpy as np
from scipy import integrate, optimize
from scipy.stats import norm

sys.argv = sys.argv[:1] + ['7']
import maxcorr_J2 as M  # noqa: E402
from fsharp_check import sharp_pieces, params  # noqa: E402
from m9_k4_scan import CANDS  # noqa: E402


def lam_minus_p2(p, rho):
    t = norm.ppf(p)
    val, _ = integrate.quad(lambda s: np.exp(-t * t / (1 + s)) / (2 * np.pi * np.sqrt(1 - s * s)), 0, rho,
                            epsabs=1e-15, epsrel=1e-13)
    return val


def g_inf(p, A, B, a):
    A0, A1, A2 = A
    return A0 + A1 * p + A2 * p * p + B * lam_minus_p2(p, -a)


def phi_sharp_min(pieces):
    return min(M.quad_min(*pc) for pc in pieces)


if __name__ == '__main__':
    for spec in CANDS:
        hv = (Fr(spec[0]), Fr(spec[1]), Fr(spec[1]), Fr(spec[2]))
        mu, b, lam, qq = params(hv)
        a, q, r, th, A, pieces = sharp_pieces(hv)
        lam_other = max(lam.values())
        assert 0 <= lam_other < a
        Af = tuple(float(v) for v in A)
        B, af = float(4 * abs(b)), float(a)
        ps = np.linspace(1e-4, 1 - 1e-4, 2001)
        vals = np.array([g_inf(p, Af, B, af) for p in ps])
        i = int(np.argmin(vals))
        res = optimize.minimize_scalar(lambda p: g_inf(p, Af, B, af), bounds=(ps[max(i - 1, 0)], ps[min(i + 1, len(ps) - 1)]),
                                       method='bounded', options={'xatol': 1e-12})
        pmin, gmin = float(res.x), float(res.fun)
        hmin_p = -Af[1] / (2 * Af[2])
        print(f"h = {spec}: a = {float(a):.5f} (other sign: lambda = {float(lam_other):.5f}), q = {float(q):.5f}, "
              f"theta = {float(th):.5f}, min Phi# = {float(phi_sharp_min(pieces)):+.4e}, "
              f"min G_inf = {gmin:+.4e} at p = {pmin:.5f}; H min at p = {hmin_p:.4f}, H(q) - 4|b|a q(1-q) = "
              f"{float(A[0] + A[1] * q + A[2] * q * q - 4 * abs(b) * a * q * (1 - q)):+.4e}")
