"""Exploration (floating point): coupling LP with three-copy "triangle" constraints, one class of size two, eps = 1.

Level weights w_{ij} = sum of ||P_S||^2 over S with i rows of the dangerous sign and j rows of the other sign.
Objective: max sum -lambda_{ij} w_{ij}, lambda_{ij} = (-a)^i lambda'^j  (so that sigma Gamma >= phi(p) - 4|b| * LP).
Constraints (all valid for P : {+-1}^k -> [0,1] with mean p):
  two-point : -min(p,1-p)^2 <= sum t1^i t2^j w_ij <= p - p^2   for row couplings with correlations t1, t2;
  three-point: E[P_X P_Y] + p >= E[P_X P_W] + E[P_Y P_W]  for every coupling of three copies, i.e.
              sum (c12_1^i c12_2^j - c13_1^i c13_2^j - c23_1^i c23_2^j) w_ij >= p^2 - p,
  where (c12, c13, c23) ranges over pairwise-correlation triples of three copies of a biased bit (per row type).
usage: python3 coupling_lp3.py "x z y" p1 [p2 ...]
"""
import itertools
import sys
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import linprog

from fpp_test import params, sh

J = 8


def triples(q, n=9):
    """Feasible pairwise correlation triples of three {c, cbar} bits with P(c) = q (grid in the s_ij)."""
    out = set()
    ss = np.linspace(0, q, n)
    for s12, s13, s23 in itertools.product(ss, repeat=3):
        lo = max(0.0, s12 + s13 - q, s12 + s23 - q, s13 + s23 - q)
        hi = min(s12, s13, s23, 1 - 3 * q + s12 + s13 + s23)
        if lo <= hi + 1e-12:
            c = tuple(round((s - q * q) / (q * (1 - q)), 12) for s in (s12, s13, s23))
            out.add(c)
    return sorted(out)


def lp3(hv, ps, use3=True):
    mu, pi, b, lam, qq = params(hv)
    nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    a, lp_ = float(-lam[nus]), float(lam[-nus])
    q, qp = float(qq[nus]), float(qq[-nus])
    r, rp = q / (1 - q), qp / (1 - qp)
    idx = [(i, j) for i in range(J + 1) for j in range(J + 1) if (i, j) != (0, 0)]
    obj = np.array([(-a) ** i * lp_ ** j for i, j in idx])
    rows2 = [[t1 ** i * t2 ** j for i, j in idx]
             for t1 in np.linspace(-r, 1, 31) for t2 in np.linspace(-rp, 1, 13)]
    G2 = np.array(rows2)
    rows3 = []
    if use3:
        T1, T2 = triples(q), triples(qp, 5)
        for c1 in T1:
            for c2 in T2:
                for (x, y, z) in ((0, 1, 2), (1, 2, 0), (2, 0, 1)):
                    rows3.append([c1[x] ** i * c2[x] ** j - c1[y] ** i * c2[y] ** j - c1[z] ** i * c2[z] ** j for i, j in idx])
    G3 = np.array(rows3) if rows3 else np.zeros((0, len(idx)))
    res = []
    for p in ps:
        K = min(p * p, (1 - p) ** 2)
        A = [-G2, G2, np.ones((1, len(idx)))]
        bb = [np.full(len(G2), K), np.full(len(G2), p - p * p), [p - p * p]]
        if len(G3):
            A.append(-G3)
            bb.append(np.full(len(G3), p - p * p))
        sol = linprog(obj, A_ub=np.vstack(A), b_ub=np.concatenate(bb), bounds=(0, None), method='highs')
        V = -sol.fun
        res.append((p, V, float(sh(hv, Fr(p).limit_denominator(10 ** 9))) - 4 * abs(float(b)) * V))
    return res


if __name__ == '__main__':
    xs, zs, ys = sys.argv[1].split()
    hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
    ps = [float(x) for x in sys.argv[2:]]
    for use3 in (False, True):
        for p, V, val in lp3(hv, ps, use3):
            print(f"{'3pt' if use3 else '2pt'} p={p:.4f}: LP = {V:.6e}, bound on sigma Gamma = {val:+.4e}", flush=True)
