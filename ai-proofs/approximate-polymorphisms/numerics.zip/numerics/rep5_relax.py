"""rep5 with the cubic-free majorant h' = h + t1*1_{+++} + t2*1_{-+-}, t1 + t2 = 1, d = t1 - t2 (floating point).

For the representative of rep5 (pair class {1,2}, singleton class {3}),
  8h' = -2 + (d-1)(y1 + y1y2) + (1+d)(y3 + y2y3) - 2y1y3   (only the sum of the two level-one pair coefficients matters),
so with a = F_p, b = F_s and Y = (a(X1), a(X2), b(X3)),
  8E h'(Y) = -2 + (d-1)E a + (1+d)E b + (d-1)E[a1 a2] - 2E[a1 b3] + (1+d)E[a2 b3].
For d = -1 this is the inequality  E(2E[P(X1)|X3] - 1)_+ <= 2E[P(X1)P(X2)]  for P = (1+a)/2.
This script maximises E h'(Y) over decoders by alternating best responses (b is a sign pattern given a; exact coordinate
steps in a, whose objective is concave in each single value), from dictator, constant and random starts, for every nu up
to permutation.  Usage: python3 rep5_relax.py KMAX RESTARTS SEED [d]
"""
import sys
import itertools
import numpy as np

H2 = [-2, -1, -1, 0, 1, -2, 0, -1]
VERTS = list(itertools.product([1, -1], repeat=3))


def row_laws():
    h = np.array(H2, float) / 2
    mu = h.mean()
    return {b: (1 + b * h) / (8 * (1 + b * mu)) for b in (1, -1)}


def pair_law(pi, i, j):
    L = np.zeros((2, 2))
    for w, p in zip(VERTS, pi):
        L[(1 - w[i]) // 2, (1 - w[j]) // 2] += p
    return L


def joint(nu, laws, i, j):
    M = np.ones((1, 1))
    for b in nu:
        M = np.kron(M, pair_law(laws[b], i, j))
    return M


def objective(a, b, M12, M13, M23, m1, m3, d):
    Ea = m1 @ a
    Eb = m3 @ b
    return (-2 + (d - 1) * Ea + (1 + d) * Eb + (d - 1) * (a @ M12 @ a) - 2 * (a @ M13 @ b)
            + (1 + d) * (a @ M23 @ b)) / 8


def ascend(a, M12, M13, M23, m1, m3, d, iters=200):
    n = len(a)
    diag = np.diag(M12).copy()
    best = -np.inf
    for _ in range(iters):
        g = -2 * (a @ M13) + (1 + d) * (a @ M23) + (1 + d) * m3
        b = np.where(g > 0, 1.0, -1.0)
        lin = (d - 1) * m1 - 2 * (M13 @ b) + (1 + d) * (M23 @ b)
        for _sweep in range(3):
            for z in np.random.permutation(n):
                rest = (M12[z] @ a) - diag[z] * a[z]
                c1 = lin[z] + 2 * (d - 1) * rest
                c2 = (d - 1) * diag[z]
                if c2 < 0:
                    a[z] = np.clip(-c1 / (2 * c2), -1, 1)
                else:
                    a[z] = 1.0 if c1 + c2 > -c1 + c2 else -1.0
        val = objective(a, b, M12, M13, M23, m1, m3, d)
        if val <= best + 1e-13:
            break
        best = val
    return best, a, b


def main():
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    restarts = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    seed = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    d = float(sys.argv[4]) if len(sys.argv) > 4 else -1.0
    rng = np.random.default_rng(seed)
    np.random.seed(seed)
    laws = row_laws()
    print(f"rep5, cubic-free majorant with d = {d}")
    overall = -np.inf
    for k in range(1, kmax + 1):
        for npos in range(k + 1):
            nu = [1] * npos + [-1] * (k - npos)
            M12 = joint(nu, laws, 0, 1)
            M13 = joint(nu, laws, 0, 2)
            M23 = joint(nu, laws, 1, 2)
            m1 = M12.sum(1)
            m3 = M13.sum(0)
            pts = np.array(list(itertools.product([1, -1], repeat=k)), float)
            starts = [np.ones(2 ** k), -np.ones(2 ** k)]
            for r in range(k):
                starts += [pts[:, r].copy(), -pts[:, r].copy()]
            for r1, r2 in itertools.combinations(range(k), 2):
                starts += [np.where((pts[:, r1] > 0) & (pts[:, r2] > 0), 1.0, -1.0),
                           np.where((pts[:, r1] > 0) | (pts[:, r2] > 0), 1.0, -1.0)]
            for _ in range(restarts):
                starts.append(rng.uniform(-1, 1, 2 ** k))
                starts.append(np.where(rng.random(2 ** k) < rng.random(), 1.0, -1.0))
            best = -np.inf
            for a0 in starts:
                val, a, b = ascend(a0.copy(), M12, M13, M23, m1, m3, d)
                best = max(best, val)
            overall = max(overall, best)
            print(f"k={k} nu=+{npos}/-{k - npos}: max E h'(Y) found = {best:.3e}", flush=True)
    print(f"overall max = {overall:.3e}")


if __name__ == "__main__":
    main()
