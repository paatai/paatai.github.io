"""Continuous optimisation of label decoders at x = infinity.

Gamma_nu(F) = E_{C ~ pi_nu} h(F_{c(1)}(C_1), ..., F_{c(d)}(C_d)),
C a k x d matrix with independent rows, row i ~ pi_{nu_i} on {+-1}^d,
pi_b(a) = (1 + b h(a)) / (2^d (1 + b mu)); F_c : {+-1}^k -> [-1,1] one decoder per class.
h normalised so that mu < 0.  We maximise over F by projected gradient ascent from random starts.
usage: python3 q6_contlabels.py d r k [ncand] [nstarts]
"""
import itertools
import sys
import numpy as np

d, r, k = (int(a) for a in sys.argv[1:4])
ncand = int(sys.argv[4]) if len(sys.argv) > 4 else 10 ** 9
nstarts = int(sys.argv[5]) if len(sys.argv) > 5 else 40
rng = np.random.default_rng(1)
H = np.load(f'outputs/hard_h_d{d}_r{r}.npy')[:ncand]
P = np.array(list(itertools.product([1, -1], repeat=d)))
n = len(P)
L = np.array(list(itertools.product([1, -1], repeat=k)))  # label vectors
lid = {tuple(l): i for i, l in enumerate(L)}
SUBS = [S for t in range(d + 1) for S in itertools.combinations(range(d), t)]


def fourier(h):
    return {S: float(np.mean(h * np.prod(P[:, list(S)], axis=1))) for S in SUBS}


def setup(h, nu):
    mu = h.mean()
    pis = {b: (1 + b * h) / (n * (1 + b * mu)) for b in (1, -1)}
    Ws = list(itertools.product(range(n), repeat=k))
    wts = np.array([np.prod([pis[nu[i]][W[i]] for i in range(k)]) for W in Ws])
    keep = wts > 1e-15
    cols = np.array([[lid[tuple(int(P[W[i]][j]) for i in range(k))] for j in range(d)]
                     for W, kk in zip(Ws, keep) if kk])
    return wts[keep], cols


def value_and_grad(F, cls, hf, wts, cols):
    # Y[w, j] = F[cls[j], cols[w, j]]
    Y = F[cls][np.arange(d)[None, :].repeat(len(cols), 0) * 0 + np.array(cls)[None, :], cols] if False else \
        np.stack([F[cls[j], cols[:, j]] for j in range(d)], axis=1)
    val = np.zeros(len(cols))
    grads = np.zeros_like(Y)
    for S, c in hf.items():
        if c == 0:
            continue
        if not S:
            val += c
            continue
        prodS = np.prod(Y[:, list(S)], axis=1)
        val += c * prodS
        for j in S:
            rest = [t for t in S if t != j]
            grads[:, j] += c * (np.prod(Y[:, rest], axis=1) if rest else 1.0)
    v = wts @ val
    G = np.zeros_like(F)
    for j in range(d):
        np.add.at(G[cls[j]], cols[:, j], wts * grads[:, j])
    return v, G


def optimise(h):
    mu = h.mean()
    if mu > 0:
        h = -h
    hf = fourier(h)
    l1 = np.array([hf[(j,)] for j in range(d)])
    uniq = sorted(set(np.round(l1, 10)))
    cls = [uniq.index(v) for v in np.round(l1, 10)]
    R = len(uniq)
    best = (-np.inf, None, None)
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        wts, cols = setup(h, nu)
        for s in range(nstarts):
            F = rng.choice([-1.0, 1.0], size=(R, len(L))) if s % 2 else rng.uniform(-1, 1, size=(R, len(L)))
            lr = 0.5
            v_old = -np.inf
            for it in range(400):
                v, G = value_and_grad(F, cls, hf, wts, cols)
                F = np.clip(F + lr * G / (np.abs(G).max() + 1e-12), -1, 1)
                if it % 50 == 49:
                    lr *= 0.5
                v_old = v
            v, _ = value_and_grad(F, cls, hf, wts, cols)
            if v > best[0]:
                best = (v, tuple(nu), F.copy())
    return best


cnt = 0
for t, hv in enumerate(H):
    v, nu, F = optimise(hv)
    cnt += v > 1e-7
    print(t, 'best', round(v, 7), 'nu', nu, 'F', np.round(F, 3).tolist() if v > 1e-7 else '')
    sys.stdout.flush()
print(f'{cnt}/{len(H)} beaten with k={k} continuous decoders')
