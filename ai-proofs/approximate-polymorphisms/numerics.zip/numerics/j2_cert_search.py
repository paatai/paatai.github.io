"""Search for single-decoder certificates (Gamma > 0, mu < 0) for one-class candidates h = (x, z, z, y), and verify the best
Boolean decoders exactly.

For each k <= kmax and nu (up to permutation), runs coordinate ascent (exact quadratic maximisation in each value F(z))
from random Boolean and continuous starts and from the dictator; rounds the best local maximum to a Boolean decoder
when it is Boolean up to 1e-9, and recomputes Gamma in exact rational arithmetic.
usage: python3 j2_cert_search.py kmax restarts seed "x z y" ["x z y" ...]
"""
import itertools
import sys
from fractions import Fraction as Fr

import numpy as np

W2 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def hml(hv, y1, y2):
    x, z, _, y = hv
    return (x * (1 + y1) * (1 + y2) + z * (1 + y1) * (1 - y2) + z * (1 - y1) * (1 + y2) + y * (1 - y1) * (1 - y2)) / 4


def laws(hv):
    mu = sum(hv) / 4
    return {b: [(1 + b * hv[i]) / (4 * (1 + b * mu)) for i in range(4)] for b in (1, -1)}


def setup(pi, nu):
    k = len(nu)
    cols, probs = [], []
    for rows in itertools.product(range(4), repeat=k):
        p = 1.0
        for i in range(k):
            p *= float(pi[nu[i]][rows[i]])
        if p == 0:
            continue
        c = []
        for j in range(2):
            v = 0
            for i in range(k):
                v = 2 * v + (W2[rows[i]][j] == -1)
            c.append(v)
        cols.append(c)
        probs.append(p)
    return np.array(cols), np.array(probs)


def gamma_exact(hv, pi, nu, F):
    """F: sequence indexed by z encoded as sum_i 2^(k-1-i) [z_i = -1]; exact rationals."""
    k = len(nu)
    tot = Fr(0)
    for rows in itertools.product(range(4), repeat=k):
        p = Fr(1)
        for i in range(k):
            p *= pi[nu[i]][rows[i]]
        if p == 0:
            continue
        c = [0, 0]
        for j in range(2):
            for i in range(k):
                c[j] = 2 * c[j] + (W2[rows[i]][j] == -1)
        tot += p * hml(hv, Fr(F[c[0]]), Fr(F[c[1]]))
    return tot


def ascent(hf, F, cols, probs, rng, sweeps=300):
    nz = len(F)
    occ = [np.nonzero((cols == z).any(axis=1))[0] for z in range(nz)]
    ts = np.array([-1.0, 0.0, 1.0])
    V = np.vander(ts, 3)

    def gam(F):
        return probs @ hf(F[cols[:, 0]], F[cols[:, 1]])

    for _ in range(sweeps):
        changed = 0.0
        for z in rng.permutation(nz):
            idx = occ[z]
            if len(idx) == 0:
                continue
            vals = []
            for t in ts:
                old = F[z]
                F[z] = t
                vals.append(probs[idx] @ hf(F[cols[idx, 0]], F[cols[idx, 1]]))
                F[z] = old
            c2, c1, c0 = np.linalg.solve(V, np.array(vals))
            cands = [-1.0, 1.0]
            if c2 < 0:
                t0 = -c1 / (2 * c2)
                if -1 < t0 < 1:
                    cands.append(t0)
            best = max(cands, key=lambda t: c2 * t * t + c1 * t + c0)
            changed = max(changed, abs(best - F[z]))
            F[z] = best
        if changed < 1e-12:
            break
    return gam(F), F


def search(hv, kmax, restarts, rng, verbose=True):
    pi = laws(hv)
    hvf = [float(v) for v in hv]

    def hf(y1, y2):
        x, z, _, y = hvf
        return (x * (1 + y1) * (1 + y2) + z * (1 + y1) * (1 - y2) + z * (1 - y1) * (1 + y2) + y * (1 - y1) * (1 - y2)) / 4

    overall = None
    for k in range(1, kmax + 1):
        for npos in range(k, -1, -1):
            nu = tuple([1] * npos + [-1] * (k - npos))
            cols, probs = setup(pi, nu)
            best = (-np.inf, None)
            starts = []
            for c in range(k):
                for s in (1, -1):
                    starts.append(np.array([s * (1 - 2 * ((z >> (k - 1 - c)) & 1)) for z in range(2 ** k)], float))
            for _ in range(restarts):
                starts.append(rng.choice([-1.0, 1.0], size=2 ** k))
                starts.append(rng.uniform(-1, 1, size=2 ** k))
            for F0 in starts:
                g, F = ascent(hf, F0.copy(), cols, probs, rng)
                if g > best[0]:
                    best = (g, F.copy())
            g, F = best
            ex = None
            if np.all(np.abs(np.abs(F) - 1) < 1e-9):
                Fb = [int(round(v)) for v in F]
                ex = gamma_exact(hv, pi, nu, Fb)
            if verbose:
                tag = f"exact Boolean Gamma = {ex} ({float(ex):+.3e})" if ex is not None else "non-Boolean"
                print(f"  k={k} nu={''.join('+' if v > 0 else '-' for v in nu)}: best {g:+.4e}  [{tag}]", flush=True)
            if overall is None or g > overall[0]:
                overall = (g, k, nu, F.copy(), ex)
    return overall


if __name__ == '__main__':
    kmax = int(sys.argv[1])
    restarts = int(sys.argv[2])
    rng = np.random.default_rng(int(sys.argv[3]))
    for spec in sys.argv[4:]:
        xs, zs, ys = spec.split()
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        print(f"h = ({xs}, {zs}, {zs}, {ys}):", flush=True)
        g, k, nu, F, ex = search(hv, kmax, restarts, rng)
        Fs = [int(round(v)) if abs(abs(v) - 1) < 1e-9 else round(float(v), 4) for v in F]
        print(f"  overall best {g:+.4e} at k={k}, nu={nu}, F={Fs}, exact={ex}", flush=True)
