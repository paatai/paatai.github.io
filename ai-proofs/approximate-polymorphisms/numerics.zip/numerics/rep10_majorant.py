"""rep10: the largest admissible majorant h'' = h + 1_{++-} and its one-function form (T10) (Section 11, paragraph
"Exact forms for rep5 and rep10").

A majorant h' >= h (multilinear, on [-1,1]^3) gives E h(Y) <= E h'(Y), so E h'(Y) <= 0 for all decoders proves rep10 trivial.
For it to have a chance, h' = h on the support of pi_+ (dictator decoders, nu_r = +1, have Y ~ pi_+ and E h(Y) = 0). Exact checks
(Fractions):
 (a) pi_+ vanishes exactly at ++-, so these majorants are h + t 1_{++-}, t >= 0 (nonnegative at the vertices = nonnegative on
     [-1,1]^3), and t <= 1 is necessary: for t > 1 the constant decoders F_p = 1, F_s = -1 (k = 0) give E h'(Y) = t - 1 > 0;
 (b) h'' = h + 1_{++-} has the Fourier expansion 8h'' = -1 - y1y2 - y1y3 + y2y3 - 2y1y2y3 (no linear terms), and
     -8h'' = 4(1_{+++} + 1_{-+-} + 1_{--+} - 1_{-++}); so, for random [0,1]-valued P, B with k <= 3 and every nu,
     -2 E h''(Y) = E[Q1P2] + E[Q1B3] + E[P2B3] - 4E[Q1P2B3] with Q = 1 - P, F_p = 2P - 1, F_s = 2B - 1;
 (c) for random P with k <= 3 and every nu (up to the order of the labels), 4 max over all {-1,1}-valued F_s of
     E h''(F_p(X1), F_p(X2), F_s(X3)) = 2(L'' - R''), where F_p = 2P - 1,
         L'' = E(E[P1 + 3P2 - 4P1P2 - 1 | X3])_+,   R'' = E[P1(1 - P2)],
     and L'' - R'' >= L - R for the two sides of (rep10ex) (rep510_exact.sides);
 (d) k = 4: L'' <= R'' for every {0,1}-valued P and every nu, in exact integer arithmetic as in rep510_k4_boolean.py (all
     quantities are integers of modulus < 2^50 after scaling by D), with the list of equality cases and random cross-checks
     against the Fraction computation of (c).
usage: python3 rep10_majorant.py [ntest] [ncross] [seed]
"""
import random
import sys
from fractions import Fraction as Fr

import numpy as np

from rep510_exact import REPS, W3, brute_max, check, columns, cube, fourier, gamma, mlin, setup, sides
from rep510_k4_boolean import K, classify, tables


def sides_major(J, P):
    cond = {}
    for (z1, z2, z3), p in J.items():
        a, b = P[z1], P[z2]
        cond[z3] = cond.get(z3, 0) + p * (a + 3 * b - 4 * a * b - 1)
    lhs = sum(max(v, 0) for v in cond.values())
    rhs = sum(p * P[z1] * (1 - P[z2]) for (z1, z2, z3), p in J.items())
    return lhs, rhs


def all_sides_major(T):
    n = T.shape[0]
    P = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1).astype(np.float64)
    M12, M13, M23 = T.sum(2), T.sum(1), T.sum(0)
    m1, m3 = T.sum((1, 2)), T.sum((0, 1))
    A = (P @ T.reshape(n, n * n)).reshape(-1, n, n)
    C = np.einsum("pi,pij->pj", P, A)
    S = P @ M13 + 3 * (P @ M23) - 4 * C - m3
    rhs = P @ m1 - np.einsum("pi,pi->p", P @ M12, P)
    lhs = np.maximum(S, 0).sum(1)
    for arr in (lhs, rhs):
        assert np.all(arr == np.round(arr)) and np.abs(arr).max() < 2 ** 50
    return lhs, rhs


def main():
    ntest = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    ncross = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    rng = random.Random(int(sys.argv[3]) if len(sys.argv) > 3 else 1)
    h, mu, pi = setup(REPS["rep10"])
    zeros = [w for w in W3 if pi[1][w] == 0]
    check(zeros == [(1, 1, -1)], "rep10: pi_+ vanishes exactly at ++- (so the admissible majorants are h + t 1_{++-}, t >= 0)")
    check(h[(1, 1, -1)] == -1, "rep10: h(++-) = -1, so h + t 1_{++-} is positive at the constant decoder (1, 1, -1) iff t > 1")
    for t in (Fr(1), Fr(5, 4)):
        ht = {w: h[w] + (t if w == (1, 1, -1) else 0) for w in W3}
        print(f"   t = {t}: E h_t(Y) at the constant decoder F_p = 1, F_s = -1 (k = 0) is {mlin(ht, (1, 1, -1))}")
    h2 = {w: h[w] + (1 if w == (1, 1, -1) else 0) for w in W3}
    expected = {(0, 0, 0): Fr(-1, 8), (1, 0, 0): Fr(0), (0, 1, 0): Fr(0), (0, 0, 1): Fr(0), (1, 1, 0): Fr(-1, 8),
                (1, 0, 1): Fr(-1, 8), (0, 1, 1): Fr(1, 8), (1, 1, 1): Fr(-1, 4)}
    check(fourier(h2) == expected, "h'' = h + 1_{++-}: 8h'' = -1 - y1y2 - y1y3 + y2y3 - 2y1y2y3")
    print(f"   h'' at +++,++-,...,---: {[str(h2[w]) for w in W3]}")
    nbr = {(1, 1, 1): 1, (-1, 1, -1): 1, (-1, -1, 1): 1, (-1, 1, 1): -1}
    check(all(-8 * h2[w] == 4 * nbr.get(w, 0) for w in W3),
          "-8h'' = 4(1_{+++} + 1_{-+-} + 1_{--+} - 1_{-++}) (the vertex -++ against its three neighbours)")
    count = 0
    for k in range(0, 4):
        for npos in range(k + 1):
            nu = (1,) * npos + (-1,) * (k - npos)
            J = columns(pi, nu)
            for _ in range(ntest if k > 0 else 2):
                P = {z: Fr(rng.randint(0, 12), 12) for z in cube(k)}
                B = {z: Fr(rng.randint(0, 12), 12) for z in cube(k)}
                Fp, Fs = {z: 2 * P[z] - 1 for z in cube(k)}, {z: 2 * B[z] - 1 for z in cube(k)}
                E = lambda f: sum(p * f(z1, z2, z3) for (z1, z2, z3), p in J.items())
                rhs = E(lambda x, y, z: (1 - P[x]) * P[y]) + E(lambda x, y, z: (1 - P[x]) * B[z]) + E(lambda x, y, z: P[y] * B[z])
                lhs = 4 * E(lambda x, y, z: (1 - P[x]) * P[y] * B[z])
                assert -2 * gamma(h2, J, Fp, Fs) == rhs - lhs, (k, nu)
                count += 1
    check(True, f"-2 E h''(Y) = E[Q1P2] + E[Q1B3] + E[P2B3] - 4E[Q1P2B3] (Q = 1 - P, B = (1 + F_s)/2), {count} exact random "
                f"tests with [0,1]-valued P and B, k <= 3, all nu")
    count = 0
    for k in range(0, 4):
        for npos in range(k + 1):
            nu = (1,) * npos + (-1,) * (k - npos)
            J = columns(pi, nu)
            for _ in range(ntest if k > 0 else 2):
                P = {z: Fr(rng.randint(0, 12), 12) for z in cube(k)}
                if rng.random() < 0.3:
                    P = {z: Fr(rng.randint(0, 1)) for z in cube(k)}
                Fp = {z: 2 * P[z] - 1 for z in cube(k)}
                lhs, rhs = sides_major(J, P)
                assert 4 * brute_max(h2, J, Fp, k) == 2 * (lhs - rhs), (k, nu)
                l0, r0 = sides("rep10", J, P)
                assert lhs - rhs >= l0 - r0, (k, nu)
                count += 1
    check(True, f"4 max over all {{-1,1}}-valued F_s of E h''(Y) = 2(L'' - R'') and L'' - R'' >= L - R, {count} exact random "
                f"tests, k <= 3, all nu")
    worst = None
    for npos in range(K, -1, -1):
        nu = (1,) * npos + (-1,) * (K - npos)
        D, T, J, pts = tables(pi, nu)
        lhs, rhs = all_sides_major(T)
        diff = lhs - rhs
        mx = diff.max()
        n_eq = int((diff == 0).sum())
        second = diff[diff < 0].max()
        print(f"rep10 majorant nu=(+{npos},-{K - npos}): D = {D}; max (L'' - R'') = {Fr(int(mx), D)}; L'' = R'' for {n_eq} "
              f"of {len(diff)} P; largest negative value {float(second) / D:.6g}", flush=True)
        name = lambda q: "1" if q == 2 ** (2 ** K) - 1 else classify(q, pts)
        print(f"   equality cases: {', '.join(name(int(q)) for q in np.flatnonzero(diff == 0))}", flush=True)
        for _ in range(ncross):
            p = rng.randrange(2 ** (2 ** K))
            P = {z: Fr((p >> i) & 1) for i, z in enumerate(pts)}
            l, r = sides_major(J, P)
            assert l * D == int(lhs[p]) and r * D == int(rhs[p]), (nu, p)
        worst = Fr(int(mx), D) if worst is None else max(worst, Fr(int(mx), D))
    check(worst <= 0, f"rep10 majorant: L'' <= R'' for every {{0,1}}-valued P with k = 4 and every nu (max L'' - R'' = {worst}); "
                      f"{ncross} cross-checks per nu against the Fraction computation agree")


if __name__ == "__main__":
    main()
