"""Sanity check of the coupling bound of Proposition 10.6 on random decoders (floating point):
sigma Gamma_nu(F) >= sigma h(2p-1,2p-1) - 4|b| a min{p(1-p), theta p(1-p) + (1-theta) min(p,1-p)^2 / r}, p = (1 + E F(X))/2,
for the 22 m = 8 candidates left by Theorem F and Proposition 10.4 (including the four with certificates, where the bound
still holds)."""
import itertools
from fractions import Fraction as Fr

import numpy as np

from fpp_test import UNDEC, params, sh
from sharp_test import theta_lo

W2 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
rng = np.random.default_rng(5)


def setup(pi, nu):
    k = len(nu)
    cols, probs = [], []
    for rows in itertools.product(range(4), repeat=k):
        p = np.prod([float(pi[nu[i]][rows[i]]) for i in range(k)])
        c = []
        for j in range(2):
            v = 0
            for i in range(k):
                v = 2 * v + (W2[rows[i]][j] == -1)
            c.append(v)
        cols.append(c)
        probs.append(p)
    return np.array(cols), np.array(probs)


worst = np.inf
for xs, zs, ys in UNDEC:
    for mirror in (False, True):
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        if mirror:
            hv = hv[::-1]
        mu, pi, b, lam, qq = params(hv)
        nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
        a = float(-lam[nus]); q = float(qq[nus]); r = q / (1 - q)
        th = theta_lo(a, r)
        x, z, _, y = [float(v) for v in hv]
        hf = lambda s, t: (x * (1 + s) * (1 + t) + z * (1 + s) * (1 - t) + z * (1 - s) * (1 + t) + y * (1 - s) * (1 - t)) / 4
        for _ in range(300):
            k = int(rng.integers(1, 5))
            nu = tuple(int(v) for v in rng.choice([1, -1], size=k))
            cols, probs = setup(pi, nu)
            mode = rng.integers(3)
            F = rng.choice([-1.0, 1.0], size=2 ** k) if mode == 0 else rng.uniform(-1, 1, size=2 ** k)
            if mode == 2:
                F = np.sign(F) * np.abs(F) ** 0.2
            G = probs @ hf(F[cols[:, 0]], F[cols[:, 1]])
            p = (1 + probs @ F[cols[:, 0]]) / 2
            K = min(p, 1 - p) ** 2
            V = p * (1 - p)
            bound = -(x * p * p + 2 * z * p * (1 - p) + y * (1 - p) ** 2) - 4 * abs(float(b)) * a * min(V, th * V + (1 - th) * K / r)
            worst = min(worst, -G - bound)
print(f"min over random decoders of sigma Gamma - Phi#(p) = {worst:.3e} (must be >= 0)")
