"""Where does Theorem K (E|sum a_i chi_i| <= E|chi| = 2 tau for unit a) stop holding as q decreases below 3/8?

Exact counterexample family: a = (1, 1)/sqrt(2) gives E|L| = sqrt(2) (1 - q) 2 tau (checked here by enumeration), which exceeds 2 tau iff
q < 1 - 1/sqrt(2) = 0.29289...  This script also maximises E|L| / (2 tau) over unit vectors with n <= NMAX coordinates (exact
enumeration of the 2^n sign patterns, coordinate-ascent from random starts, floating point) on a grid of q, to locate the
threshold numerically.
usage: python3 khintchine_threshold.py
"""
import itertools
import math
import random

import numpy as np


def law(q):
    return math.sqrt((1 - q) / q), -math.sqrt(q / (1 - q))


def EabsL(q, a):
    u, mv = law(q)
    n = len(a)
    tot = 0.0
    for bits in itertools.product((0, 1), repeat=n):
        k = sum(bits)
        val = sum(ai * (u if b else mv) for ai, b in zip(a, bits))
        tot += q**k * (1 - q)**(n - k) * abs(val)
    return tot


def patterns(n):
    P = np.array(list(itertools.product((0, 1), repeat=n)), dtype=float)
    return P, P.sum(axis=1)


def ratio_fast(q, a, P, K):
    u, mv = law(q)
    X = P * u + (1 - P) * mv
    w = q**K * (1 - q)**(len(a) - K)
    a = np.asarray(a) / np.linalg.norm(a)
    return float(w @ np.abs(X @ a)) / (2 * math.sqrt(q * (1 - q)))


def maximise(q, n, rng, restarts=40, iters=300):
    P, K = patterns(n)
    best, besta = -1.0, None
    for r in range(restarts):
        a = np.array([rng.gauss(0, 1) for _ in range(n)])
        if r == 0:
            a = np.ones(n)
        a /= np.linalg.norm(a)
        f = ratio_fast(q, a, P, K)
        step = 0.3
        for _ in range(iters):
            improved = False
            for i in range(n):
                for sgn in (1, -1):
                    b = a.copy()
                    b[i] += sgn * step
                    nb = np.linalg.norm(b)
                    if nb == 0:
                        continue
                    b /= nb
                    fb = ratio_fast(q, b, P, K)
                    if fb > f + 1e-15:
                        a, f, improved = b, fb, True
            if not improved:
                step /= 2
                if step < 1e-7:
                    break
        if f > best:
            best, besta = f, a
    return best, besta


def main():
    for q in (0.25, 0.29, 0.3, 1 / 3, 0.36):
        tau = math.sqrt(q * (1 - q))
        e = EabsL(q, [1 / math.sqrt(2)] * 2)
        assert abs(e - math.sqrt(2) * (1 - q) * 2 * tau) < 1e-12
    print("check: a = (1,1)/sqrt2 gives E|L| = sqrt2 (1-q) 2 tau  (q = 0.25, 0.29, 0.3, 1/3, 0.36)")
    rng = random.Random(1)
    NMAX = 7
    print(f"max over unit a in R^n, n <= {NMAX}, of E|L| / (2 tau)  (1 = Theorem K tight at dictators)")
    for q in (0.28, 0.29, 0.2929, 0.295, 0.30, 0.31, 0.32, 0.33, 0.34, 0.35, 0.36, 0.37, 0.375):
        row = []
        for n in range(2, NMAX + 1):
            best, a = maximise(q, n, rng, restarts=12 if n > 5 else 25)
            row.append((best, a))
        b, a = max(row, key=lambda t: t[0])
        a = np.sort(np.abs(a))[::-1]
        print(f"q = {q:.4f}: max ratio {b:.7f}   (per n: " + ", ".join(f"{r[0]:.5f}" for r in row) + ")"
              f"   maximiser |a| = " + np.array2string(a[a > 1e-4], precision=4))


if __name__ == "__main__":
    main()
