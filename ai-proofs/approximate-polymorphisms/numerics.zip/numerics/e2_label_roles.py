"""Labelled constructions for E2 with two roles: Q_z = sgn if f(z) = 1 and Q_z = -sgn if f(z) = 0, for f : {-1,1}^k -> {0,1}.

Given g(W) = nu, the three columns of W receive roles; the number t of columns with role sgn determines the inputs up to order,
and (E2 symmetric, G_1, G_2, G_3 exchangeable given x)
    t = 2: gamma_q(x),  t = 1: gamma_q(-x),  t = 3: gamma_3(x),  t = 0: gamma_3(-x),
where q = (sgn, sgn, -sgn) and gamma_3 = gamma_(sgn,sgn,sgn).  So gamma_nu = sum_t w_{nu,t} gamma_t and (Lemma 2.3(a))
    val^lab(Q) - 5/8 = sum_nu Pr[nu] E_x gamma_nu(x)^+ ,
to be compared with J = E_x gamma_q^+ = val(q) - 5/8 and with the bound (1 - 4^-k) J' of Remark 4.4 (J' = s^U - 5/8 >= J).
Floating point (Owen's T, grid quadrature).  usage: python3 e2_label_roles.py [kmax=4]
"""
import itertools
import sys

import numpy as np
from scipy.special import owens_t
from scipy.stats import norm

BETA = np.sqrt(15 / 13)
ALPHA = np.sqrt(7 / 6)
C = -1 / 14


def Phi2_equal(h, r):
    """P[Y1 < h, Y2 < h] for standard normals with correlation r (Owen)."""
    return norm.cdf(h) - 2 * owens_t(h, np.sqrt((1 - r) / (1 + r)))


def gammas(xs):
    a = xs / np.sqrt(14)
    hh = np.linspace(-40, a.max(), 400001)
    integrand = 3 * norm.pdf(hh) * Phi2_equal(BETA * hh, C / (1 + C))
    cum = np.concatenate([[0], np.cumsum((integrand[1:] + integrand[:-1]) / 2 * np.diff(hh))])
    L = np.interp(a, hh, cum)
    P2 = Phi2_equal(a, C)
    g_q = 6 * L + 4 * norm.cdf(a) - 8 * P2 - 1
    g_3 = 6 * P2 - 6 * L - 1
    return g_q, g_3


XS = np.linspace(-12, 12, 24001)
DX = XS[1] - XS[0]
PHI = norm.pdf(XS) * DX
GQ, G3 = gammas(XS)
GAM_T = np.stack([G3[::-1], GQ[::-1], GQ, G3])           # t = 0, 1, 2, 3 (number of columns with role sgn)
J = float(np.sum(np.maximum(GQ, 0) * PHI))

ROWS = [r for r in itertools.product((1, -1), repeat=3)]
E2 = {r: (1 if sum(1 for v in r if v == 1) == 2 else -1) for r in ROWS}


def structure(k):
    """For every W in {-1,1}^{k x 3}: index of nu, column indices, and Pr[W | nu]."""
    Ws = list(itertools.product(range(8), repeat=k))
    nu_idx = np.zeros(len(Ws), dtype=np.int64)
    cols = np.zeros((len(Ws), 3), dtype=np.int64)
    pr = np.zeros(len(Ws))
    for n, w in enumerate(Ws):
        rows = [ROWS[i] for i in w]
        nu = [E2[r] for r in rows]
        nu_idx[n] = sum((1 if v == 1 else 0) << i for i, v in enumerate(nu))
        for j in range(3):
            cols[n, j] = sum((1 if rows[i][j] == 1 else 0) << i for i in range(k))
        pr[n] = np.prod([1 / 3 if v == 1 else 1 / 5 for v in nu])
    pnu = np.array([np.prod([3 / 8 if (m >> i) & 1 else 5 / 8 for i in range(k)]) for m in range(2 ** k)])
    return nu_idx, cols, pr, pnu


def value(f, st, k, split=False):
    nu_idx, cols, pr, pnu = st
    t = f[cols].sum(axis=1)
    w = np.zeros((2 ** k, 4))
    np.add.at(w, (nu_idx, t), pr)
    gam = w @ GAM_T                                          # (2^k, grid)
    contrib = pnu * (np.maximum(gam, 0) @ PHI)
    if split:
        pure = w.max(axis=1) > 1 - 1e-12
        return float(contrib.sum()), w, float(contrib[~pure].sum())
    return float(contrib.sum()), w


def main():
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    print(f"J = E gamma_q^+ = {J:.10e}  (grid quadrature; rigorous value 3.1663998209e-04)")
    print(f"check E gamma_q = {np.sum(GQ * PHI):.8f}, E gamma_3 = {np.sum(G3 * PHI):.8f} (both -1/4); "
          f"max gamma_3 = {G3.max():.6f} (< 2*0.49788-1 = {2 * 0.49788 - 1:.5f})")
    for k in range(1, kmax + 1):
        st = structure(k)
        best, bestf, worst_impure = -1, None, 0.0
        n = 2 ** k
        for bits in range(2 ** (n - 1)):                     # f and 1-f give the same value (x -> -x)
            f = np.array([(bits >> i) & 1 for i in range(n)])
            v, _, imp = value(f, st, k, split=True)
            worst_impure = max(worst_impure, imp)
            if v > best + 1e-15:
                best, bestf = v, f
        _, w = value(bestf, st, k)
        print(f"k = {k}: best two-role value - 5/8 = {best:.6e} = {best / J:.4f} J  (bound (1-4^-k) = {1 - 4.0 ** -k:.4f}); "
              f"f = {''.join(map(str, bestf))}; largest contribution of nu with undetermined role pattern, over all f: "
              f"{worst_impure:.2e}")
        if k <= 2:
            for m in range(n):
                print(f"    nu = {m:0{k}b}: weights of t = 0..3: " + ", ".join(f"{x:.4f}" for x in w[m] / max(w[m].sum(), 1e-300)))


if __name__ == "__main__":
    main()
