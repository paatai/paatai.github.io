"""Theorem K for every q in [3/8, 1/2]: exact verification of the two q-dependent steps of the proof (Section 9.4).

The proof of Theorem K is uniform in q in [1/3, 1/2] except for two numerical inputs:
  Case A (a <= a_A):  sqrt(2/pi) + a_A C(q) <= 2 tau,  C(q) = (q^2 + (1-q)^2)/(2 tau) = (1 - 2 tau^2)/(2 tau),  tau = sqrt(q(1-q));
  Case C (a_A < a < a_B):  p_q(s) <= 0 for s in [s(a_A), s(a_B)],  s(a) = a/sqrt(1-a^2),  a_B = kappa/(1-kappa) = (1-q)/(5q-1),
       p_q(s) = 2 theta s^3 + (theta^2 + 2 kappa' - 1) s^2 + 2 theta kappa' s + kappa'^2,  theta = 1-2q, kappa' = q/(4(1-q)).
Case B (a >= a_B) needs only q in [1/3, 1/2].  Multiplying p_q by 16(1-q)^2 > 0 gives the polynomial
       P(q,s) = 32(1-q)^2(1-2q) s^3 + 8q(1-q)(1 - 8(1-q)^2) s^2 + 8q(1-q)(1-2q) s + q^2 .
The script covers [3/8, 1/2] by intervals [q0, q1].  On each it takes a rational tau_lo <= sqrt(q0(1-q0)) and the largest
a_A on a grid of step 1/10^4 with sqrt(2/pi) + a_A C(tau_lo) <= 2 tau_lo (using sqrt(2/pi) < 79789/10^5, from pi > 3.14159);
as tau is increasing and C decreasing in tau on (0, 1/2], Case A then holds for all q in [q0, q1].  If a_A >= a_B(q0), Case C
is empty on [q0, q1] (a_B is decreasing in q).  Otherwise it takes rational s_lo <= s(a_A), s_hi >= s(a_B(q0)) and proves
P < 0 on [q0, q1] x [s_lo, s_hi] by bisection with a termwise interval upper bound (on [3/8, 1/2]: the s^3 and s terms are
nonnegative, the s^2 term is negative since 8(1-q)^2 >= 2, and each factor is monotone in q).  Exact rational arithmetic.
usage: python3 khintchine_interval.py [number of q-intervals, default 64]
"""
import sys
from fractions import Fraction as Fr
from math import isqrt

SQRT_2_PI_UP = Fr(79789, 10**5)
assert SQRT_2_PI_UP**2 * Fr(314159, 10**5) > 2                      # sqrt(2/pi) < 79789/10^5 since pi > 3.14159


def sqrt_lo(x, den=10**9):
    return Fr(isqrt(x.numerator * den * den // x.denominator), den)


def sqrt_hi(x, den=10**9):
    r = sqrt_lo(x, den)
    while r * r < x:
        r += Fr(1, den)
    return r


def a_B(q):
    return (1 - q) / (5 * q - 1)


def P_upper(q0, q1, s0, s1):
    t3 = 32 * (1 - q0)**2 * (1 - 2 * q0) * s1**3
    t2 = -8 * q0 * (1 - q0) * (8 * (1 - q1)**2 - 1) * s0**2
    t1 = 8 * q1 * (1 - q1) * (1 - 2 * q0) * s1
    return t3 + t2 + t1 + q1**2


def P_exact(q, s):
    return 32 * (1 - q)**2 * (1 - 2 * q) * s**3 + 8 * q * (1 - q) * (1 - 8 * (1 - q)**2) * s**2 \
        + 8 * q * (1 - q) * (1 - 2 * q) * s + q**2


def prove_negative(q0, q1, s0, s1, depth=0, stats=None):
    if P_upper(q0, q1, s0, s1) < 0:
        stats['boxes'] += 1
        stats['depth'] = max(stats['depth'], depth)
        return
    assert depth < 40, (q0, q1, s0, s1)
    assert P_exact(q0, s0) < 0 and P_exact(q1, s1) < 0, ("P >= 0 at a corner", q0, q1, s0, s1)
    if (s1 - s0) * 4 > (q1 - q0) * 16:
        sm = (s0 + s1) / 2
        prove_negative(q0, q1, s0, sm, depth + 1, stats)
        prove_negative(q0, q1, sm, s1, depth + 1, stats)
    else:
        qm = (q0 + q1) / 2
        prove_negative(q0, qm, s0, s1, depth + 1, stats)
        prove_negative(qm, q1, s0, s1, depth + 1, stats)


def main():
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 64
    lo, hi = Fr(3, 8), Fr(1, 2)
    for qq in (Fr(3, 8), Fr(2, 5), Fr(5, 12)):
        p = {Fr(3, 8): [200, -255, 30, 9], Fr(2, 5): [360, -564, 60, 25], Fr(5, 12): [2352, -4340, 420, 225]}[qq]
        ratio = None
        for s in (Fr(0), Fr(1, 3), Fr(1), Fr(2), Fr(7, 5)):
            val = sum(c * s**(3 - i) for i, c in enumerate(p))
            r = P_exact(qq, s) / val
            ratio = r if ratio is None else ratio
            assert r == ratio                                         # P(q, .) is a positive multiple of the table's p_q
        assert ratio > 0
    stats = {'boxes': 0, 'depth': 0}
    rows = []
    emptyC = 0
    for i in range(N):
        q0, q1 = lo + (hi - lo) * i / N, lo + (hi - lo) * (i + 1) / N
        tau_lo = sqrt_lo(q0 * (1 - q0))
        C_up = (1 - 2 * tau_lo**2) / (2 * tau_lo)
        aA = Fr(int((2 * tau_lo - SQRT_2_PI_UP) / C_up * 10**4), 10**4)
        assert SQRT_2_PI_UP + aA * C_up <= 2 * tau_lo and 0 < aA < 1
        aB = a_B(q0)
        assert aB <= 1                                                # Case B needs q >= 1/3
        if aA >= aB:
            emptyC += 1
            rows.append((q0, q1, aA, aB, None))
            continue
        s_lo = sqrt_lo(aA**2 / (1 - aA**2))
        s_hi = sqrt_hi(aB**2 / (1 - aB**2)) if aB < 1 else None
        assert s_hi is not None
        before = stats['boxes']
        prove_negative(q0, q1, s_lo, s_hi, 0, stats)
        rows.append((q0, q1, aA, aB, stats['boxes'] - before))
    for q0, q1, aA, aB, nb in rows[:3] + rows[-3:]:
        print(f"q in [{q0}, {q1}]: a_A = {aA}, a_B(q0) = {float(aB):.4f}, "
              + ("Case C empty" if nb is None else f"P < 0 on Case C range ({nb} boxes)"))
    print(f"{N} intervals cover [3/8, 1/2]; Case C empty on {emptyC} of them; {stats['boxes']} boxes in total, "
          f"maximal bisection depth {stats['depth']}")
    print("Theorem K holds for every q in [3/8, 1/2]  [EXACT]")


if __name__ == "__main__":
    main()
