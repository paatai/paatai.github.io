"""Prototype (floating point): cell-based LP for the separable majorant (rigorous version: e2_upper_rig.py).

Knots u_0 < ... < u_N in [-1,1].  On a cell B = product of [u_a,u_{a+1}], psi is affine in each coordinate and
E2 is multilinear, so sum psi(m_j) - E2(m) attains its minimum on B at a vertex.  Hence
    sum_j psi(v_j) >= E2(v) + Corr_up(B)  for all vertices v of B
implies sum psi >= Gamma_H on B, where Corr_up(B) >= sup_B (first + second + triple correction).
"""
import sys
import numpy as np
from scipy.special import ndtr, ndtri
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack
from e2_upper_herm import gram_max, C, K3

R2 = np.sqrt(2.0)


def e2m(m1, m2, m3):
    return -0.25 + (m1 + m2 + m3) / 4 - (m1 * m2 + m1 * m3 + m2 * m3) / 4 - 0.75 * m1 * m2 * m3


def knot_data(z):
    """z: increasing array of finite knots in z-space (u = 2 Phi(z) - 1); adds u = -1, 1."""
    u = np.concatenate([[-1.0], 2 * ndtr(z) - 1, [1.0]])
    ell = np.concatenate([[0.0], 2 * np.exp(-z * z / 2) / np.sqrt(2 * np.pi), [0.0]])
    sig = np.sqrt(np.maximum(1 - u * u, 0))
    return u, ell, sig


def cell_intervals(u, ell, sig):
    """per cell a: [u_a,u_{a+1}], ell range, sigma max, kappa range."""
    ulo, uhi = u[:-1], u[1:]
    # ell and sigma are unimodal with max at u=0 (a knot): range from endpoints
    elo = np.minimum(ell[:-1], ell[1:])
    ehi = np.maximum(ell[:-1], ell[1:])
    shi = np.maximum(sig[:-1], sig[1:])
    klo, khi = (1 + 3 * ulo) / 4, (1 + 3 * uhi) / 4
    return ulo, uhi, elo, ehi, shi, klo, khi


def prod_int(klo, khi, e1lo, e1hi, e2lo, e2hi):
    """interval of kappa * l1 * l2 with l1, l2 >= 0."""
    plo, phi_ = e1lo * e2lo, e1hi * e2hi
    lo = np.where(klo >= 0, klo * plo, klo * phi_)
    hi = np.where(khi >= 0, khi * phi_, khi * plo)
    return lo, hi


def corr_up(ia, ib, ic, CI, k3=K3):
    ulo, uhi, elo, ehi, shi, klo, khi = CI
    a, b, c = ia, ib, ic
    w12 = prod_int(klo[c], khi[c], elo[a], ehi[a], elo[b], ehi[b])
    w13 = prod_int(klo[b], khi[b], elo[a], ehi[a], elo[c], ehi[c])
    w23 = prod_int(klo[a], khi[a], elo[b], ehi[b], elo[c], ehi[c])
    best = np.full(len(a), -np.inf)
    for s1 in (0, 1):
        for s2 in (0, 1):
            for s3 in (0, 1):
                best = np.maximum(best, gram_max(w12[s1], w13[s2], w23[s3]))
    first = C * best
    ka = np.maximum(np.abs(klo), np.abs(khi))
    second = C * C * (ka[c] * shi[a] * shi[b] + ka[b] * shi[a] * shi[c] + ka[a] * shi[b] * shi[c])
    trip = 0.75 * (R2 * C * C * (ehi[a] * ehi[b] * shi[c] + ehi[a] * ehi[c] * shi[b] + ehi[b] * ehi[c] * shi[a])
                   + k3 * C ** 3 * shi[a] * shi[b] * shi[c])
    return first + second + trip


def build_constraints(u, ell, sig, k3=K3, chunk=400000):
    N = len(u) - 1
    CI = cell_intervals(u, ell, sig)
    rhs = {}
    A, B, Cc = np.meshgrid(np.arange(N), np.arange(N), np.arange(N), indexing="ij")
    sel = (A <= B) & (B <= Cc)
    A, B, Cc = A[sel], B[sel], Cc[sel]
    verts_all, vals_all = [], []
    for s in range(0, len(A), chunk):
        a, b, c = A[s:s + chunk], B[s:s + chunk], Cc[s:s + chunk]
        cu = corr_up(a, b, c, CI, k3)
        vmax = np.full(len(a), -np.inf)
        vs = []
        for d1 in (0, 1):
            for d2 in (0, 1):
                for d3 in (0, 1):
                    i, j, k = a + d1, b + d2, c + d3
                    e = e2m(u[i], u[j], u[k])
                    vmax = np.maximum(vmax, e)
                    vs.append((i, j, k, e))
        act = vmax + cu > -1e-9
        for (i, j, k, e) in vs:
            ii, jj, kk = i[act], j[act], k[act]
            srt = np.sort(np.stack([ii, jj, kk], 1), 1)
            verts_all.append(srt)
            vals_all.append(e[act] + cu[act])
    V = np.concatenate(verts_all)
    R = np.concatenate(vals_all)
    key = (V[:, 0] * (N + 1) + V[:, 1]) * (N + 1) + V[:, 2]
    order = np.lexsort((-R, key))
    key, R, V = key[order], R[order], V[order]
    first = np.concatenate([[True], key[1:] != key[:-1]])
    return V[first], R[first]


def weights_u(u, nx=400001, X=13.0):
    """w_i = E[hat_i(U)], U = 2 Phi(X/sqrt14)-1, for nonuniform knots u (float quadrature)."""
    x = np.linspace(-X, X, nx)
    dens = np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
    uu = 2 * ndtr(x / np.sqrt(14)) - 1
    dx = x[1] - x[0]
    idx = np.clip(np.searchsorted(u, uu, side="right") - 1, 0, len(u) - 2)
    frac = (uu - u[idx]) / (u[idx + 1] - u[idx])
    w = np.zeros(len(u))
    np.add.at(w, idx, (1 - frac) * dens * dx)
    np.add.at(w, idx + 1, frac * dens * dx)
    return w


def solve_lp(u, V, R):
    N = len(u) - 1
    nc = len(R)
    rows = np.repeat(np.arange(nc), 3)
    A = coo_matrix((-np.ones(3 * nc), (rows, V.ravel())), shape=(nc, N + 1)).tocsr()
    # convexity for nonuniform knots: slope_{a} <= slope_{a+1}
    h = np.diff(u)
    r2 = np.repeat(np.arange(N - 1), 3)
    c2 = np.stack([np.arange(N - 1), np.arange(1, N), np.arange(2, N + 1)], 1).ravel()
    v2 = np.stack([-1 / h[:-1], 1 / h[:-1] + 1 / h[1:], -1 / h[1:]], 1).ravel()
    Bc = coo_matrix((v2, (r2, c2)), shape=(N - 1, N + 1)).tocsr()
    w = 3 * weights_u(u)
    res = linprog(w, A_ub=vstack([A, Bc]).tocsr(), b_ub=np.concatenate([-R, np.zeros(N - 1)]),
                  bounds=[(0, None)] * (N + 1), method="highs")
    return res


def make_z_knots(n_core, zmax=6.0):
    """knots in z (u = 2Phi(z)-1) roughly uniform in u on [-1,1] plus a few tail knots; includes z=0."""
    ut = np.linspace(-1, 1, n_core + 1)[1:-1]
    z = ndtri((1 + ut) / 2)
    z = np.round(z, 8)
    z = np.unique(np.concatenate([z, [0.0]]))
    return z[np.abs(z) <= zmax]


if __name__ == "__main__":
    n = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    z = make_z_knots(n)
    u, ell, sig = knot_data(z)
    V, R = build_constraints(u, ell, sig)
    res = solve_lp(u, V, R)
    print(f"N={len(u) - 1} knots, constraints={len(R)}, status={res.status}, "
          f"bound E gamma^+ <= {res.fun:.6e}, s^U <= {0.625 + res.fun:.6f}")
    np.save(f"/tmp/psi_cells_{n}.npy", np.stack([u, res.x]))
