"""Exact checks for the two nontrivial m = 8 candidates with |J| = 2 found after Proposition 10.6.

For h1 = (-9/32, 1/8, 1/8, -3/32) and h2 = (-5/32, 1/16, 1/16, -1/32) (order ++, +-, -+, --):
  1. builds g : {-1,1}^8 -> {-1,1} (inputs w1, w2, u1..u6) with E_u g(w, u) = h(w): g(w, u) = 1 iff u in A_w, where
     A_{+-} = A_{-+} is a union of antipodal pairs {u, -u}, A_{++} = {v} + pairs, A_{--} = {-v} + pairs, v = (1,...,1);
  2. checks: hat g({u_i}) = 0 for all i, hat g({w_1}) = hat g({w_2}) != 0 (J = {1,2}, one class), E g != 0, g depends on
     all 8 coordinates, g != +-parity, and that E_u g(w,u) = h(w);
  3. computes the row laws pi_nu (law of w given g = nu) directly from g;
  4. evaluates the certificates exactly: Gamma_nu(F) = E h(F(C_1), F(C_2)) > 0 (sigma = -1), with
     h1: k = 3, nu = (+,+,+), F = (-41937/121670, -1, 1, -1, 1, -1, 1, -1) and the Boolean k = 4 decoder;
     h2: k = 2, nu = (+,+), F = (-554/1215, -1, 1, -1);
  5. re-derives the exact maxima over continuous decoders with k <= 2 (j2_k2_exact.cube_max): negative for h1.
"""
import itertools
from fractions import Fraction as Fr

from j2_k2_exact import cube_max, quad_form

W2 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
U6 = list(itertools.product([1, -1], repeat=6))


def build_g(hv):
    v = (1,) * 6
    pairs = [u for u in U6 if u[0] == 1 and u != v]
    neg = lambda u: tuple(-c for c in u)
    A = {}
    for w, hw in zip(W2, hv):
        N = 32 * (1 + hw)
        assert N.denominator == 1
        N = int(N)
        if w in ((1, -1), (-1, 1)):
            assert N % 2 == 0
            S = set()
            for u in pairs[:N // 2]:
                S |= {u, neg(u)}
        else:
            assert N % 2 == 1
            S = {v} if w == (1, 1) else {neg(v)}
            for u in pairs[:(N - 1) // 2]:
                S |= {u, neg(u)}
        assert len(S) == N
        A[w] = S
    return lambda x: 1 if tuple(x[2:]) in A[tuple(x[:2])] else -1


def fourier(g, S):
    tot = 0
    for x in itertools.product([1, -1], repeat=8):
        t = g(x)
        for i in S:
            t *= x[i]
        tot += t
    return Fr(tot, 256)


def check_g(g, hv):
    for w, hw in zip(W2, hv):
        assert Fr(sum(g(w + u) for u in U6), 64) == hw
    lin = [fourier(g, [i]) for i in range(8)]
    assert lin[2:] == [0] * 6 and lin[0] == lin[1] != 0
    mu = fourier(g, [])
    assert mu != 0
    for i in range(8):
        assert any(g(x) != g(x[:i] + (-x[i],) + x[i + 1:]) for x in itertools.product([1, -1], repeat=8))
    par = fourier(g, list(range(8)))
    assert abs(par) != 1
    return mu, lin[0]


def laws_from_g(g):
    pi = {}
    for nu in (1, -1):
        cnt = [sum(1 for u in U6 if g(w + u) == nu) for w in W2]
        tot = sum(cnt)
        pi[nu] = [Fr(c, tot) for c in cnt]
    return pi


def hml(hv, y1, y2):
    x, z, _, y = hv
    return (x * (1 + y1) * (1 + y2) + z * (1 + y1) * (1 - y2) + z * (1 - y1) * (1 + y2) + y * (1 - y1) * (1 - y2)) / 4


def gamma(hv, pi, nu, F):
    k = len(nu)
    tot = Fr(0)
    for rows in itertools.product(range(4), repeat=k):
        p = Fr(1)
        for i in range(k):
            p *= pi[nu[i]][rows[i]]
        c = [0, 0]
        for j in range(2):
            for i in range(k):
                c[j] = 2 * c[j] + (W2[rows[i]][j] == -1)
        tot += p * hml(hv, F[c[0]], F[c[1]])
    return tot


CASES = [
    ((Fr(-9, 32), Fr(1, 8), Fr(1, 8), Fr(-3, 32)),
     [((1, 1, 1), [Fr(-41937, 121670), -1, 1, -1, 1, -1, 1, -1]),
      ((1, 1, 1, 1), [1, 1, -1, -1, 1, 1, -1, -1, 1, 1, -1, -1, 1, -1, -1, -1])]),
    ((Fr(-5, 32), Fr(1, 16), Fr(1, 16), Fr(-1, 32)),
     [((1, 1), [Fr(-554, 1215), -1, 1, -1])]),
]

if __name__ == '__main__':
    for hv, certs in CASES:
        g = build_g(hv)
        mu, c1 = check_g(g, hv)
        pi = laws_from_g(g)
        mu4 = sum(hv) / 4
        assert pi == {b: [(1 + b * hv[i]) / (4 * (1 + b * mu4)) for i in range(4)] for b in (1, -1)}
        print(f"h = {tuple(str(v) for v in hv)}: g on 8 variables with E g = {mu}, hat g(1) = hat g(2) = {c1}, "
              f"hat g(u_i) = 0, depends on all coordinates; pi_+ = {[str(v) for v in pi[1]]}, pi_- = {[str(v) for v in pi[-1]]}")
        for nu, F in certs:
            G = gamma(hv, pi, nu, [Fr(v) for v in F])
            assert G > 0
            print(f"  certificate k = {len(nu)}, nu = {nu}: Gamma = {G} = {float(G):.6e} > 0 (sigma = -1)")
        best = None
        for k in (1, 2):
            for npos in range(k, -1, -1):
                nu = tuple([1] * npos + [-1] * (k - npos))
                val, F = cube_max(*quad_form(hv, nu))
                best = val if best is None else max(best, val)
        print(f"  max over continuous decoders with k <= 2: {best} = {float(best):.6e}")
