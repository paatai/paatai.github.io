"""Exploration: pointwise bound on gamma via Hermite expansion + level-one inequality + Gram constraint,
then the separable convex majorant LP (as in e2_upper_maj.py).

gamma = E2(m) - sum_{i<j} kappa_k C_ij - (3/4) T,  kappa_k = (1 + 3 m_k)/4,
C_ij = c <a_i, a_j> + R_ij,  |R_ij| <= c^2 s_i s_j,   |a_i| <= l_i = 2 phi(Phi^-1((1+m_i)/2)),
|T| <= sqrt2 c^2 (l1 l2 s3 + l1 l3 s2 + l2 l3 s1) + K3 |c|^3 s1 s2 s3.
"""
import sys
import numpy as np
from scipy.special import ndtr, ndtri
from e2_upper_maj import phi_weights, p2max_borell
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack

C = 1 / 14
K3 = 5.15

def gram_max(w12, w13, w23):
    """max of w12<u1,u2> + w13<u1,u3> + w23<u2,u3> over unit vectors (= over the 3x3 elliptope).
    Not frustrated (w12 w13 w23 >= 0): sum |w|.  Frustrated: with a,b,d = |w|, if
    al=sqrt(ab/d), be=sqrt(ad/b), ga=sqrt(bd/a) satisfy the triangle inequality the max is
    (ab/d+ad/b+bd/a)/2 (|al u1+be u2+ga u3|^2>=0, equality when the vectors close up), else a+b+d-2 min."""
    w12, w13, w23 = np.broadcast_arrays(*(np.asarray(t, float) for t in (w12, w13, w23)))
    a, b, d = np.abs(w12), np.abs(w13), np.abs(w23)
    tot = a + b + d
    frus = (w12 * w13 * w23) < 0
    with np.errstate(divide="ignore", invalid="ignore"):
        al, be, ga = np.sqrt(a * b / d), np.sqrt(a * d / b), np.sqrt(b * d / a)
        tri = (al <= be + ga) & (be <= al + ga) & (ga <= al + be)
        psd = (a * b / d + a * d / b + b * d / a) / 2
    rank1 = tot - 2 * np.minimum(np.minimum(a, b), d)
    out = np.where(frus, np.where(tri, psd, rank1), tot)
    return np.where(np.isfinite(out), out, tot)


def ell(m):
    mu = np.clip((1 + m) / 2, 1e-300, 1)
    z = ndtri(mu)
    return np.where((mu <= 0) | (mu >= 1), 0.0, 2 * np.exp(-z * z / 2) / np.sqrt(2 * np.pi))


def e2_multilinear(m1, m2, m3):
    return -0.25 + (m1 + m2 + m3) / 4 - (m1 * m2 + m1 * m3 + m2 * m3) / 4 - 0.75 * m1 * m2 * m3


def gamma_bound(m1, m2, m3, k3=K3):
    l1, l2, l3 = ell(m1), ell(m2), ell(m3)
    s1, s2, s3 = [np.sqrt(np.maximum(1 - m * m, 0)) for m in (m1, m2, m3)]
    k1, k2, kk3 = (1 + 3 * m1) / 4, (1 + 3 * m2) / 4, (1 + 3 * m3) / 4
    first = C * gram_max(kk3 * l1 * l2, k2 * l1 * l3, k1 * l2 * l3)
    second = C * C * (abs(kk3) * s1 * s2 + abs(k2) * s1 * s3 + abs(k1) * s2 * s3)
    trip = 0.75 * (np.sqrt(2) * C * C * (l1 * l2 * s3 + l1 * l3 * s2 + l2 * l3 * s1) + k3 * C ** 3 * s1 * s2 * s3)
    return np.minimum(e2_multilinear(m1, m2, m3) + first + second + trip, 1.0)


def solve_grid(G, knots, label):
    N = len(knots) - 1
    I1, I2, I3 = np.nonzero(G > 0)
    sel = (I1 <= I2) & (I2 <= I3)
    I1, I2, I3 = I1[sel], I2[sel], I3[sel]
    rhs = G[I1, I2, I3]
    nc = len(rhs)
    rows = np.repeat(np.arange(nc), 3)
    cols = np.stack([I1, I2, I3], 1).ravel()
    A = coo_matrix((-np.ones(3 * nc), (rows, cols)), shape=(nc, N + 1)).tocsr()
    r2 = np.repeat(np.arange(N - 1), 3)
    c2 = np.stack([np.arange(N - 1), np.arange(1, N), np.arange(2, N + 1)], 1).ravel()
    Bc = coo_matrix((np.tile([-1.0, 2.0, -1.0], N - 1), (r2, c2)), shape=(N - 1, N + 1)).tocsr()
    w = 3 * phi_weights(knots)
    res = linprog(w, A_ub=vstack([A, Bc]).tocsr(), b_ub=np.concatenate([-rhs, np.zeros(N - 1)]),
                  bounds=[(0, None)] * (N + 1), method="highs")
    print(f"{label}: N={N}, constraints={nc}, bound E gamma^+ <= {res.fun:.6e}, s^U <= {0.625 + res.fun:.6f}")
    return res.x, res.fun


if __name__ == "__main__":
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 60
    knots = np.linspace(-1, 1, N + 1)
    g1, g2, g3 = np.meshgrid(knots, knots, knots, indexing="ij")
    x = np.linspace(0, 14, 200001)
    dens = np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
    u = 2 * ndtr(x / np.sqrt(14)) - 1
    Gc = np.maximum(gamma_bound(u, u, -u), 0)
    print(f"Hermite: curve value x>0: {np.trapezoid(Gc * dens, x):.6e}")
    GH = gamma_bound(g1, g2, g3)
    GB = -1 + 2 * p2max_borell(g1, g2, g3)
    solve_grid(GH, knots, "Hermite")
    solve_grid(np.minimum(GH, GB), knots, "min(Hermite, Borell)")
