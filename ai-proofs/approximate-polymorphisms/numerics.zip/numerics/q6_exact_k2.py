"""Exact (integer) version of q6_deeplabels.py for the 348 boundary candidates (d=3, r=2).

For k in {1,2}, every output-label pattern nu (up to row order) and every choice of class-wise decoders
F_c : {+-1}^k -> {-1,0,1}, compute sgn Gamma_nu(F) exactly, where (h normalised to mu < 0)
  Gamma_nu(F) = sum_W prod_i pi_{nu_i}(W_i) h(F(W)),   pi_b(w) = (1 + b h(w)) / (2^d (1 + b mu)).
With h2 = 2h (integers) and S = sum_w h2(w): pi_b(w) = (2 + b h2(w)) / (16 + b S), and 16 h is an integer on
{-1,0,1}^3, so Gamma_nu(F) * prod_i (16 + nu_i S) / 16 is the integer
  sum_W prod_i (2 + nu_i h2(W_i)) * (16 h)(F(W)).
Reports how many candidates have a positive value (a certificate that s_g is nontrivial, Theorem C(iii)) and
checks that for all other candidates the maximum is exactly 0.
"""
import itertools
import numpy as np

d = 3
H = np.load('outputs/hard_h_d3_r2.npy')
P = list(itertools.product([1, -1], repeat=d))
T = list(itertools.product([1, 0, -1], repeat=d))
tid = {t: i for i, t in enumerate(T)}


def h16_table(h2):
    """16*h on {-1,0,1}^d (multilinear extension), as integers."""
    hv = dict(zip(P, h2))
    out = np.zeros(len(T), dtype=np.int64)
    for t, i in tid.items():
        zs = [j for j in range(d) if t[j] == 0]
        tot = 0
        for s in itertools.product([1, -1], repeat=len(zs)):
            w = list(t)
            for j, v in zip(zs, s):
                w[j] = v
            tot += hv[tuple(w)]
        out[i] = tot * 8 // 2 ** len(zs)
        assert tot * 8 % 2 ** len(zs) == 0
    return out


def best(h2, k, outs):
    S = int(sum(h2))
    if S > 0:
        h2 = [-x for x in h2]
        S = -S
    hv = dict(zip(P, h2))
    l1 = [sum(hv[w] * w[j] for w in P) for j in range(d)]
    uniq = sorted(set(l1))
    cls = [uniq.index(v) for v in l1]
    R = len(uniq)
    tab = h16_table(h2)
    labs = list(itertools.product([1, -1], repeat=k))
    lid = {l: i for i, l in enumerate(labs)}
    Fs = np.array(list(itertools.product(outs, repeat=len(labs))), dtype=np.int64)
    top = None
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        Ws = list(itertools.product(P, repeat=k))
        wt = np.array([np.prod([2 + nu[i] * hv[W[i]] for i in range(k)]) for W in Ws], dtype=np.int64)
        col = np.array([[lid[tuple(W[i][j] for i in range(k))] for j in range(d)] for W in Ws])
        allc = np.array(list(itertools.product(range(len(Fs)), repeat=R)), dtype=np.int64)
        for start in range(0, len(allc), 20000):
            combos = allc[start:start + 20000]
            idx = np.zeros((len(combos), len(Ws)), dtype=np.int64)
            for j in range(d):
                eff = Fs[combos[:, cls[j]]][:, col[:, j]]
                idx = idx * 3 + np.where(eff == 1, 0, np.where(eff == 0, 1, 2))
            m = int((tab[idx] @ wt).max())
            top = m if top is None else max(top, m)
    return top


for outs, name in (([1, -1], 'values in {-1,1}'), ([1, 0, -1], 'values in {-1,0,1}')):
    npos = nzero = nneg = 0
    for hv in H:
        h2 = [int(round(2 * x)) for x in hv]
        b = max(best(h2, 1, outs), best(h2, 2, outs))
        npos += b > 0
        nzero += b == 0
        nneg += b < 0
    print(f'k<=2 decoders with {name}: positive (certificate) {npos}, max exactly 0: {nzero}, negative: {nneg}'
          f' (total {len(H)})')
