"""Necessary condition for one-class coupling designs (oneclass_designs.py) with N columns, for one-class h with two distinct
pair laws (L1 on the pairs {1,2},{1,3}, L2 on {2,3}; B12, C12, D12, A12).  Floating-point LP (scipy/HiGHS).

R-feasibility (existence of h' and R, see oneclass_designs.py) can only improve when a free pair receives a law or a copy is
added.  So if no fully assigned design (every pair carries L1 or L2, i.e. a graph on N vertices with L1 = edge, with all
eligible copies) is R-feasible, then no design with N columns gives a certificate.  Fully assigned designs up to isomorphism
are the graphs of the networkx atlas (N <= 7).  For R-feasible full designs the script then searches downwards (removing pair
assignments and copies while R stays feasible) for a design whose row laws rho_+- also exist.
usage: python3 oneclass_full.py NAMES NS [budget]   (budget = nodes of the downward search per design; 0 = skip it)
       e.g. python3 oneclass_full.py B12,D12,C12,A12 4,5,6,7
"""
import itertools
import sys

import networkx as nx

from oneclass_designs import ONE, P3, R_feasible, eligible_copies, rho_feasible, setup


def full_designs(N):
    for G in nx.graph_atlas_g():
        if G.number_of_nodes() != N:
            continue
        yield {(a, c): (1 if G.has_edge(a, c) else 2) for a, c in itertools.combinations(range(N), 2)}


def key(assign, copies, N):
    best = None
    for pm in itertools.permutations(range(N)):
        k1 = tuple(sorted((tuple(sorted((pm[a], pm[c]))), L) for (a, c), L in assign.items() if L))
        k2 = tuple(sorted(tuple(sorted((pm[a], pm[c], pm[e]))) for a, c, e, _ in copies))
        k = (k1, k2)
        if best is None or k < best:
            best = k
    return best


def down_search(N, assign, copies, st, seen, budget):
    """DFS over sub-designs that stay R-feasible; returns a design with rho feasible, or None."""
    if budget[0] <= 0:
        return None
    budget[0] -= 1
    k = key(assign, copies, N) if N <= 6 else (tuple(sorted(assign.items())), tuple(sorted(c[:3] for c in copies)))
    if k in seen:
        return None
    seen.add(k)
    if rho_feasible(N, assign, copies, st):
        return assign, copies
    for t in range(len(copies)):
        sub = copies[:t] + copies[t + 1:]
        if R_feasible(N, assign, sub, st)[0]:
            out = down_search(N, assign, sub, st, seen, budget)
            if out:
                return out
    for pr, L in assign.items():
        if not L:
            continue
        a2 = dict(assign)
        a2[pr] = 0
        sub = [c for c in copies if pr not in itertools.combinations(c[:3], 2)]
        if R_feasible(N, a2, sub, st)[0]:
            out = down_search(N, a2, sub, st, seen, budget)
            if out:
                return out
    return None


def main():
    names = sys.argv[1].split(',')
    Ns = [int(x) for x in sys.argv[2].split(',')]
    budget0 = int(sys.argv[3]) if len(sys.argv) > 3 else 0
    for name in names:
        st = setup(name)
        assert [st['law_of'][jk] for jk in P3] == [1, 1, 2], name
        for N in Ns:
            nfull, nR, cert = 0, 0, None
            for assign in full_designs(N):
                nfull += 1
                copies = eligible_copies(N, assign, st)
                if not R_feasible(N, assign, copies, st)[0]:
                    continue
                nR += 1
                if cert is None and budget0 > 0:
                    out = down_search(N, assign, copies, st, set(), [budget0])
                    if out:
                        cert = out
            print(f"{name} N={N}: {nfull} full designs, {nR} R-feasible"
                  + (f"; certificate: assigned {dict((k, v) for k, v in cert[0].items() if v)}, copies "
                     f"{[c[:3] for c in cert[1]]}" if cert else "; no certificate found below them"), flush=True)


if __name__ == '__main__':
    main()
