"""rep5 and rep10: exhaustive exact check of (rep5ex), (R5), (rep10ex), (rep10maj) for every {0,1}-valued P with k = 4 and k = 5.

Compiles rep510_boolean.c (gcc -O3, once for K = 4 and once for K = 5) and runs it for every nu up to the order of the labels,
nu = (+1)^r (-1)^(k-r); for k = 5 the 2^32 Gray-code indices are split into CHUNKS ranges run in parallel. The C program works
with D*LHS and D*RHS in exact integer arithmetic (every value has modulus at most 9D, and 9D < 2^31) and recomputes its incrementally
updated accumulators from scratch at the end of every range. Checks made here:
  k = 4: the C results (maximum of LHS - RHS, number of P attaining it, number of P with LHS = RHS, largest negative value,
         set of equality cases) coincide with a direct numpy evaluation of all 2^16 P (exact: integers < 2^53 in float64);
  every range: the sample points printed by the C program (t = t0 and pseudo-random Gray indices, about one in 2^shift)
         coincide with Fraction evaluations of the four sides from the joint law rep510_exact.columns (independent of the
         C construction of the law).
Equality cases must be complete (at most MAXEQ per range); they are named (0, 1, z_r = +-1, two-literal ANDs) and asserted to be
exactly the families listed in want_eq, with r = number of labels with nu = +.
usage: python3 rep510_boolean.py [chunks] [jobs]
"""
import os
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor
from fractions import Fraction as Fr
from math import lcm

import numpy as np

from rep510_exact import REPS, columns, cube, setup

HERE = os.path.dirname(os.path.abspath(__file__))
NAMES = {"rep5": ("rep5ex", "R5"), "rep10": ("rep10ex", "rep10maj")}
MAXEQ = 512


def build(k):
    exe = f"/tmp/rep510_boolean_k{k}"
    subprocess.run(["gcc", "-O3", "-march=native", f"-DK={k}", "-o", exe, os.path.join(HERE, "rep510_boolean.c")], check=True)
    return exe


def run(exe, orbit, npos, t0, t1, shift):
    out = subprocess.run([exe, str(orbit), str(npos), str(t0), str(t1), str(shift)], check=True, capture_output=True,
                         text=True).stdout.splitlines()
    samples, ineq, D, ok = [], {}, None, False
    for line in out:
        f = line.split()
        if f[0] == "sample":
            samples.append(tuple(int(v) for v in f[1:]))
        elif f[0] == "consistency":
            ok = True
        elif f[0] == "D":
            D = int(f[1])
        elif f[0] == "ineq":
            ineq[int(f[1])] = dict(maxd=int(f[3]), cnt_max=int(f[5]), cnt_zero=int(f[7]), maxneg=int(f[9]),
                                   eq=[int(v) for v in f[11:]])
    assert ok and D is not None and len(ineq) == 2, (orbit, npos, t0, t1)
    return D, ineq, samples


def four_sides(name, J, P):
    """(L1, R1, L2, R2) as Fractions: (rep5ex), (R5) for rep5; (rep10ex), (rep10maj) for rep10."""
    c1, c2, e12, pm = {}, {}, Fr(0), Fr(0)
    for (z1, z2, z3), p in J.items():
        a, b = P[z1], P[z2]
        if name == "rep5":
            v1, v2 = 2 * a - 1 - 2 * (1 - a) * b, 2 * a - 1
        else:
            v1, v2 = a + 3 * b - 2 * a * b - 1, a + 3 * b - 4 * a * b - 1
        c1[z3] = c1.get(z3, 0) + p * v1
        c2[z3] = c2.get(z3, 0) + p * v2
        e12 += p * a * b
        pm += p * a
    L1, L2 = sum(max(v, 0) for v in c1.values()), sum(max(v, 0) for v in c2.values())
    if name == "rep5":
        return L1, 2 * e12, L2, 2 * e12
    return L1, pm + e12, L2, pm - e12


def numpy_k4(pi, nu):
    """Direct evaluation of D*(L1, R1, L2, R2) for all 2^16 {0,1}-valued P with k = 4."""
    k = 4
    den = {b: lcm(*[q.denominator for q in pi[b].values()]) for b in (1, -1)}
    D = 1
    for b in nu:
        D *= den[b]
    pts = cube(k)
    idx = {z: i for i, z in enumerate(pts)}
    n = 2 ** k
    T = np.zeros((n, n, n))
    for (z1, z2, z3), p in columns(pi, nu).items():
        T[idx[z1], idx[z2], idx[z3]] = (p * D).numerator
    P = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1).astype(np.float64)
    M12, M13, M23 = T.sum(2), T.sum(1), T.sum(0)
    m1, m3 = T.sum((1, 2)), T.sum((0, 1))
    C = np.einsum("pi,pij->pj", P, (P @ T.reshape(n, n * n)).reshape(-1, n, n))
    Q13, Q23 = P @ M13, P @ M23
    E12 = np.einsum("pi,pi->p", P @ M12, P)
    return D, {"rep5": (np.maximum(2 * Q13 - m3 - 2 * Q23 + 2 * C, 0).sum(1), 2 * E12, np.maximum(2 * Q13 - m3, 0).sum(1), 2 * E12),
               "rep10": (np.maximum(Q13 + 3 * Q23 - 2 * C - m3, 0).sum(1), P @ m1 + E12,
                         np.maximum(Q13 + 3 * Q23 - 4 * C - m3, 0).sum(1), P @ m1 - E12)}


def classify(p, k):
    pts = cube(k)
    supp = frozenset(z for i, z in enumerate(pts) if (p >> i) & 1)
    names = {frozenset(): "0", frozenset(pts): "1"}
    for r in range(k):
        for a in (1, -1):
            names[frozenset(z for z in pts if z[r] == a)] = f"z{r + 1}={a}"
            for s in range(k):
                for b in (1, -1):
                    if s != r and not (s < r and a == b):
                        names.setdefault(frozenset(z for z in pts if z[r] == a and z[s] == b),
                                         f"z{r + 1}={a},z{s + 1}={b}" if a != b else f"z{r + 1}=z{s + 1}={a}")
    return names.get(supp, f"other{sorted(supp)}")


def want_eq(lab, r):
    """Claimed equality cases with nu = (+1)^r (-1)^(k-r), in the naming of classify."""
    plus = range(1, r + 1)
    dic = {f"z{i}=1" for i in plus}
    ands = {f"z{i}=z{j}=1" for i in plus for j in plus if i < j}
    mixed = {f"z{i}={a},z{j}={-a}" for i in plus for j in plus if i < j for a in (1, -1)}
    neg = {f"z{i}=-1" for i in plus}
    return {"rep5ex": {"0"} | dic | ands, "R5": {"0"} | dic | ands | mixed,
            "rep10ex": {"0"} | dic | neg, "rep10maj": {"0", "1"} | dic | neg}[lab]


def main():
    chunks = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    jobs = int(sys.argv[2]) if len(sys.argv) > 2 else os.cpu_count()
    t_start = time.time()
    exes = {k: build(k) for k in (4, 5)}
    tasks = []
    for k in (4, 5):
        n_idx = 2 ** (2 ** k)
        nch = 1 if k == 4 else chunks
        for name in REPS:
            for npos in range(k, -1, -1):
                for c in range(nch):
                    t0, t1 = n_idx * c // nch, n_idx * (c + 1) // nch
                    shift = 12 if k == 4 else max((t1 - t0).bit_length() - 3, 1)
                    tasks.append((k, name, npos, t0, t1, shift))
    with ThreadPoolExecutor(max_workers=jobs) as ex:
        results = list(ex.map(lambda a: run(exes[a[0]], 5 if a[1] == "rep5" else 10, *a[2:]), tasks))
    print(f"# {len(tasks)} ranges done in {time.time() - t_start:.0f} s ({jobs} parallel jobs)", flush=True)

    agg, nsamples = {}, 0
    for (k, name, npos, t0, t1, shift), (D, ineq, samples) in zip(tasks, results):
        _, _, pi = setup(REPS[name])
        nu = (1,) * npos + (-1,) * (k - npos)
        J = columns(pi, nu)
        for (p, *vals) in samples:
            P = {z: Fr((p >> i) & 1) for i, z in enumerate(cube(k))}
            exact = four_sides(name, J, P)
            assert all(v * D == w for v, w in zip(exact, vals)), (k, name, nu, p)
            nsamples += 1
        for q in (0, 1):
            st = ineq[q]
            assert st["cnt_zero"] <= MAXEQ and len(st["eq"]) == st["cnt_zero"]
            a = agg.setdefault((k, name, npos, q), dict(D=D, maxd=None, cnt_max=0, cnt_zero=0, maxneg=None, eq=[], n=0))
            if a["maxd"] is None or st["maxd"] > a["maxd"]:
                a["maxd"], a["cnt_max"] = st["maxd"], 0
            if st["maxd"] == a["maxd"]:
                a["cnt_max"] += st["cnt_max"]
            a["cnt_zero"] += st["cnt_zero"]
            if st["maxneg"] > -2 ** 62:
                a["maxneg"] = st["maxneg"] if a["maxneg"] is None else max(a["maxneg"], st["maxneg"])
            a["eq"] += st["eq"]
            a["n"] += t1 - t0

    for name in REPS:
        _, _, pi = setup(REPS[name])
        for npos in range(4, -1, -1):
            D, arrs = numpy_k4(pi, (1,) * npos + (-1,) * (4 - npos))
            for q in (0, 1):
                diff = arrs[name][2 * q] - arrs[name][2 * q + 1]
                assert np.all(diff == np.round(diff)) and np.abs(diff).max() < 2 ** 50
                a = agg[(4, name, npos, q)]
                mx = int(diff.max())
                assert a["D"] == D and a["n"] == 2 ** 16 and a["maxd"] == mx and a["cnt_max"] == int((diff == mx).sum())
                assert a["cnt_zero"] == int((diff == 0).sum()) and a["maxneg"] == int(diff[diff < 0].max())
                assert sorted(a["eq"]) == sorted(int(v) for v in np.flatnonzero(diff == 0))
    print("ok: k = 4, all four inequalities, every nu: C results coincide with the direct numpy evaluation of all 2^16 P")
    print(f"ok: {nsamples} sample points coincide with exact Fraction evaluations of the four sides (rep510_exact.columns)")

    worst = {}
    for k in (4, 5):
        for name in REPS:
            for q in (0, 1):
                for npos in range(k, -1, -1):
                    a = agg[(k, name, npos, q)]
                    assert a["n"] == 2 ** (2 ** k)
                    lab = NAMES[name][q]
                    worst[(k, lab)] = max(worst.get((k, lab), a["maxd"]), a["maxd"])
                    print(f"k={k} {lab} nu=(+{npos},-{k - npos}): D = {a['D']}; max (LHS - RHS) = {Fr(a['maxd'], a['D'])} at "
                          f"{a['cnt_max']} of {a['n']} P; LHS = RHS for {a['cnt_zero']} P; largest negative value "
                          f"{a['maxneg'] / a['D']:.6g}", flush=True)
                    got = sorted(classify(p, k) for p in a["eq"])
                    print(f"   equality cases: {', '.join(got)}", flush=True)
                    assert set(got) == want_eq(lab, npos) and len(got) == len(want_eq(lab, npos)), (k, lab, npos)
    for (k, lab), v in worst.items():
        print(f"{'ok' if v <= 0 else 'FAIL'}: k={k} {lab}: LHS <= RHS for every {{0,1}}-valued P and every nu (max LHS - RHS = {v})")
    print("ok: the equality cases are exactly the claimed families (want_eq) for every k, inequality and nu")
    print(f"# total {time.time() - t_start:.0f} s")
    assert all(v <= 0 for v in worst.values())


if __name__ == "__main__":
    main()
