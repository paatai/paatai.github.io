"""Certificate search with exact polishing for one-class candidates h = (x, z, z, y) (mu < 0, so a certificate is Gamma > 0).

For each k in the given range and each nu (up to permutation of rows), coordinate ascent over F : {+-1}^k -> [-1,1]
(j2_cert_search.ascent, floating point) from the dictators, from "dictator with the all-c point lowered" starts and from
random starts.  The best local maximum is then polished exactly: the coordinates with |F| = 1 (up to 1e-7) are fixed, the
stationarity equations of Gamma in the remaining coordinates are solved in rational arithmetic (j2_k2_exact.solve), and if
the solution lies in (-1,1) the exact value of Gamma is computed (j2_k2_exact.value).  Any positive exact value is a
certificate (Theorem C(iii)); the decoder is printed with exact rational values.

usage: python3 j2_cert_polish.py kmin kmax restarts seed workers "x z y" ["x z y" ...]
"""
import sys
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np

from j2_cert_search import ascent, laws, setup
from j2_k2_exact import quad_form, solve, value


def polish(hv, nu, F):
    c0, lin, Q = quad_form(hv, nu)
    n = len(F)
    fixed = {i: (1 if F[i] > 0 else -1) for i in range(n) if abs(abs(F[i]) - 1) < 1e-7}
    free = [i for i in range(n) if i not in fixed]
    G = [Fr(fixed.get(i, 0)) for i in range(n)]
    if free:
        M = [[2 * Q[i][j] for j in free] for i in free]
        rhs = [-(lin[i] + 2 * sum(Q[i][j] * G[j] for j in fixed)) for i in free]
        sol = solve(M, rhs)
        if sol is None:
            return None
        if any(not (-1 < s < 1) for s in sol):
            return None
        for i, s in zip(free, sol):
            G[i] = s
    return value(c0, lin, Q, G), G


def run_one(args):
    spec, kmin, kmax, restarts, seed = args
    xs, zs, ys = spec.split()
    hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
    rng = np.random.default_rng(seed)
    pi = laws(hv)
    hvf = [float(v) for v in hv]

    def hf(y1, y2):
        x, z, _, y = hvf
        return (x * (1 + y1) * (1 + y2) + z * (1 + y1) * (1 - y2) + z * (1 - y1) * (1 + y2) + y * (1 - y1) * (1 - y2)) / 4

    lines = [f"h = ({xs}, {zs}, {zs}, {ys}):"]
    found = None
    for k in range(kmin, kmax + 1):
        for npos in range(k, -1, -1):
            nu = tuple([1] * npos + [-1] * (k - npos))
            cols, probs = setup(pi, nu)
            n = 2 ** k
            starts = []
            for c in range(k):
                for s in (1, -1):
                    d = np.array([s * (1 - 2 * ((z >> (k - 1 - c)) & 1)) for z in range(n)], float)
                    starts.append(d)
                    for corner in (0, n - 1):
                        e = d.copy()
                        e[corner] = 0.0
                        starts.append(e)
            for _ in range(restarts):
                starts.append(rng.choice([-1.0, 1.0], size=n))
                starts.append(rng.uniform(-1, 1, size=n))
            best = (-np.inf, None)
            for F0 in starts:
                g, F = ascent(hf, F0.copy(), cols, probs, rng)
                if g > best[0]:
                    best = (g, F.copy())
            g, F = best
            tag = ''
            if g > -1e-6:
                pol = polish(hv, nu, F)
                if pol is not None:
                    val, G = pol
                    tag = f"  exact polished Gamma = {val} ({float(val):+.4e})"
                    if val > 0 and found is None:
                        found = (k, nu, val, G)
                else:
                    tag = "  (polish failed)"
            lines.append(f"  k={k} nu={''.join('+' if v > 0 else '-' for v in nu)}: best float {g:+.4e}{tag}")
        if found is not None:
            break
    if found:
        k, nu, val, G = found
        lines.append(f"  CERTIFICATE k={k} nu={nu} Gamma={val} F={[str(v) for v in G]}")
    else:
        lines.append("  no certificate found")
    return "\n".join(lines)


if __name__ == '__main__':
    kmin, kmax, restarts, seed, workers = (int(a) for a in sys.argv[1:6])
    specs = sys.argv[6:]
    with Pool(workers) as pool:
        for out in pool.imap(run_one, [(s, kmin, kmax, restarts, seed + i) for i, s in enumerate(specs)]):
            print(out, flush=True)
