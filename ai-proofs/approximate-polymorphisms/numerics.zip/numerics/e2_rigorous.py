"""Rigorous checks for g = E2 ("exactly two of three inputs are +1").

(1) Exact certificate for s^L_{E2} = 5/8 (Theorem A of MAIN_RESULT):
    for every q : R^n -> [-1,1] with E q = 0 and every x,
        P[g = +1 | G_0 = x] <= Btilde(p),  p = p(x) in [0,1],
        Btilde(p) = 3p^2(1-p) + (3/(14 pi)) p + (3p/1372 + 3/196 + 3/169) p(1-p).
    Btilde is increasing in 1/pi and 1/pi < 50/157 (pi > 3.14), so it suffices that the cubic
        Bbar(p) = Btilde(p) with 1/pi replaced by 50/157
    satisfies Bbar < 1/2 on [0,1].  We verify this in exact rational arithmetic (Sturm root count).

(2) The rigorous lower bounds
        s^U_{E2} >= 5/8 + I,   s_{E2} >= 5/8 + (3/8) I,
        I = int_{x0}^inf (1 - 6 Phi(-x/sqrt 14)) phi(x) dx,  x0 = sqrt(14) Phi^{-1}(5/6),
    evaluated to 30 digits with mpmath (the integrand is positive on (x0, inf), so I > 0 needs no numerics).
"""
import sympy as sp
import mpmath as mp

p = sp.symbols('p')
inv_pi_ub = sp.Rational(50, 157)
assert sp.pi.evalf(50) > sp.Rational(314, 100)  # pi > 3.14  =>  1/pi < 50/157

def Btilde(inv_pi):
    return (3 * p**2 * (1 - p) + sp.Rational(3, 14) * inv_pi * p
            + (sp.Rational(3, 1372) * p + sp.Rational(3, 196) + sp.Rational(3, 169)) * p * (1 - p))

Bbar = sp.expand(Btilde(inv_pi_ub))
P = sp.Poly(sp.Rational(1, 2) - Bbar, p)
print("1/2 - Bbar(p) =", P.as_expr())
nroots = P.count_roots(0, 1)          # exact (Sturm) count of real roots in [0,1]
val0 = P.eval(0)
print("number of real roots of 1/2 - Bbar in [0,1]:", nroots, "; value at p=0:", val0)
assert nroots == 0 and val0 > 0, "certificate failed"
c_star = sp.Rational(49788, 100000)
P2 = sp.Poly(c_star - Bbar, p)
nroots2, val2 = P2.count_roots(0, 1), P2.eval(0)
print("number of real roots of 49788/100000 - Bbar in [0,1]:", nroots2, "; value at p=0:", val2)
assert nroots2 == 0 and val2 > 0, "certificate for the constant 0.49788 failed"
print("=> Bbar < 0.49788 on [0,1]  [CERTIFIED, exact]")
crit = [r for r in sp.Poly(sp.diff(Bbar, p), p).real_roots() if 0 <= r <= 1]
cands = [sp.Integer(0), sp.Integer(1)] + crit
mx = max(cands, key=lambda r: Bbar.subs(p, r).evalf(40))
print("max_[0,1] Bbar = %s at p = %s  (exact critical point: %s)"
      % (sp.N(Bbar.subs(p, mx), 20), sp.N(mx, 20), mx))
print("=> P[g=+1 | G_0=x] <= %.10f < 1/2 for all x, q:  s^L_E2 = 5/8  [CERTIFIED]" % float(sp.N(Bbar.subs(p, mx), 20)))

# Same with the exact 1/pi (for reporting only).
Bt = sp.lambdify(p, Btilde(1 / sp.pi), 'mpmath')
mp.mp.dps = 30
pm = mp.findroot(lambda t: mp.diff(Bt, t), 0.66)
print("for reference: max Btilde (exact 1/pi) = %s at p = %s" % (mp.nstr(Bt(pm), 12), mp.nstr(pm, 12)))

# Original (sharper) bound with W_1 <= phi(Phi^{-1}(p))^2 instead of 1/(2 pi).
def Borig(t):
    t = mp.mpf(t)
    ph = mp.npdf(mp.sqrt(2) * mp.erfinv(2 * t - 1))
    return (3 * t**2 * (1 - t) + 6 * mp.mpf(1) / 14 * t * ph**2
            + t * (1 - t) * (6 * mp.mpf(1) / 14**3 * t + 3 * mp.mpf(1) / 196 + 3 * mp.mpf(1) / 169))
pm2 = mp.findroot(lambda t: mp.diff(Borig, t), 0.66)
print("for reference: max of the sharper bound B = %s at p = %s" % (mp.nstr(Borig(pm2), 12), mp.nstr(pm2, 12)))

# (2) rigorous lower bounds for s^U and s.
Phi = mp.ncdf
x0 = mp.sqrt(14) * mp.sqrt(2) * mp.erfinv(2 * mp.mpf(5) / 6 - 1)
I = mp.quad(lambda x: (1 - 6 * Phi(-x / mp.sqrt(14))) * mp.npdf(x), [x0, x0 + 2, x0 + 6, mp.inf])
print("x0 = %s,  I = %s" % (mp.nstr(x0, 15), mp.nstr(I, 15)))
print("s^U_E2 >= 5/8 + I       = %s" % mp.nstr(mp.mpf(5) / 8 + I, 15))
print("s_E2   >= 5/8 + (3/8) I = %s" % mp.nstr(mp.mpf(5) / 8 + 3 * I / 8, 15))
