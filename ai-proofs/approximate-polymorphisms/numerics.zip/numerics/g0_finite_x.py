"""Numerical test of the conjecture s_{g0} = triv at finite x (one label bit, n = 1).

For g0 (numerics/q6_g0.py), J = {1,2,3}, rho_j = rho = -1/(4 sqrt 3), a = sqrt(sum rho_j^2) = 1/4.
CFMMS representation: Z ~ N(0, I_3), G_0 = <e, Z> with e = -(1,1,1)/sqrt 3, G_j = a Z_j + sqrt(1-a^2) W_j.
Then E[prod_j Q_j(G_j) | Z] = prod_j (U_a Q_j)(Z_j), so with one label bit (k = 1) and output label nu,
   gamma_nu(x) = sum_w pi_nu(w) E[ h( (U_a Q_{w_1})(Z_1), (U_a Q_{w_2})(Z_2), (U_a Q_{w_3})(Z_3) ) | <e,Z> = x ].
We maximise gamma_nu(x) at fixed x over mean-zero step functions Q_{+1}, Q_{-1} : R -> [-1,1]
(projected gradient ascent, several starts incl. the dictator Q_z = z sgn).  A positive value would refute
the conjecture (it would give s_{g0} > triv via Lemma 2.3(a)).
"""
import itertools
import sys
import numpy as np
from scipy.special import ndtr

rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
W3 = list(itertools.product([1, -1], repeat=3))
hval = dict(zip(W3, [-1, -1, -1, 0.5, 0, -0.5, -0.5, -0.5]))
mu = np.mean(list(hval.values()))
hhat = {S: np.mean([hval[w] * np.prod([w[j] for j in S]) for w in W3])
        for r in range(4) for S in itertools.combinations(range(3), r)}
pi = {b: {w: (1 + b * hval[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}

a = 0.25
sig = np.sqrt(1 - a * a)
edges = np.concatenate([[-np.inf], np.linspace(-6, 6, 121), [np.inf]])
B = len(edges) - 1
mass = ndtr(edges[1:]) - ndtr(edges[:-1])

gh_x, gh_w = np.polynomial.hermite_e.hermegauss(36)
gh_w = gh_w / gh_w.sum()
e = -np.ones(3) / np.sqrt(3)
e1 = np.array([1, -1, 0]) / np.sqrt(2)
e2 = np.array([1, 1, -2]) / np.sqrt(6)
U, V = np.meshgrid(gh_x, gh_x, indexing='ij')
WT = (gh_w[:, None] * gh_w[None, :]).ravel()
UV = np.stack([U.ravel(), V.ravel()], axis=1)


def kernel(x):
    Z = x * e[None, :] + UV[:, :1] * e1[None, :] + UV[:, 1:] * e2[None, :]    # nodes x 3
    t = a * Z[..., None]
    return ndtr((edges[None, None, 1:] - t) / sig) - ndtr((edges[None, None, :-1] - t) / sig)   # nodes x 3 x B


def value_grad(Q, K, nu):
    """Q: dict z -> (B,) ; returns gamma_nu(x) and gradient wrt Q[z]."""
    A = {z: K @ Q[z] for z in (1, -1)}          # nodes x 3
    val = 0.0
    grad = {1: np.zeros(B), -1: np.zeros(B)}
    for w in W3:
        p = pi[nu][w]
        if p == 0:
            continue
        y = np.stack([A[w[j]][:, j] for j in range(3)], axis=1)
        hv = sum(c * np.prod(y[:, list(S)], axis=1) for S, c in hhat.items())
        val += p * WT @ hv
        for j in range(3):
            d = sum(c * np.prod(y[:, [i for i in S if i != j]], axis=1) for S, c in hhat.items() if j in S)
            grad[w[j]] += p * (WT * d) @ K[:, j, :]
    return val, grad


def project(q):
    lo, hi = -2.0, 2.0
    for _ in range(60):
        t = (lo + hi) / 2
        if mass @ np.clip(q - t, -1, 1) > 0:
            lo = t
        else:
            hi = t
    return np.clip(q - (lo + hi) / 2, -1, 1)


def optimise(x, nu, Q0, steps=400, lr=2.0):
    K = kernel(x)
    Q = {z: project(Q0[z].copy()) for z in (1, -1)}
    best = -np.inf
    for s in range(steps):
        v, g = value_grad(Q, K, nu)
        best = max(best, v)
        for z in (1, -1):
            Q[z] = project(Q[z] + lr * g[z] / np.sqrt(mass + 1e-6))
    v, _ = value_grad(Q, K, nu)
    return max(best, v), Q


mid = (np.clip(edges[1:], -7, 7) + np.clip(edges[:-1], -7, 7)) / 2
dictator = {z: z * np.sign(mid) for z in (1, -1)}
for nu in (1, -1):
    for x in (-3.0, -6.0, -10.0, -16.0, -25.0, 3.0, 6.0, 10.0):
        K = kernel(x)
        vd, _ = value_grad({z: project(dictator[z]) for z in (1, -1)}, K, nu)
        res = [optimise(x, nu, dictator)[0]]
        for _ in range(6):
            Q0 = {z: rng.uniform(-1, 1, B) for z in (1, -1)}
            res.append(optimise(x, nu, Q0)[0])
        print(f'nu={nu:+d} x={x:6.1f}: dictator {vd:+.6f}  best after ascent {max(res):+.6f}  (starts: '
              + ' '.join(f'{r:+.4f}' for r in res) + ')', flush=True)
