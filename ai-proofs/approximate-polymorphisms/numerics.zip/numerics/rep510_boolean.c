/* rep510_boolean.c: exhaustive exact check of the one-function inequalities of Section 11 over all {0,1}-valued P with k = K.

For orbit rep5 it evaluates (rep5ex) and (R5), for orbit rep10 it evaluates (rep10ex) and (rep10maj), in the scaled form
D*LHS, D*RHS (D = product of the row-law denominators, so that D*Pr[X1=z1, X2=z2, X3=z3] is an integer). P runs through the
Gray-code indices t0 <= t < t1 (P = t ^ (t >> 1), bit i of P is P(z_i), z_i the i-th point of itertools.product((1,-1), repeat=K));
all accumulators are updated incrementally when one bit of P flips and are recomputed from scratch at the end of the range
and compared. Every quantity is an integer of modulus at most 9D, and 9D < 2^31 is asserted, so the arithmetic is exact.
usage: rep510_boolean ORBIT(5|10) NPOS T0 T1 SAMPLE_SHIFT     (nu = (+1)^NPOS (-1)^(K-NPOS))
output: per inequality the maximum of D*(LHS-RHS), the number of P attaining it, the number of P with LHS = RHS, the largest
negative value, up to MAXEQ masks P with LHS = RHS; sample lines "sample P L1 R1 L2 R2" at t = T0 and at the indices t with
mix(t) (the splitmix64 finalizer) divisible by 2^SAMPLE_SHIFT (pseudo-random, about one index in 2^SAMPLE_SHIFT). */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifndef K
#define K 5
#endif
#define N (1 << K)
#define MAXEQ 512

static int32_t T[N][N][N], Tsym[N][N][N];
static int32_t M12[N][N], M13[N][N], M23[N][N], Msym[N][N], m1[N], m3[N];
static const int H5[8] = {-2, -1, -1, 0, 1, -2, 0, -1}, H10[8] = {-1, -2, 0, 0, 1, -1, -1, 0};

typedef struct {
    int32_t W[N][N], c[N], q13[N], q23[N], u[N];
    int64_t e12, p1;
} state;

typedef struct {
    int64_t maxd, cnt_max, cnt_zero, maxneg, neq;
    uint64_t eq[MAXEQ];
} stats;

static int coord(int i, int r) { return 1 - 2 * ((i >> (K - 1 - r)) & 1); }
static uint64_t mix(uint64_t z) {
    z += 0x9E3779B97F4A7C15ULL;
    z = (z ^ (z >> 30)) * 0xBF58476D1CE4E5B9ULL;
    z = (z ^ (z >> 27)) * 0x94D049BB133111EBULL;
    return z ^ (z >> 31);
}
static int widx(int a, int b, int c) { return ((a == -1) << 2) | ((b == -1) << 1) | (c == -1); }

static void die(const char *m) {
    fprintf(stderr, "error: %s\n", m);
    exit(1);
}

static void init_state(state *s, uint64_t P) {
    memset(s, 0, sizeof *s);
    for (int i = 0; i < N; i++) {
        if (!((P >> i) & 1)) continue;
        s->p1 += m1[i];
        for (int x = 0; x < N; x++) {
            s->q13[x] += M13[i][x];
            s->q23[x] += M23[i][x];
        }
        for (int j = 0; j < N; j++) {
            s->u[j] += Msym[i][j];
            for (int x = 0; x < N; x++) s->W[j][x] += Tsym[i][j][x];
            if ((P >> j) & 1) {
                s->e12 += M12[i][j];
                for (int x = 0; x < N; x++) s->c[x] += T[i][j][x];
            }
        }
    }
}

static inline void flip(state *s, int b, int up) {
    if (up) {
        for (int x = 0; x < N; x++) s->c[x] += s->W[b][x] + T[b][b][x];
        s->e12 += s->u[b] + M12[b][b];
        for (int i = 0; i < N; i++)
            for (int x = 0; x < N; x++) s->W[i][x] += Tsym[b][i][x];
        for (int i = 0; i < N; i++) s->u[i] += Msym[b][i];
        for (int x = 0; x < N; x++) {
            s->q13[x] += M13[b][x];
            s->q23[x] += M23[b][x];
        }
        s->p1 += m1[b];
    } else {
        for (int x = 0; x < N; x++) s->c[x] -= s->W[b][x] - T[b][b][x];
        s->e12 -= s->u[b] - M12[b][b];
        for (int i = 0; i < N; i++)
            for (int x = 0; x < N; x++) s->W[i][x] -= Tsym[b][i][x];
        for (int i = 0; i < N; i++) s->u[i] -= Msym[b][i];
        for (int x = 0; x < N; x++) {
            s->q13[x] -= M13[b][x];
            s->q23[x] -= M23[b][x];
        }
        s->p1 -= m1[b];
    }
}

static inline void sides(const state *s, int orbit, int64_t *L1, int64_t *R1, int64_t *L2, int64_t *R2) {
    int32_t a = 0, b = 0;
    if (orbit == 5) {
        for (int x = 0; x < N; x++) {
            int32_t v2 = 2 * s->q13[x] - m3[x];
            int32_t v1 = v2 - 2 * s->q23[x] + 2 * s->c[x];
            a += v1 > 0 ? v1 : 0;
            b += v2 > 0 ? v2 : 0;
        }
        *L1 = a, *R1 = 2 * s->e12, *L2 = b, *R2 = 2 * s->e12;
    } else {
        for (int x = 0; x < N; x++) {
            int32_t v1 = s->q13[x] + 3 * s->q23[x] - 2 * s->c[x] - m3[x];
            int32_t v2 = v1 - 2 * s->c[x];
            a += v1 > 0 ? v1 : 0;
            b += v2 > 0 ? v2 : 0;
        }
        *L1 = a, *R1 = s->p1 + s->e12, *L2 = b, *R2 = s->p1 - s->e12;
    }
}

static inline void record(stats *st, int64_t d, uint64_t P) {
    if (d > st->maxd) st->maxd = d, st->cnt_max = 0;
    if (d == st->maxd) st->cnt_max++;
    if (d == 0) {
        if (st->neq < MAXEQ) st->eq[st->neq] = P;
        st->neq++;
        st->cnt_zero++;
    } else if (d < 0 && d > st->maxneg)
        st->maxneg = d;
}

int main(int argc, char **argv) {
    if (argc != 6) die("usage: rep510_boolean ORBIT NPOS T0 T1 SAMPLE_SHIFT");
    int orbit = atoi(argv[1]), npos = atoi(argv[2]), shift = atoi(argv[5]);
    uint64_t t0 = strtoull(argv[3], 0, 10), t1 = strtoull(argv[4], 0, 10);
    if ((orbit != 5 && orbit != 10) || npos < 0 || npos > K || t0 >= t1 || t1 > ((uint64_t)1 << N)) die("bad arguments");
    const int *h2 = orbit == 5 ? H5 : H10;
    int num[2][8], den[2] = {0, 0};
    for (int w = 0; w < 8; w++) {
        num[0][w] = 2 + h2[w];
        num[1][w] = 2 - h2[w];
        den[0] += num[0][w];
        den[1] += num[1][w];
    }
    int64_t D = 1;
    for (int r = 0; r < K; r++) D *= den[r < npos ? 0 : 1];
    if (9 * D >= ((int64_t)1 << 31)) die("D too large for int32");
    int64_t tot = 0;
    for (int i1 = 0; i1 < N; i1++)
        for (int i2 = 0; i2 < N; i2++)
            for (int i3 = 0; i3 < N; i3++) {
                int64_t v = 1;
                for (int r = 0; r < K; r++) v *= num[r < npos ? 0 : 1][widx(coord(i1, r), coord(i2, r), coord(i3, r))];
                T[i1][i2][i3] = (int32_t)v;
                tot += v;
            }
    if (tot != D) die("T does not sum to D");
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++)
            for (int x = 0; x < N; x++) {
                M12[i][j] += T[i][j][x];
                M13[i][x] += T[i][j][x];
                M23[j][x] += T[i][j][x];
                m1[i] += T[i][j][x];
                m3[x] += T[i][j][x];
                Tsym[j][i][x] = T[i][j][x] + T[j][i][x];
            }
    for (int i = 0; i < N; i++)
        for (int j = 0; j < N; j++) Msym[j][i] = M12[i][j] + M12[j][i];

    static state s, chk;
    static stats st[2];
    for (int q = 0; q < 2; q++) st[q].maxd = st[q].maxneg = INT64_MIN, st[q].cnt_max = st[q].cnt_zero = st[q].neq = 0;
    uint64_t P = t0 ^ (t0 >> 1), mask = ((uint64_t)1 << shift) - 1;
    init_state(&s, P);
    for (uint64_t t = t0;;) {
        int64_t L1, R1, L2, R2;
        sides(&s, orbit, &L1, &R1, &L2, &R2);
        record(&st[0], L1 - R1, P);
        record(&st[1], L2 - R2, P);
        if ((mix(t) & mask) == 0 || t == t0)
            printf("sample %llu %lld %lld %lld %lld\n", (unsigned long long)P, (long long)L1, (long long)R1, (long long)L2,
                   (long long)R2);
        if (++t >= t1) break;
        int b = __builtin_ctzll(t);
        int up = !((P >> b) & 1);
        P ^= (uint64_t)1 << b;
        flip(&s, b, up);
    }
    init_state(&chk, P);
    if (memcmp(&chk, &s, sizeof s) != 0) die("incremental state differs from recomputation");
    printf("consistency ok: final P %llu (Gray index %llu)\n", (unsigned long long)P, (unsigned long long)(t1 - 1));
    printf("D %lld\n", (long long)D);
    for (int q = 0; q < 2; q++) {
        printf("ineq %d maxd %lld cnt_max %lld cnt_zero %lld maxneg %lld eq", q, (long long)st[q].maxd, (long long)st[q].cnt_max,
               (long long)st[q].cnt_zero, (long long)st[q].maxneg);
        for (int64_t e = 0; e < st[q].neq && e < MAXEQ; e++) printf(" %llu", (unsigned long long)st[q].eq[e]);
        printf("\n");
    }
    return 0;
}
