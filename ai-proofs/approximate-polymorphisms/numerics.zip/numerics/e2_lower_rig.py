"""Rigorous lower bounds for s^U_E2 and s_E2 (Theorem A(b),(c)) from q = (sgn, sgn, -sgn), n = 1.

J = E_x gamma_q(x)^+ with gamma_q(x) = 2 P(x) - 1 and P(x) = Pr[E2(sgn G1, sgn G2, -sgn G3) = 1 | G0 = x].
Given G0 = x, G_j > 0 iff Y_j > -a, where a = x/sqrt14 and Y is standard Gaussian with pairwise correlation
c = -1/14.  With A_j = {Y_j > -a}, inclusion-exclusion gives
    P = Pr[A1 A2 A3] + 2 Pr[A1 A2^c A3^c] = 3 L(a) + 2 Phi(a) - 4 Phi2(a, a; c),
    Phi2(a, a; c) = Phi(a) - 2 T(a, beta),            beta  = sqrt((1-c)/(1+c)) = sqrt(15/13)   (Owen),
    L(a) = Phi3(a, a, a; c) = 3 int_{-inf}^a phi(h) Phi2(beta h, beta h; c') dh,   c' = c/(1+c) = -1/13,
         = 3 int_{-inf}^a phi(h) [Phi(beta h) - 2 T(beta h, alpha)] dh,         alpha = sqrt((1-c')/(1+c')) = sqrt(7/6),
so gamma_q(x) = 6 L(a) - 4 Phi(a) + 16 T(a, beta) - 1, where T(h, s) = (1/2pi) int_0^s exp(-h^2(1+t^2)/2)/(1+t^2) dt.

Since gamma^+ >= gamma, J >= J(x1, X) = int_{x1}^X gamma_q(x) phi(x) dx for all x1 < X.  Exchanging the order of
integration writes J(x1, X) through one- and two-dimensional integrals of analytic functions (see `rigorous`), which
are enclosed with Arb (acb.integral).  x1 is a rational approximation of the zero of gamma_q (floating point; any
x1 gives a valid bound) and X = 12 (Proposition 4.3).  Then (Lemma 2.3(a) and the one-label construction of
Proposition 4.2, where gamma_+ = gamma_q by exchangeability)
    s^U_E2 >= 5/8 + J,     s_E2 >= s^lab_E2 >= 5/8 + (3/8) J.
The first part of the script cross-checks the formula for gamma_q against the tensor Gauss-Hermite evaluation of
polymorph.py (floating point).
usage: python3 e2_lower_rig.py
"""
import math
import os
import time
from fractions import Fraction

import numpy as np
from flint import acb, arb, ctx
from scipy.integrate import quad
from scipy.optimize import brentq
from scipy.special import ndtr, owens_t

BETA_F = np.sqrt(15 / 13)
ALPHA_F = np.sqrt(7 / 6)


def phi_f(x):
    return np.exp(-x * x / 2) / np.sqrt(2 * np.pi)


def L_float(a):
    f = lambda h: phi_f(h) * (ndtr(BETA_F * h) - 2 * owens_t(BETA_F * h, ALPHA_F))
    return 3 * quad(f, -np.inf, a, epsabs=1e-15, epsrel=1e-13, limit=200)[0]


def gamma_float(x):
    a = x / np.sqrt(14)
    return 6 * L_float(a) - 4 * ndtr(a) + 16 * owens_t(a, BETA_F) - 1


def float_checks(pr):
    from polymorph import GaussData, E2, gamma_x, U_sign
    GD = GaussData(E2, 3)
    sgn, msgn = U_sign(GD, 1.0), U_sign(GD, -1.0)
    worst = 0.0
    for x in [-3.0, -1.0, 0.0, 1.0, 2.0, 2.5, 3.0, 4.0, 6.0]:
        gh = float(gamma_x(GD, x, [sgn, sgn, msgn], npts=64)[0])
        worst = max(worst, abs(gh - gamma_float(x)))
    pr(f"formula vs Gauss-Hermite (9 points): max |difference| = {worst:.2e}")
    x0 = brentq(gamma_float, 1.0, 5.0, xtol=1e-14)
    J = quad(lambda x: gamma_float(x) * phi_f(x), x0, 12, epsabs=1e-15, epsrel=1e-12, limit=200)[0]
    pr(f"zero of gamma_q: x0 = {x0:.12f};  J = E gamma_q^+ = {J:.10e} (floating point)")
    return x0


def rigorous(x1q, Xq=12, prec=128, pr=print):
    ctx.prec = prec
    s14 = arb(14).sqrt()
    beta2 = arb(15) / 13
    beta = beta2.sqrt()
    alpha = (arb(7) / 6).sqrt()
    x1 = arb(x1q.numerator) / x1q.denominator
    X = arb(Xq)
    h1, H = x1 / s14, X / s14
    rs2 = 1 / acb(2).sqrt()
    isq2pi = 1 / (2 * acb.pi()).sqrt()
    inv2pi = 1 / (2 * acb.pi())
    Phi = lambda z: (-z * rs2).erfc() / 2
    phi = lambda z: isq2pi * (-(z * z) / 2).exp()
    PhiX, Phix1 = Phi(acb(X)), Phi(acb(x1))
    tol = dict(rel_tol=arb(2) ** -60, abs_tol=arb(2) ** -70)

    def real(z):
        assert z.imag.contains(0), z
        return z.real

    # I_Phi = int_{x1}^X phi(x) Phi(x/sqrt14) dx
    I_Phi = real(acb.integral(lambda x, an: phi(x) * Phi(x / s14), x1, X, **tol))
    # I_T = int_{x1}^X phi(x) T(x/sqrt14, beta) dx
    #     = (1/2pi) int_0^beta (1+t^2)^-1 k^-1/2 [Phi(sqrt(k) X) - Phi(sqrt(k) x1)] dt,  k = (15+t^2)/14
    def fT(t, an):
        sk = ((15 + t * t) / 14).sqrt(analytic=an)
        return (Phi(sk * X) - Phi(sk * x1)) / (sk * (1 + t * t))
    I_T = real(inv2pi * acb.integral(fT, 0, beta, **tol))
    # L(h1) = 3 A1 - 6 A2,  A1 = int_{-inf}^{h1} phi(h) Phi(beta h) dh  (cut at -40; integrand in [0, phi(h)]),
    # A2 = int_{-inf}^{h1} phi(h) T(beta h, alpha) dh = (1/2pi) int_0^alpha (1+t^2)^-1 l^-1/2 Phi(sqrt(l) h1) dt,
    # l = 1 + beta^2 (1+t^2) = (28 + 15 t^2)/13
    A1 = real(acb.integral(lambda h, an: phi(h) * Phi(beta * h), -40, h1, **tol))
    A1 = A1 + arb(0, ((arb(40) / arb(2).sqrt()).erfc() / 2).upper())

    def fA2(t, an):
        sl = ((28 + 15 * t * t) / 13).sqrt(analytic=an)
        return Phi(sl * h1) / (sl * (1 + t * t))
    A2 = real(inv2pi * acb.integral(fA2, 0, alpha, **tol))
    Lh1 = 3 * A1 - 6 * A2
    # I_L = int_{x1}^X phi(x) L(x/sqrt14) dx = (Phi(X) - Phi(x1)) L(h1) + 3 B1 - 6 B2, where for w(h) = Phi(X) - Phi(sqrt14 h)
    # B1 = int_{h1}^H phi(h) Phi(beta h) w(h) dh,  B2 = int_{h1}^H phi(h) T(beta h, alpha) w(h) dh
    B1 = real(acb.integral(lambda h, an: phi(h) * Phi(beta * h) * (PhiX - Phi(s14 * h)), h1, H, **tol))
    itol = dict(rel_tol=arb(2) ** -60, abs_tol=arb(2) ** -75, eval_limit=20000)

    def fB2(t, an):
        e = beta2 * (1 + t * t) / 2
        inner = acb.integral(lambda h, an2: phi(h) * (-(e * h * h)).exp() * (PhiX - Phi(s14 * h)), h1, H, **itol)
        return inner / (1 + t * t)
    B2 = real(inv2pi * acb.integral(fB2, 0, alpha, **tol))
    dP = real(PhiX - Phix1)
    I_L = dP * Lh1 + 3 * B1 - 6 * B2
    J = 6 * I_L - 4 * I_Phi + 16 * I_T - dP
    for name, v in [("I_Phi", I_Phi), ("I_T", I_T), ("A1", A1), ("A2", A2), ("L(h1)", Lh1), ("B1", B1), ("B2", B2),
                    ("I_L", I_L)]:
        pr(f"  {name:6s} = {v.str(20, radius=True)}")
    return J


def main():
    out = []
    pr = lambda s: (print(s, flush=True), out.append(s))
    t0 = time.time()
    x0 = float_checks(pr)
    x1q = Fraction(round(x0 * 10 ** 9), 10 ** 9)
    pr(f"rigorous part: x1 = {x1q} = {float(x1q):.9f}, X = 12")
    J = rigorous(x1q, pr=pr)
    pr(f"J >= int_x1^X gamma_q phi dx in {J.str(20, radius=True)}")
    lo = J.lower()
    man, ex = lo.man_exp()
    lo_q = Fraction(int(man)) * Fraction(2) ** int(ex)  # the lower endpoint, exactly

    def dec_down(v, d):
        n = math.floor(v * 10 ** d)
        return f"{n // 10 ** d}.{n % 10 ** d:0{d}d}"

    pr(f"lower endpoint, truncated: J > {dec_down(lo_q, 20)},  5/8 + J > {dec_down(Fraction(5, 8) + lo_q, 13)},  "
       f"5/8 + 3J/8 > {dec_down(Fraction(5, 8) + 3 * lo_q / 8, 13)}")
    assert lo > arb("3.1663998209e-4") and arb(5) / 8 + lo > arb("0.6253166") and arb(5) / 8 + 3 * lo / 8 > arb("0.6251187")
    assert lo_q > Fraction(31663998209, 10 ** 14) and Fraction(5, 8) + lo_q > Fraction(6253166, 10 ** 7) \
        and Fraction(5, 8) + 3 * lo_q / 8 > Fraction(6251187, 10 ** 7)
    pr("certified (Proposition 4.3): J > 3.1663998209e-4, s^U_E2 >= 5/8 + J > 0.6253166, "
       "s_E2 >= 5/8 + (3/8) J > 0.6251187  [asserted in exact arithmetic]")
    pr(f"time {time.time() - t0:.1f} s")
    with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "outputs", "e2_lower_rig.txt"), "w") as fh:
        fh.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
