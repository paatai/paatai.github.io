"""Numerical test of p-dependent level-one inequalities on the q-biased cube (floating point).

For f : {-1,1}^n -> [0,1] with E f = p, W^1(f) = sup_alpha T_p(L_alpha)^2, where L_alpha = sum alpha_i chi_i (unit alpha)
and T_p(L) = sup{E[f L] : 0 <= f <= 1, E f = p} is the upper-tail functional (fill mass p from the top atoms of L).
Tested inequality (needed for the one-class boundary orbit D12, q = 2/5):
    W^1(f) <= q p + ((1-2q)/q) p^2      for p <= q,
which is tight for the dictator (p = q) and for AND of two bits (p = q^2).
usage: python3 level1_profile_test.py q nmax restarts
"""
import itertools
import sys

import numpy as np
from scipy.optimize import minimize

q = float(eval(sys.argv[1])) if len(sys.argv) > 1 else 0.4
nmax = int(sys.argv[2]) if len(sys.argv) > 2 else 6
restarts = int(sys.argv[3]) if len(sys.argv) > 3 else 30
beta = (1 - 2 * q) / q
u, v = np.sqrt((1 - q) / q), np.sqrt(q / (1 - q))
rng = np.random.default_rng(0)


def atoms(n):
    pts = np.array(list(itertools.product([u, -v], repeat=n)))
    wts = np.prod(np.where(pts > 0, q, 1 - q), axis=1)
    return pts, wts


def tail(vals, wts, p):
    o = np.argsort(-vals)
    vs, ws = vals[o], wts[o]
    cw = np.cumsum(ws)
    k = np.searchsorted(cw, p)
    prev = cw[k - 1] if k > 0 else 0.0
    return float(np.dot(vs[:k], ws[:k]) + (p - prev) * vs[k]) if k < len(vs) else float(np.dot(vs, ws))


def excess(alpha, pts, wts, p):
    a = alpha / np.linalg.norm(alpha)
    t = tail(pts @ a, wts, p)
    return t * t - (q * p + beta * p * p)


ps = np.concatenate([np.linspace(0.005, q, 80), [q * q, q]])
worst = (-np.inf, None, None)
for n in range(1, nmax + 1):
    pts, wts = atoms(n)
    wn = -np.inf
    for p in ps:
        best = -np.inf
        starts = [np.eye(n)[0]] + [np.ones(n)] + [np.abs(rng.standard_normal(n)) * rng.random(n) ** 2 for _ in range(restarts)]
        for a0 in starts:
            r = minimize(lambda a: -excess(a, pts, wts, p), a0, method="Nelder-Mead",
                         options={"xatol": 1e-10, "fatol": 1e-13, "maxiter": 4000})
            best = max(best, -r.fun)
        if best > wn:
            wn = best
        if best > worst[0]:
            worst = (best, n, p)
    print(f"n={n}: max over p in (0,q] of W1 - (qp + beta p^2) = {wn:+.3e}", flush=True)
print(f"overall max excess {worst[0]:+.3e} at n={worst[1]}, p={worst[2]:.4f}")
