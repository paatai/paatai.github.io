"""Inspect optimal LP duals of the coupling LP (coupling_lp_J2.py) at given p for given candidates.

Prints the couplings (rho_*, rho', type) carrying dual mass, with type L (E[P P] >= 0, cost min(p^2,(1-p)^2)) or
U (E[P(1-P)] >= 0, cost p - p^2).
usage: python3 coupling_lp_dual.py p "x z y" ["x z y" ...]
"""
import sys
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import linprog

from fpp_test import params, sh

J = 12


def solve(hv, p, rhos, rhops):
    mu, pi, b, lam, qq = params(hv)
    nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    a = float(-lam[nus])
    lp_ = float(lam[-nus])
    idx = [(j, k) for j in range(J + 1) for k in range(J + 1) if (j, k) != (0, 0)]
    c = np.array([(-a) ** j * lp_ ** k for j, k in idx])
    pairs = [(r1, r2) for r1 in rhos for r2 in rhops]
    G = np.array([[r1 ** j * r2 ** k for j, k in idx] for r1, r2 in pairs])
    K = min(p * p, (1 - p) ** 2)
    Aub = np.vstack([-G, G])
    bub = np.concatenate([np.full(len(G), K), np.full(len(G), p - p * p)])
    sol = linprog(c, A_ub=Aub, b_ub=bub, bounds=(0, None), method='highs')
    duals = -sol.ineqlin.marginals
    val = -sol.fun
    phi = float(sh(hv, Fr(p).limit_denominator(10 ** 9))) - 4 * abs(float(b)) * val
    used = []
    for i, d in enumerate(duals):
        if d > 1e-9:
            typ = 'L' if i < len(G) else 'U'
            used.append((typ, pairs[i % len(G)], d))
    return phi, val, used, a, lp_


if __name__ == '__main__':
    p = float(sys.argv[1])
    for spec in sys.argv[2:]:
        xs, zs, ys = spec.split()
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        mu, pi, b, lam, qq = params(hv)
        nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
        q = float(qq[nus]); qp = float(qq[-nus])
        r, rp = q / (1 - q), qp / (1 - qp)
        rhos = np.unique(np.concatenate([np.linspace(-r, 0, 61), np.linspace(0, 1, 11)]))
        rhops = np.unique(np.concatenate([np.linspace(-rp, 0, 9), np.linspace(0, 1, 11), [float(lam[-nus])]]))
        phi, val, used, a, lp_ = solve(hv, p, rhos, rhops)
        print(f"h = ({xs}, {zs}, {zs}, {ys}), p = {p}: a = {a:.4f}, lambda' = {lp_:.4f}, r = {r:.4f}, r' = {rp:.4f}; "
              f"LP bracket = {val:.6f}, Phi_LP = {phi:+.6f}")
        for typ, (r1, r2), d in used:
            print(f"    {typ} rho_* = {r1:+.4f}, rho' = {r2:+.4f}: mass {d:.6f}")
