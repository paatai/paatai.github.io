"""First variation of Gamma_+ at the dictator decoder (k=1) for the boundary example g0 (exact)."""
import itertools
from fractions import Fraction as Fr
W = list(itertools.product([1, -1], repeat=3))
h = dict(zip(W, [Fr(-1), Fr(-1), Fr(-1), Fr(1, 2), Fr(0), Fr(-1, 2), Fr(-1, 2), Fr(-1, 2)]))
mu = sum(h.values()) / 8
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W} for b in (1, -1)}
flip = lambda w, j: tuple(-x if i == j else x for i, x in enumerate(w))
print('mu =', mu, ' Gamma_+(dictator) = E_{pi_+} h =', sum(pi[1][w] * h[w] for w in W),
      ' Gamma_-(dictator) =', sum(pi[-1][w] * h[w] for w in W))
for s in (1, -1):
    V = sum(pi[1][w] * (h[flip(w, j)] - h[w]) for w in W for j in range(3) if w[j] == s)
    print(f'label value s={s:+d}: sum_j E_pi+[1(w_j=s)(h(w^j)-h(w))] =', V)
