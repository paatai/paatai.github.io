"""Coupling LP bound for one class of size two (UNDEC candidates of maxcorr_J2.py, case eps = 1).

With P = (1+F)/2, p = E P and w_{jk} = sum of ||P_S||^2 over S with |S cap R_*| = j, |S cap R'| = k:
  sigma Gamma = sigma h(2p-1,2p-1) + 4|b| sum_{(j,k) != 0} c_{jk} w_{jk},   c_{jk} = (-a)^j lambda'^k.
Constraints used (valid for every [0,1]-valued P): for every product coupling with correlation rho_* on the R_* rows
(rho_* in [-r, 1], r = q/(1-q)) and rho' on the R' rows (rho' in [-r', 1]):
  E[P(x)P(y)] >= 0, E[(1-P(x))(1-P(y))] >= 0, E[P(x)(1-P(y))] >= 0, i.e.
  -min(p^2, (1-p)^2) <= sum rho_*^j rho'^k w_{jk} <= p - p^2.
LP(p) = max of -sum c w subject to these (grid of couplings, truncation j, k <= J).
"""
import sys
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import linprog

from fpp_test import UNDEC, params, sh

J = 9
NG = 25


def lp_bound(hv, ps):
    mu, pi, b, lam, qq = params(hv)
    nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    a = float(-lam[nus])
    lp_ = float(lam[-nus])
    q = float(qq[nus])
    qp = float(qq[-nus])
    r, rp = q / (1 - q), qp / (1 - qp)
    idx = [(j, k) for j in range(J + 1) for k in range(J + 1) if (j, k) != (0, 0)]
    c = np.array([(-a) ** j * lp_ ** k for j, k in idx])
    rhos = np.concatenate([np.linspace(-r, 0, NG), np.linspace(0, 1, 6)[1:]])
    rhops = np.concatenate([np.linspace(-rp, 0, 8), np.linspace(0, 1, 6)[1:]])
    rows = []
    for r1 in rhos:
        for r2 in rhops:
            rows.append([r1 ** j * r2 ** k for j, k in idx])
    G = np.array(rows)
    res = []
    for p in ps:
        K = min(p * p, (1 - p) ** 2)
        Aub = np.vstack([-G, G])
        bub = np.concatenate([np.full(len(G), K), np.full(len(G), p - p * p)])
        sol = linprog(c, A_ub=Aub, b_ub=bub, bounds=(0, None), method='highs')
        val = -sol.fun
        res.append(float(sh(hv, Fr(p).limit_denominator(10 ** 9))) - 4 * abs(float(b)) * val)
    return np.array(res)


if __name__ == '__main__':
    ps = np.linspace(0.005, 0.995, int(sys.argv[1]) if len(sys.argv) > 1 else 100)
    for xs, zs, ys in UNDEC:
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        v = lp_bound(hv, ps)
        i = v.argmin()
        print(f"h = ({xs}, {zs}, {zs}, {ys}): min Phi_LP = {v[i]:+.6f} at p = {ps[i]:.4f}", flush=True)
