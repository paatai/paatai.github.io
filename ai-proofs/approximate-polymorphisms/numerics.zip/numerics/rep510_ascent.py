"""rep5 and rep10: alternating maximisation of Gamma_nu(F_p, F_s) for larger k (floating point).

Gamma = E h(F_p(X1), F_p(X2), F_s(X3)) for the Table 1 representative (mu < 0, so a certificate of nontriviality is
Gamma > 0). For fixed F_s, Gamma is a quadratic form in the vector F_p, and each step maximises it exactly in one value
F_p(z) on [-1,1]; for fixed F_p, F_s is set to the best response sgn E[l(F_p(X1),F_p(X2)) | X3] (rep510_exact.py), so the
values found are values of the one-function forms L - R of rep510_exact.py (times 2). The joint law of the three columns is
the Kronecker product of the row laws. Starts: constants, the dictator, the AND of two labels, 1{z = (1,-1)}, their negations,
random decoders, and the four best decoders found for k - 1 labels, lifted by an extra row that they ignore (so the maxima
found are nondecreasing in k); every nu up to the order of the rows.
usage: python3 rep510_ascent.py NAME KMIN KMAX RESTARTS SEED      (NAME = rep5 or rep10)
Optional: OBJ="8 numbers" replaces the objective 2h by another vertex function (row laws still from NAME); positive control:
OBJ="0 -1 -1 0 1 -2 0 -1" (rep5 with the majorant h + 1_{+++}, which fails at k = 3 with max about 0.012).
"""
import itertools
import os
import sys

import numpy as np

W3 = list(itertools.product([1, -1], repeat=3))
REPS = {"rep5": [-2, -1, -1, 0, 1, -2, 0, -1], "rep10": [-1, -2, 0, 0, 1, -1, -1, 0]}


def setup(name, obj=None):
    h = np.array(REPS[name], float) / 2
    mu = h.mean()
    laws = {b: ((1 + b * h) / (8 * (1 + b * mu))).reshape(2, 2, 2) for b in (1, -1)}
    f = h if obj is None else np.array(obj, float) / 2
    coef = {}
    for S in itertools.product((0, 1), repeat=3):
        coef[S] = np.mean([hv * np.prod([w[j] for j in range(3) if S[j]]) for hv, w in zip(f, W3)])
    return laws, coef


def tensor(laws, nu):
    T = np.ones((1, 1, 1))
    for b in nu:
        n = T.shape[0]
        T = np.einsum("abc,def->adbecf", T, laws[b]).reshape(2 * n, 2 * n, 2 * n)
    return T


class Problem:
    def __init__(self, T, c):
        self.T, self.c = T, c
        self.M12, self.M13, self.M23 = T.sum(2), T.sum(1), T.sum(0)
        self.m1, self.m2, self.m3 = T.sum((1, 2)), T.sum((0, 2)), T.sum((0, 1))

    def value(self, a, b):
        c, T = self.c, self.T
        return (c[0, 0, 0] + c[1, 0, 0] * self.m1 @ a + c[0, 1, 0] * self.m2 @ a + c[0, 0, 1] * self.m3 @ b
                + c[1, 1, 0] * a @ self.M12 @ a + c[1, 0, 1] * a @ self.M13 @ b + c[0, 1, 1] * a @ self.M23 @ b
                + c[1, 1, 1] * np.einsum("xyz,x,y,z->", T, a, a, b))

    def best_b(self, a):
        c = self.c
        g = (c[0, 0, 1] * self.m3 + c[1, 0, 1] * self.M13.T @ a + c[0, 1, 1] * self.M23.T @ a
             + c[1, 1, 1] * np.einsum("xyz,x,y->z", self.T, a, a))
        return np.where(g >= 0, 1.0, -1.0)

    def ascend_a(self, a, b, sweeps=60):
        c = self.c
        Q = c[1, 1, 0] * self.M12 + c[1, 1, 1] * (self.T @ b)
        S = (Q + Q.T) / 2
        lin = c[1, 0, 0] * self.m1 + c[0, 1, 0] * self.m2 + c[1, 0, 1] * self.M13 @ b + c[0, 1, 1] * self.M23 @ b
        a = a.copy()
        g = lin + 2 * S @ a
        diag = np.diag(S)
        for _ in range(sweeps):
            moved = 0.0
            for z in range(len(a)):
                s, beta = diag[z], g[z] - 2 * diag[z] * a[z]
                cands = [-1.0, 1.0]
                if s < 0:
                    cands.append(min(1.0, max(-1.0, -beta / (2 * s))))
                t = max(cands, key=lambda u: s * u * u + beta * u)
                if t != a[z]:
                    g += 2 * S[:, z] * (t - a[z])
                    moved = max(moved, abs(t - a[z]))
                    a[z] = t
            if moved < 1e-12:
                break
        return a

    def run(self, a, iters=200):
        b = self.best_b(a)
        val = self.value(a, b)
        for _ in range(iters):
            a = self.ascend_a(a, b)
            b = self.best_b(a)
            new = self.value(a, b)
            if new <= val + 1e-14:
                val = max(val, new)
                break
            val = new
        return val, a, b


def starts(k, rng, restarts):
    pts = np.array(list(itertools.product([1, -1], repeat=k)), float).reshape(-1, k)
    out = [np.full(2 ** k, 1.0), np.full(2 ** k, -1.0)]
    if k >= 1:
        out += [pts[:, 0].copy(), -pts[:, 0]]
    if k >= 2:
        and2 = np.where((pts[:, 0] == 1) & (pts[:, 1] == 1), 1.0, -1.0)
        mix = np.where((pts[:, 0] == 1) & (pts[:, 1] == -1), 1.0, -1.0)
        out += [and2, -and2, mix, -mix]
    for _ in range(restarts):
        out.append(rng.uniform(-1, 1, 2 ** k))
        out.append(rng.choice([-1.0, 1.0], 2 ** k))
    return out


def main():
    name = sys.argv[1]
    kmin, kmax = int(sys.argv[2]), int(sys.argv[3])
    restarts = int(sys.argv[4]) if len(sys.argv) > 4 else 6
    rng = np.random.default_rng(int(sys.argv[5]) if len(sys.argv) > 5 else 0)
    obj = [int(x) for x in os.environ["OBJ"].split()] if "OBJ" in os.environ else None
    laws, coef = setup(name, obj)
    if obj is not None:
        print(f"objective 2h' = {obj} (row laws from {name})")
    c = np.zeros((2, 2, 2))
    for S, v in coef.items():
        c[S] = v
    print(f"{name}: mu = {coef[(0, 0, 0)]:.6f}; level-one coefficients {[coef[(1, 0, 0)], coef[(0, 1, 0)], coef[(0, 0, 1)]]}")
    overall = -np.inf
    keep = {}
    for k in range(kmin, kmax + 1):
        for npos in range(k, -1, -1):
            nu = (1,) * npos + (-1,) * (k - npos)
            prob = Problem(tensor(laws, nu), c)
            lifted = [np.repeat(a, 2) for a in keep.get((k - 1, npos), [])]
            lifted += [np.concatenate([a, a]) for a in keep.get((k - 1, npos - 1), [])]
            found = []
            for a0 in starts(k, rng, restarts) + lifted:
                val, a, b = prob.run(a0)
                found.append((val, a))
            found.sort(key=lambda t: -t[0])
            keep[(k, npos)] = [a for _, a in found[:4]]
            best = found[0][0]
            overall = max(overall, best)
            print(f"k={k} nu=(+{npos},-{k - npos}): max Gamma found {best:.3e} ({len(found)} starts, {len(lifted)} lifted)",
                  flush=True)
    print(f"overall max Gamma found: {overall:.3e}")


if __name__ == "__main__":
    main()
