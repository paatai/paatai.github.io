"""Exploration (floating point): recursive split lower bound for inf E[P(X) P(Z)], one class of size two, eps = 1.

Rows of the dangerous sign nu_*: P(X_r = c, Z_r = c) = s = q^2 - a q (1-q), P(c, cbar) = q - s, P(cbar, cbar) = 1 - 2q + s.
If P depends on some row of sign nu_*, splitting on it gives
  E[P(X)P(Z)] = s E[Pc Pc'] + 2 (q - s) E[Pc(X) Pcb(Z)] + (1 - 2q + s) E[Pcb Pcb'],   p = q u + (1-q) v,
where u, v are the means of Pc, Pcb (functions of the other rows).  Otherwise all lambda_S >= 0 and E[PP] >= p^2.
Diagonal terms: induction (L_d); cross term: E[f(X) g(Z)] >= max(0, uv - rho sqrt(u(1-u) v(1-v))) with
rho = max(a, lambda') the maximal correlation of the columns.  Base L_0(p) = p^2 - V#(p) (Proposition 10.6).
  L_{d+1}(p) = max(L_0(p), min(p^2, min_u [s L_d(u) + 2(q-s) C(u, v) + (1-2q+s) L_d(v)])).
Reports min_p of phi(p) + 4|b| (L_d(p) - p^2) for d = 0, 1, 2, ...
usage: python3 split_bound.py depth "x z y" ["x z y" ...]
"""
import sys
from fractions import Fraction as Fr

import numpy as np

depth = int(sys.argv[1])
specs = sys.argv[2:]
sys.argv = sys.argv[:1] + ['6']
import maxcorr_J2 as M  # noqa: E402
from fsharp_check import params  # noqa: E402

N = 2001
P = np.linspace(0, 1, N)


def run(spec):
    xs, zs, ys = spec.split()
    hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
    mu, b, lam, qq = params(hv)
    nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    a, q, lp = float(-lam[nus]), float(qq[nus]), float(lam[-nus])
    r = q / (1 - q)
    th = float(M.theta_lo(-lam[nus], qq[nus] / (1 - qq[nus])))
    s = q * q - a * q * (1 - q)
    sb = 1 - 2 * q + s
    rho = max(a, lp)
    Vs = a * np.minimum(P * (1 - P), th * P * (1 - P) + (1 - th) / r * np.minimum(P, 1 - P) ** 2)
    L0 = P ** 2 - Vs
    phi = np.array([float(-M.hml(hv, Fr(2 * p - 1).limit_denominator(10 ** 7), Fr(2 * p - 1).limit_denominator(10 ** 7)))
                    for p in P])
    B = 4 * abs(float(b))
    out = [f"h = ({xs}, {zs}, {ys}): a={a:.4f}, q={q:.4f}, lambda'={lp:.4f}, theta={th:.4f}"]
    L = L0.copy()
    for d in range(depth + 1):
        val = phi + B * (L - P ** 2)
        i = int(np.argmin(val))
        out.append(f"  depth {d}: min {val[i]:+.4e} at p={P[i]:.4f}")
        if d == depth:
            break
        newL = L0.copy()
        for k, p in enumerate(P):
            u = P[(P * q <= p + 1e-15) & (P * q >= p - (1 - q) - 1e-15)]
            if len(u) == 0:
                continue
            v = np.clip((p - q * u) / (1 - q), 0, 1)
            Lu = np.interp(u, P, L)
            Lv = np.interp(v, P, L)
            C = np.maximum(0, u * v - rho * np.sqrt(np.maximum(u * (1 - u) * v * (1 - v), 0)))
            split = np.min(s * Lu + 2 * (q - s) * C + sb * Lv)
            newL[k] = max(L0[k], min(p * p, split))
        L = newL
    return "\n".join(out)


if __name__ == '__main__':
    for spec in specs:
        print(run(spec), flush=True)
