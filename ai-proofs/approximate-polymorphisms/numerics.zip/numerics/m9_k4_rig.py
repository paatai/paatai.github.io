"""Rigorous version of m9_k4_scan.py: for the 17 pairs of one-class |J| = 2 candidates left open at m = 9 (one of each mirror
pair), every [-1,1]-valued decoder with k labels has Gamma_nu(F) < 0, for every nu.  Default k = 4.

Gamma_nu(F) = c0 + lin . F + F^T Q F (j2_k2_exact.quad_form) is multiplied by the common denominator D of its coefficients, so
that c0, lin, Q are integers; all of them, and every partial sum below, are smaller than 2^52 in modulus, so the constant parts
base(A) = c0 + lin_X . A + A^T Q_XX A and the vectors b(A) = lin_F + 2 Q_FX A are computed exactly in double precision.
The maximum over [-1,1]^n (n = 2^k) is attained at a vertex or at the critical point S = -H^{-1} b(A), H = 2 Q_FF, of the
restriction to the relative interior of a face (free set F, fixed coordinates X = A) with nonsingular H; there the value is
base(A) + b(A) . S / 2.  For every free set:
  * R = inv(H) in floating point, and alpha >= ||I - R H||_inf is bounded rigorously (rounding of the products bounded by
    gamma_f |R| |H|, gamma_f = f u / (1 - f u), u = 2^-53).  If alpha < 1/2 then H is nonsingular,
    ||H^{-1} - R||_inf <= 2 alpha ||R||_inf, and for every assignment |S - fl(-R b)| <= 2 alpha ||R||_inf ||b||_inf + gamma_f |R||b|
    componentwise.  A critical point is discarded if this bound puts it outside [-1,1]^f; otherwise an upper bound for its
    value is computed and must be negative.  Points for which neither test succeeds are re-checked exactly (python-flint).
  * If alpha >= 1/2 (or R is not finite) the block is treated exactly: det H = 0 means the block is singular and the face is
    skipped (its maximum is attained on its relative boundary); otherwise S and the value are computed exactly from the adjugate.
Vertices are checked exactly.  Floating point is IEEE double with round-to-nearest; the matrix products are classical (any
order of summation), for which the gamma_f bounds hold.

usage: python3 m9_k4_rig.py [k=4] [workers=8] ["x z y" ...]   (default: the 17 pairs of m9_k4_scan.py)
"""
import itertools
import sys
import time
from fractions import Fraction as Fr
from math import lcm
from multiprocessing import Pool

import numpy as np
from flint import fmpq_mat, fmpz_mat

from j2_k2_exact import quad_form
from m9_k4_scan import CANDS

U = 2.0 ** -53


def gam(f):
    return f * U / (1 - f * U)


def integer_form(c0, lin, Q):
    D = lcm(c0.denominator, *(v.denominator for v in lin), *(v.denominator for row in Q for v in row))
    c0i = int(c0 * D)
    lini = [int(v * D) for v in lin]
    Qi = [[int(v * D) for v in row] for row in Q]
    assert c0i == c0 * D and all(a == b * D for a, b in zip(lini, lin))
    assert all(a == b * D for ra, rb in zip(Qi, Q) for a, b in zip(ra, rb))
    total = abs(c0i) + sum(abs(v) for v in lini) + 2 * sum(abs(v) for row in Qi for v in row)
    assert total < 2 ** 52, total
    return D, c0i, lini, Qi


def exact_columns(Hint, Bint, baseint):
    """Exact check of the critical points for the columns of Bint (lists of Python ints).  Returns (singular, values) where
    values lists the exact values (as Fractions) of the critical points that lie in the open cube."""
    Hf = fmpz_mat(Hint)
    d = int(Hf.det())
    if d == 0:
        return True, []
    adj = fmpq_mat(Hf).inv() * d
    f = len(Hint)
    adj = [[int(adj[i, j]) for j in range(f)] for i in range(f)]
    out = []
    for col, base in zip(Bint, baseint):
        num = [-sum(adj[i][j] * col[j] for j in range(f)) for i in range(f)]
        if all(abs(v) < abs(d) for v in num):
            out.append(Fr(base) + Fr(sum(col[i] * num[i] for i in range(f)), 2 * d))
    return False, out


def enclosure(H, B):
    """For an integer-valued f x f block H and integer-valued columns B (all exact in double precision): None if the block is
    not certified, else (S, eS) with |(-H^{-1} B) - S| <= eS entrywise (and H nonsingular)."""
    f = len(H)
    g = gam(f)
    with np.errstate(all='ignore'):
        try:
            R = np.linalg.inv(H)
        except np.linalg.LinAlgError:
            return None
        if not np.all(np.isfinite(R)):
            return None
        absR = np.abs(R)
        E = np.eye(f) - R @ H
        alpha = float(np.max(np.abs(E).sum(axis=1) + 2 * g * (absR @ np.abs(H)).sum(axis=1))) * (1 + 1e-10)
        if not (np.isfinite(alpha) and alpha < 0.5):
            return None
    normR = float(absR.sum(axis=1).max()) * (1 + 1e-10)
    S = -(R @ B)
    nb = np.abs(B).max(axis=0)
    eS = (2 * alpha * normR * nb[None, :] + 2 * g * (absR @ np.abs(B))) * (1 + 1e-10)
    if not (np.all(np.isfinite(S)) and np.all(np.isfinite(eS))):
        return None
    return S, eS


def value_upper(base, B, S, eS):
    """Upper bound for base + b . S_true / 2 (the value at the critical point), given |S_true - S| <= eS."""
    bS = np.einsum('ic,ic->c', B, S)
    t1 = np.einsum('ic,ic->c', np.abs(B), eS)
    t2 = np.einsum('ic,ic->c', np.abs(B), np.abs(S))
    return base + 0.5 * bS + 0.5 * t1 + 1e-12 * (np.abs(base) + np.abs(bS) + t1 + t2 + 1)


def float_data(c0i, lini, Qi):
    n = len(lini)
    assigns = {m: np.array(list(itertools.product((-1.0, 1.0), repeat=m))).T.reshape(m, 2 ** m) for m in range(n + 1)}
    return float(c0i), np.array(lini, dtype=float), np.array(Qi, dtype=float), assigns


def face_data(c0, lin, Q, assigns, mask):
    n = len(lin)
    free = [a for a in range(n) if mask >> a & 1]
    fixed = [a for a in range(n) if not mask >> a & 1]
    A = assigns[len(fixed)]
    base = c0 + lin[fixed] @ A + np.einsum('ic,ij,jc->c', A, Q[np.ix_(fixed, fixed)], A)
    H = 2 * Q[np.ix_(free, free)]
    B = lin[free][:, None] + 2 * Q[np.ix_(free, fixed)] @ A
    return free, base, H, B


def certify(c0i, lini, Qi):
    n = len(lini)
    c0, lin, Q, assigns = float_data(c0i, lini, Qi)
    stats = dict(singular=0, exact_masks=0, exact_cols=0, outside=0, checked=0)
    ub = -np.inf
    exact_vals = []
    for mask in range(2 ** n):
        free, base, H, B = face_data(c0, lin, Q, assigns, mask)
        if not free:
            assert np.all(base == np.round(base))
            ub = max(ub, float(base.max()))
            continue
        enc = enclosure(H, B)
        if enc is None:
            stats['exact_masks'] += 1
            Hint = [[int(v) for v in row] for row in H]
            singular, vals = exact_columns(Hint, [[int(v) for v in col] for col in B.T], [int(v) for v in base])
            if singular:
                stats['singular'] += 1
            exact_vals += vals
            continue
        S, eS = enc
        outside = np.any(np.abs(S) - eS > 1 + 1e-9, axis=0)
        stats['outside'] += int(outside.sum())
        keep = ~outside
        if not keep.any():
            continue
        Bk, basek = B[:, keep], base[keep]
        Vub = value_upper(basek, Bk, S[:, keep], eS[:, keep])
        stats['checked'] += int(keep.sum())
        bad = ~(Vub < 0)
        if bad.any():
            stats['exact_cols'] += int(bad.sum())
            Hint = [[int(v) for v in row] for row in H]
            cols = [[int(v) for v in col] for col in Bk[:, bad].T]
            singular, vals = exact_columns(Hint, cols, [int(v) for v in basek[bad]])
            assert not singular
            exact_vals += vals
            if (~bad).any():
                ub = max(ub, float(Vub[~bad].max()))
        else:
            ub = max(ub, float(Vub.max()))
    exact_max = max(exact_vals) if exact_vals else None
    return ub, exact_max, stats


def task(args):
    spec, nu = args
    hv = (Fr(spec[0]), Fr(spec[1]), Fr(spec[1]), Fr(spec[2]))
    c0, lin, Q = quad_form(hv, nu)
    D, c0i, lini, Qi = integer_form(c0, lin, Q)
    t = time.time()
    ub, exact_max, stats = certify(c0i, lini, Qi)
    return spec, nu, D, ub, exact_max, stats, time.time() - t


if __name__ == '__main__':
    k = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    cands = [tuple(s.split()) for s in sys.argv[3:]] or CANDS
    print(f"m9_k4_rig.py k={k}: rigorous face enumeration over [-1,1]-valued decoders, {len(cands)} candidates, "
          f"nu = (+^a, -^(k-a)), a = k..0", flush=True)
    jobs = [(spec, tuple([1] * npos + [-1] * (k - npos))) for spec in cands for npos in range(k, -1, -1)]
    t0 = time.time()
    overall, positive = {}, []
    with Pool(workers) as pool:
        for spec, nu, D, ub, exact_max, stats, dt in pool.imap(task, jobs):
            m = ub if exact_max is None else max(ub, exact_max)
            overall[spec] = max(overall.get(spec, -np.inf), m / D)
            if m >= 0:
                positive.append((spec, nu))
            em = 'none' if exact_max is None else f"{float(exact_max / D):+.6e}"
            print(f"h = ({spec[0]}, {spec[1]}, {spec[1]}, {spec[2]}) k={k} nu={''.join('+' if v > 0 else '-' for v in nu)}: "
                  f"points bounded in floating point: Gamma <= {ub / D:+.6e}; largest exact value {em}; "
                  f"singular blocks {stats['singular']}, "
                  f"exact blocks {stats['exact_masks']}, exact points {stats['exact_cols']}, discarded {stats['outside']}, "
                  f"bounded {stats['checked']}  [{dt:.0f} s]", flush=True)
    for spec in cands:
        print(f"h = ({spec[0]}, {spec[1]}, {spec[1]}, {spec[2]}): certified upper bound over nu, k = {k}: "
              f"{overall[spec]:+.6e}", flush=True)
    if positive:
        print(f"NOT CERTIFIED (a vertex or critical point with Gamma >= 0): {positive}", flush=True)
    else:
        print(f"certified: Gamma_nu(F) < 0 for every [-1,1]-valued decoder with k = {k}, every nu and all {len(cands)} "
              f"candidates; largest upper bound {max(overall.values()):+.6e}  [{time.time() - t0:.0f} s]", flush=True)
