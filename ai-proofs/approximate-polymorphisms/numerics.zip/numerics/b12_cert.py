"""Exact check of the seven-column one-class coupling certificate for B12 (Proposition "B12" in Section 11 of MAIN_RESULT.tex):
B12 is trivial, i.e. Gamma_nu(F) <= 0 for all k, nu and F.

h = h_B12, h' = h (no raise), mu = -1/4.  Columns U0..U6, one decoder F on all of them.
  copies of the row (u_a, u_c, u_e) ~ (w1, w2, w3):  (U0,U1,U2), (U0,U3,U2), (U6,U1,U2), (U6,U3,U2);
  further pairs with the law L1 of (w1,w2) (= law of (w1,w3)):  (U1,U3), (U0,U4), (U2,U4), (U4,U5), (U2,U5), (U5,U6);
  32R = -8 - 2(y0+y1+y3+y4+y5+y6) - (1-y2)(y0+y6)(y1+y3) - 2(y1y3 + y0y4 + y2y4 + y4y5 + y2y5 + y5y6).
Checks (exact rational arithmetic): rho_+- are probability laws with all assigned marginals (columns, pairs, copies) equal to
those of pi_+-; the coefficients of R aggregated by law equal those of h (so Gamma_nu(F) = E[R(F(U0), ..., F(U6))]); R <= 0 at
all 128 vertices with R = 0 on supp rho_+; the displayed form of R and the elimination of y4, y5 used in the proof; exact random
tests Gamma_nu(F) = E[R] <= 0 for decoders with k <= 3 (all nu), enumerating the rows over the supports of pi_+- and rho_+-.
usage: python3 b12_cert.py [tests_per_nu] [seed]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

from oneclass_certs import W3, check, eval_chi, mlin

N = 7
RHO_PLUS = {s: Fr(1, 12) for s in ('++---+-', '+-+---+', '+--+-+-', '+---+-+', '+----++', '-++-+--', '-++----', '-+-+++-',
                                   '-+--+-+', '--++-+-', '--++---', '---++-+')}
RHO_MINUS = {s: Fr(c, 40) for s, c in (('+++++++', 2), ('+++++--', 1), ('++++-+-', 1), ('+++-+++', 2), ('+++-+--', 2),
                                       ('++-++++', 3), ('++-++-+', 3), ('+-++--+', 3), ('+-++---', 1), ('+-+--+-', 2),
                                       ('+---+-+', 1), ('+-----+', 1), ('-++-+++', 4), ('-+-+---', 4), ('--+++++', 3),
                                       ('--++---', 1), ('----+--', 1), ('-----+-', 5))}
L1, L2 = (0, 1), (1, 2)
PAIRS = {(0, 1): L1, (0, 3): L1, (1, 6): L1, (3, 6): L1, (0, 2): L1, (2, 6): L1, (1, 2): L2, (2, 3): L2,
         (1, 3): L1, (0, 4): L1, (2, 4): L1, (4, 5): L1, (2, 5): L1, (5, 6): L1}
COPIES = [((0, 1, 2), (0, 1, 2)), ((0, 3, 2), (0, 1, 2)), ((6, 1, 2), (0, 1, 2)), ((6, 3, 2), (0, 1, 2))]
h32 = {(): -8, (0,): -2, (1,): -2, (3,): -2, (4,): -2, (5,): -2, (6,): -2,
       (0, 1): -1, (0, 3): -1, (1, 6): -1, (3, 6): -1,
       (1, 3): -2, (0, 4): -2, (2, 4): -2, (4, 5): -2, (2, 5): -2, (5, 6): -2,
       (0, 1, 2): 1, (0, 2, 3): 1, (1, 2, 6): 1, (2, 3, 6): 1}
R16 = {S: Fr(c, 2) for S, c in h32.items()}


def R32(y):
    return sum(c * eval_chi(S, y) for S, c in h32.items())


def main():
    ntests = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    h, hp, pi, rho, R, _ = check('B12 (seven columns, four copies)', [-2, -1, -1, 1, 0, 0, 0, -1], {}, N, PAIRS, COPIES, R16,
                                 RHO_PLUS, RHO_MINUS,
                                 'L1 on 12 pairs (coefficient sum -1/2), L2 only inside copies (coefficient 0), cubic 1/8')
    for b in (1, -1):
        print(f"  supp rho_{'+' if b == 1 else '-'}: {sum(1 for p in rho[b].values() if p > 0)} points")
    U = list(itertools.product((1, -1), repeat=N))
    for y in U:
        y0, y1, y2, y3, y4, y5, y6 = y
        form = -8 - 2 * (y0 + y1 + y3 + y4 + y5 + y6) - (1 - y2) * (y0 + y6) * (y1 + y3) \
            - 2 * (y1 * y3 + y0 * y4 + y2 * y4 + y4 * y5 + y2 * y5 + y5 * y6)
        assert form == R32(y) == 32 * sum(c * eval_chi(S, y) for S, c in R.items())
    print("  32R = -8 - 2(y0+y1+y3+y4+y5+y6) - (1-y2)(y0+y6)(y1+y3) - 2(y1y3+y0y4+y2y4+y4y5+y2y5+y5y6) at all vertices")
    # elimination of y4, y5: max over y4, y5 of -2(y4 + y5 + y0y4 + y2y4 + y4y5 + y2y5 + y5y6) = 2 max(|a+c|-1, |a-c|+1),
    # a = 1+y0+y2, c = 1+y2+y6; then the case analysis on y2 and s = y0+y6, t = y1+y3.
    for y0, y1, y2, y3, y6 in itertools.product((1, -1), repeat=5):
        a, c = 1 + y0 + y2, 1 + y2 + y6
        best = max(-2 * (y4 + y5 + y0 * y4 + y2 * y4 + y4 * y5 + y2 * y5 + y5 * y6)
                   for y4, y5 in itertools.product((1, -1), repeat=2))
        assert best == 2 * max(abs(a + c) - 1, abs(a - c) + 1)
        s, t = y0 + y6, y1 + y3
        m = max(R32((y0, y1, y2, y3, y4, y5, y6)) for y4, y5 in itertools.product((1, -1), repeat=2))
        if y2 == 1 or s == 0:
            assert m == -t * (2 + t)
        elif s == 2:
            assert m == -8 - 6 * t - t * t
        else:
            assert m == t * (2 - t)
    print("  max over y4,y5 of 32R: -t(2+t) if y2 = 1 or s = 0; -8-6t-t^2 if y2 = -1, s = 2; t(2-t) if y2 = -1, s = -2")
    # exact random tests over the supports
    supp = {b: [(u, p) for u, p in rho[b].items() if p > 0] for b in (1, -1)}
    psupp = {b: [(w, p) for w, p in pi[b].items() if p > 0] for b in (1, -1)}
    worst, count = None, 0
    for k in range(1, 4):
        Z = list(itertools.product((1, -1), repeat=k))
        for nu in itertools.product((1, -1), repeat=k):
            for _ in range(ntests):
                if rng.random() < 0.3:
                    G = {z: Fr(rng.choice((-1, 1))) for z in Z}
                else:
                    G = {z: Fr(rng.randint(-7, 7), 7) for z in Z}
                gam = Fr(0)
                for rows in itertools.product(*[psupp[b] for b in nu]):
                    p = Fr(1)
                    for _, q in rows:
                        p *= q
                    y = [G[tuple(rows[i][0][j] for i in range(k))] for j in range(3)]
                    gam += p * mlin(h, y)
                ER = Fr(0)
                for rows in itertools.product(*[supp[b] for b in nu]):
                    p = Fr(1)
                    for _, q in rows:
                        p *= q
                    y = [G[tuple(rows[i][0][a] for i in range(k))] for a in range(N)]
                    ER += p * sum(cc * eval_chi(S, y) for S, cc in R.items())
                assert gam == ER <= 0, (k, nu, gam, ER)
                worst = ER if worst is None else max(worst, ER)
                count += 1
    print(f"  exact random tests ({count} decoders, k <= 3, all nu): Gamma = E[R] <= 0 always; largest value {worst}")


if __name__ == '__main__':
    main()
