"""Coordinate-ascent search for single-decoder certificates for a one-class h on {+-1}^2 (|J| = 2).

h is given by its four vertex values (order ++, +-, -+, --) as fractions, normalised to mu < 0 (certificate:
Gamma > 0).  For every k <= kmax and every nu, maximises Gamma_nu(F) = E h(F(C_1), F(C_2)) over
F : {+-1}^k -> [-1,1] (Gamma is quadratic in each value F(z)), from the dictator, random continuous and random
Boolean starts.  Floating point; used as a sanity check of Theorem F and to probe undecided cases.
usage: python3 j2_ascent.py "x z z y" kmax restarts seed
"""
import itertools
import sys
from fractions import Fraction

import numpy as np

hv = [float(Fraction(s)) for s in sys.argv[1].replace(",", " ").split()]
kmax = int(sys.argv[2]) if len(sys.argv) > 2 else 6
restarts = int(sys.argv[3]) if len(sys.argv) > 3 else 10
rng = np.random.default_rng(int(sys.argv[4]) if len(sys.argv) > 4 else 0)
if sum(hv) > 0:
    hv = [-v for v in hv]
W2 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]
mu = sum(hv) / 4
pi = {b: [(1 + b * hv[i]) / (4 * (1 + b * mu)) for i in range(4)] for b in (1, -1)}


def hml(y1, y2):
    x, z, _, y = hv
    return (x * (1 + y1) * (1 + y2) + z * (1 + y1) * (1 - y2) + z * (1 - y1) * (1 + y2) + y * (1 - y1) * (1 - y2)) / 4


def setup(nu):
    k = len(nu)
    cols, probs = [], []
    for rows in itertools.product(range(4), repeat=k):
        p = np.prod([pi[nu[i]][rows[i]] for i in range(k)])
        if p == 0:
            continue
        c = []
        for j in range(2):
            v = 0
            for i in range(k):
                v = 2 * v + (W2[rows[i]][j] == -1)
            c.append(v)
        cols.append(c)
        probs.append(p)
    return np.array(cols), np.array(probs)


def gamma(F, cols, probs):
    return probs @ hml(F[cols[:, 0]], F[cols[:, 1]])


def ascent(F, cols, probs, sweeps=200):
    nz = len(F)
    occ = [np.nonzero((cols == z).any(axis=1))[0] for z in range(nz)]
    ts = np.array([-1.0, 0.0, 1.0])
    V = np.vander(ts, 3)
    for _ in range(sweeps):
        changed = 0.0
        for z in rng.permutation(nz):
            I = occ[z]
            if len(I) == 0:
                continue
            c2, p2 = cols[I], probs[I]
            vals = []
            for t in ts:
                G = F.copy()
                G[z] = t
                vals.append(p2 @ hml(G[c2[:, 0]], G[c2[:, 1]]))
            a, b, c = np.linalg.solve(V, np.array(vals))
            cand = [-1.0, 1.0] + ([float(np.clip(-b / (2 * a), -1, 1))] if a != 0 else [])
            tb = max(cand, key=lambda t: a * t * t + b * t + c)
            changed = max(changed, abs(tb - F[z]))
            F[z] = tb
        if changed < 1e-12:
            break
    return F


print(f"h = {hv}, mu = {mu:+.4f}", flush=True)
overall = -np.inf
for k in range(1, kmax + 1):
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        cols, probs = setup(nu)
        starts = [np.array([1.0 if (z >> (k - 1)) & 1 == 0 else -1.0 for z in range(2 ** k)])]
        starts += [rng.uniform(-1, 1, 2 ** k) for _ in range(restarts)]
        starts += [rng.choice([-1.0, 1.0], 2 ** k) for _ in range(restarts)]
        best, bestF = -np.inf, None
        for F0 in starts:
            F = ascent(F0.copy(), cols, probs)
            v = gamma(F, cols, probs)
            if v > best:
                best, bestF = v, F.copy()
        overall = max(overall, best)
        print(f'k={k} nu={"".join("+" if b > 0 else "-" for b in nu)}: best local max={best:+.3e}'
              + (f'  F={np.round(bestF, 3).tolist()}' if best > 1e-9 else ''), flush=True)
print(f"overall best = {overall:+.3e}", flush=True)
