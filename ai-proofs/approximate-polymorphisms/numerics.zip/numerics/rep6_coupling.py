"""Exact verification of the six-column coupling proof that the orbit rep6 (2h = (-2,-1,0,-1,1,-2,-1,0), classes {1,2},{3}) is
trivial (Proposition "rep6" in Section 11 of MAIN_RESULT.tex), and hence also C12 (class flip).

  * h' = h raised by 1/2 at +++ and -+- (the vertices outside supp pi_+): 8h'(y) = -2 - y1 + y3 - y1y2 + y2y3 - 2y1y2y3.
  * Columns A1..A5 (decoder F of {1,2}) and B (decoder F' of {3}) of a matrix with independent rows ~ rho_{nu_i}, where
    (A1,A4,B), (A1,A5,B), (A3,A4,B) ~ (w1,w2,w3) and (A2,A3,B) ~ (w2,w1,w3) (full row law), (A2,A5) ~ (A3,A5) ~ (w1,w2) under pi_b.
    Then E[h'(Y)] = E[R(F(A1),...,F(A5),F'(B))] with
        16R(y0..y4, y5) = -4 - y1 - y4 + 2y5 + y0y3 + y0y4 - y1y2 - 2y1y4 + y1y5 + y2y3 - 2y2y4 + y4y5 - y5(y0y3 + y0y4 + y1y2 + y2y3).
  * R <= 0: at y5 = 1, 16R = -((y1+y2+y4)^2 - 1); at y5 = -1, 16R = -2[2 + (1+y1)(1+y4) + y2(y4-y3) - y0(y3+y4)].
  * rho_+ is uniform on ten points; rho_- has nine atoms (denominators 22).
  * Random exact tests (k <= 3, every nu, random rational / Boolean / dictator class-wise decoders) of
        Gamma_nu(F) <= Gamma'_nu(F) [pi] = E_rho[R] <= 0.
  * Flipping the class {3} of rep6 merges the classes and gives a function in the orbit of C12 (checked exactly).
usage: python3 rep6_coupling.py [trials=200] [seed=1]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
W6 = list(itertools.product((1, -1), repeat=6))
H2 = [-2, -1, 0, -1, 1, -2, -1, 0]
C12 = [-1, -2, -2, 1, -1, 0, 0, -1]
h = {w: Fr(v, 2) for w, v in zip(W3, H2)}
mu = sum(h.values()) / 8
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
SUBSETS = [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]
RHO_PLUS = ['++++--', '++---+', '+-+--+', '+---+-', '-+-+++', '-+-+-+', '--+-++', '--+---', '---+++', '------']
RHO_MINUS = {'++++++': Fr(2, 11), '++++--': Fr(3, 22), '+-+-+-': Fr(3, 22), '+-+--+': Fr(1, 11), '-+-+++': Fr(1, 22),
             '-+-++-': Fr(1, 11), '-+-+--': Fr(1, 11), '----+-': Fr(1, 11), '-----+': Fr(3, 22)}
TRIPLES = [((0, 3, 5), (0, 1, 2)), ((0, 4, 5), (0, 1, 2)), ((2, 3, 5), (0, 1, 2)), ((1, 2, 5), (1, 0, 2))]
PAIRS = [((1, 4), (0, 1)), ((2, 4), (0, 1))]


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def multilinear(vals):
    return {S: sum(vals[w] * chi(S, w) for w in W3) / 8 for S in SUBSETS}


def ext(coef, y):
    return sum((c * chi(S, y) for S, c in coef.items()), Fr(0))


def marg(law, idx):
    out = {}
    for w, p in law.items():
        key = tuple(w[a] for a in idx)
        out[key] = out.get(key, 0) + p
    return out


def R16(y):
    y0, y1, y2, y3, y4, y5 = y
    return (-4 - y1 - y4 + 2 * y5 + y0 * y3 + y0 * y4 - y1 * y2 - 2 * y1 * y4 + y1 * y5 + y2 * y3 - 2 * y2 * y4 + y4 * y5
            - y5 * (y0 * y3 + y0 * y4 + y1 * y2 + y2 * y3))


def orbit(vals):
    out = set()
    for perm in itertools.permutations(range(3)):
        for sgn in (1, -1):
            for neg in (1, -1):
                f = {w: v for w, v in zip(W3, vals)}
                out.add(tuple(sgn * f[tuple(neg * w[perm[a]] for a in range(3))] for w in W3))
    return out


def key(u):
    return ''.join('+' if t > 0 else '-' for t in u)


def main():
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    assert mu == Fr(-3, 8) and sum(v * v for v in h.values()) / 8 == -mu
    for b in (1, -1):
        assert sum(pi[b].values()) == 1 and min(pi[b].values()) >= 0
    ch = multilinear(h)
    assert [ch[(a,)] for a in range(3)] == [Fr(-1, 8), Fr(-1, 8), Fr(1, 8)]
    supp = [w for w in W3 if pi[1][w] > 0]
    print("pi_+ :", [str(pi[1][w]) for w in W3])
    print("pi_- :", [str(pi[-1][w]) for w in W3])
    print("level one (1/8)(-1,-1,1): classes {1,2},{3}; supp pi_+ misses:", [w for w in W3 if w not in supp])

    hp = dict(h)
    for w in W3:
        if w not in supp:
            hp[w] = Fr(-1, 2)
    assert all(hp[w] >= h[w] for w in W3) and [w for w in W3 if hp[w] != h[w]] == [(1, 1, 1), (-1, 1, -1)]
    chp = multilinear(hp)
    assert {S: 8 * c for S, c in chp.items() if c} == {(): -2, (0,): -1, (2,): 1, (0, 1): -1, (1, 2): 1, (0, 1, 2): -2}
    print("h' = h raised by 1/2 at +++ and -+-: 8h' = -2 - y1 + y3 - y1y2 + y2y3 - 2y1y2y3  [exact]")

    rho = {1: {u: (Fr(1, 10) if key(u) in RHO_PLUS else Fr(0)) for u in W6},
           -1: {u: RHO_MINUS.get(key(u), Fr(0)) for u in W6}}
    for b in (1, -1):
        r = rho[b]
        assert sum(r.values()) == 1 and min(r.values()) >= 0
        for cols, wc in TRIPLES:
            assert marg(r, cols) == marg(pi[b], wc)
        for cols, wc in PAIRS:
            assert marg(r, cols) == marg(pi[b], wc)
        assert marg(pi[b], (0,)) == marg(pi[b], (1,)) and marg(pi[b], (0, 1)) == marg(pi[b], (1, 0))
        print(f"rho_{'+' if b > 0 else '-'} :", {key(u): str(p) for u, p in r.items() if p})
    print("rho_b >= 0; (A1,A4,B), (A1,A5,B), (A3,A4,B) ~ (w1,w2,w3), (A2,A3,B) ~ (w2,w1,w3), (A2,A5) ~ (A3,A5) ~ (w1,w2)  [exact]")

    # coefficient aggregation (R in units of 1/16, h' in units of 1/8)
    coefR = {}
    for S in itertools.chain.from_iterable(itertools.combinations(range(6), r) for r in range(4)):
        c = Fr(sum(R16(u) * chi(S, u) for u in W6), 64)
        if c:
            coefR[S] = c
    law_of = {}
    for cols, wc in TRIPLES:
        law_of[cols] = ('cubic',)
        for t in itertools.combinations(range(3), 2):
            law_of[tuple(cols[x] for x in t)] = tuple(sorted(wc[x] for x in t))
    for cols, wc in PAIRS:
        law_of[cols] = tuple(sorted(wc))
    agg = {}
    for S, c in coefR.items():
        if len(S) == 0:
            k = ()
        elif len(S) == 1:
            k = ('p',) if S[0] < 5 else ('s',)
        else:
            k = law_of[S]
        agg[k] = agg.get(k, 0) + c
    target = {(): 2 * 8 * chp[()], ('p',): 2 * 8 * (chp[(0,)] + chp[(1,)]), ('s',): 2 * 8 * chp[(2,)],
              (0, 1): 2 * 8 * chp[(0, 1)], (0, 2): 2 * 8 * chp[(0, 2)], (1, 2): 2 * 8 * chp[(1, 2)], ('cubic',): 2 * 8 * chp[(0, 1, 2)]}
    assert all(agg.get(k, 0) == v for k, v in target.items()) and set(agg) <= set(target)
    print("coefficients of R summed over columns/pairs/triples with the same law equal those of h'  [exact]")

    for u in W6:
        y0, y1, y2, y3, y4, y5 = u
        if y5 == 1:
            assert R16(u) == -((y1 + y2 + y4) ** 2 - 1)
        else:
            assert R16(u) == -2 * (2 + (1 + y1) * (1 + y4) + y2 * (y4 - y3) - y0 * (y3 + y4))
        assert R16(u) <= 0
    assert all(R16(u) == 0 for u in W6 if rho[1][u] > 0)
    print("R <= 0 on [-1,1]^6 (16R = -((y1+y2+y4)^2-1) at y5=1, -2[2+(1+y1)(1+y4)+y2(y4-y3)-y0(y3+y4)] at y5=-1); "
          "R = 0 at every atom of rho_+  [exact]")

    flipped = tuple(int(2 * h[(w[0], w[1], -w[2])]) for w in W3)
    fl = multilinear({w: h[(w[0], w[1], -w[2])] for w in W3})
    assert flipped in orbit(tuple(C12)) and len({fl[(a,)] for a in range(3)}) == 1
    print("flipping the class {3} gives", flipped, "in the orbit of C12 (one class): rep6 trivial => C12 trivial  [exact]")

    def expectations(nu, F, Fs, k):
        Eh = Ehp = Fr(0)
        for rows in itertools.product(W3, repeat=k):
            p = Fr(1)
            for i, w in enumerate(rows):
                p *= pi[nu[i]][w]
            if p == 0:
                continue
            y = tuple((F, F, Fs)[j][tuple(w[j] for w in rows)] for j in range(3))
            Eh += p * ext(ch, y)
            Ehp += p * ext(chp, y)
        ER = Fr(0)
        supp6 = [u for u in W6 if any(rho[b][u] for b in nu)]
        for rows in itertools.product(supp6, repeat=k):
            p = Fr(1)
            for i, u in enumerate(rows):
                p *= rho[nu[i]][u]
            if p == 0:
                continue
            cols = [tuple(u[j] for u in rows) for j in range(6)]
            ER += p * R16([F[cols[a]] for a in range(5)] + [Fs[cols[5]]]) / 16
        return Eh, Ehp, ER

    worst = None
    count = 0
    for k in (1, 2, 3):
        cube = list(itertools.product((1, -1), repeat=k))
        for nu in itertools.product((1, -1), repeat=k):
            ntr = trials if k < 3 else max(1, trials // 10)
            for t in range(ntr):
                mode = t % 3
                if mode == 0:
                    F = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                    Fs = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                elif mode == 1:
                    F = {z: Fr(rng.choice((-1, 1))) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1))) for z in cube}
                else:
                    r = rng.randrange(k)
                    F = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                Eh, Ehp, ER = expectations(nu, F, Fs, k)
                assert Eh <= Ehp == ER <= 0, (k, nu)
                count += 1
                if worst is None or Ehp > worst[0]:
                    worst = (Ehp, k, nu)
    print(f"{count} random exact tests (k <= 3, every nu): Gamma <= Gamma'[pi] = E_rho[R] <= 0 in every case; "
          f"largest Gamma' = {worst[0]} (k={worst[1]}, nu={worst[2]})")
    print("rep6 (and C12) trivial: Gamma_nu(F) <= 0 for every k, nu and class-wise decoder  [proof in MAIN_RESULT.tex]")


if __name__ == '__main__':
    main()
