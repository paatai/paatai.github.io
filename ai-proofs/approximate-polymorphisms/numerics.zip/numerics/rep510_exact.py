"""rep5 and rep10: exact one-function forms of triviality (Section 11, paragraph "Exact forms for rep5 and rep10").

For a two-class representative h with pair class {1,2} and singleton class {3}, write h(y) = c(y1,y2) + l(y1,y2) y3.
Gamma_nu(F_p,F_s) = E h(F_p(X1),F_p(X2),F_s(X3)) is affine in each value F_s(z), so its maximum over F_s is
E c(F_p(X1),F_p(X2)) + E|E[l(F_p(X1),F_p(X2)) | X3]|. With P = (1+F_p)/2, P1 = P(X1), P2 = P(X2), p = E P:
  rep5,  2h = (-2,-1,-1,0,1,-2,0,-1):  4 max_{F_s} Gamma = 2(L5 - R5),   L5 = E(E[2P1 - 1 - 2(1-P1)P2 | X3])_+,   R5 = 2E[P1P2];
  rep10, 2h = (-1,-2,0,0,1,-1,-1,0):   4 max_{F_s} Gamma = 2(L10 - R10), L10 = E(E[P1 + 3P2 - 2P1P2 - 1 | X3])_+, R10 = p + E[P1P2].
So, by Theorem D and Lemma 11.2 (class-wise), rep5 (rep10) is trivial iff L5 <= R5 (L10 <= R10) for all k, nu, P.
Checks (exact, Fractions): the Fourier expansions; for random P with k <= 3 and every nu, the maximum of Gamma over all
{-1,1}-valued F_s (by enumeration, Gamma from the multilinear extension of h) equals the formula; equality cases.
usage: python3 rep510_exact.py [ntest] [seed]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
REPS = {"rep5": [-2, -1, -1, 0, 1, -2, 0, -1], "rep10": [-1, -2, 0, 0, 1, -1, -1, 0]}


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)
    print("ok:", msg)


def setup(h2):
    h = {w: Fr(v, 2) for w, v in zip(W3, h2)}
    mu = sum(h.values()) / 8
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    return h, mu, pi


def fourier(f):
    out = {}
    for S in itertools.product((0, 1), repeat=3):
        out[S] = sum(f[w] * (w[0] if S[0] else 1) * (w[1] if S[1] else 1) * (w[2] if S[2] else 1) for w in W3) / 8
    return out


def mlin(f, y):
    out = Fr(0)
    for w in W3:
        wt = Fr(1)
        for wi, yi in zip(w, y):
            wt *= (1 + wi * Fr(yi)) / 2
        out += wt * f[w]
    return out


def cube(k):
    return list(itertools.product((1, -1), repeat=k))


def columns(pi, nu):
    out = {((), (), ()): Fr(1)}
    for b in nu:
        new = {}
        for (z1, z2, z3), p in out.items():
            for w, q in pi[b].items():
                if q:
                    key = (z1 + (w[0],), z2 + (w[1],), z3 + (w[2],))
                    new[key] = new.get(key, 0) + p * q
        out = new
    return out


def gamma(h, J, Fp, Fs):
    return sum(p * mlin(h, (Fp[z1], Fp[z2], Fs[z3])) for (z1, z2, z3), p in J.items())


def brute_max(h, J, Fp, k):
    return max(gamma(h, J, Fp, dict(zip(cube(k), s))) for s in itertools.product((1, -1), repeat=2 ** k))


def sides(name, J, P):
    cond = {}
    for (z1, z2, z3), p in J.items():
        a, b = P[z1], P[z2]
        v = 2 * a - 1 - 2 * (1 - a) * b if name == "rep5" else a + 3 * b - 2 * a * b - 1
        cond[z3] = cond.get(z3, 0) + p * v
    lhs = sum(max(v, 0) for v in cond.values())
    E12 = sum(p * P[z1] * P[z2] for (z1, z2, z3), p in J.items())
    pm = sum(p * P[z1] for (z1, z2, z3), p in J.items())
    rhs = 2 * E12 if name == "rep5" else pm + E12
    return lhs, rhs


def main():
    ntest = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    expected = {
        "rep5": {(0, 0, 0): Fr(-3, 8), (1, 0, 0): Fr(-1, 8), (0, 1, 0): Fr(-1, 8), (0, 0, 1): Fr(1, 8), (1, 1, 0): Fr(-1, 8),
                 (1, 0, 1): Fr(-3, 8), (0, 1, 1): Fr(1, 8), (1, 1, 1): Fr(-1, 8)},
        "rep10": {(0, 0, 0): Fr(-1, 4), (1, 0, 0): Fr(-1, 8), (0, 1, 0): Fr(-1, 8), (0, 0, 1): Fr(1, 8), (1, 1, 0): Fr(-1, 4),
                  (1, 0, 1): Fr(0), (0, 1, 1): Fr(1, 4), (1, 1, 1): Fr(-1, 8)}}
    for name, h2 in REPS.items():
        h, mu, pi = setup(h2)
        fh = fourier(h)
        check(fh == expected[name], f"{name}: Fourier expansion of h (classes {{1,2}}, {{3}}; mu = {mu})")
        count = 0
        for k in range(0, 4):
            for npos in range(k + 1):
                nu = (1,) * npos + (-1,) * (k - npos)
                J = columns(pi, nu)
                for _ in range(ntest if k > 0 else 2):
                    P = {z: Fr(rng.randint(0, 12), 12) for z in cube(k)}
                    if rng.random() < 0.3:
                        P = {z: Fr(rng.randint(0, 1)) for z in cube(k)}
                    Fp = {z: 2 * P[z] - 1 for z in cube(k)}
                    lhs, rhs = sides(name, J, P)
                    assert 4 * brute_max(h, J, Fp, k) == 2 * (lhs - rhs), (name, k, nu)
                    count += 1
        check(True, f"{name}: 4 max over all {{-1,1}}-valued F_s of Gamma = 2(LHS - RHS), {count} exact random tests, k <= 3, all nu")
        J1, J2 = columns(pi, (1,)), columns(pi, (1, 1))
        cases = [("P = 0", J1, {z: Fr(0) for z in cube(1)}), ("dictator", J1, {z: Fr(int(z[0] == 1)) for z in cube(1)}),
                 ("AND2", J2, {z: Fr(int(z == (1, 1))) for z in cube(2)}),
                 ("1{z = (1,-1)}", J2, {z: Fr(int(z == (1, -1))) for z in cube(2)})]
        for cname, J, P in cases:
            lhs, rhs = sides(name, J, P)
            print(f"   {name}, {cname}: LHS = {lhs}, RHS = {rhs}")
    h5, _, pi5 = setup(REPS["rep5"])
    for cname, nu, P, val in [("dictator", (1,), {z: Fr(int(z[0] == 1)) for z in cube(1)}, 0),
                              ("AND2", (1, 1), {z: Fr(int(z == (1, 1))) for z in cube(2)}, 0),
                              ("1{z = (1,-1)}", (1, 1), {z: Fr(int(z == (1, -1))) for z in cube(2)}, Fr(-1, 50))]:
        lhs, rhs = sides("rep5", columns(pi5, nu), P)
        check(lhs - rhs == val, f"rep5, {cname}: LHS - RHS = {val}")
    h10, _, pi10 = setup(REPS["rep10"])
    lhs, rhs = sides("rep10", columns(pi10, (1,)), {z: Fr(int(z[0] == 1)) for z in cube(1)})
    check(lhs == rhs == Fr(1, 2), "rep10, dictator: LHS = RHS = 1/2")


if __name__ == "__main__":
    main()
