"""Mixed limit for the 17 open m = 9 pairs: k0 label rows read exactly plus a Gaussian part (floating point, exploratory).

Setting as in m9_gauss_limit.py: one class {i, j}, sigma = -1, sigma Gamma = H(p) + 4|b| (E[P(X)P(Z)] - p^2).  Take k0 rows A
with signs nu_A and, in addition, n rows of the dangerous sign whose normalised X- and Z-counts (S_X, S_Z) tend to a Gaussian pair
(G1, G2) with correlation -a, independent of (X_A, Z_A).  For a decoder P(x) = Q_{x_A}(S_X) with means p_u = E Q_u(G),

    E[P(X)P(Z)] -> sum_{u,v} w(u,v) E[Q_u(G1) Q_v(G2)] >= sum_{u,v} w(u,v) Phi2(t_u, t_v; -a),   Phi(t_u) = p_u,

where w is the law of (X_A, Z_A); the inequality is Borell's theorem for each pair (u, v) (for negative correlation the minimum
of E[f(G1) g(G2)] at given means is attained by lower half-lines), with equality for Q_u = 1[g <= t_u].  So for fixed nu_A the
limit values of sigma Gamma are bounded below by

    V(p) = H(pbar) + 4|b| (sum_{u,v} w(u,v) Phi2(t_u, t_v; -a) - pbar^2),     pbar = sum_u m(u) p_u,

and V is attained in the limit.  V(p) <= sigma Gamma for every decoder on the rows A alone (constant Q_u = p_u is dominated by
the half-line with the same mean), so min V over k0 rows is at most the exact k0-row minimum; k0 = 0 is m9_gauss_limit.py.
The script minimises V over p in [0,1]^(2^k0) (L-BFGS-B, analytic gradient, random starts) for every sign pattern nu_A up to
order and prints the smallest value found.  Phi2 is computed as Phi(h)Phi(k) + int_0^rho phi2(h, k; s) ds by Gauss-Legendre
quadrature (|rho| = a < 0.38).

usage: python3 m9_mixed_limit.py [k0max] [starts] [workers]
"""
import itertools
import sys
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np
from scipy import optimize
from scipy.special import ndtr, ndtri

KMAX = int(sys.argv[1]) if len(sys.argv) > 1 else 3
STARTS = int(sys.argv[2]) if len(sys.argv) > 2 else 200
WORKERS = int(sys.argv[3]) if len(sys.argv) > 3 else 8

sys.argv = sys.argv[:1] + ['7']
import maxcorr_J2 as M  # noqa: E402
from fsharp_check import sharp_pieces, params  # noqa: E402
from m9_k4_scan import CANDS  # noqa: E402

GL_X, GL_W = np.polynomial.legendre.leggauss(40)
TMAX = 40.0


def phi2_minus_prod(h, k, rho):
    """Phi2(h, k; rho) - Phi(h) Phi(k), broadcasting over h, k."""
    s = 0.5 * rho * (GL_X + 1.0)
    w = 0.5 * rho * GL_W
    h = h[..., None]
    k = k[..., None]
    q = (h * h - 2.0 * s * h * k + k * k) / (2.0 * (1.0 - s * s))
    return np.sum(w * np.exp(-q) / (2.0 * np.pi * np.sqrt(1.0 - s * s)), axis=-1)


def setup(spec, k0, nu_A):
    hv = (Fr(spec[0]), Fr(spec[1]), Fr(spec[1]), Fr(spec[2]))
    mu, b, lam, qq = params(hv)
    a, q, r, th, A, pieces = sharp_pieces(hv)
    _, pi = M.laws(hv)
    us = list(itertools.product((1, -1), repeat=k0))
    n = len(us)
    W = np.zeros((n, n))
    for iu, u in enumerate(us):
        for iv, v in enumerate(us):
            pr = 1.0
            for r_ in range(k0):
                pr *= float(pi[nu_A[r_]][M.W2.index((u[r_], v[r_]))])
            W[iu, iv] = pr
    m = W.sum(axis=1)
    return dict(A=tuple(float(x) for x in A), B=float(4 * abs(b)), a=float(a), W=W, m=m, us=us)


def value_grad(p, S):
    A0, A1, A2 = S['A']
    B, a, W, m = S['B'], S['a'], S['W'], S['m']
    pc = np.clip(p, 0.0, 1.0)
    t = np.clip(ndtri(pc), -TMAX, TMAX)
    Phi = ndtr(t)
    pbar = float(m @ Phi)
    T1, T2 = np.meshgrid(t, t, indexing='ij')
    E = np.outer(Phi, Phi) + phi2_minus_prod(T1, T2, -a)
    val = A0 + A1 * pbar + A2 * pbar * pbar + B * (float(np.sum(W * E)) - pbar * pbar)
    cond = ndtr((T2 + a * T1) / np.sqrt(1.0 - a * a))
    dE = 2.0 * np.sum(W * cond, axis=1)
    grad = (A1 + 2.0 * A2 * pbar) * m + B * (dE - 2.0 * pbar * m)
    return val, grad


def minimise(S, x0):
    n = len(S['us'])
    res = optimize.minimize(value_grad, x0, args=(S,), jac=True, method='L-BFGS-B', bounds=[(0.0, 1.0)] * n,
                            options={'maxiter': 2000, 'ftol': 1e-15, 'gtol': 1e-12})
    return float(res.fun), res.x.copy()


def boolean_values(S, X):
    """V at 0/1 points (rows of X): then Phi2(t_u, t_v) = p_u p_v and V is the value of a decoder on the rows A alone."""
    A0, A1, A2 = S['A']
    pbar = X @ S['m']
    return A0 + A1 * pbar + A2 * pbar * pbar + S['B'] * (np.einsum('ci,ij,cj->c', X, S['W'], X) - pbar * pbar)


def boolean_seeds(S, rng, top=10, walks=400):
    """The best 0/1 points: all of them for 2^k0 <= 16, otherwise the ends of single-flip descents from random 0/1 points."""
    n = len(S['us'])
    if n <= 16:
        X = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1).astype(float)
    else:
        X = rng.integers(0, 2, (walks, n)).astype(float)
        vals = boolean_values(S, X)
        while True:
            Y = np.repeat(X, n, axis=0)
            idx = np.tile(np.arange(n), len(X))
            Y[np.arange(len(Y)), idx] = 1 - Y[np.arange(len(Y)), idx]
            nv = boolean_values(S, Y).reshape(len(X), n)
            j = np.argmin(nv, axis=1)
            better = nv[np.arange(len(X)), j] < vals - 1e-15
            if not better.any():
                break
            X[better, j[better]] = 1 - X[better, j[better]]
            vals = boolean_values(S, X)
    vals = boolean_values(S, X)
    order = np.argsort(vals)
    out = []
    for i in order:
        if all(np.any(X[i] != y) for y in out):
            out.append(X[i].copy())
        if len(out) == top:
            break
    return out


def embed(x, k_old, front):
    """A decoder on k_old rows as a decoder on k_old + 1 rows that ignores a new first (front) or last row."""
    x = np.asarray(x).reshape((2,) * k_old) if k_old else np.asarray(x).reshape(())
    y = np.stack([x, x], axis=0 if front else k_old)
    return y.reshape(-1)


def run(job):
    """All k0 <= kmax for one candidate; patterns nu_A = (+^npos, -^(k0-npos)).  Besides random starts, every search at k0 is
    seeded with the best points found at k0 - 1 (a new + row in front, or a new - row at the end), so the minima found are
    non-increasing in k0, and with the best 0/1 points (decoders on the rows A alone)."""
    ci, kmax, starts, keep = job
    found = {}
    for k0 in range(1, kmax + 1):
        for npos in range(k0, -1, -1):
            nu_A = tuple([1] * npos + [-1] * (k0 - npos))
            S = setup(CANDS[ci], k0, nu_A)
            n = len(S['us'])
            rng = np.random.default_rng(1000 * ci + 17 * k0 + npos)
            seeds = []
            if k0 > 1:
                if npos > 0:
                    seeds += [embed(x, k0 - 1, True) for _, x in found[(k0 - 1, npos - 1)]]
                if npos < k0:
                    seeds += [embed(x, k0 - 1, False) for _, x in found[(k0 - 1, npos)]]
            seeds += boolean_seeds(S, rng)
            pts = []
            for x0 in seeds:
                pts.append(minimise(S, x0))
            for st in range(starts):
                if st % 3 == 0:
                    x0 = rng.random(n)
                elif st % 3 == 1:
                    x0 = np.clip(rng.integers(0, 2, n) + 0.05 * rng.standard_normal(n), 0, 1)
                else:
                    x0 = np.full(n, rng.random())
                pts.append(minimise(S, x0))
            pts.sort(key=lambda t: t[0])
            uniq = []
            for v, x in pts:
                if all(np.max(np.abs(x - y)) > 1e-6 for _, y in uniq):
                    uniq.append((v, x))
                if len(uniq) == keep:
                    break
            found[(k0, npos)] = uniq
    return ci, found


if __name__ == '__main__':
    jobs = [(ci, KMAX, STARTS, 6) for ci in range(len(CANDS))]
    with Pool(WORKERS) as pool:
        res = pool.map(run, jobs, chunksize=1)
    overall = np.inf
    for ci, found in sorted(res, key=lambda t: t[0]):
        spec = CANDS[ci]
        rows = sorted((pts[0][0], k0, npos, pts[0][1]) for (k0, npos), pts in found.items())
        val, k0, npos, x = rows[0]
        overall = min(overall, val)
        per_k = {k: min(v for v, kk, _, _ in rows if kk == k) for k in range(1, KMAX + 1)}
        assert all(per_k[k + 1] <= per_k[k] + 1e-12 for k in range(1, KMAX)), per_k
        frac = int(np.sum((x > 1e-6) & (x < 1 - 1e-6)))
        print(f"h = {spec}: min V = {val:+.4e} (k0 = {k0}, nu_A = {'+' * npos + '-' * (k0 - npos)}, "
              f"{frac} of {len(x)} values p_u strictly inside (0,1)); by k0: "
              + ", ".join(f"{k}: {v:+.4e}" for k, v in per_k.items()), flush=True)
    print(f"smallest value over all pairs, k0 <= {KMAX}: {overall:+.4e}  ({STARTS} random starts per sign pattern, plus seeds "
          f"from k0 - 1 and the best 0/1 points)")
