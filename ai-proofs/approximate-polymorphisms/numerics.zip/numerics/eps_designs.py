"""Best bound eps(N) proved by coupling designs with N columns (floating point, scipy.milp / HiGHS).

A design whose polynomial R satisfies R <= eps at every vertex of {-1,1}^N (instead of R <= 0) proves Gamma_nu(F) <= eps for
all k, nu and F, since Gamma <= E h'(Y) = E R(F(V_1), ..., F(V_N)) <= max R.  eps(N) is the least such eps over all designs with
N columns (same formulation as milp_designs.build; the vertex constraints R(u) <= 0 become R(u) <= eps and eps is minimised).
A tiny penalty on the binaries selects sparse optimal designs.  Prints the solver status, eps, the dual bound and the design.
Coefficient bound: R <= eps gives |R^(S)| <= E[eps - R] = eps - h'^(emptyset) <= eps + |mu| for S != {}.  With EPSMAX given
(an a priori upper bound on the optimal eps, e.g. 1/4 for B12 and N >= 3, since eps(3) = 1/4 and unused columns can be added),
eps <= EPSMAX and every coefficient is bounded by EPSMAX + |mu|, which cuts off no design with eps <= EPSMAX; without it the bound
is |mu| (milp_designs default), exact for eps = 0 but a restriction for eps > 0.
usage: python3 eps_designs.py NAME N1,N2,... [PATTERN|-] [MODE] [time_limit] [disp|-] [EPSMAX]
"""
from fractions import Fraction
import sys
import time

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

import milp_designs as md


def sgn(u):
    return ''.join('+' if s == 1 else '-' for s in u)


def run(name, N, pattern='-', mode='copy', tl=3600.0, disp=False, penalty=1e-6, epsmax=None):
    mu = abs(float(sum(Fraction(v, 2) for v in md.H[name]) / 8))
    M = None if epsmax is None else mu + epsmax
    cost, A, lo, hi, lb, ub, integ, info = md.build(name, N, None if pattern == '-' else pattern, mode, M=M)
    o_tf, o_R0, o_Ra, o_Rz, o_Rt, o_z, o_t, o_rho = info['o']
    vrows = np.where((A[:, o_R0] == 1) & (hi == 0) & np.isneginf(lo))[0]
    assert len(vrows) == 2 ** N, (len(vrows), 2 ** N)
    nv = A.shape[1]
    A2 = np.hstack([A, np.zeros((A.shape[0], 1))])
    A2[vrows, nv] = -1.0
    c = np.zeros(nv + 1)
    c[nv] = 1.0
    c[o_z:o_t + len(info['tkeys'])] = penalty
    t0 = time.time()
    res = milp(c, constraints=LinearConstraint(A2, lo, hi),
               bounds=Bounds(np.append(lb, 0.0), np.append(ub, 1.0 if epsmax is None else epsmax)),
               integrality=np.append(integ, 0), options={'time_limit': tl, 'disp': disp})
    dt = time.time() - t0
    cap = f"coefficient cap {mu if M is None else M:g}" + ("" if epsmax is None else f", eps <= {epsmax:g}")
    print(f"== {name} N={N} {pattern} [{mode}] ({cap}): status {res.status} ({res.message[:60]}), "
          f"dual bound {getattr(res, 'mip_dual_bound', None)}, {dt:.1f}s", flush=True)
    if res.x is None:
        return None
    x = res.x
    print(f"  eps = {x[nv]:.8f}")
    print("  tf:", [round(float(v), 5) for v in x[o_tf:o_tf + len(info['free'])]], "at", info['free'])
    print("  R0", round(float(x[o_R0]), 6), " Ra", [round(float(v), 6) for v in x[o_Ra:o_Ra + N]])
    for q, (a, cc, K) in enumerate(info['zkeys']):
        if x[o_z + q] > 0.5:
            print(f"  pair ({a},{cc}) law P+(++)={K[2][0]} P-(++)={K[2][1]}  coef {x[o_Rz + q]:.6f}")
    for q, tk in enumerate(info['tkeys']):
        if x[o_t + q] > 0.5:
            print(f"  copy {tk[:3]} pair laws {[(p[0], p[1], str(p[2][2][0])) for p in tk[3]]}  coef {x[o_Rt + q]:.6f}")
    U = info['U']
    nu = info['nu']
    for bi, b in enumerate((1, -1)):
        rho = x[o_rho + bi * nu: o_rho + (bi + 1) * nu]
        print(f"  rho_{'+' if b == 1 else '-'}:", {sgn(U[v]): round(float(rho[v]), 5) for v in range(nu) if rho[v] > 1e-7})
    Rv = []
    for v in range(nu):
        u = U[v]
        val = x[o_R0] + sum(x[o_Ra + a] * u[a] for a in range(N))
        val += sum(x[o_Rz + q] * u[a] * u[cc] for q, (a, cc, K) in enumerate(info['zkeys']))
        val += sum(x[o_Rt + q] * u[tk[0]] * u[tk[1]] * u[tk[2]] for q, tk in enumerate(info['tkeys']))
        Rv.append(val)
    mx = max(Rv)
    print("  max R", round(float(mx), 8), " vertices at max:", [sgn(U[v]) for v in range(nu) if Rv[v] > mx - 1e-7], flush=True)
    return x[nv]


if __name__ == '__main__':
    name, Ns = sys.argv[1], [int(x) for x in sys.argv[2].split(',')]
    pattern = sys.argv[3] if len(sys.argv) > 3 else '-'
    mode = sys.argv[4] if len(sys.argv) > 4 else 'copy'
    tl = float(sys.argv[5]) if len(sys.argv) > 5 else 3600.0
    disp = len(sys.argv) > 6 and sys.argv[6] == 'disp'
    epsmax = float(Fraction(sys.argv[7])) if len(sys.argv) > 7 else None
    for N in Ns:
        run(name, N, pattern, mode, tl, disp, epsmax=epsmax)
