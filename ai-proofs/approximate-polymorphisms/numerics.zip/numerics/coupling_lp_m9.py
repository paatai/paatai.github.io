"""Coupling LP (two-copy constraints) for all 17 pairs of open one-class |J| = 2 candidates with m = 9 (floating point).

For each candidate with Phi# negative on (q^2, q) (one representative of each pair {h, h(-.)}), the LP of coupling_lp3.py with
two-copy constraints only (product couplings whose per-row correlations lie on a 31 x 13 grid) is solved at every p of the grid
0.005 Z in (q^2, q), giving the bound sigma Gamma >= Phi_LP(p) = sh(p) - 4|b| LP(p).  The script prints the grid minimum of
Phi_LP, the grid minimum of Phi# (fsharp_check.sharp_pieces) and the range of Phi_LP - Phi# over the grid: the LP is never
weaker than Phi#, is stronger away from the minimiser, and has the same grid minimum.  Writes outputs/coupling_lp_m9.txt.
usage: python3 coupling_lp_m9.py
"""
import os
import re
from fractions import Fraction as Fr

from coupling_lp3 import lp3
from fsharp_check import sharp_pieces
from m9_open import M, phi_sharp

HERE = os.path.dirname(os.path.abspath(__file__))


def main():
    rows = [ln for ln in open(os.path.join(HERE, 'outputs/maxcorr_J2_r7.txt')) if ln.startswith('  UNDEC')]
    assert len(rows) == 34
    lines, worst_rel = [], 0.0
    for ln in rows:
        hv = tuple(Fr(s) for s in re.search(r"= \('([^']*)', '([^']*)', '([^']*)', '([^']*)'\)", ln).groups())
        a, q, r, th, _, pieces = sharp_pieces(hv)
        if [i for i, pc in enumerate(pieces) if M.quad_min(*pc) < 0] != [0]:
            continue                                            # mirror image (Phi# negative on (1-q, 1-q^2))
        lo, hi = float(q * q), float(q)
        ps = [j / 200 for j in range(1, 200) if lo < j / 200 < hi]
        res = lp3(hv, ps, use3=False)
        sharp = [float(phi_sharp(pieces, Fr(p).limit_denominator(10 ** 6))) for p in ps]
        diffs = [val - s for (p, _, val), s in zip(res, sharp)]
        p_min, _, v_min = min(res, key=lambda t: t[2])
        s_min = min(sharp)
        rel = abs(v_min - s_min) / abs(s_min)
        worst_rel = max(worst_rel, rel)
        lines.append(f"h = ({hv[0]}, {hv[1]}, {hv[3]}): min Phi_LP = {v_min:.6e} at p = {p_min:.4f}; grid min of Phi# = "
                     f"{s_min:.6e}; Phi_LP - Phi# on the {len(ps)} grid points in [{min(diffs):+.2e}, {max(diffs):+.2e}]")
    assert len(lines) == 17
    lines.append(f"17 pairs: Phi_LP >= Phi# at every grid point (up to rounding), with gains away from the minimiser, but the grid "
                 f"minimum of Phi_LP equals that of Phi# (largest relative difference {worst_rel:.1e}), so the LP decides nothing")
    with open(os.path.join(HERE, 'outputs/coupling_lp_m9.txt'), 'w') as f:
        f.write('\n'.join(lines) + '\n')
    print('\n'.join(lines))


if __name__ == '__main__':
    main()
