"""Exhaustive search for certificates with k = 4 for the 17 pairs of one-class |J| = 2 candidates left open at m = 9
(floating point).  For each candidate h = (x, z, z, y) (one of each mirror pair; mu < 0, so a certificate is Gamma > 0) and each
nu = (+,...,+,-,...,-) with k = 4, Gamma_nu(F) = c0 + lin . F + F^T Q F (j2_k2_exact.quad_form) is maximised over the cube
[-1,1]^16 by enumerating all 3^16 faces: for each set of free coordinates the Hessian block 2 Q[free, free] is inverted once
(blocks with condition number above 1e12 are skipped; on a face with a singular block the maximum is attained on its relative
boundary) and the critical points for all assignments of the fixed coordinates are computed together.

usage: python3 m9_k4_scan.py [k=4] [workers=8]
"""
import itertools
import sys
import time
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np

from j2_k2_exact import quad_form

CANDS = [('-9/16', '9/64', '-3/32'), ('-1/2', '9/64', '-3/32'), ('-17/32', '9/64', '-3/32'), ('-43/64', '1/8', '-5/64'),
         ('-23/64', '9/64', '-7/64'), ('-23/32', '7/64', '-1/16'), ('-25/64', '1/8', '-5/64'), ('-5/16', '9/64', '-1/8'),
         ('-27/64', '5/32', '-9/64'), ('-41/64', '1/8', '-5/64'), ('-11/32', '7/64', '-1/16'), ('-41/64', '9/64', '-7/64'),
         ('-25/64', '9/64', '-7/64'), ('-47/64', '3/32', '-3/64'), ('-53/64', '3/64', '-1/64'), ('-23/32', '5/64', '-1/32'),
         ('-27/64', '1/8', '-5/64')]


def cube_max_float(c0, lin, Q, cond_max=1e12):
    n = len(lin)
    assigns = {m: np.array(list(itertools.product((-1.0, 1.0), repeat=m))).T.reshape(m, 2 ** m) for m in range(n + 1)}
    best, arg = -np.inf, None
    for mask in range(2 ** n):
        free = [a for a in range(n) if mask >> a & 1]
        fixed = [a for a in range(n) if not mask >> a & 1]
        A = assigns[len(fixed)]
        QXX = Q[np.ix_(fixed, fixed)]
        base = c0 + lin[fixed] @ A + np.einsum('ic,ij,jc->c', A, QXX, A)
        if not free:
            vals, S = base, None
        else:
            M = 2 * Q[np.ix_(free, free)]
            if np.linalg.cond(M) > cond_max:
                continue
            QFX = Q[np.ix_(free, fixed)]
            R = -(lin[free][:, None] + 2 * QFX @ A)
            S = np.linalg.solve(M, R)
            inside = np.all(np.abs(S) < 1, axis=0)
            if not inside.any():
                continue
            S, A, base = S[:, inside], A[:, inside], base[inside]
            vals = base + lin[free] @ S + np.einsum('ic,ij,jc->c', S, Q[np.ix_(free, free)], S) \
                + 2 * np.einsum('ic,ij,jc->c', S, QFX, A)
        i = int(np.argmax(vals))
        if vals[i] > best:
            best = float(vals[i])
            F = np.zeros(n)
            F[fixed] = A[:, i]
            if free:
                F[free] = S[:, i]
            arg = F
    return best, arg


def task(args):
    spec, nu = args
    hv = (Fr(spec[0]), Fr(spec[1]), Fr(spec[1]), Fr(spec[2]))
    c0, lin, Q = quad_form(hv, nu)
    lin = np.array([float(v) for v in lin])
    Q = np.array([[float(v) for v in row] for row in Q])
    t = time.time()
    val, F = cube_max_float(float(c0), lin, Q)
    return spec, nu, val, F, time.time() - t


if __name__ == '__main__':
    k = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    jobs = [(spec, tuple([1] * npos + [-1] * (k - npos))) for spec in CANDS for npos in range(k, -1, -1)]
    t0 = time.time()
    overall = {}
    with Pool(workers) as pool:
        for spec, nu, val, F, dt in pool.imap(task, jobs):
            overall[spec] = max(overall.get(spec, -np.inf), val)
            print(f"h = ({spec[0]}, {spec[1]}, {spec[1]}, {spec[2]}) k={k} nu={''.join('+' if v > 0 else '-' for v in nu)}: "
                  f"max Gamma = {val:+.6e}  at F = {np.round(F, 4).tolist()}  [{dt:.0f} s]", flush=True)
    for spec in CANDS:
        print(f"h = ({spec[0]}, {spec[1]}, {spec[1]}, {spec[2]}): max over nu, k = {k}: {overall[spec]:+.6e}", flush=True)
    print(f"largest value over all 17 pairs: {max(overall.values()):+.6e}  [{time.time() - t0:.0f} s]", flush=True)
