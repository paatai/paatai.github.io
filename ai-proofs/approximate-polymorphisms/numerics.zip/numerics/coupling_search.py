"""Which two-class boundary orbits (m = 5) yield to the re-coupling argument of Proposition "rep3" (Section 11)?  Exact.

For a representative h with pair class {i,j} and singleton s (mu < 0), the argument needs
  * a multilinear h' >= h without cubic term, equal to h on supp pi_+ (necessary for Gamma' <= 0, since the dictator has
    Gamma = 0), given by its values at the vertices outside supp pi_+;
  * a set Z of pairs whose coefficient in h' vanishes, containing (i,s) or (j,s) (the pair laws of (w_i,w_s) and (w_j,w_s)
    differ for every representative, so a pair-class symmetry needs one of them to be free);
  * row laws pit_b (b = +-1) with the marginals of pi_b on the pairs outside Z, under which (w_i,w_s) and (w_j,w_s) have the
    same law;
  * the average h'' of h' over the swap of y_i and y_j is <= 0 at all eight vertices.
Then Gamma_nu(F) <= E[h'(Y)] = E_pit[h''(Y)] <= 0 for all class-wise decoders.  For every Z the conditions on h' form a linear
system in at most three unknowns, decided exactly by Fourier-Motzkin elimination; the re-coupled laws are decided exactly:
if Z contains exactly one cross pair (a,s) and not (i,j), the laws with the required pair marginals are
pi_b + c_b w_a w_s + d w_1 w_2 w_3 with c_b fixed and d free (an interval); in the other cases they always exist.
usage: python3 coupling_search.py
"""
import itertools
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
REPS = {
    'rep1': [-2, -2, -1, 0, -1, 1, 0, -1],
    'rep2': [-2, -2, -1, 0, 1, -2, -1, -1],
    'rep3': [-2, -2, -1, 1, 0, -1, -1, 0],
    'rep5': [-2, -1, -1, 0, 1, -2, 0, -1],
    'rep6': [-2, -1, 0, -1, 1, -2, -1, 0],
    'rep7': [-1, -2, -1, 0, 1, -2, -1, 0],
    'rep8': [-1, -2, -1, 0, 1, -2, 0, -1],
    'rep9': [-1, -2, 0, -1, 1, -2, -1, 0],
    'rep10': [-1, -2, 0, 0, 1, -1, -1, 0],
}


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def fm_feasible(ineqs, n):
    """Exact Fourier-Motzkin: is {x in Q^n : a.x <= b for all (a, b) in ineqs} nonempty?"""
    rows = [(list(a), b) for a, b in ineqs]
    for v in range(n):
        pos, neg, zero = [], [], []
        for a, b in rows:
            (pos if a[v] > 0 else neg if a[v] < 0 else zero).append((a, b))
        new = list(zero)
        for ap, bp in pos:
            for an, bn in neg:
                lp, ln = -an[v], ap[v]
                new.append(([lp * x + ln * y for x, y in zip(ap, an)], lp * bp + ln * bn))
        rows = new
    return all(b >= 0 for a, b in rows)


def analyse(name):
    h = {w: Fr(v, 2) for w, v in zip(W3, REPS[name])}
    mu = sum(h.values()) / 8
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    lvl1 = [sum(h[w] * w[a] for w in W3) / 8 for a in range(3)]
    groups = {}
    for a, c in enumerate(lvl1):
        groups.setdefault(c, []).append(a)
    (i, j), (s,) = sorted(groups.values(), key=len, reverse=True)
    E = {b: {(a, c): sum(p * w[a] * w[c] for w, p in pi[b].items()) for a in range(3) for c in range(3)} for b in (1, -1)}
    assert any(E[b][(i, s)] != E[b][(j, s)] for b in (1, -1))
    supp = [w for w in W3 if pi[1][w] > 0]
    free = [w for w in W3 if w not in supp]
    n = len(free)
    pos = {w: t for t, w in enumerate(free)}

    def coef(S):
        return [Fr(chi(S, w), 8) for w in free], sum(h[w] * chi(S, w) for w in supp) / 8

    lines = [f"{name}: mu = {mu}, pair class {{{i + 1},{j + 1}}}, singleton {s + 1}, free vertices {free}"]
    found = False
    cross = [(i, s), (j, s)]
    for Z in [[(i, s)], [(j, s)], [(i, j), (i, s)], [(i, j), (j, s)], [(i, s), (j, s)], [(i, j), (i, s), (j, s)]]:
        ineqs = []
        for S in [(0, 1, 2)] + [tuple(sorted(p)) for p in Z]:
            a, c = coef(S)
            ineqs += [(a, -c), ([-x for x in a], c)]
        for w in free:
            a = [Fr(0)] * n
            a[pos[w]] = Fr(-1)
            ineqs.append((a, -h[w]))
        for w in W3:
            u = list(w)
            u[i], u[j] = w[j], w[i]
            a, c = [Fr(0)] * n, Fr(0)
            for v in (w, tuple(u)):
                if v in pos:
                    a[pos[v]] += Fr(1, 2)
                else:
                    c += h[v] / 2
            ineqs.append((a, -c))
        lp = fm_feasible(ineqs, n)
        zc = [p for p in cross if p in Z]
        intervals = []
        if len(zc) == 1 and (i, j) not in Z:
            (a0, _), = zc
            other = (j, s) if a0 == i else (i, s)
            law = True
            for b in (1, -1):
                cb = (E[b][other] - E[b][(a0, s)]) / 8
                lo, hi = None, None
                for w in W3:
                    base = pi[b][w] + cb * w[a0] * w[s]
                    if chi((0, 1, 2), w) > 0:
                        lo = -base if lo is None else max(lo, -base)
                    else:
                        hi = base if hi is None else min(hi, base)
                law = law and lo <= hi
                intervals.append(f"b={'+1' if b == 1 else '-1'}: c_b = {cb}, d in [{lo}, {hi}]{'' if lo <= hi else ' (empty)'}")
        else:
            law = True
        ok = lp and law
        found = found or ok
        lines.append(f"  zero pairs {[(p[0] + 1, p[1] + 1) for p in Z]}: h' conditions {'feasible' if lp else 'infeasible'}, "
                     f"re-coupled laws {'exist' if law else 'do not exist'}{'  -> ARGUMENT APPLIES' if ok else ''}")
        if intervals:
            lines.append("      re-coupled laws pi_b + c_b w_a w_s + d w_1 w_2 w_3: " + "; ".join(intervals))
    lines.append(f"  {name}: {'settled by the re-coupling argument' if found else 'not settled by this argument'}")
    return lines


if __name__ == '__main__':
    for name in REPS:
        print("\n".join(analyse(name)))
