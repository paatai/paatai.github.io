"""usage: python3 e2_halfspace_angles.py [eps ...]   (values for three perturbations; default eps = 0.1 0.2 0.3)
       python3 e2_halfspace_angles.py D           (first-order coefficients D12, D13 = D23)
Exploration (floating point, high accuracy): val(q_1, q_2, q_3) for g = E2 when q_j(x) = sgn(<v_j, x>) are halfspaces through
0 with unit normals v_j.  Only the Gram matrix of (v_1, v_2, v_3) matters.  Question (CFMMS Q5, second part): is the collinear
(one-dimensional) configuration (sgn, sgn, -sgn) a local maximum among halfspace configurations?

Given G_0 = x, U_j = <v_j, G_j> are jointly normal with means rho <v_j, x>, variances 1 - rho^2 and covariances -rho^2 <v_i, v_j>,
i.e. U ~ N(rho y, I - rho^2 Gram) with y = (<v_j, x>)_j ~ N(0, Gram).  gamma(y) = sum_s E2(s) Pr[sgn U = s]; the orthant
probabilities are computed by integrating the first coordinate (Gauss-Legendre) against exact bivariate orthant probabilities
(Owen's T).  Since E gamma = mu = -1/4, val = 1/2 + E|gamma|/2 = 5/8 + E[gamma^+].
"""
import itertools
import sys

import numpy as np
from scipy.special import ndtr, owens_t
from scipy import integrate

RHO = 1 / np.sqrt(15)
SIGNS = list(itertools.product([1, -1], repeat=3))
E2V = np.array([1.0 if sum(1 for t in s if t > 0) == 2 else -1.0 for s in SIGNS])
GL_X, GL_W = np.polynomial.legendre.leggauss(80)


def bvn_upper(h, k, r):
    """Pr[X > h, Y > k] for standard bivariate normal with correlation r (vectorised in h, k)."""
    h = np.where(np.abs(h) < 1e-13, 1e-13, h)
    k = np.where(np.abs(k) < 1e-13, 1e-13, k)
    s = np.sqrt(1 - r * r)
    ah = (k - r * h) / (h * s)
    ak = (h - r * k) / (k * s)
    beta = np.where(h * k > 0, 0.0, 0.5)
    return 0.5 * (ndtr(-h) + ndtr(-k)) - owens_t(h, ah) - owens_t(k, ak) - beta


def orthant(m, C):
    """Pr[V_1 > 0, V_2 > 0, V_3 > 0] for V ~ N(m, C)."""
    s1 = np.sqrt(C[0, 0])
    z0 = -m[0] / s1
    lo, hi = z0, max(z0, 0.0) + 9.0
    z = 0.5 * (hi - lo) * GL_X + 0.5 * (hi + lo)
    w = 0.5 * (hi - lo) * GL_W
    t = m[0] + s1 * z
    b = C[1:, 0] / C[0, 0]
    Cc = C[1:, 1:] - np.outer(C[1:, 0], C[1:, 0]) / C[0, 0]
    sd = np.sqrt(np.diag(Cc))
    r = Cc[0, 1] / (sd[0] * sd[1])
    mu2 = m[1] + b[0] * (t - m[0])
    mu3 = m[2] + b[1] * (t - m[0])
    vals = bvn_upper(-mu2 / sd[0], -mu3 / sd[1], r)
    return float(np.sum(w * np.exp(-z * z / 2) / np.sqrt(2 * np.pi) * vals))


def gamma(y, C):
    m = RHO * y
    tot = 0.0
    for e, s in zip(E2V, SIGNS):
        D = np.array(s, dtype=float)
        tot += e * orthant(D * m, C * np.outer(D, D))
    return tot


def val(gram, R=9.0):
    C = np.eye(3) - RHO ** 2 * gram
    w, V = np.linalg.eigh(gram)
    keep = w > 1e-12
    L = V[:, keep] * np.sqrt(w[keep])
    d = L.shape[1]
    phi = lambda z: np.exp(-z * z / 2) / np.sqrt(2 * np.pi)
    if d == 1:
        f = lambda z: max(gamma(L @ np.array([z]), C), 0.0) * phi(z)
        a = integrate.quad(f, -R, 0, limit=400, epsabs=1e-13)[0]
        b = integrate.quad(f, 0, R, limit=400, epsabs=1e-13)[0]
        return 0.625 + a + b
    if d == 2:
        f = lambda z2, z1: max(gamma(L @ np.array([z1, z2]), C), 0.0) * phi(z1) * phi(z2)
        return 0.625 + integrate.dblquad(f, -R, R, -R, R, epsabs=1e-11)[0]
    raise ValueError("rank 3 not implemented")


def gram_from_vectors(vs):
    vs = np.array(vs, dtype=float)
    vs = vs / np.linalg.norm(vs, axis=1, keepdims=True)
    return vs @ vs.T


def first_order(v0, eps_list=(0.1, 0.05)):
    """D13 (= D23) from 'v3 rotated' (delta13 = delta23 = 1 - cos eps, delta12 = 0) and D12 from 'v1 rotated'
    (delta12 = delta13 = 1 - cos eps, delta23 = 0); the estimates at eps have error O(eps^2), removed by Richardson."""
    est = []
    for eps in eps_list:
        c, s = np.cos(eps), np.sin(eps)
        dl = 1 - c
        d13 = (val(gram_from_vectors([[1, 0], [1, 0], [-c, s]])) - v0) / (2 * dl)
        d12 = (val(gram_from_vectors([[c, s], [1, 0], [-1, 0]])) - v0) / dl - d13
        est.append((d12, d13))
        print("eps=%.3f  D12 ~ %.4e  D13 = D23 ~ %.4e" % (eps, d12, d13), flush=True)
    (a12, a13), (b12, b13) = est
    r = (eps_list[0] / eps_list[1]) ** 2
    print("Richardson: D12 = %.4e, D13 = D23 = %.4e" % ((r * b12 - a12) / (r - 1), (r * b13 - a13) / (r - 1)), flush=True)


if __name__ == '__main__':
    v0 = val(gram_from_vectors([[1, 0], [1, 0], [-1, 0]]))
    print("collinear (sgn, sgn, -sgn): val = %.10f" % v0, flush=True)
    if sys.argv[1:2] == ["D"]:
        first_order(v0)
        sys.exit()
    for eps in [float(e) for e in sys.argv[1:]] or [0.1, 0.2, 0.3]:
        c, s = np.cos(eps), np.sin(eps)
        confs = {
            "v1,v2 split symmetrically": [[c, s], [c, -s], [-1, 0]],
            "v3 rotated": [[1, 0], [1, 0], [-c, s]],
            "v1 rotated": [[c, s], [1, 0], [-1, 0]],
        }
        for name, vs in confs.items():
            print("eps=%.3f %-28s val = %.10f" % (eps, name, val(gram_from_vectors(vs))), flush=True)
