"""Search for coupling-design certificates (paragraph "Coupling designs" in Section 11 of MAIN_RESULT.tex) for the two-class
boundary orbits, m = 5.  Floating-point linear programming (scipy/HiGHS); positive results are re-proved exactly elsewhere
(rep2_coupling.py, rep1_coupling.py, rep7_coupling.py, rep6_coupling.py, rep3_coupling.py), negative results are numerical.

A design on N columns: classes p (decoder F of the pair class {i,j}) / s (decoder F' of the singleton class {s}); every pair of
columns is 'free' or carries one of the pair laws L_ij (p-p), L_is, L_js (p-s, p first) of the row laws pi_b; every triple
(p, p, s) whose pairs carry L_ij, L_is, L_js (in some order) may carry the full row law (mode 'cubic' only).
Certificate: (h', R) with h' >= h on {-1,1}^3, h' = h on supp pi_+, R multilinear on {-1,1}^N with monomials on assigned pairs and
triples (and all constants/linear terms), R <= 0 at the vertices, coefficients aggregated over columns / pairs / triples with the same
law equal to those of h' (pair-class linear terms aggregate to h'_i + h'_j, since w_i and w_j have the same law); and laws rho_b on
{-1,1}^N (b = +-1) with all assigned marginals.  Then Gamma_nu(F) <= E[h'(Y)] = E[R] <= 0 for all k, nu, F.
Designs are enumerated up to permutations of the columns within each class.
usage: python3 coupling_designs.py MODE NAMES PATTERNS [workers]
  e.g. python3 coupling_designs.py pairs rep1,rep2,rep3,rep5,rep6,rep7,rep8,rep9,rep10 pps,ppps,ppss,pppps,pppss,ppsss
       python3 coupling_designs.py cubic rep5,rep6,rep10 ppssss,pppsss,ppppps,ppppss 8
"""
import itertools
import sys
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np
from scipy.optimize import linprog

W3 = list(itertools.product((1, -1), repeat=3))
REPS = {
    'rep1': [-2, -2, -1, 0, -1, 1, 0, -1],
    'rep2': [-2, -2, -1, 0, 1, -2, -1, -1],
    'rep3': [-2, -2, -1, 1, 0, -1, -1, 0],
    'rep5': [-2, -1, -1, 0, 1, -2, 0, -1],
    'rep6': [-2, -1, 0, -1, 1, -2, -1, 0],
    'rep7': [-1, -2, -1, 0, 1, -2, -1, 0],
    'rep8': [-1, -2, -1, 0, 1, -2, 0, -1],
    'rep9': [-1, -2, 0, -1, 1, -2, -1, 0],
    'rep10': [-1, -2, 0, 0, 1, -1, -1, 0],
}
STATE = {}


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def setup(name):
    h = {w: Fr(v, 2) for w, v in zip(W3, REPS[name])}
    mu = sum(h.values()) / 8
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    lvl1 = [sum(h[w] * w[a] for w in W3) / 8 for a in range(3)]
    groups = {}
    for a, c in enumerate(lvl1):
        groups.setdefault(c, []).append(a)
    (i, j), (s,) = sorted(groups.values(), key=len, reverse=True)
    pair_laws = {}
    for b in (1, -1):
        for key, (a, c) in {'ij': (i, j), 'is': (i, s), 'js': (j, s)}.items():
            M = np.zeros((2, 2))
            for w, p in pi[b].items():
                M[int(w[a] == -1), int(w[c] == -1)] += float(p)
            pair_laws[(b, key)] = M
    marg = {b: (float(sum(p for w, p in pi[b].items() if w[i] == 1)), float(sum(p for w, p in pi[b].items() if w[s] == 1)))
            for b in (1, -1)}
    supp = [w for w in W3 if pi[1][w] > 0]
    free = [w for w in W3 if w not in supp]
    pif = {b: {w: float(p) for w, p in pi[b].items()} for b in (1, -1)}
    return h, (i, j, s), pair_laws, marg, supp, free, pif


def rho_feasible(N, cls, assign, triples, st):
    h, (i, j, s), pair_laws, marg, supp, free, pi = st
    Uarr = np.array(list(itertools.product((1, -1), repeat=N)))
    for b in (1, -1):
        A, rhs = [np.ones(len(Uarr))], [1.0]
        for a in range(N):
            A.append((Uarr[:, a] == 1).astype(float))
            rhs.append(marg[b][0] if cls[a] == 'p' else marg[b][1])
        for (a, c), law in assign.items():
            if law == 'free':
                continue
            M = pair_laws[(b, law)]
            if cls[a] == 's':
                M = M.T
            for x, y in [(1, 1), (1, -1), (-1, 1)]:
                A.append(((Uarr[:, a] == x) & (Uarr[:, c] == y)).astype(float))
                rhs.append(M[int(x == -1), int(y == -1)])
        for (a, c, e, orient) in triples:
            ii, jj = (i, j) if orient == 0 else (j, i)
            for x, y, z in itertools.product((1, -1), repeat=3):
                if (x, y, z) == (-1, -1, -1):
                    continue
                A.append(((Uarr[:, a] == x) & (Uarr[:, c] == y) & (Uarr[:, e] == z)).astype(float))
                rhs.append(sum(p for w, p in pi[b].items() if w[ii] == x and w[jj] == y and w[s] == z))
        res = linprog(np.zeros(len(Uarr)), A_eq=np.array(A), b_eq=np.array(rhs), bounds=[(0, None)] * len(Uarr), method='highs')
        if res.status != 0:
            return False
    return True


def R_feasible(N, cls, assign, triples, st):
    h, (i, j, s), pair_laws, marg, supp, free, pi = st
    pairs = list(itertools.combinations(range(N), 2))
    nh, nt = len(free), len(triples)
    nv = nh + 1 + N + len(pairs) + nt
    o0, oa, oac, ot = nh, nh + 1, nh + 1 + N, nh + 1 + N + len(pairs)

    def hcoef(S):
        row = np.zeros(nv)
        for t, w in enumerate(free):
            row[t] = chi(S, w) / 8
        return float(sum(h[w] * chi(S, w) for w in supp)) / 8, row

    A_eq, b_eq = [], []

    def equate(S, cols):
        c, r = hcoef(S)
        row = -r
        for k in cols:
            row[k] += 1
        A_eq.append(row)
        b_eq.append(c)

    equate((0, 1, 2), [ot + t for t in range(nt)])
    equate((), [o0])
    ci, ri = hcoef((i,))
    cj, rj = hcoef((j,))
    row = -(ri + rj)
    for a in range(N):
        if cls[a] == 'p':
            row[oa + a] += 1
    A_eq.append(row)
    b_eq.append(ci + cj)
    equate((s,), [oa + a for a in range(N) if cls[a] == 's'])
    for law, S in [('ij', tuple(sorted((i, j)))), ('is', tuple(sorted((i, s)))), ('js', tuple(sorted((j, s))))]:
        equate(S, [oac + t for t, pr in enumerate(pairs) if assign[pr] == law])
    for t, pr in enumerate(pairs):
        if assign[pr] == 'free':
            row = np.zeros(nv)
            row[oac + t] = 1
            A_eq.append(row)
            b_eq.append(0.0)
    A_ub = []
    for u in itertools.product((1, -1), repeat=N):
        row = np.zeros(nv)
        row[o0] = 1
        for a in range(N):
            row[oa + a] = u[a]
        for t, (a, c) in enumerate(pairs):
            row[oac + t] = u[a] * u[c]
        for t, (a, c, e, _) in enumerate(triples):
            row[ot + t] = u[a] * u[c] * u[e]
        A_ub.append(row)
    bounds = [(float(h[w]), None) for w in free] + [(None, None)] * (nv - nh)
    res = linprog(np.zeros(nv), A_ub=np.array(A_ub), b_ub=np.zeros(len(A_ub)), A_eq=np.array(A_eq), b_eq=np.array(b_eq),
                  bounds=bounds, method='highs')
    return res.status == 0, (res.x if res.status == 0 else None)


def eligible_triples(cls, assign):
    N = len(cls)
    out = []
    for a, c in itertools.combinations(range(N), 2):
        if cls[a] != 'p' or cls[c] != 'p' or assign[(a, c)] != 'ij':
            continue
        for e in range(N):
            if cls[e] != 's':
                continue
            lae, lce = assign[tuple(sorted((a, e)))], assign[tuple(sorted((c, e)))]
            if (lae, lce) == ('is', 'js'):
                out.append((a, c, e, 0))
            elif (lae, lce) == ('js', 'is'):
                out.append((a, c, e, 1))
    return out


def canonical_designs(cls):
    """All pair assignments up to permutations of columns within each class (vectorised lexicographic minimum)."""
    N = len(cls)
    pairs = list(itertools.combinations(range(N), 2))
    opts = []
    for a, c in pairs:
        if cls[a] == 'p' and cls[c] == 'p':
            opts.append(['free', 'ij'])
        elif cls[a] == 's' and cls[c] == 's':
            opts.append(['free'])
        else:
            opts.append(['free', 'is', 'js'])
    code = {'free': 0, 'ij': 1, 'is': 1, 'js': 2}
    grid = np.array(list(itertools.product(*[[code[o] for o in op] for op in opts])), dtype=np.int64)
    pidx = [a for a in range(N) if cls[a] == 'p']
    sidx = [a for a in range(N) if cls[a] == 's']
    pos = {pr: t for t, pr in enumerate(pairs)}
    weights = 3 ** np.arange(len(pairs))[::-1]
    enc = grid @ weights
    best = enc.copy()
    for pp in itertools.permutations(pidx):
        for sp in itertools.permutations(sidx):
            m = dict(zip(pidx, pp))
            m.update(zip(sidx, sp))
            perm = [pos[tuple(sorted((m[a], m[c])))] for a, c in pairs]
            permuted = np.empty_like(grid)
            permuted[:, perm] = grid
            best = np.minimum(best, permuted @ weights)
    keep = grid[enc == best]
    inv = []
    for op in opts:
        inv.append({code[o]: o for o in op})
    return [{pr: inv[t][int(row[t])] for t, pr in enumerate(pairs)} for row in keep]


def work(args):
    name, cls, assign, mode = args
    st = STATE[name]
    N = len(cls)
    el = eligible_triples(cls, assign) if mode == 'cubic' else []
    if mode == 'pairs' and not ({'is', 'js'} & set(assign.values())):
        return None
    ok, _ = R_feasible(N, cls, assign, el, st)
    if not ok:
        return None
    for r in range(0, len(el) + 1):
        for triples in itertools.combinations(el, r):
            ok, x = R_feasible(N, cls, assign, list(triples), st)
            if ok and rho_feasible(N, cls, assign, list(triples), st):
                return name, ''.join(cls), {k: v for k, v in assign.items() if v != 'free'}, triples, \
                    [round(float(t), 4) for t in x[:len(st[5])]]
    return None


def init(names):
    for name in names:
        STATE[name] = setup(name)


def main():
    mode = sys.argv[1]
    names = sys.argv[2].split(',')
    patterns = [tuple(x) for x in sys.argv[3].split(',')]
    workers = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    assert mode in ('pairs', 'cubic')
    print(f"mode {mode}: {'pair laws only' if mode == 'pairs' else 'pair laws and copies of the rows (triples)'}", flush=True)
    with Pool(workers, initializer=init, initargs=(names,)) as pool:
        for cls in patterns:
            des = canonical_designs(cls)
            for name in names:
                found = 0
                for res in pool.imap_unordered(work, [(name, cls, a, mode) for a in des], chunksize=32):
                    if res is not None:
                        found += 1
                        if found <= 2:
                            print(f"  {res[0]} {res[1]}: certificate, assigned {res[2]}, triples {res[3]}, h' at free vertices "
                                  f"{res[4]}", flush=True)
                print(f"{name} {''.join(cls)}: {len(des)} designs up to symmetry, {found} with a certificate", flush=True)


if __name__ == '__main__':
    main()
