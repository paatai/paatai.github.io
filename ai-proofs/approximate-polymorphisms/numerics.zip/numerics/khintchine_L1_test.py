"""Numerical test of the biased L1-Khintchine inequality (Theorem K of MAIN_RESULT).

chi takes the value u = sqrt((1-q)/q) with probability q and -v = -sqrt(q/(1-q))
with probability 1-q (mean 0, variance 1).  For q = 3/8 we test

    sup_{|alpha| = 1} E | sum_i alpha_i chi_i |  <=  E|chi| = 2 sqrt(q(1-q)).

Equivalently (MAIN_RESULT, Theorem K, level-one form): every [0,1]-valued P on the q-biased
cube has level-1 Fourier weight at most q(1-q).

Usage: python3 khintchine_L1_test.py [kmax] [restarts]
"""
import itertools
import sys

import numpy as np

q = 3 / 8
u = np.sqrt((1 - q) / q)
v = np.sqrt(q / (1 - q))
TARGET = 2 * np.sqrt(q * (1 - q))


def atoms(k):
    pts = np.array(list(itertools.product([u, -v], repeat=k)))
    pr = np.prod(np.where(pts > 0, q, 1 - q), axis=1)
    return pts, pr


def l1(alpha, pts, pr):
    a = np.asarray(alpha, float)
    a = a / np.linalg.norm(a)
    return float(pr @ np.abs(pts @ a))


def grad_ascent(k, pts, pr, rng, steps=400):
    a = rng.normal(size=k)
    a /= np.linalg.norm(a)
    lr = 0.05
    best = l1(a, pts, pr)
    for _ in range(steps):
        s = np.sign(pts @ a)
        g = (pr * s) @ pts
        g -= (g @ a) * a
        cand = a + lr * g
        cand /= np.linalg.norm(cand)
        val = l1(cand, pts, pr)
        if val >= best:
            a, best = cand, val
            lr = min(lr * 1.2, 0.5)
        else:
            lr *= 0.5
            if lr < 1e-9:
                break
    return best, a


def structured(m_max=60):
    """alpha = (c, s, ..., s) with m small coordinates of either sign, exact via binomials."""
    from math import comb
    out = []
    for m in range(1, m_max + 1):
        for sign in (+1, -1):
            for theta in np.linspace(0.0, np.pi / 2, 181)[1:]:
                c, s = np.cos(theta), sign * np.sin(theta) / np.sqrt(m)
                tot = 0.0
                for first, pf in ((u, q), (-v, 1 - q)):
                    for j in range(m + 1):
                        val = c * first + s * (j * u - (m - j) * v)
                        tot += pf * comb(m, j) * q ** j * (1 - q) ** (m - j) * abs(val)
                out.append((tot, m, sign, theta))
    out.sort(reverse=True)
    return out[:5]


def main():
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 10
    restarts = int(sys.argv[2]) if len(sys.argv) > 2 else 40
    rng = np.random.default_rng(1)
    print(f"q = {q}, target E|chi| = {TARGET:.10f}")
    overall = 0.0
    for k in range(2, kmax + 1):
        pts, pr = atoms(k)
        best, arg = 0.0, None
        for _ in range(restarts):
            val, a = grad_ascent(k, pts, pr, rng)
            if val > best:
                best, arg = val, a
        overall = max(overall, best)
        srt = np.sort(np.abs(arg))[::-1]
        print(f"k={k:2d}  best E|L| = {best:.10f}  (target - best = {TARGET - best:.3e})  "
              f"top |alpha| = {np.round(srt[:3], 4)}", flush=True)
    print("structured (c, s/sqrt(m) x m):")
    for tot, m, sign, theta in structured():
        print(f"   E|L| = {tot:.10f}  m={m} sign={sign:+d} theta={theta:.4f}")
    print(f"overall best random-start value {overall:.10f} vs target {TARGET:.10f}")


if __name__ == "__main__":
    main()
