"""Sanity test of the pointwise bound gamma <= Gamma(m) (Lemma 4.6) on explicit configurations.

(1) Halfspaces in any dimension: Y_j = +1 iff <theta_j, V_j> > tau_j; then (<theta_j,V_j>)_j is trivariate normal
    with correlations c <theta_i, theta_j>; Pr[exactly two] by inclusion-exclusion of orthant probabilities.
(2) One-dimensional unions of intervals: Y_j = +1 iff V_j in S_j; exact via trivariate CDFs of boxes.
Reports min over configurations of Gamma(m) - gamma (must be >= 0).
"""
import itertools
import numpy as np
from scipy.stats import multivariate_normal
from scipy.special import ndtr
from e2_upper_rig import gmax, e2m

C = -1 / 14
K3 = 5.15
rng = np.random.default_rng(7)


def Gamma(m):
    m1, m2, m3 = m
    mu = (1 + np.array(m)) / 2
    from scipy.special import ndtri
    l = [0.0 if (t <= 0 or t >= 1) else 2 * np.exp(-ndtri(t) ** 2 / 2) / np.sqrt(2 * np.pi) for t in mu]
    s = [np.sqrt(max(1 - t * t, 0)) for t in m]
    k = [(1 + 3 * t) / 4 for t in m]
    first = abs(C) * gmax(np.array(k[2] * l[0] * l[1]), np.array(k[1] * l[0] * l[2]), np.array(k[0] * l[1] * l[2]))
    second = C * C * (abs(k[2]) * s[0] * s[1] + abs(k[1]) * s[0] * s[2] + abs(k[0]) * s[1] * s[2])
    trip = 0.75 * (np.sqrt(2) * C * C * (l[0] * l[1] * s[2] + l[0] * l[2] * s[1] + l[1] * l[2] * s[0])
                   + K3 * abs(C) ** 3 * s[0] * s[1] * s[2])
    return float(e2m(m1, m2, m3) + first + second + trip)


GLX, GLW = np.polynomial.legendre.leggauss(160)


def orth3(a, R):
    """Pr[X1>a1, X2>a2, X3>a3], unit-variance trivariate normal with correlation matrix R
    (1-D Gauss-Legendre over X3 in [a3, max(a3,0)+12] of the conditional bivariate orthant, Owen's T)."""
    from e2_halfspace_angles import bvn_upper
    a = np.maximum(np.asarray(a, float), -12.0)
    r12, r13, r23 = R[0, 1], R[0, 2], R[1, 2]
    s1, s2 = np.sqrt(1 - r13 ** 2), np.sqrt(1 - r23 ** 2)
    rc = (r12 - r13 * r23) / (s1 * s2)
    lo, hi = a[2], max(a[2], 0.0) + 12.0
    t = (hi - lo) / 2 * GLX + (hi + lo) / 2
    w = (hi - lo) / 2 * GLW
    vals = bvn_upper((a[0] - r13 * t) / s1, (a[1] - r23 * t) / s2, rc)
    return float(np.sum(w * np.exp(-t * t / 2) / np.sqrt(2 * np.pi) * vals))


def box_prob(cov, lo, hi):
    """Pr[lo < X < hi] by inclusion-exclusion over upper orthants (terms with a +inf threshold vanish)."""
    tot = 0.0
    for S in itertools.product((0, 1), repeat=3):
        pt = [hi[i] if S[i] else lo[i] for i in range(3)]
        if any(np.isposinf(p) for p in pt):
            continue
        pt = [max(p, -12.0) for p in pt]
        tot += (-1) ** sum(S) * orth3(pt, cov)
    return tot


def gamma_from_sets(cov, sets):
    """sets[j] = list of disjoint intervals (lo, hi) where Y_j = +1 (scalar Gaussians with covariance cov)."""
    comp = []
    for S in sets:
        pts = [-np.inf] + [p for iv in S for p in iv] + [np.inf]
        comp.append([(pts[2 * i], pts[2 * i + 1]) for i in range(len(pts) // 2)])
    p2 = 0.0
    for pattern in [(1, 1, 0), (1, 0, 1), (0, 1, 1)]:
        lists = [sets[j] if pattern[j] else comp[j] for j in range(3)]
        for ivs in itertools.product(*lists):
            lo = [iv[0] for iv in ivs]
            hi = [iv[1] for iv in ivs]
            if any(a >= b for a, b in zip(lo, hi)):
                continue
            p2 += box_prob(cov, lo, hi)
    means = []
    for S in sets:
        pr = sum(ndtr(min(b, 40)) - ndtr(max(a, -40)) for a, b in S)
        means.append(2 * pr - 1)
    return -1 + 2 * p2, means


def test_halfspaces(ntest=400):
    worst = (np.inf, None)
    for t in range(ntest):
        d = rng.integers(1, 4)
        th = rng.normal(size=(3, d))
        if rng.random() < 0.5:     # aligned / anti-aligned directions (one-dimensional configurations)
            th = np.outer(rng.choice([-1, 1], 3), [1.0] + [0.0] * (d - 1))
        th /= np.linalg.norm(th, axis=1, keepdims=True)
        G = th @ th.T
        cov = np.eye(3) + C * (G - np.diag(np.diag(G)))
        tau = rng.normal(scale=1.2, size=3)
        sets = [[(tau[j], np.inf)] for j in range(3)]
        g, m = gamma_from_sets(cov, sets)
        gap = Gamma(m) - g
        if gap < worst[0]:
            worst = (gap, (np.round(m, 3), round(g, 4), np.round(G, 2)))
    return worst


def test_intervals(ntest=150):
    worst = (np.inf, None)
    cov = np.eye(3) + C * (np.ones((3, 3)) - np.eye(3))
    for t in range(ntest):
        sets = []
        for j in range(3):
            k = rng.integers(1, 3)
            pts = np.sort(rng.normal(scale=1.5, size=2 * k))
            if rng.random() < 0.3:
                pts[-1] = np.inf
            sets.append([(pts[2 * i], pts[2 * i + 1]) for i in range(k)])
        g, m = gamma_from_sets(cov, sets)
        gap = Gamma(m) - g
        if gap < worst[0]:
            worst = (gap, (np.round(m, 3), round(g, 4)))
    return worst


def test_extremal():
    """near the extremal case of Lemma 4.6: m = (phi, phi, -phi) with all three sets 'increasing' (aligned)."""
    cov = np.eye(3) + C * (np.ones((3, 3)) - np.eye(3))
    rows = []
    for phi in [0.3, 0.45, 0.6, 0.75, 0.9]:
        from scipy.special import ndtri
        t = ndtri((1 - phi) / 2)       # Pr[V > t] = (1+phi)/2
        t3 = ndtri((1 + phi) / 2)      # Pr[V > t3] = (1-phi)/2
        for name, sets in [("aligned", [[(t, np.inf)], [(t, np.inf)], [(t3, np.inf)]]),
                           ("(s,s,-s)", [[(t, np.inf)], [(t, np.inf)], [(-np.inf, -t3)]])]:
            g, m = gamma_from_sets(cov, sets)
            rows.append((phi, name, round(g, 5), round(Gamma(m), 5), round(Gamma(m) - g, 5)))
    return rows


def curve_losses(psi_file="outputs/e2_upper_psi_400.txt"):
    """Along (sgn, sgn, -sgn): m(x) = (f*, f*, -f*), f* = 2 Phi(x/sqrt14) - 1.  Returns E gamma^+ (exact sets),
    E Gamma(m(x))^+ and E sum_j psi(m_j(x)) (Remark 4.10)."""
    from scipy.integrate import quad
    d = np.loadtxt(psi_file)
    psi = lambda t: np.interp(t, d[:, 0], d[:, 1])
    fs = lambda x: 2 * ndtr(x / np.sqrt(14)) - 1
    phi = lambda x: np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
    cov = np.eye(3) + C * (np.ones((3, 3)) - np.eye(3))

    def gam(x):     # given G0 = x: q_j(G_j) = +1 iff Y_j > -x/sqrt14 (j = 1, 2), iff Y_3 < -x/sqrt14
        t = -x / np.sqrt(14)
        return gamma_from_sets(cov, [[(t, np.inf)], [(t, np.inf)], [(-np.inf, t)]])[0]

    Eg = quad(lambda x: max(gam(x), 0) * phi(x), 0.0, 12, limit=200, points=[2, 4])[0]
    EG = quad(lambda x: max(Gamma((fs(x), fs(x), -fs(x))), 0) * phi(x), -12, 12, limit=400, points=[0, 2, 4])[0]
    ES = quad(lambda x: (2 * psi(fs(x)) + psi(-fs(x))) * phi(x), -12, 12, limit=400, points=[0, 2, 4])[0]
    return Eg, EG, ES


def pointwise_floor():
    """E_x gamma_al(m(x))^+ along m(x) = (f*, f*, -f*): gamma_al(m) is gamma of the aligned configuration
    f_j = sgn(y - theta_j) (one-dimensional, all increasing) with means m.  Every bound of the form
    gamma(x) <= B(m(x)) must have B >= gamma_al, so this is a lower bound for E B(m(x))^+ along the curve."""
    from scipy.integrate import quad
    from scipy.special import ndtri
    fs = lambda x: 2 * ndtr(x / np.sqrt(14)) - 1
    phi = lambda x: np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
    cov = np.eye(3) + C * (np.ones((3, 3)) - np.eye(3))

    def gal(x):
        m = (fs(x), fs(x), -fs(x))
        th = [ndtri((1 - mj) / 2) for mj in m]          # Pr[y > th] = (1 + m)/2
        return gamma_from_sets(cov, [[(t, np.inf)] for t in th])[0]

    return quad(lambda x: max(gal(x), 0) * phi(x), -12, 12, limit=400, points=[-4, -2, 0, 2, 4])[0]


if __name__ == "__main__":
    for r in test_extremal():
        print("phi=%.2f %-9s gamma=%.5f Gamma=%.5f gap=%.5f" % r)
    print("halfspaces (random dims/directions/thresholds): min gap", test_halfspaces())
    print("1-D unions of intervals: min gap", test_intervals())
    Eg, EG, ES = curve_losses()
    print("along (sgn,sgn,-sgn): E gamma^+ = %.4e, E Gamma(m(x))^+ = %.4e, E sum psi(m_j(x)) = %.4e" % (Eg, EG, ES))
    print("along (sgn,sgn,-sgn): E gamma_aligned(m(x))^+ = %.4e (floor for bounds depending on m(x) only)"
          % pointwise_floor())
