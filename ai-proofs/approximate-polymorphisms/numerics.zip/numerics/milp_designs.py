"""Exhaustive search for coupling-design certificates with N columns as one mixed-integer linear programme (scipy.milp /
HiGHS, floating point).  Covers the designs of coupling_designs.py (two classes) and oneclass_designs.py (one class) for all
assignments at once; positive results must be re-proved exactly, negative results are numerical.

Columns have types (the class whose decoder they carry).  Binary z[a,c,K] = 1 if the pair of columns (a,c) carries the pair
law K (a distinct law of a pair of coordinates of the row whose classes are the types of a and c); binary t[a,c,e,P] = 1 if
the triple carries a copy of the row in placement P (which fixes the laws of its three pairs).  Continuous: rho_b(u) on
{-1,1}^N, the raise tf_w >= 0 of h at the vertices outside supp pi_+ (h' = h + sum_w tf_w 1_w), and the coefficients of R.
  * R <= 0 at every vertex of {-1,1}^N; R0 = h'^(0); per class, sum of column coefficients = sum of h'^({j}) over the class;
    per pair law K, sum of the coefficients of the pairs carrying K = sum of h'^({j,k}) over the coordinate pairs with law K;
    sum of the copy coefficients = h'^({1,2,3}).  Pair (copy) coefficients vanish unless z = 1 (t = 1): |coef| <= M z with
    M = |mu|, which is valid since every Fourier coefficient of R is at most E|R| = -R0 <= |mu| in modulus.
  * Column marginals of rho_b fixed by the types; z = 1 forces P(u_a = u_c = 1) = law value (with the marginals this fixes
    the pair law); t = 1 forces the three pair laws and P(u_a = u_c = u_e = 1) = pi_b(+++) (the law of three +-1 variables is
    determined by these), for both b.
usage: python3 milp_designs.py NAME N [PATTERN] [time_limit] [MODE]
  NAME in B12, C12, D12, A12, A24 (one class; PATTERN '-') or rep1, ..., rep10 (PATTERN like ppppsss, p's first).
  MODE: 'any' (no symmetry breaking), 'copy' (at least one copy; WLOG on the first triple in its first placement; for a
  two-class h the two placements of a (p, p, s) triple are exchanged by swapping the p columns), 'nocopy' (pairs only).
  'copy' and 'nocopy' together cover 'any'.  Suffix '+spec' (one class only): a spectral part as well.  For a common
  decoder G and an exchangeable pair law L with per-row correlations lam_L(+-), E_L[G G] = sum_S lam_L^S Ghat(S)^2; if
  kappa(S) = sum_L c_L lam_L^S <= kappa0 for all S != {} (imposed for |S| <= T; the tail is small), then
  sum_L c_L E_L[GG] <= (sum_L c_L - kappa0)(E G)^2 + kappa0 (as E G^2 <= 1), and (E G)^2 = E[G(V)G(V')] for a pair of
  columns with independent law.  So R gets the constant h'^(0) + kappa0, the L-pair sums h'_L - c_L, and pairs with the
  independent law and coefficient sum sum_L c_L - kappa0.
"""
import itertools
import sys
import time
from fractions import Fraction as Fr

import numpy as np
from scipy.optimize import Bounds, LinearConstraint, milp

W3 = list(itertools.product((1, -1), repeat=3))
H = {
    'A12': [-2, -2, -2, 1, 0, -1, -1, -1], 'A24': [-2, -2, -1, 1, 0, 0, -1, -1], 'D12': [-1, -2, -2, 1, 0, -1, -1, 0],
    'B12': [-2, -1, -1, 1, 0, 0, 0, -1], 'C12': [-1, -2, -2, 1, -1, 0, 0, -1],
    'rep1': [-2, -2, -1, 0, -1, 1, 0, -1], 'rep2': [-2, -2, -1, 0, 1, -2, -1, -1], 'rep3': [-2, -2, -1, 1, 0, -1, -1, 0],
    'rep5': [-2, -1, -1, 0, 1, -2, 0, -1], 'rep6': [-2, -1, 0, -1, 1, -2, -1, 0], 'rep7': [-1, -2, -1, 0, 1, -2, -1, 0],
    'rep8': [-1, -2, -1, 0, 1, -2, 0, -1], 'rep9': [-1, -2, 0, -1, 1, -2, -1, 0], 'rep10': [-1, -2, 0, 0, 1, -1, -1, 0],
}


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def build(name, N, pattern=None, mode='any', T=40, M=None):
    """M: bound on the moduli of the coefficients of R (default |mu|, valid when R <= 0; eps_designs.py passes eps_max + |mu|)."""
    h = {w: Fr(v, 2) for w, v in zip(W3, H[name])}
    mu = sum(h.values()) / 8
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    lvl1 = [sum(h[w] * w[a] for w in W3) / 8 for a in range(3)]
    groups = {}
    for a, c in enumerate(lvl1):
        groups.setdefault(c, []).append(a)
    classes = sorted(groups.values(), key=len, reverse=True)
    role_cls = {r: ci for ci, cl in enumerate(classes) for r in cl}
    if pattern is None:
        assert len(classes) == 1
        types = [0] * N
    else:
        assert len(classes) == 2 and len(pattern) == N and pattern == ''.join(sorted(pattern))
        types = [0 if ch == 'p' else 1 for ch in pattern]
    free = [w for w in W3 if pi[1][w] == 0]
    marg = {(b, ci): sum(p for w, p in pi[b].items() if w[classes[ci][0]] == 1) for b in (1, -1) for ci in range(len(classes))}

    def plaw(r1, r2):
        return tuple(sum(p for w, p in pi[b].items() if w[r1] == 1 and w[r2] == 1) for b in (1, -1))

    laws = {}
    for r1, r2 in itertools.permutations(range(3), 2):
        key = (role_cls[r1], role_cls[r2], plaw(r1, r2))
        laws.setdefault(key, set()).add(frozenset((r1, r2)))
    spec = mode.endswith('+spec')
    mode = mode.replace('+spec', '')
    pilaws = [K for K in laws if K[0] <= K[1]]
    if spec:
        assert pattern is None, "the spectral part needs one class (a common decoder)"
        K0 = (0, 0, tuple(marg[(b, 0)] ** 2 for b in (1, -1)), 'indep')
        laws[K0] = set()
        lam = {K: tuple((K[2][bi] - marg[(b, 0)] ** 2) / (marg[(b, 0)] * (1 - marg[(b, 0)])) for bi, b in enumerate((1, -1)))
               for K in pilaws}
    pairs = list(itertools.combinations(range(N), 2))
    triples = list(itertools.combinations(range(N), 3))
    zkeys = [(a, c, K) for a, c in pairs for K in laws if K[0] == types[a] and K[1] == types[c]]
    tkeys = []
    for a, c, e in triples:
        seen = set()
        for sg in itertools.permutations(range(3)):
            if [role_cls[r] for r in sg] != [types[a], types[c], types[e]]:
                continue
            ind = tuple((x, y, (role_cls[sg[i]], role_cls[sg[j]], plaw(sg[i], sg[j])))
                        for (i, x), (j, y) in itertools.combinations(list(enumerate((a, c, e))), 2))
            if ind not in seen:
                seen.add(ind)
                tkeys.append((a, c, e, ind))
    U = np.array(list(itertools.product((1, -1), repeat=N)))
    nf, nz, nt, nu = len(free), len(zkeys), len(tkeys), len(U)
    # variable layout
    o_tf, o_R0, o_Ra = 0, nf, nf + 1
    o_Rz, o_Rt = o_Ra + N, o_Ra + N + nz
    o_z, o_t = o_Rt + nt, o_Rt + nt + nz
    o_rho = o_t + nt
    o_c = o_rho + 2 * nu
    nL = len(pilaws) if spec else 0
    nv = o_c + (nL + 1 if spec else 0)
    M = float(abs(mu)) if M is None else float(M)
    rows, lo, hi = [], [], []

    def add(coefs, l, u):
        r = np.zeros(nv)
        for k, v in coefs:
            r[k] += v
        rows.append(r)
        lo.append(l)
        hi.append(u)

    def hcoef(S):
        return float(sum(h[w] * chi(S, w) for w in W3)) / 8, [(o_tf + t, -chi(S, w) / 8) for t, w in enumerate(free)]

    c0, tfc = hcoef(())
    add([(o_R0, 1)] + tfc + ([(o_c + nL, -1)] if spec else []), c0, c0)
    for ci, cl in enumerate(classes):
        cc, tcs = 0.0, []
        for j in cl:
            c1, t1 = hcoef((j,))
            cc += c1
            tcs += t1
        add([(o_Ra + a, 1) for a in range(N) if types[a] == ci] + tcs, cc, cc)
    for K, rset in laws.items():
        if K[0] > K[1] or (spec and K == K0):
            continue
        cc, tcs = 0.0, []
        for rr in rset:
            c1, t1 = hcoef(tuple(sorted(rr)))
            cc += c1
            tcs += t1
        idx = [(o_Rz + q, 1) for q, (a, c, K2) in enumerate(zkeys) if K2 == K]
        cl = [(o_c + pilaws.index(K), 1)] if spec else []
        if idx or tcs or cl or abs(cc) > 1e-12:
            add(idx + tcs + cl, cc, cc)
    if spec:
        idx = [(o_Rz + q, 1) for q, (a, c, K2) in enumerate(zkeys) if K2 == K0]
        add(idx + [(o_c + l, -1) for l in range(nL)] + [(o_c + nL, 1)], 0.0, 0.0)
        for st in range(1, T + 1):
            for s_ in range(st + 1):
                t_ = st - s_
                add([(o_c + l, float(lam[K][0] ** s_ * lam[K][1] ** t_)) for l, K in enumerate(pilaws)] + [(o_c + nL, -1)],
                    -np.inf, 0.0)
    c3, t3 = hcoef((0, 1, 2))
    add([(o_Rt + q, 1) for q in range(nt)] + t3, c3, c3)
    for u in U:
        co = [(o_R0, 1)] + [(o_Ra + a, float(u[a])) for a in range(N)]
        co += [(o_Rz + q, float(u[a] * u[c])) for q, (a, c, K) in enumerate(zkeys)]
        co += [(o_Rt + q, float(u[a] * u[c] * u[e])) for q, (a, c, e, _) in enumerate(tkeys)]
        add(co, -np.inf, 0.0)
    for q in range(nz):
        add([(o_Rz + q, 1), (o_z + q, -M)], -np.inf, 0.0)
        add([(o_Rz + q, -1), (o_z + q, -M)], -np.inf, 0.0)
    for q in range(nt):
        add([(o_Rt + q, 1), (o_t + q, -M)], -np.inf, 0.0)
        add([(o_Rt + q, -1), (o_t + q, -M)], -np.inf, 0.0)
    for a, c in pairs:
        idx = [(o_z + q, 1) for q, (a2, c2, K) in enumerate(zkeys) if (a2, c2) == (a, c)]
        if idx:
            add(idx, -np.inf, 1.0)
    zindex = {(a, c, K): q for q, (a, c, K) in enumerate(zkeys)}
    for q, (a, c, e, ind) in enumerate(tkeys):
        for x, y, K in ind:
            add([(o_t + q, 1), (o_z + zindex[(x, y, K)], -1)], -np.inf, 0.0)
    for bi, b in enumerate((1, -1)):
        base = o_rho + bi * nu
        add([(base + v, 1) for v in range(nu)], 1.0, 1.0)
        for a in range(N):
            m = float(marg[(b, types[a])])
            add([(base + v, 1) for v in range(nu) if U[v, a] == 1], m, m)
        for q, (a, c, K) in enumerate(zkeys):
            val = float(K[2][bi])
            sel = [(base + v, 1) for v in range(nu) if U[v, a] == 1 and U[v, c] == 1]
            add(sel + [(o_z + q, 1)], -np.inf, val + 1)
            add([(k, -1) for k, _ in sel] + [(o_z + q, 1)], -np.inf, -val + 1)
        p3 = float(pi[b][(1, 1, 1)])
        for q, (a, c, e, _) in enumerate(tkeys):
            sel = [(base + v, 1) for v in range(nu) if U[v, a] == 1 and U[v, c] == 1 and U[v, e] == 1]
            add(sel + [(o_t + q, 1)], -np.inf, p3 + 1)
            add([(k, -1) for k, _ in sel] + [(o_t + q, 1)], -np.inf, -p3 + 1)
    # symmetry breaking (valid up to permutations of same-type columns): mode 'copy' puts a copy on the first triple
    # (0, 1, first s column; or 0, 1, 2) in its first placement, and orders the other same-type columns by degree;
    # mode 'nocopy' forbids copies and orders all same-type columns by degree.
    forced = ()
    if mode == 'copy':
        s0 = types.index(1) if 1 in types else 2
        trip = (0, 1, s0)
        q0 = next(q for q, tk in enumerate(tkeys) if tk[:3] == trip)
        add([(o_t + q0, 1)], 1.0, 1.0)
        forced = trip
    if mode == 'nocopy':
        for q in range(nt):
            add([(o_t + q, 1)], 0.0, 0.0)
    if mode in ('copy', 'nocopy'):
        others = [a for a in range(N) if a not in forced]
        for a, a2 in zip(others, others[1:]):
            if types[a] != types[a2]:
                continue
            co = [(o_z + q, 1) for q, (x, y, K) in enumerate(zkeys) if a in (x, y)]
            co += [(o_z + q, -1) for q, (x, y, K) in enumerate(zkeys) if a2 in (x, y)]
            add(co, 0.0, np.inf)
    A = np.array(rows)
    lb = np.full(nv, -np.inf)
    ub = np.full(nv, np.inf)
    lb[o_tf:o_tf + nf] = 0
    ub[o_tf:o_tf + nf] = 4
    lb[o_Ra:o_Rt + nt] = -M
    ub[o_Ra:o_Rt + nt] = M
    lb[o_z:o_t + nt] = 0
    ub[o_z:o_t + nt] = 1
    lb[o_rho:o_c] = 0
    ub[o_rho:o_c] = 1
    if spec:
        lb[o_c:o_c + nL] = -4
        ub[o_c:o_c + nL] = 4
        lb[o_c + nL] = 0
        ub[o_c + nL] = 1
    integrality = np.zeros(nv)
    integrality[o_z:o_t + nt] = 1
    cost = np.zeros(nv)
    cost[o_z:o_t + nt] = 1
    info = dict(free=free, zkeys=zkeys, tkeys=tkeys, o=(o_tf, o_R0, o_Ra, o_Rz, o_Rt, o_z, o_t, o_rho), nu=nu, U=U, mu=mu,
                spec=spec, o_c=o_c, nL=nL, lam=(lam if spec else None), pilaws=pilaws)
    return cost, A, np.array(lo), np.array(hi), lb, ub, integrality, info


def main():
    name, N = sys.argv[1], int(sys.argv[2])
    pattern = sys.argv[3] if len(sys.argv) > 3 and sys.argv[3] != '-' else None
    tl = float(sys.argv[4]) if len(sys.argv) > 4 else 3600
    mode = sys.argv[5] if len(sys.argv) > 5 else 'any'
    cost, A, lo, hi, lb, ub, integ, info = build(name, N, pattern, mode)
    t0 = time.time()
    res = milp(cost, constraints=LinearConstraint(A, lo, hi), bounds=Bounds(lb, ub), integrality=integ,
               options=dict(time_limit=tl, disp=False))
    dt = time.time() - t0
    head = f"{name} N={N}{' ' + pattern if pattern else ''} [{mode}]: {A.shape[1]} variables, {A.shape[0]} constraints, " \
           f"{len(info['zkeys'])} pair and {len(info['tkeys'])} copy binaries; "
    if res.status == 0:
        x = res.x
        o_tf, o_R0, o_Ra, o_Rz, o_Rt, o_z, o_t, o_rho = info['o']
        zs = [info['zkeys'][q][:2] + (round(float(info['zkeys'][q][2][2][0]), 4),) for q in range(len(info['zkeys']))
              if x[o_z + q] > 0.5]
        ts = [info['tkeys'][q][:3] for q in range(len(info['tkeys'])) if x[o_t + q] > 0.5]
        extra = ''
        if info['spec']:
            extra = f"; c_L {[round(float(v), 4) for v in x[info['o_c']:info['o_c'] + info['nL']]]}, kappa0 " \
                    f"{round(float(x[info['o_c'] + info['nL']]), 4)}"
        print(head + f"FEASIBLE ({dt:.1f}s): pairs (a, c, P_+(++)) {zs}; copies {ts}; "
              f"tf {[round(float(v), 4) for v in x[o_tf:o_tf + len(info['free'])]]}{extra}", flush=True)
    elif res.status == 2:
        print(head + f"INFEASIBLE ({dt:.1f}s)", flush=True)
    else:
        print(head + f"status {res.status} ({res.message}) after {dt:.1f}s", flush=True)


if __name__ == '__main__':
    main()
