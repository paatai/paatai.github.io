"""The 34 one-class |J| = 2 candidates for m = 9 (r = 7) left undecided by Proposition 10.7's methods (class UNDEC in
outputs/maxcorr_J2_r7.txt, produced by `python3 maxcorr_J2.py 7`).

For each candidate (mu < 0) this recomputes in exact arithmetic: the dangerous sign, a, q, r, theta and the odd l attaining it,
the minimum of Phi# (negative) and its location, whether that location lies in (q^2, q), the value Phi#(q^2) and, if theta is
attained at l = 1, that Phi#(q^2) is the value of the AND of two labels; and the exact maximum of Gamma over [-1,1]-valued
decoders with k <= 3 (negative: no certificate with k <= 3). For l = 1 it also checks that P = 1[z_1 = cbar, z_2 = c] attains
Phi# at p = q(1-q), where Phi# > 0, and that the minimiser of Phi# lies in (q^2, q(1-q)).
"""
import re
import sys
from fractions import Fraction as Fr

sys.argv = sys.argv[:1] + ['7']
import maxcorr_J2 as M  # noqa: E402
from fsharp_check import params, sharp_pieces  # noqa: E402
from j2_k2_exact import cube_max, quad_form  # noqa: E402


def phi_sharp(pieces, p):
    for c0, c1, c2, lo, hi in pieces:
        if lo <= p <= hi:
            return c0 + c1 * p + c2 * p * p
    raise ValueError


def piece_argmin(c0, c1, c2, lo, hi):
    cands = [lo, hi]
    if c2 > 0 and lo < -c1 / (2 * c2) < hi:
        cands.append(-c1 / (2 * c2))
    return min(cands, key=lambda p: c0 + c1 * p + c2 * p * p)


def and2_value(hv, s=1, mixed=False):
    """Gamma for the decoder P = 1[z_1 = z_2 = c] (s = 1) or P = 1 - 1[z_1 = z_2 = c] (s = -1); with mixed=True,
    P = 1[z_1 = cbar, z_2 = c] (s = 1) or its complement (s = -1).  k = 2, both rows of the dangerous sign, c the less likely
    value of w_1 under it."""
    mu, b, lam, qq = params(hv)
    nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    _, pi = M.laws(hv)
    e = pi[nus][0] + pi[nus][1] - pi[nus][2] - pi[nus][3]
    c = 1 if (1 + e) / 2 <= (1 - e) / 2 else -1
    top = (-c, c) if mixed else (c, c)
    F = {z: (s if z == top else -s) for z in [(1, 1), (1, -1), (-1, 1), (-1, -1)]}
    return M.gamma(hv, pi, (nus, nus), F)


if __name__ == '__main__':
    rows = [ln for ln in open('outputs/maxcorr_J2_r7.txt') if ln.startswith('  UNDEC')]
    assert len(rows) == 34
    out = []
    for ln in rows:
        hv = tuple(Fr(s) for s in re.search(r"= \('([^']*)', '([^']*)', '([^']*)', '([^']*)'\)", ln).groups())
        a, q, r, th, _, pieces = sharp_pieces(hv)
        ells = [l for l in range(1, 200, 2) if (r ** l - a ** l) / (1 + r ** l) == th]
        mins = [M.quad_min(*pc) for pc in pieces]
        mn = min(mins)
        assert mn < 0
        neg = [i for i, v in enumerate(mins) if v < 0]
        assert neg in ([0], [2])
        pstar = piece_argmin(*pieces[neg[0]])
        lo_, hi_ = (q * q, q) if neg == [0] else (1 - q, 1 - q * q)
        assert pieces[neg[0]][2] > 0 and phi_sharp(pieces, lo_) > 0 and phi_sharp(pieces, hi_) > 0 and lo_ < pstar < hi_
        best = max(cube_max(*quad_form(hv, nu))[0]
                   for k in (1, 2, 3) for nu in [tuple([1] * j + [-1] * (k - j)) for j in range(k, -1, -1)])
        assert best <= 0
        ph_q2 = phi_sharp(pieces, lo_ if neg == [0] else hi_)
        and_ok = None
        if ells and ells[0] == 1:
            s_ = 1 if neg == [0] else -1
            pm = q * (1 - q) if neg == [0] else 1 - q * (1 - q)
            ph_qm = phi_sharp(pieces, pm)
            and_ok = (-and2_value(hv, s_) == ph_q2 and -and2_value(hv, s_, mixed=True) == ph_qm and ph_qm > 0
                      and (q * q < pstar < pm if neg == [0] else pm < pstar < 1 - q * q))
        out.append((hv, a, q, th, ells[:1], neg, mn, pstar, ph_q2, and_ok, best))
    out.sort(key=lambda t: t[6])
    print("h | q | a | theta (attained at l) | negative piece(s) | min Phi# | argmin p* | p* in (q^2,q) or mirror | "
          "Phi#(q^2) (Phi#(1-q^2) for mirror) | AND2 exact there | max Gamma, k<=3")
    for hv, a, q, th, ell, neg, mn, ps, pq2, aok, best in out:
        print(f"{tuple(str(v) for v in hv)} | {q} | {a} | {th} (l={ell}) | {neg} | {float(mn):.4e} | {float(ps):.4f} | "
              f"{q * q < ps < q or (1 - q) < ps < 1 - q * q} | {float(pq2):+.4e} | {aok} | {float(best):.3e}")
    print("all 34: Phi# is negative only on one piece, convex there, and positive at q^2 and q (at 1-q and 1-q^2 for the "
          "mirror images), so {Phi# < 0} is a subinterval of (q^2, q) or of (1-q, 1-q^2)")
    print(f"all 34: min Phi# in [{float(min(t[6] for t in out)):.4e}, {float(max(t[6] for t in out)):.4e}]; "
          f"theta attained at l = 1 for {sum(1 for t in out if t[4] == [1])}; "
          f"whenever l = 1: AND2 equals Phi#(q^2), 1[z1 = cbar, z2 = c] equals Phi#(q(1-q)) > 0, and the minimiser lies in "
          f"(q^2, q(1-q)) (mirrored for the mirror images): {all(t[9] for t in out if t[4] == [1])}")
