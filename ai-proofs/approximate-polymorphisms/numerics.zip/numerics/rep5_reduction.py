"""rep5: exact checks of the reduction to a two-function inequality (Remark rem:rep5 of Section 11).

For the representative 2h = (-2,-1,-1,0,1,-2,0,-1) of rep5 (pair class {1,2}, singleton class {3}) and h' = h + 1_{-+-}:
  (1) pi_+(-+-) = 0, h' - h = 1_{-+-} >= 0 on [-1,1]^3, and 4h'(y) = -1 - y1 (1 + y2 + y3);
  (2) the pair laws of (w1,w2) and of (w1,-w3) under pi_+ and pi_-; the law of (w2,-w3) equals that of (w1,w2);
  (3) for decoders F_p, F_s:  4 E h'(Y) = -1 - E F_p(X1) - E[F_p(X1)F_p(X2)] - E[F_p(X1)F_s(X3)], and the maximum over F_s
      is attained at F_s = -sgn E[F_p(X1) | X3]; in terms of P = (1 + F_p)/2 the resulting condition max_{F_s} E h'(Y) <= 0 is
      E(2E[P(X1)|X3] - 1)_+ <= 2E[P(X1)P(X2)]                                                              (R5)
  (4) Gamma = 0 for the dictator pair (k = 1, nu = +) and for (F_p, F_s) = (AND2, OR2) (k = 2, nu = (+,+)), and (R5) is
      an equality for P = 0, the dictator, the AND of two labels and P = 1{z = (1,-1)} (nu = (+,+)); for the last one
      Gamma = -1/100 < 0 at the best response; over all {0,1}-valued P depending on all k <= 3 labels and all nu, (R5)
      holds, with equality exactly in these cases;
  (5) with B~(v) := 1{2E[P(X1)|X3 = -v] > 1}, (R5) reads Psi(P, B~) >= 0 where
      Psi(P, B) = 2E_{L2}[P P] - 2E_{Lv}[P B] + E B,  and Psi(P, P) >= 0 is the inequality -p - 2E[P1P2] + 2E[P2P3] <= 0
      proved for D12 in Proposition 9.11 (same pair laws);
  (6) exact random tests (k <= 3, all nu): Gamma <= E h'(Y), the formula in (3), and the best-response identity.
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
H2 = [-2, -1, -1, 0, 1, -2, 0, -1]
h = {w: Fr(v, 2) for w, v in zip(W3, H2)}
mu = sum(h.values()) / 8
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}


def mlin(f, y):
    """multilinear extension of f: {-1,1}^3 -> Q at y in [-1,1]^3"""
    out = Fr(0)
    for w in W3:
        wt = Fr(1)
        for wi, yi in zip(w, y):
            wt *= (1 + wi * Fr(yi)) / 2
        out += wt * f[w]
    return out


def fourier(f):
    return {S: sum(f[w] * (w[0] if 0 in S else 1) * (w[1] if 1 in S else 1) * (w[2] if 2 in S else 1) for w in W3) / 8
            for S in [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]}


def check(cond, msg):
    if not cond:
        raise AssertionError(msg)
    print("ok:", msg)


hp = dict(h)
hp[(-1, 1, -1)] += 1
check(mu == Fr(-3, 8), "mu = -3/8")
check(pi[1][(-1, 1, -1)] == 0 and pi[1][(1, 1, 1)] == 0, "supp pi_+ misses exactly +++ and -+-")
check(all(pi[1][w] > 0 for w in W3 if w not in [(1, 1, 1), (-1, 1, -1)]), "pi_+ > 0 elsewhere")
fh = fourier(hp)
check(fh == {(): Fr(-1, 4), (0,): Fr(-1, 4), (1,): 0, (2,): 0, (0, 1): Fr(-1, 4), (0, 2): Fr(-1, 4), (1, 2): 0, (0, 1, 2): 0},
      "4h'(y) = -1 - y1 - y1y2 - y1y3")
check(all(4 * hp[w] == -1 - w[0] * (1 + w[1] + w[2]) for w in W3), "4h' = -1 - y1(1+y2+y3) at the vertices")
fl = fourier(h)
check([fl[(j,)] for j in range(3)] == [Fr(-1, 8), Fr(-1, 8), Fr(1, 8)], "classes {1,2}, {3}")


def plaw(b, i, j, sj=1):
    return tuple(sum(p for w, p in pi[b].items() if w[i] == s and sj * w[j] == t) for s, t in [(1, 1), (1, -1), (-1, 1), (-1, -1)])


L2 = {b: plaw(b, 0, 1) for b in (1, -1)}
Lv = {b: plaw(b, 0, 2, -1) for b in (1, -1)}
Lu = {b: plaw(b, 1, 2, -1) for b in (1, -1)}
check(L2[1] == (Fr(1, 10), Fr(3, 10), Fr(3, 10), Fr(3, 10)) and L2[-1] == (Fr(7, 22), Fr(5, 22), Fr(5, 22), Fr(5, 22)),
      "law of (w1,w2): (1,3,3,3)/10 and (7,5,5,5)/22")
check(Lv[1] == (Fr(3, 10), Fr(1, 10), Fr(1, 10), Fr(5, 10)) and Lv[-1] == (Fr(5, 22), Fr(7, 22), Fr(7, 22), Fr(3, 22)),
      "law of (w1,-w3): (3,1,1,5)/10 and (5,7,7,3)/22")
check(Lu == L2, "law of (w2,-w3) = law of (w1,w2)")
# the D12 laws of Proposition 9.11: (w1,w2) and (w2,w3) of h_{g2}
hD = {w: Fr(v, 2) for w, v in zip(W3, [-1, -2, -2, 1, 0, -1, -1, 0])}
muD = sum(hD.values()) / 8
piD = {b: {w: (1 + b * hD[w]) / (8 * (1 + b * muD)) for w in W3} for b in (1, -1)}
D12 = {b: tuple(sum(p for w, p in piD[b].items() if w[0] == s and w[1] == t) for s, t in [(1, 1), (1, -1), (-1, 1), (-1, -1)])
       for b in (1, -1)}
D23 = {b: tuple(sum(p for w, p in piD[b].items() if w[1] == s and w[2] == t) for s, t in [(1, 1), (1, -1), (-1, 1), (-1, -1)])
       for b in (1, -1)}
check(D12 == L2 and D23 == Lv, "the pair laws (w1,w2), (w2,w3) of D12 (Prop. 9.11) are L2 and Lv")


def columns(nu):
    """joint law of the three columns: dict (z1, z2, z3) -> prob, z_j in {-1,1}^k"""
    out = {((), (), ()): Fr(1)}
    for b in nu:
        new = {}
        for (z1, z2, z3), p in out.items():
            for w, q in pi[b].items():
                if q:
                    key = (z1 + (w[0],), z2 + (w[1],), z3 + (w[2],))
                    new[key] = new.get(key, 0) + p * q
        out = new
    return out


def gamma(f, Fp, Fs, nu):
    return sum(p * mlin(f, (Fp[z1], Fp[z2], Fs[z3])) for (z1, z2, z3), p in columns(nu).items())


def reduced(Fp, Fs, nu):
    J = columns(nu)
    E = lambda g: sum(p * g(z1, z2, z3) for (z1, z2, z3), p in J.items())
    return (-1 - E(lambda a, b, c: Fp[a]) - E(lambda a, b, c: Fp[a] * Fp[b]) - E(lambda a, b, c: Fp[a] * Fs[c])) / 4


def best_response_value(Fp, nu):
    """max over F_s of E h'(Y) = (-1 - E a - E[a1 a2] + E|E[a1 | X3]|)/4"""
    J = columns(nu)
    cond = {}
    m3 = {}
    for (z1, z2, z3), p in J.items():
        cond[z3] = cond.get(z3, 0) + p * Fp[z1]
        m3[z3] = m3.get(z3, 0) + p
    Ea = sum(p * Fp[z1] for (z1, z2, z3), p in J.items())
    Eaa = sum(p * Fp[z1] * Fp[z2] for (z1, z2, z3), p in J.items())
    L1 = sum(abs(v) for v in cond.values())
    Fs = {z: (-1 if cond[z] > 0 else 1) for z in cond}
    return (-1 - Ea - Eaa + L1) / 4, Fs


def r5_sides(P, nu):
    J = columns(nu)
    cond, m3 = {}, {}
    for (z1, z2, z3), p in J.items():
        cond[z3] = cond.get(z3, 0) + p * P[z1]
        m3[z3] = m3.get(z3, 0) + p
    lhs = sum(max(2 * cond[z] - m3[z], 0) for z in cond)
    rhs = 2 * sum(p * P[z1] * P[z2] for (z1, z2, z3), p in J.items())
    return lhs, rhs


def cube(k):
    return list(itertools.product((1, -1), repeat=k))


# (4) equality cases
dic = {z: z[0] for z in cube(1)}
check(gamma(h, dic, dic, (1,)) == 0, "Gamma = 0 for the dictator pair (k = 1, nu = +)")
AND2 = {z: (1 if z == (1, 1) else -1) for z in cube(2)}
OR2 = {z: (-1 if z == (-1, -1) else 1) for z in cube(2)}
check(gamma(h, AND2, OR2, (1, 1)) == 0, "Gamma = 0 for (F_p, F_s) = (AND2, OR2), k = 2, nu = (+,+)")
val, Fs = best_response_value(AND2, (1, 1))
check(val == 0 and Fs == OR2, "OR2 is the best response to AND2 for E h', with value 0")
for P, nu, name in [({z: 0 for z in cube(1)}, (1,), "P = 0"), ({z: (1 if z[0] == 1 else 0) for z in cube(1)}, (1,), "dictator"),
                    ({z: (1 if z == (1, 1) else 0) for z in cube(2)}, (1, 1), "AND2"),
                    ({z: (1 if z == (1, -1) else 0) for z in cube(2)}, (1, 1), "1{z = (1,-1)}")]:
    lhs, rhs = r5_sides(P, nu)
    check(lhs == rhs, f"(R5) is an equality for {name} ({lhs} = {rhs})")
P10 = {z: (1 if z == (1, -1) else 0) for z in cube(2)}
F10 = {z: 2 * P10[z] - 1 for z in cube(2)}
val, Fs = best_response_value(F10, (1, 1))
check(val == 0 and gamma(h, F10, Fs, (1, 1)) == Fr(-1, 100),
      "for P = 1{z = (1,-1)}: max over F_s of E h'(Y) is 0, but Gamma = -1/100 at the maximiser")
eqs = []
for k in range(1, 4):
    for npos in range(k + 1):
        nu = (1,) * npos + (-1,) * (k - npos)
        for bits in itertools.product((0, 1), repeat=2 ** k):
            P = dict(zip(cube(k), bits))
            if any(bits) and all(any(P[z] != P[z[:i] + (-z[i],) + z[i + 1:]] for z in cube(k)) for i in range(k)):
                lhs, rhs = r5_sides(P, nu)
                assert lhs <= rhs, (k, nu, bits)
                if lhs == rhs:
                    eqs.append((k, nu, tuple(z for z in cube(k) if P[z])))
check(sorted(eqs) == sorted([(1, (1,), ((1,),)), (2, (1, 1), ((1, 1),)), (2, (1, 1), ((1, -1),)), (2, (1, 1), ((-1, 1),))]),
      "{0,1}-valued P depending on all k <= 3 labels, all nu: (R5) holds, with equality exactly for the dictator (nu = +), "
      "AND2 and 1{z = (1,-1)}, 1{z = (-1,1)} (nu = (+,+))")

# (5) Psi(P, P) is the D12 expression of Prop. 9.11, and (R5) is min over B of Psi(P, B) >= 0
def psi(P, B, nu):
    J = columns(nu)
    E2 = sum(p * P[z1] * P[z2] for (z1, z2, z3), p in J.items())
    Ev = sum(p * P[z1] * B[tuple(-x for x in z3)] for (z1, z2, z3), p in J.items())
    EB = sum(p * B[tuple(-x for x in z3)] for (z1, z2, z3), p in J.items())
    return 2 * E2 - 2 * Ev + EB


def d12_expr(P, nu):
    """-p - 2E[P1P2] + 2E[P2P3] for the D12 row laws (Prop. 9.11, one decoder)"""
    out = {((), (), ()): Fr(1)}
    for b in nu:
        new = {}
        for (z1, z2, z3), p in out.items():
            for w, q in piD[b].items():
                if q:
                    key = (z1 + (w[0],), z2 + (w[1],), z3 + (w[2],))
                    new[key] = new.get(key, 0) + p * q
        out = new
    E = lambda g: sum(p * g(z1, z2, z3) for (z1, z2, z3), p in out.items())
    return -E(lambda a, b, c: P[a]) - 2 * E(lambda a, b, c: P[a] * P[b]) + 2 * E(lambda a, b, c: P[b] * P[c])


rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
ntest = int(sys.argv[1]) if len(sys.argv) > 1 else 20


def rnd():
    return Fr(rng.randint(-12, 12), 12)


count = 0
for k in range(0, 4):
    for npos in range(k + 1):
        nu = (1,) * npos + (-1,) * (k - npos)
        for _ in range(ntest if k > 0 else 2):
            Fp = {z: rnd() for z in cube(k)}
            Fsr = {z: rnd() for z in cube(k)}
            g = gamma(h, Fp, Fsr, nu)
            e = gamma(hp, Fp, Fsr, nu)
            assert g <= e, (k, nu)
            assert e == reduced(Fp, Fsr, nu), (k, nu)
            val, Fs = best_response_value(Fp, nu)
            assert gamma(hp, Fp, Fs, nu) == val and val >= e
            P = {z: (1 + Fp[z]) / 2 for z in cube(k)}
            lhs, rhs = r5_sides(P, nu)
            assert 4 * val == 2 * (lhs - rhs), (k, nu)
            assert psi(P, P, nu) == -d12_expr(P, nu)
            Bt = {z: (1 if 2 * sum(p * P[z1] for (z1, z2, z3), p in columns(nu).items() if z3 == tuple(-x for x in z))
                       > sum(p for (z1, z2, z3), p in columns(nu).items() if z3 == tuple(-x for x in z)) else 0) for z in cube(k)}
            assert psi(P, Bt, nu) == rhs - lhs
            count += 1
print(f"ok: {count} exact random tests (k <= 3, all nu): Gamma <= E h'(Y) = formula (3); best response value; "
      f"4 max_Fs E h' = 2(LHS - RHS of (R5)); Psi(P,P) = -(D12 expression); Psi(P, B~) = RHS - LHS")
