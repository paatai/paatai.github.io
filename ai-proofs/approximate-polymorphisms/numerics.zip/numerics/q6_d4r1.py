"""Exact classification of the m = 5 functions with |J| = 4, |U| = 1 (the case not covered by q6_hsearch.py).

Here h(w) = (g(w,+1) + g(w,-1))/2 takes values in {-1,0,1} on {+-1}^4, and h is realisable by some g depending
on the u-coordinate with ghat({u}) = 0 iff the number of zeros of h is even and positive (each zero w contributes
g(w,+1) - g(w,-1) = +-2 to 8*ghat({u}), and we can choose the signs to cancel).  Conditions: hhat({j}) != 0 for
j = 1..4, mu != 0.  For every such h (all 3^16, integer arithmetic, no symmetry reduction) we test, after
normalising mu < 0 (h -> -h, i.e. g -> -g):
  TRIV : max_w h(w) <= 0                               (Theorem C(i): s_g trivial)
  L0   : h(w) > 0 for some class-constant w             (s^L_g nontrivial)
  LAB1 : k = 1, nu = +-1, class-wise decoders in {id,-id,+1,-1}, sum_a (1 + nu h(a)) h(tau(a)) > 0
  LAB2 : k = 2 exact (Boolean decoders), as in q6_exact_k2.py
and report the counts and the survivors.
"""
import itertools
import numpy as np

d = 4
P = np.array(list(itertools.product([1, -1], repeat=d)), dtype=np.int64)   # 16 x 4
n = len(P)

# set partitions of [4] -> mask of class-constant w (as boolean over the 16 points)
def partitions(s):
    if not s:
        yield []
        return
    first, rest = s[0], s[1:]
    for p in partitions(rest):
        for i in range(len(p)):
            yield p[:i] + [[first] + p[i]] + p[i + 1:]
        yield [[first]] + p

PARTS = list(partitions(list(range(d))))
def part_key(blocks):
    lab = [0] * d
    for b, blk in enumerate(blocks):
        for j in blk:
            lab[j] = b
    # canonical relabel
    m, out = {}, []
    for x in lab:
        m.setdefault(x, len(m))
        out.append(m[x])
    return tuple(out)
PKEYS = {part_key(p): i for i, p in enumerate(PARTS)}
MASK = np.zeros((len(PARTS), n), dtype=bool)
for key, i in PKEYS.items():
    for t, w in enumerate(P):
        MASK[i, t] = all(w[a] == w[b] for a in range(d) for b in range(d) if key[a] == key[b])

# k = 1 decoders tau in {id, -id, +1, -1}: image of coordinate value x in {+-1}
TAU = [lambda x: x, lambda x: -x, lambda x: 1 + 0 * x, lambda x: -1 + 0 * x]
pidx = {tuple(w): t for t, w in enumerate(P.tolist())}


def classes_of(l1):
    lab, m = [], {}
    for v in l1:
        m.setdefault(v, len(m))
        lab.append(m[v])
    return tuple(lab)


def lab1(h, cls):
    R = max(cls) + 1
    best = None
    for combo in itertools.product(range(4), repeat=R):
        img = np.stack([TAU[combo[cls[j]]](P[:, j]) for j in range(d)], axis=1)
        tid = [pidx[tuple(r)] for r in img.tolist()]
        hv = h[tid]
        for nu in (1, -1):
            v = int(((1 + nu * h) * hv).sum())
            best = v if best is None else max(best, v)
    return best


T3 = list(itertools.product([1, 0, -1], repeat=d))
def h16_table(h):
    hv = {tuple(w): int(x) for w, x in zip(P.tolist(), h)}
    out = np.zeros(len(T3), dtype=np.int64)
    for i, t in enumerate(T3):
        zs = [j for j in range(d) if t[j] == 0]
        tot = 0
        for s in itertools.product([1, -1], repeat=len(zs)):
            w = list(t)
            for j, v in zip(zs, s):
                w[j] = v
            tot += hv[tuple(w)]
        out[i] = tot * 16 // 2 ** len(zs)
    return out


def lab2(h, cls):
    R = max(cls) + 1
    tab = h16_table(h)
    hv = {tuple(w): int(x) for w, x in zip(P.tolist(), h)}
    labs = list(itertools.product([1, -1], repeat=2))
    lid = {l: i for i, l in enumerate(labs)}
    Fs = np.array(list(itertools.product([1, -1], repeat=4)), dtype=np.int64)
    Pl = [tuple(w) for w in P.tolist()]
    top = None
    for npos in range(3):
        nu = [1] * npos + [-1] * (2 - npos)
        Ws = list(itertools.product(Pl, repeat=2))
        wt = np.array([(1 + nu[0] * hv[W[0]]) * (1 + nu[1] * hv[W[1]]) for W in Ws], dtype=np.int64)
        keep = wt > 0
        Ws = [W for W, k in zip(Ws, keep) if k]
        wt = wt[keep]
        col = np.array([[lid[(W[0][j], W[1][j])] for j in range(d)] for W in Ws])
        allc = np.array(list(itertools.product(range(len(Fs)), repeat=R)), dtype=np.int64)
        for st in range(0, len(allc), 4096):
            combos = allc[st:st + 4096]
            idx = np.zeros((len(combos), len(Ws)), dtype=np.int64)
            for j in range(d):
                eff = Fs[combos[:, cls[j]]][:, col[:, j]]
                idx = idx * 3 + np.where(eff == 1, 0, 2)
            m = int((tab[idx] @ wt).max())
            top = m if top is None else max(top, m)
    return top


PAIRS = [(a, b) for a in range(d) for b in range(a + 1, d)]
CODE2PART = {}
for key, i in PKEYS.items():
    CODE2PART[sum(1 << p for p, (a, b) in enumerate(PAIRS) if key[a] == key[b])] = i
code2part = np.full(1 << len(PAIRS), -1, dtype=np.int64)
for c, i in CODE2PART.items():
    code2part[c] = i
PART_TIDS = {}
for key, i in PKEYS.items():
    R = max(key) + 1
    tids = []
    for combo in itertools.product(range(4), repeat=R):
        img = np.stack([TAU[combo[key[j]]](P[:, j]) for j in range(d)], axis=1)
        tids.append([pidx[tuple(r)] for r in img.tolist()])
    PART_TIDS[i] = np.array(tids, dtype=np.int64)


def lab1_vec(H, pid):
    """max over k=1 Boolean class-wise decoders and nu of sum_a (1 + nu h(a)) h(tau(a)), vectorised over rows."""
    best = np.full(len(H), -10 ** 9, dtype=np.int64)
    for tid in PART_TIDS[pid]:
        hv = H[:, tid]
        for nu in (1, -1):
            best = np.maximum(best, ((1 + nu * H) * hv).sum(axis=1))
    return best


pow3 = 3 ** np.arange(10)[::-1]
low = ((np.arange(3 ** 10)[:, None] // pow3[None, :]) % 3 - 1).astype(np.int64)   # 59049 x 10, values -1,0,1
cnt = dict(total=0, TRIV=0, L0=0, LAB1=0, LAB2=0, undecided=0)
surv = []
for hi in range(3 ** 6):
    high = np.array([(hi // 3 ** (5 - i)) % 3 - 1 for i in range(6)], dtype=np.int64)
    H = np.concatenate([np.broadcast_to(high, (len(low), 6)), low], axis=1)   # values on the 16 points
    S = H.sum(axis=1)
    L1 = H @ P                                    # 16 * hhat({j})
    nz = (H == 0).sum(axis=1)
    ok = (S != 0) & np.all(L1 != 0, axis=1) & (nz > 0) & (nz % 2 == 0)
    H, S, L1 = H[ok], S[ok], L1[ok]
    if len(H) == 0:
        continue
    sg = np.where(S > 0, -1, 1)                   # normalise mu < 0
    H = H * sg[:, None]
    L1 = L1 * sg[:, None]
    cnt['total'] += len(H)
    triv = H.max(axis=1) <= 0
    cnt['TRIV'] += int(triv.sum())
    H, L1 = H[~triv], L1[~triv]
    code = np.zeros(len(H), dtype=np.int64)
    for p, (a, b) in enumerate(PAIRS):
        code |= (L1[:, a] == L1[:, b]).astype(np.int64) << p
    pid = code2part[code]
    assert (pid >= 0).all()
    l0 = (np.where(MASK[pid], H, -9)).max(axis=1) > 0
    cnt['L0'] += int(l0.sum())
    H, L1, pid = H[~l0], L1[~l0], pid[~l0]
    for q in np.unique(pid):
        sel = pid == q
        Hq, L1q = H[sel], L1[sel]
        l1ok = lab1_vec(Hq, q) > 0
        cnt['LAB1'] += int(l1ok.sum())
        for i in np.nonzero(~l1ok)[0]:
            h = Hq[i]
            cls = classes_of(L1q[i].tolist())
            if lab2(h, cls) > 0:
                cnt['LAB2'] += 1
            else:
                cnt['undecided'] += 1
                surv.append(h.copy())
print(cnt)
np.save('outputs/hard_h_d4_r1.npy', np.array(surv))
if surv:
    S = np.array(surv)
    nrm = (S ** 2).sum(axis=1) / 16
    mu = S.sum(axis=1) / 16
    print('survivors: ||h||^2 == |mu| for', int(np.sum(np.isclose(nrm, -mu))), 'of', len(S))
    for h in S[:10]:
        print(h.tolist())
