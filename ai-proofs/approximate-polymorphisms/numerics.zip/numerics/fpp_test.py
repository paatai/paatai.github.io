"""Numerical test of strengthened brackets for the 22 UNDEC candidates (r = 6) of maxcorr_J2.py.

sigma Gamma >= sigma h(2p-1, 2p-1) - 4|b| * max_f V(f; p), where V bounds the dangerous part of -Cov/4 (Prop 10.4 notation).
Brackets compared (all with + M'(p - f), max over f in [p^2, p]):
  F+  : min(l3, l4, l5)            (Proposition 10.4)
  F++ : min(l1, l2, l3, l4, l5)    (adds the generalised Theorem L with theta = max(theta_a, theta_4))
  triv: additionally -Cov(P(X),P(Z)) <= min(p^2, (1-p)^2) (positivity of P(X)P(Z) and (1-P(X))(1-P(Z)))
"""
import itertools
from fractions import Fraction as Fr

import numpy as np

UNDEC = [
    ('-29/32', '1/32', '-1/32'), ('-27/32', '1/16', '-1/32'), ('-27/32', '3/32', '-3/32'), ('-13/16', '3/32', '-1/16'),
    ('-25/32', '1/16', '-1/32'), ('-3/4', '3/32', '-1/16'), ('-23/32', '1/16', '-1/32'), ('-23/32', '1/8', '-3/32'),
    ('-21/32', '1/8', '-3/32'), ('-9/32', '1/8', '-3/32'), ('-5/32', '1/16', '-1/32'),
]


def params(hv):
    x, z, _, y = hv
    mu = sum(hv) / 4
    pi = {s: [(1 + s * hv[i]) / (4 * (1 + s * mu)) for i in range(4)] for s in (1, -1)}
    b = (x + y - 2 * z) / 4
    lam, qq = {}, {}
    for nu in (1, -1):
        p_ = pi[nu]
        e = p_[0] + p_[1] - p_[2] - p_[3]
        e12 = p_[0] - p_[1] - p_[2] + p_[3]
        lam[nu] = (e12 - e * e) / (1 - e * e)
        qq[nu] = min((1 + e) / 2, (1 - e) / 2)
    return mu, pi, b, lam, qq


def sh(hv, p):
    x, z, _, y = hv
    return -(x * p * p + 2 * z * p * (1 - p) + y * (1 - p) ** 2)


def analyse(hv, npts=4001, nf=801):
    mu, pi, b, lam, qq = params(hv)
    assert -b > 0
    D = [nu for nu in (1, -1) if lam[nu] < 0]
    assert len(D) == 1
    nus = D[0]
    a = float(-lam[nus])
    lp = float(lam[-nus])
    q = float(qq[nus])
    r = q / (1 - q)
    beta = (1 - 2 * q) / q
    a2, Mp = a ** 3, a * lp
    A = max(a2, (Mp - a * q) / (1 - q))
    th_a = (r - a) / (1 + r)
    th_4 = max((r ** (s - 1) - a ** (s - 1)) / (1 + r ** (s - 1)) for s in range(4, 200, 2))
    th = max(th_a, th_4)
    Bt = (1 - th) / r - th
    B4 = 4 * abs(float(b))
    ps = np.linspace(0, 1, npts)
    out = {}
    for name in ('F+', 'F++', 'F++triv'):
        vals = []
        for p in ps:
            f = np.linspace(p * p, p, nf)
            l3 = a * (f - p * p)
            l4 = (a - A) * (q * f + beta * p * p) + A * (f - p * p)
            l5 = (a - A) * (q * (1 - 2 * p + f) + beta * (1 - p) ** 2) + A * (f - p * p)
            L = np.minimum(np.minimum(l3, l4), l5)
            if name != 'F+':
                l1 = a * th * f + a * Bt * p * p
                l2 = a * th * (1 - 2 * p + f) + a * Bt * (1 - p) ** 2
                L = np.minimum(np.minimum(L, l1), l2)
            V = L + Mp * (p - f)
            if name == 'F++triv':
                V = np.minimum(V, min(p * p, (1 - p) ** 2))
            vals.append(float(sh(hv, Fr(p).limit_denominator(10 ** 9))) - B4 * V.max())
        vals = np.array(vals)
        i = vals.argmin()
        out[name] = (vals[i], ps[i])
    return out, dict(a=a, lp=lp, q=q, r=r, th_a=th_a, th_4=th_4, A=A, Mp=Mp)


if __name__ == '__main__':
    for xs, zs, ys in UNDEC:
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        out, par = analyse(hv)
        print(f"h = ({xs}, {zs}, {zs}, {ys}): q = {par['q']:.4f}, a = {par['a']:.4f}, lambda' = {par['lp']:.4f}, "
              f"theta_a = {par['th_a']:.4f}, theta_4 = {par['th_4']:.4f}")
        for k, (v, p) in out.items():
            print(f"    {k:8s} min = {v:+.6f} at p = {p:.4f}")
