"""Faster Q6 enumeration for m = 4 (or 3): canonical classes under S_m x <input negation> x <output negation>,
then the s^U criterion and the 'infinity' constructions L0 / labels (see q6_enumerate.py)."""
import itertools
import sys
import numpy as np

m = int(sys.argv[1]) if len(sys.argv) > 1 else 4
KMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 1
pts = np.array(list(itertools.product([1, -1], repeat=m)))
N = len(pts)
idx = {tuple(p): i for i, p in enumerate(pts)}

# all truth tables as +-1 arrays
T = 1 - 2 * ((np.arange(2 ** N)[:, None] >> np.arange(N)[None, :]) & 1)
T = T.astype(np.int8)

# symmetries: point permutation + output sign
syms = []
for perm in itertools.permutations(range(m)):
    for ins in (1, -1):
        mp = np.array([idx[tuple(ins * pts[i][list(perm)])] for i in range(N)])
        for outs in (1, -1):
            syms.append((mp, outs))
w2 = (1 << np.arange(N)).astype(np.int64)


def code(tt):
    return ((1 - tt) // 2).astype(np.int64) @ w2


canon = np.full(2 ** N, np.iinfo(np.int64).max)
for mp, outs in syms:
    canon = np.minimum(canon, code(outs * T[:, mp]))
codes = np.arange(2 ** N)
reps_mask = canon == codes
# filters
mu = T.mean(axis=1)
par = np.prod(pts, axis=1)
isp = np.all(T == par, axis=1) | np.all(T == -par, axis=1)
dep = np.ones(2 ** N, bool)
for j in range(m):
    fl = pts.copy(); fl[:, j] *= -1
    mp = np.array([idx[tuple(p)] for p in fl])
    dep &= np.any(T != T[:, mp], axis=1)
sel = reps_mask & (mu != 0) & ~isp & dep
R = T[sel]
print(f"m={m}: {len(R)} classes")

L1 = (R @ pts) / N  # level-1 coefficients


def analyse(tt, l1):
    mu = tt.mean()
    J = [j for j in range(m) if abs(l1[j]) > 1e-12]
    hpts = list(itertools.product([1, -1], repeat=len(J)))
    h = {}
    for w in hpts:
        mask = np.all(pts[:, J] == np.array(w), axis=1) if J else np.ones(N, bool)
        h[w] = tt[mask].mean()
    sg = np.sign(mu)
    crit = any(sg * h[w] < -1e-12 for w in hpts)
    vals = sorted(set(np.round(l1[J], 12)))
    cls = [vals.index(np.round(l1[j], 12)) for j in J]
    r = len(vals)
    best0 = max(-sg * h[tuple(psi[c] for c in cls)] for psi in itertools.product([1, -1], repeat=r)) if J else -np.inf
    return dict(mu=mu, J=J, h=h, crit=crit, cls=cls, r=r, best0=best0)


def label_best(tt, A, k):
    J, h, cls, r, mu = A['J'], A['h'], A['cls'], A['r'], A['mu']
    sg = np.sign(mu)
    rows = {b: pts[tt == b][:, J] for b in (1, -1)}
    lab = list(itertools.product([1, -1], repeat=k))
    labidx = {l: i for i, l in enumerate(lab)}
    Fs = list(itertools.product([1, -1], repeat=2 ** k))
    best = -np.inf
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        Ws = list(itertools.product(*[range(len(rows[b])) for b in nu]))
        weight = 1.0 / np.prod([len(rows[b]) for b in nu])
        col = np.array([[labidx[tuple(int(rows[nu[i]][Wi[i]][t]) for i in range(k))] for t in range(len(J))] for Wi in Ws])
        for combo in itertools.product(range(len(Fs)), repeat=r):
            val = 0.0
            for crow in col:
                w = tuple(Fs[combo[cls[t]]][crow[t]] for t in range(len(J)))
                val += h[w]
            best = max(best, -sg * val * weight)
    return best


stats = {}
hard = []
for tt, l1 in zip(R, L1):
    A = analyse(tt, l1)
    if not A['crit']:
        st = 'trivial(sU)'
    elif A['best0'] > 1e-12:
        st = 'L0'
    else:
        st = None
        for k in range(1, KMAX + 1):
            if label_best(tt, A, k) > 1e-12:
                st = f'lab{k}'
                break
        if st is None:
            st = 'HARD'
            hard.append((tt, A))
    stats[st] = stats.get(st, 0) + 1
print(stats)
for tt, A in hard[:40]:
    print('HARD: mu=', A['mu'], 'J=', A['J'], 'cls=', A['cls'], 'h=', {k: round(v, 3) for k, v in A['h'].items()},
          'g^-1(+1)=', [tuple(int(v) for v in pts[i]) for i in range(N) if tt[i] == 1])
np.save(f'outputs/hard_m{m}.npy', np.array([tt for tt, _ in hard]))
