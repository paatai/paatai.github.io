"""Class flips of the 14 orbit representatives of hard288 (exact arithmetic).

For h on {-1,1}^3 and a class K (a maximal set of coordinates with equal level-one
coefficient), h^K(w) = h(w with the coordinates in K negated).  If the flipped
coefficients -hat h(j), j in K, differ from the other level-one coefficients, the
classes of h^K are those of h and criterion (c) of Theorem D holds for h iff it holds
for h^K.  If they coincide with another class, the classes merge and only
"h trivial => h^K trivial" holds.  The script prints, for every representative,
its level-one coefficients, classes, cubic coefficient, and for every class flip the
orbit (under Lemma sym) of h^K and whether classes merge.
"""
import itertools
from fractions import Fraction as Fr

W3 = list(itertools.product([1, -1], repeat=3))
reps = {
    1: (-2, -2, -1, 0, -1, 1, 0, -1), 2: (-2, -2, -1, 0, 1, -2, -1, -1), 3: (-2, -2, -1, 1, 0, -1, -1, 0),
    4: (-2, -2, -1, 1, 0, 0, -1, -1), 5: (-2, -1, -1, 0, 1, -2, 0, -1), 6: (-2, -1, 0, -1, 1, -2, -1, 0),
    7: (-1, -2, -1, 0, 1, -2, -1, 0), 8: (-1, -2, -1, 0, 1, -2, 0, -1), 9: (-1, -2, 0, -1, 1, -2, -1, 0),
    10: (-1, -2, 0, 0, 1, -1, -1, 0), 11: (-2, -2, -2, 1, 0, -1, -1, -1), 12: (-2, -1, -1, 1, 0, 0, 0, -1),
    13: (-1, -2, -2, 1, -1, 0, 0, -1), 14: (-1, -2, -2, 1, 0, -1, -1, 0)}
names = {4: 'A24 (g1)', 11: 'A12 (g0)', 12: 'B12', 13: 'C12', 14: 'D12 (g2)'}


def name(i):
    return names.get(i, f'rep{i}')


def orbit(h2):
    out = set()
    d = dict(zip(W3, h2))
    for perm in itertools.permutations(range(3)):
        for sg in (1, -1):
            for neg in (1, -1):
                out.add(tuple(neg * d[tuple(sg * w[perm[j]] for j in range(3))] for w in W3))
    return out


def fourier(h2):
    d = dict(zip(W3, h2))
    out = {}
    for S in itertools.product([0, 1], repeat=3):
        out[S] = Fr(sum(d[w] * (w[0] ** S[0]) * (w[1] ** S[1]) * (w[2] ** S[2]) for w in W3), 16)
    return out


def classes(lev1):
    cl = {}
    for j, c in enumerate(lev1):
        cl.setdefault(c, []).append(j)
    return sorted(cl.values())


orbits = {i: orbit(r) for i, r in reps.items()}
union = set().union(*orbits.values())
assert len(union) == 288 and sum(len(o) for o in orbits.values()) == 288

for i, h2 in reps.items():
    fh = fourier(h2)
    lev1 = [fh[(1, 0, 0)], fh[(0, 1, 0)], fh[(0, 0, 1)]]
    cls = classes(lev1)
    print(f"{name(i):9s} 2h={h2} |orbit|={len(orbits[i])} level1={[str(x) for x in lev1]} "
          f"classes={cls} cubic hat h(123)={fh[(1, 1, 1)]}")
    if len(cls) == 1:
        continue
    for K in cls:
        f = tuple(dict(zip(W3, h2))[tuple(-w[l] if l in K else w[l] for l in range(3))] for w in W3)
        ff = fourier(f)
        lev1f = [ff[(1, 0, 0)], ff[(0, 1, 0)], ff[(0, 0, 1)]]
        merged = len(classes(lev1f)) < len(cls)
        hit = [name(o) for o, orb in orbits.items() if f in orb]
        assert len(hit) == 1
        print(f"    flip class {[k + 1 for k in K]}: level1={[str(x) for x in lev1f]} -> orbit {hit[0]}"
              f"{'  (classes merge: only h trivial => h^K trivial)' if merged else '  (classes kept: equivalent)'}")
