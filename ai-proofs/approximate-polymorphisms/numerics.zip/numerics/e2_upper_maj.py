"""Exploration: upper bound on s^U_{E2} by majorization (Borell) + separable convex majorant.

gamma(x) = -1 + 2 P2(x), P2 = Pr[exactly two of q_j(G_j) = +1 | G_0 = x].
Given x, V_j = (G_j - rho x)/sqrt(1-rho^2) are standard Gaussian vectors with pairwise correlation
c = -1/14; V_k has canonical correlation r3 = 1/sqrt(91) with (V_i, V_j).
Borell: Pr[A_i & A_j] <= Lam(mu_i, mu_j; |c|), Pr[A_k^c & B] <= Lam(1-mu_k, Pr B; r3).
So P2 <= sum_k Lam(1-mu_k, Lam(mu_i, mu_j; |c|); r3)  =: P2max(mu).
If (-1 + 2 P2max(m))^+ <= sum_j psi(m_j) with psi convex, then (majorization of U_rho q by U_rho sgn)
E gamma^+ <= 3 E psi(2 Phi(X/sqrt14) - 1).
"""
import sys
import numpy as np
from scipy.special import ndtr, ndtri, owens_t
from scipy.optimize import linprog
from scipy.sparse import coo_matrix

C = 1 / 14
R3 = 1 / np.sqrt(91)


def bvn_upper(h, k, r):
    h = np.where(np.abs(h) < 1e-13, 1e-13, h)
    k = np.where(np.abs(k) < 1e-13, 1e-13, k)
    s = np.sqrt(1 - r * r)
    ah = (k - r * h) / (h * s)
    ak = (h - r * k) / (k * s)
    beta = np.where(h * k > 0, 0.0, 0.5)
    return 0.5 * (ndtr(-h) + ndtr(-k)) - owens_t(h, ah) - owens_t(k, ak) - beta


def lam(a, b, r):
    """Pr[Z1 <= Phi^-1(a), Z2 <= Phi^-1(b)], Corr = r >= 0 (Borell's extremal value)."""
    a = np.asarray(a, float)
    b = np.asarray(b, float)
    out = np.empty(np.broadcast(a, b).shape)
    a, b = np.broadcast_arrays(a, b)
    lo = (a <= 0) | (b <= 0)
    one_a = (a >= 1) & ~lo
    one_b = (b >= 1) & ~lo & ~one_a
    mid = ~(lo | one_a | one_b)
    out[lo] = 0.0
    out[one_a] = b[one_a]
    out[one_b] = a[one_b]
    h = ndtri(a[mid])
    k = ndtri(b[mid])
    out[mid] = bvn_upper(-h, -k, r)
    return np.clip(out, np.maximum(0, a + b - 1), np.minimum(a, b))


def p2max_borell(m1, m2, m3):
    mu = [(1 + m1) / 2, (1 + m2) / 2, (1 + m3) / 2]
    tot = 0
    for k in range(3):
        i, j = [t for t in range(3) if t != k]
        pij = lam(mu[i], mu[j], C)
        tot = tot + lam(1 - mu[k], pij, R3)
    return np.minimum(tot, 1.0)


def p2max_mc(m1, m2, m3):
    """same with maximal-correlation (covariance) bounds instead of Borell."""
    mu = [(1 + m1) / 2, (1 + m2) / 2, (1 + m3) / 2]
    tot = 0
    for k in range(3):
        i, j = [t for t in range(3) if t != k]
        pij = np.minimum(mu[i] * mu[j] + C * np.sqrt(mu[i] * (1 - mu[i]) * mu[j] * (1 - mu[j])),
                         np.minimum(mu[i], mu[j]))
        a = 1 - mu[k]
        tot = tot + np.minimum(a * pij + R3 * np.sqrt(a * (1 - a) * pij * (1 - pij)), np.minimum(a, pij))
    return np.minimum(tot, 1.0)


def phi_weights(knots, nx=200001, X=12.0):
    """w_i = E[hat_i(U)], U = 2 Phi(X/sqrt14) - 1, X ~ N(0,1)."""
    x = np.linspace(-X, X, nx)
    dens = np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
    u = 2 * ndtr(x / np.sqrt(14)) - 1
    dx = x[1] - x[0]
    N = len(knots) - 1
    h = knots[1] - knots[0]
    t = (u - knots[0]) / h
    idx = np.clip(np.floor(t).astype(int), 0, N - 1)
    frac = t - idx
    w = np.zeros(N + 1)
    np.add.at(w, idx, (1 - frac) * dens * dx)
    np.add.at(w, idx + 1, frac * dens * dx)
    return w


def solve(p2fun, N=200, label=""):
    knots = np.linspace(-1, 1, N + 1)
    g1, g2, g3 = np.meshgrid(knots, knots, knots, indexing="ij")
    G = -1 + 2 * p2fun(g1, g2, g3)
    I1, I2, I3 = np.nonzero((G > 0))
    sel = (I1 <= I2) & (I2 <= I3)  # symmetric under permutations
    I1, I2, I3 = I1[sel], I2[sel], I3[sel]
    rhs = G[I1, I2, I3]
    nc = len(rhs)
    rows = np.repeat(np.arange(nc), 3)
    cols = np.stack([I1, I2, I3], 1).ravel()
    A = coo_matrix((-np.ones(3 * nc), (rows, cols)), shape=(nc, N + 1)).tocsr()
    A.sum_duplicates()
    # convexity: -(y_{i-1} - 2 y_i + y_{i+1}) <= 0
    r2 = np.repeat(np.arange(N - 1), 3)
    c2 = np.stack([np.arange(N - 1), np.arange(1, N), np.arange(2, N + 1)], 1).ravel()
    v2 = np.tile([-1.0, 2.0, -1.0], N - 1)
    Bc = coo_matrix((v2, (r2, c2)), shape=(N - 1, N + 1)).tocsr()
    from scipy.sparse import vstack
    Aub = vstack([A, Bc]).tocsr()
    bub = np.concatenate([-rhs, np.zeros(N - 1)])
    w = 3 * phi_weights(knots)
    res = linprog(w, A_ub=Aub, b_ub=bub, bounds=[(0, None)] * (N + 1), method="highs")
    print(f"{label}: N={N}, constraints={nc}, status={res.status}, bound E gamma^+ <= {res.fun:.6e},"
          f" s^U <= {0.625 + res.fun:.6f}")
    return knots, res.x, res.fun


def curve_value(p2fun, nx=400001):
    """E[(-1+2P2max(phi,phi,-phi))^+] over x>0 (what the bound would be with no losses)."""
    x = np.linspace(0, 14, nx)
    dens = np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
    u = 2 * ndtr(x / np.sqrt(14)) - 1
    G = np.maximum(-1 + 2 * p2fun(u, u, -u), 0)
    return np.trapezoid(G * dens, x)


if __name__ == "__main__":
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 100
    for name, f in [("Borell", p2max_borell), ("maxcorr", p2max_mc)]:
        cv = curve_value(f)
        print(f"{name}: curve value (phi,phi,-phi), x>0: {cv:.6e}; x1.5 = {1.5 * cv:.6e}")
        solve(f, N, name)
