"""Re-verification of the scout's E2 numbers (PICKS.md O2-O4) and first exploration.

E2(x1,x2,x3) = +1 iff exactly two inputs are +1.
"""
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq, minimize_scalar
from scipy.special import ndtr, ndtri
from polymorph import GaussData, E2, gamma_x, U_sign

GD = GaussData(E2, 3)
print("Fourier:", {k: v for k, v in GD.coef.items()})
print("mu =", GD.mu, " rho =", GD.rho, " a =", GD.a, " s=a/sqrt(1-a^2) =", GD.s)
phi = lambda x: np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
a, sig = GD.a, np.sqrt(1 - GD.a ** 2)


def Uq_interval_sum(pieces):
    """q = sum of values v on intervals (l, r): returns z -> (U_a q)(z)."""
    def U(z):
        out = 0.0
        for (l, r, v) in pieces:
            out = out + v * (ndtr((r - a * z) / sig) - ndtr((l - a * z) / sig))
        return out
    return U


def Epos(gam, lo=-12, hi=12):
    f = lambda x: phi(x) * max(gam(x), 0.0)
    xs = np.linspace(lo, hi, 241)
    return sum(quad(f, xs[i], xs[i + 1], epsabs=1e-14, epsrel=1e-12, limit=200)[0] for i in range(len(xs) - 1))


def mk_gamma(Us, npts=48):
    return lambda x: float(gamma_x(GD, x, Us, npts=npts)[0])


sgn = U_sign(GD, 1.0)
msgn = U_sign(GD, -1.0)
t0 = ndtri(0.75)  # P(|Z| > t0) = 1/2
even = Uq_interval_sum([(-np.inf, -t0, 1.0), (-t0, t0, -1.0), (t0, np.inf, 1.0)])
meven = lambda z: -even(z)

# sanity: E gamma = mu
g_ppm = mk_gamma([sgn, sgn, msgn])
print("E gamma(++-) =", quad(lambda x: phi(x) * g_ppm(x), -12, 12, limit=200)[0])
xstar = brentq(g_ppm, 1.0, 5.0)
print("(sgn,sgn,-sgn): zero crossing x* =", xstar, " E gamma^+ =", Epos(g_ppm))

g_ppp = mk_gamma([sgn, sgn, sgn])
res = minimize_scalar(lambda x: -g_ppp(x), bounds=(-6, 6), method="bounded")
print("q=sgn: max_x P(g=+1|x) =", (1 - res.fun) / 2, "at x =", res.x)

# label construction of the scout (q_lambda = lambda * sgn)
g_pmm = mk_gamma([sgn, msgn, msgn])
g_mmm = mk_gamma([msgn, msgn, msgn])
gbar_minus = lambda x: (g_ppp(x) + g_mmm(x) + 3 * g_pmm(x)) / 5
lab = 5 / 8 + 3 / 8 * Epos(g_ppm) + 5 / 8 * Epos(gbar_minus)
print("scout label construction value =", lab)

# even-function label construction: q_lambda = lambda * Psi, Psi = sgn(|z| - t0)
g_eem = mk_gamma([even, even, meven])
print("(Psi,Psi,-Psi) Psi even: E gamma^+ =", Epos(g_eem))
g_eee = mk_gamma([even, even, even])
g_emm = mk_gamma([even, meven, meven])
g_mmm2 = mk_gamma([meven, meven, meven])
gbar_minus2 = lambda x: (g_eee(x) + g_mmm2(x) + 3 * g_emm(x)) / 5
lab2 = 5 / 8 + 3 / 8 * Epos(g_eem) + 5 / 8 * Epos(gbar_minus2)
print("even-Psi label construction value =", lab2)

# s^U candidate: (sgn, -sgn, Psi_even)
g_sme = mk_gamma([sgn, msgn, even])
print("(sgn,-sgn,Psi): E gamma^+ =", Epos(g_sme), " s^U >=", 5 / 8 + Epos(g_sme))


def B(mu):
    c, cp = -1 / 14, -1 / 13
    if mu <= 0 or mu >= 1:
        return 0.0
    return (3 * mu ** 2 * (1 - mu) + 6 * abs(c) * mu * phi(ndtri(mu)) ** 2
            + mu * (1 - mu) * (6 * abs(c) ** 3 * mu + 3 * c ** 2 + 3 * cp ** 2))


r = minimize_scalar(lambda u: -B(u), bounds=(0.01, 0.99), method="bounded")
print("max B(mu) =", -r.fun, "at mu =", r.x)
