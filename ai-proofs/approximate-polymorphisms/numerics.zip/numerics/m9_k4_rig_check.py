"""Test of the floating-point enclosures of m9_k4_rig.py against exact rational arithmetic (python-flint): for random free sets
and random assignments of the fixed coordinates, the exact critical point -H^{-1} b and its value base + b . S / 2 must lie
inside the enclosure returned by enclosure() and below value_upper().  Not part of the proof; a check of the implementation.

usage: python3 m9_k4_rig_check.py [k=4] [masks per (candidate, nu)=300] [columns per mask=32] [seed=0]
"""
import sys
from fractions import Fraction as Fr

import numpy as np
from flint import fmpq_mat, fmpz_mat

from j2_k2_exact import quad_form
from m9_k4_rig import enclosure, face_data, float_data, integer_form, value_upper
from m9_k4_scan import CANDS

if __name__ == '__main__':
    k = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    nmask = int(sys.argv[2]) if len(sys.argv) > 2 else 300
    ncol = int(sys.argv[3]) if len(sys.argv) > 3 else 32
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    rng = np.random.default_rng(seed)
    worst_ratio, worst_slack, tested, uncertified = 0.0, None, 0, 0
    for spec in CANDS:
        for npos in range(k, -1, -1):
            nu = tuple([1] * npos + [-1] * (k - npos))
            hv = (Fr(spec[0]), Fr(spec[1]), Fr(spec[1]), Fr(spec[2]))
            D, c0i, lini, Qi = integer_form(*quad_form(hv, nu))
            c0, lin, Q, assigns = float_data(c0i, lini, Qi)
            n = len(lini)
            for mask in rng.integers(1, 2 ** n, size=nmask):
                free, base, H, B = face_data(c0, lin, Q, assigns, int(mask))
                enc = enclosure(H, B)
                if enc is None:
                    uncertified += 1
                    continue
                S, eS = enc
                cols = rng.choice(B.shape[1], size=min(ncol, B.shape[1]), replace=False)
                f = len(free)
                Hinv = fmpq_mat(fmpz_mat([[int(v) for v in row] for row in H])).inv()
                Bq = fmpq_mat(fmpz_mat([[int(B[i, c]) for c in cols] for i in range(f)]))
                Sx = -(Hinv * Bq)
                Vub = value_upper(base[cols], B[:, cols], S[:, cols], eS[:, cols])
                for t, c in enumerate(cols):
                    for i in range(f):
                        sx = Fr(int(Sx[i, t].p), int(Sx[i, t].q))
                        err = abs(sx - Fr(S[i, c]))
                        assert err <= Fr(eS[i, c]), (spec, nu, mask, c, i, float(err), eS[i, c])
                        if eS[i, c] > 0:
                            worst_ratio = max(worst_ratio, float(err / Fr(eS[i, c])))
                    vx = Fr(int(base[c])) + sum(Fr(int(B[i, c])) * Fr(int(Sx[i, t].p), int(Sx[i, t].q)) for i in range(f)) / 2
                    slack = Fr(Vub[t]) - vx
                    assert slack >= 0, (spec, nu, mask, c, float(slack))
                    rel = float(slack / D)
                    worst_slack = rel if worst_slack is None else min(worst_slack, rel)
                    tested += 1
    print(f"m9_k4_rig_check.py k={k}, {nmask} random free sets per (candidate, nu), up to {ncol} assignments each, seed {seed}: "
          f"{tested} critical points; every exact point lies in its enclosure (largest error / bound {worst_ratio:.3e}) and below "
          f"its value bound (smallest slack {worst_slack:.3e}, in units of Gamma); {uncertified} sampled blocks not certified")
