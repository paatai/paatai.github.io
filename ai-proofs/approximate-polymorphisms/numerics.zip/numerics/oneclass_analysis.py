"""Exact data for the one-class orbits of the 288 boundary functions (m = 5, |J| = 3).

For each orbit representative h (normalised to mu < 0, so sigma = -1 and a certificate is Gamma > 0) we print:
  * the multilinear polynomial 2h in p_j = (1 + y_j)/2,
  * the permutations of the three columns that fix h (they fix pi_+ and pi_-),
  * the common column bias beta_b = Pr_{pi_b}[w_j = +1] and the pair correlations
    lambda^{jl}_b = E_{pi_b}[chi(w_j) chi(w_l)] in the beta_b-biased basis,
  * the labelled values Gamma_nu(F) of the k = 1 decoders F in {z, -z, 1, -1, 0} for nu = +1 and nu = -1.
All arithmetic is exact (sympy rationals).
"""
import itertools

import sympy as sp

W = list(itertools.product((1, -1), repeat=3))
REPS = {
    "g0": (-2, -2, -2, 1, 0, -1, -1, -1),
    "A24": (-2, -2, -1, 1, 0, 0, -1, -1),
    "B12": (-2, -1, -1, 1, 0, 0, 0, -1),
    "C12": (-1, -2, -2, 1, -1, 0, 0, -1),
    "D12": (-1, -2, -2, 1, 0, -1, -1, 0),
}
p = sp.symbols("p1:4")


def poly2h(h2):
    expr = 0
    for w, v in zip(W, h2):
        term = sp.Integer(v)
        for j in range(3):
            term *= p[j] if w[j] == 1 else (1 - p[j])
        expr += term
    return sp.Poly(sp.expand(expr), *p)


def col_symmetries(h2):
    hv = dict(zip(W, h2))
    out = []
    for perm in itertools.permutations(range(3)):
        if all(hv[w] == hv[tuple(w[perm[j]] for j in range(3))] for w in W):
            out.append(perm)
    return out


def row_laws(h2):
    h = [sp.Rational(v, 2) for v in h2]
    mu = sum(h) / 8
    return mu, {b: {w: (1 + b * hv) / (8 * (1 + b * mu)) for w, hv in zip(W, h)} for b in (1, -1)}


def analyse(name, h2):
    mu, pi = row_laws(h2)
    P = poly2h(h2)
    print(f"=== {name}: 2h = {tuple(h2)}  mu = {mu}")
    print("  2h(p) =", P.as_expr())
    print("  column symmetries:", col_symmetries(h2))
    for b in (1, -1):
        beta = [sum(pr for w, pr in pi[b].items() if w[j] == 1) for j in range(3)]
        assert len(set(beta)) == 1, "not one class"
        be = beta[0]
        lam = {}
        for (j, l) in ((0, 1), (0, 2), (1, 2)):
            ett = sum(pr * w[j] * w[l] for w, pr in pi[b].items())
            m = 2 * be - 1
            lam[(j + 1, l + 1)] = sp.nsimplify((ett - m * m) / (1 - m * m))
        print(f"  b={b:+d}: beta = {be}, pi_b = {[pi[b][w] for w in W]}, lambda = {lam}")
    for nu in (1, -1):
        vals = {}
        for name_f, F in (("z", lambda z: z), ("-z", lambda z: -z), ("1", lambda z: 1), ("-1", lambda z: -1),
                          ("0", lambda z: 0)):
            tot = 0
            for w in W:
                y = [F(w[j]) for j in range(3)]
                tot += pi[nu][w] * P.as_expr().subs({p[j]: sp.Rational(1 + y[j], 2) for j in range(3)}) / 2
            vals[name_f] = tot
        print(f"  Gamma_{'+' if nu == 1 else '-'}(F) for k=1:", vals)


if __name__ == "__main__":
    for name, h2 in REPS.items():
        analyse(name, h2)
