"""Exact check of the worked examples of the refined criterion: the paragraph "Examples" after Corollary 10.8 (cor:J2small)
in Section 10, i.e. Proposition 10.4 (prop:Fplus), case (i), and Theorem F for one class of size two.

For h = (x, z, z, y) (one class, |J| = 2, mu < 0) check() prints lambda_+-, the data a, lambda', a2, M', q, beta,
the admissible range [max(a2, (M' - a q)/(1 - q)), a) for A, and for the chosen A the three quadratic pieces of
Phi+(p) = sigma h(2p-1, 2p-1) - 4|b| [(a - A) B(p) + A p (1 - p)] on [0, q], [q, 1-q], [1-q, 1] with their exact
minima.  Examples: the m = 6 candidate (-5/8, 1/8, 1/8, -1/8) with A = M' = 17/256, and the m = 7 candidate
(-3/4, 1/8, 1/8, -1/8) with the smallest admissible A (= a^3) and, for comparison, with A = max(a2, M') = M'.
Every number of the paragraph is asserted exactly (Fractions):
  m = 6: sigma = -1, b = -1/4, eps = 1, lambda_+ = -5/16, lambda_- = 17/80, nu* = +1, a = 5/16, lambda' = 17/80, a2 = a^3,
    M' = a lambda' = 17/256, q = 3/7, beta = 1/3, (M' - a q)/(1 - q) < 0; Theorem F: min_t Phi(t, t) = -1/1344 at t = -8/21;
    the dictator decoder has Gamma = -1/56; with A = M': 256 Phi+ = 32 - 172p + 252p^2 on [0, 3/7] (negative discriminant),
    16 Phi+ = 2 - 13p + 21p^2 on [3/7, 4/7] (roots 2/7 and 1/3), 64 Phi+ = -4 - 19p + 63p^2 on [4/7, 1] (increasing there,
    = 40/7 at p = 4/7); min Phi+ = 167/16128 at p = 43/126, and Phi+(3/7) = 1/56;
  m = 7: sigma = -1, b = -9/32, eps = 1, lambda_+ = -67/176, lambda_- = 11/48, q = 11/27, beta = 5/11, M' = 67/768,
    (M' - a q)/(1 - q) = -469/4096, A = a^3 = (67/176)^3 admissible; the minima of Phi+ on the three intervals are
    32815487183/30334366605312 (~1.08e-3), 1/216 (at the dictator value p = 11/27) and 13/108; with A = M' the first is
    -2161/43079040 < 0; Theorem F: min Phi = -168601/12317184 (at t = -880/2187), ~ -0.0137.
Also checked exactly: both h and their images h(-w) are candidates (the mirror images have the same data and Phi+ reflected
in p = 1/2); the piecewise form of B(p) and of Phi+ (from the definition, on the grid p = j/378, and (1-q)/(1+beta) = q);
the identity Phi+(p) - Phi(2p-1, 2p-1) = 4|b|[(rho_12 - a) p(1-p) + (a - A)(p(1-p) - B(p))] with a <= rho_12; that at p = q
the bound is attained by the dictator decoder (k = 1, nu = nu*, E F = 2q - 1), with value sigma h(2q-1, 2q-1) - 4|b| a q(1-q);
and, for every decoder with values in {-1,0,1} and k <= 2 and with values in {-1,1} and k = 3, the inequalities
sigma Gamma_nu(F) >= Phi+(p) >= Phi(2p-1, 2p-1) with p = (1 + E F(C_1))/2 (Proposition 10.4 (i) and Theorem F); for m = 6
none of these decoders beats the dictator (max Gamma = -1/56; j2_ascent.py searches k <= 6).
usage: python3 fplus_check.py
"""
import itertools
from fractions import Fraction as Fr
from math import prod

W = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def hml(hv, y1, y2):
    x, z, _, y = hv
    return (x * (1 + y1) * (1 + y2) + z * (1 + y1) * (1 - y2) + z * (1 - y1) * (1 + y2) + y * (1 - y1) * (1 - y2)) / 4


def quad_argmin(c0, c1, c2, lo, hi):
    """(min, argmin) of c0 + c1 t + c2 t^2 over [lo, hi]."""
    cands = [Fr(lo), Fr(hi)]
    if c2 != 0:
        t = -c1 / (2 * c2)
        if lo <= t <= hi:
            cands.append(t)
    return min((c0 + c1 * t + c2 * t * t, t) for t in cands)


def quad_min(c0, c1, c2, lo, hi):
    return quad_argmin(c0, c1, c2, lo, hi)[0]


def ev(c, t):
    return c[0] + c[1] * t + c[2] * t * t


def check(hv, A=None, verbose=True):
    say = print if verbose else (lambda *args, **kwargs: None)
    mu = sum(hv) / 4
    assert mu < 0
    sigma = -1
    pi = {nu: [(1 + nu * hv[i]) / (4 * (1 + nu * mu)) for i in range(4)] for nu in (1, -1)}
    x, z, _, y = hv
    b = (x + y - 2 * z) / 4
    eps = 1 if sigma * b > 0 else -1
    lam, qq = {}, {}
    for nu in (1, -1):
        p_ = pi[nu]
        e = p_[0] + p_[1] - p_[2] - p_[3]
        e12 = p_[0] - p_[1] - p_[2] + p_[3]
        lam[nu] = (e12 - e * e) / (1 - e * e)
        qq[nu] = min((1 + e) / 2, (1 - e) / 2)
    D = [nu for nu in (1, -1) if eps * lam[nu] < 0]
    assert len(D) == 1, 'case (i) needs exactly one dangerous type'
    ns = D[0]
    a, lp, q = abs(lam[ns]), abs(lam[-ns]), qq[ns]
    beta = (1 - 2 * q) / q
    a2, Mp = (a ** 3, a * lp) if eps == 1 else (a ** 2, lp * lp)
    assert a > max(a2, Mp)
    Amin = max(a2, (Mp - a * q) / (1 - q))
    if A is None:
        A = Amin
    assert Amin <= A < a
    say(f"h = {tuple(str(v) for v in hv)}: mu = {mu}, b = {b}, eps = {eps:+d}, lambda_+ = {lam[1]}, "
        f"lambda_- = {lam[-1]}")
    say(f"  nu* = {ns:+d}, a = {a}, lambda' = {lp}, a2 = {a2}, M' = {Mp}, q = {q}, beta = {beta}")
    say(f"  (M' - a q)/(1 - q) = {(Mp - a * q) / (1 - q)}; admissible A in [{Amin}, {a}); using A = {A}")
    s0, s1, s2 = sigma * hml(hv, -1, -1), sigma * hml(hv, 0, 0), sigma * hml(hv, 1, 1)
    c2 = 2 * (s2 + s0) - 4 * s1
    c1 = s2 - s0 - c2
    c0 = s0
    say(f"  sigma h(2p-1, 2p-1) = {c0} + ({c1}) p + ({c2}) p^2")
    Bc = 4 * abs(b)
    c = a - A
    pieces = [((c0, c1 - Bc * (c * q + A), c2 - Bc * (c * beta - A)), Fr(0), q),
              ((c0, c1 - Bc * (c + A), c2 + Bc * (c + A)), q, 1 - q),
              ((c0 - Bc * c * (q + beta), c1 - Bc * (-c * (q + 2 * beta) + A), c2 - Bc * (c * beta - A)), 1 - q, Fr(1))]
    ok = True
    res = []
    for (d0, d1, d2), lo, hi in pieces:
        m, arg = quad_argmin(d0, d1, d2, lo, hi)
        ok = ok and m >= 0
        say(f"  on [{lo}, {hi}]: Phi+ = {d0} + ({d1}) p + ({d2}) p^2, discriminant {d1 * d1 - 4 * d0 * d2}, "
            f"min = {m} (~{float(m):.4e})")
        res.append(dict(c=(d0, d1, d2), lo=lo, hi=hi, min=m, arg=arg, disc=d1 * d1 - 4 * d0 * d2))
    say("  Phi+ >= 0 on [0,1]:", ok)
    return dict(hv=hv, mu=mu, sigma=sigma, pi=pi, b=b, eps=eps, lam=lam, qq=qq, ns=ns, a=a, lp=lp, q=q, beta=beta, a2=a2,
                Mp=Mp, Mlow=(Mp - a * q) / (1 - q), Amin=Amin, A=A, sh=(c0, c1, c2), pieces=res, ok=ok)


def mirror(hv):
    """h(-w) in the order ++, +-, -+, --."""
    return (hv[3], hv[1], hv[2], hv[0])


def is_candidate(hv, r):
    step = Fr(2, 2 ** r)
    x, z, z2, y = hv
    grid = all(((v + 1) / step).denominator == 1 and 0 <= (v + 1) / step <= 2 ** r for v in hv)
    par = sum(hv) / step
    return (z == z2 and grid and x != y and sum(hv) != 0 and any(abs(v) < 1 for v in hv)
            and par.denominator == 1 and par.numerator % 2 == 0)


def Bfun(p, q, beta):
    return min(q * p + beta * p * p, q * (1 - p) + beta * (1 - p) ** 2, p * (1 - p))


def phi_plus(d, p):
    """Phi+(p) straight from the definition in Proposition 10.4 (i)."""
    return ev(d['sh'], p) - 4 * abs(d['b']) * ((d['a'] - d['A']) * Bfun(p, d['q'], d['beta']) + d['A'] * p * (1 - p))


def thm_F(d):
    """Theorem F for one class of size two: Phi(t, t) = sigma h(t, t) - |b| rho_12 (1 - t^2) with rho_12 = max |lambda_nu|;
    returns rho_12, the coefficients of Phi(t, t) in t, and its minimum over [-1, 1] with the argmin."""
    x, z, _, y = d['hv']
    s, b = d['sigma'], d['b']
    rho = max(abs(d['lam'][1]), abs(d['lam'][-1]))
    cF = (s * d['mu'] - abs(b) * rho, 2 * s * (x - y) / 4, s * b + abs(b) * rho)  # h(t,t) = mu + 2 hhat({1}) t + b t^2
    for t in (Fr(-1), Fr(-1, 3), Fr(0), Fr(1, 2), Fr(1)):
        assert ev(cF, t) == s * hml(d['hv'], t, t) - abs(b) * rho * (1 - t * t)
    val, arg = quad_argmin(*cF, Fr(-1), Fr(1))
    return rho, cF, val, arg


def gamma(d, nu, Fv):
    """Gamma_nu(F) = E h(F(X), F(Z)) and E F(X), exactly; X, Z the columns of the k x 2 label matrix, row r ~ pi_{nu_r}."""
    k = len(nu)
    F = dict(zip(itertools.product([1, -1], repeat=k), Fv))
    pi = {n: dict(zip(W, d['pi'][n])) for n in (1, -1)}
    gam = ey = Fr(0)
    for rows in itertools.product(W, repeat=k):
        wt = prod(pi[nu[r]][rows[r]] for r in range(k))
        fx, fz = F[tuple(w[0] for w in rows)], F[tuple(w[1] for w in rows)]
        gam += wt * hml(d['hv'], fx, fz)
        ey += wt * fx
    return gam, ey


def dictator(d):
    """the dictator decoder k = 1, nu = nu*, F(z) = +-z with E F = 2q - 1; its value is Phi+(q)."""
    ns, q = d['ns'], d['q']
    hits = [gamma(d, (ns,), (s, -s)) for s in (1, -1)]
    hits = [(g, e) for g, e in hits if e == 2 * q - 1]
    assert len(hits) == 1
    gam, ey = hits[0]
    val = d['sigma'] * gam
    assert val == ev(d['sh'], q) - 4 * abs(d['b']) * d['a'] * q * (1 - q) == phi_plus(d, q)
    return gam, ey


def grid_check(d, N=378):
    """Phi+ from its definition agrees with the three quadratic pieces at p = j/N (at least 3 points per piece, so the
    pieces are exact); B(p) has the stated piecewise form; Phi+(p) - Phi(2p-1, 2p-1) = 4|b|[(rho - a)p(1-p) + (a - A)(p(1-p) - B(p))]."""
    rho, cF, _, _ = thm_F(d)
    q, beta, a, A = d['q'], d['beta'], d['a'], d['A']
    assert q <= Fr(1, 2) and (1 - q) / (1 + beta) == q and A < a <= rho
    npts = [0, 0, 0]
    for j in range(N + 1):
        p = Fr(j, N)
        val = phi_plus(d, p)
        on = [i for i, pc in enumerate(d['pieces']) if pc['lo'] <= p <= pc['hi']]
        assert on and all(ev(d['pieces'][i]['c'], p) == val for i in on)
        for i in on:
            npts[i] += 1
        assert val >= min(pc['min'] for pc in d['pieces'])
        Bp = Bfun(p, q, beta)
        assert Bp == (q * p + beta * p * p if p <= q else p * (1 - p) if p <= 1 - q else q * (1 - p) + beta * (1 - p) ** 2)
        assert Bp <= p * (1 - p)
        phiF = ev(cF, 2 * p - 1)
        assert val - phiF == 4 * abs(d['b']) * ((rho - a) * p * (1 - p) + (a - A) * (p * (1 - p) - Bp)) and val >= phiF
    assert min(npts) >= 3
    return rho


def brute(d):
    """exact sigma Gamma_nu(F) for all decoders with values in {-1,0,1} and k <= 2 and with values in {-1,1} and k = 3
    (for k = 3 only sorted nu: permuting the rows permutes the arguments of F).  Asserts Proposition 10.4 (i) and Theorem F
    for each of them; returns (number of decoders, min sigma Gamma, a minimiser)."""
    H = {(u, v): hml(d['hv'], u, v) for u in (-1, 0, 1) for v in (-1, 0, 1)}
    pi = {n: dict(zip(W, d['pi'][n])) for n in (1, -1)}
    _, cF, _, _ = thm_F(d)
    count, best = 0, None
    for k, vals in ((1, (1, 0, -1)), (2, (1, 0, -1)), (3, (1, -1))):
        cube = list(itertools.product([1, -1], repeat=k))
        idx = {cv: i for i, cv in enumerate(cube)}
        nus = itertools.product([1, -1], repeat=k) if k < 3 else itertools.combinations_with_replacement([1, -1], k)
        for nu in nus:
            terms = []
            for rows in itertools.product(W, repeat=k):
                wt = prod(pi[nu[r]][rows[r]] for r in range(k))
                terms.append((wt, idx[tuple(w[0] for w in rows)], idx[tuple(w[1] for w in rows)]))
            assert sum(t[0] for t in terms) == 1
            for Fv in itertools.product(vals, repeat=2 ** k):
                sg = d['sigma'] * sum(wt * H[Fv[i], Fv[j]] for wt, i, j in terms)
                p = (1 + sum(wt * Fv[i] for wt, i, _ in terms)) / 2
                assert sg >= phi_plus(d, p) >= ev(cF, 2 * p - 1)
                count += 1
                if best is None or sg < best[0]:
                    best = (sg, nu, Fv)
    return count, best[0], best[1:]


if __name__ == '__main__':
    h6 = (Fr(-5, 8), Fr(1, 8), Fr(1, 8), Fr(-1, 8))
    h7 = (Fr(-3, 4), Fr(1, 8), Fr(1, 8), Fr(-1, 8))
    d6 = check(h6, A=Fr(17, 256))
    d7 = check(h7)
    print("comparison, A = max(a2, M') (the coefficient of the first version):")
    d7c = None
    try:
        d7c = check(h7, A=Fr(67, 768))
    except AssertionError as err:
        print("  assertion:", err)
    assert d7c is not None

    print("\nParagraph 'Examples' after Corollary 10.8: exact assertions")
    # ---------------------------------------------------------------- m = 6
    assert is_candidate(h6, 4) and mirror(h6) == (Fr(-1, 8), Fr(1, 8), Fr(1, 8), Fr(-5, 8)) and is_candidate(mirror(h6), 4)
    assert (d6['sigma'], d6['b'], d6['eps'], d6['lam'][1], d6['lam'][-1]) == (-1, Fr(-1, 4), 1, Fr(-5, 16), Fr(17, 80))
    assert (d6['ns'], d6['a'], d6['lp'], d6['a2']) == (1, Fr(5, 16), Fr(17, 80), Fr(5, 16) ** 3)
    assert d6['Mp'] == d6['a'] * d6['lp'] == Fr(17, 256) and d6['q'] == Fr(3, 7) and d6['beta'] == Fr(1, 3)
    assert d6['Mlow'] == Fr(-121, 1024) < 0 and d6['A'] == d6['Mp'] and d6['ok']
    rho6, cF6, mF6, tF6 = thm_F(d6)
    assert rho6 == Fr(5, 16) and cF6 == (Fr(3, 64), Fr(1, 4), Fr(21, 64)) and (mF6, tF6) == (Fr(-1, 1344), Fr(-8, 21))
    print(f"m = 6, h = (-5/8, 1/8, 1/8, -1/8): Theorem F: Phi(t,t) = 3/64 + t/4 + (21/64) t^2, min = {mF6} at t = {tF6} < 0")
    gam6, ey6 = dictator(d6)
    assert gam6 == Fr(-1, 56) and ey6 == 2 * d6['q'] - 1
    print(f"  dictator decoder (k = 1, nu = +1, F(z) = z): Gamma = {gam6}, E F = {ey6} = 2q - 1")
    P = d6['pieces']
    assert [(pc['lo'], pc['hi']) for pc in P] == [(0, Fr(3, 7)), (Fr(3, 7), Fr(4, 7)), (Fr(4, 7), 1)]
    assert tuple(256 * cc for cc in P[0]['c']) == (32, -172, 252) and P[0]['disc'] < 0 and 172 ** 2 - 4 * 32 * 252 == -2672
    assert tuple(16 * cc for cc in P[1]['c']) == (2, -13, 21)
    assert all(21 * p * p - 13 * p + 2 == (7 * p - 2) * (3 * p - 1) for p in (Fr(0), Fr(1), Fr(2), Fr(5, 3)))
    assert ev(P[1]['c'], Fr(2, 7)) == 0 == ev(P[1]['c'], Fr(1, 3)) and Fr(2, 7) < Fr(1, 3) < Fr(3, 7)
    assert tuple(64 * cc for cc in P[2]['c']) == (-4, -19, 63)
    assert -19 + 126 * Fr(4, 7) > 0 and 64 * ev(P[2]['c'], Fr(4, 7)) == Fr(40, 7)
    assert min(pc['min'] for pc in P) == P[0]['min'] == Fr(167, 16128) and P[0]['arg'] == Fr(43, 126)
    assert phi_plus(d6, Fr(3, 7)) == Fr(1, 56) == P[1]['min'] and P[1]['arg'] == Fr(3, 7)
    print("  A = M' = 17/256: 256 Phi+ = 32 - 172p + 252p^2 on [0,3/7] (disc -2672), 16 Phi+ = 2 - 13p + 21p^2 = "
          "(7p-2)(3p-1) on [3/7,4/7], 64 Phi+ = -4 - 19p + 63p^2 on [4/7,1] (increasing, 40/7 at 4/7)")
    print(f"  min Phi+ = {P[0]['min']} at p = {P[0]['arg']}; Phi+(3/7) = {phi_plus(d6, Fr(3, 7))} = -Gamma(dictator)  [EXACT]")
    # ---------------------------------------------------------------- m = 7
    assert is_candidate(h7, 5) and is_candidate(mirror(h7), 5)
    assert (d7['sigma'], d7['b'], d7['eps'], d7['lam'][1], d7['lam'][-1]) == (-1, Fr(-9, 32), 1, Fr(-67, 176), Fr(11, 48))
    assert d7['ns'] == 1 and d7['a'] == Fr(67, 176) and d7['lp'] == Fr(11, 48)
    assert d7['q'] == Fr(11, 27) and d7['beta'] == Fr(5, 11) and d7['Mp'] == d7['a'] * d7['lp'] == Fr(67, 768)
    assert d7['Mlow'] == Fr(-469, 4096) and d7['Amin'] == d7['A'] == d7['a2'] == Fr(67, 176) ** 3 and d7['ok']
    P = d7['pieces']
    assert [(pc['lo'], pc['hi']) for pc in P] == [(0, Fr(11, 27)), (Fr(11, 27), Fr(16, 27)), (Fr(16, 27), 1)]
    assert [pc['min'] for pc in P] == [Fr(32815487183, 30334366605312), Fr(1, 216), Fr(13, 108)]
    assert f"{float(P[0]['min']):.2e}" == "1.08e-03" and P[1]['arg'] == Fr(11, 27)
    gam7, ey7 = dictator(d7)
    assert d7['sigma'] * gam7 == Fr(1, 216) and ey7 == 2 * Fr(11, 27) - 1
    assert d7c['A'] == max(d7c['a2'], d7c['Mp']) == Fr(67, 768) and not d7c['ok']
    assert d7c['pieces'][0]['min'] == Fr(-2161, 43079040) and all(pc['min'] > 0 for pc in d7c['pieces'][1:])
    rho7, cF7, mF7, tF7 = thm_F(d7)
    assert rho7 == Fr(67, 176) and cF7 == (Fr(277, 5632), Fr(5, 16), Fr(2187, 5632))
    assert (mF7, tF7) == (Fr(-168601, 12317184), Fr(-880, 2187))
    assert f"{float(mF7):.4f}" == "-0.0137" and f"{float(mF7):.5f}" == "-0.01369"
    print(f"m = 7, h = (-3/4, 1/8, 1/8, -1/8): A = a^3 = {d7['A']} admissible; min Phi+ = {P[0]['min']} "
          f"(~{float(P[0]['min']):.2e}), {P[1]['min']} (at p = {P[1]['arg']}), {P[2]['min']}")
    print(f"  dictator decoder (k = 1, nu = +1, F(z) = z): sigma Gamma = {d7['sigma'] * gam7} = Phi+(11/27), E F = {ey7}")
    print(f"  A = M' = 67/768: min on [0, 11/27] = {d7c['pieces'][0]['min']} < 0")
    print(f"  Theorem F: Phi(t,t) = {cF7[0]} + {cF7[1]} t + {cF7[2]} t^2, min = {mF7} ~ {float(mF7):.6f} at t = {tF7}  [EXACT]")
    # ---------------------------------------------------------------- mirror images, grid, dictator at p = q
    for d in (d6, d7, d7c):
        dm = check(mirror(d['hv']), A=d['A'], verbose=False)
        keys = ('mu', 'sigma', 'b', 'eps', 'lam', 'qq', 'ns', 'a', 'lp', 'q', 'beta', 'a2', 'Mp', 'Mlow', 'Amin', 'A', 'ok')
        assert all(dm[kk] == d[kk] for kk in keys)
        assert [(pc['lo'], pc['hi'], pc['min']) for pc in dm['pieces']] == \
            [(1 - pc['hi'], 1 - pc['lo'], pc['min']) for pc in reversed(d['pieces'])]
        assert all(phi_plus(dm, Fr(j, 378)) == phi_plus(d, 1 - Fr(j, 378)) for j in range(379))
        _, _, mFm, tFm = thm_F(dm)
        assert (mFm, tFm) == (thm_F(d)[2], -thm_F(d)[3])
        grid_check(d)
        grid_check(dm)
    print("mirror images h(-w): same data, same minima on the reflected intervals, Phi+_mirror(p) = Phi+(1-p); B(p) and the")
    print("  three pieces agree with the definition on p = j/378; Phi+ - Phi(2p-1,2p-1) = 4|b|[(rho-a)p(1-p) + "
          "(a-A)(p(1-p)-B)] >= 0  [EXACT]")
    # ---------------------------------------------------------------- brute force over small decoders
    for name, d, dict_val in (("m = 6", d6, Fr(1, 56)), ("m = 7", d7, Fr(1, 216))):
        count, best, arg = brute(d)
        assert best <= dict_val
        if name == "m = 6":
            assert best == dict_val
        print(f"{name}: {count} decoders ({{-1,0,1}}-valued, k <= 2; {{-1,1}}-valued, k = 3): sigma Gamma >= Phi+(p) >= "
              f"Phi(2p-1,2p-1) for each; min sigma Gamma = {best} (nu = {arg[0]}, F = {arg[1]}); dictator {dict_val}  [EXACT]")
    print("All numbers of the paragraph 'Examples' (Section 10) verified exactly.")
