"""Search for labelled certificates at x = infinity for the boundary function g0, with many labels.

Gamma_nu(F) = sum_C P_nu(C) h(F(C_1), F(C_2), F(C_3)), C in {+-1}^{k x 3} with independent rows, row i ~ pi_{nu_i},
C_j = column j in {+-1}^k, F : {+-1}^k -> [-1,1] (one class).  For fixed other values, Gamma is a cubic polynomial
in a single value t = F(z); we maximise it exactly on [-1,1] (coordinate ascent), from many random starts.
A value > 0 would be a certificate that s_{g0} > triv (Theorem C(iii)).
usage: python3 g0_coord_ascent.py kmax restarts seed
"""
import itertools
import sys
import numpy as np

kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 6
restarts = int(sys.argv[2]) if len(sys.argv) > 2 else 30
seed = int(sys.argv[3]) if len(sys.argv) > 3 else 0
rng = np.random.default_rng(seed)
print(f'g0_coord_ascent.py kmax={kmax} restarts={restarts} seed={seed}: per (k, nu) the dictator start, {restarts} uniform '
      f'and {restarts} random-sign starts; floating point', flush=True)
W3 = list(itertools.product([1, -1], repeat=3))
hval = dict(zip(W3, [-1, -1, -1, 0.5, 0, -0.5, -0.5, -0.5]))
mu = np.mean(list(hval.values()))
hhat = {S: np.mean([hval[w] * np.prod([w[j] for j in S]) for w in W3])
        for r in range(4) for S in itertools.combinations(range(3), r)}
pi = {b: {w: (1 + b * hval[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}


def hml(y1, y2, y3):
    ys = (y1, y2, y3)
    out = 0.0
    for S, c in hhat.items():
        t = c
        for j in S:
            t = t * ys[j]
        out = out + t
    return out


def setup(nu):
    k = len(nu)
    rows = [[(w, p) for w, p in pi[b].items() if p > 0] for b in nu]
    cols, probs = [], []
    for combo in itertools.product(*rows):
        p = np.prod([c[1] for c in combo])
        idx = []
        for j in range(3):
            v = 0
            for i in range(k):
                v = 2 * v + (combo[i][0][j] == -1)
            idx.append(v)
        cols.append(idx)
        probs.append(p)
    return np.array(cols), np.array(probs)


def gamma(F, cols, probs):
    return probs @ hml(F[cols[:, 0]], F[cols[:, 1]], F[cols[:, 2]])


def ascent(F, cols, probs, sweeps=60):
    nz = 2 ** int(np.log2(len(F)))
    occ = [np.nonzero((cols == z).any(axis=1))[0] for z in range(nz)]
    ts = np.array([-1.0, -1 / 3, 1 / 3, 1.0])
    V = np.vander(ts, 4)
    grid = np.linspace(-1, 1, 201)
    for _ in range(sweeps):
        changed = 0.0
        for z in rng.permutation(nz):
            I = occ[z]
            if len(I) == 0:
                continue
            c3, p3 = cols[I], probs[I]
            vals = []
            for t in ts:
                G = F.copy()
                G[z] = t
                vals.append(p3 @ hml(G[c3[:, 0]], G[c3[:, 1]], G[c3[:, 2]]))
            coef = np.linalg.solve(V, np.array(vals))
            cand = np.concatenate([grid, np.roots(np.polyder(coef)).real.clip(-1, 1)])
            tbest = cand[np.argmax(np.polyval(coef, cand))]
            changed = max(changed, abs(tbest - F[z]))
            F[z] = tbest
        if changed < 1e-9:
            break
    return F


for k in range(1, kmax + 1):
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        cols, probs = setup(nu)
        best = -np.inf
        dict_val = None
        starts = [np.array([1.0 if (z >> (k - 1)) & 1 == 0 else -1.0 for z in range(2 ** k)])]
        starts += [rng.uniform(-1, 1, 2 ** k) for _ in range(restarts)]
        starts += [rng.choice([-1.0, 1.0], 2 ** k) for _ in range(restarts)]
        for s, F0 in enumerate(starts):
            F = ascent(F0.copy(), cols, probs)
            v = gamma(F, cols, probs)
            if s == 0:
                dict_val = gamma(F0, cols, probs)
            best = max(best, v)
        print(f'k={k} nu={"".join("+" if b > 0 else "-" for b in nu)}: #C={len(probs):7d}  '
              f'dictator(row 1)={dict_val:+.6f}  best local max={best:+.8f}', flush=True)
