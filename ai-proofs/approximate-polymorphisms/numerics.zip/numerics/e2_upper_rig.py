"""Rigorous computer part of Theorem 4.5 (upper bound on s^U_{E2}).

Proves:  E[gamma^+] <= 3 E[psi(U)],  U = 2 Phi(X/sqrt14) - 1,  for an explicit convex piecewise linear psi >= 0
with   psi(m1) + psi(m2) + psi(m3) >= Gamma(m)   for all m in [-1,1]^3,  where (Lemma 4.6)
   Gamma(m) = E2(m) + |c| Gmax(k3 l1 l2, k2 l1 l3, k1 l2 l3) + c^2 (|k3| s1 s2 + |k2| s1 s3 + |k1| s2 s3)
              + (3/4) (sqrt2 c^2 (l1 l2 s3 + l1 l3 s2 + l2 l3 s1) + K3 |c|^3 s1 s2 s3),
   c = -1/14, k_j = (1+3 m_j)/4, l_j = 2 phi(Phi^-1((1+m_j)/2)), s_j = sqrt(1-m_j^2), K3 = 5.15,
   Gmax = max of w12<u1,u2> + w13<u1,u3> + w23<u2,u3> over unit vectors (closed form, Lemma 4.7).

Method.  Knots u_a = erf(z_a/sqrt2) with dyadic z_a (z = 0 included) and u = -1, 1.  On a cell B (product of knot
intervals) psi is affine in each coordinate and E2 multilinear, so psi(m1)+psi(m2)+psi(m3)-E2(m) is minimal at a
vertex of B; the correction terms are bounded on B by interval arithmetic (Corr_up).  The script checks
    psi(v1)+psi(v2)+psi(v3) >= E2(v) + Corr_up(B)   for every vertex v of every cell B with max_v E2 + Corr_up > 0,
(cells with max_v E2(v) + Corr_up(B) <= 0 have Gamma <= 0 <= sum psi).  Knot values u, l, s are enclosed with
Arb balls (python-flint) and converted to floats with outward rounding.  Everything after that is double precision with
rounding to nearest (including k = (1+3u)/4, whose one-ulp widening is not an enclosure near u = -1/3); the errors are
absorbed by margins (Remark 4.9(iv)): Corr_up has nonnegative terms and relative error < 30 * 2^-53 < 4e-15 << REL, the
absolute errors (k near its zero < 1e-16 after propagation, E2(v) < 4e-15, vertex shift < 7e-16) are < ABS = 1e-14, and
the slacks are required to exceed 1e-13.  Convexity is checked in ball arithmetic;
E psi(U) is evaluated in ball arithmetic (acb.integral) and rounded up.

Usage: python3 e2_upper_rig.py [n_core]   (default 200; output outputs/e2_upper_rig.txt)
"""
import sys
import time
from fractions import Fraction as Fr
from math import factorial
import numpy as np
from scipy.special import ndtri
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack
from flint import arb, acb, ctx

ctx.prec = 200
C = 1.0 / 14.0          # |c|
K3 = 5.15
R2 = 1.4142135623730951  # sqrt 2 (float, rounded up below via margin)
REL, ABS = 1e-12, 1e-14  # safety margins for Corr_up / E2


def k3_certificate(Kmax=60):
    """sqrt(sum_{K>=3} M(d)^2 c^{2K}) <= K3 |c|^3, M(d)^2 = d1!d2!d3!/(k12!k13!k23!)^2; exact + tail bound."""
    c2 = Fr(1, 196)
    tot = Fr(0)
    for K in range(3, Kmax + 1):
        s = 0
        for a in range(K + 1):
            for b in range(K + 1 - a):
                d = K - a - b
                d1, d2, d3 = a + b, a + d, b + d
                if min(d1, d2, d3) < 1:
                    continue
                s += Fr(factorial(d1) * factorial(d2) * factorial(d3), (factorial(a) * factorial(b) * factorial(d)) ** 2)
        tot += s * c2 ** K
    # tail: M^2 = C(d1,k12) C(d2,k12) C(d3,k13) <= 4^K, #triples <= (K+1)(K+2)/2; sum_{K>Kmax} <= 2 * first term
    K = Kmax + 1
    tail = Fr((K + 1) * (K + 2), 2) * Fr(4, 196) ** K * 2
    bound = tot + tail
    ok = bound <= (Fr(515, 100) ** 2) * c2 ** 3
    return float(bound), ok


def enclose(x):
    lo = np.nextafter(float(x.lower()), -np.inf)
    hi = np.nextafter(float(x.upper()), np.inf)
    return lo, hi


def make_knots(n_core, zcap=6.0):
    ut = np.linspace(-1, 1, n_core + 1)[1:-1]
    z = ndtri((1 + ut) / 2)
    z = np.round(z * 2 ** 30) / 2 ** 30          # dyadic, exact in float and arb
    z = np.unique(np.concatenate([z, [0.0]]))
    return z[np.abs(z) <= zcap]


def knot_enclosures(z):
    n = len(z) + 2
    ulo, uhi, umid = np.empty(n), np.empty(n), np.empty(n)
    elo, ehi, shi = np.empty(n), np.empty(n), np.empty(n)
    ulo[0] = uhi[0] = umid[0] = -1.0
    ulo[-1] = uhi[-1] = umid[-1] = 1.0
    elo[0] = ehi[0] = elo[-1] = ehi[-1] = 0.0
    shi[0] = shi[-1] = 0.0
    s2 = arb(2).sqrt()
    norm = 2 / (2 * arb.pi()).sqrt()
    U = [None] * n
    for i, zz in enumerate(z, start=1):
        za = arb(float(zz))
        u = (za / s2).erf()
        l = norm * (-(za * za) / 2).exp()
        s = (1 - u * u).sqrt()
        U[i] = u
        ulo[i], uhi[i] = enclose(u)
        umid[i] = float(u)
        elo[i], ehi[i] = enclose(l)
        shi[i] = enclose(s)[1]
    return ulo, uhi, umid, elo, ehi, shi, U


def gmax(w12, w13, w23):
    """max over unit vectors of w12<u1,u2>+w13<u1,u3>+w23<u2,u3> (Lemma 4.7)."""
    a = np.abs(w12)
    b = np.abs(w13)
    d = np.abs(w23)
    tot = a + b + d
    frus = (w12 * w13 * w23) < 0
    srt = np.sort(np.stack([a, b, d]), axis=0)
    amin, p, q = srt[0], srt[1], srt[2]
    with np.errstate(divide="ignore", invalid="ignore"):
        psd = (amin * p / q + amin * q / p + p * q / amin) / 2
    rank1 = p + q - amin
    cond = p * q >= amin * (p + q)
    out = np.where(frus, np.where(cond, rank1, psd), tot)
    return np.where(np.isfinite(out), out, tot)


def e2m(m1, m2, m3):
    return -0.25 + (m1 + m2 + m3) / 4 - (m1 * m2 + m1 * m3 + m2 * m3) / 4 - 0.75 * m1 * m2 * m3


class Cells:
    def __init__(self, enc):
        ulo, uhi, umid, elo, ehi, shi, _ = enc
        self.umid = umid
        self.mlo, self.mhi = ulo[:-1], uhi[1:]
        self.Elo = np.minimum(elo[:-1], elo[1:])
        self.Ehi = np.maximum(ehi[:-1], ehi[1:])
        self.Shi = np.maximum(shi[:-1], shi[1:])
        self.klo = np.nextafter((1 + 3 * self.mlo) / 4, -np.inf)
        self.khi = np.nextafter((1 + 3 * self.mhi) / 4, np.inf)
        self.kab = np.maximum(np.abs(self.klo), np.abs(self.khi))
        self.N = len(self.mlo)

    def corr_up(self, a, b, c):
        def wint(k, i, j):
            plo = self.Elo[i] * self.Elo[j]
            phi_ = self.Ehi[i] * self.Ehi[j]
            lo = np.where(self.klo[k] >= 0, self.klo[k] * plo, self.klo[k] * phi_)
            hi = np.where(self.khi[k] >= 0, self.khi[k] * phi_, self.khi[k] * plo)
            return lo, hi
        w12, w13, w23 = wint(c, a, b), wint(b, a, c), wint(a, b, c)
        best = np.full(len(a), -np.inf)
        for s1 in (0, 1):
            for s2 in (0, 1):
                for s3 in (0, 1):
                    best = np.maximum(best, gmax(w12[s1], w13[s2], w23[s3]))
        S, E, Kb = self.Shi, self.Ehi, self.kab
        first = C * best
        second = C * C * (Kb[c] * S[a] * S[b] + Kb[b] * S[a] * S[c] + Kb[a] * S[b] * S[c])
        trip = 0.75 * (R2 * C * C * (E[a] * E[b] * S[c] + E[a] * E[c] * S[b] + E[b] * E[c] * S[a])
                       + K3 * C ** 3 * S[a] * S[b] * S[c])
        return (first + second + trip) * (1 + REL) + ABS

    def sorted_cells(self):
        N = self.N
        A, B, Cc = np.meshgrid(np.arange(N), np.arange(N), np.arange(N), indexing="ij")
        sel = (A <= B) & (B <= Cc)
        return A[sel], B[sel], Cc[sel]

    def scan(self, chunk=300000):
        """yields (vertex index triples (8,n,3), E2 upper values (8,n), corr_up (n,), active mask)."""
        A, B, Cc = self.sorted_cells()
        u = self.umid
        for s in range(0, len(A), chunk):
            a, b, c = A[s:s + chunk], B[s:s + chunk], Cc[s:s + chunk]
            cu = self.corr_up(a, b, c)
            V, E = [], []
            for d1 in (0, 1):
                for d2 in (0, 1):
                    for d3 in (0, 1):
                        i, j, k = a + d1, b + d2, c + d3
                        V.append(np.stack([i, j, k], 1))
                        E.append(e2m(u[i], u[j], u[k]) + ABS)
            V = np.stack(V)
            E = np.stack(E)
            act = E.max(0) + cu > -1e-13
            yield V, E, cu, act


def lp_weights(umid, nx=400001, X=13.0):
    from scipy.special import ndtr
    x = np.linspace(-X, X, nx)
    dens = np.exp(-x * x / 2) / np.sqrt(2 * np.pi)
    uu = 2 * ndtr(x / np.sqrt(14)) - 1
    dx = x[1] - x[0]
    idx = np.clip(np.searchsorted(umid, uu, side="right") - 1, 0, len(umid) - 2)
    frac = (uu - umid[idx]) / (umid[idx + 1] - umid[idx])
    w = np.zeros(len(umid))
    np.add.at(w, idx, (1 - frac) * dens * dx)
    np.add.at(w, idx + 1, frac * dens * dx)
    return w


def solve(cells):
    N = cells.N
    keys, vals = [], []
    nact = 0
    for V, E, cu, act in cells.scan():
        nact += int(act.sum())
        for t in range(8):
            srt = np.sort(V[t][act], 1)
            keys.append((srt[:, 0] * (N + 1) + srt[:, 1]) * (N + 1) + srt[:, 2])
            vals.append(E[t][act] + cu[act])
    key = np.concatenate(keys)
    R = np.concatenate(vals)
    order = np.lexsort((-R, key))
    key, R = key[order], R[order]
    first = np.concatenate([[True], key[1:] != key[:-1]])
    key, R = key[first], R[first]
    Vs = np.stack([key // ((N + 1) ** 2), (key // (N + 1)) % (N + 1), key % (N + 1)], 1)
    nc = len(R)
    A = coo_matrix((-np.ones(3 * nc), (np.repeat(np.arange(nc), 3), Vs.ravel())), shape=(nc, N + 1)).tocsr()
    u = cells.umid
    h = np.diff(u)
    r2 = np.repeat(np.arange(N - 1), 3)
    c2 = np.stack([np.arange(N - 1), np.arange(1, N), np.arange(2, N + 1)], 1).ravel()
    v2 = np.stack([-1 / h[:-1], 1 / h[:-1] + 1 / h[1:], -1 / h[1:]], 1).ravel()
    Bc = coo_matrix((v2, (r2, c2)), shape=(N - 1, N + 1)).tocsr()
    w = 3 * lp_weights(u)
    res = linprog(w, A_ub=vstack([A, Bc]).tocsr(), b_ub=np.concatenate([-(R + 1e-9), np.zeros(N - 1)]),
                  bounds=[(0, None)] * (N + 1), method="highs",
                  options={"primal_feasibility_tolerance": 1e-10, "dual_feasibility_tolerance": 1e-10})
    return res, nact, nc


def verify(cells, y):
    worst = np.inf
    nact = 0
    for V, E, cu, act in cells.scan():
        nact += int(act.sum())
        for t in range(8):
            v = V[t][act]
            slack = y[v[:, 0]] + y[v[:, 1]] + y[v[:, 2]] - (E[t][act] + cu[act])
            if len(slack):
                worst = min(worst, slack.min())
    return worst, nact


def convex_check(U, y):
    """slopes nondecreasing, in ball arithmetic with the exact knots; returns a lower bound for the minimum over a of
    (slope increment at u_{a+1}) * (u_{a+1} - u_a) * (u_{a+2} - u_{a+1})."""
    n = len(y)
    uu = [arb(-1)] + [U[i] for i in range(1, n - 1)] + [arb(1)]
    yy = [arb(float(t)) for t in y]
    worst = None
    for a in range(n - 2):
        d = (yy[a + 2] - yy[a + 1]) * (uu[a + 1] - uu[a]) - (yy[a + 1] - yy[a]) * (uu[a + 2] - uu[a + 1])
        lo = d.lower()
        if worst is None or lo < worst:
            worst = lo
    return worst


def expectation(z, U, y, L=40):
    """E psi(U) in ball arithmetic. Cell a: u in [u_a,u_{a+1}] <=> X/sqrt14 in [z_a,z_{a+1}] (z_0=-inf, z_N=inf).
    psi = alpha_a + beta_a u on the cell; E[1_cell] = P_a, E[U 1_cell] = sqrt14 int erf(t/sqrt2) phi(sqrt14 t) dt."""
    s14 = arb(14).sqrt()
    s2 = acb(2).sqrt()
    inv = 1 / (2 * acb.pi()).sqrt()
    n = len(y)
    uu = [arb(-1)] + [U[i] for i in range(1, n - 1)] + [arb(1)]
    yy = [arb(float(t)) for t in y]
    zz = [None] + [arb(float(t)) for t in z] + [None]
    tcut = arb(L) / s14
    Phi = lambda x: (-x / arb(2).sqrt()).erfc() / 2

    def f(t, analytic):
        return (t / s2).erf() * inv * (-(t * t) * 7).exp()

    tail = Phi(-arb(L))  # Pr[|X| > L]/2, and |U| <= 1
    tot = arb(0)
    for a in range(n - 1):
        lo_t = zz[a] if zz[a] is not None else -tcut
        hi_t = zz[a + 1] if zz[a + 1] is not None else tcut
        P = (Phi(s14 * zz[a + 1]) if zz[a + 1] is not None else arb(1)) - \
            (Phi(s14 * zz[a]) if zz[a] is not None else arb(0))
        M = acb.integral(f, acb(lo_t), acb(hi_t)).real * s14
        if zz[a] is None or zz[a + 1] is None:
            M = M + arb(0, tail)
        beta = (yy[a + 1] - yy[a]) / (uu[a + 1] - uu[a])
        alpha = yy[a] - beta * uu[a]
        tot += alpha * P + beta * M
    return tot


def main():
    n_core = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    t0 = time.time()
    out = []
    pr = lambda s: (print(s, flush=True), out.append(s))
    kb, ok = k3_certificate()
    pr(f"K3 certificate: sum_(K>=3) M^2 c^(2K) <= {kb:.6e}; (5.15 |c|^3)^2 = {(5.15 / 14 ** 3) ** 2:.6e}; ok = {ok}")
    assert ok
    z = make_knots(n_core)
    enc = knot_enclosures(z)
    cells = Cells(enc)
    pr(f"knots: {cells.N + 1} (dyadic z in [{z.min():.4f}, {z.max():.4f}], plus u = -1, 1); sorted cells: "
       f"{cells.N * (cells.N + 1) * (cells.N + 2) // 6}")
    res, nact, nc = solve(cells)
    pr(f"LP: status {res.status}, active cells {nact}, vertex constraints {nc}, value 3 E psi(U) ~ {res.fun:.8e}")
    u = cells.umid
    y = res.x + 2e-9 + 1e-6 * u * u    # feasibility / strict convexity margin
    y = np.maximum(y, 0.0)
    worst, nact2 = verify(cells, y)
    pr(f"verification: active cells {nact2}, min over active vertices of sum psi - E2_up - Corr_up = {worst:.3e}")
    assert worst > 1e-13
    cmin = convex_check(enc[6], y)
    pr(f"convexity: min over a of slope increment * h_a * h_(a+1) (ball lower bound) = {float(cmin):.3e} > 0")
    assert cmin > 0
    assert (y >= 0).all()
    Ep = expectation(z, enc[6], y)
    bound = 3 * Ep
    pr(f"3 E psi(U) in {bound}")
    up = float(bound.upper())
    pr(f"RESULT: E gamma^+ <= {up:.7e}, hence s^U_E2 <= 5/8 + {up:.7e} = {0.625 + up:.7f}")
    np.savetxt(f"outputs/e2_upper_psi_{n_core}.txt", np.stack([u, y], 1), fmt="%.17e",
               header="knot u (float midpoint of exact knot erf(z/sqrt2)), psi value (exact binary64)")
    np.savetxt(f"outputs/e2_upper_z_{n_core}.txt", z, fmt="%.17e", header="dyadic z knots")
    pr(f"time {time.time() - t0:.0f}s")
    with open(f"outputs/e2_upper_rig_{n_core}.txt", "w") as fh:
        fh.write("\n".join(out) + "\n")


if __name__ == "__main__":
    main()
