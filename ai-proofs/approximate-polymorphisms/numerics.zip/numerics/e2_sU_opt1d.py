"""Numerical exploration: is (sgn, sgn, -sgn) optimal for s^U_{E2} among one-dimensional test functions?

We maximise E_x[gamma_q(x)^+] (= val(q) - 5/8) over mean-zero step functions q_1,q_2,q_3 : R -> [-1,1]
(bins of width 0.1 on [-6,6] plus two tails), by projected gradient ascent on a softplus-smoothed objective,
starting from (sgn,sgn,-sgn) and from perturbations / random points.  gamma is computed with the
CFMMS representation (see polymorph.py) and Gauss-Hermite quadrature.
"""
import sys
import numpy as np
from scipy.special import ndtr, expit
from polymorph import GaussData, E2, gh_nodes

rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 1)
GD = GaussData(E2, 3)
a, sig = GD.a, np.sqrt(1 - GD.a ** 2)
coef = GD.coef
edges = np.concatenate([[-np.inf], np.linspace(-6, 6, 121), [np.inf]])
B = len(edges) - 1
mass = ndtr(edges[1:]) - ndtr(edges[:-1])
xs = np.linspace(-9, 9, 361)
wx = np.exp(-xs ** 2 / 2) / np.sqrt(2 * np.pi) * (xs[1] - xs[0])
nodes, wn = gh_nodes(40, 2)
P = GD.perp @ np.vstack(nodes)                      # 3 x N


def kernels(x):
    Z = x * GD.rhohat[:, None] + P                   # 3 x N
    t = a * Z[..., None]
    return ndtr((edges[1:] - t) / sig) - ndtr((edges[:-1] - t) / sig)   # 3 x N x B


KS = [kernels(x) for x in xs]


def eval_grad(q, tau):
    """q: 3 x B.  Returns exact E[gamma^+], smoothed objective and its gradient."""
    tot_pos, obj, grad = 0.0, 0.0, np.zeros_like(q)
    for K, w in zip(KS, wx):
        y = np.einsum('jnb,jb->jn', K, q)            # 3 x N
        val = 0.0
        d = np.zeros_like(y)
        for S, c in coef.items():
            term = c * np.prod(y[list(S)], axis=0) if S else c * np.ones(y.shape[1])
            val = val + term
            for j in S:
                d[j] += c * np.prod(y[[i for i in S if i != j]], axis=0)
        gam = wn @ val
        tot_pos += w * max(gam, 0.0)
        obj += w * tau * np.logaddexp(0, gam / tau)
        dg = np.einsum('n,jn,jnb->jb', wn, d, K)
        grad += w * expit(gam / tau) * dg
    return tot_pos, obj, grad


def project(v):
    lo, hi = -2.0, 2.0
    for _ in range(60):
        t = (lo + hi) / 2
        if mass @ np.clip(v - t, -1, 1) > 0:
            lo = t
        else:
            hi = t
    return np.clip(v - (lo + hi) / 2, -1, 1)


mid = (np.clip(edges[1:], -7, 7) + np.clip(edges[:-1], -7, 7)) / 2
base = np.stack([np.sign(mid), np.sign(mid), -np.sign(mid)])
starts = [('sgn,sgn,-sgn', base)]
for i in range(3):
    starts.append((f'perturbed{i}', base + 0.3 * rng.standard_normal(base.shape)))
for i in range(2):
    starts.append((f'random{i}', rng.uniform(-1, 1, base.shape)))
for name, q0 in starts:
    q = np.stack([project(r) for r in q0])
    p0 = eval_grad(q, 1e-3)[0]
    best = p0
    for tau, lr, steps in ((3e-3, 30.0, 60), (1e-3, 15.0, 60), (3e-4, 5.0, 60)):
        for _ in range(steps):
            pos, obj, g = eval_grad(q, tau)
            best = max(best, pos)
            q = np.stack([project(q[j] + lr * g[j] / np.sqrt(mass + 1e-8)) for j in range(3)])
    pos = eval_grad(q, 1e-3)[0]
    best = max(best, pos)
    print(f'{name:14s} start E[gamma^+] = {p0:.7e}   best found = {best:.7e}   (val = {0.625 + best:.7f})', flush=True)
