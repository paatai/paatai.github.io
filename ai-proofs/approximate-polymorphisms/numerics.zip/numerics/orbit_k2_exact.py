"""Exact maximum of Gamma_nu over all [-1,1]-valued class-wise decoders with k <= kmax for the two-class boundary orbits
(m = 5, |J| = 3; Table 1 of MAIN_RESULT.pdf), in rational arithmetic.

h: {+-1}^3 -> Q is given by 2h on +++, ++-, ..., ---.  The classes are the sets of coordinates with equal level-one
coefficient; here a pair class {i, j} with decoder Fp and a singleton class {s} with decoder Fs, both {+-1}^k -> [-1,1].
Gamma_nu(F) = sum_C Pr[C] h(F_c(1)(C_1), F_c(2)(C_2), F_c(3)(C_3)) (h multilinear), the rows of C independent, row r ~ pi_(nu_r).
Gamma is affine in the values of Fs, so for fixed Fp its maximum over Fs is attained at a vertex of [-1,1]^(2^k).  For each
vertex Fs, Gamma is a quadratic in the 2^k values of Fp, maximised exactly by face enumeration (j2_k2_exact.cube_max).
Permuting the label rows (and the label bits of both decoders) does not change the maximum, so nu = (+,...,+,-,...,-).
All representatives have mu < 0 (sigma = -1), so a certificate is a decoder with Gamma > 0.

usage: python3 orbit_k2_exact.py [kmax=2] [names ...]      (names from REPS; default: all nine two-class orbits)
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

from j2_k2_exact import cube_max

W3 = list(itertools.product([1, -1], repeat=3))
REPS = {
    'rep1': (-2, -2, -1, 0, -1, 1, 0, -1), 'rep2': (-2, -2, -1, 0, 1, -2, -1, -1), 'rep3': (-2, -2, -1, 1, 0, -1, -1, 0),
    'rep5': (-2, -1, -1, 0, 1, -2, 0, -1), 'rep6': (-2, -1, 0, -1, 1, -2, -1, 0), 'rep7': (-1, -2, -1, 0, 1, -2, -1, 0),
    'rep8': (-1, -2, -1, 0, 1, -2, 0, -1), 'rep9': (-1, -2, 0, -1, 1, -2, -1, 0), 'rep10': (-1, -2, 0, 0, 1, -1, -1, 0),
}
SUBSETS = [S for r in range(4) for S in itertools.combinations(range(3), r)]


def data(h2):
    hv = {w: Fr(v, 2) for w, v in zip(W3, h2)}
    mu = sum(hv.values()) / 8
    hhat = {S: sum(hv[w] * prod_(w[j] for j in S) for w in W3) / 8 for S in SUBSETS}
    pi = {b: {w: (1 + b * hv[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    lev1 = [hhat[(j,)] for j in range(3)]
    classes = {}
    for j in range(3):
        classes.setdefault(lev1[j], []).append(j)
    classes = sorted(classes.values(), key=len, reverse=True)
    return hv, mu, hhat, pi, classes


def prod_(it):
    out = 1
    for v in it:
        out *= v
    return out


def hml(hhat, y):
    return sum(c * prod_(y[j] for j in S) for S, c in hhat.items())


def column_law(pi, nu):
    """Pr[(C_1, C_2, C_3) = (c_1, c_2, c_3)] with c_j the index of column j in {+-1}^k (bit 1 <-> -1, row 1 = top bit)."""
    k = len(nu)
    A = {}
    for rows in itertools.product(W3, repeat=k):
        p = prod_(pi[nu[r]][rows[r]] for r in range(k))
        if p == 0:
            continue
        c = [0, 0, 0]
        for j in range(3):
            for r in range(k):
                c[j] = 2 * c[j] + (rows[r][j] == -1)
        A[tuple(c)] = A.get(tuple(c), 0) + p
    return A


def gamma(hhat, A, dec, cls_of):
    return sum(p * hml(hhat, [dec[cls_of[j]][c[j]] for j in range(3)]) for c, p in A.items())


def quad_for_vertex(hhat, A, n, pair, s, ys):
    """Gamma as c0 + lin . Fp + Fp^T Q Fp for the singleton decoder Fs = ys (a vertex)."""
    i, j = pair
    c0, lin, Q = Fr(0), [Fr(0)] * n, [[Fr(0)] * n for _ in range(n)]
    for c, p in A.items():
        y = ys[c[s]]
        c0 += p * (hhat[()] + hhat[(s,)] * y)
        for a in (i, j):
            lin[c[a]] += p * (hhat[(a,)] + hhat[tuple(sorted((a, s)))] * y)
        q = p * (hhat[tuple(sorted((i, j)))] + hhat[(0, 1, 2)] * y) / 2
        Q[c[i]][c[j]] += q
        Q[c[j]][c[i]] += q
    return c0, lin, Q


def run(name, kmax, rng):
    hv, mu, hhat, pi, classes = data(REPS[name])
    assert mu < 0 and len(classes) == 2 and len(classes[0]) == 2, (name, classes)
    pair, (s,) = classes
    cls_of = {pair[0]: 'p', pair[1]: 'p', s: 's'}
    print(f"{name}: 2h = {REPS[name]}, mu = {mu}, pair class {[j + 1 for j in pair]}, singleton {s + 1}", flush=True)
    overall = None
    for k in range(kmax + 1):
        n = 2 ** k
        for npos in range(k, -1, -1):
            nu = tuple([1] * npos + [-1] * (k - npos))
            A = column_law(pi, nu)
            assert sum(A.values()) == 1
            best = None
            for ys in itertools.product((-1, 1), repeat=n):
                c0, lin, Q = quad_for_vertex(hhat, A, n, pair, s, ys)
                for _ in range(2):
                    Fp = [Fr(rng.randint(-8, 8), 8) for _ in range(n)]
                    direct = gamma(hhat, A, {'p': Fp, 's': ys}, cls_of)
                    assert direct == c0 + sum(lin[a] * Fp[a] for a in range(n)) + sum(
                        Q[a][b] * Fp[a] * Fp[b] for a in range(n) for b in range(n))
                val, Fp = cube_max(c0, lin, Q)
                if best is None or val > best[0]:
                    best = (val, Fp, ys)
            val, Fp, ys = best
            overall = val if overall is None else max(overall, val)
            print(f"  k={k} nu={''.join('+' if v > 0 else '-' for v in nu) or '()'}: max Gamma = {val}"
                  f"  at Fp = {[str(v) for v in Fp]}, Fs = {list(ys)}", flush=True)
    print(f"  {name}: max Gamma over all class-wise decoders with k <= {kmax} = {overall}", flush=True)
    return overall


if __name__ == '__main__':
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 2
    names = sys.argv[2:] or [n for n in REPS]
    rng = random.Random(0)
    res = {name: run(name, kmax, rng) for name in names}
    assert all(v == 0 for v in res.values()), res
    print(f"all {len(res)} orbits: max Gamma <= 0 for every k <= {kmax} and every nu, with maximum 0 over all of them (exact), "
          f"so no class-wise certificate with k <= {kmax}", flush=True)
