"""Sharpness of Theorem L (Section 9.7): equality cases, ANDs of t coordinates, small means.

Exact (fractions) unless stated otherwise.  On the q-biased cube write y_i = 1{x_i = 1}; then
hat f({i}) = ((1-q) a_i - q b_i) / sqrt(q(1-q)) with a_i = E[f 1{x_i=1}], b_i = E[f 1{x_i=-1}], so W^1(f) is rational.
  (1) every {0,1}-valued f on {-1,1}^n, n <= 4, and q in {1/5, 3/10, 1/3, 2/5}: equality in the second inequality of
      Theorem L holds iff f = 0 or f is 1{x_i=1}, 1{x_i=x_j=1} or 1{x_i=1, x_j=-1};
  (2) random nonnegative integer-valued f of degree <= 2 on {-1,1}^4: equality in the first inequality iff the support is
      intersecting (sets of +1 coordinates pairwise meet), iff f has one of the two forms y_1 g (g >= 0 affine in the other
      coordinates) or a y_1y_2 + b y_1y_3 + c y_2y_3 (a, b, c >= 0), up to relabelling; and (E f)^2 / E f^2 lies in
      [q^2, q] for every equality case;
  (3) the AND of t coordinates: W^1 = t (1-q) p^2 / q with p = q^t, and the ratio W^1 / (q p + beta p^2) equals
      t (1-q) q^(t-2) / (1 + (1-2q) q^(t-2)): 1 for t = 1, 2, 3q/(1+2q) for t = 3, < 1 for t >= 3;
  (4) floating point: the small-mean bound W^1(f) <= p^2/(2q(1-q)) (ln(1/p) + 1 + 1/(4 ln(1/p))) on random [0,1]-valued
      and random {0,1}-valued f (n <= 10), on ANDs, ORs-of-ANDs and thresholds, with the largest ratio found.
usage: python3 thmL_sharpness.py
"""
import itertools
import math
import random
from fractions import Fraction as Fr

import numpy as np

QS = [Fr(1, 5), Fr(3, 10), Fr(1, 3), Fr(2, 5)]


_CUBE, _W = {}, {}


def cube(n):
    if n not in _CUBE:
        _CUBE[n] = list(itertools.product([1, -1], repeat=n))
    return _CUBE[n]


def weights(n, q):
    if (n, q) not in _W:
        _W[(n, q)] = [q ** sum(1 for c in x if c == 1) * (1 - q) ** sum(1 for c in x if c == -1) for x in cube(n)]
    return _W[(n, q)]


def stats(fvals, n, q):
    pts = cube(n)
    w = weights(n, q)
    Ef = sum(wi * fi for wi, fi in zip(w, fvals) if fi)
    Ef2 = sum(wi * fi * fi for wi, fi in zip(w, fvals) if fi)
    W1 = Fr(0)
    for i in range(n):
        a = sum(wi * fi for wi, fi, x in zip(w, fvals, pts) if fi and x[i] == 1)
        b = Ef - a
        W1 += ((1 - q) * a - q * b) ** 2 / (q * (1 - q))
    return Ef, Ef2, W1


def bound1(Ef, Ef2, q):
    return q * Ef2 + (1 - 2 * q) / q * Ef ** 2


_LISTED = {}


def is_listed_boolean(fvals, n):
    if n not in _LISTED:
        pts = cube(n)
        cands = set()
        for i in range(n):
            cands.add(frozenset(x for x in pts if x[i] == 1))
            for j in range(n):
                if j != i:
                    cands.add(frozenset(x for x in pts if x[i] == 1 and x[j] == 1))
                    cands.add(frozenset(x for x in pts if x[i] == 1 and x[j] == -1))
        _LISTED[n] = cands
    supp = frozenset(x for x, v in zip(cube(n), fvals) if v)
    return not supp or supp in _LISTED[n]


def intersecting(fvals, n):
    pts = cube(n)
    supp = [frozenset(i for i in range(n) if x[i] == 1) for x, v in zip(pts, fvals) if v != 0]
    return all(A & B for A in supp for B in supp)


def poly_vals(c0, c1, c2, n):
    """values of c0 + sum c1[i] y_i + sum c2[i,j] y_i y_j on the cube (order of cube(n))."""
    out = []
    for x in cube(n):
        y = [1 if c == 1 else 0 for c in x]
        v = c0 + sum(c1[i] * y[i] for i in range(n))
        v += sum(c2[(i, j)] * y[i] * y[j] for i in range(n) for j in range(i + 1, n))
        out.append(v)
    return out


def listed_form(c0, c1, c2, n):
    """the two forms of the equality cases, for f = c0 + sum c1 y + sum c2 yy given by its coefficients."""
    if c0 != 0:
        return False
    pos = [i for i in range(n) if c1[i] != 0]
    edges = [e for e, v in c2.items() if v != 0]
    if any(c1[i] < 0 for i in range(n)):
        return False
    if len(pos) >= 2:
        return False
    if len(pos) == 1:
        i = pos[0]
        if any(i not in e for e in edges):
            return False
        g = [c1[i]] + [c2[tuple(sorted((i, j)))] for j in range(n) if j != i]
        return g[0] >= 0 and g[0] + sum(min(0, d) for d in g[1:]) >= 0
    if not edges:
        return True
    if any(c2[e] < 0 for e in edges):
        return False
    verts = set(itertools.chain.from_iterable(edges))
    star = any(all(v in e for e in edges) for v in verts)
    tri = len(verts) == 3 and len(edges) <= 3
    return star or tri


def check_boolean():
    for n in range(1, 5):
        N = 2 ** n
        for q in QS:
            eq_count = 0
            for mask in range(2 ** N):
                fv = [Fr((mask >> k) & 1) for k in range(N)]
                Ef, Ef2, W1 = stats(fv, n, q)
                b2 = q * Ef + (1 - 2 * q) / q * Ef ** 2
                assert W1 <= b2
                eq = W1 == b2
                assert eq == is_listed_boolean(fv, n), (n, q, fv)
                eq_count += eq
            print(f"  n={n} q={q}: all {2 ** N} Boolean f satisfy the bound; equality for exactly the {eq_count} "
                  f"listed ones (0, 1{{x_i=1}}, 1{{x_i=x_j=1}}, 1{{x_i=1,x_j=-1}})")


def check_degree2(trials=3000, seed=1):
    rng = random.Random(seed)
    n = 4
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    found_eq = found_neq = 0
    rmin, rmax = {}, {}
    for t in range(trials):
        q = QS[t % len(QS)]
        mode = rng.randrange(4)
        c0 = 0
        c1 = [0] * n
        c2 = {e: 0 for e in pairs}
        if mode == 0:            # star form y_i g
            i = rng.randrange(n)
            d = [rng.randint(-3, 3) for _ in range(n)]
            d[i] = abs(d[i]) + sum(max(0, -d[j]) for j in range(n) if j != i)
            c1[i] = d[i]
            for j in range(n):
                if j != i:
                    c2[tuple(sorted((i, j)))] = d[j]
        elif mode == 1:          # triangle form
            tri = rng.sample(range(n), 3)
            for e in itertools.combinations(sorted(tri), 2):
                c2[e] = rng.randint(0, 3)
        else:                    # random degree <= 2 polynomial, shifted to be nonnegative
            c0 = rng.randint(-2, 2)
            c1 = [rng.randint(-2, 2) for _ in range(n)]
            c2 = {e: rng.randint(-2, 2) for e in pairs}
            m = min(poly_vals(c0, c1, c2, n))
            if m < 0:
                c0 -= m
            if mode == 3:
                c0 = 0 if min(poly_vals(0, c1, c2, n)) >= 0 else c0
        fv = [Fr(v) for v in poly_vals(c0, c1, c2, n)]
        assert min(fv) >= 0
        if max(fv) == 0:
            continue
        Ef, Ef2, W1 = stats(fv, n, q)
        b1 = bound1(Ef, Ef2, q)
        assert W1 <= b1
        eq = W1 == b1
        assert eq == intersecting(fv, n) == listed_form(c0, c1, c2, n), (q, c0, c1, c2)
        if eq:
            found_eq += 1
            r = Ef ** 2 / Ef2
            assert q ** 2 <= r <= q
            rmin[q] = min(rmin.get(q, r), r)
            rmax[q] = max(rmax.get(q, r), r)
        else:
            found_neq += 1
    print(f"  {found_eq} equality cases and {found_neq} strict cases among random nonnegative degree<=2 f on "
          f"{{-1,1}}^4; equality <=> intersecting support <=> listed form; (E f)^2/E f^2 in [q^2, q] for all "
          f"equality cases (ranges found: " + ", ".join(f"q={q}: [{float(rmin[q]):.4f}, {float(rmax[q]):.4f}]"
                                                        for q in sorted(rmin)) + ")")


def check_and():
    for q in QS + [Fr(1, 2)]:
        beta = (1 - 2 * q) / q
        row = []
        for t in range(1, 9):
            p = q ** t
            fv = None
            if t <= 4:
                n = t
                fv = [Fr(1) if all(c == 1 for c in x) else Fr(0) for x in cube(n)]
                Ef, Ef2, W1 = stats(fv, n, q)
                assert Ef == p and W1 == t * (1 - q) * p ** 2 / q
            W1 = t * (1 - q) * p ** 2 / q
            ratio = W1 / (q * p + beta * p ** 2)
            assert ratio == t * (1 - q) * q ** (t - 2) / (1 + (1 - 2 * q) * q ** (t - 2))
            if t <= 2:
                assert ratio == 1
            else:
                assert ratio < 1
            if t == 3:
                assert ratio == 3 * q / (1 + 2 * q)
            row.append(float(ratio))
        print(f"  q={q}: W^1(AND_t)/(qp+beta p^2), t=1..8: " + " ".join(f"{r:.4f}" for r in row))


def lvl1_bound(p, q):
    L = math.log(1 / p)
    return p * p / (2 * q * (1 - q)) * (L + 1 + 1 / (4 * L))


def W1_float(f, n, q):
    pts = np.array(cube(n))
    w = np.prod(np.where(pts == 1, q, 1 - q), axis=1)
    p = float(w @ f)
    W = 0.0
    for i in range(n):
        a = float(w[pts[:, i] == 1] @ f[pts[:, i] == 1])
        b = float(w[pts[:, i] == -1] @ f[pts[:, i] == -1])
        W += ((1 - q) * a - q * b) ** 2 / (q * (1 - q))
    return p, W


def check_small_means(seed=2):
    rng = np.random.default_rng(seed)
    worst = 0.0
    for q in [0.2, 0.3, 1 / 3, 0.4, 0.5]:
        for n in range(1, 11):
            pts = np.array(cube(n))
            ys = (pts == 1).astype(int)
            fams = []
            for t in range(1, n + 1):
                fams.append(np.all(ys[:, :t] == 1, axis=1).astype(float))                 # AND_t
                fams.append((ys[:, :t].sum(1) >= max(1, (t + 1) // 2)).astype(float))      # threshold
            if n >= 4:
                fams.append(((ys[:, 0] & ys[:, 1]) | (ys[:, 2] & ys[:, 3])).astype(float))  # OR of two ANDs
            for _ in range(30):
                fams.append(rng.uniform(0, 1, 2 ** n) * (rng.uniform(0, 1, 2 ** n) < rng.uniform(0, 1)))
                fams.append((rng.uniform(0, 1, 2 ** n) < rng.uniform(0, 0.3)).astype(float))
            for f in fams:
                p, W = W1_float(f, n, q)
                if 1e-12 < p < 1 - 1e-12:
                    r = W / lvl1_bound(p, q)
                    assert r <= 1 + 1e-12, (q, n, p, W)
                    worst = max(worst, r)
    print(f"  small-mean bound holds on all tested f (largest ratio W^1/bound = {worst:.4f})")
    for q in [0.3, 0.4, 0.5]:
        c_and, c_up = (1 - q) / (q * math.log(1 / q)), 1 / (2 * q * (1 - q))
        print(f"  q={q}: AND_t constant (1-q)/(q ln(1/q)) = {c_and:.4f} <= 1/(2q(1-q)) = {c_up:.4f}")


def main():
    print("(1) Boolean equality cases of the second inequality (exact):")
    check_boolean()
    print("(2) equality cases of the first inequality among nonnegative f of degree <= 2 (exact):")
    check_degree2()
    print("(3) ANDs of t coordinates (exact):")
    check_and()
    print("(4) small means (floating point):")
    check_small_means()


if __name__ == "__main__":
    main()
