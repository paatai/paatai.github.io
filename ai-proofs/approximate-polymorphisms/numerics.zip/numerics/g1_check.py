"""The second explicit m = 5 boundary function g1 (MAIN_RESULT, Section 9.6; orbit "A24" of hard288).

g1(w1,w2,w3,u1,u2) = +1  iff  (u1,u2) in A'_w, where
  A'_{+++} = A'_{++-} = {},  A'_{+-+} = {(+,+)},  A'_{+--} = all but (+,+),
  A'_{-++} = {(+,+),(-,-)},  A'_{-+-} = {(+,-),(-,+)},  A'_{--+} = {(+,-)},  A'_{---} = {(-,+)}.

Exact checks (Fractions / sympy) of every number in Section 9.6, i.e. the data of g1 and the proof of
Proposition 9.10 (prop:g1):
  data of g1 (dependence on all coordinates, g1(-,+,+,u) = u1 u2, mu = -3/8, sigma = -1, triv = 11/16, level-one
  coefficients, the displayed formula and inner sums for the u-coefficients, h, sigma h(+--) = -1/2, membership of 2h
  in hard288 and the size 24 of its orbit) and of the extensions g_{1,m}, m = 6, 7, 8;
  the multilinear identity for 2h(p) with its displayed vertex values, the row laws pi_+- (displayed values),
  the biases beta_+-, the four displayed pair laws of (w1,w2) and (w1,w3), the correlations lambda with their displayed
  numerators and denominators, the spectral coefficients a_S for |S| <= 2 (displayed expressions) and the bound
  a_1* = 539/864 for |S| >= 3, the final case split, and the dictator decoder (p = 2/5, P1P2 = 0, W_+ = Var P = 6/25,
  Gamma_+ = 0, every inequality tight).
Then a brute-force test (exact rationals for decoders with values in {-1,0,1} and k <= 2; floating point for random
[-1,1]-valued decoders with k <= 4): Gamma <= reduction bound, reduction bound == spectral formula, Gamma <= 0.
"""
import itertools
import math
from fractions import Fraction as Fr

import numpy as np
import sympy as sp

W = list(itertools.product([1, -1], repeat=3))
U = list(itertools.product([1, -1], repeat=2))
A = {(1, 1, 1): [], (1, 1, -1): [], (1, -1, 1): [(1, 1)],
     (1, -1, -1): [u for u in U if u != (1, 1)],
     (-1, 1, 1): [(1, 1), (-1, -1)], (-1, 1, -1): [(1, -1), (-1, 1)], (-1, -1, 1): [(1, -1)], (-1, -1, -1): [(-1, 1)]}
g = {w + u: (1 if u in A[w] else -1) for w in W for u in U}
pts = list(g)


def coef(S):
    return Fr(sum(g[x] * math.prod(x[i] for i in S) for x in pts), 32)


mu = coef(())
l1 = [coef((i,)) for i in range(5)]
dep = all(any(g[x] != g[x[:i] + (-x[i],) + x[i + 1:]] for x in pts) for i in range(5))
h = {w: Fr(sum(g[w + u] for u in U), 4) for w in W}
print("g1^{-1}(+1):", sorted(x for x in pts if g[x] == 1))
print("depends on all coordinates:", dep, " mu =", mu, " level-1 =", [str(c) for c in l1])
print("h (order +++,++-,...,---) =", [str(h[w]) for w in W])
assert dep and mu == Fr(-3, 8) and l1[3] == 0 and l1[4] == 0 and all(c == Fr(-1, 8) for c in l1[:3])
assert [h[w] for w in W] == [Fr(x, 2) for x in (-2, -2, -1, 1, 0, 0, -1, -1)]
assert all(h[w] == Fr(len(A[w]), 2) - 1 for w in W)
assert sum(v * v for v in h.values()) / 8 == -mu and max(h.values()) > 0
assert [sum(h[w] * w[j] for w in W) / 8 for j in range(3)] == l1[:3]  # hhat({j}) = ghat({w_j})
sigma = 1 if mu > 0 else -1
assert sigma == -1 and Fr(1, 2) + abs(mu) / 2 == Fr(11, 16)  # triv_{g1} = 11/16
assert sigma * h[(1, -1, -1)] == Fr(-1, 2)  # Theorem C(ii): s^U > triv
assert all(g[(-1, 1, 1) + uu] == uu[0] * uu[1] for uu in U)  # g1(-,+,+,u) = u1 u2
nonzero = [S for r in range(6) for S in itertools.combinations(range(5), r) if coef(S) != 0]
assert nonzero != [(0, 1, 2, 3, 4)]  # not +- a parity
SHOWN = [(1, -1, 1), (1, -1, -1), (-1, 1, 1), (-1, 1, -1), (-1, -1, 1), (-1, -1, -1)]  # w = +-+, +--, -++, -+-, --+, ---
inner = {i: [sum(uu[i] for uu in A[w]) for w in SHOWN] for i in range(2)}
for i in range(2):  # inner sums over the sets A'_w of u_i (the displayed values in the paper)
    print(f"inner sums of u_{i + 1} over A'_w, w = +-+, +--, -++, -+-, --+, ---:", inner[i])
    assert 2 * Fr(sum(sum(uu[i] for uu in A[w]) for w in W), 32) == l1[3 + i] == 0  # ghat({u_i}) = 2*2^-5*sum = 0
assert inner[0] == [1, -1, 0, 0, 1, -1] and inner[1] == [1, -1, 0, 0, -1, 1]
assert all(A[w] == [] for w in W if w not in SHOWN)  # A'_{+++} = A'_{++-} = {}
hard = set()
with open("outputs/hard288.txt") as fh:
    for line in fh:
        line = line.strip()
        if line and not line.startswith("#"):
            try:
                hard.add(tuple(Fr(t) for t in line.replace(",", " ").split()[:8]))
            except (ValueError, ZeroDivisionError):
                pass
assert len(hard) == 288  # the file lists 2h
assert tuple(2 * h[w] for w in W) in hard
IDX = {w: i for i, w in enumerate(W)}


def sym_orbit(v):
    """Orbit of a vertex-value vector under the symmetries of Lemma sym: permutations of J, h -> -h, h -> h(-w)."""
    out = set()
    for perm in itertools.permutations(range(3)):
        for nw in (1, -1):
            for nh in (1, -1):
                out.add(tuple(nh * v[IDX[tuple(nw * w[perm[j]] for j in range(3))]] for w in W))
    return out


orb = sym_orbit(tuple(2 * h[w] for w in W))
assert len(orb) == 24 and orb <= hard
print("2h is in hard288.txt (288 entries parsed); its orbit has 24 elements, all in hard288")
for m in (6, 7, 8):  # g_{1,m}(w, u_1, ..., u_{m-3}) = g1(w, u_1, u_2 ... u_{m-3})
    Um = list(itertools.product([1, -1], repeat=m - 3))
    gm = {w + uu: g[w + (uu[0], math.prod(uu[1:]))] for w in W for uu in Um}
    ptsm = list(gm)
    assert {w: Fr(sum(gm[w + uu] for uu in Um), 2 ** (m - 3)) for w in W} == h and Fr(sum(gm.values()), 2 ** m) == mu
    assert [Fr(sum(gm[x] * x[i] for x in ptsm), 2 ** m) for i in range(m)] == [Fr(-1, 8)] * 3 + [Fr(0)] * (m - 3)
    assert all(any(gm[x] != gm[x[:i] + (-x[i],) + x[i + 1:]] for x in ptsm) for i in range(m))
print("g_{1,m}, m = 6, 7, 8: same h and mu, level-one coefficients -1/8 on w and 0 on every u_i, depends on all coordinates")

# ---------------------------------------------------------------- multilinear form
p1, p2, p3 = sp.symbols("p1 p2 p3")
twoh = -1 + 2 * p1 + p2 - 4 * p1 * p2 - 2 * p1 * p3 + 2 * p1 * p2 * p3
vertex_vals = []
for w in W:
    val = twoh.subs({p1: (1 + w[0]) // 2, p2: (1 + w[1]) // 2, p3: (1 + w[2]) // 2})
    assert val == 2 * h[w]
    vertex_vals.append(val)
assert vertex_vals == [-2, -2, -1, 1, 0, 0, -1, -1]  # the displayed values at p = (1,1,1), (1,1,0), ..., (0,0,0)
ext = sum(sp.Rational(h[w].numerator, h[w].denominator)
          * sp.prod([pj if w[j] == 1 else 1 - pj for j, pj in enumerate((p1, p2, p3))]) for w in W)
assert sp.expand(2 * ext - twoh) == 0
print("2h(p) = -1 + 2p1 + p2 - 4p1p2 - 2p1p3 + 2p1p2p3 (values -2,-2,-1,1 and 0,0,-1,-1 at the vertices)  [EXACT]")

# ---------------------------------------------------------------- row laws, biases, correlations
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W} for b in (1, -1)}
beta = {}
lam = {}
for b in (1, -1):
    assert sum(pi[b].values()) == 1
    bs = [sum(pi[b][w] for w in W if w[j] == 1) for j in range(3)]
    assert bs[0] == bs[1] == bs[2]
    beta[b] = bs[0]
    m2 = (2 * beta[b] - 1) ** 2
    for (j, l) in [(0, 1), (0, 2), (1, 2)]:
        lam[b, j, l] = (sum(pi[b][w] * w[j] * w[l] for w in W) - m2) / (1 - m2)
print("pi_+ =", [str(pi[1][w]) for w in W])
print("pi_- =", [str(pi[-1][w]) for w in W])
print("beta_+ =", beta[1], " beta_- =", beta[-1])
print("lambda^{12}_+-, lambda^{13}_+-, lambda^{23}_+- =",
      [str(lam[b, 0, 1]) for b in (1, -1)], [str(lam[b, 0, 2]) for b in (1, -1)], [str(lam[b, 1, 2]) for b in (1, -1)])
assert beta[1] == Fr(2, 5) and beta[-1] == Fr(6, 11)
assert (lam[1, 0, 1], lam[-1, 0, 1], lam[1, 0, 2], lam[-1, 0, 2]) == (Fr(-2, 3), Fr(4, 15), Fr(-1, 4), Fr(1, 12))
assert pi[1][(1, 1, 1)] == 0 and pi[1][(1, 1, -1)] == 0  # pi_+(++.) = 0: P1 P2 = 0 for the dictator
assert [pi[1][w] for w in W] == [Fr(0), Fr(0), Fr(1, 10), Fr(3, 10), Fr(1, 5), Fr(1, 5), Fr(1, 10), Fr(1, 10)]
assert [pi[-1][w] for w in W] == [Fr(2, 11), Fr(2, 11), Fr(3, 22), Fr(1, 22), Fr(1, 11), Fr(1, 11), Fr(3, 22), Fr(3, 22)]
assert all(pi[1][w] == (1 + h[w]) / 5 and pi[-1][w] == (1 - h[w]) / 11 for w in W)
PAIRS = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def pair_law(b, j, l):
    return [sum(pi[b][w] for w in W if (w[j], w[l]) == c) for c in PAIRS]


LAWS = {(1, 0, 1): [Fr(0), Fr(2, 5), Fr(2, 5), Fr(1, 5)], (-1, 0, 1): [Fr(4, 11), Fr(2, 11), Fr(2, 11), Fr(3, 11)],
        (1, 0, 2): [Fr(1, 10), Fr(3, 10), Fr(3, 10), Fr(3, 10)], (-1, 0, 2): [Fr(7, 22), Fr(5, 22), Fr(5, 22), Fr(5, 22)]}
for (b, j, l), law in LAWS.items():  # the displayed pair laws, and the correlations computed from them
    assert pair_law(b, j, l) == law, (b, j, l)
    m2 = (2 * beta[b] - 1) ** 2
    assert (law[0] - law[1] - law[2] + law[3] - m2) / (1 - m2) == lam[b, j, l]
for (j, l) in [(0, 1), (0, 2)]:
    print(f"law of (w{j + 1},w{l + 1}) on (++,+-,-+,--): pi_+:", [str(x) for x in pair_law(1, j, l)],
          " pi_-:", [str(x) for x in pair_law(-1, j, l)])
assert (2 * beta[1] - 1) ** 2 == Fr(1, 25) and (2 * beta[-1] - 1) ** 2 == Fr(1, 121)
assert lam[1, 0, 1] == (Fr(-3, 5) - Fr(1, 25)) / Fr(24, 25) == Fr(-2, 3)
assert lam[-1, 0, 1] == (Fr(3, 11) - Fr(1, 121)) / Fr(120, 121) == Fr(4, 15)
assert lam[1, 0, 2] == (Fr(-1, 5) - Fr(1, 25)) / Fr(24, 25) == Fr(-1, 4)
assert lam[-1, 0, 2] == (Fr(1, 11) - Fr(1, 121)) / Fr(120, 121) == Fr(1, 12)
print("pi_+-, the four pair laws and lambda^{12}_+-, lambda^{13}_+- (displayed numerators/denominators)  [EXACT]")

# ---------------------------------------------------------------- spectral coefficients a_S = -2(lambda^12_S + lambda^13_S)
def aS(npos, nneg):
    l12 = lam[1, 0, 1] ** npos * lam[-1, 0, 1] ** nneg
    l13 = lam[1, 0, 2] ** npos * lam[-1, 0, 2] ** nneg
    return -2 * (l12 + l13)


astar = 2 * (Fr(2, 3) ** 3 + Fr(1, 4) ** 3)
assert astar == Fr(539, 864)
print("a_S, |S|=1:  nu=+: ", aS(1, 0), "  nu=-: ", aS(0, 1))
print("a_S, |S|=2:  (++, +-, --): ", aS(2, 0), aS(1, 1), aS(0, 2))
assert aS(1, 0) == Fr(11, 6) and aS(0, 1) == Fr(-7, 10) and aS(1, 1) == Fr(143, 360)
assert aS(2, 0) < 0 and aS(0, 2) < 0 and aS(1, 1) <= astar and aS(0, 1) <= astar
# the displayed expressions
assert aS(1, 0) == 2 * (Fr(2, 3) + Fr(1, 4)) and aS(0, 1) == -2 * (Fr(4, 15) + Fr(1, 12))
assert aS(2, 0) == -2 * (Fr(4, 9) + Fr(1, 16)) and aS(1, 1) == 2 * (Fr(8, 45) + Fr(1, 48))
assert aS(0, 2) == -2 * (Fr(16, 225) + Fr(1, 144))
mx12 = max(abs(lam[b, 0, 1]) for b in (1, -1))
mx13 = max(abs(lam[b, 0, 2]) for b in (1, -1))
assert mx12 == Fr(2, 3) and mx13 == Fr(1, 4)
for k in range(3, 12):
    assert 2 * (mx12 ** k + mx13 ** k) <= astar
    for npos in range(k + 1):
        assert aS(npos, k - npos) <= astar
print("a* = 2((2/3)^3 + (1/4)^3) =", astar, "bounds a_S for |S| >= 3  [EXACT]")

# ---------------------------------------------------------------- final case split
p, A_ = sp.symbols("p astar")
lhs = -1 + 3 * p - 4 * p**2 + sp.Rational(11, 6) * (p - p**2)
assert sp.expand(lhs + (5 * p - 2) * (7 * p - 3) / 6) == 0
G = -1 + 3 * p - 4 * p**2 + A_ * (p - p**2) + (sp.Rational(11, 6) - A_) * sp.Rational(6, 25)
assert sp.simplify(G.subs(p, sp.Rational(2, 5))) == 0
assert sp.simplify(sp.diff(G, p).subs(p, sp.Rational(2, 5)) - (A_ - 1) / 5) == 0
assert sp.Rational(11, 6) > sp.Rational(539, 864)
assert sorted(sp.solve((5 * p - 2) * (7 * p - 3), p)) == [sp.Rational(2, 5), sp.Rational(3, 7)]
assert Fr(2, 5) * (1 - Fr(2, 5)) == Fr(6, 25)  # Theorem K with q = 2/5: W_+ <= 6/25
G1 = G.subs(A_, sp.Rational(539, 864))
assert G1.subs(p, sp.Rational(2, 5)) == 0 and sp.diff(G1, p).subs(p, sp.Rational(2, 5)) == (sp.Rational(539, 864) - 1) / 5 < 0
assert sp.diff(G1, p, 2) < 0  # concave
print("case split: -1+3p-4p^2+(11/6)(p-p^2) = -(5p-2)(7p-3)/6;  G(2/5) = 0, G'(2/5) = (a*-1)/5 < 0, G'' < 0  [EXACT]")


# ---------------------------------------------------------------- brute force
def gamma_and_bounds(nu, Fvals, exact):
    """Gamma_nu(F), the reduction bound (E[...]/2 after P1P2P3 <= P1P2) and the spectral expression / 2."""
    k = len(nu)
    zs = list(itertools.product([1, -1], repeat=k))
    F = dict(zip(zs, Fvals))
    one = Fr(1) if exact else 1.0
    hval = {w: (h[w] if exact else float(h[w])) for w in W}
    piv = {b: {w: (pi[b][w] if exact else float(pi[b][w])) for w in W} for b in (1, -1)}
    gam = red = 0 * one
    for rows in itertools.product(W, repeat=k):
        wt = one
        for i, r in enumerate(rows):
            wt *= piv[nu[i]][r]
        if wt == 0:
            continue
        y = [F[tuple(rows[i][j] for i in range(k))] for j in range(3)]
        P = [(one + yj) / 2 for yj in y]
        # multilinear extension of h at y
        hy = sum(hval[w] * math.prod((one + w[j] * y[j]) / 2 for j in range(3)) for w in W)
        gam += wt * hy
        red += wt * (-1 + 2 * P[0] + P[1] - 2 * P[0] * P[1] - 2 * P[0] * P[2]) / 2
    # spectral expression: P(x) on Omega_nu with coordinates +1 w.p. beta_{nu_i}
    bet = [beta[n] if exact else float(beta[n]) for n in nu]
    Pz = {z: (one + F[z]) / 2 for z in zs}
    wz = {z: math.prod(bet[i] if z[i] == 1 else 1 - bet[i] for i in range(k)) for z in zs}
    pbar = sum(wz[z] * Pz[z] for z in zs)
    spec = -1 + 3 * pbar - 4 * pbar**2
    for r in range(1, k + 1):
        for S in itertools.combinations(range(k), r):
            if exact:
                chi = {z: math.prod(sp.Rational(z[i] - (2 * bet[i] - 1)) / (2 * sp.sqrt(bet[i] * (1 - bet[i]))) for i in S) for z in zs}
                coefS = sp.nsimplify(sum(wz[z] * Pz[z] * chi[z] for z in zs))
                sq = sp.nsimplify(coefS**2)
            else:
                chi = {z: math.prod((z[i] - (2 * bet[i] - 1)) / (2 * math.sqrt(bet[i] * (1 - bet[i]))) for i in S) for z in zs}
                sq = sum(wz[z] * Pz[z] * chi[z] for z in zs) ** 2
            npos = sum(1 for i in S if nu[i] == 1)
            spec += (aS(npos, r - npos) if exact else float(aS(npos, r - npos))) * sq
    return gam, red, spec / 2


gam, red, spec = gamma_and_bounds((1,), [Fr(1), Fr(-1)], True)  # dictator: k = 1, nu = (+1), F(z) = z
m_ = 2 * beta[1] - 1
W_dict = (beta[1] * (1 - m_)) ** 2 / (4 * beta[1] * (1 - beta[1]))  # Phat({1})^2 for P = 1{z = 1}
p_d = beta[1]
assert gam == 0 and red == 0 and spec == 0 and p_d == Fr(2, 5)
assert pi[1][(1, 1, 1)] + pi[1][(1, 1, -1)] == 0  # E[P1 P2] = pi_+(++.) = 0
assert W_dict == p_d - p_d**2 == Fr(6, 25)  # W_+ = Var P = 6/25
assert -1 + 3 * p_d - 4 * p_d**2 + astar * (p_d - p_d**2) + (Fr(11, 6) - astar) * W_dict == 0
print("dictator (k=1, nu=+1, F(z)=z): p = 2/5, P1P2 = 0 a.s., W_+ = Var P = 6/25, Gamma_+ = reduction = spectral = 0  [EXACT]")
best_exact = None
for k in (1, 2):
    for nu in itertools.product([1, -1], repeat=k):
        for Fv in itertools.product([1, -1, 0], repeat=2**k):
            gam, red, spec = gamma_and_bounds(nu, [Fr(x) for x in Fv], True)
            assert gam <= red and sp.simplify(sp.Rational(red) - spec) == 0 and gam <= 0
            best_exact = gam if best_exact is None else max(best_exact, gam)
print("k<=2, values in {-1,0,1}: Gamma <= reduction bound = spectral formula, max Gamma =", best_exact, " [EXACT]")
rng = np.random.default_rng(0)
worst_gap = worst_gam = -np.inf
for trial in range(400):
    k = int(rng.integers(1, 5))
    nu = tuple(int(x) for x in rng.choice([1, -1], size=k))
    Fv = list(np.clip(rng.uniform(-1.3, 1.3, size=2**k), -1, 1))
    gam, red, spec = gamma_and_bounds(nu, Fv, False)
    assert gam <= red + 1e-12 and abs(red - spec) < 1e-10
    worst_gam = max(worst_gam, gam)
print(f"(float) 400 random decoders, k<=4: reduction bound == spectral formula, max Gamma = {worst_gam:.3e} (<= 0)")
print("g1 verified.")
