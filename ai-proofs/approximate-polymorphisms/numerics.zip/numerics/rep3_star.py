"""Numerical test of the relaxed class-wise inequality for the orbit rep3 (2h = (-2,-2,-1,1,0,-1,-1,0), classes {1,3},{2}).

Raising h to 0 at the two vertices +++ and ++- (outside the support of pi_+) gives h' >= h, and triviality of rep3
follows from
    (star)   Psi(G,H) = 2 E[H(V) G(Z)] - E[G(X) G(Z)] <= 1   for all k, nu, G,H : {-1,1}^k -> [-1,1],
where (X,V,Z) are the columns (1,2,3) of the label matrix.  Only the pair laws (V,Z) and (X,Z) enter, so the
bilinear forms are Kronecker products of 2x2 kernels.  Alternating maximisation: H = sgn(K^{VZ} G) is the best
response, and G is improved by exact coordinate ascent (Psi is quadratic in each value G(z)).
usage: python3 rep3_star.py kmax restarts seed
"""
import itertools
import sys

import numpy as np

H2 = [-2, -2, -1, 1, 0, -1, -1, 0]
W3 = list(itertools.product([1, -1], repeat=3))
h = dict(zip(W3, [x / 2 for x in H2]))
mu = np.mean(list(h.values()))
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}


def pair_kernel(b, i, j):
    K = np.zeros((2, 2))
    for w, p in pi[b].items():
        K[int(w[i] == -1), int(w[j] == -1)] += p
    return K


KVZ = {b: pair_kernel(b, 1, 2) for b in (1, -1)}
KXZ = {b: pair_kernel(b, 0, 2) for b in (1, -1)}


def kron(Ks):
    out = np.ones((1, 1))
    for K in Ks:
        out = np.kron(out, K)
    return out


def psi(G, H, A, B):
    return 2 * H @ A @ G - G @ B @ G


def optimise(G, A, B, sweeps=200):
    Bs = (B + B.T) / 2
    n = len(G)
    best = -np.inf
    for _ in range(sweeps):
        H = np.sign(A @ G)
        H[H == 0] = 1
        c = A.T @ H
        changed = False
        for z in range(n):
            # Psi as a function of t = G(z): 2 c_z t - Bs_zz t^2 - 2 t sum_{z' != z} Bs_zz' G(z') + const
            lin = 2 * c[z] - 2 * (Bs[z] @ G - Bs[z, z] * G[z])
            quad = -Bs[z, z]
            cands = [-1.0, 1.0]
            if quad < 0:
                t = -lin / (2 * quad)
                if -1 < t < 1:
                    cands.append(t)
            vals = [lin * t + quad * t * t for t in cands]
            t = cands[int(np.argmax(vals))]
            if abs(t - G[z]) > 1e-12:
                G[z] = t
                changed = True
        H = np.sign(A @ G)
        H[H == 0] = 1
        val = psi(G, H, A, B)
        if val <= best + 1e-14 and not changed:
            break
        best = max(best, val)
    H = np.sign(A @ G)
    H[H == 0] = 1
    return psi(G, H, A, B), G, H


def main():
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    restarts = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    rng = np.random.default_rng(int(sys.argv[3]) if len(sys.argv) > 3 else 0)
    for k in range(1, kmax + 1):
        overall = -np.inf
        for npos in range(k + 1):
            nu = [1] * npos + [-1] * (k - npos)
            A = kron([KVZ[b] for b in nu])
            B = kron([KXZ[b] for b in nu])
            n = 2 ** k
            best, bestG = -np.inf, None
            starts = []
            zs = np.array(list(itertools.product([1, -1], repeat=k)))
            for i in range(k):
                starts.append(zs[:, i].astype(float))
                starts.append(-zs[:, i].astype(float))
            starts.append(np.ones(n))
            for _ in range(restarts):
                starts.append(rng.uniform(-1, 1, n))
                starts.append(np.sign(rng.uniform(-1, 1, n)))
            for G0 in starts:
                val, G, H = optimise(G0.copy(), A, B)
                if val > best:
                    best, bestG = val, G.copy()
            overall = max(overall, best)
            print(f"k={k} nu={''.join('+' if b > 0 else '-' for b in nu)} max Psi = {best:.12f}"
                  + (f"  G={np.round(bestG, 3).tolist()}" if k <= 3 else ""), flush=True)
        print(f"k={k} overall max Psi = {overall:.12f} (claim: <= 1)", flush=True)


if __name__ == "__main__":
    main()
