"""Exact (integer-arithmetic) classification of s_g-nontriviality for all g : {-1,1}^m -> {-1,1}, m <= 4.

Every g with E g != 0 that depends on all coordinates and is not +-parity is checked directly
(no symmetry reduction).  Notation: J = {j : ghat({j}) != 0}, h(w) = E_u g(w,u) on {-1,1}^J,
classes of J = distinct values of ghat({j}) (equivalently of rho_j).  In this script sigma = -sgn(mu)
(the opposite of the sign convention of MAIN_RESULT, so that certificates are positive numbers).
Certificates (MAIN_RESULT, Theorem C):
  TRIV : sigma*h(w) <= 0 for all w           => s^U_g (hence s_g) trivial       [Thm C(i)]
  L0   : sigma*h(w) > 0 at a class-constant w => s^L_g (hence s_g) nontrivial   [Thm C(iii), k = 0]
  LAB1 : some nu in {+-1} and class-wise decoders F_c in {id, -id, +1, -1} with
         sigma * sum_w (1 + nu h(w)) h(F(w)) > 0  => s_g nontrivial            [Thm C(iii), k = 1]
Prints the counts and asserts that every g gets a certificate.
"""
import itertools
import sys
from collections import Counter

def run(m):
    pts = list(itertools.product([1, -1], repeat=m))
    N = len(pts)
    stats = Counter()
    undecided = []
    lab1 = []
    for code in range(2 ** N):
        g = [1 - 2 * ((code >> i) & 1) for i in range(N)]
        S = sum(g)                              # 2^m * mu
        if S == 0:
            continue
        par = [pp[0] * pp[1] * (pp[2] if m > 2 else 1) * (pp[3] if m > 3 else 1) for pp in pts] if m > 1 else [pp[0] for pp in pts]
        if g == par or g == [-v for v in par]:
            continue
        dep = True
        for j in range(m):
            flip = {pp: pp[:j] + (-pp[j],) + pp[j + 1:] for pp in pts}
            gi = dict(zip(pts, g))
            if all(gi[pp] == gi[flip[pp]] for pp in pts):
                dep = False
                break
        if not dep:
            continue
        gi = dict(zip(pts, g))
        l1 = [sum(gi[pp] * pp[j] for pp in pts) for j in range(m)]   # 2^m * ghat({j})
        J = [j for j in range(m) if l1[j] != 0]
        U = [j for j in range(m) if l1[j] == 0]
        sigma = -1 if S > 0 else 1
        # 2^|U| * h(w), integer valued
        H = {}
        for w in itertools.product([1, -1], repeat=len(J)):
            tot = 0
            for u in itertools.product([1, -1], repeat=len(U)):
                x = [0] * m
                for a, j in zip(w, J):
                    x[j] = a
                for b, j in zip(u, U):
                    x[j] = b
                tot += gi[tuple(x)]
            H[w] = sigma * tot                  # sigma * 2^|U| h(w)
        if max(H.values()) <= 0:
            stats['TRIV'] += 1
            continue
        vals = sorted(set(l1[j] for j in J))
        cls = [vals.index(l1[j]) for j in J]
        r = len(vals)
        if any(H[tuple(psi[c] for c in cls)] > 0 for psi in itertools.product([1, -1], repeat=r)):
            stats['L0'] += 1
            continue
        Q = 2 ** len(U)
        ok = False
        dec = [lambda a: a, lambda a: -a, lambda a: 1, lambda a: -1]
        for nu in (1, -1):
            for combo in itertools.product(range(4), repeat=r):
                tot = 0
                for w, hw in H.items():
                    Fw = tuple(dec[combo[c]](a) for a, c in zip(w, cls))
                    tot += (Q + nu * sigma * hw) * H[Fw]     # (Q + nu*Q*h(w)) * sigma*Q*h(F(w))
                if tot > 0:
                    ok = True
                    break
            if ok:
                break
        if ok:
            stats['LAB1'] += 1
            lab1.append(g)
        else:
            stats['UNDECIDED'] += 1
            undecided.append(g)
    return stats, undecided, lab1

for m in [int(a) for a in sys.argv[1:]] or [2, 3, 4]:
    st, und, lab1 = run(m)
    print(f"m={m}: {sum(st.values())} functions g (E g != 0, all coordinates relevant, not +-parity): {dict(st)}")
    assert not und, f"undecided functions at m={m}"
    if m == 3:
        pts3 = list(itertools.product([1, -1], repeat=3))
        e2 = [1 if sum(1 for t in p if t > 0) == 2 else -1 for p in pts3]
        e2neg = [1 if sum(1 for t in p if t < 0) == 2 else -1 for p in pts3]   # E2(-x)
        orbit = {tuple(e2), tuple(-v for v in e2), tuple(e2neg), tuple(-v for v in e2neg)}
        assert set(map(tuple, lab1)) == orbit
        print("  m=3 LAB1 functions (values on +++,++-,...,---): " + "; ".join(str(tuple(g)) for g in lab1)
              + "  = {+-E2(x), +-E2(-x)}  [asserted]")
print("all functions decided; s_g nontrivial <=> exists w with sgn(mu) h(w) < 0")
