"""Search for 'hard' g: s^U criterion holds but the simple constructions (L0, Lab1) fail.

We enumerate h : {+-1}^d -> {-1 + 2a/2^r : a = 0..2^r} (d = |J|, r = |J^c|) with
  * hhat({j}) != 0 for all j in J,  mu = hhat(empty) != 0,
  * realisability as h(w) = E_u g(w,u) with ghat({u_i}) = 0 for u-coordinates and g depending on
    every u-coordinate: necessary+sufficient-ish parity test (see realise()).
Tests (mu < 0 normalisation by global sign):
  crit : max_w h(w) > 0 (s^U criterion)
  L0   : max over class-measurable w of h(w) > 0
  Lab1 : for b in {+-1} and class-wise tau_c in {id, -id, +1, -1}:
         E_a[(1 + b h(a)) h(tau(a))] > 0   (a uniform on {+-1}^d)
Floating point, but exact: every quantity computed (h, mu, level-one coefficients, the Lab1 means, partial sums) is a dyadic
rational with denominator dividing 2^(2r+d) and modulus at most 2, hence exactly representable, and divisions are by powers of 2.
So the tolerance 1e-12 only separates 0 from nonzero values, which have modulus >= 2^-(2r+d).  np.round(l1, 10) maps equal
coefficients to equal keys and keeps distinct ones (which differ by >= 2^-(r+d)) distinct.
usage: python3 q6_hsearch.py d r     (m = 5: d=2 r=3 and d=3 r=2; outputs/q6_hsearch_d{d}_r{r}.txt)
"""
import itertools
import sys
from fractions import Fraction as Fr
import numpy as np

d = int(sys.argv[1])
r = int(sys.argv[2])
P = np.array(list(itertools.product([1, -1], repeat=d)))
n = len(P)
Q = 2 ** r
vals = np.array([-1 + 2 * a / Q for a in range(Q + 1)])


def coeffs(H):
    mu = H.mean(axis=-1)
    l1 = H @ P / n
    return mu, l1


def analyse(hv):
    mu = hv.mean()
    s = -1 if mu > 0 else 1  # normalise so that mu < 0
    h = s * hv
    l1 = h @ P / n
    key = np.round(l1, 10)
    uniq = sorted(set(key))
    cls = np.array([uniq.index(v) for v in key])
    R = len(uniq)
    if h.max() <= 1e-12:
        return 'triv'
    # L0
    for psi in itertools.product([1, -1], repeat=R):
        w = tuple(psi[c] for c in cls)
        if h[idx[w]] > 1e-12:
            return 'L0'
    # Lab1
    for tau in itertools.product(range(4), repeat=R):
        img = np.empty_like(P)
        for j in range(d):
            t = tau[cls[j]]
            img[:, j] = P[:, j] if t == 0 else (-P[:, j] if t == 1 else (1 if t == 2 else -1))
        himg = h[[idx[tuple(v)] for v in img]]
        for b in (1, -1):
            if np.mean((1 + b * h) * himg) > 1e-12:
                return 'Lab1'
    return 'HARD'


idx = {tuple(p): i for i, p in enumerate(P)}


def realise(hv):
    """parity condition: sum_w |A_w| even when r >= 1; for r = 1 also #(h=0) even and >= 2? (need dependence)."""
    sizes = np.round((hv + 1) * Q / 2).astype(int)
    if sizes.sum() % 2:
        return False
    # need g to depend on each u-coordinate: some A_w not closed under flipping u_i.
    # A set of size a in {+-1}^r closed under flipping coordinate i has even size; if all sizes
    # are even we could still choose non-closed sets as long as some 0 < a < Q.
    if not np.any((sizes > 0) & (sizes < Q)):
        return False
    if r == 1:
        # A_w subset {+1,-1}: size-1 sets contribute +-1; need equal numbers -> #(size 1) even
        return (np.sum(sizes == 1) % 2 == 0) and np.sum(sizes == 1) >= 2
    return True


counts = {}
hard = []
total = 0
for combo in itertools.product(range(Q + 1), repeat=n):
    hv = vals[list(combo)]
    mu = hv.mean()
    if abs(mu) < 1e-12:
        continue
    l1 = hv @ P / n
    if np.any(np.abs(l1) < 1e-12):
        continue
    if not realise(hv):
        continue
    total += 1
    st = analyse(hv)
    counts[st] = counts.get(st, 0) + 1
    if st == 'HARD':
        hard.append(hv)
print(f"d={d} r={r}: {total} admissible h; {counts}")
for hv in hard[:20]:
    print('HARD h=', [str(Fr(v).limit_denominator(64)) for v in hv], 'mu=', hv.mean())
np.save(f'outputs/hard_h_d{d}_r{r}.npy', np.array(hard))
