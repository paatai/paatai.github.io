"""Theorem F and the 288 boundary functions (exact arithmetic).

Only the orbits of rep3 and rep8 have hat h(123) = 0 (class_flips.py), so Theorem F can only apply there.
For both representatives this script finds a class-constant y with Phi(y) < 0, certified exactly:
each term |hat h(ij)| rho_ij sqrt((1-y_i^2)(1-y_j^2)) equals |hat h(ij)| |Cov_b| sqrt(R) with R rational,
and sqrt(R) is bounded below by a rational r with r^2 <= R.  So the hypothesis of Theorem F fails for all
48 functions of these two orbits (Phi is invariant under the symmetries of Lemma sym), and Theorem F settles
none of the 288 boundary functions.
"""
import itertools
from fractions import Fraction as Fr
from math import isqrt

W3 = list(itertools.product([1, -1], repeat=3))
reps = {3: (-2, -2, -1, 1, 0, -1, -1, 0), 8: (-1, -2, -1, 0, 1, -2, 0, -1)}


def sqrt_lo(R, bits=60):
    """rational r with r^2 <= R (R >= 0 rational), accurate to about 2^-bits."""
    N = 1 << bits
    r = Fr(isqrt(R.numerator * N * N // R.denominator), N)
    assert r * r <= R
    return r


def fourier(d):
    return {S: Fr(sum(d[w] * w[0] ** S[0] * w[1] ** S[1] * w[2] ** S[2] for w in W3), 8)
            for S in itertools.product([0, 1], repeat=3)}


def hml(fh, y):
    tot = Fr(0)
    for S, c in fh.items():
        t = c
        for j in range(3):
            if S[j]:
                t *= y[j]
        tot += t
    return tot


for i, h2 in reps.items():
    d = {w: Fr(v, 2) for w, v in zip(W3, h2)}
    fh = fourier(d)
    mu = fh[(0, 0, 0)]
    sigma = 1 if mu > 0 else -1
    assert fh[(1, 1, 1)] == 0
    lev1 = [fh[(1, 0, 0)], fh[(0, 1, 0)], fh[(0, 0, 1)]]
    pi = {b: {w: (1 + b * d[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    pairs = [(0, 1), (0, 2), (1, 2)]
    # for each pair: (|hat h(ij)|, list over b of (Cov_b, Var_i,b * Var_j,b))
    data = {}
    for (a, c) in pairs:
        S = tuple(1 if j in (a, c) else 0 for j in range(3))
        covs = []
        for b in (1, -1):
            Ea = sum(p * w[a] for w, p in pi[b].items())
            Ec = sum(p * w[c] for w, p in pi[b].items())
            Eac = sum(p * w[a] * w[c] for w, p in pi[b].items())
            covs.append((Eac - Ea * Ec, (1 - Ea * Ea) * (1 - Ec * Ec)))
        data[(a, c)] = (abs(fh[S]), covs)

    def best_term(ac, y):
        """exact lower bound for |hat h(ac)| rho_ac sqrt((1-y_a^2)(1-y_c^2))"""
        a, c = ac
        hh, covs = data[ac]
        lo = Fr(0)
        for cov, vv in covs:
            if vv == 0 or hh == 0:
                continue
            R = cov * cov * (1 - y[a] ** 2) * (1 - y[c] ** 2) / vv
            lo = max(lo, hh * sqrt_lo(R))
        return lo

    def phi_upper(y):
        return sigma * hml(fh, y) - sum(best_term(ac, y) for ac in pairs)

    # classes: coordinates with equal level-one coefficient
    cls = {}
    for j, c in enumerate(lev1):
        cls.setdefault(c, []).append(j)
    cls = list(cls.values())
    best = None
    grid = [Fr(j, 40) for j in range(-40, 41)]
    for vals in itertools.product(grid, repeat=len(cls)):
        y = [None] * 3
        for K, v in zip(cls, vals):
            for j in K:
                y[j] = v
        val = phi_upper(y)
        if best is None or val < best[0]:
            best = (val, tuple(y))
    print(f"rep{i}: 2h={h2}, mu={mu}, classes={[[j + 1 for j in K] for K in cls]}, "
          f"hat h(12),(13),(23)={[str(data[p][0]) for p in pairs]}")
    print(f"   Phi(y) <= {best[0]} = {float(best[0]):.3e} < 0 at class-constant y = {[str(v) for v in best[1]]}")
    assert best[0] < 0
print("Theorem F's hypothesis fails for rep3 and rep8 (hence for their orbits). [EXACT]")
