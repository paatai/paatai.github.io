"""Coordinate-ascent search for class-wise certificates (Theorem C(iii) / D(c)) for the two-class orbits of hard288.

For a two-class h the certificate may use one decoder per class: Gamma_nu(F_a, F_b) = E h(F_{c(1)}(C_1), F_{c(2)}(C_2),
F_{c(3)}(C_3)), where c(j) is the class of column j (columns j, j' are in the same class iff hat h({j}) = hat h({j'})).
By Theorem D this is equivalent to the single-decoder criterion, but at a fixed number k of labels the class-wise
family is strictly larger, so small-k searches over it are more informative than orbit_coord_ascent.py.
h is normalised to mu < 0, so a certificate is Gamma > 0.  Each coordinate update maximises the polynomial (degree <= 3)
Gamma(t) in one value t = F_c(z) exactly.  Floating point; a positive value would have to be confirmed exactly.
usage: python3 classwise_ascent.py "2h vector" kmax restarts seed
Optional environment variables: CLASSES="0,0,1" imposes a class assignment of the columns (for example a one-class h
with two decoders), and OBJ="8 numbers" replaces the objective 2h by another vertex function (the row laws still
come from h); this is used to test relaxed (cubic-free) objectives.
"""
import itertools
import os
import sys
from fractions import Fraction

import numpy as np

h2 = [int(x) for x in sys.argv[1].replace(",", " ").split()]
kmax = int(sys.argv[2]) if len(sys.argv) > 2 else 4
restarts = int(sys.argv[3]) if len(sys.argv) > 3 else 20
rng = np.random.default_rng(int(sys.argv[4]) if len(sys.argv) > 4 else 0)
W3 = list(itertools.product([1, -1], repeat=3))
flip = sum(h2) > 0
if flip:
    h2 = [-x for x in h2]
hval = dict(zip(W3, [x / 2 for x in h2]))
mu = np.mean(list(hval.values()))
obj2 = [float(x) for x in os.environ["OBJ"].replace(",", " ").split()] if os.environ.get("OBJ") else list(h2)
if flip and os.environ.get("OBJ"):
    obj2 = [-x for x in obj2]
oval = dict(zip(W3, [x / 2 for x in obj2]))
hhat = {S: np.mean([oval[w] * np.prod([w[j] for j in S]) for w in W3])
        for r in range(4) for S in itertools.combinations(range(3), r)}
lev1 = [Fraction(sum(h2[i] * W3[i][j] for i in range(8)), 16) for j in range(3)]
if os.environ.get("CLASSES"):
    cls = [int(x) for x in os.environ["CLASSES"].split(",")]
else:
    classes = sorted(set(lev1))
    cls = [classes.index(v) for v in lev1]
ncl = len(set(cls))
pi = {b: {w: (1 + b * hval[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}


def hml(y1, y2, y3):
    ys = (y1, y2, y3)
    out = 0.0
    for S, c in hhat.items():
        t = c
        for j in S:
            t = t * ys[j]
        out = out + t
    return out


def setup(nu):
    k = len(nu)
    rows = [[(w, p) for w, p in pi[b].items() if p > 0] for b in nu]
    cols, probs = [], []
    for combo in itertools.product(*rows):
        p = np.prod([c[1] for c in combo])
        idx = []
        for j in range(3):
            v = 0
            for i in range(k):
                v = 2 * v + (combo[i][0][j] == -1)
            idx.append(v)
        cols.append(idx)
        probs.append(p)
    return np.array(cols), np.array(probs)


def gamma_cols(F, c3, p3):
    return p3 @ hml(F[cls[0]][c3[:, 0]], F[cls[1]][c3[:, 1]], F[cls[2]][c3[:, 2]])


def ascent(F, cols, probs, sweeps=100):
    nz = F.shape[1]
    occ = {}
    for c in range(ncl):
        js = [j for j in range(3) if cls[j] == c]
        for z in range(nz):
            occ[(c, z)] = np.nonzero((cols[:, js] == z).any(axis=1))[0]
    ts = np.array([-1.0, -1 / 3, 1 / 3, 1.0])
    V = np.vander(ts, 4)
    grid = np.linspace(-1, 1, 201)
    keys = list(occ.keys())
    for _ in range(sweeps):
        changed = 0.0
        for i in rng.permutation(len(keys)):
            c, z = keys[i]
            I = occ[(c, z)]
            if len(I) == 0:
                continue
            c3, p3 = cols[I], probs[I]
            vals = []
            for t in ts:
                G = F.copy()
                G[c, z] = t
                vals.append(gamma_cols(G, c3, p3))
            coef = np.linalg.solve(V, np.array(vals))
            cand = np.concatenate([grid, np.roots(np.polyder(coef)).real.clip(-1, 1)])
            tbest = cand[np.argmax(np.polyval(coef, cand))]
            changed = max(changed, abs(tbest - F[c, z]))
            F[c, z] = tbest
        if changed < 1e-10:
            break
    return F


print(f"2h = {tuple(h2)}, mu = {mu:+.4f}, level one = {[str(v) for v in lev1]}, classes of columns = {cls}", flush=True)
overall = -np.inf
for k in range(1, kmax + 1):
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        cols, probs = setup(nu)
        nz = 2 ** k
        dic = np.array([1.0 if (z >> (k - 1)) & 1 == 0 else -1.0 for z in range(nz)])
        starts = []
        for signs in itertools.product([1.0, -1.0], repeat=ncl):
            starts.append(np.array([s * dic for s in signs]))
        starts += [rng.uniform(-1, 1, (ncl, nz)) for _ in range(restarts)]
        starts += [rng.choice([-1.0, 1.0], (ncl, nz)) for _ in range(restarts)]
        best, bestF = -np.inf, None
        for F0 in starts:
            F = ascent(F0.copy(), cols, probs)
            v = gamma_cols(F, cols, probs)
            if v > best:
                best, bestF = v, F.copy()
        overall = max(overall, best)
        print(f'k={k} nu={"".join("+" if b > 0 else "-" for b in nu)}: best local max={best:+.3e}'
              + (f'  F={np.round(bestF, 3).tolist()}' if best > 1e-9 else ''), flush=True)
print(f"overall best = {overall:+.3e}", flush=True)
