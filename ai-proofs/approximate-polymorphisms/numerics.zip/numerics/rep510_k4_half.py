"""rep5 and rep10, k = 4: the one-function inequalities (rep5ex), (R5), (rep10ex), (rep10maj) for every P with values in
{0, 1/2, 1} (all 3^16 of them) and every nu, in exact integer arithmetic.  Only nu = (+1)^r (-1)^(4-r) is run: permuting the
labels permutes the independent rows and the coordinates of P, which preserves the value set of P and both sides.

As in rep510_k4_boolean.py, T is the joint law of the three columns scaled by D (integer entries).  With P2 = 2P in {0,1,2}^16
every side is multiplied by 4 and becomes an integer combination of the entries of T; all entries and partial sums have modulus
at most 20D < 2^23 here, so the float64 products below are exact (the sides and C are also asserted integral, of modulus < 2^40).  Sides (Section 11, paragraphs "Exact forms for rep5 and rep10", "A reduction for rep5",
"A reduction for rep10"), with Q13 = P@M13, Q23 = P@M23, C = sum P(z1)P(z2)T[z1,z2,.], E12 = sum P(z1)P(z2)M12[z1,z2]:
  (rep5ex)   sum_z3 (2Q13 - m3 - 2Q23 + 2C)_+  <=  2 E12
  (R5)       sum_z3 (2Q13 - m3)_+               <=  2 E12
  (rep10ex)  sum_z3 (Q13 + 3Q23 - 2C - m3)_+    <=  P@m1 + E12
  (rep10maj) sum_z3 (Q13 + 3Q23 - 4C - m3)_+    <=  P@m1 - E12
Prints, per orbit, inequality and nu, the maximum of LHS - RHS, the number of P attaining 0, and the number of attaining P with a
value 1/2.  Random P are cross-checked against Fraction computations (rep510_exact.sides, rep10_majorant.sides_major, and (R5)
directly).
usage: python3 rep510_k4_half.py [batch_log2=15] [ncross=10] [seed=1]
"""
import random
import sys
import time
from fractions import Fraction as Fr

import numpy as np

from rep10_majorant import sides_major
from rep510_exact import REPS, setup, sides
from rep510_k4_boolean import K, tables

N = 2 ** K
TOTAL = 3 ** N
POW3 = 3 ** np.arange(N, dtype=np.int64)


def digits(lo, hi):
    idx = np.arange(lo, hi, dtype=np.int64)
    return ((idx[:, None] // POW3[None, :]) % 3).astype(np.float64)


def r5_sides(J, P):
    cond, m3 = {}, {}
    for (z1, z2, z3), q in J.items():
        cond[z3] = cond.get(z3, 0) + q * P[z1]
        m3[z3] = m3.get(z3, 0) + q
    return sum(max(2 * cond[z] - m3[z], 0) for z in cond), 2 * sum(q * P[z1] * P[z2] for (z1, z2, z3), q in J.items())


def scaled_sides(name, T, P2):
    M12, M13, M23 = T.sum(2), T.sum(1), T.sum(0)
    m1, m3 = T.sum((1, 2)), T.sum((0, 1))
    A = (P2 @ T.reshape(N, N * N)).reshape(-1, N, N)
    C = np.matmul(P2[:, None, :], A)[:, 0, :]
    Q13, Q23 = P2 @ M13, P2 @ M23
    E12 = np.einsum("pi,pi->p", P2 @ M12, P2)
    out = {}
    if name == "rep5":
        out["rep5ex"] = (np.maximum(4 * Q13 - 4 * m3 - 4 * Q23 + 2 * C, 0).sum(1), 2 * E12)
        out["R5"] = (np.maximum(4 * Q13 - 4 * m3, 0).sum(1), 2 * E12)
    else:
        out["rep10ex"] = (np.maximum(2 * Q13 + 6 * Q23 - 2 * C - 4 * m3, 0).sum(1), 2 * (P2 @ m1) + E12)
        out["rep10maj"] = (np.maximum(2 * Q13 + 6 * Q23 - 4 * C - 4 * m3, 0).sum(1), 2 * (P2 @ m1) - E12)
    for lhs, rhs in out.values():
        for arr in (lhs, rhs, C):
            assert np.all(arr == np.round(arr)) and np.abs(arr).max() < 2 ** 40
    return out


def main():
    blog = int(sys.argv[1]) if len(sys.argv) > 1 else 15
    ncross = int(sys.argv[2]) if len(sys.argv) > 2 else 10
    rng = random.Random(int(sys.argv[3]) if len(sys.argv) > 3 else 1)
    step = 2 ** blog
    t0 = time.time()
    verdict = {}
    for name in ("rep10", "rep5"):
        _, _, pi = setup(REPS[name])
        for npos in range(K, -1, -1):
            nu = (1,) * npos + (-1,) * (K - npos)
            D, T, J, pts = tables(pi, nu)
            best, n_eq, n_eq_half = {}, {}, {}
            for lo in range(0, TOTAL, step):
                P2 = digits(lo, min(lo + step, TOTAL))
                half = (P2 == 1).any(1)
                for key, (lhs, rhs) in scaled_sides(name, T, P2).items():
                    diff = lhs - rhs
                    mx = diff.max()
                    if key not in best or mx > best[key][0]:
                        best[key] = (mx, lo + int(diff.argmax()))
                    n_eq[key] = n_eq.get(key, 0) + int((diff == 0).sum())
                    n_eq_half[key] = n_eq_half.get(key, 0) + int(((diff == 0) & half).sum())
            for _ in range(ncross):
                idx = rng.randrange(TOTAL)
                P2 = digits(idx, idx + 1)
                P = {z: Fr(int(P2[0, i]), 2) for i, z in enumerate(pts)}
                got = scaled_sides(name, T, P2)
                refs = ({"rep5ex": sides("rep5", J, P), "R5": r5_sides(J, P)} if name == "rep5"
                        else {"rep10ex": sides("rep10", J, P), "rep10maj": sides_major(J, P)})
                for key, (l, r) in refs.items():
                    assert 4 * l * D == int(got[key][0][0]) and 4 * r * D == int(got[key][1][0]), (name, nu, idx, key)
            for key in best:
                mx, arg = best[key]
                val = Fr(int(mx), 4 * D)
                verdict[key] = val if key not in verdict else max(verdict[key], val)
                argP = [int(d) for d in digits(arg, arg + 1)[0]]
                print(f"{name} {key:8s} nu=(+{npos},-{K - npos}): max (LHS - RHS) = {val}; LHS = RHS for {n_eq[key]} of {TOTAL} P, "
                      f"{n_eq_half[key]} of them with a value 1/2; argmax 2P = {argP}  [{time.time() - t0:.0f} s]", flush=True)
            print(f"   {ncross} Fraction cross-checks agree", flush=True)
    for key, val in verdict.items():
        print(f"{key}: max over all {{0,1/2,1}}-valued P with k = 4 and every nu of LHS - RHS = {val}", flush=True)
    assert all(v <= 0 for v in verdict.values()), verdict
    print(f"all four inequalities hold for every {{0,1/2,1}}-valued P with k = 4 and every nu (exact integers)  "
          f"[{time.time() - t0:.0f} s]", flush=True)


if __name__ == "__main__":
    main()
