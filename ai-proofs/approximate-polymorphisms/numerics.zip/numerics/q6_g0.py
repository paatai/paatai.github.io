"""The explicit m = 5 boundary function g0 (MAIN_RESULT, Section 9.1; Theorem E).

g0(w1,w2,w3,u1,u2) = +1  iff  (u1,u2) in A_w, where
  A_{+++} = A_{++-} = A_{+-+} = {},          A_{+--} = all but (+,+),
  A_{-++} = {(+,+),(-,-)},  A_{-+-} = {(+,+)},  A_{--+} = {(+,-)},  A_{---} = {(-,+)}.
Checks (exact, Fractions): g0 depends on all 5 coordinates, mu = -1/2, ghat({u1}) = ghat({u2}) = 0,
ghat({wj}) = -1/8, h(w) = E_u g0(w,u), ||h||^2 = |mu| = 1/2, the s^U criterion holds (h(+--) = 1/2 > 0),
and the certificates TRIV / L0 / LAB1 of q6_exact.py all fail; also every labelled decoder at infinity
F: {-1,1}^k -> {-1,1} with k <= 2 (rows i.i.d. pi_{nu_i}) gives Gamma <= 0, i.e. sigma*Gamma >= 0 since
sigma = -1 (no certificate), with equality Gamma = 0 attained for k = 1 and k = 2.
Every number in the proof of Proposition 9.1 (prop:E) is checked in g0_check.py.
"""
import itertools
from fractions import Fraction as Fr

W = list(itertools.product([1, -1], repeat=3))
U = list(itertools.product([1, -1], repeat=2))
A = {(1, 1, 1): [], (1, 1, -1): [], (1, -1, 1): [],
     (1, -1, -1): [u for u in U if u != (1, 1)],
     (-1, 1, 1): [(1, 1), (-1, -1)], (-1, 1, -1): [(1, 1)], (-1, -1, 1): [(1, -1)], (-1, -1, -1): [(-1, 1)]}
g = {w + u: (1 if u in A[w] else -1) for w in W for u in U}
pts = list(g)

def coef(S):
    return Fr(sum(g[x] * (1 if not S else __import__('math').prod(x[i] for i in S)) for x in pts), 32)

mu = coef(())
l1 = [coef((i,)) for i in range(5)]
dep = all(any(g[x] != g[x[:i] + (-x[i],) + x[i + 1:]] for x in pts) for i in range(5))
h = {w: Fr(sum(g[w + u] for u in U), 4) for w in W}
hn2 = sum(v * v for v in h.values()) / 8
print("truth table g0^{-1}(+1):", sorted(x for x in pts if g[x] == 1))
print("depends on all coordinates:", dep, " mu =", mu, " level-1 =", [str(c) for c in l1])
print("h =", {w: str(v) for w, v in h.items()}, " ||h||^2 =", hn2)
assert dep and mu == Fr(-1, 2) and l1[3] == 0 and l1[4] == 0 and all(c == Fr(-1, 8) for c in l1[:3])
assert hn2 == -mu and max(h.values()) > 0
# certificates (one class: all level-1 coefficients on J are equal)
assert all(h[(a, a, a)] <= 0 for a in (1, -1)), "L0 would apply"
dec = [lambda a: a, lambda a: -a, lambda a: 1, lambda a: -1]
best1 = max(sum((1 + nu * h[w]) * h[tuple(dec[t](a) for a in w)] for w in W) for nu in (1, -1) for t in range(4))
print("best k=1 Boolean decoder value (unnormalised, must be <= 0):", best1)
assert best1 <= 0
# k = 2: rows i.i.d. pi_{nu_i}, decoder F : {+-1}^2 -> {+-1}
labs = list(itertools.product([1, -1], repeat=2))
best2 = None
for nu in itertools.product([1, -1], repeat=2):
    for Fv in itertools.product([1, -1], repeat=4):
        F = dict(zip(labs, Fv))
        tot = Fr(0)
        for w1 in W:
            for w2 in W:
                wt = (1 + nu[0] * h[w1]) * (1 + nu[1] * h[w2])
                if wt == 0:
                    continue
                tot += wt * h[tuple(F[(w1[j], w2[j])] for j in range(3))]
        best2 = tot if best2 is None else max(best2, tot)
print("best k=2 Boolean decoder value (unnormalised, must be <= 0):", best2)
assert best2 <= 0
assert best1 == 0 and best2 == 0  # equality is attained (e.g. by the dictator decoder)
print("g0 verified: s^U_{g0} nontrivial, and no k<=2 Boolean labelled certificate exists (value 0 is attained).")
