"""Moment-problem bound for the inductive step of the biased L1-Khintchine inequality.

Identity (exact): for L = a chi_1 + b M with a^2 + b^2 = 1, M independent of chi_1,
    E|L| = 2 tau a + 2 E Phi_a(bM),   Phi_a(y) = (1-q)(y - a v)_+ + q(-y - a u)_+.
E|L| <= 2 tau  <=>  E Phi_a(bM) <= tau (1 - a).

Here we compute  S(a) = sup { E Phi_a(Y) : E Y = 0, E Y^2 = b^2, E|Y| <= 2 tau b [, extra] }
by a discretised LP and compare it with tau(1-a).  Optional extra constraints:
    E Y^4 <= 3 b^4            (kappa_4 < 0 for chi),
    |E Y^3| <= kappa_3 b^3 min(1, a/b)  (|sum m_j^3| <= max_j |m_j|, max_j |m_j| <= a/b).
"""
import sys

import numpy as np
from scipy.optimize import linprog

q = 3 / 8
u = np.sqrt((1 - q) / q)
v = np.sqrt(q / (1 - q))
tau = np.sqrt(q * (1 - q))
k3 = (1 - 2 * q) / tau


def phi(a, y):
    return (1 - q) * np.maximum(y - a * v, 0) + q * np.maximum(-y - a * u, 0)


def lp_bound(a, extra=(), Y=8.0, n=3201):
    b = np.sqrt(1 - a * a)
    y = np.linspace(-Y * b, Y * b, n)
    c = -phi(a, y)
    A_eq = [np.ones(n), y, y ** 2]
    b_eq = [1.0, 0.0, b * b]
    A_ub = [np.abs(y)]
    b_ub = [2 * tau * b]
    if "m4" in extra:
        A_ub.append(y ** 4)
        b_ub.append(3 * b ** 4)
    if "m3" in extra:
        m3 = k3 * b ** 3 * min(1.0, a / b)
        A_ub.append(y ** 3)
        b_ub.append(m3)
        A_ub.append(-y ** 3)
        b_ub.append(m3)
    res = linprog(c, A_ub=np.array(A_ub), b_ub=b_ub, A_eq=np.array(A_eq), b_eq=b_eq,
                  bounds=(0, None), method="highs")
    if res.status != 0:
        return np.nan, None
    m = res.x
    supp = [(round(float(y[i]), 4), round(float(m[i]), 5)) for i in np.nonzero(m > 1e-7)[0]]
    return -res.fun, supp


def main():
    extras = tuple(sys.argv[1:])
    print(f"extra constraints: {extras or 'none'}")
    print("   a      S(a)        tau(1-a)    margin      support")
    for a in [0.05, 0.1, 0.15, 0.2, 0.25, 0.3, 0.35, 0.4, 0.45, 0.5, 0.55, 0.6, 0.65,
              0.7, 0.72, 0.75, 0.8, 0.85, 0.9, 0.95, 0.99]:
        S, supp = lp_bound(a, extras)
        print(f"{a:5.2f}  {S:10.6f}  {tau * (1 - a):10.6f}  {tau * (1 - a) - S:+10.6f}   {supp}")


if __name__ == "__main__":
    main()
