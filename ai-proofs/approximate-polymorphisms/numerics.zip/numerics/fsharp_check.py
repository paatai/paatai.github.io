"""Exact minima of Phi# (Proposition 10.6) for the 18 m = 8 candidates in class F# of Proposition 10.7, and the worked
example h = (-23/32, 1/8, 1/8, -3/32) quoted in the text (the candidate with the smallest minimum).

Reads numerics/outputs/maxcorr_J2_r6.txt (produced by `python3 maxcorr_J2.py 6`).
"""
import re
import sys
from fractions import Fraction as Fr

sys.argv = sys.argv[:1] + ['6']
import maxcorr_J2 as M  # noqa: E402


def params(hv):
    mu, pi = M.laws(hv)
    x, z, _, y = hv
    b = (x + y - 2 * z) / 4
    lam, qq = {}, {}
    for nu in (1, -1):
        p_ = pi[nu]
        e = p_[0] + p_[1] - p_[2] - p_[3]
        e12 = p_[0] - p_[1] - p_[2] + p_[3]
        lam[nu] = (e12 - e * e) / (1 - e * e)
        qq[nu] = min((1 + e) / 2, (1 - e) / 2)
    return mu, b, lam, qq


def sharp_pieces(hv):
    """sigma = -1 (mu < 0).  Returns (a, q, r, theta, [(c0, c1, c2, lo, hi)] for the three pieces of Phi#)."""
    mu, b, lam, qq = params(hv)
    assert mu < 0 and -b > 0                     # eps = sgn(sigma b) = 1
    D = [nu for nu in (1, -1) if lam[nu] < 0]
    assert len(D) == 1
    a, q = -lam[D[0]], qq[D[0]]
    r = q / (1 - q)
    th = M.theta_lo(a, r)
    s0, s1, s2 = (-M.hml(hv, t, t) for t in (-1, 0, 1))
    A0, A2 = s0, 2 * (s2 + s0) - 4 * s1
    A1 = s2 - s0 - A2
    B, cc = 4 * abs(b), (1 - th) / r
    return a, q, r, th, (A0, A1, A2), [
        (A0, A1 - B * a * th, A2 - B * a * (cc - th), Fr(0), q),
        (A0, A1 - B * a, A2 + B * a, q, 1 - q),
        (A0 - B * a * cc, A1 - B * a * (th - 2 * cc), A2 - B * a * (cc - th), 1 - q, Fr(1)),
    ]


if __name__ == '__main__':
    rows = [ln for ln in open('outputs/maxcorr_J2_r6.txt') if ln.startswith('  THM_F#')]
    assert len(rows) == 18
    res = []
    for ln in rows:
        hv = tuple(Fr(s) for s in re.search(r"= \('([^']*)', '([^']*)', '([^']*)', '([^']*)'\)", ln).groups())
        a, q, r, th, _, pieces = sharp_pieces(hv)
        mins = [M.quad_min(*pc) for pc in pieces]
        assert min(mins) > 0
        res.append((min(mins), hv, th))
    res.sort()
    for mn, hv, th in res:
        print(f"h = {tuple(str(v) for v in hv)}: theta = {th}, min Phi# = {mn} = {float(mn):.4e}")

    hv = (Fr(-23, 32), Fr(1, 8), Fr(1, 8), Fr(-3, 32))
    mu, b, lam, qq = params(hv)
    assert (mu, b, lam[1], lam[-1], qq[1]) == (Fr(-9, 64), Fr(-17, 64), Fr(-23, 65), Fr(163, 747), Fr(9, 22))
    a, q, r, th, sh, pieces = sharp_pieces(hv)
    assert (a, r) == (Fr(23, 65), Fr(9, 13))
    terms = [(r ** l - a ** l) / (1 + r ** l) for l in (1, 3, 5)]
    assert terms[0] == Fr(1, 5) and terms[1] == th == Fr(3589, 16625) and terms[2] < th
    assert sh == (Fr(3, 32), Fr(-7, 16), Fr(17, 16))
    c0, c1, c2, lo, hi = pieces[0]
    assert (c1, c2) == (Fr(-4483837, 8645000), Fr(6981458, 9725625))
    pmin = -c1 / (2 * c2)
    assert lo < pmin < hi and pmin == Fr(40354533, 111703328)
    assert M.quad_min(*pieces[0]) == c0 - c1 * c1 / (4 * c2) == Fr(120965046879, 1931350541120000)
    assert M.quad_min(*pieces[1]) == Fr(3, 1760)
    print("worked example h = (-23/32, 1/8, 1/8, -3/32): all quoted values confirmed")
