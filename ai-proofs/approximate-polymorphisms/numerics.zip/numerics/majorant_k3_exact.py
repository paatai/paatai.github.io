"""Exact maximum of E[h'(Y)] over all [-1,1]-valued class-wise decoders with k <= 3 labels, for the majorants h' >= h of the
reductions for rep5 and rep10 (MAIN_RESULT.pdf, Section 11), in exact rational arithmetic (python-flint), by the face enumeration
of orbit_k3_exact.py.  The rows keep the laws pi_b of h; only the integrand h is replaced by h' = h + 1_v (v outside supp pi_+).

  rep10: h'' = h + 1_{++-}, 8h'' = -1 - y1y2 - y1y3 + y2y3 - 2y1y2y3; max E h''(Y) <= 0 for all decoders is (rep10maj).
  rep5:  h'  = h + 1_{-+-}, 4h'  = -1 - y1(1 + y2 + y3);              max E h'(Y)  <= 0 for all decoders is (R5).
  control: rep5 with h + 1_{+++}, which the paper reports to fail at k = 3, nu = +++ (max E h'(Y) about 0.012).

E h'(Y) is affine in the singleton decoder Fs (one column), so its maximum over Fs is attained at a vertex of [-1,1]^(2^k); for
each vertex it is a quadratic in the pair decoder Fp, maximised exactly over [-1,1]^(2^k) by fast_cube_max (cross-checked against
the Fraction-based cube_max for k <= 2).  For every vertex Fs the quadratic form is checked against a direct evaluation of
E h'(Y) at a random rational Fp.  Permuting label rows does not change the maximum, so nu = (+,...,+,-,...,-).

Then k = 4 for (R5), E(2E[P(X1)|X3] - 1)_+ <= 2E[P(X1)P(X2)], over all 2^16 {0,1}-valued P and every nu, in exact integer
arithmetic as in rep510_k4_boolean.py (scaled by D, all quantities integers of modulus < 2^50), with the equality cases and
random cross-checks against a Fraction computation of the two sides (as rep5_reduction.r5_sides).

usage: python3 majorant_k3_exact.py [kmax=3] [ncross=20]
"""
import itertools
import random
import sys
import time
from fractions import Fraction as Fr

import numpy as np

from j2_k2_exact import cube_max
from orbit_k2_exact import REPS, SUBSETS, W3, column_law, data, gamma, prod_, quad_for_vertex
from orbit_k3_exact import fast_cube_max, fq
from rep510_exact import REPS as REPS_EX, setup
from rep510_k4_boolean import K, tables

CASES = [
    ('rep10', (1, 1, -1), 'rep10maj', {(): -1, (0, 1): -1, (0, 2): -1, (1, 2): 1, (0, 1, 2): -2}, 8),
    ('rep5', (-1, 1, -1), 'R5', {(): -1, (0,): -1, (0, 1): -1, (0, 2): -1}, 4),
    ('rep5', (1, 1, 1), 'control', None, None),
]


def sgn(t):
    return ''.join('+' if v > 0 else '-' for v in t)


def run_case(name, v, label, expect, scale, kmax, rng):
    hv, mu, hhat, pi, classes = data(REPS[name])
    pair, (s,) = classes
    assert pair == [0, 1] and s == 2, classes
    assert pi[1][v] == 0, (name, v)
    hv2 = {w: hv[w] + (1 if w == v else 0) for w in W3}
    hhat2 = {S: sum(hv2[w] * prod_(w[j] for j in S) for w in W3) / 8 for S in SUBSETS}
    if expect is not None:
        assert all(hhat2[S] == Fr(expect.get(S, 0), scale) for S in SUBSETS), hhat2
    cls_of = {0: 'p', 1: 'p', 2: 's'}
    print(f"{name} [{label}]: h' = h + 1_{sgn(v)}, 2h' = {[int(2 * hv2[w]) for w in W3]}, "
          f"Fourier {{{', '.join(f'{S}: {c}' for S, c in hhat2.items() if c)}}}", flush=True)
    overall = None
    for k in range(kmax + 1):
        n = 2 ** k
        for npos in range(k, -1, -1):
            nu = tuple([1] * npos + [-1] * (k - npos))
            A = column_law(pi, nu)
            assert sum(A.values()) == 1
            best = None
            t0 = time.time()
            for ys in itertools.product((-1, 1), repeat=n):
                c0, lin, Q = quad_for_vertex(hhat2, A, n, pair, s, ys)
                Fp = [Fr(rng.randint(-8, 8), 8) for _ in range(n)]
                assert gamma(hhat2, A, {'p': Fp, 's': ys}, cls_of) == c0 + sum(lin[a] * Fp[a] for a in range(n)) + sum(
                    Q[a][b] * Fp[a] * Fp[b] for a in range(n) for b in range(n))
                val, arg = fast_cube_max(c0, lin, Q)
                if k <= 2:
                    ref, _ = cube_max(c0, lin, Q)
                    assert fq(ref) == val, (name, nu, ys, ref, val)
                if best is None or val > best[0]:
                    best = (val, arg, ys)
            val, arg, ys = best
            overall = val if overall is None else max(overall, val)
            print(f"  k={k} nu={sgn(nu) or '()'}: max E h'(Y) = {val} (~{float(val):.6f})  at Fp = {[str(x) for x in arg]}, "
                  f"Fs = {list(ys)}  [{time.time() - t0:.0f} s]", flush=True)
    print(f"  {name} [{label}]: max E h'(Y) over all [-1,1]-valued class-wise decoders with k <= {kmax}: {overall}", flush=True)
    return overall


def name_r5(p, pts):
    supp = frozenset(z for i, z in enumerate(pts) if (p >> i) & 1)
    names = {frozenset(): "0"}
    for r in range(K):
        names[frozenset(z for z in pts if z[r] == 1)] = f"z{r + 1}=1"
        for s in range(K):
            if s > r:
                names[frozenset(z for z in pts if z[r] == z[s] == 1)] = f"z{r + 1}=z{s + 1}=1"
            if s != r:
                names[frozenset(z for z in pts if z[r] == 1 and z[s] == -1)] = f"(z{r + 1},z{s + 1})=(1,-1)"
    return names.get(supp, f"other{sorted(supp)}")


def r5_k4_boolean(ncross, rng):
    _, _, pi = setup(REPS_EX["rep5"])
    worst = None
    for npos in range(K, -1, -1):
        nu = (1,) * npos + (-1,) * (K - npos)
        D, T, J, pts = tables(pi, nu)
        n = T.shape[0]
        P = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1).astype(np.float64)
        lhs = np.maximum(2 * (P @ T.sum(1)) - T.sum((0, 1)), 0).sum(1)
        rhs = 2 * np.einsum("pi,pi->p", P @ T.sum(2), P)
        for arr in (lhs, rhs):
            assert np.all(arr == np.round(arr)) and np.abs(arr).max() < 2 ** 50
        diff = lhs - rhs
        mx = diff.max()
        second = diff[diff < 0].max()
        print(f"(R5) k=4 nu=(+{npos},-{K - npos}): D = {D}; max (LHS - RHS) = {Fr(int(mx), D)}; LHS = RHS for "
              f"{int((diff == 0).sum())} of {len(diff)} P; largest negative value {float(second) / D:.6g}", flush=True)
        print(f"   equality cases: {', '.join(name_r5(int(q), pts) for q in np.flatnonzero(diff == 0))}", flush=True)
        for _ in range(ncross):
            p = rng.randrange(2 ** n)
            Pd = {z: Fr((p >> i) & 1) for i, z in enumerate(pts)}
            cond, m3 = {}, {}
            for (z1, z2, z3), q in J.items():
                cond[z3] = cond.get(z3, 0) + q * Pd[z1]
                m3[z3] = m3.get(z3, 0) + q
            lf = sum(max(2 * cond[z] - m3[z], 0) for z in cond)
            rf = 2 * sum(q * Pd[z1] * Pd[z2] for (z1, z2, z3), q in J.items())
            assert lf * D == int(lhs[p]) and rf * D == int(rhs[p]), (nu, p)
        worst = Fr(int(mx), D) if worst is None else max(worst, Fr(int(mx), D))
    return worst


if __name__ == '__main__':
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    ncross = int(sys.argv[2]) if len(sys.argv) > 2 else 20
    rng = random.Random(0)
    t0 = time.time()
    res = {label: run_case(name, v, label, expect, scale, kmax, rng) for name, v, label, expect, scale in CASES}
    assert res['rep10maj'] == 0 and res['R5'] == 0, res
    print(f"(rep10maj) and (R5) hold for every k <= {kmax}, every nu and all [0,1]-valued P, B (exact; maximum 0)", flush=True)
    if kmax >= 3:
        assert res['control'] > 0, res
        print(f"control h + 1_+++ for rep5: maximum {res['control']} > 0 at k <= {kmax}, as reported", flush=True)
    worst = r5_k4_boolean(ncross, rng)
    assert worst <= 0, worst
    print(f"(R5) holds for every {{0,1}}-valued P with k = 4 and every nu (max LHS - RHS = {worst}; exact integers); "
          f"{ncross} Fraction cross-checks per nu agree", flush=True)
    print(f"[{time.time() - t0:.0f} s]", flush=True)
