"""Exact maximum of Gamma_nu over all [-1,1]-valued class-wise decoders with k = 3 for the nine two-class boundary orbits
(m = 5, |J| = 3), in exact rational arithmetic (python-flint fmpq / fmpq_mat).  Same set-up as orbit_k2_exact.py.

For a vertex Fs of the singleton decoder, Gamma = c0 + lin . Fp + Fp^T Q Fp.  Its maximum over [-1,1]^n (n = 2^k) is attained
at a critical point of its restriction to the relative interior of a face whose Hessian block 2 Q[free, free] is nonsingular,
or at a vertex (on a face with a singular block the quadratic is affine along a kernel direction, so the maximum over that
face is also attained on its relative boundary).  For each free set the block is inverted once and the critical points for
all 2^(n - |free|) assignments of the fixed coordinates are computed together; those strictly inside the face are evaluated.
For k <= 2 the result is compared, vertex by vertex, with the Fraction-based face enumeration of orbit_k2_exact.py.

usage: python3 orbit_k3_exact.py [k=3] [workers=8] [names ...]
"""
import itertools
import sys
import time
from multiprocessing import Pool

from flint import fmpq, fmpq_mat

from j2_k2_exact import cube_max
from orbit_k2_exact import REPS, column_law, data, quad_for_vertex


def fq(x):
    return fmpq(x.numerator, x.denominator)


def fast_cube_max(c0, lin, Q):
    n = len(lin)
    c0, lin = fq(c0), [fq(v) for v in lin]
    Q = [[fq(v) for v in row] for row in Q]

    def value(F):
        return c0 + sum(lin[a] * F[a] for a in range(n)) + sum(Q[a][b] * F[a] * F[b] for a in range(n) for b in range(n))

    best, arg = None, None
    for mask in range(2 ** n):
        free = [a for a in range(n) if mask >> a & 1]
        fixed = [a for a in range(n) if not mask >> a & 1]
        assigns = list(itertools.product((-1, 1), repeat=len(fixed)))
        if not free:
            for x in assigns:
                F = [fmpq(v) for v in x]
                v = value(F)
                if best is None or v > best:
                    best, arg = v, F
            continue
        f = len(free)
        M = fmpq_mat(f, f, [2 * Q[a][b] for a in free for b in free])
        if M.det() == 0:
            continue
        Minv = M.inv()
        m = len(assigns)
        R = fmpq_mat(f, m, [-(lin[a] + 2 * sum(Q[a][b] * x[t] for t, b in enumerate(fixed))) for a in free for x in assigns])
        S = Minv * R
        for col, x in enumerate(assigns):
            s = [S[r, col] for r in range(f)]
            if all(-1 < v < 1 for v in s):
                F = [fmpq(0)] * n
                for r, a in enumerate(free):
                    F[a] = s[r]
                for t, b in enumerate(fixed):
                    F[b] = fmpq(x[t])
                v = value(F)
                if best is None or v > best:
                    best, arg = v, F
    return best, arg


def task(args):
    name, nu, check = args
    hv, mu, hhat, pi, classes = data(REPS[name])
    pair, (s,) = classes
    k = len(nu)
    n = 2 ** k
    A = column_law(pi, nu)
    best = None
    for ys in itertools.product((-1, 1), repeat=n):
        c0, lin, Q = quad_for_vertex(hhat, A, n, pair, s, ys)
        val, Fp = fast_cube_max(c0, lin, Q)
        if check:
            ref, _ = cube_max(c0, lin, Q)
            assert fq(ref) == val, (name, nu, ys, ref, val)
        if best is None or val > best[0]:
            best = (val, Fp, ys)
    return name, nu, best


if __name__ == '__main__':
    k = int(sys.argv[1]) if len(sys.argv) > 1 else 3
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    names = sys.argv[3:] or list(REPS)
    t0 = time.time()
    jobs = [(name, tuple([1] * npos + [-1] * (k - npos)), k <= 2) for name in names for npos in range(k, -1, -1)]
    with Pool(workers) as pool:
        res = pool.map(task, jobs, chunksize=1)
    overall = {}
    for name, nu, (val, Fp, ys) in res:
        overall[name] = val if name not in overall else max(overall[name], val)
        print(f"{name:6s} k={k} nu={''.join('+' if v > 0 else '-' for v in nu)}: max Gamma = {val}"
              f"  at Fp = {[str(v) for v in Fp]}, Fs = {list(ys)}", flush=True)
    for name in names:
        print(f"{name}: max Gamma over class-wise decoders with k = {k}: {overall[name]}", flush=True)
    assert all(v <= 0 for v in overall.values()), overall
    print(f"all {len(names)} orbits: max Gamma <= 0 for k = {k} and every nu (exact)"
          + ("; cross-checked against orbit_k2_exact.cube_max for every vertex Fs" if k <= 2 else "")
          + f"  [{time.time() - t0:.0f} s]", flush=True)
