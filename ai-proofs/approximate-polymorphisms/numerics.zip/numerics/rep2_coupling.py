"""Exact verification of the four-column coupling proof that the orbit rep2 (2h = (-2,-2,-1,0,1,-2,-1,-1), classes {1,2},{3})
is trivial (Proposition "rep2" in Section 11 of MAIN_RESULT.tex), and hence also A12 = orbit of h_{g0} (class flip).

  * h' >= h is h raised by 1/2 at +++ and ++- and by 1 at -+- (the vertices outside supp pi_+); it has no cubic term:
        8h'(y) = -2 - (y1 - y2) - 2 y1 y2 - (y1 - y2) y3,
    so Gamma'_nu(F) = E[h'(Y)] depends on the row laws only through the pair marginals (w1,w2), (w1,w3), (w2,w3).
  * rho_b on {-1,1}^4 (coordinates u1..u4): rho_+ = (2 d(--++) + d(--+-) + d(++-+) + 2 d(-+-+) + 2 d(+---))/8 and
    rho_- = (1 - 4 rho_+)/12.  Pair marginals: (u1,u3) ~ (u2,u3) ~ (w1,w2), (u1,u4) ~ (w1,w3), (u2,u4) ~ (w2,w3) under pi_b.
    With columns A, B, D, E of a matrix with independent rows ~ rho_{nu_i}:
        8 E[h'(Y)] = -E[psi(F(A), F(B), F(D), F'(E))],  psi(a,b,d,e) = 2 + d(a+b) + e(a-b)
                   = ((1+a)(1+b)(1+d) + (1-a)(1-b)(1-d) + (1+a)(1-b)(1+e) + (1-a)(1+b)(1-e))/2 >= 0.
  * Random exact tests (k <= 3, every nu, random rational / Boolean / dictator class-wise decoders) of
        Gamma_nu(F) <= Gamma'_nu(F) [pi] = E_rho[R] = -E_rho[psi]/8 <= 0.
  * The class flip of {3} maps rep2 to the orbit of A12 (the g0 orbit), checked exactly.
usage: python3 rep2_coupling.py [trials=200] [seed=1]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
W4 = list(itertools.product((1, -1), repeat=4))
H2 = [-2, -2, -1, 0, 1, -2, -1, -1]
A12 = [-2, -2, -2, 1, 0, -1, -1, -1]
h = {w: Fr(v, 2) for w, v in zip(W3, H2)}
mu = sum(h.values()) / 8
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
SUBSETS = [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def multilinear(vals):
    return {S: sum(vals[w] * chi(S, w) for w in W3) / 8 for S in SUBSETS}


def ext(coef, y):
    out = Fr(0)
    for S, c in coef.items():
        out += c * chi(S, y)
    return out


def marg(law, idx):
    out = {}
    for w, p in law.items():
        key = tuple(w[a] for a in idx)
        out[key] = out.get(key, 0) + p
    return out


def psi(a, b, d, e):
    return 2 + d * (a + b) + e * (a - b)


def orbit(vals):
    """Orbit of a function on {-1,1}^3 (tuple of values in W3 order) under coordinate permutations, h -> -h, h -> h(-.)."""
    out = set()
    for perm in itertools.permutations(range(3)):
        for sgn in (1, -1):
            for neg in (1, -1):
                f = {w: v for w, v in zip(W3, vals)}
                out.add(tuple(sgn * f[tuple(neg * w[perm[a]] for a in range(3))] for w in W3))
    return out


def main():
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    assert mu == Fr(-1, 2) and sum(v * v for v in h.values()) / 8 == -mu
    for b in (1, -1):
        assert sum(pi[b].values()) == 1 and min(pi[b].values()) >= 0
    ch = multilinear(h)
    assert [ch[(a,)] for a in range(3)] == [Fr(-1, 8), Fr(-1, 8), Fr(1, 8)]
    supp = [w for w in W3 if pi[1][w] > 0]
    print("pi_+ :", [str(pi[1][w]) for w in W3])
    print("pi_- :", [str(pi[-1][w]) for w in W3])
    print("level one (1/8)(-1,-1,1): classes {1,2},{3}; supp pi_+ misses:", [w for w in W3 if w not in supp])

    hp = dict(h)
    hp[(1, 1, 1)] = Fr(-1, 2)
    hp[(1, 1, -1)] = Fr(-1, 2)
    hp[(-1, 1, -1)] = Fr(0)
    assert all(hp[w] >= h[w] for w in W3) and all(hp[w] == h[w] for w in supp)
    chp = multilinear(hp)
    assert {S: 8 * c for S, c in chp.items() if c} == {(): -2, (0,): -1, (1,): 1, (0, 1): -2, (0, 2): -1, (1, 2): 1}
    print("h' = h raised by 1/2 at +++, ++- and by 1 at -+-: 8h' = -2 - (y1-y2) - 2y1y2 - (y1-y2)y3, no cubic term  [exact]")

    atoms = {(-1, -1, 1, 1): 2, (-1, -1, 1, -1): 1, (1, 1, -1, 1): 1, (-1, 1, -1, 1): 2, (1, -1, -1, -1): 2}
    rho = {1: {u: Fr(atoms.get(u, 0), 8) for u in W4}}
    rho[-1] = {u: (1 - 4 * rho[1][u]) / 12 for u in W4}
    assert rho[-1] == {u: (Fr(1, 8) - (1 + mu) * rho[1][u]) / (1 - mu) for u in W4}
    for b in (1, -1):
        r = rho[b]
        assert sum(r.values()) == 1 and min(r.values()) >= 0
        assert marg(r, (0, 2)) == marg(r, (1, 2)) == marg(pi[b], (0, 1))
        assert marg(r, (0, 3)) == marg(pi[b], (0, 2)) and marg(r, (1, 3)) == marg(pi[b], (1, 2))
        assert marg(pi[b], (0,)) == marg(pi[b], (1,))
        print(f"rho_{'+' if b > 0 else '-'} :", {''.join('+' if x > 0 else '-' for x in u): str(p) for u, p in r.items() if p})
    print("rho_b >= 0; (u1,u3) ~ (u2,u3) ~ (w1,w2), (u1,u4) ~ (w1,w3), (u2,u4) ~ (w2,w3) under pi_b; w1 ~ w2  [exact]")

    for a, b, d, e in itertools.product((1, -1), repeat=4):
        assert 2 * psi(a, b, d, e) == ((1 + a) * (1 + b) * (1 + d) + (1 - a) * (1 - b) * (1 - d)
                                       + (1 + a) * (1 - b) * (1 + e) + (1 - a) * (1 + b) * (1 - e))
        assert psi(a, b, d, e) >= 0
    print("psi(a,b,d,e) = 2 + d(a+b) + e(a-b) = half a sum of four products of factors 1 +- x, so psi >= 0 on [-1,1]^4  [exact]")

    flipped = tuple(int(2 * h[(w[0], w[1], -w[2])]) for w in W3)
    assert flipped in orbit(tuple(A12))
    fl = multilinear({w: h[(w[0], w[1], -w[2])] for w in W3})
    assert len({fl[(a,)] for a in range(3)}) == 1
    print("flipping the class {3} gives", flipped, "in the orbit of A12 (one class): rep2 trivial => A12 trivial  [exact]")

    def expectations(nu, F, Fs, k):
        Eh = Ehp = Fr(0)
        for rows in itertools.product(W3, repeat=k):
            p = Fr(1)
            for i, w in enumerate(rows):
                p *= pi[nu[i]][w]
            if p == 0:
                continue
            y = tuple((F, F, Fs)[j][tuple(w[j] for w in rows)] for j in range(3))
            Eh += p * ext(ch, y)
            Ehp += p * ext(chp, y)
        Epsi = Fr(0)
        for rows in itertools.product(W4, repeat=k):
            p = Fr(1)
            for i, u in enumerate(rows):
                p *= rho[nu[i]][u]
            if p == 0:
                continue
            cols = [tuple(u[j] for u in rows) for j in range(4)]
            Epsi += p * psi(F[cols[0]], F[cols[1]], F[cols[2]], Fs[cols[3]])
        return Eh, Ehp, Epsi

    worst = None
    count = 0
    for k in (1, 2, 3):
        cube = list(itertools.product((1, -1), repeat=k))
        for nu in itertools.product((1, -1), repeat=k):
            ntr = trials if k < 3 else max(1, trials // 10)
            for t in range(ntr):
                mode = t % 3
                if mode == 0:
                    F = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                    Fs = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                elif mode == 1:
                    F = {z: Fr(rng.choice((-1, 1))) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1))) for z in cube}
                else:
                    r = rng.randrange(k)
                    F = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                Eh, Ehp, Epsi = expectations(nu, F, Fs, k)
                assert Eh <= Ehp, (k, nu)
                assert Ehp == -Epsi / 8, (k, nu)
                assert Epsi >= 0
                count += 1
                if worst is None or Ehp > worst[0]:
                    worst = (Ehp, k, nu)
    print(f"{count} random exact tests (k <= 3, every nu): Gamma <= Gamma'[pi] = -E_rho[psi]/8 <= 0 in every case; "
          f"largest Gamma' = {worst[0]} (k={worst[1]}, nu={worst[2]})")
    print("rep2 trivial: Gamma_nu(F) <= 0 for every k, nu and class-wise decoder  [proof in MAIN_RESULT.tex]")


if __name__ == '__main__':
    main()
