"""Coordinate-ascent search for single-decoder certificates (Theorem D(d)) for the orbit representatives of hard288.

Generalises g0_coord_ascent.py to an arbitrary h on {+-1}^3 (given as the integer vector 2h, order +++,...,---),
normalised to mu < 0 so that a certificate is Gamma_nu(F) > 0.  For every k <= kmax and every number of '+' rows,
Gamma_nu(F) = sum_C P_nu(C) h(F(C_1), F(C_2), F(C_3)) is maximised over F : {+-1}^k -> [-1,1] by exact coordinate
ascent (Gamma is a cubic polynomial in each single value F(z)), from the dictator, random continuous and random
Boolean starts.  Floating point; a positive value would have to be confirmed in exact arithmetic.
usage: python3 orbit_coord_ascent.py "2h vector" kmax restarts seed
"""
import itertools
import sys

import numpy as np

h2 = [int(x) for x in sys.argv[1].replace(",", " ").split()]
kmax = int(sys.argv[2]) if len(sys.argv) > 2 else 5
restarts = int(sys.argv[3]) if len(sys.argv) > 3 else 20
rng = np.random.default_rng(int(sys.argv[4]) if len(sys.argv) > 4 else 0)
W3 = list(itertools.product([1, -1], repeat=3))
if sum(h2) > 0:
    h2 = [-x for x in h2]
hval = dict(zip(W3, [x / 2 for x in h2]))
mu = np.mean(list(hval.values()))
hhat = {S: np.mean([hval[w] * np.prod([w[j] for j in S]) for w in W3])
        for r in range(4) for S in itertools.combinations(range(3), r)}
pi = {b: {w: (1 + b * hval[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}


def hml(y1, y2, y3):
    ys = (y1, y2, y3)
    out = 0.0
    for S, c in hhat.items():
        t = c
        for j in S:
            t = t * ys[j]
        out = out + t
    return out


def setup(nu):
    k = len(nu)
    rows = [[(w, p) for w, p in pi[b].items() if p > 0] for b in nu]
    cols, probs = [], []
    for combo in itertools.product(*rows):
        p = np.prod([c[1] for c in combo])
        idx = []
        for j in range(3):
            v = 0
            for i in range(k):
                v = 2 * v + (combo[i][0][j] == -1)
            idx.append(v)
        cols.append(idx)
        probs.append(p)
    return np.array(cols), np.array(probs)


def gamma(F, cols, probs):
    return probs @ hml(F[cols[:, 0]], F[cols[:, 1]], F[cols[:, 2]])


def ascent(F, cols, probs, sweeps=80):
    nz = len(F)
    occ = [np.nonzero((cols == z).any(axis=1))[0] for z in range(nz)]
    ts = np.array([-1.0, -1 / 3, 1 / 3, 1.0])
    V = np.vander(ts, 4)
    grid = np.linspace(-1, 1, 201)
    for _ in range(sweeps):
        changed = 0.0
        for z in rng.permutation(nz):
            I = occ[z]
            if len(I) == 0:
                continue
            c3, p3 = cols[I], probs[I]
            vals = []
            for t in ts:
                G = F.copy()
                G[z] = t
                vals.append(p3 @ hml(G[c3[:, 0]], G[c3[:, 1]], G[c3[:, 2]]))
            coef = np.linalg.solve(V, np.array(vals))
            cand = np.concatenate([grid, np.roots(np.polyder(coef)).real.clip(-1, 1)])
            tbest = cand[np.argmax(np.polyval(coef, cand))]
            changed = max(changed, abs(tbest - F[z]))
            F[z] = tbest
        if changed < 1e-10:
            break
    return F


print(f"2h = {tuple(h2)}, mu = {mu:+.4f}, level one = {[round(hhat[(j,)], 4) for j in range(3)]}", flush=True)
overall = -np.inf
for k in range(1, kmax + 1):
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        cols, probs = setup(nu)
        best, bestF = -np.inf, None
        starts = [np.array([1.0 if (z >> (k - 1)) & 1 == 0 else -1.0 for z in range(2 ** k)])]
        starts += [rng.uniform(-1, 1, 2 ** k) for _ in range(restarts)]
        starts += [rng.choice([-1.0, 1.0], 2 ** k) for _ in range(restarts)]
        for F0 in starts:
            F = ascent(F0.copy(), cols, probs)
            v = gamma(F, cols, probs)
            if v > best:
                best, bestF = v, F.copy()
        overall = max(overall, best)
        print(f'k={k} nu={"".join("+" if b > 0 else "-" for b in nu)}: best local max={best:+.3e}'
              + (f'  F={np.round(bestF, 3).tolist()}' if best > 1e-9 else ''), flush=True)
print(f"overall best = {overall:+.3e}", flush=True)
