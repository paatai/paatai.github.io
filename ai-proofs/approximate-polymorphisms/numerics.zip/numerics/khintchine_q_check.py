"""Exact verification of the constants in the proof of Theorem K for q in {3/8, 2/5, 5/12}.

Notation as in MAIN_RESULT.tex, Section 9.4: chi = u w.p. q, -v w.p. 1-q, u = sqrt((1-q)/q), v = sqrt(q/(1-q)),
tau = sqrt(q(1-q)), theta = 1-2q, kappa = (1-q)/(4q), kappa' = q/(4(1-q)).

  Case A (a <= a_A):   E|L| <= sqrt(2/pi) + a (q^2+(1-q)^2)/(2 tau) < 2 tau,
  Case B (a >= a_B):   R_a(y) <= kappa tau y^2/a, and a + kappa(1-a^2)/a <= 1 iff a >= kappa/(1-kappa) = a_B,
  Case C (a_A<a<a_B):  R_a(y) <= kappa' tau y^2/a + theta y_+ (both discriminants vanish), and
                       psi(a) = a + kappa'(1-a^2)/a + theta sqrt(1-a^2) <= 1, which (s = a/sqrt(1-a^2)) is the cubic
                       2 theta s^3 + (theta^2 + 2 kappa' - 1) s^2 + 2 theta kappa' s + kappa'^2 <= 0.

Everything marked [EXACT] is checked in rational arithmetic (sympy); pi is only used through pi > 3.14159.  This includes
every entry of the table of Section 9.4 (tau^2, theta, kappa, kappa', a_A, a_B, p_q with coprime integer coefficients,
[s_-, s_+]), the identities of the proof for general q (qu = (1-q)v = tau, tau v = q, tau u = 1-q, u + v = 1/tau,
E|chi| = 2 tau, 4 kappa' tau^2 = q^2, Lemma 9.4 (lem:K1), the Case B/C majorants, the cubic reduction, the zero-bias
constant), the numbers of Cases A-C (the constants 17/(8 sqrt 15) < 0.5487, 13/(10 sqrt 6) < 0.5308, 37/(12 sqrt 35) < 0.5212,
their products with a_A below 0.1647, 0.1770, 0.1825, E|L| < 0.9626, 0.9749, 0.9804 < 2 tau = sqrt(15)/4, 2 sqrt(6)/5,
sqrt(35)/6 (> 0.9682, 0.9797, 0.9860), the values of p_q at -1, 0, s_-, s_+, 2, and s(a_A), s(a_B) with their bounds), and
from Remark 9.8 (rem:K): Case A has margin >= 0.0049, max psi on [a_A, a_B] is below 0.9935, 0.9664, 0.9539 (exactly, via
the quartic (s^2 + theta s + kappa')^2 - c^2 s^2 (1 + s^2) < 0 on [s(a_A), s(a_B)]), and a_B <= 1 iff q >= 1/3.
The remaining parts are floating point and only sanity checks: the scan over q (grid of step 0.005, with the Case C range
(a_A, min(a_B, 1)); asserts that the three cases close at every grid point q >= 0.375, that Case C fails at every grid
point q <= 0.37 and that Cases A and B overlap exactly for q >= 0.47), E|L| for random unit vectors (near-dictator checks),
and an adversarial local search started away from dictators (Nelder-Mead on alpha = x/|x| from random starts with
max|alpha_i| <= 0.8, n = 2..10, E|L| by exact enumeration of the 2^n sign patterns), which finds nothing above 2 tau.
usage: python3 khintchine_q_check.py      (runtime about 70 seconds)
"""
import itertools

import numpy as np
import sympy as sp
from scipy.optimize import minimize

R = sp.Rational
PI_LOWER = R(314159, 100000)
assert sp.pi > PI_LOWER
SQRT2PI_UPPER = R(7979, 10000)
# sqrt(2/pi) < 0.7979  <=>  pi > 2/0.7979^2
assert 2 / SQRT2PI_UPPER**2 < PI_LOWER
print("sqrt(2/pi) < 0.7979  [EXACT, from pi > 3.14159]")

# ---------------------------------------------------------------- symbolic identities (general q)
Q, P, a, y, s = sp.symbols("Q P a y s", positive=True)  # q = Q^2, 1-q = P^2, so that all roots are rational
q, pq = Q**2, P**2
tau = Q * P
u, v = P / Q, Q / P
assert sp.simplify(sp.sqrt(q * pq) - tau) == 0 and sp.simplify(sp.sqrt(pq / q) - u) == 0 and sp.simplify(sp.sqrt(q / pq) - v) == 0
for name, expr in [("q u - tau", q * u - tau), ("(1-q) v - tau", pq * v - tau), ("tau v - q", tau * v - q),
                   ("tau u - (1-q)", tau * u - pq), ("tau (u+v) - (q + (1-q))", tau * (u + v) - (q + pq)),
                   ("E|chi| - 2 tau", q * u + pq * v - 2 * tau)]:
    assert sp.simplify(sp.expand(sp.powsimp(expr, force=True))) == 0, name
theta, kappa, kappap = pq - q, pq / (4 * q), q / (4 * pq)  # theta = 1-2q
assert sp.simplify(4 * kappap * tau**2 - q**2) == 0
# Case B: the two quadratic coefficients (1-q)/(4 a v) and q/(4 a u) equal kappa tau/a and kappa' tau/a
assert sp.simplify(pq / (4 * a * v) - kappa * tau / a) == 0
assert sp.simplify(q / (4 * a * u) - kappap * tau / a) == 0
assert sp.simplify(a + kappa * (1 - a**2) / a - 1 - (a - 1) * ((1 - kappa) * a - kappa) / a) == 0
# Case C: c y^2 + theta y - (1-q)(y - a v) = c y^2 - q y + (1-q) a v  and  c y^2 + q y + q a u
# have zero discriminant for c = kappa' tau/a
c = kappap * tau / a
assert sp.simplify(theta - pq + q) == 0
disc1 = q**2 - 4 * c * pq * a * v
disc2 = q**2 - 4 * c * q * a * u
assert sp.simplify(sp.powsimp(disc1, force=True)) == 0 and sp.simplify(sp.powsimp(disc2, force=True)) == 0
# psi(a) <= 1  <=>  cubic(s) <= 0, s = a/b, b = sqrt(1-a^2): (s + theta + kappa'/s)^2 - (1+s^2) = cubic(s)/s^2
th_, kp_ = sp.symbols("theta kappap")
cubic_gen = 2 * th_ * s**3 + (th_**2 + 2 * kp_ - 1) * s**2 + 2 * th_ * kp_ * s + kp_**2
assert sp.simplify((s + th_ + kp_ / s)**2 - (1 + s**2) - cubic_gen / s**2) == 0
# zero-bias coupling constant: tau E|chi - U| = (1-q)^2/2 + (1-(1-q))^2/2 = ((1-q)^2 + q^2)/2
V = sp.symbols("V")
EabsA = sp.integrate(V / tau, (V, 0, pq)) + sp.integrate((1 - V) / tau, (V, pq, 1))
assert sp.expand(EabsA * tau - (pq**2 + (1 - pq)**2) / 2) == 0
# Lemma 9.4: q|au + y| + (1-q)|y - av| = 2 tau a + (2q - 1) y + 2 R_a(y), at rational points (q = Q^2 with 1 - q = P^2)
for Qr, Pr in ((R(3, 5), R(4, 5)), (R(5, 13), R(12, 13))):
    qr, ur, vr, tr = Qr**2, Pr / Qr, Qr / Pr, Qr * Pr
    for ar in (R(1, 5), R(1, 2), R(1)):
        for yr in (R(-3), R(-1), R(-1, 3), R(0), R(1, 4), R(1), R(2)):
            Ra = (1 - qr) * sp.Max(yr - ar * vr, 0) + qr * sp.Max(-yr - ar * ur, 0)
            assert qr * abs(ar * ur + yr) + (1 - qr) * abs(yr - ar * vr) == 2 * tr * ar + (2 * qr - 1) * yr + 2 * Ra
# Remark 9.8(b): a_B <= 1 iff q >= 1/3 (for 1/5 < q <= 1/2, where kappa < 1)
qs = sp.symbols("qs", positive=True)
kB = (1 - qs) / (4 * qs)
assert sp.simplify(kB / (1 - kB) - 1 - 2 * (1 - 3 * qs) / (5 * qs - 1)) == 0 and sp.simplify(1 - kB - (5 * qs - 1) / (4 * qs)) == 0
print("general-q identities (Lemma K1 constants, Case B/C majorants, cubic reduction, zero-bias constant)  [EXACT]")
print("  also E|chi| = 2 tau, 4 kappa' tau^2 = q^2, Lemma 9.4 at rational points, a_B - 1 = 2(1-3q)/(5q-1) (a_B <= 1 iff "
      "q >= 1/3)  [EXACT]")

# ---------------------------------------------------------------- the three biases
TABLE = {
    # q: (a_A, s_lo, s_hi, display constants for Case A)
    R(3, 8): (R(3, 10), R(31, 100), R(21, 20)),
    R(2, 5): (R(1, 3), R(7, 20), R(1)),
    R(5, 12): (R(7, 20), R(9, 25), R(1)),
}
EXPECT = {
    # the table of Section 9.4 and the numbers of Cases A-C: tau^2, (theta, kappa, kappa'), a_B, p_q, p_q(-1, 0, s_-, s_+, 2),
    # (zero-bias constant)^2 and the displayed bounds, (2 tau)^2 and its displayed lower bound, s(a_A)^2, s(a_B)^2,
    # and the bound for max psi of Remark 9.8(a)
    R(3, 8): dict(tau2=R(15, 64), tkk=(R(1, 4), R(5, 12), R(3, 20)), aB=R(5, 7), pq=[200, -255, 30, 9],
                  vals=[-476, 9, R(-2473, 10000), R(-729, 80), 649], zb2=R(17, 8)**2 / 15, zb_ub=R(5487, 10000),
                  azb_ub=R(1647, 10000), EL_ub=R(9626, 10000), two_tau2=R(15, 16), two_tau_lb=R(9682, 10000),
                  sA2=R(9, 91), sB2=R(25, 24), psi_ub=R(9935, 10000)),
    R(2, 5): dict(tau2=R(6, 25), tkk=(R(1, 5), R(3, 8), R(1, 6)), aB=R(3, 5), pq=[360, -564, 60, 25],
                  vals=[-959, 25, R(-1531, 200), -119, 769], zb2=R(13, 10)**2 / 6, zb_ub=R(5308, 10000),
                  azb_ub=R(1770, 10000), EL_ub=R(9749, 10000), two_tau2=R(24, 25), two_tau_lb=R(9797, 10000),
                  sA2=R(1, 8), sB2=R(9, 16), psi_ub=R(9664, 10000)),
    R(5, 12): dict(tau2=R(35, 144), tkk=(R(1, 6), R(7, 20), R(5, 28)), aB=R(7, 13), pq=[2352, -4340, 420, 225],
                   vals=[-6887, 225, R(-1195767, 15625), -1343, 2521], zb2=R(37, 12)**2 / 35, zb_ub=R(5212, 10000),
                   azb_ub=R(1825, 10000), EL_ub=R(9804, 10000), two_tau2=R(35, 36), two_tau_lb=R(9860, 10000),
                   sA2=R(49, 351), sB2=R(49, 120), psi_ub=R(9539, 10000)),
}

for qq, (aA, slo, shi) in TABLE.items():
    t = qq * (1 - qq)
    th, ka, kp = 1 - 2 * qq, (1 - qq) / (4 * qq), qq / (4 * (1 - qq))
    E = EXPECT[qq]
    assert t == E['tau2'] and (th, ka, kp) == E['tkk']
    print(f"\n=== q = {qq}:  tau^2 = {t},  2 tau = {float(2 * sp.sqrt(t)):.7f},  theta = {th},  kappa = {ka},  kappa' = {kp}")
    # Case A: r + aA (1-2t)/(2 sqrt t) <= 2 sqrt t  <=>  X := 4t - (1-2t) aA >= 0 and X^2 >= 4 r^2 t
    X = 4 * t - (1 - 2 * t) * aA
    assert X > 0 and X**2 > 4 * SQRT2PI_UPPER**2 * t
    zb = (qq**2 + (1 - qq)**2) / (2 * sp.sqrt(t))
    bound = SQRT2PI_UPPER + aA * zb
    print(f"Case A: a <= {aA}: zero-bias constant (q^2+(1-q)^2)/(2tau) = {sp.nsimplify(zb)} = {float(zb):.6f};"
          f" E|L| < 0.7979 + {float(aA * zb):.6f} = {float(bound):.6f} < 2 tau  [EXACT]")
    zb2 = (qq**2 + (1 - qq)**2)**2 / (4 * t)
    assert zb2 == E['zb2'] and zb2 < E['zb_ub']**2 and aA**2 * zb2 < E['azb_ub']**2
    assert SQRT2PI_UPPER + E['azb_ub'] == E['EL_ub'] < E['two_tau_lb'] and 4 * t == E['two_tau2'] > E['two_tau_lb']**2
    margin = 2 * (SQRT2PI_UPPER + R(49, 10000))  # Remark 9.8(a): 2 tau - (0.7979 + a_A * constant) >= 0.0049
    assert X**2 >= margin**2 * t
    print(f"        constant = sqrt({zb2}) < {float(E['zb_ub']):.4f}, times a_A < {float(E['azb_ub']):.4f}, E|L| < "
          f"{float(E['EL_ub']):.4f} < {float(E['two_tau_lb']):.4f} < 2 tau = sqrt({E['two_tau2']}); margin "
          f"2 tau - 0.7979 - a_A * constant = {float(2 * sp.sqrt(t) - bound):.6f} >= 0.0049  [EXACT]")
    # Case B
    aB = ka / (1 - ka)
    assert ka >= kp and ka < 1
    assert aB == E['aB']
    print(f"Case B: a >= a_B = kappa/(1-kappa) = {aB}  (kappa >= kappa', kappa < 1)  [EXACT]")
    assert aA < aB
    # Case C
    poly = sp.Poly(sp.expand(cubic_gen.subs({th_: th, kp_: kp})), s)
    den = sp.ilcm(*[sp.fraction(cf)[1] for cf in poly.all_coeffs()])
    P = sp.Poly(sp.expand(den * poly.as_expr()), s)
    assert all(cf.is_integer for cf in P.all_coeffs())
    assert P.all_coeffs() == E['pq'] and sp.igcd(*E['pq']) == 1 and E['pq'][0] > 0
    vals = {pt: P.eval(pt) for pt in (-1, 0, slo, shi, 2)}
    signs = [sp.sign(vals[pt]) for pt in (-1, 0, slo, shi, 2)]
    assert signs == [-1, 1, -1, -1, 1], signs
    assert [vals[pt] for pt in (-1, 0, slo, shi, 2)] == E['vals']
    assert P.count_roots(slo, shi) == 0
    # s-range of Case C inside [slo, shi]: s(a) = a/sqrt(1-a^2) is increasing
    assert aA**2 / (1 - aA**2) > slo**2 and aB**2 / (1 - aB**2) < shi**2
    sA2, sB2 = aA**2 / (1 - aA**2), aB**2 / (1 - aB**2)
    assert sA2 == E['sA2'] and sB2 == E['sB2']
    print(f"Case C: {aA} < a < {aB}: {den} * cubic = {P.as_expr()}")
    print(f"        values at -1, 0, {slo}, {shi}, 2: " + ", ".join(str(vals[pt]) for pt in (-1, 0, slo, shi, 2)))
    print(f"        => one root in each of (-1,0), (0,{slo}), ({shi},2); cubic < 0 on [{slo},{shi}]  [EXACT]")
    print(f"        s(a_A) = {float(aA / sp.sqrt(1 - aA**2)):.5f} >= {slo},  s(a_B) = {float(aB / sp.sqrt(1 - aB**2)):.5f} <= {shi}  [EXACT]")
    print(f"        s(a_A) = sqrt({sA2}), s(a_B) = sqrt({sB2})  [EXACT]")
    # margin of Case C (floating point)
    agrid = np.linspace(float(aA), float(aB), 200001)
    psi = agrid + float(kp) * (1 - agrid**2) / agrid + float(th) * np.sqrt(1 - agrid**2)
    print(f"        (float) max psi on [a_A, a_B] = {psi.max():.5f}")
    # Remark 9.8(a), exactly: psi(a) < c  <=>  (s^2 + theta s + kappa')^2 < c^2 s^2 (1 + s^2), s = s(a) in [s(a_A), s(a_B)]
    cpsi = E['psi_ub']
    Qc = sp.Poly(sp.expand((s**2 + th * s + kp)**2 - cpsi**2 * s**2 * (1 + s**2)), s)
    sAl = sp.floor(sp.sqrt(sA2) * 10**8) / R(10**8)
    sBu = sp.ceiling(sp.sqrt(sB2) * 10**8) / R(10**8)
    assert sAl**2 <= sA2 and sBu**2 >= sB2 and Qc.count_roots(sAl, sBu) == 0 and Qc.eval(sAl) < 0
    assert psi.max() < float(cpsi)
    print(f"        max psi on [a_A, a_B] < c = {float(cpsi):.4f}: the quartic (s^2 + theta s + kappa')^2 - c^2 s^2 (1 + s^2) "
          f"has no root on [{float(sAl):.8f}, {float(sBu):.8f}] (rational endpoints) and is negative there  [EXACT]")

# ---------------------------------------------------------------- floating point: where does the method work?
print("\n(float) scan: q, a_A(q) (exact Case A threshold), a_B(q), max psi_q on [a_A, min(a_B, 1)]")
first_ok = None
status = {}
for qf in np.arange(0.30, 0.50001, 0.005):
    tf = qf * (1 - qf)
    aAf = (2 * np.sqrt(tf) - np.sqrt(2 / np.pi)) * 2 * np.sqrt(tf) / (qf**2 + (1 - qf)**2)
    kaf, kpf, thf = (1 - qf) / (4 * qf), qf / (4 * (1 - qf)), 1 - 2 * qf
    aBf = kaf / (1 - kaf)
    aCf = min(aBf, 1.0)  # a = max|alpha_i| <= 1: for a_B > 1 (q < 1/3) Case B is empty and Case C runs up to a = 1
    if aAf >= aCf:
        mx = -np.inf
    else:
        ag = np.linspace(max(aAf, 1e-9), aCf, 20001)
        mx = (ag + kpf * (1 - ag**2) / ag + thf * np.sqrt(np.maximum(1 - ag**2, 0.0))).max()
    assert np.isfinite(mx) or mx == -np.inf
    ok = mx <= 1
    status[int(round(qf * 1000))] = (ok, aAf >= aBf)
    if ok and first_ok is None:
        first_ok = qf
    if abs(qf * 200 - round(qf * 200)) < 1e-9 and (round(qf * 200) % 2 == 0 or qf < 0.4):
        print(f"  q={qf:.3f}  a_A={aAf:.4f}  a_B={aBf:.4f}  max psi={'(empty)' if mx == -np.inf else f'{mx:.5f}'}  {'ok' if ok else 'FAILS'}")
print(f"(float) the three-case argument closes for all grid points q >= {first_ok:.3f}")
assert len(status) == 41 and all(status[k][0] == (k >= 375) for k in status)
assert all(status[k][1] == (k >= 470) for k in status)
print("(float) asserted on the grid: closes at every q >= 0.375, Case C fails at every q <= 0.370, Cases A and B overlap "
      "(a_A >= a_B) exactly for q >= 0.470")

# ---------------------------------------------------------------- floating point: E|L| for random unit vectors
rng = np.random.default_rng(1)
for qq in TABLE:
    qf = float(qq)
    uf, vf, tf = np.sqrt((1 - qf) / qf), np.sqrt(qf / (1 - qf)), np.sqrt(qf * (1 - qf))
    worst = 0.0
    for n in range(2, 11):
        pts = np.array(list(itertools.product([uf, -vf], repeat=n)))
        wts = np.prod(np.where(pts > 0, qf, 1 - qf), axis=1)
        for _ in range(60):
            al = rng.standard_normal(n) * rng.random(n) ** 3
            al /= np.linalg.norm(al)
            worst = max(worst, float(wts @ np.abs(pts @ al)))
    print(f"(float) q={qq}: max E|L| over 540 random unit vectors, n<=10: {worst:.6f}  vs 2tau = {2 * tf:.6f}")

# ---------------------------------------------------------------- floating point: adversarial search away from dictators
STARTS, CAP = 40, 0.8
print(f"\n(float, adversarial sanity check) local search for E|L| > 2 tau started away from dictators: for each n = 2..10, "
      f"{STARTS} random unit starts\n  with max|alpha_i| <= {CAP}; Nelder-Mead (adaptive) on alpha = x/|x|, E|L| by exact "
      f"enumeration of the 2^n sign patterns; (i) unconstrained,\n  (ii) with max|alpha_i| <= {CAP} enforced by the exact "
      f"penalty 10 (max|alpha_i| - {CAP})_+ (E|L| is 1-Lipschitz in alpha)")
rng = np.random.default_rng(2)
for qq in TABLE:
    qf = float(qq)
    uf, vf, two_tau = np.sqrt((1 - qf) / qf), np.sqrt(qf / (1 - qf)), 2 * np.sqrt(qf * (1 - qf))
    best, best_far, best_cap = (0.0, None, None), 0.0, 0.0
    for n in range(2, 11):
        pts = np.array(list(itertools.product([uf, -vf], repeat=n)))
        wts = np.prod(np.where(pts > 0, qf, 1 - qf), axis=1)

        def EL(x):
            return float(wts @ np.abs(pts @ (x / np.linalg.norm(x))))

        def EL_pen(x):
            return -EL(x) + 10 * max(0.0, np.abs(x / np.linalg.norm(x)).max() - CAP)

        opts = dict(xatol=1e-10, fatol=1e-14, maxiter=3000 * n, maxfev=3000 * n, adaptive=True)
        for _ in range(STARTS):
            while True:
                x0 = rng.standard_normal(n)
                x0 /= np.linalg.norm(x0)
                if np.abs(x0).max() <= CAP:
                    break
            r1 = minimize(lambda x: -EL(x), x0, method="Nelder-Mead", options=opts)
            al = r1.x / np.linalg.norm(r1.x)
            if -r1.fun > best[0]:
                best = (-r1.fun, n, np.abs(al).max())
            if np.abs(al).max() < 0.99:
                best_far = max(best_far, -r1.fun)
            r2 = minimize(EL_pen, x0, method="Nelder-Mead", options=opts)
            if np.abs(r2.x / np.linalg.norm(r2.x)).max() <= CAP + 1e-12:
                best_cap = max(best_cap, EL(r2.x))
    assert best[0] <= two_tau + 1e-9 and best_far < two_tau and 0 < best_cap < two_tau
    kind = "a dictator" if best[2] > 1 - 1e-6 else "not a dictator"
    print(f"  q={qq}: 2 tau = {two_tau:.10f}; (i) best E|L| = {best[0]:.10f} (n = {best[1]}, max|alpha_i| = {best[2]:.6f}: "
          f"{kind}), best local maximum with max|alpha_i| < 0.99: {best_far:.6f}; (ii) best E|L| with max|alpha_i| <= "
          f"{CAP}: {best_cap:.6f}")
print("(float) no unit vector with E|L| > 2 tau + 1e-9 found; away from dictators E|L| stays well below 2 tau")
