"""Exact verification of the coupling proof that the orbit rep3 (2h = (-2,-2,-1,1,0,-1,-1,0), classes {1,3},{2}) is trivial
(Proposition "rep3" in Section 11 of MAIN_RESULT.tex), and hence also rep8 (class flip).

  * h' >= h is h raised to 0 at +++ and ++- (outside supp pi_+); it has no cubic term:
        2h'(y) = -1/4 + (y1 - y3)/4 - y1 y3/4 + y2 y3/2,
    so Gamma'_nu(F) = E[h'(Y)] depends on the row laws only through the pair marginals (w1,w3) and (w2,w3).
  * pit_b = pi_b + c_b w1 w2 (c_+ = 1/10, c_- = -1/22) is a probability law with the same (w1,w3)- and (w2,w3)-marginals,
    under which (w2,w1) has the law of (w2,w3).  Hence, with rows ~ pit, E[F2(V)F(Z)] = E[F2(V)F(X)] and
        8 E[h'(Y)] = -E[1 + F(X)F(Z) - F2(V)(F(X)+F(Z))] = -E[phi],  phi(a,b,t) = (1+t)/2 (1-a)(1-b) + (1-t)/2 (1+a)(1+b) >= 0.
  * Random exact tests (k <= 3, every nu, random rational class-wise decoders) of
        Gamma_nu(F) <= Gamma'_nu(F) [pi] = Gamma'_nu(F) [pit] = -E_pit[phi]/8 <= 0.
usage: python3 rep3_coupling.py [trials=200] [seed=1]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
H2 = [-2, -2, -1, 1, 0, -1, -1, 0]
h = {w: Fr(v, 2) for w, v in zip(W3, H2)}
mu = sum(h.values()) / 8
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}


def multilinear(vals):
    """Fourier coefficients of a function on {-1,1}^3 given by its values (dict w -> value)."""
    return {S: sum(vals[w] * (w[0] if 0 in S else 1) * (w[1] if 1 in S else 1) * (w[2] if 2 in S else 1) for w in W3) / 8
            for S in [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]}


def ext(coef, y):
    out = Fr(0)
    for S, c in coef.items():
        t = c
        for i in S:
            t *= y[i]
        out += t
    return out


def pair(law, i, j):
    out = {}
    for w, p in law.items():
        out[(w[i], w[j])] = out.get((w[i], w[j]), 0) + p
    return out


def main():
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    assert mu == Fr(-3, 8) and sum(v * v for v in h.values()) / 8 == -mu
    for b in (1, -1):
        assert sum(pi[b].values()) == 1 and min(pi[b].values()) >= 0
    supp = [w for w in W3 if pi[1][w] > 0]
    print("pi_+ :", [str(pi[1][w]) for w in W3])
    print("pi_- :", [str(pi[-1][w]) for w in W3])
    print("supp pi_+ misses:", [w for w in W3 if w not in supp])

    hp = dict(h)
    hp[(1, 1, 1)] = Fr(0)
    hp[(1, 1, -1)] = Fr(0)
    assert all(hp[w] >= h[w] for w in W3) and all(hp[w] == h[w] for w in supp)
    ch, chp = multilinear(h), multilinear(hp)
    assert chp[(0, 1, 2)] == 0 and chp[(0, 1)] == 0
    assert {S: 2 * c for S, c in chp.items() if c} == {(): Fr(-1, 4), (0,): Fr(1, 4), (2,): Fr(-1, 4), (0, 2): Fr(-1, 4),
                                                        (1, 2): Fr(1, 2)}
    print("h' = h raised to 0 at +++, ++-: no cubic and no w1w2 term; 2h' = -1/4 + (y1-y3)/4 - y1y3/4 + y2y3/2  [exact]")

    c = {1: Fr(1, 10), -1: Fr(-1, 22)}
    pit = {b: {w: pi[b][w] + c[b] * w[0] * w[1] for w in W3} for b in (1, -1)}
    for b in (1, -1):
        assert sum(pit[b].values()) == 1 and min(pit[b].values()) >= 0
        assert pair(pit[b], 0, 2) == pair(pi[b], 0, 2) and pair(pit[b], 1, 2) == pair(pi[b], 1, 2)
        assert pair(pit[b], 1, 0) == pair(pi[b], 1, 2)
        assert pair(pi[b], 0, 2) == pair(pi[b], 2, 0)
        e12 = sum(p * w[0] * w[1] for w, p in pi[b].items())
        e23 = sum(p * w[1] * w[2] for w, p in pi[b].items())
        assert c[b] == (e23 - e12) / 8
        print(f"pit_{'+' if b > 0 else '-'} = pi + ({c[b]}) w1w2 :", [str(pit[b][w]) for w in W3],
              f" E_pi[w1w2] = {e12}, E_pi[w2w3] = {e23}")
    print("pit_b >= 0, same (w1,w3) and (w2,w3) marginals as pi_b, and (w2,w1) ~ (w2,w3) under pit_b  [exact]")

    def phi(a, bb, t):
        return (1 + t) / 2 * (1 - a) * (1 - bb) + (1 - t) / 2 * (1 + a) * (1 + bb)

    for a, bb, t in itertools.product((1, -1), repeat=3):
        assert phi(a, bb, t) == 1 + a * bb - t * (a + bb) >= 0
    print("phi(a,b,t) = 1 + ab - t(a+b) = (1+t)/2 (1-a)(1-b) + (1-t)/2 (1+a)(1+b) >= 0 on [-1,1]^3  [exact]")

    def expectations(law_rows, F13, F2, k):
        """Exact E[h(Y)], E[h'(Y)] and E[phi] for rows with the given laws; Y = (F13(X), F2(V), F13(Z))."""
        Eh = Ehp = Ephi = Fr(0)
        for rows in itertools.product(W3, repeat=k):
            p = Fr(1)
            for i, w in enumerate(rows):
                p *= law_rows[i][w]
            if p == 0:
                continue
            X = tuple(w[0] for w in rows)
            V = tuple(w[1] for w in rows)
            Z = tuple(w[2] for w in rows)
            y = (F13[X], F2[V], F13[Z])
            Eh += p * ext(ch, y)
            Ehp += p * ext(chp, y)
            Ephi += p * phi(y[0], y[2], y[1])
        return Eh, Ehp, Ephi

    worst = None
    count = 0
    for k in (1, 2, 3):
        cube = list(itertools.product((1, -1), repeat=k))
        for nu in itertools.product((1, -1), repeat=k):
            ntr = trials if k < 3 else max(1, trials // 10)
            for t in range(ntr):
                mode = t % 3
                if mode == 0:
                    F13 = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                    F2 = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                elif mode == 1:
                    F13 = {z: Fr(rng.choice((-1, 1))) for z in cube}
                    F2 = {z: Fr(rng.choice((-1, 1))) for z in cube}
                else:
                    r = rng.randrange(k)
                    s = rng.choice((-1, 1))
                    F13 = {z: Fr(s * z[r]) for z in cube}
                    F2 = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                Eh, Ehp, _ = expectations([pi[b] for b in nu], F13, F2, k)
                Eh2, Ehp2, Ephi = expectations([pit[b] for b in nu], F13, F2, k)
                assert Eh <= Ehp, (k, nu)
                assert Ehp == Ehp2 == -Ephi / 8, (k, nu)
                assert Ephi >= 0
                count += 1
                if worst is None or Ehp > worst[0]:
                    worst = (Ehp, k, nu)
    print(f"{count} random exact tests (k <= 3, every nu): Gamma <= Gamma'[pi] = Gamma'[pit] = -E_pit[phi]/8 <= 0 in every case; "
          f"largest Gamma' = {worst[0]} (k={worst[1]}, nu={worst[2]})")
    print("rep3 (and rep8) trivial: Gamma_nu(F) <= 0 for every k, nu and class-wise decoder  [proof in MAIN_RESULT.tex]")


if __name__ == '__main__':
    main()
