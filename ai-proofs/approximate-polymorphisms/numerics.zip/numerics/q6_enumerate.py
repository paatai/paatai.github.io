"""Q6 exploration: for every g on m bits (mu != 0, depends on all coords, not +-parity),
compute
  * J = {j : ghat({j}) != 0}, h(w) = E_u g(w,u) on {+-1}^J,
  * the s^U criterion  (exists w: sgn(mu) h(w) < 0),
  * 'infinity' constructions:
      (L0) no labels, effective input w_j = psi(rho_j) for any function psi of rho_j
           (realisable by one-dimensional q with breakpoints at different scales);
      (Lk) k junta labels: rows of W independent, row i ~ uniform on g^{-1}(nu_i);
           effective input w_j = F_{c(j)}(W_{.j}),  F_c : {+-1}^k -> {+-1} per class c.
Reports functions where the s^U criterion holds but these constructions fail.
"""
import itertools
import sys
import numpy as np

m = int(sys.argv[1]) if len(sys.argv) > 1 else 3
KMAX = int(sys.argv[2]) if len(sys.argv) > 2 else 2

pts = np.array(list(itertools.product([1, -1], repeat=m)))  # 2^m x m
N = len(pts)
idx = {tuple(p): i for i, p in enumerate(pts)}


def chars(S):
    return np.prod(pts[:, list(S)], axis=1) if S else np.ones(N)


def analyse(tt):
    tt = np.asarray(tt)
    mu = tt.mean()
    l1 = np.array([np.mean(tt * pts[:, j]) for j in range(m)])
    J = [j for j in range(m) if abs(l1[j]) > 1e-12]
    Jc = [j for j in range(m) if j not in J]
    # h on {+-1}^J
    hpts = list(itertools.product([1, -1], repeat=len(J)))
    h = {}
    for w in hpts:
        vals = [tt[i] for i in range(N) if tuple(pts[i, J]) == w]
        h[w] = np.mean(vals)
    sg = np.sign(mu)
    crit = any(sg * h[w] < -1e-12 for w in hpts)
    # classes by value of ghat({j})
    vals = sorted(set(np.round(l1[J], 12)))
    cls = [vals.index(np.round(l1[j], 12)) for j in J]
    r = len(vals)
    # (L0): class-measurable w
    best0 = -np.inf
    for psi in itertools.product([1, -1], repeat=r):
        w = tuple(psi[c] for c in cls)
        best0 = max(best0, -sg * h[w])
    return dict(mu=mu, l1=l1, J=J, h=h, crit=crit, cls=cls, r=r, best0=best0, tt=tt)


def label_best(A, k):
    """max over nu in {+-1}^k (up to row order) and class decoders of
       -sgn(mu) * E_{W ~ D_nu}[h(F(W_J))]   (unnormalised by P(nu))."""
    tt, J, h, cls, r, mu = A['tt'], A['J'], A['h'], A['cls'], A['r'], A['mu']
    sg = np.sign(mu)
    best = -np.inf
    rows_by_b = {b: [pts[i] for i in range(N) if tt[i] == b] for b in (1, -1)}
    lab = list(itertools.product([1, -1], repeat=k))
    labidx = {l: i for i, l in enumerate(lab)}
    for npos in range(k + 1):
        nu = [1] * npos + [-1] * (k - npos)
        # enumerate W: choose a row for each i
        Ws = list(itertools.product(*[rows_by_b[b] for b in nu]))
        weight = 1.0 / np.prod([len(rows_by_b[b]) for b in nu])
        # for each W, the column labels (as index into lab) for columns in J
        colidx = np.array([[labidx[tuple(int(W[i][j]) for i in range(k))] for j in J] for W in Ws])
        # optimise decoders: brute force over F_c in {+-1}^{2^k} for each class
        nF = 2 ** (2 ** k)
        if nF ** r > 3_000_000:
            return None
        Fs = np.array(list(itertools.product([1, -1], repeat=2 ** k)))
        hJ = np.array([h[w] for w in itertools.product([1, -1], repeat=len(J))])
        hidx = {w: i for i, w in enumerate(itertools.product([1, -1], repeat=len(J)))}
        for combo in itertools.product(range(nF), repeat=r):
            # effective inputs
            eff = np.empty(colidx.shape, dtype=int)
            for t, j in enumerate(J):
                eff[:, t] = Fs[combo[cls[t]]][colidx[:, t]]
            val = 0.0
            for row in eff:
                val += h[tuple(row)]
            val *= weight
            best = max(best, -sg * val)
    return best


def is_parity(tt):
    for s in (1, -1):
        if np.all(tt == s * np.prod(pts, axis=1)):
            return True
    return False


def depends_all(tt):
    for j in range(m):
        flip = pts.copy()
        flip[:, j] *= -1
        if all(tt[idx[tuple(flip[i])]] == tt[i] for i in range(N)):
            return False
    return True


def canon(tt):
    """canonical rep under S_m, output negation, global input negation."""
    best = None
    for perm in itertools.permutations(range(m)):
        for ins in (1, -1):
            for outs in (1, -1):
                new = np.empty(N, dtype=int)
                for i in range(N):
                    x = ins * pts[i][list(perm)]
                    new[i] = outs * tt[idx[tuple(x)]]
                key = tuple(new)
                if best is None or key < best:
                    best = key
    return best


seen = set()
reps = []
for bits in itertools.product([1, -1], repeat=N):
    tt = np.array(bits)
    if tt.sum() == 0 or is_parity(tt) or not depends_all(tt):
        continue
    c = canon(tt)
    if c in seen:
        continue
    seen.add(c)
    reps.append(np.array(c))

print(f"m={m}: {len(reps)} classes (mu != 0, depends on all, not parity)")
hard = 0
for tt in reps:
    A = analyse(tt)
    if not A['crit']:
        status = "TRIVIAL(s^U trivial)"
    elif A['best0'] > 1e-12:
        status = "L0 works (s^L nontrivial at infinity)"
    else:
        status = None
        for k in range(1, KMAX + 1):
            b = label_best(A, k)
            if b is not None and b > 1e-12:
                status = f"labels k={k} work (val {b:.4f})"
                break
        if status is None:
            status = "HARD: s^U nontrivial, constructions fail"
            hard += 1
    ones = [tuple(int(v) for v in pts[i]) for i in range(N) if tt[i] == 1]
    print(f"mu={A['mu']:+.3f} l1={np.round(A['l1'],3)} J={A['J']} classes={A['cls']} | {status} | g^-1(+1)={ones}")
print("hard cases:", hard)
