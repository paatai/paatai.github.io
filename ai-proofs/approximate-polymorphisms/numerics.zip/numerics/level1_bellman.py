"""Minimal Bellman function for the level-1 vector on the q-biased cube (q = 3/8).

For P:{-1,1}^k -> [0,1] put D_i = E[P | x_i=+] - E[P | x_i=-] and beta(P) = ||D||_2.
Splitting on the last coordinate, P = (P_+, P_-) with means x, y and p = q x + (1-q) y,
    beta(P)^2 = (x-y)^2 + || q D(P_+) + (1-q) D(P_-) ||^2 <= (x-y)^2 + (q beta(P_+) + (1-q) beta(P_-))^2.
Hence any B >= 0 on [0,1] with
    (TP)  B(q x + (1-q) y)^2 >= (x-y)^2 + (q B(x) + (1-q) B(y))^2      for all x, y in [0,1]
satisfies beta(P) <= B(E P) for every P (induction on k).  Value iteration from B = 0 computes the least
such B on a grid (linear interpolation).  We need B <= 1 on [3/8, 5/11].
"""
import numpy as np

q = 3 / 8
M = 4000
grid = np.linspace(0, 1, M + 1)


def interp(B, t):
    return np.interp(t, grid, B)


def iterate(B, nx=4001):
    xs = np.linspace(0, 1, nx)
    newB = B.copy()
    for idx, p in enumerate(grid):
        # x ranges so that y = (p - q x)/(1-q) in [0,1]
        lo = max(0.0, (p - (1 - q)) / q)
        hi = min(1.0, p / q)
        if hi < lo:
            continue
        x = np.linspace(lo, hi, 400)
        y = (p - q * x) / (1 - q)
        y = np.clip(y, 0, 1)
        val = np.sqrt((x - y) ** 2 + (q * interp(B, x) + (1 - q) * interp(B, y)) ** 2)
        newB[idx] = max(newB[idx], val.max())
    return newB


B = np.zeros_like(grid)
for it in range(200):
    nb = iterate(B)
    diff = np.abs(nb - B).max()
    B = nb
    if it % 10 == 0 or diff < 1e-10:
        sel = (grid >= 3 / 8) & (grid <= 5 / 11)
        print(f"iter {it:3d}  change {diff:.2e}  B(3/8)={interp(B, 3/8):.6f}  max_[3/8,5/11] B = {B[sel].max():.6f} "
              f"at p={grid[sel][np.argmax(B[sel])]:.4f}   max B = {B.max():.6f} at p={grid[np.argmax(B)]:.4f}", flush=True)
    if diff < 1e-10:
        break
np.save('outputs/level1_bellman_B.npy', np.vstack([grid, B]))
for p in [0.05, 0.1, 0.2, 0.3, 0.35, 0.375, 0.38, 0.4, 0.42, 0.45, 5 / 11, 0.5, 0.6, 0.7, 0.8, 0.9]:
    print(f"p={p:.4f}  B={interp(B, p):.6f}   sqrt(64/15 p(1-p))={np.sqrt(64 / 15 * p * (1 - p)):.6f}")
