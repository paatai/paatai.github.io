"""One-parameter coupling bound for one class of size two, case eps = 1 (numerical test).

Coupling (-t, lambda'): correlation -t on the rows of sign nu_* (t in [a, r], r = q/(1-q)), the actual coupling on the
other rows.  With c = a(1+a)/(t(1+t)) and kappa = a(t-a)/(1+t), and provided kappa >= c t^j - a^j for all even j >= 4,
  -Cov(P(X), P(Z)) <= c min(p^2, (1-p)^2) + kappa p(1-p),
so sigma Gamma >= Phi_t(p) = sigma h(2p-1, 2p-1) - 4|b| [c K + kappa V].  Report min_p max_t Phi_t(p).
"""
from fractions import Fraction as Fr

import numpy as np

from fpp_test import UNDEC, params, sh


def admissible(a, t):
    c = a * (1 + a) / (t * (1 + t))
    kap = a * (t - a) / (1 + t)
    j = 4
    while c * t ** j > kap and j < 400:
        if c * t ** j - a ** j > kap + 1e-15:
            return False
        j += 2
    return True


def run(hv, ngrid=2001, nt=400):
    mu, pi, b, lam, qq = params(hv)
    nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    a = float(-lam[nus])
    q = float(qq[nus])
    r = q / (1 - q)
    rho = max(abs(float(lam[1])), abs(float(lam[-1])))
    ts = [t for t in np.linspace(a, r, nt) if admissible(a, t)]
    ps = np.linspace(0, 1, ngrid)
    best = []
    for p in ps:
        K = min(p * p, (1 - p) ** 2)
        V = p * (1 - p)
        brk = min(a * (1 + a) / (t * (1 + t)) * K + a * (t - a) / (1 + t) * V for t in ts)
        brk = min(brk, rho * V)
        best.append(float(sh(hv, Fr(p).limit_denominator(10 ** 9))) - 4 * abs(float(b)) * brk)
    best = np.array(best)
    i = best.argmin()
    return best[i], ps[i], a, r, ts[-1]


if __name__ == '__main__':
    for xs, zs, ys in UNDEC:
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        v, p, a, r, tmax = run(hv)
        print(f"h = ({xs}, {zs}, {zs}, {ys}): a = {a:.4f}, r = {r:.4f}, max admissible t = {tmax:.4f}: "
              f"min_p Phi = {v:+.6f} at p = {p:.4f}", flush=True)
