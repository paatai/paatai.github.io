"""Read-once "formula" decoders for one class of size two, all label rows of the dangerous sign nu_* (floating point).

Per row, the column pair (X_r, Z_r) has P(c, c) = s = q^2 - a q (1 - q) for the less likely value c (correlation -a).
If g has mean m and W = E[g(X) g(Z)], then on a fresh row
  AND with D = 1[z = c]      : (m, W) -> (q m, s W)
  AND with 1 - D             : (m, W) -> ((1-q) m, (1 - 2q + s) W)
  complement 1 - g           : (m, W) -> (1 - m, 1 - 2m + W)
  scaling lambda g           : (m, W) -> (lambda m, lambda^2 W)
all realised by actual decoders.  Value iteration on a grid of m gives an upper envelope L(m) for
inf E[P(X) P(Z)] over this family; sigma Gamma = phi(m) + 4|b| (L(m) - m^2), phi(p) = sigma h(2p-1, 2p-1).
Compares with the lower bound of Proposition 10.6 and reports min_m of the family value for each candidate.
usage: python3 formula_envelope.py "x z y" ["x z y" ...]
"""
import sys
from fractions import Fraction as Fr

import numpy as np

sys.argv, _args = sys.argv[:1] + ['6'], sys.argv[1:]
import maxcorr_J2 as M  # noqa: E402
from fsharp_check import params  # noqa: E402

N = 20001
grid = np.linspace(0, 1, N)


def envelope(q, s, iters=200):
    L = grid ** 2
    sb = 1 - 2 * q + s
    lams = np.linspace(0, 1, 201)[1:]
    for _ in range(iters):
        old = L.copy()
        # AND with D and with 1 - D: target mean t = q m  -> m = t / q
        for f, sc in ((q, s), (1 - q, sb)):
            mm = grid[grid <= f] / f
            L[: len(mm)] = np.minimum(L[: len(mm)], sc * np.interp(mm, grid, L))
        # complement
        L = np.minimum(L, 1 - 2 * grid[::-1] + L[::-1])
        # scaling: L(t) <= lambda^2 L(t / lambda)
        for lam in lams[::10]:
            mm = grid[grid <= lam] / lam
            L[: len(mm)] = np.minimum(L[: len(mm)], lam ** 2 * np.interp(mm, grid, L))
        if np.max(np.abs(old - L)) < 1e-15:
            break
    return L


if __name__ == '__main__':
    for spec in _args:
        xs, zs, ys = spec.split()
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        mu, b, lam, qq = params(hv)
        D = [nu for nu in (1, -1) if lam[nu] < 0]
        nus = D[0]
        a, q = float(-lam[nus]), float(qq[nus])
        r = q / (1 - q)
        th = float(M.theta_lo(-lam[nus], qq[nus] / (1 - qq[nus])))
        s = q * q - a * q * (1 - q)
        L = envelope(q, s)
        phi = np.array([float(-M.hml(hv, Fr(2 * p - 1).limit_denominator(10 ** 6), Fr(2 * p - 1).limit_denominator(10 ** 6)))
                        for p in grid[::20]])
        B = 4 * abs(float(b))
        fam = phi + B * (L[::20] - grid[::20] ** 2)
        pm = grid[::20]
        sharp = -a * np.minimum(pm * (1 - pm), th * pm * (1 - pm) + (1 - th) / r * np.minimum(pm, 1 - pm) ** 2)
        lowb = phi + B * sharp
        i = int(np.argmin(fam))
        j = int(np.argmin(lowb))
        gap = np.max((L[::20] - pm ** 2) - sharp)
        print(f"h = ({xs}, {zs}, {ys}): a={a:.4f} q={q:.4f} theta={th:.4f}; family min {fam[i]:+.3e} at p={pm[i]:.4f}; "
              f"Phi# min {lowb[j]:+.3e} at p={pm[j]:.4f}; max gap Cov_family - bound = {gap:.3e}", flush=True)
