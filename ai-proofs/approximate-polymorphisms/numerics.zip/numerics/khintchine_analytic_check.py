"""Sanity checks (floating point) for the analytic proof of Theorem K (q = 3/8).

Middle case majorant: for t > 0 and all real m,
    Phi_t(m) = (5/8)(m - t)_+ + (3/8)(-m - 5t/3)_+  <=  9 m^2 / (160 t) + m_+ / 4,
with equality at m = 0 (for m <= 0 on [-5t/3, 0]), m = 10t/3 and m = -10t/3.
Consequence (a = max coefficient, b = sqrt(1-a^2)):
    E|L| <= 2 tau [a + 3 b^2/(20 a) + b/4]          (middle case, uses E|M| <= 2 tau)
    E|L| <= 2 tau [a + 5 b^2/(12 a)]                 (large-coefficient case)
    E|L| <= sqrt(2/pi) + 17/(8 sqrt 15) max|alpha_i| (small-coefficient case, zero bias)
Also checks the cubic 200 s^3 - 255 s^2 + 30 s + 9 < 0 on [31/100, 21/20] by exact root location,
and runs a Monte-Carlo-free exact test of E|L| for random unit vectors (n <= 12).
"""
import itertools
from fractions import Fraction as Fr

import numpy as np

q = 3 / 8
u, v = np.sqrt(5 / 3), np.sqrt(3 / 5)
tau = np.sqrt(15) / 8


def phi_t(t, m):
    return 0.625 * np.maximum(m - t, 0) + 0.375 * np.maximum(-m - 5 * t / 3, 0)


def majorant(t, m):
    return 9 * m * m / (160 * t) + np.maximum(m, 0) / 4


worst = np.inf
for t in np.linspace(0.01, 5, 500):
    m = np.linspace(-40 * t - 5, 40 * t + 5, 20001)
    worst = min(worst, np.min(majorant(t, m) - phi_t(t, m)))
print(f"min over grid of majorant - Phi_t: {worst:.3e} (should be >= -1e-12)")

a = np.linspace(0.3, 5 / 7, 100001)
b = np.sqrt(1 - a * a)
mid = a + 3 * b * b / (20 * a) + b / 4
print(f"middle case: max over a in [3/10,5/7] of a + 3b^2/(20a) + b/4 = {mid.max():.6f} (< 1)")
a2 = np.linspace(5 / 7, 1, 100001)
big = a2 + 5 * (1 - a2 * a2) / (12 * a2)
print(f"large case : max over a in [5/7,1] of a + 5b^2/(12a) = {big.max():.6f} (<= 1)")
small = np.sqrt(2 / np.pi) + 17 / (8 * np.sqrt(15)) * 0.3
print(f"small case : sqrt(2/pi) + 0.3*17/(8 sqrt15) = {small:.6f} < 2 tau = {2 * tau:.6f}")


def p(s):
    return 200 * s ** 3 - 255 * s ** 2 + 30 * s + 9


pts = [Fr(-1), Fr(0), Fr(31, 100), Fr(21, 20), Fr(2)]
print("cubic signs at -1, 0, 31/100, 21/20, 2:", [str(p(x)) for x in pts])
print("s-range of the middle case: [3/sqrt(91), 5/sqrt(24)] =", [3 / np.sqrt(91), 5 / np.sqrt(24)])


def exact_EL(alpha):
    n = len(alpha)
    tot = 0.0
    for bits in itertools.product((0, 1), repeat=n):
        k = sum(bits)
        val = sum(al * (u if bt else -v) for al, bt in zip(alpha, bits))
        tot += q ** k * (1 - q) ** (n - k) * abs(val)
    return tot


rng = np.random.default_rng(1)
best = 0.0
for n in range(2, 13):
    for _ in range(40):
        al = rng.normal(size=n)
        if rng.random() < 0.5:
            al[0] *= 4
        al /= np.linalg.norm(al)
        best = max(best, exact_EL(al))
print(f"random unit vectors, n<=12: max E|L| = {best:.6f} <= 2 tau = {2 * tau:.6f}")
