"""Exact verification of the five-column coupling proof that the orbit rep7 (2h = (-1,-2,-1,0,1,-2,-1,0), classes {1,2},{3}) is
trivial (Proposition "rep7" in Section 11 of MAIN_RESULT.tex), and hence also A24 = orbit of h_{g1} (class flip).

  * No majorant is needed: with columns A, B, C (decoder F of {1,2}) and D, E (decoder F' of {3}) of a matrix with independent rows
    ~ rho_{nu_i}, Gamma_nu(F) = E[R(F(A), F(B), F(C), F'(D), F'(E))] for
        8R(a,b,c,d,e) = -3 - a - b + e - bc - ad + ae + bd + be - ace,
    provided (a,c,e) ~ (w2,w1,w3) (full row law), (b,c) ~ (w1,w2), (a,d) ~ (w1,w3), (b,d) ~ (b,e) ~ (w2,w3) under pi_b.
  * rho_+ (7 atoms, denominators 10) and rho_- (9 atoms, denominators 22) are explicit.
  * -8R >= 3 + a + b + bc - |a-b| - |ac-1-a-b| (minimum over d, e), which is 2+2c or 0 at the vertices (a,b,c); so R <= 0.
  * Random exact tests (k <= 3, every nu, random rational / Boolean / dictator class-wise decoders) of Gamma_nu(F) = E_rho[R] <= 0.
  * Flipping the class {3} of rep7 merges the classes and gives a function in the orbit of A24 (checked exactly).
usage: python3 rep7_coupling.py [trials=200] [seed=1]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))
W5 = list(itertools.product((1, -1), repeat=5))
H2 = [-1, -2, -1, 0, 1, -2, -1, 0]
A24 = [-2, -2, -1, 1, 0, 0, -1, -1]
h = {w: Fr(v, 2) for w, v in zip(W3, H2)}
mu = sum(h.values()) / 8
pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
SUBSETS = [(), (0,), (1,), (2,), (0, 1), (0, 2), (1, 2), (0, 1, 2)]
RHO = {
    1: {'++-++': Fr(1, 5), '+-+-+': Fr(1, 10), '+---+': Fr(1, 10), '-++++': Fr(1, 10), '-+-++': Fr(1, 10), '--+--': Fr(1, 5),
        '---+-': Fr(1, 5)},
    -1: {'+++--': Fr(2, 11), '++-+-': Fr(2, 11), '++--+': Fr(1, 22), '+-+++': Fr(1, 11), '+-+-+': Fr(1, 22), '-++-+': Fr(3, 22),
         '--++-': Fr(1, 11), '---+-': Fr(1, 11), '----+': Fr(3, 22)},
}


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def multilinear(vals):
    return {S: sum(vals[w] * chi(S, w) for w in W3) / 8 for S in SUBSETS}


def ext(coef, y):
    return sum((c * chi(S, y) for S, c in coef.items()), Fr(0))


def marg(law, idx):
    out = {}
    for w, p in law.items():
        key = tuple(w[a] for a in idx)
        out[key] = out.get(key, 0) + p
    return out


def R8(a, b, c, d, e):
    return -3 - a - b + e - b * c - a * d + a * e + b * d + b * e - a * c * e


def orbit(vals):
    out = set()
    for perm in itertools.permutations(range(3)):
        for sgn in (1, -1):
            for neg in (1, -1):
                f = {w: v for w, v in zip(W3, vals)}
                out.add(tuple(sgn * f[tuple(neg * w[perm[a]] for a in range(3))] for w in W3))
    return out


def main():
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 200
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    assert mu == Fr(-3, 8) and sum(v * v for v in h.values()) / 8 == -mu
    for b in (1, -1):
        assert sum(pi[b].values()) == 1 and min(pi[b].values()) >= 0
    ch = multilinear(h)
    assert [ch[(a,)] for a in range(3)] == [Fr(-1, 8), Fr(-1, 8), Fr(1, 8)]
    assert {S: 8 * c for S, c in ch.items() if c} == {(): -3, (0,): -1, (1,): -1, (2,): 1, (0, 1): -1, (0, 2): -1, (1, 2): 3,
                                                      (0, 1, 2): -1}
    print("pi_+ :", [str(pi[1][w]) for w in W3])
    print("pi_- :", [str(pi[-1][w]) for w in W3])
    print("8h = -3 - y1 - y2 + y3 - y1y2 - y1y3 + 3y2y3 - y1y2y3; classes {1,2},{3}  [exact]")

    rho = {b: {u: RHO[b].get(''.join('+' if t > 0 else '-' for t in u), Fr(0)) for u in W5} for b in (1, -1)}
    for b in (1, -1):
        r = rho[b]
        assert sum(r.values()) == 1 and min(r.values()) >= 0
        assert marg(r, (0, 2, 4)) == marg(pi[b], (1, 0, 2))
        assert marg(r, (1, 2)) == marg(pi[b], (0, 1))
        assert marg(r, (0, 3)) == marg(pi[b], (0, 2))
        assert marg(r, (1, 3)) == marg(r, (1, 4)) == marg(pi[b], (1, 2))
        assert marg(pi[b], (0,)) == marg(pi[b], (1,)) and marg(pi[b], (0, 1)) == marg(pi[b], (1, 0))
        print(f"rho_{'+' if b > 0 else '-'} :", {k: str(v) for k, v in RHO[b].items()})
    print("rho_b >= 0; (a,c,e) ~ (w2,w1,w3), (b,c) ~ (w1,w2), (a,d) ~ (w1,w3), (b,d) ~ (b,e) ~ (w2,w3) under pi_b  [exact]")

    for a, b, c in itertools.product((1, -1), repeat=3):
        lower = 3 + a + b + b * c - abs(a - b) - abs(a * c - 1 - a - b)
        assert lower == min(-R8(a, b, c, d, e) for d in (1, -1) for e in (1, -1))
        assert lower == (2 + 2 * c if a == b == 1 else 0)
    zeros = [u for u in W5 if R8(*u) == 0]
    assert all(R8(*u) <= 0 for u in W5) and all(R8(*u) == 0 for u in W5 if rho[1][u] > 0)
    print(f"8R = -3 - a - b + e - bc - ad + ae + bd + be - ace <= 0 on [-1,1]^5; zero at {len(zeros)} vertices including all atoms "
          "of rho_+  [exact]")

    flipped = tuple(int(2 * h[(w[0], w[1], -w[2])]) for w in W3)
    fl = multilinear({w: h[(w[0], w[1], -w[2])] for w in W3})
    assert flipped in orbit(tuple(A24)) and len({fl[(a,)] for a in range(3)}) == 1
    print("flipping the class {3} gives", flipped, "in the orbit of A24 (one class): rep7 trivial => A24 trivial  [exact]")

    def expectations(nu, F, Fs, k):
        Eh = Fr(0)
        for rows in itertools.product(W3, repeat=k):
            p = Fr(1)
            for i, w in enumerate(rows):
                p *= pi[nu[i]][w]
            if p == 0:
                continue
            y = tuple((F, F, Fs)[j][tuple(w[j] for w in rows)] for j in range(3))
            Eh += p * ext(ch, y)
        ER = Fr(0)
        supp = [u for u in W5 if any(rho[b][u] for b in nu)]
        for rows in itertools.product(supp, repeat=k):
            p = Fr(1)
            for i, u in enumerate(rows):
                p *= rho[nu[i]][u]
            if p == 0:
                continue
            cols = [tuple(u[j] for u in rows) for j in range(5)]
            ER += p * R8(F[cols[0]], F[cols[1]], F[cols[2]], Fs[cols[3]], Fs[cols[4]]) / 8
        return Eh, ER

    worst = None
    count = 0
    for k in (1, 2, 3):
        cube = list(itertools.product((1, -1), repeat=k))
        for nu in itertools.product((1, -1), repeat=k):
            ntr = trials if k < 3 else max(1, trials // 10)
            for t in range(ntr):
                mode = t % 3
                if mode == 0:
                    F = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                    Fs = {z: Fr(rng.randint(-8, 8), 8) for z in cube}
                elif mode == 1:
                    F = {z: Fr(rng.choice((-1, 1))) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1))) for z in cube}
                else:
                    r = rng.randrange(k)
                    F = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                    Fs = {z: Fr(rng.choice((-1, 1)) * z[r]) for z in cube}
                Eh, ER = expectations(nu, F, Fs, k)
                assert Eh == ER <= 0, (k, nu)
                count += 1
                if worst is None or Eh > worst[0]:
                    worst = (Eh, k, nu)
    print(f"{count} random exact tests (k <= 3, every nu): Gamma = E_rho[R] <= 0 in every case; "
          f"largest Gamma = {worst[0]} (k={worst[1]}, nu={worst[2]})")
    print("rep7 trivial: Gamma_nu(F) <= 0 for every k, nu and class-wise decoder  [proof in MAIN_RESULT.tex]")


if __name__ == '__main__':
    main()
