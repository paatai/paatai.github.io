"""Numerical test of the pairwise inequality (*) for the boundary function g0.

For g0, with p_j = (1+y_j)/2 one has 2 h(y) = 3 p1 q2 q3 + q1 p2 p3 - 1 - p1 (q = 1-p), and since the
row laws pi_b are symmetric in columns 2,3,
    2 Gamma_nu(F) = 2E[a] - 6E[ab] + 2E[abc] + E[bc] - 1,   a=P(X), b=P(Y), c=P(Z), P=(1+F)/2.
Using E[abc] <= E[ab] it suffices to prove
    (*)  2E[P(X)] + E[P(Y)P(Z)] - 4E[P(X)P(Y)] <= 1     for all P:{-1,1}^k -> [0,1].
This script maximises the left side minus 1 by exact coordinate ascent (the objective is quadratic in
each value P(z)) from many starts, for given nu, and also reports the true 2*Gamma at the optimum.
"""
import itertools
import sys
from fractions import Fraction as Fr

import numpy as np

H = {(1, 1, 1): -1, (1, 1, -1): -1, (1, -1, 1): -1, (1, -1, -1): Fr(1, 2),
     (-1, 1, 1): 0, (-1, 1, -1): Fr(-1, 2), (-1, -1, 1): Fr(-1, 2), (-1, -1, -1): Fr(-1, 2)}
MU = sum(H.values()) / 8


def pi(b):
    return {w: (1 + b * H[w]) / (8 * (1 + b * MU)) for w in H}


def pair_law(b, j, l):
    """2x2 matrix M[s,t] = Pr_{pi_b}[w_j = s, w_l = t], index 0 <-> +1, 1 <-> -1."""
    M = np.zeros((2, 2))
    for w, p in pi(b).items():
        M[0 if w[j] == 1 else 1, 0 if w[l] == 1 else 1] += float(p)
    return M


def kron_all(mats):
    out = np.ones((1, 1))
    for M in mats:
        out = np.kron(out, M)
    return out


def triple_tensor(nu):
    """joint law of (X,Y,Z) columns as a dict over index triples is too big; return per-row 2x2x2."""
    T = []
    for b in nu:
        A = np.zeros((2, 2, 2))
        for w, p in pi(b).items():
            A[tuple(0 if v == 1 else 1 for v in w)] += float(p)
        T.append(A)
    return T


def gamma2(P, nu):
    """exact 2*Gamma for decoder P (vector over {+,-}^k, index bits 0<->+)."""
    k = len(nu)
    T = triple_tensor(nu)
    J = T[0]
    for A in T[1:]:
        J = np.einsum('abc,def->adbecf', J, A).reshape(J.shape[0] * 2, J.shape[1] * 2, J.shape[2] * 2)
    a = P[:, None, None]
    b = P[None, :, None]
    c = P[None, None, :]
    val = 3 * a * (1 - b) * (1 - c) + (1 - a) * b * c - 1 - a
    return float((J * val).sum())


def ascent(nu, starts, sweeps=200, rng=None):
    k = len(nu)
    M12 = kron_all([pair_law(b, 0, 1) for b in nu])
    M23 = kron_all([pair_law(b, 1, 2) for b in nu])
    marg = M12.sum(axis=1)
    Q = M23 - 4 * M12
    Q = (Q + Q.T) / 2
    lin = 2 * marg

    def obj(P):
        return lin @ P + P @ Q @ P - 1

    best = (-np.inf, None)
    for P in starts:
        P = P.copy()
        for _ in range(sweeps):
            changed = 0.0
            for z in range(2 ** k):
                # objective as function of t = P[z]: Q[z,z] t^2 + (lin[z] + 2 sum_{w!=z} Q[z,w]P[w]) t + const
                qa = Q[z, z]
                qb = lin[z] + 2 * (Q[z] @ P - Q[z, z] * P[z])
                cands = [0.0, 1.0]
                if qa < 0:
                    t = -qb / (2 * qa)
                    if 0 < t < 1:
                        cands.append(t)
                vals = [qa * t * t + qb * t for t in cands]
                t = cands[int(np.argmax(vals))]
                changed = max(changed, abs(t - P[z]))
                P[z] = t
            if changed < 1e-12:
                break
        v = obj(P)
        if v > best[0]:
            best = (v, P.copy())
    return best


def main():
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 6
    nstart = int(sys.argv[2]) if len(sys.argv) > 2 else 30
    rng = np.random.default_rng(1)
    for k in range(1, kmax + 1):
        for npos in range(k, -1, -1):
            nu = [1] * npos + [-1] * (k - npos)
            starts = []
            if npos:
                dic = np.array([1.0 if ((z >> (k - 1)) & 1) == 0 else 0.0 for z in range(2 ** k)])
                starts.append(dic)
            for _ in range(nstart):
                starts.append(rng.random(2 ** k))
                starts.append((rng.random(2 ** k) < rng.random()).astype(float))
            v, P = ascent(nu, starts)
            g2 = gamma2(P, nu) if k <= 7 else float('nan')
            print(f"k={k} nu={''.join('+' if b == 1 else '-' for b in nu)}  max LHS(*)-1 = {v:+.10f}   "
                  f"2*Gamma at argmax = {g2:+.10f}   mean P = {P @ kron_all([pair_law(b,0,1) for b in nu]).sum(axis=1):.4f}",
                  flush=True)
    print("PAIRWISE-FINISHED")


if __name__ == '__main__':
    main()
