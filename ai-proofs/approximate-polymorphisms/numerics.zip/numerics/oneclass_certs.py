"""Exact checks of the one-class coupling certificates for A24 (= the orbit of g1; three columns) and C12 (four columns, two
copies of the row), Remark "one-class designs" in Section 11 of MAIN_RESULT.tex.

For each: the data h, mu, pi_+-, one class; h' >= h with h' = h on supp pi_+; the laws rho_+- on {-1,1}^N are probability
laws with all assigned marginals (columns, pairs, copies) equal to those of pi_+- (for both signs); the coefficients of R,
aggregated over columns / pairs / copies with the same law, equal those of h' (so E[h'(Y)] = E[R(G(U))] for every decoder);
R <= 0 at the vertices (and the displayed identity), R = 0 on supp rho_+; then exact random tests of
Gamma_nu(G) <= E[h'(Y)] = E[R(G(U))] <= 0 for decoders with k <= 3 (all nu), by enumeration of the rows.
usage: python3 oneclass_certs.py [tests_per_nu] [seed]
"""
import itertools
import random
import sys
from fractions import Fraction as Fr

W3 = list(itertools.product((1, -1), repeat=3))


def vec(s, n):
    return tuple(1 if ch == '+' else -1 for ch in s)


def mlin(vals, y):
    """multilinear extension of a function on {-1,1}^n given as dict, at y in [-1,1]^n"""
    out = Fr(0)
    for w, v in vals.items():
        t = v
        for wj, yj in zip(w, y):
            t *= (1 + wj * yj) / 2
        out += t
    return out


def fourier(vals, n):
    return {S: sum(v * eval_chi(S, w) for w, v in vals.items()) / 2 ** n
            for r in range(n + 1) for S in itertools.combinations(range(n), r)}


def eval_chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def check(name, h2, raise_, N, pairs, copies, R16, rho_plus, rho_minus, nlaws_note):
    print(f"== {name}")
    h = {w: Fr(v, 2) for w, v in zip(W3, h2)}
    mu = sum(h.values()) / 8
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    hh = fourier(h, 3)
    assert len({hh[(j,)] for j in range(3)}) == 1, "one class"
    hp = dict(h)
    for w, t in raise_.items():
        hp[vec(w, 3)] += t
    assert all(hp[w] >= h[w] for w in W3) and all(hp[w] == h[w] for w in W3 if pi[1][w] > 0)
    hhp = fourier(hp, 3)
    print(f"  mu = {mu}, pi_+ = {[str(pi[1][w]) for w in W3]}, pi_- = {[str(pi[-1][w]) for w in W3]}")
    print(f"  h' Fourier: {[(S, str(c)) for S, c in hhp.items() if c]}")
    rho = {1: {vec(k, N): Fr(v) for k, v in rho_plus.items()}, -1: {vec(k, N): Fr(v) for k, v in rho_minus.items()}}
    U = list(itertools.product((1, -1), repeat=N))
    for b in (1, -1):
        for u in U:
            rho[b].setdefault(u, Fr(0))
        assert all(p >= 0 for p in rho[b].values()) and sum(rho[b].values()) == 1
        for a in range(N):
            assert sum(p for u, p in rho[b].items() if u[a] == 1) == sum(p for w, p in pi[b].items() if w[0] == 1)
        for (a, c), (j, k) in pairs.items():
            for x, y in itertools.product((1, -1), repeat=2):
                assert sum(p for u, p in rho[b].items() if (u[a], u[c]) == (x, y)) == \
                    sum(p for w, p in pi[b].items() if (w[j], w[k]) == (x, y)), (name, b, a, c)
        for cols, roles in copies:
            for v in itertools.product((1, -1), repeat=3):
                lhs = sum(p for u, p in rho[b].items() if tuple(u[a] for a in cols) == v)
                w = [0, 0, 0]
                for a_idx, r in enumerate(roles):
                    w[r] = v[a_idx]
                assert lhs == pi[b][tuple(w)], (name, b, cols)
    print("  rho_+- are probability laws with the assigned column, pair and copy marginals of pi_+- (both signs)")
    # coefficient matching, aggregated by laws
    R = {tuple(sorted(S)): Fr(c, 16) for S, c in R16.items()}
    for S in R:
        assert len(S) <= 1 or (len(S) == 2 and S in pairs) or \
            (len(S) == 3 and any(tuple(sorted(cols)) == S for cols, _ in copies)), S
    assert R.get((), 0) == hhp[()]
    assert sum(R.get((a,), 0) for a in range(N)) == sum(hhp[(j,)] for j in range(3))
    lawkey = {}
    for jk in [(0, 1), (0, 2), (1, 2)]:
        key = tuple(sum(p for w, p in pi[b].items() if w[jk[0]] == 1 and w[jk[1]] == 1) for b in (1, -1))
        lawkey.setdefault(key, []).append(jk)
    for key, jks in lawkey.items():
        lhs = sum(R.get(pr, 0) for pr, jk in pairs.items() if tuple(sorted(jk)) in jks)
        assert lhs == sum(hhp[jk] for jk in jks), (key, lhs)
    assert sum(R.get(tuple(sorted(cols)), 0) for cols, _ in copies) == hhp[(0, 1, 2)]
    print(f"  coefficients of R aggregated by law equal those of h' ({nlaws_note})")
    Rv = {u: sum(c * eval_chi(S, u) for S, c in R.items()) for u in U}
    assert all(v <= 0 for v in Rv.values())
    assert all(Rv[u] == 0 for u, p in rho[1].items() if p > 0)
    print(f"  R <= 0 at all {len(U)} vertices; max R = {max(Rv.values())}; R = 0 on supp rho_+ "
          f"({sum(1 for p in rho[1].values() if p > 0)} points); zeros of R: {sum(1 for v in Rv.values() if v == 0)}")
    return h, hp, pi, rho, R, N


def exact_tests(data, ntests, rng):
    h, hp, pi, rho, R, N = data
    worst = None
    for k in range(1, 4):
        Z = list(itertools.product((1, -1), repeat=k))
        for nu in itertools.product((1, -1), repeat=k):
            for _ in range(ntests):
                mode = rng.random()
                if mode < 0.3:
                    G = {z: Fr(rng.choice((-1, 1))) for z in Z}
                else:
                    G = {z: Fr(rng.randint(-7, 7), 7) for z in Z}
                gam = hpe = Fr(0)
                for rows in itertools.product(W3, repeat=k):
                    p = Fr(1)
                    for i, w in enumerate(rows):
                        p *= pi[nu[i]][w]
                    if p == 0:
                        continue
                    y = [G[tuple(rows[i][j] for i in range(k))] for j in range(3)]
                    gam += p * mlin(h, y)
                    hpe += p * mlin(hp, y)
                ER = Fr(0)
                Uall = list(itertools.product((1, -1), repeat=N))
                for rows in itertools.product(Uall, repeat=k):
                    p = Fr(1)
                    for i, u in enumerate(rows):
                        p *= rho[nu[i]][u]
                    if p == 0:
                        continue
                    y = [G[tuple(rows[i][a] for i in range(k))] for a in range(N)]
                    ER += p * sum(c * _prod(y, S) for S, c in R.items())
                assert gam <= hpe == ER <= 0, (k, nu, gam, hpe, ER)
                worst = ER if worst is None else max(worst, ER)
    return worst


def _prod(y, S):
    out = Fr(1)
    for a in S:
        out *= y[a]
    return out


def main():
    ntests = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    # A24 (orbit of g1): h' = h raised by 1 at ++-; columns U0, U1, U2 with (U0,U1) ~ (w1,w2), (U0,U2) ~ (U1,U2) ~ (w1,w3);
    # 4R = -1 - y0 y1 - (y0 + y1)(1 + y2)/2,  -16R = (1+y0)(1+y1)(3+y2) + (1-y0)(1-y1)(1-y2).
    A24 = check('A24 (g1)', [-2, -2, -1, 1, 0, 0, -1, -1], {'++-': 1}, 3,
                {(0, 1): (0, 1), (0, 2): (0, 2), (1, 2): (0, 2)}, [],
                {(): -4, (0,): -2, (1,): -2, (0, 1): -4, (0, 2): -2, (1, 2): -2},
                {'+-+': Fr(1, 10), '+--': Fr(3, 10), '-++': Fr(1, 10), '-+-': Fr(3, 10), '--+': Fr(1, 5)},
                {'+++': Fr(4, 22), '++-': Fr(4, 22), '+-+': Fr(3, 22), '+--': Fr(1, 22), '-++': Fr(3, 22), '-+-': Fr(1, 22),
                 '--+': Fr(2, 22), '---': Fr(4, 22)},
                'L12 on (0,1); L13 on (0,2), (1,2); L23 unused, h^(23) = 0; no cubic term')
    y = list(itertools.product((1, -1), repeat=3))
    for u in y:
        lhs = -16 * sum(c * eval_chi(S, u) for S, c in A24[4].items())
        rhs = (1 + u[0]) * (1 + u[1]) * (3 + u[2]) + (1 - u[0]) * (1 - u[1]) * (1 - u[2])
        assert lhs == rhs
    print("  identity -16R = (1+y0)(1+y1)(3+y2) + (1-y0)(1-y1)(1-y2) holds at the vertices (both sides multilinear)")
    print(f"  exact random tests: largest E[R] = {exact_tests(A24, ntests, rng)}")
    # C12: h' = h; columns U0..U3; copies (U0,U1,U2) ~ (w1,w2,w3) and (U3,U1,U2) ~ (w1,w2,w3); (U0,U3) ~ (w2,w3);
    # 16R = -6 - 3s - st - 2q + 4p + 3sp with s = y0+y3, t = y1+y2, p = y1y2, q = y0y3.
    rp = {'+--+': Fr(1, 5), '-+--': Fr(1, 5), '--+-': Fr(1, 5), '+++-': Fr(1, 10), '-+++': Fr(1, 10), '+---': Fr(1, 10),
          '---+': Fr(1, 10)}
    rm = {}
    for u in itertools.product('+-', repeat=4):
        s = ''.join(u)
        rm[s] = (1 - 5 * rp.get(s, Fr(0))) / 11
    C12 = check('C12', [-1, -2, -2, 1, -1, 0, 0, -1], {}, 4,
                {(0, 1): (0, 1), (0, 2): (0, 2), (1, 3): (1, 0), (2, 3): (2, 0), (0, 3): (1, 2), (1, 2): (1, 2)},
                [((0, 1, 2), (0, 1, 2)), ((3, 1, 2), (0, 1, 2))],
                {(): -6, (0,): -3, (3,): -3, (0, 1): -1, (0, 2): -1, (1, 3): -1, (2, 3): -1, (0, 3): -2, (1, 2): 4,
                 (0, 1, 2): 3, (1, 2, 3): 3},
                rp, rm, 'L1 = law of (w1,w2) = law of (w1,w3) on (0,1),(0,2),(1,3),(2,3); L2 = law of (w2,w3) on (0,3),(1,2)')
    print("  rho_- = (1 - 5 rho_+)/11 (complement construction)")
    print(f"  exact random tests: largest E[R] = {exact_tests(C12, ntests, rng)}")


if __name__ == '__main__':
    main()
