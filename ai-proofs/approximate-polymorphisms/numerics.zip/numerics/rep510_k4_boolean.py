"""rep5 and rep10, k = 4: exact check of the one-function forms (rep5ex), (rep10ex) for every {0,1}-valued P.

For every nu in {-1,1}^4 (up to the order of the labels) and every P: {-1,1}^4 -> {0,1} (all 2^16 of them), computes
D*LHS and D*RHS of (rep5ex) / (rep10ex) (Section 11, paragraph "Exact forms for rep5 and rep10"), where D is the product of
the denominators of the row laws, so that D*Pr[X1=z1, X2=z2, X3=z3] is an integer for every (z1, z2, z3). All quantities and
partial sums are then integers of modulus at most 7D < 2^53, so the float64 matrix products below are exact. By the exact forms,
LHS - RHS = 2 max_{F_s} Gamma_nu(F_p, F_s) with F_p = 2P - 1, so LHS <= RHS for all these P says: Gamma_nu <= 0 for every
class-wise decoder with k = 4, {-1,1}-valued F_p and [-1,1]-valued F_s. Prints, per nu, the maximum of LHS - RHS and the number of
P attaining it, and cross-checks random P against rep510_exact.sides (Fractions).
usage: python3 rep510_k4_boolean.py [ncross] [seed]
"""
import random
import sys
from fractions import Fraction as Fr
from math import lcm

import numpy as np

from rep510_exact import REPS, columns, cube, setup, sides

K = 4


def tables(pi, nu):
    den = {b: lcm(*[q.denominator for q in pi[b].values()]) for b in (1, -1)}
    D = 1
    for b in nu:
        D *= den[b]
    pts = cube(K)
    idx = {z: i for i, z in enumerate(pts)}
    T = np.zeros((2 ** K,) * 3)
    J = columns(pi, nu)
    for (z1, z2, z3), p in J.items():
        v = p * D
        assert v.denominator == 1
        T[idx[z1], idx[z2], idx[z3]] = v.numerator
    assert T.sum() == D
    return D, T, J, pts


def all_sides(name, T):
    n = T.shape[0]
    P = ((np.arange(2 ** n)[:, None] >> np.arange(n)) & 1).astype(np.float64)
    M12, M13, M23 = T.sum(2), T.sum(1), T.sum(0)
    m1, m3 = T.sum((1, 2)), T.sum((0, 1))
    A = (P @ T.reshape(n, n * n)).reshape(-1, n, n)
    C = np.einsum("pi,pij->pj", P, A)
    Q13, Q23 = P @ M13, P @ M23
    E12 = np.einsum("pi,pi->p", P @ M12, P)
    if name == "rep5":
        S, rhs = 2 * Q13 - m3 - 2 * Q23 + 2 * C, 2 * E12
    else:
        S, rhs = Q13 + 3 * Q23 - 2 * C - m3, P @ m1 + E12
    lhs = np.maximum(S, 0).sum(1)
    for arr in (lhs, rhs):
        assert np.all(arr == np.round(arr)) and np.abs(arr).max() < 2 ** 50
    return lhs, rhs


def classify(p, pts):
    """Name a {0,1}-valued P (bit i of p is P(pts[i])) if it is 0, a dictator, a negated dictator or an AND of two labels."""
    supp = {z for i, z in enumerate(pts) if (p >> i) & 1}
    names = {frozenset(): "0"}
    for r in range(K):
        names[frozenset(z for z in pts if z[r] == 1)] = f"z{r + 1}=1"
        names[frozenset(z for z in pts if z[r] == -1)] = f"z{r + 1}=-1"
        for s in range(r + 1, K):
            names[frozenset(z for z in pts if z[r] == z[s] == 1)] = f"z{r + 1}=z{s + 1}=1"
    return names.get(frozenset(supp), f"other{sorted(supp)}")


def main():
    ncross = int(sys.argv[1]) if len(sys.argv) > 1 else 20
    rng = random.Random(int(sys.argv[2]) if len(sys.argv) > 2 else 1)
    overall = {}
    for name, h2 in REPS.items():
        _, _, pi = setup(h2)
        worst = None
        for npos in range(K, -1, -1):
            nu = (1,) * npos + (-1,) * (K - npos)
            D, T, J, pts = tables(pi, nu)
            lhs, rhs = all_sides(name, T)
            diff = lhs - rhs
            mx = diff.max()
            n_at = int((diff == mx).sum())
            n_eq = int((diff == 0).sum())
            second = diff[diff < 0].max()
            print(f"{name} nu=(+{npos},-{K - npos}): D = {D}; max (LHS - RHS) = {Fr(int(mx), D)} at {n_at} of {len(diff)} P; "
                  f"LHS = RHS for {n_eq} P; largest negative value {float(second) / D:.6g}", flush=True)
            print(f"   equality cases: {', '.join(classify(int(q), pts) for q in np.flatnonzero(diff == 0))}", flush=True)
            for _ in range(ncross):
                p = rng.randrange(2 ** (2 ** K))
                P = {z: Fr((p >> i) & 1) for i, z in enumerate(pts)}
                l, r = sides(name, J, P)
                assert l * D == int(lhs[p]) and r * D == int(rhs[p]), (name, nu, p)
            worst = Fr(int(mx), D) if worst is None else max(worst, Fr(int(mx), D))
        overall[name] = worst
        print(f"ok: {name}: LHS <= RHS for every {{0,1}}-valued P with k = 4 and every nu (max LHS - RHS = {worst}); "
              f"{ncross} cross-checks per nu against rep510_exact.sides (Fractions) agree", flush=True)
    assert all(v <= 0 for v in overall.values())


if __name__ == "__main__":
    main()
