"""Exact maximum of Gamma_nu(F) over all continuous decoders F : {+-1}^k -> [-1,1] (k = 1, 2, optionally 3) for one-class
h = (x, z, z, y) on {+-1}^2, in rational arithmetic.

Gamma_nu(F) = alpha + beta * sum_z (m_1(z) + m_2(z)) F(z) + b * sum_{z,z'} Pr[C_1 = z, C_2 = z'] F(z) F(z'), a quadratic in
the 2^k values.  Its maximum over the cube is attained at a critical point of the restriction to the relative interior of
some face (faces with a singular Hessian block attain their maximum on their relative boundary, since the quadratic is
affine along a kernel direction).  All critical points are rational; we enumerate the 3^(2^k) faces.
usage: python3 j2_k2_exact.py kmax "x z y" ["x z y" ...]
"""
import itertools
import sys
from fractions import Fraction as Fr

W2 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def laws(hv):
    mu = sum(hv) / 4
    return {b: [(1 + b * hv[i]) / (4 * (1 + b * mu)) for i in range(4)] for b in (1, -1)}


def quad_form(hv, nu):
    """Gamma = c0 + lin . F + F^T Q F (Q symmetric)."""
    x, z, _, y = hv
    # h(s,t) = al + be (s + t) + b s t
    al = (x + 2 * z + y) / 4
    be = (x - y) / 4
    b = (x - 2 * z + y) / 4
    pi = laws(hv)
    k = len(nu)
    n = 2 ** k
    lin = [Fr(0)] * n
    Q = [[Fr(0)] * n for _ in range(n)]
    for rows in itertools.product(range(4), repeat=k):
        p = Fr(1)
        for i in range(k):
            p *= pi[nu[i]][rows[i]]
        if p == 0:
            continue
        c = [0, 0]
        for j in range(2):
            for i in range(k):
                c[j] = 2 * c[j] + (W2[rows[i]][j] == -1)
        lin[c[0]] += p * be
        lin[c[1]] += p * be
        Q[c[0]][c[1]] += p * b / 2
        Q[c[1]][c[0]] += p * b / 2
    return al, lin, Q


def value(c0, lin, Q, F):
    n = len(F)
    return c0 + sum(lin[i] * F[i] for i in range(n)) + sum(Q[i][j] * F[i] * F[j] for i in range(n) for j in range(n))


def solve(M, v):
    """Gaussian elimination over Q; returns None if singular."""
    n = len(M)
    A = [row[:] + [v[i]] for i, row in enumerate(M)]
    for col in range(n):
        piv = next((r for r in range(col, n) if A[r][col] != 0), None)
        if piv is None:
            return None
        A[col], A[piv] = A[piv], A[col]
        for r in range(n):
            if r != col and A[r][col] != 0:
                f = A[r][col] / A[col][col]
                A[r] = [A[r][i] - f * A[col][i] for i in range(n + 1)]
    return [A[i][n] / A[i][i] for i in range(n)]


def cube_max(c0, lin, Q):
    n = len(lin)
    best = None
    for face in itertools.product((-1, 0, 1), repeat=n):
        free = [i for i in range(n) if face[i] == 0]
        F = [Fr(face[i]) for i in range(n)]
        if free:
            # gradient wrt free coords: lin_i + 2 sum_j Q_ij F_j = 0
            M = [[2 * Q[i][j] for j in free] for i in free]
            rhs = [-(lin[i] + 2 * sum(Q[i][j] * F[j] for j in range(n) if j not in free)) for i in free]
            sol = solve(M, rhs)
            if sol is None:
                continue
            if any(not (-1 < s < 1) for s in sol):
                continue
            for i, s in zip(free, sol):
                F[i] = s
        val = value(c0, lin, Q, F)
        if best is None or val > best[0]:
            best = (val, F)
    return best


if __name__ == '__main__':
    kmax = int(sys.argv[1])
    for spec in sys.argv[2:]:
        xs, zs, ys = spec.split()
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        print(f"h = ({xs}, {zs}, {zs}, {ys}):", flush=True)
        for k in range(1, kmax + 1):
            for npos in range(k, -1, -1):
                nu = tuple([1] * npos + [-1] * (k - npos))
                c0, lin, Q = quad_form(hv, nu)
                val, F = cube_max(c0, lin, Q)
                print(f"  k={k} nu={''.join('+' if v > 0 else '-' for v in nu)}: max Gamma = {val} ({float(val):+.4e}) "
                      f"at F = {[str(v) for v in F]}", flush=True)
