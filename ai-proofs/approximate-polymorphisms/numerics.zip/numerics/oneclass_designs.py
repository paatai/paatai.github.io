"""Search for coupling-design certificates for the one-class boundary orbits (m = 5), in particular B12.  Floating-point
linear programming (scipy/HiGHS); positive results must be re-proved exactly, negative results are numerical.

For a one-class h all three coordinates share one decoder G, all coordinates have the same law under pi_b, and every pair law
of pi_b is exchangeable.  A design on N columns assigns to every pair of columns either nothing ('free') or one of the
distinct pair laws of pi_b, and to every triple of columns whose three pairs carry the pair laws induced by some placement of
the coordinates (1,2,3) either nothing or the full row law in that placement (a 'copy').  Certificate: h' >= h on {-1,1}^3,
h' = h on supp pi_+, a multilinear R on {-1,1}^N with monomials on the constant, the columns, the assigned pairs and the copies,
R <= 0 at the vertices, with aggregated coefficients
    R_0 = h'^(0),   sum_a R_a = sum_j h'^({j}),   sum over pairs carrying law L of R_ac = sum over {j,k} with law L of h'^({j,k}),
    sum over copies of R_ace = h'^({1,2,3}),
and laws rho_b on {-1,1}^N (b = +-1) with all assigned marginals.  Then, with U a k x N matrix with independent rows
~ rho_{nu_i}, Gamma_nu(G) <= E[h'(Y)] = E[R(G(U_1), ..., G(U_N))] <= 0 for all k, nu, G.
Designs are enumerated up to permutations of the columns (N <= 5 by brute force).
usage: python3 oneclass_designs.py NAMES NS [workers]      e.g. python3 oneclass_designs.py B12,C12,A12,A24,D12 3,4,5 8
"""
import itertools
import sys
from fractions import Fraction as Fr
from multiprocessing import Pool

import numpy as np
from scipy.optimize import linprog

W3 = list(itertools.product((1, -1), repeat=3))
ONE = {
    'A12': [-2, -2, -2, 1, 0, -1, -1, -1],
    'A24': [-2, -2, -1, 1, 0, 0, -1, -1],
    'D12': [-1, -2, -2, 1, 0, -1, -1, 0],
    'B12': [-2, -1, -1, 1, 0, 0, 0, -1],
    'C12': [-1, -2, -2, 1, -1, 0, 0, -1],
}
P3 = [(0, 1), (0, 2), (1, 2)]
STATE = {}


def chi(S, w):
    out = 1
    for a in S:
        out *= w[a]
    return out


def setup(name):
    h = {w: Fr(v, 2) for w, v in zip(W3, ONE[name])}
    mu = sum(h.values()) / 8
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    lvl1 = [sum(h[w] * w[a] for w in W3) / 8 for a in range(3)]
    assert len(set(lvl1)) == 1, name
    m1 = tuple(sum(p for w, p in pi[b].items() if w[0] == 1) for b in (1, -1))
    pp = {jk: tuple(sum(p for w, p in pi[b].items() if w[jk[0]] == 1 and w[jk[1]] == 1) for b in (1, -1)) for jk in P3}
    laws = sorted(set(pp.values()))
    law_of = {jk: laws.index(pp[jk]) + 1 for jk in P3}
    placements = {}
    for sg in itertools.permutations(range(3)):
        induced = (law_of[tuple(sorted((sg[0], sg[1])))], law_of[tuple(sorted((sg[0], sg[2])))],
                   law_of[tuple(sorted((sg[1], sg[2])))])
        tl = {}
        for b in (1, -1):
            for u in itertools.product((1, -1), repeat=3):
                w = [0, 0, 0]
                w[sg[0]], w[sg[1]], w[sg[2]] = u
                tl[(b, u)] = pi[b][tuple(w)]
        key = tuple(sorted(tl.items()))
        placements.setdefault(induced, {})[key] = tl
    supp = [w for w in W3 if pi[1][w] > 0]
    free = [w for w in W3 if w not in supp]
    return dict(h=h, mu=mu, pi=pi, m1=m1, laws=laws, law_of=law_of, placements=placements, supp=supp, free=free)


def R_feasible(N, assign, copies, st):
    h, supp, free, law_of, laws = st['h'], st['supp'], st['free'], st['law_of'], st['laws']
    pairs = list(itertools.combinations(range(N), 2))
    nh, nt = len(free), len(copies)
    nv = nh + 1 + N + len(pairs) + nt
    o0, oa, oac, ot = nh, nh + 1, nh + 1 + N, nh + 1 + N + len(pairs)

    def hcoef(S):
        row = np.zeros(nv)
        for t, w in enumerate(free):
            row[t] = chi(S, w) / 8
        return float(sum(h[w] * chi(S, w) for w in supp)) / 8, row

    A_eq, b_eq = [], []

    def equate(Ss, cols):
        c, r = 0.0, np.zeros(nv)
        for S in Ss:
            c1, r1 = hcoef(S)
            c, r = c + c1, r + r1
        row = -r
        for k in cols:
            row[k] += 1
        A_eq.append(row)
        b_eq.append(c)

    equate([(0, 1, 2)], [ot + t for t in range(nt)])
    equate([()], [o0])
    equate([(0,), (1,), (2,)], [oa + a for a in range(N)])
    for L in range(1, len(laws) + 1):
        equate([jk for jk in P3 if law_of[jk] == L], [oac + t for t, pr in enumerate(pairs) if assign[pr] == L])
    for t, pr in enumerate(pairs):
        if assign[pr] == 0:
            row = np.zeros(nv)
            row[oac + t] = 1
            A_eq.append(row)
            b_eq.append(0.0)
    A_ub = []
    for u in itertools.product((1, -1), repeat=N):
        row = np.zeros(nv)
        row[o0] = 1
        for a in range(N):
            row[oa + a] = u[a]
        for t, (a, c) in enumerate(pairs):
            row[oac + t] = u[a] * u[c]
        for t, (a, c, e, _) in enumerate(copies):
            row[ot + t] = u[a] * u[c] * u[e]
        A_ub.append(row)
    bounds = [(float(h[w]), None) for w in free] + [(None, None)] * (nv - nh)
    res = linprog(np.zeros(nv), A_ub=np.array(A_ub), b_ub=np.zeros(len(A_ub)), A_eq=np.array(A_eq), b_eq=np.array(b_eq),
                  bounds=bounds, method='highs')
    return res.status == 0, (res.x if res.status == 0 else None)


def rho_feasible(N, assign, copies, st):
    Uarr = np.array(list(itertools.product((1, -1), repeat=N)))
    for bi, b in enumerate((1, -1)):
        A, rhs = [np.ones(len(Uarr))], [1.0]
        for a in range(N):
            A.append((Uarr[:, a] == 1).astype(float))
            rhs.append(float(st['m1'][bi]))
        for (a, c), L in assign.items():
            if L:
                A.append(((Uarr[:, a] == 1) & (Uarr[:, c] == 1)).astype(float))
                rhs.append(float(st['laws'][L - 1][bi]))
        for (a, c, e, tl) in copies:
            for u in itertools.product((1, -1), repeat=3):
                if u == (-1, -1, -1):
                    continue
                A.append(((Uarr[:, a] == u[0]) & (Uarr[:, c] == u[1]) & (Uarr[:, e] == u[2])).astype(float))
                rhs.append(float(tl[(b, u)]))
        res = linprog(np.zeros(len(Uarr)), A_eq=np.array(A), b_eq=np.array(rhs), bounds=[(0, None)] * len(Uarr), method='highs')
        if res.status != 0:
            return False
    return True


def eligible_copies(N, assign, st):
    out = []
    for a, c, e in itertools.combinations(range(N), 3):
        induced = (assign[(a, c)], assign[(a, e)], assign[(c, e)])
        if 0 in induced:
            continue
        for tl in st['placements'].get(induced, {}).values():
            out.append((a, c, e, tl))
    return out


def canonical_designs(N, nlaws):
    pairs = list(itertools.combinations(range(N), 2))
    grid = np.array(list(itertools.product(range(nlaws + 1), repeat=len(pairs))), dtype=np.int64)
    pos = {pr: t for t, pr in enumerate(pairs)}
    weights = (nlaws + 1) ** np.arange(len(pairs))[::-1]
    enc = grid @ weights
    best = enc.copy()
    for pm in itertools.permutations(range(N)):
        perm = [pos[tuple(sorted((pm[a], pm[c])))] for a, c in pairs]
        permuted = np.empty_like(grid)
        permuted[:, perm] = grid
        best = np.minimum(best, permuted @ weights)
    keep = grid[enc == best]
    return [{pr: int(row[t]) for t, pr in enumerate(pairs)} for row in keep]


def work(args):
    name, N, assign = args
    st = STATE[name]
    el = eligible_copies(N, assign, st)
    ok, _ = R_feasible(N, assign, el, st)
    if not ok:
        return None
    for r in range(0, len(el) + 1):
        for copies in itertools.combinations(el, r):
            ok, x = R_feasible(N, assign, list(copies), st)
            if ok and rho_feasible(N, assign, list(copies), st):
                return name, N, {k: v for k, v in assign.items() if v}, [c[:3] for c in copies], \
                    [round(float(t), 4) for t in x[:len(st['free'])]]
    return None


def init(names):
    for name in names:
        STATE[name] = setup(name)


def main():
    names = sys.argv[1].split(',')
    Ns = [int(x) for x in sys.argv[2].split(',')]
    workers = int(sys.argv[3]) if len(sys.argv) > 3 else 1
    init(names)
    for name in names:
        st = STATE[name]
        print(f"{name}: mu = {st['mu']}, free vertices {st['free']}, distinct pair laws "
              f"{[[str(x) for x in L] for L in st['laws']]} (P(++) for b=+1,-1), law of pairs 12,13,23: "
              f"{[st['law_of'][jk] for jk in P3]}", flush=True)
    with Pool(workers, initializer=init, initargs=(names,)) as pool:
        for N in Ns:
            for name in names:
                des = canonical_designs(N, len(STATE[name]['laws']))
                found = 0
                for res in pool.imap_unordered(work, [(name, N, a) for a in des], chunksize=16):
                    if res is not None:
                        found += 1
                        if found <= 3:
                            print(f"  {res[0]} N={res[1]}: certificate, assigned {res[2]}, copies {res[3]}, h' at free "
                                  f"vertices {res[4]}", flush=True)
                print(f"{name} N={N}: {len(des)} designs up to symmetry, {found} with a certificate", flush=True)


if __name__ == '__main__':
    main()
