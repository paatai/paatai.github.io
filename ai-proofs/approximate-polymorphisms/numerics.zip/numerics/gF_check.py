"""Exact checks for the explicit function g_F on 6 variables: Proposition 10.3 (prop:gF) in Section 10 (Section 10.1;
Theorem F, |J| = 2).

g_F(w_1, w_2, u_1, ..., u_4) = +1 iff u in A_w, with s = u_1 + u_2 + u_3 + u_4 and
  A_{++} = {u_1 = u_2, u_3 = u_4},  A_{+-} = {s in {4, 2, -2}},  A_{-+} = {s in {2, -2, -4}},  A_{--} = {s = 0}.
Checks (exact, Fractions / sympy) of every number in the proof of Proposition 10.3: the sizes |A_w|, the Fourier data
(mu = -1/8, level-one coefficients -1/16 on w and 0 on u together with the symmetry argument, hhat({1,2}) = -1/4,
J = {w_1, w_2}, one class), the hypotheses of Theorem B with the displayed witnesses of dependence, h, sigma = -1,
triv = 9/16, sigma h(+-) = -1/8 < 0 (so s^U_g > triv), the row laws pi_+-, E w_j = -1/14 and 1/18,
E[w_1 w_2] = -2/7 (pi_+) and 2/9 (pi_-), the correlations -19/65 (pi_+) and 71/323 (pi_-) with their displayed
numerators and denominators, rho_12 = 19/65, h(t,t), Phi(t,t) = 27/520 + t/8 + (21/65) t^2 with discriminant
-13919/270400 and minimum 13919/349440 (so s_g = triv = 9/16 by Theorem F); the extensions of Corollary F' (m = 7, 8);
the remark after the proof (dictator: sigma Gamma_+ = -(mu + ||h||^2)/(1 + mu) = 5/112, ||h||^2 = 11/128); and a
brute-force test of sigma Gamma_nu(F) >= 13919/349440 (exact for decoders with values in {-1,0,1} and k <= 2 and with
values in {-1,1} and k = 3; floating point for random [-1,1]-valued decoders with k <= 4).
"""
import itertools
from fractions import Fraction as Fr
from math import prod

import numpy as np
import sympy as sp

U = list(itertools.product([1, -1], repeat=4))
W = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def inA(w, u):
    s = sum(u)
    if w == (1, 1):
        return u[0] == u[1] and u[2] == u[3]
    if w == (1, -1):
        return s in (4, 2, -2)
    if w == (-1, 1):
        return s in (2, -2, -4)
    return s == 0


def g(x):
    return 1 if inA((x[0], x[1]), x[2:]) else -1


X = list(itertools.product([1, -1], repeat=6))
ghat = {S: Fr(sum(g(x) * prod(x[i] for i in S) for x in X), 64)
        for r in range(7) for S in itertools.combinations(range(6), r)}
mu = ghat[()]
J = [i for i in range(6) if ghat[(i,)] != 0]
print("mu =", mu, " level one:", [str(ghat[(i,)]) for i in range(6)], " J =", J)
assert mu == Fr(-1, 8) and J == [0, 1] and ghat[(0,)] == ghat[(1,)] == Fr(-1, 16)
for i in range(6):
    assert any(g(x) != g(tuple(-x[j] if j == i else x[j] for j in range(6))) for x in X), i
nonzero = [S for S, c in ghat.items() if c != 0]
assert not (len(nonzero) == 1 and len(nonzero[0]) == 6)
Aset = {w: [u for u in U if inA(w, u)] for w in W}
assert [len(Aset[w]) for w in W] == [4, 9, 9, 6]
assert all(len([u for u in Aset[w] if sum(u) == s]) == c for w, s, c in
           [((1, -1), 4, 1), ((1, -1), 2, 4), ((1, -1), -2, 4), ((-1, 1), 2, 4), ((-1, 1), -2, 4), ((-1, 1), -4, 1)])
for i in range(4):  # ghat({u_i}) = 2^-6 sum_w sum_u g u_i = 2^-5 sum_w sum_{u in A_w} u_i = 0
    assert Fr(sum(sum(u[i] for u in Aset[w]) for w in W), 32) == ghat[(2 + i,)] == 0
neg = lambda us: sorted(tuple(-t for t in u) for u in us)
assert neg(Aset[(1, 1)]) == sorted(Aset[(1, 1)]) and neg(Aset[(-1, -1)]) == sorted(Aset[(-1, -1)])
assert neg(Aset[(1, -1)]) == sorted(Aset[(-1, 1)])  # A_{-+} = -A_{+-}
one4 = (1, 1, 1, 1)
assert inA((1, 1), one4) and not inA((-1, 1), one4)  # dependence on w_1
assert inA((1, 1), tuple(-t for t in one4)) and not inA((1, -1), tuple(-t for t in one4))  # dependence on w_2
for u in Aset[(-1, -1)]:  # dependence on u_i: flipping u_i leaves A_{--}
    assert all(not inA((-1, -1), tuple(-u[j] if j == i else u[j] for j in range(4))) for i in range(4))
print("g_F depends on all 6 coordinates, is not +-parity, mu != 0: hypotheses of Theorem B hold.")
print("|A_w| = 4, 9, 9, 6; u-coefficients vanish (A_{++}, A_{--} symmetric under u -> -u, A_{-+} = -A_{+-})  [EXACT]")

h = {w: Fr(sum(g(w + u) for u in U), 16) for w in W}
print("h(++, +-, -+, --) =", [str(h[w]) for w in W])
assert [h[w] for w in W] == [Fr(-1, 2), Fr(1, 8), Fr(1, 8), Fr(-1, 4)]
assert all(h[w] == Fr(2 * len(Aset[w]), 16) - 1 for w in W)
b = sum(h[w] * w[0] * w[1] for w in W) / 4
a = sum(h[w] * w[0] for w in W) / 4
assert b == Fr(-1, 4) and a == Fr(-1, 16)
assert a == sum(h[w] * w[1] for w in W) / 4 == Fr(1, 4) * (Fr(-1, 2) + Fr(1, 8) - Fr(1, 8) + Fr(1, 4))
assert b == Fr(1, 4) * (Fr(-1, 2) - Fr(1, 8) - Fr(1, 8) - Fr(1, 4))
sigma = 1 if mu > 0 else -1
assert sigma == -1 and Fr(1, 2) + abs(mu) / 2 == Fr(9, 16) and sigma * h[(1, -1)] == Fr(-1, 8) < 0
print("h(y) = -1/8 - (y1 + y2)/16 - y1 y2 / 4;  sigma = -1, triv = 9/16, sigma h(+-) = -1/8 < 0 (so s^U > triv)")

for m in (7, 8):  # Corollary F': g(w, u_1, ..., u_{m-2}) = g_F(w, u_1, u_2, u_3, u_4 ... u_{m-2})
    Xm = list(itertools.product([1, -1], repeat=m))
    gm = {x: g(x[:5] + (prod(x[5:]),)) for x in Xm}
    assert Fr(sum(gm.values()), 2 ** m) == mu
    assert {w: Fr(sum(gm[w + u] for u in itertools.product([1, -1], repeat=m - 2)), 2 ** (m - 2)) for w in W} == h
    assert [Fr(sum(gm[x] * x[i] for x in Xm), 2 ** m) for i in range(m)] == [Fr(-1, 16)] * 2 + [Fr(0)] * (m - 2)
    assert all(any(gm[x] != gm[x[:i] + (-x[i],) + x[i + 1:]] for x in Xm) for i in range(m))
print("Corollary F' extensions, m = 7, 8: same mu, h and level-one coefficients, depend on all coordinates  [EXACT]")

PI = {1: [Fr(1, 7), Fr(9, 28), Fr(9, 28), Fr(3, 14)], -1: [Fr(1, 3), Fr(7, 36), Fr(7, 36), Fr(5, 18)]}
EW = {1: Fr(-1, 14), -1: Fr(1, 18)}
EWW = {1: Fr(-2, 7), -1: Fr(2, 9)}
CORR = {1: (Fr(-2, 7) - Fr(1, 196)) / (1 - Fr(1, 196)), -1: (Fr(2, 9) - Fr(1, 324)) / (1 - Fr(1, 324))}
assert CORR[1] == Fr(-19, 65) and CORR[-1] == Fr(71, 323)
rho = Fr(0)
for nu in (1, -1):
    pi = {w: (1 + nu * h[w]) / (4 * (1 + nu * mu)) for w in W}
    e = sum(pi[w] * w[0] for w in W)
    assert e == sum(pi[w] * w[1] for w in W)
    e12 = sum(pi[w] * w[0] * w[1] for w in W)
    corr = (e12 - e * e) / (1 - e * e)
    print(f"nu = {nu:+d}: pi = {[str(pi[w]) for w in W]}, E w_j = {e}, E w_1 w_2 = {e12}, Corr(w_1, w_2) = {corr}")
    assert [pi[w] for w in W] == PI[nu] and e == EW[nu] and e * e == (Fr(1, 196) if nu == 1 else Fr(1, 324))
    assert e12 == EWW[nu] and corr == CORR[nu]
    rho = max(rho, abs(corr))
assert rho == Fr(19, 65)
# Phi(y) = -h(y, y) - |b| rho (1 - y^2) = c0 + c1 y + c2 y^2
c0 = Fr(1, 8) - abs(b) * rho
c1 = Fr(1, 8)
c2 = Fr(1, 4) + abs(b) * rho
disc = c1 * c1 - 4 * c2 * c0
minPhi = c0 - c1 * c1 / (4 * c2)
print(f"Phi(y) = {c0} + {c1} y + {c2} y^2, discriminant {disc} < 0, min over R = {minPhi} = {float(minPhi):.5f}")
assert c2 > 0 and disc < 0 and minPhi == Fr(13919, 349440)
assert (c0, c1, c2) == (Fr(27, 520), Fr(1, 8), Fr(21, 65))
assert disc == Fr(1, 64) - 4 * Fr(21, 65) * Fr(27, 520) == Fr(-13919, 270400)
assert minPhi == -disc / (4 * c2) and f"{float(minPhi):.4f}" == "0.0398"
t = sp.symbols("t")
R = lambda x: sp.Rational(x.numerator, x.denominator)
htt = R(mu) + 2 * R(a) * t + R(b) * t**2
assert sp.expand(htt - (-sp.Rational(1, 8) - t / 8 - t**2 / 4)) == 0
assert sp.expand(htt - sum(R(h[w]) * prod((1 + w[j] * t) / 2 for j in range(2)) for w in W)) == 0
Phi_tt = sigma * htt - R(abs(b)) * R(rho) * (1 - t**2)
assert sp.expand(Phi_tt - (sp.Rational(1, 8) + t / 8 + t**2 / 4 - sp.Rational(1, 4) * sp.Rational(19, 65) * (1 - t**2))) == 0
assert sp.expand(Phi_tt - (sp.Rational(27, 520) + t / 8 + sp.Rational(21, 65) * t**2)) == 0
print("h(t,t) = -1/8 - t/8 - t^2/4,  Phi(t,t) = 1/8 + t/8 + t^2/4 - (1/4)(19/65)(1 - t^2) = 27/520 + t/8 + (21/65) t^2  [EXACT]")
print("Hence sigma Gamma_nu(F) >= min Phi > 0 for every k, nu, F: s_g = triv = 9/16 < s^U_g. [EXACT]")

# ---------------------------------------------------------------- the remark after the proof; brute force
hn2 = sum(v * v for v in h.values()) / 4
pip = {w: (1 + h[w]) / (4 * (1 + mu)) for w in W}
dict_val = sigma * sum(pip[w] * h[w] for w in W)  # dictator: k = 1, nu = +1, F(z) = z
assert hn2 == Fr(11, 128) < abs(mu) and dict_val == -(mu + hn2) / (1 + mu) == Fr(5, 112) and f"{float(dict_val):.4f}" == "0.0446"
print(f"dictator decoder: sigma Gamma_+ = -(mu + ||h||^2)/(1 + mu) = {dict_val} ~ {float(dict_val):.4f}, ||h||^2 = {hn2}  [EXACT]")


def sigma_gamma(nu, Fvals, exact):
    """sigma * Gamma_nu(F) = sigma * E h(F(X), F(Z)), X, Z the two columns, rows i.i.d. pi_{nu_i}."""
    k = len(nu)
    cv = (lambda x: x) if exact else float
    F = dict(zip(itertools.product([1, -1], repeat=k), Fvals))
    piv = {n: {w: cv((1 + n * h[w]) / (4 * (1 + n * mu))) for w in W} for n in (1, -1)}
    hv = {w: cv(h[w]) for w in W}
    tot = 0 * cv(Fr(1))
    for rows in itertools.product(W, repeat=k):
        wt = prod(piv[nu[i]][rows[i]] for i in range(k))
        y = (F[tuple(r[0] for r in rows)], F[tuple(r[1] for r in rows)])
        tot += wt * sum(hv[w] * prod((1 + w[j] * y[j]) / 2 for j in range(2)) for w in W)
    return sigma * tot


best = None
for k, vals in ((1, (1, 0, -1)), (2, (1, 0, -1)), (3, (1, -1))):
    for nu in itertools.product([1, -1], repeat=k):
        for Fv in itertools.product(vals, repeat=2**k):
            v = sigma_gamma(nu, [Fr(x) for x in Fv], True)
            assert v >= minPhi
            best = v if best is None else min(best, v)
print(f"decoders with values in {{-1,0,1}} (k <= 2) and in {{-1,1}} (k = 3): min sigma Gamma = {best} >= {minPhi}  [EXACT]")
rng = np.random.default_rng(0)
worst = np.inf
for trial in range(400):
    k = int(rng.integers(1, 5))
    nu = tuple(int(x) for x in rng.choice([1, -1], size=k))
    v = sigma_gamma(nu, list(np.clip(rng.uniform(-1.3, 1.3, size=2**k), -1, 1)), False)
    assert v >= float(minPhi) - 1e-12
    worst = min(worst, v)
print(f"(float) 400 random [-1,1]-valued decoders, k <= 4: min sigma Gamma = {worst:.5f} >= {float(minPhi):.5f}")
