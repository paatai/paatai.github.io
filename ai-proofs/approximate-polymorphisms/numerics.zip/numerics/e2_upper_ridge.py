"""Exploration (floating point, not rigorous): ridge majorants for Theorem 4.5.

For h = sum_j theta_j q_j with ||theta||_1 <= 1, h is [-1,1]-valued with mean 0, and the majorisation
E psi(U_rho h) <= E psi(f*) still holds (bathtub + Borell).  So
    E gamma^+ <= sum_F |F| E psi_F(f*)
for convex psi_F with  sum_F sum_{theta in F} psi_F(<theta, m>) >= max(Xi(m), 0)  on [-1,1]^3,
where each family F is a permutation-invariant set of directions sharing one function psi_F.
The separable bound of Theorem 4.5 is the family {e1, e2, e3}.  This script solves the LP on a grid of knot
triples (sorted, by symmetry) and reports the value for several choices of families.

Usage: python3 e2_upper_ridge.py [n_core]
"""
import itertools
import sys
import numpy as np
from scipy.optimize import linprog
from scipy.sparse import coo_matrix, vstack
from scipy.special import ndtri
from e2_upper_herm import gamma_bound
from e2_upper_rig import lp_weights


def make_knots(n_core):
    ut = np.linspace(-1, 1, n_core + 1)[1:-1]
    z = ndtri((1 + ut) / 2)
    z = np.unique(np.concatenate([z, [0.0]]))
    from scipy.special import erf
    return np.concatenate([[-1.0], erf(z / np.sqrt(2)), [1.0]])


def perm_family(v):
    return sorted(set(itertools.permutations(v)))


FAMILIES = {
    "sep": perm_family((1, 0, 0)),
    "r3": perm_family((1 / 3, 1 / 3, -1 / 3)),
    "r3m": perm_family((-1 / 3, -1 / 3, 1 / 3)),
    "d3": [(1 / 3, 1 / 3, 1 / 3)],
    "d3m": [(-1 / 3, -1 / 3, -1 / 3)],
    "p2": perm_family((0.5, 0.5, 0)),
    "p2m": perm_family((-0.5, -0.5, 0)),
    "a2": perm_family((0.5, -0.5, 0)),
    "w4": perm_family((0.5, 0.25, -0.25)),
    "w4b": perm_family((0.5, -0.25, -0.25)),
    "w4c": perm_family((0.5, 0.25, 0.25)),
}


def interp_weights(u, s):
    """indices/weights of the hat functions at s (piecewise linear interpolation on knots u)."""
    i = np.clip(np.searchsorted(u, s, side="right") - 1, 0, len(u) - 2)
    t = (s - u[i]) / (u[i + 1] - u[i])
    return i, 1 - t, i + 1, t


def solve(u, fams, verbose=True):
    N = len(u)
    idx = np.arange(N)
    A, B, Cc = np.meshgrid(idx, idx, idx, indexing="ij")
    sel = (A <= B) & (B <= Cc)
    a, b, c = A[sel], B[sel], Cc[sel]
    m = np.stack([u[a], u[b], u[c]], 1)
    rhs = np.maximum(gamma_bound(m[:, 0], m[:, 1], m[:, 2]), 0.0)
    nc = len(rhs)
    rows, cols, vals = [], [], []
    for f, name in enumerate(fams):
        off = f * N
        for th in FAMILIES[name]:
            s = m @ np.array(th)
            i0, w0, i1, w1 = interp_weights(u, s)
            r = np.arange(nc)
            rows += [r, r]
            cols += [off + i0, off + i1]
            vals += [-w0, -w1]
    Aub = coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))),
                     shape=(nc, N * len(fams))).tocsr()
    h = np.diff(u)
    conv = []
    for f in range(len(fams)):
        off = f * N
        r2 = np.repeat(np.arange(N - 2), 3)
        c2 = off + np.stack([np.arange(N - 2), np.arange(1, N - 1), np.arange(2, N)], 1).ravel()
        v2 = np.stack([-1 / h[:-1], 1 / h[:-1] + 1 / h[1:], -1 / h[1:]], 1).ravel()
        conv.append(coo_matrix((v2, (r2, c2)), shape=(N - 2, N * len(fams))))
    w = lp_weights(u)
    obj = np.concatenate([len(FAMILIES[name]) * w for name in fams])
    res = linprog(obj, A_ub=vstack([Aub] + conv).tocsr(), b_ub=np.concatenate([-rhs, np.zeros((N - 2) * len(fams))]),
                  bounds=[(None, None)] * (N * len(fams)), method="highs")
    if verbose:
        print(f"{'+'.join(fams):40s} constraints {nc:7d}  value {res.fun:.6e}  status {res.status}", flush=True)
    return res


if __name__ == "__main__":
    n_core = int(sys.argv[1]) if len(sys.argv) > 1 else 80
    u = make_knots(n_core)
    print(f"knots {len(u)}")
    for fams in [["sep"], ["sep", "r3"], ["sep", "r3", "r3m"], ["sep", "r3", "d3", "d3m"],
                 ["sep", "r3", "r3m", "p2", "p2m", "a2"], ["sep", "r3", "r3m", "d3", "d3m", "p2", "p2m", "a2"],
                 ["sep", "r3", "r3m", "d3", "d3m", "p2", "p2m", "a2", "w4", "w4b", "w4c"]]:
        solve(u, fams)
