"""Tight cases of the class-wise inequality Phi_delta(P,T) >= 0 for rep3 (numerical exploration).

Phi_delta = E[P(X)P(Z)] + E[T(V)] - 2E[T(V)P(Z)] + (2-delta) E[P(X)T(V)]  (delta = 0: exact class-wise condition of
rep3; delta = 2: the relaxation (star) of rep3_star.py).  For each k <= kmax and nu, minimise Phi over P, T in
[0,1] (T = best response 1[E[1-2P(Z) + (2-delta)P(X) | V] < 0], P by exact coordinate descent) from many starts and
print all local minima with value < tol.
usage: python3 classwise_tight.py delta kmax restarts
"""
import itertools
import sys

import numpy as np

from rep3_star import pi

def kern(b, i, j):
    K = np.zeros((2, 2))
    for w, p in pi[b].items():
        K[int(w[i] == -1), int(w[j] == -1)] += p
    return K


def kron(Ks):
    out = np.ones((1, 1))
    for K in Ks:
        out = np.kron(out, K)
    return out


def margV(b):
    return np.array([sum(p for w, p in pi[b].items() if w[1] == 1), sum(p for w, p in pi[b].items() if w[1] == -1)])


def phi(P, T, KXZ, KVZ, KXV, mV, d):
    return P @ KXZ @ P + mV @ T - 2 * T @ KVZ @ P + (2 - d) * P @ KXV @ T


def main():
    d = float(sys.argv[1])
    kmax = int(sys.argv[2])
    restarts = int(sys.argv[3])
    rng = np.random.default_rng(0)
    for k in range(1, kmax + 1):
        for npos in range(k + 1):
            nu = [1] * npos + [-1] * (k - npos)
            KXZ = kron([kern(b, 0, 2) for b in nu])
            KVZ = kron([kern(b, 1, 2) for b in nu])   # rows V, cols Z
            KXV = kron([kern(b, 0, 1) for b in nu])   # rows X, cols V
            mV = kron([margV(b)[None, :] for b in nu])[0]
            n = 2 ** k
            S = (KXZ + KXZ.T) / 2
            found = []
            starts = [rng.uniform(0, 1, n) for _ in range(restarts)] + [rng.integers(0, 2, n).astype(float) for _ in range(restarts)]
            zs = np.array(list(itertools.product([1, -1], repeat=k)))
            for r in range(k):
                starts.append((zs[:, r] == 1).astype(float))
            for P in starts:
                P = P.copy()
                for _ in range(300):
                    # best response T: coefficient of T(v) is mV(v) - 2 (KVZ P)(v) + (2-d)(KXV^T P)(v)
                    cT = mV - 2 * KVZ @ P + (2 - d) * KXV.T @ P
                    T = (cT < 0).astype(float)
                    # coordinate descent in P: Phi = P S P + P.(lin) + const
                    lin = -2 * KVZ.T @ T + (2 - d) * KXV @ T
                    old = P.copy()
                    for z in range(n):
                        a = S[z, z]
                        b = lin[z] + 2 * (S[z] @ P - S[z, z] * P[z])
                        cands = [0.0, 1.0]
                        if a > 0:
                            x = -b / (2 * a)
                            if 0 < x < 1:
                                cands.append(x)
                        vals = [a * x * x + b * x for x in cands]
                        P[z] = cands[int(np.argmin(vals))]
                    if np.max(np.abs(P - old)) < 1e-13:
                        break
                cT = mV - 2 * KVZ @ P + (2 - d) * KXV.T @ P
                T = (cT < 0).astype(float)
                val = phi(P, T, KXZ, KVZ, KXV, mV, d)
                found.append((val, tuple(np.round(P, 4)), tuple(T)))
            found.sort()
            uniq = []
            for f in found:
                if f[0] < 1e-9 and all(f[1] != u[1] for u in uniq):
                    uniq.append(f)
            print(f"k={k} nu={''.join('+' if b > 0 else '-' for b in nu)} min Phi = {found[0][0]:.3e}; "
                  f"#tight local minima: {len(uniq)}")
            for u in uniq[:12]:
                print("    P =", u[1], " T =", u[2], f" Phi={u[0]:.2e}")


if __name__ == "__main__":
    main()
