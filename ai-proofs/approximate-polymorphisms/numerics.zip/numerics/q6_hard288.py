"""Write the 288 m=5 boundary functions h (|J|=3) that have no certificate with k<=2 labels (exact, as in
q6_exact_k2.py) to outputs/hard288.txt, one per line, values of 2h on (+++,++-,+-+,+--,-++,-+-,--+,---)."""
import itertools
import numpy as np
import q6_exact_k2_lib as L
H = np.load('outputs/hard_h_d3_r2.npy')
rows = []
for hv in H:
    h2 = [int(round(2 * x)) for x in hv]
    if max(L.best(h2, 1, [1, 0, -1]), L.best(h2, 2, [1, 0, -1])) <= 0:
        rows.append(h2)
with open('outputs/hard288.txt', 'w') as f:
    for r in rows:
        f.write(' '.join(map(str, r)) + '\n')
print(len(rows), 'boundary functions written; g0 (2h = -2 -2 -2 1 0 -1 -1 -1) included:',
      [-2, -2, -2, 1, 0, -1, -1, -1] in rows or [2, 2, 2, -1, 0, 1, 1, 1] in rows)
