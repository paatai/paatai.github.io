"""Core numerics for the list-decoding thresholds s_g of approximate polymorphisms.

Conventions (CFMMS, arXiv:2106.00093, Section 5):
  g : {-1,1}^m -> {-1,1}, given as a dict / array indexed by sign vectors.
  mu = E g, rho_j = ghat({j}) / sqrt(1 - mu^2).
  (G_0, G_1..G_m): standard Gaussians, G_1..G_m independent, E[G_0 G_j] = rho_j.

Representation used throughout (Lemma lem:sg-ub of CFMMS):
  a = |rho|, Z_1..Z_m, W_1..W_m iid N(0,1),
  G_0 = sum_j (rho_j / a) Z_j,   G_j = a Z_j + sqrt(1 - a^2) W_j.
Given Z the G_j are independent, so for q_j: R -> [-1,1],
  E[ g(q_1(G_1),...,q_m(G_m)) | Z ] = g_ml( (U_a q_1)(Z_1), ..., (U_a q_m)(Z_m) ),
with g_ml the multilinear extension.  Conditioning on G_0 = x fixes the component
of Z along rho/a; the orthogonal complement is an (m-1)-dim standard Gaussian.
"""
import itertools
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.special import ndtr  # standard normal CDF


def cube(m):
    return [np.array(v) for v in itertools.product([1, -1], repeat=m)]


def fourier(gfun, m):
    """Return dict S(tuple of indices) -> ghat(S)."""
    pts = cube(m)
    coef = {}
    for r in range(m + 1):
        for S in itertools.combinations(range(m), r):
            coef[S] = np.mean([gfun(tuple(v)) * np.prod(v[list(S)]) for v in pts])
    return coef


def multilinear(coef, ys):
    """Evaluate the multilinear extension at ys (list of arrays, broadcastable)."""
    out = 0.0
    for S, c in coef.items():
        if c == 0:
            continue
        term = c
        for j in S:
            term = term * ys[j]
        out = out + term
    return out


class GaussData:
    def __init__(self, gfun, m):
        self.m = m
        self.gfun = gfun
        self.coef = fourier(gfun, m)
        self.mu = self.coef[()]
        self.lvl1 = np.array([self.coef[(j,)] for j in range(m)])
        self.rho = self.lvl1 / np.sqrt(1 - self.mu ** 2)
        self.a = np.linalg.norm(self.rho)
        self.rhohat = self.rho / self.a if self.a > 0 else None
        # orthonormal basis of the complement of rhohat
        if self.a > 0:
            M = np.eye(m)
            M[:, 0] = self.rhohat
            Q, _ = np.linalg.qr(M)
            if np.dot(Q[:, 0], self.rhohat) < 0:
                Q[:, 0] *= -1
            self.perp = Q[:, 1:]
        self.s = self.a / np.sqrt(1 - self.a ** 2)  # U_a sgn(z) = 2 Phi(s z) - 1


def gh_nodes(npts, dim):
    x, w = hermegauss(npts)
    w = w / np.sqrt(2 * np.pi)
    grids = np.meshgrid(*([x] * dim), indexing="ij")
    wgrid = np.ones_like(grids[0])
    for d in range(dim):
        wgrid = wgrid * np.meshgrid(*([w] * dim), indexing="ij")[d]
    return [gg.ravel() for gg in grids], wgrid.ravel()


def gamma_x(GD, x, Ufuncs, npts=60):
    """gamma(x) = E[ g(q_1(G_1),...,q_m(G_m)) | G_0 = x ] for n = 1.

    Ufuncs[j] is the function z -> (U_a q_j)(z) (vectorised)."""
    m = GD.m
    nodes, w = gh_nodes(npts, m - 1)
    x = np.atleast_1d(x)
    out = np.empty_like(x, dtype=float)
    for i, xv in enumerate(x):
        Z = xv * GD.rhohat[:, None] + GD.perp @ np.vstack(nodes)
        ys = [Ufuncs[j](Z[j]) for j in range(m)]
        out[i] = np.dot(w, multilinear(GD.coef, ys))
    return out


def U_sign(GD, t=1.0, theta=0.0):
    """U_a of q(z) = t * sgn(z - theta)  (not balanced unless theta = 0)."""
    s = GD.s
    a = GD.a
    sig = np.sqrt(1 - a ** 2)
    return lambda z: t * (2 * ndtr((a * z - theta) / sig) - 1)


def E2(v):
    return 1 if sum(1 for b in v if b == 1) == 2 else -1
