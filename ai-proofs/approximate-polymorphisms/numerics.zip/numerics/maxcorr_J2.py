"""Theorem F (maximal-correlation criterion) for |J| = 2: exact classification of one-class h on {+-1}^2.

h(++) = x, h(+-) = h(-+) = z, h(--) = y (one class: hat h({1}) = hat h({2}) = a = (x - y)/4 != 0), values in
delta*Z with delta = 2^(1-r) (r = |U|, m = r + 2), normalised to mu < 0 (sigma = -1, a certificate is Gamma > 0).
Necessary conditions for realisability by some g with J = {1,2}: sum_w h(w)/delta even (otherwise sum_{w,u} g u_i
is odd, so hat g({u_i}) != 0) and |h(w)| < 1 for some w (g depends on u).  For each such h, in exact arithmetic:
  TRIV  : -h >= 0 on the four vertices (Theorem C(i));
  CERT  : a certificate Gamma > 0 among the k = 1 decoders (continuous, both nu; this includes the constant
          decoders) and the k = 2 decoders with values in {-1,1};
  THM_F : the maximal-correlation criterion Phi(y) = -h(y,y) - |b| rho (1 - y^2) >= 0 on [-1,1], where
          b = hat h({1,2}) and rho = max_nu |Corr_{pi_nu}(w_1, w_2)| (a rational number, since both columns have the
          same marginal); then s_g = triv (Theorem F), and s^U_g > triv iff some -h(w) < 0 (Theorem C(ii)).
  THM_F+: Proposition 10.4 (Theorem L applied to E[P | rows of the dangerous sign]);
  THM_F#: Proposition 10.6 (single-coupling bound), tried when THM_F+ fails;
  CERT_k2, CERT_k3: a certificate among continuous decoders with k = 2 or 3 (exact maximum over the cube of values,
          j2_k2_exact.py), tried when THM_F# fails;
  UNDEC : none of these.
usage: python3 maxcorr_J2.py r [workers]
"""
import itertools
import sys
from fractions import Fraction as Fr

r = int(sys.argv[1]) if len(sys.argv) > 1 else 4
delta = Fr(2, 2 ** r)
vals = [-1 + j * delta for j in range(2 ** r + 1)]
W2 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def hml(hv, y1, y2):
    x, z, _, y = hv
    return (x * (1 + y1) * (1 + y2) + z * (1 + y1) * (1 - y2) + z * (1 - y1) * (1 + y2) + y * (1 - y1) * (1 - y2)) / 4


def laws(hv):
    mu = sum(hv) / 4
    return mu, {b: [(1 + b * hv[i]) / (4 * (1 + b * mu)) for i in range(4)] for b in (1, -1)}


def gamma(hv, pi, nu, F):
    """F: dict z -> value, z in {+-1}^k; rows independent, row i ~ pi[nu[i]] on W2."""
    k = len(nu)
    tot = Fr(0)
    for rows in itertools.product(range(4), repeat=k):
        p = Fr(1)
        for i in range(k):
            p *= pi[nu[i]][rows[i]]
        if p == 0:
            continue
        c1 = tuple(W2[rows[i]][0] for i in range(k))
        c2 = tuple(W2[rows[i]][1] for i in range(k))
        tot += p * hml(hv, F[c1], F[c2])
    return tot


def quad_max(c0, c1, c2, lo=-1, hi=1):
    """max of c0 + c1 t + c2 t^2 on [lo, hi]."""
    cands = [Fr(lo), Fr(hi)]
    if c2 != 0:
        t = -c1 / (2 * c2)
        if lo <= t <= hi:
            cands.append(t)
    return max(c0 + c1 * t + c2 * t * t for t in cands)


def k1_max(hv, pi):
    """max over F(+) = s, F(-) = t in [-1,1]^2 and nu in {+,-} of Gamma; Gamma is a quadratic in (s, t)."""
    best = None
    for b in (1, -1):
        p = pi[b]
        # Gamma(s,t) = p++ h(s,s) + p+- h(s,t) + p-+ h(t,s) + p-- h(t,t)
        def G(s, t):
            return p[0] * hml(hv, s, s) + p[1] * hml(hv, s, t) + p[2] * hml(hv, t, s) + p[3] * hml(hv, t, t)
        # coefficients of the quadratic form in (s, t): evaluate on a 3x3 grid and solve
        pts = [Fr(-1), Fr(0), Fr(1)]
        vals_ = {(s, t): G(s, t) for s in pts for t in pts}
        A = (vals_[(1, 0)] + vals_[(-1, 0)]) / 2 - vals_[(0, 0)]      # coeff s^2
        C = (vals_[(0, 1)] + vals_[(0, -1)]) / 2 - vals_[(0, 0)]      # coeff t^2
        D = (vals_[(1, 0)] - vals_[(-1, 0)]) / 2                      # coeff s
        E = (vals_[(0, 1)] - vals_[(0, -1)]) / 2                      # coeff t
        B = (vals_[(1, 1)] - vals_[(1, -1)] - vals_[(-1, 1)] + vals_[(-1, -1)]) / 4  # coeff s t
        c00 = vals_[(0, 0)]
        cand = []
        for s in (Fr(-1), Fr(1)):   # edges s = +-1: quadratic in t
            cand.append(quad_max(c00 + D * s + A * s * s, E + B * s, C))
        for t in (Fr(-1), Fr(1)):
            cand.append(quad_max(c00 + E * t + C * t * t, D + B * t, A))
        det = 4 * A * C - B * B
        if det != 0:
            s0 = (B * E - 2 * C * D) / det
            t0 = (B * D - 2 * A * E) / det
            if -1 <= s0 <= 1 and -1 <= t0 <= 1:
                cand.append(G(s0, t0))
        m = max(cand)
        best = m if best is None else max(best, m)
    return best


def thmF(hv, pi):
    """True iff Phi(y) = -h(y,y) - |b| rho (1 - y^2) >= 0 on [-1, 1]."""
    x, z, _, y = hv
    b = (x + y - 2 * z) / 4
    rho = Fr(0)
    for nu in (1, -1):
        p = pi[nu]
        e = p[0] + p[1] - p[2] - p[3]
        e12 = p[0] - p[1] - p[2] + p[3]
        if 1 - e * e == 0:
            continue
        rho = max(rho, abs((e12 - e * e) / (1 - e * e)))
    # Phi(t) = -h(t,t) - |b| rho + |b| rho t^2 ; minimum on [-1,1] of a quadratic
    c0 = -hml(hv, 0, 0) - abs(b) * rho
    c1 = -(hml(hv, 1, 1) - hml(hv, -1, -1)) / 2
    c2 = -((hml(hv, 1, 1) + hml(hv, -1, -1)) / 2 - hml(hv, 0, 0)) + abs(b) * rho
    return -quad_max(-c0, -c1, -c2) >= 0, rho, b


def quad_min(c0, c1, c2, lo, hi):
    return -quad_max(-c0, -c1, -c2, lo, hi)


def thmFplus(hv, pi):
    """Refined criterion (Proposition 10.4).  With P = (1+F)/2, p = E P, eps = sgn(sigma b) and lambda_S the product
    of the row correlations, sigma Gamma = sigma h(y,y) + |b| eps Cov, Cov = 4 sum_{S != 0} lambda_S |P_S|^2.
    Dangerous S (eps lambda_S < 0): singletons of the rows nu* with eps lambda_nu* < 0 (coefficient a = |lambda_nu*|),
    sets of size >= 2 inside the rows nu* (coefficient <= a2) and sets meeting the other rows (coefficient <= Mp).
    With Pbar = E[P | rows nu*] and f = E Pbar^2, Theorem L applied to Pbar and 1 - Pbar bounds the level-one weight
    of Pbar; the bound is nonincreasing in f once a2 is raised to A = max(a2, (Mp - a q)/(1 - q)), so f = p is the
    worst case.  Returns (ok, reason); ok means Phi+(p) >= 0 on [0, 1], checked exactly piece by piece."""
    x, z, _, y = hv
    b = (x + y - 2 * z) / 4
    sigma = -1                                   # mu < 0 normalisation
    eps = 1 if sigma * b > 0 else -1
    lam, qq = {}, {}
    for nu in (1, -1):
        p_ = pi[nu]
        e = p_[0] + p_[1] - p_[2] - p_[3]
        e12 = p_[0] - p_[1] - p_[2] + p_[3]
        lam[nu] = Fr(0) if 1 - e * e == 0 else (e12 - e * e) / (1 - e * e)
        qq[nu] = min((1 + e) / 2, (1 - e) / 2)
    D = [nu for nu in (1, -1) if eps * lam[nu] < 0]
    M = Fr(0)
    for size in (2, 3):
        for combo in itertools.combinations_with_replacement((1, -1), size):
            prod = Fr(1)
            for nu in combo:
                prod *= lam[nu]
            if eps * prod < 0:
                M = max(M, abs(prod))
    # sigma h(y, y) as a quadratic in p, y = 2p - 1
    s0 = sigma * hml(hv, -1, -1)
    s1v = sigma * hml(hv, 0, 0)
    s2v = sigma * hml(hv, 1, 1)
    # values at p = 0, 1/2, 1 -> coefficients
    A0 = s0
    A2 = 2 * (s2v + s0) - 4 * s1v
    A1 = s2v - s0 - A2
    B = 4 * abs(b)
    if b == 0:
        return quad_min(A0, A1, A2, 0, 1) >= 0, 'b=0'
    if len(D) == 2:
        return False, 'D=2 (not implemented)'
    if len(D) == 1 and abs(lam[D[0]]) <= M:
        D = []
    if len(D) == 0:
        # every dangerous coefficient is <= M:  Phi+ = sigma h - B M p (1 - p)
        return quad_min(A0, A1 - B * M, A2 + B * M, 0, 1) >= 0, f'D=0, M={M}'
    nus = D[0]
    a = abs(lam[nus])
    q = qq[nus]
    beta = (1 - 2 * q) / q
    assert a > M and 0 < q <= Fr(1, 2)
    # a2: dangerous sets inside the nu* rows of size >= 2; Mp: dangerous sets meeting the other rows
    lo = lam[-nus]
    a2, Mp = (a ** 3, a * lo) if eps == 1 else (a ** 2, lo * lo)
    Acoef = max(a2, (Mp - a * q) / (1 - q))
    assert a2 <= Acoef <= M and Mp < a
    c = a - Acoef
    # piece 1, p in [0, q]: W <= q p + beta p^2
    ok1 = quad_min(A0, A1 - B * (c * q + Acoef), A2 - B * (c * beta - Acoef), 0, q) >= 0
    # piece 2, p in [q, 1-q]: W <= p (1 - p)
    ok3 = quad_min(A0, A1 - B * (c + Acoef), A2 + B * (c + Acoef), q, 1 - q) >= 0
    # piece 3, p in [1-q, 1]: W <= q (1-p) + beta (1-p)^2 = (q + beta) - (q + 2 beta) p + beta p^2
    ok2 = quad_min(A0 - B * c * (q + beta), A1 - B * (-c * (q + 2 * beta) + Acoef), A2 - B * (c * beta - Acoef),
                   1 - q, 1) >= 0
    return ok1 and ok2 and ok3, f'D={nus:+d}, a={a}, a2={a2}, Mp={Mp}, A={Acoef}, M={M}, q={q}'


def theta_lo(a, r):
    """sup over odd l >= 1 of (r^l - a^l) / (1 + r^l), exactly (0 < a <= r <= 1).  If a = r all terms vanish; if
    r = 1 > a the terms increase to 1/2; otherwise the first term is positive and every term is <= r^l, so the terms
    with r^l <= current max can be skipped and the supremum is a maximum."""
    if a == r:
        return Fr(0)
    if r == 1:
        return Fr(1, 2)
    th = Fr(0)
    i = 2
    while True:
        ri, ai = r ** (i - 1), a ** (i - 1)
        th = max(th, (ri - ai) / (1 + ri))
        if r ** (i + 1) <= th:
            return th
        i += 2


def thmFsharp(hv, pi):
    """Coupling criterion (Proposition 10.6): eps = 1, exactly one sign nu_* with lambda_nu* = -a < 0 <= lambda' =
    lambda_{-nu*}.  With r = q/(1-q), q = q_{nu*}, theta = theta_lo(a, r):
      sigma Gamma >= sigma h(2p-1, 2p-1) - 4|b| a min{p(1-p), theta p(1-p) + (1-theta) min(p,1-p)^2 / r},
    a quadratic on [0,q], [q,1-q], [1-q,1]; checked exactly."""
    x, z, _, y = hv
    b = (x + y - 2 * z) / 4
    sigma = -1
    if not sigma * b > 0:
        return False, 'eps=-1'
    lam, qq = {}, {}
    for nu in (1, -1):
        p_ = pi[nu]
        e = p_[0] + p_[1] - p_[2] - p_[3]
        e12 = p_[0] - p_[1] - p_[2] + p_[3]
        lam[nu] = Fr(0) if 1 - e * e == 0 else (e12 - e * e) / (1 - e * e)
        qq[nu] = min((1 + e) / 2, (1 - e) / 2)
    D = [nu for nu in (1, -1) if lam[nu] < 0]
    if len(D) != 1:
        return False, f'#D={len(D)}'
    nus = D[0]
    a, q = -lam[nus], qq[nus]
    r = q / (1 - q)
    assert 0 < a <= r <= 1
    th = theta_lo(a, r)
    s0 = sigma * hml(hv, -1, -1)
    s1v = sigma * hml(hv, 0, 0)
    s2v = sigma * hml(hv, 1, 1)
    A0 = s0
    A2 = 2 * (s2v + s0) - 4 * s1v
    A1 = s2v - s0 - A2
    B = 4 * abs(b)
    cc = (1 - th) / r
    ok1 = quad_min(A0, A1 - B * a * th, A2 - B * a * (cc - th), 0, q) >= 0
    ok2 = quad_min(A0, A1 - B * a, A2 + B * a, q, 1 - q) >= 0
    ok3 = quad_min(A0 - B * a * cc, A1 - B * a * (th - 2 * cc), A2 - B * a * (cc - th), 1 - q, 1) >= 0
    return ok1 and ok2 and ok3, f'D={nus:+d}, a={a}, q={q}, theta={th}'


def cont_cert(hv, kmax):
    """Exact maximum of Gamma over continuous decoders with k <= kmax (j2_k2_exact.cube_max); returns (k, nu, value, F)
    for the first k with a positive maximum, or None."""
    from j2_k2_exact import cube_max, quad_form
    for k in range(1, kmax + 1):
        for npos in range(k, -1, -1):
            nu = tuple([1] * npos + [-1] * (k - npos))
            val, F = cube_max(*quad_form(hv, nu))
            if val > 0:
                return k, nu, val, F
    return None


def k2_bool_cert(hv, pi):
    """True iff some {-1,1}-valued decoder with k = 2 has Gamma > 0.  For such F, Gamma is a sum of 16 terms
    prob * h(vertex); it is screened in floating point (error < 1e-14) and every decoder with float value > -1e-9 is
    re-evaluated exactly, so the answer is exact."""
    zs = list(itertools.product([1, -1], repeat=2))
    hvf = [float(v) for v in hv]
    for nu in [(1, 1), (1, -1), (-1, -1)]:
        terms = []
        for rows in itertools.product(range(4), repeat=2):
            p = float(pi[nu[0]][rows[0]] * pi[nu[1]][rows[1]])
            c1 = (W2[rows[0]][0], W2[rows[1]][0])
            c2 = (W2[rows[0]][1], W2[rows[1]][1])
            terms.append((p, zs.index(c1), zs.index(c2)))
        for v in itertools.product([1, -1], repeat=4):
            gf = sum(p * hvf[(1 - v[i]) + (1 - v[j]) // 2] for p, i, j in terms)
            if gf > -1e-9 and gamma(hv, pi, nu, dict(zip(zs, v))) > 0:
                return True
    return False


def classify(hv):
    """Category of a candidate h (mu < 0), with a reason string and (mu, rho, b) for the report."""
    mu, pi = laws(hv)
    if all(-v >= 0 for v in hv):
        return 'TRIV', '', None
    if k1_max(hv, pi) > 0 or k2_bool_cert(hv, pi):
        return 'CERT', '', None
    okF, rho, b = thmF(hv, pi)
    info = (mu, rho, b)
    if okF:
        return 'THM_F', '', info
    okFp, why = thmFplus(hv, pi)
    okS, whyS = thmFsharp(hv, pi)
    diag_key = (okFp, okS)
    if okFp:
        return 'THM_F+', why, info + (diag_key,)
    if okS:
        return 'THM_F#', whyS, info + (diag_key,)
    cc_ = cont_cert(hv, 3)
    if cc_ is None:
        return 'UNDEC', whyS, info + (diag_key,)
    k_, nu_, val_, F_ = cc_
    return f'CERT_k{k_}', f'nu={nu_}, Gamma={val_}, F={[str(v) for v in F_]}', info + (diag_key,)


def candidates_with_x(x):
    out = []
    for z, y in itertools.product(vals, repeat=2):
        hv = (x, z, z, y)
        if x == y or sum(hv) >= 0:
            continue                   # mu < 0 normalisation (the case mu > 0 is the mirror image)
        if (sum(hv) / delta) % 2 != 0:
            continue
        if all(abs(v) == 1 for v in hv):
            continue
        out.append(hv)
    return out


def work(x):
    return [(hv,) + classify(hv) for hv in candidates_with_x(x)]


if __name__ == '__main__':
    import multiprocessing as mp
    workers = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    if workers > 1:
        with mp.Pool(workers) as pool:
            results = pool.map(work, vals, chunksize=1)
    else:
        results = [work(x) for x in vals]
    counts, diag, examples = {}, {}, []
    nF = nFp = 0
    for res in results:
        for hv, cat, why, info in res:
            counts[cat] = counts.get(cat, 0) + 1
            if info is not None and len(info) == 4:
                diag[info[3]] = diag.get(info[3], 0) + 1
            if cat == 'THM_F':
                nF += 1
                if nF <= 400:
                    examples.append((cat, hv, info))
            elif cat == 'THM_F+':
                nFp += 1
                if nFp <= 400:
                    examples.append((cat + f' [{why}]', hv, info))
            elif cat not in ('TRIV', 'CERT'):
                examples.append((cat + f' [{why}]', hv, info))
    print(f"r = {r} (values in {delta}Z, m = r + 2 = {r + 2}):", counts)
    print("  candidates not in TRIV/CERT/THM_F, by (F+ applies, F# applies):", diag)
    for cat, hv, info in examples:
        mu, rho, b = info[:3]
        print(f"  {cat}: h(++,+-,-+,--) = {tuple(str(v) for v in hv)}, mu = {mu}, hat h(12) = {b}, rho = {rho}")
