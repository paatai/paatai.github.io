"""Global search over structured decoders for the 34 open m=9 candidates (|J|=2, one class; numerics/outputs/m9_open.txt).

Decoder: F(z) = G(z_k, n), n = #{i < k : z_i = c}, c the less likely value of w_1 under pi_{nu*}; all k rows of the dangerous
sign nu*.  Gamma is a quadratic in the 2k values of G; its maximum over [-1,1]^{2k} is found by enumerating all faces
(free set f, bound values on the rest), vectorised over the bound assignments.  Floating point; a positive maximum would be
confirmed exactly.  Faces whose restricted Hessian is (numerically) singular are skipped: on such a face the quadratic is affine
along a kernel direction, so its maximum is attained on a smaller face, which is enumerated as well.
Validation: for the m = 8 candidates (-5/32, 1/16, 1/16, -1/32) and (-9/32, 1/8, 1/8, -3/32) the search recovers the certificates of
Section 10 (Gamma = 67561/411505920 at k = 2 and 4317675409/14846652293120 at k = 3).
usage: python3 m9_struct_search.py kmax [kmin]
"""
import itertools
import os
import sys
from fractions import Fraction as Fr

import numpy as np

W2 = [(1, 1), (1, -1), (-1, 1), (-1, -1)]


def laws(hv):
    mu = sum(hv) / 4
    return {b: [(1 + b * hv[i]) / (4 * (1 + b * mu)) for i in range(4)] for b in (1, -1)}


def structured_form(hv, k, nus=None, c=None):
    x, z, _, y = hv
    al = (x + 2 * z + y) / 4
    be = (x - y) / 4
    b = (x - 2 * z + y) / 4
    pi = laws(hv)
    mu = sum(hv) / 4
    lam = {}
    for nu in (1, -1):
        p_ = pi[nu]
        e = p_[0] + p_[1] - p_[2] - p_[3]
        e12 = p_[0] - p_[1] - p_[2] + p_[3]
        lam[nu] = (e12 - e * e) / (1 - e * e)
    if nus is None:
        nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    p_ = pi[nus]
    pw1 = p_[0] + p_[1]                     # Pr[w1 = +1]
    if c is None:
        c = 1 if pw1 <= Fr(1, 2) else -1
    # per-row indicator pair (u, v) = (1[w1 = c], 1[w2 = c])
    puv = {(0, 0): Fr(0), (0, 1): Fr(0), (1, 0): Fr(0), (1, 1): Fr(0)}
    for i, (w1, w2) in enumerate(W2):
        puv[(int(w1 == c), int(w2 == c))] += p_[i]
    # distribution of (n1, n2) over k-1 rows
    dist = {(0, 0): Fr(1)}
    for _ in range(k - 1):
        nd = {}
        for (a1, a2), pr in dist.items():
            for (u, v), q in puv.items():
                if q == 0:
                    continue
                key = (a1 + u, a2 + v)
                nd[key] = nd.get(key, Fr(0)) + pr * q
        dist = nd
    states = [(t, n) for t in (1, -1) for n in range(k)]
    idx = {s: i for i, s in enumerate(states)}
    N = len(states)
    lin = [Fr(0)] * N
    Q = [[Fr(0)] * N for _ in range(N)]
    for i, (t1, t2) in enumerate(W2):
        pt = p_[i]
        if pt == 0:
            continue
        for (n1, n2), pn in dist.items():
            pr = pt * pn
            s1, s2 = idx[(t1, n1)], idx[(t2, n2)]
            lin[s1] += pr * be
            lin[s2] += pr * be
            Q[s1][s2] += pr * b / 2
            Q[s2][s1] += pr * b / 2
    return al, lin, Q, states, (nus, c, lam)


def box_max(c0, lin, Q):
    """max of c0 + lin.G + G^T Q G over [-1,1]^N by face enumeration (float)."""
    lin = np.array([float(v) for v in lin])
    Q = np.array([[float(v) for v in row] for row in Q])
    N = len(lin)
    best, bestG = -np.inf, None
    allidx = np.arange(N)
    for r in range(N + 1):
        for f in itertools.combinations(range(N), r):
            f = list(f)
            fix = [i for i in allidx if i not in f]
            nfix = len(fix)
            # all bound assignments of the fixed variables
            B = np.array(list(itertools.product([1.0, -1.0], repeat=nfix))) if nfix else np.zeros((1, 0))
            if r:
                Qff = Q[np.ix_(f, f)]
                try:
                    M = np.linalg.inv(Qff)
                except np.linalg.LinAlgError:
                    continue
                if np.linalg.cond(Qff) > 1e12:
                    continue
                # stationarity: lin_f + 2 Qff Gf + 2 Qf,fix Gfix = 0
                rhs = -(lin[f][None, :] + 2 * B @ Q[np.ix_(fix, f)]) / 2      # (#B, r)
                Gf = rhs @ M.T
                ok = np.all(np.abs(Gf) <= 1 + 1e-12, axis=1)
                if not ok.any():
                    continue
                Gf, Bk = Gf[ok], B[ok]
                G = np.zeros((len(Gf), N))
                G[:, f] = Gf
                G[:, fix] = Bk
            else:
                G = B
            vals = c0 + G @ lin + np.einsum('bi,ij,bj->b', G, Q, G)
            j = int(np.argmax(vals))
            if vals[j] > best:
                best, bestG = vals[j], G[j].copy()
    return best, bestG


def candidates():
    out = []
    for line in open(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'outputs', 'm9_open.txt')):
        if line.startswith("('"):
            hv = tuple(Fr(s.strip(" '")) for s in line.split('|')[0].strip()[1:-1].split(','))
            out.append(hv)
    return out


if __name__ == '__main__':
    for hv, k, val in [((Fr(-5, 32), Fr(1, 16), Fr(1, 16), Fr(-1, 32)), 2, Fr(67561, 411505920)),
                       ((Fr(-9, 32), Fr(1, 8), Fr(1, 8), Fr(-3, 32)), 3, Fr(4317675409, 14846652293120))]:
        c0, lin, Q, states, info = structured_form(hv, k)
        best, G = box_max(float(c0), lin, Q)
        assert abs(best - float(val)) < 1e-12, (hv, best)
        print('validation (m = 8):', tuple(str(v) for v in hv), 'k = %d: max %.10e (certificate value %.10e)' % (k, best, float(val)))
    kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 5
    kmin = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    cands = candidates()[::2]                       # one of each mirror pair
    for hv in cands:
        res = []
        for k in range(kmin, kmax + 1):
            c0, lin, Q, states, info = structured_form(hv, k)
            best, G = box_max(float(c0), lin, Q)
            res.append((k, best))
        print(tuple(str(v) for v in hv), 'nu*=%+d c=%+d' % info[:2],
              ' '.join('k=%d:%.3e' % kb for kb in res), flush=True)
