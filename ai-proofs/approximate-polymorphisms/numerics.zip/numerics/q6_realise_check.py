"""Exact checks on the 348 boundary candidates h (d=3, r=2) from q6_hsearch.py:
(1) each is realisable as h(w) = E_u g(w,u) by some g on 5 variables with ghat({u1}) = ghat({u2}) = 0 and
    g depending on u1 and u2 (exact DP over the choices of the accepted sets A_w subset {+-1}^2);
(2) each has ||h||^2 = |mu| exactly."""
import itertools
from fractions import Fraction as Fr
import numpy as np
H = np.load('outputs/hard_h_d3_r2.npy')
U = list(itertools.product([1, -1], repeat=2))
subsets = {s: [A for A in itertools.combinations(U, s)] for s in range(5)}
def info(A):
    s = (sum(u[0] for u in A), sum(u[1] for u in A))
    d1 = any(((-u[0], u[1]) in A) != (u in A) for u in U)
    d2 = any(((u[0], -u[1]) in A) != (u in A) for u in U)
    return s, d1, d2
ok_real = ok_norm = 0
for hv in H:
    h = [Fr(v).limit_denominator(4) for v in hv]
    sizes = [int(2 * (x + 1)) for x in h]
    states = {((0, 0), False, False)}
    for s in sizes:
        new = set()
        for (sv, a, b) in states:
            for A in subsets[s]:
                (x, y), d1, d2 = info(A)
                new.add(((sv[0] + x, sv[1] + y), a or d1, b or d2))
        states = new
    ok_real += ((0, 0), True, True) in states
    mu = sum(h) / 8
    ok_norm += (sum(x * x for x in h) / 8 == abs(mu))
print(f"{len(H)} candidates: realisable {ok_real}, ||h||^2 = |mu| exactly: {ok_norm}")
