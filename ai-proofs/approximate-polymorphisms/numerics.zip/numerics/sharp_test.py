"""Numerical test of the single-coupling bound (case eps = 1, one dangerous sign nu_*):
  -Cov(P(X),P(Z)) <= a * min{ p(1-p), theta p(1-p) + (1-theta) K / r },  K = min(p^2, (1-p)^2),
theta = max(theta_a, theta_even), theta_a = (r-a)/(1+r), theta_even = max_{even i>=4} (r^i - a^i)/(r + r^i)... (computed exactly
from the constraints kappa >= c r^i - a^i with c = a(1-theta)/r, kappa = a theta).
"""
from fractions import Fraction as Fr

import numpy as np

from fpp_test import UNDEC, params, sh


def theta_lo(a, r):
    # kappa = a th, c = a (1-th)/r ; need a th >= c r^i - a^i = a (1-th) r^(i-1) - a^i for even i >= 2
    th = 0.0
    for i in range(2, 400, 2):
        # th >= (r^(i-1) - a^(i-1)) / (1 + r^(i-1))
        th = max(th, (r ** (i - 1) - a ** (i - 1)) / (1 + r ** (i - 1)))
    return th


def run(hv, ngrid=4001):
    mu, pi, b, lam, qq = params(hv)
    nus = [nu for nu in (1, -1) if lam[nu] < 0][0]
    a = float(-lam[nus])
    q = float(qq[nus])
    r = q / (1 - q)
    th = theta_lo(a, r)
    ps = np.linspace(0, 1, ngrid)
    vals = []
    for p in ps:
        K = min(p * p, (1 - p) ** 2)
        V = p * (1 - p)
        brk = a * min(V, th * V + (1 - th) * K / r)
        vals.append(float(sh(hv, Fr(p).limit_denominator(10 ** 9))) - 4 * abs(float(b)) * brk)
    vals = np.array(vals)
    i = vals.argmin()
    return vals[i], ps[i], a, r, th, (r - a) / (1 + r)


if __name__ == '__main__':
    for xs, zs, ys in UNDEC:
        hv = (Fr(xs), Fr(zs), Fr(zs), Fr(ys))
        v, p, a, r, th, tha = run(hv)
        print(f"h = ({xs}, {zs}, {zs}, {ys}): a = {a:.4f}, r = {r:.4f}, theta_a = {tha:.4f}, theta = {th:.4f}: "
              f"min Phi = {v:+.6f} at p = {p:.4f}", flush=True)
