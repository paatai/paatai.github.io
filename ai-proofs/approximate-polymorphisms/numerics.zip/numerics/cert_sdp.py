"""SDP search for coupling certificates of triviality, class-wise formulation, two-class h on {-1,1}^3.

Let h (normalised to mu < 0) have classes {i,j} (pair) and {s} (singleton).  Triviality of h (Theorem D(c)) means
Gamma_nu(P,T) <= 0 for all k, nu and class-wise decoders, P = (1+F_pair)/2 on columns i,j and T = (1+F_s)/2 on column s.
For a cubic-free h' >= h with h' = h on supp(pi_+) (h' is an unknown of the SDP), Phi := -2 Gamma'_nu(P,T) is
    Phi = phi(p,t) + sum_{S != empty} [ A_S Phat(S)^2 + 2 B_S Phat(S) That(S) ]          (biased Fourier bases)
with A_S, B_S products over the rows of S of per-row correlations.  A certificate is an identity
    Phi = sum_i c_i N_i + R(p,t) + sum_{S != empty} Q_S(Phat(S), That(S))
with c_i >= 0, N_i = E_kappa[A(x) B(y)] >= 0 (A, B in {P, 1-P, T, 1-T}, kappa a product coupling of the relevant
marginals with per-row correlation rho_+ or rho_- by row sign), R >= 0 on [0,1]^2 and every 2x2 form Q_S PSD.
Since every term depends on S only through its numbers (a,b) of + and - rows, the PSD constraints are imposed for
1 <= a+b <= L (the tail is checked separately).
usage: python3 cert_sdp.py "2h vector" [L] [grid]
"""
import itertools
import sys

import cvxpy as cp
import numpy as np

W3 = list(itertools.product([1, -1], repeat=3))


def setup(h2):
    h = {w: x / 2 for w, x in zip(W3, h2)}
    mu = np.mean(list(h.values()))
    assert mu < 0
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    lev1 = [np.mean([h[w] * w[j] for w in W3]) for j in range(3)]
    vals = sorted(set(np.round(lev1, 12)))
    assert len(vals) == 2
    cls = [vals.index(round(x, 12)) for x in lev1]
    big = [j for j in range(3) if cls.count(cls[j]) == 2]
    s = [j for j in range(3) if cls.count(cls[j]) == 1][0]
    i, j = big
    return h, mu, pi, (i, j, s)


def marg(pi_b, j):
    return sum(p for w, p in pi_b.items() if w[j] == 1)


def corr(pi_b, j1, j2):
    q1, q2 = marg(pi_b, j1), marg(pi_b, j2)
    pp = sum(p for w, p in pi_b.items() if w[j1] == 1 and w[j2] == 1)
    return (pp - q1 * q2) / np.sqrt(q1 * (1 - q1) * q2 * (1 - q2))


def rho_range(q1, q2):
    lo, hi = max(0.0, q1 + q2 - 1), min(q1, q2)
    d = np.sqrt(q1 * (1 - q1) * q2 * (1 - q2))
    return (lo - q1 * q2) / d, (hi - q1 * q2) / d


def mobius(vals):
    """vals: dict w -> value; returns coefficients of the multilinear polynomial in p_j = 1[w_j = +]."""
    out = {}
    for T in itertools.product([0, 1], repeat=3):
        c = 0
        for U in itertools.product([0, 1], repeat=3):
            if all(U[k] <= T[k] for k in range(3)):
                w = tuple(1 if U[k] else -1 for k in range(3))
                c = c + (-1) ** (sum(T) - sum(U)) * vals[w]
        out[T] = c
    return out


def main():
    h2 = [int(x) for x in sys.argv[1].replace(",", " ").split()]
    L = int(sys.argv[2]) if len(sys.argv) > 2 else 8
    ng = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    h, mu, pi, (i, j, s) = setup(h2)
    supp = [w for w in W3 if h[w] > -1 + 1e-12]
    nons = [w for w in W3 if w not in supp]
    print("pair class", (i, j), "singleton", s, "non-support of pi_+:", nons)
    q = {b: marg(pi[b], i) for b in (1, -1)}
    qs = {b: marg(pi[b], s) for b in (1, -1)}
    lam = {key: {b: corr(pi[b], *key) for b in (1, -1)} for key in [(i, j), (i, s), (j, s)]}
    for b in (1, -1):
        print(f"row {b:+d}: q={q[b]:.6f} q_s={qs[b]:.6f} lam_ij={lam[(i, j)][b]:.6f} lam_is={lam[(i, s)][b]:.6f} "
              f"lam_js={lam[(j, s)][b]:.6f}")
    # h' = h + delta on the non-support vertices (values of 2h')
    delta = cp.Variable(len(nons), nonneg=True)
    h2p = {w: (h[w] * 2 + (delta[nons.index(w)] if w in nons else 0)) for w in W3}
    mob = mobius(h2p)
    key = lambda *idx: tuple(1 if k in idx else 0 for k in range(3))
    cons = [mob[(1, 1, 1)] == 0]
    c0, ci, cj, cs = mob[(0, 0, 0)], mob[key(i)], mob[key(j)], mob[key(s)]
    cij, cis, cjs = mob[key(i, j)], mob[key(i, s)], mob[key(j, s)]
    # Phi = -2 Gamma' ; empty-set polynomial in (p,t): coefficients of 1, p, t, p^2, pt, t^2
    phi0 = [-c0, -(ci + cj), -cs, -cij, -(cis + cjs), 0]

    types = [(a, b) for a in range(L + 1) for b in range(L + 1) if 1 <= a + b <= L]

    def prod(lmb, ab):
        return lmb[1] ** ab[0] * lmb[-1] ** ab[1]

    # positivity terms
    terms = []  # (name, poly6, aS(list), bS(list), cS(list))  aS: coeff of P^2, bS: half coeff of PT, cS: T^2

    def grid(lo, hi):
        return sorted(set([lo, hi] + list(np.linspace(lo, hi, ng))))

    rPP = {b: grid(*rho_range(q[b], q[b])) for b in (1, -1)}
    rTT = {b: grid(*rho_range(qs[b], qs[b])) for b in (1, -1)}
    rPT = {b: grid(*rho_range(q[b], qs[b])) for b in (1, -1)}
    for rp in rPP[1]:
        for rm in rPP[-1]:
            lm = {1: rp, -1: rm}
            v = [prod(lm, ab) for ab in types]
            terms.append((f"PP({rp:.3f},{rm:.3f})", [0, 0, 0, 1, 0, 0], v, [0] * len(v), [0] * len(v)))
            terms.append((f"P(1-P)({rp:.3f},{rm:.3f})", [0, 1, 0, -1, 0, 0], [-x for x in v], [0] * len(v), [0] * len(v)))
            terms.append((f"(1-P)(1-P)({rp:.3f},{rm:.3f})", [1, -2, 0, 1, 0, 0], v, [0] * len(v), [0] * len(v)))
    for rp in rTT[1]:
        for rm in rTT[-1]:
            lm = {1: rp, -1: rm}
            v = [prod(lm, ab) for ab in types]
            z = [0] * len(v)
            terms.append((f"TT({rp:.3f},{rm:.3f})", [0, 0, 0, 0, 0, 1], z, z, v))
            terms.append((f"T(1-T)({rp:.3f},{rm:.3f})", [0, 0, 1, 0, 0, -1], z, z, [-x for x in v]))
            terms.append((f"(1-T)(1-T)({rp:.3f},{rm:.3f})", [1, 0, -2, 0, 0, 1], z, z, v))
    for rp in rPT[1]:
        for rm in rPT[-1]:
            lm = {1: rp, -1: rm}
            v = [prod(lm, ab) / 2 for ab in types]
            z = [0] * len(v)
            terms.append((f"PT({rp:.3f},{rm:.3f})", [0, 0, 0, 0, 1, 0], z, v, z))
            terms.append((f"P(1-T)({rp:.3f},{rm:.3f})", [0, 1, 0, 0, -1, 0], z, [-x for x in v], z))
            terms.append((f"(1-P)T({rp:.3f},{rm:.3f})", [0, 0, 1, 0, -1, 0], z, [-x for x in v], z))
            terms.append((f"(1-P)(1-T)({rp:.3f},{rm:.3f})", [1, -1, -1, 0, 1, 0], z, v, z))
    nt = len(terms)
    c = cp.Variable(nt, nonneg=True)
    print("number of positivity terms:", nt)
    # R(p,t) = phi0 - sum c N^0  >= 0 on the square: R = m^T M m + sum alpha_k g_k
    Rco = [phi0[k] - sum(c[n] * terms[n][1][k] for n in range(nt)) for k in range(6)]
    M = cp.Variable((3, 3), PSD=True)
    al = cp.Variable(10, nonneg=True)
    # g: p, 1-p, t, 1-t, p(1-p), t(1-t), pt, p(1-t), (1-p)t, (1-p)(1-t) as coefficient vectors [1,p,t,p2,pt,t2]
    g = [[0, 1, 0, 0, 0, 0], [1, -1, 0, 0, 0, 0], [0, 0, 1, 0, 0, 0], [1, 0, -1, 0, 0, 0],
         [0, 1, 0, -1, 0, 0], [0, 0, 1, 0, 0, -1], [0, 0, 0, 0, 1, 0], [0, 1, 0, 0, -1, 0],
         [0, 0, 1, 0, -1, 0], [1, -1, -1, 0, 1, 0]]
    mm = [M[0, 0], 2 * M[0, 1], 2 * M[0, 2], M[1, 1], 2 * M[1, 2], M[2, 2]]
    for k in range(6):
        cons.append(Rco[k] == mm[k] + sum(al[n] * g[n][k] for n in range(10)))
    # Q_S PSD
    for idx, ab in enumerate(types):
        A = -cij * prod(lam[(i, j)], ab) - sum(c[n] * terms[n][2][idx] for n in range(nt))
        B = -(cis * prod(lam[(i, s)], ab) + cjs * prod(lam[(j, s)], ab)) / 2 - sum(c[n] * terms[n][3][idx] for n in range(nt))
        C = -sum(c[n] * terms[n][4][idx] for n in range(nt))
        Q = cp.Variable((2, 2), PSD=True)
        cons += [Q[0, 0] == A, Q[0, 1] == B, Q[1, 1] == C]
    prob = cp.Problem(cp.Minimize(cp.sum(c) + cp.sum(delta)), cons)
    prob.solve(solver="CLARABEL")
    print("status:", prob.status)
    if prob.status in ("optimal", "optimal_inaccurate"):
        print("delta (raise of 2h on non-support vertices):", dict(zip(nons, np.round(delta.value, 6))))
        for n in np.argsort(-c.value):
            if c.value[n] > 1e-7:
                print(f"  c={c.value[n]:.6g}  {terms[n][0]}")
        print("R coefficients [1,p,t,p2,pt,t2]:", [float(np.round(x.value if hasattr(x, 'value') else x, 8)) for x in Rco])


if __name__ == "__main__":
    main()
