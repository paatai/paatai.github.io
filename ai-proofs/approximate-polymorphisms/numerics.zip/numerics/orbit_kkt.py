"""First-order (KKT) conditions at the dictator decoder for the 14 orbit representatives of hard288 (Table 1 of the paper).

For h on {+-1}^3 (given as 2h, order +++, ..., ---, normalised to mu < 0, so a certificate is Gamma > 0) and its classes c,
the dictator decoder (F_c(z) = z_1 for every class, row 1 of sign +1) has Gamma = 0 because ||h||^2 = |mu|.  At this decoder
    dGamma / dF_c(z) = D_c(z_1) * prod_{i >= 2} pi_{nu_i}(w_j = z_i)   (any j in c),
since the partial derivatives of h at the dictator depend on row 1 only and the rows are independent; the marginal
pi_b(w_j = s) depends on j only through hat h({j}), i.e. through the class.  Here
    D_c(s) = sum_w pi_+(w) sum_{j in c, w_j = s} (d h / d y_j)(w)
is the derivative for k = 1.  If D_c(+1) > 0 > D_c(-1) for every class and all marginals are positive, then every admissible
direction (F_c(z) may only decrease where it is +1 and increase where it is -1) decreases Gamma at first order, so the
dictator is a strict local maximum of Gamma_nu for every k and every nu with nu_1 = +1.  Exact rational arithmetic.

For rep10 the derivative of the singleton class at s = -1 vanishes.  Gamma is affine in the decoder of a singleton class, so
Gamma = 0 on the whole face {F_{12} = dictator, F_3(z) = 1 for z_1 = +1, F_3(z) = t(z) in [-1,1] for z_1 = -1}; the script checks
(k = 1, exactly, at the endpoints and midpoint of the face) that the first-order conditions of the pair class stay strict on it.
For every k: at a face point, dGamma/dF_{12}(z) = A_1(z_1) prod_{i>=2} m(z_i)
    + sum_{j in {1,2}} alpha_j(z_1) sum_{z'} t(-1, z') prod_{i>=2} pi_{nu_i}(w_j = z_i, w_3 = z'_i),
with A_1 the k = 1 derivative at t = 0, m the common marginal of the class and
alpha_j(s) = sum_{w: w_j = s, w_3 = -1} pi_+(w) d^2 h / dy_j dy_3 (w).  As |t| <= 1 and the inner sums over z' of the pair laws
are the marginals, s * dGamma/dF_{12}(z) >= (s A_1(s) - sum_j |alpha_j(s)|) prod_{i>=2} m(z_i); the script checks exactly that
this margin is positive for s = +1 and s = -1, so the transversal first-order conditions hold strictly on the whole face, for
every k and every nu with nu_1 = +1.
"""
import itertools
import math
from fractions import Fraction as Fr

W3 = list(itertools.product([1, -1], repeat=3))
REPS = {
    'A12': (-2, -2, -2, 1, 0, -1, -1, -1), 'A24': (-2, -2, -1, 1, 0, 0, -1, -1), 'D12': (-1, -2, -2, 1, 0, -1, -1, 0),
    'B12': (-2, -1, -1, 1, 0, 0, 0, -1), 'C12': (-1, -2, -2, 1, -1, 0, 0, -1),
    'rep1': (-2, -2, -1, 0, -1, 1, 0, -1), 'rep2': (-2, -2, -1, 0, 1, -2, -1, -1), 'rep3': (-2, -2, -1, 1, 0, -1, -1, 0),
    'rep5': (-2, -1, -1, 0, 1, -2, 0, -1), 'rep6': (-2, -1, 0, -1, 1, -2, -1, 0), 'rep7': (-1, -2, -1, 0, 1, -2, -1, 0),
    'rep8': (-1, -2, -1, 0, 1, -2, 0, -1), 'rep9': (-1, -2, 0, -1, 1, -2, -1, 0), 'rep10': (-1, -2, 0, 0, 1, -1, -1, 0)}


def data(h2):
    h = {w: Fr(v, 2) for w, v in zip(W3, h2)}
    if sum(h.values()) > 0:
        h = {w: -v for w, v in h.items()}
    mu = sum(h.values()) / 8
    hh = {S: sum(h[w] * math.prod(w[j] for j in S) for w in W3) / 8
          for r in range(4) for S in itertools.combinations(range(3), r)}
    pi = {b: {w: (1 + b * h[w]) / (8 * (1 + b * mu)) for w in W3} for b in (1, -1)}
    classes = {}
    for j in range(3):
        classes.setdefault(hh[(j,)], []).append(j)
    return h, mu, hh, pi, list(classes.values())


def dh(hh, j, y):
    return sum(c * math.prod(y[i] for i in S if i != j) for S, c in hh.items() if j in S)


def d2h(hh, j, l, y):
    return sum(c * math.prod(y[i] for i in S if i not in (j, l)) for S, c in hh.items() if j in S and l in S)


def hml(hh, y):
    return sum(c * math.prod(y[i] for i in S) for S, c in hh.items())


def derivs(hh, pi, classes, F):
    """k = 1, nu = +1: dGamma/dF_c(s) for class-wise decoders F[c][s] (index c into classes)."""
    out = {}
    for ci, cl in enumerate(classes):
        for s in (1, -1):
            tot = Fr(0)
            for w in W3:
                y = tuple(F[next(i for i, c2 in enumerate(classes) if j in c2)][w[j]] for j in range(3))
                tot += pi[1][w] * sum(dh(hh, j, y) for j in cl if w[j] == s)
            out[(ci, s)] = tot
    return out


def gamma1(hh, pi, classes, F):
    cls_of = {j: ci for ci, cl in enumerate(classes) for j in cl}
    return sum(pi[1][w] * hml(hh, tuple(F[cls_of[j]][w[j]] for j in range(3))) for w in W3)


if __name__ == '__main__':
    for name, h2 in REPS.items():
        h, mu, hh, pi, classes = data(h2)
        assert sum(v * v for v in hh.values()) == -mu                      # boundary: ||h||^2 = |mu|
        dict_dec = [{1: Fr(1), -1: Fr(-1)} for _ in classes]
        assert gamma1(hh, pi, classes, dict_dec) == 0
        marg_pos = all(1 + b * (mu + s * hh[(j,)]) > 0 for b in (1, -1) for s in (1, -1) for j in range(3))
        D = derivs(hh, pi, classes, dict_dec)
        strict = all(D[(ci, 1)] > 0 > D[(ci, -1)] for ci in range(len(classes)))
        print(f"{name:6s} classes={[tuple(j + 1 for j in cl) for cl in classes]}  marginals>0: {marg_pos}  "
              + "  ".join(f"D_{ci}(+)={D[(ci, 1)]}, D_{ci}(-)={D[(ci, -1)]}" for ci in range(len(classes)))
              + f"  strict: {strict}")
        if not strict:
            zero = [(ci, s) for (ci, s), v in D.items() if v == 0]
            for ci, s in zero:
                assert len(classes[ci]) == 1, "flat direction only expected for a singleton class"
            other = [i for i in range(len(classes)) if i not in [ci for ci, _ in zero]]
            for t in (Fr(-1), Fr(0), Fr(1)):
                F = [dict(d) for d in dict_dec]
                for ci, s in zero:
                    F[ci][s] = t
                assert gamma1(hh, pi, classes, F) == 0
                Dt = derivs(hh, pi, classes, F)
                ok = all(Dt[(i, 1)] > 0 > Dt[(i, -1)] for i in other)
                print(f"        face point F_c(s)={t} for the flat (c,s)={[(classes[ci][0] + 1, s) for ci, s in zero]}: "
                      f"Gamma=0, other classes: " + ", ".join(f"D_{i}(+)={Dt[(i, 1)]}, D_{i}(-)={Dt[(i, -1)]}" for i in other)
                      + f", strict: {ok}")
            assert len(zero) == 1
            (c0, s0), j0 = zero[0], classes[zero[0][0]][0]
            F0 = [dict(d) for d in dict_dec]
            F0[c0][s0] = Fr(0)
            A1 = derivs(hh, pi, classes, F0)
            for i in other:
                for b in (1, -1):
                    assert len({sum(p for w, p in pi[b].items() if w[j] == 1) for j in classes[i]}) == 1
                for s in (1, -1):
                    alpha = [sum(pi[1][w] * d2h(hh, j, j0, w) for w in W3 if w[j] == s and w[j0] == s0)
                             for j in classes[i]]
                    margin = s * A1[(i, s)] - sum(abs(a) for a in alpha)
                    assert margin > 0
                    print(f"        every k: class {tuple(j + 1 for j in classes[i])}, s={s:+d}: s*A_1={s * A1[(i, s)]}, "
                          f"alpha_j={alpha}, s*dGamma/dF(z) >= {margin} * prod_(i>=2) marginals > 0 on the whole face")
