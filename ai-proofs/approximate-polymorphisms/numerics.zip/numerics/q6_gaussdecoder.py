"""'Gaussian decoders' on many label rows: low-influence F applied to the columns of k >> 1 rows
drawn from pi_b behaves like Ftilde(H_j) with H a Gaussian vector having the column correlation
matrix of pi_b.  Test thresholds Ftilde = sgn(y - theta) (n = 1) for the hard candidates.
"""
import itertools
import sys
import numpy as np
from scipy.stats import multivariate_normal

d, r = int(sys.argv[1]), int(sys.argv[2])
ncand = int(sys.argv[3]) if len(sys.argv) > 3 else 10
H = np.load(f'outputs/hard_h_d{d}_r{r}.npy')[:ncand]
P = np.array(list(itertools.product([1, -1], repeat=d)))
n = len(P)


def orthant_probs(Sigma, thetas):
    """P[sgn(H_j - theta_j) = y_j for all j] for all y in P."""
    out = np.zeros(n)
    for i, y in enumerate(P):
        # P[y_j (H_j - theta_j) > 0] = P[-y_j H_j < -y_j theta_j]
        D = np.diag(-y)
        S = D @ Sigma @ D
        out[i] = multivariate_normal(mean=np.zeros(d), cov=S, allow_singular=True).cdf(-y * thetas)
    return out


for t, hv in enumerate(H):
    h = -hv if hv.mean() > 0 else hv
    mu = h.mean()
    best = (-9, None)
    for b in (1, -1):
        pi = (1 + b * h) / (n * (1 + b * mu))
        m1 = P.T @ pi
        M2 = (P * pi[:, None]).T @ P
        cov = M2 - np.outer(m1, m1)
        sd = np.sqrt(np.diag(cov))
        Sig = cov / np.outer(sd, sd)
        for theta in np.linspace(-3, 3, 61):
            pr = orthant_probs(Sig, np.full(d, theta))
            v = pr @ h
            if v > best[0]:
                best = (v, (b, theta))
    print(t, 'h', np.round(h, 2).tolist(), 'best Gaussian-threshold decoder', round(best[0], 5), best[1])
