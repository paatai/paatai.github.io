"""Exact verification of the middle case of the biased L1-Khintchine inequality (Theorem K).

Setting (q = 3/8): chi = u w.p. q, -v w.p. 1-q, u = sqrt(5/3), v = sqrt(3/5), tau = sqrt(15)/8.
For L = a chi_1 + b M (a^2 + b^2 = 1, M independent, E M = 0, E M^2 = 1):

    E|L| = 2 tau a + 2 b E Phi_t(M),   Phi_t(m) = (5/8)(m - t)_+ + (3/8)(-m - 5t/3)_+,

with s = a/b and t = s v (so that s u = 5t/3).  E|L| <= 2 tau  <=>  E Phi_t(M) <= R(s),
R(s) = tau (sqrt(1+s^2) - s).  Under the induction hypothesis E|M| <= 2 tau, a dual
certificate (l0, l1, l2, mu), mu >= 0, with

    g(m) = l0 + l1 m + l2 m^2 + mu |m| - Phi_t(m) >= 0   for all real m

gives E Phi_t(M) <= l0 + l2 + 2 tau mu.  Phi_t is pointwise nonincreasing in t and R is
decreasing in s, so a certificate at t_i whose value is <= R(s_{i+1}) covers the whole cell
[t_i, t_{i+1}].  All checks below are in exact rational arithmetic (square roots enclosed by
rational bounds).  The cells cover t in [6/25, 4/5], which contains t(a) = a v / sqrt(1-a^2)
for every a in [3/10, 5/7].

Usage: python3 khintchine_certificates.py [N_cells]
"""
import sys
from fractions import Fraction as Fr
from math import isqrt

import numpy as np
from scipy.optimize import linprog

K = 40  # decimal digits for square-root enclosures


def sqrt_bounds(x: Fr):
    """Rational lo <= sqrt(x) <= hi."""
    p, r = x.numerator, x.denominator
    scale = 10 ** K
    lo_int = isqrt(p * r * scale * scale)
    lo = Fr(lo_int, r * scale)
    hi = Fr(lo_int + 1, r * scale)
    assert lo * lo <= x <= hi * hi
    return lo, hi


SQ15_LO, SQ15_HI = sqrt_bounds(Fr(15))
TAU_LO, TAU_HI = SQ15_LO / 8, SQ15_HI / 8
SQ53_LO, SQ53_HI = sqrt_bounds(Fr(5, 3))
Q, P = Fr(3, 8), Fr(5, 8)


def pieces(t, l0, l1, l2, mu):
    """g on its four pieces as (A, B, C, left, right) meaning A m^2 + B m + C on [left, right]."""
    c = Fr(5, 8) * t  # = (3/8)(5t/3) = (5/8) t
    return [
        (l2, l1 - mu + Q, l0 + c, None, -Fr(5, 3) * t),
        (l2, l1 - mu, l0, -Fr(5, 3) * t, Fr(0)),
        (l2, l1 + mu, l0, Fr(0), t),
        (l2, l1 + mu - P, l0 + c, t, None),
    ]


def quad_min(A, B, C, left, right):
    assert A > 0
    cands = []
    vtx = -B / (2 * A)
    if (left is None or vtx >= left) and (right is None or vtx <= right):
        cands.append(vtx)
    for e in (left, right):
        if e is not None:
            cands.append(e)
    return min(A * x * x + B * x + C for x in cands)


def exact_min_g(t, cert):
    return min(quad_min(*pc) for pc in pieces(t, *cert))


def numeric_dual(t, tau=np.sqrt(15) / 8, M=6.0, n=6001):
    m = np.linspace(-M, M, n)
    m = np.unique(np.concatenate([m, [-5 * t / 3, 0.0, t]]))
    phi = 0.625 * np.maximum(m - t, 0) + 0.375 * np.maximum(-m - 5 * t / 3, 0)
    # variables l0, l1, l2, mu ; minimise l0 + l2 + 2 tau mu ; constraints -(...) <= -phi
    A_ub = -np.stack([np.ones_like(m), m, m ** 2, np.abs(m)], axis=1)
    res = linprog([1.0, 0.0, 1.0, 2 * tau], A_ub=A_ub, b_ub=-phi,
                  bounds=[(None, None), (None, None), (0, None), (0, None)], method="highs")
    assert res.status == 0, res.message
    return res.x


def certificate(t: Fr):
    x = numeric_dual(float(t))
    l0, l1, l2, mu = (Fr(float(z)).limit_denominator(10 ** 12) for z in x)
    if l2 <= 0:
        l2 = Fr(1, 10 ** 12)
    if mu < 0:
        mu = Fr(0)
    deficit = exact_min_g(t, (l0, l1, l2, mu))
    if deficit < 0:
        l0 -= deficit
    l0 += Fr(1, 10 ** 12)
    cert = (l0, l1, l2, mu)
    assert exact_min_g(t, cert) >= 0
    value_hi = l0 + l2 + 2 * TAU_HI * mu
    return cert, value_hi


def rhs_lo(t: Fr):
    """Lower bound for R(s) = tau / (sqrt(1+s^2) + s) at s = t sqrt(5/3)."""
    _, root_hi = sqrt_bounds(1 + Fr(5, 3) * t * t)
    return TAU_LO / (root_hi + t * SQ53_HI)


def main():
    N = int(sys.argv[1]) if len(sys.argv) > 1 else 560
    t0, t1 = Fr(6, 25), Fr(4, 5)
    a_lo, a_hi = Fr(3, 10), Fr(5, 7)
    # the cells must cover t(a) for a in [a_lo, a_hi]; t(a) = a v / sqrt(1-a^2) is increasing
    v_lo, v_hi = sqrt_bounds(Fr(3, 5))
    t_of_alo_lo = a_lo * v_lo / sqrt_bounds(1 - a_lo * a_lo)[1]
    t_of_ahi_hi = a_hi * v_hi / sqrt_bounds(1 - a_hi * a_hi)[0]
    assert t0 <= t_of_alo_lo and t_of_ahi_hi <= t1, (float(t_of_alo_lo), float(t_of_ahi_hi))
    grid = [t0 + (t1 - t0) * Fr(i, N) for i in range(N + 1)]
    worst = None
    for i in range(N):
        cert, val = certificate(grid[i])
        rhs = rhs_lo(grid[i + 1])
        margin = rhs - val
        assert margin > 0, (i, float(grid[i]), float(val), float(rhs))
        if worst is None or margin < worst[0]:
            worst = (margin, i, val, rhs, cert)
        if i % max(1, N // 14) == 0:
            print(f"cell {i:4d}  t in [{float(grid[i]):.5f},{float(grid[i+1]):.5f}]  "
                  f"cert value <= {float(val):.6f}   R >= {float(rhs):.6f}   margin {float(margin):.6f}",
                  flush=True)
    m, i, val, rhs, cert = worst
    print(f"ALL {N} CELLS VERIFIED (exact rational arithmetic).")
    print(f"worst cell {i}: t in [{float(grid[i]):.5f},{float(grid[i+1]):.5f}], value {float(val):.6f}, "
          f"R {float(rhs):.6f}, margin {float(m):.3e}")
    print("worst certificate (l0, l1, l2, mu) =", [str(c) for c in cert])


if __name__ == "__main__":
    main()
