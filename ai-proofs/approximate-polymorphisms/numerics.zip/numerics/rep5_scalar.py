"""rep5: two level-weight relaxations of (R5) that FAIL (floating point; a record of the failure point, not a proof).

In the biased Fourier basis common to the three columns, (R5) is Psi(P,B) >= 0 for P, B: {-1,1}^k -> [0,1] with
    Psi(P,B) = 2p^2 - 2pb + b + sum_{S != empty} (2 lam2^S Phat(S)^2 - 2 lamv^S Phat(S) Bhat(S)),
lam2 = -1/4, 1/12 and lamv = 7/12, -17/60 per row (nu_i = +1, -1), p = E P, b = E B.  Bound every level other than the
singletons of the nu = +1 rows by AM-GM with weights for which the coefficients are at most 31/144 (P) and 49/144 (B), the
values at S = {r,s}, nu_r = nu_s = +1, as needed for equality at AND2.  With A = W_+(P), W = W_+(B), X = sum_{i: nu_i=+1}
Phat(i)Bhat(i), V = Var P, B {0,1}-valued (Var B = b - b^2):
    Psi >= G = 2p^2 - 2pb + b - A/2 - (7/6)X - (31/144)(V - A) - (49/144)(b - b^2 - W),
with V <= p - p^2, A <= min(V, (2/5)(V + p^2) + p^2/2) and W <= min(b - b^2, (2/5)b + b^2/2) (Theorem L, q = 2/5).
  relaxation 1: X <= sqrt(A W) (Cauchy-Schwarz);
  relaxation 2: also Theorem L for the nonnegative functions P + cB, c > 0, with E[PB] <= min(p, b):
      2cX <= (2/5)(E P^2 + 2c E[PB] + c^2 b) + (p + cb)^2/2 - A - c^2 W.
Both minima of G over the constraints are negative (about -0.023 and -0.015, at p ~ 0.1, b ~ 0.025), so these
constraints do not imply (R5).  The relaxation is tight at P = B = dictator, AND2 and 1{z = (1,-1)} (G = 0 there).
usage: python3 rep5_scalar.py [grid]
"""
import sys

import numpy as np

CS = np.concatenate([np.linspace(0.01, 1, 100), np.linspace(1, 20, 200)])


def g_value(p, b, A, W, X):
    V = p - p * p
    return 2 * p * p - 2 * p * b + b - A / 2 - 7 / 6 * X - 31 / 144 * (V - A) - 49 / 144 * (b - b * b - W)


def minimum(p, b, relax, n=30):
    V = p - p * p
    amax = min(V, 0.4 * (V + p * p) + p * p / 2)
    wmax = min(b - b * b, 0.4 * b + b * b / 2)
    worst = np.inf
    for A in np.linspace(0, amax, n):
        for W in np.linspace(0, wmax, n):
            X = np.sqrt(A * W)
            if relax == 2:
                X = min(X, ((0.4 * (V + p * p + 2 * CS * min(p, b) + CS * CS * b) + 0.5 * (p + CS * b) ** 2 - A - CS * CS * W)
                            / (2 * CS)).min())
            worst = min(worst, g_value(p, b, A, W, X))
    return worst


def main():
    grid = int(sys.argv[1]) if len(sys.argv) > 1 else 41
    pts = np.linspace(0, 1, grid)
    q = 0.4
    for p0, a0, name in [(q, q * (1 - q), "dictator"), (q * q, 2 * q ** 3 * (1 - q), "AND2"),
                         (q * (1 - q), (1 - q) ** 3 * q + q ** 3 * (1 - q), "1{z=(1,-1)}")]:
        print(f"P = B = {name}: p = {p0:.4f}, W_+ = {a0:.4f} (Theorem L bound {q * p0 + p0 * p0 / 2:.4f}), "
              f"G = {g_value(p0, p0, a0, a0, a0):.2e}")
    for relax in (1, 2):
        best = min((minimum(p, b, relax), p, b) for p in pts for b in pts)
        print(f"relaxation {relax}: min G = {best[0]:.6f} at p = {best[1]:.4f}, b = {best[2]:.4f}")


if __name__ == "__main__":
    main()
