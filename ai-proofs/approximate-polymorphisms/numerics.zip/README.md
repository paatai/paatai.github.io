# Numerical checks for "Approximate polymorphisms" (`approximate-polymorphisms.pdf`)

Scripts behind the exact and numerical checks in the paper. In the docstrings `MAIN_RESULT`
refers to the paper, and theorem, proposition and section numbers are the paper's. Scripts
described as exact use integer or rational arithmetic (or certified enclosures) and back
statements in the paper; floating-point searches and LPs are exploration, and their positive
results are re-checked exactly by the corresponding exact script.

## Requirements

Python 3 with `numpy`, `scipy` (HiGHS LP/MILP), `sympy`, `mpmath`, `python-flint`, `networkx`;
`cert_sdp.py` also needs `cvxpy`.

```bash
pip install numpy scipy sympy mpmath python-flint networkx cvxpy
```

## Running

Run from the `numerics/` directory, for example

```bash
cd numerics
python3 q6_g0.py              # the explicit boundary function g0 (Theorem E), exact
python3 rep1_coupling.py      # the coupling proof for orbit rep1, exact
python3 khintchine_q_check.py # constants in the proof of Theorem K, exact
```

Scripts take their parameters from the command line where noted in the docstring. The saved
output of each run is in `outputs/` (`outputs/<script>[_<parameters>].txt`); some scripts read
earlier outputs from there (for example `m9_struct_search.py` reads `outputs/m9_open.txt`).

## Scripts

| script | what it checks |
| --- | --- |
| `b12_cert.py` | Exact check of the seven-column one-class coupling certificate for B12 (Proposition "B12" in Section 11 of MAIN_RESULT.tex): B12 is trivial, i.e. |
| `cert_sdp.py` | SDP search for coupling certificates of triviality, class-wise formulation, two-class h on {-1,1}^3. |
| `class_flips.py` | Class flips of the 14 orbit representatives of hard288 (exact arithmetic). |
| `classwise_ascent.py` | Coordinate-ascent search for class-wise certificates (Theorem C(iii) / D(c)) for the two-class orbits of hard288. |
| `classwise_tight.py` | Tight cases of the class-wise inequality Phi_delta(P,T) >= 0 for rep3 (numerical exploration). |
| `coupling_designs.py` | Search for coupling-design certificates (paragraph "Coupling designs" in Section 11 of MAIN_RESULT.tex) for the two-class boundary orbits, m = 5. |
| `coupling_lp3.py` | Exploration (floating point): coupling LP with three-copy "triangle" constraints, one class of size two, eps = 1. |
| `coupling_lp_J2.py` | Coupling LP bound for one class of size two (UNDEC candidates of maxcorr_J2.py, case eps = 1). |
| `coupling_lp_dual.py` | Inspect optimal LP duals of the coupling LP (coupling_lp_J2.py) at given p for given candidates. |
| `coupling_lp_m9.py` | Coupling LP (two-copy constraints) for all 17 pairs of open one-class \|J\| = 2 candidates with m = 9 (floating point). |
| `coupling_search.py` | Which two-class boundary orbits (m = 5) yield to the re-coupling argument of Proposition "rep3" (Section 11)? |
| `d12_check.py` | Theorem L (level-one inequality for nonnegative functions on the q-biased cube) and the boundary orbit D12. |
| `e2_check.py` | Re-verification of earlier numerical values for E2, and first exploration. |
| `e2_halfspace_angles.py` | Exploration (floating point): is the collinear configuration (sgn, sgn, -sgn) a local maximum of val among halfspace configurations for g = E2? |
| `e2_label_roles.py` | Labelled constructions for E2 with two roles: Q_z = sgn if f(z) = 1 and Q_z = -sgn if f(z) = 0, for f : {-1,1}^k -> {0,1}. |
| `e2_lower_rig.py` | Rigorous lower bounds for s^U_E2 and s_E2 (Theorem A(b),(c)) from q = (sgn, sgn, -sgn), n = 1. |
| `e2_rigorous.py` | Rigorous checks for g = E2 ("exactly two of three inputs are +1"). |
| `e2_sU_opt1d.py` | Numerical exploration: is (sgn, sgn, -sgn) optimal for s^U_{E2} among one-dimensional test functions? |
| `e2_upper_cells.py` | Prototype (floating point): cell-based LP for the separable majorant (rigorous version: e2_upper_rig.py). |
| `e2_upper_herm.py` | Exploration: pointwise bound on gamma via Hermite expansion + level-one inequality + Gram constraint, then the separable convex majorant LP (as in e2_upper_maj.py). |
| `e2_upper_maj.py` | Exploration: upper bound on s^U_{E2} by majorization (Borell) + separable convex majorant. |
| `e2_upper_ridge.py` | Exploration (floating point, not rigorous): ridge majorants for Theorem 4.5. |
| `e2_upper_rig.py` | Rigorous computer part of Theorem 4.5 (upper bound on s^U_{E2}). |
| `e2_upper_sanity.py` | Sanity test of the pointwise bound gamma <= Gamma(m) (Lemma 4.6) on explicit configurations. |
| `eps_designs.py` | Best bound eps(N) proved by coupling designs with N columns (floating point, scipy.milp / HiGHS). |
| `formula_envelope.py` | Read-once "formula" decoders for one class of size two, all label rows of the dangerous sign nu_* (floating point). |
| `fplus_check.py` | Exact check of the worked examples of the refined criterion: the paragraph "Examples" after Corollary 10.8 (cor:J2small) in Section 10, i.e. |
| `fpp_test.py` | Numerical test of strengthened brackets for the 22 UNDEC candidates (r = 6) of maxcorr_J2.py. |
| `fsharp_check.py` | Exact minima of Phi# (Proposition 10.6) for the 18 m = 8 candidates in class F# of Proposition 10.7, and the worked example h = (-23/32, 1/8, 1/8, -3/32) quoted in the text (the candidate with the smallest minimum). |
| `fsharp_sanity.py` | Sanity check of the coupling bound of Proposition 10.6 on random decoders (floating point): sigma Gamma_nu(F) >= sigma h(2p-1,2p-1) - 4\|b\| a min{p(1-p), theta p(1-p) + (1-theta) min(p,1-p)^2 / r}, p = (1 + E F(X))/2, for the 22 m = 8 candid |
| `g0_check.py` | The explicit m = 5 boundary function g0 of Theorem E (MAIN_RESULT, Section 9; orbit "A12" of hard288). |
| `g0_coord_ascent.py` | Search for labelled certificates at x = infinity for the boundary function g0, with many labels. |
| `g0_finite_x.py` | Numerical test of the conjecture s_{g0} = triv at finite x (one label bit, n = 1). |
| `g0_pairwise_test.py` | Numerical test of the pairwise inequality (*) for the boundary function g0. |
| `g1_check.py` | The second explicit m = 5 boundary function g1 (MAIN_RESULT, Section 9.6; orbit "A24" of hard288). |
| `gF_check.py` | Exact checks for the explicit function g_F on 6 variables: Proposition 10.3 (prop:gF) in Section 10 (Section 10.1; Theorem F, \|J\| = 2). |
| `hard288_orbits.py` | Orbit structure of the 288 boundary functions under the symmetries of the nontriviality question. |
| `j2_ascent.py` | Coordinate-ascent search for single-decoder certificates for a one-class h on {+-1}^2 (\|J\| = 2). |
| `j2_cert_polish.py` | Certificate search with exact polishing for one-class candidates h = (x, z, z, y) (mu < 0, so a certificate is Gamma > 0). |
| `j2_cert_search.py` | Search for single-decoder certificates (Gamma > 0, mu < 0) for one-class candidates h = (x, z, z, y), and verify the best Boolean decoders exactly. |
| `j2_k2_exact.py` | Exact maximum of Gamma_nu(F) over all continuous decoders F : {+-1}^k -> [-1,1] (k = 1, 2, optionally 3) for one-class h = (x, z, z, y) on {+-1}^2, in rational arithmetic. |
| `khintchine_L1_test.py` | Numerical test of the biased L1-Khintchine inequality (Theorem K of MAIN_RESULT). |
| `khintchine_analytic_check.py` | Sanity checks (floating point) for the analytic proof of Theorem K (q = 3/8). |
| `khintchine_certificates.py` | Exact verification of the middle case of the biased L1-Khintchine inequality (Theorem K). |
| `khintchine_interval.py` | Theorem K for every q in [3/8, 1/2]: exact verification of the two q-dependent steps of the proof (Section 9.4). |
| `khintchine_moment_lp.py` | Moment-problem bound for the inductive step of the biased L1-Khintchine inequality. |
| `khintchine_q_check.py` | Exact verification of the constants in the proof of Theorem K for q in {3/8, 2/5, 5/12}. |
| `khintchine_threshold.py` | Where does Theorem K (E\|sum a_i chi_i\| <= E\|chi\| = 2 tau for unit a) stop holding as q decreases below 3/8? |
| `level1_bellman.py` | Minimal Bellman function for the level-1 vector on the q-biased cube (q = 3/8). |
| `level1_profile_test.py` | Numerical test of p-dependent level-one inequalities on the q-biased cube (floating point). |
| `m8_check.py` | Exact checks for the two nontrivial m = 8 candidates with \|J\| = 2 found after Proposition 10.6. |
| `m9_gauss_limit.py` | Gaussian limit of threshold decoders for the 17 open m = 9 pairs (floating point, exploratory). |
| `m9_k4_rig.py` | Rigorous version of m9_k4_scan.py: for the 17 pairs of one-class \|J\| = 2 candidates left open at m = 9 (one of each mirror pair), every [-1,1]-valued decoder with k labels has Gamma_nu(F) < 0, for every nu. |
| `m9_k4_rig_check.py` | Test of the floating-point enclosures of m9_k4_rig.py against exact rational arithmetic (python-flint): for random free sets and random assignments of the fixed coordinates, the exact critical point -H^{-1} b and its value base + b . |
| `m9_k4_scan.py` | Exhaustive search for certificates with k = 4 for the 17 pairs of one-class \|J\| = 2 candidates left open at m = 9 (floating point). |
| `m9_mixed_limit.py` | Mixed limit for the 17 open m = 9 pairs: k0 label rows read exactly plus a Gaussian part (floating point, exploratory). |
| `m9_open.py` | The 34 one-class \|J\| = 2 candidates for m = 9 (r = 7) left undecided by Proposition 10.7's methods (class UNDEC in outputs/maxcorr_J2_r7.txt, produced by `python3 maxcorr_J2.py 7`). |
| `m9_struct_search.py` | Global search over structured decoders for the 34 open m=9 candidates (\|J\|=2, one class; numerics/outputs/m9_open.txt). |
| `majorant_k3_exact.py` | Exact maximum of E[h'(Y)] over all [-1,1]-valued class-wise decoders with k <= 3 labels, for the majorants h' >= h of the reductions for rep5 and rep10 (MAIN_RESULT.pdf, Section 11), in exact rational arithmetic (python-flint), by the face  |
| `maxcorr_J2.py` | Theorem F (maximal-correlation criterion) for \|J\| = 2: exact classification of one-class h on {+-1}^2. |
| `milp_designs.py` | Exhaustive search for coupling-design certificates with N columns as one mixed-integer linear programme (scipy.milp / HiGHS, floating point). |
| `oneclass_analysis.py` | Exact data for the one-class orbits of the 288 boundary functions (m = 5, \|J\| = 3). |
| `oneclass_certs.py` | Exact checks of the one-class coupling certificates for A24 (= the orbit of g1; three columns) and C12 (four columns, two copies of the row), Remark "one-class designs" in Section 11 of MAIN_RESULT.tex. |
| `oneclass_designs.py` | Search for coupling-design certificates for the one-class boundary orbits (m = 5), in particular B12. |
| `oneclass_full.py` | Necessary condition for one-class coupling designs (oneclass_designs.py) with N columns, for one-class h with two distinct pair laws (L1 on the pairs {1,2},{1,3}, L2 on {2,3}; B12, C12, D12, A12). |
| `orbit_coord_ascent.py` | Coordinate-ascent search for single-decoder certificates (Theorem D(d)) for the orbit representatives of hard288. |
| `orbit_k2_exact.py` | Exact maximum of Gamma_nu over all [-1,1]-valued class-wise decoders with k <= kmax for the two-class boundary orbits (m = 5, \|J\| = 3; Table 1 of MAIN_RESULT.pdf), in rational arithmetic. |
| `orbit_k3_exact.py` | Exact maximum of Gamma_nu over all [-1,1]-valued class-wise decoders with k = 3 for the nine two-class boundary orbits (m = 5, \|J\| = 3), in exact rational arithmetic (python-flint fmpq / fmpq_mat). |
| `orbit_kkt.py` | First-order (KKT) conditions at the dictator decoder for the 14 orbit representatives of hard288 (Table 1 of the paper). |
| `polymorph.py` | Core numerics for the list-decoding thresholds s_g of approximate polymorphisms. |
| `q6_contlabels.py` | Continuous optimisation of label decoders at x = infinity. |
| `q6_d4r1.py` | Exact classification of the m = 5 functions with \|J\| = 4, \|U\| = 1 (the case not covered by q6_hsearch.py). |
| `q6_deeplabels.py` | Deeper label constructions for candidate hard h (from q6_hsearch.py). |
| `q6_enum_fast.py` | Faster Q6 enumeration for m = 4 (or 3): canonical classes under S_m x <input negation> x <output negation>, then the s^U criterion and the 'infinity' constructions L0 / labels (see q6_enumerate.py). |
| `q6_enumerate.py` | Q6 exploration: for every g on m bits (mu != 0, depends on all coords, not +-parity), compute * J = {j : ghat({j}) != 0}, h(w) = E_u g(w,u) on {+-1}^J, * the s^U criterion (exists w: sgn(mu) h(w) < 0), * 'infinity' constructions: (L0) no la |
| `q6_exact.py` | Exact (integer-arithmetic) classification of s_g-nontriviality for all g : {-1,1}^m -> {-1,1}, m <= 4. |
| `q6_exact_k2.py` | Exact (integer) version of q6_deeplabels.py for the 348 boundary candidates (d=3, r=2). |
| `q6_exact_k2_lib.py` | Exact (integer) version of q6_deeplabels.py for the 348 boundary candidates (d=3, r=2). |
| `q6_g0.py` | The explicit m = 5 boundary function g0 (MAIN_RESULT, Section 9.1; Theorem E). |
| `q6_g0_variation.py` | First variation of Gamma_+ at the dictator decoder (k=1) for the boundary example g0 (exact). |
| `q6_gaussdecoder.py` | 'Gaussian decoders' on many label rows: low-influence F applied to the columns of k >> 1 rows drawn from pi_b behaves like Ftilde(H_j) with H a Gaussian vector having the column correlation matrix of pi_b. |
| `q6_hard288.py` | Write the 288 m=5 boundary functions h (\|J\|=3) that have no certificate with k<=2 labels (exact, as in q6_exact_k2.py) to outputs/hard288.txt, one per line, values of 2h on (+++,++-,+-+,+--,-++,-+-,--+,---). |
| `q6_hsearch.py` | Search for 'hard' g: s^U criterion holds but the simple constructions (L0, Lab1) fail. |
| `q6_realise_check.py` | Exact checks on the 348 boundary candidates h (d=3, r=2) from q6_hsearch.py: (1) each is realisable as h(w) = E_u g(w,u) by some g on 5 variables with ghat({u1}) = ghat({u2}) = 0 and g depending on u1 and u2 (exact DP over the choices of th |
| `rep10_majorant.py` | rep10: the largest admissible majorant h'' = h + 1_{++-} and its one-function form (T10) (Section 11, paragraph "Exact forms for rep5 and rep10"). |
| `rep1_coupling.py` | Exact verification of the cubic coupling proof that the orbit rep1 (2h = (-2,-2,-1,0,-1,1,0,-1), classes {1},{2,3}) is trivial (Proposition "rep1" in Section 11 of MAIN_RESULT.tex), and hence also rep9 (class flip). |
| `rep2_coupling.py` | Exact verification of the four-column coupling proof that the orbit rep2 (2h = (-2,-2,-1,0,1,-2,-1,-1), classes {1,2},{3}) is trivial (Proposition "rep2" in Section 11 of MAIN_RESULT.tex), and hence also A12 = orbit of h_{g0} (class flip). |
| `rep3_coupling.py` | Exact verification of the coupling proof that the orbit rep3 (2h = (-2,-2,-1,1,0,-1,-1,0), classes {1,3},{2}) is trivial (Proposition "rep3" in Section 11 of MAIN_RESULT.tex), and hence also rep8 (class flip). |
| `rep3_star.py` | Numerical test of the relaxed class-wise inequality for the orbit rep3 (2h = (-2,-2,-1,1,0,-1,-1,0), classes {1,3},{2}). |
| `rep510_ascent.py` | rep5 and rep10: alternating maximisation of Gamma_nu(F_p, F_s) for larger k (floating point). |
| `rep510_boolean.py` | rep5 and rep10: exhaustive exact check of (rep5ex), (R5), (rep10ex), (rep10maj) for every {0,1}-valued P with k = 4 and k = 5. |
| `rep510_exact.py` | rep5 and rep10: exact one-function forms of triviality (Section 11, paragraph "Exact forms for rep5 and rep10"). |
| `rep510_k4_boolean.py` | rep5 and rep10, k = 4: exact check of the one-function forms (rep5ex), (rep10ex) for every {0,1}-valued P. |
| `rep510_k4_half.py` | rep5 and rep10, k = 4: the one-function inequalities (rep5ex), (R5), (rep10ex), (rep10maj) for every P with values in {0, 1/2, 1} (all 3^16 of them) and every nu, in exact integer arithmetic. |
| `rep5_reduction.py` | rep5: exact checks of the reduction to a two-function inequality (Remark rem:rep5 of Section 11). |
| `rep5_relax.py` | rep5 with the cubic-free majorant h' = h + t1*1_{+++} + t2*1_{-+-}, t1 + t2 = 1, d = t1 - t2 (floating point). |
| `rep5_scalar.py` | rep5: two level-weight relaxations of (R5) that FAIL (floating point; a record of the failure point, not a proof). |
| `rep6_coupling.py` | Exact verification of the six-column coupling proof that the orbit rep6 (2h = (-2,-1,0,-1,1,-2,-1,0), classes {1,2},{3}) is trivial (Proposition "rep6" in Section 11 of MAIN_RESULT.tex), and hence also C12 (class flip). |
| `rep7_coupling.py` | Exact verification of the five-column coupling proof that the orbit rep7 (2h = (-1,-2,-1,0,1,-2,-1,0), classes {1,2},{3}) is trivial (Proposition "rep7" in Section 11 of MAIN_RESULT.tex), and hence also A24 = orbit of h_{g1} (class flip). |
| `sharp_test.py` | Numerical test of the single-coupling bound (case eps = 1, one dangerous sign nu_*): -Cov(P(X),P(Z)) <= a * min{ p(1-p), theta p(1-p) + (1-theta) K / r }, K = min(p^2, (1-p)^2), theta = max(theta_a, theta_even), theta_a = (r-a)/(1+r), theta |
| `split_bound.py` | Exploration (floating point): recursive split lower bound for inf E[P(X) P(Z)], one class of size two, eps = 1. |
| `tcoupling_test.py` | One-parameter coupling bound for one class of size two, case eps = 1 (numerical test). |
| `thmF_boundary.py` | Theorem F and the 288 boundary functions (exact arithmetic). |
| `thmL_sharpness.py` | Sharpness of Theorem L (Section 9.7): equality cases, ANDs of t coordinates, small means. |
