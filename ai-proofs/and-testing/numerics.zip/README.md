# Numerical checks for "AND testing" (`and-testing-sqrt-eps.pdf`)

Scripts behind the numerical and exact checks in the paper. In the docstrings `MAIN_RESULT`
refers to the paper, and theorem, lemma and section numbers are the paper's. Scripts marked
"exact" use integer or rational arithmetic; floating-point and search scripts are evidence or
exploration only, and no proof depends on them. `exploratory/` holds early experiments that are
not used in the paper.

## Requirements

Python 3 with `numpy`, `scipy`, `sympy`, `mpmath`; `gaussian_certified.py` also needs
`python-flint` (`pip install numpy scipy sympy mpmath python-flint`).

## Running

Run from the `numerics/` directory, for example

```bash
cd numerics
python3 verify_exhaustive.py       # every lemma, all f on n <= 4 variables, exact
python3 verify_refined_final.py    # Lemma 4.3 and Theorem 1.1 (c0 = 4 + 2 sqrt 2), exhaustive
python3 neq3_check.py              # Theorem 8.55, exact enumeration on small instances
```

Most scripts take no arguments and finish in seconds to minutes; a few take optional sizes on
the command line (see the docstring). The saved output of a run of `name.py` is in `name.out`
or `name_<parameters>.txt` next to it.

## Scripts

| script | what it checks |
| --- | --- |
| `alpha_dependence.py` | Exact check of Remark rem:alphanec (MAIN_RESULT.pdf, Section 8.8). |
| `alphabet_census.py` | Census of the hypotheses of Theorem 8.45 (Section 8.9) for all g: [q]^m -> [q] depending on all coordinates. |
| `alphabet_check.py` | Exact small-n checks for the larger-alphabet extension (Section 8.9 of MAIN_RESULT). |
| `alphabet_quotient_census.py` | Iterated quotient of binary operations g on 3 letters (exploratory; not used in any proof). |
| `band_fast.py` | Fast floating-point evaluation and optimisation of band-structured symmetric f for large n. |
| `band_search.py` | Structured search for f = 1{#zeros(x) in Z} with Z a union of a few integer intervals (uniform measure). |
| `correlated_check.py` | Exact small-n checks for the correlated-input extension (Section 8.8 of MAIN_RESULT). |
| `counterexample_sharp.py` | Exact check of counterexamples to the sharp conjecture dist(f)^2 <= eps(f) (uniform measure). |
| `doeblin_check.py` | Doeblin coefficients for the near-constant lemma (paper Lemma 8.23, Theorem 8.18(d)). |
| `exact_band_check.py` | Exact integer computation of eps(f) and dist(f) for symmetric f(x) = 1{#zeros(x) in Z} (uniform measure). |
| `exponent_classification.py` | Census for the exponent theorem (paper Theorem 8.18; completability is Definition 8.17). |
| `gaussian_certified.py` | Certified (ball arithmetic, python-flint/Arb) value of the Gaussian limit of the two-band family. |
| `gaussian_junta.py` | Gaussian limit with k junta bits: f(z, x) = g_z(X) near weight n/2 and h_w(U) near weight n/4. |
| `gaussian_limit.py` | Gaussian (n -> infinity) limit of symmetric two-region constructions for the AND test. |
| `gaussian_opt.py` | Optimise the Gaussian-limit ratio over general g: R -> [0,1] (discretised), with h chosen optimally. |
| `maxnonflex_check.py` | Checks for Lemma 8.72 / Corollary 8.73 (maximum non-flexible predicates over Z_3). |
| `meet7_upsets.py` | Exhaustive floating-point scan over pairs of nested up-sets on 5 points (k = 6, two product measures); exploratory. |
| `multi_exponent_census.py` | Census for the multi-polymorphism exponent E(g) (paper Section 8.7). |
| `near_constant_check.py` | Exact check of the near-constant lemma (paper Lemma 8.21). |
| `neq3_check.py` | Checks for Theorem 8.55 (the predicate P = {(a,b,c) in Z_3^3 : a+b+c != 0} under the uniform distribution pi on P), by exact enumeration on small instances. |
| `neq3_general_mu_check.py` | Checks for Section 8.10, Lemmas 8.59-8.60 and Theorem 8.61: the predicate P = {(a,b,c) in Z_3^3 : a+b+c != 0} under full-support distributions mu on P. |
| `neq3_n2_check.py` | All generalized polymorphisms of P = {(a,b,c) in Z_3^3 : a+b+c != 0} for n = 2. |
| `neq3_poly_check.py` | Polymorphisms of P = {(a,b,c) in Z_3^3 : a+b+c != 0} (Corollary 8.68). |
| `neq3_shift_check.py` | P_neq = {(a,b,c) in Z_3^3 : a+b+c != 0} under the shift distribution mu^sh_alpha (Proposition 8.62(b)). |
| `neq3_transfer_check.py` | Checks for Section 8.10, Lemma 8.64 (transfer), Lemma 8.65 (chain of marginals) and Theorem 8.66 (every full-support distribution) for P = {(a,b,c) in Z_3^3 : a+b+c != 0}. |
| `neq_all_constants_check.py` | Checks the absorption inequalities in the proof of Theorem 8.66 (thm:neqall). |
| `neq_large_kappa_check.py` | Checks for Proposition 8.81 of the PDF (a larger parameter for reverse hypercontractivity). |
| `neq_product_check.py` | Check of the product inequality used in Step 2 of the proofs of Theorems 8.61 and 8.80. |
| `neq_rhc_sharp_check.py` | Checks for the inequality (S_kappa) of Proposition prop:rhcsharp and Remark rem:rhcsharp (after Proposition 8.82). |
| `neq_sharp_shift_check.py` | Checks for Proposition prop:neqsharp (the sharp constant for uniform marginals). |
| `neqm_check.py` | The m-ary predicate P^(m) = {a in Z_3^m : a_1+...+a_m != 0}, m >= 4, uniform distribution (Theorem 8.70). |
| `neqm_mu_check.py` | P^(m) = {a in Z_3^m : a_1+...+a_m != 0}, m >= 4, under a general full-support distribution mu (Lemma 8.77, Theorem 8.78, and the extension of Lemma 8.60 in Remark 8.71(c)). |
| `neqm_poly_check.py` | Checks for Corollary 8.75: equal functions and polymorphisms of P^(m) = {a in Z_3^m : a_1+...+a_m != 0}, m >= 4, under the uniform distribution pi_m (exact integer / rational arithmetic). |
| `neqm_unif_check.py` | P^(m) = {a in Z_3^m : a_1+...+a_m != 0}, m >= 4, under full-support distributions with uniform marginals (Theorem 8.80). |
| `rkappa_check.py` | The exponent r_kappa = 2(1 - sqrt(1-kappa))/(2 - sqrt(1-kappa)) of the reverse hypercontractivity lemma (Lemma 8.35 of the PDF) satisfies 8 kappa/9 <= r_kappa < kappa for every kappa in (0, 1). |
| `sc7_finite_n.py` | Finite-n values of dist^2/eps for the two-band family of Proposition prop:gausslimit (floating point). |
| `search_symmetric_sharp.py` | Local search for symmetric f = 1{\|x\| in W} maximising dist(f)^2 / eps(f) (uniform measure). |
| `search_worst.py` | Simulated annealing search for f:{0,1}^n->{0,1} maximising dist(f, {0} u ANDs)^2 / eps. |
| `sharp_lower_bounds.py` | Exact tests (all f on n <= 4) of candidate intermediate inequalities for the sharp conjecture dist^2 <= eps. |
| `sharp_lower_bounds_symmetric.py` | Symmetric f(x) = F(\|x\|): compare eps, the Booleanity lower bound L(f) <= eps, and dist^2 (all F, n <= nmax). |
| `sharp_relative.py` | Checks for Theorem 5.4, Lemma 5.5 and Theorem 5.6 (sharp relative constant near the ANDs). |
| `symmetric_exact.py` | Exact eps and dist for symmetric f(x) = F(\|x\|), all F in {0,1}^{n+1}, small n (vectorised). |
| `symmetric_top_levels.py` | EXACT (big-integer) delta^2/eps for symmetric f supported on the top r+1 Hamming levels, large n. |
| `test_sharp_inequalities.py` | Exhaustively test candidate sharp inequalities for all f on n <= 4 variables (exact integers). |
| `theta_estimate.py` | Floating-point estimate of the SDPI constant theta(pi, K_S) of Lemma 8.22 for the non-completable triples (g, b, S) with m <= 4 (Nelder-Mead over softmax-parametrised nu, 60 restarts per triple). |
| `top_level_asymptotic.py` | Leading-order (n -> infinity) test of the sharp conjecture dist^2 <= eps for top-level symmetric families. |
| `verify_exhaustive.py` | Exhaustive exact verification of every lemma in MAIN_RESULT for all f:{0,1}^n->{0,1}, n<=4. |
| `verify_extensions.py` | Exhaustive floating-point checks of the extensions in MAIN_RESULT on small n. |
| `verify_general_containment.py` | Exact check of the containment inequality for approximate multi-polymorphisms of a general g. |
| `verify_refined_final.py` | Exhaustive check of the refined final-step lemma (Lemma 4.3 of MAIN_RESULT.pdf) and of Theorem 1.1 (constant c0 = 4 + 2 sqrt 2). |
| `exploratory/corr_contain.py` | Exploratory: does the global p-biased spectral containment survive rho-correlated pairs (rho >= 0)? |
| `exploratory/corr_contain2.py` | Exploratory: compare LHS_glob = sum_S fhat(S)^2 Pr[f(y)=1, y_S != 1] (mu_p, x indep of y) with CQ = (1/2) Pr[f(y)=1, f(x) != f(x')] for (x,y) rho-correlated and x' = x resampled on Z(y) from the conditional law Bern(p') (p' = p(1-rho)). |
| `exploratory/corr_search.py` | Exploratory local search: maximize LHS_glob/eps_rho and dist*mu/eps_rho over f on n variables (rho-correlated AND test). |
| `exploratory/corr_sym.py` | Exploratory: symmetric f = 1{\|x\| in W} under rho-correlated pairs; exact LHS_glob, eps_rho, dist (floats, log-safe). |
| `exploratory/neq3_star.py` | Numerical exploration of the inequality eps_ind(p,q,r) >= (1/3) sigma(p) sigma(q) sigma(r) for three distributions p,q,r on Z_3, where eps_ind = Pr[X+Y+Z = 0] for independent X~p, Y~q, Z~r and sigma(p)^2 = 1 - \|sum_v p_v w^v\|^2, w = exp(2 p |
