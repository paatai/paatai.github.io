"""Checks for Theorem 5.4, Lemma 5.5 and Theorem 5.6 (sharp relative constant near the ANDs).

Sections:
  1. Lemma 5.5: 4 Pr[x in T, x^y in T] - Pr[x^y in T] <= 4 d^{3/2} (random and structured T).
  2. The m-ary meet lemma (m=3): 2m Pr[x in T, w in T] - Pr[w in T] <= m^2 d^{kappa_m}, w = x ^ y', y' ~ mu_{1/4}.
  3. The event accounting (eq:sharprel) and eps >= 2q delta_C (1 - 4 sqrt r) for every C, small n (brute force).
  4. eps_3 >= 3 q^2 delta_C (1 - 9 r^{3/4}) for every C, small n (brute force).
  5. Non-vacuous regime (r < 1/16): exact integer eps and eps_3 via superset-sum / Moebius transforms,
     f = AND_C xor 1_E with sparse or structured E, n up to 20; exact rational comparison.
  6. The consequence of Theorem 5.4 with the set C of Theorem 1.1, and the example AND_C(1-AND_T),
     whose dist*mu/eps is exactly 1/2 (dist by exact minimisation over all of A_n).
"""
import itertools
from fractions import Fraction
import numpy as np

SQ2 = 2 ** 0.5


def popcounts(n):
    pc = np.zeros(1 << n, dtype=np.int64)
    for i in range(n):
        pc += (np.arange(1 << n) >> i) & 1
    return pc


def superset_sum(a, n):
    a = a.copy()
    for i in range(n):
        v = a.reshape(-1, 2, 1 << i)
        v[:, 0, :] += v[:, 1, :]
    return a


def superset_moebius(a, n):
    a = a.copy()
    for i in range(n):
        v = a.reshape(-1, 2, 1 << i)
        v[:, 0, :] -= v[:, 1, :]
    return a


def eps_exact(F, n, m=2):
    """(2^m)^n * eps_m(f) as an exact integer (F a 0/1 int64 array indexed by points)."""
    pc = popcounts(n)
    M = int(F.sum())
    hat = superset_sum(F, n)
    cnt = superset_moebius(hat ** m, n)          # #{(x_1..x_m) in A^m : x_1 ^ ... ^ x_m = z}
    base = (1 << m) - 1                           # #{tuples with meet z} = (2^m - 1)^{n-|z|}
    layer = np.bincount(pc[F == 1], minlength=n + 1)
    p_meet = sum(int(layer[k]) * base ** (n - k) for k in range(n + 1))
    tau = int((F * cnt).sum())
    return p_meet + M ** m - 2 * tau


def eps_brute(F, n, m=2):
    N = 1 << n
    cnt = 0
    for tup in itertools.product(range(N), repeat=m):
        w = N - 1
        p = 1
        for t in tup:
            w &= t
            p *= int(F[t])
        cnt += int(F[w]) != p
    return cnt


def and_vec(n, C):
    pts = np.arange(1 << n)
    return ((pts & C) == C).astype(np.int64)


# ---------------------------------------------------------------- 1. Lemma 5.5
rng = np.random.default_rng(0)


def meet2(k, T):
    N = 1 << k
    pts = np.arange(N)
    M = pts[:, None] & pts[None, :]
    inT = np.zeros(N, bool)
    inT[list(T)] = True
    d = inT.mean()
    a = (inT[:, None] & inT[M]).mean()
    b = inT[M].mean()
    return 4 * a - b, 4 * d ** 1.5


worst = 0.0
for trial in range(3000):
    k = int(rng.integers(1, 9))
    N = 1 << k
    T = rng.choice(N, size=int(rng.integers(1, N + 1)), replace=False)
    lhs, rhs = meet2(k, T)
    worst = max(worst, lhs / rhs)
for k in range(1, 10):
    N = 1 << k
    pts = np.arange(N)
    for s in range(k + 1):
        for t in range(k - s + 1):
            Sm = (1 << s) - 1
            Tm = ((1 << t) - 1) << s
            T = [x for x in pts if (x & Sm) == 0 and (x & Tm) == Tm]
            lhs, rhs = meet2(k, T)
            worst = max(worst, lhs / rhs)
    pc = popcounts(k)
    for w0 in range(k + 1):                       # Hamming balls around 1^k and 0^k, slices
        for T in (pts[pc >= w0], pts[pc <= w0], pts[pc == w0]):
            if len(T):
                lhs, rhs = meet2(k, T)
                worst = max(worst, lhs / rhs)
print("1. Lemma 5.5: max (4a-b)/(4 d^{3/2}) over random, subcube, ball and slice sets, k<=9:", round(worst, 6))
assert worst <= 1 + 1e-12

# ---------------------------------------------------------------- 2. m-ary meet lemma, m = 3
m = 3
kap = 2 - 2.0 ** (1 - m)
worst = 0.0
for trial in range(2000):
    k = int(rng.integers(1, 9))
    N = 1 << k
    pts = np.arange(N)
    pc = popcounts(k)
    T = np.zeros(N, bool)
    T[rng.choice(N, size=int(rng.integers(1, N + 1)), replace=False)] = True
    pw = 0.25 ** pc * 0.75 ** (k - pc)
    M = pts[:, None] & pts[None, :]
    a = ((T[:, None] & T[M]) * pw[None, :]).sum() / N
    b = (T[M] * pw[None, :]).sum() / N
    d = T.mean()
    worst = max(worst, (2 * m * a - b) / (m * m * d ** kap))
print("2. m=3 meet lemma: max (6a-b)/(9 d^{7/4}) over random sets, k<=8:", round(worst, 6))
assert worst <= 1 + 1e-12

# ---------------------------------------------------------------- 3. accounting + final inequality, m = 2
rng = np.random.default_rng(1)
bad_acc = bad_fin = 0
cnt = 0
for trial in range(1500):
    n = int(rng.integers(2, 7))
    N = 1 << n
    pts = np.arange(N)
    M = pts[:, None] & pts[None, :]
    C0 = int(rng.integers(0, N))
    F = and_vec(n, C0)
    if rng.random() < 0.3:
        F = rng.integers(0, 2, N).astype(np.int64)
    else:
        F[rng.choice(N, size=int(rng.integers(1, 5)), replace=False)] ^= 1
    eps = Fraction(int((F[M] != (F[:, None] * F[None, :])).sum()), N * N)
    A = F.astype(bool)
    X = np.broadcast_to(pts[:, None], (N, N))
    Y = np.broadcast_to(pts[None, :], (N, N))
    for C in range(N):
        Qv = and_vec(n, C).astype(bool)
        q = Fraction(int(Qv.sum()), N)
        D = Qv & ~A
        B = A & ~Qv
        dD = Fraction(int(D.sum()), N)
        dB = Fraction(int(B.sum()), N)
        dl = dD + dB
        aD = Fraction(int((D[X] & Qv[Y] & D[M]).sum()), N * N)
        bD = Fraction(int((Qv[X] & Qv[Y] & D[M]).sum()), N * N)
        aB = Fraction(int((B[X] & Qv[Y] & B[M]).sum()), N * N)
        bB = Fraction(int((~Qv[X] & Qv[Y] & B[M]).sum()), N * N)
        lower = 2 * q * dl - 2 * dD * dD - 2 * dB * dD + (bD - 4 * aD) + 2 * (bB - 2 * aB)
        cnt += 1
        bad_acc += eps < lower
        X2 = 2 * q * dl
        r = dl / q
        if X2 > eps and 16 * r * X2 * X2 < (X2 - eps) ** 2:
            bad_fin += 1
print("3. m=2, n<=6, %d pairs (f,C): violations of eq:sharprel: %d; of eps>=2q delta(1-4 sqrt r): %d" % (cnt, bad_acc, bad_fin))
assert bad_acc == 0 and bad_fin == 0

# ---------------------------------------------------------------- 4. final inequality, m = 3
rng = np.random.default_rng(2)
bad = cnt = 0
for trial in range(250):
    n = int(rng.integers(2, 5))
    N = 1 << n
    F = and_vec(n, int(rng.integers(0, N)))
    if rng.random() < 0.3:
        F = rng.integers(0, 2, N).astype(np.int64)
    else:
        F[rng.choice(N, size=int(rng.integers(1, 4)), replace=False)] ^= 1
    E = eps_brute(F, n, 3)
    assert E == eps_exact(F, n, 3)
    e3 = Fraction(E, N ** 3)
    for C in range(N):
        Qv = and_vec(n, C)
        q = Fraction(int(Qv.sum()), N)
        dl = Fraction(int((F != Qv).sum()), N)
        r = dl / q
        X3 = 3 * q * q * dl
        cnt += 1
        if X3 > e3 and (9 * X3) ** 4 * r ** 3 < (X3 - e3) ** 4:
            bad += 1
print("4. m=3, n<=4, %d pairs (f,C): violations of eps_3>=3q^2 delta(1-9 r^{3/4}): %d (eps_3 brute force = Moebius formula)" % (cnt, bad))
assert bad == 0

# ---------------------------------------------------------------- 5. non-vacuous regime
rng = np.random.default_rng(3)


def check_family(n, m, trials):
    N = 1 << n
    pts = np.arange(N)
    pc = popcounts(n)
    bad = nonvac = 0
    tight = Fraction(10)
    for trial in range(trials):
        c = int(rng.integers(0, 4))
        Cset = rng.choice(n, size=c, replace=False)
        C = int(sum(1 << int(i) for i in Cset))
        Qv = (pts & C) == C
        F = Qv.astype(np.int64)
        kind = trial % 6
        Qi = np.nonzero(Qv)[0]
        Ni = np.nonzero(~Qv)[0]
        if kind == 0:                                  # random D (inside Q)
            E = rng.choice(Qi, size=int(rng.integers(1, 40)), replace=False)
        elif kind == 1 and len(Ni):                    # random B (outside Q)
            E = rng.choice(Ni, size=int(rng.integers(1, 40)), replace=False)
        elif kind == 2:                                # subcube D: x_C = 1, x_T = 1
            t = int(rng.integers(5, n - c + 1))
            Tset = rng.choice([i for i in range(n) if not (C >> i) & 1], size=t, replace=False)
            Tm = int(sum(1 << int(i) for i in Tset))
            E = pts[Qv & ((pts & Tm) == Tm)]
        elif kind == 3:                                # top slice of Q (one zero outside C)
            E = pts[Qv & (pc == n - 1)]
        elif kind == 4 and c > 0:                      # near-top B: one zero, inside C, plus a few more points
            E = pts[(~Qv) & (pc >= n - 1)]
            E = np.concatenate([E, rng.choice(Ni, size=int(rng.integers(0, 5)), replace=False)])
        else:                                          # mixed
            E = np.concatenate([rng.choice(Qi, size=int(rng.integers(1, 20)), replace=False),
                                rng.choice(Ni, size=min(len(Ni), int(rng.integers(0, 20))), replace=False)])
        E = np.unique(E)
        F[E] ^= 1
        eps = Fraction(eps_exact(F, n, m), (1 << m) ** n)
        q = Fraction(int(Qv.sum()), N)
        dl = Fraction(len(E), N)
        r = dl / q
        X = m * q ** (m - 1) * dl
        if m == 2:
            ok = not (X > eps and 16 * r * X * X < (X - eps) ** 2)
            nv = r < Fraction(1, 16)
        else:
            K = Fraction(m * m)
            ok = not (X > eps and (K * X) ** 4 * r ** 3 < (X - eps) ** 4)
            nv = K ** 4 * r ** 3 < 1
        bad += not ok
        if nv:
            nonvac += 1
            tight = min(tight, eps / X)
    return bad, nonvac, tight


for (n, m, tr) in ((16, 2, 300), (20, 2, 120), (14, 3, 200)):
    bad, nonvac, tight = check_family(n, m, tr)
    print("5. n=%d, m=%d: %d functions AND_C xor 1_E; violations %d; non-vacuous cases %d; min eps/(m q^{m-1} delta_C) there = %.6f"
          % (n, m, tr, bad, nonvac, float(tight)))
    assert bad == 0

# ---------------------------------------------------------------- 6. consequence and the example
theta0 = 1 - 1 / SQ2
c0 = 4 + 2 * SQ2


def hfun(eta):
    return (2 + 2 * SQ2) * (1 - 2 * eta) / (1 - (2 + SQ2) * eta)


def dist_exact(F, n):
    """2^n * dist(f) by exact minimisation over A_n: Pr[f != AND_S] = mu + 2^{-|S|} - 2 Pr[f=1, x_S=1]."""
    N = 1 << n
    pc = popcounts(n)
    M = int(F.sum())
    hat = superset_sum(F, n)
    vals = M + (N >> pc) - 2 * hat
    return min(M, int(vals.min()))


rng = np.random.default_rng(4)
worst_ratio = 0.0
checked = 0
for trial in range(200):
    n = 16
    N = 1 << n
    pts = np.arange(N)
    c = int(rng.integers(0, 4))
    C0 = int(sum(1 << int(i) for i in rng.choice(n, size=c, replace=False)))
    F = and_vec(n, C0)
    F[rng.choice(N, size=int(rng.integers(1, 60)), replace=False)] ^= 1
    mu = F.sum() / N
    e = eps_exact(F, n) / 4 ** n
    eta = e / mu ** 2
    if not (0 < eta < 1 / c0):
        continue
    Cth = 0
    for i in range(n):
        if ((F == 1) & (((pts >> i) & 1) == 0)).sum() / N <= theta0 * mu:
            Cth |= 1 << i
    dC = (F != and_vec(n, Cth)).sum() / N
    rr = hfun(eta) * eta / (1 - hfun(eta) * eta)
    q = and_vec(n, Cth).mean()
    assert dC / q <= rr + 1e-12
    if rr < 1 / 16:
        bound = (1 + rr) / (2 * (1 - 4 * rr ** 0.5)) * e / mu
        assert dist_exact(F, n) / N <= dC <= bound + 1e-15
        worst_ratio = max(worst_ratio, dC / bound)
        checked += 1
print("6a. consequence of Thm 5.4 (n=16, set C of Thm 1.1): r <= r(eta) always; %d cases with r(eta)<1/16, max Pr[f!=AND_C]/bound = %.4f"
      % (checked, worst_ratio))

ok = 0
for n in range(3, 13):
    for c in range(0, n - 1):
        for t in range(2, n - c + 1):
            C = (1 << c) - 1
            Tm = ((1 << t) - 1) << c
            pts = np.arange(1 << n)
            F = (((pts & C) == C) & ((pts & Tm) != Tm)).astype(np.int64)
            E2 = eps_exact(F, n, 2)
            D = dist_exact(F, n)
            M = int(F.sum())
            tau = Fraction(1, 1 << t)
            qq = Fraction(1, 1 << c)
            assert Fraction(E2, 4 ** n) == 2 * qq * qq * tau * (1 - tau)
            assert Fraction(D, 1 << n) == qq * tau
            assert Fraction(D * M, 1) / E2 == Fraction(1, 2)
            for mm in (3, 4):
                if n <= 9:
                    Em = eps_exact(F, n, mm)
                    assert Fraction(Em, (1 << mm) ** n) == qq ** mm * (1 - (1 - tau) ** mm - tau ** mm)
            ok += 1
print("6b. example AND_C(1-AND_T): eps, dist (exact over A_n) and dist*mu/eps = 1/2 verified for %d triples (n<=12); eps_3, eps_4 formula for n<=9" % ok)
print("ALL CHECKS PASSED")
