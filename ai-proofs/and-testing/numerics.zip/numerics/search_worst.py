#!/usr/bin/env python3
"""Simulated annealing search for f:{0,1}^n->{0,1} maximising dist(f, {0} u ANDs)^2 / eps.

Exact incremental updates:
  err  = #{(x,y) : f(x&y) != f(x) f(y)}            (eps = err / N^2)
  D[S] = #{x : f(x) != AND_S(x)}                    (dist to AND_S = D[S]/N)
  A    = #{x : f(x) = 1}                            (dist to 0 = A/N)
Usage: python3 search_worst.py n [steps] [restarts] [seed]
"""
import sys

import numpy as np


def build(n):
    N = 1 << n
    pts = np.arange(N)
    meet = pts[:, None] & pts[None, :]
    pairs_by_meet = [np.argwhere(meet == z) for z in range(N)]  # list of (x,y) pairs with x&y = z
    ANDm = ((pts[None, :] & pts[:, None]) == pts[:, None]).astype(np.int8)  # ANDm[S, x]
    return N, meet, pairs_by_meet, ANDm


def full_err(f, meet):
    return int((f[meet] != (f[:, None] & f[None, :])).sum())


def delta_err(f, z, meet, pairs_by_meet):
    """Change in err if f[z] is flipped."""
    N = len(f)
    # affected pairs: x=z (row), y=z (column), x&y=z. Collect unique pairs.
    rows = np.stack([np.full(N, z), np.arange(N)], axis=1)
    cols = np.stack([np.arange(N), np.full(N, z)], axis=1)
    pm = pairs_by_meet[z]
    P = np.unique(np.concatenate([rows, cols, pm], axis=0), axis=0)
    x, y = P[:, 0], P[:, 1]
    before = (f[meet[x, y]] != (f[x] & f[y])).sum()
    g = f.copy()
    g[z] ^= 1
    after = (g[meet[x, y]] != (g[x] & g[y])).sum()
    return int(after - before)


def objective(A, Dmin, err, N):
    if err == 0:
        return 0.0
    d = min(A, Dmin) / N
    return d * d / (err / (N * N))


def anneal(n, steps=20000, seed=0, init=None, T0=0.05):
    rng = np.random.default_rng(seed)
    N, meet, pbm, ANDm = build(n)
    if init is None:
        dens = rng.uniform(0.05, 0.6)
        f = (rng.random(N) < dens).astype(np.int8)
    else:
        f = init.astype(np.int8).copy()
    err = full_err(f, meet)
    A = int(f.sum())
    D = (ANDm != f[None, :]).sum(axis=1).astype(np.int64)
    cur = objective(A, D.min(), err, N)
    best, bestf = cur, f.copy()
    for t in range(steps):
        T = T0 * (1 - t / steps) + 1e-6
        z = int(rng.integers(N))
        de = delta_err(f, z, meet, pbm)
        newA = A + (1 if f[z] == 0 else -1)
        # D[S] changes: if AND_S(z) == f(z) now, after flip they differ (+1), else -1
        dD = np.where(ANDm[:, z] == f[z], 1, -1)
        newD = D + dD
        new = objective(newA, newD.min(), err + de, N)
        if new >= cur or rng.random() < np.exp((new - cur) / T):
            f[z] ^= 1
            err += de
            A = newA
            D = newD
            cur = new
            if cur > best:
                best, bestf = cur, f.copy()
    assert err == full_err(f, meet)
    return best, bestf


if __name__ == "__main__":
    n = int(sys.argv[1])
    steps = int(sys.argv[2]) if len(sys.argv) > 2 else 20000
    restarts = int(sys.argv[3]) if len(sys.argv) > 3 else 5
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    N = 1 << n
    overall = 0.0
    for r in range(restarts):
        b, bf = anneal(n, steps, seed=seed * 1000 + r)
        A = int(bf.sum())
        weights = sorted(set(int(bin(x).count("1")) for x in range(N) if bf[x]))
        print(f"restart {r}: best delta^2/eps = {b:.6f}; |A| = {A}; Hamming weights in A: {weights}", flush=True)
        overall = max(overall, b)
    print(f"n={n}: overall best delta^2/eps = {overall:.6f}  (slice |x|=n-1 gives n/(n+1) = {n/(n+1):.6f})")
