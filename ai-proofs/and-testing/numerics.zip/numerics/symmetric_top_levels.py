#!/usr/bin/env python3
"""EXACT (big-integer) delta^2/eps for symmetric f supported on the top r+1 Hamming levels, large n.

f(x) = F(#zeros of x) with F: {0..r} -> {0,1}, and f = 0 on inputs with more than r zeros.
E = 4^n eps and D = 2^n delta are integers, so delta^2/eps = D^2/E exactly.
Distance candidates: 0, and AND_S for every u = |S^c| in [0, n] (all of them; by symmetry the distance
to AND_S depends only on u).
"""
import sys
from fractions import Fraction
from math import comb


def multinom(n, a, b, c, d):
    return comb(n, a) * comb(n - a, b) * comb(n - a - b, c)


def tables(n, r):
    R1 = []  # (z0, zx, zy, count) with z0 = #zeros(x&y) <= r
    R2 = []  # (zx, zy, count) with zx, zy <= r, z0 > r
    for d in range(r + 1):
        for b in range(r + 1):
            for c in range(r + 1):
                a = n - b - c - d
                if a < 0:
                    continue
                z0, zx, zy = b + c + d, c + d, b + d
                if z0 <= r:
                    R1.append((z0, zx, zy, multinom(n, a, b, c, d)))
                elif zx <= r and zy <= r:
                    R2.append((zx, zy, multinom(n, a, b, c, d)))
    return R1, R2


def evaluate(n, r):
    R1, R2 = tables(n, r)
    lev = [comb(n, j) for j in range(r + 1)]  # #inputs with j zeros
    binom_u = [[comb(u, j) for j in range(min(u, r) + 1)] for u in range(n + 1)]
    best = None
    for code in range(1, 1 << (r + 1)):
        F = [(code >> j) & 1 for j in range(r + 1)]
        val = lambda j: F[j] if j <= r else 0
        E = 0
        for z0, zx, zy, cnt in R1:
            if val(z0) != (val(zx) & val(zy)):
                E += cnt
        for zx, zy, cnt in R2:
            if F[zx] & F[zy]:
                E += cnt
        if E == 0:
            continue
        A = sum(F[j] * lev[j] for j in range(r + 1))  # 2^n mu
        D = A
        for u in range(0, n + 1):
            # AND_S with |S^c| = u: AND_S(x) = 1 iff zeros(x) subset S^c; #(x with j zeros, all in S^c) = C(u,j)
            inter = sum(F[j] * c for j, c in enumerate(binom_u[u]))
            dist = A + (1 << u) - 2 * inter
            D = min(D, dist)
        ratio = Fraction(D * D, E)
        if best is None or ratio > best[0]:
            best = (ratio, ''.join(map(str, F)), E, D, A)
    return best


if __name__ == "__main__":
    r = int(sys.argv[1]) if len(sys.argv) > 1 else 7
    ns = [int(s) for s in sys.argv[2:]] or [20, 40, 80, 160, 320]
    for n in ns:
        ratio, F, E, D, A = evaluate(n, r)
        print(f"n={n:4d} r={r}: max delta^2/eps = {float(ratio):.6f} (exact ratio-1 = {float(ratio - 1):.3e})  "
              f"F(#zeros=0..r)={F}  "
              f"eps={E / 4**n:.3e} delta={D / 2**n:.3e} mu={A / 2**n:.3e}", flush=True)
