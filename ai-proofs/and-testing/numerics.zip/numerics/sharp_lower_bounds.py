#!/usr/bin/env python3
"""Exact tests (all f on n <= 4) of candidate intermediate inequalities for the sharp conjecture dist^2 <= eps.

Exact decomposition (uniform measure):
  eps = E_x[ f(x) Pr_y[f(x&y) != f(y)] ] + E_x[ (1-f(x)) T f(x) ],   T f(x) = Pr_y[f(x&y) = 1].
Booleanity lower bound: for f(x) = 1, Pr_y[f(x&y) != f(y)] >= D_{supp x}(f), where
  D_J(f) = min over Boolean J-juntas h of Pr[f != h] = E min(m_J, 1 - m_J),  m_J = E[f | x_J].
  L(f) = E_x[f(x) D_{supp x}(f)] + E_x[(1-f(x)) T f(x)] <= eps.
Tested:  L(f) >= dist(f)^2 ?   (would be a strengthening of the conjecture)
"""
import sys
from fractions import Fraction

import numpy as np


def run(n):
    N = 1 << n
    pts = np.arange(N, dtype=np.int64)
    meet = pts[:, None] & pts[None, :]
    nfun = 1 << N
    F = ((np.arange(nfun, dtype=np.int64)[:, None] >> pts[None, :]) & 1).astype(np.int64)
    ANDm = ((pts[None, :] & pts[:, None]) == pts[:, None]).astype(np.int64)
    A = F.sum(1)
    err = (F[:, meet] != (F[:, :, None] * F[:, None, :])).sum((1, 2))  # N^2 eps
    Dall = (F[:, None, :] != ANDm[None, :, :]).sum(2)
    dist = np.minimum(A, Dall.min(1))  # N * dist
    # D_J for every J (bitmask): group points by x & J; m = mean of f over the class
    DJ = np.zeros((nfun, N), dtype=np.int64)  # N * D_J * (2^{n-|J|}) normalisation handled below
    # N * D_J = sum over classes c of min(#ones in c, #zeros in c)
    for J in range(N):
        keys = pts & J
        tot = np.zeros(nfun, dtype=np.int64)
        for k in np.unique(keys):
            cls = keys == k
            ones = F[:, cls].sum(1)
            tot += np.minimum(ones, cls.sum() - ones)
        DJ[:, J] = tot
    # T f(x) * N = #{y : f(x&y) = 1}
    Tf = F[:, meet].sum(2)  # (nfun, N)
    # N^2 L = sum_x f(x) * (N D_{x}) + sum_x (1-f(x)) * (N Tf(x))
    L = (F * DJ[:, pts]).sum(1) + ((1 - F) * Tf).sum(1)
    assert np.all(L <= err), "L > eps ?!"
    viol = L < dist ** 2
    worst = None
    for k in np.nonzero(err > 0)[0]:
        r = Fraction(int(dist[k]) ** 2, int(L[k])) if L[k] > 0 else None
        if r is not None and (worst is None or r > worst[0]):
            worst = (r, k)
    return int(viol.sum()), worst, nfun


if __name__ == "__main__":
    for n in range(1, int(sys.argv[1]) + 1 if len(sys.argv) > 1 else 5):
        nv, worst, nfun = run(n)
        print(f"n={n}: #f with L(f) < dist^2: {nv} of {nfun}; max dist^2/L = {worst[0]} = {float(worst[0]):.4f} "
              f"(f={worst[1]})", flush=True)
