"""P^(m) = {a in Z_3^m : a_1+...+a_m != 0}, m >= 4, under a general full-support distribution mu
(Lemma 8.77, Theorem 8.78, and the extension of Lemma 8.60 in Remark 8.71(c)).

Exact checks (rational arithmetic):
 (D)  the decomposition of Lemma 8.77(b), for random full-support mu (m = 4, 5; generic, nearly degenerate,
      and with very unequal masses), every pair {b, c} and every choice of a: y -> (T(y), y_R) is a bijection
      onto P_neq x Z_3^R; min mu_T >= 3^(m-3) alpha; the second and third marginals of mu_T are mu_b, mu_c;
      nu = (mu - sigma mu_T x mu_R)/(1 - sigma), sigma = alpha/2, satisfies nu >= mu/2, nu_b = mu_b,
      nu_c = mu_c, nu_bc(u, v) >= 3^(m-3) alpha >= alpha nu_b(u) nu_c(v); min mu_t >= 2*3^(m-2) alpha and every
      value has probability >= 18 alpha = 6a' under the marginals of mu_T.
 (I)  the restricted instances: for m = 4, n = 2 and random mu, f, the average over L, rho of the error of the
      triple f^{L,rho} = (F, f_b(., rho_b), f_c(., rho_c)) under mu_T, with F built from the formula
      F(x) = f_a(x - s, rho_a) + sum_{j in R} f_j(c_j), equals err_mu(f) exactly; also each restricted error is
      computed from mu_T-rows only, so this checks that the conditional law of the free rows is mu_T^(x L).
 (A)  the counts used in Remark 8.71(c) for Lemma 8.60 with m >= 4 (m = 4, 5, 6): every pair of entries has
      2*3^(m-3) completions; for a != a' exactly 3^(m-2) completions v of the other m-1 entries are common to a
      and a' (2*3^(m-2) if a = a'); the kernel bound K(a, a') >= 3^(m-2) alpha^2 mu_l(a') for random mu, every l;
      mu_j(a) >= 2*3^(m-2) alpha; and alpha^2 + (m+1) alpha + 2(m+1)/3^(m-2) <= 2 at alpha = 1/(2*3^(m-1))
      for m = 4..40 (the final bound). The one-variable classification itself is check (a1) of neqm_check.py.
 (C)  the constants of Theorem 8.78 (mpmath, 60 digits): for alpha on a grid in [1e-12, 1/54] and every m >= 4
      with alpha <= 1/(2*3^(m-1)): with r = r_alpha exactly, c = c_{3 alpha} r / 2 > alpha^9/8000, and
      ln C <= 1.22e10 alpha^-16 ln(1/alpha), where C = max(1 + (m-1) E_0, 4(m+1) alpha^-4) as in the proof.
"""
import itertools
import random
import sys
from fractions import Fraction

import mpmath

Q = 3


def rows(m):
    return [a for a in itertools.product(range(Q), repeat=m) if sum(a) % Q != 0]


P3 = rows(3)


def random_mu(m, rng, mode):
    P = rows(m)
    if mode == "generic":
        w = [rng.randint(1, 50) for _ in P]
    elif mode == "spiky":
        w = [rng.choice([1, 1, 1, 10 ** 6]) for _ in P]
    else:
        w = [1] * len(P)
        w[rng.randrange(len(P))] = 10 ** 9
    s = sum(w)
    return {a: Fraction(x, s) for a, x in zip(P, w)}


def marg(mu, idx):
    out = {}
    for a, p in mu.items():
        k = tuple(a[i] for i in idx)
        out[k] = out.get(k, 0) + p
    return out


def T_of(y, a, b, c, R):
    return ((y[a] + sum(y[j] for j in R)) % Q, y[b], y[c])


def check_decomposition(m, rng):
    ok = True
    for mode in ("generic", "spiky", "nearpoint"):
        for _ in range(4):
            mu = random_mu(m, rng, mode)
            alpha = min(mu.values())
            sigma = alpha / 2
            for b, c in itertools.permutations(range(m), 2):
                for a in [j for j in range(m) if j not in (b, c)]:
                    R = [j for j in range(m) if j not in (a, b, c)]
                    img = {(T_of(y, a, b, c, R), tuple(y[j] for j in R)) for y in mu}
                    ok &= len(img) == len(mu) == len(P3) * Q ** len(R)
                    muT, muR = {}, {}
                    for y, p in mu.items():
                        t = T_of(y, a, b, c, R)
                        muT[t] = muT.get(t, 0) + p
                        r = tuple(y[j] for j in R)
                        muR[r] = muR.get(r, 0) + p
                    ok &= set(muT) == set(P3) and min(muT.values()) >= 3 ** (m - 3) * alpha
                    mub, muc = marg(mu, [b]), marg(mu, [c])
                    ok &= marg(muT, [1]) == mub and marg(muT, [2]) == muc
                    nu = {}
                    for y, p in mu.items():
                        q = (p - sigma * muT[T_of(y, a, b, c, R)] * muR[tuple(y[j] for j in R)]) / (1 - sigma)
                        nu[y] = q
                        ok &= q >= p / 2
                    ok &= sum(nu.values()) == 1
                    ok &= marg(nu, [b]) == mub and marg(nu, [c]) == muc
                    nubc = marg(nu, [b, c])
                    nub, nuc = marg(nu, [b]), marg(nu, [c])
                    ok &= all(nubc[(u, v)] >= 3 ** (m - 3) * alpha >= alpha * nub[(u,)] * nuc[(v,)]
                              for u in range(Q) for v in range(Q))
                    ok &= all(mub[(v,)] >= 2 * 3 ** (m - 2) * alpha and muc[(v,)] >= 2 * 3 ** (m - 2) * alpha
                              for v in range(Q))
                    ok &= all(marg(muT, [t])[(v,)] >= 18 * alpha for t in (1, 2) for v in range(Q))
    return ok


def check_restricted(rng, trials=6):
    m, n = 4, 2
    ok = True
    pts = list(itertools.product(range(Q), repeat=n))
    for _ in range(trials):
        mu = random_mu(m, rng, rng.choice(["generic", "spiky"]))
        alpha = min(mu.values())
        sigma = alpha / 2
        f = [{w: rng.randrange(Q) for w in pts} for _ in range(m)]
        P = list(mu)
        err = Fraction(0)
        for rs in itertools.product(P, repeat=n):
            cols = [tuple(r[j] for r in rs) for j in range(m)]
            if sum(f[j][cols[j]] for j in range(m)) % Q == 0:
                w = Fraction(1)
                for r in rs:
                    w *= mu[r]
                err += w
        b, c = rng.sample(range(m), 2)
        a = rng.choice([j for j in range(m) if j not in (b, c)])
        R = [j for j in range(m) if j not in (a, b, c)]
        muT, muR = {}, {}
        for y, p in mu.items():
            t = T_of(y, a, b, c, R)
            muT[t] = muT.get(t, 0) + p
            r = tuple(y[j] for j in R)
            muR[r] = muR.get(r, 0) + p
        nu = {y: (p - sigma * muT[T_of(y, a, b, c, R)] * muR[tuple(y[j] for j in R)]) / (1 - sigma)
              for y, p in mu.items()}
        total = Fraction(0)
        for L in itertools.product((0, 1), repeat=n):
            pL = Fraction(1)
            for i in range(n):
                pL *= sigma if L[i] else 1 - sigma
            Lidx = [i for i in range(n) if L[i]]
            Oidx = [i for i in range(n) if not L[i]]
            for outside in itertools.product(P, repeat=len(Oidx)):
                for zeta in itertools.product(list(muR), repeat=len(Lidx)):
                    w = pL
                    for y in outside:
                        w *= nu[y]
                    for z in zeta:
                        w *= muR[z]
                    # restricted triple on Z_3^L: free rows are T-rows (x_i, y_ib, y_ic) ~ mu_T
                    derr = Fraction(0)
                    for Trows in itertools.product(P3, repeat=len(Lidx)):
                        wt = Fraction(1)
                        for t in Trows:
                            wt *= muT[t]
                        col = {j: [None] * n for j in range(m)}
                        for k, i in enumerate(Oidx):
                            for j in range(m):
                                col[j][i] = outside[k][j]
                        for k, i in enumerate(Lidx):
                            for jj, j in enumerate(R):
                                col[j][i] = zeta[k][jj]
                            s_i = sum(zeta[k]) % Q
                            x_i, yb, yc = Trows[k]
                            col[a][i] = (x_i - s_i) % Q
                            col[b][i] = yb
                            col[c][i] = yc
                        F = (f[a][tuple(col[a])] + sum(f[j][tuple(col[j])] for j in R)) % Q
                        if (F + f[b][tuple(col[b])] + f[c][tuple(col[c])]) % Q == 0:
                            derr += wt
                    total += w * derr
        ok &= total == err
    return ok


def check_counts():
    ok = True
    rng = random.Random(7)
    for m in (4, 5, 6):
        P = set(rows(m))
        for (l1, l2) in itertools.combinations(range(m), 2):
            for u in range(Q):
                for v in range(Q):
                    ok &= sum(1 for y in P if y[l1] == u and y[l2] == v) == 2 * 3 ** (m - 3)
        others = list(itertools.product(range(Q), repeat=m - 1))
        for x in range(Q):
            for xp in range(Q):
                common = sum(1 for v in others if (x + sum(v)) % Q and (xp + sum(v)) % Q)
                ok &= common == (3 ** (m - 2) if x != xp else 2 * 3 ** (m - 2))
        if m <= 5:
            for _ in range(3):
                mu = random_mu(m, rng, rng.choice(["generic", "spiky", "nearpoint"]))
                alpha = min(mu.values())
                for l in range(m):
                    ml = marg(mu, [l])
                    ok &= all(ml[(x,)] >= 2 * 3 ** (m - 2) * alpha for x in range(Q))
                    mrest = marg(mu, [j for j in range(m) if j != l])
                    for x in range(Q):
                        for xp in range(Q):
                            K = Fraction(0)
                            for v, pv in mrest.items():
                                y1 = v[:l] + (x,) + v[l:]
                                y2 = v[:l] + (xp,) + v[l:]
                                if y1 in mu and y2 in mu:
                                    K += (mu[y1] / ml[(x,)]) * (mu[y2] / pv)
                            ok &= K >= 3 ** (m - 2) * alpha ** 2 * ml[(xp,)]
    for m in range(4, 41):
        al = Fraction(1, 2 * 3 ** (m - 1))
        ok &= al ** 2 + (m + 1) * al + Fraction(2 * (m + 1), 3 ** (m - 2)) <= 2
    return ok


def check_constants():
    mpmath.mp.dps = 60
    ok = True
    worst_c = mpmath.mpf(0)
    worst_C = mpmath.mpf(0)
    for k in range(0, 241):
        alpha = mpmath.mpf(10) ** (-12 + k * (12 - mpmath.log10(54)) / 240)
        alpha = min(alpha, mpmath.mpf(1) / 54)
        x = 1 / alpha
        ell = mpmath.log(x)
        a3 = 3 * alpha
        cp = a3 ** 8 / 13107200
        lnCp = mpmath.mpf("1.2e11") * a3 ** -9 * mpmath.log(1 / a3)
        s = mpmath.sqrt(1 - alpha)
        r = 2 * (1 - s) / (2 - s)
        ln_inv_delta1 = (lnCp + mpmath.log(2 * x)) / cp
        lnK = mpmath.log(mpmath.exp(lnCp - ln_inv_delta1) + 15 * x) + ln_inv_delta1
        lnE0 = mpmath.log(4 * x) + r / 2 * lnK
        c = cp * r / 2
        ok &= c > alpha ** 9 / 8000
        worst_c = max(worst_c, (alpha ** 9 / 8000) / c)
        m = 4
        while alpha <= mpmath.mpf(1) / (2 * 3 ** (m - 1)):
            lnC = max(mpmath.log(1 + (m - 1) * mpmath.exp(lnE0)), mpmath.log(4 * (m + 1)) + 4 * ell)
            bound = mpmath.mpf("1.22e10") * x ** 16 * ell
            ok &= lnC <= bound
            worst_C = max(worst_C, lnC / bound)
            m += 1
    return ok, worst_c, worst_C


if __name__ == "__main__":
    rng = random.Random(11)
    allok = True
    for m in (4, 5):
        good = check_decomposition(m, rng)
        print(f"(D) m={m}: bijection, min mu_T >= 3^(m-3) alpha, shared marginals, nu >= mu/2, nu_b = mu_b, "
              f"nu_c = mu_c, nu_bc >= 3^(m-3) alpha >= alpha nu_b nu_c, marginal bounds, for all pairs and a: {good}")
        allok &= good
    good = check_restricted(rng)
    print(f"(I) m=4, n=2: E_L E_rho err_(mu_T)(f^(L,rho)) = err_mu(f) exactly (6 random mu, f): {good}")
    allok &= good
    good = check_counts()
    print(f"(A) m=4,5,6: completion counts 2*3^(m-3) and 3^(m-2), kernel bound K >= 3^(m-2) alpha^2 mu_l, "
          f"mu_j >= 2*3^(m-2) alpha, final arithmetic for m=4..40: {good}")
    allok &= good
    good, wc, wC = check_constants()
    print(f"(C) constants of Theorem 8.78 on alpha in [1e-12, 1/54], all admissible m: c > alpha^9/8000 and "
          f"ln C <= 1.22e10 alpha^-16 ln(1/alpha): {good}; max (alpha^9/8000)/c = {mpmath.nstr(wc, 6)}, "
          f"max ln C / bound = {mpmath.nstr(wC, 6)}")
    allok &= good
    print("all checks passed" if allok else "CHECK FAILED")
    sys.exit(0 if allok else 1)
