"""Checks for Lemma 8.72 / Corollary 8.73 (maximum non-flexible predicates over Z_3).

(Q) Every k-ary quasigroup of order 3 (a map L: Z_3^k -> Z_3 that is a bijection in each
    argument when the others are fixed) is L(a) = e_1 a_1 + ... + e_k a_k + c with e_j in {1, 2}:
    all of them are enumerated by backtracking for k <= 4 (there are 3 * 2^k).
(P) For m = 3, every P in Z_3^3 with 18 points and no flexible coordinate (no axis-parallel line
    inside P) is {a : e_1 a_1 + e_2 a_2 + e_3 a_3 != c}: search over all C(27, 9) nine-point
    complements (this does not use the counting argument of the proof), and, as a cross-check,
    over the 3^9 choices of one missing point on each line in direction 3.
(T) Coordinatewise bijections transport generalized polymorphisms, errors and distances: for the
    isotope P' = {a_1 + a_2 + 2 a_3 != 1} of P_neq, the generalized polymorphisms for n = 1 are
    the images of those of P_neq, and for n = 2 the error of random tuples is preserved exactly.
(I) For n = 1 the generalized polymorphisms of P' = {sum_j e_j a_j != c} are exactly the tuples of the
    intrinsic forms of Remark 8.74(a): all functions but one, g_b, constant (u_j), with g_b avoiding
    the unique t with e_b t + sum_{j != b} e_j u_j = c; or g_j = k w_1 + d_j with sum_j e_j d_j = (1 - k) c.
"""
import itertools
import random
from fractions import Fraction

Z3 = range(3)


def quasigroups(k):
    cells = list(itertools.product(Z3, repeat=k))
    index = {c: i for i, c in enumerate(cells)}
    val = [None] * len(cells)
    out = []

    def ok(i, v):
        c = cells[i]
        for j in range(k):
            for t in Z3:
                if t == c[j]:
                    continue
                d = c[:j] + (t,) + c[j + 1:]
                if val[index[d]] == v:
                    return False
        return True

    def rec(i):
        if i == len(cells):
            out.append(tuple(val))
            return
        for v in Z3:
            if ok(i, v):
                val[i] = v
                rec(i + 1)
                val[i] = None

    rec(0)
    return cells, out


def is_affine_unit(cells, table, k):
    c = table[0]
    e = []
    for j in range(k):
        unit = tuple(1 if l == j else 0 for l in range(k))
        e.append((table[cells.index(unit)] - c) % 3)
    if any(x == 0 for x in e):
        return False
    return all(table[i] == (sum(e[j] * a[j] for j in range(k)) + c) % 3 for i, a in enumerate(cells))


def check_Q():
    for k in range(1, 5):
        cells, qs = quasigroups(k)
        assert len(qs) == 3 * 2 ** k, (k, len(qs))
        assert all(is_affine_unit(cells, t, k) for t in qs)
        print(f"(Q) k={k}: {len(qs)} quasigroups of order 3 (= 3*2^k), all affine with unit coefficients")


def lines(m):
    for j in range(m):
        for rest in itertools.product(Z3, repeat=m - 1):
            yield [rest[:j] + (t,) + rest[j:] for t in Z3]


def check_P():
    m = 3
    all_lines = list(lines(m))
    forms = set()
    for e in itertools.product((1, 2), repeat=m):
        for c in Z3:
            forms.add(frozenset(a for a in itertools.product(Z3, repeat=m)
                                if sum(x * y for x, y in zip(e, a)) % 3 != c))
    found = set()
    for L in itertools.product(Z3, repeat=9):
        missing = {(a, b, L[3 * a + b]) for a in Z3 for b in Z3}
        P = frozenset(x for x in itertools.product(Z3, repeat=m) if x not in missing)
        if all(not all(pt in P for pt in line) for line in all_lines):
            found.add(P)
    assert len(found) == 12 and found == forms, (len(found), len(forms))

    # P has no axis-parallel line iff its complement Q meets all 27 lines; scan all 9-point sets Q.
    pts = list(itertools.product(Z3, repeat=m))
    pidx = {p: i for i, p in enumerate(pts)}
    linemask = [0] * len(pts)
    for li, line in enumerate(all_lines):
        for p in line:
            linemask[pidx[p]] |= 1 << li
    full = (1 << len(all_lines)) - 1
    found_all = set()
    scanned = 0
    for Qs in itertools.combinations(range(len(pts)), 9):
        scanned += 1
        msk = 0
        for i in Qs:
            msk |= linemask[i]
        if msk == full:
            found_all.add(frozenset(pts[i] for i in range(len(pts)) if i not in Qs))
    assert scanned == 4686825
    assert found_all == forms, (len(found_all), len(forms))
    print(f"(P) m=3: {len(found_all)} predicates with 18 points and no flexible coordinate among all "
          f"{scanned} = C(27,9) nine-point complements, all of the form sum e_j a_j != c "
          f"({len(forms)} distinct such sets); the 3^9 one-missing-point-per-line scan agrees")


def gp_count(P, n):
    pts = list(itertools.product(Z3, repeat=n))
    funcs = list(itertools.product(Z3, repeat=len(pts)))
    rows = list(P)
    mats = list(itertools.product(rows, repeat=n))
    cols = [tuple(tuple(r[j] for r in M) for j in range(3)) for M in mats]
    pidx = {p: i for i, p in enumerate(pts)}
    sols = []
    for f1 in funcs:
        for f2 in funcs:
            # f3 must avoid, at every point z, the values forced by some matrix
            bad = [set() for _ in pts]
            for c1, c2, c3 in cols:
                v1, v2 = f1[pidx[c1]], f2[pidx[c2]]
                for v in Z3:
                    if (v1, v2, v) not in P:
                        bad[pidx[c3]].add(v)
            choices = [[v for v in Z3 if v not in bad[i]] for i in range(len(pts))]
            for f3 in itertools.product(*choices):
                sols.append((f1, f2, f3))
    return pts, sols


def check_T():
    Pneq = frozenset(a for a in itertools.product(Z3, repeat=3) if sum(a) % 3 != 0)
    # sigma maps P_neq onto P' = {b : b1 + b2 + 2 b3 != 1}: b1 = a1 + 1, b2 = a2, b3 = 2 a3.
    sig = [lambda t: (t + 1) % 3, lambda t: t, lambda t: (2 * t) % 3]
    sig_inv = [lambda t: (t - 1) % 3, lambda t: t, lambda t: (2 * t) % 3]
    Pp = frozenset(tuple(sig[j](a[j]) for j in range(3)) for a in Pneq)
    assert Pp == frozenset(b for b in itertools.product(Z3, repeat=3) if (b[0] + b[1] + 2 * b[2]) % 3 != 1)
    pts, sols = gp_count(Pneq, 1)
    _, solsp = gp_count(Pp, 1)
    image = {tuple(tuple(sig[j](f[pts.index((sig_inv[j](x[0]),))]) for x in pts) for j, f in enumerate(s))
             for s in sols}
    assert image == set(solsp), (len(image), len(solsp))
    print(f"(T) n=1: P_neq and P' each have {len(sols)} generalized polymorphisms; sigma maps one set onto the other")

    n = 2
    pts2 = list(itertools.product(Z3, repeat=n))
    pidx = {p: i for i, p in enumerate(pts2)}
    rows = list(Pneq)
    mats = list(itertools.product(rows, repeat=n))
    rnd = random.Random(1)
    for _ in range(200):
        f = [[rnd.randrange(3) for _ in pts2] for _ in range(3)]
        fp = [[sig[j](f[j][pidx[tuple(sig_inv[j](t) for t in x)]]) for x in pts2] for j in range(3)]
        e = Fraction(sum(1 for M in mats
                         if tuple(f[j][pidx[tuple(r[j] for r in M)]] for j in range(3)) not in Pneq), len(mats))
        matsp = [tuple(tuple(sig[j](r[j]) for j in range(3)) for r in M) for M in mats]
        ep = Fraction(sum(1 for M in matsp
                          if tuple(fp[j][pidx[tuple(r[j] for r in M)]] for j in range(3)) not in Pp), len(mats))
        assert e == ep
    print("(T) n=2: error preserved exactly for 200 random triples")


def check_I():
    e, c = (1, 1, 2), 1
    Pp = frozenset(b for b in itertools.product(Z3, repeat=3) if sum(x * y for x, y in zip(e, b)) % 3 != c)
    pts, sols = gp_count(Pp, 1)
    intrinsic = set()
    for b in range(3):
        others = [j for j in range(3) if j != b]
        for us in itertools.product(Z3, repeat=2):
            s = sum(e[j] * u for j, u in zip(others, us))
            t = next(t for t in Z3 if (e[b] * t + s) % 3 == c)
            for gb in itertools.product([v for v in Z3 if v != t], repeat=len(pts)):
                g = [None] * 3
                for j, u in zip(others, us):
                    g[j] = tuple([u] * len(pts))
                g[b] = gb
                intrinsic.add(tuple(g))
    nB = 0
    for k in (1, 2):
        for d in itertools.product(Z3, repeat=3):
            if sum(x * y for x, y in zip(e, d)) % 3 == ((1 - k) * c) % 3:
                nB += 1
                intrinsic.add(tuple(tuple((k * x[0] + d[j]) % 3 for x in pts) for j in range(3)))
    assert nB == 18
    assert intrinsic == set(sols), (len(intrinsic), len(sols))
    print(f"(I) n=1: the {len(sols)} generalized polymorphisms of P' are exactly the tuples of the two intrinsic "
          f"forms ({nB} tuples of the second form)")


if __name__ == "__main__":
    check_Q()
    check_P()
    check_T()
    check_I()
    print("all checks passed")
