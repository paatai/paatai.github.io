"""P^(m) = {a in Z_3^m : a_1+...+a_m != 0}, m >= 4, under full-support distributions with uniform marginals
(Theorem 8.80). alpha = min mu, alpha' = 3^(m-3) alpha in (0, 1/18].

Checks:
 (U)  exact (rationals), m = 4, 5: random full-support mu with uniform marginals (pi_m plus a random exact
      perturbation in the kernel of the marginal map, at 1/2, 9/10 and 999/1000 of the largest admissible size;
      and averages of random generic or spiky weights over the translations t with sum t = 0, t_(m-1) = t_m):
      alpha' <= 1/18; sigma = 9 alpha' = 3^(m-1) alpha <= 1/2; sigma pi_m = alpha/2 on P^(m);
      nu = (mu - sigma pi_m)/(1 - sigma) >= alpha/2 is a distribution with uniform marginals; every pair of entries
      has 2*3^(m-3) completions; nu_jl(a, b) >= alpha' = 9 alpha' nu_j(a) nu_l(b) for all j != l; and the kernel
      K(a, a') = sum_b Pr[y_l = b | y_j = a] Pr[y_j = a' | y_l = b] of Lemma 8.59 satisfies K >= 9 alpha' nu_j(a').
 (S)  exact, m = 4, 5, 6 and alpha' in {1/18, 1/45, 1/100, 1/1000}: mu^sh_(m,alpha) (mass alpha on the
      4*3^(m-2) elements with a_m != a_(m-1)+1, mass (1 - 4*3^(m-2) alpha)/(2*3^(m-2)) on the other 2*3^(m-2)):
      (a_1..a_(m-2), b, b+1) is in P^(m) iff b != a_1+...+a_(m-2)+1; total mass 1, full support, min alpha;
      invariance under the 3^(m-2) translations with sum t = 0, t_(m-1) = t_m, the translations of Remark 8.71(c)
      shifting entry j by s; uniform marginals; Pr[y_(m-1) = 0, y_m != 1] = 4 alpha' with all these rows of mass
      alpha; the four classes (1[y_(m-1) = 0], 1[y_m = 1]) have probabilities 1/3 - 4 alpha', 4 alpha', 4 alpha',
      2/3 - 4 alpha', those of mu^sh_(alpha') for m = 3 (Proposition 8.62(b)); mu^sh_(m,alpha) = pi_m at
      alpha' = 1/18.
 (F)  m = 4, n = 3, brute force over all 54^3 row tuples (alpha' = 1/45): N_0(c_3) - N_1(c_4) <= D =
      #{i : y_i3 = 0, y_i4 != 1}; the law of (N_0(c_3), N_1(c_4), D) equals the multinomial formula over the four
      classes; and the error of f = (0, 0, 1_A, 1 + 1_B), computed from the functions, equals the formula.
 (E)  m = 4, the error bound exactly (integers) for n = 3k <= 24, alpha' in {1/45, 1/100, 1/400}, every T in
      [1, k]: err <= Pr[Bin(n, 4 alpha') >= 2T] <= C(n, 2T)(4 alpha')^(2T) <= (4 e alpha' n/(2T))^(2T), and at
      T = ceil(tau n), tau = 2 e^2 alpha', also <= e^(-2T) <= e^(-2 tau n).
 (D)  m = 4, n = 3, 6, 9, every T in [1, k]: the minimum of dist(f, g) over all generalized polymorphisms g (type
      (A_4): three constants and a fourth function avoiding minus their sum, in closed form; type (B_4):
      kappa w_i + d_j with d_1+...+d_4 = 0) under the uniform measure is >= min(Pr A, Pr B) whenever
      Pr A, Pr B <= 1/2.
 (K)  the numerical inequalities of the proof (mpmath, 50 digits), alpha' on a grid in [1e-12, 1/18] and
      m in {4..60, 100, 789, 790, 1000, 10^4}: (4m-3) alpha' delta_m + 14/9 + alpha' <= 2 (so K_1 = 2/(alpha' delta_m));
      2 sqrt(delta_m) < 1/10; X = alpha'^(-3/2) delta_m^(-1/2) >= 18^(3/2)*4e7 > 3e9; 1 + (sqrt2/3)(m-1) X <=
      (m/2) X; with r = r_(9 alpha') = 2 kappa/(1 + kappa + sqrt(1 - kappa)) at kappa = 9 alpha': 8 alpha' <= r
      < 9 alpha' (r/kappa = 2/(2 + t(1 - t)), t = sqrt(1 - kappa), Lemma 8.35); (4(m+1))^(1/4) >= 2; the trivial and the beta >= 1/2 cases, 1 < (4(m+1) delta/alpha^4)^(r/2) <=
      (4(m+1))^(1/4) alpha^-1 delta^(r/2) for delta > alpha^4/(4(m+1)) and 2 delta/alpha^4 <= (4(m+1))^(1/4)
      alpha^-1 delta^(r/2) for delta <= alpha^4/(4(m+1)); eps = K_1^(r/2) delta^(r/2)/(3 alpha') <=
      (sqrt2/3) X delta^(r/2); tau = 2 e^2 alpha' < 1/3 for alpha' <= 1/45; and (9/2) e^2 < 33.26, 4 e^2 < 30,
      (9/4) e^2 < 17, (9/8) e^2 < 8.4.
"""
import itertools
import math
import random
from fractions import Fraction

import mpmath
import numpy as np

mpmath.mp.dps = 50
Q = 3
E = mpmath.e


def rows(m):
    return [a for a in itertools.product(range(Q), repeat=m) if sum(a) % Q != 0]


def marg(mu, idx):
    out = {}
    for a, p in mu.items():
        k = tuple(a[i] for i in idx)
        out[k] = out.get(k, 0) + p
    return out


def solve(G, b):
    n = len(G)
    M = [row[:] + [b[i]] for i, row in enumerate(G)]
    for c in range(n):
        piv = next(r for r in range(c, n) if M[r][c] != 0)
        M[c], M[piv] = M[piv], M[c]
        inv = 1 / M[c][c]
        M[c] = [x * inv for x in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c]
                M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][n] for i in range(n)]


def kernel_direction(P, m, rng):
    """A random exact rational vector v on P with all marginals of v equal to 0."""
    B = [[Fraction(int(a[j] == v)) for a in P] for j in range(m) for v in (0, 1)] + [[Fraction(1)] * len(P)]
    x = [Fraction(rng.randint(-50, 50)) for _ in P]
    G = [[sum(r1[i] * r2[i] for i in range(len(P))) for r2 in B] for r1 in B]
    y = solve(G, [sum(r[i] * x[i] for i in range(len(P))) for r in B])
    v = [x[i] - sum(y[k] * B[k][i] for k in range(len(B))) for i in range(len(P))]
    for j in range(m):
        for s in range(Q):
            assert sum(vi for vi, a in zip(v, P) if a[j] == s) == 0
    return v


def group(m):
    return [t for t in itertools.product(range(Q), repeat=m) if sum(t) % Q == 0 and t[m - 2] == t[m - 1]]


def random_unif_mu(m, rng, mode, lam=None):
    P = rows(m)
    pim = Fraction(1, 2 * 3 ** (m - 1))
    if mode == "kernel":
        v = kernel_direction(P, m, rng)
        epsmax = min(pim / (-vi) for vi in v if vi < 0)
        return {a: pim + lam * epsmax * vi for a, vi in zip(P, v)}
    if mode == "generic":
        w = {a: rng.randint(1, 50) for a in P}
    else:
        w = {a: rng.choice([1, 1, 1, 10 ** 6]) for a in P}
    G = group(m)
    avg = {a: sum(w[tuple((x + y) % Q for x, y in zip(a, t))] for t in G) for a in P}
    s = sum(avg.values())
    return {a: Fraction(x, s) for a, x in avg.items()}


def check_U():
    rng = random.Random(2026)
    out = []
    for m in (4, 5):
        P = rows(m)
        pim = Fraction(1, 2 * 3 ** (m - 1))
        for (j, l) in itertools.combinations(range(m), 2):
            for u in range(Q):
                for v in range(Q):
                    assert sum(1 for y in P if y[j] == u and y[l] == v) == 2 * 3 ** (m - 3)
        cases = [("kernel", Fraction(1, 2)), ("kernel", Fraction(9, 10)), ("kernel", Fraction(999, 1000))] * 2
        cases += [("generic", None)] * 3 + [("spiky", None)] * 3
        amin = Fraction(1)
        for mode, lam in cases:
            mu = random_unif_mu(m, rng, mode, lam)
            assert sum(mu.values()) == 1 and set(mu) == set(P) and all(p > 0 for p in mu.values())
            for j in range(m):
                assert marg(mu, [j]) == {(s,): Fraction(1, 3) for s in range(Q)}
            alpha = min(mu.values())
            amin = min(amin, alpha)
            ap = 3 ** (m - 3) * alpha
            assert ap <= Fraction(1, 18)
            sigma = 9 * ap
            assert sigma == 3 ** (m - 1) * alpha and sigma <= Fraction(1, 2) and sigma * pim == alpha / 2
            nu = {a: (p - sigma * pim) / (1 - sigma) for a, p in mu.items()}
            assert sum(nu.values()) == 1 and min(nu.values()) >= alpha / 2
            for a in P:
                assert sigma * pim + (1 - sigma) * nu[a] == mu[a]
            nus = [marg(nu, [j]) for j in range(m)]
            for j in range(m):
                assert nus[j] == {(s,): Fraction(1, 3) for s in range(Q)}
            for (j, l) in itertools.permutations(range(m), 2):
                njl = marg(nu, [j, l])
                for x in range(Q):
                    for y in range(Q):
                        assert njl[(x, y)] >= ap == 9 * ap * nus[j][(x,)] * nus[l][(y,)]
                for x in range(Q):
                    for xp in range(Q):
                        K = sum((njl[(x, b)] / nus[j][(x,)]) * (njl[(xp, b)] / nus[l][(b,)]) for b in range(Q))
                        assert K == 9 * sum(njl[(x, b)] * njl[(xp, b)] for b in range(Q))
                        assert K >= 9 * ap * nus[j][(xp,)]
        out.append(f"m={m}: {len(cases)} distributions, smallest alpha' = {float(3 ** (m - 3) * amin):.3g}")
    print("(U) decomposition, nu >= alpha/2, uniform nu-marginals, 2*3^(m-3) completions, nu_jl >= alpha' ="
          " 9 alpha' nu_j nu_l, K >= 9 alpha' nu_j:", "; ".join(out), ": ok")


def mu_sh(m, alpha):
    big = (1 - 4 * 3 ** (m - 2) * alpha) / (2 * 3 ** (m - 2))
    return {a: (big if a[m - 1] == (a[m - 2] + 1) % Q else alpha) for a in rows(m)}


def cls(a, m):
    return (int(a[m - 2] == 0), int(a[m - 1] == 1))


def check_S():
    for m in (4, 5, 6):
        P = rows(m)
        for a in itertools.product(range(Q), repeat=m - 2):
            for b in range(Q):
                y = a + (b, (b + 1) % Q)
                assert ((sum(y) % Q) != 0) == (b != (sum(a) + 1) % Q)
        G = group(m)
        assert len(G) == 3 ** (m - 2)
        shifts = {}
        for j in range(m):
            for s in range(Q):
                t = [0] * m
                if j <= m - 3:
                    t[j] = t[m - 2] = t[m - 1] = s
                else:
                    t[0] = t[m - 2] = t[m - 1] = s
                assert tuple(t) in G and t[j] == s
                shifts[(j, s)] = tuple(t)
        for M in (18, 45, 100, 1000):
            ap = Fraction(1, M)
            alpha = ap / 3 ** (m - 3)
            mu = mu_sh(m, alpha)
            big = [a for a in P if a[m - 1] == (a[m - 2] + 1) % Q]
            assert len(big) == 2 * 3 ** (m - 2) and len(P) - len(big) == 4 * 3 ** (m - 2)
            assert sum(mu.values()) == 1 and min(mu.values()) == alpha and all(p > 0 for p in mu.values())
            for t in G:
                for a in P:
                    assert mu[tuple((x + y) % Q for x, y in zip(a, t))] == mu[a]
            for j in range(m):
                assert marg(mu, [j]) == {(s,): Fraction(1, 3) for s in range(Q)}
            drows = [a for a in P if a[m - 2] == 0 and a[m - 1] != 1]
            assert len(drows) == 4 * 3 ** (m - 3) and all(mu[a] == alpha for a in drows)
            assert sum(mu[a] for a in drows) == 4 * ap
            pc = {(s, t): sum(p for a, p in mu.items() if cls(a, m) == (s, t)) for s in (0, 1) for t in (0, 1)}
            assert pc == {(1, 1): Fraction(1, 3) - 4 * ap, (1, 0): 4 * ap, (0, 1): 4 * ap,
                          (0, 0): Fraction(2, 3) - 4 * ap}
            mu3 = mu_sh(3, ap)
            assert pc == {(s, t): sum(p for a, p in mu3.items() if cls(a, 3) == (s, t)) for s in (0, 1) for t in (0, 1)}
            if M == 18:
                assert all(p == Fraction(1, 2 * 3 ** (m - 1)) for p in mu.values())
    print("(S) mu^sh_(m,alpha), m=4,5,6: counts, full support, min alpha, invariance, uniform marginals,"
          " Pr[y_(m-1)=0, y_m!=1] = 4 alpha', class law = that of mu^sh_(alpha') for m=3, = pi_m at alpha'=1/18: ok")


def joint_law_formula(p, n):
    law = {}
    f = math.factorial
    for n11 in range(n + 1):
        for n10 in range(n + 1 - n11):
            for n01 in range(n + 1 - n11 - n10):
                n00 = n - n11 - n10 - n01
                coef = f(n) // (f(n11) * f(n10) * f(n01) * f(n00))
                pr = coef * p[(1, 1)] ** n11 * p[(1, 0)] ** n10 * p[(0, 1)] ** n01 * p[(0, 0)] ** n00
                key = (n11 + n10, n11 + n01, n10)
                law[key] = law.get(key, 0) + pr
    return law


def check_F():
    m, n, k, T = 4, 3, 1, 1
    alpha = Fraction(1, 135)
    mu = mu_sh(m, alpha)
    den = 270
    w = {a: int(p * den) for a, p in mu.items()}
    assert all(Fraction(w[a], den) == mu[a] for a in mu)
    P = rows(m)
    law = {}
    err = 0
    for tup in itertools.product(P, repeat=n):
        n0 = sum(r[2] == 0 for r in tup)
        n1 = sum(r[3] == 1 for r in tup)
        d = sum(r[2] == 0 and r[3] != 1 for r in tup)
        assert n0 - n1 <= d
        wt = 1
        for r in tup:
            wt *= w[r]
        law[(n0, n1, d)] = law.get((n0, n1, d), 0) + wt
        f3 = int(n0 >= k + T)
        f4 = 1 + int(n1 <= k - T)
        if (0 + 0 + f3 + f4) % Q == 0:
            err += wt
    pc = {(s, t): sum(w[a] for a in P if cls(a, m) == (s, t)) for s in (0, 1) for t in (0, 1)}
    lf = {key: v for key, v in joint_law_formula(pc, n).items() if v != 0}
    assert law == lf
    assert err == sum(v for (n0, n1, d), v in lf.items() if n0 >= k + T and n1 <= k - T)
    print(f"(F) m=4, n=3, all 54^3 row tuples: N_0(c_3) - N_1(c_4) <= D; multinomial law = brute force; "
          f"err(0,0,1_A,1+1_B) = {Fraction(err, den ** n)} from the functions = formula: ok")


def check_E():
    worst = 0.0
    count = 0
    m = 4
    for M in (45, 100, 400):
        ap = Fraction(1, M)
        tau = 2 * E ** 2 / M
        mu = mu_sh(m, ap / 3)
        w = {(1, 1): M - 12, (1, 0): 12, (0, 1): 12, (0, 0): 2 * M - 12}
        for (s, t), wt in w.items():
            assert Fraction(wt, 3 * M) == sum(p for a, p in mu.items() if cls(a, m) == (s, t))
        for n in range(3, 25, 3):
            k = n // 3
            law = joint_law_formula(w, n)
            Tstar = int(mpmath.ceil(tau * n))
            assert 1 <= Tstar <= k
            for T in range(1, k + 1):
                err_int = sum(v for (n0, n1, d), v in law.items() if n0 >= k + T and n1 <= k - T)
                bin_int = sum(math.comb(n, d) * 4 ** d * (M - 4) ** (n - d) for d in range(2 * T, n + 1))
                assert err_int <= bin_int * 3 ** n
                union = Fraction(math.comb(n, 2 * T) * 4 ** (2 * T), M ** (2 * T)) if 2 * T <= n else Fraction(0)
                assert Fraction(bin_int, M ** n) <= union
                if 2 * T <= n:
                    chern = (4 * E * n / (M * 2 * T)) ** (2 * T)
                    assert mpmath.mpf(union.numerator) / union.denominator <= chern
                    if T == Tstar:
                        assert chern <= (2 * E / (M * tau)) ** (2 * T) * (1 + mpmath.mpf(10) ** -40)
                        assert abs((2 * E / (M * tau)) ** (2 * T) - mpmath.exp(-2 * T)) < mpmath.mpf(10) ** -40
                        assert mpmath.exp(-2 * T) <= mpmath.exp(-2 * tau * n)
                if bin_int:
                    worst = max(worst, float(mpmath.mpf(err_int) / (mpmath.mpf(bin_int) * 3 ** n)))
                count += 1
    print(f"(E) m=4: err <= Pr[Bin(n,4 alpha') >= 2T] <= C(n,2T)(4 alpha')^2T <= (4e alpha' n/2T)^2T, and"
          f" <= e^-2T <= e^(-2 tau n) at T = ceil(tau n): {count} cases (n <= 24), max err/Pr[D >= 2T] ="
          f" {worst:.4f}: ok")


def check_D():
    m = 4
    out = []
    for n in (3, 6, 9):
        k = n // 3
        pts = np.array(list(itertools.product(range(Q), repeat=n)), dtype=np.int64)
        size = len(pts)
        N0 = (pts == 0).sum(axis=1)
        N1 = (pts == 1).sum(axis=1)
        for T in range(1, k + 1):
            f = [np.zeros(size, dtype=np.int64), np.zeros(size, dtype=np.int64),
                 (N0 >= k + T).astype(np.int64), (1 + (N1 <= k - T).astype(np.int64)) % Q]
            PA = Fraction(int(f[2].sum()), size)
            PB = Fraction(int((f[3] == 2).sum()), size)
            cnt = [[int((fj == v).sum()) for v in range(Q)] for fj in f]
            best = Fraction(1)
            for b in range(m):
                others = [j for j in range(m) if j != b]
                for us in itertools.product(range(Q), repeat=m - 1):
                    vbad = (-sum(us)) % Q
                    dd = max([Fraction(size - cnt[j][u], size) for j, u in zip(others, us)]
                             + [Fraction(cnt[b][vbad], size)])
                    best = min(best, dd)
            for i in range(n):
                for kappa in (1, 2):
                    for ds in itertools.product(range(Q), repeat=m):
                        if sum(ds) % Q:
                            continue
                        dd = max(Fraction(int((f[t] != (kappa * pts[:, i] + ds[t]) % Q).sum()), size)
                                 for t in range(m))
                        best = min(best, dd)
            if PA <= Fraction(1, 2) and PB <= Fraction(1, 2):
                assert best >= min(PA, PB), (n, T, best, PA, PB)
                out.append(f"n={n},T={T}: min dist {best} >= min(PA,PB) = {min(PA, PB)}")
            else:
                out.append(f"n={n},T={T}: PA={PA}, PB={PB} (hypothesis fails; skipped)")
    print("(D) m=4, distance against all generalized polymorphisms:", "; ".join(out), ": ok")


def r_of(kappa):
    s = mpmath.sqrt(1 - kappa)
    r = 2 * (1 - s) / (2 - s)
    assert abs(r - 2 * kappa / (1 + kappa + s)) < mpmath.mpf(10) ** -45
    return r


def check_K():
    e2 = E ** 2
    assert mpmath.mpf(9) / 2 * e2 < mpmath.mpf("33.26") and 4 * e2 < 30 and 2 * e2 / 45 < mpmath.mpf(1) / 3
    assert mpmath.mpf(9) / 4 * e2 < 17
    assert mpmath.mpf(9) / 8 * e2 < mpmath.mpf("8.4")
    ms = list(range(4, 61)) + [100, 789, 790, 1000, 10 ** 4]
    worst = {"K1": 0, "X": mpmath.inf, "conc": 0, "triv": 0, "beta": 0, "eps": 0}
    for mm in range(3, 13):
        end = Fraction(1, 2 * 3 ** (mm - 1))
        for al in (end, end * Fraction(99, 100), end * Fraction(101, 100)):
            ok = (1 - 4 * 3 ** (mm - 2) * al) / (2 * 3 ** (mm - 2)) >= al
            assert ok == (al <= end)
    for kk in range(0, 201):
        ap = mpmath.mpf(10) ** (-12 + kk * (12 - mpmath.log10(18)) / 200)
        ap = min(ap, mpmath.mpf(1) / 18)
        kappa = 9 * ap
        r = r_of(kappa)
        assert 8 * kappa / 9 <= r < kappa and kappa <= mpmath.mpf(1) / 2
        if ap <= mpmath.mpf(1) / 45:
            assert 2 * e2 * ap < mpmath.mpf(1) / 3
        for m in ms:
            dm = min(mpmath.mpf("5e-16"), (6 * mpmath.sqrt(2) * (m - 1)) ** -4)
            assert 2 * mpmath.sqrt(dm) < mpmath.mpf(1) / 10
            lhs = (4 * m - 3) * ap * dm + mpmath.mpf(14) / 9 + ap
            assert lhs <= 2
            worst["K1"] = max(worst["K1"], lhs / 2)
            X = ap ** mpmath.mpf(-1.5) / mpmath.sqrt(dm)
            assert X >= mpmath.mpf(18) ** mpmath.mpf(1.5) * 4 * 10 ** 7 > 3 * 10 ** 9
            worst["X"] = min(worst["X"], X)
            conc = (1 + mpmath.sqrt(2) / 3 * (m - 1) * X) / (mpmath.mpf(m) / 2 * X)
            assert conc <= 1
            worst["conc"] = max(worst["conc"], conc)
            K1 = 2 / (ap * dm)
            assert K1 >= 1
            eps_coef = K1 ** (r / 2) / (3 * ap)
            assert eps_coef <= mpmath.sqrt(2) / 3 * X
            worst["eps"] = max(worst["eps"], eps_coef / (mpmath.sqrt(2) / 3 * X))
            q4 = mpmath.mpf(4 * (m + 1)) ** mpmath.mpf(0.25)
            assert q4 >= 2
            ln_alpha = mpmath.log(ap) - (m - 3) * mpmath.log(3)
            alpha = mpmath.exp(ln_alpha)
            d0 = alpha ** 4 / (4 * (m + 1))
            for t in (mpmath.mpf(1), mpmath.mpf(10) ** -3, mpmath.mpf(10) ** -30):
                d = d0 * t
                lhs_b = 2 * d / alpha ** 4
                rhs_b = q4 / alpha * d ** (r / 2)
                assert lhs_b <= rhs_b
                worst["beta"] = max(worst["beta"], lhs_b / rhs_b)
            for t in (mpmath.mpf(1) + mpmath.mpf(10) ** -20, mpmath.mpf(2), 1 / d0):
                d = min(d0 * t, mpmath.mpf(1))
                mid = (4 * (m + 1) * d / alpha ** 4) ** (r / 2)
                assert 1 < mid <= q4 / alpha * d ** (r / 2) * (1 + mpmath.mpf(10) ** -40)
                worst["triv"] = max(worst["triv"], mid / (q4 / alpha * d ** (r / 2)))
    print(f"(K) constants on alpha' in [1e-12, 1/18], m in 4..60 and {ms[-5:]}: max ((4m-3)a'd_m+14/9+a')/2 ="
          f" {mpmath.nstr(worst['K1'], 6)}; min X = {mpmath.nstr(worst['X'], 6)} > 3e9; max (1+(sqrt2/3)(m-1)X)/"
          f"((m/2)X) = {mpmath.nstr(worst['conc'], 6)}; max eps/((sqrt2/3)X d^(r/2)) = {mpmath.nstr(worst['eps'], 6)};"
          f" max ratios in the beta and trivial cases = {mpmath.nstr(worst['beta'], 6)},"
          f" {mpmath.nstr(worst['triv'], 6)}; 8a' <= r < 9a'; 2e^2/45 < 1/3; (9/2)e^2 ="
          f" {mpmath.nstr(mpmath.mpf(9) / 2 * e2, 8)}, 4e^2 = {mpmath.nstr(4 * e2, 6)},"
          f" (9/4)e^2 = {mpmath.nstr(mpmath.mpf(9) / 4 * e2, 6)}, (9/8)e^2 = {mpmath.nstr(mpmath.mpf(9) / 8 * e2, 6)} < 8.4: ok")


if __name__ == "__main__":
    check_U()
    check_S()
    check_F()
    check_E()
    check_D()
    check_K()
    print("all checks passed")
