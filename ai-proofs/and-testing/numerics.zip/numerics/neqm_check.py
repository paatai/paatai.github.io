"""The m-ary predicate P^(m) = {a in Z_3^m : a_1+...+a_m != 0}, m >= 4, uniform distribution (Theorem 8.70).

Exact checks (rational arithmetic, enumeration of all row tuples):
 (R)  the reduction: (a_1..a_m) -> (a_1 + a_4 + ... + a_m, a_2, a_3, a_4, ..., a_m) maps P^(m) bijectively
      onto P_neq x Z_3^(m-3); so under the uniform law the new first three entries are uniform on P_neq and
      independent of the last m-3 entries.  Also: any m-1 entries of a uniform row are uniform, and given one
      entry the row sum is uniform on {1, 2}.
 (a1) n = 1, m = 4: all 27^4 tuples (g_1..g_4) of maps Z_3 -> Z_3; the generalized polymorphisms are exactly
      the types (A_4) and (B_4) (702 + 54 = 756).
 (b1) n = 1, m = 4: for all 27^4 tuples, the exact error and the exact distance to the nearest generalized
      polymorphism; both bounds of (b) hold, and the largest ratio dist / sqrt(delta) is 1.2649 (at
      delta = 5/18), so ratios above 1 do occur when delta is large.
 (c)  the sharp example f_1 = ... = f_{m-2} = 0, f_{m-1} = 1_E, f_m = 1 + 1_E: err = eta^2 and distance eta
      to the nearest generalized polymorphism (n <= 3 for m = 4, n <= 2 for m = 5).
 (b)  random perturbations of generalized polymorphisms (m = 4, n = 2, 3; m = 5, n = 2): the distance to the
      nearest generalized polymorphism (types (A_m), (B_m), which are all of them by (a)) is at most
      sqrt(delta) + (2 + 12 (m-1)^2) delta and at most (1 + 2 m delta^(1/4)) sqrt(delta); the largest observed
      ratio dist / sqrt(delta) is reported.
 (d)  for the perturbations of type-(B_m) tuples within distance 1/10 of type (B_m) (the hypothesis of (d)):
      the linear bound sum_j Pr[f_j != g_j] <= 3 delta for the nearest type-(B_m) tuple g.  For n = 2 the
      hypothesis forces distance 0 (probabilities are multiples of 1/9), so only n = 3 gives non-vacuous checks;
      their number is reported.
 (e)  Remark 8.71(c): the distribution mu^(alpha)_m (mass alpha on the 2*3^(m-2) rows with a_(m-1) = a_m,
      the rest spread evenly) has uniform marginals and minimum alpha (m = 3, 4, 5); the example of (c) with
      E = {0} in Z_3^k has error exactly (2*3^(m-3)*alpha)^k under mu^(alpha)_m and distance >= 3^-k
      ((m, k) = (4, 1), (4, 2), (5, 1)).
 All tests have delta far above delta_m, so they test the inequalities outside the range where they are claimed.
"""
import itertools
import math
import random
import sys
from fractions import Fraction

import numpy as np

Q = 3


def rows(m):
    return [a for a in itertools.product(range(Q), repeat=m) if sum(a) % Q]


def check_reduction(m):
    P = rows(m)
    img = sorted(tuple([(a[0] + sum(a[3:])) % Q] + list(a[1:])) for a in P)
    target = sorted(b for b in itertools.product(range(Q), repeat=m) if (b[0] + b[1] + b[2]) % Q)
    ok = img == target
    for k in range(m):
        cnt = {}
        for a in P:
            key = a[:k] + a[k + 1:]
            cnt[key] = cnt.get(key, 0) + 1
        ok &= len(cnt) == Q ** (m - 1) and set(cnt.values()) == {2}
    for k in range(m):
        for t in range(Q):
            sums = [sum(a) % Q for a in P if a[k] == t]
            ok &= sums.count(1) == sums.count(2) == len(sums) // 2
    return ok


def gp_n1_count(m):
    P = np.array(rows(m), dtype=np.int64)
    maps = np.array(list(itertools.product(range(Q), repeat=Q)), dtype=np.int64)
    sols = []
    for tup in itertools.product(range(len(maps)), repeat=m):
        s = np.zeros(len(P), dtype=np.int64)
        for j, t in enumerate(tup):
            s += maps[t][P[:, j]]
        if not np.any(s % Q == 0):
            sols.append(tuple(tuple(int(v) for v in maps[t]) for t in tup))
    return sols


def type_A_or_B_n1(g, m):
    consts = [len(set(gj)) == 1 for gj in g]
    for b in range(m):
        if all(consts[j] for j in range(m) if j != b):
            forb = (-sum(g[j][0] for j in range(m) if j != b)) % Q
            if forb not in g[b]:
                return True
    for k in (1, 2):
        ds = []
        for gj in g:
            d = gj[0]
            if any(gj[a] != (k * a + d) % Q for a in range(Q)):
                break
            ds.append(d)
        else:
            if sum(ds) % Q == 0:
                return True
    return False


def ratio_n1(m):
    """All 27^m tuples for n = 1: exact err, exact distance to the nearest generalized polymorphism, and the
    largest ratio dist / sqrt(err) over the tuples with err > 0 (vectorized over tuples)."""
    funcs = np.array(list(itertools.product(range(Q), repeat=Q)), dtype=np.int64)
    ham = (funcs[:, None, :] != funcs[None, :, :]).sum(axis=2)
    P = rows(m)
    F = np.array(list(itertools.product(range(len(funcs)), repeat=m)), dtype=np.int64)
    cnt = np.zeros(len(F), dtype=np.int64)
    for y in P:
        s = np.zeros(len(F), dtype=np.int64)
        for j in range(m):
            s += funcs[F[:, j], y[j]]
        cnt += (s % Q == 0)
    gps = F[cnt == 0]
    best = np.full(len(F), Q + 1, dtype=np.int64)
    for g in gps:
        mx = ham[F[:, 0], g[0]]
        for j in range(1, m):
            mx = np.maximum(mx, ham[F[:, j], g[j]])
        best = np.minimum(best, mx)
    ratios = [(Fraction(int(b), Q) / math.sqrt(c / len(P)), Fraction(int(c), len(P)), Fraction(int(b), Q))
              for c, b in {(int(c), int(b)) for c, b in zip(cnt, best) if c > 0}]
    bounds_ok = all(float(d) <= math.sqrt(e) + (2 + 12 * (m - 1) ** 2) * e and
                    float(d) <= (1 + 2 * m * float(e) ** 0.25) * math.sqrt(e) for _, e, d in ratios)
    return len(gps), max(ratios), bounds_ok


class Setting:
    def __init__(self, m, n):
        self.m, self.n = m, n
        self.pts = list(itertools.product(range(Q), repeat=n))
        idx = {w: t for t, w in enumerate(self.pts)}
        P = rows(m)
        cols = []
        for rs in itertools.product(P, repeat=n):
            cols.append([idx[tuple(r[j] for r in rs)] for j in range(m)])
        self.cols = np.array(cols, dtype=np.int64)
        self.N = len(self.pts)
        self.dict_funcs = {(i, k, d): np.array([(k * w[i] + d) % Q for w in self.pts], dtype=np.int64)
                           for i in range(n) for k in (1, 2) for d in range(Q)}

    def err(self, f):
        s = np.zeros(len(self.cols), dtype=np.int64)
        for j in range(self.m):
            s += f[j][self.cols[:, j]]
        return Fraction(int(np.count_nonzero(s % Q == 0)), len(self.cols))

    def dist_A(self, f):
        m, N = self.m, self.N
        counts = [np.bincount(fj, minlength=Q) for fj in f]
        best = None
        for b in range(m):
            others = [j for j in range(m) if j != b]
            for us in itertools.product(range(Q), repeat=m - 1):
                d = max(N - counts[j][u] for j, u in zip(others, us))
                forb = (-sum(us)) % Q
                d = max(d, counts[b][forb])
                if best is None or d < best:
                    best = d
        return Fraction(best, N)

    def dist_B(self, f):
        m, N = self.m, self.N
        best = None
        bestg = None
        for i in range(self.n):
            for k in (1, 2):
                dis = [[int(np.count_nonzero(f[j] != self.dict_funcs[(i, k, d)])) for d in range(Q)]
                       for j in range(m)]
                for ds in itertools.product(range(Q), repeat=m - 1):
                    dl = (-sum(ds)) % Q
                    full = list(ds) + [dl]
                    d = max(dis[j][full[j]] for j in range(m))
                    if best is None or d < best:
                        best = d
                        bestg = (i, k, tuple(full), sum(dis[j][full[j]] for j in range(m)))
        return Fraction(best, N), bestg

    def dist(self, f):
        return min(self.dist_A(f), self.dist_B(f)[0])


def random_gp(S, rng):
    m, n, N = S.m, S.n, S.N
    if rng.random() < 0.5:
        b = rng.randrange(m)
        us = [rng.randrange(Q) for _ in range(m - 1)]
        forb = (-sum(us)) % Q
        allowed = [v for v in range(Q) if v != forb]
        f = []
        it = iter(us)
        for j in range(m):
            if j == b:
                mode = rng.random()
                if mode < 0.3:
                    f.append(np.full(N, allowed[0], dtype=np.int64))
                else:
                    f.append(np.array([allowed[rng.randrange(2)] for _ in range(N)], dtype=np.int64))
            else:
                f.append(np.full(N, next(it), dtype=np.int64))
        return f, "A"
    i, k = rng.randrange(n), rng.choice((1, 2))
    ds = [rng.randrange(Q) for _ in range(m - 1)]
    ds.append((-sum(ds)) % Q)
    return [S.dict_funcs[(i, k, d)].copy() for d in ds], "B"


def perturb(f, rng, N, maxk):
    g = [fj.copy() for fj in f]
    for j in range(len(g)):
        if rng.random() < 0.6:
            for t in rng.sample(range(N), rng.randint(0, maxk)):
                g[j][t] = (g[j][t] + rng.randrange(1, Q)) % Q
    return g


def mu_alpha(m, alpha):
    P = rows(m)
    nA = sum(1 for a in P if a[m - 2] == a[m - 1])
    beta = (1 - nA * alpha) / (len(P) - nA)
    return {a: (alpha if a[m - 2] == a[m - 1] else beta) for a in P}, nA, len(P) - nA


def check_mu_alpha():
    """Remark 8.71(c): mu^(alpha)_m has uniform marginals and min = alpha; the tuple (0,..,0,1_E,1+1_E) with
    E = {0} in Z_3^k has err = (2*3^(m-3)*alpha)^k under mu^(alpha)_m and distance >= 3^-k (uniform marginals)."""
    ok = True
    for m in (3, 4, 5):
        for alpha in (Fraction(1, 2 * 3 ** (m - 1)), Fraction(1, 100 * 3 ** (m - 1)), Fraction(1, 7 * 3 ** m)):
            mu, nA, nB = mu_alpha(m, alpha)
            ok &= nA == 2 * 3 ** (m - 2) and nB == 4 * 3 ** (m - 2)
            ok &= sum(mu.values()) == 1 and min(mu.values()) == alpha
            ok &= all(sum(p for a, p in mu.items() if a[j] == t) == Fraction(1, Q) for j in range(m) for t in range(Q))
            p00 = sum(p for a, p in mu.items() if a[m - 2] == a[m - 1] == 0)
            ok &= p00 == 2 * Fraction(3) ** (m - 3) * alpha
    for m, k in ((4, 1), (4, 2), (5, 1)):
        alpha = Fraction(1, 5 * 3 ** m)
        mu, _, _ = mu_alpha(m, alpha)
        S = Setting(m, k)
        f = sharp_example(S, {0})
        weights = [math.prod(mu[r] for r in rs) for rs in itertools.product(rows(m), repeat=k)]
        s = np.zeros(len(S.cols), dtype=np.int64)
        for j in range(m):
            s += f[j][S.cols[:, j]]
        err = sum((w for w, bad in zip(weights, s % Q == 0) if bad), Fraction(0))
        ok &= err == (2 * Fraction(3) ** (m - 3) * alpha) ** k and S.dist(f) >= Fraction(1, 3 ** k)
    return ok


def sharp_example(S, E):
    m, N = S.m, S.N
    ind = np.array([1 if t in E else 0 for t in range(N)], dtype=np.int64)
    f = [np.zeros(N, dtype=np.int64) for _ in range(m - 2)] + [ind, (1 + ind) % Q]
    return f


if __name__ == "__main__":
    rng = random.Random(4)
    ok = True
    for m in (4, 5, 6):
        good = check_reduction(m)
        print(f"(R) m={m}: bijection onto P_neq x Z_3^(m-3), (m-1)-wise uniform, row sum uniform on "
              f"{{1,2}} given any entry: {good}")
        ok &= good

    sols = gp_n1_count(4)
    nA_B = sum(type_A_or_B_n1(g, 4) for g in sols)
    good = len(sols) == 756 and nA_B == len(sols)
    print(f"(a1) m=4, n=1: {len(sols)} generalized polymorphisms, all of type (A_4) or (B_4): {good}")
    ok &= good

    ngp, (r, e, d), bounds_ok = ratio_n1(4)
    good = ngp == 756 and bounds_ok
    print(f"(b1) m=4, n=1, all 27^4 tuples: both bounds of (b) hold: {bounds_ok}; largest dist/sqrt(delta) = "
          f"{r:.4f}, at delta = {e} with dist = {d} (far outside delta <= delta_m)")
    ok &= good

    for m, n in ((4, 1), (4, 2), (4, 3), (5, 1), (5, 2)):
        S = Setting(m, n)
        allgood = True
        for size in range(1, S.N // 3 + 1):
            for _ in range(3 if n > 1 else 1):
                E = set(rng.sample(range(S.N), size))
                f = sharp_example(S, E)
                eta = Fraction(size, S.N)
                e = S.err(f)
                d = S.dist(f)
                allgood &= (e == eta * eta and d == eta)
        print(f"(c) m={m}, n={n}: sharp example err = eta^2 and dist = eta for all tested E: {allgood}")
        ok &= allgood

    for m, n, trials, maxk in ((4, 2, 400, 3), (4, 3, 120, 4), (5, 2, 150, 3)):
        S = Setting(m, n)
        worst = 0.0
        bad = 0
        lin_ok = True
        lin_n = 0
        for _ in range(trials):
            f0, typ = random_gp(S, rng)
            f = perturb(f0, rng, S.N, maxk)
            e = S.err(f)
            d = S.dist(f)
            if e == 0:
                if d != 0:
                    bad += 1
                continue
            de = float(e)
            ratio = float(d) / math.sqrt(de)
            worst = max(worst, ratio)
            if float(d) > (1 + 2 * m * de ** 0.25) * math.sqrt(de) + 1e-12:
                bad += 1
            if float(d) > math.sqrt(de) + (2 + 12 * (m - 1) ** 2) * de + 1e-12:
                bad += 1
            dB, gB = S.dist_B(f)
            if typ == "B" and dB <= Fraction(1, 10):
                lin_n += 1
                if Fraction(gB[3], S.N) > 3 * e:
                    lin_ok = False
        good = bad == 0 and lin_ok
        print(f"(b),(d) m={m}, n={n}: {trials} perturbed generalized polymorphisms; "
              f"dist <= sqrt(delta) + (2+12(m-1)^2) delta <= (1+2m delta^(1/4)) sqrt(delta) and exact iff err=0: "
              f"{bad == 0}; largest dist/sqrt(delta) = {worst:.4f}; "
              f"linear bound near (B_m): {lin_ok} ({lin_n} non-vacuous cases)")
        ok &= good

    good = check_mu_alpha()
    print(f"(e) mu^(alpha)_m (m=3,4,5): uniform marginals, min = alpha, Pr[y_(m-1)=y_m=0] = 2*3^(m-3)*alpha; "
          f"(m,k)=(4,1),(4,2),(5,1): err = (2*3^(m-3)*alpha)^k exactly and distance >= 3^-k: {good}")
    ok &= good

    print("all checks passed" if ok else "CHECK FAILED")
    sys.exit(0 if ok else 1)
