#!/usr/bin/env python3
"""Symmetric f(x) = F(|x|): compare eps, the Booleanity lower bound L(f) <= eps, and dist^2 (all F, n <= nmax).

L(f) = sum_w P(|x|=w) [ F(w) D_w + (1-F(w)) T_w ],
  D_w = sum_k C(w,k) 2^-w min(m_{w,k}, 1-m_{w,k}),  m_{w,k} = sum_j C(n-w,j) 2^-(n-w) F(k+j),
  T_w = sum_k C(w,k) 2^-w F(k).
Reports max dist^2/L and max dist^2/eps over all symmetric F.
"""
import sys
from math import comb

import numpy as np

from symmetric_exact import tables


def run(n):
    trip, prob, K = tables(n)
    nF = 1 << (n + 1)
    Fs = ((np.arange(nF)[:, None] >> np.arange(n + 1)[None, :]) & 1).astype(np.int8)
    fa, fx, fy = Fs[:, trip[:, 0]], Fs[:, trip[:, 1]], Fs[:, trip[:, 2]]
    eps = ((fa != (fx & fy)) * prob[None, :]).sum(1)
    dist_and = Fs @ K[:, :, 0].T + (1 - Fs) @ K[:, :, 1].T
    mu = Fs @ K[0, :, 1]
    delta = np.minimum(mu, dist_and.min(1))
    Pw = np.array([comb(n, w) / 2.0 ** n for w in range(n + 1)])
    L = np.zeros(nF)
    Ff = Fs.astype(float)
    for w in range(n + 1):
        # m_{w,k} for k = 0..w : vector over F
        bj = np.array([comb(n - w, j) / 2.0 ** (n - w) for j in range(n - w + 1)])
        Dw = np.zeros(nF)
        Tw = np.zeros(nF)
        for k in range(w + 1):
            m = Ff[:, k:k + n - w + 1] @ bj
            ck = comb(w, k) / 2.0 ** w
            Dw += ck * np.minimum(m, 1 - m)
            Tw += ck * Ff[:, k]
        L += Pw[w] * (Ff[:, w] * Dw + (1 - Ff[:, w]) * Tw)
    assert np.all(L <= eps + 1e-12)
    ok = eps > 1e-300
    rL = np.where(L > 1e-300, delta ** 2 / np.maximum(L, 1e-300), np.where(delta > 0, np.inf, 0))
    rE = np.where(ok, delta ** 2 / np.maximum(eps, 1e-300), 0)
    iL, iE = int(np.argmax(rL)), int(np.argmax(rE))
    return rL[iL], ''.join(map(str, Fs[iL])), rE[iE], ''.join(map(str, Fs[iE]))


if __name__ == "__main__":
    for n in range(2, int(sys.argv[1]) + 1 if len(sys.argv) > 1 else 15):
        rL, FL, rE, FE = run(n)
        print(f"n={n:2d}: max dist^2/L = {rL:.6f} (F={FL})   max dist^2/eps = {rE:.6f} (F={FE})", flush=True)
