#!/usr/bin/env python3
"""Exhaustively test candidate sharp inequalities for all f on n <= 4 variables (exact integers).

Candidates (d_T = Pr[f != AND_T], d = min_T d_T, delta = min(mu, d)):
  (S1) eps >= mu * d
  (S2) eps >= delta^2
  (S3) eps >= mu * d_C  where C = {i : Pr[f=1, x_i=0] <= mu/4}
  (S4) eps >= mu * d_{C'} where C' = {i : Pr[f=1, x_i=0] < mu/2}
Prints the worst ratios.
"""
import sys
from fractions import Fraction

import numpy as np


def run(n):
    N = 1 << n
    pts = np.arange(N, dtype=np.int64)
    meet = pts[:, None] & pts[None, :]
    ANDm = ((pts[None, :] & pts[:, None]) == pts[:, None]).astype(np.int64)
    nfun = 1 << N
    F = ((np.arange(nfun, dtype=np.int64)[:, None] >> pts[None, :]) & 1).astype(np.int64)
    A = F.sum(axis=1)
    err = (F[:, meet] != (F[:, :, None] * F[:, None, :])).sum(axis=(1, 2))
    Dall = (F[:, None, :] != ANDm[None, :, :]).sum(axis=2)  # (nfun, N): N*d_T
    d = Dall.min(axis=1)
    zero_i = np.array([((pts >> i) & 1) == 0 for i in range(n)]).astype(np.int64)
    b = F @ zero_i.T
    Cm = ((4 * b <= A[:, None]) * (1 << np.arange(n))[None, :]).sum(axis=1)
    Cm2 = ((2 * b < A[:, None]) * (1 << np.arange(n))[None, :]).sum(axis=1)
    dC = Dall[np.arange(nfun), Cm]
    dC2 = Dall[np.arange(nfun), Cm2]
    out = {}
    # ratios as exact fractions: (mu*d)/eps = (A/N)(d/N)/(err/N^2) = A*d/err
    for name, num in [("S1 mu*d/eps", A * d), ("S2 delta^2/eps", np.minimum(A, d) ** 2),
                      ("S3 mu*d_C/eps", A * dC), ("S4 mu*d_C'/eps", A * dC2)]:
        best = Fraction(0)
        arg = None
        for k in range(nfun):
            if err[k] == 0:
                assert num[k] == 0 or name.startswith("S3") or name.startswith("S4")
                continue
            r = Fraction(int(num[k]), int(err[k]))
            if r > best:
                best, arg = r, k
        out[name] = (best, arg)
    return out


if __name__ == "__main__":
    for n in range(1, int(sys.argv[1]) + 1 if len(sys.argv) > 1 else 5):
        res = run(n)
        print(f"n={n}: " + "; ".join(f"{k} max={float(v[0]):.4f} (f={v[1]})" for k, v in res.items()), flush=True)
