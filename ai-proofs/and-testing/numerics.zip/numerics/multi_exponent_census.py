r"""Census for the multi-polymorphism exponent E(g) (paper Section 8.7).

A flip pair of g: {0,1}^m -> {0,1} is (z, S) with g(z xor 1_S) != g(z) and
g(z xor 1_S') = g(z) for every proper subset S' of S.  E(g) is the largest |S|
over all flip pairs (Definition 8.26).

For every g with m <= 4 that depends on all m coordinates the script
  * computes E(g) from the definition (dynamic programming over subsets S for
    each base point z);
  * computes E(g) a second way, as the largest k such that some k-dimensional
    subcube contains exactly 1 or exactly 2^k - 1 ones of g (the restriction
    is an AND of k literals or its negation), and checks that the two agree;
  * checks E(g) = 1 iff g is affine (Lemma 8.27(c)), E(g) = m iff g is of AND
    type, and E(g) >= e(g) = max(s_0, s_1) (Lemma 8.27(b));
  * prints the distribution of E(g), and compares E(g) with the optimal
    exponent for polymorphisms (1 if E[g] = 1/2, e(g) otherwise).

Truth tables are indexed by x = sum_k x_k 2^k.  Run: python3 multi_exponent_census.py
"""
import itertools
import sys
from collections import Counter

import numpy as np


def all_tables(m):
    N = 1 << m
    idx = np.arange(1 << N, dtype=np.int64)
    return ((idx[:, None] >> np.arange(N)) & 1).astype(np.uint8)


def depends_on_all(T, m):
    N = 1 << m
    ok = np.ones(T.shape[0], dtype=bool)
    for k in range(m):
        flip = np.arange(N) ^ (1 << k)
        ok &= (T != T[:, flip]).any(axis=1)
    return ok


def E_flip_pairs(T, m):
    """E(g) from the definition, vectorized over all truth tables."""
    N = 1 << m
    G = T.shape[0]
    E = np.zeros(G, dtype=np.int64)
    subsets = sorted(range(N), key=lambda S: bin(S).count("1"))
    for z in range(N):
        gz = T[:, z]
        U = {}
        for S in subsets:
            same = T[:, z ^ S] == gz
            below = np.ones(G, dtype=bool)
            for k in range(m):
                if S >> k & 1:
                    below &= U[S ^ (1 << k)]
            U[S] = same & below
            if S:
                is_pair = (~same) & below
                E = np.where(is_pair, np.maximum(E, bin(S).count("1")), E)
    return E


def E_restrictions(T, m):
    """Largest k such that some k-dim subcube has exactly 1 or 2^k - 1 ones."""
    G = T.shape[0]
    E = np.zeros(G, dtype=np.int64)
    for k in range(1, m + 1):
        for F in itertools.combinations(range(m), k):
            rest = [j for j in range(m) if j not in F]
            for vals in itertools.product((0, 1), repeat=len(rest)):
                base = sum(v << j for v, j in zip(vals, rest))
                pts = [base | sum(((s >> i) & 1) << F[i] for i in range(k)) for s in range(1 << k)]
                ones = T[:, pts].sum(axis=1)
                hit = (ones == 1) | (ones == (1 << k) - 1)
                E = np.where(hit, np.maximum(E, k), E)
    return E


def s_b(tab, m, b):
    full = (1 << m) - 1
    base_pt = full if b else 0
    for size in range(1, m + 1):
        for S in itertools.combinations(range(m), size):
            if tab[base_pt ^ sum(1 << k for k in S)] != tab[base_pt]:
                return size
    return None


def is_affine(tab, m):
    for lam in range(1 << (m + 1)):
        c, coeffs = lam & 1, lam >> 1
        if all(tab[x] == (c ^ (bin(x & coeffs).count("1") & 1)) for x in range(1 << m)):
            return True
    return False


def is_and_type(tab, m):
    N = 1 << m
    for c in (0, 1):
        for a in range(N):
            target = [c ^ (1 if (x ^ a) == N - 1 else 0) for x in range(N)]
            if list(tab) == target:
                return True
    return False


def main(mmax):
    ok_all = True
    for m in range(1, mmax + 1):
        T = all_tables(m)
        T = T[depends_on_all(T, m)]
        E1 = E_flip_pairs(T, m)
        E2 = E_restrictions(T, m)
        agree = bool((E1 == E2).all())
        ok_all &= agree
        dist = Counter(E1.tolist())
        bad_affine = bad_and = bad_e = 0
        comp = Counter()
        examples = {}
        for row, E in zip(T, E1.tolist()):
            tab = [int(v) for v in row]
            if (E == 1) != is_affine(tab, m):
                bad_affine += 1
            if m >= 2 and (E == m) != is_and_type(tab, m):
                bad_and += 1
            e = max(s_b(tab, m, 0), s_b(tab, m, 1))
            if E < e:
                bad_e += 1
            balanced = 2 * sum(tab) == len(tab)
            poly_exp = 1 if balanced else e
            key = ("balanced" if balanced else "unbalanced", poly_exp, E)
            comp[key] += 1
            if poly_exp < E and key not in examples:
                examples[key] = sum(v << x for x, v in enumerate(tab))
        ok_all &= bad_affine == 0 and bad_and == 0 and bad_e == 0
        print(f"m={m}: functions depending on all coordinates: {len(T)}")
        print(f"  E distribution: {dict(sorted(dist.items()))}")
        print(f"  definitions agree (flip pairs vs restrictions): {agree}")
        print(f"  violations: (E=1 iff affine) {bad_affine}, (E=m iff AND type) {bad_and}, (E>=e) {bad_e}")
        for key in sorted(comp):
            tag = f"  {key[0]:>10}, polymorphism exponent {key[1]}, E={key[2]}: {comp[key]}"
            if key in examples:
                tag += f"   (e.g. truth table index {examples[key]})"
            print(tag)
        more = sum(v for k, v in comp.items() if k[1] < k[2])
        print(f"  functions with E(g) > polymorphism exponent: {more}")
        sys.stdout.flush()
    print("ALL CHECKS PASSED" if ok_all else "SOME CHECK FAILED")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
