"""Check of the product inequality used in Step 2 of the proofs of Theorems 8.61 and 8.80.

Under the uniform distribution pi_m on P^(m)_neq = {a in Z_3^m : sum a != 0}, m >= 3, rows iid,
for every tuple f_1..f_m : Z_3^n -> Z_3, every choice of distinct positions j, s, every vector
of constants (u_l)_{l != s} and every j != s:

    Pr[f_j != u_j] * dc(f_s)
        <= err(f) + Pr[f_j != u_j] * ( sum_{l not in {j,s}} Pr[f_l != u_l] + Pr[f_s = -U] ),

where U = sum_{l != s} u_l and dc(h) = 1 - max_v Pr[h = v] (uniform measure on Z_3^n).
Exact rational arithmetic; m = 3 exhaustively for n = 1 and randomly for n = 2;
m = 4 randomly for n = 1, 2. Random tuples are biased towards nearly constant functions,
where the inequality is tight.
"""
import itertools
import random
from fractions import Fraction

random.seed(20261021)


def rows(m):
    return [a for a in itertools.product(range(3), repeat=m) if sum(a) % 3 != 0]


def points(n):
    return list(itertools.product(range(3), repeat=n))


def err(fs, m, n):
    """Exact failure probability under pi_m^{otimes n}; fs[j] is a dict point -> value."""
    R = rows(m)
    pts = points(n)
    tot = 0
    # columns c_j in Z_3^n; enumerate row choices per coordinate
    for choice in itertools.product(R, repeat=n):
        cols = [tuple(choice[i][j] for i in range(n)) for j in range(m)]
        if sum(fs[j][cols[j]] for j in range(m)) % 3 == 0:
            tot += 1
    return Fraction(tot, len(R) ** n)


def prob(f, pred, pts):
    return Fraction(sum(1 for p in pts if pred(f[p])), len(pts))


def dc(f, pts):
    return 1 - max(prob(f, lambda v, c=c: v == c, pts) for c in range(3))


def check_tuple(fs, m, n, pts):
    e = err(fs, m, n)
    worst = None
    for s in range(m):
        dcs = dc(fs[s], pts)
        others = [l for l in range(m) if l != s]
        for us in itertools.product(range(3), repeat=m - 1):
            u = dict(zip(others, us))
            U = sum(us) % 3
            ps = {l: prob(fs[l], lambda v, c=u[l]: v != c, pts) for l in others}
            qs = prob(fs[s], lambda v: v == (-U) % 3, pts)
            for j in others:
                lhs = ps[j] * dcs
                rhs = e + ps[j] * (sum(ps[l] for l in others if l != j) + qs)
                assert lhs <= rhs, (m, n, fs, s, u, j, lhs, rhs)
                if lhs > 0:
                    r = lhs / rhs
                    if worst is None or r > worst:
                        worst = r
    return worst


def random_function(pts, mode):
    if mode == 0:
        return {p: random.randrange(3) for p in pts}
    base = random.randrange(3)
    k = random.choice([1, 1, 2, 3])
    f = {p: base for p in pts}
    for p in random.sample(pts, min(k, len(pts))):
        f[p] = random.randrange(3)
    return f


def main():
    best = Fraction(0)
    # m = 3, n = 1: all 27^3 triples
    m, n = 3, 1
    pts = points(n)
    funcs = [dict(zip(pts, vals)) for vals in itertools.product(range(3), repeat=len(pts))]
    cnt = 0
    for fs in itertools.product(funcs, repeat=3):
        w = check_tuple(list(fs), m, n, pts)
        if w is not None and w > best:
            best = w
        cnt += 1
    print(f"m=3 n=1: all {cnt} triples pass; max lhs/rhs = {best} = {float(best):.4f}")
    for (m, n, trials) in [(3, 2, 400), (4, 1, 3000), (4, 2, 60)]:
        pts = points(n)
        best = Fraction(0)
        for _ in range(trials):
            fs = [random_function(pts, random.randrange(2)) for _ in range(m)]
            w = check_tuple(fs, m, n, pts)
            if w is not None and w > best:
                best = w
        print(f"m={m} n={n}: {trials} random tuples pass; max lhs/rhs = {float(best):.4f}")
    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
