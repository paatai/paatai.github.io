#!/usr/bin/env python3
"""Iterated quotient of binary operations g on 3 letters (exploratory; not used in any proof).

One quotient step: merge the letters of coordinate j into the components P_j of the collision graph N_j,
and merge the outputs into the components (blocks) of G = G_1 u G_2 (Theorem 8.45). The block of g(x)
depends only on the component vector of x, giving a quotient operation; iterate until nothing changes.
'trivial' = the quotient is constant, which happens iff (H) holds (17118 operations). Otherwise the
terminal quotient is 'rigid' (every coordinate injective); the output lists its alphabet sizes and
number of outputs, and the second part says whether g factors exactly through the first quotient.
"""
import itertools, collections
q=3
def comps(n, edges):
    p=list(range(n))
    def f(a):
        while p[a]!=a: p[a]=p[p[a]]; a=p[a]
        return a
    for a,b in edges: p[f(a)]=f(b)
    return [f(a) for a in range(n)]
def quotient(tab, sizes):
    # tab: dict (x1,x2)->out (outs relabeled 0..)
    outs=sorted(set(tab.values()))
    ks=[]
    for j in range(2):
        e=[]
        for a in range(sizes[j]):
            for b in range(a+1,sizes[j]):
                for u in range(sizes[1-j]):
                    xa=(a,u) if j==0 else (u,a); xb=(b,u) if j==0 else (u,b)
                    if tab[xa]==tab[xb]: e.append((a,b));break
        ks.append(comps(sizes[j],e))
    ge=[]
    for j in range(2):
        for a in range(sizes[j]):
            for b in range(sizes[j]):
                if ks[j][a]==ks[j][b]:
                    for u in range(sizes[1-j]):
                        xa=(a,u) if j==0 else (u,a); xb=(b,u) if j==0 else (u,b)
                        ge.append((tab[xa],tab[xb]))
    nO=max(outs)+1
    bl=comps(nO,ge)
    # relabel
    lab=[{c:i for i,c in enumerate(sorted(set(k)))} for k in ks]
    bll={c:i for i,c in enumerate(sorted(set(bl[o] for o in outs)))}
    ns=[len(l) for l in lab]
    nt={}
    for x,o in tab.items():
        kx=(lab[0][ks[0][x[0]]],lab[1][ks[1][x[1]]])
        v=bll[bl[o]]
        assert nt.get(kx,v)==v
        nt[kx]=v
    return nt, ns
def classify(nt,ns):
    outs=set(nt.values())
    if len(outs)==1: return 'trivial'
    return ('rigid', tuple(ns), len(outs), tuple(nt[(a,b)] for a in range(ns[0]) for b in range(ns[1])))
cnt=collections.Counter(); ex={}
for vals in itertools.product(range(q),repeat=q*q):
    tab={(a,b):vals[a*q+b] for a in range(q) for b in range(q)}
    # depends on both
    if all(tab[(a,b)]==tab[(a,0)] for a in range(q) for b in range(q)): continue
    if all(tab[(a,b)]==tab[(0,b)] for a in range(q) for b in range(q)): continue
    t,ns=tab,[q,q]; steps=0
    while True:
        nt,nns=quotient(t,ns)
        if nns==ns and len(set(nt.values()))==len(set(t.values())): break
        t,ns=nt,nns; steps+=1
    c=classify(t,ns)
    key=(c if c=='trivial' else ('rigid',c[1],c[2])),steps
    cnt[key]+=1; ex.setdefault(key,vals)
for k,v in sorted(cnt.items(),key=str): print(k,v,ex[k])
print('--- factoring through k (one step) ---')
cnt2=collections.Counter()
for vals in itertools.product(range(q),repeat=q*q):
    tab={(a,b):vals[a*q+b] for a in range(q) for b in range(q)}
    if all(tab[(a,b)]==tab[(a,0)] for a in range(q) for b in range(q)): continue
    if all(tab[(a,b)]==tab[(0,b)] for a in range(q) for b in range(q)): continue
    nt,ns=quotient(tab,[q,q])
    if len(set(nt.values()))==1: continue
    fac = len(set(nt.values()))==len(set(tab.values()))
    nt2,ns2=quotient(nt,ns)
    rigid = ns2==ns and len(set(nt2.values()))==len(set(nt.values()))
    kind=None
    if rigid:
        outs=len(set(nt.values()))
        dep=[any(nt[(a,b)]!=nt[(a2,b)] for a in range(ns[0]) for a2 in range(ns[0]) for b in range(ns[1])), any(nt[(a,b)]!=nt[(a,b2)] for a in range(ns[0]) for b in range(ns[1]) for b2 in range(ns[1]))]
        kind=(tuple(ns),outs,tuple(dep))
    cnt2[(fac,rigid,kind)]+=1
for k,v in sorted(cnt2.items(),key=str): print(k,v)
