"""Checks for Proposition 8.81 of the PDF (a larger parameter for reverse hypercontractivity).

Notation: mu is a full-support distribution on P^(m)_neq = {a in Z_3^m : sum a != 0}, alpha = min mu,
alpha' = 3^(m-3) alpha < 1/18, 0 < s <= 1/2, sigma = 18 alpha' s, kappa_s = 18 alpha'(1 - s)/(1 - 18 alpha' s),
nu = (mu - sigma pi_m)/(1 - sigma), and r_kappa = 2(1 - sqrt(1 - kappa))/(2 - sqrt(1 - kappa)) (Lemma 8.35).

 (U) exact (rationals), m = 3, 4, 5, random mu with uniform marginals (near pi_m, generic, nearly degenerate) and
     s in {1/2, 1/4, 1/10, 1/1000}: sigma pi_m = alpha s, sigma <= 9 alpha' <= 1/2, mu = sigma pi_m + (1 - sigma) nu,
     nu >= alpha(1 - s)/(1 - sigma) >= alpha/2, uniform nu-marginals, nu_jl >= 2 alpha'(1 - s)/(1 - sigma)
     = kappa_s/9 = kappa_s nu_j nu_l and nu_jl >= alpha' for every pair j != l, the kernel bound
     K(a, a') >= 9 alpha' nu_j(a') (theta = 9 alpha' in Lemma 8.59), and 9 alpha' <= 18 alpha'(1 - s) <= kappa_s
     < min(18 alpha', 1).
 (T) exact, m = 3, random mu with mu_1 and mu_2 uniform (mu_3 not uniform): the same for the pair {1, 2}, and
     mu_lm >= kappa'' mu_l mu_m with kappa'' = 9 alpha/(1 - 9 alpha) for every ordered pair (l, m) meeting {1, 2}
     (case (b); the minimum of the ratio over these pairs is reported relative to kappa'').
 (R) Lemma 8.35 in its norm form E[Phi(X) Psi(Y)] >= ||Phi(X)||_r ||Psi(Y)||_r, r = r_kappa, for kappa = kappa_s and
     pair laws nu_jl from (U), and for kappa = kappa'' and pair laws mu_lm from (T); n = 1, 2 independent pairs,
     random nonnegative functions and indicators (floating point, relative tolerance 1e-12).
 (N) Step 4 with sigma = 18 alpha' s: for random f on Z_3^3 (uniform measure), D(L) = E_rho dc(f(., rho)) is
     nondecreasing in L, and E_L D(L) >= (sigma/3)(1 - |E omega^f|^2) >= (sigma/3) dc(f) for L ~ product(sigma); exact.
 (E) the example for c*(mu) <= 1/2: (a, b) minimising mu_{m-1,m}(a, b) has mu_{m-1,m}(a, b) <= 1/9; the error of
     f = (0, ..., 0, 1_E, 1 + 1_E') with E = {(a, ..., a)} and E' = {(b, ..., b)} in Z_3^k is exactly
     mu_{m-1,m}(a, b)^k <= 9^-k (enumeration of all |P|^k row tuples; m = 3, k <= 3 and m = 4, k <= 2), and its
     distance from every tuple of type (A_m) or (B_m) is at least 3^-k (exactly 3^-k); for k = 1 also against all
     generalized polymorphisms, found by exhaustive search (198 for m = 3, 756 for m = 4).
 (K) mpmath: the numerical inequalities of the proof (opening, the constants for m = 3 in (a) and (b), the
     conclusion for m >= 4) on grids of alpha', s, m and delta, and the consequences: r_(18 alpha')/2 >= 8 alpha',
     r_(kappa'') >= 8 alpha and r_(18 alpha) r_(kappa'')/4 >= 32 alpha^2, r_(kappa_s) increasing as s decreases with
     limit r_(18 alpha') as s -> 0, r_(18 alpha') -> 1 and log 3/log(1/(2 alpha')) -> 1/2 as alpha' -> 1/18,
     r_(18 alpha')/(18 alpha') -> 1 as alpha' -> 0. It also reports, for alpha' <= 1/45 only, the largest ratio of the
     earlier upper bound (9/2) e^2 alpha' to r_(18 alpha')/2 (about 4.0168); that bracket is superseded by
     Proposition 8.82 (ratio at most 9/8, checked in neq_sharp_shift_check.py) and is no longer claimed.
"""
import itertools
import random
from fractions import Fraction

import mpmath
import numpy as np

mpmath.mp.dps = 60
Q = 3
S_VALUES = [Fraction(1, 2), Fraction(1, 4), Fraction(1, 10), Fraction(1, 1000)]
nprng = np.random.default_rng(20261022)


def rows(m):
    return [a for a in itertools.product(range(Q), repeat=m) if sum(a) % Q != 0]


def marg(mu, idx):
    out = {}
    for a, p in mu.items():
        k = tuple(a[i] for i in idx)
        out[k] = out.get(k, 0) + p
    return out


def solve(G, b):
    n = len(G)
    M = [row[:] + [b[i]] for i, row in enumerate(G)]
    for c in range(n):
        piv = next(r for r in range(c, n) if M[r][c] != 0)
        M[c], M[piv] = M[piv], M[c]
        inv = 1 / M[c][c]
        M[c] = [x * inv for x in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c]
                M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][n] for i in range(n)]


def kernel_direction(P, js, rng):
    """A random exact rational vector v on P with sum 0 whose j-th marginals vanish for j in js."""
    B = [[Fraction(int(a[j] == v)) for a in P] for j in js for v in (0, 1)] + [[Fraction(1)] * len(P)]
    x = [Fraction(rng.randint(-50, 50)) for _ in P]
    G = [[sum(r1[i] * r2[i] for i in range(len(P))) for r2 in B] for r1 in B]
    y = solve(G, [sum(r[i] * x[i] for i in range(len(P))) for r in B])
    v = [x[i] - sum(y[k] * B[k][i] for k in range(len(B))) for i in range(len(P))]
    assert sum(v) == 0
    for j in js:
        for t in range(Q):
            assert sum(vi for vi, a in zip(v, P) if a[j] == t) == 0
    return v


def diag_group(m):
    return [t for t in itertools.product(range(Q), repeat=m) if sum(t) % Q == 0 and t[m - 2] == t[m - 1]]


def random_mu(m, js, rng, mode, lam=None):
    P = rows(m)
    pim = Fraction(1, 2 * 3 ** (m - 1))
    if mode == "kernel":
        v = kernel_direction(P, js, rng)
        epsmax = min(pim / (-vi) for vi in v if vi < 0)
        return {a: pim + lam * epsmax * vi for a, vi in zip(P, v)}
    assert tuple(js) == tuple(range(m))
    if mode == "generic":
        w = {a: rng.randint(1, 50) for a in P}
    else:
        w = {a: rng.choice([1, 1, 1, 10 ** 6]) for a in P}
    G = diag_group(m)
    avg = {a: sum(w[tuple((x + y) % Q for x, y in zip(a, t))] for t in G) for a in P}
    tot = sum(avg.values())
    return {a: Fraction(x, tot) for a, x in avg.items()}


def r_np(kappa):
    return 2 * kappa / (1 + kappa + np.sqrt(1 - kappa))


def r_mp(kappa):
    k = mpmath.mpf(kappa.numerator) / kappa.denominator if isinstance(kappa, Fraction) else mpmath.mpf(kappa)
    t = mpmath.sqrt(1 - k)
    r = 2 * k / (1 + k + t)
    assert abs(r - 2 * (1 - t) / (2 - t)) < mpmath.mpf(10) ** -50
    return r


def decomposition_checks(mu, m, s, pairs, pair_store):
    """The decomposition for one mu and one s; `pairs` are the ordered pairs (j, l) with mu_j, mu_l uniform."""
    P = rows(m)
    pim = Fraction(1, 2 * 3 ** (m - 1))
    third = Fraction(1, 3)
    alpha = min(mu.values())
    ap = 3 ** (m - 3) * alpha
    assert ap < Fraction(1, 18)
    sigma = 18 * ap * s
    kap = 18 * ap * (1 - s) / (1 - 18 * ap * s)
    assert sigma * pim == alpha * s and sigma <= 9 * ap <= Fraction(1, 2)
    assert 9 * ap <= 18 * ap * (1 - s) <= kap < min(18 * ap, Fraction(1))
    nu = {a: (p - sigma * pim) / (1 - sigma) for a, p in mu.items()}
    assert sum(nu.values()) == 1 and set(nu) == set(P)
    for a in P:
        assert sigma * pim + (1 - sigma) * nu[a] == mu[a]
    lo = alpha * (1 - s) / (1 - sigma)
    assert min(nu.values()) >= lo >= alpha * (1 - s) >= alpha / 2
    unif = sorted({j for pr in pairs for j in pr})
    nus = {j: marg(nu, [j]) for j in unif}
    for j in unif:
        assert marg(mu, [j]) == {(t,): third for t in range(Q)}
        assert nus[j] == {(t,): third for t in range(Q)}
    for (j, l) in pairs:
        njl = marg(nu, [j, l])
        bound = 2 * ap * (1 - s) / (1 - sigma)
        assert bound == kap / 9
        for x in range(Q):
            for y in range(Q):
                assert njl[(x, y)] >= bound == kap * nus[j][(x,)] * nus[l][(y,)]
                assert njl[(x, y)] >= ap
        for x in range(Q):
            for xp in range(Q):
                K = sum((njl[(x, b)] / nus[j][(x,)]) * (njl[(xp, b)] / nus[l][(b,)]) for b in range(Q))
                assert K >= 9 * ap * nus[j][(xp,)]
        if pair_store is not None and (j, l) == pairs[0]:
            pair_store.append((np.array([[float(njl[(x, y)]) for y in range(Q)] for x in range(Q)]), float(kap)))
    return float(kap)


def check_U(pair_store):
    rng = random.Random(2026)
    out = []
    for m in (3, 4, 5):
        cases = [("kernel", Fraction(1, 100)), ("kernel", Fraction(1, 2)), ("kernel", Fraction(999, 1000))] * 2
        cases += [("generic", None)] * 2 + [("spiky", None)] * 2
        pairs = list(itertools.permutations(range(m), 2))
        kmin, kmax, amin = 1.0, 0.0, Fraction(1)
        for mode, lam in cases:
            mu = random_mu(m, tuple(range(m)), rng, mode, lam)
            assert sum(mu.values()) == 1 and all(p > 0 for p in mu.values())
            amin = min(amin, min(mu.values()))
            for s in S_VALUES:
                k = decomposition_checks(mu, m, s, pairs, pair_store if m <= 4 else None)
                kmin, kmax = min(kmin, k), max(kmax, k)
        out.append(f"m={m}: {len(cases)} mu x {len(S_VALUES)} s, kappa_s in [{kmin:.3g}, {kmax:.6f}],"
                   f" smallest alpha' = {float(3 ** (m - 3) * amin):.3g}")
    print("(U) exact decomposition with sigma = 18 alpha' s:", "; ".join(out), ": ok")


def check_T(pair_store, pair_store_b):
    rng = random.Random(2027)
    m = 3
    third = Fraction(1, 3)
    cnt, nonunif = 0, 0
    worst = None
    for lam in [Fraction(1, 100), Fraction(1, 2), Fraction(9, 10), Fraction(999, 1000)] * 3:
        mu = random_mu(m, (0, 1), rng, "kernel", lam)
        assert sum(mu.values()) == 1 and all(p > 0 for p in mu.values())
        if marg(mu, [2]) != {(t,): third for t in range(Q)}:
            nonunif += 1
        alpha = min(mu.values())
        kap2 = 9 * alpha / (1 - 9 * alpha)
        assert kap2 < 1
        for s in S_VALUES:
            decomposition_checks(mu, m, s, [(0, 1), (1, 0)], pair_store)
        margs = [marg(mu, [j]) for j in range(m)]
        for (l, mm) in itertools.permutations(range(m), 2):
            if l not in (0, 1) and mm not in (0, 1):
                continue
            mlm = marg(mu, [l, mm])
            for x in range(Q):
                for y in range(Q):
                    assert margs[l][(x,)] * margs[mm][(y,)] <= third
                    assert mlm[(x, y)] >= 2 * alpha
                    assert mlm[(x, y)] >= kap2 * margs[l][(x,)] * margs[mm][(y,)]
                    q = mlm[(x, y)] / (kap2 * margs[l][(x,)] * margs[mm][(y,)])
                    worst = q if worst is None or q < worst else worst
            if (l, mm) == (0, 2):
                pair_store_b.append((np.array([[float(mlm[(x, y)]) for y in range(Q)] for x in range(Q)]),
                                     float(kap2)))
        cnt += 1
    assert nonunif == cnt
    print(f"(T) m=3, {cnt} mu with mu_1, mu_2 uniform and mu_3 not uniform, {len(S_VALUES)} s each: decomposition for"
          f" the pair (1,2); mu_lm >= 2 alpha and mu_lm >= (9 alpha/(1 - 9 alpha)) mu_l mu_m when {{l,m}} meets {{1,2}}"
          f" (min ratio to this bound {float(worst):.4f}): ok")


def check_R(pair_store, pair_store_b, trials=150):
    worst = np.inf
    count = 0
    for pair, kappa in pair_store + pair_store_b:
        r = r_np(kappa)
        PX, PY = pair.sum(axis=1), pair.sum(axis=0)
        assert (pair >= kappa * np.outer(PX, PY) - 1e-15).all() and 0 < kappa < 1
        for n in (1, 2):
            W = pair if n == 1 else np.kron(pair, pair)
            px, py = W.sum(axis=1), W.sum(axis=0)
            N = W.shape[0]
            for t in range(trials):
                mode = t % 4
                if mode == 0:
                    g = nprng.random(N) ** nprng.uniform(0.3, 8)
                    h = nprng.random(N) ** nprng.uniform(0.3, 8)
                elif mode == 1:
                    g = (nprng.random(N) < nprng.uniform(0.05, 0.6)).astype(float)
                    h = (nprng.random(N) < nprng.uniform(0.05, 0.6)).astype(float)
                elif mode == 2:
                    g = np.exp(nprng.normal(0, 3, N))
                    h = np.exp(nprng.normal(0, 3, N))
                else:
                    g = np.where(nprng.random(N) < 0.3, 0.0, nprng.random(N))
                    h = np.where(nprng.random(N) < 0.3, 0.0, nprng.random(N))
                lhs = g @ W @ h
                rhs = (px @ g ** r) ** (1 / r) * (py @ h ** r) ** (1 / r)
                assert lhs >= rhs - 1e-12 * max(1.0, rhs), (lhs, rhs, kappa, n)
                if rhs > 1e-9:
                    worst = min(worst, lhs / rhs)
                count += 1
    print(f"(R) Lemma 8.35 (norm form), {len(pair_store)} pair laws nu_jl with kappa = kappa_s and"
          f" {len(pair_store_b)} pair laws mu_lm with kappa = 9 alpha/(1 - 9 alpha), n = 1, 2: {count} function pairs,"
          f" min lhs/rhs = {worst:.6f}: ok")


def check_N(trials=60):
    rng = random.Random(2028)
    n = 3
    pts = list(itertools.product(range(Q), repeat=n))
    sigmas = [Fraction(1, 2), Fraction(1, 3), Fraction(1, 10), Fraction(1, 100), Fraction(1, 10 ** 4)]
    worst = None
    for t in range(trials):
        if t % 2 == 0:
            f = {p: rng.randrange(Q) for p in pts}
        else:
            base = rng.randrange(Q)
            f = {p: (rng.randrange(Q) if rng.random() < rng.choice([0.05, 0.15, 0.4]) else base) for p in pts}

        def dc(vals):
            c = [sum(1 for v in vals if v == x) for x in range(Q)]
            return 1 - Fraction(max(c), len(vals))

        D = {}
        for k in range(n + 1):
            for L in itertools.combinations(range(n), k):
                Lc = [i for i in range(n) if i not in L]
                tot = Fraction(0)
                for rho in itertools.product(range(Q), repeat=len(Lc)):
                    vals = [f[p] for p in pts if all(p[i] == rv for i, rv in zip(Lc, rho))]
                    tot += dc(vals)
                D[L] = tot / 3 ** len(Lc)
        for L in D:
            for i in range(n):
                if i not in L:
                    assert D[L] <= D[tuple(sorted(L + (i,)))]
        c = [Fraction(sum(1 for p in pts if f[p] == x), len(pts)) for x in range(Q)]
        noise = 3 * (c[0] * c[1] + c[0] * c[2] + c[1] * c[2])
        dcf = 1 - max(c)
        assert noise >= dcf
        for sg in sigmas:
            ED = sum(sg ** len(L) * (1 - sg) ** (n - len(L)) * D[L] for L in D)
            assert ED >= sg / 3 * noise >= sg / 3 * dcf
            if dcf > 0:
                q = ED / (sg / 3 * dcf)
                worst = q if worst is None or q < worst else worst
    print(f"(N) Step 4 and monotonicity, n=3, {trials} functions, sigma in {[str(x) for x in sigmas]}:"
          f" E_L D(L) >= (sigma/3)(1-|E w^f|^2) >= (sigma/3) dc(f), min ratio {float(worst):.4f}: ok")


def all_gen_polymorphisms_n1(m):
    F = np.array(list(itertools.product(range(Q), repeat=Q)))
    valid = np.ones((27,) * m, dtype=bool)
    for a in rows(m):
        s = np.zeros((27,) * m, dtype=np.int64)
        for j in range(m):
            shape = [1] * m
            shape[j] = 27
            s = s + F[:, a[j]].reshape(shape)
        valid &= (s % Q != 0)
    return F, valid


def type_distances(fs, m, k):
    """Exact min distance (uniform measure on Z_3^k) from fs to the tuples of type (A_m) and of type (B_m)."""
    pts = list(itertools.product(range(Q), repeat=k))
    N = len(pts)

    def pr_neq_const(f, u):
        return Fraction(sum(1 for p in pts if f[p] != u), N)

    best_A = None
    for b in range(m):
        others = [j for j in range(m) if j != b]
        for us in itertools.product(range(Q), repeat=m - 1):
            U = sum(us) % Q
            d = max([pr_neq_const(fs[j], u) for j, u in zip(others, us)]
                    + [Fraction(sum(1 for p in pts if fs[b][p] == (-U) % Q), N)])
            best_A = d if best_A is None or d < best_A else best_A
    best_B = None
    for kap in (1, 2):
        for i in range(k):
            for ds in itertools.product(range(Q), repeat=m):
                if sum(ds) % Q != 0:
                    continue
                d = max(Fraction(sum(1 for p in pts if fs[j][p] != (kap * p[i] + ds[j]) % Q), N) for j in range(m))
                best_B = d if best_B is None or d < best_B else best_B
    return best_A, best_B


def check_E():
    rng = random.Random(2029)
    out = []
    for m, kmax in ((3, 3), (4, 2)):
        P = rows(m)
        F, valid = all_gen_polymorphisms_n1(m)
        ngp = int(valid.sum())
        assert ngp == {3: 198, 4: 756}[m]
        mus = [random_mu(m, tuple(range(m)), rng, "kernel", lam) for lam in (Fraction(1, 2), Fraction(999, 1000))]
        mus += [random_mu(m, tuple(range(m)), rng, "generic"), random_mu(m, tuple(range(m)), rng, "spiky")]
        for mu in mus:
            M = marg(mu, [m - 2, m - 1])
            (a, b) = min(M, key=lambda key: M[key])
            assert M[(a, b)] <= Fraction(1, 9)
            for k in range(1, kmax + 1):
                pts = list(itertools.product(range(Q), repeat=k))
                fs = [{p: 0 for p in pts} for _ in range(m - 2)]
                fs.append({p: int(p == (a,) * k) for p in pts})
                fs.append({p: (1 + int(p == (b,) * k)) % Q for p in pts})
                err = Fraction(0)
                for tup in itertools.product(P, repeat=k):
                    cols = [tuple(tup[i][j] for i in range(k)) for j in range(m)]
                    if sum(fs[j][cols[j]] for j in range(m)) % Q == 0:
                        pr = Fraction(1)
                        for row in tup:
                            pr *= mu[row]
                        err += pr
                assert err == M[(a, b)] ** k <= Fraction(1, 9 ** k)
                dA, dB = type_distances(fs, m, k)
                assert min(dA, dB) == Fraction(1, 3 ** k) and dB == Fraction(2, 3)
                if k == 1:
                    mism = []
                    for j in range(m):
                        fv = np.array([fs[j][(x,)] for x in range(Q)])
                        mism.append((F != fv[None, :]).sum(axis=1))
                    dist = np.zeros((27,) * m, dtype=np.int64)
                    for j in range(m):
                        shape = [1] * m
                        shape[j] = 27
                        dist = np.maximum(dist, mism[j].reshape(shape))
                    dmin = Fraction(int(dist[valid].min()), 3)
                    assert dmin == Fraction(1, 3)
        out.append(f"m={m}: {len(mus)} mu, k<={kmax}, {ngp} generalized polymorphisms for n=1")
    print("(E) example for c*(mu) <= 1/2: min mu_{m-1,m} <= 1/9, error = mu_{m-1,m}(a,b)^k <= 9^-k, distance from"
          " types (A_m)/(B_m) exactly 3^-k (and 2/3 from (B_m)), for k=1 also from all generalized polymorphisms:",
          "; ".join(out), ": ok")


def check_K():
    e2 = mpmath.e ** 2
    sq2 = mpmath.sqrt(2)
    c75 = sq2 / 6 * mpmath.mpf(10) ** mpmath.mpf(7.5)
    assert c75 < mpmath.mpf("7.4536e6")
    assert mpmath.mpf(18) ** mpmath.mpf(-1.5) < mpmath.mpf("0.007") * 2
    assert mpmath.mpf("0.007") + 2 * mpmath.mpf("7.4536e6") < mpmath.mpf("1.5e7")
    assert mpmath.mpf("0.007") + mpmath.mpf("7.4536e6") <= mpmath.mpf("7.46e6")
    assert 2 * mpmath.sqrt(mpmath.mpf("7.46e6")) < 5463
    assert 5463 * mpmath.mpf(18) ** mpmath.mpf(-0.75) < 626 < mpmath.mpf("7.4536e6")
    assert 1 / mpmath.mpf(4) > sq2 / 6
    aps = [mpmath.mpf(10) ** (-12 + kk * (12 - mpmath.log10(18)) / 120) for kk in range(120)]
    aps += [(1 - mpmath.mpf(10) ** (-k)) / 18 for k in range(1, 21)] + [mpmath.mpf(1) / 45]
    svals = [mpmath.mpf(1) / 2, mpmath.mpf(1) / 4, mpmath.mpf(1) / 10] + [mpmath.mpf(10) ** (-k) for k in (3, 6, 12)]
    ms = list(range(4, 41)) + [60, 100, 1000, 10 ** 4]
    worst = {"m3a": 0, "m3b": 0, "m4": 0, "open": 0, "bracket": 0}
    for ap in aps:
        assert ap < mpmath.mpf(1) / 18
        r18 = r_mp(18 * ap)
        assert r18 / 2 >= 8 * ap
        if ap <= mpmath.mpf(1) / 45:
            ratio = mpmath.mpf(9) / 2 * e2 * ap / (r18 / 2)
            worst["bracket"] = max(worst["bracket"], ratio)
        alpha3 = ap
        kap2 = 9 * alpha3 / (1 - 9 * alpha3)
        assert kap2 < 1
        r6 = r_mp(kap2)
        assert r6 >= 8 * kap2 / 9 >= 8 * alpha3 and r18 * r6 / 4 >= 32 * alpha3 ** 2
        prev = None
        for s in svals:
            kap = 18 * ap * (1 - s) / (1 - 18 * ap * s)
            assert 9 * ap <= 18 * ap * (1 - s) <= kap < min(18 * ap, 1)
            r = r_mp(kap)
            assert 8 * kap / 9 <= r < kap and r >= 8 * ap
            if prev is not None:
                assert r >= prev
            prev = r
            # m = 3
            a = alpha3
            K1 = 2 * mpmath.mpf(10) ** 15 / a
            eps_coef = K1 ** (r / 2) / (6 * a * s)
            assert eps_coef <= c75 / s * a ** mpmath.mpf(-1.5)
            assert mpmath.mpf(18) ** mpmath.mpf(-1.5) * a ** mpmath.mpf(-1.5) >= 1
            assert mpmath.mpf(18) ** mpmath.mpf(-1.5) < mpmath.mpf("0.007") / s
            Y = mpmath.mpf("7.46e6") / s * a ** mpmath.mpf(-1.5)
            assert Y >= 1
            assert 5463 / mpmath.sqrt(s) * a ** mpmath.mpf(-0.75) < 626 / s * a ** mpmath.mpf(-1.5)
            M3 = mpmath.mpf("1.5e7") * a ** mpmath.mpf(-1.5)
            Cs3 = max(4 / a ** 2, M3 / s)
            for dk in (0, 1, 3, 10, 40, 200, 2000):
                d = mpmath.mpf(10) ** (-dk)
                eps = eps_coef * d ** (r / 2)
                lhs_a = d + 2 * eps
                rhs_a = M3 / s * d ** (r / 2)
                assert lhs_a < rhs_a
                worst["m3a"] = max(worst["m3a"], lhs_a / rhs_a)
                epsb = max(eps, 2 * (d + eps) ** (r6 / 2))
                lhs_b = d + 2 * epsb
                rhs_b = M3 / s * d ** (r * r6 / 4)
                assert lhs_b < rhs_b
                worst["m3b"] = max(worst["m3b"], lhs_b / rhs_b)
            d0 = a ** 4 / 16
            for t in (mpmath.mpf(1), mpmath.mpf(10) ** -3, mpmath.mpf(10) ** -50):
                d = d0 * t
                assert 3 * d / a ** 4 <= 3 * a ** (-2 * r) * d ** (r / 2) <= 3 * a ** -2 * d ** (r / 2) <= Cs3 * d ** (r / 2)
            for t in (1 + mpmath.mpf(10) ** -20, mpmath.mpf(2), 1 / d0):
                d = min(d0 * t, mpmath.mpf(1))
                mid = (16 * d / a ** 4) ** (r / 2)
                assert 1 < mid <= 4 / a ** 2 * d ** (r / 2) * (1 + mpmath.mpf(10) ** -40)
                worst["open"] = max(worst["open"], mid / (Cs3 * d ** (r / 2)))
            # m >= 4
            for m in ms:
                dm = min(mpmath.mpf("5e-16"), (6 * sq2 * (m - 1)) ** -4)
                X = ap ** mpmath.mpf(-1.5) / mpmath.sqrt(dm)
                assert X > 3 * 10 ** 9
                K1m = 2 / (ap * dm)
                assert K1m >= 1
                assert K1m ** (r / 2) / (6 * ap * s) <= sq2 / 6 / s * X
                lhs = 1 + sq2 / 6 * (m - 1) / s * X
                rhs = mpmath.mpf(m) / 4 / s * X
                assert lhs <= rhs
                assert mpmath.mpf(m) / 4 - sq2 / 6 * (m - 1) >= sq2 / 6 > s / X
                worst["m4"] = max(worst["m4"], lhs / rhs)
                alpha = ap / mpmath.mpf(3) ** (m - 3)
                q2 = mpmath.sqrt(4 * (m + 1))
                Csm = max(q2 / alpha ** 2, mpmath.mpf(m) / 4 * X / s)
                d0 = alpha ** 4 / (4 * (m + 1))
                for t in (mpmath.mpf(1), mpmath.mpf(10) ** -30):
                    d = d0 * t
                    assert 3 * d / alpha ** 4 <= 3 * alpha ** (-2 * r) * d ** (r / 2) <= 3 / alpha ** 2 * d ** (r / 2)
                    assert 3 / alpha ** 2 <= Csm
                for t in (1 + mpmath.mpf(10) ** -20, 1 / d0):
                    d = min(d0 * t, mpmath.mpf(1))
                    mid = (4 * (m + 1) * d / alpha ** 4) ** (r / 2)
                    assert 1 < mid <= q2 / alpha ** 2 * d ** (r / 2) * (1 + mpmath.mpf(10) ** -40)
        s0 = mpmath.mpf(10) ** -12
        k0 = 18 * ap * (1 - s0) / (1 - 18 * ap * s0)
        assert abs(r_mp(k0) - r18) < mpmath.mpf(10) ** -9
    for k in range(1, 21):
        ap = (1 - mpmath.mpf(10) ** (-2 * k)) / 18
        assert 1 - r_mp(18 * ap) <= mpmath.mpf(10) ** (-k)
        v = mpmath.log(3) / mpmath.log(1 / (2 * ap))
        assert mpmath.mpf(1) / 2 - mpmath.mpf(10) ** (-2 * k) < v < mpmath.mpf(1) / 2
    assert r_mp(18 * mpmath.mpf(10) ** -12) / (18 * mpmath.mpf(10) ** -12) > 1 - mpmath.mpf(10) ** -11
    print(f"(K) {len(aps)} values alpha' in [1e-12, 1/18), s in {{1/2,1/4,1/10,1e-3,1e-6,1e-12}}, m=3 and m in 4..40,"
          f" 60, 100, 1000, 10^4: max ratios (a) {mpmath.nstr(worst['m3a'], 6)}, (b) {mpmath.nstr(worst['m3b'], 6)},"
          f" m>=4 {mpmath.nstr(worst['m4'], 6)}, opening {mpmath.nstr(worst['open'], 6)}; r_(18a')/2 >= 8a';"
          f" r_(9a/(1-9a)) >= 8a and r_(18a) r_(9a/(1-9a))/4 >= 32a^2; r_(kappa_s) increasing as s decreases,"
          f" -> r_(18a') as s -> 0; r_(18a') -> 1 and log3/log(1/(2a')) -> 1/2 as a' -> 1/18: ok."
          f" (Superseded earlier bracket, not claimed: max over a' <= 1/45 of (9/2)e^2 a'/(r_(18a')/2) ="
          f" {mpmath.nstr(worst['bracket'], 8)}.)")


if __name__ == "__main__":
    store, store_b = [], []
    check_U(store)
    check_T(store, store_b)
    check_R(store, store_b)
    check_N()
    check_E()
    check_K()
    print("ALL CHECKS PASSED")
