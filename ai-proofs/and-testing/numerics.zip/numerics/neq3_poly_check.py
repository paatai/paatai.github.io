"""Polymorphisms of P = {(a,b,c) in Z_3^3 : a+b+c != 0} (Corollary 8.68).

(b) For n = 1, 2, exhaustive search over all h : Z_3^n -> Z_3 with h(x)+h(y)+h(z) != 0 whenever
    every row of (x,y,z) is in P: the solutions are exactly the 6n functions kappa*w_i + d.
(c) The inequality err(h,h,h) >= (3/2) s - 6 s^2 with s = Pr[h != p], for every p = kappa*w_i + d:
    all h for n = 1, and for n = 2, 3 random h and random perturbations of the functions p on small
    sets (where the inequality is nearly tight). Exact enumeration under the uniform distribution pi.
(d) For n = 2, 3, 4 and h = w_1 + 1_E with E determined by w_2..w_n and s = Pr[E] <= 1/3 (both
    E = {w_2 = ... = w_n = 0} and random sets E), exact enumeration of the 18^n row tuples gives
    err(h,h,h) = (3/2) s (1-s), and Pr[h != kappa*w_i + d] >= s for all (i, kappa, d), with equality
    for w_1.
"""
import itertools
import random
import sys
from fractions import Fraction

import numpy as np

Q = 3
P = [(a, b, c) for a in range(Q) for b in range(Q) for c in range(Q) if (a + b + c) % Q]


def points(n):
    return list(itertools.product(range(Q), repeat=n))


def constraints(n):
    pts = points(n)
    idx = {w: t for t, w in enumerate(pts)}
    cons = [tuple(idx[tuple(r[j] for r in rows)] for j in range(3))
            for rows in itertools.product(P, repeat=n)]
    return np.array(cons, dtype=np.int64)


def affine(n):
    pts = points(n)
    return {(i, k, d): np.array([(k * w[i] + d) % Q for w in pts], dtype=np.int64)
            for i in range(n) for k in (1, 2) for d in range(Q)}


def err(h, cons):
    bad = int((((h[cons[:, 0]] + h[cons[:, 1]] + h[cons[:, 2]]) % Q) == 0).sum())
    return Fraction(bad, len(cons))


def polymorphisms(n, cons):
    size = Q ** n
    return [h for h in itertools.product(range(Q), repeat=size)
            if err(np.array(h, dtype=np.int64), cons) == 0]


def check_c(n, cons, aff, hs):
    worst = None
    for h in hs:
        e = err(h, cons)
        s_min = None
        for p in aff.values():
            s = Fraction(int((h != p).sum()), len(h))
            slack = e - (Fraction(3, 2) * s - 6 * s * s)
            if slack < 0:
                return False, slack
            s_min = s if s_min is None else min(s_min, s)
        if s_min > 0 and (worst is None or e / s_min < worst):
            worst = e / s_min
    return True, worst


def check_d(n, cons, aff, E):
    pts = points(n)
    h = np.array([(w[0] + (1 if w[1:] in E else 0)) % Q for w in pts], dtype=np.int64)
    s = Fraction(len(E), Q ** (n - 1))
    e = err(h, cons)
    dists = {key: Fraction(int((h != g).sum()), len(pts)) for key, g in aff.items()}
    good = e == Fraction(3, 2) * s * (1 - s) and min(dists.values()) == s and dists[(0, 1, 0)] == s
    return good, s, e, min(dists.values())


if __name__ == "__main__":
    rng = random.Random(20261021)
    ok = True
    cons = {n: constraints(n) for n in (1, 2, 3, 4)}
    aff = {n: affine(n) for n in (1, 2, 3, 4)}

    for n in (1, 2):
        sols = polymorphisms(n, cons[n])
        good = len(sols) == 6 * n and {tuple(s) for s in sols} == {tuple(int(t) for t in g)
                                                                    for g in aff[n].values()}
        print(f"(b) n={n}: {len(sols)} polymorphisms, equal to the 6n functions kappa*w_i+d: {good}")
        ok &= good

    for n, n_rand, n_pert in ((1, 0, 0), (2, 3000, 3000), (3, 300, 1500)):
        size = Q ** n
        if n == 1:
            hs = [np.array(h, dtype=np.int64) for h in itertools.product(range(Q), repeat=size)]
        else:
            hs = [np.array([rng.randrange(Q) for _ in range(size)], dtype=np.int64)
                  for _ in range(n_rand)]
            plist = list(aff[n].values())
            for _ in range(n_pert):
                h = plist[rng.randrange(len(plist))].copy()
                for t in rng.sample(range(size), rng.randint(1, max(1, size // 6))):
                    h[t] = (h[t] + rng.randrange(1, Q)) % Q
                hs.append(h)
        good, worst = check_c(n, cons[n], aff[n], hs)
        print(f"(c) n={n}: err >= (3/2)s - 6s^2 for all p and {len(hs)} functions h: {good} "
              f"(smallest err/min_p Pr[h!=p] over h that are not polymorphisms: {worst})")
        ok &= good

    for n in (2, 3, 4):
        tail = points(n - 1)
        sets = [{tuple([0] * (n - 1))}]
        for _ in range(40 if n < 4 else 12):
            k = rng.randint(1, len(tail) // 3)
            sets.append(set(rng.sample(tail, k)))
        all_good = True
        for E in sets:
            good, s, e, md = check_d(n, cons[n], aff[n], E)
            all_good &= good
        good0, s0, e0, md0 = check_d(n, cons[n], aff[n], sets[0])
        print(f"(d) n={n}: E = {{w_2=...=w_n=0}}: s={s0}, err={e0}, min distance={md0}; "
              f"{len(sets)} sets E determined by w_2..w_n, err = (3/2)s(1-s) and min distance = s "
              f"for all: {all_good}")
        ok &= all_good

    print("all checks passed" if ok else "CHECK FAILED")
    sys.exit(0 if ok else 1)
