"""Checks for Corollary 8.75: equal functions and polymorphisms of P^(m) = {a in Z_3^m : a_1+...+a_m != 0},
m >= 4, under the uniform distribution pi_m (exact integer / rational arithmetic).

(b) Exhaustive, m = 4, 5, 6, 7 and n = 1, 2: h is a polymorphism iff no (c_1..c_m) in (Z_3^n)^m with
    sum_j c_j in {1,2}^n (i.e. no matrix with rows in P^(m)) has sum_j h(c_j) = 0.  The polymorphisms are exactly
    {k w_i + d : m d = 0} u {constants u : m u != 0}: 6n of them if 3 | m, and 2n + 2 otherwise.
(d) Sharp examples, m = 4, 5, 6, 7, 9 and n = 2, 3, 4.  If 3 | m: h = w_1 + 1_E with E determined by w_2..w_n has
    err = (1/2) Pr[N != 0 mod 3] <= m s / 2.  If 3 does not divide m: h = u + m u 1_E (u = 1, 2, any E) has
    err = Pr[N = 2 mod 3] <= C(m,2) s^2.  In both cases the distance to the nearest polymorphism is exactly s.
    Here s = Pr[E] and N = #{j : c_j in E}; the law of N mod 3 is computed separately from the error.
(c) The two inequalities used in the proof, for random h near polymorphisms (m = 4..7, n = 2, 3): for every
    polymorphism p = k w_i + d, delta >= (m/2) s - m(m-1) s^2 with s = Pr[h != p]; and if 3 does not divide m, for
    u = 1, 2: delta >= (1 - (m-1) sigma) (m p_{t*} + C(m,2) p_{t**}^2), sigma = Pr[h != u], p_t = Pr[h = u + t],
    t* = -m u, t** = m u.
(a) The step behind (a), which does not depend on delta: for random tuples with prescribed equalities f_j = f_l
    (m = 4, n = 2, 3; m = 5, n = 2), whenever some tuple of type (A_m)/(B_m) is within distance < 1/2, some such
    tuple with g_j = g_l whenever f_j = f_l is within the same distance.
"""
import itertools
import random
import sys
from fractions import Fraction
from math import comb

import numpy as np

from neqm_check import Setting, perturb, random_gp

Q = 3


class Group:
    """G = Z_3^n x Z_3; element (s, v) has index v + 3 * t(s), where t(s) = sum_k s_k 3^k is the point index."""

    def __init__(self, n):
        self.n = n
        self.N = Q ** n
        self.size = Q * self.N
        coords = np.array([[(g // Q) // Q ** k % Q for k in range(n)] + [g % Q] for g in range(self.size)])
        weights = np.array([Q * Q ** k for k in range(n)] + [1])
        self.add = (((coords[:, None, :] + coords[None, :, :]) % Q) @ weights).astype(np.int64)
        self.sub = (((coords[None, :, :] - coords[:, None, :]) % Q) @ weights).astype(np.int64)
        self.pts = [tuple(t // Q ** k % Q for k in range(n)) for t in range(self.N)]
        self.bad = [Q * sum(s[k] * Q ** k for k in range(n)) for s in itertools.product((1, 2), repeat=n)]

    def counts(self, f):
        A = np.zeros(self.size, dtype=np.int64)
        np.add.at(A, Q * np.arange(self.N) + np.asarray(f) % Q, 1)
        return A

    def conv(self, A, B):
        R = np.zeros(self.size, dtype=np.int64)
        for g in np.nonzero(A)[0]:
            R[self.add[g]] += A[g] * B
        return R

    def joint(self, fs):
        C = self.counts(fs[0])
        for f in fs[1:]:
            C = self.conv(C, self.counts(f))
        assert int(C.sum()) == self.N ** len(fs)
        return C

    def err(self, fs):
        m = len(fs)
        C = self.joint(fs)
        return Fraction(int(sum(C[g] for g in self.bad)), (2 * Q ** (m - 1)) ** self.n)

    def mod3_law(self, ind, m):
        """Pr[sum_j ind(c_j) = r mod 3] under pi_m^{(x) n}, r = 0, 1, 2."""
        C = self.joint([ind] * m)
        den = (2 * Q ** (m - 1)) ** self.n
        return [Fraction(int(sum(C[g + r] for g in self.bad)), den) for r in range(Q)]

    def w(self, i):
        return np.array([p[i] for p in self.pts], dtype=np.int64)


def predicted_polys(G, m):
    out = []
    for i in range(G.n):
        for k in (1, 2):
            for d in range(Q):
                if m * d % Q == 0:
                    out.append((k * G.w(i) + d) % Q)
    for u in range(Q):
        if m * u % Q:
            out.append(np.full(G.N, u, dtype=np.int64))
    return out


def exhaustive_polys(G, m):
    H = Q ** G.N
    funcs = np.array(list(itertools.product(range(Q), repeat=G.N)), dtype=np.int64)
    R1 = np.zeros((H, G.size), dtype=bool)
    for t in range(G.N):
        R1[np.arange(H), Q * t + funcs[:, t]] = True
    R = R1.copy()
    for _ in range(m - 1):
        Z = np.zeros_like(R)
        for g1 in range(G.size):
            Z |= R[:, [g1]] & R1[:, G.sub[g1]]
        R = Z
    poly = ~R[:, G.bad].any(axis=1)
    return funcs[poly]


def dist_to(G, h, polys):
    return min(Fraction(int(np.count_nonzero(h != p)), G.N) for p in polys)


def check_b():
    ok = True
    for m in (4, 5, 6, 7):
        for n in (1, 2):
            G = Group(n)
            found = {tuple(f) for f in exhaustive_polys(G, m)}
            pred = {tuple(f) for f in predicted_polys(G, m)}
            expect = 6 * n if m % 3 == 0 else 2 * n + 2
            good = found == pred and len(found) == expect
            ok &= good
            print(f"(b) m={m}, n={n}: {len(found)} polymorphisms by exhaustive search over all {Q ** G.N} h; "
                  f"equal to {{k w_i + d : m d = 0}} u {{u : m u != 0}} ({expect}): {good}")
    return ok


def check_d(rng):
    ok = True
    for m in (4, 5, 6, 7, 9):
        for n in (2, 3, 4):
            G = Group(n)
            polys = predicted_polys(G, m)
            good = True
            tested = 0
            if m % 3 == 0:
                M = Q ** (n - 1)
                for k in range(1, M // 3 + 1):
                    for _ in range(2):
                        F = set(rng.sample(range(M), k))
                        ind = np.array([1 if t // Q in F else 0 for t in range(G.N)], dtype=np.int64)
                        s = Fraction(k, M)
                        h = (G.w(0) + ind) % Q
                        e = G.err([h] * m)
                        law = G.mod3_law(ind, m)
                        good &= e == (1 - law[0]) / 2 and e <= Fraction(m, 2) * s and dist_to(G, h, polys) == s
                        tested += 1
            else:
                for k in range(1, G.N // 3 + 1):
                    E = set(rng.sample(range(G.N), k))
                    ind = np.array([1 if t in E else 0 for t in range(G.N)], dtype=np.int64)
                    s = Fraction(k, G.N)
                    law = G.mod3_law(ind, m)
                    for u in (1, 2):
                        h = (u + m * u * ind) % Q
                        e = G.err([h] * m)
                        good &= e == law[2] and e <= comb(m, 2) * s * s and dist_to(G, h, polys) == s
                        tested += 1
            ok &= good
            form = "w_1 + 1_E: err = Pr[N != 0]/2 <= m s/2" if m % 3 == 0 else "u + m u 1_E: err = Pr[N = 2] <= C(m,2) s^2"
            print(f"(d) m={m}, n={n}: {tested} examples h = {form}, distance to polymorphisms = s: {good}")
    return ok


def check_c(rng):
    ok = True
    for m in (4, 5, 6, 7):
        for n, trials, maxk in ((2, 150, 3), (3, 60, 6)):
            G = Group(n)
            polys = predicted_polys(G, m)
            dict_polys = [p for p in polys if len(set(p.tolist())) > 1]
            good = True
            nontriv = 0
            for _ in range(trials):
                h = polys[rng.randrange(len(polys))].copy()
                for t in rng.sample(range(G.N), rng.randint(1, maxk)):
                    h[t] = (h[t] + rng.randrange(1, Q)) % Q
                de = G.err([h] * m)
                for p in dict_polys:
                    s = Fraction(int(np.count_nonzero(h != p)), G.N)
                    rhs = Fraction(m, 2) * s - m * (m - 1) * s * s
                    good &= de >= rhs
                    nontriv += rhs > 0
                if m % 3:
                    cnt = np.bincount(h, minlength=Q)
                    for u in (1, 2):
                        sigma = Fraction(G.N - int(cnt[u]), G.N)
                        pt = {t: Fraction(int(cnt[(u + t) % Q]), G.N) for t in (1, 2)}
                        ts, tss = (-m * u) % Q, (m * u) % Q
                        rhs = (1 - (m - 1) * sigma) * (m * pt[ts] + comb(m, 2) * pt[tss] ** 2)
                        good &= de >= rhs
                        nontriv += rhs > 0
            ok &= good
            print(f"(c) m={m}, n={n}: {trials} random h near polymorphisms; both inequalities hold: {good} "
                  f"({nontriv} instances with a positive right-hand side)")
    return ok


def dist_constrained(S, f):
    m, N = S.m, S.N
    cls = []
    for j in range(m):
        for C in cls:
            if np.array_equal(f[C[0]], f[j]):
                C.append(j)
                break
        else:
            cls.append([j])
    cid = [None] * m
    for ci, C in enumerate(cls):
        for j in C:
            cid[j] = ci
    sizes = [len(C) for C in cls]
    counts = [np.bincount(fj, minlength=Q) for fj in f]
    best = N + 1
    for i in range(S.n):
        for k in (1, 2):
            dis = [[int(np.count_nonzero(f[j] != S.dict_funcs[(i, k, d)])) for d in range(Q)] for j in range(m)]
            for dc in itertools.product(range(Q), repeat=len(cls)):
                if sum(sz * d for sz, d in zip(sizes, dc)) % Q == 0:
                    best = min(best, max(dis[j][dc[cid[j]]] for j in range(m)))
    for uc in itertools.product(range(Q), repeat=len(cls)):
        if sum(sz * u for sz, u in zip(sizes, uc)) % Q:
            best = min(best, max(N - int(counts[j][uc[cid[j]]]) for j in range(m)))
    for b in range(m):
        if sizes[cid[b]] > 1:
            continue
        others = [ci for ci in range(len(cls)) if ci != cid[b]]
        for uo in itertools.product(range(Q), repeat=len(others)):
            u_of = dict(zip(others, uo))
            v = (-sum(sizes[ci] * u_of[ci] for ci in others)) % Q
            d = max([N - int(counts[j][u_of[cid[j]]]) for j in range(m) if j != b] + [int(counts[b][v])])
            best = min(best, d)
    return Fraction(best, N), len(cls)


def check_a(rng):
    ok = True
    for m, n, trials, maxk in ((4, 2, 400, 2), (4, 3, 120, 4), (5, 2, 200, 2)):
        S = Setting(m, n)
        good = True
        relevant = 0
        for _ in range(trials):
            f, _typ = random_gp(S, rng)
            labels = [rng.randrange(rng.choice((1, 2, 3))) for _ in range(m)]
            lead = {}
            for j, lab in enumerate(labels):
                lead.setdefault(lab, j)
            f = [f[lead[lab]].copy() for lab in labels]
            f = perturb(f, rng, S.N, maxk)
            f = [f[lead[lab]].copy() for lab in labels]
            du = S.dist(f)
            dc, ncls = dist_constrained(S, f)
            if du < Fraction(1, 2):
                good &= dc == du
                relevant += ncls < m
        ok &= good
        print(f"(a) m={m}, n={n}: {trials} random tuples with equalities; whenever the distance to types "
              f"(A_m)/(B_m) is < 1/2 it is attained with g_j = g_l for f_j = f_l: {good} "
              f"({relevant} relevant cases with some f_j = f_l)")
    return ok


if __name__ == "__main__":
    rng = random.Random(7)
    ok = check_b()
    ok &= check_d(rng)
    ok &= check_c(rng)
    ok &= check_a(rng)
    print("all checks passed" if ok else "CHECK FAILED")
    sys.exit(0 if ok else 1)
