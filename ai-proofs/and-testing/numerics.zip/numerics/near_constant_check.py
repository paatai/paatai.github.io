r"""Exact check of the near-constant lemma (paper Lemma 8.21).

For g satisfying the completion condition at b with s = s_b(g) and f with
eta = Pr_unif[f != b] <= 1/(4m), the lemma asserts eta^s <= 2^{m+1} * delta,
where delta = Pr[f(g^n(Z)) != g(f(Z^1),...,f(Z^m))] for a uniform n x m
matrix Z.  We compute delta exactly by enumerating all 2^{nm} matrices and
record the worst ratio eta^s / delta over random and structured f.
"""
import itertools
import random
import sys

from exponent_classification import completion, depends_on_all, s_b


def err(tab, m, n, F):
    N = 1 << n
    cols = range(N)
    gn = {}
    bad = 0
    for Zc in itertools.product(cols, repeat=m):
        y = 0
        for i in range(n):
            idx = 0
            for k in range(m):
                idx |= ((Zc[k] >> i) & 1) << k
            y |= tab[idx] << i
        rhs_idx = 0
        for k in range(m):
            rhs_idx |= F[Zc[k]] << k
        if F[y] != tab[rhs_idx]:
            bad += 1
    return bad / N ** m


def main(n=4, trials=150, seed=1):
    rng = random.Random(seed)
    m = 3
    N = 1 << n
    funcs = []
    for code in range(1 << 8):
        tab = [(code >> x) & 1 for x in range(8)]
        if 2 * sum(tab) == 8 or not depends_on_all(tab, m):
            continue
        funcs.append(tab)
    rng.shuffle(funcs)
    worst = 0.0
    checked = 0
    for tab in funcs[:24]:
        for b in (0, 1):
            s = s_b(tab, m, b)
            if s >= 2 and not completion(tab, m, b, s):
                continue
            for t in range(trials):
                k = rng.choice([1, 1, 1, 2])
                F = [b] * N
                if t % 3 == 0:
                    pts = rng.sample(range(N), k)
                else:
                    I = rng.sample(range(n), rng.choice([n - 1, n]))
                    pts = [x for x in range(N) if all((x >> i) & 1 == (t >> (i % 2)) & 1 for i in I)][:k]
                for x in pts:
                    F[x] = 1 - b
                eta = sum(1 for x in range(N) if F[x] != b) / N
                if eta == 0 or eta > 1 / (4 * m):
                    continue
                d = err(tab, m, n, F)
                ratio = eta ** s / (2 ** (m + 1) * d) if d > 0 else float("inf")
                worst = max(worst, ratio)
                checked += 1
                if ratio > 1:
                    print("VIOLATION", "".join(map(str, tab)), b, s, F, eta, d)
    print(f"n={n}: checked {checked} (g,b,f) triples; max eta^s/(2^(m+1) delta) = {worst:.4f}")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
