#!/usr/bin/env python3
"""Structured search for f = 1{#zeros(x) in Z} with Z a union of a few integer intervals (uniform measure).

Closed forms (P = zero set of x, Q = zero set of y, so x & y has zero set P u Q):
  2^n mu            = sum_{m in Z} C(n,m)
  4^n Pr[x&y in A]  = sum_{m in Z} C(n,m) 3^m
  4^n tau           = sum_{m in Z} C(n,m) N_m,   N_m = #{(P,Q): P u Q = [m], |P|,|Q| in Z}
                                                     = sum_{i,j in Z} C(m,i) C(i, i+j-m)
  eps = Pr[x&y in A] + mu^2 - 2 tau
  Delta(u) = 2^{u-n} (2 Pr[Bin(u,1/2) in Z] - 1)  (gain of AND_S over 0, |S| = n-u),  dist = mu - max(0, max_u Delta(u)).
Evaluated in log space (floating point) for the search; maximisers are re-checked exactly elsewhere.
Usage: python3 band_search.py n [n2 ...]
"""
import sys

import numpy as np
from scipy.special import gammaln, logsumexp

LOG2, LOG3, LOG4 = np.log(2.0), np.log(3.0), np.log(4.0)


def lC(a, b):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    out = gammaln(a + 1) - gammaln(b + 1) - gammaln(a - b + 1)
    return np.where((b >= 0) & (b <= a), out, -np.inf)


def evaluate(n, Z):
    Z = np.array(sorted(set(int(z) for z in Z if 0 <= z <= n)))
    if len(Z) == 0:
        return 0.0, None
    lCn = lC(n, Z)
    log_mu = logsumexp(lCn) - n * LOG2
    log_meet = logsumexp(lCn + Z * LOG3) - n * LOG4
    I = Z[:, None]
    J = Z[None, :]
    lN = np.empty(len(Z))
    for k, m in enumerate(Z):
        mask = (I <= m) & (J <= m) & (I + J >= m)
        vals = np.where(mask, lC(m, I) + lC(I, I + J - m), -np.inf)
        lN[k] = logsumexp(vals)
    log_tau = logsumexp(lCn + lN) - n * LOG4
    mu = np.exp(log_mu)
    eps = np.exp(log_meet) + mu * mu - 2 * np.exp(log_tau)
    u = np.arange(n + 1)
    # Pr[Bin(u,1/2) in Z] for all u
    lpz = np.array([logsumexp(lC(uu, Z[Z <= uu]) - uu * LOG2) if np.any(Z <= uu) else -np.inf for uu in u])
    Delta = np.exp((u - n) * LOG2) * (2 * np.exp(lpz) - 1)
    k = int(np.argmax(Delta))
    gain = max(0.0, Delta[k])
    dist = mu - gain
    if eps <= 0:
        return np.inf, None
    return dist * dist / eps, (n - k if Delta[k] > 0 else None)


def Z_of(bands, extra):
    Z = set(extra)
    for a, b in bands:
        Z.update(range(a, b + 1))
    return Z


def climb(n, bands, extra, iters=400, rng=None):
    best = evaluate(n, Z_of(bands, extra))[0]
    bands = [list(b) for b in bands]
    extra = set(extra)
    steps = [1, 2, 3]
    improved = True
    while improved:
        improved = False
        moves = []
        for bi in range(len(bands)):
            for e in range(2):
                for s in steps:
                    for sg in (-1, 1):
                        moves.append(("band", bi, e, sg * s))
            for sg in (-1, 1):
                moves.append(("shift", bi, 0, sg))
        for z in range(0, 6):
            moves.append(("extra", z, 0, 0))
        for mv in moves:
            nb = [b[:] for b in bands]
            ne = set(extra)
            if mv[0] == "band":
                nb[mv[1]][mv[2]] += mv[3]
            elif mv[0] == "shift":
                nb[mv[1]][0] += mv[3]
                nb[mv[1]][1] += mv[3]
            else:
                ne ^= {mv[1]}
            if any(b[0] > b[1] or b[0] < 0 or b[1] > n for b in nb):
                continue
            r = evaluate(n, Z_of([tuple(b) for b in nb], ne))[0]
            if r > best + 1e-13:
                best, bands, extra, improved = r, nb, ne, True
    return best, [tuple(b) for b in bands], sorted(extra)


if __name__ == "__main__":
    for n in [int(t) for t in sys.argv[1:]]:
        seeds = [
            [(round(0.30 * n), round(0.48 * n)), (round(0.62 * n), round(0.68 * n))],
            [(round(0.28 * n), round(0.47 * n)), (round(0.60 * n), round(0.67 * n))],
            [(round(0.30 * n), round(0.48 * n)), (round(0.62 * n), round(0.68 * n)), (round(0.78 * n), round(0.80 * n))],
        ]
        results = []
        for sd in seeds:
            for ex in ([], [0, 1]):
                results.append(climb(n, sd, ex))
        results.sort(key=lambda t: -t[0])
        r, bands, extra = results[0]
        print(f"n={n}: ratio {r:.9f} bands(zero counts) {bands} extra {extra}", flush=True)
