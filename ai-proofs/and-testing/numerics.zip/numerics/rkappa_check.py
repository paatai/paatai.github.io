"""The exponent r_kappa = 2(1 - sqrt(1-kappa))/(2 - sqrt(1-kappa)) of the reverse hypercontractivity lemma
(Lemma 8.35 of the PDF) satisfies 8 kappa/9 <= r_kappa < kappa for every kappa in (0, 1).

Checks:
 (I)  exact (rationals): with t = sqrt(1 - kappa), so kappa = (1 - t)(1 + t), the polynomial identities
      2(1 - t)(2 - t)(1 + t) = 2(2 - t)(1 - t)(1 + t) [i.e. r_kappa/kappa = 2/((2 - t)(1 + t))],
      (2 - t)(1 + t) = 2 + t(1 - t) = 1 + kappa + t and 9/4 - (2 + t(1 - t)) = (t - 1/2)^2, each of degree
      at most 3 in t, at 50 rational points (more than the degree, so they hold identically).
 (G)  mpmath (120 digits, since 1 - sqrt(1 - kappa) cancels for small kappa; tolerance 1e-50): on 10^5
      points kappa in (0, 1) and on geometric grids towards 0 and 1 (down to distance 1e-30),
      8/9 <= r_kappa/kappa < 1 and the closed form agrees; the minimum 8/9 is attained at kappa = 3/4.
 (C)  the consequences used in the text: r_(9 alpha) >= 8 alpha and r_(2 alpha) >= (16/9) alpha, so
      r_(9 alpha)/2 >= 4 alpha and r_(9 alpha) r_(2 alpha)/4 >= (32/9) alpha^2 (the exponents of Theorem 8.61);
      (9/2) e^2/4 = (9/8) e^2 < 8.4 (the bracket of Remark 8.63(a)); also r_(9 alpha) <= 9 alpha <= 1/2.
"""
from fractions import Fraction

import mpmath


def r_of(kappa):
    s = mpmath.sqrt(1 - kappa)
    return 2 * (1 - s) / (2 - s)


def check_I():
    for i in range(1, 51):
        t = Fraction(i, 51)
        kappa = (1 - t) * (1 + t)
        assert kappa == 1 - t * t
        r = 2 * (1 - t) / (2 - t)
        assert r / kappa == 2 / ((2 - t) * (1 + t))
        assert (2 - t) * (1 + t) == 2 + t * (1 - t) == 1 + kappa + t
        assert Fraction(9, 4) - (2 + t * (1 - t)) == (t - Fraction(1, 2)) ** 2
        assert Fraction(8, 9) <= r / kappa < 1
    print("(I) r/kappa = 2/((2-t)(1+t)) = 2/(2+t(1-t)) = 2/(1+kappa+sqrt(1-kappa)); 9/4-(2+t(1-t)) = (t-1/2)^2;"
          " exact at 50 rational t: ok")


def check_G():
    mpmath.mp.dps = 120
    lo, arg = mpmath.inf, None
    pts = [mpmath.mpf(i) / 100000 for i in range(1, 100000)]
    pts += [mpmath.mpf(10) ** (-k) for k in range(6, 31)] + [1 - mpmath.mpf(10) ** (-k) for k in range(6, 31)]
    for k in pts:
        q = r_of(k) / k
        t = mpmath.sqrt(1 - k)
        assert abs(q - 2 / (2 + t * (1 - t))) < mpmath.mpf(10) ** -50
        assert mpmath.mpf(8) / 9 - mpmath.mpf(10) ** -50 <= q < 1
        if q < lo:
            lo, arg = q, k
    assert abs(r_of(mpmath.mpf(3) / 4) / (mpmath.mpf(3) / 4) - mpmath.mpf(8) / 9) < mpmath.mpf(10) ** -50
    print(f"(G) {len(pts)} points: 8/9 <= r/kappa < 1; min r/kappa = {mpmath.nstr(lo, 12)} at kappa ="
          f" {mpmath.nstr(arg, 6)}; r/kappa at kappa = 1/2: {mpmath.nstr(r_of(mpmath.mpf(1) / 2) * 2, 8)}: ok")


def check_C():
    mpmath.mp.dps = 120
    for i in range(0, 401):
        a = mpmath.mpf(10) ** (-30 + i * (30 - mpmath.log10(18)) / 400)
        a = min(a, mpmath.mpf(1) / 18)
        r, rp = r_of(9 * a), r_of(2 * a)
        assert r >= 8 * a and r / 2 >= 4 * a and r <= 9 * a <= mpmath.mpf(1) / 2
        assert rp >= mpmath.mpf(16) / 9 * a and r * rp / 4 >= mpmath.mpf(32) / 9 * a ** 2
    e2 = mpmath.e ** 2
    assert mpmath.mpf(9) / 2 * e2 / 4 == mpmath.mpf(9) / 8 * e2 < mpmath.mpf("8.4")
    print(f"(C) alpha in [1e-30, 1/18] (401 points): r_(9a) >= 8a, r_(2a) >= 16a/9, r_(9a)/2 >= 4a,"
          f" r_(9a) r_(2a)/4 >= 32a^2/9; (9/8)e^2 = {mpmath.nstr(mpmath.mpf(9) / 8 * e2, 8)} < 8.4: ok")


if __name__ == "__main__":
    check_I()
    check_G()
    check_C()
    print("all checks passed")
