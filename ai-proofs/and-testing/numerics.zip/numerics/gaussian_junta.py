#!/usr/bin/env python3
"""Gaussian limit with k junta bits: f(z, x) = g_z(X) near weight n/2 and h_w(U) near weight n/4.

z, z' uniform in {0,1}^k, the meet is w = z & z'. With mu_z = E g_z, m = E_z mu_z,
  eps = m^2 - sum_w E[(2 Psi_w(U) - P(w))_+],  Psi_w(u) = 4^-k sum_{z & z' = w} E[g_z(X) g_z'(Y) | U = u],
  P(w) = Pr[z & z' = w],  and the optimal h_w = 1{2 Psi_w > P(w)};
  dist = min( m, min_{T subseteq [k]} E_z[mu_z + 1{z_T = 1}(1 - 2 mu_z)] ).
g_z = 1{X >= a_z} (a_z = +inf: g_z = 0; -inf: g_z = 1). Given U = u, (X, Y) is bivariate normal with means u/3,
variances 2/3 and correlation -1/2, so the conditional orthant probabilities are evaluated with Owen's T function.
"""
import itertools
import sys

import numpy as np
from scipy.optimize import minimize
from scipy.special import owens_t
from scipy.stats import norm

UG = np.linspace(-12, 12, 4801)
PU = norm.pdf(UG, scale=np.sqrt(3.0)) * (UG[1] - UG[0])


RHO = -0.5


def Phi2(h, k, rho=RHO):
    """P[Z1 <= h, Z2 <= k] for standard bivariate normal with correlation rho (Owen's T formula), vectorised."""
    h = np.where(np.abs(h) < 1e-12, 1e-12, h)
    k = np.where(np.abs(k) < 1e-12, 1e-12, k)
    s = np.sqrt(1 - rho * rho)
    ah = (k - rho * h) / (h * s)
    ak = (h - rho * k) / (k * s)
    beta = np.where(h * k > 0, 0.0, 0.5)
    return 0.5 * (norm.cdf(h) + norm.cdf(k)) - owens_t(h, ah) - owens_t(k, ak) - beta


def cond_orthant(a, b):
    """phi(u) = P[X >= a, Y >= b | U = u] on the U grid; (X, Y) | U=u ~ N((u/3,u/3), 2/3, corr -1/2)."""
    if a == np.inf or b == np.inf:
        return np.zeros_like(UG)
    sd = np.sqrt(2 / 3)
    if a == -np.inf and b == -np.inf:
        return np.ones_like(UG)
    if a == -np.inf:
        return norm.cdf((UG / 3 - b) / sd)
    if b == -np.inf:
        return norm.cdf((UG / 3 - a) / sd)
    return Phi2((UG / 3 - a) / sd, (UG / 3 - b) / sd)


def ratio(avec, k):
    zs = list(itertools.product([0, 1], repeat=k))
    a = dict(zip(zs, avec))
    mu = {z: norm.sf(a[z]) for z in zs}
    m = np.mean([mu[z] for z in zs])
    Psi, P = {}, {}
    for z in zs:
        for z2 in zs:
            w = tuple(x & y for x, y in zip(z, z2))
            Psi[w] = Psi.get(w, 0) + cond_orthant(a[z], a[z2]) / 4 ** k
            P[w] = P.get(w, 0) + 1 / 4 ** k
    gain = sum(np.sum(PU * np.maximum(2 * Psi[w] - P[w], 0)) for w in Psi)
    eps = m * m - gain
    d = m
    for T in itertools.chain.from_iterable(itertools.combinations(range(k), r) for r in range(k + 1)):
        val = np.mean([mu[z] + (all(z[t] for t in T)) * (1 - 2 * mu[z]) for z in zs])
        d = min(d, val)
    return d * d / eps, dict(m=m, eps=eps, dist=d, mu=mu)


if __name__ == "__main__":
    k = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    rng = np.random.default_rng(1)
    print("k=0 check (single threshold a=0):", ratio([0.0], 0)[0], flush=True)
    best = (0, None)
    for trial in range(int(sys.argv[2]) if len(sys.argv) > 2 else 30):
        x0 = rng.normal(0, 1.0, size=2 ** k)
        res = minimize(lambda v: -ratio(np.clip(v, -8, 8), k)[0], x0, method="Nelder-Mead",
                       options=dict(maxiter=600, xatol=1e-4, fatol=1e-7))
        r = -res.fun
        if r > best[0]:
            best = (r, np.clip(res.x, -8, 8))
            print(f"trial {trial}: ratio {r:.6f} thresholds {np.round(best[1], 3)}", flush=True)
    r, info = ratio(best[1], k)
    print("best", r, info)
