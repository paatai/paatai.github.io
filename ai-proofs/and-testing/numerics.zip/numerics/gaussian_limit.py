#!/usr/bin/env python3
"""Gaussian (n -> infinity) limit of symmetric two-region constructions for the AND test.

f(x) = g(X) for |x| = n/2 + (sqrt(n)/2) X  (region near weight n/2),
f(x) = h(U) for |x| = n/4 + (sqrt(n)/4) U  (region near weight n/4), f = 0 elsewhere.
For independent uniform x, y:  (X, Y, U) -> (X, Y, X+Y+V) with X, Y, V iid N(0,1).
Limits:  mu = E g(X),  Pr[f(x&y)=1] = E h(U),  tau = E[g(X) g(Y) h(U)],  eps = E h(U) + mu^2 - 2 tau,
and every AND_S (|S| fixed) has gain 2^-s (2 mu - 1), so dist = min(mu, 1 - mu).
For fixed g the best h is h(u) = 1{phi(u) > 1/2}, phi(u) = E[g(X) g(Y) | U = u], giving
eps = mu^2 - Gamma,  Gamma = E[(2 phi(U) - 1)_+].
Given U = u: (X, Y) ~ N((u/3, u/3), [[2/3, -1/3], [-1/3, 2/3]]).
"""
import numpy as np
from scipy.stats import multivariate_normal, norm


def phi_threshold(a, u):
    # P[X >= a, Y >= a | U = u]
    m = u / 3.0
    cov = np.array([[2 / 3, -1 / 3], [-1 / 3, 2 / 3]])
    # P[X >= a, Y >= a] = P[-X <= -a, -Y <= -a]; (-X,-Y) has mean -m, same cov
    return multivariate_normal(mean=[-m, -m], cov=cov).cdf([-a, -a])


def gamma_threshold(a, grid=np.linspace(-12, 12, 2401)):
    sd = np.sqrt(3.0)
    vals = np.array([max(0.0, 2 * phi_threshold(a, u) - 1) for u in grid])
    dens = norm.pdf(grid, scale=sd)
    return np.trapezoid(vals * dens, grid)


if __name__ == "__main__":
    for a in [-0.2, -0.1, 0.0, 0.1, 0.2, 0.3, 0.5, 0.75, 1.0]:
        mu = norm.sf(a)
        G = gamma_threshold(a)
        d = min(mu, 1 - mu)
        print(f"a={a:5.2f}: mu={mu:.4f} Gamma={G:.5f} eps={mu * mu - G:.5f} ratio dist^2/eps={d * d / (mu * mu - G):.5f}",
              flush=True)
