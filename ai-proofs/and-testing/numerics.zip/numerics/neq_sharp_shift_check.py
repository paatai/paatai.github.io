"""Checks for Proposition prop:neqsharp (the sharp constant for uniform marginals).

Statement checked: for a full-support distribution mu on P^(m)_neq = {a in Z_3^m : sum a != 0}
with uniform marginals and M = max_{j != l, a, b} mu_jl(a, b), no exponent c > (9/4)(1/3 - M) is
possible; for mu^sh_{m,alpha} (mass alpha on the 4*3^(m-2) rows with a_m != a_{m-1}+1, mass
(1 - 4*3^(m-2) alpha)/(2*3^(m-2)) on the other 2*3^(m-2) rows), M = (1 - 12 alpha')/3 with
alpha' = 3^(m-3) alpha, so c <= 9 alpha'.  Together with Proposition prop:neqmularge the class
supremum lies in [r_{18 alpha'}/2, 9 alpha'].

Suites:
  (P) mu^sh_{m,alpha} exactly (m = 3, 4, 5; several alpha' <= 1/18): masses, support, minimum,
      uniform marginals, M = (1 - 12 alpha')/3 attained by the last two entries, Pr[X = +-1] = 4 alpha',
      smallest ratio mu_jl(a,b)/(mu_j(a) mu_l(b)) of the last two entries = 18 alpha'.
  (G) random mu with uniform marginals (m = 3, 4): 1/9 <= M <= 1/3 - 4 alpha', Pr[X = +-1] = 1/3 - M.
  (C) cosh(t) - 1 <= (t^2/2) cosh(t) and 1 + 2p(cosh t - 1) <= exp(p t^2 cosh t) on grids.
  (T) Pr[Bin(n,1/3) = k] >= exp(-n d(k/n))/(n+1) for n <= 200 (all k); the Taylor bound for d;
      d(k_A/n), d(k_B/n) <= K_n for n >= 7 and 0 < tau < min(p, 1/6) on grids.
  (E) m = 3, mu^sh_alpha (four values of alpha, two of tau), n = 30, 60, ..., 150: the error of
      (0, 1_A, 1 + 1_B), summed in floating point (log-gamma) over the four classes of rows given by
      1[y_2 = 0], 1[y_3 = 1], against exp(-Lambda n) (relative tolerance 1e-12), and Pr[A], Pr[B],
      exactly (fractions), against exp(-n K_n)/(n+1); for n <= 4 the exact class formula for the
      error against enumeration of all row tuples.
  (D) m = 3, 3 <= n <= 7: the distance of (0, 1_A, 1 + 1_B) from all tuples of types (A) and (B), by
      exact enumeration; it equals min(Pr[A], Pr[B]).
  (R) grids: r_{18a}/2 >= max(8a, 9a(1 - 9a)); 18a/r_{18a} = 1 + t(1-t)/2 <= 9/8 (equality at
      a = 1/24); limits; 9a <= log 3/log(1/(2a)) on (0, 1/18]; Lambda/(2K) -> 1/(18 a') as tau -> 0;
      the tau-bound decreases to 9p/4.
"""
import itertools
import math
import random
from fractions import Fraction

import mpmath
import numpy as np

mpmath.mp.dps = 50
Q = 3
FAIL = []


def check(cond, msg):
    if not cond:
        FAIL.append(msg)
        print("FAIL:", msg)


def rows(m):
    return [a for a in itertools.product(range(Q), repeat=m) if sum(a) % Q != 0]


def marg(mu, idx):
    out = {}
    for a, p in mu.items():
        k = tuple(a[i] for i in idx)
        out[k] = out.get(k, 0) + p
    return out


def mu_sh(m, alpha):
    heavy = (1 - 4 * 3 ** (m - 2) * alpha) / (2 * 3 ** (m - 2))
    return {a: (heavy if a[m - 1] == (a[m - 2] + 1) % Q else alpha) for a in rows(m)}, heavy


def max_pair(mu, m):
    best = None
    for j in range(m):
        for l in range(m):
            if j == l:
                continue
            pj = marg(mu, (j, l))
            for (a, b), v in pj.items():
                if best is None or v > best[0]:
                    best = (v, j, l, a, b)
    return best


def X_probs(mu, j, l, a0, b0):
    p_plus = sum(v for a, v in mu.items() if a[j] == a0 and a[l] != b0)
    p_minus = sum(v for a, v in mu.items() if a[j] != a0 and a[l] == b0)
    return p_plus, p_minus


def check_P():
    print("(P) mu^sh_{m,alpha} exactly")
    for m in (3, 4, 5):
        P = rows(m)
        check(len(P) == 2 * 3 ** (m - 1), "row count")
        for ap in (Fraction(1, 1000), Fraction(1, 90), Fraction(1, 45), Fraction(1, 30),
                   Fraction(1, 24), Fraction(1, 20), Fraction(1, 18)):
            alpha = ap / 3 ** (m - 3)
            mu, heavy = mu_sh(m, alpha)
            nheavy = sum(1 for a in P if a[m - 1] == (a[m - 2] + 1) % Q)
            check(nheavy == 2 * 3 ** (m - 2), "heavy count")
            check(sum(mu.values()) == 1, "total mass")
            check(min(mu.values()) == alpha and heavy >= alpha, "minimum alpha")
            for j in range(m):
                check(all(v == Fraction(1, 3) for v in marg(mu, (j,)).values()), "uniform marginal")
            M, j, l, a0, b0 = max_pair(mu, m)
            check(M == (1 - 12 * ap) / 3, "M = (1-12a')/3")
            pair = marg(mu, (m - 2, m - 1))
            check(all(pair[(b, (b + 1) % Q)] == M for b in range(Q)), "M attained by last two entries")
            pp, pm = X_probs(mu, m - 2, m - 1, 0, 1)
            check(pp == 4 * ap and pm == 4 * ap, "Pr[X=+-1] = 4a'")
            check(Fraction(9, 4) * (Fraction(1, 3) - M) == 9 * ap, "bound 9a'")
            ratio = min(v * 9 for v in pair.values())
            check(ratio == 18 * ap, "smallest ratio 18a'")
            for (a, b), v in pair.items():
                if b != (a + 1) % Q:
                    check(v == 2 * ap, "light pair mass 2a'")
            if ap == Fraction(1, 18):
                check(all(v == Fraction(1, 2 * 3 ** (m - 1)) for v in mu.values()), "a'=1/18 gives pi_m")
        print(f"  m={m}: 7 values of alpha' checked")


def solve(G, b):
    n = len(G)
    M = [row[:] + [b[i]] for i, row in enumerate(G)]
    for c in range(n):
        piv = next(r for r in range(c, n) if M[r][c] != 0)
        M[c], M[piv] = M[piv], M[c]
        inv = 1 / M[c][c]
        M[c] = [x * inv for x in M[c]]
        for r in range(n):
            if r != c and M[r][c] != 0:
                f = M[r][c]
                M[r] = [x - f * y for x, y in zip(M[r], M[c])]
    return [M[i][n] for i in range(n)]


def kernel_direction(P, m, rng):
    B = [[Fraction(int(a[j] == v)) for a in P] for j in range(m) for v in (0, 1)] + [[Fraction(1)] * len(P)]
    x = [Fraction(rng.randint(-50, 50)) for _ in P]
    G = [[sum(r1[i] * r2[i] for i in range(len(P))) for r2 in B] for r1 in B]
    y = solve(G, [sum(r[i] * x[i] for i in range(len(P))) for r in B])
    return [x[i] - sum(y[k] * B[k][i] for k in range(len(B))) for i in range(len(P))]


def random_mu(m, rng, lam):
    P = rows(m)
    pim = Fraction(1, 2 * 3 ** (m - 1))
    v = kernel_direction(P, m, rng)
    epsmax = min(pim / (-vi) for vi in v if vi < 0)
    return {a: pim + lam * epsmax * vi for a, vi in zip(P, v)}


def check_G():
    print("(G) random mu with uniform marginals")
    rng = random.Random(20261022)
    cnt = 0
    for m, trials in ((3, 60), (4, 12)):
        for _ in range(trials):
            lam = Fraction(rng.choice([1, 3, 9, 99, 999]), 1000)
            mu = random_mu(m, rng, lam)
            alpha = min(mu.values())
            check(alpha > 0, "full support")
            for j in range(m):
                check(all(v == Fraction(1, 3) for v in marg(mu, (j,)).values()), "uniform marginal (G)")
            ap = alpha * 3 ** (m - 3)
            M, j, l, a0, b0 = max_pair(mu, m)
            check(Fraction(1, 9) <= M <= Fraction(1, 3) - 4 * ap, "1/9 <= M <= 1/3 - 4a'")
            pp, pm = X_probs(mu, j, l, a0, b0)
            check(pp == Fraction(1, 3) - M and pm == Fraction(1, 3) - M, "Pr[X=+-1] = 1/3 - M")
            cnt += 1
    print(f"  {cnt} random distributions checked")


def check_C():
    print("(C) cosh inequalities")
    worst = mpmath.inf
    for i in range(1, 3001):
        t = mpmath.mpf(i) / 1000
        lhs = mpmath.cosh(t) - 1
        rhs = t ** 2 / 2 * mpmath.cosh(t)
        check(lhs <= rhs, f"cosh bound at {t}")
        worst = min(worst, rhs - lhs)
        for j in (1, 10, 50, 100, 200, 333):
            p = mpmath.mpf(j) / 1000
            check(1 + 2 * p * (mpmath.cosh(t) - 1) <= mpmath.exp(p * t ** 2 * mpmath.cosh(t)), "mgf bound")
    print("  min gap (t^2/2)cosh t - (cosh t - 1) over t in (0,3]:", mpmath.nstr(worst, 5))


def dq(q):
    q = mpmath.mpf(q)
    third = mpmath.mpf(1) / 3
    s = mpmath.mpf(0)
    if q > 0:
        s += q * mpmath.log(q / third)
    if q < 1:
        s += (1 - q) * mpmath.log((1 - q) / (1 - third))
    return s


def check_T():
    print("(T) method of types and Taylor bounds")
    third = mpmath.mpf(1) / 3
    worst = mpmath.inf
    for n in range(1, 201):
        for k in range(n + 1):
            pk = mpmath.binomial(n, k) * third ** k * (1 - third) ** (n - k)
            lb = mpmath.exp(-n * dq(mpmath.mpf(k) / n)) / (n + 1)
            check(pk >= lb, f"type bound n={n} k={k}")
            worst = min(worst, pk / lb)
    print("  min ratio Pr[Bin=k] / (e^{-n d}/(n+1)) over n<=200:", mpmath.nstr(worst, 8))
    for i in range(1, 1000):
        q = mpmath.mpf(i) / 1000
        mn = min(q * (1 - q), mpmath.mpf(2) / 9)
        check(dq(q) <= (q - third) ** 2 / (2 * mn) * (1 + mpmath.mpf(10) ** -40), f"Taylor bound q={q}")
    cnt = 0
    for p in (Fraction(1, 250), Fraction(1, 45), Fraction(4, 45), Fraction(1, 5), Fraction(1, 3)):
        for frac in (Fraction(1, 2), Fraction(1, 10), Fraction(99, 100)):
            tau = min(p, Fraction(1, 6)) * frac
            for n in list(range(7, 60)) + [100, 257, 400]:
                kA = math.ceil((Fraction(1, 3) + tau) * n)
                kB = math.floor((Fraction(1, 3) - tau) * n)
                tn = tau + Fraction(1, n)
                check(0 <= kB < kA <= n, "kB < kA range")
                check(Fraction(1, 3) <= Fraction(kA, n) <= Fraction(2, 3), "kA/n in [1/3,2/3]")
                check(Fraction(kB, n) >= Fraction(1, 3) - tn > 0, "kB/n >= 1/3 - tau_n > 0")
                check(abs(Fraction(kA, n) - Fraction(1, 3)) <= tn and abs(Fraction(kB, n) - Fraction(1, 3)) <= tn, "|k/n-1/3|<=tau_n")
                Kn = mpmath.mpf(tn.numerator) ** 2 / tn.denominator ** 2 / (2 * (third - mpmath.mpf(tn.numerator) / tn.denominator) * (2 * third + mpmath.mpf(tn.numerator) / tn.denominator))
                check(dq(mpmath.mpf(kA) / n) <= Kn and dq(mpmath.mpf(kB) / n) <= Kn, "d(k/n) <= K_n")
                cnt += 1
    print(f"  {cnt} (p, tau, n) triples checked for the k_A, k_B claims")


def binom_tail_ge(n, k):
    return sum(Fraction(math.comb(n, i) * 2 ** (n - i), 3 ** n) for i in range(max(k, 0), n + 1))


def binom_tail_le(n, k):
    return sum(Fraction(math.comb(n, i) * 2 ** (n - i), 3 ** n) for i in range(0, min(k, n) + 1))


def err_classes(n, alpha, kA, kB):
    q11 = (1 - 12 * alpha) / 3
    q10 = q01 = 4 * alpha
    q00 = Fraction(2, 3) - 4 * alpha
    lq = [math.log(float(x)) for x in (q11, q10, q01, q00)]
    lf = [math.lgamma(i + 1) for i in range(n + 1)]
    terms = []
    for n11 in range(n + 1):
        for n10 in range(n + 1 - n11):
            if n11 + n10 < kA:
                continue
            hi = min(kB - n11, n - n11 - n10)
            if hi < 0:
                continue
            n01 = np.arange(0, hi + 1)
            n00 = n - n11 - n10 - n01
            lt = (lf[n] - lf[n11] - lf[n10] - np.array([lf[x] for x in n01]) - np.array([lf[x] for x in n00])
                  + n11 * lq[0] + n10 * lq[1] + n01 * lq[2] + n00 * lq[3])
            terms.append(lt)
    if not terms:
        return 0.0
    allt = np.concatenate(terms)
    mx = allt.max()
    return float(np.exp(mx) * np.exp(allt - mx).sum())


def err_classes_exact(n, alpha, kA, kB):
    q11 = (1 - 12 * alpha) / 3
    q10 = q01 = 4 * alpha
    q00 = Fraction(2, 3) - 4 * alpha
    s = Fraction(0)
    for n11 in range(n + 1):
        for n10 in range(n + 1 - n11):
            for n01 in range(n + 1 - n11 - n10):
                n00 = n - n11 - n10 - n01
                if n11 + n10 >= kA and n11 + n01 <= kB:
                    c = math.factorial(n) // (math.factorial(n11) * math.factorial(n10) * math.factorial(n01) * math.factorial(n00))
                    s += c * q11 ** n11 * q10 ** n10 * q01 ** n01 * q00 ** n00
    return s


def check_E():
    print("(E) m = 3, mu^sh_alpha: error and Pr[A], Pr[B]")
    for alpha in (Fraction(1, 90), Fraction(1, 45), Fraction(1, 30), Fraction(1, 20)):
        p = 4 * alpha
        for tfrac in (Fraction(1, 2), Fraction(1, 4)):
            tau = min(p, Fraction(1, 6)) * tfrac
            if tau >= min(p, Fraction(1, 6)):
                continue
            tf = float(tau)
            pf = float(p)
            Lam = tf ** 2 / pf * (2 - math.cosh(tf / pf))
            line = []
            for n in (30, 60, 90, 120, 150):
                kA = math.ceil((Fraction(1, 3) + tau) * n)
                kB = math.floor((Fraction(1, 3) - tau) * n)
                e = err_classes(n, alpha, kA, kB)
                check(e <= math.exp(-Lam * n) * (1 + 1e-12), f"err <= e^(-Lambda n) a={alpha} tau={tau} n={n}")
                PA = binom_tail_ge(n, kA)
                PB = binom_tail_le(n, kB)
                tn = tf + 1 / n
                Kn = tn ** 2 / (2 * (1 / 3 - tn) * (2 / 3 + tn))
                lb = math.exp(-n * Kn) / (n + 1)
                check(float(PA) >= lb and float(PB) >= lb, f"Pr[A],Pr[B] >= e^(-nK_n)/(n+1) a={alpha} n={n}")
                line.append(f"n={n}: err={e:.3e} (bound {math.exp(-Lam*n):.3e}), PA={float(PA):.3e}, PB={float(PB):.3e}, lb={lb:.3e}")
            print(f"  alpha={alpha}, tau={tau}:")
            for s in line:
                print("    " + s)
    # cross-check the class formula against full enumeration of row tuples for n <= 4
    P = rows(3)
    for alpha in (Fraction(1, 45), Fraction(1, 20)):
        mu, _ = mu_sh(3, alpha)
        p = 4 * alpha
        tau = p / 2
        for n in (1, 2, 3, 4):
            kA = math.ceil((Fraction(1, 3) + tau) * n)
            kB = math.floor((Fraction(1, 3) - tau) * n)
            tot = Fraction(0)
            for tup in itertools.product(P, repeat=n):
                n0 = sum(1 for r in tup if r[1] == 0)
                n1 = sum(1 for r in tup if r[2] == 1)
                f2 = 1 if n0 >= kA else 0
                f3 = 1 + (1 if n1 <= kB else 0)
                if (0 + f2 + f3) % Q == 0:
                    pr = Fraction(1)
                    for r in tup:
                        pr *= mu[r]
                    tot += pr
            check(tot == err_classes_exact(n, alpha, kA, kB), f"class formula n={n}")
        print(f"  alpha={alpha}: class formula = enumeration for n<=4")


def type_tuples_B(n):
    out = []
    for i in range(n):
        for kap in (1, 2):
            for d in itertools.product(range(Q), repeat=3):
                if all((kap * s + sum(d)) % Q != 0 for s in (1, 2)):
                    out.append((i, kap, d))
    return out


def check_D():
    print("(D) m = 3: distance from all tuples of types (A) and (B)")
    for alpha in (Fraction(1, 45), Fraction(1, 20)):
        p = 4 * alpha
        tau = p / 2
        for n in range(3, 8):
            pts = list(itertools.product(range(Q), repeat=n))
            kA = math.ceil((Fraction(1, 3) + tau) * n)
            kB = math.floor((Fraction(1, 3) - tau) * n)
            f = [[0] * len(pts),
                 [1 if w.count(0) >= kA else 0 for w in pts],
                 [1 + (1 if w.count(1) <= kB else 0) for w in pts]]
            N = len(pts)
            PA = Fraction(sum(f[1]), N)
            PB = Fraction(sum(1 for v in f[2] if v == 2), N)
            best = None
            for (i, kap, d) in type_tuples_B(n):
                dist = max(Fraction(sum(1 for x, w in zip(f[k], pts) if x != (kap * w[i] + d[k]) % Q), N) for k in range(3))
                best = dist if best is None else min(best, dist)
            for b in range(3):
                others = [k for k in range(3) if k != b]
                for u in itertools.product(range(Q), repeat=2):
                    U = sum(u) % Q
                    dist = max([Fraction(sum(1 for x in f[k] if x != uk), N) for k, uk in zip(others, u)]
                               + [Fraction(sum(1 for x in f[b] if x == (-U) % Q), N)])
                    best = min(best, dist)
            if PA <= Fraction(1, 2) and PB <= Fraction(1, 2):
                check(best == min(PA, PB), f"dist = min(PA,PB) n={n} alpha={alpha}")
            else:
                check(best >= min(PA, PB, 1 - PA, 1 - PB), f"dist lower bound n={n}")
            print(f"  alpha={alpha}, n={n}: PA={PA}, PB={PB}, dist={best}")


def r_mp(kappa):
    k = mpmath.mpf(kappa)
    t = mpmath.sqrt(1 - k)
    return 2 * (1 - t) / (2 - t)


def check_R():
    print("(R) constants and limits")
    mx = mpmath.mpf(0)
    for i in range(1, 18000):
        a = mpmath.mpf(i) / 18000 / 18
        r = r_mp(18 * a)
        t = mpmath.sqrt(1 - 18 * a)
        check(r / 2 >= 8 * a and r / 2 >= 9 * a * (1 - 9 * a), "r/2 >= max(8a, 9a(1-9a))")
        ratio = 18 * a / r
        check(abs(ratio - (1 + t * (1 - t) / 2)) < mpmath.mpf(10) ** -40, "ratio formula")
        check(ratio <= mpmath.mpf(9) / 8 + mpmath.mpf(10) ** -40, "ratio <= 9/8")
        mx = max(mx, ratio)
    a24 = mpmath.mpf(1) / 24
    check(abs(18 * a24 / r_mp(18 * a24) - mpmath.mpf(9) / 8) < mpmath.mpf(10) ** -40, "equality at 1/24")
    print("  max ratio 18a/r_{18a} on grid:", mpmath.nstr(mx, 12), " (9/8 at a=1/24)")
    for a in (mpmath.mpf(10) ** -12, mpmath.mpf(10) ** -6, mpmath.mpf(1) / 18 - mpmath.mpf(10) ** -12):
        print(f"  a={mpmath.nstr(a, 6)}: 18a/r = {mpmath.nstr(18 * a / r_mp(18 * a), 12)}")
    for i in range(1, 10001):
        a = mpmath.mpf(i) / 10000 / 18
        check(9 * a <= mpmath.log(3) / mpmath.log(1 / (2 * a)) * (1 + mpmath.mpf(10) ** -40), "9a <= log3/log(1/2a)")
    print("  9a <= log3/log(1/(2a)) on (0,1/18]; at 1/45:", mpmath.nstr(9 / mpmath.mpf(45), 5), "vs",
          mpmath.nstr(mpmath.log(3) / mpmath.log(mpmath.mpf(45) / 2), 5))
    for ap in (mpmath.mpf(1) / 1000, mpmath.mpf(1) / 45, mpmath.mpf(1) / 20):
        p = 4 * ap
        vals = []
        prev = None
        for e in range(1, 9):
            tau = min(p, mpmath.mpf(1) / 6) * mpmath.mpf(10) ** -e
            Lam = tau ** 2 / p * (2 - mpmath.cosh(tau / p))
            K = tau ** 2 / (2 * (mpmath.mpf(1) / 3 - tau) * (mpmath.mpf(2) / 3 + tau))
            bound = p / (2 * (mpmath.mpf(1) / 3 - tau) * (mpmath.mpf(2) / 3 + tau) * (2 - mpmath.cosh(tau / p)))
            check(bound > 9 * p / 4, "tau-bound > 9p/4")
            if prev is not None:
                check(bound < prev, "tau-bound decreasing as tau -> 0")
            prev = bound
            vals.append((Lam / (2 * K), bound))
        check(abs(vals[-1][0] * 18 * ap - 1) < mpmath.mpf(10) ** -6, "Lambda/(2K) -> 1/(18a')")
        check(abs(vals[-1][1] / (9 * ap) - 1) < mpmath.mpf(10) ** -6, "tau-bound -> 9a'")
        print(f"  a'={mpmath.nstr(ap, 5)}: Lambda/(2K)*18a' -> {mpmath.nstr(vals[-1][0] * 18 * ap, 10)}, bound/(9a') -> {mpmath.nstr(vals[-1][1] / (9 * ap), 10)}")


if __name__ == "__main__":
    check_P()
    check_G()
    check_C()
    check_T()
    check_E()
    check_D()
    check_R()
    print()
    print("ALL CHECKS PASSED" if not FAIL else f"{len(FAIL)} FAILURES")
