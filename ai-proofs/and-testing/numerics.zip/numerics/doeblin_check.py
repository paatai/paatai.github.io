r"""Doeblin coefficients for the near-constant lemma (paper Lemma 8.23, Theorem 8.18(d)).

For g: {0,1}^m -> {0,1}, b in {0,1} and a minimal flip set S at b
(|S| = s_b(g), g(b^m xor 1_S) != g(b^m)), consider the channel
    K_S(y | x) = Pr_{u uniform on {0,1}^{[m]\S}} [ g(x, u) = y ],   x in {0,1}^S,
and its Doeblin coefficient lambda_S = sum_y min_x K_S(y | x).  By Lemma 8.22(c),
theta(pi, K_S) <= 1 - lambda_S, which makes the constants of Lemma 8.23 explicit.

For every g depending on all m coordinates with E[g] != 1/2, and every b with
2 <= s_b(g) < m, the script computes Lambda_b(g) = max_S lambda_S (exact rationals)
and whether g is completable at b (Definition 8.17).  Theorem 8.18(d) claims that for
m <= 4 every such (g, b) is completable at b or has Lambda_b(g) > 0 ("covered").
(s_b = 1 is completable by definition, and s_b = m only for AND, OR, NAND, NOR.)
"""
import itertools
import sys
from fractions import Fraction

from exponent_classification import and_family, completion, depends_on_all, s_b


def lam(tab, m, S):
    rest = [k for k in range(m) if k not in S]
    mins = [Fraction(1), Fraction(1)]
    for xs in range(1 << len(S)):
        x = sum(((xs >> t) & 1) << S[t] for t in range(len(S)))
        ones = 0
        for ns in range(1 << len(rest)):
            z = x | sum(((ns >> t) & 1) << rest[t] for t in range(len(rest)))
            ones += tab[z]
        p1 = Fraction(ones, 1 << len(rest))
        mins[1] = min(mins[1], p1)
        mins[0] = min(mins[0], 1 - p1)
    return mins[0] + mins[1]


def Lambda(tab, m, b, s):
    N = 1 << m
    base = N - 1 if b else 0
    best = Fraction(0)
    for S in itertools.combinations(range(m), s):
        if tab[base ^ sum(1 << k for k in S)] != tab[base]:
            best = max(best, lam(tab, m, list(S)))
    return best


def main(M):
    all_ok = True
    for m in range(2, M + 1):
        N = 1 << m
        pairs = compl = doeb = 0
        noncompl = []
        uncovered = []
        and_type_at_m = 0
        for code in range(1 << N):
            tab = [(code >> x) & 1 for x in range(N)]
            if 2 * sum(tab) == N or not depends_on_all(tab, m):
                continue
            for b in (0, 1):
                s = s_b(tab, m, b)
                if s == m:
                    assert and_family(tab, m), "s_b = m forces AND/OR/NAND/NOR"
                    and_type_at_m += 1
                    continue
                if s < 2:
                    continue
                pairs += 1
                c = completion(tab, m, b, s)
                L = Lambda(tab, m, b, s)
                compl += bool(c)
                doeb += L > 0
                if not c:
                    noncompl.append(("".join(map(str, tab)), b, s, L))
                    if L == 0:
                        uncovered.append(("".join(map(str, tab)), b, s))
        print(f"m={m}: (g,b) with 2 <= s_b < m: {pairs}; completable at b: {compl}; "
              f"Lambda_b > 0: {doeb}; not completable: {len(noncompl)}; "
              f"uncovered (not completable and Lambda_b = 0): {len(uncovered)}; "
              f"(g,b) with s_b = m (all AND-type): {and_type_at_m}")
        if noncompl:
            print(f"   min Lambda_b over non-completable (g,b): {min(t[3] for t in noncompl)}")
            for t in noncompl[:8]:
                print(f"   non-completable: g={t[0]} b={t[1]} s={t[2]} Lambda={t[3]}")
        for u in uncovered:
            print("   UNCOVERED:", u)
        all_ok &= not uncovered
        sys.stdout.flush()
    print("ALL COVERED" if all_ok else "SOME (g,b) UNCOVERED")


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
