r"""Exact check of the containment inequality for approximate multi-polymorphisms of a general g.

Setting (uniform inputs): g: {0,1}^m -> {0,1}; Z is a uniform n x m 0/1 matrix with columns
x^(1..m) and rows z_i; w = (g(z_1),...,g(z_n)).  For Boolean f_0,...,f_m on {0,1}^n,
    err = Pr[f_0(w) != g(f_1(x^(1)),...,f_m(x^(m)))].
For a coordinate j with insensitive contexts A_j and sensitive contexts B_j of g, let
c_j = (f_k(x^(k)))_{k != j} and R_j = {i : z_i restricted to [m]\{j} lies in A_j}.  The claim is
    sum_S fhat_j(S)^2 Pr[c_j in B_j, S meets R_j] <= err.          (containment)
The script also checks the junta consequences (a) and (b) of the paper's junta lemma:
    (a) sum_{S not in C_j} fhat_j(S)^2 <= 4 err / (a_j P_j),
    (b) |C_j| <= (8/a_j) ln(2/P_j),
where P_j = Pr[c_j in B_j], a_j = |A_j| / 2^(m-1) and C_j = {i : Pr[i in R_j | c_j in B_j] <= a_j/4}.
All quantities are exact rationals.  Usage: python3 verify_general_containment.py [trials]
"""
import itertools
import math
import random
import sys
from fractions import Fraction

GS = {
    "AND2": (2, lambda z: z[0] & z[1]),
    "OR2": (2, lambda z: z[0] | z[1]),
    "MAJ3": (3, lambda z: int(z[0] + z[1] + z[2] >= 2)),
    "x1&(x2|x3)": (3, lambda z: z[0] & (z[1] | z[2])),
    "x1^(x2&x3)": (3, lambda z: z[0] ^ (z[1] & z[2])),
    "NAE3": (3, lambda z: int(not (z[0] == z[1] == z[2]))),
    "AND3": (3, lambda z: z[0] & z[1] & z[2]),
}


def fourier_sq(f, n):
    """Squared uniform-measure Fourier coefficients of the 0/1 function f (tuple of length 2^n)."""
    out = {}
    N = 1 << n
    for S in range(N):
        s = 0
        for x in range(N):
            s += f[x] * (-1) ** bin(x & S).count("1")
        out[S] = Fraction(s, N) ** 2
    return out


def structured(gname, n, rng, flip):
    """A perturbed exact multi-polymorphism: dictators, a certificate tuple, or (for AND/OR) a common AND/OR."""
    m, g = GS[gname]
    N = 1 << n
    kind = rng.choice(["dict", "cert", "andor"])
    if kind == "dict":
        i0 = rng.randrange(n)
        base = [tuple((x >> i0) & 1 for x in range(N)) for _ in range(m + 1)]
    elif kind == "cert":
        cert = None
        for J in range(1, 1 << m):
            for vals in itertools.product((0, 1), repeat=m):
                outs = {g([vals[k] if (J >> k) & 1 else z[k] for k in range(m)])
                        for z in itertools.product((0, 1), repeat=m)}
                if len(outs) == 1:
                    cert = (J, vals, outs.pop())
                    break
            if cert:
                break
        J, vals, a0 = cert
        base = [tuple(a0 for _ in range(N))]
        for k in range(m):
            if (J >> k) & 1:
                base.append(tuple(vals[k] for _ in range(N)))
            else:
                base.append(tuple(rng.randrange(2) for _ in range(N)))
    else:
        S = [i for i in range(n) if rng.random() < 0.5] or [0]
        if gname.startswith("AND"):
            h = tuple(int(all((x >> i) & 1 for i in S)) for x in range(N))
        elif gname == "OR2":
            h = tuple(int(any((x >> i) & 1 for i in S)) for x in range(N))
        else:
            i0 = S[0]
            h = tuple((x >> i0) & 1 for x in range(N))
        base = [h for _ in range(m + 1)]
    return [tuple(v ^ int(rng.random() < flip) for v in f) for f in base]


def check(gname, n, rng, density, fs=None):
    m, g = GS[gname]
    N = 1 << n
    if fs is None:
        fs = [tuple(int(rng.random() < density[k]) for _ in range(N)) for k in range(m + 1)]
    contexts = list(itertools.product((0, 1), repeat=m - 1))
    total = 0
    fails = 0
    ratio = Fraction(0)
    acc = {}
    for j in range(m):
        A = set()
        for a in contexts:
            z0 = list(a[:j]) + [0] + list(a[j:])
            z1 = list(a[:j]) + [1] + list(a[j:])
            if g(z0) == g(z1):
                A.add(a)
        acc[j] = {"A": A, "num": {}, "P": Fraction(0), "pin": [Fraction(0)] * n}
    err = Fraction(0)
    weight = Fraction(1, 1 << (n * m))
    for cols in itertools.product(range(N), repeat=m):
        rows = [tuple((cols[k] >> i) & 1 for k in range(m)) for i in range(n)]
        w = sum(g(list(r)) << i for i, r in enumerate(rows))
        vals = [fs[k + 1][cols[k]] for k in range(m)]
        if fs[0][w] != g(vals):
            err += weight
        for j in range(m):
            cj = tuple(vals[:j] + vals[j + 1:])
            zj0 = list(cj[:j]) + [0] + list(cj[j:])
            zj1 = list(cj[:j]) + [1] + list(cj[j:])
            if g(zj0) == g(zj1):
                continue
            R = 0
            for i, r in enumerate(rows):
                if tuple(r[:j] + r[j + 1:]) in acc[j]["A"]:
                    R |= 1 << i
            acc[j]["P"] += weight
            acc[j]["num"][R] = acc[j]["num"].get(R, Fraction(0)) + weight
            for i in range(n):
                if (R >> i) & 1:
                    acc[j]["pin"][i] += weight
    for j in range(m):
        fsq = fourier_sq(fs[j + 1], n)
        lhs = Fraction(0)
        for S, c2 in fsq.items():
            if c2 == 0:
                continue
            pr = sum(pw for R, pw in acc[j]["num"].items() if R & S)
            lhs += c2 * pr
        total += 1
        if err > 0:
            ratio = max(ratio, lhs / err)
        ok = lhs <= err
        P = acc[j]["P"]
        aj = Fraction(len(acc[j]["A"]), 1 << (m - 1))
        if P > 0 and aj > 0:
            C = [i for i in range(n) if acc[j]["pin"][i] <= aj / 4 * P]
            Cmask = sum(1 << i for i in C)
            tail = sum(c2 for S, c2 in fsq.items() if S & ~Cmask)
            ok_a = tail <= 4 * err / (aj * P)
            ok_b = len(C) <= 8 / float(aj) * math.log(2 / float(P)) + 1e-12
            ok = ok and ok_a and ok_b
        if not ok:
            fails += 1
            print("FAIL", gname, n, j, float(lhs), float(err))
    return total, fails, ratio


def main():
    trials = int(sys.argv[1]) if len(sys.argv) > 1 else 40
    rng = random.Random(20261021)
    grand = 0
    bad = 0
    for gname in GS:
        m = GS[gname][0]
        for n in ((1, 2, 3) if m == 3 else (1, 2, 3, 4)):
            for t in range(trials):
                dens = [rng.choice([0.1, 0.3, 0.5, 0.7, 0.9]) for _ in range(m + 1)]
                tot, fl, _ = check(gname, n, rng, dens)
                grand += tot
                bad += fl
        print(f"{gname}: random done, cumulative checks {grand}, failures {bad}", flush=True)
    for gname in GS:
        m = GS[gname][0]
        worst = Fraction(0)
        for n in ((2, 3, 4) if m == 3 else (2, 3, 4, 5, 6)):
            for t in range(trials):
                flip = rng.choice([0.0, 0.01, 0.03, 0.08])
                fs = structured(gname, n, rng, flip)
                tot, fl, r = check(gname, n, rng, None, fs=fs)
                worst = max(worst, r)
                grand += tot
                bad += fl
        print(f"{gname}: structured done, cumulative checks {grand}, failures {bad}, "
              f"max containment ratio LHS/err = {float(worst):.4f}", flush=True)
    print("ALL OK" if bad == 0 else f"FAILURES: {bad}")


if __name__ == "__main__":
    main()
