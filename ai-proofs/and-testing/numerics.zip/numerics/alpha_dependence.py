"""Exact check of Remark rem:alphanec (MAIN_RESULT.pdf, Section 8.8).

mu on {0,1}^2 with mu(1,1)=a, mu(1,0)=mu(0,1)=p-a, mu(0,0)=1-2p+a: equal marginals p,
correlation rho=(a-p^2)/(p(1-p)).  f=1{|x|>=k}, k=ceil(p n+t sqrt(n)), f_0=f_1=f_2=f, g=AND_2.

For each (mu, t, n) the script computes exactly
  eps_n = Pr[f(x and y) != f(x) f(y)]                (multinomial sum, log space),
  d_n   = min(P_n, (1-p) Pr[Bin(n-1,p)>=k], 1-P_n),  P_n = Pr[Bin(n,p)>=k],
which is a lower bound for the distance (under mu_p) from f to every exact solution,
and checks eps_n <= B_n = exp(-2n(p-a)^2) + exp(-t^2/(s2(1+rho)+2t/(3 sqrt n))), s2=p(1-p)
(Hoeffding + Bernstein, as in the proof).  It also prints -log(eps_n)/t^2 and -log(d_n)/t^2
next to their limits 1/(s2(1+rho)) and 1/(2 s2); their ratio tends to (1+rho)/2.
"""
import math

import numpy as np
from scipy.special import gammaln, logsumexp
from scipy.stats import binom


def log_eps_exact(n, k, p, a):
    m00, m10, m11 = 1 - 2 * p + a, p - a, a
    terms = []
    for n11 in range(0, min(k, n + 1)):
        n00 = np.arange(0, n - n11 + 1)
        r = n - n11 - n00
        logw = (gammaln(n + 1) - gammaln(n11 + 1) - gammaln(n00 + 1) - gammaln(r + 1)
                + n11 * math.log(m11) + n00 * math.log(m00) + r * math.log(2 * m10))
        lo = k - n11
        hi = r - lo
        ok = hi >= lo
        if not ok.any():
            continue
        # N10 ~ Bin(r, 1/2); need lo <= N10 <= hi
        prob = binom.cdf(hi[ok], r[ok], 0.5) - binom.cdf(lo - 1, r[ok], 0.5)
        good = prob > 0
        if good.any():
            terms.append(logw[ok][good] + np.log(prob[good]))
    if not terms:
        return -np.inf
    return float(logsumexp(np.concatenate(terms)))


def main():
    cases = [(0.5, 0.05), (0.5, 0.10), (0.5, 0.25), (0.3, 0.05)]
    all_ok = True
    for p, a in cases:
        s2 = p * (1 - p)
        rho = (a - p * p) / s2
        print(f"mu(11)={a}, p={p}: rho={rho:.4f}, (1+rho)/2={(1 + rho) / 2:.4f}, "
              f"limits 1/(s2(1+rho))={1 / (s2 * (1 + rho)):.3f}, 1/(2 s2)={1 / (2 * s2):.3f}")
        for t in (0.5, 1.0, 1.5, 2.0):
            for n in (400, 1600, 3600):
                k = math.ceil(p * n + t * math.sqrt(n))
                le = log_eps_exact(n, k, p, a)
                Pn = binom.sf(k - 1, n, p)
                d = min(Pn, (1 - p) * binom.sf(k - 1, n - 1, p), 1 - Pn)
                B = math.exp(-2 * n * (p - a) ** 2) + math.exp(-t * t / (s2 * (1 + rho) + 2 * t / (3 * math.sqrt(n))))
                ok = le <= math.log(B)
                all_ok &= ok
                print(f"  t={t:3.1f} n={n:5d}: eps={math.exp(le):.3e} <= B={B:.3e} {'ok' if ok else 'FAIL'};"
                      f" d={d:.3e}; -log(eps)/t^2={-le / t / t:.3f}, -log(d)/t^2={-math.log(d) / t / t:.3f}")
    print("ALL CHECKS PASSED" if all_ok else "SOME CHECK FAILED")


if __name__ == "__main__":
    main()
