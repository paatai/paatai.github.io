#!/usr/bin/env python3
"""Exhaustive check of the refined final-step lemma (Lemma 4.3 of MAIN_RESULT.pdf) and of Theorem 1.1 (constant c0 = 4 + 2 sqrt 2).

Refined final step: for Boolean G on the uniform cube, C a set of coordinates, theta in (0,1),
kappa_a, kappa_b in [0,1) with
  (a) sum_{S not in C} hatG(S)^2 <= kappa_a mu,   (b) Pr[G=1, x_C != 1] <= kappa_b mu,
  (c) Pr[G=1, x_i=0] <= theta mu for all i in C,
we have Pr[G != AND_C] <= mu * max{ ka/(1-ka), 2kb-1+((1-kb)^2+theta*kb)/(1-ka), 2kb-1+theta }.
We test it for EVERY G on n <= 4 variables and EVERY C, with the tightest admissible parameters
  ka = (a)-ratio, kb = (b)-ratio, theta = max_{i in C} Pr[G=1,x_i=0]/mu  (theta = 0 if C is empty),
whenever ka < 1, kb < 1, theta < 1. The bound is monotone in each parameter, so this covers all admissible choices.

Theorem 1.1: dist(G) <= min(mu, c0 eps/mu) with c0 = 4 + 2 sqrt 2, and with theta0 = 1 - 1/sqrt 2,
C = {i : Pr[G=1,x_i=0] <= theta0 mu} and eta = eps/mu^2 <= eta0 = (2 - sqrt 2)/4, Pr[G != AND_C] <= c0 eps / mu.
Both are checked exactly: comparisons with sqrt 2 are done by squaring rationals.
"""
import itertools
import sys
from fractions import Fraction

import numpy as np


def run(n):
    N = 1 << n
    pts = np.arange(N)
    bits = (pts[:, None] >> np.arange(n)[None, :]) & 1  # bits[x, i] = x_i
    F = ((np.arange(1 << N)[:, None] >> pts[None, :]) & 1).astype(np.int64)  # all functions, F[g, x]
    # Walsh-Hadamard with chi_S(x) = (-1)^{|S \ x|}... use phi_S = prod (2x_i - 1); hatf(S) = 2^-n sum f(x) phi_S(x)
    phi = np.ones((N, N), dtype=np.int64)  # phi[S, x]
    for S in range(N):
        for i in range(n):
            if (S >> i) & 1:
                phi[S] *= 2 * bits[:, i] - 1
    W = F @ phi.T  # 2^n hatf(S)
    W2 = W * W  # 4^n hatf(S)^2
    M = F.sum(axis=1)  # 2^n mu
    meet = pts[:, None] & pts[None, :]
    # eps * 4^n = #{(x,y): f(x&y) != f(x) f(y)}
    E = np.zeros(1 << N, dtype=np.int64)
    for x in range(N):
        for y in range(N):
            E += (F[:, meet[x, y]] != F[:, x] * F[:, y])
    # b_i * 2^n = #{x: f(x)=1, x_i=0}
    B = np.stack([(F * (1 - bits[:, i])[None, :]).sum(axis=1) for i in range(n)], axis=1)
    worst_lemma = Fraction(-1)
    n_checked = 0
    D = M.copy()  # 2^n dist, start with g = 0
    for C in range(N):
        Cset = [i for i in range(n) if (C >> i) & 1]
        andC = ((pts & C) == C).astype(np.int64)
        P = (F != andC[None, :]).sum(axis=1)  # 2^n Pr[G != AND_C]
        D = np.minimum(D, P)
        tail = W2[:, [S for S in range(N) if S & ~C]].sum(axis=1)  # 4^n sum_{S not in C} hatf^2
        bC = (F * (1 - andC)[None, :]).sum(axis=1)  # 2^n Pr[G=1, x_C != 1]
        thC = B[:, Cset].max(axis=1) if Cset else np.zeros(1 << N, dtype=np.int64)
        for g in range(1, 1 << N):
            mu = Fraction(int(M[g]), N)
            ka = Fraction(int(tail[g]), N * N) / mu
            kb = Fraction(int(bC[g]), N) / mu
            th = Fraction(int(thC[g]), N) / mu
            if ka >= 1 or kb >= 1 or th >= 1:
                continue
            bound = max(ka / (1 - ka), 2 * kb - 1 + ((1 - kb) ** 2 + th * kb) / (1 - ka), 2 * kb - 1 + th)
            lhs = Fraction(int(P[g]), N) / mu
            n_checked += 1
            if lhs > bound:
                print(f"  LEMMA VIOLATED: n={n} g={g} C={Cset} lhs={lhs} bound={bound}")
                return False
            slack = lhs - bound
            if slack > worst_lemma:
                worst_lemma = slack
    # Theorem 1.1
    def le_c0(r):  # r <= 4 + 2 sqrt 2 for rational r
        return r <= 4 or (r - 4) ** 2 <= 8

    def in_core(b, mu):  # b <= (1 - 1/sqrt 2) mu  <=>  (1 - b/mu)^2 >= 1/2  (as 0 <= b <= mu)
        return (1 - b / mu) ** 2 >= Fraction(1, 2)

    def le_eta0(eta):  # eta <= (2 - sqrt 2)/4  <=>  2 - 4 eta >= sqrt 2
        return 2 - 4 * eta >= 0 and (2 - 4 * eta) ** 2 >= 2

    worst_thm = Fraction(0)
    worst_core = Fraction(0)
    for g in range(1, 1 << N):
        mu = Fraction(int(M[g]), N)
        eps = Fraction(int(E[g]), N * N)
        dist = Fraction(int(D[g]), N)
        if eps == 0:
            assert dist == 0, (n, g)
            continue
        if dist > mu or not le_c0(dist * mu / eps):
            print(f"  THEOREM VIOLATED: n={n} g={g}")
            return False
        worst_thm = max(worst_thm, dist * dist / eps)
        eta = eps / (mu * mu)
        if le_eta0(eta):
            C = sum(1 << i for i in range(n) if in_core(Fraction(int(B[g, i]), N), mu))
            andC = ((pts & C) == C).astype(np.int64)
            P = Fraction(int((F[g] != andC).sum()), N)
            if not le_c0(P * mu / eps):
                print(f"  CORE BOUND VIOLATED: n={n} g={g}")
                return False
            worst_core = max(worst_core, P * mu / eps)
    print(f"n={n}: refined lemma checked on {n_checked} (G, C) pairs, max(lhs - bound) = {float(worst_lemma):.6f} (<= 0);"
          f" max dist^2/eps = {worst_thm} = {float(worst_thm):.6f};"
          f" max Pr[f != AND_C]/(eps/mu) over eta <= (2-sqrt2)/4 = {float(worst_core):.6f} (<= 4+2sqrt2 = 6.828)")
    return True


if __name__ == "__main__":
    ok = all(run(n) for n in range(1, int(sys.argv[1]) + 1 if len(sys.argv) > 1 else 5))
    print("ALL OK" if ok else "FAILURE")
