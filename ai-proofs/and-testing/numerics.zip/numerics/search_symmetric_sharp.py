#!/usr/bin/env python3
"""Local search for symmetric f = 1{|x| in W} maximising dist(f)^2 / eps(f) (uniform measure).

Floating point is used only for the search; every reported maximiser is re-checked exactly with
integer arithmetic (closed forms in counterexample_sharp.py style). Usage:
    python3 search_symmetric_sharp.py n_min n_max [restarts] [seed]
"""
import sys
from math import comb, factorial

import numpy as np


def tables(n):
    lf = np.array([np.log(float(factorial(k))) if k < 171 else sum(np.log(np.arange(1, k + 1, dtype=float)))
                   for k in range(n + 1)])
    q = np.zeros((n + 1, n + 1, n + 1))
    base = lf[n] - n * np.log(4.0)
    for a in range(n + 1):
        for i in range(a, n + 1):
            for j in range(a, n + 1 - i + a):
                q[a, i, j] = np.exp(base - lf[a] - lf[i - a] - lf[j - a] - lf[n - i - j + a])
    pw = np.array([comb(n, w) / 2.0 ** n for w in range(n + 1)])
    m1 = q.sum(axis=(1, 2))
    # andw[s, w] = Pr[x_S = 1, |x| = w] for |S| = s
    andw = np.zeros((n + 1, n + 1))
    for s in range(n + 1):
        for w in range(s, n + 1):
            andw[s, w] = comb(n - s, w - s) / 2.0 ** n
    return q, pw, m1, andw


def ratio(F, q, pw, m1, andw):
    mu = F @ pw
    if mu == 0:
        return 0.0
    t = np.einsum('aij,i,j->a', q, F, F)
    eps = F @ m1 + mu * mu - 2 * (F @ t)
    d = min(mu, mu + (andw @ (1 - 2 * F)).min())
    if eps <= 0:
        return 0.0 if d <= 1e-300 else np.inf
    return d * d / eps


def exact(n, F):
    Fi = [int(v) for v in F]
    A = sum(comb(n, w) * Fi[w] for w in range(n + 1))
    E = 0
    fact = [factorial(k) for k in range(n + 1)]
    for a in range(n + 1):
        for b in range(n + 1 - a):
            for c in range(n + 1 - a - b):
                d = n - a - b - c
                if Fi[a] != (Fi[a + b] & Fi[a + c]):
                    E += fact[n] // (fact[a] * fact[b] * fact[c] * fact[d])
    best = A
    for s in range(n + 1):
        val = A + sum(comb(n - s, w - s) * (1 - 2 * Fi[w]) for w in range(s, n + 1))
        best = min(best, val)
    return best, E


def search(n, restarts, rng):
    q, pw, m1, andw = tables(n)
    best_r, best_F = -1.0, None
    for rep in range(restarts):
        F = np.zeros(n + 1)
        if rep % 3 == 0:
            K = rng.integers(3, max(4, n // 2))
            lo = rng.integers(max(0, K - 12), K)
            for z in range(lo, K - rng.integers(2, 6)):
                F[n - z] = 1
            F[n - K] = 1
        elif rep % 3 == 1:
            F[rng.random(n + 1) < 0.15] = 1
        else:
            k = rng.integers(1, n)
            F[n - k:] = 1
            F[n - rng.integers(0, k)] = 0
        r = ratio(F, q, pw, m1, andw)
        T = 0.02
        for it in range(4000):
            w = rng.integers(0, n + 1)
            F[w] = 1 - F[w]
            r2 = ratio(F, q, pw, m1, andw)
            if r2 >= r or rng.random() < np.exp((r2 - r) / T):
                r = r2
            else:
                F[w] = 1 - F[w]
            T *= 0.998
            if r > best_r:
                best_r, best_F = r, F.copy()
        # greedy polish
        improved = True
        while improved:
            improved = False
            for w in range(n + 1):
                F[w] = 1 - F[w]
                r2 = ratio(F, q, pw, m1, andw)
                if r2 > r + 1e-15:
                    r, improved = r2, True
                else:
                    F[w] = 1 - F[w]
            if r > best_r:
                best_r, best_F = r, F.copy()
    return best_r, best_F


if __name__ == "__main__":
    n_min, n_max = int(sys.argv[1]), int(sys.argv[2])
    restarts = int(sys.argv[3]) if len(sys.argv) > 3 else 12
    seed = int(sys.argv[4]) if len(sys.argv) > 4 else 1
    rng = np.random.default_rng(seed)
    for n in range(n_min, n_max + 1):
        r, F = search(n, restarts, rng)
        zeros = [n - w for w in range(n + 1) if F[w] == 1]
        D, E = exact(n, F)
        print(f"n={n}: float ratio {r:.9f}; exact D^2/E = {D * D / E:.12f}; zero-count set Z = {sorted(zeros)}",
              flush=True)
