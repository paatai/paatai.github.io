"""P_neq = {(a,b,c) in Z_3^3 : a+b+c != 0} under the shift distribution mu^sh_alpha (Proposition 8.62(b)).

mu^sh_alpha gives mass (1 - 12 alpha)/6 to the six elements (a,b,b+1) of P_neq and alpha to the other twelve.
For n = 3k, tau = 2 e^2 alpha and T = ceil(tau n) the triple is f = (0, 1_A, 1 + 1_B) with
A = {N_0 >= k+T} and B = {N_1 <= k-T}, where N_v(w) = #{i : w_i = v}.

Checks:
 (M)  exact (rationals), alpha in {1/18, 1/45, 1/100, 1/1000}: support P_neq, total mass 1, min = alpha, uniform
      marginals, invariance under (a,b,c) -> (a+t,b+t,c+t); the elements with c = b+1 are the (a,b,b+1) with
      a in {b,b+1}; Pr[y = 0, z != 1] = 4 alpha (rows (1,0,0), (2,0,0), (0,0,2), (2,0,2)); Pr[z != y+1] = 12 alpha.
 (F)  the failure event: N_0(y) - N_1(z) <= D = #{i : y_i = 0, z_i != 1} for every row tuple with n <= 4 (brute
      force), so a failure (y in A, z in B) forces D >= 2T; and the joint law of (N_0(y), N_1(z), D) from the
      multinomial formula over the four row classes (1[y_i = 0], 1[z_i = 1]) equals the brute-force law (n <= 4).
 (E)  the error bound, exactly (integers) for n = 3k <= 36, alpha in {1/45, 1/100, 1/400} and every T in [1, k]:
      err <= Pr[Bin(n, 4 alpha) >= 2T] <= C(n, 2T) (4 alpha)^(2T) <= (4 e alpha n / (2T))^(2T); and for
      T = ceil(tau n) also (4 e alpha n / (2T))^(2T) <= (2 e alpha / tau)^(2T) = e^(-2T) <= e^(-2 tau n).
 (D)  the distance: for n = 3, 6, 9 and every T in [1, k], the minimum of dist(f, g) over all generalized
      polymorphisms g (type (A): two constants u, v and a third function avoiding -u-v, in closed form; type (B):
      kappa w_i + d_j with d_1 + d_2 + d_3 = 0) under the uniform measure is >= min(Pr A, Pr B) whenever
      Pr A, Pr B <= 1/2.
 (B)  the binomial bounds (exact integer sums, compared in mpmath), alpha in {1/45, 1/100, 1/1000} and n = 3k
      from max(tau^-2, (1/3 - tau)^-1) on: Pr A, Pr B <= 2/9; D(q || 1/3) <= (9/2)(q - 1/3)^2; and
      Pr[N_0 = k+T], Pr[N_1 = k-T] >= e^(-n D(j/n || 1/3))/(n+1) >= e^(-(9/2) n (tau + 1/n)^2)/(n+1).
 (X)  the constants: (9/2) e^2 < 33.26 < 34, 4 e^2 < 30, (9/4) e^2 < 17, (9/8) e^2 < 8.4, 2 e^2 / 45 < 1/3; and the exponent
      ((9/2) n (tau + 1/n)^2 + ln(n+1)) / (2 tau n) of the final step tends to (9/4) tau = (9/2) e^2 alpha.
"""
import itertools
import math
from fractions import Fraction

import mpmath
import numpy as np

mpmath.mp.dps = 50
Q = 3
P = [r for r in itertools.product(range(Q), repeat=3) if sum(r) % Q != 0]
assert len(P) == 18
E = mpmath.e


def mu_sh(alpha):
    big = (1 - 12 * alpha) / 6
    return {r: (big if r[2] == (r[1] + 1) % Q else alpha) for r in P}


def cls(r):
    return (int(r[1] == 0), int(r[2] == 1))


def check_M():
    for alpha in [Fraction(1, 18), Fraction(1, 45), Fraction(1, 100), Fraction(1, 1000)]:
        mu = mu_sh(alpha)
        assert sum(mu.values()) == 1
        assert min(mu.values()) == alpha and all(v > 0 for v in mu.values())
        for j in range(3):
            for v in range(Q):
                assert sum(p for r, p in mu.items() if r[j] == v) == Fraction(1, 3)
        for t in range(Q):
            for r in P:
                assert mu[tuple((x + t) % Q for x in r)] == mu[r]
        six = sorted(r for r in P if r[2] == (r[1] + 1) % Q)
        assert six == sorted((a, b, (b + 1) % Q) for b in range(Q) for a in (b, (b + 1) % Q))
        drows = sorted(r for r in P if r[1] == 0 and r[2] != 1)
        assert drows == sorted([(1, 0, 0), (2, 0, 0), (0, 0, 2), (2, 0, 2)])
        assert sum(mu[r] for r in drows) == 4 * alpha
        assert sum(p for r, p in mu.items() if r[2] != (r[1] + 1) % Q) == 12 * alpha
    print("(M) mu^sh_alpha: full support, min alpha, uniform marginals, translation invariant;"
          " Pr[y=0, z!=1] = 4 alpha, Pr[z != y+1] = 12 alpha: ok")


def joint_law_formula(p, n):
    """Law of (N_0, N_1, D) for n i.i.d. rows with class probabilities p[(s, t)], s = 1[y=0], t = 1[z=1]."""
    law = {}
    f = math.factorial
    for n11 in range(n + 1):
        for n10 in range(n + 1 - n11):
            for n01 in range(n + 1 - n11 - n10):
                n00 = n - n11 - n10 - n01
                coef = f(n) // (f(n11) * f(n10) * f(n01) * f(n00))
                pr = coef * p[(1, 1)] ** n11 * p[(1, 0)] ** n10 * p[(0, 1)] ** n01 * p[(0, 0)] ** n00
                key = (n11 + n10, n11 + n01, n10)
                law[key] = law.get(key, 0) + pr
    return law


def check_F():
    alpha = Fraction(1, 45)
    mu = mu_sh(alpha)
    p = {(s, t): sum(m for r, m in mu.items() if cls(r) == (s, t)) for s in (0, 1) for t in (0, 1)}
    for n in range(1, 5):
        law = {}
        for tup in itertools.product(P, repeat=n):
            n0 = sum(r[1] == 0 for r in tup)
            n1 = sum(r[2] == 1 for r in tup)
            d = sum(r[1] == 0 and r[2] != 1 for r in tup)
            assert n0 - n1 <= d
            pr = Fraction(1)
            for r in tup:
                pr *= mu[r]
            law[(n0, n1, d)] = law.get((n0, n1, d), 0) + pr
        lf = {k: v for k, v in joint_law_formula(p, n).items() if v != 0}
        assert law == lf, n
    print("(F) N_0(y) - N_1(z) <= D for all row tuples (n <= 4), so a failure forces D >= 2T;"
          " multinomial law of (N_0, N_1, D) = brute force (n <= 4): ok")


def check_E():
    worst = 0.0
    count = 0
    for M in (45, 100, 400):
        alpha = Fraction(1, M)
        tau = 2 * E ** 2 / M
        # class weights times 3M: p11 = (M-12)/(3M), p10 = p01 = 12/(3M), p00 = (2M-12)/(3M)
        w = {(1, 1): M - 12, (1, 0): 12, (0, 1): 12, (0, 0): 2 * M - 12}
        mu = mu_sh(alpha)
        for (s, t), wt in w.items():
            assert Fraction(wt, 3 * M) == sum(m for r, m in mu.items() if cls(r) == (s, t))
        for n in range(3, 37, 3):
            k = n // 3
            law = joint_law_formula(w, n)
            Tstar = int(mpmath.ceil(tau * n))
            for T in sorted(set(range(1, k + 1)) | {Tstar}):
                err_int = sum(v for (n0, n1, d), v in law.items() if n0 >= k + T and n1 <= k - T)
                # err = err_int / (3M)^n ; Pr[Bin(n, 4/M) >= 2T] = bin_int / M^n
                bin_int = sum(math.comb(n, d) * 4 ** d * (M - 4) ** (n - d) for d in range(2 * T, n + 1))
                assert err_int <= bin_int * 3 ** n
                union = Fraction(math.comb(n, 2 * T) * 4 ** (2 * T), M ** (2 * T)) if 2 * T <= n else Fraction(0)
                assert Fraction(bin_int, M ** n) <= union
                if 2 * T <= n:
                    chern = (4 * E * n / (M * 2 * T)) ** (2 * T)
                    assert mpmath.mpf(union.numerator) / union.denominator <= chern
                    if T == Tstar:
                        assert chern <= (2 * E / (M * tau)) ** (2 * T) * (1 + mpmath.mpf(10) ** -40)
                        assert abs((2 * E / (M * tau)) ** (2 * T) - mpmath.exp(-2 * T)) < mpmath.mpf(10) ** -40
                        assert mpmath.exp(-2 * T) <= mpmath.exp(-2 * tau * n)
                if bin_int:
                    worst = max(worst, float(mpmath.mpf(err_int) / (mpmath.mpf(bin_int) * 3 ** n)))
                count += 1
    print(f"(E) err <= Pr[Bin(n,4 alpha) >= 2T] <= C(n,2T)(4 alpha)^2T <= (4e alpha n/2T)^2T, and <= e^-2T <= "
          f"e^(-2 tau n) at T = ceil(tau n): {count} cases (n <= 36), max err/Pr[D >= 2T] = {worst:.4f}: ok")


def check_D():
    out = []
    for n in (3, 6, 9):
        k = n // 3
        pts = np.array(list(itertools.product(range(Q), repeat=n)), dtype=np.int64)
        size = len(pts)
        N0 = (pts == 0).sum(axis=1)
        N1 = (pts == 1).sum(axis=1)
        for T in range(1, k + 1):
            f = [np.zeros(size, dtype=np.int64), (N0 >= k + T).astype(np.int64),
                 (1 + (N1 <= k - T).astype(np.int64)) % Q]
            PA = Fraction(int(f[1].sum()), size)
            PB = Fraction(int((f[2] == 2).sum()), size)
            cnt = [[int((fj == v).sum()) for v in range(Q)] for fj in f]
            best = Fraction(1)
            for m in range(3):
                j, l = [t for t in range(3) if t != m]
                for u in range(Q):
                    for v in range(Q):
                        dd = max(Fraction(size - cnt[j][u], size), Fraction(size - cnt[l][v], size),
                                 Fraction(cnt[m][(-u - v) % Q], size))
                        best = min(best, dd)
            for i in range(n):
                for kappa in (1, 2):
                    for d1 in range(Q):
                        for d2 in range(Q):
                            ds = (d1, d2, (-d1 - d2) % Q)
                            dd = max(Fraction(int((f[t] != (kappa * pts[:, i] + ds[t]) % Q).sum()), size)
                                     for t in range(3))
                            best = min(best, dd)
            if PA <= Fraction(1, 2) and PB <= Fraction(1, 2):
                assert best >= min(PA, PB), (n, T, best, PA, PB)
                out.append(f"n={n},T={T}: min dist {best} = {float(best):.4f} >= min(PA,PB) = {float(min(PA, PB)):.4f}")
            else:
                out.append(f"n={n},T={T}: PA={PA}, PB={PB} (hypothesis fails; skipped)")
    print("(D) distance against all generalized polymorphisms:", "; ".join(out), ": ok")


def binom_pmf_int(n, j):
    return math.comb(n, j) * 2 ** (n - j)  # times 3^-n gives Pr[Bin(n,1/3) = j]


def check_B():
    out = []
    for M in (45, 100, 1000):
        alpha = mpmath.mpf(1) / M
        tau = 2 * E ** 2 * alpha
        nmin = int(mpmath.ceil(max(1 / tau ** 2, 1 / (mpmath.mpf(1) / 3 - tau))))
        nmin += (-nmin) % 3
        ns = [nmin, nmin + 3, nmin + 30, 2 * nmin + (-(2 * nmin)) % 3, 4 * nmin + (-(4 * nmin)) % 3]
        for n in ns:
            k = n // 3
            T = int(mpmath.ceil(tau * n))
            assert 0 <= k - T and k + T <= n
            den = mpmath.mpf(3) ** n
            pa_int = sum(binom_pmf_int(n, j) for j in range(k + T, n + 1))
            pb_int = sum(binom_pmf_int(n, j) for j in range(0, k - T + 1))
            PA = mpmath.mpf(pa_int) / den
            PB = mpmath.mpf(pb_int) / den
            assert PA <= mpmath.mpf(2) / 9 and PB <= mpmath.mpf(2) / 9
            lower = mpmath.exp(-mpmath.mpf(9) / 2 * n * (tau + mpmath.mpf(1) / n) ** 2) / (n + 1)
            for j, Pall in ((k + T, PA), (k - T, PB)):
                q = mpmath.mpf(j) / n
                Dq = q * mpmath.log(3 * q) + (1 - q) * mpmath.log(3 * (1 - q) / 2)
                assert Dq <= mpmath.mpf(9) / 2 * (q - mpmath.mpf(1) / 3) ** 2
                pj = mpmath.mpf(binom_pmf_int(n, j)) / den
                assert pj >= mpmath.exp(-n * Dq) / (n + 1) >= lower
                assert Pall >= pj
            out.append(f"1/{M}: n={n}, PA={mpmath.nstr(PA, 3)}, PB={mpmath.nstr(PB, 3)}, "
                       f"lower={mpmath.nstr(lower, 3)}")
    print("(B) binomial bounds:", "; ".join(out[::5] + out[4::5]), ": ok")


def check_X():
    e2 = E ** 2
    assert mpmath.mpf(9) / 2 * e2 < mpmath.mpf('33.26') and 4 * e2 < 30 and 2 * e2 / 45 < mpmath.mpf(1) / 3
    assert mpmath.mpf(9) / 4 * e2 < 17
    assert mpmath.mpf(9) / 8 * e2 < mpmath.mpf("8.4")
    rows = []
    for M in (45, 100, 1000):
        tau = 2 * e2 / M
        target = mpmath.mpf(9) / 4 * tau
        vals = []
        for n in (10 ** 4, 10 ** 6, 10 ** 8):
            ratio = (mpmath.mpf(9) / 2 * n * (tau + mpmath.mpf(1) / n) ** 2 + mpmath.log(n + 1)) / (2 * tau * n)
            vals.append(mpmath.nstr(ratio * M, 6))
        rows.append(f"alpha=1/{M}: ratio/alpha at n=1e4,1e6,1e8: {', '.join(vals)} -> {mpmath.nstr(target * M, 6)}")
    print(f"(X) (9/2)e^2 = {mpmath.nstr(mpmath.mpf(9) / 2 * e2, 8)}, 4e^2 = {mpmath.nstr(4 * e2, 6)},"
          f" (9/4)e^2 = {mpmath.nstr(mpmath.mpf(9) / 4 * e2, 6)}, (9/8)e^2 = {mpmath.nstr(mpmath.mpf(9) / 8 * e2, 6)} < 8.4, 2e^2/45 = {mpmath.nstr(2 * e2 / 45, 6)} < 1/3;", "; ".join(rows), ": ok")


if __name__ == "__main__":
    check_M()
    check_F()
    check_E()
    check_D()
    check_B()
    check_X()
    print("all checks passed")
