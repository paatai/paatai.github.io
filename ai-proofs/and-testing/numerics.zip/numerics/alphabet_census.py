"""Census of the hypotheses of Theorem 8.45 (Section 8.9) for all g: [q]^m -> [q] depending on all coordinates.

N_j: the collision graph on [q], a ~ b iff g(u^{j->a}) = g(u^{j->b}) for some context u.
(H) (Theorem 8.45): the union over j of the graphs G_j on the image of g is connected, where y ~ y' in G_j iff
    g(u^{j->a}) = y and g(u^{j->b}) = y' for a context u and letters a, b in the same component of N_j.
Weaker conditions of earlier versions, printed for comparison:
(Hc) the outputs are connected by changes of collision-connected coordinates (N_j connected) alone;
(Hk) the same with "some context makes g constant in x_j" instead of "N_j connected".
Prints the counts for (q, m) = (2,2), (2,3), (3,2), and checks the rounded mean floor((x+y)/2) for q = 3..6.
"""
import itertools, collections


def conn(nodes, edges):
    nodes = list(nodes)
    if not nodes:
        return True
    adj = {y: set() for y in nodes}
    for a, b in edges:
        adj[a].add(b); adj[b].add(a)
    seen = {nodes[0]}; st = [nodes[0]]
    while st:
        y = st.pop()
        for z in adj[y]:
            if z not in seen:
                seen.add(z); st.append(z)
    return len(seen) == len(nodes)


def analyze(q, m, g):
    S0 = sorted(set(g.values()))
    def ins(u, j, a):
        u = list(u); return tuple(u[:j] + [a] + u[j:])
    ctx = list(itertools.product(range(q), repeat=m - 1))
    dep = all(any(g[ins(u, j, a)] != g[ins(u, j, b)] for u in ctx for a in range(q) for b in range(q)) for j in range(m))
    J1 = [j for j in range(m) if any(len({g[ins(u, j, a)] for a in range(q)}) == 1 for u in ctx)]
    J1s = [j for j in range(m) if conn(range(q), [(a, b) for a in range(q) for b in range(a + 1, q)
                                                  if any(g[ins(u, j, a)] == g[ins(u, j, b)] for u in ctx)])]
    assert set(J1) <= set(J1s)
    comp = []
    for j in range(m):
        lab = list(range(q))
        for a in range(q):
            for b in range(q):
                if any(g[ins(u, j, a)] == g[ins(u, j, b)] for u in ctx):
                    la, lb = lab[a], lab[b]
                    lab = [la if x == lb else x for x in lab]
        comp.append(lab)
    Ecomp = set()
    for j in range(m):
        for u in ctx:
            for a in range(q):
                for b in range(q):
                    if comp[j][a] == comp[j][b] and g[ins(u, j, a)] < g[ins(u, j, b)]:
                        Ecomp.add((g[ins(u, j, a)], g[ins(u, j, b)]))
    Hfull = conn(S0, Ecomp)
    edgeless = all(len(set(comp[j])) == q for j in range(m))
    def H(J):
        E = set()
        for j in J:
            for u in ctx:
                vals = {g[ins(u, j, a)] for a in range(q)}
                E |= {(a, b) for a in vals for b in vals if a < b}
        return conn(S0, E)
    return dep, H(J1), H(J1s), Hfull, edgeless


for q, m in [(2, 2), (2, 3), (3, 2)]:
    pts = list(itertools.product(range(q), repeat=m))
    cnt = collections.Counter()
    for table in itertools.product(range(q), repeat=q ** m):
        d, hk, hc, h, edgeless = analyze(q, m, dict(zip(pts, table)))
        if not d:
            continue
        assert (not hk or hc) and (not hc or h)
        cnt["depend on all"] += 1; cnt["(H)"] += h; cnt["(Hc)"] += hc; cnt["(Hk)"] += hk
        if not h:
            cnt["(H) fails, every N_j edgeless" if edgeless else "(H) fails, some N_j has an edge"] += 1
    print(q, m, dict(cnt))

for q in range(3, 7):
    g = {(x, y): (x + y) // 2 for x in range(q) for y in range(q)}
    d, hk, hc, h, _ = analyze(q, 2, g)
    print("rounded mean, q =", q, ": depends on both:", d, "(H):", h, "(Hc):", hc, "(Hk):", hk)
g = {(x, y): int(x != 0) ^ int(y != 0) for x in range(3) for y in range(3)}
print("1{x!=0} xor 1{y!=0} on 3 letters: (H):", analyze(3, 2, g)[3])
