"""Checks for Section 8.10, Lemma 8.64 (transfer), Lemma 8.65 (chain of marginals) and
Theorem 8.66 (every full-support distribution) for P = {(a,b,c) in Z_3^3 : a+b+c != 0}.

 (9)  Lemma 8.65, in exact rational arithmetic, for random full-support mu (multi-scale weights)
      and for mu near the point masses, near two- and three-point distributions and near the
      distributions that are nearly degenerate in one or two columns:
      the explicit transportation solution (one free parameter) and the Hall conditions;
      pi_1 (column 1 replaced by m_1', pair law of columns 2,3 kept): marginals, min >= alpha/2,
      s_a/3 <= m_1'(a) <= (3/4) min(2/3, s_a); the coupling gamma of m_1', m_3: Pr_gamma[a+c=-b] <= 7/12,
      min gamma >= alpha/6; pi_2 (columns 1,3 law gamma, column 2 uniform): min >= alpha/30;
      pi_3 = (1-9 alpha) sum_c m~_3(c) Q_c + 9 alpha pi: uniform columns 1,2, column 3 = m_3, min >= alpha/2;
      the matching columns (mu,pi_1: 2,3; pi_1,pi_2: 1,3; pi_2,pi_3: 2,3).
 (10) Lemma 8.64, ingredients: for each transfer step of the chain (float), the decomposition
      mu = sigma pi' + (1-sigma) nu with sigma = a/2: nu >= mu/2, nu_t = mu_t on the matched columns,
      nu_jl >= a nu_j nu_l (reverse hypercontractivity with kappa = a, checked by enumeration, m <= 3),
      mu_lm >= 2a mu_l mu_m (Step 5); the coordinate laws of a matched column do not depend on L;
      monotonicity of D_t(L) and E_L D_t(L) >= (sigma/2) dc(f_t) when the free and the fixed
      entries have the same (non-uniform) law, exactly for n <= 3; the pointer facts (distinct
      kappa w_i + d differ with probability >= 2 min p; distance >= min p to every function with
      at most two values) and the bijection bound of Step 1 (if h is theta-close to kappa w_i + d
      under p^n, then a -> h(a, w'') is a bijection except with probability <= theta/min p),
      exactly for n <= 3.
 (11) Theorem 8.66, arithmetic: c(mu) >= alpha^8/13107200 and the recursion for C(mu) against
      exp(1.2e11 alpha^-9 ln(1/alpha)), for alpha from 1e-12 to 1/18.
"""
import itertools
import math
from fractions import Fraction as Fr

import numpy as np

rng = np.random.default_rng(20261021)
P = [p for p in itertools.product(range(3), repeat=3) if sum(p) % 3 != 0]
assert len(P) == 18
PSET = set(P)
PI = {p: Fr(1, 18) for p in P}


def marg(m, j):
    v = [Fr(0)] * 3 if isinstance(next(iter(m.values())), Fr) else [0.0] * 3
    for p, w in m.items():
        v[p[j]] += w
    return v


def pair(m, j, l):
    zero = Fr(0) if isinstance(next(iter(m.values())), Fr) else 0.0
    d = {(u, v): zero for u in range(3) for v in range(3)}
    for p, w in m.items():
        d[(p[j], p[l])] += w
    return d


def transport(T, D):
    """Class e has supply T[e] and may not send to the value e; value a has demand D[a].
    Returns x[(e, a)] >= 0, e != a, with the prescribed row and column sums (one free parameter s)."""
    assert sum(T) == 1 and sum(D) == 1
    for a in range(3):
        assert 0 <= D[a] <= 1 - T[a], ("Hall", a, D, T)
    s = max(Fr(0), D[1] - T[2], T[0] - D[2])
    x = {(0, 1): s, (0, 2): T[0] - s, (2, 1): D[1] - s, (2, 0): T[2] - D[1] + s,
         (1, 0): 1 - D[2] - T[2] - s, (1, 2): D[2] - T[0] + s}
    assert all(v >= 0 for v in x.values())
    for e in range(3):
        assert sum(x[(e, a)] for a in range(3) if a != e) == T[e]
    for a in range(3):
        assert sum(x[(e, a)] for e in range(3) if e != a) == D[a]
    return x


def fill_column(pl, cols, j, target, eps):
    """pl: law of the entries in columns cols = (l, m). Returns psi on P with that pair law and
    j-th marginal target: lambda(a | u, v) = eps/2 on both completions + (1 - eps) x_{e,a} / T_e."""
    T = [sum(w for (u, v), w in pl.items() if (-(u + v)) % 3 == e) for e in range(3)]
    s = [1 - T[a] for a in range(3)]
    for a in range(3):  # the hypothesis of Lemma 8.65(i)
        assert eps * s[a] / 2 <= target[a] <= (1 - eps / 2) * s[a]
    Dt = [(target[a] - eps * s[a] / 2) / (1 - eps) for a in range(3)]
    x = transport(T, Dt)
    psi = {}
    for (u, v), w in pl.items():
        e = (-(u + v)) % 3
        for a in range(3):
            if a == e:
                continue
            t = [0, 0, 0]
            t[j], t[cols[0]], t[cols[1]] = a, u, v
            psi[tuple(t)] = w * (eps / 2 + (1 - eps) * x[(e, a)] / T[e])
    return psi


def Q(c):
    base = [(1, 1, 0), (2, 2, 0), (0, 1, 0), (0, 2, 0), (1, 0, 0), (2, 0, 0)]
    return {((a - c) % 3, b, c): Fr(1, 6) for (a, b, _) in base}


def chain(mu):
    alpha = min(mu.values())
    m2, m3 = marg(mu, 1), marg(mu, 2)
    mu23 = pair(mu, 1, 2)
    T = [sum(w for (b, c), w in mu23.items() if (-(b + c)) % 3 == e) for e in range(3)]
    s = [1 - T[a] for a in range(3)]
    for a in range(3):
        assert s[a] >= 12 * alpha
    Z = sum(min(Fr(2, 3), s[a]) for a in range(3))
    assert Fr(4, 3) <= Z <= 2
    m1p = [min(Fr(2, 3), s[a]) / Z for a in range(3)]
    for a in range(3):
        assert s[a] / 3 <= m1p[a] <= Fr(3, 4) * min(Fr(2, 3), s[a]) <= Fr(1, 2)
    pi1 = fill_column(mu23, (1, 2), 0, m1p, Fr(1, 2))
    pi13 = pair(pi1, 0, 2)
    gamma = {(a, c): Fr(5, 6) * m1p[a] * m3[c] + Fr(1, 6) * pi13[(a, c)] for a in range(3) for c in range(3)}
    for b in range(3):
        assert sum(w for (a, c), w in gamma.items() if (a + c + b) % 3 == 0) <= Fr(7, 12)
    assert min(gamma.values()) >= alpha / 6
    pi2 = fill_column(gamma, (0, 2), 1, [Fr(1, 3)] * 3, Fr(2, 5))
    mt3 = [(m3[c] - 3 * alpha) / (1 - 9 * alpha) for c in range(3)]
    assert min(mt3) >= 0
    pi3 = {p: 9 * alpha * PI[p] for p in P}
    for c in range(3):
        for p, w in Q(c).items():
            pi3[p] += (1 - 9 * alpha) * mt3[c] * w
    for d in (pi1, pi2, pi3):
        assert set(d) <= PSET and len(d) == 18 and sum(d.values()) == 1
    third = [Fr(1, 3)] * 3
    assert pair(pi1, 1, 2) == mu23 and marg(pi1, 0) == m1p
    assert pair(pi2, 0, 2) == gamma and marg(pi2, 1) == third
    assert marg(pi2, 0) == m1p and marg(pi2, 2) == m3
    assert marg(pi3, 0) == third and marg(pi3, 1) == third and marg(pi3, 2) == m3
    assert min(pi1.values()) >= alpha / 2
    assert min(pi2.values()) >= alpha / 30
    assert min(pi3.values()) >= alpha / 2
    # matching columns of consecutive distributions
    assert marg(mu, 1) == marg(pi1, 1) and marg(mu, 2) == marg(pi1, 2)
    assert marg(pi1, 0) == marg(pi2, 0) and marg(pi1, 2) == marg(pi2, 2)
    assert marg(pi2, 1) == marg(pi3, 1) and marg(pi2, 2) == marg(pi3, 2)
    ratios = (min(pi1.values()) / alpha, min(pi2.values()) / alpha, min(pi3.values()) / alpha)
    return pi1, pi2, pi3, ratios


def mu_from_weights(w):
    tot = sum(w)
    return {p: Fr(int(x), tot) for p, x in zip(P, w)}


def test_mus():
    out = []
    for _ in range(1500):  # multi-scale random weights
        w = [int(rng.integers(1, 10 ** int(rng.integers(0, 10)) + 1)) for _ in P]
        out.append(("random", mu_from_weights(w)))
    for N in (10 ** 3, 10 ** 6, 10 ** 9, 10 ** 15):
        for i in range(18):  # near a point mass
            w = [1] * 18
            w[i] = N
            out.append(("point", mu_from_weights(w)))
        for _ in range(40):  # near two- or three-point distributions
            w = [1] * 18
            for i in rng.choice(18, size=int(rng.integers(2, 4)), replace=False):
                w[i] = N * int(rng.integers(1, 5))
            out.append(("few", mu_from_weights(w)))
        for j in range(3):  # nearly degenerate column j, and two nearly degenerate columns
            for v in range(3):
                w = [N if p[j] == v else 1 for p in P]
                out.append(("col", mu_from_weights(w)))
                for l in range(3):
                    if l != j:
                        for u in range(3):
                            w = [N if (p[j] == v and p[l] == u) else 1 for p in P]
                            out.append(("2col", mu_from_weights(w)))
        w = [N if p in ((0, 0, 1),) else 1 for p in P]
        out.append(("(0,0,1)", mu_from_weights(w)))
    out.append(("uniform", dict(PI)))
    return out


def check_chain():
    mus = test_mus()
    worst = [math.inf] * 3
    for kind, mu in mus:
        _, _, _, ratios = chain(mu)
        worst = [min(x, float(r)) for x, r in zip(worst, ratios)]
    print(f"(9) chain of marginals: {len(mus)} distributions (exact arithmetic), all checks pass;")
    print(f"    smallest min(pi_1)/alpha = {worst[0]:.4f} (>= 1/2), min(pi_2)/alpha = {worst[1]:.4f} (>= 1/30), "
          f"min(pi_3)/alpha = {worst[2]:.4f} (>= 1/2)")
    return mus


# ---------------------------------------------------------------- (10) transfer ingredients (float)

def to_vec(m):
    return np.array([float(m[p]) for p in P])


def fpair(v, j, l):
    M = np.zeros((3, 3))
    for i, p in enumerate(P):
        M[p[j], p[l]] += v[i]
    return M


def fmarg(v, j):
    out = np.zeros(3)
    for i, p in enumerate(P):
        out[p[j]] += v[i]
    return out


def r_kappa(k):
    s = math.sqrt(1 - k)
    return 2 * k / ((1 + s) * (2 - s))  # = 2(1-s)/(2-s), without cancellation for small k


def check_rhc(M, kappa, m, trials=6):
    """E[g(X)h(Y)] >= (E g E h)^(1/r) for [0,1]-valued g, h, X, Y in Z_3^m with iid pairs ~ M."""
    r = r_kappa(kappa)
    joint = M.copy()
    for _ in range(m - 1):
        joint = np.einsum('ab,cd->acbd', joint, M).reshape(joint.shape[0] * 3, joint.shape[1] * 3)
    px, py = joint.sum(1), joint.sum(0)
    worst = math.inf
    nonvac = 0
    s = min(1.0, 2 * (1 - 0.05 ** (r / 2)))  # functions near 1, so that (Eg Eh)^(1/r) does not underflow
    for _ in range(trials):
        for kind in range(4):
            if kind == 0:
                g, h = rng.uniform(size=len(px)), rng.uniform(size=len(py))
            elif kind == 1:
                g, h = (rng.uniform(size=len(px)) < 0.3).astype(float), (rng.uniform(size=len(py)) < 0.3).astype(float)
            elif kind == 2:
                g = (rng.uniform(size=len(px)) < 0.08).astype(float)
                h = (rng.uniform(size=len(py)) < 0.08).astype(float)
            else:
                g, h = 1 - s * rng.uniform(size=len(px)), 1 - s * rng.uniform(size=len(py))
            Eg, Eh = px @ g, py @ h
            lhs = g @ joint @ h
            rhs = (Eg * Eh) ** (1 / r)
            assert lhs >= rhs * (1 - 1e-9) - 1e-15
            if rhs > 1e-200 and Eg * Eh < 1 - 1e-9:  # g = h = 1 is the trivial equality case
                worst = min(worst, lhs / rhs)
                nonvac += 1
    return worst, nonvac


def dc_vec(f, w):
    return max(0.0, 1 - max(w[f == v].sum() for v in range(3)))


def prod_w(p, n):
    w = np.array([1.0])
    for _ in range(n):
        w = np.outer(w, p).ravel()
    return w


def D_of_L(f, n, p, L):
    """E_{rho ~ p^(L^c)} dc_{p^L}(f(., rho)) with f indexed in base 3, first coordinate most significant."""
    F = f.reshape((3,) * n)
    Lc = [i for i in range(n) if i not in L]
    G = np.transpose(F, list(L) + Lc).reshape(3 ** len(L), 3 ** len(Lc))
    wL, wLc = prod_w(p, len(L)), prod_w(p, len(Lc))
    return sum(wLc[k] * dc_vec(G[:, k], wL) for k in range(G.shape[1]))


def random_f(n):
    kind = rng.integers(0, 4)
    N = 3 ** n
    if kind == 0:
        return rng.integers(0, 3, size=N)
    coords = np.array(list(itertools.product(range(3), repeat=n)))
    if kind == 1:  # perturbed constant
        f = np.full(N, rng.integers(0, 3))
    elif kind == 2:  # perturbed dictator
        i = rng.integers(0, n)
        f = (rng.integers(1, 3) * coords[:, i] + rng.integers(0, 3)) % 3
    else:  # majority-like: value 1 if many coordinates are 0
        f = ((coords == 0).sum(1) >= (n + 1) // 2).astype(int)
    k = rng.integers(0, N // 3 + 1)
    idx = rng.choice(N, size=k, replace=False)
    f = f.copy()
    f[idx] = rng.integers(0, 3, size=k)
    return f


def check_monotone_noise(trials=150):
    worst_ratio = math.inf
    cnt = 0
    for _ in range(trials):
        p = rng.dirichlet(np.full(3, rng.choice([0.3, 1.0, 5.0])))
        p = np.maximum(p, 1e-3)
        p /= p.sum()
        n = int(rng.integers(1, 4))
        f = random_f(n)
        sigma = float(rng.uniform(0.001, 0.05))
        D = {}
        for k in range(n + 1):
            for L in itertools.combinations(range(n), k):
                D[L] = D_of_L(f, n, p, L)
        for L in D:
            for L2 in D:
                if set(L) <= set(L2):
                    assert D[L] <= D[L2] + 1e-12
        EL = sum(sigma ** len(L) * (1 - sigma) ** (n - len(L)) * D[L] for L in D)
        dcf = dc_vec(f, prod_w(p, n))
        assert EL >= sigma / 2 * dcf - 1e-12
        if dcf > 1e-9:
            worst_ratio = min(worst_ratio, EL / (sigma / 2 * dcf))
        cnt += 1
    return cnt, worst_ratio


def affine_dictators(n):
    coords = np.array(list(itertools.product(range(3), repeat=n)))
    return [((k * coords[:, i] + d) % 3, i) for i in range(n) for k in (1, 2) for d in range(3)]


def check_pointer_facts(trials=60):
    worst1 = worst2 = worst3 = math.inf
    for _ in range(trials):
        p = rng.dirichlet(np.full(3, rng.choice([0.3, 1.0, 5.0])))
        p = np.maximum(p, 1e-3)
        p /= p.sum()
        mp = p.min()
        n = int(rng.integers(1, 4))
        w = prod_w(p, n)
        dic = affine_dictators(n)
        for (g, i), (h, i2) in itertools.combinations(dic, 2):
            dist = w[g != h].sum()
            assert dist >= 2 * mp - 1e-12
            worst1 = min(worst1, dist / mp)
        for g, i in dic:  # nearest function with at most two values misses one value v entirely
            d2 = min(w[g == v].sum() for v in range(3))
            assert d2 >= mp - 1e-12
            worst2 = min(worst2, d2 / mp)
        coords = np.array(list(itertools.product(range(3), repeat=n)))
        for g, i in dic:  # Step 1: closeness to kappa w_i + d makes most i-lines bijections
            h = g.copy()
            k = int(rng.integers(0, 3 ** n // 2 + 1))
            idx = rng.choice(3 ** n, size=k, replace=False)
            h[idx] = rng.integers(0, 3, size=k)
            theta = w[h != g].sum()
            others = [c for c in range(n) if c != i]
            wo = prod_w(p, n - 1)
            nb = 0.0
            for t, rest in enumerate(itertools.product(range(3), repeat=n - 1)):
                vals = set()
                for a in range(3):
                    x = list(rest)
                    x.insert(i, a)
                    vals.add(h[int(np.ravel_multi_index(tuple(x), (3,) * n))])
                if len(vals) < 3:
                    nb += wo[t]
            assert nb <= theta / mp + 1e-12
            if theta > 0:
                worst3 = min(worst3, theta / mp / max(nb, 1e-300))
    return worst1, worst2, worst3


def check_transfer_steps(mus, count=40):
    worst_rhc = math.inf
    worst_nu = math.inf
    worst_lm = math.inf
    nonvac = 0
    idx = rng.choice(len(mus), size=count, replace=False)
    for k in idx:
        mu = mus[k][1]
        pi1, pi2, pi3, _ = chain(mu)
        alpha = float(min(mu.values()))
        steps = [(to_vec(pi2), to_vec(pi3), (1, 2), alpha / 30, alpha / 2),
                 (to_vec(pi1), to_vec(pi2), (0, 2), alpha / 2, alpha / 30),
                 (to_vec(mu), to_vec(pi1), (1, 2), alpha, alpha / 2)]
        for tgt, src, (j, l), a, ap in steps:
            assert tgt.min() >= a * (1 - 1e-12) and src.min() >= ap * (1 - 1e-12)
            for t in (j, l):
                assert np.allclose(fmarg(tgt, t), fmarg(src, t), atol=1e-15)
            sigma = a / 2
            nu = (tgt - sigma * src) / (1 - sigma)
            assert np.all(nu >= tgt / 2 * (1 - 1e-12)) and abs(nu.sum() - 1) < 1e-12
            worst_nu = min(worst_nu, (nu / tgt).min())
            assert np.allclose(sigma * src + (1 - sigma) * nu, tgt, atol=1e-15)
            for t in (j, l):
                assert np.allclose(fmarg(nu, t), fmarg(tgt, t), atol=1e-14)
            Mjl = fpair(nu, j, l)
            assert np.all(Mjl >= a * np.outer(fmarg(nu, j), fmarg(nu, l)) * (1 - 1e-12))
            for t in range(3):
                for u in range(3):
                    if t < u:
                        Mt = fpair(tgt, t, u)
                        q = Mt / np.outer(fmarg(tgt, t), fmarg(tgt, u))
                        assert q.min() >= 2 * a * (1 - 1e-12)
                        worst_lm = min(worst_lm, q.min() / (2 * a))
            # the coordinate law of a matched column is the same inside and outside L
            for t in (j, l):
                assert np.allclose(fmarg(src, t), fmarg(nu, t), atol=1e-14)
            if Mjl.min() > 1e-7:
                wr, nv = check_rhc(Mjl, a, m=int(rng.integers(1, 4)), trials=2)
                worst_rhc = min(worst_rhc, wr)
                nonvac += nv
    return count, worst_nu, worst_lm, worst_rhc, nonvac


# ---------------------------------------------------------------- (11) arithmetic of Theorem 8.66

def log_C_chain(alpha):
    """ln C(mu) from the recursion of Lemma 8.64 along the chain, with r_a/2 <= a and the
    exponent lower bounds c_3 = 9 alpha^2/64, c <- c a^2/8."""
    lnC = math.log(3e7) + 1.5 * math.log(2 / alpha)
    c = 9 * alpha ** 2 / 64
    for a, ap in ((alpha / 30, alpha / 2), (alpha / 2, alpha / 30), (alpha, alpha / 2)):
        theta = min(2 * ap, a / 2)
        ln_inv_d1 = (lnC + math.log(1 / theta)) / c
        lnK = math.log(1 + 15 / a) + ln_inv_d1  # K = C' + 15/(a d1) <= (1 + 15/a)/d1
        lnE = math.log(16 / a) + a * lnK  # 4 E_0 = (16/a) K^(r/2) and r = r_a <= 2a
        lnC = max(lnE + math.log1p(5 * math.exp(-lnE)), math.log(16) + 4 * math.log(1 / a))
        c = c * a ** 2 / 8
    return lnC, c


def check_arith():
    worst = 0.0
    for e in np.linspace(math.log10(1 / 18), -12, 200):
        alpha = 10 ** e
        lnC, c = log_C_chain(alpha)
        assert abs(c - alpha ** 8 / 13107200) <= 1e-12 * c
        bound = 1.2e11 * alpha ** -9 * math.log(1 / alpha)
        assert lnC <= bound
        worst = max(worst, lnC / bound)
        # exact exponent with r_kappa is at least the stated one
        cex = r_kappa(9 * alpha / 2) * r_kappa(alpha) / 8 if 9 * alpha / 2 < 1 else None
        if cex is not None:
            for a in (alpha / 30, alpha / 2, alpha):
                cex *= r_kappa(a) * r_kappa(2 * a) / 4
            assert cex >= alpha ** 8 / 13107200
    print(f"(11) arithmetic: c(mu) = alpha^8/13107200 and ln C(mu) <= 1.2e11 alpha^-9 ln(1/alpha) "
          f"for 200 values of alpha in [1e-12, 1/18]; largest ratio {worst:.4f}")


if __name__ == "__main__":
    mus = check_chain()
    cnt, wnu, wlm, wr, nv = check_transfer_steps(mus)
    print(f"(10) transfer steps of the chain for {cnt} distributions: decomposition, matched marginals, "
          f"min nu/mu = {wnu:.4f} (>= 1/2), min mu_lm/(mu_l mu_m)/(2a) = {wlm:.3f} (>= 1), "
          f"RHC with kappa = a ({nv} non-vacuous instances): min E[gh]/(EgEh)^(1/r) = {wr:.4f} (>= 1)")
    cnt, wratio = check_monotone_noise()
    print(f"     D_t monotone in L and E_L D_t >= (sigma/2) dc(f_t), matched non-uniform laws, n <= 3: "
          f"{cnt} cases, min ratio {wratio:.4f} (>= 1)")
    w1, w2, w3 = check_pointer_facts()
    print(f"     pointer facts, n <= 3: distinct affine dictators differ by >= {w1:.3f} min p (>= 2); "
          f"distance to two-valued functions >= {w2:.3f} min p (>= 1); "
          f"Pr[i-line not a bijection] <= theta/min p, slack >= {w3:.3f} (>= 1)")
    check_arith()
    print("ALL CHECKS PASSED")
