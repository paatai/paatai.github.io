#!/usr/bin/env python3
"""Exhaustive exact verification of every lemma in MAIN_RESULT for all f:{0,1}^n->{0,1}, n<=4.

All checks use exact integer arithmetic (every quantity is a rational with a power-of-2 denominator).

Notation (uniform measure, p = 1/2):
  N = 2^n, points x in {0,1}^n encoded as bitmasks, x_i = bit i.
  mu = E f,  eps = Pr_{x,y}[f(x&y) != f(x) f(y)],
  fhat(S) = E[f(x) (-1)^{|S & x|}],  a_S = Pr[f(x)=1, x_S = 1^S],
  b_i = Pr[f=1, x_i=0],  C = {i : b_i <= mu/4},  eta = eps/mu^2,  kappa = 4 eta.

Checked statements:
  L1 (spectral inequality):  sum_S fhat(S)^2 (mu - a_S) <= eps.
  L2 (influence lower bound): sum_{S ni i} fhat(S)^2 >= mu/2 - b_i.
  F1: sum_{S not subset C} fhat(S)^2 <= 4 eps / mu.
  F2: Pr[f=1, x_C != 1^C] <= 4 eps / mu.
  T  (main theorem): dist(f, {0} u {AND_T}) <= min(mu, 12 eps/mu), and if kappa <= 1/3 then
     Pr[f != AND_C] <= kappa mu (2 - 3 kappa)/(1 - 2 kappa)  (<= 12 eps/mu).
Also records max over all f of dist^2/eps (empirical constant).
"""
import sys
from fractions import Fraction

import numpy as np


def popcount_table(N):
    return np.array([bin(i).count("1") for i in range(N)], dtype=np.int64)


def run(n):
    N = 1 << n
    pts = np.arange(N, dtype=np.int64)
    pc = popcount_table(N)
    meet = pts[:, None] & pts[None, :]
    # chi[S, x] = (-1)^{|S & x|}
    chi = np.where(pc[pts[:, None] & pts[None, :]] % 2 == 0, 1, -1).astype(np.int64)
    # AND_S(x) = 1 iff (x & S) == S ; ANDm[S, x]
    ANDm = ((pts[None, :] & pts[:, None]) == pts[:, None]).astype(np.int64)
    # subset-of-C test for sets: S subset C iff S & ~C == 0
    nfun = 1 << N
    F = ((np.arange(nfun, dtype=np.int64)[:, None] >> pts[None, :]) & 1).astype(np.int64)  # (nfun, N)

    cntA = F.sum(axis=1)  # N * mu
    # eps * N^2 : count of pairs (x,y) with f(x&y) != f(x) f(y)
    fm = F[:, meet]  # (nfun, N, N)
    prod = F[:, :, None] * F[:, None, :]
    errcnt = (fm != prod).sum(axis=(1, 2))  # N^2 * eps
    del fm, prod

    Fh = F @ chi.T  # N * fhat(S)   (nfun, N)
    aS = F @ ANDm.T  # N * a_S       (nfun, N)

    # L1: sum_S fhat^2 (mu - a_S) <= eps   <=>   sum_S (N fhat)^2 (N mu - N a_S) <= N * (N^2 eps)
    L1lhs = (Fh ** 2 * (cntA[:, None] - aS)).sum(axis=1)
    L1rhs = N * errcnt
    assert np.all(L1lhs <= L1rhs), "L1 violated"
    # tightness statistics
    ok = errcnt > 0
    ratio_L1 = np.max(L1lhs[ok] / L1rhs[ok])

    # b_i * N = #{x : f(x)=1, x_i = 0}
    zero_i = np.array([((pts >> i) & 1) == 0 for i in range(n)]).astype(np.int64)  # (n, N)
    bcnt = F @ zero_i.T  # (nfun, n)
    # L2: sum_{S ni i} fhat^2 >= mu/2 - b_i  <=>  sum_{S ni i} (N fhat)^2 >= N^2 (mu/2 - b_i) = N (N mu /2 - N b_i)
    for i in range(n):
        Smask = ((pts >> i) & 1) == 1
        lhs = (Fh[:, Smask] ** 2).sum(axis=1) * 2
        rhs = N * (cntA - 2 * bcnt[:, i])
        assert np.all(lhs >= rhs), "L2 violated"

    # C = {i : b_i <= mu/4}  <=>  4 N b_i <= N mu
    inC = (4 * bcnt <= cntA[:, None])  # (nfun, n) bool
    Cmask = (inC * (1 << np.arange(n))[None, :]).sum(axis=1)  # bitmask of C

    worst_const = Fraction(0)
    worst_f = None
    for k in range(nfun):
        A = int(cntA[k])
        e = int(errcnt[k])
        # distances (times N)
        f = F[k]
        d0 = A
        dand = int(np.min((f[None, :] != ANDm).sum(axis=1)))
        dist = min(d0, dand)  # N * delta
        # T: dist <= min(mu, 12 eps / mu)  <=> N dist' ... in exact rationals
        mu = Fraction(A, N)
        eps = Fraction(e, N * N)
        delta = Fraction(dist, N)
        if A > 0:
            bound = min(mu, 12 * eps / mu)
            assert delta <= bound, ("theorem violated", n, k)
        else:
            assert delta == 0
        if e > 0:
            c = delta * delta / eps
            if c > worst_const:
                worst_const, worst_f = c, k
        if A == 0:
            continue
        C = int(Cmask[k])
        notC = (~C) & (N - 1)
        # F1: sum_{S not subset C} fhat^2 <= 4 eps/mu
        sel = (pts & notC) != 0
        F1lhs = Fraction(int((Fh[k, sel] ** 2).sum()), N * N)
        assert F1lhs <= 4 * eps / mu, "F1 violated"
        # F2: Pr[f=1, x_C != 1^C] <= 4 eps/mu
        offC = (pts & C) != C
        F2lhs = Fraction(int(f[offC].sum()), N)
        assert F2lhs <= 4 * eps / mu, "F2 violated"
        kappa = 4 * eps / (mu * mu)
        if kappa <= Fraction(1, 3):
            dC = Fraction(int((f != ANDm[C]).sum()), N)
            assert dC <= kappa * mu * (2 - 3 * kappa) / (1 - 2 * kappa), "final step violated"
            assert dC <= 12 * eps / mu
    return dict(n=n, nfun=nfun, max_L1_ratio=float(ratio_L1), worst_delta2_over_eps=worst_const,
                worst_f=worst_f)


if __name__ == "__main__":
    nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 4
    for n in range(1, nmax + 1):
        r = run(n)
        print(f"n={r['n']}: all {r['nfun']} functions OK. max L1 lhs/eps = {r['max_L1_ratio']:.6f}; "
              f"max delta^2/eps = {r['worst_delta2_over_eps']} = {float(r['worst_delta2_over_eps']):.6f} "
              f"(f bitmask {r['worst_f']})")
