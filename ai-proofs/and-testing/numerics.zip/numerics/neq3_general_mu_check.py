"""Checks for Section 8.10, Lemmas 8.59-8.60 and Theorem 8.61: the predicate
P = {(a,b,c) in Z_3^3 : a+b+c != 0} under full-support distributions mu on P.

For random mu (general, and with uniform marginals) this script checks:
 (1) the latent decomposition mu = sigma*pi + (1-sigma)*nu, sigma = 9*alpha:
     nu >= alpha/2, nu has uniform marginals, nu_jl >= alpha (uniform-marginal case);
 (2) the Doeblin bounds behind Lemma 8.59: K(a,a') >= theta*P(a') for the two-step kernels
     (pairs of entries of a mu-row: theta = 2*alpha; x given (y,z): theta = 3*alpha^2;
     pairs of entries of a nu-row: theta = 9*alpha), and the copy inequality
     Pr[d(U) != d(U'')] >= theta * dc(d(U)) by exact enumeration for random d, m <= 3;
 (3) monotonicity of D_j(L) in L and the noise bound E_L D_j(L) >= (sigma/3) dc(f_j);
 (4) reverse hypercontractivity E[g h] >= (Eg Eh)^(1/r), r = r_kappa, kappa = 9*alpha,
     for random [0,1]-valued g, h of two nu-correlated columns;
 (5) Lemma 8.60 and Theorem 8.61 for n = 2 by exhaustive comparison with all 13824 exact
     generalized polymorphisms, on random perturbations of exact ones.
 (6) Theorem 8.61(b) (two uniform marginals; a 13-dimensional family): the decomposition
     (nu_1, nu_2 uniform, nu_12 >= alpha) and the bound for n = 2 against all 13824 exact solutions.
 (7) Step 5 (any full-support mu): p_s q_s <= (delta+eps')^r' and
     min(dc f_l, dc f_m) <= 2 (delta+eps')^(r'/2), eps' = dc(f_j), r' = r_{2 alpha}, exact for n <= 2;
     and Remark 8.63(b): the coupling operator T of mu_j is PSD with gap >= 4 sigma/9, and
     E_L D_j(L) >= (2 sigma/9) dc(f_j) for non-uniform mu_j (free entries uniform, fixed ones nu_j).
 (8) Proposition 8.62: mu^(alpha) has uniform marginals and min alpha, mu^(1/18) = pi, and
     f = (0, 1_E, 1 + 1_E), E = {0} in Z_3^k, has err = (2 alpha)^k and dist >= 3^-k (k = 1, 2).
"""
import itertools

import numpy as np

rng = np.random.default_rng(20261021)
P = [p for p in itertools.product(range(3), repeat=3) if sum(p) % 3 != 0]
assert len(P) == 18
IDX = {p: i for i, p in enumerate(P)}


def marg_matrix():
    A = np.zeros((9, 18))
    for i, p in enumerate(P):
        for j in range(3):
            A[3 * j + p[j], i] = 1.0
    return A


A = marg_matrix()
_, s, Vt = np.linalg.svd(A)
NULL = Vt[np.sum(s > 1e-9):]  # signed measures on P with zero marginals
assert NULL.shape[0] == 11
_, s12, Vt12 = np.linalg.svd(A[:6])
NULL12 = Vt12[np.sum(s12 > 1e-9):]  # zero first and second marginals (third arbitrary)
assert NULL12.shape[0] == 13


def random_mu(uniform_marginals, two_only=False):
    if not uniform_marginals:
        w = rng.exponential(size=18) + rng.uniform(0.01, 0.3)
        return w / w.sum()
    pi = np.full(18, 1 / 18)
    N = NULL12 if two_only else NULL
    d = N.T @ rng.normal(size=N.shape[0])
    t = rng.uniform(0.05, 0.98) * (1 / 18) / max(1e-12, -d.min())
    mu = pi + t * d
    assert mu.min() > 0 and abs(mu.sum() - 1) < 1e-12
    return mu


def pair_marg(m, j, l):
    M = np.zeros((3, 3))
    for i, p in enumerate(P):
        M[p[j], p[l]] += m[i]
    return M


def single_marg(m, j):
    v = np.zeros(3)
    for i, p in enumerate(P):
        v[p[j]] += m[i]
    return v


def two_step_kernel(joint):
    """joint[a, v] = Pr[U=a, V=v]; returns K(a,a') = sum_v P(v|a) P(a'|v) and P_U."""
    PU = joint.sum(axis=1)
    PV = joint.sum(axis=0)
    K = (joint / PU[:, None]) @ (joint / PV[None, :]).T
    return K, PU


def x_given_yz_joint(m, j):
    """Pr[entry_j = a, (other two entries) = v] as a 3 x 9 matrix."""
    others = [t for t in range(3) if t != j]
    J = np.zeros((3, 9))
    for i, p in enumerate(P):
        J[p[j], 3 * p[others[0]] + p[others[1]]] += m[i]
    return J


def dc(probs):
    return 1 - probs.max()


def check_copy_inequality(joint, theta, trials=30):
    """Exact Pr[d(U) != d(U'')] vs theta*dc(d) for random d on range(U)^m, m <= 3."""
    K, PU = two_step_kernel(joint)
    qa = len(PU)
    worst = np.inf
    for m in (1, 2, 3):
        pts = list(itertools.product(range(qa), repeat=m))
        pu = np.array([np.prod([PU[a] for a in pt]) for pt in pts])
        Km = np.array([[np.prod([K[a, b] for a, b in zip(pt, qt)]) for qt in pts] for pt in pts])
        for _ in range(trials):
            nv = rng.integers(2, 5)
            d = rng.integers(0, nv, size=len(pts))
            if rng.random() < 0.5:  # nearly constant d
                d = np.where(rng.random(len(pts)) < 0.15, d, 0)
            same = sum(pu[i] * Km[i, k] for i in range(len(pts)) for k in range(len(pts)) if d[i] == d[k])
            probs = np.array([pu[d == v].sum() for v in range(nv)])
            lhs, rhs = 1 - same, theta * dc(probs)
            assert lhs >= rhs - 1e-12, (lhs, rhs)
            if rhs > 1e-12:
                worst = min(worst, lhs / rhs)
    return worst


def r_kappa(k):
    return 2 * (1 - np.sqrt(1 - k)) / (2 - np.sqrt(1 - k))


def check_rhc(pair, kappa, trials=20):
    """E[g(X) h(Y)] >= (Eg Eh)^(1/r_kappa) for [0,1]-valued g, h of m i.i.d. pairs with law `pair`, m <= 3."""
    r = r_kappa(kappa)
    PX, PY = pair.sum(axis=1), pair.sum(axis=0)
    assert (pair >= kappa * np.outer(PX, PY) - 1e-15).all()
    worst = np.inf
    for m in (1, 2, 3):
        pts = list(itertools.product(range(3), repeat=m))
        W = np.array([[np.prod([pair[a, b] for a, b in zip(pt, qt)]) for qt in pts] for pt in pts])
        px, py = W.sum(axis=1), W.sum(axis=0)
        for _ in range(trials):
            g = rng.random(len(pts)) ** rng.uniform(0.5, 6)
            h = rng.random(len(pts)) ** rng.uniform(0.5, 6)
            if rng.random() < 0.5:
                g = (rng.random(len(pts)) < 0.2).astype(float)
                h = (rng.random(len(pts)) < 0.2).astype(float)
            lhs = g @ W @ h
            rhs = (px @ g * (py @ h)) ** (1 / r)
            assert lhs >= rhs - 1e-12, (lhs, rhs)
            if rhs > 1e-12:
                worst = min(worst, lhs / rhs)
    return worst


def check_distributions(n_mu=40):
    stats = {"theta_pair": np.inf, "theta_x_yz": np.inf, "theta_nu": np.inf, "copy": np.inf, "rhc": np.inf}
    pi = np.full(18, 1 / 18)
    for t in range(n_mu):
        unif = t % 2 == 0
        mu = random_mu(unif)
        alpha = mu.min()
        assert alpha <= 1 / 18 + 1e-15
        for j in range(3):
            for l in range(3):
                if j == l:
                    continue
                K, PU = two_step_kernel(pair_marg(mu, j, l))
                stats["theta_pair"] = min(stats["theta_pair"], (K / PU[None, :]).min() / (2 * alpha))
            K, PU = two_step_kernel(x_given_yz_joint(mu, j))
            stats["theta_x_yz"] = min(stats["theta_x_yz"], (K / PU[None, :]).min() / (3 * alpha ** 2))
        if t < 8:
            stats["copy"] = min(stats["copy"], check_copy_inequality(pair_marg(mu, 0, 1), 2 * alpha))
            stats["copy"] = min(stats["copy"], check_copy_inequality(x_given_yz_joint(mu, 0), 3 * alpha ** 2, trials=10))
        if not unif:
            continue
        sigma = 9 * alpha
        nu = (mu - sigma * pi) / (1 - sigma)
        assert nu.min() >= alpha / 2 - 1e-15
        for j in range(3):
            assert np.allclose(single_marg(nu, j), 1 / 3)
            assert np.allclose(single_marg(mu, j), 1 / 3)
        for j in range(3):
            for l in range(3):
                if j == l:
                    continue
                nujl = pair_marg(nu, j, l)
                assert nujl.min() >= alpha - 1e-15
                K, PU = two_step_kernel(nujl)
                stats["theta_nu"] = min(stats["theta_nu"], (K / PU[None, :]).min() / (9 * alpha))
        # (4) reverse hypercontractivity for two nu-correlated columns of length m
        stats["rhc"] = min(stats["rhc"], check_rhc(pair_marg(nu, 0, 1), 9 * alpha))
    for k, v in stats.items():
        assert v >= 1 - 1e-9, (k, v)
    return stats


def dc_fun(vals, weights=None):
    if weights is None:
        weights = np.full(len(vals), 1 / len(vals))
    return 1 - max(weights[vals == v].sum() for v in range(3))


def check_monotone_noise(n=4, trials=60):
    """D_j(L) = E_rho dc(f(., rho)) under the uniform measure; L ranges over subsets of [n]."""
    pts = np.array(list(itertools.product(range(3), repeat=n)))
    worst_noise = np.inf
    for _ in range(trials):
        f = rng.integers(0, 3, size=len(pts))
        if rng.random() < 0.5:
            f = np.where(rng.random(len(pts)) < rng.uniform(0.02, 0.3), f, 1)
        D = {}
        for k in range(n + 1):
            for L in itertools.combinations(range(n), k):
                Lc = [i for i in range(n) if i not in L]
                tot = 0.0
                for rho in itertools.product(range(3), repeat=len(Lc)):
                    mask = np.all(pts[:, Lc] == np.array(rho, dtype=int), axis=1) if Lc else np.ones(len(pts), bool)
                    tot += dc_fun(f[mask])
                D[L] = tot / 3 ** len(Lc)
        for L in D:
            for i in range(n):
                if i not in L:
                    L2 = tuple(sorted(L + (i,)))
                    assert D[L2] >= D[L] - 1e-12
        for sigma in (0.05, 0.2, 0.5):
            EL = sum(sigma ** len(L) * (1 - sigma) ** (n - len(L)) * D[L] for L in D)
            d = dc_fun(f)
            assert EL >= sigma / 3 * d - 1e-12
            if d > 0:
                worst_noise = min(worst_noise, EL / (sigma / 3 * d))
    return worst_noise


def exact_gps_n2():
    """All exact generalized polymorphisms for n = 2 (types (A) and (B)), as 3 x 9 arrays."""
    pts = list(itertools.product(range(3), repeat=2))
    out = set()
    funcs = list(itertools.product(range(3), repeat=9))
    for j in range(3):
        for u in range(3):
            for v in range(3):
                bad = (-u - v) % 3
                for f in funcs:
                    if bad in f:
                        continue
                    t = [None, None, None]
                    others = [k for k in range(3) if k != j]
                    t[others[0]] = (u,) * 9
                    t[others[1]] = (v,) * 9
                    t[j] = f
                    out.add(tuple(t))
    for i in range(2):
        for kap in (1, 2):
            for d1 in range(3):
                for d2 in range(3):
                    d3 = (-d1 - d2) % 3
                    out.add(tuple(tuple((kap * w[i] + d) % 3 for w in pts) for d in (d1, d2, d3)))
    arr = np.array(sorted(out), dtype=np.int8)
    assert len(arr) == 13824, len(arr)
    return arr


def check_theorem_n2(gps, n_mu=6, per_mu=150):
    pts = list(itertools.product(range(3), repeat=2))
    worst = {"thm861": 0.0, "lem860": 0.0, "sqrt": 0.0}
    for t in range(n_mu):
        mu = random_mu(uniform_marginals=(t % 3 != 2))
        alpha = mu.min()
        unif = np.allclose([single_marg(mu, j) for j in range(3)], 1 / 3)
        w1 = [np.array([np.prod([single_marg(mu, j)[a] for a in x]) for x in pts]) for j in range(3)]
        # error: sum over row pairs of mu(row1) mu(row2) * [f1(x)+f2(y)+f3(z) == 0]
        R = [(p, q, mu[IDX[p]] * mu[IDX[q]]) for p in P for q in P]
        xi = np.array([3 * p[0] + q[0] for p, q, _ in R])
        yi = np.array([3 * p[1] + q[1] for p, q, _ in R])
        zi = np.array([3 * p[2] + q[2] for p, q, _ in R])
        wr = np.array([w for _, _, w in R])
        for _ in range(per_mu):
            g = gps[rng.integers(len(gps))].astype(np.int64)
            f = g.copy()
            k = rng.integers(1, 4)
            for _ in range(k):
                j, x = rng.integers(3), rng.integers(9)
                f[j, x] = rng.integers(3)
            if rng.random() < 0.2:
                f = rng.integers(0, 3, size=(3, 9))
            delta = wr[(f[0, xi] + f[1, yi] + f[2, zi]) % 3 == 0].sum()
            diff = np.stack([(gps[:, j, :] != f[j]) @ w1[j] for j in range(3)], axis=1)
            dist = diff.max(axis=1).min()
            if delta == 0:
                assert dist < 1e-12
                continue
            if unif:
                bound = 3e7 * alpha ** -1.5 * delta ** (r_kappa(9 * alpha) / 2)
                assert dist <= bound
                worst["thm861"] = max(worst["thm861"], dist / bound)
                worst["sqrt"] = max(worst["sqrt"], dist / np.sqrt(delta))
            # Lemma 8.60(b): if f is alpha-close to a type-(B) triple and delta <= alpha^4/16,
            # it is 3 delta/alpha^4-close to one; for n = 2 the hypothesis on delta is never met
            # (delta >= alpha^2 unless delta = 0), so we record the empirical ratio dist_B/delta.
            distB = diff[len(gps) - 36:].max(axis=1).min()
            if distB <= alpha:
                if delta <= alpha ** 4 / 16:
                    assert distB <= 3 * delta / alpha ** 4 + 1e-12
                worst["lem860"] = max(worst["lem860"], distB / delta)
    return worst


def exact_gps_n1():
    """All exact generalized polymorphisms for n = 1, by brute force over all 27^3 triples."""
    out = [f for f in itertools.product(itertools.product(range(3), repeat=3), repeat=3)
           if all((f[0][p[0]] + f[1][p[1]] + f[2][p[2]]) % 3 != 0 for p in P)]
    arr = np.array(out, dtype=np.int8)
    n_const = np.array([sum(len(set(r)) == 1 for r in g) for g in arr])
    n_bij = np.array([sum(len(set(r)) == 3 for r in g) for g in arr])
    assert len(arr) == 198 and (n_const >= 2).sum() == 180 and (n_bij == 3).sum() == 18
    for g in arr[n_bij == 3]:  # type (B): kappa*w + d_j with sum d_j = 0
        kap = (g[0][1] - g[0][0]) % 3
        d = [g[j][0] for j in range(3)]
        assert sum(d) % 3 == 0 and all(g[j][w] == (kap * w + d[j]) % 3 for j in range(3) for w in range(3))
    return arr


def row_tuples(m, n):
    """Columns of n i.i.d. m-rows: base-3 indices of x, y, z in Z_3^n (first coordinate most significant), weights."""
    xs, ys, zs, ws = [], [], [], []
    for rows in itertools.product(range(18), repeat=n):
        w, xi, yi, zi = 1.0, 0, 0, 0
        for i in rows:
            p = P[i]
            w *= m[i]
            xi, yi, zi = 3 * xi + p[0], 3 * yi + p[1], 3 * zi + p[2]
        xs.append(xi)
        ys.append(yi)
        zs.append(zi)
        ws.append(w)
    return np.array(xs), np.array(ys), np.array(zs), np.array(ws)


def prod_weights(m1, n):
    """The product measure m1^n on Z_3^n, in the base-3 order of row_tuples."""
    w = np.ones(1)
    for _ in range(n):
        w = np.outer(w, m1).ravel()
    return w


def err(f, tup):
    xs, ys, zs, ws = tup
    return ws[(f[0][xs] + f[1][ys] + f[2][zs]) % 3 == 0].sum()


def dc_w(fj, w):
    return max(0.0, 1 - max(w[fj == v].sum() for v in range(3)))


def perturbed(gps, N):
    g = gps[rng.integers(len(gps))].astype(np.int64)
    if rng.random() < 0.15:
        return rng.integers(0, 3, size=(3, N))
    f = g.copy()
    for _ in range(rng.integers(1, 4)):
        f[rng.integers(3), rng.integers(N)] = rng.integers(3)
    return f


def check_theorem_b_n2(gps, n_mu=6, per_mu=150):
    """(6) Theorem 8.61(b): mu_1, mu_2 uniform, mu_3 arbitrary."""
    worst = {"thm861b": 0.0, "theta_nu12": np.inf, "rhc_nu12": np.inf}
    nonunif3 = 0
    for _ in range(n_mu):
        mu = random_mu(True, two_only=True)
        alpha = mu.min()
        m = [single_marg(mu, j) for j in range(3)]
        assert np.allclose(m[0], 1 / 3) and np.allclose(m[1], 1 / 3)
        nonunif3 += not np.allclose(m[2], 1 / 3, atol=1e-6)
        sigma = 9 * alpha
        nu = (mu - sigma / 18) / (1 - sigma)
        assert nu.min() >= alpha / 2 - 1e-15 and abs(nu.sum() - 1) < 1e-12
        assert np.allclose(single_marg(nu, 0), 1 / 3) and np.allclose(single_marg(nu, 1), 1 / 3)
        nu12 = pair_marg(nu, 0, 1)
        assert nu12.min() >= alpha - 1e-15
        K, PU = two_step_kernel(nu12)
        worst["theta_nu12"] = min(worst["theta_nu12"], (K / PU[None, :]).min() / (9 * alpha))
        worst["rhc_nu12"] = min(worst["rhc_nu12"], check_rhc(nu12, 9 * alpha, trials=10))
        r, rp = r_kappa(9 * alpha), r_kappa(2 * alpha)
        assert r >= 4.5 * alpha and rp >= alpha
        tup = row_tuples(mu, 2)
        w2 = [prod_weights(m[j], 2) for j in range(3)]
        for _ in range(per_mu):
            f = perturbed(gps, 9)
            delta = err(f, tup)
            dist = np.stack([(gps[:, j, :] != f[j]) @ w2[j] for j in range(3)], axis=1).max(axis=1).min()
            if delta == 0:
                assert dist < 1e-12
                continue
            bound = 3e7 * alpha ** -1.5 * delta ** (r * rp / 4)
            assert dist <= bound
            worst["thm861b"] = max(worst["thm861b"], dist / bound)
    for k in ("theta_nu12", "rhc_nu12"):
        assert worst[k] >= 1 - 1e-9, (k, worst[k])
    return worst, nonunif3


def check_step5(gps1, gps2, n_mu=12, per_mu=80):
    """(7a) Step 5 for full-support mu (general, and with two uniform marginals), exact for n = 1, 2."""
    worst = {"S": 0.0, "rhc_pq": 0.0, "pq_gamma": 0.0, "min_dc": 0.0, "rhc_mu_lm": np.inf}
    for t in range(n_mu):
        mu = random_mu(True, two_only=True) if t % 3 == 0 else random_mu(False)
        alpha = mu.min()
        rp = r_kappa(2 * alpha)
        for l, m_ in ((0, 1), (0, 2), (1, 2)):
            if t < 4:
                worst["rhc_mu_lm"] = min(worst["rhc_mu_lm"], check_rhc(pair_marg(mu, l, m_), 2 * alpha, trials=8))
        for n, gps in ((1, gps1), (2, gps2)):
            N = 3 ** n
            tup = row_tuples(mu, n)
            cols, ws = tup[:3], tup[3]
            wj = [prod_weights(single_marg(mu, j), n) for j in range(3)]
            for _ in range(per_mu):
                f = perturbed(gps, N)
                delta = err(f, tup)
                for j in range(3):
                    probs = [wj[j][f[j] == v].sum() for v in range(3)]
                    u, eps = int(np.argmax(probs)), max(0.0, 1 - max(probs))
                    l, m_ = [i for i in range(3) if i != j]
                    fl, fm = f[l][cols[l]], f[m_][cols[m_]]
                    S = ws[(fl + fm + u) % 3 == 0].sum()
                    assert S <= delta + eps + 1e-12
                    if delta + eps > 1e-9:
                        worst["S"] = max(worst["S"], S / (delta + eps))
                    gamma = (delta + eps) ** rp
                    for s in range(3):
                        tgt = (-u - s) % 3
                        ps, qs = wj[l][f[l] == s].sum(), wj[m_][f[m_] == tgt].sum()
                        joint = ws[(fl == s) & (fm == tgt)].sum()
                        assert ps * qs <= joint ** rp + 1e-12 and ps * qs <= gamma + 1e-12
                        if 1e-9 < ps * qs < 1 - 1e-9:  # pq = 1 is the trivial equality case
                            worst["rhc_pq"] = max(worst["rhc_pq"], ps * qs / joint ** rp)
                            worst["pq_gamma"] = max(worst["pq_gamma"], ps * qs / gamma)
                    md = min(dc_w(f[l], wj[l]), dc_w(f[m_], wj[m_]))
                    assert md <= 2 * np.sqrt(gamma) + 1e-12
                    if md > 1e-9:
                        worst["min_dc"] = max(worst["min_dc"], md / (2 * np.sqrt(gamma)))
    assert worst["rhc_mu_lm"] >= 1 - 1e-9
    return worst


def EL_D(f, n, nj, sigma):
    """E_L D_j(L): L contains each coordinate w.p. sigma; free entries uniform, fixed ones nu_j."""
    pts = np.array(list(itertools.product(range(3), repeat=n)))
    tot = 0.0
    D = {}
    for k in range(n + 1):
        for L in itertools.combinations(range(n), k):
            Lc = [i for i in range(n) if i not in L]
            DL = 0.0
            for rho in itertools.product(range(3), repeat=len(Lc)):
                mask = np.all(pts[:, Lc] == np.array(rho, dtype=int), axis=1) if Lc else np.ones(len(pts), bool)
                DL += np.prod(nj[list(rho)]) * dc_fun(f[mask])
            D[L] = DL
            tot += sigma ** k * (1 - sigma) ** (n - k) * DL
    return tot, D


def check_noise_general(n_mu=10, trials=30):
    """(7b) Remark 8.63(b): the coupling sigma u(x)u + (1-sigma) diag(nu_j) of mu_j with itself is PSD
    with spectral gap >= 4 sigma/9, and E_L D_j(L) >= (2 sigma/9) dc(f_j) for non-uniform mu_j."""
    worst_gap, worst_noise = np.inf, np.inf
    for t in range(n_mu):
        mu = random_mu(False)
        alpha = mu.min()
        sigma = 9 * alpha
        nu = (mu - sigma / 18) / (1 - sigma)
        assert nu.min() >= alpha / 2 - 1e-15
        for j in range(3):
            mj, nj = single_marg(mu, j), single_marg(nu, j)
            J = sigma * np.full((3, 3), 1 / 9) + (1 - sigma) * np.diag(nj)
            assert np.allclose(J, J.T) and np.allclose(J.sum(axis=1), mj)
            Dm = np.diag(mj ** -0.5)
            ev = np.linalg.eigvalsh(Dm @ J @ Dm)
            assert ev[0] >= -1e-12 and abs(ev[-1] - 1) < 1e-12
            gap = 1 - ev[-2]
            assert gap >= 4 * sigma / 9 - 1e-12
            worst_gap = min(worst_gap, gap / (4 * sigma / 9))
        j = t % 3
        mj, nj = single_marg(mu, j), single_marg(nu, j)
        for n in (1, 2, 3):
            wmu = prod_weights(mj, n)
            for _ in range(trials):
                f = rng.integers(0, 3, size=3 ** n)
                if rng.random() < 0.6:
                    f = np.where(rng.random(3 ** n) < rng.uniform(0.02, 0.4), f, rng.integers(3))
                d = dc_w(f, wmu)
                el, _ = EL_D(f, n, nj, sigma)
                assert el >= 2 * sigma / 9 * d - 1e-12
                if d > 1e-9:
                    worst_noise = min(worst_noise, el / (2 * sigma / 9 * d))
    return worst_gap, worst_noise


def nonmonotone_example(alpha=0.01, j=0):
    """For a non-uniform marginal, D_j need not be monotone in L (so Harris's inequality is unavailable)."""
    mu = np.array([alpha if p[j] != 0 else (1 - 12 * alpha) / 6 for p in P])
    assert abs(mu.sum() - 1) < 1e-12 and abs(mu.min() - alpha) < 1e-15
    sigma = 9 * alpha
    nj = single_marg((mu - sigma / 18) / (1 - sigma), j)
    f = np.array([w1 if w2 == 0 else 0 for w1, w2 in itertools.product(range(3), repeat=2)])
    _, D = EL_D(f, 2, nj, sigma)
    assert D[(0,)] > D[(0, 1)] + 0.3
    return D[(0,)], D[(0, 1)]


def mu_alpha(a):
    return np.array([a if p[1] == p[2] else (1 - 6 * a) / 12 for p in P])


def check_prop862(gps1, gps2):
    """(8) Proposition 8.62."""
    rows = []
    for a in (1 / 18, 0.04, 0.02, 0.005, 1e-4):
        mu = mu_alpha(a)
        assert abs(mu.sum() - 1) < 1e-12 and abs(mu.min() - a) < 1e-15
        assert all(np.allclose(single_marg(mu, j), 1 / 3) for j in range(3))
        if a == 1 / 18:
            assert np.allclose(mu, 1 / 18)
        for k in (1, 2, 3):
            N = 3 ** k
            f = np.zeros((3, N), dtype=np.int64)
            f[1, 0] = 1
            f[2] = 1
            f[2, 0] = 2
            assert abs(err(f, row_tuples(mu, k)) - (2 * a) ** k) < 1e-15
            if k <= 2:
                gps = gps1 if k == 1 else gps2
                w = prod_weights(np.full(3, 1 / 3), k)
                dist = np.stack([(gps[:, j, :] != f[j]) @ w for j in range(3)], axis=1).max(axis=1).min()
                assert abs(dist - 3.0 ** -k) < 1e-12
        lo, hi = r_kappa(9 * a) / 2, np.log(3) / np.log(1 / (2 * a))
        assert 4 * a <= lo <= hi
        rows.append((a, lo, hi))
    return rows


if __name__ == "__main__":
    st = check_distributions()
    print("(1)-(2),(4) distributions: min ratios (all must be >= 1):",
          {k: round(float(v), 4) for k, v in st.items()})
    print("(3) monotonicity of D_j(L): ok; min of E_L D_j / ((sigma/3) dc(f_j)) =", round(check_monotone_noise(), 4))
    gps = exact_gps_n2()
    order = np.argsort([1 if all(len(set(r)) == 3 for r in g) else 0 for g in gps], kind="stable")
    gps = gps[order]  # 13788 of type (A) first, then the 36 of type (B)
    assert all(all(len(set(r)) == 3 for r in g) for g in gps[-36:])
    w = check_theorem_n2(gps)
    lem = f"{w['lem860']:.4f}" if w["lem860"] > 0 else "n/a (no instance with 0 < dist_B <= alpha for n = 2)"
    print("(5) n=2: max dist/bound(Thm 8.61) =", f"{w['thm861']:.3e}", "; max dist/sqrt(delta) (uniform marginals) =",
          f"{w['sqrt']:.4f}", "; Lemma 8.60(b):", lem)
    wb, nonunif3 = check_theorem_b_n2(gps)
    print("(6) Thm 8.61(b), mu_1, mu_2 uniform (mu_3 non-uniform for", nonunif3, "of 6 mu): decomposition ok;",
          "min K/(9 alpha P) for nu_12 =", round(float(wb["theta_nu12"]), 4), "; min RHC ratio (kappa = 9 alpha) =",
          round(float(wb["rhc_nu12"]), 4), "; n=2: max dist/bound =", f"{wb['thm861b']:.3e}")
    gps1 = exact_gps_n1()
    s5 = check_step5(gps1, gps)
    print("(7a) Step 5, n = 1, 2: max S/(delta+eps') =", round(s5["S"], 4), "; max p_s q_s / Pr[both]^r' =",
          round(s5["rhc_pq"], 4), "; max p_s q_s / gamma =", round(s5["pq_gamma"], 4),
          "; max min(dc f_l, dc f_m)/(2 sqrt(gamma)) =", round(s5["min_dc"], 4),
          "; min RHC ratio for mu_lm (kappa = 2 alpha) =", f"{s5['rhc_mu_lm']:.3g}")
    g_gap, g_noise = check_noise_general()
    d1, d12 = nonmonotone_example()
    print("(7b) non-uniform mu_j: T PSD; min gap/(4 sigma/9) =", round(float(g_gap), 4),
          "; min E_L D_j / ((2 sigma/9) dc(f_j)) =", round(float(g_noise), 4),
          f"; D_j need not be monotone: D_j({{1}}) = {d1:.4f} > D_j({{1,2}}) = {d12:.4f}")
    rows = check_prop862(gps1, gps)
    print("(8) Prop 8.62: mu^(alpha) ok; err = (2 alpha)^k (k <= 3), dist = 3^-k (k <= 2); exponent brackets",
          "[r_{9 alpha}/2, log 3/log(1/(2 alpha))]:", ", ".join(f"alpha={a:.4g}: [{lo:.4f}, {hi:.4f}]" for a, lo, hi in rows))
    print("ALL CHECKS PASSED")
