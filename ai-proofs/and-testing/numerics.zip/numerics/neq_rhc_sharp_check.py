"""Checks for the inequality (S_kappa) of Proposition prop:rhcsharp and Remark rem:rhcsharp (after Proposition 8.82).

(S_kappa): for 0 < kappa < 1 and phi, psi: Z_3 -> [0, oo), under the uniform measure,
    (1 - kappa) E[phi psi] + kappa E[phi] E[psi] >= ||phi||_kappa ||psi||_kappa.
It is proved in the paper for 0 < kappa <= 1/2 on every probability space (check (P) tests the steps of that proof);
for 1/2 < kappa < 1 it is a conjecture, and checks (S), (G) are numerical evidence only.

 (S) uniform Z_3: multistart L-BFGS-B over log phi, log psi (6 parameters, values down to e^-40, so functions that
     nearly vanish are included) of log LHS - log RHS, for kappa in [1e-3, 0.99]. Minimum should be >= -1e-10
     (round-off). Power check: with the exponent 1.02 kappa in place of kappa the same search must find violations.
 (G) the one-function (dual) form ||(1 - kappa) Z + kappa E Z||_{-kappa/(1 - kappa)} >= ||Z||_kappa on spaces with
     2, 3 or 4 points and arbitrary weights (grid over two-point laws, random and optimized 3- and 4-point laws),
     equivalent to (S_kappa) on that space by reverse Hoelder; minimum gap should be >= -1e-10.
 (P) the proof for 0 < kappa <= 1/2 (every probability space): Hoelder step, symmetrisation
     E V^beta E V^-beta = E cosh(beta Z), cosh(beta z) - 1 <= beta^2 (cosh z - 1), Bernoulli, the dual and primal
     forms, on random finite spaces with arbitrary weights (see check_P).
 (B) the Birkhoff step: for random pair laws nu on Z_3^2 with uniform marginals (rational, built by exact Sinkhorn-free
     construction) and kappa = 9 min nu, the matrix 3(nu - kappa/9)/(1 - kappa) is doubly stochastic and is decomposed
     exactly (Fractions) into permutation matrices; the mixture of the simple couplings composed with the
     permutations reproduces nu exactly. Then E_{nu^(x)N}[Phi Psi] >= ||Phi||_kappa ||Psi||_kappa is tested for N = 1, 2
     on random nonnegative functions (consistent with the conjecture; floating point).
"""
import itertools
import random
from fractions import Fraction

import numpy as np
from scipy.optimize import minimize

rng = np.random.default_rng(20261022)
KAPPAS = [1e-3, 0.01, 0.05, 0.1, 0.2, 0.3, 0.5, 0.7, 0.9, 0.99]


def gap_S(x, kappa, p):
    """log LHS - log RHS of (S) with exponent p on uniform Z_3, x = (log phi, log psi)."""
    phi, psi = np.exp(x[:3]), np.exp(x[3:])
    lhs = (1 - kappa) * np.mean(phi * psi) + kappa * np.mean(phi) * np.mean(psi)
    lr = (np.log(np.mean(phi ** p)) + np.log(np.mean(psi ** p))) / p
    return np.log(lhs) - lr


def search_S(kappa, p, starts=300):
    best = np.inf
    for t in range(starts):
        scale = [0.01, 0.3, 1.0, 3.0, 10.0][t % 5]
        x0 = rng.normal(size=6) * scale
        if t % 7 == 0:
            x0[rng.integers(6)] -= 20
        res = minimize(gap_S, x0, args=(kappa, p), method="L-BFGS-B", bounds=[(-40, 40)] * 6)
        best = min(best, res.fun, gap_S(x0, kappa, p))
    return best


def check_S():
    out = []
    for kappa in KAPPAS:
        g = search_S(kappa, kappa)
        assert g >= -1e-10, (kappa, g)
        gp = search_S(kappa, min(1.02 * kappa, 0.999999), starts=100)
        assert gp < -1e-9, (kappa, gp)
        out.append(f"kappa={kappa}: min {g:.1e}, at 1.02kappa {gp:.1e}")
    print("(S) uniform Z_3, (S_kappa):", "; ".join(out), ": ok (no violation at kappa; violations at 1.02 kappa)")


def gap_D(z, w, kappa):
    """log ||(1-k)Z + k||_{-beta} - log ||Z||_k for Z normalised to mean 1 (beta = k/(1-k))."""
    beta = kappa / (1 - kappa)
    z = z / np.sum(w * z)
    W = (1 - kappa) * z + kappa
    lq = -np.log(np.sum(w * W ** (-beta))) / beta
    zk = np.where(z > 0, np.abs(z) ** kappa, 0.0)
    return lq - np.log(np.sum(w * zk)) / kappa


def check_G():
    out = []
    for kappa in KAPPAS:
        mn = np.inf
        for lw in np.linspace(-10, 10, 161):
            w1 = 1 / (1 + np.exp(-lw))
            w = np.array([w1, 1 - w1])
            for lz in np.linspace(-25, 25, 201):
                mn = min(mn, gap_D(np.array([np.exp(lz), 1.0]), w, kappa))
            mn = min(mn, gap_D(np.array([0.0, 1.0]), w, kappa))
        for t in range(4000):
            k = 3 + (t % 2)
            w = rng.dirichlet(np.ones(k) * [0.05, 0.3, 1, 5][t % 4])
            w = np.maximum(w, 1e-300)
            w = w / w.sum()
            z = np.exp(rng.normal(size=k) * [0.01, 0.3, 2, 8][(t // 4) % 4])
            if t % 5 == 0:
                z[0] = 0.0
            mn = min(mn, gap_D(z, w, kappa))
            if t % 20 == 0:
                lw0 = np.log(w)
                f = lambda y: gap_D(np.exp(y[:k]), np.exp(y[k:]) / np.exp(y[k:]).sum(), kappa)
                res = minimize(f, np.concatenate([np.log(np.maximum(z, 1e-12)), lw0]), method="L-BFGS-B",
                               bounds=[(-30, 30)] * (2 * k))
                mn = min(mn, res.fun)
        assert mn >= -1e-10, (kappa, mn)
        out.append(f"kappa={kappa}: {mn:.1e}")
    print("(G) dual form on 2-, 3-, 4-point spaces with arbitrary weights, min gap:", "; ".join(out), ": ok")


PERMS = list(itertools.permutations(range(3)))


def birkhoff(D):
    """Exact Birkhoff-von Neumann decomposition of a 3x3 doubly stochastic matrix of Fractions."""
    D = [row[:] for row in D]
    parts = []
    while any(D[i][j] != 0 for i in range(3) for j in range(3)):
        for pi in PERMS:
            lam = min(D[i][pi[i]] for i in range(3))
            if lam > 0:
                break
        else:
            raise AssertionError("no positive permutation")
        for i in range(3):
            D[i][pi[i]] -= lam
        parts.append((lam, pi))
    return parts


def random_uniform_marginal_law(rs):
    """Random rational 3x3 law with uniform marginals: a random mixture of the six permutation laws plus noise
    along the zero-sum 2x2 directions, kept positive."""
    lam = [Fraction(rs.randint(0, 50), 1) for _ in PERMS]
    if sum(lam) == 0:
        lam[0] = Fraction(1)
    tot = sum(lam)
    nu = [[Fraction(0)] * 3 for _ in range(3)]
    for l, pi in zip(lam, PERMS):
        for i in range(3):
            nu[i][pi[i]] += l / tot / 3
    # add a uniform part so that the law has full support
    eps = Fraction(rs.randint(1, 100), 1000)
    nu = [[(1 - eps) * nu[i][j] + eps / 9 for j in range(3)] for i in range(3)]
    return nu


def check_B():
    rs = random.Random(7)
    cnt, worst = 0, np.inf
    for _ in range(300):
        nu = random_uniform_marginal_law(rs)
        assert all(sum(nu[i]) == Fraction(1, 3) for i in range(3))
        assert all(sum(nu[i][j] for i in range(3)) == Fraction(1, 3) for j in range(3))
        kappa = 9 * min(min(r) for r in nu)
        assert 0 < kappa < 1
        D = [[3 * (nu[i][j] - kappa / 9) / (1 - kappa) for j in range(3)] for i in range(3)]
        assert all(x >= 0 for r in D for x in r)
        assert all(sum(r) == 1 for r in D) and all(sum(D[i][j] for i in range(3)) == 1 for j in range(3))
        parts = birkhoff(D)
        assert sum(l for l, _ in parts) == 1
        rec = [[Fraction(0)] * 3 for _ in range(3)]
        for l, pi in parts:
            for i in range(3):
                for j in range(3):
                    rec[i][j] += l * (kappa / 9 + (1 - kappa) * Fraction(int(pi[i] == j), 3))
        assert rec == nu
        cnt += 1
        P = np.array([[float(x) for x in r] for r in nu])
        k = float(kappa)
        for N in (1, 2):
            PN = P if N == 1 else np.kron(P, P)
            for t in range(40):
                sc = [0.3, 2, 8][t % 3]
                Phi = np.exp(rng.normal(size=3 ** N) * sc)
                Psi = np.exp(rng.normal(size=3 ** N) * sc)
                if t % 4 == 0:
                    Phi[rng.integers(3 ** N)] = 0.0
                lhs = Phi @ PN @ Psi
                px, py = PN.sum(axis=1), PN.sum(axis=0)
                rhs = (px @ Phi ** k) ** (1 / k) * (py @ Psi ** k) ** (1 / k)
                worst = min(worst, np.log(lhs) - np.log(rhs))
    assert worst >= -1e-10, worst
    print(f"(B) {cnt} rational laws with uniform marginals, kappa = 9 min nu: exact Birkhoff decomposition of"
          f" 3(nu - kappa/9)/(1 - kappa) reproduces nu as a mixture of simple couplings composed with permutations;"
          f" E[Phi Psi] >= ||Phi||_kappa ||Psi||_kappa for N = 1, 2 pairs (min log-ratio {worst:.1e}): ok")


def check_P():
    """The proof of (S_kappa) for 0 < kappa <= 1/2 on every probability space (Proposition prop:rhcsharp(a)).
    With beta = kappa/(1 - kappa) <= 1, E psi = 1, V = (1 - kappa) psi + kappa, H = E[1/V], h = H - 1:
      (1) Hoelder: E psi^kappa <= (E[psi/V])^kappa (E V^beta)^(1 - kappa), and E[psi/V] = 1 - beta h >= 0;
      (2) symmetrisation: E V^beta E V^-beta = E cosh(beta Z), H = E cosh Z, Z = log V - log V' (V' an independent
          copy), both computed as double sums over pairs of atoms;
      (3) cosh(beta z) - 1 <= beta^2 (cosh z - 1) (also on a grid of (beta, z));
      (4) Bernoulli: (1 - beta h)^beta <= 1 - beta^2 h, so (1 - beta h)^beta (1 + beta^2 h) <= 1 - beta^4 h^2 <= 1;
    and the conclusions E psi^kappa (E V^-beta)^(1 - kappa) <= 1 and the primal form (S_kappa)."""
    for beta in np.linspace(0.001, 1, 400):
        z = np.linspace(-60, 60, 4001)
        assert np.all(np.cosh(beta * z) - 1 <= beta ** 2 * (np.cosh(z) - 1) * (1 + 1e-12) + 1e-300)
    kappas = [1e-3, 0.01, 0.05, 0.1, 0.2, 0.3, 0.4, 0.45, 0.5]
    worst_dual, worst_primal, cnt = np.inf, np.inf, 0
    for kappa in kappas:
        beta = kappa / (1 - kappa)
        for t in range(6000):
            n = int(rng.integers(2, 8))
            w = rng.dirichlet(np.ones(n) * [0.1, 1, 5][t % 3])
            psi = np.exp(rng.normal(size=n) * [0.1, 1, 4, 10][(t // 3) % 4])
            phi = np.exp(rng.normal(size=n) * [0.1, 1, 4][(t // 12) % 3])
            if t % 5 == 0:
                psi[0] = 0.0
            if t % 7 == 0:
                phi[-1] = 0.0
            psi = psi / np.sum(w * psi)
            V = (1 - kappa) * psi + kappa
            H = np.sum(w / V)
            h = H - 1
            epk = np.sum(w * psi ** kappa)
            m_plus, m_minus = np.sum(w * V ** beta), np.sum(w * V ** (-beta))
            r = np.sum(w * psi / V)
            assert h >= -1e-12 and abs(r - (1 - beta * h)) <= 1e-12 * (1 + beta * H) and r >= -1e-12
            assert epk <= r ** kappa * m_plus ** (1 - kappa) * (1 + 1e-12)
            Z = np.log(V)[:, None] - np.log(V)[None, :]
            ww = w[:, None] * w[None, :]
            assert abs(np.sum(ww * np.cosh(beta * Z)) - m_plus * m_minus) <= 1e-11 * m_plus * m_minus
            assert abs(np.sum(ww * np.cosh(Z)) - H) <= 1e-11 * H
            assert m_plus * m_minus <= (1 + beta ** 2 * h) * (1 + 1e-12)
            x = min(max(beta * h, 0.0), 1.0)
            assert (1 - x) ** beta <= 1 - beta * x + 1e-12
            assert (1 - x) ** beta * (1 + beta ** 2 * h) <= 1 + 1e-12
            dual = epk * m_minus ** (1 - kappa)
            assert dual <= 1 + 1e-12
            worst_dual = min(worst_dual, 1 - dual)
            lhs = (1 - kappa) * np.sum(w * phi * psi) + kappa * np.sum(w * phi) * np.sum(w * psi)
            rhs = np.sum(w * phi ** kappa) ** (1 / kappa) * epk ** (1 / kappa)
            if rhs > 0:
                with np.errstate(over="ignore"):
                    worst_primal = min(worst_primal, lhs / rhs)
            cnt += 1
    assert worst_primal >= 1 - 1e-10
    print(f"(P) proof of (S_kappa) for kappa in {kappas} on {cnt} random spaces with 2..7 points and arbitrary"
          f" weights: Hoelder step, E V^beta E V^-beta = E cosh(beta Z) <= 1 + beta^2 h, H = E cosh Z,"
          f" cosh(beta z) - 1 <= beta^2 (cosh z - 1) (grid), Bernoulli; dual form <= 1 (min slack {worst_dual:.1e}),"
          f" primal ratio >= 1 (min {worst_primal:.15f}): ok")


if __name__ == "__main__":
    check_P()
    check_B()
    check_S()
    check_G()
    print("ALL CHECKS PASSED")
