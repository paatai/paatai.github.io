#!/usr/bin/env python3
"""Certified (ball arithmetic, python-flint/Arb) value of the Gaussian limit of the two-band family.

f_n(x) = 1 iff |x| >= n/2, or n/4 + u0*sqrt(n)/4 <= |x| <= n/4 + u1*sqrt(n)/4   (Proposition 7.4 of the PDF;
Proposition 7a of MAIN_RESULT.md).

With X, Y, V iid N(0,1) and U = X + Y + V:
  mu      -> 1/2,
  Pr[f(x&y) = 1]                 -> P_U  = Phi(u1/sqrt3) - Phi(u0/sqrt3),
  Pr[f(x) = f(y) = f(x&y) = 1]   -> P_3  = Pr[X >= 0, Y >= 0, u0 <= U <= u1]
                                        = int_0^oo q(s) (Phi(u1 - s) - Phi(u0 - s)) ds,
  where q(s) = exp(-s^2/4) erf(s/2) / (2 sqrt(pi)) is the density of X + Y on {X >= 0, Y >= 0}.
  eps -> 1/4 + P_U - 2 P_3 and dist -> 1/2, so dist^2/eps -> R = (1/4) / (1/4 + P_U - 2 P_3).

The integrand is >= 0, so the Arb integral over [0, S] is a rigorous lower bound for P_3,
and R_low = (1/4) / (1/4 + P_U - 2 P_3[0,S]) is a rigorous lower bound for R.
The tail int_S^oo q <= erfc(S/2)/2 gives a rigorous upper bound too.

The band ends u0, u1 are exact rationals (fmpq), e.g. u0 = 157/100, u1 = 12, and enter the computation as
Arb balls that contain them (radius about 1e-60), never as binary floating-point numbers.
"""
from flint import acb, arb, ctx, fmpq

ctx.prec = 200


def Phi(t):
    return (1 + (t / arb(2).sqrt()).erf()) / 2


def ball(u):
    """An Arb ball containing the exact rational u (an fmpq or an int)."""
    assert isinstance(u, (fmpq, int))
    b = arb(fmpq(u))
    assert b.contains(fmpq(u))
    return b


def P3_lower(u0, u1, S):
    a0, a1 = acb(ball(u0)), acb(ball(u1))

    def f(s, analytic):
        a2 = acb(2)
        e = lambda z: (1 + (z / a2.sqrt()).erf()) / 2
        return (-(s * s) / 4).exp() * (s / 2).erf() / (2 * acb.pi().sqrt()) * (e(a1 - s) - e(a0 - s))

    val = acb.integral(f, 0, S)
    return val.real


def R_bounds(u0, u1, S=30):
    PU = Phi(ball(u1) / arb(3).sqrt()) - Phi(ball(u0) / arb(3).sqrt())
    P3 = P3_lower(u0, u1, S)
    tail = (arb(S) / 2).erfc() / 2
    eps_hi = arb(1) / 4 + PU - 2 * P3
    eps_lo = arb(1) / 4 + PU - 2 * (P3 + tail)
    return PU, P3, eps_lo, eps_hi, (arb(1) / 4) / eps_hi, (arb(1) / 4) / eps_lo


if __name__ == "__main__":
    best = None
    for k in range(-40, 41):
        u0 = fmpq(160 + k, 100)
        PU, P3, elo, ehi, Rlo, Rhi = R_bounds(u0, 12, S=20)
        v = float(Rlo.mid())
        if best is None or v > best[0]:
            best = (v, u0)
    print("scan over u0 = j/100 (u1 = 12): best u0 = %s, R ~ %.6f" % (best[1], best[0]))
    assert best[1] == fmpq(157, 100)
    for u0, u1 in [(fmpq(157, 100), 12), (fmpq(162, 100), 12), (fmpq(8, 5), 10)]:
        PU, P3, elo, ehi, Rlo, Rhi = R_bounds(u0, u1, S=30)
        print(f"u0={u0}, u1={u1} (exact rationals, enclosed in Arb balls):")
        print("  P_U =", PU.str(15, radius=True))
        print("  P_3 (over [0,30], lower bound) =", P3.str(15, radius=True))
        print("  eps limit in", elo.str(12), ehi.str(12))
        print("  R in [", Rlo.str(12, radius=True), ",", Rhi.str(12, radius=True), "]")
        print("  certified: R > 1.351:", bool(Rlo > arb("1.351")), " sqrt(R) > 1.1623:", bool(Rlo.sqrt() > arb("1.1623")))
