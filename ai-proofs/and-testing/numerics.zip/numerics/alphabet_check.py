"""Exact small-n checks for the larger-alphabet extension (Section 8.9 of MAIN_RESULT).

Checks, by exact enumeration (no sampling inside an instance):
  (1) single-coordinate Gibbs output kernels Q_j, (1b) block kernels Q_J: stochastic, reversible, PSD,
      irreducible when the corresponding graph is connected (used by an earlier version of Lemma 8.51)
  (2) rounding and noise (Lemma 8.47 (a)-(c))
  (3) the junta lemma with full resampling of column j for g = min, mult mod 3 (insensitive context 0)
  (5) alternating projections (Lemma 8.49): c_j < 1 for trees and forests, ||M^{(x)2} - E^{(x)2}|| = c_j,
      ||h - E^P_T h|| <= sum_e ||h - P_e^S h|| / (1 - c_j)
  (3*) the junta lemma (Lemma 8.50), one latent decomposition per forest edge e with context u_e and
      W moving the entries in R by p_e: containment, the conditional identity, reverse hypercontractivity,
      Jensen, (8.10), the combined bound for E^j_T, and Lemma 8.47(d) for pl_G
  (4) Lemma 8.52 (propagation from f_0 to every column)
  (4b) the component kernel Q of Lemma 8.48 (reversible, PSD, lambda_* < 1 under (H)) and Lemma 8.51
"""
import itertools
import math
import random
import sys

import numpy as np

TOL = 1e-10


def r_of(kappa):
    s = math.sqrt(1.0 - kappa)
    return 2.0 * (1.0 - s) / (2.0 - s)


def random_dist(size, rng, floor=0.05):
    w = np.array([rng.gammavariate(1.0, 1.0) for _ in range(size)]) + floor
    return w / w.sum()


def g_min(x):
    return min(x)


def make_mult(q):
    def g(x):
        p = 1
        for a in x:
            p = (p * a) % q
        return p
    return g


def make_random_g(q, m, rng):
    table = {x: rng.randrange(q) for x in itertools.product(range(q), repeat=m)}
    return lambda x: table[tuple(x)]


def insert(u, j, a):
    u = list(u)
    return tuple(u[:j] + [a] + u[j:])


# ---------------------------------------------------------------- kernel
def kernel(g, mu, q, m, j):
    """Return (Sigma_0 list, mu_0, Q_j) for the Gibbs resampling of coordinate j."""
    pts = list(itertools.product(range(q), repeat=m))
    S0 = sorted({g(x) for x in pts})
    idx = {y: i for i, y in enumerate(S0)}
    joint = np.zeros((len(S0), len(S0)))
    for u in itertools.product(range(q), repeat=m - 1):
        w = np.array([mu[insert(u, j, a)] for a in range(q)])
        tot = w.sum()
        for a in range(q):
            for b in range(q):
                joint[idx[g(insert(u, j, a))], idx[g(insert(u, j, b))]] += w[a] * w[b] / tot
    mu0 = joint.sum(axis=1)
    Q = joint / mu0[:, None]
    return S0, mu0, Q, joint


def graph_connected(g, q, m, j, S0):
    adj = {y: set() for y in S0}
    for u in itertools.product(range(q), repeat=m - 1):
        vals = {g(insert(u, j, a)) for a in range(q)}
        for y in vals:
            adj[y] |= vals - {y}
    seen, stack = {S0[0]}, [S0[0]]
    while stack:
        y = stack.pop()
        for z in adj[y]:
            if z not in seen:
                seen.add(z)
                stack.append(z)
    return len(seen) == len(S0), adj


def lam_of(Q, pi):
    D = np.sqrt(pi)
    A = (D[:, None] * Q) / D[None, :]
    A = (A + A.T) / 2
    ev = np.sort(np.linalg.eigvalsh(A))
    return ev, (ev[-2] if len(ev) > 1 else 0.0)


def check_kernel(rng, trials=400):
    worst_rev = worst_psd = 0.0
    nconn = 0
    for t in range(trials):
        q = rng.choice([2, 3, 4])
        m = rng.choice([2, 3]) if q <= 3 else 2
        kind = t % 3
        g = g_min if kind == 0 else (make_mult(q) if kind == 1 else make_random_g(q, m, rng))
        pts = list(itertools.product(range(q), repeat=m))
        p = random_dist(len(pts), rng)
        mu = dict(zip(pts, p))
        for j in range(m):
            S0, mu0, Q, joint = kernel(g, mu, q, m, j)
            assert np.allclose(Q.sum(axis=1), 1.0)
            worst_rev = max(worst_rev, np.abs(joint - joint.T).max())
            ev, lam = lam_of(Q, mu0)
            worst_psd = min(worst_psd, ev[0])
            conn, adj = graph_connected(g, q, m, j, S0)
            for a, y in enumerate(S0):
                for b, z in enumerate(S0):
                    if a != b:
                        assert (Q[a, b] > 1e-14) == (z in adj[y]), "positivity pattern"
            if conn:
                nconn += 1
                assert lam < 1 - 1e-9, "lambda < 1 for connected G_j"
    assert worst_rev < TOL and worst_psd > -TOL
    print(f"(1) kernel: {trials} instances; max |reversibility defect| = {worst_rev:.1e}, "
          f"min eigenvalue = {worst_psd:.1e} (>= 0), positivity pattern = G_j, lambda < 1 on {nconn} connected cases: OK")


def block_kernel(g, mu, q, m, J):
    """(Sigma_0, mu_0, Q_J, joint) for the Gibbs resampling of the block J."""
    pts = list(itertools.product(range(q), repeat=m))
    S0 = sorted({g(x) for x in pts})
    idx = {y: i for i, y in enumerate(S0)}
    joint = np.zeros((len(S0), len(S0)))
    rest = [k for k in range(m) if k not in J]
    groups = {}
    for x in pts:
        groups.setdefault(tuple(x[k] for k in rest), []).append(x)
    for u, xs in groups.items():
        w = np.array([mu[x] for x in xs])
        tot = w.sum()
        for a, x in enumerate(xs):
            for b, x2 in enumerate(xs):
                joint[idx[g(x)], idx[g(x2)]] += w[a] * w[b] / tot
    mu0 = joint.sum(axis=1)
    return S0, mu0, joint / mu0[:, None], joint


def check_block_kernel(rng, trials=300):
    worst_rev = worst_psd = 0.0
    nconn = 0
    for t in range(trials):
        q = rng.choice([2, 3])
        m = 3
        g = [g_min, make_mult(q), make_random_g(q, m, rng)][t % 3]
        pts = list(itertools.product(range(q), repeat=m))
        mu = dict(zip(pts, random_dist(len(pts), rng)))
        J = [k for k in range(m) if rng.random() < 0.6] or [0]
        S0, mu0, Q, joint = block_kernel(g, mu, q, m, J)
        assert np.allclose(Q.sum(axis=1), 1.0)
        worst_rev = max(worst_rev, np.abs(joint - joint.T).max())
        ev, lam = lam_of(Q, mu0)
        worst_psd = min(worst_psd, ev[0])
        adj = {y: set() for y in S0}
        for j in J:
            _, a = graph_connected(g, q, m, j, S0)
            for y in S0:
                adj[y] |= a[y]
        seen, stack = {S0[0]}, [S0[0]]
        while stack:
            y = stack.pop()
            for z in adj[y]:
                if z not in seen:
                    seen.add(z)
                    stack.append(z)
        if len(seen) == len(S0):
            nconn += 1
            assert lam < 1 - 1e-9, "lambda_J < 1 when G_J is connected"
    assert worst_rev < TOL and worst_psd > -TOL
    print(f"(1b) block kernel Q_J: {trials} instances (m=3, random J); max |reversibility defect| = {worst_rev:.1e}, "
          f"min eigenvalue = {worst_psd:.1e}, lambda_J < 1 on {nconn} cases with G_J connected: OK")


# ---------------------------------------------------------------- rounding / noise
def avg_out(arr, axes, pi):
    """Average arr (n-dim, each axis of size len(pi)) over the given axes, keep dims."""
    out = arr
    for ax in axes:
        out = np.tensordot(out, pi, axes=([ax], [0]))
        out = np.expand_dims(out, ax)
    return out


def es_norms(h, n, pi):
    """||h^{=S}||^2 for all S (Efron-Stein w.r.t. pi^{otimes n})."""
    w = pi
    for _ in range(n - 1):
        w = np.multiply.outer(w, pi)
    cond = {}
    for S in itertools.chain.from_iterable(itertools.combinations(range(n), k) for k in range(n + 1)):
        cond[S] = np.broadcast_to(avg_out(h, [i for i in range(n) if i not in S], pi), h.shape)
    norms = {}
    for S in cond:
        comp = np.zeros(h.shape)
        for k in range(len(S) + 1):
            for U in itertools.combinations(S, k):
                comp = comp + (-1) ** (len(S) - k) * cond[U]
        norms[S] = float((w * comp ** 2).sum())
    return norms, w


def plurality(h, T, n, pi, L):
    """pl_T h as an array (ties broken towards the smallest label)."""
    shape = h.shape
    other = [i for i in range(n) if i not in T]
    m = np.stack([np.broadcast_to(avg_out((h == c).astype(float), other, pi), shape) for c in range(L)])
    return np.argmax(m - 1e-13 * np.arange(L)[:, None].reshape((L,) + (1,) * n), axis=0)


def check_rounding(rng, trials=300):
    worst_a = worst_b = worst_c = -math.inf
    for t in range(trials):
        q = rng.choice([2, 3])
        m = 2
        g = g_min if t % 2 == 0 else make_mult(q)
        pts = list(itertools.product(range(q), repeat=m))
        mu = dict(zip(pts, random_dist(len(pts), rng)))
        S0, pi, Q, joint = kernel(g, mu, q, m, rng.randrange(m))
        k = len(S0)
        n = rng.choice([2, 3]) if k <= 3 else 2
        L = rng.choice([2, 3, 4])
        h = np.array([rng.randrange(L) for _ in range(k ** n)]).reshape((k,) * n)
        T = tuple(i for i in range(n) if rng.random() < 0.4)
        _, lam = lam_of(Q, pi)
        pl = plurality(h, T, n, pi, L)
        w = pi
        for _ in range(n - 1):
            w = np.multiply.outer(w, pi)
        p_pl = float((w * (h != pl)).sum())
        # (a): exact Pr[h(y) != h(y')] with y'_T = y_T and Q-moves off T
        tot = 0.0
        for y in itertools.product(range(k), repeat=n):
            py = w[y]
            for y2 in itertools.product(range(k), repeat=n):
                pr = 1.0
                for i in range(n):
                    if i in T:
                        pr *= 1.0 if y2[i] == y[i] else 0.0
                    else:
                        pr *= Q[y[i], y2[i]]
                if pr and h[y] != h[y2]:
                    tot += py * pr
        worst_a = max(worst_a, p_pl - tot / (1 - lam))
        # (b): identity for a random R
        R = tuple(i for i in range(n) if rng.random() < 0.5)
        lhs = 0.0
        for y in itertools.product(range(k), repeat=n):
            for y2 in itertools.product(range(k), repeat=n):
                if any(y2[i] != y[i] for i in range(n) if i not in R):
                    continue
                pr = w[y] * math.prod(pi[y2[i]] for i in R)
                if h[y] != h[y2]:
                    lhs += pr
        rhs = 0.0
        for c in range(L):
            norms, _ = es_norms((h == c).astype(float), n, pi)
            rhs += sum(v for S, v in norms.items() if set(S) & set(R))
        worst_b = max(worst_b, abs(lhs - rhs))
        # (c)
        for c in range(L):
            worst_c = max(worst_c, float((w * (pl == c)).sum()) - L * float((w * (h == c)).sum()))
    assert worst_a < TOL and worst_b < TOL and worst_c < TOL
    print(f"(2) rounding/noise: {trials} instances; max violation (a) {worst_a:.1e}, "
          f"|identity defect| (b) {worst_b:.1e}, max violation (c) {worst_c:.1e}: OK")


# ---------------------------------------------------------------- junta lemma
def column_dist(mu, q, m, j):
    d = np.zeros(q)
    for x, p in mu.items():
        d[x[j]] += p
    return d


def check_junta(rng, trials=40):
    """g in {min, mult mod q}, j = 0, insensitive context u* = (0,...,0); m = 2, q = 3, n <= 3."""
    worst = {k: -math.inf for k in ("contain", "ident", "rhc", "jensen", "b", "a")}
    for t in range(trials):
        q, m = 3, 2
        n = 2 if t % 2 == 0 else 3
        g = g_min if t % 4 < 2 else make_mult(q)
        j = 0
        ustar = (0,) * (m - 1)
        pts = list(itertools.product(range(q), repeat=m))
        mu = dict(zip(pts, random_dist(len(pts), rng)))
        alpha = min(mu.values())
        sigma = alpha / 2
        muj = column_dist(mu, q, m, j)
        nu1 = {x: (muj[x[j]] if tuple(x[:j] + x[j + 1:]) == ustar else 0.0) for x in pts}
        nu0 = {x: (mu[x] - sigma * nu1[x]) / (1 - sigma) for x in pts}
        assert min(nu0.values()) >= alpha / 2 - 1e-15
        # random functions, biased so that delta is not huge
        rate = rng.choice([0.02, 0.05, 0.15])
        f = []
        for k in range(m + 1):
            tab = {}
            for x in itertools.product(range(q), repeat=n):
                tab[x] = x[0] if rng.random() > rate else rng.randrange(q)
            f.append(tab)
        r = r_of(alpha / 2)
        rows = list(itertools.product(pts, repeat=n))  # matrices as tuples of rows

        def col(Z, k):
            return tuple(z[k] for z in Z)

        def rhs(Z):
            return g(tuple(f[k + 1][col(Z, k)] for k in range(m)))

        def lhs(Z):
            return f[0][tuple(g(z) for z in Z)]

        def pZ(Z, law):
            return math.prod(law[z] for z in Z)

        delta = sum(pZ(Z, mu) for Z in rows if lhs(Z) != rhs(Z))
        contexts = list(itertools.product(range(q), repeat=m - 1))
        for v in contexts:
            Hv = {x: g(insert(v, j, f[j + 1][x])) for x in itertools.product(range(q), repeat=n)}
            Pv = sum(pZ(Z, mu) for Z in rows if tuple(f[k + 1][col(Z, k)] for k in range(m) if k != j) == v)
            if Pv == 0:
                continue
            harr = np.array([Hv[x] for x in itertools.product(range(q), repeat=n)]).reshape((q,) * n)
            norms_c = [es_norms((harr == c).astype(float), n, muj)[0] for c in range(q)]
            PE = 0.0
            EWomega = 0.0
            pi_i = np.zeros(n)
            for zeta in itertools.product((0, 1), repeat=n):
                pzeta = math.prod(sigma if b else 1 - sigma for b in zeta)
                R = [i for i in range(n) if zeta[i]]
                laws = [nu1 if b else nu0 for b in zeta]
                pE = pdiff = omega = 0.0
                for Z in rows:
                    pz = math.prod(laws[i][Z[i]] for i in range(n))
                    if pz == 0:
                        continue
                    cv = tuple(f[k + 1][col(Z, k)] for k in range(m) if k != j) == v
                    if cv:
                        omega += pz
                    for repl in itertools.product(range(q), repeat=len(R)):
                        pr = math.prod(muj[a] for a in repl)
                        Wj = list(col(Z, j))
                        for i, a in zip(R, repl):
                            Wj[i] = a
                        d = Hv[col(Z, j)] != Hv[tuple(Wj)]
                        if d:
                            pdiff += pz * pr
                            if cv:
                                pE += pz * pr
                WR = sum(sum(val for S, val in nc.items() if set(S) & set(R)) for nc in norms_c)
                worst["ident"] = max(worst["ident"], abs(pdiff - WR))
                worst["rhc"] = max(worst["rhc"], (pdiff * omega) ** (1 / r) - pE)
                PE += pzeta * pE
                EWomega += pzeta * WR * omega
                for i in R:
                    pi_i[i] += pzeta * omega
            worst["contain"] = max(worst["contain"], PE - 2 * delta)
            worst["jensen"] = max(worst["jensen"], EWomega - (2 * delta) ** r)
            Tv = [i for i in range(n) if pi_i[i] <= sigma * Pv / 4]
            tail = sum(sum(val for S, val in nc.items() if not set(S) <= set(Tv)) for nc in norms_c)
            plv = plurality(harr, tuple(Tv), n, muj, q)
            w = muj
            for _ in range(n - 1):
                w = np.multiply.outer(w, muj)
            perr = float((w * (harr != plv)).sum())
            bound_b = 8 * (2 * delta) ** r / (alpha * Pv)
            worst["b"] = max(worst["b"], tail - bound_b, perr - tail)
            if Tv:
                worst["a"] = max(worst["a"], len(Tv) - (16 / alpha) * math.log(2 / Pv))
    for k, val in worst.items():
        assert val < TOL, (k, val)
    print(f"(3) junta lemma: {trials} instances (q=3, m=2, n<=3, g in {{min, mult mod 3}}); max violations: "
          + ", ".join(f"{k} {val:.1e}" for k, val in worst.items()) + ": OK")


# ---------------------------------------------------------------- propagation
def check_propagation(rng, trials=40):
    worst_D = worst_E = -math.inf
    for t in range(trials):
        q, m, n = 3, 2, 2
        g = g_min if t % 2 == 0 else make_mult(q)
        pts = list(itertools.product(range(q), repeat=m))
        mu = dict(zip(pts, random_dist(len(pts), rng)))
        alpha = min(mu.values())
        dom = list(itertools.product(range(q), repeat=n))
        rate = rng.choice([0.05, 0.15, 0.4])
        f = [{x: (x[0] if rng.random() > rate else rng.randrange(q)) for x in dom} for _ in range(m + 1)]
        rows = list(itertools.product(pts, repeat=n))

        def col(Z, k):
            return tuple(z[k] for z in Z)

        def rhs(Z):
            return g(tuple(f[k + 1][col(Z, k)] for k in range(m)))

        def pZ(Z):
            return math.prod(mu[z] for z in Z)

        delta = sum(pZ(Z) for Z in rows if f[0][tuple(g(z) for z in Z)] != rhs(Z))
        mus = [column_dist(mu, q, m, k) for k in range(m)]
        pis = [{a: sum(math.prod(mus[k][x[i]] for i in range(n)) for x in dom if f[k + 1][x] == a) for a in range(q)}
               for k in range(m)]
        allv = sorted({p for k in range(m) for p in pis[k].values() if p > 0})
        eta = rng.choice(allv)
        V = [[a for a in range(q) if pis[k][a] >= eta] for k in range(m)]
        if any(not Vk for Vk in V):
            continue
        theta = max([p for k in range(m) for p in pis[k].values() if p < eta] + [0.0]) + 1e-15
        # classes
        cls = []
        for j in range(m):
            ctx = list(itertools.product(*[V[k] for k in range(m) if k != j]))
            sig = {a: tuple(g(insert(v, j, a)) for v in ctx) for a in V[j]}
            reps = sorted(set(sig.values()))
            cls.append({a: reps.index(sig[a]) for a in V[j]})
        T = tuple(i for i in range(n) if rng.random() < 0.5)
        Gamma = 1.0  # Gamma_{m-1} with m = 2
        # Lemma 8.51 with J_0 = pl_T f_0 (computed on S0^n)
        S0, mu0, _, _ = kernel(g, mu, q, m, 0)
        k0 = len(S0)
        h = np.array([f[0][y] for y in itertools.product(S0, repeat=n)]).reshape((k0,) * n)
        pl = plurality(h, T, n, mu0, q)
        w = mu0
        for _ in range(n - 1):
            w = np.multiply.outer(w, mu0)
        beta0 = float((w * (h != pl)).sum())
        J0 = {y: pl[tuple(S0.index(a) for a in y)] for y in itertools.product(S0, repeat=n)}
        # joint law of (Z, W): W = Z with rows off T refreshed
        pairs = []
        for Z in rows:
            for Wrows in itertools.product(pts, repeat=n - len(T)):
                it = iter(Wrows)
                W = tuple(Z[i] if i in T else next(it) for i in range(n))
                pairs.append((Z, W, pZ(Z) * math.prod(mu[z] for z in Wrows)))
        p_rhs = sum(p for Z, W, p in pairs if rhs(Z) != rhs(W))
        assert p_rhs <= 2 * delta + 2 * beta0 + 1e-12
        for jj in range(m):
            ncls = max(cls[jj].values()) + 1
            ctx = list(itertools.product(*[V[k] for k in range(m) if k != jj]))
            for C in range(ncls):
                for C2 in range(ncls):
                    if C == C2:
                        continue
                    aC = [a for a in V[jj] if cls[jj][a] == C][0]
                    aC2 = [a for a in V[jj] if cls[jj][a] == C2][0]
                    v = [u for u in ctx if g(insert(u, jj, aC)) != g(insert(u, jj, aC2))][0]

                    def cj(Z):
                        return tuple(f[k + 1][col(Z, k)] for k in range(m) if k != jj)

                    PD = sum(p for Z, W, p in pairs if cls[jj].get(f[jj + 1][col(Z, jj)], -1) == C
                             and cls[jj].get(f[jj + 1][col(W, jj)], -1) == C2)
                    PE = sum(p for Z, W, p in pairs if cj(Z) == v and cj(W) == v)
                    PA = sum(pZ(Z) for Z in rows if cj(Z) == v)
                    worst_E = max(worst_E, PA ** 2 - PE, eta ** Gamma - PA)
                    worst_D = max(worst_D, PD - (2 * delta + 2 * beta0) ** (alpha ** 2 / 2) / PE)
    assert worst_D < TOL and worst_E < TOL
    print(f"(4) propagation to every column (Lemma 8.52): {trials} instances (q=3, m=2, n=2); max violations: "
          f"Pr[D] bound {worst_D:.1e}, Pr[E] >= Pr[c=v]^2 >= eta^Gamma {worst_E:.1e}: OK")


def check_qf0(rng, trials=30):
    """Lemma 8.48 (component kernel Q: reversible, PSD, lambda_* < 1 under (H)) and Lemma 8.51: with
    gamma = max_{j, v in N_j} sum_c ||h_{v,c} - E^j_T h_{v,c}||^2 for an arbitrary T,
    Pr[RHS(Z) != RHS(W)] <= m(2 q theta + 2 N gamma) and Pr[f_0 != pl_T f_0] <= (2 delta + 2 m q theta + 2 m N gamma)/(1 - lambda_*)."""
    worst = {k: -math.inf for k in ("rev", "psd", "lam", "rhs", "f0")}
    gcomp = find_component_only_g(3, 2, rng)
    done = 0
    for t in range(trials):
        q, m, n = 3, 2, 2
        N = q * (q - 1) // 2
        g = [g_min, g_mean, gcomp][t % 3]
        H, comps, S0 = comp_graph_H(g, q, m)
        assert H
        pts = list(itertools.product(range(q), repeat=m))
        mu = dict(zip(pts, random_dist(len(pts), rng)))
        kvec = lambda z: tuple(comps[k][z[k]] for k in range(m))
        mass = {}
        for z in pts:
            mass[kvec(z)] = mass.get(kvec(z), 0.0) + mu[z]
        idx = {y: i for i, y in enumerate(S0)}
        k0 = len(S0)
        J = np.zeros((k0, k0))
        for z in pts:
            for z2 in pts:
                if kvec(z) == kvec(z2):
                    J[idx[g(z)], idx[g(z2)]] += mu[z] * mu[z2] / mass[kvec(z)]
        mu0 = J.sum(axis=1)
        Q = J / mu0[:, None]
        worst["rev"] = max(worst["rev"], float(np.abs(J - J.T).max()))
        d = np.sqrt(mu0)
        ev = np.linalg.eigvalsh((d[:, None] * Q) / d[None, :])
        worst["psd"] = max(worst["psd"], -float(ev.min()))
        lam = float(sorted(ev)[-2]) if k0 > 1 else 0.0
        worst["lam"] = max(worst["lam"], lam - (1 - 1e-12))
        dom = list(itertools.product(range(q), repeat=n))
        rate = rng.choice([0.05, 0.15, 0.4])
        f = [{x: (x[0] if rng.random() > rate else rng.randrange(q)) for x in dom} for _ in range(m + 1)]
        rows = list(itertools.product(pts, repeat=n))
        col = lambda Z, k: tuple(z[k] for z in Z)
        rhs = lambda Z: g(tuple(f[k + 1][col(Z, k)] for k in range(m)))
        pZ = lambda Z: math.prod(mu[z] for z in Z)
        delta = sum(pZ(Z) for Z in rows if f[0][tuple(g(z) for z in Z)] != rhs(Z))
        mus = [column_dist(mu, q, m, k) for k in range(m)]
        pis = [{a: sum(math.prod(mus[k][x[i]] for i in range(n)) for x in dom if f[k + 1][x] == a) for a in range(q)}
               for k in range(m)]
        allv = sorted({p for k in range(m) for p in pis[k].values() if p > 0})
        eta = rng.choice(allv)
        V = [[a for a in range(q) if pis[k][a] >= eta] for k in range(m)]
        theta = max([p for k in range(m) for p in pis[k].values() if p < eta] + [0.0]) + 1e-15
        T = tuple(i for i in range(n) if rng.random() < 0.5)
        gamma = 0.0
        for j in range(m):
            ctx = list(itertools.product(*[V[k] for k in range(m) if k != j]))
            sig = {a: tuple(g(insert(v, j, a)) for v in ctx) for a in V[j]}
            reps = sorted(set(sig.values()))
            cls = {a: reps.index(sig[a]) for a in V[j]}
            Nj = set()
            for C in range(len(reps)):
                for C2 in range(C + 1, len(reps)):
                    aC = [a for a in V[j] if cls[a] == C][0]
                    aC2 = [a for a in V[j] if cls[a] == C2][0]
                    Nj.add([u for u in ctx if g(insert(u, j, aC)) != g(insert(u, j, aC2))][0])
            w = mus[j]
            for _ in range(n - 1):
                w = np.multiply.outer(w, mus[j])
            for v in Nj:
                harr = np.array([g(insert(v, j, f[j + 1][x])) for x in dom]).reshape((q,) * n)
                tot = 0.0
                for c in S0:
                    hc = (harr == c).astype(float)
                    tot += float((w * (hc - apply_EP(hc, T, comps[j], mus[j])) ** 2).sum())
                gamma = max(gamma, tot)
        # coupling: rows off T resampled given their component vector
        p_rhs = 0.0
        p_f0 = 0.0
        for Z in rows:
            pz = pZ(Z)
            choices = [[(Z[i], 1.0)] if i in T else [(z2, mu[z2] / mass[kvec(Z[i])]) for z2 in pts if kvec(z2) == kvec(Z[i])]
                       for i in range(n)]
            for combo in itertools.product(*choices):
                W = tuple(z for z, _ in combo)
                pw = pz * math.prod(pp for _, pp in combo)
                if rhs(Z) != rhs(W):
                    p_rhs += pw
        worst["rhs"] = max(worst["rhs"], p_rhs - m * (2 * q * theta + 2 * N * gamma))
        h = np.array([f[0][y] for y in itertools.product(S0, repeat=n)]).reshape((k0,) * n)
        pl = plurality(h, T, n, mu0, q)
        w0 = mu0
        for _ in range(n - 1):
            w0 = np.multiply.outer(w0, mu0)
        beta0 = float((w0 * (h != pl)).sum())
        worst["f0"] = max(worst["f0"], beta0 - (2 * delta + 2 * m * q * theta + 2 * m * N * gamma) / (1 - lam))
        done += 1
    for k, val in worst.items():
        assert val < 1e-9, (k, val)
    print(f"(4b) component kernel and Lemma 8.51: {done} instances (q=3, m=2, n=2, g in {{min, rounded mean, "
          f"a random g covered only through components}}); max violations: "
          + ", ".join(f"{k} {val:.1e}" for k, val in worst.items()) + ": OK")


# ---------------------------------------------------------------- edge projections (hypothesis (H1))
def g_mean(x):
    return sum(x) // len(x)


def edge_proj(e, muj):
    """Matrix of p_e: (p_e f)(x) = f(x) off e, and the mu_j-average of f over e on e."""
    q = len(muj)
    P = np.eye(q)
    a, b = e
    s = muj[a] + muj[b]
    for x in e:
        P[x, :] = 0.0
        P[x, a] = muj[a] / s
        P[x, b] = muj[b] / s
    return P


def apply_axis(P, arr, axis):
    out = np.tensordot(P, arr, axes=([1], [axis]))
    return np.moveaxis(out, 0, axis)


def spanning_tree(g, q, m, j):
    """Edges {a,b} of a spanning tree of N_j with contexts u_e, or None if N_j is disconnected."""
    ctxs = list(itertools.product(range(q), repeat=m - 1))
    seen, tree, frontier = {0}, [], [0]
    while frontier:
        a = frontier.pop()
        for b in range(q):
            if b in seen:
                continue
            for u in ctxs:
                if g(insert(u, j, a)) == g(insert(u, j, b)):
                    seen.add(b); frontier.append(b); tree.append(((a, b), u))
                    break
    return tree if len(seen) == q else None


def spanning_forest(g, q, m, j):
    """Edges {a,b} (with contexts u_e) of a spanning forest of N_j, and the component label of each letter."""
    ctxs = list(itertools.product(range(q), repeat=m - 1))
    comp, tree = [-1] * q, []
    for r in range(q):
        if comp[r] >= 0:
            continue
        comp[r] = r; frontier = [r]
        while frontier:
            a = frontier.pop()
            for b in range(q):
                if comp[b] >= 0:
                    continue
                for u in ctxs:
                    if g(insert(u, j, a)) == g(insert(u, j, b)):
                        comp[b] = r; frontier.append(b); tree.append(((a, b), u))
                        break
    return tree, comp


def block_proj(comp, muj):
    """Matrix of E^P: average over the block of x."""
    q = len(muj)
    E = np.zeros((q, q))
    for x in range(q):
        blk = [y for y in range(q) if comp[y] == comp[x]]
        s = sum(muj[y] for y in blk)
        for y in blk:
            E[x, y] = muj[y] / s
    return E


def apply_EP(h, T, comp, muj):
    E = block_proj(comp, muj)
    out = h
    for i in range(h.ndim):
        if i not in T:
            out = apply_axis(E, out, i)
    return out


def comp_graph_H(g, q, m):
    """Hypothesis (H): the union over j of the graphs G_j (outputs linked by a change of x_j within a component of N_j)."""
    pts = list(itertools.product(range(q), repeat=m))
    S0 = sorted({g(x) for x in pts})
    comps = [spanning_forest(g, q, m, j)[1] for j in range(m)]
    adj = {y: set() for y in S0}
    for j in range(m):
        for u in itertools.product(range(q), repeat=m - 1):
            for a in range(q):
                for b in range(q):
                    if comps[j][a] == comps[j][b]:
                        adj[g(insert(u, j, a))].add(g(insert(u, j, b)))
    seen, st = {S0[0]}, [S0[0]]
    while st:
        y = st.pop()
        for z in adj[y]:
            if z not in seen:
                seen.add(z); st.append(z)
    return len(seen) == len(S0), comps, S0


def find_component_only_g(q, m, rng):
    """A random g with (H) such that the collision-connected coordinates alone do not connect the outputs."""
    while True:
        tab = {x: rng.randrange(q) for x in itertools.product(range(q), repeat=m)}
        g = lambda x, tab=tab: tab[tuple(x)]
        ok, comps, S0 = comp_graph_H(g, q, m)
        full = [j for j in range(m) if len(set(comps[j])) == 1]
        if not ok or len(S0) < 2:
            continue
        adj = {y: set() for y in S0}
        for j in full:
            for u in itertools.product(range(q), repeat=m - 1):
                vals = {g(insert(u, j, a)) for a in range(q)}
                for y in vals:
                    adj[y] |= vals
        seen, st = {S0[0]}, [S0[0]]
        while st:
            y = st.pop()
            for z in adj[y]:
                if z not in seen:
                    seen.add(z); st.append(z)
        if len(seen) < len(S0):
            return g


def c_of(tree, muj, comp=None):
    q = len(muj)
    M = np.eye(q)
    for e, _ in tree:
        M = M @ edge_proj(e, muj)
    E = np.outer(np.ones(q), muj) if comp is None else block_proj(comp, muj)
    d = np.sqrt(muj)
    return float(np.linalg.norm((d[:, None] * (M - E)) / d[None, :], 2)), M


def check_altproj(rng, trials=300):
    """c_j < 1, ||A - E_T|| = c_j on the tensor power, and ||h - E_T h|| <= sum_e ||h - P_e h|| / (1 - c_j)."""
    worst_c = worst_t = worst_ineq = -math.inf
    forests = 0
    for t in range(trials):
        q = rng.choice([3, 4])
        m = 2
        g = [g_mean, g_min, make_random_g(q, m, rng)][t % 3]
        tree, comp = spanning_forest(g, q, m, 0)
        if not tree:
            continue
        muj = random_dist(q, rng)
        c, M = c_of(tree, muj, comp)
        forests += len(set(comp)) > 1
        worst_c = max(worst_c, c - (1 - 1e-9))
        n = 2
        Mk = np.kron(M, M)
        Ek = np.kron(block_proj(comp, muj), block_proj(comp, muj))
        dk = np.sqrt(np.kron(muj, muj))
        worst_t = max(worst_t, abs(float(np.linalg.norm((dk[:, None] * (Mk - Ek)) / dk[None, :], 2)) - c))
        n = rng.choice([2, 3])
        w = muj
        for _ in range(n - 1):
            w = np.multiply.outer(w, muj)
        h = np.array([rng.gauss(0, 1) for _ in range(q ** n)]).reshape((q,) * n)
        T = [i for i in range(n) if rng.random() < 0.4]
        S = [i for i in range(n) if i not in T]
        nrm = lambda a: math.sqrt(float((w * a ** 2).sum()))
        ET = apply_EP(h, T, comp, muj)
        rhs = 0.0
        for e, _ in tree:
            Ph = h
            for i in S:
                Ph = apply_axis(edge_proj(e, muj), Ph, i)
            rhs += nrm(h - Ph)
        worst_ineq = max(worst_ineq, nrm(h - ET) - rhs / (1 - c))
    assert worst_c < 0 and worst_t < 1e-8 and worst_ineq < TOL
    print(f"(5) alternating projections: {trials} instances (q in {{3,4}}; {forests} with a disconnected N_j); max c_j = {worst_c + 1:.4f} < 1, "
          f"|tensor norm - c_j| {worst_t:.1e}, max violation of the projection inequality {worst_ineq:.1e}: OK")


def pl_G_err(harr, T, comp, muj):
    """Pr[h != pl_G h] for G generated by x_T and the components of the other entries."""
    n = harr.ndim
    atoms = {}
    for x in itertools.product(range(len(muj)), repeat=n):
        key = tuple(x[i] if i in T else ("c", comp[x[i]]) for i in range(n))
        px = math.prod(muj[a] for a in x)
        atoms.setdefault(key, {}).setdefault(int(harr[x]), 0.0)
        atoms[key][int(harr[x])] += px
    return sum(sum(d.values()) - max(d.values()) for d in atoms.values())


def check_edge_junta(rng, trials=24):
    """Junta lemma under (H1): g = rounded mean (no context makes g constant in x_j) and g = min; q=3, m=2, n=2,
    one latent decomposition per tree edge e = {a,b} with context u_e, W moves the entries in R by p_e."""
    worst = {k: -math.inf for k in ("contain", "ident", "rhc", "jensen", "edge", "a", "comb", "pl")}
    gcomp = find_component_only_g(3, 2, rng)
    for t in range(trials):
        q, m, n, j = 3, 2, 2, 0
        g = [g_min, g_mean, gcomp][t % 3]
        tree, comp = spanning_forest(g, q, m, j)
        pts = list(itertools.product(range(q), repeat=m))
        mu = dict(zip(pts, random_dist(len(pts), rng)))
        alpha = min(mu.values())
        sigma = alpha / 2
        muj = column_dist(mu, q, m, j)
        cj, _ = c_of(tree, muj, comp)
        rate = rng.choice([0.02, 0.05, 0.15])
        f = [{x: (x[0] if rng.random() > rate else rng.randrange(q)) for x in itertools.product(range(q), repeat=n)}
             for _ in range(m + 1)]
        r = r_of(alpha / 2)
        rows = list(itertools.product(pts, repeat=n))
        col = lambda Z, k: tuple(z[k] for z in Z)
        rhs = lambda Z: g(tuple(f[k + 1][col(Z, k)] for k in range(m)))
        lhs = lambda Z: f[0][tuple(g(z) for z in Z)]
        delta = sum(math.prod(mu[z] for z in Z) for Z in rows if lhs(Z) != rhs(Z))
        w = np.multiply.outer(muj, muj)
        nrm2 = lambda a: float((w * a ** 2).sum())
        for v in itertools.product(range(q), repeat=m - 1):
            Hv = {x: g(insert(v, j, f[j + 1][x])) for x in itertools.product(range(q), repeat=n)}
            Pv = sum(math.prod(mu[z] for z in Z) for Z in rows
                     if tuple(f[k + 1][col(Z, k)] for k in range(m) if k != j) == v)
            if Pv == 0:
                continue
            harr = np.array([Hv[x] for x in itertools.product(range(q), repeat=n)]).reshape((q,) * n)
            hc = [(harr == c).astype(float) for c in range(q)]
            Tv = set()
            for e, ue in tree:
                pe = edge_proj(e, muj)
                nu1 = {x: (muj[x[j]] if tuple(x[:j] + x[j + 1:]) == ue else 0.0) for x in pts}
                nu0 = {x: (mu[x] - sigma * nu1[x]) / (1 - sigma) for x in pts}
                assert min(nu0.values()) >= alpha / 2 - 1e-15
                PE = EWomega = 0.0
                pi_i = np.zeros(n)
                for zeta in itertools.product((0, 1), repeat=n):
                    pzeta = math.prod(sigma if b else 1 - sigma for b in zeta)
                    R = [i for i in range(n) if zeta[i]]
                    laws = [nu1 if b else nu0 for b in zeta]
                    pE = pdiff = omega = 0.0
                    for Z in rows:
                        pz = math.prod(laws[i][Z[i]] for i in range(n))
                        if pz == 0:
                            continue
                        cv = tuple(f[k + 1][col(Z, k)] for k in range(m) if k != j) == v
                        omega += pz * cv
                        for repl in itertools.product(range(q), repeat=len(R)):
                            pr = math.prod(pe[Z[i][j], a] for i, a in zip(R, repl))
                            if pr == 0:
                                continue
                            Wrows = list(Z)
                            for i, a in zip(R, repl):
                                Wrows[i] = insert(Z[i][:j] + Z[i][j + 1:], j, a)
                            assert tuple(g(z) for z in Wrows) == tuple(g(z) for z in Z)
                            if Hv[col(Z, j)] != Hv[col(Wrows, j)]:
                                pdiff += pz * pr
                                pE += pz * pr * cv
                    WR = 0.0
                    for h in hc:
                        Ph = h
                        for i in R:
                            Ph = apply_axis(pe, Ph, i)
                        WR += nrm2(h - Ph)
                    worst["ident"] = max(worst["ident"], abs(pdiff - WR))
                    worst["rhc"] = max(worst["rhc"], (pdiff * omega) ** (1 / r) - pE)
                    PE += pzeta * pE
                    EWomega += pzeta * WR * omega
                    for i in R:
                        pi_i[i] += pzeta * omega
                worst["contain"] = max(worst["contain"], PE - 2 * delta)
                worst["jensen"] = max(worst["jensen"], EWomega - (2 * delta) ** r)
                Tev = [i for i in range(n) if pi_i[i] <= sigma * Pv / 4]
                tail = 0.0
                for h in hc:
                    Ph = h
                    for i in range(n):
                        if i not in Tev:
                            Ph = apply_axis(pe, Ph, i)
                    tail += nrm2(h - Ph)
                worst["edge"] = max(worst["edge"], tail - 8 * (2 * delta) ** r / (alpha * Pv))
                if Tev:
                    worst["a"] = max(worst["a"], len(Tev) - (16 / alpha) * math.log(2 / Pv))
                Tv |= set(Tev)
            comb = sum(nrm2(h - apply_EP(h, Tv, comp, muj)) for h in hc)
            F = len(tree)
            worst["comb"] = max(worst["comb"], comb - F ** 2 * 8 * (2 * delta) ** r / ((1 - cj) ** 2 * alpha * Pv))
            worst["pl"] = max(worst["pl"], pl_G_err(harr, Tv, comp, muj) - comb)
    for k, val in worst.items():
        assert val < TOL, (k, val)
    print(f"(3*) junta lemma, one decomposition per forest edge: {trials} instances "
          f"(q=3, m=2, n=2, g in {{min, rounded mean, a random g with disconnected N_j}}); max violations: "
          + ", ".join(f"{k} {val:.1e}" for k, val in worst.items()) + ": OK")


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 2026
    rng = random.Random(seed)
    print(f"seed {seed}")
    check_kernel(rng)
    check_block_kernel(rng)
    check_rounding(rng)
    check_junta(rng)
    check_altproj(rng)
    check_edge_junta(rng)
    check_propagation(rng)
    check_qf0(rng)
    print("ALL CHECKS PASSED")


if __name__ == "__main__":
    main()
