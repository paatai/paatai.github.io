"""All generalized polymorphisms of P = {(a,b,c) in Z_3^3 : a+b+c != 0} for n = 2.

Backtracking search with forward checking over the 27 values g_j(w), j = 1,2,3, w in Z_3^2,
subject to the 18^2 = 324 constraints g_1(x) + g_2(y) + g_3(z) != 0 (every row of (x,y,z) in P).
Checks that every solution is of type (A) (two constants u, v; the third function avoids -u-v)
or of type (B) (g_j(w) = kappa*w_i + d_j with d_1+d_2+d_3 = 0), and that the counts are
|A| = 3*9*2^9 - 2*18 = 13788 and |B| = 2*2*9 = 36.

With Theorem 1.3 of Filmus, "Triviality of promise polymorphisms" (arXiv:2607.27057; box-triviality
for n = 2 implies it for all n, for predicates with full projections), this gives a second proof of
Theorem 8.55(a): for P the box-type triples are exactly those of type (A), and the dictator-type
triples are those of type (A) or (B) depending on one coordinate.
"""
import itertools
import sys
import time

Q = 3
P = [(a, b, c) for a in range(Q) for b in range(Q) for c in range(Q) if (a + b + c) % Q]
N = 2
PTS = list(itertools.product(range(Q), repeat=N))
IDX = {w: i for i, w in enumerate(PTS)}
M = len(PTS)


def var(j, w):
    return j * M + IDX[w]


CONS = []
for rows in itertools.product(P, repeat=N):
    x = tuple(r[0] for r in rows)
    y = tuple(r[1] for r in rows)
    z = tuple(r[2] for r in rows)
    CONS.append((var(0, x), var(1, y), var(2, z)))
NV = 3 * M
BYVAR = [[] for _ in range(NV)]
for c in CONS:
    for v in c:
        BYVAR[v].append(c)


def solve():
    dom = [0b111] * NV
    val = [-1] * NV
    sols = []

    def propagate(v, trail):
        for c in BYVAR[v]:
            others = [u for u in c if u != v]
            un = [u for u in others if val[u] < 0]
            if len(un) == 0:
                if sum(val[u] for u in c) % Q == 0:
                    return False
            elif len(un) == 1:
                u = un[0]
                s = sum(val[t] for t in c if t != u)
                bad = 1 << ((-s) % Q)
                if dom[u] & bad:
                    trail.append((u, dom[u]))
                    dom[u] &= ~bad
                    if dom[u] == 0:
                        return False
        return True

    def rec(nassigned):
        if nassigned == NV:
            sols.append(tuple(val))
            return
        v = min((u for u in range(NV) if val[u] < 0), key=lambda u: bin(dom[u]).count("1"))
        for a in range(Q):
            if not dom[v] >> a & 1:
                continue
            trail = []
            val[v] = a
            if propagate(v, trail):
                rec(nassigned + 1)
            val[v] = -1
            for u, d in reversed(trail):
                dom[u] = d

    rec(0)
    return sols


def kind(sol):
    g = [sol[j * M:(j + 1) * M] for j in range(3)]
    consts = [j for j in range(3) if len(set(g[j])) == 1]
    if len(consts) >= 2:
        u, v = g[consts[0]][0], g[consts[1]][0]
        free = [j for j in range(3) if j not in consts[:2]][0]
        assert all((u + v + t) % Q for t in g[free])
        return "A"
    for i in range(N):
        for kappa in (1, 2):
            d = [(g[j][0] - kappa * PTS[0][i]) % Q for j in range(3)]
            if sum(d) % Q == 0 and all(
                    g[j][IDX[w]] == (kappa * w[i] + d[j]) % Q for j in range(3) for w in PTS):
                return "B"
    return "other"


if __name__ == "__main__":
    t0 = time.time()
    sols = solve()
    kinds = {}
    for s in sols:
        k = kind(s)
        kinds[k] = kinds.get(k, 0) + 1
    print(f"n=2: {len(sols)} generalized polymorphisms, types {kinds}  ({time.time() - t0:.1f} s)")
    ok = len(sols) == 13824 and kinds.get("A") == 13788 and kinds.get("B") == 36 and "other" not in kinds
    print("all checks passed" if ok else "CHECK FAILED")
    sys.exit(0 if ok else 1)
