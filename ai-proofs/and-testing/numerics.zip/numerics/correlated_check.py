"""Exact small-n checks for the correlated-input extension (Section 8.8 of MAIN_RESULT).

Checks, by exact enumeration (no sampling inside an instance):
  (1) two-function reverse hypercontractivity for independent, non-identical coordinate pairs
      E[Phi(X)Psi(Y)] >= ||Phi||_s ||Psi||_s,  s = s(kappa) = 2(1-r)/(2-r), r = sqrt(1-kappa),
      kappa = min_i min_{a,b} P_i(a,b)/(P_i(a)P_i(b))       (Lemma 8.35)
  (2) the multi-party bound Pr[all Z^l in A_l] >= eps^{H_k}         (Lemma 8.36)
  (3) the correlated row-pair noise bound 0 <= rho_j < 1, 1/(1-rho_j) <= 1/(4 alpha^2)   (Lemma 8.37)
  (4) the correlated junta lemma: latent decomposition, conditional reverse HC, containment
      sum_zeta P(zeta) E[Phi Psi | zeta] <= 2 delta, E[Phi|zeta] = 2 W_R, and the bounds (a), (b)  (Lemma 8.38)
  (5) the propagation step from f_0 to the columns: reverse HC for the (Z, W) pair resampled off T,
      Pr[E] >= Pr[A]^2, and Pr[f_j(Z^j) != f_j(W^j)] <= Pr[RHS(Z) != RHS(W)]^s / Pr[E]   (Lemma 8.40)
"""
import itertools
import math
import random
import sys

import numpy as np

TOL = 1e-12


def s_of(kappa):
    kappa = min(max(kappa, 0.0), 1.0)
    r = math.sqrt(1.0 - kappa)
    return 2.0 * (1.0 - r) / (2.0 - r)


def kron_rows(rows):
    P = np.array([[1.0]])
    for Pi in rows:
        P = np.kron(P, Pi)
    return P


def kappa_of(Pi):
    px = Pi.sum(axis=1)
    py = Pi.sum(axis=0)
    k = 1.0
    for a in range(Pi.shape[0]):
        for b in range(Pi.shape[1]):
            if px[a] > 0 and py[b] > 0:
                k = min(k, Pi[a, b] / (px[a] * py[b]))
    return k


def snorm(phi, p, s):
    return float((p * phi ** s).sum()) ** (1.0 / s)


def random_full_support(size, rng, floor=0.0):
    w = np.array([rng.gammavariate(1.0, 1.0) for _ in range(size)]) + floor
    return w / w.sum()


# ---------------------------------------------------------------- (1)
def check_rhc(rng, trials=3000):
    worst = float("inf")
    for _ in range(trials):
        n = rng.choice([1, 2, 3])
        rows = []
        for _i in range(n):
            ax, ay = rng.choice([2, 3, 4]), rng.choice([1, 2, 3, 4])
            kind = rng.random()
            if kind < 0.2 or ay == 1:
                Pi = np.outer(random_full_support(ax, rng), random_full_support(ay, rng))
            elif kind < 0.3:
                # diagonal-type row (X and Y are both functions of one variable), as in Lemma 8.38
                base = random_full_support(ax * ay, rng, 0.05).reshape(ax, ay)
                Pi = base
            else:
                Pi = random_full_support(ax * ay, rng, rng.choice([0.0, 0.02, 0.2])).reshape(ax, ay)
            rows.append(Pi)
        kappa = min(kappa_of(Pi) for Pi in rows)
        s = s_of(kappa)
        if s <= 0:
            continue
        P = kron_rows(rows)
        px, py = P.sum(axis=1), P.sum(axis=0)
        for _f in range(5):
            if rng.random() < 0.5:
                phi = np.array([float(rng.random() < 0.3) for _ in range(P.shape[0])])
                psi = np.array([float(rng.random() < 0.3) for _ in range(P.shape[1])])
            else:
                phi = np.array([rng.random() ** 3 for _ in range(P.shape[0])])
                psi = np.array([rng.random() ** 3 for _ in range(P.shape[1])])
            lhs = float(phi @ P @ psi)
            rhs = snorm(phi, px, s) * snorm(psi, py, s)
            if rhs > 0:
                worst = min(worst, lhs / rhs)
                if lhs < rhs * (1 - 1e-9) - TOL:
                    print("RHC VIOLATION", lhs, rhs, kappa, s)
                    return False, worst
    return True, worst


# ---------------------------------------------------------------- helpers for matrices Z
def all_matrices(n, m):
    """rows z_i in {0,1}^m encoded as ints; Z is a tuple of n row-ints."""
    return itertools.product(range(2 ** m), repeat=n)


def bit(z, k):
    return (z >> k) & 1


def column(Z, k):
    v = 0
    for i, z in enumerate(Z):
        v |= bit(z, k) << i
    return v


def mu_n(Z, mu):
    p = 1.0
    for z in Z:
        p *= mu[z]
    return p


def gvec(Z, g):
    v = 0
    for i, z in enumerate(Z):
        v |= g[z] << i
    return v


def err(f, g, mu, n, m):
    e = 0.0
    for Z in all_matrices(n, m):
        args = 0
        for k in range(m):
            args |= f[k + 1][column(Z, k)] << k
        if f[0][gvec(Z, g)] != g[args]:
            e += mu_n(Z, mu)
    return e


def biased_fourier_weights(h, n, p):
    """returns dict S(bitmask) -> hat h(S)^2 under mu_p."""
    x = np.arange(2 ** n)
    bits = ((x[:, None] >> np.arange(n)) & 1).astype(float)
    px = np.prod(np.where(bits == 1, p, 1 - p), axis=1)
    sd = math.sqrt(p * (1 - p))
    phi_i = (bits - p) / sd
    hv = np.array([h[v] for v in range(2 ** n)], dtype=float)
    out = {}
    for S in range(2 ** n):
        chi = np.ones(2 ** n)
        for i in range(n):
            if (S >> i) & 1:
                chi = chi * phi_i[:, i]
        c = float((px * hv * chi).sum())
        out[S] = c * c
    return out, px


# ---------------------------------------------------------------- (2)
def check_multiparty(rng, trials=400):
    worst_margin = float("inf")
    for _ in range(trials):
        m = rng.choice([2, 3])
        n = rng.choice([1, 2, 3]) if m == 3 else rng.choice([1, 2, 3, 4])
        mu = random_full_support(2 ** m, rng, rng.choice([0.01, 0.1, 0.5]))
        alpha = float(mu.min())
        s = s_of(alpha)
        H = 1.0
        for _k in range(2, m + 1):
            H = (1.0 + H) / s
        A = [set(v for v in range(2 ** n) if rng.random() < rng.choice([0.1, 0.3, 0.6])) for _ in range(m)]
        if any(len(a) == 0 for a in A):
            continue
        pr_all = 0.0
        pr = [0.0] * m
        for Z in all_matrices(n, m):
            w = mu_n(Z, mu)
            ins = [column(Z, k) in A[k] for k in range(m)]
            for k in range(m):
                if ins[k]:
                    pr[k] += w
            if all(ins):
                pr_all += w
        eps = min(pr)
        bound = eps ** H
        if pr_all < bound * (1 - 1e-9):
            print("MULTIPARTY VIOLATION", pr_all, bound)
            return False, worst_margin
        if bound > 1e-300:
            worst_margin = min(worst_margin, pr_all / bound)
    return True, worst_margin


# ---------------------------------------------------------------- (3)
def check_rowpair(rng, trials=300):
    worst = 0.0
    for _ in range(trials):
        m = rng.choice([2, 3, 4])
        mu = random_full_support(2 ** m, rng, rng.choice([0.0, 0.05, 1.0]))
        alpha = float(mu.min())
        gs = range(2 ** (2 ** m)) if m <= 3 else [rng.randrange(2 ** 16) for _ in range(200)]
        for gi in gs:
            g = [(gi >> z) & 1 for z in range(2 ** m)]
            pg = sum(mu[z] for z in range(2 ** m) if g[z])
            for j in range(m):
                if all(g[z] == g[z ^ (1 << j)] for z in range(2 ** m)):
                    continue
                pdiff = 0.0
                p11 = 0.0
                for z in range(2 ** m):
                    if bit(z, j):
                        continue
                    z0, z1 = z, z | (1 << j)
                    mm = mu[z0] + mu[z1]
                    q = mu[z1] / mm
                    r = (g[z1] * q + g[z0] * (1 - q))
                    p11 += mm * r * r
                    if g[z0] != g[z1]:
                        pdiff += mm * 2 * q * (1 - q)
                rho = 1 - pdiff / (2 * pg * (1 - pg))
                if not (rho >= -1e-12 and rho < 1):
                    print("ROWPAIR rho out of range", rho)
                    return False, worst
                if abs(2 * (pg - p11) - pdiff) > 1e-12:
                    print("ROWPAIR identity fails")
                    return False, worst
                ratio = (1 / (1 - rho)) / (1 / (4 * alpha ** 2))
                worst = max(worst, ratio)
                if ratio > 1 + 1e-9:
                    print("ROWPAIR bound fails", ratio)
                    return False, worst
    return True, worst


# ---------------------------------------------------------------- functions f
def near_poly_tuple(g, m, n, rng, noise):
    """a perturbed exact multi-polymorphism (dictator or constant-certificate type), or random."""
    kind = rng.random()
    if kind < 0.5:
        i0 = rng.randrange(n)
        base = [[(v >> i0) & 1 for v in range(2 ** n)] for _ in range(m + 1)]
    elif kind < 0.8:
        base = [[rng.randrange(2) for _ in range(2 ** n)] for _ in range(m + 1)]
        # make column functions juntas on a random set, f_0 arbitrary junta
        J = [i for i in range(n) if rng.random() < 0.4]
        for l in range(m + 1):
            table = {}
            for v in range(2 ** n):
                key = tuple((v >> i) & 1 for i in J)
                if key not in table:
                    table[key] = rng.randrange(2)
                base[l][v] = table[key]
    else:
        base = [[rng.randrange(2) for _ in range(2 ** n)] for _ in range(m + 1)]
    f = [[b ^ (rng.random() < noise) for b in row] for row in base]
    return f


# ---------------------------------------------------------------- (4)
def check_junta(rng, trials=120):
    worst = {"rhc": float("inf"), "contain": 0.0, "b": 0.0, "a": 0.0}
    done = 0
    while done < trials:
        m = rng.choice([2, 2, 3])
        n = rng.choice([2, 3, 4]) if m == 2 else rng.choice([2, 3])
        gi = rng.randrange(2 ** (2 ** m))
        g = [(gi >> z) & 1 for z in range(2 ** m)]
        cands = []
        for j in range(m):
            dep = any(g[z] != g[z ^ (1 << j)] for z in range(2 ** m))
            ins = [z for z in range(2 ** m) if not bit(z, j) and g[z] == g[z | (1 << j)]]
            if dep and ins:
                cands.append((j, ins))
        if not cands:
            continue
        j, ins = rng.choice(cands)
        u0 = rng.choice(ins)  # a full z with bit j = 0 whose context is insensitive
        mu = random_full_support(2 ** m, rng, rng.choice([0.05, 0.3, 1.0]))
        alpha = float(mu.min())
        pj = sum(mu[z] for z in range(2 ** m) if bit(z, j))
        sigma = alpha / 2
        nu_s = np.zeros(2 ** m)
        nu_s[u0] = 1 - pj
        nu_s[u0 | (1 << j)] = pj
        mu_r = (mu - sigma * nu_s) / (1 - sigma)
        assert mu_r.min() >= alpha / 2 - 1e-15
        others = [k for k in range(m) if k != j]

        def ctx(z):
            c = 0
            for t, k in enumerate(others):
                c |= bit(z, k) << t
            return c

        ustar = ctx(u0)
        f = near_poly_tuple(g, m, n, rng, rng.choice([0.0, 0.03, 0.1]))
        delta = err(f, g, mu, n, m)
        # sensitive contexts for j
        B = set()
        for z in range(2 ** m):
            if not bit(z, j) and g[z] != g[z | (1 << j)]:
                B.add(ctx(z))
        # Phi on X = (z_ij, w_ij)_i, Psi on Y = (ctx(z_i))_i ; index row-major with row 0 most significant (kron)
        nx, ny = 4, 2 ** (m - 1)
        Xs = list(itertools.product(range(nx), repeat=n))
        Ys = list(itertools.product(range(ny), repeat=n))
        fj = f[j + 1]
        phi = np.zeros(len(Xs))
        for ix, X in enumerate(Xs):
            zc = sum(((x >> 1) & 1) << i for i, x in enumerate(X))
            wc = sum((x & 1) << i for i, x in enumerate(X))
            phi[ix] = float(fj[zc] != fj[wc])
        psi = np.zeros(len(Ys))
        for iy, Y in enumerate(Ys):
            c = 0
            for t, k in enumerate(others):
                col = sum(((y >> t) & 1) << i for i, y in enumerate(Y))
                c |= f[k + 1][col] << t
            psi[iy] = float(c in B)
        # row laws
        Ps = np.zeros((nx, ny))
        Pr_ = np.zeros((nx, ny))
        for a in range(2):
            for a2 in range(2):
                Ps[2 * a + a2, ustar] = (pj if a else 1 - pj) * (pj if a2 else 1 - pj)
        for z in range(2 ** m):
            a = bit(z, j)
            Pr_[3 * a, ctx(z)] += mu_r[z]
        kappa = min(kappa_of(Ps), kappa_of(Pr_))
        s = s_of(kappa)
        s_paper = s_of(alpha / 2)
        assert s >= s_paper - 1e-15
        weights, _ = biased_fourier_weights(fj, n, pj)
        total = 0.0
        Pj = 0.0
        EW = 0.0
        incl = [0.0] * n
        for zeta in itertools.product([0, 1], repeat=n):  # 1 = s (resampled), 0 = r
            Pz = 1.0
            for t in zeta:
                Pz *= sigma if t else 1 - sigma
            P = kron_rows([Ps if t else Pr_ for t in zeta])
            px, py = P.sum(axis=1), P.sum(axis=0)
            ephipsi = float(phi @ P @ psi)
            ephi = float(phi @ px)
            om = float(psi @ py)
            Rmask = sum(1 << i for i, t in enumerate(zeta) if t)
            WR = sum(w for S, w in weights.items() if S & Rmask)
            if abs(ephi - 2 * WR) > 1e-10:
                print("IDENTITY E[Phi|zeta] = 2 W_R FAILS", ephi, 2 * WR)
                return False, worst
            lower = (ephi * om) ** (1 / s) if ephi * om > 0 else 0.0
            if ephipsi < lower * (1 - 1e-9) - TOL:
                print("CONDITIONAL RHC FAILS", ephipsi, lower)
                return False, worst
            if lower > 0:
                worst["rhc"] = min(worst["rhc"], ephipsi / lower)
            total += Pz * ephipsi
            Pj += Pz * om
            EW += Pz * WR * om
            for i in range(n):
                if zeta[i]:
                    incl[i] += Pz * om
        if total > 2 * delta + 1e-12:
            print("CONTAINMENT FAILS", total, 2 * delta)
            return False, worst
        if delta > 0:
            worst["contain"] = max(worst["contain"], total / (2 * delta))
        if Pj <= 0:
            continue
        # E_zeta[W_R omega] <= (2 delta)^s / 2 with the paper's s
        if EW > (2 * delta) ** s_paper / 2 + 1e-12:
            print("JENSEN STEP FAILS", EW, (2 * delta) ** s_paper / 2)
            return False, worst
        T = [i for i in range(n) if incl[i] <= sigma * Pj / 4]
        Tmask = sum(1 << i for i in T)
        tail = sum(w for S, w in weights.items() if S & ~Tmask)
        bound_b = 2 * (2 * delta) ** s_paper / (sigma * Pj)
        if tail > bound_b + 1e-12:
            print("JUNTA (b) FAILS", tail, bound_b)
            return False, worst
        bound_a = (8 / sigma) * math.log(2 / Pj)
        if len(T) > bound_a:
            print("JUNTA (a) FAILS", len(T), bound_a)
            return False, worst
        if bound_b > 0:
            worst["b"] = max(worst["b"], tail / bound_b)
        worst["a"] = max(worst["a"], len(T) / bound_a)
        done += 1
    return True, worst


# ---------------------------------------------------------------- (5)
def check_propagation(rng, trials=150):
    worst = {"rhc": float("inf"), "E": float("inf"), "final": 0.0}
    done = 0
    while done < trials:
        m = rng.choice([2, 2, 3])
        n = rng.choice([2, 3]) if m == 2 else 2
        gi = rng.randrange(2 ** (2 ** m))
        g = [(gi >> z) & 1 for z in range(2 ** m)]
        js = [j for j in range(m) if any(g[z] != g[z ^ (1 << j)] for z in range(2 ** m))]
        if not js:
            continue
        j = rng.choice(js)
        others = [k for k in range(m) if k != j]

        def ctx(z):
            c = 0
            for t, k in enumerate(others):
                c |= bit(z, k) << t
            return c

        B = sorted(set(ctx(z) for z in range(2 ** m) if not bit(z, j) and g[z] != g[z | (1 << j)]))
        v = rng.choice(B)
        mu = random_full_support(2 ** m, rng, rng.choice([0.05, 0.3, 1.0]))
        alpha = float(mu.min())
        T = [i for i in range(n) if rng.random() < 0.4]
        f = near_poly_tuple(g, m, n, rng, rng.choice([0.0, 0.05, 0.15]))
        nx, ny = 4, 4 ** (m - 1)
        # row law: X_i = (z_ij, w_ij) -> 2a+a', Y_i = (ctx z_i, ctx w_i) -> c*2^(m-1) + c'
        PT = np.zeros((nx, ny))
        PO = np.zeros((nx, ny))
        for z in range(2 ** m):
            PT[3 * bit(z, j), ctx(z) * 2 ** (m - 1) + ctx(z)] += mu[z]
            for w in range(2 ** m):
                PO[2 * bit(z, j) + bit(w, j), ctx(z) * 2 ** (m - 1) + ctx(w)] += mu[z] * mu[w]
        kappa = min(kappa_of(PT), kappa_of(PO))
        s = s_of(kappa)
        s_paper = alpha ** 2 / 2
        assert s >= s_paper - 1e-15
        rows = [PT if i in T else PO for i in range(n)]
        P = kron_rows(rows)
        Xs = list(itertools.product(range(nx), repeat=n))
        Ys = list(itertools.product(range(ny), repeat=n))
        fj = f[j + 1]
        zcol = [sum(((x >> 1) & 1) << i for i, x in enumerate(X)) for X in Xs]
        wcol = [sum((x & 1) << i for i, x in enumerate(X)) for X in Xs]
        phi = np.array([float(fj[a] != fj[b]) for a, b in zip(zcol, wcol)])
        h = 2 ** (m - 1)
        psiE = np.zeros(len(Ys))
        psiA = np.zeros(len(Ys))
        cZ = []
        cW = []
        for iy, Y in enumerate(Ys):
            okZ = okW = True
            cz = cw = 0
            for t, k in enumerate(others):
                colZ = sum((((y // h) >> t) & 1) << i for i, y in enumerate(Y))
                colW = sum((((y % h) >> t) & 1) << i for i, y in enumerate(Y))
                bz, bw = f[k + 1][colZ], f[k + 1][colW]
                cz |= bz << t
                cw |= bw << t
                okZ &= bz == ((v >> t) & 1)
                okW &= bw == ((v >> t) & 1)
            psiE[iy] = float(okZ and okW)
            psiA[iy] = float(okZ)
            cZ.append(cz)
            cW.append(cw)
        px, py = P.sum(axis=1), P.sum(axis=0)
        ephi, eE, eA = float(phi @ px), float(psiE @ py), float(psiA @ py)
        joint = float(phi @ P @ psiE)
        lower = (ephi * eE) ** (1 / s) if ephi * eE > 0 else 0.0
        if joint < lower * (1 - 1e-9) - TOL:
            print("PROPAGATION RHC FAILS", joint, lower)
            return False, worst
        if lower > 0:
            worst["rhc"] = min(worst["rhc"], joint / lower)
        if eE < eA ** 2 - 1e-12:
            print("Pr[E] >= Pr[A]^2 FAILS", eE, eA ** 2)
            return False, worst
        if eA > 0:
            worst["E"] = min(worst["E"], eE / eA ** 2)
        # Pr[RHS(Z) != RHS(W)] computed exactly
        diff = 0.0
        for ix in range(len(Xs)):
            if px[ix] == 0:
                continue
            for iy in range(len(Ys)):
                pr = P[ix, iy]
                if pr == 0:
                    continue
                aZ = 0
                aW = 0
                for t, k in enumerate(others):
                    aZ |= ((cZ[iy] >> t) & 1) << k
                    aW |= ((cW[iy] >> t) & 1) << k
                aZ |= fj[zcol[ix]] << j
                aW |= fj[wcol[ix]] << j
                if g[aZ] != g[aW]:
                    diff += pr
        if eE > 0:
            final_bound = diff ** s_paper / eE
            if ephi > final_bound + 1e-12:
                print("PROPAGATION FINAL FAILS", ephi, final_bound)
                return False, worst
            if final_bound > 0:
                worst["final"] = max(worst["final"], ephi / final_bound)
        done += 1
    return True, worst


def main():
    seed = int(sys.argv[1]) if len(sys.argv) > 1 else 20261021
    rng = random.Random(seed)
    ok_all = True
    ok, w = check_rhc(rng)
    print(f"(1) reverse HC, 3000 random product instances x 5 function pairs: {'OK' if ok else 'FAIL'}; min lhs/rhs = {w:.4f}")
    ok_all &= ok
    ok, w = check_multiparty(rng)
    print(f"(2) multi-party bound (m=2,3): {'OK' if ok else 'FAIL'}; min Pr[all]/eps^H = {w:.4g}")
    ok_all &= ok
    ok, w = check_rowpair(rng)
    print(f"(3) row-pair noise, all g (m<=3) and 200 random g (m=4): {'OK' if ok else 'FAIL'}; max (1/(1-rho))/(1/(4 alpha^2)) = {w:.4f}")
    ok_all &= ok
    ok, w = check_junta(rng)
    print(f"(4) correlated junta lemma, 120 instances (m=2: n<=4, m=3: n<=3): {'OK' if ok else 'FAIL'}; "
          f"min conditional RHC ratio = {w['rhc']:.4f}, max containment sum/(2 delta) = {w['contain']:.4f}, "
          f"max tail/bound(b) = {w['b']:.3g}, max |T|/bound(a) = {w['a']:.3g}")
    ok_all &= ok
    ok, w = check_propagation(rng)
    print(f"(5) propagation f_0 -> columns, 150 instances: {'OK' if ok else 'FAIL'}; min RHC ratio = {w['rhc']:.4f}, "
          f"min Pr[E]/Pr[A]^2 = {w['E']:.4f}, max Pr[f_j changes]/bound = {w['final']:.3g}")
    ok_all &= ok
    print("ALL CHECKS PASSED" if ok_all else "SOME CHECK FAILED")


if __name__ == "__main__":
    main()
