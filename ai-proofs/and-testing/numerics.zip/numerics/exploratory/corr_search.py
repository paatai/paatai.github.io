#!/usr/bin/env python3
"""Exploratory local search: maximize LHS_glob/eps_rho and dist*mu/eps_rho over f on n variables (rho-correlated AND test)."""
import sys

import numpy as np

n, p, rho, iters, seed = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
rng = np.random.default_rng(seed)
N = 1 << n
pts = np.arange(N)
bits = ((pts[:, None] >> np.arange(n)) & 1)
wt = bits.sum(1)
popc = np.array([bin(i).count('1') for i in range(N)])
mup = p ** wt * (1 - p) ** (n - wt)
sig = np.sqrt(p * (1 - p))
phi1 = (bits - p) / sig
Phi = np.ones((N, N))
for S in range(N):
    for i in range(n):
        if S >> i & 1:
            Phi[:, S] *= phi1[:, i]
ySnot = ((pts[:, None] & pts[None, :]) != pts[None, :]).astype(float)
ANDs = ((pts[:, None] & pts[None, :]) == pts[None, :]).astype(float)  # [x,S]
a = p * p + rho * p * (1 - p)
m11, m10, m00 = a, p - a, 1 - 2 * p + a
meet = pts[:, None] & pts[None, :]
n11 = popc[meet]
n10 = popc[pts[:, None] & ~pts[None, :] & (N - 1)]
n01 = n10.T
n00 = n - n11 - n10 - n01
J = m11 ** n11 * m10 ** (n10 + n01) * m00 ** n00


def stats(f):
    mu = f @ mup
    if mu < 1e-12:
        return 0, 0, 1, 0
    fh = (f * mup) @ Phi
    w = (mup * f) @ ySnot
    L = (fh ** 2 * w).sum()
    eps = (np.abs(f[meet] - f[:, None] * f[None, :]) * J).sum()
    d = min(mu, ((f[:, None] != ANDs) * mup[:, None]).sum(0).min())
    return mu, L, eps, d


def score(f, mode):
    mu, L, eps, d = stats(f)
    if eps < 1e-15:
        return 0.0
    return L / eps if mode == 0 else (d * mu / eps if mode == 1 else d * d / eps)


for mode in (0, 1, 2):
    best_overall = 0
    for restart in range(8):
        f = (rng.random(N) < rng.random()).astype(float)
        cur = score(f, mode)
        T = 0.3
        for it in range(iters):
            k = rng.integers(N)
            f[k] = 1 - f[k]
            new = score(f, mode)
            if new >= cur or rng.random() < np.exp((new - cur) / max(T * max(cur, 1e-9), 1e-12)):
                cur = new
            else:
                f[k] = 1 - f[k]
            T *= 0.999
        if cur > best_overall:
            best_overall, bestf = cur, f.copy()
    mu, L, eps, d = stats(bestf)
    name = ["LHS/eps", "dist*mu/eps", "dist^2/eps"][mode]
    print(f"n={n} p={p} rho={rho} max {name} = {best_overall:.4f}  (mu={mu:.4f}, eps={eps:.3g}, dist={d:.4f}, "
          f"f={''.join(str(int(v)) for v in bestf)})", flush=True)
