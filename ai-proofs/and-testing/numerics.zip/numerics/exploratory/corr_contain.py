#!/usr/bin/env python3
"""Exploratory: does the global p-biased spectral containment survive rho-correlated pairs (rho >= 0)?
For all f on n variables: eps_rho, LHS = sum_S fhat(S)^2 Pr[f(y)=1, y_S != 1], dist to ANDs/0, under mu_p.
"""
import itertools
import sys

import numpy as np

n = int(sys.argv[1])
p = float(sys.argv[2])
rhos = [float(r) for r in sys.argv[3:]]
N = 1 << n
pts = np.arange(N)
bits = ((pts[:, None] >> np.arange(n)) & 1).astype(np.int64)  # N x n
wt = bits.sum(1)
mup = p ** wt * (1 - p) ** (n - wt)
# p-biased Fourier characters phi_S(x), S as bitmask
sig = np.sqrt(p * (1 - p))
phi1 = (bits - p) / sig  # N x n
Phi = np.ones((N, N))
for S in range(N):
    for i in range(n):
        if S >> i & 1:
            Phi[:, S] *= phi1[:, i]
# subsets: y_S != 1  <=>  (y & S) != S
ySnot = ((pts[:, None] & pts[None, :]) != pts[None, :]).astype(float)  # [y, S]
# AND family: AND_S(x) = 1{x & S == S}; plus zero
ANDs = ((pts[:, None] & pts[None, :]) == pts[None, :]).astype(np.int8)  # [x, S]

funcs = ((np.arange(1 << N)[:, None] >> pts[None, :]) & 1).astype(np.int8)  # F x N
mu = funcs @ mup
fhat = (funcs * mup) @ Phi  # F x N
w = funcs @ (mup[:, None] * ySnot)  # F x N : Pr[f(y)=1, y_S != 1]
LHS = (fhat ** 2 * w).sum(1)
# distances
d_and = (funcs[:, :, None] != ANDs[None, :, :]).astype(float)
dist = np.minimum(mu, np.einsum('fxs,x->fs', d_and, mup).min(1))
meet = pts[:, None] & pts[None, :]
for rho in rhos:
    a = p * p + rho * p * (1 - p)
    m11, m10, m00 = a, p - a, 1 - 2 * p + a
    # joint weight of (x, y)
    n11 = np.array([[bin(x & y).count('1') for y in range(N)] for x in range(N)])
    n10 = np.array([[bin(x & ~y & (N - 1)).count('1') for y in range(N)] for x in range(N)])
    n01 = n10.T
    n00 = n - n11 - n10 - n01
    J = m11 ** n11 * m10 ** n10 * m10 ** n01 * m00 ** n00
    fx = funcs[:, :, None].astype(float)
    fy = funcs[:, None, :].astype(float)
    fm = funcs[:, meet].astype(float)
    eps = (np.abs(fm - fx * fy) * J[None]).sum((1, 2))
    ok = (mu > 1e-12) & (dist > 1e-12)
    r1 = np.where(eps > 1e-15, LHS / np.maximum(eps, 1e-300), np.where(LHS > 1e-12, np.inf, 0))
    r2 = np.where(ok, dist * mu / np.maximum(eps, 1e-300), 0)
    r3 = np.where(ok, dist ** 2 / np.maximum(eps, 1e-300), 0)
    i1, i2, i3 = r1.argmax(), r2.argmax(), r3.argmax()
    print(f"n={n} p={p} rho={rho}: max LHS/eps={r1[i1]:.4f} (f={i1:#x})  max dist*mu/eps={r2[i2]:.4f} (f={i2:#x})"
          f"  max dist^2/eps={r3[i3]:.4f} (f={i3:#x})")
