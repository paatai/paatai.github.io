"""Numerical exploration of the inequality
    eps_ind(p,q,r) >= (1/3) sigma(p) sigma(q) sigma(r)
for three distributions p,q,r on Z_3, where eps_ind = Pr[X+Y+Z = 0] for independent
X~p, Y~q, Z~r and sigma(p)^2 = 1 - |sum_v p_v w^v|^2, w = exp(2 pi i/3).
Also reports the gap on the 'core' region (all |phat|^2 > 1/5, all distances to
constants >= eta2).
"""
import numpy as np

w = np.exp(2j * np.pi / 3)
rng = np.random.default_rng(1)


def eps_ind(p, q, r):
    s = 0.0
    for a in range(3):
        for b in range(3):
            s += p[..., a] * q[..., b] * r[..., (-a - b) % 3]
    return s


def phat(p):
    return p[..., 0] + p[..., 1] * w + p[..., 2] * w * w


def sig(p):
    return np.sqrt(np.maximum(0.0, 1 - np.abs(phat(p)) ** 2))


def dist_const(p):
    return 1 - p.max(axis=-1)


def sample(N, conc):
    return rng.dirichlet(np.ones(3) * conc, size=N)


def run(N=2_000_000):
    worst = 1e9
    for conc in (0.05, 0.2, 1.0, 5.0):
        p, q, r = sample(N, conc), sample(N, conc), sample(N, conc)
        g = eps_ind(p, q, r) - sig(p) * sig(q) * sig(r) / 3
        k = np.argmin(g)
        worst = min(worst, g[k])
        print(f"conc={conc}: min gap {g[k]:.3e} at p={p[k].round(3)} q={q[k].round(3)} r={r[k].round(3)}")
    print("overall min gap:", worst)
    for eta2 in (0.05, 0.02, 0.01):
        best = 1e9
        for conc in (0.05, 0.2, 1.0, 5.0):
            p, q, r = sample(N, conc), sample(N, conc), sample(N, conc)
            m = np.ones(N, bool)
            for t in (p, q, r):
                m &= (np.abs(phat(t)) ** 2 > 0.2) & (dist_const(t) >= eta2)
            if m.any():
                g = (eps_ind(p, q, r) - sig(p) * sig(q) * sig(r) / 3)[m]
                best = min(best, g.min())
        print(f"core region eta2={eta2}: min gap {best:.4e}")


if __name__ == "__main__":
    run()
