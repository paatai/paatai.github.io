#!/usr/bin/env python3
"""Exploratory: compare LHS_glob = sum_S fhat(S)^2 Pr[f(y)=1, y_S != 1] (mu_p, x indep of y)
with CQ = (1/2) Pr[f(y)=1, f(x) != f(x')] for (x,y) rho-correlated and x' = x resampled on Z(y)
from the conditional law Bern(p') (p' = p(1-rho)).  CQ <= eps_rho always.
Also the 'upper-noised' global quantity and fiber-wise quantities.
"""
import sys

import numpy as np

n = int(sys.argv[1])
p = float(sys.argv[2])
rhos = [float(r) for r in sys.argv[3:]]
N = 1 << n
pts = np.arange(N)
bits = ((pts[:, None] >> np.arange(n)) & 1).astype(np.int64)
wt = bits.sum(1)
popc = np.array([bin(i).count('1') for i in range(N)])


def prod_measure(bias_vec):
    """bias_vec: n-vector; returns N-vector of probabilities."""
    pr = np.ones(N)
    for i in range(n):
        pr *= np.where(bits[:, i] == 1, bias_vec[i], 1 - bias_vec[i])
    return pr


mup = prod_measure([p] * n)
sig = np.sqrt(p * (1 - p))
phi1 = (bits - p) / sig
Phi = np.ones((N, N))
for S in range(N):
    for i in range(n):
        if S >> i & 1:
            Phi[:, S] *= phi1[:, i]
ySnot = ((pts[:, None] & pts[None, :]) != pts[None, :]).astype(float)
funcs = ((np.arange(1 << N)[:, None] >> pts[None, :]) & 1).astype(np.float64)
mu = funcs @ mup
fhat = (funcs * mup) @ Phi
w = funcs @ (mup[:, None] * ySnot)
LHS = (fhat ** 2 * w).sum(1)
meet = pts[:, None] & pts[None, :]
for rho in rhos:
    a = p * p + rho * p * (1 - p)
    p1 = a / p
    pp = p * (1 - rho)
    m11, m10, m00 = a, p - a, 1 - 2 * p + a
    n11 = popc[meet]
    n10 = popc[pts[:, None] & ~pts[None, :] & (N - 1)]
    n01 = n10.T
    n00 = n - n11 - n10 - n01
    J = m11 ** n11 * m10 ** (n10 + n01) * m00 ** n00
    fm = funcs[:, meet]
    eps = (np.abs(fm - funcs[:, :, None] * funcs[:, None, :]) * J[None]).sum((1, 2))
    # CQ: for each y: x ~ nu_y, x' resampled on Z(y)
    CQ = np.zeros(len(funcs))
    for y in range(N):
        supp = [i for i in range(n) if y >> i & 1]
        Z = [i for i in range(n) if not y >> i & 1]
        nu = prod_measure([p1 if (y >> i & 1) else pp for i in range(n)])
        # group x by x_supp: g = E[f | x_supp] under nu
        suppmask = y
        key = pts & suppmask
        tot = np.zeros((len(funcs),))
        for k in np.unique(key):
            idx = np.where(key == k)[0]
            wk = nu[idx].sum()
            g = (funcs[:, idx] @ nu[idx]) / wk
            tot += wk * 2 * g * (1 - g)
        CQ += mup[y] * funcs[:, y] * tot / 2
    good = eps > 1e-14
    r_l_cq = np.where(CQ > 1e-14, LHS / np.maximum(CQ, 1e-300), np.where(LHS > 1e-12, np.inf, 0))
    r_cq_e = np.where(good, CQ / np.maximum(eps, 1e-300), 0)
    i1 = r_l_cq.argmax()
    i2 = r_cq_e.argmax()
    print(f"n={n} p={p} rho={rho}: max LHS_glob/CQ = {r_l_cq[i1]:.4f} (f={i1:#x}, LHS={LHS[i1]:.3g}, CQ={CQ[i1]:.3g});"
          f"  max CQ/eps = {r_cq_e[i2]:.4f};  1/(1-rho)^2 = {1/(1-rho)**2:.3f}")
