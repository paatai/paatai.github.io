#!/usr/bin/env python3
"""Exploratory: symmetric f = 1{|x| in W} under rho-correlated pairs; exact LHS_glob, eps_rho, dist (floats, log-safe).
Local search over W maximizing LHS/eps, dist*mu/eps, dist^2/eps."""
import sys
from math import comb, lgamma, log, exp

import numpy as np

n, p, rho, iters, seed = int(sys.argv[1]), float(sys.argv[2]), float(sys.argv[3]), int(sys.argv[4]), int(sys.argv[5])
rng = np.random.default_rng(seed)
a = p * p + rho * p * (1 - p)
b = p - a
d = 1 - 2 * p + a
sig = (p * (1 - p)) ** 0.5
q = 1 - p
# precompute
Pw = np.array([comb(n, w) * p ** w * q ** (n - w) for w in range(n + 1)])
# level coefficients: F_k = sigma^-k sum_w c_w C(n,w) p^w q^(n-w) sum_j [C(k,j)C(n-k,w-j)/C(n,w)] q^j (-p)^(k-j)
M = np.zeros((n + 1, n + 1))  # M[k, w]: F_k = sum_w c_w M[k,w]
for k in range(n + 1):
    for w in range(n + 1):
        s = 0.0
        for j in range(max(0, w - (n - k)), min(k, w) + 1):
            s += comb(k, j) * comb(n - k, w - j) * q ** j * (-p) ** (k - j)
        M[k, w] = p ** w * q ** (n - w) * s / sig ** k
Ck = np.array([comb(n, k) for k in range(n + 1)], dtype=float)
# W_k = mu - sum_w c_w p^k C(n-k,w-k) p^(w-k) q^(n-w)
Rk = np.zeros((n + 1, n + 1))
for k in range(n + 1):
    for w in range(k, n + 1):
        Rk[k, w] = comb(n - k, w - k) * p ** w * q ** (n - w)
# meet: Bin(n, a)
Pmeet = np.array([comb(n, k) * a ** k * (1 - a) ** (n - k) for k in range(n + 1)])
# joint (N11=k, N10=i, N01=j) probabilities
logf = [lgamma(t + 1) for t in range(n + 2)]
T3 = np.zeros((n + 1, n + 1, n + 1))
for k in range(n + 1):
    for i in range(n + 1 - k):
        for j in range(n + 1 - k - i):
            l = n - k - i - j
            T3[k, i, j] = exp(logf[n] - logf[k] - logf[i] - logf[j] - logf[l] + k * log(a) + (i + j) * log(b) + l * log(d))
# P(|x|=w,|y|=w') = sum_k T3[k, w-k, w'-k]
PXY = np.zeros((n + 1, n + 1))
for k in range(n + 1):
    for i in range(n + 1 - k):
        PXY[k + i, k:n + 1 - i] += T3[k, i, :n + 1 - k - i]
# AND distances: for |S|=s: mu + p^s - 2 p^s Pr[s + Bin(n-s,p) in W]
Bs = np.zeros((n + 1, n + 1))
for s in range(n + 1):
    for t in range(n - s + 1):
        Bs[s, s + t] = comb(n - s, t) * p ** t * q ** (n - s - t)


def stats(c):
    mu = c @ Pw
    if mu < 1e-14:
        return None
    F = M @ c
    Wlev = Ck * F ** 2
    Wk = mu - Rk @ c
    L = Wlev @ Wk
    pm = c @ Pmeet
    pxy = c @ PXY @ c
    tau = 0.0
    idx = np.nonzero(c)[0]
    for k in idx:
        ii = idx[(idx >= k)] - k
        tau += T3[k][np.ix_(ii, ii)].sum()
    eps = pm + pxy - 2 * tau
    ps = np.array([p ** s for s in range(n + 1)])
    dist = min(mu, (mu + ps - 2 * ps * (Bs @ c)).min())
    return mu, L, eps, dist


def score(c, mode):
    st = stats(c)
    if st is None:
        return 0.0
    mu, L, eps, dist = st
    if eps < 1e-13:
        return 0.0
    return [L / eps, dist * mu / eps, dist * dist / eps][mode]


for mode in (0, 1, 2):
    best = 0
    for r in range(6):
        c = (rng.random(n + 1) < 0.5).astype(float)
        cur = score(c, mode)
        for it in range(iters):
            k = rng.integers(n + 1)
            c[k] = 1 - c[k]
            new = score(c, mode)
            if new >= cur or rng.random() < 0.02:
                cur = new
            else:
                c[k] = 1 - c[k]
        if cur > best:
            best, bc = cur, c.copy()
    mu, L, eps, dist = stats(bc)
    print(f"n={n} p={p} rho={rho} mode={['LHS/eps','dist*mu/eps','dist^2/eps'][mode]}: {best:.4f} "
          f"(mu={mu:.4f} eps={eps:.3g} dist={dist:.4f}) W={''.join(str(int(v)) for v in bc)}", flush=True)
