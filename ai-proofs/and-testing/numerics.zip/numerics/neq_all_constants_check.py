"""Checks the absorption inequalities in the proof of Theorem 8.66 (thm:neqall).

x = 1/alpha >= 18, l = ln x.  Each written inequality is checked on a
logarithmic grid of x in [18, 1e15]; the values at x = 18 (where two of them
have little room) are printed.
"""
import math

import numpy as np


def ineqs(x):
    l = math.log(x)
    out = {}
    # (i)
    lnC3 = math.log(3e7 * 2 ** 1.5) + 1.5 * l
    out["i: lnC3 <= 18.26+1.5l"] = (lnC3, 18.26 + 1.5 * l)
    lnid1 = (64 / 9) * (18.26 + math.log(60) + 2.5 * l) * x ** 2
    out["i: ln(1/d1) <= (159+17.78l)x^2"] = (lnid1, (159 + 17.78 * l) * x ** 2)
    out["i: 6.24+l+ln(1+450x)/(30x) <= (0.35+0.0573l)x"] = (
        6.24 + l + math.log1p(450 * x) / (30 * x), (0.35 + 0.0573 * l) * x)
    out["i: ln(510x) <= 6.24+l"] = (math.log(510 * x), 6.24 + l)
    out["i: (159+17.78l)/30 <= 5.3+0.5927l"] = ((159 + 17.78 * l) / 30, 5.3 + 0.5927 * l)
    out["i: ln16+4ln(30x) <= 16.38+4l <= (5.65+0.65l)x"] = (
        max(math.log(16) + 4 * math.log(30 * x), 16.38 + 4 * l), (5.65 + 0.65 * l) * x)
    # (ii)
    out["ii: 51200(ln15+l) <= (7720+2920l)x"] = (51200 * (math.log(15) + l), (7720 + 2920 * l) * x)
    out["ii: 3.53+l+ln(1+30x)/(2x) <= 500x^4"] = (
        max(math.log(34 * x), 3.53 + l) + math.log1p(30 * x) / (2 * x), 500 * x ** 4)
    out["ii: ln16+4ln(2x) <= (1.49e5+1.81e4l)x^4"] = (
        math.log(16) + 4 * math.log(2 * x), (1.49e5 + 1.81e4 * l) * x ** 4)
    # (iii)
    out["iii: 1638400(ln2+l) <= (7e7+4e6l)x^4"] = (1638400 * (math.log(2) + l), (7e7 + 4e6 * l) * x ** 4)
    out["iii: ln(17x)+ln(1+15x)/x <= (8e8+4e7l)x^9"] = (
        math.log(17 * x) + math.log1p(15 * x) / x, (8e8 + 4e7 * l) * x ** 9)
    out["iii: 2.45e11+2.97e10l <= 1.2e11 l"] = (2.45e11 + 2.97e10 * l, 1.2e11 * l)
    return out


def main():
    assert 51200 * 5.65 == 289280 and 51200 * 0.65 == 33280
    assert 2.97e5 - 289280 == 7720 and abs(3.62e4 - 33280 - 2920) < 1e-9
    assert 1638400 * 1.49e5 < 2.4413e11 and 1638400 * 1.81e4 < 2.9656e10
    assert abs((2.442e11 - 2.4413e11) - 7e7) < 1 and abs((2.966e10 - 2.9656e10) - 4e6) < 1
    assert abs(9 / 64 / 7200 - 1 / 51200) < 1e-18 and 51200 * 32 == 1638400
    worst = {}
    for x in np.geomspace(18, 1e15, 20001):
        for k, (lhs, rhs) in ineqs(float(x)).items():
            assert lhs <= rhs, (k, x, lhs, rhs)
            worst[k] = min(worst.get(k, math.inf), rhs / lhs)
    for k, (lhs, rhs) in ineqs(18.0).items():
        print(f"{k}: at x=18 lhs={lhs:.6g} rhs={rhs:.6g}; min rhs/lhs on grid = {worst[k]:.6g}")
    print("all inequalities hold on 20001 grid points in [18, 1e15]")


if __name__ == "__main__":
    main()
