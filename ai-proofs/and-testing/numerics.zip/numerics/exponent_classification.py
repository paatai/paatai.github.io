r"""Census for the exponent theorem (paper Theorem 8.18; completability is Definition 8.17).

For g: {0,1}^m -> {0,1} depending on all m coordinates with E[g] != 1/2:
  s_b(g) = min{|S| : g(b^m xor 1_S) != g(b^m)},   e(g) = max(s_0, s_1).
Completion condition at b (needed only when s_b >= 2): there are S with
|S| = s_b and g(b^m xor 1_S) != g(b^m), j in S and u in {0,1}^{[m]\S} such
that the input with x_{S\j} = 1-b, x_{[m]\S} = u is insensitive in
coordinate j (flipping x_j does not change g).

Output, for each m: the number of such g, the distribution of e(g), the
number for which the completion condition fails at some b with s_b >= 2,
how many of those are AND_m, OR_m, NAND_m, NOR_m, and the remaining
("exceptional") truth tables (index x = sum_k x_k 2^k).
"""
import itertools
import sys
from collections import Counter


def depends_on_all(tab, m):
    return all(any(tab[x] != tab[x ^ (1 << k)] for x in range(1 << m)) for k in range(m))


def s_b(tab, m, b):
    base_pt = (1 << m) - 1 if b else 0
    base = tab[base_pt]
    for size in range(1, m + 1):
        for S in itertools.combinations(range(m), size):
            if tab[base_pt ^ sum(1 << k for k in S)] != base:
                return size
    return None


def completion(tab, m, b, s):
    full = (1 << m) - 1
    base_pt = full if b else 0
    base = tab[base_pt]
    for S in itertools.combinations(range(m), s):
        if tab[base_pt ^ sum(1 << k for k in S)] == base:
            continue
        rest = [k for k in range(m) if k not in S]
        for j in S:
            face = 0 if b else sum(1 << k for k in S if k != j)
            for r in range(len(rest) + 1):
                for R in itertools.combinations(rest, r):
                    w = face | sum(1 << k for k in R)
                    w &= ~(1 << j)
                    if tab[w] == tab[w | (1 << j)]:
                        return True
    return False


def and_family(tab, m):
    N = 1 << m
    full = N - 1
    AND = [1 if x == full else 0 for x in range(N)]
    OR = [0 if x == 0 else 1 for x in range(N)]
    fam = [AND, OR, [1 - t for t in AND], [1 - t for t in OR]]
    return any(tab == F for F in fam)


def main(M):
    for m in range(2, M + 1):
        N = 1 << m
        total = 0
        edist = Counter()
        fails = 0
        fails_and = 0
        exceptional = []
        for code in range(1 << N):
            tab = [(code >> x) & 1 for x in range(N)]
            if 2 * sum(tab) == N or not depends_on_all(tab, m):
                continue
            total += 1
            s = [s_b(tab, m, 0), s_b(tab, m, 1)]
            edist[max(s)] += 1
            bad = [b for b in (0, 1) if s[b] >= 2 and not completion(tab, m, b, s[b])]
            if bad:
                fails += 1
                if and_family(tab, m):
                    fails_and += 1
                else:
                    exceptional.append(("".join(map(str, tab)), s, bad))
        print(f"m={m}: unbalanced g depending on all coordinates: {total}")
        print(f"   distribution of e(g) = max(s_0,s_1): {dict(sorted(edist.items()))}")
        print(f"   completion condition fails: {fails} (AND/OR/NAND/NOR: {fails_and}, exceptional: {len(exceptional)})")
        for nm, s, bad in exceptional:
            print(f"   exceptional: {nm}  (s_0,s_1)={tuple(s)}  fails at b={bad}")
        sys.stdout.flush()


if __name__ == "__main__":
    main(int(sys.argv[1]) if len(sys.argv) > 1 else 4)
