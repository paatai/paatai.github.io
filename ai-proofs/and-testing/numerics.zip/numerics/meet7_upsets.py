import numpy as np
def upsets(k):
    if k==0: return [0,1]
    prev=upsets(k-1); n=1<<(k-1)
    return [u0|(u1<<n) for u0 in prev for u1 in prev if u0&~u1==0]
U5=np.array(upsets(5),dtype=np.uint64)   # 7581 masks over 32 points
k=6; N=64
pc=np.array([bin(x).count('1') for x in range(N)])
w12=np.full(N,0.5**k); w34=0.75**pc*0.25**(k-pc)
# byte tables
T12=np.zeros((8,256)); T34=np.zeros((8,256))
for j in range(8):
    for v in range(256):
        idx=[8*j+t for t in range(8) if (v>>t)&1]
        T12[j,v]=w12[idx].sum(); T34[j,v]=w34[idx].sum()
best=9; cnt=0; worst=None
for u0 in U5:
    sub=U5[(u0 & ~U5)==0]          # u1 with u0 subset u1
    m=u0 | (sub<<np.uint64(32))
    cnt+=len(m)
    d=np.zeros(len(m)); b=np.zeros(len(m))
    for j in range(8):
        byte=((m>>np.uint64(8*j))&np.uint64(255)).astype(np.int64)
        d+=T12[j,byte]; b+=T34[j,byte]
    v=b-4*d+7*d*d
    # exclude empty set
    v[d==0]=9
    i=np.argmin(v)
    if v[i]<best: best=v[i]; worst=(d[i],b[i])
print("k=6 up-sets:",cnt," min over nonempty of mu34-4d+7d^2 =",best," at (d,mu34)=",worst)
