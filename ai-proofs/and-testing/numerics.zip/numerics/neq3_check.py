"""Checks for Theorem 8.55 (the predicate P = {(a,b,c) in Z_3^3 : a+b+c != 0} under the
uniform distribution pi on P), by exact enumeration on small instances.

  (1) n = 1: brute force over all 27^3 triples; the exact generalized polymorphisms are the
      180 triples of type (A) and the 18 of type (B) (Lemma 8.57).
  (2) The Fourier formula of Lemma 8.56 for random complex H_1,H_2,H_3 (n = 2, 3).
  (3) The local inequalities in the proof of Theorem 8.55 on random perturbations (n <= 4):
      near (B):            delta >= (1/2) sum_j d_j - 2 sum_{j<l} d_j d_l,
      case (alpha):        delta >= (1-d_1-d_2) r* + sum_t (pi_1(t)+pi_2(t)) r_{-a-b-t} - 2 d_1 d_2,
      three constants:     delta >= (1-3h) (sum_j pi*_j + v w),  h = max_j d_j <= 1/4,
      and the bound X <= u v w + u sqrt(v w)/2 for the safe sets.
  (4) The theorem: D <= 3 sqrt(delta) on perturbations of exact triples (n <= 4), where
      D = min over exact triples g of max_j Pr[f_j != g_j]; the extremal example of 8.55(c),
      f_1 = 0, f_2 = 1_E, f_3 = 1 + 1_E (E a subcube or a random set, Pr[E] = eta <= 1/3):
      delta = eta^2 and D = eta, so the constant 1 in 8.55(b) is sharp; and the triple
      f_1 = f_2 = 1_E, f_3 = 1 + 1_E (E a subcube of measure eta): delta = 3 eta^2, D = eta.
"""
import itertools
from collections import Counter

import numpy as np

Q = 3
W3 = np.exp(2j * np.pi / 3)
P = [(a, b, c) for a in range(Q) for b in range(Q) for c in range(Q) if (a + b + c) % Q]
rng = np.random.default_rng(2026)


def points(n):
    return np.array(list(itertools.product(range(Q), repeat=n)), dtype=np.int64)


def index_of(W):
    n = W.shape[1]
    return (W * (Q ** np.arange(n - 1, -1, -1))).sum(axis=1)


def triples_index(n):
    rows = np.array(P)
    combos = np.array(list(itertools.product(range(len(P)), repeat=n)))
    T = rows[combos]
    return index_of(T[:, :, 0]), index_of(T[:, :, 1]), index_of(T[:, :, 2])


def err(f, TI):
    ix, iy, iz = TI
    return np.mean((f[0][ix] + f[1][iy] + f[2][iz]) % Q == 0)


def kind_n1(t):
    nconst = sum(len(set(g)) == 1 for g in t)
    if nconst >= 2:
        return "A"
    if nconst == 0 and all(len(set(g)) == 3 for g in t):
        k = (t[0][1] - t[0][0]) % Q
        ok = all(all((g[a] - g[0] - k * a) % Q == 0 for a in range(Q)) for g in t)
        d = sum(g[0] for g in t) % Q
        return "B" if ok and d == 0 else "other"
    return "other"


def check_n1():
    funcs = list(itertools.product(range(Q), repeat=Q))
    sols = [(g1, g2, g3) for g1 in funcs for g2 in funcs for g3 in funcs
            if all((g1[a] + g2[b] + g3[c]) % Q for a, b, c in P)]
    cnt = Counter(kind_n1(t) for t in sols)
    print(f"(1) n=1: {len(sols)} exact triples, types {dict(cnt)}")
    assert len(sols) == 198 and cnt["A"] == 180 and cnt["B"] == 18


def fourier(H, W):
    n = W.shape[1]
    A = points(n)
    chars = W3 ** ((W @ A.T) % Q)
    return (np.conj(chars) * H[:, None]).mean(axis=0), A


def check_fourier():
    worst = 0.0
    for n in (2, 3):
        W = points(n)
        TI = triples_index(n)
        for _ in range(20):
            H = [rng.normal(size=len(W)) + 1j * rng.normal(size=len(W)) for _ in range(3)]
            lhs = np.mean(H[0][TI[0]] * H[1][TI[1]] * H[2][TI[2]])
            hats = []
            for h in H:
                hh, A = fourier(h, W)
                hats.append(hh)
            wts = (-0.5) ** (A != 0).sum(axis=1)
            rhs = np.sum(hats[0] * hats[1] * hats[2] * wts)
            worst = max(worst, abs(lhs - rhs))
    print(f"(2) Fourier formula: max |E[H1H2H3] - sum| = {worst:.2e}")
    assert worst < 1e-10


def exact_triples(n, W):
    N = len(W)
    out = []
    for i in range(n):
        for kap in (1, 2):
            for d1 in range(Q):
                for d2 in range(Q):
                    d = [d1, d2, (-d1 - d2) % Q]
                    out.append(("B", [(kap * W[:, i] + d[j]) % Q for j in range(3)]))
    return out


def dist(f, W):
    N = len(f[0])
    cnt = [np.bincount(g, minlength=Q) / N for g in f]
    best = 1.0
    for j in range(3):
        o = [k for k in range(3) if k != j]
        for u in range(Q):
            for v in range(Q):
                bad = (-u - v) % Q
                best = min(best, max(1 - cnt[o[0]][u], 1 - cnt[o[1]][v], cnt[j][bad]))
    for _, g in exact_triples(W.shape[1], W):
        best = min(best, max(np.mean(f[j] != g[j]) for j in range(3)))
    return best


def perturb(g, rate):
    f = []
    for h in g:
        h = h.copy()
        m = rng.random(len(h)) < rate
        h[m] = rng.integers(Q, size=m.sum())
        f.append(h)
    return f


def check_local_and_theorem():
    worst_ratio = 0.0
    viol = Counter()
    tested = Counter()
    for n in (2, 3, 4):
        W = points(n)
        N = len(W)
        TI = triples_index(n)
        trials = 2500 if n < 4 else 500
        for _ in range(trials):
            kind = rng.integers(3)
            rate = rng.choice([0.01, 0.03, 0.06, 0.1, 0.2])
            if kind == 0:
                i = rng.integers(n)
                kap = rng.integers(1, Q)
                d1, d2 = rng.integers(Q, size=2)
                d = [d1, d2, (-d1 - d2) % Q]
                g = [(kap * W[:, i] + d[j]) % Q for j in range(3)]
            elif kind == 1:
                a, b = rng.integers(Q, size=2)
                bad = (-a - b) % Q
                g = [np.full(N, a), np.full(N, b), (bad + rng.integers(1, Q, size=N)) % Q]
            else:
                a, b, c = rng.integers(Q, size=3)
                while (a + b + c) % Q == 0:
                    c = rng.integers(Q)
                g = [np.full(N, a), np.full(N, b), np.full(N, c)]
            f = perturb(g, rate)
            delta = err(f, TI)
            D = dist(f, W)
            if delta > 0:
                worst_ratio = max(worst_ratio, D / np.sqrt(delta))
            else:
                assert D == 0
            if kind == 0:
                dj = [np.mean(f[j] != g[j]) for j in range(3)]
                lb = 0.5 * sum(dj) - 2 * (dj[0] * dj[1] + dj[0] * dj[2] + dj[1] * dj[2])
                tested["B"] += 1
                viol["B"] += delta < lb - 1e-12
            if kind == 1:
                d1, d2 = np.mean(f[0] != a), np.mean(f[1] != b)
                r = np.bincount(f[2], minlength=Q) / N
                p1 = np.bincount(f[0], minlength=Q) / N
                p2 = np.bincount(f[1], minlength=Q) / N
                lb = (1 - d1 - d2) * r[(-a - b) % Q] - 2 * d1 * d2
                for t in (1, 2):
                    lb += (p1[(a + t) % Q] + p2[(b + t) % Q]) * r[(-a - b - t) % Q]
                tested["alpha"] += 1
                viol["alpha"] += delta < lb - 1e-12
            if kind == 2:
                modes = [a, b, c]
                sig = (a + b + c) % Q
                dj = [np.mean(f[j] != modes[j]) for j in range(3)]
                if max(dj) <= 0.25:
                    pis = [np.mean(f[j] == (modes[j] - sig) % Q) for j in range(3)]
                    pio = [np.mean(f[j] == (modes[j] + sig) % Q) for j in range(3)]
                    u, v, w = sorted(pio)
                    h = max(dj)
                    lb = (1 - 3 * h) * (sum(pis) + v * w)
                    tested["three"] += 1
                    viol["three"] += delta < lb - 1e-12
                    Aset = [f[j] == (modes[j] + sig) % Q for j in range(3)]
                    X = np.mean(Aset[0][TI[0]] & Aset[1][TI[1]] & Aset[2][TI[2]])
                    viol["X"] += X > u * v * w + 0.5 * u * np.sqrt(v * w) + 1e-12
        E = np.all(W == 0, axis=1)
        f = [E.astype(np.int64), E.astype(np.int64), (1 + E).astype(np.int64)]
        delta, D, eta = err(f, TI), dist(f, W), E.mean()
        print(f"    n={n}: f1=f2=1_E, f3=1+1_E, eta={eta:.5f}: delta={delta:.6f} (3 eta^2={3*eta**2:.6f}), D={D:.5f}")
        assert abs(delta - 3 * eta ** 2) < 1e-12 and abs(D - eta) < 1e-12
        sets = [np.all(W[:, :k] == 0, axis=1) for k in range(1, n + 1)]
        for _ in range(10):
            S = np.zeros(N, dtype=bool)
            S[rng.choice(N, rng.integers(1, N // 3 + 1), replace=False)] = True
            sets.append(S)
        for S in sets:
            f = [np.zeros(N, dtype=np.int64), S.astype(np.int64), (1 + S).astype(np.int64)]
            delta, D, eta = err(f, TI), dist(f, W), S.mean()
            assert abs(delta - eta ** 2) < 1e-12 and abs(D - eta) < 1e-12
        print(f"    n={n}: f1=0, f2=1_E, f3=1+1_E (Theorem 8.55(c)): delta=eta^2 and D=eta for {len(sets)} sets E "
              f"(subcubes and random sets with Pr[E]<=1/3)")
    print(f"(3) local inequalities: tested {dict(tested)}, violations {dict(viol)}")
    print(f"(4) max D/sqrt(delta) over perturbations (n<=4): {worst_ratio:.3f}  "
          f"(theorem: <= (1+56 delta^(1/8)) for delta <= 1e-16; the constant 1 is attained by 8.55(c))")
    assert sum(viol.values()) == 0 and worst_ratio <= 3


if __name__ == "__main__":
    check_n1()
    check_fourier()
    check_local_and_theorem()
    print("all checks passed")
