"""Floating-point estimate of the SDPI constant theta(pi, K_S) of Lemma 8.22 for the
non-completable triples (g, b, S) with m <= 4 (Nelder-Mead over softmax-parametrised nu,
60 restarts per triple). Heuristic only: used as a sanity check of
theta <= 1 - lambda_S (Lemma 8.22(c)); no proof depends on it.
"""
import itertools, sys
import numpy as np
from scipy.optimize import minimize
sys.path.insert(0, __import__('os').path.dirname(__import__('os').path.abspath(__file__)))
from exponent_classification import depends_on_all, s_b, completion, and_family

def channel(tab, m, S):
    rest = [k for k in range(m) if k not in S]
    K = []
    for xs in range(1 << len(S)):
        x = sum(((xs >> t) & 1) << S[t] for t in range(len(S)))
        ones = sum(tab[x | sum(((ns >> t) & 1) << rest[t] for t in range(len(rest)))] for ns in range(1 << len(rest)))
        p1 = ones / (1 << len(rest))
        K.append([1 - p1, p1])
    return np.array(K)

def D(p, q):
    m = p > 1e-300
    return float(np.sum(p[m] * np.log(p[m] / q[m])))

def theta(K, restarts=60, rng=np.random.default_rng(0)):
    nx = K.shape[0]; pi = np.full(nx, 1.0 / nx); piK = pi @ K
    best = 0.0
    def neg(w):
        nu = np.exp(w - w.max()); nu /= nu.sum()
        d = D(nu, pi)
        if d < 1e-12: return 0.0
        return -D(nu @ K, piK) / d
    for r in range(restarts):
        w0 = rng.normal(scale=[0.01, 0.3, 1, 3, 10][r % 5], size=nx)
        res = minimize(neg, w0, method='Nelder-Mead', options={'maxiter': 4000, 'xatol': 1e-10, 'fatol': 1e-12})
        best = max(best, -res.fun)
    return best

for m in (3, 4):
    N = 1 << m; worst = 0; viol = 0; cnt = 0
    for code in range(1 << N):
        tab = [(code >> x) & 1 for x in range(N)]
        if 2 * sum(tab) == N or not depends_on_all(tab, m) or and_family(tab, m):
            continue
        for b in (0, 1):
            s = s_b(tab, m, b)
            if s < 2 or completion(tab, m, b, s):
                continue
            base = N - 1 if b else 0
            for S in itertools.combinations(range(m), s):
                if tab[base ^ sum(1 << k for k in S)] == tab[base]: continue
                K = channel(tab, m, list(S))
                lam = K[:, 0].min() + K[:, 1].min()
                th = theta(K)
                cnt += 1; worst = max(worst, th)
                if th > 1 - lam + 1e-6: viol += 1
    print(f"m={m}: non-completable (g,b,S) triples: {cnt}; max numerical theta = {worst:.4f}; Doeblin violations: {viol}")
