#!/usr/bin/env python3
"""Exact integer computation of eps(f) and dist(f) for symmetric f(x) = 1{#zeros(x) in Z} (uniform measure).

Closed forms (P, Q = zero sets of x, y; the zero set of x & y is P u Q):
  M = 2^n mu             = sum_{m in Z} C(n,m)
  H = 4^n Pr[x&y in A]   = sum_{m in Z} C(n,m) 3^m
  G = 4^n tau            = sum_{m in Z} C(n,m) N_m,
      N_m = #{(P,Q): P u Q = [m], |P|,|Q| in Z} = sum_{i in Z, i<=m} C(m,i) sum_{k=0}^{i} C(i,k) [m-i+k in Z]
      (choose P of size i inside [m]; Q contains [m]\\P and k further points of P, so |Q| = m-i+k)
  E = 4^n eps = H + M^2 - 2G          (eps = Pr[f(x&y)=1] + Pr[f(x)f(y)=1] - 2 Pr[both])
  D = 2^n dist = min(M, min_{0<=u<=n} (M + 2^u - 2 sum_{j in Z} C(u,j)))   (AND_S with |S| = n-u)
Usage: python3 exact_band_check.py n z1,z2,a-b,...   [--brute]  (--brute also runs the O(n^3) brute force)
"""
import hashlib
import sys
from fractions import Fraction
from math import comb

from counterexample_sharp import F_of, exact_dist_times_2n, exact_eps_times_4n, parse_Z


def intervals_of(Z):
    out = []
    for z in Z:
        if out and z == out[-1][1] + 1:
            out[-1][1] = z
        else:
            out.append([z, z])
    return out


def exact_band(n, Z):
    Z = sorted(set(z for z in Z if 0 <= z <= n))
    Zset = set(Z)
    ivs = intervals_of(Z)
    M = sum(comb(n, m) for m in Z)
    H = sum(comb(n, m) * 3 ** m for m in Z)
    N = {m: 0 for m in Z}
    best_D, best_u = M, None
    row = [1]  # row u of Pascal's triangle
    for u in range(n + 1):
        if u > 0:
            row = [1] + [row[k - 1] + row[k] for k in range(1, u)] + [1]
        sZ = sum(row[j] for j in Z if j <= u)
        val = M + (1 << u) - 2 * sZ
        if val < best_D:
            best_D, best_u = val, u
        if u in Zset:
            i = u
            pref = [0]
            for v in row:
                pref.append(pref[-1] + v)
            for m in Z:
                if m < i:
                    continue
                # sum_{k=0}^{i} C(i,k) [m-i+k in Z]  =  sum over j in Z with m-i <= j <= m of C(i, j-m+i)
                s = 0
                lo, hi = m - i, m
                for zl, zh in ivs:
                    a, b = max(zl, lo), min(zh, hi)
                    if a <= b:
                        s += pref[b - lo + 1] - pref[a - lo]
                N[m] += comb(m, i) * s
    G = sum(comb(n, m) * N[m] for m in Z)
    E = H + M * M - 2 * G
    return M, best_D, best_u, E


def show(name, v):
    s = str(v)
    if len(s) <= 200:
        return f"{name} = {s}"
    return f"{name} = <{len(s)} digits, sha256 {hashlib.sha256(s.encode()).hexdigest()[:16]}...>"


if __name__ == "__main__":
    if hasattr(sys, "set_int_max_str_digits"):
        sys.set_int_max_str_digits(0)
    n = int(sys.argv[1])
    Z = parse_Z(sys.argv[2])
    M, D, u, E = exact_band(n, Z)
    r = Fraction(D * D, E)
    print(f"n={n}, Z={Z if len(Z) < 40 else 'intervals ' + str(intervals_of(list(Z)))}")
    print("  " + show("M = 2^n mu", M))
    print("  " + show("D = 2^n dist", D) + f"  (nearest member: {'0' if u is None else f'AND_S with |S|={n - u}'})")
    print("  " + show("E = 4^n eps", E))
    print(f"  dist^2/eps = D^2/E = {r.numerator * 10**12 // r.denominator / 10**12:.12f} (truncated);  D^2 > E: {D * D > E}")
    for num, den in [(4, 3), (134, 100), (1342, 1000)]:
        print(f"  D^2/E > {num}/{den}: {den * D * D > num * E}")
    for a in sys.argv[3:]:
        if a.startswith("--out="):
            with open(a[6:], "w") as fh:
                fh.write(f"n={n}\nZ={sys.argv[2]}\nM={M}\nD={D}\nE={E}\n")
    if "--brute" in sys.argv:
        F = F_of(n, set(Z))
        E2 = exact_eps_times_4n(n, F)
        D2, s2, A2 = exact_dist_times_2n(n, F)
        print(f"  brute force: E equal: {E2 == E}, D equal: {D2 == D}, M equal: {A2 == M}")
