#!/usr/bin/env python3
"""Fast floating-point evaluation and optimisation of band-structured symmetric f for large n.

f(x) = 1{#zeros(x) in Z}, Z a union of intervals. In probability form (cf. exact_band_check.py):
  mu  = sum_{m in Z} Pr[Bin(n,1/2) = m]
  meet = Pr[f(x&y)=1] = sum_{m in Z} Pr[Bin(n,3/4) = m]
  tau = sum_{m in Z} Pr[Bin(n,3/4) = m] * nu_m,
        nu_m = sum_{i in Z} Pr[Bin(m,2/3) = i] * Pr[m - i + Bin(i,1/2) in Z]
  eps = meet + mu^2 - 2 tau,   dist = mu - max(0, max_u 2^{u-n} (2 Pr[Bin(u,1/2) in Z] - 1)).
Usage: python3 band_fast.py n1 n2 ...   (optimises 2 bands + optional top band, prints the best)
"""
import sys

import numpy as np
from scipy.stats import binom


def prob_in(ivs, N, shift):
    """Pr[shift + Bin(N, 1/2) in union of intervals], vectorised over arrays N, shift."""
    tot = np.zeros(np.broadcast(N, shift).shape)
    for zl, zh in ivs:
        tot += binom.cdf(zh - shift, N, 0.5) - binom.cdf(zl - shift - 1, N, 0.5)
    return tot


def evaluate(n, ivs):
    Z = np.concatenate([np.arange(a, b + 1) for a, b in ivs])
    mu = binom.pmf(Z, n, 0.5).sum()
    pm = binom.pmf(Z, n, 0.75)
    meet = pm.sum()
    tau = 0.0
    for m, w in zip(Z, pm):
        if w < 1e-300:
            continue
        i = Z[Z <= m]
        pi = binom.pmf(i, m, 2.0 / 3.0)
        tau += w * np.sum(pi * prob_in(ivs, i, m - i))
    eps = meet + mu * mu - 2 * tau
    u = np.arange(n + 1)
    gain = np.exp2(u - n) * (2 * prob_in(ivs, u, 0) - 1)
    k = int(np.argmax(gain))
    dist = mu - max(0.0, gain[k])
    return dist * dist / eps, dict(mu=mu, eps=eps, dist=dist, S=(n - k) if gain[k] > 0 else None)


def climb(n, ivs, steps=(8, 4, 2, 1)):
    ivs = [list(v) for v in ivs]
    best = evaluate(n, ivs)[0]
    for st in steps:
        improved = True
        while improved:
            improved = False
            for bi in range(len(ivs)):
                for e in range(2):
                    for sg in (-1, 1):
                        cand = [v[:] for v in ivs]
                        cand[bi][e] += sg * st
                        if cand[bi][0] > cand[bi][1] or cand[bi][0] < 0 or cand[bi][1] > n:
                            continue
                        if any(cand[j][1] >= cand[j + 1][0] for j in range(len(cand) - 1)):
                            continue
                        r = evaluate(n, cand)[0]
                        if r > best + 1e-12:
                            best, ivs, improved = r, cand, True
    return best, ivs


if __name__ == "__main__":
    for n in [int(t) for t in sys.argv[1:]]:
        s = np.sqrt(n)
        # zero counts: first band = weights >= n/2 + 0.06 sqrt(n) (X >= 0.12), second = weights in n/4 + [0.45, 2.5] sqrt(n)
        b1 = int(n / 2 - 0.06 * s)
        a1 = max(0, int(n / 2 - 3.8 * s))
        a2 = int(3 * n / 4 - 2.5 * s)
        b2 = int(3 * n / 4 - 0.45 * s)
        r, ivs = climb(n, [(a1, b1), (a2, b2)])
        r2, info = evaluate(n, ivs)
        print(f"n={n}: ratio {r:.9f} bands(zero counts) {ivs}  mu={info['mu']:.4f} eps={info['eps']:.4f} "
              f"dist={info['dist']:.4f} nearest |S|={info['S']}", flush=True)
