#!/usr/bin/env python3
"""Leading-order (n -> infinity) test of the sharp conjecture dist^2 <= eps for top-level symmetric families.

f(x) = 1 iff #zeros(x) in Z, Z a finite set of integers with max K. As n -> infinity with Z fixed:
  4^n (tau - sigma) = sum_{m in Z} C(n,m) (2 N_m(Z) - 3^m),  N_m(Z) = #{(P,Q): P u Q = [m], |P|,|Q| in Z},
  2^n Delta_S = 2 sum_{j in Z} C(u,j) - 2^u  for |S^c| = u,  c_Z = max(0, max_u of that),
and eps >= dist^2  <=>  tau - sigma <= 2 mu Delta* - Delta*^2, whose leading order (C(n,K) terms) is
  2 N_K(Z) - 3^K <= 2 c_Z.
Prints every Z violating the leading-order inequality (none expected if the conjecture holds), and the
tightest cases.
"""
import sys
from math import comb


def N(m, Z):
    tot = 0
    for i in Z:
        if i > m:
            continue
        for j in Z:
            if j > m or i + j < m:
                continue
            tot += comb(m, i) * comb(i, i + j - m)
    return tot


def cZ(Z):
    K = max(Z)
    best = 0
    for u in range(0, 2 * K + 3):
        best = max(best, 2 * sum(comb(u, j) for j in Z if j <= u) - 2 ** u)
    return best


if __name__ == "__main__":
    Kmax = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    worst = []
    nviol = 0
    for K in range(0, Kmax + 1):
        for mask in range(1 << K):
            Z = [j for j in range(K) if (mask >> j) & 1] + [K]
            lhs = 2 * N(K, Z) - 3 ** K
            rhs = 2 * cZ(Z)
            if lhs > rhs:
                nviol += 1
                print("VIOLATION", Z, lhs, rhs)
            if lhs > 0:
                worst.append((lhs / rhs if rhs > 0 else float('inf'), Z, lhs, rhs))
    worst.sort(reverse=True)
    print(f"K <= {Kmax}: {nviol} violations of 2N_K - 3^K <= 2c_Z")
    for r, Z, l, rr in worst[:15]:
        print(f"  ratio {r:.4f}  Z={Z}  2N_K-3^K={l}  2c_Z={rr}")
