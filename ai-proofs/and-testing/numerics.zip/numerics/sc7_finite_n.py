#!/usr/bin/env python3
"""Finite-n values of dist^2/eps for the two-band family of Proposition prop:gausslimit (floating point).

f_n = 1{|x| in W}, W = B1 u B2, B1 = {w >= n/2}, B2 = {n/4 + u0 sqrt(n)/4 <= w <= n/4 + u1 sqrt(n)/4}
(w = number of ones; the band ends are rounded inwards: ceil for the lower end, floor for the upper end).

With N11, N10, N01 the numbers of coordinates where (x_i, y_i) = (1,1), (1,0), (0,1):
  eps = Pr[N11 in W] + mu^2 - 2 tau,  tau = Pr[N11 in W, N11 + N10 in W, N11 + N01 in W],
where N11 ~ Bin(n, 1/4); given N11 = k, N10 ~ Bin(n-k, 1/3); given also N10 = a, N01 ~ Bin(n-k-a, 1/2).
dist = min(mu, min_s [mu + 2^-s - 2^(1-s) Pr[s + Bin(n-s, 1/2) in W]])  (nearest AND_S, |S| = s).
Terms more than 14 standard deviations from the mean of N11 or N10 are dropped (mass < 1e-40).
Cross-checked against the exact integer values at n = 1000 and 4000 (exact_band_check.exact_band).
"""
import math
import sys
from fractions import Fraction

import numpy as np
from scipy.stats import binom

U0, U1 = Fraction(157, 100), Fraction(12)
CUT = 14.0


def ge_root(t, u, n):
    """t >= u sqrt(n), exactly, for integers t, n >= 0 and rational u > 0."""
    return t >= 0 and t * t * u.denominator ** 2 >= u.numerator ** 2 * n


def le_root(t, u, n):
    """t <= u sqrt(n), exactly, for integers t, n >= 0 and rational u > 0."""
    return t <= 0 or t * t * u.denominator ** 2 <= u.numerator ** 2 * n


def weights(n):
    """Band ends in exact integer arithmetic: B2 = {w : U0 sqrt(n) <= 4w - n <= U1 sqrt(n)}, B1 = {2w >= n}."""
    b1 = ((n + 1) // 2, n)
    lo = math.floor(n / 4 + float(U0) * math.sqrt(n) / 4) - 2
    assert not ge_root(4 * lo - n, U0, n)
    while not ge_root(4 * lo - n, U0, n):
        lo += 1
    hi = math.floor(n / 4 + float(U1) * math.sqrt(n) / 4) + 2
    assert not le_root(4 * hi - n, U1, n)
    while not le_root(4 * hi - n, U1, n):
        hi -= 1
    b2 = (lo, hi)
    return [b2, b1] if b2[1] < b1[0] else [(b2[0], n)]


def prob_in(ivs, shift, N, p):
    """Pr[shift + Bin(N, p) in union of intervals], vectorized over N (and shift)."""
    tot = 0.0
    for lo, hi in ivs:
        tot = tot + binom.cdf(hi - shift, N, p) - binom.cdf(lo - shift - 1, N, p)
    return tot


def ratio(n):
    ivs = weights(n)
    mu = float(prob_in(ivs, 0, n, 0.5))
    p_meet = float(prob_in(ivs, 0, n, 0.25))
    sd11 = math.sqrt(n * 3 / 16)
    ks = np.arange(max(0, math.floor(n / 4 - CUT * sd11)), min(n, math.ceil(n / 4 + CUT * sd11)) + 1)
    inW = np.zeros_like(ks, dtype=bool)
    for lo, hi in ivs:
        inW |= (ks >= lo) & (ks <= hi)
    tau = 0.0
    for k in ks[inW]:
        r = n - k
        sd10 = math.sqrt(r * 2 / 9)
        a = np.arange(max(0, math.floor(r / 3 - CUT * sd10)), min(r, math.ceil(r / 3 + CUT * sd10)) + 1)
        ok = np.zeros_like(a, dtype=bool)
        for lo, hi in ivs:
            ok |= (k + a >= lo) & (k + a <= hi)
        a = a[ok]
        if a.size == 0:
            continue
        inner = prob_in(ivs, k, r - a, 0.5)
        tau += binom.pmf(k, n, 0.25) * float(np.sum(binom.pmf(a, r, 1 / 3) * inner))
    eps = p_meet + mu * mu - 2 * tau
    dist = mu
    for s in range(0, 60):
        dist = min(dist, mu + 2.0 ** -s - 2.0 ** (1 - s) * float(prob_in(ivs, s, n - s, 0.5)))
    return dist * dist / eps, dist, eps


if __name__ == "__main__":
    ns = [int(a) for a in sys.argv[1:]] or [1000, 4000, 16000, 64000, 256000]
    for n in ns:
        r, d, e = ratio(n)
        print(f"n={n:7d}  dist={d:.10f}  eps={e:.10f}  dist^2/eps={r:.6f}", flush=True)
    print("Gaussian limit (Proposition prop:gausslimit): 1.351168")
