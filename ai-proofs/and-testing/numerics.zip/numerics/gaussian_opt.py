#!/usr/bin/env python3
"""Optimise the Gaussian-limit ratio over general g: R -> [0,1] (discretised), with h chosen optimally.

R(g) = min(mu, 1-mu)^2 / (mu^2 - Gamma(g)),  Gamma(g) = E[(2 phi_g(U) - 1)_+],
phi_g(u) = E[g(X) g(Y) | X+Y+V = u],  X, Y, V iid N(0,1).
Discretisation: X, Y on a grid of cells; the joint law of (X, Y, U) is integrated exactly over cells in
X, Y (cell probabilities) and U is integrated on a fine grid.
"""
import sys

import numpy as np
from scipy.stats import norm


def setup(L=6.0, h=0.08, Lu=10.0, hu=0.05):
    edges = np.arange(-L, L + h / 2, h)
    xc = 0.5 * (edges[1:] + edges[:-1])
    px = np.diff(norm.cdf(edges))
    px[0] += norm.cdf(-L)
    px[-1] += norm.sf(L)
    u = np.arange(-Lu, Lu + hu / 2, hu)
    # P(X in cell k, Y in cell l, U in [u, u+hu)) ~ px_k px_l * pdf_V(u - x_k - y_l) * hu
    S = xc[:, None] + xc[None, :]
    W = px[None, :, None] * px[None, None, :] * norm.pdf(u[:, None, None] - S[None, :, :]) * hu
    pu = W.sum(axis=(1, 2))
    return xc, px, u, W, pu


def ratio_and_grad(g, px, W, pu):
    mu = g @ px
    joint = np.einsum('ukl,k,l->u', W, g, g)  # P(both, U in cell)
    phi = joint / np.maximum(pu, 1e-300)
    act = (2 * phi - 1) > 0
    Gam = np.sum(pu[act] * (2 * phi[act] - 1))
    den = mu * mu - Gam
    d = min(mu, 1 - mu)
    R = d * d / den
    # gradients
    dGam = 2 * 2 * np.einsum('ukl,l->k', W[act], g)  # d/dg_k of sum_u 2*joint(u) over active u
    dmu = px
    dd = dmu if mu <= 0.5 else -dmu
    dden = 2 * mu * dmu - dGam
    dR = (2 * d * dd * den - d * d * dden) / den ** 2
    return R, mu, Gam, dR


def optimise(g0, px, W, pu, steps=3000, lr=0.5):
    g = g0.copy()
    best = (-1, None)
    for t in range(steps):
        R, mu, Gam, dR = ratio_and_grad(g, px, W, pu)
        if R > best[0]:
            best = (R, g.copy(), mu, Gam)
        step = lr * dR / (np.abs(dR).max() + 1e-12)
        g = np.clip(g + step * (0.995 ** t), 0, 1)
    return best


if __name__ == "__main__":
    xc, px, u, W, pu = setup()
    print("grid sizes", len(xc), len(u), "sum pu", pu.sum(), flush=True)
    inits = {
        "threshold a=0": (xc >= 0).astype(float),
        "two-sided |x|>=0.674": (np.abs(xc) >= 0.6745).astype(float),
        "threshold a=0.3": (xc >= 0.3).astype(float),
        "half": 0.5 * np.ones_like(xc),
    }
    rng = np.random.default_rng(0)
    for k in range(3):
        inits[f"random{k}"] = rng.random(len(xc))
    for name, g0 in inits.items():
        R0 = ratio_and_grad(g0, px, W, pu)[0]
        R, g, mu, Gam = optimise(g0, px, W, pu)
        on = xc[g > 0.5]
        desc = f"g>1/2 on [{on.min():.2f},{on.max():.2f}]" if len(on) else "g<=1/2 everywhere"
        frac = np.mean((g > 0.01) & (g < 0.99))
        print(f"{name:24s}: start R={R0:.5f} -> optimised R={R:.5f} (mu={mu:.4f}, Gamma={Gam:.5f}); {desc}; "
              f"fraction of fractional cells {frac:.2f}", flush=True)
        np.save(f"/tmp/gopt_{name.replace(' ', '_')}.npy", np.vstack([xc, g]))
