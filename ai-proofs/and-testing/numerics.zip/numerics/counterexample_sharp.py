#!/usr/bin/env python3
"""Exact check of counterexamples to the sharp conjecture dist(f)^2 <= eps(f) (uniform measure).

f(x) = 1 iff the number of zeros of x lies in a set Z, on n variables.
eps is computed by brute force over coordinate-type counts (a,b,c,d) = #{i: (x_i,y_i) = (1,1),(1,0),(0,1),(0,0)}:
    4^n eps = sum_{a+b+c+d=n} n!/(a!b!c!d!) [F(a) != F(a+b) F(a+c)],   F(w) = f on inputs of weight w.
dist is computed over all members of A_n: the constant 0 and AND_S for every size s = |S| (by symmetry):
    2^n Pr[f != AND_S] = sum_w C(n,w) F(w) + C(n-s, w-s) (1 - 2F(w)).
All arithmetic is in Python integers; the verdict compares D^2 with E exactly (D = 2^n dist, E = 4^n eps).

Usage:  python3 counterexample_sharp.py                 (runs the built-in examples)
        python3 counterexample_sharp.py n z1,z2,...     (one example; ranges like 15-23 allowed)
"""
import sys
from fractions import Fraction
from math import comb, factorial

EXAMPLES = [
    (35, (6, 7, 8, 9, 10, 11, 15)),
    (40, (6, 7, 8, 9, 10, 11, 15)),
    (33, (7, 8, 9, 10, 11, 12, 16)),
    (49, (0,) + tuple(range(15, 24)) + (30, 31, 32)),
    (69, (0, 3) + tuple(range(21, 34)) + tuple(range(43, 48))),
]


def F_of(n, Z):
    return [1 if (n - w) in Z else 0 for w in range(n + 1)]


def exact_eps_times_4n(n, F):
    fact = [factorial(k) for k in range(n + 1)]
    E = 0
    for a in range(n + 1):
        for b in range(n + 1 - a):
            for c in range(n + 1 - a - b):
                d = n - a - b - c
                if F[a] != (F[a + b] & F[a + c]):
                    E += fact[n] // (fact[a] * fact[b] * fact[c] * fact[d])
    return E


def exact_dist_times_2n(n, F):
    A = sum(comb(n, w) * F[w] for w in range(n + 1))
    best = A  # distance to the constant 0
    best_s = None
    for s in range(n + 1):
        val = A + sum(comb(n - s, w - s) * (1 - 2 * F[w]) for w in range(s, n + 1))
        if val < best:
            best, best_s = val, s
    return best, best_s, A


def parse_Z(spec):
    Z = set()
    for part in spec.split(","):
        if "-" in part:
            lo, hi = part.split("-")
            Z.update(range(int(lo), int(hi) + 1))
        else:
            Z.add(int(part))
    return tuple(sorted(Z))


def report(n, Z):
    F = F_of(n, set(Z))
    E = exact_eps_times_4n(n, F)
    D, s, A = exact_dist_times_2n(n, F)
    ratio = Fraction(D * D, E)
    verdict = "dist^2 > eps  (COUNTEREXAMPLE to dist^2 <= eps)" if D * D > E else "dist^2 <= eps"
    print(f"n={n}, Z={list(Z)}:\n  2^n mu = {A}\n  2^n dist = D = {D} (nearest member: "
          f"{'0' if s is None else f'AND_S with |S|={s}'})\n  4^n eps = E = {E}\n"
          f"  mu = {A / 2**n:.6e}, eps = {E / 4**n:.6e}, dist = {D / 2**n:.6e}\n"
          f"  dist^2/eps = D^2/E = {float(ratio):.12f};  D^2 - E = {D * D - E};  {verdict}", flush=True)


if __name__ == "__main__":
    if len(sys.argv) == 3:
        report(int(sys.argv[1]), parse_Z(sys.argv[2]))
    else:
        for n, Z in EXAMPLES:
            report(n, Z)
