#!/usr/bin/env python3
"""Exact eps and dist for symmetric f(x) = F(|x|), all F in {0,1}^{n+1}, small n (vectorised).

For x,y uniform: (a,b,c,d) = (#11, #10, #01, #00) ~ Multinomial(n; 1/4,...). |x&y| = a, |x| = a+b, |y| = a+c.
dist to AND_S with |S| = s:  Pr[F(|x|) != 1{x_S = 1}] = sum_{j,l} C(s,j) C(n-s,l) 2^{-n} [F(j+l) != 1{j=s}].
Reports max over all symmetric F of delta^2/eps.
"""
import sys
from math import comb

import numpy as np


def tables(n):
    trip = []
    prob = []
    for a in range(n + 1):
        for b in range(n + 1 - a):
            for c in range(n + 1 - a - b):
                d = n - a - b - c
                m = comb(n, a) * comb(n - a, b) * comb(n - a - b, c)
                trip.append((a, a + b, a + c))
                prob.append(m / 4.0 ** n)
    trip = np.array(trip)
    prob = np.array(prob)
    # distance kernels: for each s, weight of (k = |x|, inS = [j == s])
    K = np.zeros((n + 1, n + 1, 2))  # K[s, k, ind] probability that |x| = k and AND_S(x) = ind
    for s in range(n + 1):
        for j in range(s + 1):
            for l in range(n - s + 1):
                K[s, j + l, 1 if j == s else 0] += comb(s, j) * comb(n - s, l) / 2.0 ** n
    return trip, prob, K


def run(n, top=5):
    trip, prob, K = tables(n)
    nF = 1 << (n + 1)
    Fs = ((np.arange(nF)[:, None] >> np.arange(n + 1)[None, :]) & 1).astype(np.int8)
    fa = Fs[:, trip[:, 0]]
    fx = Fs[:, trip[:, 1]]
    fy = Fs[:, trip[:, 2]]
    eps = ((fa != (fx & fy)) * prob[None, :]).sum(axis=1)
    # dist to AND_s: sum_k K[s,k,0]*F(k) + K[s,k,1]*(1-F(k))
    dist_and = Fs @ K[:, :, 0].T + (1 - Fs) @ K[:, :, 1].T  # (nF, n+1)
    mu = Fs @ K[0, :, 1]  # s=0: AND_empty = 1 always, K[0,k,1] = Pr[|x|=k]
    delta = np.minimum(mu, dist_and.min(axis=1))
    ratio = np.where(eps > 0, delta ** 2 / np.maximum(eps, 1e-300), 0)
    idx = np.argsort(-ratio)[:top]
    return [(ratio[i], ''.join(map(str, Fs[i])), eps[i], delta[i], mu[i]) for i in idx]


if __name__ == "__main__":
    nmax = int(sys.argv[1]) if len(sys.argv) > 1 else 14
    for n in range(2, nmax + 1):
        res = run(n, top=3)
        r, F, e, d, m = res[0]
        print(f"n={n:2d}: max delta^2/eps = {r:.6f}  F(0..n)={F}  eps={e:.3e} delta={d:.3e} mu={m:.3e}"
              f" | 2nd {res[1][0]:.6f} {res[1][1]} | 3rd {res[2][0]:.6f} {res[2][1]}", flush=True)
