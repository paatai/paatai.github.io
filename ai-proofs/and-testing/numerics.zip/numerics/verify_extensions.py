#!/usr/bin/env python3
"""Exhaustive floating-point checks of the extensions in MAIN_RESULT on small n.

(P) p-biased, one function, all f on n<=4, several p:
    Lemma 2.2   sum_{S ni i} fhat(S)^2 >= (1-p) mu - b_i
    Cor 3.2     sum_S fhat(S)^2 Pr[f=1, x_S != 1] <= eps
    Prop 4.2    with theta=(1-p)/2, C={i: b_i <= theta mu}:
                sum_{S not in C} fhat^2 <= 2 eps/((1-p) mu),  Pr[f=1, x_C != 1] <= 2 eps/((1-p) mu)
    Thm 5.1     dist <= min(mu, 6 eps/((1-p) mu));  kappa<1/2 => Pr[f != AND_C] <= kappa mu (2-3kappa)/(1-2kappa)
(M) m-ary test, m=3, all f on n<=4, several p:
    Cor 3.3     sum_S fhat(S)^2 Pr[f=1, x_S != 1] <= eps_3 / mu
    Thm 1.4(b)  (p=1/2) dist <= min(mu, 12 eps_3/mu^2)
(T) three functions, all (F,G,H) on n<=3, x~mu_p, y~mu_rho, several (p,rho):
    Lemma 3.1   sum_S Ghat(S)^2 Pr_rho[H=1, y_S != 1] <= eps(F,G,H)  (checked against min_F eps)
    Thm 1.4(c)  the dichotomy, for every F.
Prints the minimal slack (rhs - lhs) of every inequality; a negative slack beyond 1e-12 is a violation.
"""
import itertools
import sys

import numpy as np

TOL = 1e-12


def cube(n):
    N = 1 << n
    pts = np.arange(N)
    bits = ((pts[:, None] >> np.arange(n)[None, :]) & 1).astype(float)  # (N, n)
    return N, pts, bits


def weights(bits, p):
    return np.prod(np.where(bits == 1, p, 1 - p), axis=1)


def phi(bits, p, pts):
    """phi[S, x] = prod_{i in S} (x_i - p)/sqrt(p(1-p))."""
    N, n = bits.shape
    z = (bits - p) / np.sqrt(p * (1 - p))  # (N, n)
    out = np.ones((N, N))
    for S in range(N):
        for i in range(n):
            if (S >> i) & 1:
                out[S] *= z[:, i]
    return out


def all_functions(N):
    nf = 1 << N
    return ((np.arange(nf)[:, None] >> np.arange(N)[None, :]) & 1).astype(np.int8)


def and_matrix(pts):
    return ((pts[None, :] & pts[:, None]) == pts[:, None]).astype(np.int8)  # [S, x]


class Slack:
    def __init__(self):
        self.d = {}

    def add(self, name, rhs_minus_lhs):
        v = float(np.min(rhs_minus_lhs)) if np.size(rhs_minus_lhs) else np.inf
        self.d[name] = min(self.d.get(name, np.inf), v)
        if v < -TOL:
            raise AssertionError(f"{name} violated: slack {v}")

    def report(self, header):
        print(header)
        for k, v in self.d.items():
            print(f"   {k:55s} min slack = {v:.3e}")


def part_P(n, p, sl):
    N, pts, bits = cube(n)
    w = weights(bits, p)
    Ph = phi(bits, p, pts)
    F = all_functions(N).astype(float)
    AND = and_matrix(pts).astype(float)
    meet = pts[:, None] & pts[None, :]
    W2 = w[:, None] * w[None, :]
    mu = F @ w
    eps = np.zeros(len(F))
    for x in range(N):
        fx = F[:, x][:, None]
        eps += ((F[:, meet[x]] != fx * F) * W2[x][None, :]).sum(axis=1)
    fhat = F @ (Ph * w[None, :]).T  # (nf, N)
    aS = F @ (AND * w[None, :]).T  # Pr[f=1, x_S=1]
    b = np.stack([F @ (w * (bits[:, i] == 0)) for i in range(n)], axis=1)
    for i in range(n):
        Smask = ((pts >> i) & 1) == 1
        sl.add(f"P: Lemma 2.2 (p={p})", (fhat[:, Smask] ** 2).sum(1) - ((1 - p) * mu - b[:, i]))
    lhs = (fhat ** 2 * (mu[:, None] - aS)).sum(1)
    sl.add(f"P: Cor 3.2 (p={p})", eps - lhs)
    theta = (1 - p) / 2
    distAND = ((F[:, None, :] != AND[None, :, :]) * w[None, None, :]).sum(2)  # (nf, N)
    dist = np.minimum(mu, distAND.min(1))
    pos = mu > 0
    for k in np.nonzero(pos)[0]:
        C = sum(1 << i for i in range(n) if b[k, i] <= theta * mu[k] + 1e-15)
        notC = (~C) & (N - 1)
        sel = (pts & notC) != 0
        bound = 2 * eps[k] / ((1 - p) * mu[k])
        sl.add(f"P: Prop 4.2(a) (p={p})", bound - (fhat[k, sel] ** 2).sum())
        offC = (pts & C) != C
        sl.add(f"P: Prop 4.2(b) (p={p})", bound - (F[k, offC] * w[offC]).sum())
        kappa = 2 * eps[k] / ((1 - p) * mu[k] ** 2)
        if kappa < 0.5:
            sl.add(f"P: Thm 5.1 final step (p={p})",
                   kappa * mu[k] * (2 - 3 * kappa) / (1 - 2 * kappa) - distAND[k, C])
        sl.add(f"P: Thm 5.1 dist bound (p={p})", min(mu[k], 6 * eps[k] / ((1 - p) * mu[k])) - dist[k])


def part_M(n, p, sl, m=3):
    N, pts, bits = cube(n)
    w = weights(bits, p)
    Ph = phi(bits, p, pts)
    F = all_functions(N).astype(float)
    AND = and_matrix(pts).astype(float)
    mu = F @ w
    eps = np.zeros(len(F))
    for tup in itertools.product(range(N), repeat=m):
        z = tup[0]
        wt = 1.0
        prod = np.ones(len(F))
        for t in tup:
            z &= t
            wt *= w[t]
            prod = prod * F[:, t]
        eps += (F[:, z] != prod) * wt
    fhat = F @ (Ph * w[None, :]).T
    aS = F @ (AND * w[None, :]).T
    lhs = (fhat ** 2 * (mu[:, None] - aS)).sum(1)
    pos = mu > 0
    sl.add(f"M: Cor 3.3 m={m} (p={p})", eps[pos] / mu[pos] ** (m - 2) - lhs[pos])
    if p == 0.5:
        distAND = ((F[:, None, :] != AND[None, :, :]) * w[None, None, :]).sum(2)
        dist = np.minimum(mu, distAND.min(1))
        sl.add(f"M: Thm 1.4(b) m={m}", np.minimum(mu[pos], 12 * eps[pos] / mu[pos] ** (m - 1)) - dist[pos])


def part_T(n, p, rho, sl):
    N, pts, bits = cube(n)
    wp, wr = weights(bits, p), weights(bits, rho)
    Php = phi(bits, p, pts)
    Fs = all_functions(N).astype(float)  # used for F, G and H
    AND = and_matrix(pts).astype(float)
    meet = pts[:, None] & pts[None, :]
    W = wp[:, None] * wr[None, :]  # Pr[x, y]
    # M[z, x, y] indicator x&y = z
    Mz = np.zeros((N, N, N))
    for x in range(N):
        for y in range(N):
            Mz[meet[x, y], x, y] = 1.0
    nf = len(Fs)
    muG = Fs @ wp
    muH = Fs @ wr
    Ghat = Fs @ (Php * wp[None, :]).T  # (nf, N)  mu_p coefficients
    # Pr_rho[H=1, y_S != 1]
    notAND = 1 - AND
    hS = Fs @ (notAND * wr[None, :]).T  # (nf, N): [H, S]
    # also for the symmetric statement: Hhat (mu_rho) and Pr_p[G=1, x_S != 1]
    Phr = phi(bits, rho, pts)
    Hhat = Fs @ (Phr * wr[None, :]).T
    gS = Fs @ (notAND * wp[None, :]).T
    K = 5 / np.sqrt((1 - p) * (1 - rho))
    distG = ((Fs[:, None, :] != AND[None, :, :]) * wp[None, None, :]).sum(2)  # (nf, N) Pr_p[G != AND_T]
    distH = ((Fs[:, None, :] != AND[None, :, :]) * wr[None, None, :]).sum(2)
    wpr = weights(bits, p * rho)
    distF = ((Fs[:, None, :] != AND[None, :, :]) * wpr[None, None, :]).sum(2)
    muF = Fs @ wpr
    for g in range(nf):
        for h in range(nf):
            GH = np.outer(Fs[g], Fs[h])  # G(x)H(y)
            w1 = (Mz * (GH * W)[None]).sum((1, 2))  # Pr[x&y=z, GH=1]
            w0 = (Mz * ((1 - GH) * W)[None]).sum((1, 2))
            epsF = np.maximum(Fs @ (w0 - w1) + w1.sum(), 0.0)  # eps for every F (clamp rounding below 0)
            emin = epsF.min()
            lhs = (Ghat[g] ** 2 * hS[h]).sum()
            sl.add(f"T: Lemma 3.1 (p={p},rho={rho})", emin - lhs)
            lhs2 = (Hhat[h] ** 2 * gS[g]).sum()
            sl.add(f"T: Lemma 3.1 swapped (p={p},rho={rho})", emin - lhs2)
            # dichotomy for every F
            mn = min(muG[g], muH[h])
            se = np.sqrt(epsF)
            case1 = mn <= K * se + 1e-15
            ok1 = muF <= epsF + K * se + TOL
            # case (ii): exists T with all three bounds
            bG = 1.2 * np.sqrt((1 - p) / (1 - rho)) * se
            bH = 1.2 * np.sqrt((1 - rho) / (1 - p)) * se
            bF = epsF + 2.4 * se / np.sqrt((1 - p) * (1 - rho))
            goodT = (distG[g][None, :] <= bG[:, None] + TOL) & (distH[h][None, :] <= bH[:, None] + TOL) & \
                    (distF <= bF[:, None] + TOL)
            ok2 = goodT.any(1)
            bad = (case1 & ~ok1) | (~case1 & ~ok2)
            if bad.any():
                raise AssertionError(f"Thm 1.4(c) violated: g={g} h={h} F={np.nonzero(bad)[0][:5]}")
    sl.add(f"T: Thm 1.4(c) dichotomy holds for all (F,G,H) (p={p},rho={rho})", np.array([0.0]))


if __name__ == "__main__":
    which = sys.argv[1] if len(sys.argv) > 1 else "PMT"
    if "P" in which:
        sl = Slack()
        for n in range(1, 5):
            for p in [0.1, 0.25, 0.5, 0.7, 0.9]:
                part_P(n, p, sl)
        sl.report("(P) p-biased one-function checks, all f on n<=4:")
    if "M" in which:
        sl = Slack()
        for n in range(1, 4):
            for p in [0.2, 0.5, 0.8]:
                part_M(n, p, sl)
        part_M(4, 0.5, sl)
        sl.report("(M) 3-ary test checks, all f on n<=3 (p in {.2,.5,.8}) and n=4 (p=1/2):")
    if "T" in which:
        sl = Slack()
        for n in range(1, 4):
            for p, rho in [(0.5, 0.5), (0.3, 0.6), (0.8, 0.2), (0.1, 0.9)]:
                part_T(n, p, rho, sl)
        sl.report("(T) three-function checks, all (F,G,H) on n<=3:")
