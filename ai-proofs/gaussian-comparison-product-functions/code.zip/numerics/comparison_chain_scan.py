"""Floating-point scan (evidence only) for Proposition 1.8 of RESULT_gaussian_comparison_product_functions: the
chain S0 -> C1(b) (grouped reverse Hoelder step, exponent p1(b) = 1/(1 - sqrt(8/5) b), sharp) followed by a
discretised scalar path C1(b) -> S1 (Theorem 4.1, N pieces, bisection on its length T2). Total p = p1(b) e^{T2}."""
import numpy as np
from comparison_path_flow import min_time

S1 = np.full((3, 3), 0.5) + 0.5 * np.eye(3)
for N in (64, 128):
    best = (np.inf, None)
    for b in (0.18, 0.20, 0.21, 0.22, 0.225, 0.23, 0.24, 0.26):
        C1 = np.array([[1, 0.25, b], [0.25, 1, b], [b, b, 1.0]])
        p1 = 1 / (1 - np.sqrt(8 / 5) * b)
        T2 = min_time(C1, S1, N, lo=0.0, hi=1.2, iters=24)
        tot = p1 * np.exp(T2)
        best = min(best, (tot, b))
        print(f"N={N}, b={b}: p1={p1:.5f}, e^T2={np.exp(T2):.5f}, total p={tot:.5f}", flush=True)
    print(f"N={N}: best total {best[0]:.5f} at b={best[1]}", flush=True)
