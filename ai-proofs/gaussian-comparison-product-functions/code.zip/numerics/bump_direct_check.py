"""Independent floating-point check of the bump counterexamples (no Clarkson inequality used).

E|1 - 2h|^q - 1 = I1 - 2q E Re h,   h = T_z b,
where I1 = E[ |1-2h|^q - 1 + 2q Re h ] has a non-negative integrand (convexity), evaluated with a
cancellation-free formula, and E Re h = E b (mean preservation) is also checked numerically at high precision.
"""
import mpmath as mp
from bump_test import closed_forms, Tzb

mp.mp.dps = 160


def F(h, q):
    """|1-2h|^q - 1 + 2q Re h, stable for small |h|."""
    u = -4 * mp.re(h) + 4 * abs(h) ** 2
    if abs(h) < mp.mpf(10) ** (-30):
        # (1+u)^{q/2} - 1 + 2q Re h with u = -4Re h + 4|h|^2: second order part plus third-order bound-level terms
        a = q / 2
        return a * u + a * (a - 1) / 2 * u ** 2 + a * (a - 1) * (a - 2) / 6 * u ** 3 + 2 * q * mp.re(h)
    return mp.expm1((q / 2) * mp.log1p(u)) + 2 * q * mp.re(h)


def check(name, z, q, B, x0):
    t = B * x0
    s = 1 - z * z
    D = 1 + B * s
    bp = -B * z * z / D
    tp = t * z / D
    den = 1 - q * mp.re(bp)
    xs = q * mp.re(tp) / den
    phi = lambda x: mp.exp(-x * x / 2) / mp.sqrt(2 * mp.pi)
    pts = [-mp.inf] + [mp.mpf(k) for k in range(-80, 81, 1)] + [mp.inf]
    pts = sorted(set(pts + [xs - 3, xs, xs + 3]), key=lambda v: float(v) if v not in (mp.inf, -mp.inf) else (1e300 if v == mp.inf else -1e300))
    I1 = mp.quad(lambda x: F(Tzb(z, B, t, x), q) * phi(x), pts)
    ERe = mp.quad(lambda x: mp.re(Tzb(z, B, t, x)) * phi(x), pts)
    logETbq, logEb = closed_forms(z, q, B, t)
    Eb = mp.exp(logEb)
    ETbq = mp.exp(logETbq)
    print(name, "q=%d B=%s x0=%s" % (q, mp.nstr(B, 6), mp.nstr(x0, 6)))
    print("   E b (closed form)            =", mp.nstr(Eb, 15))
    print("   E Re T_z b (quadrature)      =", mp.nstr(ERe, 15), "  rel. diff", mp.nstr(abs(ERe / Eb - 1), 3))
    print("   I1 (quadrature, integrand>=0)=", mp.nstr(I1, 15), "   2 E|T_z b|^q (closed form) =", mp.nstr(2 * ETbq, 15))
    print("   excess E|T_z(1-2b)|^q - 1 = I1 - 2q E b =", mp.nstr(I1 - 2 * q * Eb, 15),
          "  (Clarkson bound", mp.nstr(2 * ETbq - 2 * q * Eb, 6), ")")


if __name__ == "__main__":
    check("(6,3) certified instance (I1)", mp.mpf("0.825") * mp.exp(mp.mpf("0.6") * 1j), 3, mp.mpf(3000), mp.mpf(22))
    check("(inf,3) certified instance (I2)", mp.mpf("0.81") * mp.exp(mp.mpf("0.7") * 1j), 3, mp.mpf(10) ** 4, mp.mpf("12.5"))
    check("q=4 certified instance (I3)", mp.mpf("0.72") * mp.exp(mp.mpf("0.7") * 1j), 4, mp.mpf(10) ** 4, mp.mpf("8.5"))
    check("(8,4) explicit example point", mp.mpf("0.705") * mp.exp(mp.mpf("0.7") * 1j), 4, mp.mpf(10) ** mp.mpf("3.5"), mp.mpf("13.5"))
