"""Remark 4.2(d) of RESULT_gaussian_comparison_product_functions (floating point; evidence only).

Along the segment C(h) = (1-h) Sigma_0 + h Sigma_1, condition (12) of Theorem 4.1 reads sigma(h) D(h) >= Sigma_0 - Sigma_1
for some diagonal D(h) with 0 <= D(h) <= C(h), and the exponent reached is p = exp(int_0^1 sigma(h) dh). For each h the
smallest admissible sigma is 1/tau(h), where tau(h) is the value of the semidefinite programme
    maximise tau  subject to  D - tau (Sigma_0 - Sigma_1) >= 0,  C(h) - D >= 0,  D >= 0 diagonal.
Example of Proposition 1.6: Sigma_1 equicorrelated with correlation 1/2, x = (1, 1/2, 0). The fixed-D segment of
Theorem 1.1 needs p >= 3.
"""
import numpy as np
import cvxpy as cp

S1 = np.array([[1, .5, .5], [.5, 1, .5], [.5, .5, 1]])
S0 = np.array([[1, .25, 0], [.25, 1, 0], [0, 0, 1]])
Dl = S0 - S1


def sigma(h):
    C = (1 - h) * S0 + h * S1
    d = cp.Variable(3)
    tau = cp.Variable()
    cons = [cp.diag(d) - tau * Dl >> 0, C - cp.diag(d) >> 0, d >= 0]
    cp.Problem(cp.Maximize(tau), cons).solve(solver=cp.CLARABEL)
    return 1.0 / tau.value


for n in (200, 400, 800):
    hs = np.linspace(0, 1, n + 1)
    sg = np.array([sigma(h) for h in hs])
    integral = np.sum((sg[1:] + sg[:-1]) / 2) * (hs[1] - hs[0])
    print(f"grid {n:4d}: int sigma = {integral:.6f}, p = exp(int) = {np.exp(integral):.5f}  "
          f"(sigma(0) = {sg[0]:.4f}, sigma(1) = {sg[-1]:.4f}, max sigma = {sg.max():.4f})")
