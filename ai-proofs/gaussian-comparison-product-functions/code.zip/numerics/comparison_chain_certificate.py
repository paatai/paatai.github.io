"""Exact certificate for Proposition 1.8 of RESULT_gaussian_comparison_product_functions: in the example of
Proposition 1.6 (S0 = [[1,1/4,0],[1/4,1,0],[0,0,1]], S1 = equicorrelated(1/2)) the comparison inequality holds for
every p >= 877/400.

Two steps, chained (apply the second inequality to f_j^{p1}; the exponents multiply):
(1) S0 -> C1 = [[1,1/4,b],[1/4,1,b],[b,b,1]] with exponent p1. S0 and C1 agree on the groups {1,2} and {3}, and S0
    vanishes between them, so by the grouped form of Corollary 1.4(a) with t = 0 (Remark 1.2(d)) the inequality holds
    iff S0 <= p1 C1. Checked exactly.
(2) C1 -> S1 along a piecewise-linear path with N scalar pieces of length h = T2/N (Theorem 4.1): rational C_k with
    unit diagonal, rational diagonal D_k, and exactly: C_k > 0, D_k >= 0, C_k - D_k >= 0, C_{k+1} - D_k >= 0,
    (C_{k+1} - C_k) + h D_k >= 0 (3x3 PSD by all principal minors). This gives exponent e^{T2}.
Finally p1 e^{T2} < P is checked in Arb ball arithmetic.
Modes:
  python3 comparison_chain_certificate.py build b N T2 p1 P out.json   (SDP proposes data, rounded, verified, saved)
  python3 comparison_chain_certificate.py check out.json                (solver-free exact re-verification)
Default certificate: build 9/40 256 4501/10000 139783/100000 877/400 comparison_chain_certificate.json
"""
import sys
import json
from fractions import Fraction as F
from itertools import combinations
import flint

S1q = [[F(1), F(1, 2), F(1, 2)], [F(1, 2), F(1), F(1, 2)], [F(1, 2), F(1, 2), F(1)]]
S0q = [[F(1), F(1, 4), F(0)], [F(1, 4), F(1), F(0)], [F(0), F(0), F(1)]]


def det(M, idx):
    if len(idx) == 1:
        return M[idx[0]][idx[0]]
    if len(idx) == 2:
        i, j = idx
        return M[i][i] * M[j][j] - M[i][j] * M[j][i]
    i, j, k = idx
    return (M[i][i] * (M[j][j] * M[k][k] - M[j][k] * M[k][j]) - M[i][j] * (M[j][i] * M[k][k] - M[j][k] * M[k][i])
            + M[i][k] * (M[j][i] * M[k][j] - M[j][j] * M[k][i]))


def psd(M):
    return all(det(M, list(c)) >= 0 for r in (1, 2, 3) for c in combinations(range(3), r))


def pd(M):
    return all(det(M, list(range(r))) > 0 for r in (1, 2, 3))


def comb(a, A, b, B):
    return [[a * A[i][j] + b * B[i][j] for j in range(3)] for i in range(3)]


def C1_of(b):
    return [[F(1), F(1, 4), b], [F(1, 4), F(1), b], [b, b, F(1)]]


def verify(b, N, T2, p1, P, Cq, Dq):
    h = T2 / N
    C1 = C1_of(b)
    ok1 = pd(C1) and psd(comb(p1, C1, -1, S0q))
    ok2 = Cq[0] == C1 and Cq[N] == S1q and len(Cq) == N + 1 and len(Dq) == N
    for k in range(N + 1):
        ok2 &= pd(Cq[k]) and all(Cq[k][i][i] == 1 for i in range(3)) and all(
            Cq[k][i][j] == Cq[k][j][i] for i in range(3) for j in range(3))
    for k in range(N):
        Dk = [[Dq[k][i] if i == j else F(0) for j in range(3)] for i in range(3)]
        ok2 &= all(d >= 0 for d in Dq[k])
        ok2 &= psd(comb(1, Cq[k], -1, Dk)) and psd(comb(1, Cq[k + 1], -1, Dk))
        ok2 &= psd(comb(1, comb(1, Cq[k + 1], -1, Cq[k]), h, Dk))
    bound = flint.arb(p1.numerator) / p1.denominator * (flint.arb(T2.numerator) / T2.denominator).exp()
    ok3 = bool(bound < flint.arb(P.numerator) / P.denominator)
    print(f"(1) C1 > 0 and p1 C1 - S0 >= 0 (b = {b}, p1 = {p1}): {ok1}")
    print(f"(2) path C1 -> S1, {N} scalar pieces, h = {h}: all {5 * N + 1} conditions: {ok2}")
    print(f"(3) p1 e^(T2) = {bound.str(12)} < {P} (Arb): {ok3}")
    ok = ok1 and ok2 and ok3
    print(f"CERTIFIED: the comparison inequality holds in the example for every p >= {P}" if ok else "NOT CERTIFIED")
    return ok


def s(x):
    return f"{x.numerator}/{x.denominator}"


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else "check"
    if mode == "build":
        import numpy as np
        import cvxpy as cp
        b, N, T2, p1, P, out = F(sys.argv[2]), int(sys.argv[3]), F(sys.argv[4]), F(sys.argv[5]), F(sys.argv[6]), sys.argv[7]
        tof = lambda M: np.array([[float(x) for x in r] for r in M])
        I = np.eye(3)
        t = cp.Variable()
        Ks = [cp.Constant(tof(C1_of(b)))] + [cp.Variable((3, 3), symmetric=True) for _ in range(N - 1)] + [
            cp.Constant(tof(S1q))]
        Ds = [cp.Variable(3) for _ in range(N)]
        cons = [t <= 0.05]
        for k in range(1, N):
            cons += [cp.diag(Ks[k]) == 1, Ks[k] >> t * I]
        hf = float(T2 / N)
        for k in range(N):
            Dk = cp.diag(Ds[k])
            cons += [Ds[k] >= t, Ks[k] - Dk >> t * I, Ks[k + 1] - Dk >> t * I, (Ks[k + 1] - Ks[k]) + hf * Dk >> t * hf * I]
        prob = cp.Problem(cp.Maximize(t), cons)
        prob.solve(solver="CLARABEL")
        print(f"SDP status {prob.status}, common slack {t.value:.3e}")
        rat = lambda x: F(float(x)).limit_denominator(10 ** 9)
        Cq = [C1_of(b)] + [[[F(1) if i == j else rat(0.5 * (Ks[k].value[i][j] + Ks[k].value[j][i])) for j in range(3)]
                            for i in range(3)] for k in range(1, N)] + [S1q]
        Dq = [[max(F(0), rat(x)) for x in Ds[k].value] for k in range(N)]
        data = {"b": s(b), "N": N, "T2": s(T2), "p1": s(p1), "P": s(P),
                "C": [[[s(x) for x in r] for r in M] for M in Cq], "D": [[s(x) for x in d] for d in Dq]}
        json.dump(data, open(out, "w"))
        print(f"rational data written to {out}")
        verify(b, N, T2, p1, P, Cq, Dq)
    else:
        path = sys.argv[2] if len(sys.argv) > 2 else "comparison_chain_certificate.json"
        d = json.load(open(path))
        Cq = [[[F(x) for x in r] for r in M] for M in d["C"]]
        Dq = [[F(x) for x in v] for v in d["D"]]
        print(f"solver-free check of {path}")
        verify(F(d["b"]), d["N"], F(d["T2"]), F(d["p1"]), F(d["P"]), Cq, Dq)
