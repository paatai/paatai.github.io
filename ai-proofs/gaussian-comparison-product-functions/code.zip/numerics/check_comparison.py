"""Checks for the comparison theorem for product functions (RESULT_gaussian_comparison_product_functions):

    E_{S0}[prod_j f_j(xi_j)] <= (E_{S1}[prod_j f_j(xi_j)^p])^{1/p}   whenever   p/(p-1) (S0 - S1) <= D <= S0
    for some diagonal D (here k_j = 1).

Floating point (evidence for the algebra, not part of the proof); n = 3, tensor Gauss-Hermite quadrature.
(A) weighted reverse LSI: Ent(prod Psi_j) >= -sum_{i<j} E[Psi_i' B_ij Psi_j' prod_{l != i,j} Psi_l] whenever
    S >= D (diagonal) and D + B >= 0 (B zero diagonal), random positive functions;
(B) monotonicity of h -> Phi(1/m(h), (1-h) S0 + h S1), m(h) = 1 - h(1-1/p), along the segment;
(C) the inequality at p = p* (threshold) for random and optimised test functions, at random pairs (S0, S1) of the
    source's form S0 = X S1 X + I - X^2 for which the condition holds.
"""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.optimize import minimize

rng = np.random.default_rng(7)
ND, WT = hermegauss(28)
WT = WT / WT.sum()
Z = np.array(np.meshgrid(ND, ND, ND, indexing="ij")).reshape(3, -1)
W3 = np.einsum("i,j,k->ijk", WT, WT, WT).reshape(-1)


def nodes(S):
    return np.linalg.cholesky(S) @ Z


def rand_corr(n):
    A = rng.normal(size=(n, n + 2))
    S = A @ A.T
    d = np.sqrt(np.diag(S))
    return S / np.outer(d, d)


def rand_fun():
    a, c, d, w = rng.normal(0, 0.5), rng.normal(0, 0.6), rng.normal(0, 1), rng.uniform(0.3, 1.5)
    f = lambda t: np.exp(a * t + c * np.tanh(w * (t - d)))
    df = lambda t: f(t) * (a + c * w / np.cosh(w * (t - d)) ** 2)
    return f, df


def gen_eig(S0, S1):
    L = np.linalg.cholesky(S1)
    Li = np.linalg.inv(L)
    ev, U = np.linalg.eigh(Li @ S0 @ Li.T)
    return ev[-1], Li.T @ U[:, -1]


def condition_D(S0, S1, p):
    """Diagonal D with p/(p-1)(S0-S1) <= D <= S0, if the forced choice D = diag(S0 v / v) at p = p* works."""
    ps, v = gen_eig(S0, S1)
    D = np.diag((S0 @ v) / v)
    lo = np.linalg.eigvalsh(D - p / (p - 1) * (S0 - S1))[0]
    hi = np.linalg.eigvalsh(S0 - D)[0]
    return D, min(lo, hi)


if __name__ == "__main__":
    print("(A) weighted reverse LSI, n = 3:")
    worst = np.inf
    for trial in range(300):
        S = rand_corr(3)
        d = rng.uniform(0.05, 1.0, 3)
        Dh = np.diag(1 / np.sqrt(d))
        tmax = np.linalg.eigvalsh(Dh @ S @ Dh)[0]          # largest t with S - t diag(d) >= 0
        d = d * tmax * rng.uniform(0.5, 1.0)
        D = np.diag(d)
        if np.linalg.eigvalsh(S - D)[0] < 0:
            continue
        Bdir = rng.normal(size=(3, 3)); Bdir = Bdir + Bdir.T; np.fill_diagonal(Bdir, 0)
        # largest kappa with D + kappa Bdir >= 0
        Dh = np.diag(1 / np.sqrt(d))
        kap = 1 / max(-np.linalg.eigvalsh(Dh @ Bdir @ Dh)[0], 1e-12)
        B = kap * Bdir * rng.uniform(0.5, 1.0)
        X = nodes(S)
        fs = [rand_fun() for _ in range(3)]
        Ps = [f(X[j]) for j, (f, df) in enumerate(fs)]
        dPs = [df(X[j]) for j, (f, df) in enumerate(fs)]
        Wv = Ps[0] * Ps[1] * Ps[2]
        EW = (W3 * Wv).sum()
        ent = (W3 * Wv * np.log(Wv)).sum() - EW * np.log(EW)
        cross = 0.0
        for i in range(3):
            for j in range(i + 1, 3):
                l = 3 - i - j
                cross += B[i, j] * (W3 * dPs[i] * dPs[j] * Ps[l]).sum()
        lhs, rhs = ent, -cross
        if rhs > 1e-12:
            worst = min(worst, lhs / rhs)
    print(f"  min of Ent / (-cross term) over cases with positive right side: {worst:.4f} (must be >= 1)")

    print("(B) monotonicity along the segment:")
    viol = 0; tot = 0; maxdrop = 0.0
    for trial in range(400):
        S1 = rand_corr(3); x = rng.uniform(0, 1, 3); X = np.diag(x)
        S0 = X @ S1 @ X + np.eye(3) - X @ X
        ps, v = gen_eig(S0, S1)
        if ps <= 1.02:
            continue
        D, marg = condition_D(S0, S1, ps)
        if marg < -1e-10:
            continue
        tot += 1
        fs = [rand_fun()[0] for _ in range(3)]
        hs = np.linspace(0, 1, 41)
        vals = []
        for h in hs:
            m = 1 - h * (1 - 1 / ps); q = 1 / m
            Xn = nodes((1 - h) * S0 + h * S1)
            Wv = np.prod([fs[j](Xn[j]) ** q for j in range(3)], axis=0)
            vals.append(np.log((W3 * Wv).sum()) / q)
        drops = np.diff(vals)
        maxdrop = max(maxdrop, -drops.min())
        if drops.min() < -1e-9:
            viol += 1
        if tot >= 60:
            break
    print(f"  {tot} admissible random cases; paths with a decrease > 1e-9: {viol}; largest decrease {maxdrop:.2e}")

    print("(C) the inequality at p = p*:")
    ND60, WT60 = hermegauss(60); WT60 = WT60 / WT60.sum()
    Z60 = np.array(np.meshgrid(ND60, ND60, ND60, indexing="ij")).reshape(3, -1)
    W60 = np.einsum("i,j,k->ijk", WT60, WT60, WT60).reshape(-1)
    worst = -np.inf; worst60 = -np.inf; tot = 0
    for trial in range(400):
        S1 = rand_corr(3); x = rng.uniform(0, 1, 3); X = np.diag(x)
        S0 = X @ S1 @ X + np.eye(3) - X @ X
        ps, v = gen_eig(S0, S1)
        if ps <= 1.02:
            continue
        D, marg = condition_D(S0, S1, ps)
        if marg < -1e-10:
            continue
        tot += 1
        X0, X1 = nodes(S0), nodes(S1)

        def lr(th, Zg=Z, Wg=W3):
            th = np.clip(th, -1.5, 1.5)           # bounded family: quadrature stays accurate
            A0, A1 = np.linalg.cholesky(S0) @ Zg, np.linalg.cholesky(S1) @ Zg
            fs = [lambda t, a=th[4 * j], c=th[4 * j + 1], d=th[4 * j + 2], w=0.2 + abs(th[4 * j + 3]):
                  np.exp(a * t + c * np.tanh(w * (t - d))) for j in range(3)]
            lhs = np.log((Wg * np.prod([fs[j](A0[j]) for j in range(3)], axis=0)).sum())
            rhs = np.log((Wg * np.prod([fs[j](A1[j]) ** ps for j in range(3)], axis=0)).sum()) / ps
            return lhs - rhs if np.isfinite(lhs - rhs) else -1e3
        best, bx = -np.inf, None
        for k in range(6):
            th0 = rng.normal(0, 0.7, 12)
            res = minimize(lambda t: -lr(t), th0, method="Nelder-Mead", options={"maxiter": 3000})
            if -res.fun > best:
                best, bx = -res.fun, res.x
        worst = max(worst, best)
        worst60 = max(worst60, lr(bx, Z60, W60))
        if tot >= 25:
            break
    print(f"  {tot} admissible cases at p = p*: largest optimised log-ratio {worst:+.3e} with 28 nodes per axis;")
    print(f"  the optimisers recomputed with 60 nodes per axis give at most {worst60:+.3e} (exponentials give 0)")
