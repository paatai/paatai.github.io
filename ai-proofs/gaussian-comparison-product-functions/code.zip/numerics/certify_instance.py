"""Rigorous ball-arithmetic certificate (python-flint / Arb) about the instance (I1) of the main paper
(RESULT_downward_complex_hypercontractivity, Corollary 1.5): p = 6, q = 3, z = 0.825 e^{0.6 i}.

Certified claims:
 (C1) z is NOT in Omega_{3,3}:  (q-2)|1-z^2| > q(1-|z|^2).
 (C2) z IS in Omega_{6,3} and |z|^4 < 1/(q-1) = 1/2, hence z^n in Omega_{6,3} for all n >= 1, i.e. z
      satisfies every second-order (all-chaos) local condition N_{6,3}.  [Disc of radius (q-1)^{-1/2} lies in
      Omega_{p,q} for 2 <= q <= p.]  Omega_{6,3} membership is checked via the exact criterion
      |p-2-z^2(q-2)| <= p - q|z|^2.
 (C3) For B = 10^4, the narrow Gaussian g_t(x) = exp(-B x^2/2 + t x) violates the MIXED inequality
      ||T_z g||_q <= ||g||_2^{1-theta} ||g||_p^theta (theta = 1/2) for t large: its log-ratio is c(B) + t^2 Q(B)
      with Q(B) > 0 (certified) and 1 - q Re beta' > 0.
 (C4) For the same B, the plain coefficient Q_{p,q}(B) (input ||g||_p alone) is negative: pure narrow Gaussians do
      not violate ||T_z g||_q <= ||g||_p in dimension one.  (They are not the right test functions there: the
      perturbations 1 - 2b of the constant function by such bumps DO violate it in dimension one, see
      certify_bump.py; by Theorem 1.1 of the main paper the contraction region is Omega_{3,3} in every dimension.)
 (C5) the Schur-Hoelder hypothesis of Lemma 2.3 at sigma = 6/5 (sigma' = 6 = p), delta > 0 and kappa > 0.
(C3) is the mechanism of the spike step (Lemma A.2 of the main paper) in high dimension; it is no longer needed for
Theorem 1.1.
"""
from flint import arb, acb, ctx

ctx.prec = 200

p, q = arb(6), arb(3)
theta = (arb(1) / 2 - 1 / q) / (arb(1) / 2 - 1 / p)
r, ang = arb("0.825"), arb("0.6")
z = acb(r * ang.cos(), r * ang.sin())
one = acb(1)


def absq(w):
    return w.real ** 2 + w.imag ** 2


# (C1)
lhs = (q - 2) * absq(one - z * z).sqrt()
rhs = q * (1 - absq(z))
print("(C1) (q-2)|1-z^2| - q(1-|z|^2) =", lhs - rhs, " > 0:", (lhs - rhs) > 0)

# (C2)
pp = acb(p)
lhs2 = absq(pp - 2 - z * z * (q - 2)).sqrt()
rhs2 = p - q * absq(z)
print("(C2) p-q|z|^2 - |p-2-z^2(q-2)| =", rhs2 - lhs2, " >= 0:", (rhs2 - lhs2) >= 0)
print("     |z^2|^2 - 1/(q-1) =", absq(z) ** 2 - 1 / (q - 1), " < 0:", (absq(z) ** 2 - 1 / (q - 1)) < 0,
      " (so z^n lies in the disc of radius (q-1)^(-1/2), contained in Omega_{p,q}, for all n >= 2)")

# (C3)
B = arb(10) ** 4
s = one - z * z
D = one + B * s
betap = -B * z * z / D
den_q = 1 - q * betap.real
print("(C3) 1 - q Re beta' =", den_q, " > 0:", den_q > 0)
Q_out = (s / D).real / 2 + q * ((z / D).real) ** 2 / (2 * den_q)
Q_in2 = arb(2) / (2 * (1 + 2 * B))
Q_inp = p / (2 * (1 + p * B))
Q_mix = Q_out - (1 - theta) * Q_in2 - theta * Q_inp
Q_pq = Q_out - Q_inp
c_out = -absq(D).sqrt().log() / 2 - den_q.log() / (2 * q)
c_in2 = -(1 + 2 * B).log() / 4
c_inp = -(1 + p * B).log() / (2 * p)
c_mix = c_out - (1 - theta) * c_in2 - theta * c_inp
print("     Q_mix(B) =", Q_mix, " > 0:", Q_mix > 0)
print("     B^2 Q_mix(B) =", B * B * Q_mix)
print("     c_mix(B) =", c_mix)
t0 = ((-c_mix) / Q_mix).sqrt() if c_mix < 0 else arb(0)
print("     mixed inequality violated for all t > t0, t0 <=", t0.upper())
# kappa(z) (the B -> infinity limit of B^2 Q_mix) for comparison
A = (one / s).real
C = (z / s).real
kappa = -A / 2 + 1 / (2 * q) + q * C * C / (2 * (1 - q + q * A))
print("     kappa(z) =", kappa, " (limit of B^2 Q_mix)")

# (C4)
print("(C4) Q_{p,q}(B) =", Q_pq, " < 0:", Q_pq < 0, "   B^2 Q_{p,q}(B) =", B * B * Q_pq)

# (C5) Schur-Hoelder hypothesis (Lemma 2.3) at sigma = 6/5, i.e. sigma' = 6 = p, and delta > 0, kappa > 0.
#      This lets polynomial approximations in L^6 transfer violations from bounded test functions to polynomials:
#      P_n -> g in L^6 gives ||T_z P_n||_3 -> ||T_z g||_3 and ||P_n||_r -> ||g||_r (r <= 6).
sig = arb(6) / 5
a_ = A - 1
b_ = C
cond1 = sig * a_ + 1
cond2 = q * (sig * b_ * b_ / (sig * a_ + 1) - a_)
delta = 1 - q + q * A
print("(C5) sigma=6/5: sigma*a+1 =", cond1, ">0:", cond1 > 0, ";  q(sigma b^2/(sigma a+1) - a) =", cond2, "<1:", cond2 < 1)
print("     delta = 1-q+qA =", delta, ">0:", delta > 0, ";  kappa =", kappa, ">0:", kappa > 0)
print("CONCLUSION: (C1),(C2): z in N_{6,3} but not in Omega_{3,3}; with (C5) and certify_bump.py (Theorem 1.1 of the "
      "main paper), T_z is not an L^6 -> L^3 contraction, already in dimension one, and sup_d N_d(6,3;z) = infinity.")
