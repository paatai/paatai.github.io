"""Two-stage path flow (floating point search) for the example of Proposition 1.6 of
RESULT_gaussian_comparison_product_functions: S0 = [[1,1/4,0],[1/4,1,0],[0,0,1]], S1 = equicorrelated(1/2).

Stage 1 (blocks {1,2} and {3}): c12 = 1/4 is kept fixed, c13 and c23 move; the conditioning matrix Dt may have a full
2x2 block on {1,2} (Theorem 4.1 applied to the grouped blocks, Remark 1.2(d)). Stage 2 (scalar blocks): all three
correlations move to 1/2, Dt diagonal. Chaining the two comparison inequalities multiplies the exponents, so the
total exponent is e^{T1 + T2}. Discretisation: piecewise-linear paths, one Dt per piece; for fixed (T1, T2) this is a
single semidefinite feasibility problem in all path matrices and all Dt's.
"""
import sys
import numpy as np
import cvxpy as cp

S1 = np.full((3, 3), 0.5) + 0.5 * np.eye(3)
S0 = np.array([[1, 0.25, 0], [0.25, 1, 0], [0, 0, 1.0]])
ps = (11 + np.sqrt(41)) / 8


def feasible(T1, T2, N1, N2, ret=False):
    h1, h2 = T1 / N1, T2 / N2
    Cs = [cp.Constant(S0)] + [cp.Variable((3, 3), symmetric=True) for _ in range(N1 + N2 - 1)] + [cp.Constant(S1)]
    cons = []
    for k in range(1, N1 + N2):
        cons += [cp.diag(Cs[k]) == 1, Cs[k] >> 0]
    for k in range(1, N1 + 1):
        cons += [Cs[k][0, 1] == 0.25]
    Ds = []
    for k in range(N1):
        A = cp.Variable((2, 2), symmetric=True)
        d3 = cp.Variable(nonneg=True)
        Dk = cp.bmat([[A, np.zeros((2, 1))], [np.zeros((1, 2)), cp.reshape(d3, (1, 1))]])
        cons += [A >> 0, Cs[k] - Dk >> 0, Cs[k + 1] - Dk >> 0, (Cs[k + 1] - Cs[k]) + h1 * Dk >> 0]
        Ds.append(Dk)
    for k in range(N1, N1 + N2):
        dk = cp.Variable(3, nonneg=True)
        Dk = cp.diag(dk)
        cons += [Cs[k] - Dk >> 0, Cs[k + 1] - Dk >> 0, (Cs[k + 1] - Cs[k]) + h2 * Dk >> 0]
        Ds.append(Dk)
    prob = cp.Problem(cp.Minimize(0), cons)
    try:
        prob.solve(solver="CLARABEL")
    except cp.error.SolverError:
        return (False, None) if ret else False
    ok = prob.status == "optimal"
    if ret:
        return ok, ([S0] + [Cs[k].value for k in range(1, N1 + N2)] + [S1])
    return ok


def best_total(frac, N1, N2, lo, hi, iters=24):
    f = lambda T: feasible(frac * T, (1 - frac) * T, N1, N2)
    if not f(hi):
        return np.inf
    for _ in range(iters):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if f(mid) else (mid, hi)
    return hi


if __name__ == "__main__":
    N1 = int(sys.argv[1]) if len(sys.argv) > 1 else 8
    N2 = int(sys.argv[2]) if len(sys.argv) > 2 else 24
    print(f"p* = {ps:.5f}; single-stage path (N = 32) gave 2.3045")
    for frac in (0.05, 0.1, 0.2, 0.3, 0.4, 0.5):
        T = best_total(frac, N1, N2, np.log(ps) - 1e-9, np.log(2.5))
        print(f"  stage-1 fraction {frac:.2f}: smallest total p = e^(T1+T2) = {np.exp(T):.5f}", flush=True)
