"""Complements to RESULT_gaussian_comparison_product_functions (floating point, evidence only).

Setting: k_j = 1, S1 a correlation matrix, x in [0,1]^n, S0 = X S1 X + I - X^2, p* the top generalised eigenvalue
of (S0, S1) with eigenvector v. At p = p* the only diagonal candidate in the condition
    p/(p-1)(S0 - S1) <= D <= S0
is D = diag(S0 v / v) (Lemma 5.1 of the note).
(1) Sign-balanced S1 (all off-diagonal entries <= 0 after sign changes): the candidate always works.
(2) Equicorrelated S1 with rho > 0 or rho < 0, unequal x: how often the candidate works.
(3) Random S1 (n = 3, 4), cases where the candidate fails: Gaussian test functions exp(a.t - t.B t/2), B diagonal,
    at p = p* (closed forms) - a positive score would be a violation of the comparison inequality.
"""
import numpy as np
from scipy.optimize import minimize

rng = np.random.default_rng(5)


def gen_eig(S0, S1):
    L = np.linalg.cholesky(S1)
    Li = np.linalg.inv(L)
    ev, U = np.linalg.eigh(Li @ S0 @ Li.T)
    return ev[-1], Li.T @ U[:, -1]


def candidate_margin(S0, S1):
    ps, v = gen_eig(S0, S1)
    if np.min(np.abs(v)) < 1e-12:
        return ps, None
    D = np.diag((S0 @ v) / v)
    return ps, min(np.linalg.eigvalsh(S0 - D)[0], np.linalg.eigvalsh(S1 - S0 + (1 - 1 / ps) * D)[0])


def rand_corr(n):
    A = rng.normal(size=(n, n + 1))
    S = A @ A.T
    d = np.sqrt(np.diag(S))
    return S / np.outer(d, d)


def balanced_corr(n):
    while True:
        off = rand_corr(n) - np.eye(n)
        eps = rng.choice([-1, 1], n)
        S = np.eye(n) - np.abs(off) * np.outer(eps, eps) * rng.uniform(0.2, 1.0)
        if np.linalg.eigvalsh(S)[0] > 1e-3:
            return S


def score(beta, S0, S1, p):
    n = len(beta); B = np.diag(beta); I = np.eye(n)
    K1 = np.linalg.inv(S1) + p * B
    if np.linalg.eigvalsh(K1)[0] <= 0:
        return -np.inf
    K0 = np.linalg.inv(S0) + B
    if np.linalg.eigvalsh(K0)[0] <= 0:
        return np.inf
    C = -0.5 * np.log(np.linalg.det(I + S0 @ B)) + np.log(np.linalg.det(I + p * S1 @ B)) / (2 * p)
    Q = 0.5 * (np.linalg.inv(K0) - p * np.linalg.inv(K1))
    return max(C, np.linalg.eigvalsh(0.5 * (Q + Q.T))[-1])


def best_gauss(S0, S1, p, nstart=40):
    n = S0.shape[0]; bv = -np.inf
    for _ in range(nstart):
        v0 = rng.normal(0, 2, n)
        f = lambda w: score(np.sinh(w), S0, S1, p)
        s0 = f(v0)
        if s0 == np.inf:
            return np.inf
        if not np.isfinite(s0):
            continue
        r = minimize(lambda w: -f(w) if np.isfinite(f(w)) else 1e6, v0, method="Nelder-Mead",
                     options={"maxiter": 6000, "xatol": 1e-12, "fatol": 1e-15})
        bv = max(bv, -r.fun)
    return bv


if __name__ == "__main__":
    print("(1) sign-balanced S1:")
    for n in (3, 4, 6):
        ok = tot = 0
        for _ in range(2000):
            S1 = balanced_corr(n); x = rng.uniform(0, 1, n); X = np.diag(x)
            S0 = X @ S1 @ X + np.eye(n) - X @ X
            ps, m = candidate_margin(S0, S1)
            if m is None or ps <= 1 + 1e-9:
                continue
            tot += 1; ok += m >= -1e-10
        print(f"  n={n}: candidate D works in {ok}/{tot} cases")
    print("(2) equicorrelated S1, unequal x:")
    for n in (3, 4, 6):
        for sgn in (1, -1):
            ok = tot = 0
            for _ in range(2000):
                rho = rng.uniform(0, 0.95) if sgn > 0 else -rng.uniform(0, 0.99 / (n - 1))
                S1 = (1 - rho) * np.eye(n) + rho * np.ones((n, n))
                x = rng.uniform(0, 1, n); X = np.diag(x)
                S0 = X @ S1 @ X + np.eye(n) - X @ X
                ps, m = candidate_margin(S0, S1)
                if m is None or ps <= 1 + 1e-9:
                    continue
                tot += 1; ok += m >= -1e-10
            print(f"  n={n}, rho {'> 0' if sgn > 0 else '< 0'}: candidate D works in {ok}/{tot} cases")
    print("(3) random S1, candidate fails, Gaussian test functions at p = p*:")
    for n in (3, 4):
        tested = viol = 0; worst = -np.inf
        for _ in range(400):
            S1 = rand_corr(n); x = rng.uniform(0, 1, n); X = np.diag(x)
            S0 = X @ S1 @ X + np.eye(n) - X @ X
            ps, m = candidate_margin(S0, S1)
            if m is None or ps <= 1 + 1e-6 or m >= -1e-10:
                continue
            tested += 1
            val = best_gauss(S0, S1, ps)
            worst = max(worst, val); viol += val > 1e-9
            if tested >= 60:
                break
        print(f"  n={n}: {tested} cases, violations {viol}, max score {worst:+.3e}")
