"""Targeted minimisation (floating point, evidence only) for RESULT_gaussian_comparison_product_functions, after
Proposition 1.10: in the forward-inequality structure S0 = X S1 X + I - X^2 (S1 a correlation matrix with
lambda_min >= 0.05, x in (-1,1)^n), minimise min_{2<=d<=8} lambda_min(p* S1^(d) - S0^(d)) / (p* - 1) at the threshold p*.
A negative value would be a second-order counterexample to the sufficiency of (2.17) at alpha = 1/p."""
import numpy as np
from scipy.optimize import minimize
rng=np.random.default_rng(5)
def corr_from(params,n):
    # params -> lower-triangular L with unit-norm rows -> correlation matrix
    L=np.zeros((n,n)); k=0
    for i in range(n):
        for j in range(i+1):
            L[i,j]=params[k]; k+=1
    L=L/np.linalg.norm(L,axis=1,keepdims=True)
    return L@L.T
def margin(v,n,lmin=0.05,dmax=8):
    m=n*(n+1)//2
    S1=corr_from(v[:m],n)
    if np.linalg.eigvalsh(S1)[0]<lmin: return 10.0+ (lmin-np.linalg.eigvalsh(S1)[0])
    x=np.tanh(v[m:m+n])
    X=np.diag(x); S0=X@S1@X+np.eye(n)-X@X
    L=np.linalg.cholesky(S1); Li=np.linalg.inv(L)
    ps=np.linalg.eigvalsh(Li@S0@Li.T)[-1]
    if ps<1+1e-4: return 10.0
    return min(np.linalg.eigvalsh(ps*S1**d-S0**d)[0]/(ps-1) for d in range(2,dmax+1))
for n in (3,4,5):
    m=n*(n+1)//2; best=(np.inf,None)
    for it in range(150):
        v0=np.concatenate([rng.normal(size=m),rng.normal(0,1.5,n)])
        r=minimize(lambda v: margin(v,n),v0,method="Nelder-Mead",options={"maxiter":4000,"xatol":1e-9,"fatol":1e-12})
        if r.fun<best[0]: best=(r.fun,r.x)
    v=best[1]; S1=corr_from(v[:m],n); x=np.tanh(v[m:m+n])
    print(f"n={n}: min over targeted search of min_d lambda_min(M_d)/(p*-1) = {best[0]:+.4e}; lambda_min(S1)={np.linalg.eigvalsh(S1)[0]:.3f}; x={np.round(x,3)}")
    print("   S1 offdiag:",np.round(S1[np.triu_indices(n,1)],3))
