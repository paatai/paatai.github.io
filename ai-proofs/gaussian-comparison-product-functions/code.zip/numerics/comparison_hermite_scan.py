"""Floating-point scan (evidence only) for RESULT_gaussian_comparison_product_functions, Remark 1.7 and
Proposition 1.9: the second-variation (Hermite-level) conditions p* S1^(d) >= S0^(d), d = 2..8, at the threshold p*.
(1) Forward-inequality structure S0 = X S1 X + I - X^2 (n = 3, 4; equicorrelated or random correlation matrices S1;
    x in [0,1]^n or [-1,1]^n, sometimes one x_j = 1): count instances where some level d in 2..8 fails.
(2) Two scalar functions with correlation theta under S0 and rho < theta under S1: level 2 fails at p* exactly when
    (1 + theta)(1 + rho) > 2 (Proposition 1.9), and a quadrature check of the violation by f = g = 1 + eps h_2.
"""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss

rng = np.random.default_rng(11)


def gen_eig(S0, S1):
    L = np.linalg.cholesky(S1)
    Li = np.linalg.inv(L)
    ev, U = np.linalg.eigh(Li @ S0 @ Li.T)
    return ev[-1], Li.T @ U[:, -1]


worst, cnt, fails = (np.inf, None), 0, 0
for it in range(200000):
    n = rng.choice([3, 4])
    kind = rng.integers(3)
    if kind == 0:
        rho = rng.uniform(0.01, 0.99)
        S1 = (1 - rho) * np.eye(n) + rho * np.ones((n, n))
    else:
        A = rng.normal(size=(n, n + rng.integers(0, 3)))
        S = A @ A.T
        d = np.sqrt(np.diag(S))
        S1 = S / np.outer(d, d)
        if np.linalg.eigvalsh(S1)[0] < 1e-3:
            continue
    x = rng.uniform(-1, 1, n) if rng.random() < 0.3 else rng.uniform(0, 1, n)
    if rng.random() < 0.3:
        x[rng.integers(n)] = 1.0
    X = np.diag(x)
    S0 = X @ S1 @ X + np.eye(n) - X @ X
    ps, v = gen_eig(S0, S1)
    if ps < 1 + 1e-6:
        continue
    cnt += 1
    for dd in range(2, 9):
        lam = np.linalg.eigvalsh(ps * S1 ** dd - S0 ** dd)[0]
        if lam < worst[0]:
            worst = (lam, dd)
        if lam < -1e-9:
            fails += 1
            break
print(f"(1) forward-inequality structure: {cnt} instances, some level d in 2..8 negative at p*: {fails}; "
      f"smallest lambda_min over levels 2..8: {worst[0]:.3e} (level {worst[1]})")

bad = 0
for _ in range(20000):
    rho, theta = np.sort(rng.uniform(0, 1, 2))
    ps = (1 + theta) / (1 + rho)
    lam2 = (ps - 1) - abs(ps * rho ** 2 - theta ** 2)
    bad += (lam2 < -1e-12) != ((1 + theta) * (1 + rho) > 2)
print(f"(2) two functions, theta > rho: 'level 2 fails at p*' <=> '(1+theta)(1+rho) > 2' in all but {bad} of 20000 "
      "random pairs")
xs, ws = hermegauss(120)
ws = ws / np.sqrt(2 * np.pi)


def E2(F, c):
    s = 0.0
    sc = np.sqrt(1 - c * c)
    for a, wa in zip(xs, ws):
        s += wa * np.sum(ws * F(a, c * a + sc * xs))
    return s


theta, rho = 0.9, 0.5
ps = (1 + theta) / (1 + rho)
for eps in (0.2, 0.05):
    f = lambda t: 1 + eps * (t * t - 1) / np.sqrt(2)
    for p in (ps, 1.35):
        L = E2(lambda x, y: f(x) * f(y), theta)
        R = E2(lambda x, y: (f(x) * f(y)) ** p, rho) ** (1 / p)
        pred = eps ** 2 * ((p - 1) + p * rho ** 2 - theta ** 2)
        print(f"    theta=0.9, rho=0.5, eps={eps}, p={p:.4f}: RHS - LHS = {R - L:+.4e} "
              f"(second order: {pred:+.4e})")

# (3) Gaussian test functions f_j = exp(a_j y - b_j y^2/2) for theta = 0.9, rho = 0.5: smallest p (bisection) at which a
# numerical optimisation over (b_1, b_2) finds no violation; the linear terms a only contribute a^T(K0^-1 - p K1^-1)a,
# which is <= 0 once S0 <= p S1, so the score is the log-determinant part (or +inf if that matrix is not <= 0).
from scipy.optimize import minimize


def gscore(beta, S0, S1, p):
    B = np.diag(beta)
    I = np.eye(len(beta))
    K1 = np.linalg.inv(S1) + p * B
    if np.linalg.eigvalsh(K1)[0] <= 1e-12:
        return -np.inf
    K0 = np.linalg.inv(S0) + B
    if np.linalg.eigvalsh(K0)[0] <= 1e-12:
        return np.inf
    C = -0.5 * np.log(np.linalg.det(I + S0 @ B)) + np.log(np.linalg.det(I + p * S1 @ B)) / (2 * p)
    Q = 0.5 * (np.linalg.inv(K0) - p * np.linalg.inv(K1))
    return max(C, np.linalg.eigvalsh(0.5 * (Q + Q.T))[-1])


def gbest(S0, S1, p, rng):
    bv = -np.inf
    for _ in range(60):
        w0 = rng.normal(0, 1.5, 2)
        f = lambda w: gscore(np.sinh(w), S0, S1, p)
        if not np.isfinite(f(w0)):
            continue
        r = minimize(lambda w: -f(w) if np.isfinite(f(w)) else 1e6, w0, method="Nelder-Mead",
                     options={"maxiter": 3000, "xatol": 1e-12, "fatol": 1e-15})
        bv = max(bv, -r.fun)
    return bv


rng3 = np.random.default_rng(3)
S0g = np.array([[1, 0.9], [0.9, 1.0]])
S1g = np.array([[1, 0.5], [0.5, 1.0]])
lo, hi = 1.9 / 1.5, 1.9 / 0.5
for _ in range(30):
    mid = (lo + hi) / 2
    lo, hi = (mid, hi) if gbest(S0g, S1g, mid, rng3) > 1e-10 else (lo, mid)
herm = max((1 + 0.9 ** d) / (1 + 0.5 ** d) for d in range(1, 60))
print(f"(3) theta=0.9, rho=0.5: Gaussian threshold (numerical) {hi:.4f}; Hermite-level threshold sup_d "
      f"(1+theta^d)/(1+rho^d) = {herm:.4f}; p* = {1.9 / 1.5:.4f}")
