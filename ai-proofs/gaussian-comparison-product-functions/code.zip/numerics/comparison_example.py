"""The example of Proposition 1.6 in RESULT_gaussian_comparison_product_functions (n = 3, rho = 1/2,
x = (1, 1/2, 0)): exact checks (sympy) and floating-point complements.

S1 = equicorrelated(1/2), S0 = X S1 X + I - X^2 = [[1, 1/4, 0], [1/4, 1, 0], [0, 0, 1]].
(1) p* = (11 + sqrt 41)/8 is the top generalised eigenvalue, v = (1, 1, -(1 + sqrt 41)/4);
    the diagonal D forced at p = p* is diag(5/4, 5/4, 1), and S0 - D has the eigenvalue -1/2: no solution at p*.
(2) at p = 3, D = diag(3/4, 3/4, 1) satisfies p/(p-1)(S0 - S1) <= D <= S0 (exact).
(3) floating point: bisection for the smallest p at which the condition is feasible (D = diag(d, d, e) by symmetry).
(4) floating point: Gaussian test functions at p = p* (closed forms) give no violation.
(5) exact: the reduction behind "(1) is feasible iff p >= 3" (eigen-structure of D - c(S0 - S1) for D = diag(d, d, e)),
    and the two-step Hoelder condition S0 <= S <= p S1 (S = diag(s, s, s3)): the vector (1, -1, 0) forces s <= p/2,
    S - S0 >= 0 forces s >= 5/4, and S = diag(5/4, 5/4, 1) works at p = 5/2.
(6) floating point: smallest eigenvalues of p* S1^(d) - S0^(d) (entrywise powers; second variation at constants,
    Remark 1.7), d = 1..60, against the Gershgorin bound p*/2 - 1 for d >= 2.
"""
import numpy as np
import sympy as sp
from scipy.optimize import minimize

h = sp.Rational(1, 2)
S1 = sp.Matrix(3, 3, lambda i, j: 1 if i == j else h)
X = sp.diag(1, sp.Rational(1, 2), 0)
S0 = X * S1 * X + sp.eye(3) - X * X
p = sp.symbols("p")
ps = (11 + sp.sqrt(41)) / 8
print("S0 =", S0.tolist())
print("(1) det(S0 - p S1) =", sp.factor(sp.expand((S0 - p * S1).det())))
print("    det(S0 - p* S1) =", sp.simplify((S0 - ps * S1).det()))
v = sp.Matrix([1, 1, -(1 + sp.sqrt(41)) / 4])
print("    (S0 - p* S1) v =", sp.simplify((S0 - ps * S1) * v).T)
others = sp.solve(sp.expand((S0 - p * S1).det()), p)
print("    generalised eigenvalues:", [sp.nsimplify(e) for e in others], "-> p* is the largest:",
      all(sp.N(ps - e) >= 0 for e in others))
D = sp.diag(*[sp.simplify((S0 * v)[i] / v[i]) for i in range(3)])
print("    forced D =", D.tolist(), "; eigenvalues of S0 - D:", list((S0 - D).eigenvals().keys()))
D3 = sp.diag(sp.Rational(3, 4), sp.Rational(3, 4), 1)
lo = D3 - sp.Rational(3, 2) * (S0 - S1)
hi = S0 - D3
print("(2) p = 3, D = diag(3/4,3/4,1): eigenvalues of D - (3/2)(S0 - S1):", [sp.nsimplify(e) for e in lo.eigenvals()],
      "; of S0 - D:", [sp.nsimplify(e) for e in hi.eigenvals()])

S0n, S1n = np.array(S0, dtype=float), np.array(S1, dtype=float)


def margin(pp):
    def neg(w):
        Dm = np.diag([w[0], w[0], w[1]])
        return -min(np.linalg.eigvalsh(S0n - Dm)[0], np.linalg.eigvalsh(Dm - pp / (pp - 1) * (S0n - S1n))[0])
    return -min(minimize(neg, x0, method="Nelder-Mead", options={"xatol": 1e-12, "fatol": 1e-14, "maxiter": 4000}).fun
                for x0 in ([0.5, 0.5], [0.9, 0.9], [0.3, 1.0], [1.0, 0.3]))


a, b = float(ps), 50.0
for _ in range(60):
    mid = (a + b) / 2
    a, b = (a, mid) if margin(mid) >= -1e-13 else (mid, b)
print(f"(3) smallest p with the condition feasible: {b:.10f} (p* = {float(ps):.10f})")


def score(beta, pp):
    B = np.diag(beta); I = np.eye(3)
    K1 = np.linalg.inv(S1n) + pp * B
    if np.linalg.eigvalsh(K1)[0] <= 0:
        return -np.inf
    K0 = np.linalg.inv(S0n) + B
    if np.linalg.eigvalsh(K0)[0] <= 0:
        return np.inf
    C = -0.5 * np.log(np.linalg.det(I + S0n @ B)) + np.log(np.linalg.det(I + pp * S1n @ B)) / (2 * pp)
    Q = 0.5 * (np.linalg.inv(K0) - pp * np.linalg.inv(K1))
    return max(C, np.linalg.eigvalsh(0.5 * (Q + Q.T))[-1])


rng = np.random.default_rng(0)
best = -np.inf
for _ in range(200):
    v0 = rng.normal(0, 2, 3)
    f = lambda w: score(np.sinh(w), float(ps))
    if not np.isfinite(f(v0)):
        continue
    r = minimize(lambda w: -f(w) if np.isfinite(f(w)) else 1e6, v0, method="Nelder-Mead",
                 options={"maxiter": 6000, "xatol": 1e-12, "fatol": 1e-15})
    best = max(best, -r.fun)
print(f"(4) Gaussian test functions exp(a.t - t.B t/2), B diagonal, at p = p*: max score {best:+.3e} "
      "(score > 0 would be a violation)")

d_, e_, c_, s_, s3_ = sp.symbols("d e c s s3", real=True)
Dsym = sp.diag(d_, d_, e_)
M = Dsym - c_ * (S0 - S1)
w = sp.Matrix([1, -1, 0])
u = sp.Matrix([1, 1, 0]) / sp.sqrt(2)
e3 = sp.Matrix([0, 0, 1])
print("(5) D = diag(d,d,e): M = D - c(S0 - S1); M(1,-1,0) - (d - c/4)(1,-1,0) =",
      sp.simplify(M * w - (d_ - c_ / 4) * w).T)
blk = sp.Matrix([[(u.T * M * u)[0], (u.T * M * e3)[0]], [(e3.T * M * u)[0], (e3.T * M * e3)[0]]])
print("    block on span{(1,1,0)/sqrt2, e3}:", sp.simplify(blk).tolist())
print("    S0 - D eigenvalues:", list((S0 - Dsym).eigenvals().keys()))
cond = sp.factor(sp.expand((sp.Rational(3, 4) + c_ / 4) * 1 - c_ ** 2 / 2))
print("    at d = 3/4, e = 1: (d + c/4) e - c^2/2 =", cond, "-> >= 0 iff c <= 3/2 iff p >= 3")
Ssym = sp.diag(s_, s_, s3_)
print("    S - S0 eigenvalues:", list((Ssym - S0).eigenvals().keys()))
print("    (p S1 - S)(1,-1,0) - (p/2 - s)(1,-1,0) =", sp.simplify((p * S1 - Ssym) * w - (p / 2 - s_) * w).T)
Sc = sp.diag(sp.Rational(5, 4), sp.Rational(5, 4), 1)
print("    S = diag(5/4,5/4,1): eigenvalues of S - S0:", list((Sc - S0).eigenvals().keys()),
      "; of (5/2) S1 - S:", list((sp.Rational(5, 2) * S1 - Sc).eigenvals().keys()))

psf = float(ps)
lam = []
for d in range(1, 61):
    Md = psf * S1n ** d - S0n ** d
    lam.append(round(float(np.linalg.eigvalsh(Md)[0]), 9) + 0.0)
print("(6) lambda_min(p* S1^(d) - S0^(d)), d = 1..5:", " ".join(f"{x:.6f}" for x in lam[:5]))
print(f"    min over 2 <= d <= 60: {min(lam[1:]):.6f}; Gershgorin bound p*/2 - 1 = {psf / 2 - 1:.6f}")
