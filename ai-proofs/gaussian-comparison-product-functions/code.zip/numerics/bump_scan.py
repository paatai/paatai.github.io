"""Stress test of Proposition 1.3 / Theorem 1.1: for many q and angles, just outside the boundary of
Omega_{q,q}, find (B, t) with Lambda(B, t) = log(E|T_z b|^q / E b) > log q  (closed forms, mpmath).
Also checks kappa(z) > 0 and delta(z) > 0 there.  Floating point / mpmath: evidence, not proof."""
import mpmath as mp
from bump_test import closed_forms

mp.mp.dps = 30


def r_qq(alpha, q):
    """radius of Omega_{q,q} on the ray arg z = alpha (bisection on Phi(z) = (q-2)|1-z^2| - q(1-|z|^2))."""
    lo, hi = mp.mpf(0), mp.mpf(1)
    for _ in range(80):
        mid = (lo + hi) / 2
        z = mid * mp.expj(alpha)
        if (q - 2) * abs(1 - z * z) - q * (1 - abs(z) ** 2) <= 0:
            lo = mid
        else:
            hi = mid
    return lo


def best_margin(z, q):
    best = None
    for lB in [1, 1.5, 2, 2.5, 3, 3.5, 4, 4.5, 5, 6]:
        B = mp.mpf(10) ** lB
        for x0 in [2, 4, 6, 8, 10, 15, 20, 30, 40, 60, 80, 120]:
            cf = closed_forms(z, q, B, B * x0)
            if cf is None:
                continue
            L = cf[0] - cf[1] - mp.log(q)
            if best is None or L > best[0]:
                best = (L, lB, x0)
    return best


if __name__ == "__main__":
    worst = None
    for q in [mp.mpf("2.05"), mp.mpf("2.5"), 3, 4, 6, 10, 30]:
        for k in range(1, 12):
            alpha = mp.pi / 2 * k / 12
            r0 = r_qq(alpha, q)
            for eps in [mp.mpf("0.002"), mp.mpf("0.01"), mp.mpf("0.05")]:
                r = r0 + eps
                if r >= 1:
                    continue
                z = r * mp.expj(alpha)
                s = 1 - z * z
                A = mp.re(1 / s); C = mp.re(z / s); delta = 1 - q + q * A
                kappa = -A / 2 + 1 / (2 * q) + q * C * C / (2 * delta) if delta != 0 else mp.nan
                b = best_margin(z, q)
                tag = "OK " if (b is not None and b[0] > 0) else "NO "
                if b is not None and (worst is None or b[0] < worst[0]):
                    worst = (b[0], q, alpha, eps)
                print(tag, "q=%s arg=%.4f r_qq=%.5f eps=%s delta=%.4f kappa=%.3e  best Lambda-log q=%s (log10B=%s, x0=%s)" % (
                    mp.nstr(q, 4), float(alpha), float(r0), mp.nstr(eps, 3), float(delta), float(kappa),
                    mp.nstr(b[0], 6) if b else None, b[1] if b else None, b[2] if b else None), flush=True)
    print("worst margin over the scan:", worst)
