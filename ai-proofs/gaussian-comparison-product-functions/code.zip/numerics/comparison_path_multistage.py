"""Multi-stage path flow (floating point search) for the example of Proposition 1.6 of
RESULT_gaussian_comparison_product_functions: S0 = [[1,1/4,0],[1/4,1,0],[0,0,1]], S1 = equicorrelated(1/2).

A stage is either 'S' (scalar blocks: all correlations may move, Dt diagonal) or 'G' (blocks {1,2} and {3}: c12 is
frozen during the stage and Dt may have a full 2x2 block on {1,2}). Each stage is Theorem 4.1 for its block
structure (grouping as in Remark 1.2(d)); chaining stages multiplies the exponents, so the total exponent is
e^{sum T_i}. Discretisation: piecewise-linear paths with one Dt per piece; for fixed stage lengths this is one
semidefinite feasibility problem. The stage lengths are T * (fractions); the main program probes p = 2.20, 2.21.
"""
import sys
import numpy as np
import cvxpy as cp
from scipy.optimize import minimize

S1 = np.full((3, 3), 0.5) + 0.5 * np.eye(3)
S0 = np.array([[1, 0.25, 0], [0.25, 1, 0], [0, 0, 1.0]])
ps = (11 + np.sqrt(41)) / 8


def build(stages, Ts, Ns, slack=False):
    Ntot = sum(Ns)
    Cs = [cp.Constant(S0)] + [cp.Variable((3, 3), symmetric=True) for _ in range(Ntot - 1)] + [cp.Constant(S1)]
    t = cp.Variable() if slack else 0.0
    cons = []
    for k in range(1, Ntot):
        cons += [cp.diag(Cs[k]) == 1, Cs[k] >> 0]
    Ds, k0 = [], 0
    for kind, T, N in zip(stages, Ts, Ns):
        h = T / N
        for k in range(k0, k0 + N):
            if kind == "G":
                A = cp.Variable((2, 2), symmetric=True)
                d3 = cp.Variable(nonneg=True)
                Dk = cp.bmat([[A, np.zeros((2, 1))], [np.zeros((1, 2)), cp.reshape(d3, (1, 1), order="F")]])
                cons += [A >> 0, Cs[k + 1][0, 1] == Cs[k][0, 1]]
            else:
                dk = cp.Variable(3, nonneg=True)
                Dk = cp.diag(dk)
            I = np.eye(3)
            cons += [Cs[k] - Dk >> t * I, Cs[k + 1] - Dk >> t * I, (Cs[k + 1] - Cs[k]) + h * Dk >> t * h * I]
            Ds.append((kind, Dk))
        k0 += N
    return Cs, Ds, cons, t


def feasible(stages, Ts, Ns):
    _, _, cons, _ = build(stages, Ts, Ns)
    prob = cp.Problem(cp.Minimize(0), cons)
    try:
        prob.solve(solver="CLARABEL")
    except cp.error.SolverError:
        return False
    return prob.status == "optimal"


def min_total(stages, fr, Ns, lo, hi, iters=20):
    fr = np.abs(fr) / np.sum(np.abs(fr))
    f = lambda T: feasible(stages, T * fr, Ns)
    if not f(hi):
        return hi + 1.0
    for _ in range(iters):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if f(mid) else (mid, hi)
    return hi


if __name__ == "__main__":
    # quick probe at fixed targets: is the discretised multi-stage problem feasible at p = 2.20 and 2.21?
    for stages, fr, nper in ((("G", "S"), [0.4, 0.6], 32), (("G", "S"), [0.3, 0.7], 24), (("G", "S"), [0.5, 0.5], 24),
                             (("G", "S", "G"), [0.35, 0.45, 0.2], 16), (("G", "S", "G"), [0.3, 0.5, 0.2], 16),
                             (("G", "S", "G", "S"), [0.3, 0.3, 0.2, 0.2], 12)):
        res = []
        for ptarget in (2.20, 2.21):
            T = np.log(ptarget) - 1e-4
            frn = np.array(fr) / np.sum(fr)
            res.append(f"p={ptarget}: {'feasible' if feasible(stages, T * frn, [nper] * len(stages)) else 'infeasible'}")
        print(f"stages {'-'.join(stages)}, fractions {fr}, {nper} pieces each: " + ", ".join(res), flush=True)
