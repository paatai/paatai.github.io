"""Bump test: one-dimensional violations of ||T_z f||_q <= ||f||_inf outside Omega_{q,q}.

For 0 <= b <= 1 put f = 1 - 2b, so |f| <= 1.  Since T_z 1 = 1 and E T_z b = E b, the scalar inequality
|1+w|^q >= 1 + q Re w + 2^{1-q}|w|^q  (q >= 2) gives
    E|T_z f|^q >= 1 - 2q E b + 2 E|T_z b|^q,
so f violates L^inf -> L^q contractivity as soon as E|T_z b|^q > q E b.
Here b = g / max g with g(x) = exp(-B x^2/2 + t x), B > 0, t real; everything is in closed form.
This script (mpmath, 40 digits) scans (B, x0 = t/B) using the closed forms only.
"""
import sys
import mpmath as mp

mp.mp.dps = 40


def closed_forms(z, q, B, t):
    s = 1 - z * z
    D = 1 + B * s
    bp = -B * z * z / D          # beta'
    tp = t * z / D               # t'
    tau = s * t * t / (2 * D)
    den = 1 - q * mp.re(bp)
    if den <= 0:
        return None
    # log E|T_z g|^q
    logETq = (-q / 2) * mp.log(abs(D)) + q * mp.re(tau) - mp.log(den) / 2 + (q * mp.re(tp)) ** 2 / (2 * den)
    logEg = -mp.log(1 + B) / 2 + t * t / (2 * (1 + B))
    logmax = t * t / (2 * B)
    logETbq = logETq - q * logmax
    logEb = logEg - logmax
    return logETbq, logEb


def ratio(z, q, B, x0):
    t = B * x0
    cf = closed_forms(z, q, B, t)
    if cf is None:
        return None
    a, b = cf
    return a - b   # log(E|T_z b|^q / E b)


def Tzb(z, B, t, x):
    s = 1 - z * z
    D = 1 + B * s
    bp = -B * z * z / D
    tp = t * z / D
    tau = s * t * t / (2 * D)
    return mp.exp(bp * x * x / 2 + tp * x + tau - t * t / (2 * B)) / mp.sqrt(D)


def direct(z, q, B, x0):
    """E|1 - 2 T_z b|^q - 1 by quadrature, with the integrand |1-2h|^q - 1 computed without cancellation.
    The q-mass of T_z b sits near x* = q Re t'/(1 - q Re beta'); the input bump sits near x0."""
    t = B * x0
    s = 1 - z * z
    D = 1 + B * s
    bp = -B * z * z / D
    tp = t * z / D
    den = 1 - q * mp.re(bp)
    xs = q * mp.re(tp) / den
    w = 12 / mp.sqrt(den)

    def f(x):
        h = Tzb(z, B, t, x)
        u = -4 * mp.re(h) + 4 * abs(h) ** 2
        return mp.expm1((q / 2) * mp.log1p(u)) * mp.exp(-x * x / 2) / mp.sqrt(2 * mp.pi)

    # the mean term E Re h comes from the region where T_z b is spread out; split generously
    pts = [-mp.inf] + [mp.mpf(k) for k in range(-60, 61, 2)] + [xs - w, xs - w / 3, xs, xs + w / 3, xs + w, mp.inf]
    pts = sorted(set(pts), key=lambda v: float(v) if v not in (mp.inf, -mp.inf) else (1e300 if v == mp.inf else -1e300))
    return mp.quad(f, pts), xs


if __name__ == "__main__":
    cases = [
        ("(6,3) certified instance", mp.mpf("0.825") * mp.exp(0.6j), 3),
        ("(inf,3) r=0.81 arg 0.7", mp.mpf("0.81") * mp.exp(0.7j), 3),
        ("q=4 Theorem D point", mp.mpf("0.72") * mp.exp(0.7j), 4),
        ("(8,4) explicit example point", mp.mpf("0.705") * mp.exp(0.7j), 4),
    ]
    for name, z, q in cases:
        best = None
        for lB in [1, 1.5, 2, 2.5, 3, 3.5, 4, 5]:
            B = mp.mpf(10) ** lB
            for x0 in [5, 10, 15, 20, 25, 30, 40, 50]:
                r = ratio(z, q, B, mp.mpf(x0))
                if r is None:
                    continue
                if best is None or r > best[0]:
                    best = (r, lB, x0)
        print(name, " q =", q, " best log(E|Tb|^q/Eb) on grid =", mp.nstr(best[0], 8),
              " at log10 B =", best[1], " x0 =", best[2], "  need > log q =", mp.nstr(mp.log(q), 6))
        # smallest x0 achieving violation for B = 10^lB of the best row
        B = mp.mpf(10) ** best[1]
        lo = None
        for x0 in [mp.mpf(k) / 2 for k in range(2, 200)]:
            r = ratio(z, q, B, x0)
            if r is not None and r > mp.log(q) + mp.log(2):
                lo = x0
                break
        print("   first x0 with ratio > 2q (B = 10^%s): %s" % (best[1], lo))
        if lo is not None:
            cf = closed_forms(z, q, B, B * lo)
            lb = 2 * mp.exp(cf[0]) - 2 * q * mp.exp(cf[1])
            print("   bump-lemma lower bound 2E|T_z b|^q - 2qEb =", mp.nstr(lb, 12),
                  "   E b =", mp.nstr(mp.exp(cf[1]), 6),
                  "   (for a direct quadrature of the excess see bump_direct_check.py; at 40 digits the cancellation"
                  " in E|1-2T_z b|^q - 1 is not resolved)")
        sys.stdout.flush()
