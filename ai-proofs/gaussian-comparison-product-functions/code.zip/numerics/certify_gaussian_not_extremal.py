"""Certificate for Proposition 1.10 of RESULT_gaussian_comparison_product_functions (exact sympy + Arb ball arithmetic).

n = 2 scalar blocks, correlation theta = 93/100 under Sigma_0 and rho = 3/5 under Sigma_1, p = 3/2.
(1) Exact: Sigma_0 <= p Sigma_1 (p* = (1+theta)/(1+rho) < 3/2) and the fifth Hermite level fails:
    (p - 1) + p rho^5 - theta^5 < 0, so the comparison inequality fails (Proposition 1.9 / Remark 1.7).
(2) Every Gaussian test function satisfies the inequality. With B = diag(b1, b2) and A(b) = det(I + Sigma_0 B),
    Bd(b) = det(I + p Sigma_1 B), this reduces to P = A^3 - Bd^2 >= 0 on D = {Sigma_1^{-1} + p B > 0}
    = {u1, u2 > 0, u1 u2 > 25/64}, u_i = b_i + 25/24. On D, A >= kappa u1 u2 + kappa delta (u1 + u2) + c0 with
    explicit rationals (checked exactly below) and A > 0; on the boundary Bd = 0 so P = A^3 > 0; P -> oo at infinity.
    Hence the minimum of P on the closure of D is attained at an interior critical point, unless it is positive.
    All real critical points: lex Groebner basis {c(b1) b2 + d(b1), h(b1)} of (dP/db1, dP/db2); real roots of h
    isolated exactly; b2 = -d/c evaluated in ball arithmetic; P evaluated in ball arithmetic at each.
"""
from fractions import Fraction as Fr
import sympy as sp
import flint

theta, rho, p = Fr(93, 100), Fr(3, 5), Fr(3, 2)
ok = True

pstar = (1 + theta) / (1 + rho)
lvl5 = (p - 1) + p * rho ** 5 - theta ** 5
print(f"(1) p* = {pstar} = {float(pstar):.6f} < p = 3/2: {pstar < p}; level 5: (p-1) + p rho^5 - theta^5 = {lvl5} "
      f"= {float(lvl5):+.6f} < 0: {lvl5 < 0}")
ok &= pstar < p and lvl5 < 0

kappa = 1 - theta ** 2
s = p ** 2 * (1 - rho ** 2)
cshift = Fr(1, 1) / (1 - rho ** 2) / p
print(f"    D: b_i > -{cshift}, and Bd = {s} u1 u2 - {s * cshift ** 2 - 1} > 0 with u_i = b_i + {cshift}; "
      f"threshold u1 u2 > {(s * cshift ** 2 - 1) / s}")
ok &= cshift == Fr(25, 24) and (s * cshift ** 2 - 1) / s == Fr(25, 64)
delta = 1 / kappa - cshift
kd = kappa * delta
c0 = kappa * delta ** 2 + 1 - 1 / kappa
lowerA = kd * 2 * Fr(5, 8) + c0
print(f"(2) A = kappa (u1+delta)(u2+delta) + 1 - 1/kappa: kappa = {kappa}, kappa delta = {kd} = {float(kd):.6f}, "
      f"c0 = {c0} = {float(c0):.6f}; on D (u1 + u2 >= 5/4): A >= kappa u1 u2 + {float(lowerA):.6f} > 0: {lowerA > 0}")
ok &= lowerA > 0 and kd > 0

b1, b2 = sp.symbols("b1 b2")
A = 1 + b1 + b2 + sp.Rational(kappa.numerator, kappa.denominator) * b1 * b2
Bd = 1 + sp.Rational(3, 2) * (b1 + b2) + sp.Rational(s.numerator, s.denominator) * b1 * b2
Ptot = sp.expand(A ** 3 - Bd ** 2)
P1, P2 = sp.expand(sp.diff(Ptot, b1)), sp.expand(sp.diff(Ptot, b2))
print("    gcd(dP/db1, dP/db2) =", sp.gcd(sp.Poly(P1, b1, b2), sp.Poly(P2, b1, b2)).as_expr())
G = sp.groebner([P1, P2], b2, b1, order="lex").exprs
assert len(G) == 2
g1 = [g for g in G if sp.Poly(g, b2).degree() == 1][0]
h = [g for g in G if sp.Poly(g, b2).degree() == 0][0]
cpoly = sp.Poly(g1, b2).coeff_monomial(b2)
dpoly = sp.expand(g1 - cpoly * b2)
H = sp.Poly(h, b1)
print(f"    lex Groebner basis: c(b1) b2 + d(b1) (deg c = {sp.Poly(cpoly, b1).degree()}, deg d = "
      f"{sp.Poly(dpoly, b1).degree()}), h(b1) of degree {H.degree()}")


def arb_q(q):
    q = sp.Rational(q)
    return flint.arb(flint.fmpq(int(q.p), int(q.q)))


def arbpoly(expr, x):
    out = flint.arb(0)
    for (k,), co in sp.Poly(expr, b1).terms():
        out += arb_q(co) * x ** k
    return out


def arbP(x, y):
    Aa = 1 + x + y + arb_q(sp.Rational(kappa.numerator, kappa.denominator)) * x * y
    Ba = 1 + arb_q(sp.Rational(3, 2)) * (x + y) + arb_q(sp.Rational(s.numerator, s.denominator)) * x * y
    return Aa ** 3 - Ba ** 2, Ba


ivs = H.intervals(eps=sp.Rational(1, 10 ** 40))
print(f"    real roots of h: {len(ivs)}")
n_zero = 0
for (lo, hi), mult in ivs:
    lo, hi = sp.Rational(lo), sp.Rational(hi)
    if lo == hi:
        x = arb_q(lo)
    else:
        mid, rad = (lo + hi) / 2, (hi - lo) / 2
        x = flint.arb(flint.fmpq(int(mid.p), int(mid.q)), flint.arb(flint.fmpq(int(rad.p), int(rad.q))).upper())
    cv, dv = arbpoly(cpoly, x), arbpoly(dpoly, x)
    if cv.contains(0):
        print("    c(b1) may vanish at a root: NOT CERTIFIED")
        ok = False
        continue
    y = -dv / cv
    Pv, Bv = arbP(x, y)
    outside = bool(x < -arb_q(sp.Rational(25, 24))) or bool(Bv < 0)
    exact_origin = lo == hi == 0 and sp.Poly(dpoly, b1).eval(0) == 0
    if exact_origin:
        n_zero += 1
        status = "the origin (exact), P = 0"
    elif outside:
        status = "outside D"
    elif bool(Pv > 0):
        status = "in D, P > 0"
    else:
        status = "NOT CERTIFIED"
        ok = False
    print(f"    critical point b1 = {x.str(15)}, b2 = {y.str(15)}: P = {Pv.str(12)}; {status}")
ok &= n_zero == 1
print("CERTIFIED: every Gaussian test function satisfies the inequality, while it fails at level 5" if ok
      else "NOT CERTIFIED")
