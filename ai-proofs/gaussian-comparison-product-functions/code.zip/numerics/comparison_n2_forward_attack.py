"""Floating-point attack (evidence only) for RESULT_gaussian_comparison_product_functions, after Proposition 1.10:
two scalar functions, correlation theta = 0.9 under Sigma_0 and rho = 0.5 under Sigma_1. Thresholds: p* = 1.2667,
Gaussian test functions 1.497 (numerical), Hermite levels sup_d (1+theta^d)/(1+rho^d) = 1.5587 (d = 4).
Test functions f, g = exp(sum_{k=1}^{6} a_k He_k(s)), s = t / sqrt(1 + t^2/16), optimised by BFGS with 70-node tensor
Gauss-Hermite quadrature; every optimiser is re-evaluated with 140 and 220 nodes and only values that agree to 3 digits
are reported (large 70-node "violations" with big coefficients are quadrature artefacts and disappear).
"""
import warnings
import numpy as np
from numpy.polynomial.hermite_e import hermegauss, hermevander
from scipy.optimize import minimize

warnings.filterwarnings("ignore")
th, rh, K = 0.9, 0.5, 6


def make(NQ):
    xs, ws = hermegauss(NQ)
    ws = ws / np.sqrt(2 * np.pi)

    def cw(c):
        X = np.repeat(xs, NQ)
        Y = c * X + np.sqrt(1 - c * c) * np.tile(xs, NQ)
        return X, Y, np.repeat(ws, NQ) * np.tile(ws, NQ)
    return cw(th), cw(rh)


def logf(a, t):
    return hermevander(t / np.sqrt(1 + t * t / 16), K)[:, 1:] @ a


def ratio(par, p, same, Q):
    (X0, Y0, W0), (X1, Y1, W1) = Q
    a = par[:K]
    b = par[:K] if same else par[K:]
    L = np.sum(W0 * np.exp(logf(a, X0) + logf(b, Y0)))
    R = np.sum(W1 * np.exp(p * (logf(a, X1) + logf(b, Y1)))) ** (1 / p)
    return np.log(L) - np.log(R)


Q70 = make(70)
Qf = [make(n) for n in (140, 220)]
rng = np.random.default_rng(0)
for p in (1.50, 1.56, 1.60, 1.75, 2.0):
    lev = min((p - 1) + p * rh ** d - th ** d for d in range(1, 60))
    stable = []
    for same in (True, False):
        for _ in range(25):
            x0 = rng.normal(0, 0.3, K if same else 2 * K)
            r = minimize(lambda v: -ratio(v, p, same, Q70), x0, method="BFGS", options={"maxiter": 400})
            if not np.isfinite(r.fun):
                continue
            fine = [ratio(r.x, p, same, Q) for Q in Qf]
            if abs(fine[0] - fine[1]) <= 1e-3 * max(abs(fine[1]), 1e-9) and abs(-r.fun - fine[1]) <= 1e-3 * max(abs(fine[1]), 1e-9):
                stable.append(fine[1])
    best = max(stable) if stable else float("nan")
    print(f"p = {p}: smallest Hermite-level margin min_d (p-1) + p rho^d - theta^d = {lev:+.5f}; best stable "
          f"log-ratio {best:+.3e} over {len(stable)} stable optimisers (> 0 is a violation)")
