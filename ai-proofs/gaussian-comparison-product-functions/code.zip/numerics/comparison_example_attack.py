"""Attack on the example in RESULT_gaussian_comparison_product_functions (Proposition 1.6; written when the
proved range was p >= 3, now p >= 5/2, so p* and 2.3 lie in the open range [p*, 5/2)):
S1 = equicorrelated(1/2), S0 = [[1,1/4,0],[1/4,1,0],[0,0,1]], p* = (11 + sqrt 41)/8.
Inequality: E_{S0}[f1 f2 f3] <= ||f1 f2 f3||_{L^p(S1)}. Floating point (evidence only): tensor Gauss-Hermite
quadrature, optimised test functions f_j = exp(a_j t + b_j t^2 + c_j tanh(w_j (t - d_j))), with the best values
recomputed on a finer grid."""
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from scipy.optimize import minimize

S1 = np.full((3, 3), 0.5) + 0.5 * np.eye(3)
S0 = np.array([[1, 0.25, 0], [0.25, 1, 0], [0, 0, 1.0]])
ps = (11 + np.sqrt(41)) / 8


def grid(N):
    ND, WT = hermegauss(N); WT = WT / WT.sum()
    Z = np.array(np.meshgrid(ND, ND, ND, indexing="ij")).reshape(3, -1)
    return Z, np.einsum("i,j,k->ijk", WT, WT, WT).reshape(-1)


def logratio(th, p, Z, W):
    th = np.clip(th, -1.2, 1.2)
    A0, A1 = np.linalg.cholesky(S0) @ Z, np.linalg.cholesky(S1) @ Z
    def F(t, j):
        a, b, c, d, w = th[5 * j:5 * j + 5]
        return a * t + 0.15 * b * t * t + c * np.tanh((0.3 + abs(w)) * (t - d))
    l0 = sum(F(A0[j], j) for j in range(3)); l1 = sum(F(A1[j], j) for j in range(3))
    m0, m1 = l0.max(), (p * l1).max()
    lhs = m0 + np.log((W * np.exp(l0 - m0)).sum())
    rhs = (m1 + np.log((W * np.exp(p * l1 - m1)).sum())) / p
    v = lhs - rhs
    return v if np.isfinite(v) else -1e3


if __name__ == "__main__":
    rng = np.random.default_rng(1)
    Zc, Wc = grid(30); Zf, Wf = grid(56)
    for p in (ps, 2.3, 2.6, 2.9):
        best, bx = -np.inf, None
        for k in range(40):
            th0 = rng.normal(0, 0.6, 15)
            r = minimize(lambda t: -logratio(t, p, Zc, Wc), th0, method="Nelder-Mead",
                         options={"maxiter": 6000, "xatol": 1e-10, "fatol": 1e-14})
            if -r.fun > best:
                best, bx = -r.fun, r.x
        fine = logratio(bx, p, Zf, Wf)
        print(f"p = {p:.4f}: best log-ratio {best:+.3e} (30 nodes), recomputed {fine:+.3e} (56 nodes)", flush=True)
