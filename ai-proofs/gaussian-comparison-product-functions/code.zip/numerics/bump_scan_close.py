"""Re-check, closer to the boundary of Omega_{q,q}, the rays where bump_scan.py found no violation (delta < 0 there, i.e. outside the neighbourhood U of Prop. 1.3)."""
import mpmath as mp, sys
sys.path.insert(0, ".")
from bump_scan import r_qq
from bump_test import closed_forms
mp.mp.dps = 40
cases = [("2.05", 0.7854), ("2.05", 1.4399), ("2.5", 1.3090), ("2.5", 1.4399), ("10", 1.4399), ("30", 1.4399), ("30", 1.3090)]
for qs, al in cases:
    q = mp.mpf(qs); alpha = mp.mpf(al)
    r0 = r_qq(alpha, q)
    for eps in ["1e-3", "1e-4", "1e-5"]:
        z = (r0 + mp.mpf(eps)) * mp.expj(alpha)
        s = 1 - z*z; A = mp.re(1/s); C = mp.re(z/s); delta = 1 - q + q*A
        kappa = -A/2 + 1/(2*q) + q*C*C/(2*delta)
        best = None
        for lB in [2, 3, 4, 5, 6, 7, 8, 9, 10]:
            B = mp.mpf(10)**lB
            for x0 in [10, 30, 100, 300, 1000, 3000]:
                cf = closed_forms(z, q, B, B*x0)
                if cf is None: continue
                L = cf[0] - cf[1] - mp.log(q)
                if best is None or L > best[0]: best = (L, lB, x0)
        print("q=%s arg=%.4f eps=%s delta=%.3e kappa=%.3e best=%s" % (qs, al, eps, float(delta), float(kappa),
              (mp.nstr(best[0], 5), best[1], best[2]) if best else None), flush=True)
