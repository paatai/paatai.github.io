"""Exact certificate for the path version of the flow (Theorem 4.1 of RESULT_gaussian_comparison_product_functions)
in the example of Proposition 1.6: S1 = equicorrelated(1/2), S0 = [[1,1/4,0],[1/4,1,0],[0,0,1]].

Certificate: rational correlation matrices C_0 = S0, C_1, ..., C_N = S1 (unit diagonal), rational diagonal D_k >= 0
(k = 0..N-1) and a rational step h > 0 such that, exactly,
    C_k > 0 (k = 0..N),   C_k - D_k >= 0,   C_{k+1} - D_k >= 0,   (C_{k+1} - C_k) + h D_k >= 0.
Then the piecewise-linear path C(s) through the C_k with breakpoints s_k = k h, and Dt(s) = D_k on (s_k, s_{k+1}),
satisfies the hypotheses of Theorem 4.1 (C(s) - D_k is affine in s on each piece, so positivity at the two ends
suffices), and the comparison inequality holds for p = e^{N h}, hence for every p >= e^{N h} (Lyapunov).
Positive semi-definiteness of a 3x3 rational symmetric matrix is checked by all principal minors >= 0, positive
definiteness by the leading principal minors > 0, all in exact rational arithmetic (fractions.Fraction).
e^{N h} < P_TARGET is checked with Arb ball arithmetic (python-flint).
The SDP solver (cvxpy/CLARABEL) only proposes the certificate; it is rounded to rationals and then verified exactly.
Usage: python3 comparison_path_certificate.py [N] [T] [P]   (defaults 256 1657/2000 229/100; also run: 64 1041/1250 23/10)
"""
import sys
from fractions import Fraction as F
from itertools import combinations
import numpy as np
import cvxpy as cp
import flint

N = int(sys.argv[1]) if len(sys.argv) > 1 else 256
T = F(sys.argv[2]) if len(sys.argv) > 2 else F(1657, 2000)
P_TARGET = F(sys.argv[3]) if len(sys.argv) > 3 else F(229, 100)
h = T / N

S1q = [[F(1), F(1, 2), F(1, 2)], [F(1, 2), F(1), F(1, 2)], [F(1, 2), F(1, 2), F(1)]]
S0q = [[F(1), F(1, 4), F(0)], [F(1, 4), F(1), F(0)], [F(0), F(0), F(1)]]


def det(M, idx):
    if len(idx) == 1:
        return M[idx[0]][idx[0]]
    if len(idx) == 2:
        i, j = idx
        return M[i][i] * M[j][j] - M[i][j] * M[j][i]
    i, j, k = idx
    return (M[i][i] * (M[j][j] * M[k][k] - M[j][k] * M[k][j]) - M[i][j] * (M[j][i] * M[k][k] - M[j][k] * M[k][i])
            + M[i][k] * (M[j][i] * M[k][j] - M[j][j] * M[k][i]))


def psd(M):
    return all(det(M, list(c)) >= 0 for r in (1, 2, 3) for c in combinations(range(3), r))


def pd(M):
    return all(det(M, list(range(r))) > 0 for r in (1, 2, 3))


def sub(A, B):
    return [[A[i][j] - B[i][j] for j in range(3)] for i in range(3)]


def add(A, B):
    return [[A[i][j] + B[i][j] for j in range(3)] for i in range(3)]


def diagm(d):
    return [[d[i] if i == j else F(0) for j in range(3)] for i in range(3)]


def scal(c, A):
    return [[c * A[i][j] for j in range(3)] for i in range(3)]


def propose(N, T):
    S0 = np.array([[float(x) for x in r] for r in S0q])
    S1 = np.array([[float(x) for x in r] for r in S1q])
    hf = T / N
    t = cp.Variable()
    Cs = [cp.Constant(S0)] + [cp.Variable((3, 3), symmetric=True) for _ in range(N - 1)] + [cp.Constant(S1)]
    Ds = [cp.Variable(3) for _ in range(N)]
    I = np.eye(3)
    cons = [t <= 0.05]
    for k in range(1, N):
        cons += [cp.diag(Cs[k]) == 1, Cs[k] >> t * I]
    for k in range(N):
        Dk = cp.diag(Ds[k])
        cons += [Ds[k] >= t, Cs[k] - Dk >> t * I, Cs[k + 1] - Dk >> t * I, (Cs[k + 1] - Cs[k]) + hf * Dk >> t * hf * I]
    prob = cp.Problem(cp.Maximize(t), cons)
    prob.solve(solver="CLARABEL")
    return prob.status, t.value, [S0] + [Cs[k].value for k in range(1, N)] + [S1], [d.value for d in Ds]


status, slack, Cf, Df = propose(N, float(T))
print(f"N = {N}, h = {h} (T = N h = {T}), SDP status {status}, common slack {slack:.3e}")


def rat(x):
    return F(x).limit_denominator(10 ** 9)


Cq = [S0q]
for k in range(1, N):
    M = [[F(1) if i == j else rat(0.5 * (Cf[k][i][j] + Cf[k][j][i])) for j in range(3)] for i in range(3)]
    Cq.append(M)
Cq.append(S1q)
Dq = [[max(F(0), rat(x)) for x in Df[k]] for k in range(N)]

ok = True
for k in range(N + 1):
    ok &= pd(Cq[k]) and all(Cq[k][i][i] == 1 for i in range(3))
for k in range(N):
    Dk = diagm(Dq[k])
    ok &= all(d >= 0 for d in Dq[k])
    ok &= psd(sub(Cq[k], Dk)) and psd(sub(Cq[k + 1], Dk))
    ok &= psd(add(sub(Cq[k + 1], Cq[k]), scal(h, Dk)))
expT = flint.arb(T.numerator) / flint.arb(T.denominator)
e = expT.exp()
bound_ok = bool(e < flint.arb(P_TARGET.numerator) / flint.arb(P_TARGET.denominator))
print(f"exact checks of all {4 * N + N + 1} matrix conditions: {'PASSED' if ok else 'FAILED'}")
print(f"e^(N h) = {e.str(10)} < {P_TARGET} (Arb): {bound_ok}")
print(f"CERTIFIED: the comparison inequality holds in the example for every p >= {P_TARGET}" if ok and bound_ok
      else "NOT CERTIFIED")
