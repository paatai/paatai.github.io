"""Second floating-point attack (evidence only) on the example of Proposition 1.6 of
RESULT_gaussian_comparison_product_functions (S1 = equicorrelated 1/2, S0 = [[1,1/4,0],[1/4,1,0],[0,0,1]]) in the
open range [p*, 2.29): f_j = exp(sum_{k=1}^{6} a_{jk} T_k(s)), T_k Chebyshev, s = t/sqrt(16 + t^2) in (-1,1),
a = AMAX tanh(v) (bounded, so that quadrature stays accurate), BFGS with 36 nodes per axis, then re-evaluation with
56 and 72 nodes; only optimisers whose value agrees across the three grids to 1e-3 (relative) are reported.
"""
import sys
import warnings
import numpy as np
from numpy.polynomial.hermite_e import hermegauss
from numpy.polynomial.chebyshev import chebvander
from scipy.optimize import minimize

warnings.filterwarnings("ignore")
K = 6
S1 = np.full((3, 3), 0.5) + 0.5 * np.eye(3)
S0 = np.array([[1, 0.25, 0], [0.25, 1, 0], [0, 0, 1.0]])
ps = (11 + np.sqrt(41)) / 8


def grid(NQ, S):
    xs, ws = hermegauss(NQ)
    ws = ws / np.sqrt(2 * np.pi)
    Z = np.stack(np.meshgrid(xs, xs, xs, indexing="ij"), -1).reshape(-1, 3)
    W = np.prod(np.stack(np.meshgrid(ws, ws, ws, indexing="ij"), -1).reshape(-1, 3), axis=1)
    L = np.linalg.cholesky(S)
    return Z @ L.T, W


AMAX = 1.5


def basis(t):
    return chebvander(t / np.sqrt(16 + t * t), K)[:, 1:]


def make(NQ):
    (X0, W0), (X1, W1) = grid(NQ, S0), grid(NQ, S1)
    B0 = [basis(X0[:, j]) for j in range(3)]
    B1 = [basis(X1[:, j]) for j in range(3)]
    return B0, W0, B1, W1


def ratio(par, p, Q):
    B0, W0, B1, W1 = Q
    a = AMAX * np.tanh(par).reshape(3, K)
    l0 = sum(B0[j] @ a[j] for j in range(3))
    l1 = sum(B1[j] @ a[j] for j in range(3))
    m0, m1 = l0.max(), p * l1.max()
    L = np.log(np.sum(W0 * np.exp(l0 - m0))) + m0
    R = (np.log(np.sum(W1 * np.exp(p * l1 - m1))) + m1) / p
    return L - R


Qs = [make(n) for n in (36, 56, 72)]
rng = np.random.default_rng(int(sys.argv[1]) if len(sys.argv) > 1 else 0)
for p in (ps, 2.2):
    stable = []
    for it in range(30):
        x0 = rng.normal(0, 0.4, 3 * K)
        r = minimize(lambda v: -ratio(v, p, Qs[0]), x0, method="BFGS", options={"maxiter": 300})
        if not np.isfinite(r.fun):
            continue
        vals = [-r.fun] + [ratio(r.x, p, Q) for Q in Qs[1:]]
        if abs(vals[1] - vals[2]) <= 1e-3 * max(abs(vals[2]), 1e-9):
            stable.append(vals[-1])
    print(f"p = {p:.4f}: {len(stable)} stable optimisers, best stable log-ratio "
          f"{max(stable) if stable else float('nan'):+.3e} (> 0 would be a violation)", flush=True)
