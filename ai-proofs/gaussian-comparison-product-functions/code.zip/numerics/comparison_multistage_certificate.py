"""Exact certificate for the multi-stage path flow (Theorem 4.1 with grouped blocks, Remark 4.3 of
RESULT_gaussian_comparison_product_functions) in the example of Proposition 1.6:
S0 = [[1,1/4,0],[1/4,1,0],[0,0,1]], S1 = equicorrelated(1/2).

Stages: 'G' = blocks {1,2},{3}: c12 frozen on the stage, Dt has a 2x2 block on {1,2}; 'S' = scalar blocks, Dt diagonal.
Certificate: rational correlation matrices C_0 = S0, ..., C_N = S1, rational Dt_k per piece, rational step h_i per
stage, verified exactly (fractions.Fraction):
  all C_k positive definite with unit diagonal; on a 'G' stage C_{k+1}[1,2] = C_k[1,2];
  Dt_k >= 0 (diagonal entries, or the 2x2 block and the last entry), C_k - Dt_k >= 0, C_{k+1} - Dt_k >= 0,
  (C_{k+1} - C_k) + h_i Dt_k >= 0  (3x3 PSD by all principal minors).
On each piece C(s) - Dt_k is affine in s, so these give the hypotheses of Theorem 4.1 for the block structure of the
stage; chaining the stages gives the comparison inequality with p = e^{sum_i N_i h_i}, checked against P with Arb.
The SDP solver (cvxpy/CLARABEL, maximising a common slack) only proposes the data.
Usage: python3 comparison_multistage_certificate.py STAGES NPER FRACTIONS T P
  defaults: GS 32 0.4,0.6 7929/10000 221/100 (the certificate cited in the note)
"""
import sys
from fractions import Fraction as F
from itertools import combinations
import numpy as np
import cvxpy as cp
import flint

stages = list(sys.argv[1]) if len(sys.argv) > 1 else ["G", "S"]
nper = int(sys.argv[2]) if len(sys.argv) > 2 else 32
fr = [F(x).limit_denominator(1000) for x in (sys.argv[3].split(",") if len(sys.argv) > 3 else ["0.4", "0.6"])]
T = F(sys.argv[4]) if len(sys.argv) > 4 else F(7929, 10000)
P = F(sys.argv[5]) if len(sys.argv) > 5 else F(221, 100)
fr = [x / sum(fr) for x in fr]
Ts = [T * x for x in fr]
Ns = [nper] * len(stages)
hs = [Ti / Ni for Ti, Ni in zip(Ts, Ns)]
assert len(stages) == len(fr)

S1q = [[F(1), F(1, 2), F(1, 2)], [F(1, 2), F(1), F(1, 2)], [F(1, 2), F(1, 2), F(1)]]
S0q = [[F(1), F(1, 4), F(0)], [F(1, 4), F(1), F(0)], [F(0), F(0), F(1)]]


def det(M, idx):
    if len(idx) == 1:
        return M[idx[0]][idx[0]]
    if len(idx) == 2:
        i, j = idx
        return M[i][i] * M[j][j] - M[i][j] * M[j][i]
    i, j, k = idx
    return (M[i][i] * (M[j][j] * M[k][k] - M[j][k] * M[k][j]) - M[i][j] * (M[j][i] * M[k][k] - M[j][k] * M[k][i])
            + M[i][k] * (M[j][i] * M[k][j] - M[j][j] * M[k][i]))


def psd(M):
    n = len(M)
    return all(det(M, list(c)) >= 0 for r in range(1, n + 1) for c in combinations(range(n), r))


def pd(M):
    return all(det(M, list(range(r))) > 0 for r in range(1, len(M) + 1))


def lin(a, A, b, B):
    return [[a * A[i][j] + b * B[i][j] for j in range(3)] for i in range(3)]


S0 = np.array([[float(x) for x in r] for r in S0q])
S1 = np.array([[float(x) for x in r] for r in S1q])
Ntot = sum(Ns)
t = cp.Variable()
Cs = [cp.Constant(S0)] + [cp.Variable((3, 3), symmetric=True) for _ in range(Ntot - 1)] + [cp.Constant(S1)]
I = np.eye(3)
cons = [t <= 0.05]
for k in range(1, Ntot):
    cons += [cp.diag(Cs[k]) == 1, Cs[k] >> t * I]
Dvars, kinds, hk = [], [], []
k0 = 0
for kind, N, h in zip(stages, Ns, hs):
    hf = float(h)
    for k in range(k0, k0 + N):
        if kind == "G":
            A = cp.Variable((2, 2), symmetric=True)
            d3 = cp.Variable()
            Dk = cp.bmat([[A, np.zeros((2, 1))], [np.zeros((1, 2)), cp.reshape(d3, (1, 1), order="F")]])
            cons += [A >> t * np.eye(2), d3 >= t, Cs[k + 1][0, 1] == Cs[k][0, 1]]
        else:
            dv = cp.Variable(3)
            Dk = cp.diag(dv)
            cons += [dv >= t]
        cons += [Cs[k] - Dk >> t * I, Cs[k + 1] - Dk >> t * I, (Cs[k + 1] - Cs[k]) + hf * Dk >> t * hf * I]
        Dvars.append(Dk)
        kinds.append(kind)
        hk.append(h)
    k0 += N
prob = cp.Problem(cp.Maximize(t), cons)
prob.solve(solver="CLARABEL")
print(f"stages {''.join(stages)}, {nper} pieces each, stage lengths {[str(x) for x in Ts]} (T = {T}); SDP status "
      f"{prob.status}, common slack {t.value:.3e}")


def rat(x):
    return F(float(x)).limit_denominator(10 ** 9)


Cq = [S0q]
for k in range(1, Ntot):
    V = Cs[k].value
    Cq.append([[F(1) if i == j else rat(0.5 * (V[i][j] + V[j][i])) for j in range(3)] for i in range(3)])
Cq.append(S1q)
k0 = 0
for kind, N in zip(stages, Ns):
    if kind == "G":
        c = Cq[k0][0][1]
        for k in range(k0 + 1, k0 + N + 1):
            if k < Ntot:
                Cq[k][0][1] = Cq[k][1][0] = c
            else:
                assert Cq[k][0][1] == c, "a G stage at the end must start with c12 = 1/2"
    k0 += N
Dq = []
for k in range(Ntot):
    V = Dvars[k].value
    M = [[rat(0.5 * (V[i][j] + V[j][i])) for j in range(3)] for i in range(3)]
    if kinds[k] == "S":
        M = [[M[i][j] if i == j else F(0) for j in range(3)] for i in range(3)]
    else:
        M[0][2] = M[2][0] = M[1][2] = M[2][1] = F(0)
    Dq.append(M)

ok = True
nchk = 0
for k in range(Ntot + 1):
    ok &= pd(Cq[k]) and all(Cq[k][i][i] == 1 for i in range(3))
    nchk += 1
for k in range(Ntot):
    Dk = Dq[k]
    if kinds[k] == "G":
        ok &= psd([[Dk[0][0], Dk[0][1]], [Dk[1][0], Dk[1][1]]]) and Dk[2][2] >= 0 and Cq[k + 1][0][1] == Cq[k][0][1]
    else:
        ok &= all(Dk[i][i] >= 0 for i in range(3))
    ok &= psd(lin(1, Cq[k], -1, Dk)) and psd(lin(1, Cq[k + 1], -1, Dk))
    ok &= psd([[Cq[k + 1][i][j] - Cq[k][i][j] + hk[k] * Dk[i][j] for j in range(3)] for i in range(3)])
    nchk += 4
e = (flint.arb(T.numerator) / flint.arb(T.denominator)).exp()
bound_ok = bool(e < flint.arb(P.numerator) / flint.arb(P.denominator))
print(f"exact checks of all {nchk} conditions: {'PASSED' if ok else 'FAILED'}")
print(f"e^T = {e.str(10)} < {P} (Arb): {bound_ok}")
print(f"CERTIFIED: the comparison inequality holds in the example for every p >= {P}" if ok and bound_ok
      else "NOT CERTIFIED")
