"""Path version of the flow in RESULT_gaussian_comparison_product_functions (floating point search; the exact
certificate is produced by comparison_path_certificate.py).

Path flow: if C(s), s in [0, T], is a piecewise-C^1 path of covariances with identity diagonal blocks from Sigma_0 to
Sigma_1, and for each s some block-diagonal Dt(s) satisfies 0 <= Dt(s) <= C(s) and C'(s) + Dt(s) >= 0, then the
comparison inequality holds with p = e^T.  Discretisation used here (a restriction of the continuous problem):
C piecewise linear with N equal steps of length h = T/N, one diagonal D_k per step, and
    D_k >= 0,  C_k - D_k >= 0,  C_{k+1} - D_k >= 0,  (C_{k+1} - C_k) + h D_k >= 0.
For fixed T these are linear matrix inequalities, so feasibility is a semidefinite programme; bisection in T.
"""
import sys
import numpy as np
import cvxpy as cp


def feasible(S0, S1, T, N, solver="CLARABEL", ret=False):
    n = S0.shape[0]
    h = T / N
    Cs = [cp.Constant(S0)] + [cp.Variable((n, n), symmetric=True) for _ in range(N - 1)] + [cp.Constant(S1)]
    Ds = [cp.Variable(n, nonneg=True) for _ in range(N)]
    cons = []
    for k in range(1, N):
        cons += [cp.diag(Cs[k]) == 1, Cs[k] >> 0]
    for k in range(N):
        Dk = cp.diag(Ds[k])
        cons += [Cs[k] - Dk >> 0, Cs[k + 1] - Dk >> 0, (Cs[k + 1] - Cs[k]) + h * Dk >> 0]
    prob = cp.Problem(cp.Minimize(0), cons)
    try:
        prob.solve(solver=solver)
    except Exception:
        return (False, None) if ret else False
    ok = prob.status in ("optimal", "optimal_inaccurate") and prob.status == "optimal"
    if ret:
        return ok, ([S0] + [Cs[k].value for k in range(1, N)] + [S1], [d.value for d in Ds])
    return ok


def min_time(S0, S1, N, lo=0.0, hi=3.0, iters=30):
    if not feasible(S0, S1, hi, N):
        return np.inf
    for _ in range(iters):
        mid = (lo + hi) / 2
        if feasible(S0, S1, mid, N):
            hi = mid
        else:
            lo = mid
    return hi


def corr2(c):
    return np.array([[1.0, c], [c, 1.0]])


if __name__ == "__main__":
    print("n = 2 checks (continuous optimum: reverse c0 -> c1: log((1-c0)/(1-c1)); forward theta -> 0: log(1/(1-theta)))")
    for (c0, c1) in ((0.2, 0.6), (0.0, 0.5), (0.5, 0.0), (0.7, 0.0)):
        for N in (8, 32):
            T = min_time(corr2(c0), corr2(c1), N)
            exact = np.log((1 - c0) / (1 - c1)) if c1 >= c0 else np.log(1 / (1 - c0))
            print(f"  c0={c0}, c1={c1}, N={N}: p = e^T = {np.exp(T):.5f}   (continuous: {np.exp(exact):.5f})")
    S1 = np.full((3, 3), 0.5) + 0.5 * np.eye(3)
    S0 = np.array([[1, 0.25, 0], [0.25, 1, 0], [0, 0, 1.0]])
    ps = (11 + np.sqrt(41)) / 8
    print(f"example of Proposition 1.6: p* = {ps:.5f}, two-step bound 2.5, constant-D segment 3")
    for N in (4, 8, 16, 32, 64):
        T = min_time(S0, S1, N)
        print(f"  N={N}: smallest p = e^T with a feasible discretised path: {np.exp(T):.5f}")
        sys.stdout.flush()
