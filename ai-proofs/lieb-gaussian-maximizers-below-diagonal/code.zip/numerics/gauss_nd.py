"""Closed-form ratio ||T_z f||_q / ||f||_p for Gaussian f(x) = exp(x^T B x / 2 + g^T x) on (R^d, gamma_d).

B complex symmetric (d x d), g in C^d.  With S = I - (1 - z^2) B:
  T_z f = det(S)^{-1/2} exp( x^T B' x / 2 + g'^T x + C ),
  B' = z^2 B S^{-1},  g' = z S^{-1} g,  C = (1-z^2)/2 g^T S^{-1} g.
For Re A < 1/s (as matrices),
  log || exp(x^T A x/2 + h^T x + c) ||_s = Re c - (1/(2s)) log det(I - s Re A)
                                           + (s/2) Re h^T (I - s Re A)^{-1} Re h.
p = inf:  ||f||_inf = exp( -(1/2) Re g^T (Re B)^{-1} Re g ) if Re B < 0, and = 1 if Re B = 0, Re g = 0.
For fixed B the log-ratio is c(B) + Q_B(g), Q_B a real quadratic form in (Re g, Im g).
"""
import numpy as np


def _logdet_pd(M):
    sign, ld = np.linalg.slogdet(M)
    if sign <= 0:
        return None
    return ld


def ratio_parts(B, z, p, q):
    """Return (c(B), Q_B matrix of size 2d x 2d) or None if T_z f not in L^q or f not in L^p."""
    B = np.atleast_2d(np.asarray(B, dtype=complex))
    d = B.shape[0]
    I = np.eye(d)
    S = I - (1 - z * z) * B
    Sinv = np.linalg.inv(S)
    Bp = z * z * B @ Sinv
    Bp = 0.5 * (Bp + Bp.T)
    Mq = I - q * Bp.real
    ldq = _logdet_pd(Mq)
    if ldq is None:
        return None
    if np.isinf(p):
        ev = np.linalg.eigvalsh(B.real)
        if ev.max() > 1e-15:
            return None
        ldp = 0.0
    else:
        Mp = I - p * B.real
        ldp = _logdet_pd(Mp)
        if ldp is None:
            return None
    sign, ldS = np.linalg.slogdet(S)
    c = -0.5 * ldS.real - ldq / (2 * q) + (0.0 if np.isinf(p) else ldp / (2 * p))
    # quadratic form in G = (Re g, Im g) in R^{2d}
    # Re C = Re[(1-z^2)/2 g^T Sinv g]
    A = (1 - z * z) / 2 * Sinv
    A = 0.5 * (A + A.T)
    # for complex symmetric A, Re(g^T A g) with g = u + i v:
    # = u^T Re A u - v^T Re A v - 2 u^T Im A v
    Q = np.zeros((2 * d, 2 * d))
    Q[:d, :d] += A.real
    Q[d:, d:] -= A.real
    Q[:d, d:] -= A.imag
    Q[d:, :d] -= A.imag.T
    # Re g' = Re(z Sinv g) = Re(K) u - Im(K) v
    K = z * Sinv
    L = np.hstack([K.real, -K.imag])  # d x 2d
    Q += (q / 2) * L.T @ np.linalg.inv(Mq) @ L
    if np.isinf(p):
        Rb = B.real
        if np.abs(Rb).max() < 1e-15:
            # chirp: need Re g = 0 for finiteness; restrict to v-block
            Q = Q[d:, d:]
        else:
            # ||f||_inf: subtract -(1/2) u^T (Re B)^{-1} u  (Re B < 0 so this is >= 0)
            Q[:d, :d] -= -0.5 * np.linalg.inv(Rb)
    else:
        Mp = I - p * B.real
        Q[:d, :d] -= (p / 2) * np.linalg.inv(Mp)
    Q = 0.5 * (Q + Q.T)
    return c, Q


def worst(B, z, p, q):
    """max(c(B), lambda_max(Q_B)) style violation score: >0 means a Gaussian violates contractivity."""
    r = ratio_parts(B, z, p, q)
    if r is None:
        return np.inf
    c, Q = r
    lam = np.linalg.eigvalsh(Q).max()
    if lam > 1e-12:
        return np.inf if lam > 1e-9 else lam
    return c


def log_ratio_full(B, g, z, p, q):
    r = ratio_parts(B, z, p, q)
    if r is None:
        return np.inf
    c, Q = r
    B = np.atleast_2d(np.asarray(B, dtype=complex))
    g = np.atleast_1d(np.asarray(g, dtype=complex))
    d = B.shape[0]
    G = np.concatenate([g.real, g.imag])
    if np.isinf(p) and np.abs(B.real).max() < 1e-15:
        if np.abs(g.real).max() > 0:
            return -np.inf
        G = g.imag
    return c + G @ Q @ G
