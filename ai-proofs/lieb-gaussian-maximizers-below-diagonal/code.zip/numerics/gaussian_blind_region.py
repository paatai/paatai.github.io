"""Where do Gaussians fail to detect non-contractivity below the diagonal?  (exploratory, floating point)

For q < p, Theorem A gives ||T_z||_{L^p -> L^q} > 1 for z outside Omega_{s,s} (s = q for q >= 2).  Gaussians
g = C exp(beta x^2/2 + eta x), Re beta < 1/p, satisfy ||T_z g||_q <= ||g||_p for all such g iff
  (centred)      c(beta; p) = -1/2 log|D| - 1/(2q) log m + 1/(2p) log n <= 0  for all admissible beta, and
  (non-centred)  Q_beta <= 0 for all admissible beta, which by the identities of
                 RESULT_lieb_gaussian_maximizers_below_diagonal (Lemma 3.1; valid for all z, p, q) holds iff
                 kappa_D = p c0 - alpha0 >= 0 (given alpha0 > 0 and N > 0 on the half-plane, T >= q|z|^2 kappa_D/alpha0).
Here D = 1 - s beta, m = 1 - q Re(z^2 beta / D), n = 1 - p Re beta, s = 1 - z^2, c0 = Re s - q (Im z)^2,
alpha0 = q Re s - (q-1)|s|^2, N = |D|^2 m.  On a set where both hold and z is outside Omega_{q,q}, Lieb's
"norm = sup over Gaussians" fails.  This script maps that set along rays (q = 4).
"""
import numpy as np
from scipy.optimize import minimize


def c_beta(z, beta, p, q):
    s = 1 - z * z
    D = 1 - s * beta
    m = 1 - q * (z * z * beta / D).real
    n = 1 - p * beta.real
    if n <= 0:
        return -np.inf
    if m <= 0:
        return np.inf
    return -0.5 * np.log(abs(D)) - np.log(m) / (2 * q) + np.log(n) / (2 * p)


def noncentred_ok(z, p, q):
    s = 1 - z * z
    c0 = s.real - q * z.imag ** 2
    al = q * s.real - (q - 1) * abs(s) ** 2
    kap = p * c0 - al
    om = q + (2 - q) * s
    # N(x, y) = 1 - Re(om beta) + al |beta|^2 must be > 0 on x < 1/p
    if al <= 0:
        return False, kap, al, None
    x0, y0 = om.real / (2 * al), -om.imag / (2 * al)
    x = min(x0, 1 / p)
    y = y0
    Nmin = 1 - (om.real * x - om.imag * y) + al * (x * x + y * y)
    return (kap >= 0 and Nmin > 0), kap, al, Nmin


def centred_sup(z, p, q, rng, starts=40):
    best = -np.inf
    f = lambda v: -c_beta(z, complex(1 / p - np.exp(v[0]), v[1]), p, q)
    for _ in range(starts):
        v0 = np.array([rng.uniform(-8, 6), rng.normal() * 3])
        val = f(v0)
        if not np.isfinite(val):
            if val == -np.inf:
                return np.inf
            continue
        res = minimize(f, v0, method="Nelder-Mead", options={"maxiter": 3000, "xatol": 1e-12, "fatol": 1e-15})
        if np.isfinite(res.fun):
            best = max(best, -res.fun)
    # large |beta| along rays (c tends to a limit there)
    for th in np.linspace(np.pi / 2 + 1e-3, 3 * np.pi / 2 - 1e-3, 721):
        for R in (1e2, 1e4, 1e6, 1e8):
            best = max(best, c_beta(z, R * np.exp(1j * th), p, q))
    return best


def omega_radius(q, alpha):
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = (lo + hi) / 2
        z = mid * np.exp(1j * alpha)
        ok = (q - 2) * abs(1 - z * z) <= q * (1 - abs(z) ** 2)
        lo, hi = (mid, hi) if ok else (lo, mid)
    return lo


def contraction_radius(q, p, alpha):
    """radius of Omega_{s,s}, s = min(p, max(q, 2)), via (|s-2|)|Im z| <= sqrt(s-1)(1-|z|^2)."""
    s = min(p, max(q, 2.0))
    a = abs(s - 2) * np.sin(alpha)
    c = np.sqrt(s - 1)
    return (-a + np.sqrt(a * a + 4 * c * c)) / (2 * c)


if __name__ == "__main__":
    rng = np.random.default_rng(0)
    q = 4.0
    for p in (8.0, 16.0, 64.0):
        print(f"q={q}, p={p}")
        print("  arg z   r(Omega_4)   r_G (first radius where some Gaussian violates; scan step 0.002)")
        for alpha in (0.3, 0.5, 0.7, 0.9, 1.1, 1.3):
            r0 = omega_radius(q, alpha)
            rG = None
            for rr in np.arange(r0 - 0.01, 0.999, 0.002):
                z = rr * np.exp(1j * alpha)
                ok_nc, kap, al, Nmin = noncentred_ok(z, p, q)
                cs = centred_sup(z, p, q, rng, starts=12)
                if not ok_nc or cs > 1e-12:
                    rG = (rr, "non-centred" if not ok_nc else f"centred sup={cs:.2e}")
                    break
            print(f"  {alpha:5.2f}   {r0:.5f}      {rG}", flush=True)
    print("\nOther exponents (scan step 0.0005 from just inside the boundary of Omega_{s,s}):")
    for (q, p) in [(4.0, 4.5), (4.0, 5.0), (3.0, 4.0), (3.0, 6.0), (1.5, 1.8), (1.2, 1.8), (1.3, 1.6)]:
        print(f"q={q}, p={p}, s={min(p, max(q, 2.0))}")
        for alpha in (0.3, 0.7, 1.1):
            r0 = contraction_radius(q, p, alpha)
            rG = None
            for rr in np.arange(r0 - 0.004, 0.999, 0.0005):
                z = rr * np.exp(1j * alpha)
                ok_nc, kap, al, Nmin = noncentred_ok(z, p, q)
                cs = centred_sup(z, p, q, rng, starts=10)
                if not ok_nc or cs > 1e-12:
                    rG = (round(rr, 5), "non-centred" if not ok_nc else f"centred sup={cs:.1e}")
                    break
            print(f"  arg {alpha}: r(Omega_s) = {r0:.5f}, first Gaussian violation at {rG}", flush=True)
