"""Wide-range scan of the 1D Gaussian family exp(beta x^2/2 + gamma x) for violations of ||T_z f||_q <= ||f||_p.
beta = 1/p - e^u + i v with u in [umin, umax] (so Re beta from ~1/p down to -e^{umax}) and v = +-sinh(w).
For each beta the violation score is max(c(beta), lambda_max(Q_beta)) (inf if T_z f not in L^q).
Addresses the referee remark that the earlier grids capped |beta| at about 20."""
import sys
import numpy as np
from gauss_nd import ratio_parts


def score(beta, z, p, q):
    r = ratio_parts([[beta]], z, p, q)
    if r is None:
        return np.inf
    c, Q = r
    return max(c, np.linalg.eigvalsh(Q).max())


def scan(z, p, q, umin=-25, umax=20, wmax=14, nu=1400, nw=1400):
    best, arg = -np.inf, None
    us = np.linspace(umin, umax, nu)
    ws = np.linspace(-wmax, wmax, nw)
    top = 1.0 / p
    for u in us:
        for w in ws:
            b = top - np.exp(u) + 1j * np.sinh(w)
            s = score(b, z, p, q)
            if s > best:
                best, arg = s, b
    return best, arg


if __name__ == "__main__":
    cases = [((6.0, 3.0), 0.825 * np.exp(0.6j)), ((16.0, 4.0), 0.72 * np.exp(0.7j)), ((64.0, 4.0), 0.72 * np.exp(0.7j)),
             ((8.0, 4.0), 0.705 * np.exp(0.7j))]
    for (p, q), z in cases:
        best, arg = scan(z, p, q)
        print(f"(p,q)=({p},{q}) z={abs(z):.4f}e^(i{np.angle(z):.3f}): max violation score = {best:+.3e} at beta = {arg:.6g}", flush=True)
