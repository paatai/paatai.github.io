"""Rigorous certificate (Arb) for part (a) of Theorem D:
for q = 4, z = 0.72 e^{0.7 i} and p = 16, every CENTERED Gaussian g = exp(beta x^2/2) (Re beta < 1/p) satisfies
      ||T_z g||_{L^q(gamma)} <= ||g||_{L^p(gamma)},
with equality only for beta = 0.  Since c(beta; p) is nonincreasing in p and the admissible half-plane shrinks
with p, the same holds for every p >= 16.

log-ratio:  c(beta) = -1/2 log|1 - s beta| - 1/(2q) log(1 - q Re beta') + 1/(2p) log(1 - p Re beta),
            s = 1 - z^2,  beta' = z^2 beta / (1 - s beta).
Steps:
 (1) m0 := inf_{Re beta < 1/p} (1 - q Re beta') > 0  via the Moebius image of the half-plane (a disc).
 (2) near 0 (|beta| <= rho0): c <= c2(beta) + K |beta|^3 with explicit K, c2 = (1/4)(|z^2 beta|_q^2 - |beta|_p^2)
     negative definite.
 (3) compact region rho0 <= |beta|, |Re beta|,|Im beta| <= R0, Re beta <= 1/p - eps: adaptive Arb boxes.
 (4) boundary strip 1/p - eps <= Re beta < 1/p, |Im beta| <= R0: the last term is <= (1/(2p)) log(p eps).
 (5) |beta| >= R0 (outside the square): explicit decreasing bound.
"""
import sys
from flint import arb, acb, ctx

ctx.prec = 100
q = arb(4)
p = arb(16)
r, th = arb("0.72"), arb("0.7")
z = acb(r * th.cos(), r * th.sin())
s = 1 - z * z
z2 = z * z


def absq(w):
    return w.real ** 2 + w.imag ** 2


# ---------- (1) Moebius image disc ----------
def mu(beta):
    return z2 * beta / (1 - s * beta)


def circumcircle(a, b, c):
    # center of circle through three complex points
    ax, ay, bx, by, cx, cy = a.real, a.imag, b.real, b.imag, c.real, c.imag
    d = 2 * (ax * (by - cy) + bx * (cy - ay) + cx * (ay - by))
    ux = ((ax * ax + ay * ay) * (by - cy) + (bx * bx + by * by) * (cy - ay) + (cx * cx + cy * cy) * (ay - by)) / d
    uy = ((ax * ax + ay * ay) * (cx - bx) + (bx * bx + by * by) * (ax - cx) + (cx * cx + cy * cy) * (bx - ax)) / d
    cen = acb(ux, uy)
    return cen, absq(a - cen).sqrt()


pole = 1 / s
print("pole 1/s has Re =", pole.real, " > 1/p:", pole.real > 1 / p)
P1, P2, P3 = mu(acb(1 / p, 0)), mu(acb(1 / p, 1)), mu(acb(1 / p, -1))
cen, rad = circumcircle(P1, P2, P3)
inside0 = absq(mu(acb(0)) - cen).sqrt() < rad
print("image disc: center", cen, "radius", rad, " contains mu(0)=0:", inside0)
maxRe = cen.real + rad
m0 = 1 - q * maxRe
print("(1) sup Re beta' <=", maxRe.upper(), "  m0 = inf(1 - q Re beta') >=", m0.lower(), " >0:", m0 > 0)
assert m0 > 0 and inside0


# ---------- c(beta) on boxes ----------
def c_val(b):
    D = 1 - s * b
    t1 = -absq(D).log() / 4
    arg2 = 1 - q * (z2 * b / D).real
    arg3 = 1 - p * b.real
    if not (arg2 > 0 and arg3 > 0):
        return None
    return t1 - arg2.log() / (2 * q) + arg3.log() / (2 * p)


def grad_box(b):
    """(dc/dx, dc/dy) enclosures on the box b (Wirtinger calculus, see docstring of step (3))."""
    D = 1 - s * b
    F1 = s / (2 * D)                      # derivative of -1/2 log(1 - s beta)
    bpp = z2 / (D * D)                    # d beta'/d beta
    arg2 = 1 - q * (z2 * b / D).real
    arg3 = 1 - p * b.real
    gx = F1.real + bpp.real / (2 * arg2) - 1 / (2 * arg3)
    gy = -F1.imag - bpp.imag / (2 * arg2)
    return gx, gy


def c_box(xlo, xhi, ylo, yhi):
    X = arb((xlo + xhi) / 2, (xhi - xlo) / 2)
    Y = arb((ylo + yhi) / 2, (yhi - ylo) / 2)
    b = acb(X, Y)
    plain = c_val(b)
    if plain is None:
        return None
    # mean-value form around the centre
    cm = c_val(acb(arb((xlo + xhi) / 2), arb((ylo + yhi) / 2)))
    gx, gy = grad_box(b)
    hx, hy = arb((xhi - xlo) / 2), arb((yhi - ylo) / 2)
    mv = cm + gx * arb(0, 1) * hx + gy * arb(0, 1) * hy
    return plain if plain.upper() < mv.upper() else mv


# ---------- (2) near zero ----------
rho0 = arb(sys.argv[1]) if len(sys.argv) > 1 else arb("0.03")
# second-order form c2(w) = 1/4 [ (q-1)(Re z2 w)^2 + (Im z2 w)^2 - (p-1)(Re w)^2 - (Im w)^2 ] as 2x2 matrix in (Re w, Im w)
zr, zi = z2.real, z2.imag
# Re(z2 w) = zr a - zi b ; Im(z2 w) = zi a + zr b
M11 = ((q - 1) * zr * zr + zi * zi - (p - 1)) / 4
M22 = ((q - 1) * zi * zi + zr * zr - 1) / 4
M12 = (-(q - 1) * zr * zi + zi * zr) / 4
tr, det = M11 + M22, M11 * M22 - M12 * M12
lam_max = tr / 2 + ((tr / 2) ** 2 - det).sqrt()
print("(2) lambda_max(c2) =", lam_max)
rho = rho0
u0 = abs(s) * rho
assert u0 < arb(1) / 2
E1 = (u0 ** 3) / (6 * (1 - u0))
t0 = abs(z2) * rho / (1 - u0)
assert q * t0 < arb(1) / 2
a1 = abs(z2) * rho
E2 = abs(z2) * rho * u0 ** 2 / (1 - u0)
a2 = abs(z2) * abs(s) * rho ** 2
E3 = (q * t0) ** 3 / (6 * q * (1 - q * t0))
E4 = E2 / 2 + (q / 4) * ((a2 + E2) ** 2 + 2 * a1 * (a2 + E2))
x0 = rho
assert p * x0 < arb(1) / 2
E5 = (p * x0) ** 3 / (6 * p * (1 - p * x0))
Rtot = E1 + E3 + E4 + E5
K = Rtot / rho ** 3
print("    remainder bound on |beta|<=rho0:", Rtot, "  K =", K)
near_ok = lam_max * rho ** 2 + Rtot < 0
# c(beta) <= lam_max |beta|^2 + K |beta|^3 <= |beta|^2 (lam_max + K rho0) for |beta| <= rho0
print("    lam_max + K rho0 =", lam_max + K * rho0, " < 0:", (lam_max + K * rho0) < 0)
assert (lam_max + K * rho0) < 0
# consistency check of the second-order identity at a random point
bt = acb("0.013", "-0.021")
lhs2 = (s * s * bt * bt).real / 4 + (z2 * s * bt * bt).real / 2 + q * ((z2 * bt).real) ** 2 / 4 - p * (bt.real) ** 2 / 4
wv = z2 * bt
rhs2 = ((q - 1) * wv.real ** 2 + wv.imag ** 2 - (p - 1) * bt.real ** 2 - bt.imag ** 2) / 4
print("    identity check c2:", lhs2 - rhs2)

# ---------- (5) infinity ----------
R0 = arb(10)
L1 = -m0.log()
bound_inf = -(abs(s) * R0 - 1).log() / 2 + L1 / (2 * q) + (1 + p * R0).log() / (2 * p)
print("(5) bound for |beta| >= R0:", bound_inf, " < 0:", bound_inf < 0)
assert bound_inf < 0

# ---------- (4) boundary strip ----------
eps = arb("1e-12")
term3 = (p * eps).log() / (2 * p)
strip_max = None
ny = 400
for k in range(ny):
    ylo = -10 + 20 * k / ny
    yhi = -10 + 20 * (k + 1) / ny
    X = (1 / p - eps).union(1 / p)
    Y = arb((ylo + yhi) / 2, (yhi - ylo) / 2)
    b = acb(X, Y)
    D = 1 - s * b
    t12 = -absq(D).log() / 4 - (1 - q * (z2 * b / D).real).log() / (2 * q)
    strip_max = t12 if strip_max is None else arb(max(strip_max.upper(), t12.upper()))
print("(4) sup of first two terms on strip <=", strip_max.upper(), "; last term <=", term3, ";  total < 0:",
      (strip_max + term3) < 0)
assert (strip_max + term3) < 0

# ---------- (3) compact region: adaptive boxes ----------
xmin, xmax = -10.0, float((1 / p - eps).mid())
ymin, ymax = -10.0, 10.0
rho0f = float(rho0.mid())
stack = []
NX, NY = 40, 40
for i in range(NX):
    for j in range(NY):
        stack.append((xmin + (xmax - xmin) * i / NX, xmin + (xmax - xmin) * (i + 1) / NX,
                      ymin + (ymax - ymin) * j / NY, ymin + (ymax - ymin) * (j + 1) / NY, 0))
done = 0
worst = -1e9
maxdepth = 0
while stack:
    xlo, xhi, ylo, yhi, dep = stack.pop()
    # skip boxes entirely inside the disc |beta| < rho0 (handled by (2))
    fx = max(abs(xlo), abs(xhi)) if xlo * xhi > 0 or True else 0
    farx = max(abs(xlo), abs(xhi)); fary = max(abs(ylo), abs(yhi))
    if farx ** 2 + fary ** 2 < (0.999 * rho0f) ** 2:
        done += 1
        continue
    v = c_box(xlo, xhi, ylo, yhi)
    if v is not None and v < 0:
        done += 1
        worst = max(worst, float(v.upper()))
        maxdepth = max(maxdepth, dep)
        continue
    if dep > 60:
        print("FAILED to certify box", xlo, xhi, ylo, yhi, v)
        sys.exit(1)
    xm, ym = (xlo + xhi) / 2, (ylo + yhi) / 2
    stack += [(xlo, xm, ylo, ym, dep + 1), (xm, xhi, ylo, ym, dep + 1), (xlo, xm, ym, yhi, dep + 1), (xm, xhi, ym, yhi, dep + 1)]
print(f"(3) certified {done} boxes, max depth {maxdepth}, largest upper bound {worst:.3e} (< 0)")
print("ALL CHECKS PASSED: every centered Gaussian satisfies ||T_z g||_4 <= ||g||_16 at z = 0.72 e^{0.7i}.")
