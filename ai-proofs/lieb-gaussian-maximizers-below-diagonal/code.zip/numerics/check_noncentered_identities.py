"""Independent check (written separately from certify_noncentered_gaussians.py) of Lemma 3.1 of
RESULT_lieb_gaussian_maximizers_below_diagonal and of the closed form it rests on.

Notation (q and p symbolic): z = a0 + i b0, s = 1 - z^2, beta = x + i y, eta = u + i v, D = 1 - s beta,
  beta' = z^2 beta / D, m = 1 - q Re beta', n = 1 - p x,
  Q(eta) = 1/2 Re(s eta^2 / D) + (q/2) (Re(z eta / D))^2 / m - (p/2) u^2 / n,
  c0 = Re s - q b0^2, alpha0 = q Re s - (q-1)|s|^2, omega = q + (2-q) s, kappa = p c0 - alpha0,
  N = |D|^2 m = |D|^2 - q Re(z^2 beta conj(D)), T = p N - q |z|^2 n,
  G = [[q|z|^2 + c0 - alpha0 x, -(alpha0 y + (q-2) a0 b0)], [same, -(c0 - alpha0 x)]].

Part A (exact, polynomial arithmetic only; 1/D = conj(D)/|D|^2 and m = N/|D|^2 are substituted by hand):
  (i)   N = 1 - Re(omega beta) + alpha0 |beta|^2
  (ii)  N Re(s conj(D) eta^2) + q (Re(z eta conj(D)))^2 = |D|^2 G[eta]
        (this is 2N[1/2 Re(s eta^2/D) + (q/2)(Re(z eta/D))^2/m] = G[eta] after multiplying by |D|^2)
  (iii) det G = -alpha0 N,  tr G = q |z|^2
  (iv)  with M = G/(2N) - (p/(2n)) e1 e1^T:  4 n N^2 det M = kappa N  and  2 n N tr M = -T
  (v)   4 alpha0 - |omega - q|z|^2|^2 = 4 q |z|^2 c0, hence min over beta in C of T equals q |z|^2 kappa / alpha0
        when alpha0 > 0 (T = p - q|z|^2 + p alpha0 |beta|^2 - p Re((omega - q|z|^2) beta) is checked as well).
Part B (floating point, mpmath, 30 digits): the closed form of T_z g for g = exp(beta x^2/2 + eta x), the closed form
  of log(||T_z g||_q / ||g||_p) = c(beta; p) + Q(eta), and the literal Q against the matrix M, all against direct
  quadrature, at the paper's z = 0.72 e^{0.7 i}, q = 4, p = 16 and two non-centred Gaussians.
"""
import time

import mpmath as mp
import sympy as sp

t0 = time.time()
a0, b0, x, y, u, v, p, q = sp.symbols("a0 b0 x y u v p q", real=True)
E = sp.expand


def mul(w1, w2):
    return (E(w1[0] * w2[0] - w1[1] * w2[1]), E(w1[0] * w2[1] + w1[1] * w2[0]))


def conj(w):
    return (w[0], -w[1])


def add(*ws):
    return (E(sum(w[0] for w in ws)), E(sum(w[1] for w in ws)))


def scal(c, w):
    return (E(c * w[0]), E(c * w[1]))


def abs2(w):
    return E(w[0] ** 2 + w[1] ** 2)


one = (sp.Integer(1), sp.Integer(0))
z = (a0, b0)
beta = (x, y)
eta = (u, v)
z2 = mul(z, z)
s = add(one, scal(-1, z2))
D = add(one, scal(-1, mul(s, beta)))
cD = conj(D)
absD2 = abs2(D)
N = E(absD2 - q * mul(mul(z2, beta), cD)[0])
c0 = E(s[0] - q * b0 ** 2)
alpha0 = E(q * s[0] - (q - 1) * abs2(s))
omega = add((q, 0), scal(2 - q, s))
kappa = E(p * c0 - alpha0)
absz2 = E(a0 ** 2 + b0 ** 2)
n = E(1 - p * x)
T = E(p * N - q * absz2 * n)
G11 = E(q * absz2 + c0 - alpha0 * x)
G12 = E(-(alpha0 * y + (q - 2) * a0 * b0))
G22 = E(-(c0 - alpha0 * x))
Gform = E(G11 * u ** 2 + 2 * G12 * u * v + G22 * v ** 2)

results = {}
results["(i)   N = 1 - Re(omega beta) + alpha0|beta|^2"] = E(N - (1 - mul(omega, beta)[0] + alpha0 * abs2(beta))) == 0
lhs2 = E(N * mul(mul(s, cD), mul(eta, eta))[0] + q * mul(mul(z, eta), cD)[0] ** 2)
results["(ii)  N Re(s conjD eta^2) + q Re(z eta conjD)^2 = |D|^2 G[eta]"] = E(lhs2 - absD2 * Gform) == 0
results["(iii) det G = -alpha0 N"] = E(G11 * G22 - G12 ** 2 + alpha0 * N) == 0
results["(iii) tr G = q|z|^2"] = E(G11 + G22 - q * absz2) == 0
# M = G/(2N) - (p/(2n)) e1 e1^T; clear denominators: 4 n N^2 det M = n det G - p N G22
results["(iv)  4 n N^2 det M = kappa N"] = E(n * (G11 * G22 - G12 ** 2) - p * N * G22 - kappa * N) == 0
results["(iv)  2 n N tr M = -T"] = E(n * (G11 + G22) - p * N + T) == 0
w = add(omega, (-q * absz2, 0))
results["(v)   T = p - q|z|^2 + p alpha0|beta|^2 - p Re((omega - q|z|^2) beta)"] = (
    E(T - (p - q * absz2 + p * alpha0 * abs2(beta) - p * mul(w, beta)[0])) == 0)
results["(v)   4 alpha0 - |omega - q|z|^2|^2 = 4 q |z|^2 c0"] = E(4 * alpha0 - abs2(w) - 4 * q * absz2 * c0) == 0
# minimiser of the convex quadratic T (alpha0 > 0): beta* = conj(omega - q|z|^2) / (2 alpha0)
xs, ys = w[0] / (2 * alpha0), -w[1] / (2 * alpha0)
Tmin = sp.together(T.subs({x: xs, y: ys}, simultaneous=True))
results["(v)   T(beta*) * alpha0 = q|z|^2 kappa"] = E(sp.numer(sp.together(Tmin * alpha0 - q * absz2 * kappa))) == 0
results["(v)   grad T(beta*) = 0"] = all(
    E(sp.numer(sp.together(sp.diff(T, var).subs({x: xs, y: ys}, simultaneous=True)))) == 0 for var in (x, y))

print("Part A: exact polynomial identities (all variables symbolic)")
for k, val in results.items():
    print(f"  {k:72s} {val}")
okA = all(results.values())
print(f"  Part A {'PASSED' if okA else 'FAILED'} in {time.time() - t0:.1f} s")

# Part B: floating-point cross-checks against direct quadrature
mp.mp.dps = 30
zc = mp.mpf("0.72") * mp.expj(mp.mpf("0.7"))
sc = 1 - zc ** 2
qn, pn = 4, 16


def mehler_quad(g, xx):
    """T_z g(x) = int K_z(x, y) g(y) dgamma(y), K_z = s^{-1/2} exp(-(z^2(x^2+y^2) - 2 z x y)/(2 s))."""
    f = lambda yy: (mp.exp(-(zc ** 2 * (xx ** 2 + yy ** 2) - 2 * zc * xx * yy) / (2 * sc)) * g(yy)
                    * mp.exp(-yy ** 2 / 2) / mp.sqrt(2 * mp.pi))
    return mp.quad(f, [-mp.inf, -10, 0, 10, mp.inf]) / mp.sqrt(sc)


def closed_T(bc, ec, xx):
    Dc = 1 - sc * bc
    return Dc ** (-0.5) * mp.exp(zc ** 2 * bc / Dc * xx ** 2 / 2 + zc * ec / Dc * xx + sc * ec ** 2 / (2 * Dc))


def Qform(bc, ec):
    Dc = 1 - sc * bc
    mc = 1 - qn * mp.re(zc ** 2 * bc / Dc)
    nc = 1 - pn * mp.re(bc)
    return (mp.re(sc / Dc * ec ** 2) / 2 + qn / 2 * mp.re(zc * ec / Dc) ** 2 / mc
            - pn / 2 * mp.re(ec) ** 2 / nc)


def c_beta(bc):
    Dc = 1 - sc * bc
    mc = 1 - qn * mp.re(zc ** 2 * bc / Dc)
    nc = 1 - pn * mp.re(bc)
    return -mp.log(abs(Dc)) / 2 - mp.log(mc) / (2 * qn) + mp.log(nc) / (2 * pn)


def Mmatrix(bc):
    """matrix of Q via G/(2N) - (p/(2n)) e1 e1^T, numerically."""
    a, b = mp.re(zc), mp.im(zc)
    xx, yy = mp.re(bc), mp.im(bc)
    c0n = mp.re(sc) - qn * b ** 2
    al = qn * mp.re(sc) - (qn - 1) * abs(sc) ** 2
    Dc = 1 - sc * bc
    Nn = abs(Dc) ** 2 - qn * mp.re(zc ** 2 * bc * mp.conj(Dc))
    nn = 1 - pn * xx
    g11 = qn * abs(zc) ** 2 + c0n - al * xx
    g12 = -(al * yy + (qn - 2) * a * b)
    g22 = -(c0n - al * xx)
    return (g11 / (2 * Nn) - pn / (2 * nn), g12 / (2 * Nn), g22 / (2 * Nn), Nn, nn, al, c0n)


print("Part B: floating-point cross-checks (mpmath, 30 digits)")
okB = True
for bc, ec in [(mp.mpc("0.03", "0.2"), mp.mpc("0.4", "-0.3")), (mp.mpc("-0.5", "-1.1"), mp.mpc("-0.7", "0.9"))]:
    g = lambda yy, bc=bc, ec=ec: mp.exp(bc * yy ** 2 / 2 + ec * yy)
    err_T = max(abs(mehler_quad(g, xx) / closed_T(bc, ec, xx) - 1) for xx in (mp.mpf("-1.3"), mp.mpf("0.4"), mp.mpf(2)))
    # ||T_z g||_q^q by quadrature of the closed form, ||g||_p^p by quadrature
    phi = lambda xx: mp.exp(-xx ** 2 / 2) / mp.sqrt(2 * mp.pi)
    nq = mp.quad(lambda xx: abs(closed_T(bc, ec, xx)) ** qn * phi(xx), [-mp.inf, -10, 0, 10, mp.inf])
    np_ = mp.quad(lambda xx: abs(g(xx)) ** pn * phi(xx), [-mp.inf, -10, 0, 10, mp.inf])
    lr_quad = mp.log(nq) / qn - mp.log(np_) / pn
    lr_closed = c_beta(bc) + Qform(bc, ec)
    m11, m12, m22, Nn, nn, al, c0n = Mmatrix(bc)
    uu, vv = mp.re(ec), mp.im(ec)
    err_M = abs(Qform(bc, ec) - (m11 * uu ** 2 + 2 * m12 * uu * vv + m22 * vv ** 2))
    kap = pn * c0n - al
    Tn = pn * Nn - qn * abs(zc) ** 2 * nn
    err_det = abs((m11 * m22 - m12 ** 2) - kap / (4 * nn * Nn))
    err_tr = abs((m11 + m22) + Tn / (2 * nn * Nn))
    ok = err_T < 1e-20 and abs(lr_quad - lr_closed) < 1e-20 and err_M < 1e-25 and err_det < 1e-25 and err_tr < 1e-25
    okB = okB and ok
    print(f"  beta={mp.nstr(bc, 4)}, eta={mp.nstr(ec, 4)}: Mehler closed form rel.err {mp.nstr(err_T, 3)}; "
          f"log-ratio quad {mp.nstr(lr_quad, 12)} vs closed {mp.nstr(lr_closed, 12)}; "
          f"Q vs M {mp.nstr(err_M, 3)}; det {mp.nstr(err_det, 3)}; tr {mp.nstr(err_tr, 3)}  {'ok' if ok else 'FAIL'}")
print(f"  Part B {'PASSED' if okB else 'FAILED'}")

print("Part C: the numbers quoted in Section 3.3 of the paper (z = 0.72 e^{0.7i}, q = 4, p = 16), recomputed")
mp.mp.dps = 40
zc = mp.mpf(18) / 25 * mp.expj(mp.mpf(7) / 10)
sc = 1 - zc ** 2
c0n = mp.re(sc) - qn * mp.im(zc) ** 2
al = qn * mp.re(sc) - (qn - 1) * abs(sc) ** 2
om = qn + (2 - qn) * sc
kap = pn * c0n - al
Nmin = 1 - mp.re(om) / pn + al / pn ** 2 - mp.im(om) ** 2 / (4 * al)
Tmin = qn * abs(zc) ** 2 * kap / al
quoted = {"alpha0": (al, "0.370006"), "c0": (c0n, "0.051310"), "kappa": (kap, "0.450969"),
          "N_min = N(1/16, y*)": (Nmin, "0.160105"), "T_min": (Tmin, "2.527335")}
okC = True
for k, (val, txt) in quoted.items():
    ok = mp.nstr(val, 12).startswith(txt)
    okC = okC and ok
    print(f"  {k:22s} = {mp.nstr(val, 15):20s} quoted {txt}...  {'ok' if ok else 'MISMATCH'}")
slope = -mp.re(om) + al / 8
okC = okC and slope < 0
print(f"  -Re(omega) + alpha0/8 = {mp.nstr(slope, 10)} < 0 (so N decreases in x on Re beta <= 1/16)  {slope < 0}")
print(f"  Part C {'PASSED' if okC else 'FAILED'}")
print(f"total time {time.time() - t0:.1f} s")
assert okA and okB and okC
print("ALL CHECKS PASSED")
