"""Lieb note, Theorem 1.1 point (q = 4, z = 0.72 e^{0.7i}): for which p do Gaussians stay below 1?
Floating point (exploratory).  For each p: the largest centred-Gaussian log-ratio c(beta) found by
gaussian_blind_region.centred_sup, and the non-centred criterion (kappa_D >= 0, N > 0) of the same script.
The certified statement (p >= 16) is in certify_centered_gaussians.py / certify_noncentered_gaussians.py."""
import numpy as np

from gaussian_blind_region import centred_sup, noncentred_ok

if __name__ == "__main__":
    q, z = 4.0, 0.72 * np.exp(0.7j)
    print(f"q = {q}, z = 0.72 e^(0.7i)")
    print("    p    max centred log-ratio   non-centred ok?   kappa_D")
    for p in (6.0, 8.0, 10.0, 12.0, 13.0, 14.0, 15.0, 16.0, 20.0, 64.0):
        rng = np.random.default_rng(0)
        cs = centred_sup(z, p, q, rng, starts=60)
        ok, kap, al, Nmin = noncentred_ok(z, p, q)
        print(f"  {p:5.1f}   {cs:+.4e}             {ok}             {kap:+.4e}", flush=True)
