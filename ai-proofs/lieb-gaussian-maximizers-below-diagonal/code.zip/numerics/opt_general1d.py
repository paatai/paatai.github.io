"""Maximize ||T_z f||_{L^q(gamma)} / ||f||_{L^p(gamma)} over general 1D functions f on a grid.

T_z f(x) = int K_z(x,y) f(y) dgamma(y),  K_z = (1-z^2)^{-1/2} exp(-(z^2(x^2+y^2) - 2 z x y)/(2(1-z^2))).
Discretization: trapezoid on [-L, L] for both x and y (Gaussian weights make this accurate).
p = inf: optimize over unimodular f = exp(i phi) (extreme points of the L^inf ball).
Finite p: optimize over f = exp(u + i phi) (u, phi real vectors).
Exact gradients, L-BFGS, multiple starts (random + chirp seeds).
"""
import sys
import numpy as np
from scipy.optimize import minimize


class Problem:
    def __init__(self, z, p, q, L=13.0, N=2601):
        self.z, self.p, self.q = z, p, q
        x = np.linspace(-L, L, N)
        h = x[1] - x[0]
        self.x = x
        self.w = np.exp(-x * x / 2) / np.sqrt(2 * np.pi) * h  # gamma-weights
        s2 = 1 - z * z
        X, Y = np.meshgrid(x, x, indexing="ij")
        self.K = np.exp(-(z * z * (X * X + Y * Y) - 2 * z * X * Y) / (2 * s2)) / np.sqrt(s2)
        self.Kw = self.K * self.w[None, :]

    def apply(self, f):
        return self.Kw @ f

    def logratio_and_grad(self, params):
        p, q, w = self.p, self.q, self.w
        N = len(self.x)
        if np.isinf(p):
            phi = params
            u = np.zeros(N)
        else:
            u, phi = params[:N], params[N:]
        f = np.exp(u + 1j * phi)
        g = self.Kw @ f
        ag = np.abs(g)
        Jq = np.sum(w * ag ** q)
        lq = np.log(Jq) / q
        # d lq / d f-components: dJq = sum_i w_i q |g_i|^{q-2} Re(conj(g_i) dg_i)
        hvec = w * ag ** (q - 2) * np.conj(g)          # length N (x-index)
        Kt_h = self.Kw.T @ hvec                         # sum_i Kw_ij h_i
        # df_j/dphi_j = i f_j ; df_j/du_j = f_j
        dphi = q * np.real(1j * f * Kt_h) / (q * Jq)
        if np.isinf(p):
            return lq, dphi
        Jp = np.sum(w * np.exp(p * u))
        lp = np.log(Jp) / p
        du = np.real(f * Kt_h) / Jq - w * np.exp(p * u) / Jp
        return lq - lp, np.concatenate([du, dphi])


def optimize(prob, n_starts=20, seed=0, maxiter=3000, verbose=False):
    rng = np.random.default_rng(seed)
    N = len(prob.x)
    x = prob.x
    best, bestp = -np.inf, None

    def fun(pr):
        v, g = prob.logratio_and_grad(pr)
        return -v, -g

    for k in range(n_starts):
        kind = k % 4
        sig = rng.normal(0, 1.5)
        lam = rng.normal(0, 1.0)
        if kind == 0:
            phi0 = sig * x * x / 2 + lam * x
        elif kind == 1:
            phi0 = sig * x * x / 2 + rng.normal(0, 0.3) * x ** 3 / 6
        elif kind == 2:
            phi0 = rng.normal(0, 1.0) * np.sin(rng.uniform(0.2, 2) * x) + sig * x * x / 2
        else:
            # random smooth phase
            c = rng.normal(0, 1, 8) / (1 + np.arange(8)) ** 2
            phi0 = sum(c[j] * np.cos((j + 1) * 0.4 * x + rng.uniform(0, 6)) * 3 for j in range(8))
        if np.isinf(prob.p):
            p0 = phi0
        else:
            top = 1.0 / prob.p
            b = rng.uniform(-0.3, top * 0.9)
            u0 = b * x * x / 2 + rng.normal(0, 0.3) * x
            p0 = np.concatenate([u0, phi0])
        res = minimize(fun, p0, jac=True, method="L-BFGS-B", options={"maxiter": maxiter, "gtol": 1e-10})
        v = -res.fun
        if verbose:
            print(f"   start {k} kind {kind}: {v:+.6e}", flush=True)
        if v > best:
            best, bestp = v, res.x
    return best, bestp


if __name__ == "__main__":
    p = float(sys.argv[1]); q = float(sys.argv[2]); th = float(sys.argv[3]); r = float(sys.argv[4])
    n_starts = int(sys.argv[5]) if len(sys.argv) > 5 else 16
    z = r * np.exp(1j * th)
    prob = Problem(z, p, q)
    best, bp = optimize(prob, n_starts=n_starts, verbose=True)
    print(f"p={p} q={q} z={r}e^(i{th}): best log-ratio over grid functions = {best:+.6e}")
    np.save(f"best_{p}_{q}_{th}_{r}.npy", bp)
