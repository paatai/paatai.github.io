"""Rigorous certificate (Arb ball arithmetic) for part (b) of Theorem D:

  f(y) = exp(-i lam (|y| - a)_+),  |f| = 1,  so ||f||_{L^p(gamma)} = 1 for every p in [1, inf];
  z = r e^{i th} with r = 0.72, th = 0.7, q = 4.
  CLAIM:  E_gamma |T_z f|^4 > 1,  hence ||T_z f||_4 > ||f||_p for every p.

Closed form (s = 1 - z^2, m = z x, Phi(w) = (1 + erf(w/sqrt2))/2, principal sqrt(s) with Re > 0):
  T_z f(x) = [Phi((a-m)/sqrt s) - Phi((-a-m)/sqrt s)]
           + e^{i lam a} e^{-i lam m - lam^2 s/2} [1 - Phi((a - m + i lam s)/sqrt s)]
           + e^{i lam a} e^{+i lam m - lam^2 s/2} Phi((-a - m - i lam s)/sqrt s).
For real x, |T_z f(x)|^4 = F(x)^2 G(x)^2 with G(x) = conj(F(conj x)), so the integrand
  H(x) = F(x)^2 G(x)^2 e^{-x^2/2}/sqrt(2 pi) is entire and Arb's rigorous integrator applies on [-L, L].
Tail: |T_z f(x)| <= int |k(x,y)| dy = (|s| A)^{-1/2} exp(x^2 (C^2/A - A + 1)/2), A = Re 1/s, C = Re z/s,
so the tail |x| > L contributes at most (|s|A)^{-2} int_{|x|>L} exp(-x^2 (1/2 - 2E)) dx/sqrt(2 pi),
E = C^2/A - A + 1 (needs E < 1/4), which is bounded with erfc.
"""
from flint import arb, acb, ctx

ctx.prec = 128

r, th = arb("0.72"), arb("0.7")
z = acb(r * th.cos(), r * th.sin())
a = arb("2.776")
lam = arb("5.115")
s = 1 - z * z
sq = s.sqrt()
i = acb(0, 1)
SQ2 = arb(2).sqrt()


def Phi(w):
    return (1 + (w / SQ2).erf()) / 2


def F(x, zz, ss, sqq, lam_, a_):
    m = zz * x
    ii = acb(0, 1)
    mid = Phi((a_ - m) / sqq) - Phi((-a_ - m) / sqq)
    right = (ii * lam_ * a_).exp() * (-ii * lam_ * m - lam_ * lam_ * ss / 2).exp() * (1 - Phi((a_ - m + ii * lam_ * ss) / sqq))
    left = (ii * lam_ * a_).exp() * (ii * lam_ * m - lam_ * lam_ * ss / 2).exp() * Phi((-a_ - m - ii * lam_ * ss) / sqq)
    return mid + right + left


zc = z.conjugate()
sc = s.conjugate()
sqc = sq.conjugate()   # conj of principal sqrt = principal sqrt of conj (Re s > 0)


def H(x, analytic):
    fx = F(x, z, s, sq, lam, a)
    gx = F(x, zc, sc, sqc, -lam, a)   # G(x) = conj(F(conj x)): conjugate all parameters, i -> -i via lam -> -lam
    return fx * fx * gx * gx * (-x * x / 2).exp() / (2 * arb.pi()).sqrt()


if __name__ == "__main__":
    # sanity: for real x, G(x) = conj(F(x))
    x0 = acb(arb("1.3"))
    print("check G = conj F at x=1.3:", F(x0, zc, sc, sqc, -lam, a) - F(x0, z, s, sq, lam, a).conjugate())
    print("T_z f(0) =", F(acb(0), z, s, sq, lam, a))
    L = arb(12)
    pieces = [(-12, -6), (-6, -3), (-3, 0), (0, 3), (3, 6), (6, 12)]
    total = acb(0)
    for lo, hi in pieces:
        val = acb.integral(lambda x, an: H(x, an), arb(lo), arb(hi), rel_tol=2 ** -60, eval_limit=10 ** 7)
        print(f"  integral over [{lo},{hi}] = {val}")
        total += val
    A = (1 / s).real
    C = (z / s).real
    E = C * C / A - A + 1
    print("E = C^2/A - A + 1 =", E, " (need < 1/4)")
    rate = arb(1) / 2 - 2 * E
    # int_{|x|>L} exp(-rate x^2) dx / sqrt(2 pi) = erfc(L sqrt(rate)) / sqrt(2 rate)
    tail = (abs(s) * A) ** (-2) * (L * rate.sqrt()).erfc() / (2 * rate).sqrt()
    print("tail bound =", tail)
    print("E|T_z f|^4 over [-12,12] =", total)
    # The integrand |T_z f|^4 dgamma is nonnegative, so the integral over [-12,12] is a LOWER bound:
    lower = total.real
    print("CERTIFIED: E|T_z f|^4 >= ", lower.lower(), "  > 1:", lower > 1)
    print("CERTIFIED: ||T_z f||_4 >= ", (lower.log() / 4).exp().lower(), " = exp(", (lower.log() / 4).lower(), ")")
    upper = total.real + tail
    print("(finiteness, Schur bound E<1/4): E|T_z f|^4 <= ", upper.upper())
    # Schur exponent condition q(C^2/A - A + 1) < 1 (Lemma 2.3 at sigma = 1): polynomial approximation applies
    print("Schur condition 4E < 1:", 4 * E, 4 * E < 1)
    # non-degeneracy of the Lebesgue-space kernel G(x,y) = phi(x)^{1/q} K_z(x,y) phi(y)^{1-1/p} for p >= 16:
    a_ = A - 1
    for pp in [arb(16), arb(10) ** 6]:
        m11 = arb(1) / 4 + a_
        m22 = 1 - 1 / pp + a_
        print(f"non-degeneracy (p={pp}): 1/q+a =", m11, " det-type quantity (1/q+a)(1-1/p+a)-C^2 =", m11 * m22 - C * C,
              ">0:", (m11 > 0) and (m11 * m22 - C * C > 0))
