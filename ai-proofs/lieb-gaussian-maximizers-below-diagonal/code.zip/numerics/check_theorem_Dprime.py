"""Exact (sympy) checks for the open-set version of Theorem D (Section 6 of
RESULT_lieb_gaussian_maximizers_below_diagonal).  z = x + i y, s = 1 - z^2 (varsigma), q general unless stated.

(1) |s|^2 = (1-|z|^2)^2 + 4 y^2.
(2) On the boundary of Omega_{q,q}: (q-2)^2 |s|^2 = q^2 (1-|z|^2)^2  <=>  (q-2)^2 y^2 = (q-1)(1-|z|^2)^2, and then
    (q-1)|s|^2 = q^2 y^2.
(3) alpha0 = q Re s - (q-1)|s|^2 equals |s|^2 delta_q (delta_q = 1 - q + q Re(1/s)), and
    alpha0 - q c0 = q^2 y^2 - (q-1)|s|^2 (c0 = Re s - q y^2), so alpha0 = q c0 on the boundary.
(4) Chirps beta = i t: with b = Im z^2, |D|^2 = 1 - 2 b t + |s|^2 t^2 and N = 1 + (q-2) b t + alpha0 t^2, and
    c(i t) = -((q-2)/(4q)) log|D|^2 - (1/(2q)) log N.
(5) q = 4: |D|^2 N - 1 = t^2 [ (alpha0 + S - 4 b^2) + 2 b (S - alpha0) t + alpha0 S t^2 ]  (S = |s|^2), and the
    discriminant of the bracket is 4 S^2 (1 + delta)(b^2 (1 + delta) - delta S) with alpha0 = S delta.
(6) q = 4 on the boundary, parametrised by y = sigma in (0, 1/sqrt 3), x^2 = 1 - sigma^2 - 2 sigma/sqrt 3:
    delta S - b^2 (1 + delta) = 2 sigma (1 + sigma^2) (1/sqrt 3 - sigma) > 0, so the chirp inequality is strict.
(7) The Hessian of c at beta = 0 in the direction Im beta: d^2/dt^2 c(i t)|_0 = (a^2 + (q-1) b^2 - 1)/2,
    z^2 = a + i b.
(8)-(10) the chirp lemma for every r > 2 (substitution, psi' = 2u R(u)/(AB), discriminant of R);
(11) the second-order part of c_q(beta; p); (12a)-(12d) the case q < p < 2 on the boundary of Omega_{p,p};
(13) 2 delta_r |s|^2 = r(1-|z|^4) - (r-2)|s|^2; (14) the case s = q factorisation on the boundary;
(15) 4 alpha0 - |omega - q|z|^2|^2 = 4q|z|^2 c0 and min T = q|z|^2 kappa/alpha0 (Lemma 3.1(iv));
(16) the kappa identity of the companion note (Lemma 5.2) and the Step 4 identity for s = q.
Also a floating-point cross-check of (4) against the general closed form c(beta) at random points.
"""
import random

import sympy as sp

x, y, t, q, sig = sp.symbols("x y t q sigma", real=True)
E = sp.expand
I = sp.I
z = x + I * y
s = 1 - z ** 2
re = lambda w: sp.re(E(w))
im = lambda w: sp.im(E(w))
S = E(re(s) ** 2 + im(s) ** 2)
r2 = x ** 2 + y ** 2
ok = {}
ok["(1) |s|^2 = (1-|z|^2)^2 + 4y^2"] = E(S - ((1 - r2) ** 2 + 4 * y ** 2)) == 0
# (2): from (q-2)^2 S = q^2 (1-r2)^2 and (1)
lhs = E((q - 2) ** 2 * ((1 - r2) ** 2 + 4 * y ** 2) - q ** 2 * (1 - r2) ** 2)
rhs = E(4 * ((q - 2) ** 2 * y ** 2 - (q - 1) * (1 - r2) ** 2))
ok["(2a) (q-2)^2|s|^2 - q^2(1-|z|^2)^2 = 4[(q-2)^2 y^2 - (q-1)(1-|z|^2)^2]"] = E(lhs - rhs) == 0
# on the boundary, (q-1)S - q^2 y^2 = (q-1)(1-r2)^2 + 4(q-1)y^2 - q^2 y^2 = (q-1)(1-r2)^2 - (q-2)^2 y^2 = 0
ok["(2b) (q-1)|s|^2 - q^2 y^2 = (q-1)(1-|z|^2)^2 - (q-2)^2 y^2"] = \
    E((q - 1) * S - q ** 2 * y ** 2 - ((q - 1) * (1 - r2) ** 2 - (q - 2) ** 2 * y ** 2)) == 0
alpha0 = E(q * re(s) - (q - 1) * S)
A = re(s) / S
delta = 1 - q + q * A
ok["(3a) alpha0 = |s|^2 delta_q"] = sp.simplify(alpha0 - S * delta) == 0
c0 = E(re(s) - q * y ** 2)
ok["(3b) alpha0 - q c0 = q^2 y^2 - (q-1)|s|^2"] = E(alpha0 - q * c0 - (q ** 2 * y ** 2 - (q - 1) * S)) == 0
# (4) chirps
b = im(z ** 2)
beta = I * t
D = 1 - s * beta
D2 = E(re(D) ** 2 + im(D) ** 2)
ok["(4a) |D|^2 = 1 - 2bt + |s|^2 t^2"] = E(D2 - (1 - 2 * b * t + S * t ** 2)) == 0
N = E(D2 - q * re(E(z ** 2 * beta * (re(D) - I * im(D)))))
ok["(4b) N = 1 + (q-2) b t + alpha0 t^2"] = E(N - (1 + (q - 2) * b * t + alpha0 * t ** 2)) == 0
# (5) q = 4
Sv, bv, dv = sp.symbols("S b delta", positive=True)
al4 = Sv * dv
P = E((1 - 2 * bv * t + Sv * t ** 2) * (1 + 2 * bv * t + al4 * t ** 2) - 1)
br = E(sp.cancel(P / t ** 2))
ok["(5a) |D|^2 N - 1 = t^2[(al+S-4b^2) + 2b(S-al)t + al S t^2]"] = \
    E(br - ((al4 + Sv - 4 * bv ** 2) + 2 * bv * (Sv - al4) * t + al4 * Sv * t ** 2)) == 0
disc = E((2 * bv * (Sv - al4)) ** 2 - 4 * (al4 * Sv) * (al4 + Sv - 4 * bv ** 2))
ok["(5b) discriminant = 4 S^2 (1+delta)(b^2(1+delta) - delta S)"] = \
    E(disc - 4 * Sv ** 2 * (1 + dv) * (bv ** 2 * (1 + dv) - dv * Sv)) == 0
# (6) q = 4 on the boundary: 2 y = sqrt(3)(1 - r2); parametrise y = sig, x^2 = 1 - sig^2 - 2 sig/sqrt(3)
x2 = 1 - sig ** 2 - 2 * sig / sp.sqrt(3)
sub = lambda e: sp.expand(e.subs(x ** 2, x2)) if e.has(x) else e
S4 = sp.expand(((1 - (x2 + sig ** 2)) ** 2 + 4 * sig ** 2))
b2 = sp.expand(4 * x2 * sig ** 2)                       # b^2 = (2 x y)^2
al = sp.expand(4 * (1 - x2 + sig ** 2) - 3 * S4)       # alpha0 = 4 Re s - 3|s|^2, Re s = 1 - x^2 + y^2
d4 = al / S4
expr = sp.simplify(d4 * S4 - b2 * (1 + d4))
target = 2 * sig * (1 + sig ** 2) * (1 / sp.sqrt(3) - sig)
ok["(6) on bd Omega_4: delta S - b^2(1+delta) = 2 sigma(1+sigma^2)(1/sqrt3 - sigma)"] = \
    sp.simplify(sp.together(expr - target)) == 0
ok["(6') on bd Omega_4: |s|^2 = 16 sigma^2/3 and alpha0 = 4 c0"] = (sp.simplify(S4 - 16 * sig ** 2 / 3) == 0 and
    sp.simplify(al - 4 * (1 - x2 - 3 * sig ** 2)) == 0)
# (7) Hessian in Im beta at 0
cq = -(q - 2) / (4 * q) * sp.log(1 - 2 * b * t + S * t ** 2) - 1 / (2 * q) * sp.log(1 + (q - 2) * b * t + alpha0 * t ** 2)
d2 = sp.diff(cq, t, 2).subs(t, 0)
a2 = re(z ** 2)
ok["(7) d^2/dt^2 c(it)|_0 = (a^2+(q-1)b^2-1)/2"] = sp.simplify(E(d2 - (a2 ** 2 + (q - 1) * b ** 2 - 1) / 2)) == 0
ok["(7') first derivative d/dt c(it)|_0 = 0"] = sp.simplify(sp.diff(cq, t).subs(t, 0)) == 0

# (8)-(10) general q: chirps on the boundary.  y > 0, k = sqrt(q-1), w = k y in (0,1); boundary (q-2) y = k(1-|z|^2).
qq, w, u = sp.symbols("q w u", positive=True)
kk = sp.sqrt(qq - 1)
yb = w / kk
x2b = 1 - yb ** 2 - (qq - 2) * yb / kk                       # from (q-2) y = k (1 - x^2 - y^2)
ok["(8a) on bd Omega_q: x^2 = (1-w)(w+q-1)/(q-1)"] = sp.simplify(x2b - (1 - w) * (w + qq - 1) / (qq - 1)) == 0
Sb = (1 - x2b - yb ** 2) ** 2 + 4 * yb ** 2
ok["(8b) on bd Omega_q: (q-1)|s|^2 = q^2 y^2"] = sp.simplify((qq - 1) * Sb - qq ** 2 * yb ** 2) == 0
alb = qq * (1 - x2b + yb ** 2) - (qq - 1) * Sb                # alpha0 = q Re s - (q-1)|s|^2
c0b = (1 - x2b + yb ** 2) - qq * yb ** 2
ok["(8c) on bd Omega_q: alpha0 = q c0 = q(q-2) y (1/k - y)"] = (sp.simplify(alb - qq * c0b) == 0 and
                                                              sp.simplify(alb - qq * (qq - 2) * yb * (1 / kk - yb)) == 0)
xs = sp.symbols("x_s", real=True)                            # x itself (either sign); b = 2 x y
bb_ = 2 * xs * yb
tt = kk * u / (qq * yb)                                        # t = k u / (q y)
xi = 2 * kk * xs / qq
ee = (qq - 2) / 2
gam = (qq - 2) * (qq - 1) * (1 - w) / (qq * w)
Ab = sp.expand(1 - 2 * bb_ * tt + Sb * tt ** 2)
Bb = sp.expand(1 + (qq - 2) * bb_ * tt + alb * tt ** 2)
ok["(8d) |D|^2 = 1 - 2 xi u + u^2,  N = 1 + 2 e xi u + gamma u^2  (t = k u/(q y))"] = (
    sp.simplify(Ab - (1 - 2 * xi * u + u ** 2)) == 0 and sp.simplify(Bb - (1 + 2 * ee * xi * u + gam * u ** 2)) == 0)
uu, XI, G, EE = sp.symbols("uu XI G EE", real=True)
A_ = 1 - 2 * XI * uu + uu ** 2
B_ = 1 + 2 * EE * XI * uu + G * uu ** 2
c2 = EE + G - 2 * EE * XI ** 2 * (EE + 1)
numer = sp.expand(EE * sp.diff(A_, uu) * B_ + A_ * sp.diff(B_, uu))
ok["(9) e A'B + A B' = 2u[G(e+1)u^2 + XI(e(2e+1) - G(e+2))u + c2], c2 = e + G - 2e XI^2(e+1)"] = \
    sp.expand(numer - 2 * uu * (G * (EE + 1) * uu ** 2 + XI * (EE * (2 * EE + 1) - G * (EE + 2)) * uu + c2)) == 0
Dcr = XI ** 2 * (EE * (2 * EE + 1) - G * (EE + 2)) ** 2 - 4 * G * (EE + 1) * c2
Dq = sp.together(Dcr.subs({EE: ee, G: gam}).subs(XI ** 2, 4 * (1 - w) * (w + qq - 1) / qq ** 2))
target = -(qq - 2) ** 2 * (qq - 1) * (w - 1) * (qq + 2 * w - 2) ** 2 * (qq ** 2 * w - qq ** 2 - qq * w - w + 1) / (qq ** 4 * w ** 2)
ok["(10a) discriminant = -(q-2)^2(q-1)(w-1)(q+2w-2)^2(q^2 w - q^2 - q w - w + 1)/(q^4 w^2)"] = \
    sp.simplify(Dq - target) == 0
lin = -(qq ** 2 * w - qq ** 2 - qq * w - w + 1)                # = q^2(1-w) + (q+1) w - 1, linear in w
ok["(10b) q^2(1-w)+(q+1)w-1 equals q^2-1 at w=0 and q at w=1 (so > 0 on [0,1] for q > 2)"] = (
    sp.simplify(lin.subs(w, 0) - (qq ** 2 - 1)) == 0 and sp.simplify(lin.subs(w, 1) - qq) == 0)

# (11) second-order part of c_q(beta; p) at beta = 0, all z, p, q
pp_, bx, by, eps = sp.symbols("p_ bx by eps", real=True)
beta_e = eps * (bx + I * by)
De = 1 - s * beta_e
De2 = E(re(De) ** 2 + im(De) ** 2)
bpn = E(z ** 2 * beta_e * (re(De) - I * im(De)))
ce = -sp.Rational(1, 4) * sp.log(De2) - sp.log(1 - q * re(bpn) / De2) / (2 * q) + sp.log(1 - pp_ * re(beta_e)) / (2 * pp_)
c2e = sp.diff(ce, eps, 2).subs(eps, 0) / 2
wv = z ** 2 * (bx + I * by)
nrm = lambda v, r_: (r_ - 1) * re(v) ** 2 + im(v) ** 2
ok["(11) c_q(beta;p) = (|z^2 beta|_q^2 - |beta|_p^2)/4 + O(|beta|^3), first order 0"] = (
    sp.simplify(E(c2e - (nrm(wv, q) - nrm(bx + I * by, pp_)) / 4)) == 0 and
    sp.simplify(sp.diff(ce, eps).subs(eps, 0)) == 0)
# (12) case q < p < 2 on the boundary of Omega_{p,p}: (2-p) y = k (1-|z|^2), k = sqrt(p-1)
P_, Y_ = sp.symbols("P Y", positive=True)
kp = sp.sqrt(P_ - 1)
X2p = 1 - Y_ ** 2 - (2 - P_) * Y_ / kp
Resp = 1 - X2p + Y_ ** 2
Sp_ = (1 - X2p - Y_ ** 2) ** 2 + 4 * Y_ ** 2
ok["(12a) on bd Omega_p (p<2): |s|^2 = p^2 y^2/(p-1)"] = sp.simplify(Sp_ - P_ ** 2 * Y_ ** 2 / (P_ - 1)) == 0
kapp = P_ * (Resp - q * Y_ ** 2) - (q * Resp - (q - 1) * Sp_)
ok["(12b) kappa = (p-q)(2-p)(y/k)(1-y/k)"] = sp.simplify(kapp - (P_ - q) * (2 - P_) * (Y_ / kp) * (1 - Y_ / kp)) == 0
ok["(12c) |s|^2 (A - 1/p) = (2-p)(y/k)(1-y/k)"] = sp.simplify(Resp - Sp_ / P_ - (2 - P_) * (Y_ / kp) * (1 - Y_ / kp)) == 0
Ap = Resp / Sp_
C2p = (1 - X2p - Y_ ** 2) ** 2 * X2p / Sp_ ** 2               # C = Re(z/s) = (1-|z|^2) Re z / |s|^2
detp = (1 / q + Ap - 1) * (Ap - 1 / P_) - C2p
ok["(12d) |s|^4 det = p y^3 (p-q)(2-p)(k-y)/(q(p-1)^2)"] = \
    sp.simplify(detp * Sp_ ** 2 - P_ * Y_ ** 3 * (P_ - q) * (2 - P_) * (kp - Y_) / (q * (P_ - 1) ** 2)) == 0

# (13) 2 delta_r S = r(1-|z|^4) - (r-2) S for every r, using delta_r S = (1-r) S + r Re s (A = Re s / S)
rr = sp.symbols("r", real=True)
ok["(13) 2 delta_r |s|^2 = r(1-|z|^4) - (r-2)|s|^2"] = \
    E(2 * ((1 - rr) * S + rr * re(s)) - (rr * (1 - r2 ** 2) - (rr - 2) * S)) == 0
# (14) case s = q on the boundary: with sg = sqrt(S) and (q-2) sg^2 = q (1-|z|^2) sg,
#      2 delta_q S = q(1-|z|^4) - (q-2) S = q(1-|z|^2)[(1+|z|^2) - sg]
sg = sp.symbols("sg", positive=True)
ok["(14) on bd Omega_q: q(1-|z|^4) - q(1-|z|^2) sg = q(1-|z|^2)[(1+|z|^2) - sg]"] = \
    E(q * (1 - r2 ** 2) - q * (1 - r2) * sg - q * (1 - r2) * (1 + r2 - sg)) == 0
# (15) Lemma 3.1(iv): 4 alpha0 - |omega - q|z|^2|^2 = 4 q |z|^2 c0, hence min_beta T = q|z|^2 kappa / alpha0,
#      where T = p N - q|z|^2 (1 - p Re beta) and min_beta [alpha0 |beta|^2 - Re(v beta)] = -|v|^2/(4 alpha0)
pq_ = sp.symbols("p", positive=True)
al0 = E(q * re(s) - (q - 1) * S)
c0 = E(re(s) - q * y ** 2)
v = E(q + (2 - q) * s - q * r2)
V2 = E(re(v) ** 2 + im(v) ** 2)
ok["(15a) 4 alpha0 - |omega - q|z|^2|^2 = 4 q |z|^2 c0"] = E(4 * al0 - V2 - 4 * q * r2 * c0) == 0
ok["(15b) 4 alpha0 (p - q|z|^2) - p|v|^2 = 4 q|z|^2 (p c0 - alpha0)  (min T = q|z|^2 kappa/alpha0)"] = \
    E(4 * al0 * (pq_ - q * r2) - pq_ * V2 - 4 * q * r2 * (pq_ * c0 - al0)) == 0
# (16) [DCH, Lemma 5.2]: 4[(q Re s - S)(q Re s - (q-1) S) - q^2 (Re(z conj s))^2] = S (q^2 (1-|z|^2)^2 - (q-2)^2 S),
#      i.e. (qA-1) delta_q - q^2 C^2 = [q^2(1-|z|^2)^2 - (q-2)^2 |s|^2] / (4|s|^2); so q^2 C^2 = (qA-1) delta_q on
#      the boundary, and then (1/q + A - 1)(A - 1/p) - C^2 = (delta_q/q)(1/q - 1/p)  (Step 4, case s = q)
zcs = E(z * (re(s) - I * im(s)))
ok["(16a) kappa identity of [DCH, Lemma 5.2]"] = \
    E(4 * ((q * re(s) - S) * (q * re(s) - (q - 1) * S) - q ** 2 * re(zcs) ** 2)
      - S * (q ** 2 * (1 - r2) ** 2 - (q - 2) ** 2 * S)) == 0
Asym, psym = sp.symbols("A p_sym", positive=True)
dq = q * Asym - q + 1
ok["(16b) Step 4, s = q: (1/q + A - 1)(A - 1/p) - (qA-1) delta_q/q^2 = (delta_q/q)(1/q - 1/p)"] = \
    sp.simplify((1 / q + Asym - 1) * (Asym - 1 / psym) - (q * Asym - 1) * dq / q ** 2 - dq / q * (1 / q - 1 / psym)) == 0

for k, v in ok.items():
    print(f"  {k:95s} {v}")

# floating-point cross-check of (4) against the general closed form
import cmath, math
random.seed(1)
err = 0.0
for _ in range(200):
    zz = complex(random.uniform(-0.9, 0.9), random.uniform(-0.9, 0.9))
    if abs(zz) >= 0.95:
        continue
    qq = random.uniform(2.1, 9)
    tt = random.uniform(-5, 5)
    ss = 1 - zz * zz
    Dd = 1 - ss * 1j * tt
    m = 1 - qq * (zz * zz * 1j * tt / Dd).real
    if m <= 0:
        continue
    c_gen = -0.5 * math.log(abs(Dd)) - math.log(m) / (2 * qq)
    bb = (zz * zz).imag
    al0 = qq * ss.real - (qq - 1) * abs(ss) ** 2
    c_chirp = -(qq - 2) / (4 * qq) * math.log(1 - 2 * bb * tt + abs(ss) ** 2 * tt * tt) - \
        math.log(1 + (qq - 2) * bb * tt + al0 * tt * tt) / (2 * qq)
    err = max(err, abs(c_gen - c_chirp))
print(f"  float cross-check of (4) at random points: max error {err:.2e}")
allok = all(ok.values()) and err < 1e-10
print("ALL CHECKS PASSED" if allok else "SOME CHECK FAILED")
assert allok
