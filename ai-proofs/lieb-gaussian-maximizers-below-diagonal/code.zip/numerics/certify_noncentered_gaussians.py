"""Rigorous certificate (exact symbolic identities + Arb ball arithmetic) for NON-CENTRED Gaussians in Theorem D:
q = 4, z = 0.72 e^{0.7i} (exactly (18/25) exp(7i/10)), p = 16.

For g(x) = exp(beta x^2/2 + gam x) with Re beta < 1/p and gam in C,
    log(||T_z g||_q / ||g||_p) = c(beta) + Q_beta(gam),
    Q_beta(gam) = 1/2 Re((s/D) gam^2) + (q/2) (Re(z gam/D))^2 / m - (p/2) (Re gam)^2 / n,
s = 1 - z^2, D = 1 - s beta, beta' = z^2 beta/D, m = 1 - q Re beta', n = 1 - p Re beta.
Write Q_beta(u + iv) = M11 u^2 + 2 M12 uv + M22 v^2, z = a + ib, beta = x + iy, N := |D|^2 m, and
    c0 = Re s - q b^2,   alpha0 = q Re s - (q-1)|s|^2,   omega = q + (2-q) s,   kappa = p c0 - alpha0.

(A) Exact identities (sympy Poly arithmetic over Q; a, b, x, y, p, q, u, v are free real symbols):
    (A1) 2N [1/2 Re((s/D) gam^2) + (q/2) (Re(z gam/D))^2/m] = Re(s gam^2) + q (Re z gam)^2 - alpha0 Re(beta conj(gam)^2)
         =: G(beta)[gam], so the output part of Q_beta is G(beta)[gam]/(2N) with G AFFINE in beta:
         G = [[q|z|^2 + c0 - alpha0 x, -(alpha0 y + (q-2)ab)], [-(alpha0 y + (q-2)ab), -(c0 - alpha0 x)]];
    (A2) N = |D|^2 - q Re(z^2 beta conj D) = 1 - Re(omega beta) + alpha0 |beta|^2;
    (A3) det G = -alpha0 N;   (A4) tr G = q |z|^2.
    Since M = G/(2N) - (p/(2n)) e1 e1^T, the 2x2 algebra gives
    (A5) det M = kappa/(4 n N)  (kappa = 4 det Q_0);   (A6) tr M = -T/(2 n N),  T := p N - q|z|^2 n;
    (A7) min over beta in C of T = q|z|^2 kappa/alpha0 if alpha0 > 0.
    So (det M) n N is CONSTANT: the degeneracy of Q_beta at beta = infinity (rank-one leading 1/|beta| part) is
    exact, and no asymptotic expansion or branch-and-bound is needed.  The only steps between the formula for Q and
    (A1) are 1/D = conj(D)/|D|^2 and m = N/|D|^2; (A8) re-checks the literal formula, with complex division, in
    exact rational arithmetic, and (A9) re-derives (A5) directly from the polynomial form of Q without using G.
(B) Inequalities (Arb, 256-bit balls, p = 16, q = 4):
    (B1) Re(1/s) > 1/16: D != 0 on the closed half-plane, and the Mehler integral converges;
    (B2) alpha0 > 0, c0 > 0, kappa > 0;
    (B3) N >= N_min > 0 on Re beta <= 1/16: dN/dx = -Re omega + 2 alpha0 x <= -Re omega + alpha0/8 < 0 there, so
         N(x, y) >= N(1/16, y) >= N_min (exact minimum in y).  Hence 1 - 4 Re beta' = N/|D|^2 > 0 (T_z g in L^4);
    (B4) T >= T_min > 0 on all of C (exact minimum of a convex quadratic, = q|z|^2 kappa/alpha0 by A7).
    So for Re beta < 1/16: det M > 0 and tr M < 0, i.e. Q_beta is negative definite, with
        -kappa/T(beta) <= lambda_max(Q_beta) <= -kappa/(2 T(beta)) < 0.
    (B5) Every p >= 16 directly: kappa_p = p c0 - alpha0 >= kappa_16 > 0, T_p >= q|z|^2 kappa_p/alpha0, N > 0.
(C) Consistency checks (not used in the proof): Arb evaluation of M from its definition at points in every regime
    (beta -> 0, Re beta -> 1/16, Re beta -> -inf, Im beta -> +-inf, |beta| up to 1e40); float agreement with
    gauss_nd.ratio_parts (the code of the wide scan); mpmath quadrature of the full log-ratio for two non-centred
    Gaussians (NOT rigorous).
(D) c(beta) <= 0 with equality only at beta = 0 is certified by certify_centered_gaussians.py, re-run here.
Usage: python3 certify_noncentered_gaussians.py [--skip-centred]
"""
import math
import os
import random
import subprocess
import sys
import time
from fractions import Fraction as Fr

sys.dont_write_bytecode = True
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)

import numpy as np
import sympy as sp
import mpmath as mpm
from flint import arb, acb, ctx, fmpq

T_START = time.perf_counter()
RIGOROUS = {}
CONSISTENT = {}


def record(table, key, ok, text):
    table[key] = bool(ok)
    print(f"  [{'ok' if ok else 'FAIL'}] {key}: {text}")


def fb(t, d=15):
    """ball as 'midpoint (+/- radius)'"""
    return f"{t.mid().str(d, radius=False)} (+/- {float(t.rad()):.1e})"


def dn(t, k):
    """k-decimal number certified <= every point of the ball t"""
    c = Fr(math.floor(float(t.mid()) * 10 ** k), 10 ** k)
    while not arb(fmpq(c.numerator, c.denominator)) <= t:
        c -= Fr(1, 10 ** k)
    return f"{float(c):.{k}f}"


def up(t, k):
    """k-decimal number certified >= every point of the ball t"""
    c = Fr(math.ceil(float(t.mid()) * 10 ** k), 10 ** k)
    while not arb(fmpq(c.numerator, c.denominator)) >= t:
        c += Fr(1, 10 ** k)
    return f"{float(c):.{k}f}"


# ====================================================================================================
# (A) exact identities
# ====================================================================================================
print("(A) exact identities (sympy Poly over QQ; z = a+ib, beta = x+iy, gam = u+iv, p, q symbolic)")
tA = time.perf_counter()
a, b, x, y, p, q, u, v = sp.symbols("a b x y p q u v", real=True)
GENS = (a, b, x, y, p, q, u, v)


def P(e):
    return sp.Poly(e, *GENS, domain="QQ")


class Cx:
    """complex number as a pair of real polynomials"""

    def __init__(self, r, i=0):
        self.r = r if isinstance(r, sp.Poly) else P(r)
        self.i = i if isinstance(i, sp.Poly) else P(i)

    def __add__(self, o):
        o = o if isinstance(o, Cx) else Cx(o)
        return Cx(self.r + o.r, self.i + o.i)

    __radd__ = __add__

    def __sub__(self, o):
        o = o if isinstance(o, Cx) else Cx(o)
        return Cx(self.r - o.r, self.i - o.i)

    def __rsub__(self, o):
        return Cx(o) - self

    def __mul__(self, o):
        o = o if isinstance(o, Cx) else Cx(o)
        return Cx(self.r * o.r - self.i * o.i, self.r * o.i + self.i * o.r)

    __rmul__ = __mul__

    def conj(self):
        return Cx(self.r, -self.i)


zS, betaS, gamS = Cx(a, b), Cx(x, y), Cx(u, v)
qP, pP = P(q), P(p)
z2S = zS * zS
sS = 1 - z2S
DS = 1 - sS * betaS
DcS = DS.conj()
absD2S = DS.r ** 2 + DS.i ** 2
N_def = absD2S - qP * (z2S * betaS * DcS).r                    # = |D|^2 m
# 2 |D|^2 N * [1/2 Re((s/D) gam^2) + (q/2) (Re(z gam/D))^2/m]   (using 1/D = conj D/|D|^2, m = N/|D|^2)
OUT = N_def * (sS * DcS * gamS * gamS).r + qP * ((zS * gamS * DcS).r) ** 2
absz2S = P(a ** 2 + b ** 2)
c0S = sS.r - qP * P(b ** 2)
alpha0S = qP * sS.r - P(q - 1) * (sS.r ** 2 + sS.i ** 2)
omS = Cx(qP) + sS * P(2 - q)
kappaS = pP * c0S - alpha0S
nS = P(1 - p * x)
Gc = (sS * gamS * gamS).r + qP * ((zS * gamS).r) ** 2 - alpha0S * (betaS * gamS.conj() * gamS.conj()).r
G11 = qP * absz2S + c0S - alpha0S * P(x)
G12 = -(alpha0S * P(y) + P(q - 2) * P(a * b))
G22 = -(c0S - alpha0S * P(x))
N_exp = 1 - (omS.r * P(x) - omS.i * P(y)) + alpha0S * P(x ** 2 + y ** 2)
TS = pP * N_exp - qP * absz2S * nS
idA = {
    "A1 N Re(s conj(D) gam^2) + q Re(z gam conj D)^2 = |D|^2 [Re(s gam^2) + q (Re z gam)^2 - alpha0 Re(beta conj(gam)^2)]":
        OUT - absD2S * Gc,
    "A1' Re(s gam^2) + q (Re z gam)^2 - alpha0 Re(beta conj(gam)^2) = G11 u^2 + 2 G12 uv + G22 v^2":
        Gc - (G11 * P(u ** 2) + P(2) * G12 * P(u * v) + G22 * P(v ** 2)),
    "A2 N := |D|^2 - q Re(z^2 beta conj D) = 1 - Re(omega beta) + alpha0 |beta|^2": N_def - N_exp,
    "A3 det G = -alpha0 N": G11 * G22 - G12 ** 2 + alpha0S * N_exp,
    "A4 tr G = q |z|^2": G11 + G22 - qP * absz2S,
    "A5 det M = kappa/(4nN)  [n det G - p N G22 = kappa N]": nS * (G11 * G22 - G12 ** 2) - pP * N_exp * G22 - kappaS * N_exp,
    "A6 tr M = -T/(2nN)  [n tr G - p N = -T]": nS * (G11 + G22) - pP * N_exp + TS,
    "A7 4 alpha0 min T: 4 alpha0 (p - q|z|^2) - p((q|z|^2 - Re omega)^2 + (Im omega)^2) = 4 q|z|^2 kappa":
        4 * alpha0S * (pP - qP * absz2S) - pP * ((qP * absz2S - omS.r) ** 2 + omS.i ** 2) - 4 * qP * absz2S * kappaS,
}
for k, e in idA.items():
    record(RIGOROUS, k, e.is_zero, "polynomial identity holds exactly" if e.is_zero else "NONZERO")
print("  A1, A1': Q_beta(gam) = G(beta)[gam]/(2N) - (p/2)(Re gam)^2/n, i.e. M = G/(2N) - (p/(2n)) e1 e1^T;")
print("  A5, A6: det M and tr M of this 2x2 matrix, multiplied by 4nN^2 and 2nN respectively.")


class FC:
    """exact complex rational arithmetic (independent of sympy)"""

    def __init__(self, r, i=Fr(0)):
        self.r, self.i = Fr(r), Fr(i)

    def __add__(self, o):
        o = o if isinstance(o, FC) else FC(o)
        return FC(self.r + o.r, self.i + o.i)

    __radd__ = __add__

    def __sub__(self, o):
        o = o if isinstance(o, FC) else FC(o)
        return FC(self.r - o.r, self.i - o.i)

    def __rsub__(self, o):
        return FC(o) - self

    def __mul__(self, o):
        o = o if isinstance(o, FC) else FC(o)
        return FC(self.r * o.r - self.i * o.i, self.r * o.i + self.i * o.r)

    __rmul__ = __mul__

    def __truediv__(self, o):
        o = o if isinstance(o, FC) else FC(o)
        d = o.r * o.r + o.i * o.i
        return FC((self.r * o.r + self.i * o.i) / d, (self.i * o.r - self.r * o.i) / d)


def Q_literal(zz, bb, gg, pp, qq):
    s_ = 1 - zz * zz
    D_ = 1 - s_ * bb
    m_ = 1 - qq * (zz * zz * bb / D_).r
    n_ = 1 - pp * bb.r
    return (s_ / D_ * gg * gg).r / 2 + qq / 2 * ((zz * gg / D_).r) ** 2 / m_ - pp / 2 * gg.r ** 2 / n_


def closed_rational(zz, bb, pp, qq):
    aa, b_ = zz.r, zz.i
    s_ = 1 - zz * zz
    c0_ = s_.r - qq * b_ * b_
    al_ = qq * s_.r - (qq - 1) * (s_.r ** 2 + s_.i ** 2)
    om_ = qq + (2 - qq) * s_
    N_ = 1 - (om_.r * bb.r - om_.i * bb.i) + al_ * (bb.r ** 2 + bb.i ** 2)
    n_ = 1 - pp * bb.r
    T_ = pp * N_ - qq * (aa * aa + b_ * b_) * n_
    M11 = (qq * (aa * aa + b_ * b_) + c0_ - al_ * bb.r) / (2 * N_) - pp / (2 * n_)
    M12 = -(al_ * bb.i + (qq - 2) * aa * b_) / (2 * N_)
    M22 = -(c0_ - al_ * bb.r) / (2 * N_)
    return M11, M12, M22, (pp * c0_ - al_) / (4 * n_ * N_), -T_ / (2 * n_ * N_)


rng = random.Random(20261027)
ok_exact = True
for _ in range(60):
    def rnd(lo, hi, den=97):
        return Fr(rng.randint(int(lo * den), int(hi * den)), den)
    zz = FC(rnd(-0.9, 0.9), rnd(-0.9, 0.9))
    bb = FC(rnd(-5, 0.05), rnd(-5, 5))
    pp, qq = rnd(2, 40, 7), rnd(2, 12, 5)
    M11, M12, M22, detc, trc = closed_rational(zz, bb, pp, qq)
    gg = FC(rnd(-3, 3), rnd(-3, 3))
    lit = [Q_literal(zz, bb, w, pp, qq) for w in (FC(1), FC(0, 1), FC(1, 1), gg)]
    m11, m22 = lit[0], lit[1]
    m12 = (lit[2] - m11 - m22) / 2
    ok_exact &= (m11, m12, m22) == (M11, M12, M22)
    ok_exact &= lit[3] == M11 * gg.r ** 2 + 2 * M12 * gg.r * gg.i + M22 * gg.i ** 2
    ok_exact &= (m11 * m22 - m12 * m12 == detc) and (m11 + m22 == trc)
record(CONSISTENT, "A8 literal formula (with complex division) in exact rationals at 60 random (z, beta, gam, p, q)",
       ok_exact, "M entries, Q(gam), det and tr equal the closed forms exactly" if ok_exact else "MISMATCH")

WQ = nS * OUT - pP * absD2S * N_exp * P(u ** 2)                # = W Q_beta,  W = 2 |D|^2 N n
Wc = {(2, 0): P(0), (1, 1): P(0), (0, 2): P(0)}
pure = True
for mon, cf in WQ.terms():
    key, rest = (mon[6], mon[7]), list(mon[:6]) + [0, 0]
    if key not in Wc:
        pure = False
        continue
    Wc[key] += P(sp.Mul(cf, *[g ** e for g, e in zip(GENS, rest)]))
W = 2 * absD2S * N_exp * nS
direct = 4 * nS * N_exp * (Wc[(2, 0)] * Wc[(0, 2)] - (Wc[(1, 1)] * sp.Rational(1, 2)) ** 2) - kappaS * W ** 2
record(RIGOROUS, "A9 (redundant) 4nN det(W M) = kappa W^2 with W M read off from W Q, without G", pure and direct.is_zero,
       ("polynomial identity holds exactly" if direct.is_zero else "NONZERO")
       + ("; W Q has only (u, v)-monomials of degree 2" if pure else "; W Q is NOT a pure quadratic form"))
print(f"  time (A): {time.perf_counter() - tA:.1f} s")

# ====================================================================================================
# (B) Arb inequalities at z = (18/25) e^{7i/10}, p = 16, q = 4
# ====================================================================================================
print("\n(B) Arb inequalities (z = (18/25) exp(7i/10), p = 16, q = 4, 256-bit balls)")
tB = time.perf_counter()


class Const:
    def __init__(self, prec):
        ctx.prec = prec
        self.prec = prec
        self.p, self.q = arb(16), arb(4)
        r, th = arb(fmpq(18, 25)), arb(fmpq(7, 10))
        self.z = acb(r * th.cos(), r * th.sin())
        self.z2 = self.z * self.z
        self.s = 1 - self.z2
        self.absz2 = self.z.real ** 2 + self.z.imag ** 2
        self.abss2 = self.s.real ** 2 + self.s.imag ** 2
        self.alpha0 = self.q * self.s.real - (self.q - 1) * self.abss2
        self.c0 = self.s.real - self.q * self.z.imag ** 2
        self.kappa = self.p * self.c0 - self.alpha0
        self.om = self.q + (2 - self.q) * self.s
        self.ab = self.z.real * self.z.imag

    def N(self, X, Y):
        return 1 - (self.om.real * X - self.om.imag * Y) + self.alpha0 * (X * X + Y * Y)

    def closed(self, X, Y):
        N = self.N(X, Y)
        n = 1 - self.p * X
        T = self.p * N - self.q * self.absz2 * n
        return dict(N=N, n=n, T=T, det=self.kappa / (4 * n * N), tr=-T / (2 * n * N),
                    M22=-(self.c0 - self.alpha0 * X) / (2 * N), M12=-(self.alpha0 * Y + (self.q - 2) * self.ab) / (2 * N))

    def direct(self, X, Y):
        beta = acb(X, Y)
        D = 1 - self.s * beta
        A, K = self.s / D, self.z / D
        m = 1 - self.q * (self.z2 * beta / D).real
        n = 1 - self.p * X
        M11 = A.real / 2 + (self.q / 2) * K.real ** 2 / m - (self.p / 2) / n
        M22 = -A.real / 2 + (self.q / 2) * K.imag ** 2 / m
        M12 = -A.imag / 2 - (self.q / 2) * K.real * K.imag / m
        return M11, M12, M22, m, n, D


def lam_max(tr, det):
    lam_min = tr / 2 - (tr * tr / 4 - det).sqrt()
    return det / lam_min


C = Const(256)
sixteenth = arb(1) / 16
pole = 1 / C.s
record(RIGOROUS, "B1 Re(1/s) > 1/16", pole.real > sixteenth, f"Re(1/s) = {fb(pole.real)}")
record(RIGOROUS, "B2 alpha0 > 0", C.alpha0 > 0, f"alpha0 = 4 Re s - 3|s|^2 = {fb(C.alpha0)}")
record(RIGOROUS, "B2 c0 > 0", C.c0 > 0, f"c0 = Re s - 4 (Im z)^2 = {fb(C.c0)}")
record(RIGOROUS, "B2 kappa > 0", C.kappa > 0, f"kappa = 16 c0 - alpha0 = 4 det Q_0 = {fb(C.kappa)}")
mono = C.om.real - C.alpha0 / 8
record(RIGOROUS, "B3a dN/dx < 0 on Re beta <= 1/16", mono > 0,
       f"Re omega - alpha0/8 = {fb(mono, 12)}  (omega = 4 - 2s = {C.om.real.str(12, radius=False)} "
       f"+ {C.om.imag.str(12, radius=False)}i)")
N_min = 1 - C.om.real / 16 + C.alpha0 / 256 - C.om.imag ** 2 / (4 * C.alpha0)
y_N = -C.om.imag / (2 * C.alpha0)
record(RIGOROUS, "B3b N >= N_min > 0 on Re beta <= 1/16", N_min > 0,
       f"N_min = min_y N(1/16 + iy) = {fb(N_min)}, attained at y = {y_N.str(10, radius=False)}")
Bc = C.p * (C.q * C.absz2 - C.om.real)
Cc = C.p * C.om.imag
T_min = (C.p - C.q * C.absz2) - (Bc * Bc + Cc * Cc) / (4 * C.p * C.alpha0)
T_min2 = C.q * C.absz2 * C.kappa / C.alpha0
x_T, y_T = -Bc / (2 * C.p * C.alpha0), -Cc / (2 * C.p * C.alpha0)
record(RIGOROUS, "B4 T >= T_min > 0 on C", T_min > 0 and (T_min - T_min2).contains(0),
       f"T(beta) = 16 N - 4|z|^2 (1 - 16 Re beta) >= T_min = {fb(T_min)} (= q|z|^2 kappa/alpha0 = "
       f"{T_min2.str(15, radius=False)}), attained at beta = {x_T.str(8, radius=False)} {y_T.str(8, radius=False)}i")
print("  => for every beta with Re beta < 1/16:  n > 0, N >= N_min, T >= T_min, hence")
print("     det Q_beta = kappa/(4nN) > 0,  tr Q_beta = -T/(2nN) < 0:  Q_beta is NEGATIVE DEFINITE, and")
print("     -kappa/T(beta) <= lambda_max(Q_beta) <= -kappa/(2 T(beta)) < 0.")
Lc = (Bc * Bc + Cc * Cc).sqrt()
E0 = C.p - C.q * C.absz2
print(f"     T(beta) = A |beta|^2 + B Re beta + C' Im beta + E with A = 16 alpha0 = {fb(C.p * C.alpha0, 10)},")
print(f"     B = 16(4|z|^2 - Re omega) = {fb(Bc, 10)}, C' = 16 Im omega = {fb(Cc, 10)}, E = 16 - 4|z|^2 = {fb(E0, 10)};")
print(f"     so, with outward-rounded constants, for all admissible beta")
print(f"     lambda_max(Q_beta) <= -{dn(C.kappa / 2, 6)} / ({up(C.p * C.alpha0, 5)} |beta|^2 + {up(Lc, 4)} |beta| "
      f"+ {up(E0, 4)}).")
tr0, det0 = -(C.p - C.q * C.absz2) / 2, C.kappa / 4
lm0 = lam_max(tr0, det0)
print(f"  beta = 0 (first chaos): tr Q_0 = {tr0.str(10, radius=False)}, det Q_0 = {det0.str(10, radius=False)}, "
      f"lambda_max(Q_0) = {fb(lm0, 10)}")
print(f"  |beta| -> infinity (any direction): |beta|^2 lambda_max(Q_beta) -> -kappa/(2 p alpha0) = "
      f"{(-C.kappa / (2 * C.p * C.alpha0)).str(10, radius=False)}")
okB5 = (C.c0 > 0) and (C.kappa > 0) and (N_min > 0) and (C.alpha0 > 0)
record(RIGOROUS, "B5 all p >= 16 directly", okB5,
       "kappa_p = p c0 - alpha0 >= kappa_16 > 0, T_p >= q|z|^2 kappa_p/alpha0 > 0 (A7), N > 0 on Re beta < 1/p (B3)")
print(f"  time (B): {time.perf_counter() - tB:.2f} s")

# ====================================================================================================
# (C) consistency checks (not needed for the proof)
# ====================================================================================================
print("\n(C) consistency checks")
tC = time.perf_counter()
F = Fr
pts = [(F(0), F(0)), (F(1, 10 ** 8), F(2, 10 ** 8)), (F(-3, 10 ** 6), F(1, 10 ** 6)), (F(-37, 100), F(81, 100)),
       (F(1, 16) - F(1, 2 ** 40), F(-13806, 10000)), (F(1, 16) - F(1, 10 ** 30), F(0)), (F(1, 16) - F(1, 10 ** 30), F(10 ** 6)),
       (F(1, 16) - F(1, 10 ** 12), F(-10 ** 40)), (F(-10 ** 6), F(0)), (F(-10 ** 20), F(3)), (F(-10 ** 40), F(-7)),
       (F(0), F(10 ** 8)), (F(0), F(-10 ** 8)), (F(-3), F(10 ** 25)), (F(-10 ** 15), F(10 ** 15)), (F(-10 ** 30), F(-10 ** 30)),
       (F(1, 16) - F(4851651954097903, 10 ** 7), F(-512337))]
rr = random.Random(7)
for _ in range(400):
    rad = 10 ** rr.uniform(-10, 40)
    ang = rr.uniform(0.5 * np.pi - 1e-3, 1.5 * np.pi + 1e-3)
    X, Y = F(1, 16) + F(rad * np.cos(ang)), F(rad * np.sin(ang))
    if X < F(1, 16):
        pts.append((X, Y))
for _ in range(100):
    pts.append((F(1, 16) - F(10 ** rr.uniform(-30, 0)), F(rr.choice([-1, 1]) * 10 ** rr.uniform(-3, 30))))


def relerr(e1, e2, scale):
    return float(((e1 - e2) / scale).abs_upper())


n_ok, worst_rel, show = 0, 0.0, []
for (Xq, Yq) in pts:
    good = False
    for prec in (256, 512, 1024, 2048, 4096):
        Cp = Const(prec)
        X, Y = arb(fmpq(Xq.numerator, Xq.denominator)), arb(fmpq(Yq.numerator, Yq.denominator))
        M11, M12, M22, m, n, D = Cp.direct(X, Y)
        cl = Cp.closed(X, Y)
        det_d, tr_d = M11 * M22 - M12 * M12, M11 + M22
        rel = max(relerr(det_d, cl["det"], cl["det"]), relerr(tr_d, cl["tr"], cl["tr"]),
                  relerr(M22, cl["M22"], cl["M22"]), relerr(M12, cl["M12"], abs(cl["M12"]) + abs(cl["M22"])),
                  relerr(m * abs(D) ** 2, cl["N"], cl["N"]))
        if rel < 1e-30:
            good = (det_d - cl["det"]).contains(0) and (tr_d - cl["tr"]).contains(0) and (M22 - cl["M22"]).contains(0) \
                and (M12 - cl["M12"]).contains(0) and (m * abs(D) ** 2 - cl["N"]).contains(0) \
                and m > 0 and n > 0 and det_d > 0 and tr_d < 0
            break
    worst_rel = max(worst_rel, rel)
    n_ok += good
    if len(show) < 17:
        show.append((Xq, Yq, cl, lam_max(cl["tr"], cl["det"]), prec))
print("  Arb evaluation of M from its definition vs the closed forms (balls overlap, certified rel. diff < 1e-30),")
print("  and direct signs det > 0, tr < 0, m > 0, n > 0 at the point (midpoints shown):")
for (Xq, Yq, cl, lm, prec) in show:
    print(f"    beta = {float(Xq):+.6e} {float(Yq):+.6e}i   n = {float(cl['n'].mid()):.4e}   N = {float(cl['N'].mid()):.4e}"
          f"   T = {float(cl['T'].mid()):.4e}   lambda_max = {float(lm.mid()):+.5e}   (prec {prec})")
record(CONSISTENT, f"C1 Arb pointwise agreement at {len(pts)} points in all regimes", n_ok == len(pts),
       f"{n_ok}/{len(pts)} points agree, worst certified relative difference {worst_rel:.1e}")

from gauss_nd import ratio_parts
zf = 0.72 * np.exp(0.7j)
sf = 1 - zf * zf
a0f, c0f = 4 * sf.real - 3 * abs(sf) ** 2, sf.real - 4 * zf.imag ** 2
omf = 4 - 2 * sf


def closed_float(bt):
    Nf = 1 - (omf.real * bt.real - omf.imag * bt.imag) + a0f * abs(bt) ** 2
    nf = 1 - 16 * bt.real
    G = np.array([[4 * abs(zf) ** 2 + c0f - a0f * bt.real, -(a0f * bt.imag + 2 * zf.real * zf.imag)],
                  [-(a0f * bt.imag + 2 * zf.real * zf.imag), -(c0f - a0f * bt.real)]])
    return G / (2 * Nf) - np.array([[8 / nf, 0], [0, 0]])


rs = np.random.default_rng(3)
werr = 0.0
for _ in range(3000):
    bt = 10 ** rs.uniform(-6, 6) * np.exp(1j * rs.uniform(0.5 * np.pi, 1.5 * np.pi)) + 1 / 16
    if bt.real >= 1 / 16:
        continue
    _, Qg = ratio_parts([[bt]], zf, 16.0, 4.0)
    Mc = closed_float(bt)
    werr = max(werr, np.abs(Qg - Mc).max() / np.abs(Mc).max())
record(CONSISTENT, "C2 float agreement with gauss_nd.ratio_parts (code of the wide scan), 3000 points", werr < 1e-9,
       f"max relative entry difference {werr:.1e}")
bw = 1 / 16 - np.exp(20.0) - 512337j
_, Qw = ratio_parts([[bw]], zf, 16.0, 4.0)
Cw = Const(256)
clw = Cw.closed(arb(1) / 16 - arb(20).exp(), arb(-512337))
print(f"  scan's worst point beta = 1/16 - e^20 - 512337i: lambda_max in floats (gauss_nd, abs. error ~1e-25) = "
      f"{np.linalg.eigvalsh(Qw).max():.6e}; closed form (Arb) = {fb(lam_max(clw['tr'], clw['det']), 8)}")

mpm.mp.dps = 30


def quad_check(beta, gam):
    z = mpm.mpf(18) / 25 * mpm.exp(1j * mpm.mpf(7) / 10)
    s = 1 - z * z
    D = 1 - s * beta
    bp, gp, tau = z * z * beta / D, z * gam / D, s * gam * gam / (2 * D)

    def Tg(t):
        return mpm.exp(bp * t * t / 2 + gp * t + tau) / mpm.sqrt(D)

    def Tg_quad(t):
        f = lambda w: mpm.exp(beta * w * w / 2 + gam * w - (w - z * t) ** 2 / (2 * s)) / mpm.sqrt(2 * mpm.pi * s)
        return mpm.quad(f, [-mpm.inf] + mpm.linspace(-60, 60, 25) + [mpm.inf], maxdegree=10)

    err_pt = 0
    for t in (mpm.mpf("-1.3"), mpm.mpf("0.4"), mpm.mpf("2.1")):
        A, B = Tg_quad(t), Tg(t)
        err_pt = max(err_pt, min(abs(A - B), abs(A + B)) / abs(B))
    phi = lambda t: mpm.exp(-t * t / 2) / mpm.sqrt(2 * mpm.pi)
    nodes = [-mpm.inf] + mpm.linspace(-80, 80, 33) + [mpm.inf]
    I4 = mpm.quad(lambda t: abs(Tg(t)) ** 4 * phi(t), nodes)
    Ip = mpm.quad(lambda t: abs(mpm.exp(beta * t * t / 2 + gam * t)) ** 16 * phi(t), nodes)
    lr_quad = mpm.log(I4) / 4 - mpm.log(Ip) / 16
    m_ = 1 - 4 * mpm.re(bp)
    n_ = 1 - 16 * mpm.re(beta)
    c_ = -mpm.log(abs(D)) / 2 - mpm.log(m_) / 8 + mpm.log(n_) / 32
    Q_ = mpm.re(s / D * gam * gam) / 2 + 2 * mpm.re(z * gam / D) ** 2 / m_ - 8 * mpm.re(gam) ** 2 / n_
    return err_pt, lr_quad, c_ + Q_, c_, Q_


ok_q = True
for bq, gq in ((mpm.mpc("-0.3", "0.25"), mpm.mpc("0.4", "-0.7")), (mpm.mpc("0.05", "-1.2"), mpm.mpc("-0.3", "0.9"))):
    e1, lq, lc, cq, Qq = quad_check(bq, gq)
    ok_q &= e1 < 1e-15 and abs(lq - lc) < 1e-15
    print(f"  quadrature: beta = {mpm.nstr(bq, 4)}, gam = {mpm.nstr(gq, 4)}: Mehler integral vs closed form for T_z g at "
          f"3 points, rel. err {mpm.nstr(e1, 3)}; log-ratio by quadrature = {mpm.nstr(lq, 16)}, c + Q = {mpm.nstr(lc, 16)} "
          f"(c = {mpm.nstr(cq, 8)}, Q = {mpm.nstr(Qq, 8)})")
record(CONSISTENT, "C3 mpmath quadrature of the log-ratio for two non-centred Gaussians (NOT rigorous)", ok_q,
       "closed form c + Q confirmed to 1e-15" if ok_q else "MISMATCH")
print(f"  time (C): {time.perf_counter() - tC:.1f} s")

# ====================================================================================================
# (D) the centred part c(beta) <= 0
# ====================================================================================================
print("\n(D) centred part: c(beta) < 0 for every admissible beta != 0 (certify_centered_gaussians.py)")
if "--skip-centred" in sys.argv:
    centred_ok = None
    print("  skipped (--skip-centred); see out_certify_centered_gaussians.txt")
else:
    tD = time.perf_counter()
    res = subprocess.run([sys.executable, "-B", os.path.join(HERE, "certify_centered_gaussians.py"), "0.0008"],
                         capture_output=True, text=True, cwd=HERE)
    last = res.stdout.strip().splitlines()[-1] if res.stdout.strip() else ""
    centred_ok = res.returncode == 0 and last.startswith("ALL CHECKS PASSED")
    print(f"  re-run with rho0 = 0.0008 ({time.perf_counter() - tD:.1f} s), exit code {res.returncode}: {last}")

# ====================================================================================================
print("\n" + "=" * 100)
rig = all(RIGOROUS.values())
cons = all(CONSISTENT.values())
bad_r = [k for k, o in RIGOROUS.items() if not o]
bad_c = [k for k, o in CONSISTENT.items() if not o]
print(f"rigorous steps (A1-A7, A9 symbolic; B1-B5 Arb): {'all passed' if rig else 'FAILED: ' + str(bad_r)}")
print(f"consistency checks (A8 exact; C1 Arb; C2-C3 floating point): {'all passed' if cons else 'FAILED: ' + str(bad_c)}")
if rig and cons:
    print("VERDICT: CERTIFIED.  For every beta in C with Re beta < 1/16, Q_beta is negative definite:")
    print(f"  Q_beta(gam) <= -kappa |gam|^2 / (2 T(beta)) < 0 for gam != 0, kappa > {dn(C.kappa, 6)}, "
          f"T(beta) >= T_min > {dn(T_min, 6)}, N(beta) >= N_min > {dn(N_min, 6)}.")
    if centred_ok:
        print("  Together with c(beta) <= 0 (equality only at beta = 0; re-run passed): every Gaussian")
        print("  g = C exp(beta x^2/2 + gam x), Re beta < 1/16, satisfies ||T_z g||_4 <= ||g||_16, with equality only for")
        print("  constant g; by Lyapunov (or B5 + monotonicity of c in p) the same holds for every p >= 16, Re beta < 1/p.")
    elif centred_ok is None:
        print("  (c(beta) <= 0 not re-run here; see out_certify_centered_gaussians.txt)")
    else:
        print("  WARNING: the re-run of the centred certificate did not pass; the full Gaussian statement is NOT certified.")
else:
    print("VERDICT: NOT CERTIFIED")
print(f"total runtime {time.perf_counter() - T_START:.1f} s")
