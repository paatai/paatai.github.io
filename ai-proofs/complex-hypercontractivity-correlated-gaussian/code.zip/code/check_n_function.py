"""Checks for the n equicorrelated functions results (Section 11 of the accompanying paper).

(1) Equicorrelated Gaussian moment  E exp(-mu/2 sum xi_j^2 + h sum xi_j)  vs nested quadrature.
(2) J_m = E prod_{j<=m} |T_z b(xi_j)|^r: closed form exp(t^2 R_m(B) + c_{m,B}) E b vs nested quadrature, with
    T_z b evaluated by direct quadrature of the Mehler integral.
(3) B^2 R_m(B) -> Phi_m = (m/lambda_m)(Q_m kappa_{Q_m} - 1/2) + 1/2.
(4) Plane waves: T_z e^{i w x} = exp(i z w x - (1 - z^2) w^2 / 2) (Mehler quadrature) and the n-fold moment.
(5) Phi_m > 0  <=>  F2(Q_m) > (2(m-1)(1-rho)/m) F1(Q_m)   (delta_{Q_m} > 0), random points.
(6) Exact polynomial identities F2 = 4Q^2 y^2 - 4(Q-1)|1-z^2|^2 and F1 = 2Q(Re z^2 - |z|^4) + 2|1-z^2|^2 (sympy).
(7) Phi_n(x + i eta/sqrt(Q_n)) -> (1/rho)[(eta^2 - a^2)/(2 x^2 a) - 1/2] + 1/2,  a = 1 - x^2.
All checks are floating point / high-precision quadrature (evidence for the algebra; the proofs are in the paper).
"""
import random

import mpmath as mp
import sympy as sp

mp.mp.dps = 30
gauss = lambda x: mp.exp(-x * x / 2) / mp.sqrt(2 * mp.pi)
fails = []


def check(name, a, b, tol):
    err = abs(a - b) / max(abs(b), mp.mpf(10) ** -300)
    ok = err < tol
    print(f"  {'ok ' if ok else 'FAIL'} {name}: rel.err = {mp.nstr(err, 3)}")
    if not ok:
        fails.append(name)


def nested(hfun, m, rho):
    """E prod_{j<=m} h(xi_j) for equicorrelated standard xi_j: xi_j = sqrt(rho) G + sqrt(1-rho) G_j."""
    sr, s1 = mp.sqrt(rho), mp.sqrt(1 - rho)
    inner = lambda g: mp.quad(lambda gp: hfun(sr * g + s1 * gp) * gauss(gp), [-mp.inf, 0, mp.inf])
    return mp.quad(lambda g: inner(g) ** m * gauss(g), [-mp.inf, -3, 0, 3, mp.inf])


def kappa_delta(z, q):
    s = 1 - z * z
    A, C = mp.re(1 / s), mp.re(z / s)
    d = 1 - q + q * A
    return -A / 2 + 1 / (2 * q) + q * C * C / (2 * d), d, A, C


def Phi_m(z, rho, r, m):
    lam = 1 + (m - 1) * rho
    Q = r * lam
    k, d, _, _ = kappa_delta(z, Q)
    return (m / lam) * (Q * k - mp.mpf(1) / 2) + mp.mpf(1) / 2, d


def R_m(B, z, rho, r, m):
    s = 1 - z * z
    D = 1 + s * B
    mu = r * B * mp.re(z * z / D)
    nu = r * mp.re(z / D)
    lam = 1 + (m - 1) * rho
    return (m * (-r / (2 * B) + r / 2 * mp.re(s / D)) + m * lam * nu ** 2 / (2 * (1 + mu * lam))
            + 1 / (2 * B * (1 + B))), mu, nu


def c_m(B, z, rho, r, m):
    s = 1 - z * z
    D = 1 + s * B
    mu = r * B * mp.re(z * z / D)
    lam = 1 + (m - 1) * rho
    return (-r * m / 2 * mp.log(abs(D)) - mp.log((1 + mu * lam) * (1 + mu * (1 - rho)) ** (m - 1)) / 2
            + mp.log(1 + B) / 2)


def mehler(f, z, x):
    s = 1 - z * z
    K = lambda y: mp.exp((2 * z * x * y - z * z * (x * x + y * y)) / (2 * s)) / mp.sqrt(s)
    return mp.quad(lambda y: f(y) * K(y) * gauss(y), [-mp.inf, -4, 0, 4, mp.inf])


print("(1) equicorrelated Gaussian moment")
for (mu, h, rho, m) in [(0.7, 0.3, 0.5, 3), (-0.25, 0.4, 0.4, 3), (-0.15, -0.2, 0.3, 4), (1.3, 0.1, 0.7, 4)]:
    mu, h, rho = mp.mpf(mu), mp.mpf(h), mp.mpf(rho)
    lam = 1 + (m - 1) * rho
    closed = mp.exp(m * lam * h * h / (2 * (1 + mu * lam))) / mp.sqrt((1 + mu * lam) * (1 + mu * (1 - rho)) ** (m - 1))
    num = nested(lambda x: mp.exp(-mu / 2 * x * x + h * x), m, rho)
    check(f"mu={mp.nstr(mu,3)}, h={mp.nstr(h,3)}, rho={mp.nstr(rho,3)}, m={m}", num, closed, mp.mpf(10) ** -20)

print("(2) J_m closed form vs nested quadrature (T_z b by Mehler quadrature on a grid-free basis)")
for (zz, rho, r, B, t, m) in [(0.6 * mp.expj(0.5), 0.5, 2, 1.5, 0.8, 3), (0.5 * mp.expj(0.9), 0.4, 3, 2.0, 1.0, 3),
                               (0.55 * mp.expj(0.3), 0.3, 2.5, 1.2, 0.6, 4)]:
    rho, r, B, t = mp.mpf(rho), mp.mpf(r), mp.mpf(B), mp.mpf(t)
    b = lambda y: mp.exp(-B * (y - t / B) ** 2 / 2)
    # |T_z b|^r is |c|^r exp(-mu x^2/2 + t nu x); fit (log-quadratic) from three Mehler quadratures, then compare
    xs = [mp.mpf(-1), mp.mpf(0), mp.mpf(1)]
    L = [r * mp.log(abs(mehler(b, zz, x))) for x in xs]
    R, mu, nu = R_m(B, zz, rho, r, m)
    s = 1 - zz * zz
    D = 1 + s * B
    logc = -mp.log(abs(D)) / 2 - t * t / (2 * B) + t * t / 2 * mp.re(s / D)
    pred = [r * logc - mu / 2 * x * x + t * nu * x for x in xs]
    for x, a1, a2 in zip(xs, L, pred):
        check(f"  log|T_z b|^r at x={x} (z={mp.nstr(zz,3)})", a1, a2, mp.mpf(10) ** -15)
    hfun = lambda x: mp.exp(r * logc - mu / 2 * x * x + t * nu * x)
    Jnum = nested(hfun, m, rho)
    Eb = (1 + B) ** (-mp.mpf(1) / 2) * mp.exp(-t * t / (2 * B * (1 + B)))
    Jcl = Eb * mp.exp(t * t * R + c_m(B, zz, rho, r, m))
    check(f"J_{m} (rho={mp.nstr(rho,2)}, r={mp.nstr(r,2)}, B={mp.nstr(B,2)}, t={mp.nstr(t,2)})", Jnum, Jcl, mp.mpf(10) ** -15)

print("(3) B^2 R_m(B) -> Phi_m")
random.seed(7)
for _ in range(6):
    rad, ang = random.uniform(0.3, 0.9), random.uniform(0.05, 1.5)
    zz = rad * mp.expj(ang)
    rho, r = mp.mpf(random.choice([0.3, 0.5, 0.7])), mp.mpf(random.choice([2, 3, 4]))
    for m in (2, 3, 5):
        ph, d = Phi_m(zz, rho, r, m)
        if abs(d) < mp.mpf("0.05"):
            continue
        vals = [B * B * R_m(B, zz, rho, r, m)[0] for B in (mp.mpf(10) ** 6, mp.mpf(10) ** 8)]
        check(f"z={mp.nstr(zz,3)}, rho={rho}, r={r}, m={m}: B=1e8 vs Phi_m (B=1e6: {mp.nstr(vals[0]-ph,3)})",
              vals[1], ph, mp.mpf(10) ** -6)

print("(4) plane waves")
for (zz, w) in [(0.6 * mp.expj(0.7), mp.mpf("1.3")), (0.4 * mp.expj(1.2), mp.mpf("0.7"))]:
    f = lambda y: mp.expj(w * y)
    for x in (mp.mpf("-0.8"), mp.mpf("0.5")):
        check(f"T_z e^(iwx) at x={x}, z={mp.nstr(zz,3)}", mehler(f, zz, x),
              mp.exp(1j * zz * w * x - (1 - zz * zz) * w * w / 2), mp.mpf(10) ** -15)
for (zz, w, rho, r, n) in [(0.6 * mp.expj(0.7), mp.mpf("0.9"), mp.mpf("0.5"), mp.mpf(2), 3),
                           (0.3 * mp.expj(1.4), mp.mpf("0.5"), mp.mpf("0.3"), mp.mpf(3), 4)]:
    u, v = mp.re(zz), mp.im(zz)
    h = lambda x: abs(mp.exp(1j * zz * w * x - (1 - zz * zz) * w * w / 2)) ** r
    Qn = r * (1 + (n - 1) * rho)
    check(f"n-fold plane-wave moment, n={n}", nested(h, n, rho),
          mp.exp(n * r * w * w / 2 * ((Qn - 1) * v * v + u * u - 1)), mp.mpf(10) ** -15)

print("(5) Phi_m > 0 <=> F2 > (2(m-1)(1-rho)/m) F1 when delta > 0")
cnt = bad = 0
random.seed(11)
for _ in range(4000):
    zz = mp.mpf(random.uniform(0, 0.999)) * mp.expj(random.uniform(0, mp.pi / 2))
    rho, r, m = mp.mpf(random.uniform(0.05, 0.95)), mp.mpf(random.uniform(2, 6)), random.randint(2, 12)
    lam = 1 + (m - 1) * rho
    Q = r * lam
    ph, d = Phi_m(zz, rho, r, m)
    if d <= 0:
        continue
    F1 = Q * (1 - abs(zz) ** 4) - (Q - 2) * abs(1 - zz * zz) ** 2
    F2 = (Q - 2) ** 2 * abs(1 - zz * zz) ** 2 - Q * Q * (1 - abs(zz) ** 2) ** 2
    lhs = ph > 0
    rhs = F2 > 2 * (m - 1) * (1 - rho) / m * F1
    cnt += 1
    if lhs != rhs and abs(ph) > mp.mpf(10) ** -20:
        bad += 1
    alt = (m / lam) * (F2 / (4 * F1) - mp.mpf(1) / 2) + mp.mpf(1) / 2
    if abs(alt - ph) > mp.mpf(10) ** -20 * (1 + abs(ph)):
        bad += 1
print(f"  {'ok ' if bad == 0 else 'FAIL'} {cnt} points with delta>0, {bad} mismatches")
if bad:
    fails.append("(5)")

print("(6) exact identities for F1, F2 (sympy)")
x, y, Q = sp.symbols("x y Q", real=True)
zs = x + sp.I * y
abs2 = lambda e: sp.expand(e * sp.conjugate(e))
S2 = abs2(1 - zs ** 2)
F1s = Q * (1 - (x * x + y * y) ** 2) - (Q - 2) * S2
F2s = (Q - 2) ** 2 * S2 - Q ** 2 * (1 - x * x - y * y) ** 2
id1 = sp.expand(F2s - (4 * Q ** 2 * y ** 2 - 4 * (Q - 1) * S2))
id2 = sp.expand(F1s - (2 * Q * (sp.re(sp.expand(zs ** 2)) - (x * x + y * y) ** 2) + 2 * S2))
id3 = sp.expand(S2 - ((1 - x * x - y * y) ** 2 + 4 * y * y))
for nm, e in [("F2 = 4Q^2 y^2 - 4(Q-1)|1-z^2|^2", id1), ("F1 = 2Q(Re z^2-|z|^4) + 2|1-z^2|^2", id2),
              ("|1-z^2|^2 = (1-|z|^2)^2 + 4y^2", id3)]:
    ok = sp.simplify(e) == 0
    print(f"  {'ok ' if ok else 'FAIL'} {nm}")
    if not ok:
        fails.append(nm)

print("(7) many-function limit of Phi_n at z = x + i eta / sqrt(Q_n)")
for (rho, r, xx, eta) in [(0.5, 2, 0.5, 0.85), (0.5, 2, 0.7, 0.6), (0.3, 3, 0.4, 0.95), (0.7, 4, 0.6, 0.9)]:
    rho, r, xx, eta = mp.mpf(rho), mp.mpf(r), mp.mpf(xx), mp.mpf(eta)
    a = 1 - xx * xx
    lim = (1 / rho) * ((eta ** 2 - a * a) / (2 * xx * xx * a) - mp.mpf(1) / 2) + mp.mpf(1) / 2
    n = 10 ** 9
    Qn = r * (1 + (n - 1) * rho)
    ph, d = Phi_m(xx + 1j * eta / mp.sqrt(Qn), rho, r, n)
    check(f"rho={rho}, r={r}, x={xx}, eta={eta}: Phi_n(n=1e9) vs limit {mp.nstr(lim,6)} "
          f"(threshold eta^2={mp.nstr(a*(1-rho*xx*xx),5)}, sign {'+' if lim > 0 else '-'})", ph, lim, mp.mpf(10) ** -6)

print()
print("ALL CHECKS PASSED" if not fails else f"FAILURES: {fails}")
