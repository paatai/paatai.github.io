"""Ray scan of the corrected joint narrow-bump test (joint_bump_lib.py), real and oscillating bumps, compared with
the proven inner bound and the local outer bound (exploratory, floating point)."""
import numpy as np
from scipy.optimize import minimize

from joint_bump_lib import joint_excess, single_excess
from two_function_regions import N_pred, S1_pred, S2_pred, radius


def joint_best(z, rho, r, rng, osc, nstart=40):
    def F(x):
        B1, B2 = np.exp(np.clip(x[0], -7, 14)), np.exp(np.clip(x[1], -7, 14))
        t1, t2 = np.cos(x[2]), np.sin(x[2])
        O1, O2 = (x[3], x[4]) if osc else (0.0, 0.0)
        return joint_excess(z, B1, t1, O1, B2, t2, O2, rho, r)
    best = -np.inf
    for _ in range(nstart):
        x0 = np.array([rng.uniform(-3, 8), rng.uniform(-3, 8), rng.uniform(0, 2 * np.pi),
                       rng.normal() * 1.5, rng.normal() * 1.5])
        v = F(x0)
        if v == np.inf:
            return np.inf
        if v == -np.inf:
            continue
        res = minimize(lambda x: 1e3 if not np.isfinite(F(x)) else -F(x), x0, method="Nelder-Mead",
                       options={"maxiter": 3000, "xatol": 1e-10, "fatol": 1e-14})
        best = max(best, -res.fun if res.fun < 1e3 else v)
        if best > 1e-11:
            return best
    return best


def single_best(z, r, osc):
    best = -np.inf
    for B in np.geomspace(1e-2, 1e5, 120):
        for Om in (np.linspace(-3, 3, 31) if osc else [0.0]):
            best = max(best, single_excess(z, B, 1.0, Om, r))
    return best


def bisect(ok, alpha, lo, hi, steps=24):
    if ok(hi * np.exp(1j * alpha)):
        return hi
    for _ in range(steps):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if ok(mid * np.exp(1j * alpha)) else (lo, mid)
    return lo


if __name__ == "__main__":
    rng = np.random.default_rng(2)
    for (rho, r) in [(0.5, 4.0), (0.5, 2.0), (0.3, 4.0), (0.7, 3.0)]:
        Q = r * (1 + rho)
        print(f"rho={rho}, r={r} (p = oo): proven inner bound Omega_Q, Q = r(1+rho) = {Q}")
        print("   arg z   r_inner   inner ok?(real/osc)  r_joint_real  r_joint_osc  r_single_osc  r_N(p=oo)")
        for alpha in [0.3, 0.6, 0.9, 1.2, np.pi / 2 - 1e-3]:
            a = radius(S2_pred(rho, 1e9, r), alpha)
            zin = a * 0.999 * np.exp(1j * alpha)
            okr = joint_best(zin, rho, r, rng, False) <= 1e-11
            oko = joint_best(zin, rho, r, rng, True) <= 1e-11
            er = bisect(lambda zz: joint_best(zz, rho, r, rng, False) <= 1e-11, alpha, a * 0.999, 1.0)
            eo = bisect(lambda zz: joint_best(zz, rho, r, rng, True) <= 1e-11, alpha, a * 0.999, er)
            so = radius(lambda zz: single_best(zz, r, True) <= 1e-11, alpha)
            nn = radius(N_pred(rho, 1e6, r), alpha)
            print(f"   {alpha:5.3f}  {a:.5f}   {okr}/{oko}           {er:.5f}       {eo:.5f}      {so:.5f}"
                  f"       {nn:.5f}", flush=True)
