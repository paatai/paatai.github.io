#!/usr/bin/env python3
"""Colour figure for the paper: which section proves which part of the results.

Produces ``fig_sections.pdf`` (and ``.png``), a 2x2 panel:

  (a) imaginary-axis threshold for equally weighted functions, coloured by the
      binding constraint (Section 6);
  (b) the complex z-plane for (rho,r)=(1/2,2), Q=3: proved inner region, the
      undetermined gap, and the region excluded by joint bumps (Sections 8-10);
  (c) the same for (rho,r)=(1/2,4), Q=6, with the one-function region;
  (d) the n-function asymptotic profiles (Section 11).

Pure floating point; no external data.  Run: ``python3 make_figure.py``.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.lines import Line2D

# ---------- region predicates (floating point) ----------

def omega_q(z, q):
    """z in Omega_{q,q} cap D:  |q-2| |1-z^2| <= q (1-|z|^2)."""
    return abs(q - 2.0) * abs(1 - z * z) <= q * (1 - abs(z) ** 2)

def F1(z, Q):
    return Q * (1 - abs(z) ** 4) - (Q - 2) * abs(1 - z * z) ** 2

def F2(z, Q):
    return (Q - 2) ** 2 * abs(1 - z * z) ** 2 - Q ** 2 * (1 - abs(z) ** 2) ** 2

def in_J(z, rho, Q):
    f1, f2 = F1(z, Q), F2(z, Q)
    if f1 < 0:
        return False
    if f1 > 0:
        return f2 <= (1 - rho) * f1
    return f2 <= 0.0

def omega_ab(z, a, b):
    """Scalar z in Omega_{a,b}: diag(a-1,1) - R^T diag(b-1,1) R >= 0,
    R = [[xi,-eta],[eta,xi]] the matrix of multiplication by z."""
    xi, eta = z.real, z.imag
    m11 = (a - 1) - ((b - 1) * xi * xi + eta * eta)
    m22 = 1 - ((b - 1) * eta * eta + xi * xi)
    off = -xi * eta * (2 - b)
    det = m11 * m22 - off * off
    return (m11 >= -1e-14) and (m22 >= -1e-14) and (det >= -1e-14)

def in_N(z, rho, p, r, M=40):
    for m in range(1, M + 1):
        zm = z ** m
        for sgn in (+1.0, -1.0):
            a = p * (1 + sgn * rho ** m)
            b = r * (1 + sgn * rho ** m)
            if not omega_ab(zm, a, b):
                return False
    return True

# ---------- panels ----------

def panel_a(ax):
    rho, p = 0.5, 10.0
    rs = np.linspace(0.3, 12.0, 1400)
    one = np.ones_like(rs)
    Pm1 = (p * (1 - rho) - 1) * one          # P - 1
    Qinv = 1.0 / (r_arr(rs) * (1 + rho) - 1)  # (Q-1)^{-1}
    thr = np.minimum.reduce([one, Pm1, np.where(r_arr(rs) * (1 + rho) > 1, Qinv, np.inf)])
    # colour by which constraint is binding
    binders = np.argmin(np.vstack([one, Pm1, np.where(r_arr(rs) * (1 + rho) > 1, Qinv, 1e9)]), axis=0)
    cols = {0: "#1b7837", 1: "#2166ac", 2: "#b2182b"}
    labs = {0: r"$y^2\leq1$ (new for $r<2$)", 1: r"$y^2\leq P-1$", 2: r"$y^2\leq(Q-1)^{-1}$"}
    for key in (0, 1, 2):
        mask = binders == key
        ax.scatter(rs[mask], thr[mask], s=6, color=cols[key], label=labs[key])
    ax.axvline(p, color="0.6", ls=":", lw=0.8)
    ax.set_xlabel(r"outer exponent $r$ (with $p=10$)")
    ax.set_ylabel(r"$y^2_{\max}$")
    ax.set_title(r"(a) Imaginary axis, equal parameters ($\rho=\frac{1}{2}$)", fontsize=9)
    ax.set_ylim(0, 1.15)
    ax.legend(fontsize=6.5, loc="upper right", framealpha=0.9)

def r_arr(rs):
    return rs

def disk_panel(ax, rho, r, p, star, star_label, title, show_omega_r):
    Q = r * (1 + rho)
    N = 620
    g = np.linspace(-1, 1, N)
    XX, YY = np.meshgrid(g, g)
    Z = XX + 1j * YY
    img = np.zeros((N, N, 3))
    inside = abs(Z) < 1 - 1e-9
    for i in range(N):
        for j in range(N):
            if not inside[i, j]:
                img[i, j] = (1, 1, 1)
                continue
            z = Z[i, j]
            if omega_q(z, Q):
                img[i, j] = (0.74, 0.89, 0.74)          # green: proved inner
            elif in_J(z, rho, Q) and (r <= 2 or omega_q(z, r)):
                img[i, j] = (0.99, 0.95, 0.70)          # yellow: undetermined gap
            else:
                img[i, j] = (0.96, 0.78, 0.76)          # red: excluded
    ax.imshow(img, extent=[-1, 1, -1, 1], origin="lower")
    th = np.linspace(0, 2 * np.pi, 400)
    ax.plot(np.cos(th), np.sin(th), color="0.3", lw=0.8)
    if show_omega_r:
        # boundary of Omega_r (one-function region), r>2
        bx, by = [], []
        for ang in np.linspace(0, 2 * np.pi, 1600):
            lo, hi = 0.0, 1.0
            for _ in range(60):
                mid = 0.5 * (lo + hi)
                if omega_q(mid * np.exp(1j * ang), r):
                    lo = mid
                else:
                    hi = mid
            bx.append(lo * np.cos(ang)); by.append(lo * np.sin(ang))
        ax.plot(bx, by, color="#6a3d9a", lw=1.1, ls="--", label=r"$\partial\Omega_r$")
        ax.legend(fontsize=7, loc="lower left", framealpha=0.9)
    ax.plot([star.real], [star.imag], marker="*", color="k", ms=11)
    ax.annotate(star_label, (star.real, star.imag), textcoords="offset points",
                xytext=(6, 6), fontsize=8)
    ax.set_xlim(-1, 1); ax.set_ylim(-1, 1)
    ax.set_xlabel(r"$\Re z$"); ax.set_ylabel(r"$\Im z$")
    ax.set_title(title, fontsize=9)

def panel_d(ax):
    rho, r = 0.5, 2.0
    xs = np.linspace(-1, 1, 400)
    a = 1 - xs ** 2
    inner = a                                   # |eta| = 1 - x^2
    plane = np.sqrt(np.clip(a, 0, None))        # |eta| = sqrt(1-x^2)
    xth2 = (r - 1) / (r - rho)
    outer = np.where(xs ** 2 < xth2, np.sqrt(np.clip(a * (1 - rho * xs ** 2), 0, None)), np.nan)
    ax.fill_between(xs, 0, inner, color="#74e274", alpha=0.5, label=r"proved admissible ($|\eta|\leq1-x^2$)")
    ax.fill_between(xs, inner, plane, color="#fff0b3", alpha=0.8)
    ax.plot(xs, inner, color="#1b7837", lw=1.4, label=r"inner profile")
    ax.plot(xs, outer, color="#e08214", lw=1.4, label=r"joint-bump outer")
    ax.plot(xs, plane, color="#b2182b", lw=1.2, ls="--", label=r"plane-wave outer $\sqrt{1-x^2}$")
    ax.set_xlabel(r"$x=\Re z$"); ax.set_ylabel(r"$|\eta|=\sqrt{Q_n}\,|\Im z|$")
    ax.set_title(r"(d) $n\to\infty$ profiles at scale $Q_n^{-1/2}$ ($\rho=\frac{1}{2},\,r=2$)", fontsize=9)
    ax.set_xlim(-1, 1); ax.set_ylim(0, 1.05)
    ax.legend(fontsize=6.5, loc="lower center", framealpha=0.9)

def main():
    fig, axes = plt.subplots(2, 2, figsize=(10.2, 9.2))
    panel_a(axes[0, 0])
    disk_panel(axes[0, 1], 0.5, 2.0, np.inf,
               (171 / 200) * np.exp(1j * 3 / 5), "(J1)",
               r"(b) $z$-plane, $\rho=\frac{1}{2}$, $r=2$, $Q=3$", show_omega_r=False)
    disk_panel(axes[1, 0], 0.5, 4.0, np.inf,
               (319 / 500) * np.exp(1j * 3 / 5), "(J2)",
               r"(c) $z$-plane, $\rho=\frac{1}{2}$, $r=4$, $Q=6$", show_omega_r=True)
    panel_d(axes[1, 1])
    legend_elems = [
        Patch(facecolor=(0.74, 0.89, 0.74), label=r"proved admissible: $\Omega_Q$ (Sec. 10, inner bound)"),
        Patch(facecolor=(0.99, 0.95, 0.70), label=r"undetermined gap $\mathcal{J}\cap\Omega_r\setminus\Omega_Q$ (open)"),
        Patch(facecolor=(0.96, 0.78, 0.76), label=r"excluded by joint bumps / plane waves (Sec. 10, 12)"),
        Line2D([0], [0], color="#6a3d9a", ls="--", label=r"$\partial\Omega_r$ (one-function region, Sec. 8)"),
        Line2D([0], [0], marker="*", color="k", ls="", label=r"certified failure point (Sec. 13)"),
    ]
    fig.legend(handles=legend_elems, loc="lower center", ncol=3, fontsize=7.5,
               bbox_to_anchor=(0.5, -0.01), framealpha=0.95)
    fig.suptitle("Which section proves which part of the results", fontsize=12, y=0.995)
    fig.tight_layout(rect=[0, 0.045, 1, 0.985])
    fig.savefig("fig_sections.pdf")
    fig.savefig("fig_sections.png", dpi=150)
    print("wrote fig_sections.pdf and fig_sections.png")

if __name__ == "__main__":
    main()
