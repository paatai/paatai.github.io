"""Converse within the equal-bump family (Remark 10.9 of the accompanying paper); floating point, evidence only.

For z in the gap between Omega_Q and J (delta_Q > 0, F2 > 0 >= Phi), check over a log grid of widths B that equal
narrow bumps never win at the level of the t^2-exponent:
  (a) 1 + mu_B (1 +- rho) > 0  (otherwise J = infinity at that B, a win), and
  (b) R_J(B) <= 0, with R_J from the joint-bump lower bound (Lemma 10.3 of the accompanying paper).
Points: rho in (0.05, 0.95), r in [2, 6], arg z uniform in (0.02, pi/2 - 0.02), |z| uniform between the radius of
Omega_Q and the radius of J on that ray.
"""
import numpy as np

rng = np.random.default_rng(2026)


def kd(z, q):
    s = 1 - z * z
    A = (1 / s).real
    C = (z / s).real
    d = 1 - q + q * A
    return -A / 2 + 1 / (2 * q) + q * C * C / (2 * d), d


def Phi(z, rho, r):
    Q = r * (1 + rho)
    k, d = kd(z, Q)
    return 2 * r * k - (1 - rho) / (2 * (1 + rho)), d


def in_omega(z, q):
    return abs(q - 2) * abs(1 - z * z) <= q * (1 - abs(z) ** 2)


def bisect(pred_good, alpha):
    lo, hi = 0.0, 0.999999
    if pred_good(hi * np.exp(1j * alpha)):
        return hi
    for _ in range(60):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if pred_good(mid * np.exp(1j * alpha)) else (lo, mid)
    return lo


def R_J(B, z, rho, r):
    s = 1 - z * z
    D = 1 + s * B
    mu = r * B * (z * z / D).real
    nu = r * (z / D).real
    cp, cm = 1 + mu * (1 + rho), 1 + mu * (1 - rho)
    val = -r / B + r * (s / D).real + (1 + rho) * nu ** 2 / cp + 1 / (2 * B * (1 + B))
    return val, min(cp, cm)


Bs = np.logspace(-4, 7, 2000)
n_pts, n_win, worst, worst_pt = 0, 0, -np.inf, None
while n_pts < 4000:
    rho = rng.uniform(0.05, 0.95)
    r = rng.uniform(2.0, 6.0)
    alpha = rng.uniform(0.02, np.pi / 2 - 0.02)
    Q = r * (1 + rho)

    def J_good(z):
        ph, d = Phi(z, rho, r)
        return d > 0 and ph <= 0

    rin = bisect(lambda z: in_omega(z, Q), alpha)
    rout = bisect(J_good, alpha)
    if rout <= rin + 1e-9:
        continue
    R = rng.uniform(rin, rout)
    z = R * np.exp(1j * alpha)
    ph, d = Phi(z, rho, r)
    if not (d > 0 and ph <= 0) or in_omega(z, Q):
        continue
    n_pts += 1
    vals = [R_J(B, z, rho, r) for B in Bs]
    if any(c <= 0 for _, c in vals) or any(v > 0 for v, _ in vals):
        n_win += 1
    m = max(B * B * v for (v, _), B in zip(vals, Bs))
    if m > worst:
        worst, worst_pt = m, (rho, r, z, ph)

print(f"points in the gap Omega_Q < |z| < J: {n_pts}; points where some B in [1e-4, 1e7] wins: {n_win}")
print(f"largest B^2 R_J(B) over all points and B: {worst:.4e} at (rho, r, z, Phi) = {worst_pt}")
print("CONVERSE HOLDS ON THE SAMPLE" if n_win == 0 else "COUNTEREXAMPLE FOUND")
