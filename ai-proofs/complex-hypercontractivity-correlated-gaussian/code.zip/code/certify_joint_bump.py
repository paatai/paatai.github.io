"""Two rho-correlated functions below the diagonal: joint narrow bumps (certificates for Corollary 10.8 of the
accompanying paper).

Setting.  (X, Y) rho-correlated standard Gaussians on R, varsigma = 1 - z^2, |z| < 1, T_z the Mehler transform.
For B > 0, t > 0: b(x) = exp(-B x^2/2 + t x - t^2/(2B)) in (0, 1], f = 1 - 2b (|f| <= 1).  With
D = 1 + varsigma B, beta' = -B z^2/D, eta' = t z/D and c = D^{-1/2} exp(-t^2/(2B) + varsigma t^2/(2D)),
    T_z b(x) = c exp(beta' x^2/2 + eta' x).
Every quantity below is an explicit Gaussian integral G(al1, al2, ga1, ga2) = E exp(al1 X^2/2 + al2 Y^2/2 + ga1 X +
ga2 Y) = det(I - Sigma A)^{-1/2} exp(gamma^T (Sigma^-1 - A)^-1 gamma / 2), valid (principal branch) when
Re(Sigma^-1 - A) is positive definite (checked in ball arithmetic):
    Eb, S_r = E|T b|^r, J_r = E|T b(X)|^r |T b(Y)|^r, P = E[T b(X) T b(Y)], Pc = E[T b(X) conj T b(Y)],
    R = E[T b(X) |T b(Y)|^2].
r = 2 (exact):  E|T f(X) T f(Y)|^2 = 1 - 8 Eb + 8 S_2 + 8 Re(P + Pc) - 32 Re R + 16 J_2.
r >= 2 (lower bound, bump inequality |1+w|^r >= 1 + r Re w + 2^{1-r}|w|^r):
    E|T f(X) T f(Y)|^r >= 1 + r(-4 Eb + 4 Re P) + 4 J_r - 2^{r+1} S_r.
Since |f| <= 1, ||f(X) f(Y)||_p <= 1 for every p, so a value > 1 refutes the two-function inequality
||T_z f(X) T_z g(Y)||_r <= ||f(X) g(Y)||_p for every p in [1, oo].

Part A (floating point, mpmath): the closed forms against direct quadrature at moderate parameters.
Part B (Arb, python-flint): two instances, each with
  (i)   all second-order (local) conditions of the two-function inequality for every p >= 10:
        z^m in Omega_{p(1 +- rho^m), r(1 +- rho^m)} for all m >= 1 (explicit 2x2 checks for m <= 2, tail bound);
  (ii)  the one-function condition z in Omega_{r,r} (for r = 2: |z| < 1);
  (iii) the hypotheses delta_Q > 0, Phi > 0 of the asymptotic theorem (Q = r(1+rho));
  (iv)  an explicit witness (B, t) with E|T f(X) T f(Y)|^r > 1.
  (J1) rho = 1/2, r = 2, z = (171/200) e^{3i/5};   (J2) rho = 1/2, r = 4, z = (319/500) e^{3i/5}.
"""
import time

import mpmath as mp
from flint import acb, arb, ctx

t0 = time.time()


# ---------------------------------------------------------------- closed forms (Arb) ---------------------------
def G2(al1, al2, ga1, ga2, rho):
    """E exp(al1 X^2/2 + al2 Y^2/2 + ga1 X + ga2 Y); asserts Re(Sigma^-1 - A) > 0."""
    k = 1 / (1 - rho * rho)
    m11, m22, m12 = k - al1, k - al2, -rho * k
    assert m11.real > 0 and (m11.real * m22.real - m12.real ** 2) > 0, "Re(Sigma^-1 - A) not positive definite"
    detM = m11 * m22 - m12 * m12
    detIA = detM * (1 - rho * rho)          # det(I - Sigma A) = det(Sigma) det(Sigma^-1 - A)
    quad = (m22 * ga1 * ga1 - 2 * m12 * ga1 * ga2 + m11 * ga2 * ga2) / detM
    return (quad / 2).exp() / detIA.sqrt()


def G1(al, ga):
    assert (1 - al).real > 0
    return (ga * ga / (2 * (1 - al))).exp() / (1 - al).sqrt()


def bump_data(z, B, t, rho, r):
    s = 1 - z * z
    D = 1 + s * B
    bp = -B * z * z / D
    ep = t * z / D
    c = (-t * t / (2 * B) + s * t * t / (2 * D)).exp() / D.sqrt()
    absc = abs(c)
    Eb = G1(acb(-B), acb(t)) * (-t * t / (2 * B)).exp()
    rb, re_ = bp.real, ep.real
    S = absc ** r * G1(acb(r * rb), acb(r * re_))
    J = absc ** (2 * r) * G2(acb(r * rb), acb(r * rb), acb(r * re_), acb(r * re_), rho)
    P = c * c * G2(bp, bp, ep, ep, rho)
    Pc = c * c.conjugate() * G2(bp, bp.conjugate(), ep, ep.conjugate(), rho)
    R = c * absc ** 2 * G2(bp, acb(2 * rb), ep, acb(2 * re_), rho)
    return dict(Eb=Eb.real, S=S.real, J=J.real, P=P, Pc=Pc, R=R, c=c, bp=bp, ep=ep)


def exact_r2(d):
    return 1 - 8 * d["Eb"] + 8 * d["S"] + 8 * (d["P"] + d["Pc"]).real - 32 * d["R"].real + 16 * d["J"]


def lower_bound(d, r):
    return 1 + r * (-4 * d["Eb"] + 4 * d["P"].real) + 4 * d["J"] - 2 ** (r + 1) * d["S"]


def kappa_delta(z, q):
    s = 1 - z * z
    A = (1 / s).real
    C = (z / s).real
    delta = 1 - q + q * A
    return -A / 2 + arb(1) / (2 * q) + q * C * C / (2 * delta), delta, A, C


def Phi(z, rho, r):
    Q = r * (1 + rho)
    k, d, A, C = kappa_delta(z, Q)
    return 2 * r * k - (1 - rho) / (2 * (1 + rho)), d


# ---------------------------------------------------------------- Part A ----------------------------------------
def part_A():
    print("Part A: closed forms vs direct quadrature (mpmath, 25 digits)")
    mp.mp.dps = 25
    ctx.prec = 200
    ok = True
    for (zr, th, B, t, rho, r) in [(0.7, 0.6, 2.0, 1.3, 0.5, 2), (0.6, 1.0, 1.5, -0.9, 0.3, 4)]:
        zc = mp.mpf(zr) * mp.expj(th)
        sc = 1 - zc ** 2
        b = lambda y: mp.exp(-B * y * y / 2 + t * y - t * t / (2 * B))
        Tb_quad = lambda x: mp.quad(lambda y: mp.exp(-(y - zc * x) ** 2 / (2 * sc)) * b(y), [-mp.inf, 0, mp.inf]) \
            / mp.sqrt(2 * mp.pi * sc)
        za = acb(zr) * acb(0, th).exp()
        d = bump_data(za, arb(B), arb(t), arb(rho), r)
        c, bp, ep = [mp.mpc(v.real.mid().str(40, radius=False), v.imag.mid().str(40, radius=False))
                     for v in (d["c"], d["bp"], d["ep"])]
        Tb = lambda x: c * mp.exp(bp * x * x / 2 + ep * x)
        e_T = max(abs(Tb_quad(x) / Tb(x) - 1) for x in (-1.1, 0.3, 1.7))
        dens = lambda x, y: mp.exp(-(x * x - 2 * rho * x * y + y * y) / (2 * (1 - rho * rho))) / \
            (2 * mp.pi * mp.sqrt(1 - rho * rho))
        E2 = lambda F: mp.quad(lambda x, y: F(x, y) * dens(x, y), [-mp.inf, 0, mp.inf], [-mp.inf, 0, mp.inf])
        phi = lambda x: mp.exp(-x * x / 2) / mp.sqrt(2 * mp.pi)
        E1 = lambda F: mp.quad(lambda x: F(x) * phi(x), [-mp.inf, 0, mp.inf])
        checks = {
            "Eb": (E1(b), float(d["Eb"].mid())),
            "S_r": (E1(lambda x: abs(Tb(x)) ** r), float(d["S"].mid())),
            "J_r": (E2(lambda x, y: abs(Tb(x)) ** r * abs(Tb(y)) ** r), float(d["J"].mid())),
            "P": (E2(lambda x, y: Tb(x) * Tb(y)), complex(float(d["P"].real.mid()), float(d["P"].imag.mid()))),
            "Pc": (E2(lambda x, y: Tb(x) * mp.conj(Tb(y))),
                   complex(float(d["Pc"].real.mid()), float(d["Pc"].imag.mid()))),
            "R": (E2(lambda x, y: Tb(x) * abs(Tb(y)) ** 2),
                  complex(float(d["R"].real.mid()), float(d["R"].imag.mid()))),
        }
        if r == 2:
            checks["E|Tf Tf|^2"] = (E2(lambda x, y: abs(1 - 2 * Tb(x)) ** 2 * abs(1 - 2 * Tb(y)) ** 2),
                                    float(exact_r2(d).mid()))
        print(f"  z={zr}e^({th}i), B={B}, t={t}, rho={rho}, r={r}: Mehler closed form rel.err {mp.nstr(e_T, 3)}")
        ok = ok and e_T < 1e-15
        for k, (qv, cv) in checks.items():
            err = abs(qv - cv) / max(abs(qv), 1e-30)
            ok = ok and err < 1e-10
            print(f"     {k:11s} quadrature {mp.nstr(qv, 12):>28s}  closed form {cv!s:>28s}  rel.err {mp.nstr(err, 2)}")
    # Mehler closed form at the witness parameters of (J1): B = 60, t = 1000, z = 0.855 e^{0.6 i}
    mp.mp.dps = 100
    ctx.prec = 400
    B, t = 60, 1000
    zc = mp.mpf(171) / 200 * mp.expj(mp.mpf(3) / 5)
    sc = 1 - zc ** 2
    za = (arb(171) / 200) * acb(0, arb(3) / 5).exp()
    d = bump_data(za, arb(B), arb(t), arb("0.5"), 2)
    c, bp, ep = [mp.mpc(v.real.mid().str(95, radius=False), v.imag.mid().str(95, radius=False))
                 for v in (d["c"], d["bp"], d["ep"])]
    y0 = mp.mpf(t) / B
    errs = []
    for xx in (mp.mpf(0), mp.mpf(20), mp.mpf(40)):
        quad = mp.quad(lambda y: mp.exp(-(y - zc * xx) ** 2 / (2 * sc) - B * (y - y0) ** 2 / 2),
                       [y0 - 3, y0 - 1, y0, y0 + 1, y0 + 3]) / mp.sqrt(2 * mp.pi * sc)
        closed = c * mp.exp(bp * xx * xx / 2 + ep * xx)
        errs.append(abs(quad / closed - 1))
    err_w = max(errs)
    okw = err_w < 1e-40
    print(f"  witness (J1) parameters: Mehler closed form vs quadrature at x = 0, 20, 40: max rel.err "
          f"{mp.nstr(err_w, 3)}  {'ok' if okw else 'FAIL'}")
    ok = ok and okw
    print(f"  Part A {'PASSED' if ok else 'FAILED'}")
    return ok


# ---------------------------------------------------------------- Part B ----------------------------------------
def omega_psd(w, a, b):
    """certify |w u|_b^2 <= |u|_a^2 for all u (2x2 PSD test of M_a - Z^T M_b Z), returns (ok, det, diag)."""
    x, y = w.real, w.imag
    # u = (u1, u2) ~ u1 + i u2;  w u = (x u1 - y u2) + i (y u1 + x u2)
    # |w u|_b^2 = (b-1)(x u1 - y u2)^2 + (y u1 + x u2)^2
    m11 = (a - 1) - ((b - 1) * x * x + y * y)
    m22 = 1 - ((b - 1) * y * y + x * x)
    m12 = -(-(b - 1) * x * y + x * y)
    det = m11 * m22 - m12 * m12
    return (m11 > 0 and m22 > 0 and det > 0), det, (m11, m22)


def local_conditions(z, rho, r, p0=10):
    Q = r * (1 + rho)
    ok = True
    for m in (1, 2):
        w = z ** m
        for sg in (1, -1):
            a = p0 * (1 + sg * rho ** m)
            b = r * (1 + sg * rho ** m)
            good, det, diag = omega_psd(w, a, b)
            ok = ok and good
            print(f"     m={m}, sign {'+' if sg > 0 else '-'}: a={float(a.mid()):g}, b={float(b.mid()):g}: "
                  f"det={float(det.mid()):.6e}, diag=({float(diag[0].mid()):.4e}, {float(diag[1].mid()):.4e})  {good}")
    # tail m >= 3: |z|^{2m} max(b - 1, 1) <= |z|^6 (Q - 1) <= 1 = min(a - 1, 1) since a - 1 >= p0(1-rho^3) - 1 >= 1
    tail = abs(z) ** 6 * (Q - 1)
    amin = p0 * (1 - rho ** 3) - 1
    good = tail < 1 and amin > 1
    ok = ok and good
    print(f"     m>=3: |z|^6 (Q-1) = {float(tail.mid()):.6f} < 1 and p0(1-rho^3)-1 = {float(amin.mid()):.3f} >= 1: {good}")
    print("     (Omega_{a,b} increases with a, so the same holds for every p >= p0)")
    return ok


def instance(name, rho, r, zabs, theta, B, t, prec):
    """zabs, theta given as (numerator, denominator); the inputs are exact rationals."""
    ctx.prec = prec
    print(f"\n({name}) rho={rho}, r={r}, z=({zabs[0]}/{zabs[1]}) e^(({theta[0]}/{theta[1]}) i), B={B}, t={t}, "
          f"precision {prec} bits")
    z = (arb(zabs[0]) / zabs[1]) * acb(0, arb(theta[0]) / theta[1]).exp()
    rho = arb(rho)
    Q = r * (1 + rho)
    ok = True
    print("  (i) second-order conditions for every p >= 10:")
    ok = local_conditions(z, rho, r) and ok
    if r == 2:
        good = abs(z) < 1
        print(f"  (ii) one-function condition: |z| = {float(abs(z).mid())} < 1 (T_z: L^p -> L^2 contraction, p >= 2): {good}")
    else:
        val = r * (1 - abs(z) ** 2) - (r - 2) * abs(1 - z * z)
        good = val > 0
        print(f"  (ii) one-function condition z in Omega_r: r(1-|z|^2) - (r-2)|1-z^2| = {float(val.mid()):.6e} > 0: {good}")
    ok = ok and good
    ph, dl = Phi(z, rho, r)
    s = 1 - z * z
    lhs = (Q - 2) ** 2 * abs(s) ** 2 - Q ** 2 * (1 - abs(z) ** 2) ** 2
    rhs = 2 * (1 - rho) * ((1 - Q) * abs(s) ** 2 + Q * s.real)
    good = ph > 0 and dl > 0 and lhs > rhs
    print(f"  (iii) delta_Q = {float(dl.mid()):.6f} > 0, Phi = 2r kappa_Q - (1-rho)/(2(1+rho)) = {float(ph.mid()):.6e} > 0;")
    print(f"        explicit form: (Q-2)^2|s|^2 - Q^2(1-|z|^2)^2 = {float(lhs.mid()):.6e} > 2(1-rho)[(1-Q)|s|^2 + Q Re s]"
          f" = {float(rhs.mid()):.6e}: {good}")
    ok = ok and good
    k_, d_, A, C = kappa_delta(z, Q)
    E = C * C / A - A + 1
    good = Q * E < 1
    print(f"  (iii') Schur-Hoelder condition at sigma = 1 for exponent Q: Q (C^2/A - A + 1) = {float((Q * E).mid()):.6f}"
          f" < 1: {good}  (so T_z: L^s -> L^Q is bounded for some s < oo; polynomial version for p < oo)")
    ok = ok and good
    d = bump_data(z, arb(B), arb(t), rho, r)
    if r == 2:
        val = exact_r2(d)
        print(f"  (iv) exact E|T f(X) T f(Y)|^2 - 1 = {(val - 1).str(8, radius=True)}")
    else:
        val = lower_bound(d, r)
        print(f"  (iv) lower bound for E|T f(X) T f(Y)|^{r} minus 1 = {(val - 1).str(8, radius=True)}")
    print(f"       [log Eb = {float(d['Eb'].log().mid()):.4f}, log J = {float(d['J'].log().mid()):.4f}, "
          f"log S = {float(d['S'].log().mid()):.4f}, |P|/Eb = {float((abs(d['P']) / d['Eb']).mid()):.3e}]")
    good = val > 1
    print(f"       > 0 (violation certified): {good}")
    ok = ok and good
    print(f"  ({name}) {'CERTIFIED' if ok else 'FAILED'}")
    return ok


if __name__ == "__main__":
    import sys
    okA = True if "--skip-quadrature" in sys.argv else part_A()
    okB1 = instance("J1", 0.5, 2, (171, 200), (3, 5), 60, 1000, 600)
    okB2 = instance("J2", 0.5, 4, (319, 500), (3, 5), 45, 1500, 900)
    print(f"\ntotal time {time.time() - t0:.1f} s")
    assert okA and okB1 and okB2
    print("ALL CERTIFIED")
