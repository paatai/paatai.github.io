"""n equicorrelated functions (Section 11 of the accompanying paper): radii along rays (floating point).

Inequality  || prod_j T_z f_j(xi_j) ||_r <= || prod_j f_j(xi_j) ||_p,  E xi_i xi_j = rho (i != j),  r >= 2.
lambda_m = 1 + (m-1) rho,  Q_m = r lambda_m,  Phi_m = (m/lambda_m)(Q_m kappa_{Q_m} - 1/2) + 1/2.
  inner  Omega_{Q_n}                          (Brascamp-Lieb; p = oo or p(1-rho) >= Q_n)
  outer  PW_n = {(Q_n-1) y^2 + x^2 <= 1}      (plane waves f_j = e^{i w x}; every p)
  outer  JB_n: complement of the union over 2 <= m <= n of the sets where Proposition 11.1 applies at level m,
         intersected with Omega_r (valid since R^(n) is contained in R^(2), which is contained in Omega_r).
The excluded sets need not be star-shaped (a level m switches off once z leaves Omega_{lambda_m}), so an outer radius
along a ray is the LARGEST non-excluded radius, not the first excluded one. We compute it on a grid of 20000 radii,
refined by bisection, and report how many excluded intervals the grid sees ("pieces"; > 1 means re-entry).
"""
import numpy as np

from joint_bump_regions import kappa_delta
from two_function_regions import radius


def in_omega(z, q):
    return abs(q - 2) * abs(1 - z * z) <= q * (1 - abs(z) ** 2)


def phi_delta(z, rho, r, m):
    lam = 1 + (m - 1) * rho
    Q = r * lam
    k, d = kappa_delta(z, Q)
    return (m / lam) * (Q * k - 0.5) + 0.5, d


def jb_excluded(z, rho, r, n):
    """True if Omega_r fails or Proposition 11.1 applies at some level 2 <= m <= n."""
    if not in_omega(z, r):
        return True
    prev = []
    for m in range(2, n + 1):
        lam = 1 + (m - 1) * rho
        if lam > 2 and not in_omega(z, lam):
            return False                 # fails for this and every larger level (Omega_q decreases in q >= 2)
        ph, d = phi_delta(z, rho, r, m)
        if d < 0:
            return True                  # case (i) (delta_{Q_m'} > 0 for m' < m, else we returned earlier)
        if d == 0:
            return False
        if ph > 0 and all(ph > q for q in prev):
            return True                  # case (ii)
        prev.append(ph)
    return False


def pw_excluded(z, rho, r, n):
    Qn = r * (1 + (n - 1) * rho)
    return (Qn - 1) * z.imag ** 2 + z.real ** 2 > 1


def outer_radius(bad, alpha, N=20000):
    """Largest radius R in [0, 1) along the ray with bad(R e^{i alpha}) False; number of excluded pieces."""
    rs = np.linspace(0.0, 0.999999, N + 1)
    flags = np.array([bad(R * np.exp(1j * alpha)) for R in rs])
    pieces = int(np.sum(flags[1:] & ~flags[:-1]) + (1 if flags[0] else 0))
    good = np.where(~flags)[0]
    i = good[-1]
    if i == N:
        return 1.0, pieces
    lo, hi = rs[i], rs[i + 1]
    for _ in range(50):
        mid = (lo + hi) / 2
        lo, hi = (lo, mid) if bad(mid * np.exp(1j * alpha)) else (mid, hi)
    return lo, pieces


if __name__ == "__main__":
    angles = [0.05, 0.1, 0.2, 0.3, 0.6, 0.9, 1.2, np.pi / 2]
    for (rho, r) in [(0.5, 2.0), (0.5, 4.0), (0.3, 3.0)]:
        for n in (2, 3, 5, 10, 30):
            Qn = r * (1 + (n - 1) * rho)
            print(f"rho={rho}, r={r}, n={n}  (Q_n = {Qn:g})")
            print("   arg z   inner Omega_Qn   outer JB_n (pieces)   outer PW_n   outer JB_n and PW_n   PW binding?")
            for a in angles:
                inner = radius(lambda zz: in_omega(zz, Qn), a)
                jb, pc = outer_radius(lambda zz: jb_excluded(zz, rho, r, n), a)
                pw = 1 / np.sqrt((Qn - 1) * np.sin(a) ** 2 + np.cos(a) ** 2)
                both, _ = outer_radius(lambda zz: jb_excluded(zz, rho, r, n) or pw_excluded(zz, rho, r, n), a)
                flag = "  yes" if both < jb - 1e-6 else ""
                print(f"   {a:5.3f}   {inner:.5f}          {jb:.5f} ({pc})           {min(pw, 1.0):.5f}"
                      f"      {both:.5f}{flag}", flush=True)
    print()
    print("Scaled boundary eta = sqrt(Q_n) Im z at fixed Re z = x, large n (rho=0.5, r=2); largest non-excluded eta:")
    print("   n     x     inner     JB_n     PW_n   | (1-x^2)  sqrt((1-x^2)(1-rho x^2))  sqrt(1-x^2)")
    rho, r = 0.5, 2.0
    for n in (100, 1000):
        Qn = r * (1 + (n - 1) * rho)
        for x in (0.2, 0.5, 0.7):
            def vert(bad, N=8000):
                top = np.sqrt(1 - x * x) * 0.999999
                ys = np.linspace(0, top, N + 1)
                flags = np.array([bad(x + 1j * y) for y in ys])
                good = np.where(~flags)[0]
                i = good[-1]
                if i == N:
                    return top
                lo, hi = ys[i], ys[i + 1]
                for _ in range(50):
                    mid = (lo + hi) / 2
                    lo, hi = (lo, mid) if bad(x + 1j * mid) else (mid, hi)
                return lo
            yi = vert(lambda zz: not in_omega(zz, Qn))
            yj = vert(lambda zz: jb_excluded(zz, rho, r, n))
            yp = vert(lambda zz: pw_excluded(zz, rho, r, n))
            s = np.sqrt(Qn)
            print(f"  {n:5d}  {x:.2f}  {s*yi:.5f}  {s*yj:.5f}  {s*yp:.5f}  | {1-x*x:.5f}  "
                  f"{np.sqrt((1-x*x)*(1-rho*x*x)):.5f}                  {np.sqrt(1-x*x):.5f}", flush=True)
