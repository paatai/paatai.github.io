# Numerics for *Complex hypercontractivity for several correlated Gaussian functions below the diagonal*

This directory contains the scripts that accompany the paper (`../paper/main.pdf`).
They fall into two tiers, exactly as the paper states:

- **Proof-grade** scripts use *exact* symbolic algebra (sympy) or *rigorous
  interval / ball arithmetic* (Arb, via `python-flint`). The paper relies on
  these for actual proofs (the algebraic identities and the certified failure
  points of Corollary 10.8).
- **Exploratory** scripts are ordinary floating-point computations. They produce
  the tables of region radii and the converse scans. They are *evidence*, not
  proofs, and are labelled as such wherever they are cited.

Everything here is self-contained: relative paths only, no external data, no
network access.

## Requirements

```
pip install -r requirements.txt
```

The only package that is not pure Python is `python-flint` (a binding for the
FLINT/Arb C libraries); it is needed **only** by `certify_joint_bump.py`. Every
other script runs with just numpy / scipy / mpmath / sympy / matplotlib.

## Running

Run any script from *inside this directory* (a few scripts import the small
shared helpers in `two_function_regions.py`, `joint_bump_regions.py`,
`joint_bump_lib.py`):

```
cd code
python3 check_identities.py
python3 certify_joint_bump.py          # ~8 minutes (see below)
python3 make_figure.py                 # writes fig_sections.pdf and .png here
```

`certify_joint_bump.py` is the slow one: almost all of its runtime is the
two-dimensional `mpmath` quadrature that cross-checks every closed form. To skip
that cross-check and run only the Arb certificates, pass `--skip-quadrature`.

## What each script does

### Proof-grade (exact or ball arithmetic)

| Script | Arithmetic | Paper reference |
| --- | --- | --- |
| `check_identities.py` | exact (sympy) | the polynomial identities of Lemmas 5.1–5.2 and Section 11 (seven identities for `F1`, `F2`, `kappa`, `delta`, the Gram matrix `N`) |
| `kappa_identity.py` | exact (sympy) | the identity `kappa(z) <= 0  <=>  z in Omega_{q,q}` behind Lemma 5.1 |
| `certify_joint_bump.py` | ball/exact (Arb) + mpmath cross-check | Corollary 10.8: certifies the two failure points `z = (171/200) e^{3i/5}` (`r=2`) and `z = (319/500) e^{3i/5}` (`r=4`) with rigorous enclosures |

### Exploratory (floating point)

| Script | Paper reference |
| --- | --- |
| `two_function_imaginary.py` | imaginary-axis threshold for a correlated pair (Parts I–II); matches the closed formula to `1e-12` |
| `two_function_regions.py` | inner/outer region radii for two functions (Part II) |
| `two_function_gaussian_test.py` | random-Gaussian stress test of the pair inequality on the imaginary axis |
| `joint_bump_regions.py` | region radii `Omega_Q`, `S1 u S2`, `J`, `Omega_r`, `N(p)` along rays (Part III) |
| `joint_bump_lib.py` | large-deviation exponents for the joint narrow-bump test (shared library) |
| `joint_bump_scan2.py` | ray scan of the joint-bump test with real and oscillating bumps |
| `joint_bump_converse_scan.py` | converse within the equal-bump family (evidence for Remark 10.9) |
| `check_n_function.py` | closed forms, limits, and plane-wave moments for `n` equicorrelated functions (Section 11) |
| `n_function_regions.py` | inner / joint-bump / plane-wave region radii for `n` functions (Section 11) |

### Figure

| Script | Output |
| --- | --- |
| `make_figure.py` | `fig_sections.pdf` / `.png` — Figure 1 of the paper (which section proves which part of the result) |
