"""Radii along rays of the regions in Part III of the accompanying paper (floating point, for the table).

Two-function inequality  || T_z f(X) T_z g(Y) ||_r <= || f(X) g(Y) ||_p,  (X, Y) rho-correlated, r >= 2.
  Omega_Q, Q = r(1+rho)       : proven inner bound for p = oo (Brascamp-Lieb + one-function theorem);
  S1 u S2                      : proven inner bounds for finite p (Part II of the accompanying paper);
  J = {delta_Q > 0, Phi <= 0}  : proven outer bound (joint narrow bumps), Phi = 2 r kappa_Q - (1-rho)/(2(1+rho));
  Omega_r                      : one-function outer bound (p = oo, or any p >= r);
  N(p)                         : all second-order (local) conditions (p = oo is computed as p = 1e9).
The radius of J is the first radius at which delta_Q <= 0 or Phi > 0 (scanned outwards from 0, then bisected).
"""
import numpy as np

from two_function_regions import N_pred, S1_pred, S2_pred, omega_ok, radius


def kappa_delta(z, q):
    s = 1 - z * z
    A = (1 / s).real
    C = (z / s).real
    d = 1 - q + q * A
    return -A / 2 + 1 / (2 * q) + q * C * C / (2 * d), d


def J_bad(z, rho, r):
    Q = r * (1 + rho)
    k, d = kappa_delta(z, Q)
    return d <= 0 or 2 * r * k - (1 - rho) / (2 * (1 + rho)) > 0


def first_cross(bad, alpha, n=4000):
    rs = np.linspace(0, 0.999999, n + 1)
    prev = 0.0
    for x in rs[1:]:
        if bad(x * np.exp(1j * alpha)):
            lo, hi = prev, x
            for _ in range(60):
                mid = (lo + hi) / 2
                lo, hi = (lo, mid) if bad(mid * np.exp(1j * alpha)) else (mid, hi)
            return lo
        prev = x
    return 1.0


if __name__ == "__main__":
    for (rho, p, r) in [(rho_, p_, r_) for p_ in (np.inf, 10.0) for rho_ in (0.3, 0.5, 0.7) for r_ in (2.0, 3.0, 4.0)]:
        Q = r * (1 + rho)
        pp = 1e9 if p == np.inf else p
        print(f"rho={rho}, p={p}, r={r}  (Q = r(1+rho) = {Q:g})")
        print("   arg z   inner Omega_Q   inner S1uS2   outer J   outer Omega_r   outer N(p)")
        for alpha in [0.05, 0.1, 0.2, 0.3, 0.6, 0.9, 1.2, np.pi / 2]:
            a = radius(lambda zz: omega_ok(zz, Q, Q), alpha)
            b = max(radius(S1_pred(rho, pp, r), alpha), radius(S2_pred(rho, pp, r), alpha))
            c = first_cross(lambda zz: J_bad(zz, rho, r), alpha)
            d = radius(lambda zz: omega_ok(zz, r, r), alpha)
            e = radius(N_pred(rho, pp, r), alpha)
            flag = "  <- J not binding (sticks out of Omega_r or N)" if c > min(d, e) + 1e-6 else ""
            print(f"   {alpha:5.3f}   {a:.5f}         {b:.5f}       {c:.5f}   {d:.5f}         {e:.5f}{flag}", flush=True)
