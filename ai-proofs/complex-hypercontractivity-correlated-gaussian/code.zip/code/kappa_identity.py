"""Symbolic verification of the identity linking the narrow-Gaussian coefficient kappa(z) to the
L^q-contraction region Omega_{q,q}.

s = 1 - z^2, A = Re(1/s), C = Re(z/s).  kappa(z) = -A/2 + 1/(2q) + q C^2 / (2(1 - q + qA)).
Omega_{q,q}:  (q-2)|1 - z^2| <= q (1 - |z|^2).
"""
import sympy as sp

x, y, q = sp.symbols('x y q', real=True)
z = x + sp.I * y
s = sp.expand(1 - z**2)
sr, si = sp.re(s), sp.im(s)
m2 = sr**2 + si**2                      # |s|^2
A = sr / m2                              # Re(1/s)
zs = sp.expand(z * sp.conjugate(s))
C = sp.re(zs) / m2                       # Re(z/s)
den = 1 - q + q * A
num = sp.together((q * A - 1) * (q * A - q + 1) - q**2 * C**2)   # kappa <= 0  <=>  num >= 0 (when den > 0)
N, Dn = sp.fraction(sp.factor(num))
print("numerator of (qA-1)(qA-q+1) - q^2 C^2 :", sp.factor(N))
print("denominator:", sp.factor(Dn))
r2 = x**2 + y**2
omega = sp.expand(q**2 * (1 - r2)**2 - (q - 2)**2 * m2)          # >= 0  <=>  z in Omega_{q,q}
print("Omega_qq polynomial factor:", sp.factor(omega))
ratio = sp.simplify(sp.factor(N) / sp.factor(omega))
print("ratio numerator/Omega-polynomial:", sp.factor(ratio))
print("den*|s|^2 =", sp.factor(sp.expand(den * m2)))
