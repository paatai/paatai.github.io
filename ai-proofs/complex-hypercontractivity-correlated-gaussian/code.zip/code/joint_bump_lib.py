"""Large-deviation exponents for the joint narrow-bump test of the two-function downward inequality

    || T_z f(X) T_z g(Y) ||_r <= || f(X) g(Y) ||_p   (r >= 2, (X, Y) rho-correlated standard Gaussians),

with f = 1 - 2 b1, g = 1 - 2 b2, b_i in [0, 1].  Exact identity: |T f(X) T g(Y)| = |1 - 2 T b1(X)| |1 - 2 T b2(Y)|.

A "piece" is e(x) = exp(-B x^2/2 + t eta x - t^2 tau^2/(2B)) with eta = tau + i Om (Om = 0: a real bump b = e;
Om != 0: one of the two oscillating components of b = env (1 + cos(t Om x + th))/2).  Its Mehler image satisfies
    |T_z e(x)|^r = |D|^{-r/2} exp( t^2 k - a x^2/2 + t h x ),  D = 1 + (1 - z^2) B,
with a = r B Re(z^2/D), h = r Re(z eta/D), k = r (Re((1 - z^2) eta^2/(2D)) - tau^2/(2B)); and
lim t^-2 log E env = m = -tau^2/(2B(1+B)).  In the scaling x = t u the log-integrand of
E|T e1(X)|^r |T e2(Y)|^r is t^2 [l1(u1) + l2(u2) - u^T Sigma^-1 u / 2], l_i(u) = k_i - a_i u^2/2 + h_i u.

Joint excess (exponent of the part of E|T f T g|^r - 1 that needs BOTH factors large):
  * K = Sigma^-1 + diag(a) positive definite, maximiser u* = K^-1 h feasible (l1(u1*) > 0, l2(u2*) > 0):
        J = k1 + k2 + h^T K^-1 h / 2 - max(m1, m2);
  * a1 < 0, a2 < 0 and K not positive definite: E|T f T g|^r = oo (J = +oo);
  * otherwise -oo.
The feasibility requirement is a conservative extra restriction for this exploratory scan. The rigorous
criterion (Lemma 10.3 of the accompanying paper: E|Tf(X)Tf(Y)|^r >= 1 - 8r Eb + 4J - 2^{r+1} S) needs only
lim t^-2 log J > lim t^-2 log E b, so the scanned radii are upper bounds for the joint-bump radius.
"""
import numpy as np


def piece(z, B, tau, Om, r):
    s = 1 - z * z
    D = 1 + s * B
    eta = tau + 1j * Om
    a = r * B * (z * z / D).real
    h = r * (z * eta / D).real
    k = r * ((s * eta * eta / (2 * D)).real - tau * tau / (2 * B))
    m = -tau * tau / (2 * B * (1 + B))
    return a, h, k, m


def single_excess(z, B, tau, Om, r):
    """lim t^-2 log(E|T e|^r 1{|T e| > 1} / E env) (one function, g = 1); +oo if not integrable."""
    a, h, k, m = piece(z, B, tau, Om, r)
    if 1 + a <= 0:
        return np.inf if a < 0 else -np.inf
    u = h / (1 + a)
    if k - a * u * u / 2 + h * u <= 0:
        return -np.inf
    return k + h * h / (2 * (1 + a)) - m


def joint_excess(z, B1, tau1, Om1, B2, tau2, Om2, rho, r):
    a1, h1, k1, m1 = piece(z, B1, tau1, Om1, r)
    a2, h2, k2, m2 = piece(z, B2, tau2, Om2, r)
    Si = np.array([[1.0, -rho], [-rho, 1.0]]) / (1 - rho * rho)
    K = Si + np.diag([a1, a2])
    if not np.all(np.isfinite(K)) or not np.isfinite(h1 + h2 + k1 + k2):
        return -np.inf
    ev = np.linalg.eigvalsh(K)
    if ev[0] <= 1e-14 * max(1.0, abs(ev[1])):
        return np.inf if (a1 < 0 and a2 < 0 and ev[0] < 0) else -np.inf
    h = np.array([h1, h2])
    u = np.linalg.solve(K, h)
    l1 = k1 - a1 * u[0] ** 2 / 2 + h1 * u[0]
    l2 = k2 - a2 * u[1] ** 2 / 2 + h2 * u[1]
    if l1 <= 0 or l2 <= 0:
        return -np.inf
    return k1 + k2 + 0.5 * h @ u - max(m1, m2)
