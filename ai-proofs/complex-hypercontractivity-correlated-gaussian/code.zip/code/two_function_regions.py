"""Two-function downward inequality for general z (rho-correlated pair): radii of the known inner and outer
bounds along rays, for illustration (floating point; evidence only).

Inequality:  || T_z f(X) T_z g(Y) ||_r <= || f(X) g(Y) ||_p,  r < p,  (X, Y) rho-correlated.
Outer bound  N: all second-order conditions  z^n in Omega_{p(1 +- rho^n), r(1 +- rho^n)}.
Inner bound S1: z in Omega_{s(1+rho), s(1+rho)} cap Omega_{s(1-rho), s(1-rho)} for some s in [r, p]
               ([IK25, Thm 1] at alpha = 1 with exponent s, then Lyapunov).
Inner bound S2: z in C_{P,Q}, P = p(1-rho), Q = r(1+rho)  (Nelson + Borell reverse + single-function theorem):
               Omega_{P,Q} if Q >= P, Omega_{s,s} with s = clamp(Q; 2, P) if Q < P.
"""
import numpy as np


def omega_ok(z, P, Q, nw=361):
    th = np.linspace(0, np.pi, nw)
    w = np.exp(1j * th)
    lhs = (Q - 1) * (z * w).real ** 2 + (z * w).imag ** 2
    rhs = (P - 1) * w.real ** 2 + w.imag ** 2
    return bool(np.all(lhs <= rhs + 1e-12))


def radius(pred, alpha):
    if not pred(0.0 * np.exp(1j * alpha)):
        return 0.0
    lo, hi = 0.0, 1.0
    if pred(hi * np.exp(1j * alpha)):
        return 1.0
    for _ in range(40):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if pred(mid * np.exp(1j * alpha)) else (lo, mid)
    return lo


def N_pred(rho, p, r, nmax=40):
    def ok(z):
        for n in range(1, nmax + 1):
            for sg in (1, -1):
                if not omega_ok(z ** n, p * (1 + sg * rho ** n), r * (1 + sg * rho ** n)):
                    return False
        return True
    return ok


def S1_pred(rho, p, r, ns=41):
    # Omega_{s(1+rho)} cap Omega_{s(1-rho)} is largest at s* = 2/(1-rho^2) (conjugate exponents), clamped to
    # [max(r,1), p]; the grid is kept as a safeguard (an earlier version used the grid alone and missed s*).
    lo = max(r, 1.0)
    sstar = min(max(2 / (1 - rho * rho), lo), p)
    ss = np.append(np.linspace(lo, min(p, 1e3), ns), sstar)
    def ok(z):
        return any(omega_ok(z, s * (1 + rho), s * (1 + rho)) and omega_ok(z, s * (1 - rho), s * (1 - rho)) for s in ss)
    return ok


def S2_pred(rho, p, r):
    P, Q = p * (1 - rho), r * (1 + rho)
    def ok(z):
        if Q >= P:
            return omega_ok(z, P, Q)
        s = min(P, max(Q, 2.0))
        return omega_ok(z, s, s)
    return ok


if __name__ == "__main__":
    for (rho, p, r) in [(0.5, 10.0, 2.0), (0.5, 6.0, 3.0), (0.3, 8.0, 4.0)]:
        print(f"rho={rho}, p={p}, r={r}:  P=p(1-rho)={p*(1-rho):.3f}, Q=r(1+rho)={r*(1+rho):.3f}")
        print("   arg z    r_S1     r_S2     r_N      (inner bounds S1, S2; outer bound N)")
        for alpha in [0.0, 0.3, 0.6, 0.9, 1.2, np.pi / 2]:
            a = radius(S1_pred(rho, p, r), alpha)
            b = radius(S2_pred(rho, p, r), alpha)
            c = radius(N_pred(rho, p, r), alpha)
            print(f"   {alpha:5.3f}   {a:.5f}  {b:.5f}  {c:.5f}" + ("   <- gap" if c > max(a, b) + 1e-6 else ""))
