"""Sanity check of the two-function threshold on the imaginary axis (rho-correlated pair, z = i y).

Claim: for 0 <= rho < 1, p (1 - rho) >= 1, r > 0, the inequality
    || T_{iy} f(X) T_{iy} g(Y) ||_r <= || f(X) g(Y) ||_p     (all polynomials f, g, all dimensions)
holds iff  y^2 <= Y2 := min{ 1, p(1-rho) - 1, 1/(r(1+rho) - 1) }  (last term = inf if r(1+rho) <= 1).

Necessity: all second-order conditions z^n in Omega_{p(1 +- rho^n), r(1 +- rho^n)}, n >= 1 (indefinite forms allowed).
Sufficiency: Nelson + Borell reverse hypercontractive Hoelder reduce to || T_{iy} h ||_Q <= || h ||_P with
P = p(1-rho), Q = r(1+rho), whose region on the imaginary axis is known (Weissler/Lieb/Janson if Q >= P,
Proposition 9.1 of the accompanying paper if Q < P; for Q <= 1 use || . ||_Q <= || . ||_{Q1}, Q1 in (1, P)).
This script compares (a) the threshold of the brute-force second-order conditions, (b) the threshold of the
single-function region used for sufficiency, and (c) the closed formula Y2, on a grid of (rho, p, r).
Floating point; evidence only (the proof is in the accompanying paper).
"""
import numpy as np


def in_Omega(z, P, Q, nw=721):
    """|z w|_Q^2 <= |w|_P^2 for all w (forms |w|_s^2 = (s-1)(Re w)^2 + (Im w)^2, possibly indefinite)."""
    th = np.linspace(0, np.pi, nw)
    w = np.exp(1j * th)
    lhs = (Q - 1) * (z * w).real ** 2 + (z * w).imag ** 2
    rhs = (P - 1) * w.real ** 2 + w.imag ** 2
    return np.all(lhs <= rhs + 1e-12)


def nec_threshold(rho, p, r, nmax=60):
    """largest y^2 (bisection) such that all second-order conditions hold for z = i y."""
    def ok(y2):
        z = 1j * np.sqrt(y2)
        for n in range(1, nmax + 1):
            zn = z ** n
            for sgn in (+1, -1):
                if not in_Omega(zn, p * (1 + sgn * rho ** n), r * (1 + sgn * rho ** n)):
                    return False
        return True
    if not ok(0.0):
        return None
    lo, hi = 0.0, 4.0
    for _ in range(50):
        mid = (lo + hi) / 2
        lo, hi = (mid, hi) if ok(mid) else (lo, mid)
    return lo


def suff_threshold(rho, p, r):
    """largest y^2 with i y in C_{P,Q} (single-function, all dimensions), P = p(1-rho), Q = r(1+rho)."""
    P, Q = p * (1 - rho), r * (1 + rho)
    if P < 1 - 1e-9:
        return None
    P = max(P, 1.0)
    if Q <= 1:
        Q = min(1.0 + 1e-9, P)  # || . ||_Q <= || . ||_{Q1}; take Q1 just above 1 (or P)
    if Q >= P:                  # upward: Omega_{P,Q} on the imaginary axis
        return min(1.0 / (Q - 1) if Q > 1 else np.inf, P - 1)
    s = min(P, max(Q, 2.0))     # downward: Omega_{s,s} (Proposition 9.1)
    return min(s - 1, 1.0 / (s - 1)) if s != 2 else 1.0


def formula(rho, p, r):
    P, Q = p * (1 - rho), r * (1 + rho)
    if P < 1 - 1e-9:
        return None
    P = max(P, 1.0)
    return min(1.0, P - 1, 1.0 / (Q - 1) if Q > 1 else np.inf)


if __name__ == "__main__":
    worst = 0.0
    n = 0
    for rho in [0.0, 0.1, 0.3, 0.5, 0.7, 0.9]:
        for p in [1.5, 2.0, 3.0, 6.0, 10.0]:
            for r in [0.5, 1.2, 2.0, 3.0, 5.0, 8.0, 12.0]:
                a, b, c = nec_threshold(rho, p, r), suff_threshold(rho, p, r), formula(rho, p, r)
                if c is None:
                    assert a is None and b is None, (rho, p, r, a, b)
                    continue
                n += 1
                err = max(abs(a - c), abs(b - c))
                worst = max(worst, err)
                if err > 1e-6:
                    print("MISMATCH rho=%.2f p=%.1f r=%.1f: necessary %.6f sufficient %.6f formula %.6f" % (rho, p, r, a, b, c))
    print("cases:", n, " max |threshold - formula| =", worst)
