"""Random-Gaussian stress test of the two-function inequality on the imaginary axis (floating point).

(X, Y) rho-correlated standard normals (k = 1). For f(x) = exp(b1 x^2/2 + c1 x), g(y) = exp(b2 y^2/2 + c2 y) with
complex b, c, both sides of  ||T_{iy} f(X) T_{iy} g(Y)||_r <= ||f(X) g(Y)||_p  are Gaussian integrals:
T_z e^{b x^2/2 + c x} = D^{-1/2} exp(b' x^2/2 + c' x + tau), D = 1 - b s, b' = b z^2/D, c' = c z/D, tau = s c^2/(2D),
s = 1 - z^2;  E exp(v^T x + x^T M x / 2) = det(I - S M)^{-1/2} exp(v^T (S^{-1} - M)^{-1} v / 2) for x ~ N(0, S).
We maximise log LHS - log RHS over random (b, c) at y^2 = (1 - eps) * Y2 (inside; expect <= 0 up to rounding) and
at y^2 = (1 + eps) * Y2 (outside; expect > 0 for some test function), Y2 = min{1, p(1-rho)-1, 1/(r(1+rho)-1)}.
"""
import numpy as np

rng = np.random.default_rng(0)


def gauss_moment(S, M, v):
    """log E exp(v.x + x.M.x/2), x ~ N(0,S), real symmetric M, real v; None if divergent."""
    A = np.linalg.inv(S) - M
    if np.any(np.linalg.eigvalsh(A) <= 1e-12):
        return None
    sign, logdet = np.linalg.slogdet(np.eye(len(v)) - S @ M)
    if sign <= 0:
        return None
    return -0.5 * logdet + 0.5 * v @ np.linalg.solve(A, v)


def T(z, b, c):
    s = 1 - z * z
    D = 1 - b * s
    return D, b * z * z / D, c * z / D, s * c * c / (2 * D)


def log_ratio(rho, p, r, y, b1, c1, b2, c2):
    S = np.array([[1.0, rho], [rho, 1.0]])
    z = 1j * y
    # left side: |T f(X) T g(Y)|^r
    D1, bb1, cc1, t1 = T(z, b1, c1)
    D2, bb2, cc2, t2 = T(z, b2, c2)
    M = r * np.diag([bb1.real, bb2.real])
    v = r * np.array([cc1.real, cc2.real])
    L = gauss_moment(S, M, v)
    if L is None:
        return None
    L = (L + r * (t1.real + t2.real) - (r / 2) * (np.log(abs(D1)) + np.log(abs(D2)))) / r
    # right side: |f(X) g(Y)|^p
    M = p * np.diag([b1.real, b2.real])
    v = p * np.array([c1.real, c2.real])
    R = gauss_moment(S, M, v)
    if R is None:
        return None
    return L - R / p


def search(rho, p, r, y, n=4000):
    best = -np.inf
    for _ in range(n):
        sc = 10 ** rng.uniform(-3, 0)
        b1, b2 = sc * (rng.normal() + 1j * rng.normal()), sc * (rng.normal() + 1j * rng.normal())
        c1, c2 = sc * (rng.normal() + 1j * rng.normal()), sc * (rng.normal() + 1j * rng.normal())
        if rng.random() < 0.5:   # symmetric / antisymmetric directions, as in the second-order analysis
            sg = rng.choice([1, -1])
            b2, c2 = b1, sg * c1
        lr = log_ratio(rho, p, r, y, b1, c1, b2, c2)
        if lr is not None and lr > best:
            best = lr
    return best


def targeted(rho, p, r, y):
    """real exponentials e^{eps x}, e^{+-eps y}: the first-chaos directions behind the bounds P-1 and 1/(Q-1)."""
    best = -np.inf
    for eps in [1e-3, 1e-2, 0.05, 0.1, 0.2, 0.4]:
        for sg in (1, -1):
            for c in (eps, 1j * eps):
                lr = log_ratio(rho, p, r, y, 0j, c, 0j, sg * c)
                if lr is not None:
                    best = max(best, lr)
    return best


if __name__ == "__main__":
    for rho, p, r in [(0.5, 10.0, 2.0), (0.5, 6.0, 3.0), (0.3, 8.0, 4.0), (0.2, 3.0, 1.5), (0.6, 4.0, 1.2)]:
        P, Q = p * (1 - rho), r * (1 + rho)
        Y2 = min(1.0, P - 1, 1 / (Q - 1) if Q > 1 else np.inf)
        inside = max(search(rho, p, r, np.sqrt(0.98 * Y2)), targeted(rho, p, r, np.sqrt(0.98 * Y2)))
        outside = max(search(rho, p, r, np.sqrt(1.05 * Y2)), targeted(rho, p, r, np.sqrt(1.05 * Y2)))
        print(f"rho={rho} p={p} r={r}: Y2={Y2:.4f}  max log-ratio inside {inside:+.3e}   outside {outside:+.3e}")
