"""
Exact symbolic verification (sympy) of the algebraic identities used in the paper
"Complex hypercontractivity for several correlated Gaussian functions below the diagonal".

All equalities are checked as  simplify(LHS - RHS) == 0  with z = x + i y, x, y, q real:

  (1)  |1 - z^2|^2            = (1 - |z|^2)^2 + 4 y^2
  (2)  F1^{(q)}              = 2 delta_q |1 - z^2|^2
  (3)  kappa_q               = F2^{(q)} / (4 q F1^{(q)})
  (4)  F1^{(q)}              = 2q(Re z^2 - |z|^4) + 2|1 - z^2|^2
  (5)  F2^{(q)}              = 4 q^2 y^2 - 4(q-1) |1 - z^2|^2
  (6)  det(I - N^T N)        = -F2^{(q)} / (4(q-1)),   N = G^{1/2} R G^{-1/2}
  (7)  ||N||_F^2             = 2x^2 + (q-1) y^2 + y^2/(q-1)

where  A = Re(1/s), C = Re(z/s), s = 1 - z^2, delta_q = 1 - q + qA,
kappa_q = -A/2 + 1/(2q) + q C^2 / (2 delta_q),
F1 = q(1-|z|^4) - (q-2)|1-z^2|^2,  F2 = (q-2)^2 |1-z^2|^2 - q^2 (1-|z|^2)^2,
R = [[x,-y],[y,x]] is multiplication by z, and G = diag(q-1, 1).

Identities (6)-(7) give Omega_q cap D = {F2 <= 0}: positive semidefiniteness of
I - N^T N (equivalently sigma_max(N) <= 1, i.e. z in Omega_q) is det >= 0 and trace >= 0;
det = -F2/(4(q-1)) is >= 0 iff F2 <= 0, and on {F2 <= 0} cap D the trace is >= 0 as well.
"""

import sympy as sp

x, y, q = sp.symbols('x y q', real=True)
z = x + sp.I * y
mod2 = x**2 + y**2                       # |z|^2
sigma = 1 - z**2
S = sp.expand(sp.re(sigma)**2 + sp.im(sigma)**2)   # |1 - z^2|^2 (real)

A = sp.re(1 / sigma)
C = sp.re(z / sigma)
delta = 1 - q + q * A
kappa = -A / sp.Integer(2) + 1 / (2 * q) + q * C**2 / (2 * delta)

F1 = q * (1 - mod2**2) - (q - 2) * S
F2 = (q - 2)**2 * S - q**2 * (1 - mod2)**2

results = []


def chk(name, expr):
    e = sp.simplify(sp.together(expr))
    ok = (e == 0)
    results.append(ok)
    print(f"  {'ok  ' if ok else 'FAIL'} {name}")
    if not ok:
        print(f"       residual = {e}")


chk("(1)  |1-z^2|^2 = (1-|z|^2)^2 + 4y^2", S - ((1 - mod2)**2 + 4 * y**2))
chk("(2)  F1 = 2 delta_q |1-z^2|^2", F1 - 2 * delta * S)
chk("(3)  kappa_q = F2/(4 q F1)", kappa - F2 / (4 * q * F1))
chk("(4)  F1 = 2q(Re z^2 - |z|^4) + 2|1-z^2|^2", F1 - (2 * q * (sp.re(z**2) - mod2**2) + 2 * S))
chk("(5)  F2 = 4 q^2 y^2 - 4(q-1)|1-z^2|^2", F2 - (4 * q**2 * y**2 - 4 * (q - 1) * S))

g1 = sp.sqrt(q - 1)
R = sp.Matrix([[x, -y], [y, x]])            # multiplication by z on (Re, Im)
G12 = sp.diag(g1, 1)                         # G^{1/2}, G = diag(q-1, 1)
G12inv = sp.diag(1 / g1, 1)
N = G12 * R * G12inv
M = sp.eye(2) - N.T * N

chk("(6)  det(I - N^T N) = -F2/(4(q-1))", M.det() - (-F2 / (4 * (q - 1))))
NF2 = (N.T * N).trace()
chk("(7)  ||N||_F^2 = 2x^2 + (q-1)y^2 + y^2/(q-1)",
    NF2 - (2 * x**2 + (q - 1) * y**2 + y**2 / (q - 1)))

print("\nALL OK" if all(results) else "\nSOME CHECKS FAILED")
raise SystemExit(0 if all(results) else 1)
