# LaTeX source of "A catalogue of 58 candidate stellar anomalies from Gaia and public time-domain surveys"

This is the complete source of the paper by Paata Ivanisvili published as `galaxy-58-candidates-paper.pdf`
(261 pages).

## Contents

| Path | Contents |
|---|---|
| `main.tex` | The paper |
| `tex/catalogue.tex`, `tex/summary_table.tex`, `tex/ack_rest.tex` | Catalogue entries, summary table and the remaining acknowledgments, read by `main.tex` |
| `refs.bib` | Bibliography (biblatex, biber backend) |
| `main.bbl` | The bibliography as produced by biber 2.19, so that the paper also compiles without biber |
| `figures/cand/NN/` | Figures of candidate NN (JPEG) |
| `figures/summary/` | Sky map, event types, probability histogram and timeline (PDF) |

No custom class or style files are needed. The paper uses the standard `article` class and these TeX Live packages:
fontenc, inputenc, newtx, geometry, microtype, graphicx, xcolor, booktabs, longtable, tabularx, array, pdflscape,
placeins, enumitem, fancyhdr, caption, tikz, biblatex and hyperref.

## Compiling

```bash
latexmk -pdf main.tex
```

This runs pdfLaTeX and biber. Without biber, run `pdflatex main.tex` four times; it then uses the included `main.bbl`.

The source was tested with TeX Live 2023: pdfTeX 1.40.25, biblatex 3.19, biber 2.19 and latexmk 4.83.

## Reproducing the published PDF exactly

pdfTeX writes the build time into the PDF and uses it for the PDF's file identifier, so an ordinary build differs from
the published file in those few bytes only. Setting the build time to that of the published file gives a byte-identical
PDF with TeX Live 2023 (sha256 `fc0de8f0b37ed8f605c4f5d1e267e95e8e6e8d7c4242d146eb0b61703ad83bf3`):

```bash
SOURCE_DATE_EPOCH=1793744447 FORCE_SOURCE_DATE=1 latexmk -pdf main.tex
```
